# Process all customers
for domain in QA
do
	echo ""
	echo "******************************"
	echo "Executing domain: $domain"
	echo "******************************"
	echo ""
	go_restart.py --app $domain
done

echo ""
echo "****************************  Tests Completed *************************"
echo ""


