#!/bin/bash

mkdir -p /home/tra/.snmp/mibs
cp /opt/tra/data/snmp/mibs/* /opt/tra/conf
cd /home/tra/.snmp/mibs
rm -f matrixx_*.txt
ln -s /opt/tra/conf/matrixx_mib.txt .
ln -s /opt/tra/conf/matrixx_smi.txt .
ln -s /opt/tra/conf/matrixx_rc_mib.txt .
ln -s /opt/tra/conf/matrixx_tra_mib.txt .
ln -s /opt/tra/conf/matrixx_common_mib.txt .

echo mibs +MATRIXX-SMI > /home/tra/.snmp/snmp.conf
echo mibs +MATRIXX-MIB >>  /home/tra/.snmp/snmp.conf
echo mibs +MATRIXX-COMMON-MIB >>  /home/tra/.snmp/snmp.conf
echo mibs +MATRIXX-TRA-MIB >>  /home/tra/.snmp/snmp.conf


