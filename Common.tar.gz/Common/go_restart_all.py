#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:45
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:25
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:06
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


import shutil
import os
import qa_utils as QAUTILS

#==========================================================

def main():
    # Overwrite default customer if environment variable is set
    if os.path.expandvars('$customer'):
        defCustomer = os.path.expandvars('$customer')
    else:
        defCustomer = 'QA'
    
    suites = ['vtime', 'base']

    for suite in suites :

        if suite == 'vtime' :
            cmd = 'go_restart.py -o vtime -n ' + suite
        else :
            cmd = 'go_restart.py -n ' + suite
        print(cmd)
        os.system(cmd) 

        print("============= " + suite + " test suite run is done ================") 

if __name__ == '__main__':
    main()

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
