#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Wed 2021-08-25T11:31:51
# @futurize --stage2 --no-diffs -n -w  : Wed 2021-08-25T11:31:49
#
# @futurize --stage1 --no-diffs -n -w  : Wed 2021-08-25T11:31:47
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


# from builtins import str
# from builtins import str
import os,sys, shutil
import log_errors as LOGGER
import re
import qa_utils as QAUTILS
import time
import optparse
import common_mdc as COMMON

SUBSCLIST=[]     #this array hold list of subsc Ids as we parse outQuery file
initialRun = 1   #this val is used to determine whether to delete validation file
detailedMsg=''
TOTAL_result = {}
TOTAL_expect = {}
testErrorLogger = None

#===================================================
# the purpose of this function is to blank out the variable ID value from the file names
# ex: a file with this name: DCT_270_mtx_test_group_usage_3d_postOff
# will be mtx_test_group_usage_3d_postOff
#===================================================
def findExpectFile(path,resultFile, stringToCheckFor='mtx'):
    resultFileNoPath = resultFile.split('/')[-1]
    fCmpTrsf = re.sub('trsf_(.*)'+stringToCheckFor,stringToCheckFor,resultFileNoPath)
    fCmpEct = re.sub('ECT_(.*)'+stringToCheckFor,stringToCheckFor,fCmpTrsf)
    expectDir = path + '/expect/'
    listDir = os.listdir(expectDir)
    for file1 in listDir:
        if file1.startswith('trsf') or file1.startswith('ECT'): 
            f1 = re.sub('trsf_(.*)'+stringToCheckFor,stringToCheckFor,file1)
            f2 = re.sub('ECT_(.*)'+stringToCheckFor,stringToCheckFor,f1)
            if fCmpEct == f2:
                return expectDir + file1
            if str(fCmpTrsf) == str(f1):
                return expectDir + file1
    return

def cmpTrsfResults(path, allFilesList, stringToCheckFor='mtx'):
    print('allMdcFilesList = ' + str(allFilesList))
    retCode = 0
    fileList = open(allFilesList, 'r')
    for resultFile in fileList:
        resultFile = resultFile.strip('\n')
        testTag = resultFile.split('/')[-1]
        if not testTag.startswith('ECT_'):
            expectFile = findExpectFile(path, resultFile, stringToCheckFor)
        elif not testTag.startswith('ECT_diameter'):
            expectFile = re.sub(COMMON.resultsDir,'expect',resultFile)
        else: continue

        print('expectFile = ' + str(expectFile))
        print('resultFile = ' + resultFile)
        if (expectFile != None):
            if not os.path.isfile(expectFile):
                retCode = -1
            elif not os.path.isfile(resultFile):
                retCode = 100
            else:
                suiteDir=os.path.dirname(os.getcwd())
                createDiffFile = suiteDir+"/createDiff.sh"
                inclusionList = None
                #add list of parameter that you want to include in the diff
                inclusionList = checkConfigIniForInclusion(path)
                if inclusionList:
                    createNewDiff(path, inclusionList)
                    cmd = '/bin/bash ' + path + '/qaDiffLocal.sh' + ' ' + resultFile + ' ' + expectFile + ' ' + path 
                elif os.path.isfile(createDiffFile):
                    commonDiffFile = os.path.expandvars('$QADIR/Common/qaDiff.sh')
                    localDiffFile = suiteDir+"/qaDiff.sh"
                    shutil.copy2(commonDiffFile, suiteDir)
                    QAUTILS.runCmd('/bin/bash ' + createDiffFile + ' ' + localDiffFile)
                    ## use the suite specific qaDiff.sh script  
                    cmd = '/bin/bash ' + localDiffFile + ' ' + resultFile + ' ' + expectFile + ' ' + path 
                else :
                    cmd = '/bin/bash ' + os.path.expandvars('$QADIR/Common/qaDiff.sh') + ' ' + resultFile + ' ' + expectFile + ' ' + path 
                #print 'cmd = ' + cmd
                retCode = QAUTILS.runCmd(cmd)

                if retCode + 'A' == 'A': 
                    retCode = 0
                else:
                    retCode = 1000
        else:
            retCode = -1
            
        checkDiffRetCode(path, retCode, testTag)
        retCode = 0

def checkDiffRetCode(path, retCode, testTag):
    if not retCode:
        testErrorLogger.printSummary(path, testTag + '==> Passed')
    elif(retCode == -1):
        testErrorLogger.printSummary(path, testTag + '==> Failed (missing expect file)')
    elif(retCode == 100):
        testErrorLogger.printSummary(path, testTag + '==> Failed (missing res file)')
    else:
        testErrorLogger.printSummary(path, testTag + '==> Failed (diffile)') #+ str(retCode))

def getListofMDCs(path):
    allMdcFilesList = path + '/' + COMMON.resultsDir + '/allMdcFilesList'
    if not (os.path.isfile(allMdcFilesList)):
        testErrorLogger.printRes(path,'validate_balances.txt','Cannot validate: missing ' + allMdcFilesList)
        sys.exit('Cannot validate: missing ' + allMdcFilesList + '.  This is OK if the test does all validation within the test.')
    testErrorLogger.printRes(path,'validate_balances.txt','******** START compare MDC at: ' + \
        time.strftime("%Y-%m-%dT%H:%M:%S",time.localtime(time.time())) + ' ******\n' )
    return allMdcFilesList

def checkConfigIniForInclusion(path):
    inclusionList = None
    #if config.ini file exists in mtx_test_* directory, find the inclusionList
    if os.path.exists(path + "/config.ini"):
       inclusionList0 = QAUTILS.runCmd("grep validateList " + path + "/config.ini")
    else:
       #no config.ini file exist, such as swisscom csv suite, return empty inclusionList
       return inclusionList

    if inclusionList0:
       inclusionList = inclusionList0.split("=")[1]
       return inclusionList

def createNewDiff(path, inclusion):
    inclusionList = inclusion.split(',')
    if not inclusionList: return
    #print 'inclusionList =', inclusionList
    QAUTILS.runCmd("cp " + path + "/../../../../Common/qaDiff.sh qaDiffLocal.sh")
    for inclusionString in inclusionList:
        inclusionString = re.sub(' ','', inclusionString)
        #only delete exactly matched the inclusionString
        # i.e.  only delete OfferStatus line, not delete OfferStatusClass or OfferStatusValue line
        QAUTILS.runCmd("sed -i \'/|" + inclusionString + "\"/d\' qaDiffLocal.sh")

def main():
    global testErrorLogger
    global detailedMsg
    path = os.getcwd()
    expectPath= path + '/expect'
    res=0
    
    # Allow for an input string to specify target results directory file names
    parser = optparse.OptionParser()
    parser.add_option("-s", "--string", action='store', type='string', default='mtx')
    parser.add_option("", "--resultsDir", action='store', type='string', default=None)
    (options, args) = parser.parse_args()
    
    # Update global data is resultsDir was passed in
    if options.resultsDir: COMMON.resultsDir = options.resultsDir
    
    # Initialize the logger
    testErrorLogger = LOGGER.clErrors(path)
    
    # qaDiff.sh supports defining environment variables to control the diffs.  
    # The local file (in the test directory) will have variable=value lines one per line).
    # Read those in here if the file exists (nothing changed if file doesn't exist).
    # File with environment variables to use.
    envFile = path + '/EnvironmentVariables'
    print('envFile = ' + envFile)
    
    # See if local file exists to set environment variables
    if os.path.exists(envFile):
                # Open the file
                f = open(envFile, 'r')
                
                # Process each line
                for line in f:
                        # Skip if empty or starts with "#" (comment)
                        if not line.strip() or line[0] == '#': continue

                        # Split the line on the equal sign
                        (variable,value) = line.split('=')

                        # Remove white space
                        variable = variable.strip()
                        value = value.strip()
                        
                        # Get current value
                        current = os.getenv(variable, 'None')
                        
                        # Assign environment variable
                        os.environ[variable] = value
                        
                        # Debug before/after
                        print('Updated environment variable ' + variable + ' from "' + str(current) + '" to "' + os.getenv(variable, 'None') + '"')

                # Close the file
                f.close()

    filesToDiff = getListofMDCs(path)
    cmpTrsfResults(path, filesToDiff, options.string)


main()

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

