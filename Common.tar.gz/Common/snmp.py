#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:41:06
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:49
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:25
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
import sys, os, time, pprint
import data_container as MDC
import data_container_defs as MDCDEFS
import timeToMDCtime as MDCTIME
import commonDefs
import qa_utils as QAUTILS

# The following should be the ONLY CSV file included by any QA framework file
import csv_qa as CSVQA

snmpCommandPrefix = snmpPort = snmpIpAddr = None

# Defines for before/after
snmp_read_before="before"
snmp_read_after="after"

# Define global arrays for storing SNMP data
snmp_cmds = [ \
        'snmp_diam_session_requests_in_cmd', \
        'snmp_diam_session_responses_out_cmd', \
        'snmp_diam_capability_requests_in_cmd',\
        'snmp_diam_capability_responses_out_cmd', \
        'snmp_diam_error_query_cmd', \
        'snmp_diam_critical_query_cmd', \
        'snmp_chrg_error_query_cmd', \
        'snmp_chrg_critical_query_cmd', \
        'snmp_trans_error_query_cmd', \
        'snmp_trans_critical_query_cmd', \
        'snmp_diam_transient_error_query_cmd', \
        'snmp_diam_permanent_error_query_cmd' , \
        'snmp_diam_result_code_out_cmd', \
]

SNMP = []
snmp_before = {}
snmp_after = {}
snmp_delta = []
snmpInitialized = False

def snmpInitData():
        global SNMP
        global snmpPort
        global snmpIpAddr
        global snmpCommandPrefix
        
        # Init the sructure (in case this is called more than once)
        SNMP = []
        
        # Need to use the IP address on the host, not localhost.
        cmd = 'grep "SNMP:What port number do you want the SNMP Agent to listen on" /opt/mtx/custom/create_config.info | cut -f2 -d"?"'
        snmpPort = QAUTILS.runCmd(cmd)
        cmd = 'netstat -an | grep 4700 | cut -f1 -d":" | cut -c21-'
        snmpIpAddr = QAUTILS.runCmd(cmd)
        
        print('SNMP access: ' + snmpIpAddr + ':' + snmpPort)
        
        # Build command prefix
        snmpCommandPrefix = 'snmpwalk -v 2c -c public ' + snmpIpAddr + ':' + snmpPort + " MATRIXX-MIB::"
        
        # Want to get all possibilities
        mibOid = 'matrixxMIB'
        
        # Build command that returns every MIB object
        cmd = snmpCommandPrefix + mibOid + ' | cut -f3 -d: | cut -f1 -d" "'
        mibObj = QAUTILS.runCmd(cmd).split('\n')
        
        # Process each entry
        for entry in mibObj:
                # Split the entry
                entry = entry.split(".")
                
                # Want to add combinations of entries until we reach a numeric entry
                for i,item in enumerate(entry):
                        # If numeric then we're done
                        if item.isdigit(): break
                        
                        # Get item to append
                        if i == 0: itemToAppend = item
                        else:      itemToAppend = ".".join(entry[0:i+1])
                        
                        # If key already in entry, then done
                        if itemToAppend in SNMP: continue
                        
                        # Add to SNMP list
                        SNMP.append(itemToAppend)
                
        # Add the default 'all' entry
        SNMP.append('matrixxMIB')
        
        # Debug output
#       pprint.pprint(SNMP)
        
        '''
        # Setup SNMP GET command strings
        SNMP['snmp_diam_session_requests_in_cmd'] =     snmpCommandPrefix + "diamPduStatsTotalRequestsIn.4.272 | cut -f4 -d:"
        SNMP['snmp_diam_session_responses_out_cmd'] =   snmpCommandPrefix + "diamPduStatsTotalResponsesOut.4.272 | cut -f4 -d:"
        SNMP['snmp_diam_capability_requests_in_cmd'] =  snmpCommandPrefix + "diamPduStatsTotalRequestsIn.0.257 | cut -f4 -d:"
        SNMP['snmp_diam_capability_responses_out_cmd']= snmpCommandPrefix + "diamPduStatsTotalResponsesOut.0.257 | cut -f4 -d:"
        
        SNMP['snmp_diam_error_query_cmd'] =             snmpCommandPrefix + "sysServiceStatsErrors.diameter | cut -f4 -d:"
        SNMP['snmp_diam_critical_query_cmd'] =          snmpCommandPrefix + "sysServiceStatsCriticalErrors.diameter | cut -f4 -d:"
        SNMP['snmp_chrg_error_query_cmd'] =             snmpCommandPrefix + "sysServiceStatsErrors.charging | cut -f4 -d:"
        SNMP['snmp_chrg_critical_query_cmd'] =          snmpCommandPrefix + "sysServiceStatsCriticalErrors.charging | cut -f4 -d:"
        SNMP['snmp_trans_error_query_cmd'] =            snmpCommandPrefix + "sysServiceStatsErrors.transaction | cut -f4 -d:"
        SNMP['snmp_trans_critical_query_cmd'] =         snmpCommandPrefix + "sysServiceStatsCriticalErrors.transaction | cut -f4 -d:"
        
        SNMP['snmp_diam_transient_error_query_cmd'] =   snmpCommandPrefix + "diamTotalStatsTransientFailures.0 | cut -f4 -d:"
        SNMP['snmp_diam_permanent_error_query_cmd'] =   snmpCommandPrefix + "diamTotalStatsPermanentFailures.0 | cut -f4 -d:"
        SNMP['snmp_diam_result_code_out_cmd'] =         snmpCommandPrefix + "diamResultCodeStatsResultCodeOut.4.272.5030 | cut -f4 -d:"
        '''
        
def readSNMPValues(before_after, snmpMIBs='all'):
    global snmp_after
    global snmp_before
        
    if before_after == 'before':
        snmp_before = {}
        snmp_data = snmp_before
    else:
        snmp_after = {}
        snmp_data = snmp_after
    
    # Make sure input is a list
    if type(snmpMIBs) != type(list()): snmpMIBs = [snmpMIBs]
    
    # Read into the desired array
    for i,key in enumerate(SNMP):
        # See if we should filter this key out
        # Walk the list of MIB IDs to see if we want them
        foundFlag = False
        for mib in snmpMIBs:
                # If 'all' value then change to the actual string to query (only exception)
                if mib.lower() == 'all': mib = 'matrixxMIB'
                
                # See if entry matches the reuested MIB
                if key.startswith(mib):
                        foundFlag = True
                        break
        
        # If not found, then skip
        if not foundFlag: continue

        # Each key is a list of entries
        snmp_data[key] = QAUTILS.runCmd(snmpCommandPrefix + SNMP[i]).split("\n")

        # Shouldn't really get here...
        if not snmp_data[key]:
                print('Warning: Received a NULL value for key "' + key + '".')
                snmp_data[key] = None
    
    # Debug output
#    print before_after + ' values:'    
#    pprint.pprint(snmp_data)
    
def deltaSNMPValues():
    global snmp_delta
    
    # Clear the array
    snmp_delta = []
    
    # Read into the desired array
    for key in snmp_after:
        # Skip if identical.
        # cmp not working...
#       if cmp(snmp_after[key], snmp_before[key]): continue
        
        # Want to walk through each entry to see if different
        for i in range(len(snmp_after[key])):
                beforeValue = snmp_before[key][i].strip()
                afterValue = snmp_after[key][i].strip()
                
                # Skip if values are equal
                if beforeValue == afterValue: continue
                
                # Get the key name
                keyName = beforeValue.split(':')[2].split('=')[0].strip()
                
                # Get before/after values
                beforeValue = beforeValue.split(':')[3].strip()
                afterValue  = afterValue.split(':')[3].strip()
                
                # Get string
                snmp_delta.append((keyName + ' Before/After: ' + beforeValue + '/' + afterValue))

    # Debug output
#    print 'Delta values:'      
#    pprint.pprint(snmp_delta)
    
   
def deltaSNMPSave(outputFileName, snmpMIBs):
    # Init string
    outstr = 'SNMP Deltas for MIBs "' + str(snmpMIBs) + '": \n\n'
        
    # If no entries, then nothing to loop through
    if len(snmp_delta) == 0:
        outstr += 'None\n\n'
    else:
        # Create string
        for entry in snmp_delta: outstr += entry + '\n'

#    print outstr
    
    # Write to where the caller wanted it to go
    CSVQA.processDataToOutput(outstr, outputFileName)

def SNMPCommandSetup(lclDCT):
        global snmpInitialized
        
        # If not initialized yet, do that the first time
        if not snmpInitialized:
                snmpInitData()
                snmpInitialized = True
                
        # If snmpMIBs not set, then default using the action specified
        if not lclDCT['snmpMIBs'] or not len(lclDCT['snmpMIBs']):
                # Set for diameter
                if   lclDCT['ACTION'].startswith('diameter'):   lclDCT['snmpMIBs'] = ['diam']
                elif lclDCT['ACTION'].startswith('ccf'):        lclDCT['snmpMIBs'] = ['voice']
                else:                                           lclDCT['snmpMIBs'] = ['all']

        # If snmp diff desired then we need to save current MIB values
        if lclDCT['snmpCheck'] == 'diff':
                # Save the delta
                print('Saving SNMP data for MIBs: ' + str(lclDCT['snmpMIBs']))
                SNMPPre(lclDCT['snmpMIBs'])

def SNMPCheck(outputFileName, snmpMIBs='all'):
    # Get current values (don't overwrite the before in case it was saved from previous commands)
    readSNMPValues('after', snmpMIBs)
        
    # Init string
    outstr = 'SNMP MIB values for MIBs: "' + str(snmpMIBs) + '": \n\n'
    
    # Process each MIB
    for key in snmp_after:
        # Add each read item
        for i in range(len(snmp_after[key])): outstr += snmp_after[key][i] + '\n'

    # Write to where the caller wanted it to go
    CSVQA.processDataToOutput(outstr, outputFileName)

def SNMPPre(snmpMIBs='all'):
    readSNMPValues('before', snmpMIBs)

def SNMPPost(outputFileName, snmpMIBs='all'):
    readSNMPValues('after', snmpMIBs)
    deltaSNMPValues()
    deltaSNMPSave(outputFileName, snmpMIBs)

def main():
        snmpMIBs = 'diam'
        snmpInitData()
        print('before reading values')
        readSNMPValues(snmp_read_before, snmpMIBs)
#       pprint.pprint(snmp_before)
        print('after  reading values')
        readSNMPValues(snmp_read_after, snmpMIBs)
#       pprint.pprint(snmp_after)
        print('Getting Deltas')
        deltaSNMPValues()
        deltaSNMPSave('_none_')
        return

if __name__ ==  '__main__':
    main()

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

