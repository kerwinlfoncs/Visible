#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:41:09
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:52
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:18

# from builtins import str
# from builtins import str
import os, sys
import optparse
import qa_utils
import QA_print_diameter_time as diamTime
import time
import diameter as DIAM
import timeToMDCtime as MDCTIME


##################################################################################################
#this file takes seagull_t1_1_data.csv as input andincrement the eventtime by the options entered
# ex: generate_seagull_data.py -i month -d 1 -c 10 -n 100000
# will generate 10 seagull data files where eventTime is 1 month ahead of the prev file where num calls is 100000
#the runnable script will be runall_times.sh auto generated
#this script will also move session counter file in seagull
#it  expects a directory :
#back/seagull_t1_1_data.csv
#back/seagull_t1_1_scenario_ccr_cca_swisscom.xml
#back/seagull_t1_1_conf_client.xml
##################################################################################################

def main():
    parser = optparse.OptionParser()
    parser.add_option("-i", "--interval", action = "store" , default = "month", type = "string", help = "interval to increment by, day, hour, week ,month, etc..")
    parser.add_option("-d", "--delta", default = 1, type = "int", help = "delta to increment by like 1 for 1 day.")
    parser.add_option("-c", "--count", default = 1, type = "int", help = "how many iterations.")
    parser.add_option("-n", "--numbercalls", default = 0, type = "int", help = "how many calls per input file.")
    parser.add_option("-s", "--startsession", default = 1000, type = "int", help = "session ID to start with.")

    numEvents = getLineCount()
    (options, args) = parser.parse_args()
    iter = options.count
    interval = options.interval
    delta = options.delta
    startSession = int(options.startsession)
    numberCalls = int(options.numbercalls)

    if numberCalls == 0:   #we need this to jump session counter
        numberCalls = int(numEvents)

    offset = int(getEventTimeOffset())
    line = getEventTimeFromDataFile()  #get the timestamp from seagull input file
    
    print("8888888888888888 line=", line)
    #print line
    lineArr = line.split(";")
    print("converting string:", lineArr[offset])
    print("8888888888888888 line=", lineArr[offset])
    eventTime = DIAM.convertDiameterTimeToUnixTime(int(eval(lineArr[offset])))
    print("replacing :", eventTime)
    t1 = time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime(float(eventTime)))

    i = 0
    fp = open("runall_times.sh", "w")
    fp.write("cp back/seagull_t1_1_data.csv . \n")
    fp.write("cp back/seagull_t1_1_scenario_ccr_cca_swisscom.xml . \n")
    fp.write("cp back/seagull_t1_1_conf_client.xml . \n")
    cmd = "sed -i 's/name=\"number-calls\" value=\".*\">/name=\"number-calls\" value=\"" + str(numberCalls) + "\">/g\' seagull_t1_1_conf_client.xml"
    fp.write(cmd + "\n")
    startTime = t1
    print("startTimestartTimestartTime=", startTime)

    while i < iter:
        startTime = MDCTIME.getTime(delta, interval, startTime)
        print("startTime=", startTime)
        diamTime1 = diamTime.getTimeField(startTime.strip('Z'))
        print("diamTime1--------------------------------", diamTime1)
        filename = "seagull_t1_1_newdata_" + startTime + ".csv"
        cmd = "cat back/seagull_t1_1_data.csv | sed s/" + eval(lineArr[offset]) + "/" + diamTime1 + "/g > " + filename
        os.system(cmd)
        print(cmd)
        k = i + 1
        cmd = "sed -i 's/\"session_counter\" init=\".*\">/\"session_counter\" init=\"" + str(k * numberCalls + startSession)+ "\">/g' seagull_t1_1_scenario_ccr_cca_swisscom.xml"
        fp.write(cmd + "\n")
        st1  = "cp " + filename + " seagull_t1_1_data.csv" + "\n" + "echo n | ./run_test_1.py\n"
        fp.write(st1)
        i = i + 1

    fp.close()

    
def getLineCount():
    cmd = "wc -l back/seagull_t1_1_data.csv"
    line = qa_utils.runCmd(cmd)
    num = line.split(" ")
    return num[0]

def getEventTimeFromDataFile():
    st = qa_utils.runCmd("head -11 back/seagull_t1_1_data.csv | tail -1")  #assuming the file is always seagull_t1_1_data.csv 
    return st

def getEventTimeOffset():
    st = qa_utils.runCmd("head -10 back/seagull_t1_1_data.csv | tail -1")  #assuming the file is always seagull_t1_1_data.csv 
    l1 = st.split(' ')
    i = 0
    for x in l1:
        if x == '': continue
        if x == '#': continue
        print('xxxxxx=', x)
        if x == 'EventTime':
            print('EventTime found at offset', i)
            return i
        i += 1
    
main()
