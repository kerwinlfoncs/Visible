#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:29
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:10
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:34:55
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

#

# from builtins import str
# from builtins import str
import data_container as MDC
# Check if the data_container_defs.py needs to be re-created
import data_container_defs as MDCDEFS
import common_mdc as COMMON
import optparse
import os, string

xmlStatus=True
try:
    import xml_utils
except ImportError:
    xmlStatus=Flase

# Extraction of event_types from pricing file
EventTypeTree = None
outputFile = ''

# Get readable output for flag value
def getFlagStr(flagInt):
    flagStr = ''
    if flagInt & 1:
        flagStr += 'Aggregated,'
    if flagInt & 2:
        flagStr += 'Sponsored,'
    if flagInt & 4:
        flagStr += 'Reserve'
    if flagStr == '':
        flagStr = 'None'
    return flagStr

# Get readable output for balance update value
def getBalanceUpdateType(balanceUpdateTypeInt):
    if balanceUpdateTypeInt == 0:
        return 'None'
    elif balanceUpdateTypeInt == 1:
        return 'Charge'
    elif balanceUpdateTypeInt == 2:
        return 'Discount'
    elif balanceUpdateTypeInt == 3:
        return 'Grant'
    elif balanceUpdateTypeInt == 4:
        return 'Adjustment'
    elif balanceUpdateTypeInt == 5:
        return 'Cancel Refund'
    elif balanceUpdateTypeInt == 6:
        return 'Cancel Forfeiture'
    else:
        return 'Unknown'

# Get readable output for usage type value
def getUsageType(typeInt):
    if typeInt == 1:
        return 'Actual Duration'
    elif typeInt == 2:
        return 'Active Duration'
    elif typeInt == 3:
        return 'Monetary'
    elif typeInt == 4:
        return 'Total Data'
    elif typeInt == 5:
        return 'In Data'
    elif typeInt == 6:
        return 'Out Data'
    elif typeInt == 7:
        return 'Service Specific'
    else:
        return 'Unknown'

# Get readable output for usage unit value
def getUsageUnit(typeInt):
    if typeInt == 0:
        return 'None'
    elif typeInt == 100:
        return 'Seconds'
    elif typeInt == 101:
        return 'Minutes'
    elif typeInt == 102:
        return 'Hours'
    elif typeInt == 103:
        return 'Days'
    elif typeInt == 104:
        return 'Weeks'
    elif typeInt == 200:
        return 'Bytes'
    elif typeInt == 201:
        return 'Kilobytes'
    elif typeInt == 202:
        return 'Megabytes'
    elif typeInt == 203:
        return 'Gigabytes'
    else:
        return 'Unknown'

# Traverse event type tree to get readable output for event type
def getEventType(eventTypeArray):
    global EventTypeTree

    baseEventType = eventTypeArray[0]
    del eventTypeArray[0]
    baseEventTypes = EventTypeTree.findall('event_type')
    for eventType in baseEventTypes:
        if eventType.attrib['type_num'] == baseEventType:
            subEventTypes = eventType.findall('event_type')
            if subEventTypes == [] or eventTypeArray == []:
                return eventType.attrib['event']

    return recurse(subEventTypes, eventTypeArray)

def recurse(eventTypes, eventTypeArray):
    eventTypeIndex = eventTypeArray[0]
    del eventTypeArray[0]
    for eventType in eventTypes:
        if eventType.attrib['type_num'] == eventTypeIndex:
            if eventTypeArray == []:
                return eventType.attrib['name']
            else:
                subEventTypes = eventType.findall('event_type')
                if subEventTypes == []:
                    return 'ERROR PARSING EVENT TREE!'
                return recurse(subEventTypes, eventTypeArray)

#-------------------------------------------------------------------------------
def printUsedQuantities(usedQuantityList):
    global outputFile

    print('------------------------------------------------ Used Quantities ' +\
        '------------------------------------------------', file=outputFile)
    for usedQuantity in usedQuantityList:
        print('\n', string.ljust('Type', 20), string.ljust('Unit', 20),\
            string.ljust('MsgAmt', 20 ), string.ljust('RatingAmt', 20), file=outputFile)
        type = getUsageType(usedQuantity.getUsingKey(MDCDEFS.kMtxEventUsageQuantityQuantityTypeFldKey))
        unit = getUsageUnit(usedQuantity.getUsingKey(MDCDEFS.kMtxEventUsageQuantityQuantityUnitFldKey))
        msgAmt = usedQuantity.getUsingKey(MDCDEFS.kMtxEventUsageQuantityMsgAmountFldKey)
        rtgAmt = usedQuantity.getUsingKey(MDCDEFS.kMtxEventUsageQuantityRatingAmountFldKey)

        print(string.ljust(type, 20), string.ljust(str(unit), 20), string.ljust(str(msgAmt), 20),\
            string.ljust(str(rtgAmt), 20), '\n', file=outputFile)

#-------------------------------------------------------------------------------
def printBalanceImpacts(balanceImpacts):
    global outputFile
    print('------------------------------------------------- Balance Impacts ' +\
        '------------------------------------------------\n', file=outputFile)
    printBalanceInfo(balanceImpacts)

#-------------------------------------------------------------------------------
def printMeterImpacts(meterImpacts):
    global outputFile
    print(' ', file=outputFile)
    print('------------------------------------------- Meter Impacts ' + \
        '------------------------------------------', file=outputFile)
    printBalanceInfo(meterImpacts)

#-------------------------------------------------------------------------------
def printBalanceInfo(balanceImpacts):
    global outputFile
    for impact in balanceImpacts:
        print(string.ljust('BalClass', 20), string.ljust('BalId', 20), \
            string.ljust('ResourceId', 20), string.ljust('BalSetId', 20), string.ljust('Amount', 20), \
            string.ljust('Flags', 20), file=outputFile)
        balClass = impact.getUsingKey(MDCDEFS.kMtxBalanceUpdateBalanceClassIdFldKey)
        balId = impact.getUsingKey(MDCDEFS.kMtxBalanceUpdateBalanceTemplateIdFldKey)
        resourceId = impact.getUsingKey(MDCDEFS.kMtxBalanceUpdateBalanceResourceIdFldKey)
        balSetEntry = impact.getUsingKey(MDCDEFS.kMtxBalanceUpdateBalanceSetEntryIdFldKey)
        amount = impact.getUsingKey(MDCDEFS.kMtxBalanceUpdateAmountFldKey)
        flagInt = impact.getUsingKey(MDCDEFS.kMtxBalanceUpdateFlagsFldKey)
        flag = getFlagStr(flagInt)

        print(string.ljust(str(balClass), 20), string.ljust(str(balId), 20), \
            string.ljust(str(resourceId), 20), string.ljust(str(balSetEntry), 20), string.ljust(str(amount), 20), \
            string.ljust(flag, 20), '\n', file=outputFile)

#-------------------------------------------------------------------------------
def printSegments(segments):
    global outputFile
    idx = 1
    for segment in segments:
        print('------------------------------------------------ Segment ' + str(idx) + ' ' + \
            '------------------------------------------------', file=outputFile)
        idx += 1
        print('\n', string.ljust('Size', 20), string.ljust('Unit', 20), file=outputFile)
        size = str(segment.getUsingKey(MDCDEFS.kMtxEventSegmentSizeFldKey))
        unit = getUsageUnit(segment.getUsingKey(MDCDEFS.kMtxEventSegmentSizeUnitFldKey))
        print(string.ljust(size, 20), string.ljust(str(unit), 20), '\n', file=outputFile)

        segmentCharges = segment.getUsingKey(MDCDEFS.kMtxEventSegmentMtxEventSegmentChargeListFldKey)
        if segmentCharges:
            for segmentCharge in segmentCharges:
                print(string.ljust('Offer', 20), string.ljust('ResourceId', 20),\
                    string.ljust('UpdateType1', 20 ), string.ljust('Amount1', 20), string.ljust('UpdateType2', 20),\
                    string.ljust('Amount2', 8), file=outputFile)
                offer = segmentCharge.getUsingKey(MDCDEFS.kMtxEventSegmentChargeProductOfferIdFldKey)
                resourceId = segmentCharge.getUsingKey(MDCDEFS.kMtxEventSegmentChargeProductOfferResourceIdFldKey)
                amount1 = segmentCharge.getUsingKey(MDCDEFS.kMtxEventSegmentChargeAmount1FldKey)
                amount2 = segmentCharge.getUsingKey(MDCDEFS.kMtxEventSegmentChargeAmount2FldKey)
                updateTypeInt = segmentCharge.getUsingKey(MDCDEFS.kMtxEventSegmentChargeUpdateTypeFldKey)

                updateType1Int = updateTypeInt & 255
                updateType1 = getBalanceUpdateType(updateType1Int)

                updateType2Int = (updateTypeInt >> 8)
                updateType2 = getBalanceUpdateType(updateType2Int)

                print(string.ljust(str(offer), 20), string.ljust(str(resourceId), 20),\
                    string.ljust(updateType1, 20), string.ljust(str(amount1), 20), string.ljust(updateType2, 20),\
                    string.ljust(str(amount2), 8), '\n', file=outputFile)

#-------------------------------------------------------------------------------
def getInitiatorSponsorInfo(event):
    initiatorOid = event.getUsingKey(MDCDEFS.kMtxEventInitiatorIdFldKey)
    initiatorExternalId = event.getUsingKey(MDCDEFS.kMtxEventInitiatorExternalIdFldKey)
    initiatorDeviceId = event.getUsingKey(MDCDEFS.kMtxEventInitiatorDeviceIdFldKey)
    
    '''
    sponsor info is deprecated.  hard code to None for now so that we don't need to make other changes in the framework
    sponsorArray = event.getUsingKey(MDCDEFS.kMtxEventSponsorArrayFldKey)
    if sponsorArray is None:
        sponsorOid = None
        sponsorExternalId = None
    else:
        # Fetch first sponsor
        sponsor = sponsorArray[0]
        sponsorOid = sponsor.getUsingKey(MDCDEFS.kMtxSponsorSponsorIdFldKey)
        sponsorExternalId = sponsor.getUsingKey(MDCDEFS.kMtxSponsorSponsorExternalIdFldKey)
'''
    #return (initiatorOid, initiatorExternalId, initiatorDeviceId, sponsorOid, sponsorExternalId)
    return (initiatorOid, initiatorExternalId, initiatorDeviceId, None, None)

#-------------------------------------------------------------------------------
def outputEvent(event, stripFields):
    global outputFile

    tmpEventFileName = os.getcwd() + '/' + COMMON.resultsDir + '/current_event.txt' 
    tmpEventFile = open(tmpEventFileName, 'w')
    print(event.printXml(), file=tmpEventFile)
    tmpEventFile.close()

    tmpEvent = open(tmpEventFileName, 'r')
    lines = tmpEvent.readlines()
    tmpEvent.close()
    lines.append("</root>\n")
    lines.reverse()
    lines.append("<root>\n")
    lines.reverse()
    processedData = "".join([x for x in lines if x.strip() != ''])
    tmpEvent = open(tmpEventFileName, 'w')
    tmpEvent.write(processedData)
    tmpEvent.close()

    excludeList = ['InitiatorId', 'InitiatorExternalId', 'InitiatorDeviceId',
        'InitiatorDeviceExternalId', 'InitiatorWalletId', 'WalletId', 'EventId']

    if xmlStatus and stripFields:
        print(xml_utils.transformDoc(tmpEventFileName, excludeList), file=outputFile)
    else:
        print(processedData, file=outputFile)


#-------------------------------------------------------------------------------
# Given a transaction log file, extract the event data records (EDR's) and
# display them
#-------------------------------------------------------------------------------
def customEventOutput(event, stripFields):
    """
    # Output separator
    print >>outputFile, ' '

    # Output event type/header
    eventTypeArray = event.getUsingKey(MDCDEFS.kMtxEventEventTypeArrayFldKey)
    print >>outputFile, "=============================================== Event Type '" + \
        getEventType(eventTypeArray) + "' ===============================================\n"

    # Output usage quantities
    if event.isDescendantOf(MDCDEFS.kMtxUsageEventMdcDesc.containerKey):
        usedQuantityList = event.getUsingKey(MDCDEFS.kMtxUsageEventUsageQuantityListFldKey)
        if usedQuantityList:
            printUsedQuantities(usedQuantityList)

    # Output balance impacts
    balanceImpacts = event.getUsingKey(MDCDEFS.kMtxEventBalanceUpdateArrayFldKey)
    if balanceImpacts:
        printBalanceImpacts(balanceImpacts)

    # Output segment information
    segments = event.getUsingKey(MDCDEFS.kMtxEventSegmentArrayFldKey)
    if segments:
        printSegments(segments)

    # Output meter impacts
    meterImpacts = event.getUsingKey(MDCDEFS.kMtxEventMeterUpdateArrayFldKey)
    if meterImpacts:
        printMeterImpacts(meterImpacts)

    """
    # Fetch initiator/sponsor- returned later for validation purposes
    (initiatorOid, initiatorExternalId, initiatorDeviceId, sponsorOid, sponsorExternalId) =\
        getInitiatorSponsorInfo(event)

    outputEvent(event, stripFields)

    return ('success', initiatorOid, initiatorExternalId, initiatorDeviceId, sponsorOid, sponsorExternalId)

def extractEvents(mdc, diffEvents, stripFields):
    # We expect to have a work order in the mdc
    if mdc.descObj.containerKey != MDCDEFS.kMtxWorkOrderMsgMdcDesc.containerKey:
        print("Error: Unexpected MDC type")

    # See if we have any events
    if not mdc.isPresent(MDCDEFS.kMtxWorkOrderMsgTxnActionListFldKey):
        # No events present
        return (None, None, None, None, None, None)

    # Get the action list
    actionList = mdc.getUsingKey(MDCDEFS.kMtxWorkOrderMsgTxnActionListFldKey)

    eventInfo = (None, None, None, None, None, None)
    for actionMdc in actionList:
        # Look for CREATE actions.
        if actionMdc.descObj.containerKey != MDCDEFS.kMtxTxnObjectActionDataMdcDesc.containerKey:
            continue
        action = actionMdc.getUsingKey(MDCDEFS.kMtxTxnActionDataOperatorFldKey)
        if action != 1:
            continue
        if not actionMdc.isPresent(MDCDEFS.kMtxTxnObjectActionDataObjectFldKey):
            continue

        # Now search for created MtxEventObjects.
        txnObject = actionMdc.getUsingKey(MDCDEFS.kMtxTxnObjectActionDataObjectFldKey)
        if txnObject.descObj.containerKey != MDCDEFS.kMtxEventObjectMdcDesc.containerKey:
            continue
        if not txnObject.isPresent(MDCDEFS.kMtxEventObjectEventFldKey):
            continue

        # Get the MtxEvent from the MtxEventObject.
        event = txnObject.getUsingKey(MDCDEFS.kMtxEventObjectEventFldKey)
        if diffEvents:
            eventInfo=customEventOutput(event, stripFields)
        else:
            customEventOutput(event, stripFields)

    return eventInfo

def readCompactInput(inFile, diffEvents, stripFields):
    for line in inFile:
        line = line.rstrip('\n')
        if (line == ''):
            continue
        if (line.startswith('#')):
            continue

        mdc = MDC.readFromStr(line)
        if mdc == None:
            if debug:
                # Do not terminate on error in debug mode.
                print('Cannot parse MDC for input: ' + line)
                continue
            else:
                print("Fatal Error: Cannot parse input")
                return

        (successStr, initiatorOid, initiatorExternalId, initiatorDeviceId, sponsorOid, sponsorExternalId) =\
            extractEvents(mdc, diffEvents, stripFields)

        if successStr == 'success':
            return (initiatorOid, initiatorExternalId, initiatorDeviceId, sponsorOid, sponsorExternalId)

    return (None, None, None, None, None)

def printEvents(testTag, diffEvents, stripFields = False):
    global outputFile

    path = os.getcwd()
    logFile = path + '/' + COMMON.resultsDir + '/tmpTxnLog'

    if (not os.path.exists(logFile)):
        print('Error: The input file name (' + logFile + ') does not exist.')
        return (None, None, None, None, None)

    inFile = open(logFile, 'r')

    outputFileName = path + '/' + COMMON.resultsDir + '/' + testTag + '_events'
    outputFile = open(outputFileName, 'a')

    (initiatorOid, initiatorExternalId, initiatorDeviceId, sponsorOid, sponsorExternalId) =\
        readCompactInput(inFile, diffEvents, stripFields)

    inFile.close()
    outputFile.close()

    return (initiatorOid, initiatorExternalId, initiatorDeviceId, sponsorOid, sponsorExternalId)
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

