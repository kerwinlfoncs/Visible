#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:41:04
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:43
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:24

# from builtins import str
# from builtins import str
import os, sys
import re
import time, random
import subprocess
from optparse import OptionParser

branchesList = {"500":"MTX2-MTXNIGHTRH6", "475":"MTX3-B4750", "471":"MTX3-REL", "470":"MTX3-B470XNIGHTL", \
                "462":"MTX3-B46XXNIGHTLY", "461":"MTX3-B461XNIGHTLY", "460":"MTX3-B460XNIGHTLY"} 
buildsList1 = ['activemq-connector', 'engine', 'proxy-server']
buildsList2 = ['activemq-connector', 'engine', 'network-enabler', 'proxy-server', 'traffic-manager']

def runCmd(cmd, output='delayed'):
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    out = p.stdout.read().strip()
    return out  #This is the stdout

def getRpmBuilds(bladeHost, release=None, buildVersion='latestSuccessful', rpmNames=['engine']):
    siteip_b2="10.10.86.51"
    siteip_b3="10.10.116.245"
    branch=''
    siteIp=''
    if release == None:
        print("No release is found!")
        sys.exit(1)

    release = str(release)
    relPrefix = release[0:3]
    print("getRpmBuild(): ", release, " release for ", relPrefix)

    findRelease = False
    for db_key, db_value in list(branchesList.items()):
        if relPrefix == db_key:
            findRelease = True
            branch = db_value
            if relPrefix == '500':
                siteIp = siteip_b2
            else:
                siteIp = siteip_b3
            break

    if not findRelease:
        print("Not a valid release.")
        sys.exit(1)

    job = 'job-' + branch
    if bladeHost == 'localhost':
        preCmd = ''
    else:
        preCmd = "ssh " + bladeHost + " "
    print("getRpmBuild(): ", branch, " branch on site ", siteIp, " on bladeHost ", bladeHost)

    buildVersion = str(buildVersion)
    if  buildVersion == "latestsuccessful" or buildVersion == "latestSuccessful" or buildVersion == "latest":
        latestBuild = buildVersion
        if buildVersion == "latestsuccessful":
            latestBuild = "latestSuccessful"
        cmd = preCmd + 'wget http://' + siteIp + ':8085/browse/' + branch + '/' + latestBuild
        print('wget: ', cmd)
        ret = runCmd(cmd)

        cmd = preCmd + "ls -al " + latestBuild
        ret = runCmd(cmd)
        print("list file for the latest:", ret)
        if not ret or re.search("No such file or directory", ret):
            print("wget get latest build failed")
            sys.exit(1)

        cmd = preCmd + "grep " + job + " " + latestBuild + " | cut -d'=' -f2 | cut -d'-' -f 5 | cut -d' ' -f1 | sed 's/\"//'"
        print('wget grep: ', cmd)
        buildVersion = runCmd(cmd)
        cmd = preCmd + "rm ./" + latestBuild
        print('wget rm: ', cmd)
        runCmd(cmd)
        print("wget the latest build: ", buildVersion)

    buildsList = []
    if rpmNames[0] == 'all':
        releaseNum = int(release)
        if releaseNum >=  4700:
            buildsList = buildsList2
        else:
            buildsList = buildsList1
    else:
        buildsList = rpmNames

    rpmBuildFiles = []
    for rpm in buildsList:
        rpmFile = "matrixxsw-" + rpm + "-" + release + "-" + buildVersion + ".x86_64.rpm"
        cmd = preCmd + "wget http://" + siteIp + ":8085/artifact/" + branch + "/JOB1/build-" + buildVersion + "/Packages/RPMS/x86_64/" + rpmFile
        print("wget build: ", cmd)
        runCmd(cmd)
        cmd = preCmd + "mv " + rpmFile + " /tmp"
        runCmd(cmd)
        rpmBuildFiles.append(rpmFile)

    print("End wget buildFiles =", rpmBuildFiles)

#------------------------------------------------------------------------------
def parseOptions():
    parser = OptionParser()
    parser.add_option("-r", "--release", action='store', type='string', default=None, help="Build release. ex: 4750")
    parser.add_option("-v", "--version", action='store', type='string', default='latest', help="Build version. ex: 1700 or latestSuccessful; default='latest'")
    parser.add_option("-n", "--build_names", action='store', type='string', default='engine', help="Build names for rpms. ex: engine,proxy-server or all; default='engine'")
    parser.add_option("-b", "--blade_host", action='store', type='string', default='localhost', help="Tartget blade host. ex: mtx-hp3-bld01 or 10.10.136.51; default='localhost'")


    args = None
    # Process command line params
    (options, args) = parser.parse_args()
    print("parse options:", options)
    return options

def main():
    options = parseOptions()
    release =  options.release
    buildVersion =  options.version
    bladeHost = options.blade_host
    rpmNameStr = options.build_names
    if release == None:
        print("Must specify release for rpm.   -r option")
        sys.exit(1)
    print("relese rpm is:", release, " and version is:", buildVersion)

    buildNames = rpmNameStr.split(',')
    print("release=", release, " bladeHost=", bladeHost, " rpmNames=", buildNames)
    getRpmBuilds(bladeHost, release, buildVersion, buildNames)

main()
