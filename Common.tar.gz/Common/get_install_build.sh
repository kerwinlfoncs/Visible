#!/bin/bash
#script to get latest post checkin or night build
#####################################################

if [ $# -lt 1 ]
then
   echo "specify type of build <night> <post><rpm <build#> >"
   exit
fi

#uninstall
sudo rpm -e matrixxsw-engine-4300
sudo rpm -e matrixxsw-proxy-server-4300
sudo rpm -e matrixxsw-seagull-4300

if [ $1 == "rpm" ]
then
   sudo rpm -i matrixxsw-engine-4300-$2.x86_64.rpm
   sudo rpm -i matrixxsw-proxy-server-4300-$2.x86_64.rpm
   exit
fi

PostBranch="CHKN2"
NightBranch="MTXNIGHTRH6"

Branch=$PostBranch
if [ $1 == "night" ]
then 
    Branch=$NightBranch
fi
BuildPath="http://10.10.86.51:8085/artifact/MTX2-$Branch/JOB1/build-"
Browsing="http://10.10.86.51:8085/browse/MTX2-$Branch/latestSuccessful/artifact/JOB1/Packages/RPMS/x86_64"
echo installing from $Branch ................

#get the rpm version
curl $Browsing |awk -F"=" '{print $4}'| grep rpm|sed 's/.*matrixxsw//g'|sed 's/\..*//g'  | grep -v dbg > l



#install all rpms
for rpm in `cat l`
do
    echo $rpm
    buildnum=`echo $rpm|sed s/.*-//g`
    echo $buildnum
    wget $BuildPath$buildnum/Packages/RPMS/x86_64/matrixxsw$rpm.x86_64.rpm
    sudo rpm -i matrixxsw$rpm.x86_64.rpm
done



