#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:33
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:14
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:34:58
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
import QA_subscriber_management_restv3 as REST_UTIL
import qa_utils as QAUTILS
import sys, os
import re
import log_errors as LOGGER
logger = LOGGER.clErrors(os.getcwd())
tagCounter = 0
groupspParentsDCT = {}
path = os.getcwd()

def createAndAddSubscToExistingGroup(V2inst, groupId, groupMembers, externalId,
                               deviceType, offerId = 0, allDevices = True, offerStartTime = None, offerEndTime = None, 
                               serviceId = None, eventPass = True, now=None, subscQueryType='ExternalId', billingTemplateId=None,
                               containerExtention = None,offerSpecificList=[],  fieldDct = {}):
    count = 0
    externalIdu = int(externalId) + 1
    deviceIdu = str(externalIdu)
    subscList = []
    offerIdtemplate = 0    

    print("offerId=", offerId, " offerSpecificList=", offerSpecificList)
    # we need to create subsc, add billing, then add offer
    if offerId == 0:
        pass
    elif billingTemplateId is not None :
        newOffers = [x for x in offerId if x not in offerSpecificList]
        offerIdtemplate = newOffers
        offerId = 0
    else:
        offerIdtemplate = offerId  #not needed but for clarification

    attr = None
    if containerExtention != None:
        attr = REST_UTIL.createAttr(containerExtention, fieldDct) #add any extra custom fields 
        #print "DEBUG: attr = ", attr
    
    #Lsys.exit(1)
    while (count < groupMembers):
        print(' create subsc = ' + deviceIdu + ' for group ' + str(groupId))
        (retCode, sOid) = REST_UTIL.addSubscriber(V2inst, externalIdu,
                           deviceIdu, deviceType, billingCycle = billingTemplateId,
                           allDevices = allDevices, subAttr = attr, 
                           serviceId = serviceId, eventPass = True,now=now)
        cmd = '\'"' + str(externalIdu) + '"\'' 
        os.system("echo " + cmd + " >> /tmp/subsc.out")
        print("DEBUG: in QA_subscriber_management_rest_utils.py.  billingTemplateId=", billingTemplateId)

        retCode = REST_UTIL.addSubscriberToGroup(V2inst, groupId,
                           subscriberId = deviceIdu, eventPass = True, now=now)

        if offerId == 0:
            pass
        elif billingTemplateId is not  None:  #we dont want to allow subsc with no billing cycle to buy offer!
            # Add offer
            retCode = REST_UTIL.subscribeToOffer(V2inst, externalIdu, offerIdtemplate, offerStartTime = offerStartTime, now=now)

            #we want to allow only 1 or 2 subsc to purchase a cretain shared offer from the group
         

        if (subscQueryType == 'ObjectId') :
            subscList.append(sOid)
        else :
            subscList.append(externalIdu)
            
        #retCode = REST_UTIL.addSubscriberToGroup(V2inst, groupId,
        #                   subscriberId = deviceIdu, eventPass = True, now=now)
        count = count + 1
        externalIdu = externalIdu + 1
        deviceIdu = str(externalIdu)

    if offerId == 0:
        pass
    if offerSpecificList != []:
        firstSub = int(externalId) + 1
        retCode = REST_UTIL.subscribeToOffer(V2inst, firstSub, offerSpecificList, offerStartTime = offerStartTime)
    return(subscList, externalIdu - 1)

def createGroupAndAddnNewSubscToGroup(V2inst, groupId, deviceId, testName, tag,deviceType,gofferId=0, sofferId=0,billingCycle=None, tier=None,groupMembers=0,
                         allDevices = True, offerStartTime=None, offerEndTime=None, serviceId = None, eventPass = True, containerExtention= None, fieldDct = {}): 
    count = 0
    idu = int(groupId) + int(deviceId)
    externalId = int(deviceId) + 1
    deviceIdu = idu
    externalIdu = int(deviceIdu)
    getDeviceIdOffset = deviceIdu
    # Create parent group
    gId = createGroupAndSaveMDC(V2inst, groupId, testName,tag,tier,administrator_id = 0, eventPass = True, billingCycle=billingCycle, gofferId= gofferId)
    return(createAndAddSubscToExistingGroup(V2inst, gId, groupMembers, 
                         externalId, deviceType, sofferId, allDevices, 
                         offerStartTime, offerEndTime, serviceId, eventPass, containerExtention, fieldDct,billingTemplateId=billingCycle))
                      
    
def createGroupAndSaveMDC(V2inst, groupId, testName, tag, tier=None, administrator_id=0, eventPass=True, billingCycle=None, gofferId=None):

    groupName = 'MTX_GRP_' + str(groupId)
    parentGroupId = groupId
    #create the root node
    retCode = REST_UTIL.createGroup(V2inst, groupId,
                         name = groupName, billingCycle=billingCycle, 
                         tier = tier, administrator_id = administrator_id,
                         eventPass = True)
    if gofferId != None:
         RspMdc = REST_UTIL. groupSubscribeToOffer(V2inst, groupId, gofferId, offerStartTime=None, offerEndTime=None, eventPass=True,
            queryType='ExternalId', offerIsExternal=False)
 
    QAUTILS.saveGroupMDC(parentGroupId, testName + '_create_root_' + tag)
    return(parentGroupId)

def createGroupAddToExistingGrpSaveMDC(V2inst, parentGroupId, newGroupId, testName, tag, tier = None, administrator_id = 0, eventPass = True, saveMDC = False, billingCycle = None, status = None):
    groupId = newGroupId
    groupName = 'MTX_GRP_' + str(groupId)
    #print "in createGroupAddToExistingGrpSaveMDC, tier=", tier
    retCode = REST_UTIL.createGroup(V2inst, groupId,
                         name = groupName,
                         tier = tier, administrator_id = 0, billingCycle = billingCycle,
                         eventPass = eventPass, status = status)

    if parentGroupId > 0:
        REST_UTIL.addSubGroupToGroup(V2inst, parentGroupId, subGroupId = groupId, eventPass = eventPass)
    if saveMDC:
        QAUTILS.saveGroupMDC(groupId, testName + '_create_subgrp_' + tag)

    return(groupId)
    
#=============================================
# this function returns a list of all root and subgroups created
def createGroupAndAddnSubGroupsSaveMDC(V2inst, groupId, testName, tag, groupLevels = 0, tier = None, administrator_id = 0, eventPass = True):
    groupList=[]

    #create the root node
    rootGroupId = createGroupAndSaveMDC(V2inst, groupId, testName, tag, tier = None, administrator_id = 0, eventPass = True)
    groupList.append(groupId)
    groupIdChild = rootGroupId + 1

    count = 0
    while ( count < groupLevels):
        groupList.append(groupIdChild)
        groupName = 'MTX_GRP_' + str(groupIdChild)
        retCode = REST_UTIL.createGroup(V2inst, groupIdChild, name = groupName, 
                         tier = None, administrator_id = 0, eventPass = True)

        # Add new group as a child of the original group
        REST_UTIL.addSubGroupToGroup(V2inst, rootGroupId, subGroupId = groupIdChild, eventPass = True)
        QAUTILS.saveGroupMDC(groupIdChild, testName + 'create_' + tag + '_subg_' +  str(groupIdChild) + '_pgrp_' + str(rootGroupId))
        groupIdChild += 1
        count += 1

    return groupList

def createAndAddSubscToExistingGrpSaveMDC(V2inst, groupId, groupMembers, testName, tag, deviceId, deviceType, offerId = 0, allDevices = True, offerStartTime = None, offerEndTime = None, serviceId = None, eventPass = True):
    groupSubscList=[]
    count = 0
    idu = str(int(deviceId) + 1) #str(groupId) + deviceId
    serviceId = 'None'
    deviceIdu = idu
    externalIdu = int(deviceIdu)
    while (count < groupMembers):
        #print ' create subsc = ' + deviceIdu + 'for group' + str(groupId)
        #offerId = 0
        retCode = REST_UTIL.addSubscriber(V2inst, externalIdu,
                           deviceIdu, deviceType,
                           offerId, allDevices, offerStartTime,
                           offerEndTime, serviceId, payload=None, eventPass = eventPass)
        retCode = REST_UTIL.addSubscriberToGroup(V2inst, groupId,
                           subscriberId = deviceIdu, eventPass = eventPass)
        groupSubscList.append(externalIdu)

        QAUTILS.saveMDC(deviceIdu, testName + '_create&join_subsc_' + str(count) + '_grp' + tag)

        count = count + 1
        deviceIdu = str(int(deviceIdu) + 1)
        externalIdu = externalIdu + 1

    return(groupSubscList)

    
def saveAllGroupsMDCs(numGroups, firstGroupId, testName, tag):
    i = 0
    while (i < numGroups):
        print('saving MDC for group = ' + str(firstGroupId))
        QAUTILS.saveGroupMDC(firstGroupId, testName + tag + str(firstGroupId) + '_rest')
        firstGroupId = firstGroupId + 1
        i = i + 1

groupsAndTheirLevelsDCT={}
levels = 0
newGroupId = 0
counter = 0
#======================================================
# this function returns a dictionary of rootGroup ID and each subgroups subsc
# the subGroups are in dictionary and keys are the group levels
#ex :  belowd is the level followed by the subgroups (results/output_groups_tree)
#0==> [61, 62]
#1==> [63, 64, 65, 66]
#2==> [67, 68, 69, 70, 71, 72, 73, 74]
#======================================================
def createEmptyGroupsNoOffers(V2inst, rootGroupId, testName, tag, groupLevels, subgroupspergroup, tier = None, administrator_id = 0, eventPass = True, billingCycle = None, generalDct={}, status=None ):
    global newGroupId 
    lGroupLevels = 0
    lastGroupId = 0
    nodesDCT = {}
    logger.printRes(os.getcwd(), 'output_groups_tree2.txt','starting levels =' + str(groupLevels))
    #======================================================
    #given a root , create first children
    newGroupStartId = rootGroupId + 1
    childNum = 0
    (groupsList, lastGroupId) = createSubtreeNoOffersNoSubsc(V2inst, rootGroupId, newGroupStartId, lGroupLevels, subgroupspergroup, tag, tier = tier, administrator_id = 0, testName = testName, billingCycle = billingCycle, status=status)
    nodesDCT[0] = groupsList
    logger.printRes(os.getcwd(), 'output_groups_tree2.txt','in Before : levels =' + str(lGroupLevels) + ' children =' + str(nodesDCT[0]))
    #======================================================
    #if more than 1 level , loop thru each and get all the levels
    while lGroupLevels < (groupLevels - 1):
        lGroupLevels = lGroupLevels + 1
        logger.printRes(os.getcwd(), 'output_groups_tree2.txt','in levels =' + str(lGroupLevels) + ' children =' + str(nodesDCT[lGroupLevels -1]))
        childNum = 0
        myList = []
        # each node in the level above will have more subgroups
        for v in nodesDCT[lGroupLevels-1]:
            (groupsList, lastGroupId) = createSubtreeNoOffersNoSubsc(V2inst, v, lastGroupId + 1, lGroupLevels, subgroupspergroup, tag, tier = tier, administrator_id = 0, testName = testName, billingCycle = billingCycle, status=status)
            myList.extend(groupsList)
        nodesDCT[lGroupLevels] = myList
    QAUTILS.pickleAnyDictionary(path, 'output_groupsParentsDCT.dat', groupspParentsDCT)
    return(nodesDCT)    
#======================================================
#helper function for createEmptyGroupsNoOffers. ot creates subgroups per each node
#and adds them to higher node.  
#======================================================pParentsDCT
def createSubtreeNoOffersNoSubsc(V2inst, rootGroupId, newGroupStartId, level, subgroupspergroup, tag, tier = None, administrator_id = 0, testName = None, billingCycle = None, status = None):
    global tagCounter
    global groupspParentsDCT

    groupsList = []
    newGroupId = newGroupStartId
    lgroupMembers = 0
    #logger.printRes(os.getcwd(), 'output_groups_tree2.txt', 'createSubtreeNoOffersNoSubsc : subgroupspergroup=' + str(subgroupspergroup)+ ' levels ' + str(level) )
    while lgroupMembers < subgroupspergroup:
        lgroupMembers = lgroupMembers + 1
    #    logger.printRes(os.getcwd(), 'output_groups_tree2.txt', 'creating group :'  + str(newGroupId) +  ' levels ' + str(level) + ' and Adding to group : ' + str(rootGroupId))
        tag = str(tagCounter + 1)
        groupspParentsDCT[newGroupId] = rootGroupId   #a complete list of each group and its parent
        print('rootGroupId = ', rootGroupId)
        print('groupspParentsDCT = ', groupspParentsDCT[newGroupId])
        createGroupAddToExistingGrpSaveMDC(V2inst,
                   rootGroupId, newGroupId, testName, tag,
                   tier, administrator_id, billingCycle = billingCycle, status = status)
        groupsList.append(newGroupId)
        newGroupId = newGroupId + 1
    return(groupsList, newGroupId - 1)

#======================================================
# this function loops thru onject returned by createEmptyGroupsNoOffers.
#prints them and returns max groupId used. we need it to assign more Ids later
#======================================================
def printAllGroupsAndLevels(groupsAndTheirLevelsDCT):
    len = 0
    maxList = []
    for k,v in sorted(groupsAndTheirLevelsDCT.items()): 
        #print str(k) + ': ' + str(v)
        maxList.append(max(v))
        logger.printRes(os.getcwd(), 'output_groups_tree.txt', str(k) + '==> ' + str(v))
        for x in v:
            len = len + 1
        print(len)
    logger.printRes(os.getcwd(), 'output_groups_tree.txt', 'Total number of Groups ==> ' + str(len))
    maxGroupId =  max(maxList)
    logger.printRes(os.getcwd(), 'output_groups_tree.txt', 'max GroupId ==> ' + str(maxGroupId))

    return maxGroupId

#======================================================
#This function gets an object from createEmptyGroupsNoOffers, loops thru each entry 
#in the DCT and adds subsc as specified in subscGroups.  subscGroups sample
#=[(0,0),(1,2),(2,5)] which is a list of tuples. entry 1 is the level
#entry 2 is the subgroups offset from left to right
#returns: a list of subsc per group as a DCT, and max subsc Id used
#======================================================
def addSubscribersToGroups(V2inst, groupsAndTheirLevelsDCT, subscGroups, groupMembers, externalId, deviceType, serviceId, totalUsers = 10, now=None, offerId=0,subscQueryType='ExternalId', billingTemplateId=None, containerExtention= None, offerStartTime = None, offerSpecificList=[],  fieldDct = {}):
    groupsAndSubscIdDCT = {}
    #print 'type is ' + str(type(subscGroups))
    index = 0
    if not type(subscGroups) == type(list()):
        subscGroups.append(subscGroups)

    for tuples in subscGroups:
        #print groupsAndTheirLevelsDCT[tuples[0]][tuples[1]]
        groupId = groupsAndTheirLevelsDCT[tuples[0]][tuples[1]]
        #print 'groupId = ' + str(groupId)
        (subscList, maxUsedsubscId) =  createAndAddSubscToExistingGroup(V2inst, groupId, 
               groupMembers, externalId, deviceType, offerId = offerId, allDevices = True, 
               offerStartTime = offerStartTime, offerEndTime = None, containerExtention= containerExtention, fieldDct = fieldDct, 
               serviceId = serviceId, eventPass = True, now=now, subscQueryType=subscQueryType, offerSpecificList=offerSpecificList,billingTemplateId=billingTemplateId)

        groupsAndSubscIdDCT[groupId] = subscList
        externalId = maxUsedsubscId
        #index += 1
        #if index == totalUsers: break
    
    logger.printRes(os.getcwd(), 'output_groups_tree.txt', 'list of subscribers per group')
    logger.printRes(os.getcwd(), 'output_groups_tree.txt', str(groupsAndSubscIdDCT))
    return(groupsAndSubscIdDCT, maxUsedsubscId)
        
#======================================================
# parse the dictionary from function subtree

def collectAllDevicesAndGroupsInTree(groupsAndTheirSubscDCT):
    devicesList = []
    groupsList = []

    for k, v in sorted(groupsAndTheirSubscDCT.items()):
        if k == None:
            continue
        print('========== *** ========' + str(k))
        if re.search('rootId', str(k)):  
           groupsList.append(v)
        else:
           if not v == None: 
               groupsList.append(k)
               if type(v) == type(list()):
                   for device in v:
                       devicesList.append(str(device))
               else: 
                   devicesList.append(str(v))
    return (devicesList, groupsList)
     
#======================================================
#save MDCs for groups and subsc
#=====================================================
def saveMDCsforgroupsAndSubscIdDCT(groupsAndSubscIdDCT, testName, tagCounter, tag, queryTime = None, numGroupsToSave = None, numSubscToSave = None):
    numGroups = 0
    numSubsc = 0
    for groupId, subscList in sorted(groupsAndSubscIdDCT.items()):
        QAUTILS.saveGroupMDC(groupId, testName + '_group' + tag + str(tagCounter), queryTime = queryTime)
        for deviceId in subscList:
            eventInfo = queryTime
            QAUTILS.saveMDC(str(deviceId), testName + tag + str(tagCounter), eventInfo, queryTime = queryTime)
            if numSubscToSave:
                if numSubscToSave == numSubsc: break
                numSubsc += 1
            tagCounter = tagCounter + 1
        tagCounter = tagCounter + 1
        if numGroupsToSave:
            if numGroupsToSave == numGroups: break
            numGroups += 1

    return (tagCounter)
#====================================================

def getDeviceIdOffset(groupId, groupMembers, deviceId):
    return(str(groupId) + deviceId)
    
def main():
    groupId = 2
    V2inst = REST_UTILS.SubscriberManagementV2Client('localhost','8880')
    REST_UTIL.createGroup(V2inst, groupId,
                               name = 'groupName',
                               tier = None, administrator_id = 0,
                               eventPass = True)

    createAndAddSubscToExistingGrpSaveMDC(V2inst, groupId, groupMembers = 2, testName = '1', tag = 'ttt', deviceId = '100', deviceType = 2, offerId = 0, allDevices = True, offerStartTime = None, offerEndTime = None, serviceId = None, eventPass = True)


def getGroupLevelIndexTuples(treeDCT, indexType):
    subscListToCreate = []
    for groupLevel,groupsListforThisLevel in sorted(treeDCT.items()):
        index = 0
        #print '============================================='
        #print groupLevel,groupsListforThisLevel
        for groupId in groupsListforThisLevel:
            if index%2 == indexType:
                subscListToCreate.append((groupLevel, index))
                #print subscListToCreate
            index += 1
    return subscListToCreate


def addAdminsToGroups(V2inst, groupsAndSubscIdDCT=None, numOfAdmin=0):
    groupId = 0 
    subId = 0 
    for groupId in groupsAndSubscIdDCT:
        for i in range(0,numOfAdmin):
           subId = groupsAndSubscIdDCT[groupId][i]
           adminRspMdc = REST_UTIL.addAdminToGroup(V2inst, groupId, subId, subQueryType='ExternalId', groupQueryType='ExternalId') 
           i += 1
        
def addOffersToGroups(V2inst, groupsAndSubscIdDCT, offerId, offerStartTime=None, offerEndTime=None, now=None):
    groupId = 0 
    subId = 0 
    print(groupsAndSubscIdDCT)
    for index, groupIdList in list(groupsAndSubscIdDCT.items()):
        for groupId in groupIdList:
            #print "groupIdgroupIdgroupIdgroupId=", groupId
            RspMdc = REST_UTIL. groupSubscribeToOffer(V2inst, groupId, offerId, offerStartTime=None, offerEndTime=None, eventPass=True,
            queryType='ExternalId', now=now, offerIsExternal=False)
        

if __name__ == '__main__':
    main()
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

