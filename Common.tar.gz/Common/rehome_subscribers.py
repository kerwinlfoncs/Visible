#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:41:06
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:49
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:17
import qa_utils as QAUTILS
import common_mdc as COMMON
import QA_subscriber_management_restv3
import restV3
import sys
import optparse


#It is important that config.ini in the Common Directory has the correct REST information (the rsgateway ip and port)
#[REST]
#restServer: localhost
#restPort : 8080


def main():

        parser = optparse.OptionParser()
        parser.add_option("-f", "--fileName", action='store', type='string', default= None)
        parser.add_option("-r", "--routingValue", action='store', type='string', default=None)
        parser.add_option("-q", "--queryType", action='store', type='string', default='ExternalId')


        args = sys.argv[1:]
        (options, args) = parser.parse_args(args=args)






        diameterRestConfig = QAUTILS.getDiameterRestConfig()
        V3Inst = restV3.RestClient(diameterRestConfig.get('REST', 'restServer'), diameterRestConfig.get('REST', 'restPort'))
        QA_subscriber_management_restv3.setVersion('REST')
        COMMON.disableOutput = True



      
        fileName = options.fileName
        routingValue = options.routingValue  
        queryType = options.queryType     
        with open(fileName) as fileReference:
            for line in fileReference:
                line = line.strip()
                restV3.subscriberRehome(V3Inst, line, queryType = queryType ,routingValue=routingValue)   
               
       

        return


        

if __name__ ==  '__main__':
    main()
