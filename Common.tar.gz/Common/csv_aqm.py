#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:36:02
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:36:02
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:36:02
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
from __future__ import print_function
from __future__ import division
# from builtins import str
# from builtins import str
from past.utils import old_div
import random
import csv_track as TRACK
import csv_prim as PRIM
import math

#==========================================================
def aqmGetEventParameters(aqmFunction, lclSessionId, ratingGroup, requestType, aqmMaxVelocity, i, used, vqt):
#       print 'aqmGetEventParameters on input: ' + str((aqmFunction, lclSessionId, ratingGroup, requestType, aqmMaxVelocity, i, used, vqt))
        # Get key saved items
        startTime    = TRACK.sessionGetValue(lclSessionId, ratingGroup, 'eventTime')
        timeBuffer   = TRACK.sessionGetValue(lclSessionId, ratingGroup, 'timeBuffer')
        validityTime = TRACK.sessionGetValue(lclSessionId, ratingGroup, 'validityTime')
        lookAheadVelocity = TRACK.sessionGetValue(lclSessionId, ratingGroup, 'lookAheadVelocity')

        # Real World: Used amount will (almost always) be the granted amount minus the VQT value
        used -= int(vqt)

        # Separate into parts
        aqmFunctionData = aqmFunction.split(',')
        function = aqmFunctionData[0]

        # If look ahead set, then use it.
        if lookAheadVelocity: velocity = lookAheadVelocity

        # Different behavior based on fucntion
        elif function == 'sin' or function == 'cos':
                if len(aqmFunctionData) >= 4:
                        # Allow this to use units in the command line
                        intercept = PRIM.convertAmountsToIntegers(str(aqmFunctionData[3]))
                else:   intercept = 0

                # Get fraction of circle to traverse per iteration
                if len(aqmFunctionData) >= 3:
                        # Allow this to use units in the command line
                        fraction = PRIM.convertAmountsToIntegers(str(aqmFunctionData[2]))
                else: fraction = 8

                # If repeating interims, then don;t start at 0 velocity
                if requestType == 'interim': scale = i + 1
                else: scale = i

                # Get the scale factor using the specified function
                if function == 'sin':   factor = math.sin((math.pi/fraction) * scale)
                else:                   factor = math.cos((math.pi/fraction) * scale)

                # NOTE:  if there's no intercept, then don't let the factor go negative (or else the whole second cycle will have no data)
                if intercept == 0: factor = abs(factor)

                # Get max change
                if len(aqmFunctionData) >= 2:
                        # Allow this to use units in the command line
                        maxChange = PRIM.convertAmountsToIntegers(str(aqmFunctionData[1]))
                else:   maxChange = aqmMaxVelocity

                # Scale by the factor, starting at the intercept.
                velocity = intercept + (maxChange * factor)

                # Debug output
                print('Function: ' + function + ', scale = ' + str(scale) + ', intercept = ' + str(intercept) + ', fraction = ' + str(fraction) + ', maxChange = ' + str(maxChange))

        elif function == 'line':
                # Get parameters.  The are arranged to match y = mx + b (y, m, b are the parameters)
                if len(aqmFunctionData) >= 4:
                        # Allow this to use units in the command line
                        intercept = PRIM.convertAmountsToIntegers(str(aqmFunctionData[3]))
                else:   intercept = 0

                if len(aqmFunctionData) >= 3:
                        # Allow this to use units in the command line
                        slope = PRIM.convertAmountsToIntegers(str(aqmFunctionData[2]))
                else:   slope = 0

                if len(aqmFunctionData) >= 2:
                        # Allow this to use units in the command line
                        stopValue = PRIM.convertAmountsToIntegers(str(aqmFunctionData[1]))
                else:   stopValue = aqmMaxVelocity

                # If doing a session, then want first interim to use intercept amount.
                # Else scale matches
                # The "i=0" step won't go through here, so don't need to check for that here.
                if   requestType == 'session': scale = i - 1
                else: scale = i

                # Debug output
                #print 'Function: ' + function + ', scale = ' + str(scale) + ', intercept = ' + str(intercept) + ', slope = ' + str(slope) + ', stopValue = ' + str(stopValue)

                # Calculate velocity.
                # Scale by factor, but limit based on slope sign
                velocity = (scale*slope) + intercept
                if slope >= 0:  velocity = min(stopValue, velocity)
                else:           velocity = max(stopValue, velocity)

        elif function == 'step' or function == 'mtn':
                # Get parameters.
                if len(aqmFunctionData) >= 5:
                        # Allow this to use units in the command line
                        holdTime = PRIM.convertAmountsToIntegers(str(aqmFunctionData[4]))
                else:   holdTime = 0

                if len(aqmFunctionData) >= 4:
                        # Allow this to use units in the command line
                        step = PRIM.convertAmountsToIntegers(str(aqmFunctionData[3]))
                else:   step = 0

                if len(aqmFunctionData) >= 3:
                        # Allow this to use units in the command line
                        stopValue = PRIM.convertAmountsToIntegers(str(aqmFunctionData[2]))
                else:
                        # Default end depends on delta sign
                        if step < 0: stopValue = 0
                        else:        stopValue = aqmMaxVelocity

                if len(aqmFunctionData) >= 2:
                        # Allow this to use units in the command line
                        startValue = PRIM.convertAmountsToIntegers(str(aqmFunctionData[1]))
                else:
                        # Default start depends on delta sign
                        if step >= 0: startValue = 0
                        else:         startValue = aqmMaxVelocity

                # If doing a session, then want first interim to use first value.
                # Else scale matches
                # The "i=0" step won't go through here, so don't need to check for that here.
                if   requestType == 'session': scale = i - 1
                else: scale = i

                # Debug output
#               print 'Function: ' + function + ', scale = ' + str(scale) + ', startValue = ' + str(startValue) + ', stopValue = ' + str(stopValue) + ', holdTime = ' + str(holdTime) + ', step = ' + str(step)

                # Velocity will be ((scale <oper> holdTime) * step) + startValue.  Then take the min/max to make sure it doesn't go beyond the stop point
                if function == 'step':  velocity = (int(old_div(scale, holdTime)) * step) + startValue
                else:                   velocity = (int(scale % holdTime) * step) + startValue

                if step >= 0:   velocity = min(stopValue, velocity)
                else:           velocity = max(stopValue, velocity)

        elif function == 'random':
                if len(aqmFunctionData) >= 4:
                        # Allow this to use units in the command line
                        multiple = PRIM.convertAmountsToIntegers(str(aqmFunctionData[3]))
                else:   multiple = 1

                if len(aqmFunctionData) >= 3:
                        # Allow this to use units in the command line
                        stopValue = PRIM.convertAmountsToIntegers(str(aqmFunctionData[2]))
                else:   stopValue = 0

                if len(aqmFunctionData) >= 2:
                        # Allow this to use units in the command line
                        startValue = PRIM.convertAmountsToIntegers(str(aqmFunctionData[1]))
                else:   startValue = aqmMaxVelocity

                # Debug output
#               print 'Function: ' + function + ', startValue = ' + str(startValue) + ', stopValue = ' + str(stopValue) + ', multiple = ' + str(multiple)

                # Velocity will be a random value between start and stop, as a multiple of the multiple parameter
                velocity = random.randrange(startValue, stopValue, multiple)

        # Sanity check this (in case the person did something unexpected like set the stop value to a negative amount...)
        if velocity < 0: velocity = 0.0

        # If the velocity is 0, then the used amount needs to be zero
        if int(velocity) == 0: used = 0

        #print('aqmGetEventParameters startTime, timeBuffer, used, velocity, validityTime on exit: ' + str((startTime, timeBuffer, used, velocity, validityTime)))
        return (startTime, timeBuffer, used, velocity, validityTime)

#==========================================================
#==========================================================
def aqmCalculateElapsedTime(used, velocity, timeBuffer, validityTime, aqmFunc):
        #print 'aqmCalculateElapsedTime input: ' + str((used, velocity, timeBuffer, validityTime, aqmFunc))
        # Calculate the time, given the desired velocity and the calculated used, accounting for any previous time buffer.
        # Note:  velocity may be 0, in which case just use the validity time as the timeframe.
        if velocity > 0: elapsedTime = float(float(used) / float(velocity)) + timeBuffer
        else:            elapsedTime = float(validityTime)
        
        # If elapsed time is not positive, set to 0
        #if elapsedTime <= 0: elapsedTime = 0.1
        
        # If not doing AQM, then always set elapsed time to a constant.  This will ensure that evey subscriber in
        # a multi-subscriber test environment will execute one at a time.
        if (aqmFunc == '0'): elapsedTime = 1.0

        # AQM in effect and the time is larger than the validity time, then need to recalculate items so we report within the validity time
        elif elapsedTime > float(validityTime):
                # Save data for debug print statements
                old_used = used

                # Need lower used amount.  Want velocity to be the driving factor.  Thus a lower time means less used for the same velocity.
                used = int(float(velocity) * float(validityTime))
                #print('old_used = ' + str(old_used) + ', used = ' + str(used))
                
                # Possible that used is still above old_used.  Can't let that happen.
                if used > old_used:
                        # Restore used amount
                        used = old_used

                        # Save old validity time
                        old_validity_time = validityTime

                        # Need to lower the validity time
                        validityTime = float(float(used) / float(velocity))

                        # Debug output
#                       print 'NOTE: lowering validity time'
#                       print 'Old: Validity time = ' + str(old_validity_time)
#                       print 'New: Validity time = time / velocity: ' + str(validityTime)     + ' = ' + str(used) + ' / ' + str(velocity)
#
#               else:
#                       # Debug output
#                       print 'NOTE: lowering used meet validity time.'
#                       print 'Old: Used = ' + str(old_used)
#                       print 'New: Used = velocity * time: ' + str(used)     + ' = ' + str(velocity) + ' * ' + str(validityTime)

                # Hate when this happens...
                elapsedTime = float(validityTime)

                # Reset the time buffer.  We're being forced to re-auth so assume no delta here
                timeBuffer = 0.0

        # Elapsed time needs to be whole seconds.
        if elapsedTime > int(elapsedTime):
                # Set time buffer if it's not an exact second
                timeBuffer = elapsedTime - int(elapsedTime)

                # Always set elapsedTime to int value
                elapsedTime = int(elapsedTime)

                # Re-calculate reported velocity
                if elapsedTime > 0: modVelocity = float(float(used) / float(elapsedTime))
                else:
                        # Having issues with elapsed time of 0
                        #if elapsedTime <= 0: elapsedTime = 1
                        modVelocity = float(velocity)
        else:
                # Clear time buffer
                timeBuffer = 0.0

                # modified velocity = reported velocity
                modVelocity = float(velocity)

                # Always set elapsedTime to int value
                elapsedTime = int(elapsedTime)
                
                # Having issues with elapsed time of 0
                if elapsedTime <= 0: elapsedTime = 1
                
        # HACK:  force elapsed time to be at least one second
#       if elapsedTime == 0:
#               elapsedTime = 1
#               timeBuffer = 0.0

        #print('aqmCalculateElapsedTime: returning: ' + str((elapsedTime, timeBuffer, modVelocity, used)))
        return (elapsedTime, timeBuffer, modVelocity, used)

#==========================================================
# Look ahead and see what the elapsed time will be for the next data point.
# This function does what the main loop does, except that the local variables are not updated.  Only the expected elapsed time is returned.
def aqmLookAhead(lclSessionId, ratingGroup, aqmFunc, requestType, aqmMaxVelocity, index, ttu, maxToUse, reportingReason, request, requested, SkipFlag, timeDelta, currentResv):
#       print 'aqmLookAhead on input: ' + str((lclSessionId, ratingGroup, aqmFunc, requestType, aqmMaxVelocity, index, ttu, maxToUse, reportingReason, request, requested, SkipFlag, timeDelta))
        # Retrieve key amounts
        (granted, vqt, elapsedTime) = TRACK.sessionGetLastAmounts(lclSessionId, ratingGroup)

        # Assume we're going to use everything
        used = int(granted)

        # Clear look ahead velocity, so it's always calculated
        TRACK.sessionSetValue(lclSessionId, ratingGroup, 'lookAheadVelocity', None)

        # Get AQM parameters
        (startTime, timeBuffer, used, velocity, validityTime) = aqmGetEventParameters(aqmFunc, lclSessionId, ratingGroup, requestType, aqmMaxVelocity, index, used, vqt)

        # Set look ahead velocity, so it's not calculated when the next point is executed
        TRACK.sessionSetValue(lclSessionId, ratingGroup, 'lookAheadVelocity', velocity)

        # Get elapsed time calculations for used amount adjustments
        (x, y, z, used) = aqmCalculateElapsedTime(used, velocity, timeBuffer, validityTime, aqmFunc)

        # Support totalToUse and maxToUse parameters
        (used, ttu, maxToUse, reportingReason, request, requested, SkipFlag) = PRIM.totalAndMaxToUse(ttu, maxToUse, used, requestType, reportingReason, request, requested, SkipFlag, currentResv, 'lookahead')

        # Get elapsed time calculations - not real (as usage won't be adjusted down a second time)
        (elapsedTime, timeBuffer, modVelocity, used) = aqmCalculateElapsedTime(used, velocity, timeBuffer, validityTime, aqmFunc)

        # After all this, what we want is the elapsed time
        #print('Lookahead return time to next event = ' + str(elapsedTime))
        return elapsedTime

