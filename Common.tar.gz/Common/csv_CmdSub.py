#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:35:54
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:35:53
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:35:52
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
from __future__ import print_function
# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
import sys, copy, pprint, time
import QA_subscriber_management_restv3 as REST_UTIL
import qa_utils as QAUTILS
import csv_track as TRACK
import csv_id as CSVID
import csv_prim as PRIM
import csv_data as DATA
import custSpecific as CUST
import csv_qa as CSVQA
import csvMain as CSV
import csv_Events as CSVEVENTS
import csv_CmdMisc as MISC
import csv_CmdPayNow as PAYNOW
from primitives import timeToMDCtime as MDCTIME
from primitives import primData as PRIMDATA
import xml.etree.ElementTree as ET

from primitives import primGET as GET

#==========================================================
def CmdSub_createsubscriberanddevice(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        offerId = lclDCT['offerId']
        offerStartTime = lclDCT['offerStartTime']
        offerEndTime = lclDCT['offerEndTime']
        preActiveState = lclDCT['preActiveState']
        # End of local variables setup.
        
        # Subscriber should not exist
        if externalId in TRACK.subscriberTracking and not noChecks:
                print('ERROR: subscriber with ID "' + externalId + '" is already defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Want to update local start time variable, so it's ready for the next iteration.
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if offerStartTime == None:
             offerStartTime = lclStartTime
        else:
             lclStartTime = offerStartTime
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if offerStartTime: lclStartTime = offerStartTime
        
        # Create billing cycle data if profile id defined
        if lclDCT['profileId'] and int(lclDCT['profileId']):
                billingCycle = REST_UTIL.createBillingCycleData(lclDCT['profileId'], dateOffset=lclDCT['dateOffset'], startTime=lclDCT['startTime'])
        else:
                billingCycle = None
        
        # ** Now work on offers.  Can have two parameters to specify this.  Can buy by external ID or catalog ID.  Can by legacy product ID or current catalog ID.
        # ** More difficult than it should be...
        (catalogItemId,offerId) = PRIM.processOffers(offerId, lclDCT['subOfferId'], lclDCT['offerIsExternal'], lclDCT['offerIsCatalog'])
        
        # Having fun with preActiveState and JSON.  If false set to None
        if preActiveState == False or str(preActiveState).lower() == '0': preActiveState = None
        
        # Debug output
        print('Creating subscriber ' + str(externalId) + ' with status ' + str(lclDCT['subStatus']) + ' and mark "' + str(lclDCT['mark']) + ' purchasing catalog items ' + str(offerId))
        
        # Debug output
        if str(offerId) != '0':
                if lclDCT['verbose'] not in ['low', 'none']:
                 print('Subscriber is purchasing catalog items ' + str(offerId) + ' with start/end times ' + str(offerStartTime) + '/' + str(offerEndTime))

#        print lclDCT['ACTION'] + ' device = ' + deviceId + ', accessNumbers = ' + str(accessNumbers) + ', offerID = ' + str(offerId) + ', RESTInst = ' + str(RESTInst)
        
        # Convert datetime to time
        if lclDCT['offerCycleStartTime']: offerCycleStartTime = lclDCT['offerCycleStartTime'].split('T')[1][:8]
        
        # Build US Tax data
        serviceAddress = REST_UTIL.createServiceAddressData(streetAddr=lclDCT['streetAddr'], extendedAddr=lclDCT['extendedAddr'], locality=lclDCT['locality'], region=lclDCT['region'], postalCode=lclDCT['postalCode'], extendedPostalCode=lclDCT['extendedPostalCode'], countryCode=lclDCT['countryCode'])
        geoData = REST_UTIL.createGeoData(geoCode=lclDCT['geoCode'], postalCode=lclDCT['postalCode'], plus4=lclDCT['plus4'], npa=lclDCT['npa'], nxx=lclDCT['nxx'])
        
        # Execute primitive
        retCode = REST_UTIL.createSubscriberAndDevice(RESTInst,
                externalId=externalId,
                deviceId=lclDCT['deviceId'],
                deviceType=lclDCT['deviceType'],
                offerId=offerId,
                offerStartTime=offerStartTime,
                offerEndTime=offerEndTime,
                subAttr=lclDCT['customAttr'][1],
                devAttr=lclDCT['customAttr'][0],
                billingCycle=billingCycle,
                firstName=lclDCT['firstName'],
                lastName=lclDCT['lastName'],
                contactPhoneNumber=lclDCT['contactPhoneNumber'],
                contactEmail=lclDCT['contactEmail'],
                notificationPreference=lclDCT['notificationPreference'],
                timeZone=lclDCT['subTimeZone'],
                accessNumbers=lclDCT['accessNumbers'],
                subStatus=lclDCT['subStatus'],
                devStatus=lclDCT['devStatus'],
                language=lclDCT['language'],
                offerIsExternal=lclDCT['offerIsExternal'],
                now=lclStartTime,
                offerAttr=lclDCT['customAttr'][3],
                taxStatus=lclDCT['taxStatus'],
                taxCertificate=lclDCT['taxCertificate'],
                taxLocation=lclDCT['taxLocation'],
                glCenter=lclDCT['glCenter'],
                eventPass=eventPass,
                catalogItemId=catalogItemId,
                routingType=lclDCT['routingType'],
                routingValue=lclDCT['routingValue'],
                executeMode=lclDCT['executeMode'],
                preActiveState=preActiveState,
                activationExpirationTime=lclDCT['activationExpirationTime'],
                activationExpirationRelativeOffsetUnit=lclDCT['activationExpirationRelativeOffsetUnit'],
                activationExpirationRelativeOffset=lclDCT['activationExpirationRelativeOffset'],
                autoActivationTime=lclDCT['autoActivationTime'],
                autoActivationRelativeOffsetUnit=lclDCT['autoActivationRelativeOffsetUnit'],
                autoActivationRelativeOffset=lclDCT['autoActivationRelativeOffset'],
                autoActivationCycleResourceId=lclDCT['autoActivationCycleResourceId'],
                offerCycleType=lclDCT['offerCycleType'], offerCycleOffset=lclDCT['offerCycleOffset'], offerCycleResourceId=lclDCT['offerCycleResourceId'],offerCycleStartTime=lclDCT['offerCycleStartTime'],
                isTargetResource=lclDCT['isTargetResource'],
                useTargetResource=lclDCT['useTargetResource'],
                isRecurringFailureAllowed=lclDCT['isRecurringFailureAllowed'],
                grantPurchaseProrationType=lclDCT['grantProrationType'],
                chargePurchaseProrationType=lclDCT['chargeProrationType'],
                reason=lclDCT['reason'],
                info=lclDCT['info'],
                eligibilityCheck=lclDCT['eligibilityCheck'],
                apiEventData=lclDCT['customAttr'][6],
                
                customerType=lclDCT['customerType'],
                serviceAddress=serviceAddress,
                npa=lclDCT['npa'],
                nxx=lclDCT['nxx'],
                tenantId=lclDCT['tenantId'],
                exemptionCodeList=lclDCT['exemptionCodeList'],
                geoData=geoData,
                )
        
        # Stuff to do if we passed
        if eventPass:
                # Update tracking data
                TRACK.updateTrackingData(lclDCT['ACTION'], externalId = externalId, deviceId = lclDCT['deviceId'], accessNumbers=lclDCT['accessNumbers'], offerId = offerId, mark=lclDCT['mark'], RESTInst=RESTInst)
                
                # Update CSR so we can login as this access number
                if PRIMDATA.skipMyMatrixx.lower() != 'true':
                        accessNumToUse = []
                        if type(lclDCT['accessNumbers']) == type(list()):
                                accessNumToUse = lclDCT['accessNumbers']
                        else:
                                accessNumToUse.append(lclDCT['accessNumbers'])
                        for aN in accessNumToUse: QAUTILS.updateCsrData(aN)
                        
        # Query subscriber
        queryValue = externalId
        queryType = subQueryType
        
        return (queryType, queryValue)
        
#==========================================================
def CmdSub_subscriberrehome(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
        
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Debug output
        print('Rehoming ' + REST_UTIL.subUrl + ' ' + str(externalId) + ' to ' + str(routingType) + '+' + str(lclDCT['routingValue']))

        # Execute primitive
        retCode = REST_UTIL.subscriberRehome(RESTInst,
                externalId,
                queryType=subQueryType,
                routingType=lclDCT['routingType'],
                routingValue=lclDCT['routingValue'],
                eventPass=eventPass,
                apiEventData=lclDCT['customAttr'][6],
                )

        # Query subscriber
        queryValue = externalId
        queryType = subQueryType

        return (queryType, queryValue)
        
#==========================================================
def CmdSub_removesubscriber(lclDCT, testName, sessionId, line, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, repeatCount):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
        
        # Set object type (for ease of cut/paste to other objects)
        objType='subscriber'
        
        print('Looking to remove ' + objType + ' ' + externalId + ' (' + subQueryType + ')')
        
        # First order is to get subscriber data
        q = GET.getObject(externalId, hostname=QAUTILS.gatewaysConfig.get('REST', 'restServer'), hostport=QAUTILS.gatewaysConfig.get('REST', 'restPort'), queryType=subQueryType, objType=objType)
        
        # If Q is empty, then nothing to do
        if q is None:
                print(objType + ' non-existent.')
        
                # Nothing to query
                queryType = queryValue = None
                
                return (queryType, queryValue)
        
        # Get OID
        try:
                oid = q.find('./ObjectId').text.strip()
        except:
                print('WARNING: ' + objType + ' does not have an ObjetId...')
        
                # Nothing to query
                queryType = queryValue = None
                
                return (queryType, queryValue)
        
        # *** Want to find time for delete.  Should match latest time that something new started in the object ***
        savedInputTime = lclStartTime
        lclStartTime = PRIM.findObjectLatestTime(q, lclStartTime, objType, externalId, subQueryType)    
        
        print('Remove ' + objType + ' ' + externalId + ' - using time ' + lclStartTime)
        if lclStartTime != savedInputTime: print('Updated remove time from ' + savedInputTime + ' to ' + lclStartTime)
        
        # ** Move object to deletable state.  Every customer has their own states.  TF reads this into customer specific data.
        stateMap = copy.deepcopy(CUST.subStateMap)

        # Get object state
        try:
                objState = q.find('./StatusDescription').text.strip()
        except:
                objState = 'Active'

        # Debug output
        #print 'stateMap = ' + str(stateMap) + ', starting state = ' + objState

        objState = objState.lower()
        while stateMap[objState] != 'Remove':
                # Get next state
                objState = stateMap[objState]

                # Modify to next state
                newLine='modifySubscriber;externalId=' + oid + ';subQueryType=ObjectId;subStatus=' + objState + ';noChecks=True;skipStepResults=' + str(lclDCT['skipStepResults']) + ';rmvFlag=1'
                (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)

        # ** Cycle through all devices
        xmlDctName = './DeviceIdArray/value'
        for children in q.findall(xmlDctName):
                # If keepChildren not set to true then want to remove the children
                if not lclDCT['keepChildren']:
                        # Remove the device
                        newLine='removeDevice;deviceId=' + children.text + ';devQueryType=ObjectId;noChecks=True;skipStepResults=' + str(lclDCT['skipStepResults'])
                else:
                        # Just unlink the child
                        newLine='removeDeviceFromSubscriber;externalId=' + oid + ';subQueryType=ObjectId;deviceId=' + children.text + ';devQueryType=ObjectId;deleteSessions=true;noChecks=True;skipStepResults=' + str(lclDCT['skipStepResults'])
                (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)
                
        # ** Remove from all groups
        xmlDctName = './ParentGroupIdArray/value'
        for children in q.findall(xmlDctName):
                # Remove the sub from the group
                newLine='removeSubscriberFromGroup;externalId=' + oid + ';subQueryType=ObjectId;groupQueryType=ObjectId;noChecks=True;groupId=' + children.text + ';skipStepResults=' + str(lclDCT['skipStepResults'])
                (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)
                
        # If this were complete, we'd now remove subscriber from being administrator...
        
        # ** Delete object
        newLine='deleteSubscriber;externalId=' + oid + ';subQueryType=ObjectId;noChecks=True;skipStepResults=' + str(lclDCT['skipStepResults'])
        (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)
                
        # Nothing to query
        queryType = queryValue = None
        
        return (queryType, queryValue)

#==========================================================
def CmdSub_subscriberqueryevent(lclDCT, options, RESTInst, cmdLineInput=False):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
        
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Seeing strange behavior where initial query after restart returns notifications late.
        # Account for that here.
        # timeToWaitInterval is the number of loops.
        # Get the delay time and the number of times to wait.
        intervals = int(float(lclDCT['timeToWait']) / float(lclDCT['timeToWaitInterval']))
        
        # Loop
        found = False
        for i in range(intervals):
         # Want to loop here until everything is retrieved
         qc = lclDCT['queryCursor']
         respData = ''
         while qc != 0:
                print('Calling query with lower/upper bounds = ' + str(lclDCT['eventTimeLowerBound']) + '/' + str(lclDCT['eventTimeUpperBound']) + ' and event type string = ' + str(lclDCT['eventTypeStringArray']))
                # Execute primitive
                (retCode, qc) = REST_UTIL.querySubscriberEvent(RESTInst,
                        externalId,
                        queryType=subQueryType,
                        querySize=lclDCT['querySize'],
                        eventPass=eventPass,
                        queryCursor = qc,
                        now=lclStartTime,
                        eventTimeLowerBound=lclDCT['eventTimeLowerBound'],
                        eventTimeUpperBound=lclDCT['eventTimeUpperBound'],
                        eventTypeStringArray=lclDCT['eventTypeStringArray']
                        )
                
                # HACK ATTACK: Check specific response package
                '''
                retCode = """
<MtxResponseEventInfo>
    <EventList>
        <ATTMexVoiceEvent>
            <Imsi>1005180000</Imsi>
            <Msisdn>1005180000</Msisdn>
            <originCCName>Australia</originCCName>
            <MccMncToUse>50506</MccMncToUse>
            <AcctNum>2001234567890</AcctNum>
            <CallReleaseReason>Success</CallReleaseReason>
            <typeOfNumber>1</typeOfNumber>
            <ServiceContextId>006.505.9.32260@3gpp.org</ServiceContextId>
            <mscAddress>61</mscAddress>
            <CommOffer>VF_COMBO_TALK_CO</CommOffer>
            <AccountProfile>VFA</AccountProfile>
            <ExternalServiceType>3</ExternalServiceType>
            <MigrationFlag>0</MigrationFlag>
            <ServiceProviderId>VODAFONE</ServiceProviderId>
            <Status>1</Status>
            <DestinationCountry>Ireland</DestinationCountry>
            <SubPlan>40 COMPLUS</SubPlan>
            <VHAIddToArea>IDD_IRELAND_AREA</VHAIddToArea>
            <VHAOriginArea>Australia</VHAOriginArea>
            <TADIG>AUSVF</TADIG>
            <CallingStationId>1005180000</CallingStationId>
            <CalledStationId>353</CalledStationId>
            <UsageQuantityList>
                <MtxEventUsageQuantity>
                    <QuantityType>actual_duration</QuantityType>
                    <QuantityUnit>seconds</QuantityUnit>
                    <Flags>1</Flags>
                    <MsgAmount>60.0000</MsgAmount>
                    <RatingAmount>60.0000</RatingAmount>
                </MtxEventUsageQuantity>
            </UsageQuantityList>
            <SessionId>MATRIXX-QA-TESTING.;1;395248757</SessionId>
            <UsageUtcOffset>600</UsageUtcOffset>
            <LastUsageRoundingAmount>0.0000</LastUsageRoundingAmount>
            <UsageRoundingAmount>0.0000</UsageRoundingAmount>
            <UsageRoundingAmountUnit>100</UsageRoundingAmountUnit>
            <EventTypeArray>
                <value>1</value>
                <value>2</value>
            </EventTypeArray>
            <MeterUpdateArray>
                <MtxMeterUpdate>
                    <TemplateId>21318</TemplateId>
                    <Amount>60.0000</Amount>
                </MtxMeterUpdate>
            </MeterUpdateArray>
            <AppliedOfferArray>
                <MtxEventAppliedOffer>
                    <UsageQuantity>60.0000</UsageQuantity>
                    <UsageQuantityUnit>100</UsageQuantityUnit>
                    <ProductOfferId>686</ProductOfferId>
                    <ProductOfferExternalId>VF_COMBO_TALK_CO: Voice</ProductOfferExternalId>
                    <ProductOfferOwnerId>0-1-5-1856</ProductOfferOwnerId>
                    <ProductOfferExternalOwnerId>1005180000</ProductOfferExternalOwnerId>
                    <ProductOfferResourceId>7</ProductOfferResourceId>
                    <ProductOfferVersion>0</ProductOfferVersion>
                    <ProductOfferAttr>
                        <VHAProductOffer>
                            <Category>Commercial Offer</Category>
                        </VHAProductOffer>
                    </ProductOfferAttr>
                    <AppliedBundleIndex>0</AppliedBundleIndex>
                </MtxEventAppliedOffer>
            </AppliedOfferArray>
            <AggregationId>0-1-19-7849</AggregationId>
            <AppliedBundleArray>
                <MtxEventAppliedBundle>
                    <BundleId>689</BundleId>
                    <BundleExternalId>VF_COMBO_TALK_CO</BundleExternalId>
                    <BundleResourceId>6</BundleResourceId>
                    <BundleVersion>0</BundleVersion>
                    <AppliedCatalogItemIndex>0</AppliedCatalogItemIndex>
                </MtxEventAppliedBundle>
            </AppliedBundleArray>
            <AppliedCatalogItemArray>
                <MtxEventAppliedCatalogItem>
                    <CatalogItemId>663</CatalogItemId>
                    <CatalogItemExternalId>VF_COMBO_TALK_CO</CatalogItemExternalId>
                    <CatalogItemResourceId>6</CatalogItemResourceId>
                    <CatalogItemTemplateAttr>
                        <MtxTemplateAttr />
                    </CatalogItemTemplateAttr>
                </MtxEventAppliedCatalogItem>
            </AppliedCatalogItemArray>
            <AppliedRateTagArray>
                <MtxEventAppliedRateTag>
                    <ExternalId>Voice IDD</ExternalId>
                    <Tag>Voice IDD</Tag>
                </MtxEventAppliedRateTag>
            </AppliedRateTagArray>
            <InitiatorId>0-1-5-1856</InitiatorId>
            <InitiatorExternalId>1005180000</InitiatorExternalId>
            <InitiatorDeviceId>0-1-5-1859</InitiatorDeviceId>
            <Flags>0</Flags>
            <WalletId>0-1-5-1857</WalletId>
            <WalletOwnerId>0-1-5-1856</WalletOwnerId>
            <WalletOwnerExternalId>1005180000</WalletOwnerExternalId>
            <BalanceUpdateArray>
                <MtxBalanceUpdate>
                    <BalanceClassId>36</BalanceClassId>
                    <BalanceTemplateId>21344</BalanceTemplateId>
                    <BalanceResourceId>11</BalanceResourceId>
                    <BalanceStartTime>2020-06-17T15:11:19.000000+10:00</BalanceStartTime>
                    <BalanceEndTime>2020-06-18T15:11:19.000000+10:00</BalanceEndTime>
                    <Flags>32</Flags>
                    <Amount>2.4000</Amount>
                </MtxBalanceUpdate>
            </BalanceUpdateArray>
            <ChargeList>
                <MtxEventCharge>
                    <UsageQuantity>60.0000</UsageQuantity>
                    <UsageQuantityUnit>100</UsageQuantityUnit>
                    <AppliedOfferIndex>0</AppliedOfferIndex>
                    <BalanceUpdateIndex>0</BalanceUpdateIndex>
                    <UpdateType>1</UpdateType>
                    <Amount>2.4000</Amount>
                    <ImpactSource>product_offer</ImpactSource>
                    <PaymentType>1</PaymentType>
                    <AppliedRateTagIndex>0</AppliedRateTagIndex>
                </MtxEventCharge>
            </ChargeList>
            <EventTime>2020-06-17T15:12:56.000000+10:00</EventTime>
            <Duration>1000000</Duration>
            <EventId>HJR0:1:52:13223</EventId>
            <DeleteCode>1</DeleteCode>
            <InitiatorPrimaryUserId>0-1-5-1858</InitiatorPrimaryUserId>
        </ATTMexVoiceEvent>
    </EventList>
    <QueryCursor>86412817850181464</QueryCursor>
    <RouteId>1</RouteId>
    <Result>0</Result>
    <ResultText>OK</ResultText>
    <ResultType>GET</ResultType>
</MtxResponseEventInfo>
<MtxResponseEventInfo>
    <QueryCursor>0</QueryCursor>
    <RouteId>1</RouteId>
    <Result>0</Result>
    <ResultText>OK</ResultText>
    <ResultType>GET</ResultType>
</MtxResponseEventInfo>
"""
                '''
                
                # If we're expected to fail then we may get nothing back, so break from here
                if not eventPass: break
                
                # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
                try:
                        retData = str(retCode.printElementBasedXml())
                except:
                        retData = str(retCode)
         
                # Add query response to overall response if events returned
                if "EventList" in retData: respData += '\n' + retData
                else: print('No events retiurned in query')
         
                # Get cursor value
                try:    qc = int(qc)
                except:
                        print('Received unexpected qc value: ' + str(qc))
                        qc = 0
                        
                # Debug output if we will query again
                if qc: print('Query Cursor set so will query again')
                
         # See if any events returned
         if "EventList" in respData:
                found = True
                break
         
         # If here then need to sleep to wait for events
         print('Sleeping for the ' + str(i+1) + ' time out of ' + str(intervals) + ' for event data')
         time.sleep(float(lclDCT['timeToWaitInterval']))
        
        # See if we found nothing
        if not found:
                # If eventPass then this is an error
                if eventPass:
                        print('ERROR: No events returned for subscription event store query and eventPAss set to True')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])

                # Exit from here
                print('NO events found')
                return (None, None)
        
        # Nothing to query
        queryType = queryValue = None
        
        # See if we're supposed to process assoiated or secondary events
        #print respData
        if lclDCT['processSecondaryEvents'] or lclDCT['processAssociatedEvents']: respData = CSVEVENTS.processOtherEvents(respData, lclDCT, RESTInst)
        
        # See if we found nothing
        if not respData:
                print('No requested secondary/associated events found')
                return (None, None)
        
        # HACK: cmdLineInput can indicate to return queried data
        if str(cmdLineInput).lower() == 'returndata': return (respData, None)
        
        # Do work if expecting to pass
        if eventPass:
                # If supposed to save data to variables then do that here
                if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, 'Event', respData)
                
                # Write to where the caller wanted it to go iff not saving data
                else: CSVQA.processDataToOutput(respData, lclDCT['outputFileName'])
                
        return (queryType, queryValue)

#==========================================================
def CmdSub_importsubscriberbalancevalue(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
        
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Debug output
        print('import' + REST_UTIL.subUrl.capitalize() + 'BalanceValue startTime: ' + str(lclDCT['startTime']))

        # If no resource ID passed in and a balance ID was passed in, then go find it
        if resourceId in [0, 'first', 'second', 'third', 'last'] and int(lclDCT['balanceId']) > 0:
                # Create on demand balances may not be valid at this time
                returnExpiredOk = lclDCT['createOnDemand']
                print('createOnDemand = ' + str(lclDCT['createOnDemand']))
                
                # Get the balance in question
                balance = PRIM.getBalanceData('subscriber', externalId, lclDCT['balanceId'], resourceId, lclStartTime, lclDCT['ACTION'], subQueryType, returnExpiredOk=returnExpiredOk)
                
                # Get the resource ID
                resourceId = int(balance['ResourceId'])

        # May be a formula here...  Need to ensure precision holds for the balance (error if not).
        amount = str(PRIM.processAmountFormula('subscriber', externalId, lclDCT['amount'], lclStartTime, lclDCT['ACTION'], precisionFlag = True, balanceId = lclDCT['balanceId'], queryType=subQueryType))
                        
        # Execute primitive
        retCode = REST_UTIL.importSubscriberBalanceValue(RESTInst,
                externalId=externalId,
                resourceId=resourceId,
                amount=amount,
                startTime=lclDCT['startTime'],
                now=lclStartTime,
                eventPass=eventPass,
                createOnDemand=lclDCT['createOnDemand'],
                queryType=subQueryType,
                )
        
        # Query subscriber
        queryValue = externalId
        queryType = subQueryType

        return (queryType, queryValue)
        
#==========================================================
def CmdSub_createsubscriber(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
        
        # Subscriber should not exist
        if externalId in TRACK.subscriberTracking and not noChecks:
                print('ERROR: subscriber with ID "' + externalId + '" is already defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Create billing cycle data if profileId defined
        if lclDCT['profileId'] and int(lclDCT['profileId']):
                billingCycle = REST_UTIL.createBillingCycleData(lclDCT['profileId'], dateOffset=lclDCT['dateOffset'], startTime=lclDCT['startTime'])
        else:
                billingCycle = None
        
        # Always pull in custom attributes
        lclAttr = lclDCT['customAttr'][1]
        
        # Debug output
        print('Creating subscriber ' + str(externalId))
        #if lclDCT['customAttr'][1]: print 'Including custom parameters: ' + str(lclAttr)
        
        # Build US Tax data
        serviceAddress = REST_UTIL.createServiceAddressData(streetAddr=lclDCT['streetAddr'], extendedAddr=lclDCT['extendedAddr'], locality=lclDCT['locality'], region=lclDCT['region'], postalCode=lclDCT['postalCode'], extendedPostalCode=lclDCT['extendedPostalCode'], countryCode=lclDCT['countryCode'])
        
        # Execute primitive
        retCode = REST_UTIL.createSubscriber(RESTInst,
                externalId=externalId,
                attr=lclAttr,
                billingCycle=billingCycle,
                firstName=lclDCT['firstName'],
                lastName=lclDCT['lastName'],
                contactPhoneNumber=lclDCT['contactPhoneNumber'],
                contactEmail=lclDCT['contactEmail'],
                notificationPreference=lclDCT['notificationPreference'],
                timeZone=lclDCT['subTimeZone'],
                status=lclDCT['subStatus'],
                language=lclDCT['language'],
                now=lclStartTime,
                taxStatus=lclDCT['taxStatus'],
                taxCertificate=lclDCT['taxCertificate'],
                taxLocation=lclDCT['taxLocation'],
                glCenter=lclDCT['glCenter'],
                routingType=lclDCT['routingType'],
                routingValue=lclDCT['routingValue'],
                eventPass=eventPass,
                executeMode=lclDCT['executeMode'],
                multiRequestBuild=DATA.V3Builder,
                apiEventData=lclDCT['customAttr'][6],
                 
                customerType=lclDCT['customerType'],
                serviceAddress=serviceAddress,
                npa=lclDCT['npa'],
                nxx=lclDCT['nxx'],
                tenantId=lclDCT['tenantId'],
                exemptionCodeList=lclDCT['exemptionCodeList'],
                )
                
        # Update tracking data.  Even if a Multi-Request we want the tracing data added.
        if eventPass: TRACK.updateTrackingData(lclDCT['ACTION'], externalId = externalId, mark=lclDCT['mark'], RESTInst=RESTInst)
                
        # If doing multi-request, then need to switch RESTInst
        if DATA.mrEnabled:
                # Store request
                DATA.mrCommands.append((retCode))
                
                # Store multi request index in case it's used later in the MR
                DATA.mrIndexObjectExternalId.append((externalId))
                
                # Query nothing
                queryValue = None
                queryType = None
        
        else:
                # Query subscriber
                queryValue = externalId
                queryType = subQueryType
        
        return (queryType, queryValue)
        
#==========================================================
def CmdSub_modifysubscriber(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
        
        # Subscriber should exist
        if externalId not in TRACK.subscriberTracking and not noChecks:
                print('ERROR: subscriber with ID "' + externalId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # OK...  We can have stuff that has been defaulted.  For modifies, only want to send in what was specifically requested to be modified.
        # Some fields (e.g. profileId) can't be modified and even setting them to the same value they were created with causes issues.
        # Build command to exec (very non-Pythonic...)
        if cmdLineInput:
         for param in DATA.subscriberModifyList + [x[0] for x in DATA.customSubscriberParameters]:
                if not cmdLineInput.count(param): lclDCT[param] = None
                
         # Really should recalculate Attr parameters as above lines were meant to clear those that were not input in the command line...
         (devAttr, subAttr, groupAttr, offerAttr, userAttr, loginAttr, apiEventDataAttr) = PRIM.getCustomAttributes(lclDCT, cmdLineInput)
        else:
                # Copy from dictionary
                subAttr = lclDCT['customAttr'][1]
                apiEventDataAttr = lclDCT['customAttr'][6]
          
        # Create billing cycle data if profileId defined
        if lclDCT['profileId'] and int(lclDCT['profileId']):
                billingCycle = REST_UTIL.createBillingCycleData(lclDCT['profileId'], dateOffset=lclDCT['dateOffset'], startTime=lclDCT['startTime'], immediateChange=lclDCT['immediateChange'])
                #print ' billingCycle = ' + str(billingCycle)
        else:
                billingCycle = None
        
        # Debug output
        print('Modifying subscriber ' + str(externalId))
        #if subAttr: print('Including custom parameters: ' + str(subAttr))
        
        # If the resourceId is not passed in and paymentToken is, then attempt to get it from the payment token
        if lclDCT['paymentToken'] and not resourceId:
                # Get payment data
                payment = PRIM.getPaymentData('subscriber', externalId, lclDCT['paymentToken'], lclStartTime, lclDCT['ACTION'], subQueryType)

                # Get the resource ID
                resourceId = int(payment.find('./ResourceId').text.strip())
                
        # Clear resourceId if set to 0
        if int(resourceId) == 0: resourceId = None
        
        # Build US Tax data
        serviceAddress = REST_UTIL.createServiceAddressData(streetAddr=lclDCT['streetAddr'], extendedAddr=lclDCT['extendedAddr'], locality=lclDCT['locality'], region=lclDCT['region'], postalCode=lclDCT['postalCode'], extendedPostalCode=lclDCT['extendedPostalCode'], countryCode=lclDCT['countryCode'])
        
        # Execute primitive
        retCode = REST_UTIL.modifySubscriber(RESTInst,
                externalId,
                attr=subAttr,
                billingCycle=billingCycle,
                firstName=lclDCT['firstName'],
                lastName=lclDCT['lastName'],
                contactPhoneNumber=lclDCT['contactPhoneNumber'],
                contactEmail=lclDCT['contactEmail'],
                notificationPreference=lclDCT['notificationPreference'],
                timeZone=lclDCT['subTimeZone'],
                status=lclDCT['subStatus'],
                language=lclDCT['language'],
                now=lclStartTime,
                taxStatus=lclDCT['taxStatus'],
                taxCertificate=lclDCT['taxCertificate'],
                taxLocation=lclDCT['taxLocation'],
                queryType=subQueryType,
                externalId=lclDCT['modExternalId'],
                glCenter=lclDCT['glCenter'],
                paymentGatewayUserId=lclDCT['paymentGatewayUserId'], currentPaymentTokenResourceId=resourceId,
                lastActivityUpdateTime=lclDCT['lastActivityUpdateTime'],
                apiEventData=apiEventDataAttr,
                billingCycleDisabled=lclDCT['billingCycleDisabled'],
                 
                customerType=lclDCT['customerType'],
                serviceAddress=serviceAddress,
                npa=lclDCT['npa'],
                nxx=lclDCT['nxx'],
                tenantId=lclDCT['tenantId'],
                exemptionCodeList=lclDCT['exemptionCodeList'],
                )
        
        # If changing external IDs, then need to update tracking data
        if lclDCT['modExternalId'] and (lclDCT['modExternalId'] != externalId):
               # Update tracking data
                TRACK.updateTrackingData(lclDCT['ACTION'], externalId = externalId, modId=lclDCT['modExternalId'])
        
        # Query subscriber
        if lclDCT['modExternalId']: queryValue = lclDCT['modExternalId']
        else:             queryValue = externalId
        queryType = subQueryType

        return (queryType, queryValue)
        
#==========================================================
# Work already done to get "next" IDs.  Just need to call add subscriber API
def CmdSub_addnextsubscriber(lclDCT, options, RESTInst, cmdLineInput):
        (queryType, queryValue) = CmdSub_addsubscriber(lclDCT, options, RESTInst, cmdLineInput)
        return (queryType, queryValue)
        
#==========================================================
def CmdSub_addsubscriber(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        offerId = lclDCT['offerId']
        offerStartTime = lclDCT['offerStartTime']
        offerEndTime = lclDCT['offerEndTime']
        # End of local variables setup.
        
        # Subscriber should not exist
        if externalId in TRACK.subscriberTracking and not noChecks:
                print('ERROR: subscriber with ID "' + externalId + '" is already defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Want to update local start time variable, so it's ready for the next iteration.
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if offerStartTime == None:
             offerStartTime = lclStartTime
        else:
             lclStartTime = offerStartTime
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if offerStartTime: lclStartTime = offerStartTime
        
        # Create billing cycle data if profile id defined
        if lclDCT['profileId'] and int(lclDCT['profileId']):
                billingCycle = REST_UTIL.createBillingCycleData(lclDCT['profileId'], dateOffset=lclDCT['dateOffset'], startTime=lclDCT['startTime'])
        else:
                billingCycle = None
        
        # ** Now work on offers.  Can have two parameters to specify this.  Can buy by external ID or catalog ID.  Can by legacy product ID or current catalog ID.
        # ** More difficult than it should be...
        #print 'offerIsExternal/offerIsCatalog = ' + str(offerIsExternal) + '/' + str(offerIsCatalog)
        (catalogItemId,offerId) = PRIM.processOffers(offerId, lclDCT['subOfferId'], lclDCT['offerIsExternal'], lclDCT['offerIsCatalog'])
        if catalogItemId: outStr = ' with catalog items ' + str(catalogItemId)
        else:             outStr = ' with offer IDs ' + str(offerId)

        # Debug output
        print('Adding subscriber ' + str(externalId) + ' with status ' + str(lclDCT['subStatus']) + ' and mark "' + str(lclDCT['mark']) + '"' + outStr)

        # ** End processing offers

        # Clear device data that's set to -1
        if str(lclDCT['deviceId']) == '-1': deviceId = None
        else: deviceId = lclDCT['deviceId']

        # Debug output
        if str(offerId) != '0':
                if lclDCT['verbose'] not in ['low', 'none']:
                 print('Subscriber is purchasing catalog item ' + str(offerId) + ' with start/end times ' + str(offerStartTime) + '/' + str(offerEndTime))

        # Always pull in custom attributes
        lclOfferAttr = lclDCT['customAttr'][3]
        lclSubAttr = lclDCT['customAttr'][1]
        lclDevAttr = lclDCT['customAttr'][0]
        
        # Build offer parameters
        try:    parameterList = PRIM.buildOfferParameters(CUST.custOfferParameterList, lclDCT)
        except: parameterList = None
        #print 'parameterList: ' + str(parameterList)
        
        print(lclDCT['ACTION'] + ' device = ' + deviceId + ', accessNumbers = ' + str(lclDCT['accessNumbers']) + ', offerID = ' + str(offerId))
        
        # Print custom data
        #if lclDCT['customAttr'][1]: print 'Including subscriber custom parameters: ' + str(lclSubAttr)
        #if lclDCT['customAttr'][0]: print 'Including device     custom parameters: ' + str(lclDevAttr)
        #if lclDCT['customAttr'][3]: print 'Including offer      custom parameters: ' + str(lclOfferAttr)
        
        # Convert datetime to time
        if lclDCT['offerCycleStartTime']: offerCycleStartTime = lclDCT['offerCycleStartTime'].split('T')[1][:8]
        
        # Build US Tax data
        serviceAddress = REST_UTIL.createServiceAddressData(streetAddr=lclDCT['streetAddr'], extendedAddr=lclDCT['extendedAddr'], locality=lclDCT['locality'], region=lclDCT['region'], postalCode=lclDCT['postalCode'], extendedPostalCode=lclDCT['extendedPostalCode'], countryCode=lclDCT['countryCode'])
        geoData = REST_UTIL.createGeoData(geoCode=lclDCT['geoCode'], postalCode=lclDCT['postalCode'], plus4=lclDCT['plus4'], npa=lclDCT['npa'], nxx=lclDCT['nxx'])
        
        # Execute primitive.
        # NOTE: today only support subscriber API event data.  API could define device and offer API event, but TF only doing Sub for this call.
        retCode = REST_UTIL.addSubscriber(RESTInst,
                externalId=externalId,
                deviceId=deviceId,
                deviceType=lclDCT['deviceType'],
                offerId=offerId,
                allDevices=lclDCT['allDevices'],
                offerStartTime=offerStartTime,
                offerEndTime=offerEndTime,
                serviceId=lclDCT['serviceId'],
                subAttr=lclSubAttr,
                devAttr=lclDevAttr,
                billingCycle=billingCycle,
                firstName=lclDCT['firstName'],
                lastName=lclDCT['lastName'],
                contactPhoneNumber=lclDCT['contactPhoneNumber'],
                contactEmail=lclDCT['contactEmail'],
                notificationPreference=lclDCT['notificationPreference'],
                timeZone=lclDCT['subTimeZone'],
                accessNumbers=lclDCT['accessNumbers'],
                subStatus=lclDCT['subStatus'],
                devStatus=lclDCT['devStatus'],
                language=lclDCT['language'],
                offerIsExternal=lclDCT['offerIsExternal'],
                now=lclStartTime,
                offerAttr=lclOfferAttr,
                taxStatus=lclDCT['taxStatus'],
                taxCertificate=lclDCT['taxCertificate'],
                taxLocation=lclDCT['taxLocation'],
                glCenter=lclDCT['glCenter'],
                eventPass=eventPass,
                catalogItemId=catalogItemId,
                paymentMethodResourceId=lclDCT['paymentMethodResourceId'],
                paymentGatewayId=lclDCT['paymentGatewayId'],
                paymentGatewayOneTimeToken=lclDCT['paymentGatewayOneTimeToken'],
                activationExpirationTime=lclDCT['activationExpirationTime'],
                activationExpirationRelativeOffsetUnit=lclDCT['activationExpirationRelativeOffsetUnit'],
                activationExpirationRelativeOffset=lclDCT['activationExpirationRelativeOffset'],
                endTimeRelativeOffsetUnit=lclDCT['endTimeRelativeOffsetUnit'],
                endTimeRelativeOffset=lclDCT['endTimeRelativeOffset'],
                offerCycleType=lclDCT['offerCycleType'], offerCycleOffset=lclDCT['offerCycleOffset'], offerCycleStartTime=lclDCT['offerCycleStartTime'],
                routingType=lclDCT['routingType'],
                routingValue=lclDCT['routingValue'],
                grantPurchaseProrationType=lclDCT['grantProrationType'],
                chargePurchaseProrationType=lclDCT['chargeProrationType'],
                reason=lclDCT['reason'],
                info=lclDCT['info'],
                subApiEventData=lclDCT['customAttr'][6],
                parameterList=parameterList,
                
                customerType=lclDCT['customerType'],
                serviceAddress=serviceAddress,
                npa=lclDCT['npa'],
                nxx=lclDCT['nxx'],
                tenantId=lclDCT['tenantId'],
                exemptionCodeList=lclDCT['exemptionCodeList'],
                geoData=geoData,
                )
        
        # Stuff to do if we passed
        if eventPass:
                # Update tracking data
                TRACK.updateTrackingData(lclDCT['ACTION'], externalId = externalId, deviceId = deviceId, accessNumbers=lclDCT['accessNumbers'], offerId = offerId, mark=lclDCT['mark'], RESTInst=RESTInst)
                
                # Update CSR so we can login as this access number
                if PRIMDATA.skipMyMatrixx.lower() != 'true':
                        accessNumToUse = []
                        if type(lclDCT['accessNumbers']) == type(list()):
                                accessNumToUse = lclDCT['accessNumbers']
                        else:
                                accessNumToUse.append(lclDCT['accessNumbers'])
                        for aN in accessNumToUse: QAUTILS.updateCsrData(aN)
                        
        # Query subscriber
        queryValue = externalId
        queryType = subQueryType
        
        return (queryType, queryValue)
        
#==========================================================
def CmdSub_createsubscriberbillingprofile(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
        
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Execute primitive
        retCode = REST_UTIL.createSubscriberBillingProfile(RESTInst,
                subscriberId=externalId,
                profileId=lclDCT['profileId'],
                startTime=lclDCT['startTime'],
                dateOffset=lclDCT['dateOffset'],
                queryType=subQueryType,
                eventPass=eventPass,
                )

        # Query subscriber
        queryValue = externalId
        queryType = subQueryType

        return (queryType, queryValue)
        
#==========================================================
def CmdSub_subscribetooffer(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        offerId = lclDCT['offerId']
        offerStartTime = lclDCT['offerStartTime']
        offerEndTime = lclDCT['offerEndTime']
        offerCycleResourceId = lclDCT['offerCycleResourceId']
        preActiveState = lclDCT['preActiveState']
        autoActivationCycleResourceId = lclDCT['autoActivationCycleResourceId']
        # End of local variables setup.
        
        # Default to no task ID for this case
        taskId = None
        
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Set the ofer start time to whatever the local test tool time if it's not specified via the input.
        if offerStartTime == None:
                if lclDCT['futureTime']:  offerStartTime = lclDCT['futureTime']
                else:           offerStartTime = lclStartTime
#        else: lclStartTime = offerStartTime

        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        elif lclStartTime != offerStartTime:
             print('Changing local test run time from ' + lclStartTime + ' to ' + offerStartTime + ' because offer start time parameter was specified.')
             lclStartTime = offerStartTime
        
        # Save updated time
        lclDCT['lclStartTime'] = lclStartTime
        
        # ** Now work on offers.  Can have two parameters to specify this.  Can buy by all offers, external ID, or catalog ID.  Can by legacy product ID or current catalog ID.
        # ** More difficult than it should be...
        #print 'offerIsExternal = ' + str(offerIsExternal) + ', offerIsCatalog = ' + str(offerIsCatalog) + ', offerId = ' + str(offerId) + ', subOfferId = ' + str(subOfferId)
        (catalogItemId,offerId) = PRIM.processOffers(offerId, lclDCT['subOfferId'], lclDCT['offerIsExternal'], lclDCT['offerIsCatalog'], lclDCT['allOffers'])
        #print 'catalogItemId = ' + str(catalogItemId) + ', offerId = ' + str(offerId)

#       (catalogItemId,offerId) = PRIM.processOffers(offerId, subOfferId, offerIsExternal, offerIsCatalog, allOffers)
        
        # If no offers specified, then this is an error
        if not offerId and not catalogItemId: sys.exit('ERROR: issued subscriber purchase offer command but did not specify any offers (offerId or subOfferId parameters)')
        
        # Debug output
        if lclDCT['verbose'] not in ['low', 'none']:
         print(REST_UTIL.subUrl.capitalize() + ' = ' + externalId + '(' + subQueryType + ') is purchasing catalog items '  + str(offerId) + ' with start/end times ' + str(offerStartTime) + '/' + str(offerEndTime))
        #print 'Offer attributes: ' + str(lclDCT['customAttr'][1][3])
        
        # If offer cycle type is align to a balance and resource ID not passed in, then need to retrieve that
        if lclDCT['offerCycleType'] == '3' and resourceId in [0, 'first', 'second', 'third', 'last']:
                # Get the balance in question
                balance = PRIM.getBalanceData('subscriber', externalId, lclDCT['balanceId'], resourceId, lclStartTime, lclDCT['ACTION'], subQueryType)

                # Get the resource ID
                resourceId = int(balance['ResourceId'])
        
                print('Sub offer purchase.  Retrieved resource ID ' + str(resourceId) + ' for balance ' + lclDCT['balanceId'])
        
        # If resource IDs passed in as a non-integer, then need to get its resource ID assuming they're offer external IDs
        for param in ['autoActivationCycleResourceId', 'offerCycleResourceId']:
                # Get the local parameter value
                value = lclDCT[param]
                
                # See if defined and not an integer and not 0 (so not a resource ID).
                # Ran into case where external IDs were numbers (Ugh...).  Add check for < 1000 so we do a look-up if the external ID is a large number.
                if value and not (value.isdigit() and value != '0' and int(value) < 1000):
                        # Get resource ID data
                        offerDict = PRIM.getOfferData('subscriber', externalId, 0, value, lclStartTime, lclDCT['ACTION'], queryType=subQueryType, offerIsCatalog=True)
                        
                        # Get the resource ID
                        if   param == 'autoActivationCycleResourceId': autoActivationCycleResourceId = int(offerDict['ResourceId'])
                        elif param == 'offerCycleResourceId':          offerCycleResourceId = int(offerDict['ResourceId'])
                        
                        print('Retrieved ' + param + ' = ' + offerDict['ResourceId'])
        
        # Assume nothing to query
        queryValue = queryType = None
        
        # Having fun with preActiveState and JSON.  If false set to None
        if preActiveState == False or str(preActiveState).lower() == '0': preActiveState = None
        
        # Fix down payment of 0 to be None
        if str(lclDCT['amount']) == '0': amount = None
        else: amount = lclDCT['amount']
    
        # Build offer parameters
        try:    parameterList = PRIM.buildOfferParameters(CUST.custOfferParameterList, lclDCT)
        except: parameterList = None
        #print 'parameterList: ' + str(parameterList)
        
        # Convert datetime to time
        if lclDCT['offerCycleStartTime']: offerCycleStartTime = lclDCT['offerCycleStartTime'].split('T')[1][:8]
        
        # Build US Tax data
        geoData = REST_UTIL.createGeoData(geoCode=lclDCT['geoCode'], postalCode=lclDCT['postalCode'], plus4=lclDCT['plus4'], npa=lclDCT['npa'], nxx=lclDCT['nxx'])
        print('geoData = ' + str(geoData))
        
        # If the offer file was specified, then repeat the command for all entries in the file
        if lclDCT['offerFile']:
          # open the file
          f = open(lclDCT['offerFile'], 'r')

          # Loop through the file
          for externalId in f:
           externalId = externalId.strip()
           #print 'Running command for external ID: "' + externalId + '"'
                   # Execute primitive
           (retCode, resourceIds) = REST_UTIL.subscribeToOffer(RESTInst,
                externalId=externalId,
                offerId=offerId,
                deviceId=lclDCT['deviceId'],
                allDevices=lclDCT['allDevices'],
                offerStartTime=offerStartTime,
                offerEndTime=offerEndTime,
                serviceId=lclDCT['serviceId'],
                eventPass=eventPass,
                queryType=subQueryType,
                now=offerStartTime,
                offerIsExternal=lclDCT['offerIsExternal'],
                attr=lclDCT['customAttr'][3],
                executeMode=lclDCT['executeMode'],
                catalogItemId = catalogItemId,
                chargeMethod=lclDCT['chargeMethod'],
                paymentMethodResourceId=lclDCT['paymentMethodResourceId'],
                paymentGatewayId=lclDCT['paymentGatewayId'],
                paymentGatewayOneTimeToken=lclDCT['paymentGatewayOneTimeToken'],
                endTimeRelativeOffsetUnit=lclDCT['endTimeRelativeOffsetUnit'],
                endTimeRelativeOffset=lclDCT['endTimeRelativeOffset'],
                preActiveState=preActiveState,
                activationExpirationTime=lclDCT['activationExpirationTime'],
                activationExpirationRelativeOffsetUnit=lclDCT['activationExpirationRelativeOffsetUnit'],
                activationExpirationRelativeOffset=lclDCT['activationExpirationRelativeOffset'],
                autoActivationTime=lclDCT['autoActivationTime'],
                autoActivationRelativeOffsetUnit=lclDCT['autoActivationRelativeOffsetUnit'],
                autoActivationRelativeOffset=lclDCT['autoActivationRelativeOffset'],
                autoActivationCycleResourceId=autoActivationCycleResourceId,
                offerCycleType=lclDCT['offerCycleType'], offerCycleOffset=lclDCT['offerCycleOffset'], offerCycleResourceId=offerCycleResourceId, offerCycleStartTime=lclDCT['offerCycleStartTime'],
                grantPurchaseProrationType=lclDCT['grantProrationType'],
                chargePurchaseProrationType=lclDCT['chargeProrationType'],
                isRecurringFailureAllowed=lclDCT['isRecurringFailureAllowed'],
                reason=lclDCT['reason'],
                info=lclDCT['info'],
                eligibilityCheck=lclDCT['eligibilityCheck'],
                contractPeriod=lclDCT['contractPeriod'],
                contractInterval=lclDCT['contractInterval'],
                commitmentPeriod=lclDCT['commitmentPeriod'],
                commitmentPeriodInterval=lclDCT['commitmentPeriodInterval'],
                isOpenContract=lclDCT['isOpenContract'],
                etcScheduleRangeArray=lclDCT['etcScheduleRangeArray'],
                etcScheduleRangeUnit=lclDCT['etcScheduleRangeUnit'],
                paymentScheduleRangeArray=lclDCT['paymentScheduleRangeArray'],
                paymentScheduleAmountArray=lclDCT['paymentScheduleAmountArray'],
                paymentScheduleLastAmount=lclDCT['paymentScheduleLastAmount'],
                delayCharge=lclDCT['delayCharge'],
                paymentDueDate=lclDCT['paymentDueDate'],
                parameterList=parameterList,
                
                )
           
           # Update tracking data
           if eventPass: TRACK.updateTrackingData(lclDCT['ACTION'], externalId = externalId, offerId = offerId, taskId=taskId, resourceId = resourceIds)

        else:
          if lclDCT['futureTime']:
           print('Purchasing offer in the future')
           # Execute primitive
           taskId = REST_UTIL.subscriberPurchaseOfferInFuture(RESTInst,
                externalId,
                offerId,
                lclDCT['futureTime'],
                offerStartTime=offerStartTime,
                offerEndTime=offerEndTime,
                eventPass=eventPass,
                queryType=subQueryType,
                now=offerStartTime,
                offerIsExternal=lclDCT['offerIsExternal'],
                attr=lclDCT['customAttr'][3],
                skipVtime=True,
                catalogItemId = catalogItemId,
                )
           resourceIds = None
           
           # Debug output on success
           if eventPass: print('Scheduled subscriber offer purchase task ' + str(taskId) + ' for time ' + lclDCT['futureTime'])
           
          elif lclDCT['allOffers']:
           # Want a trace after each purchase
           for offerItem in offerId:
            print('Purchasing offer: "' + offerItem + '"')
            # Execute primitive
            #MTX-24538 - replace below with catalogItemId = offerId,
            (retCode, resourceIds) = REST_UTIL.subscribeToOffer(RESTInst,
                externalId=externalId,
                offerId=offerItem,
                deviceId=lclDCT['deviceId'],
                allDevices=lclDCT['allDevices'],
                offerStartTime=offerStartTime,
                offerEndTime=offerEndTime,
                serviceId=lclDCT['serviceId'],
                eventPass=eventPass,
                queryType=subQueryType,
                now=offerStartTime,
                offerIsExternal=lclDCT['offerIsExternal'],
                attr=lclDCT['customAttr'][3],
                executeMode=lclDCT['executeMode'],
                catalogItemId = offerItem,
                chargeMethod=lclDCT['chargeMethod'],
                paymentMethodResourceId=lclDCT['paymentMethodResourceId'],
                paymentGatewayId=lclDCT['paymentGatewayId'],
                paymentGatewayOneTimeToken=lclDCT['paymentGatewayOneTimeToken'],
                preActiveState=preActiveState,
                activationExpirationTime=lclDCT['activationExpirationTime'],
                activationExpirationRelativeOffsetUnit=lclDCT['activationExpirationRelativeOffsetUnit'],
                activationExpirationRelativeOffset=lclDCT['activationExpirationRelativeOffset'],
                endTimeRelativeOffsetUnit=lclDCT['endTimeRelativeOffsetUnit'],
                endTimeRelativeOffset=lclDCT['endTimeRelativeOffset'],
                autoActivationTime=lclDCT['autoActivationTime'],
                autoActivationRelativeOffsetUnit=lclDCT['autoActivationRelativeOffsetUnit'],
                autoActivationRelativeOffset=lclDCT['autoActivationRelativeOffset'],
                autoActivationCycleResourceId=autoActivationCycleResourceId,
                offerCycleType=lclDCT['offerCycleType'], offerCycleOffset=lclDCT['offerCycleOffset'], offerCycleResourceId=offerCycleResourceId, offerCycleStartTime=lclDCT['offerCycleStartTime'],
                grantPurchaseProrationType=lclDCT['grantProrationType'],
                chargePurchaseProrationType=lclDCT['chargeProrationType'],
                isRecurringFailureAllowed=lclDCT['isRecurringFailureAllowed'],
                reason=lclDCT['reason'],
                info=lclDCT['info'],
                eligibilityCheck=lclDCT['eligibilityCheck'],
                contractPeriod=lclDCT['contractPeriod'],
                contractInterval=lclDCT['contractInterval'],
                commitmentPeriod=lclDCT['commitmentPeriod'],
                commitmentPeriodInterval=lclDCT['commitmentPeriodInterval'],
                isOpenContract=lclDCT['isOpenContract'],
                etcScheduleRangeArray=lclDCT['etcScheduleRangeArray'],
                etcScheduleRangeUnit=lclDCT['etcScheduleRangeUnit'],
                paymentScheduleRangeArray=lclDCT['paymentScheduleRangeArray'],
                paymentScheduleAmountArray=lclDCT['paymentScheduleAmountArray'],
                paymentScheduleLastAmount=lclDCT['paymentScheduleLastAmount'],
                paymentDueDate=lclDCT['paymentDueDate'],
                parameterList=parameterList,
                )
                
            # Run trace command (output goes to std out)
            if lclDCT['trace']: PRIM.printToScreen(lclDCT['saveFunc'], externalId, subQueryType, lclDCT, lclStartTime)

          else:
                # Execute primitive
                (retCode, response) = REST_UTIL.subscribeToOffer(RESTInst,
                                externalId=externalId,
                                offerId=offerId,
                                deviceId=lclDCT['deviceId'],
                                allDevices=lclDCT['allDevices'],
                                offerStartTime=offerStartTime,
                                offerEndTime=offerEndTime,
                                serviceId=lclDCT['serviceId'],
                                eventPass=eventPass,
                                queryType=subQueryType,
                                offerIsExternal=lclDCT['offerIsExternal'],
                                attr=lclDCT['customAttr'][3],
                                executeMode=lclDCT['executeMode'],
                                catalogItemId = catalogItemId,
                                chargeMethod=lclDCT['chargeMethod'],
                                paymentMethodResourceId=lclDCT['paymentMethodResourceId'],
                                paymentGatewayId=lclDCT['paymentGatewayId'],
                                paymentGatewayOneTimeToken=lclDCT['paymentGatewayOneTimeToken'],
                                purchaseInfo=True,
                                preActiveState=preActiveState,
                                activationExpirationTime=lclDCT['activationExpirationTime'],
                                activationExpirationRelativeOffsetUnit=lclDCT['activationExpirationRelativeOffsetUnit'],
                                activationExpirationRelativeOffset=lclDCT['activationExpirationRelativeOffset'],
                                endTimeRelativeOffsetUnit=lclDCT['endTimeRelativeOffsetUnit'],
                                endTimeRelativeOffset=lclDCT['endTimeRelativeOffset'],
                                autoActivationTime=lclDCT['autoActivationTime'],
                                autoActivationRelativeOffsetUnit=lclDCT['autoActivationRelativeOffsetUnit'],
                                autoActivationRelativeOffset=lclDCT['autoActivationRelativeOffset'],
                                autoActivationCycleResourceId=autoActivationCycleResourceId,
                                offerCycleType=lclDCT['offerCycleType'], offerCycleOffset=lclDCT['offerCycleOffset'], offerCycleResourceId=offerCycleResourceId, offerCycleStartTime=lclDCT['offerCycleStartTime'],
                                downPayment=amount,
                                isTargetResource=lclDCT['isTargetResource'],
                                useTargetResource=lclDCT['useTargetResource'],
                                multiRequestBuild=DATA.V3Builder,
                                grantPurchaseProrationType=lclDCT['grantProrationType'],
                                chargePurchaseProrationType=lclDCT['chargeProrationType'],
                                isRecurringFailureAllowed=lclDCT['isRecurringFailureAllowed'],
                                reason=lclDCT['reason'],
                                info=lclDCT['info'],
                                eligibilityCheck=lclDCT['eligibilityCheck'],
                                apiEventData=lclDCT['customAttr'][6],
                                etcScheduleRangeArray=lclDCT['etcScheduleRangeArray'],
                                etcScheduleRangeUnit=lclDCT['etcScheduleRangeUnit'],
                                paymentScheduleRangeArray=lclDCT['paymentScheduleRangeArray'],
                                paymentScheduleAmountArray=lclDCT['paymentScheduleAmountArray'],
                                paymentScheduleLastAmount=lclDCT['paymentScheduleLastAmount'],
                                contractPeriod=lclDCT['contractPeriod'],
                                contractInterval=lclDCT['contractInterval'],
                                commitmentPeriod=lclDCT['commitmentPeriod'],
                                commitmentPeriodInterval=lclDCT['commitmentPeriodInterval'],
                                isOpenContract=lclDCT['isOpenContract'],
                                paymentDueDate=lclDCT['paymentDueDate'],
                                parameterList=parameterList,
                                
                                geoData=geoData,
                                )
                                #now=offerStartTime,
           
                # Do stuff if expecting success and not a multi-request
                if eventPass and not DATA.V3Builder:
                        # Store purchase constants.  Some customers remove the resource ID...
                        try:
                                if eventPass: PRIM.storeOfferConstants(REST_UTIL.subUrl, response, catalogItemId, offerId)
                        except: pass
                        
                        # Update tracking data
                        TRACK.updateTrackingData(lclDCT['ACTION'], externalId = externalId, offerId = offerId, taskId=taskId, resourceId = [resourceId])
                                
                # If doing multi-request, then need to switch RESTInst
                if DATA.mrEnabled:
                        print('Storing command for multi-request')
                        
                        # Store request
                        DATA.mrCommands.append((response))
                        
                        # Query nothing
                        queryValue = None
                        queryType = None
                
                else:
                        # Query subscriber
                        queryValue = externalId
                        queryType = subQueryType
        
        return (queryType, queryValue)
        
#==========================================================
def CmdSub_unsubscribefromoffer(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        offerId = lclDCT['offerId']
        offerEndTime = lclDCT['offerEndTime']
        # End of local variables setup.
        
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Set the offer end time to whatever the local test tool time if it's not specified via the input.
        if offerEndTime == None:
                if lclDCT['futureTime']:  offerEndTime = lclDCT['futureTime']
                else:           offerEndTime = lclStartTime
#       else: lclStartTime = offerEndTime
        
        print('Unsubscriber time: ' + str(offerEndTime))

        # Can provide subOfferId or offerId for this command.
        # Map to offer ID.
        if (not offerId or offerId.count('0')) and lclDCT['subOfferId']: offerId = lclDCT['subOfferId']

        # If future time, then need to retrieve the taskId of the schedueld task
        if lclDCT['futureTime']:
          # Retrieve future task ID.
          # NOTE:  at the moment only one future task ID is stored per external ID.  Will enhance this in the future.
          taskId = TRACK.subscriberTracking[externalId]['taskId']
          #print 'Retrieved Task: ' + str(taskId)

          # If no task and expecting a failure, then use a dummy task Id (negative testing)
          if not taskId and not eventPass:
                taskId = '0-1-2-3'
                print('Created a dummy value for a taskId, for negative testing: ' + taskId)

        else:
          # No task ID here
          taskId = None

          # If no resource ID passed in, then need to get using the external IDs
          if lclDCT['futureTime']: resourceId = None
          elif resourceId in [0, 'first', 'second', 'third', 'last']:
                resourceData = ''
                for idx in range(len(offerId)):
                        offerDict = PRIM.getOfferData('subscriber', externalId, 0, offerId[idx], lclStartTime, lclDCT['ACTION'], queryType=subQueryType, offerIsCatalog=lclDCT['offerIsCatalog'], resourceId=resourceId)

                        # Get the resource ID
                        resourceData += str(offerDict['ResourceId']) + '@'
#                       print 'Subscriber ' + str(externalId) + ' canceling offer with exernal ID = ' + offerId[idx] + ', resource ID ' + str(offerDict['ResourceId'])
                
                # Remove trailing list character
                resourceId = resourceData[:-1]
        
          # Convert resource ID to a list
          resourceId = resourceId.split('@')
        
        # What to print depends on catalog vs offer...
        if lclDCT['offerIsCatalog']:
                offertype = 'catalog'
        else:
                offertype = 'legacy'
        
        # Debug output
        if lclDCT['verbose'] not in ['low', 'none']:
                print(REST_UTIL.subUrl.capitalize() + ' = ' + externalId + ' is unsubscribing from ' + offertype + ' offer(s) with resource IDs ' + str(resourceId) + ' with end time ' + str(offerEndTime))

        # Execute appropriate primitive
        if lclDCT['futureTime']:
          print('Killing task ' + taskId + '  expected result = ' + str(eventPass))
          REST_UTIL.subscriberCancelOfferInFuture(RESTInst,
                lclDCT['futureTime'],
                queryType = 'ObjectId',
                queryValue = taskId,
                resourceIdList = [],
                eventPass=eventPass,
                skipVtime = True,
                now=offerEndTime,
                )
        else:
          retCode = REST_UTIL.unsubscribeFromOffer(RESTInst,
                externalId,
                resourceId=resourceId,
                endTime=offerEndTime,
                eventPass=eventPass,
                queryType=subQueryType,
                eligibilityCheck=lclDCT['eligibilityCheck'],
                apiEventData=lclDCT['customAttr'][6],
                )

        # Update tracking data
        if eventPass: TRACK.updateTrackingData(lclDCT['ACTION'], externalId = externalId, offerId = offerId, resourceId = resourceId, taskId=taskId)

        # Query subscriber
        queryValue = externalId
        queryType = subQueryType

        return (queryType, queryValue)
        
#==========================================================
def CmdSub_modifysubscriberoffer(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        offerId = lclDCT['offerId']
        offerStartTime = lclDCT['offerStartTime']
        offerEndTime = lclDCT['offerEndTime']
        offerCycleResourceId = lclDCT['offerCycleResourceId']
        # End of local variables setup.
        
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Can provide subOfferId or offerId for this command.
        # Map to offer ID.
        if (not offerId or offerId.count('0')) and lclDCT['subOfferId']: offerId = lclDCT['subOfferId']

        # If no resource ID passed in, then need to get using the external ID
        if resourceId in [0, 'first', 'second', 'third', 'last']:
                offerDict = PRIM.getOfferData('subscriber', externalId, resourceId, offerId[0], lclStartTime, lclDCT['ACTION'], queryType=subQueryType, offerIsCatalog=True, resourceId=resourceId)

                # Get the resource ID
                resourceId = int(offerDict['ResourceId'])
        
        # If resource IDs passed in as a non-integer, then need to get its resource ID assuming they're offer external IDs
        for param in ['offerCycleResourceId']:
                # Get the local parameter value
                value = lclDCT[param]
                
                # See if defined and not an integer and not 0 (so not a resource ID)
                if value and not (value.isdigit() and value != '0'):
                        # Get resource ID data
                        offerDict = PRIM.getOfferData('subscriber', externalId, 0, value, lclStartTime, lclDCT['ACTION'], queryType=subQueryType, offerIsCatalog=True)
                        
                        # Get the resource ID
                        if param == 'offerCycleResourceId': offerCycleResourceId = int(offerDict['ResourceId'])
                        
                        print('Retrieved ' + param + ' = ' + offerDict['ResourceId'])
        
        if offerId == None: offerId = ['<not specified>']
        print(REST_UTIL.subUrl.capitalize() + ' ' + str(externalId) + ' modifying offer with exernal ID = ' + offerId[0] + ', resource ID ' + str(resourceId))
        if offerCycleResourceId: print('offerCycleResourceId = ' + str(offerCycleResourceId))
        
        # Build offer parameters
        try:    parameterList = PRIM.buildOfferParameters(CUST.custOfferParameterList, lclDCT)
        except: parameterList = None
        #print 'parameterList: ' + str(parameterList)
        
        # Convert datetime to time
        if lclDCT['offerCycleStartTime']: offerCycleStartTime = lclDCT['offerCycleStartTime'].split('T')[1][:8]
        
        # Execute primitive
        retCode = REST_UTIL.subscriberOfferModify(RESTInst,
                externalId,
                resourceId=resourceId,
                startTime=offerStartTime,
                endTime=offerEndTime,
                attr=lclDCT['customAttr'][3],
                eventPass=eventPass,
                queryType=subQueryType,
                executeMode=lclDCT['executeMode'],
                cycleType=lclDCT['offerCycleType'],
                cycleResourceId=offerCycleResourceId,
                cycleOffset=lclDCT['offerCycleOffset'],
                cycleAlignmentDisabled=lclDCT['offerCycleAlignmentDisabled'],
                immediateChange=lclDCT['immediateChange'],
                status=lclDCT['offerStatus'],
                now=lclStartTime,
                apiEventData=lclDCT['customAttr'][6],
                cycleStartTime=lclDCT['offerCycleStartTime'],
                cycleEndTime=lclDCT['offerCycleEndTime'],
                parameterList=parameterList,
                endTimeExtensionOffset = lclDCT['offerEndTimeExtensionOffset'],
                endTimeExtensionOffsetUnit = lclDCT['offerEndTimeExtensionOffsetUnit'],
                )

        # Update tracking data
        # NOTE:  if multiple resources were sent through, then need to fix the TRACK function...
        #if eventPass: TRACK.updateTrackingData(lclDCT['ACTION'], externalId = externalId, offerId = offerId, resourceId = resourceId[0])

        # Query subscriber
        queryValue = externalId
        queryType = subQueryType
        
        return (queryType, queryValue)
        
#==========================================================
def CmdSub_addsubscriberthreshold(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
        
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # notify parameter is taken from notificationPreference
        if lclDCT['notificationPreference'] != '0':
                notify = True
        else:
                notify = False
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']

        # If no resource ID passed in and a balance ID was passed in, then go find it
        if resourceId in [0, 'first', 'second', 'third', 'last'] and int(lclDCT['balanceId']) > 0:
                # Get the balance in question
                balance = PRIM.getBalanceData('subscriber', externalId, lclDCT['balanceId'], resourceId, lclStartTime, lclDCT['ACTION'], subQueryType)

                # Get the resource ID
                resourceId = int(balance['ResourceId'])
        
        # If threshold ID is still non-numeric, then give it one more chance to translate, as the user may have used the CB name.
        # Since threshold names are not unique across balances, generic name translation can't be used.
        if not lclDCT['thresholdId'].isdigit(): (lclDCT['thresholdId'], thresholdAmount, percentFlag) = PRIM.getThresholdId(lclDCT['balanceId'], lclDCT['thresholdId'])
        
        # Can reference payment method by name or resource ID
        if str(lclDCT['paymentMethodResourceId']) == '999' and lclDCT['name']: paymentMethodResourceId = PAYNOW.getPaymentResourceId(externalId, subQueryType, lclDCT['name'], objType = 'Subscriber')
        
        # Check if multiple IDs requested
        if lclDCT['everySubInGroup']: extList = TRACK.retrieveTrackingData('queryEverySubInGroupEvent', groupId = lclDCT['groupId'])
        else:               extList = [externalId]
        
        for extId in extList:
         print('Executing command for external ID + ' + str(extId))
         # Execute primitive
         retCode = REST_UTIL.addSubscriberThreshold(RESTInst,
                extId,
                lclDCT['thresholdId'],
                resourceId=resourceId,
                threshName=lclDCT['name'],
                val=lclDCT['amount'],
                notify=notify,
                eventPass=eventPass,
                queryType=subQueryType,
                now=lclStartTime,
                recurringStart=lclDCT['recurringStart'],
                recurringStop=lclDCT['recurringStop'],
                virtualCreditLimitIsPercent=lclDCT['virtualCreditLimitIsPercent'],
                isTemporaryCreditLimit=lclDCT['isTemporaryCreditLimit'],
                rechargeAmount=lclDCT['rechargeAmount'],
                rechargePaymentMethodResourceId=lclDCT['paymentMethodResourceId'],
                apiEventData=lclDCT['customAttr'][6],
                )

        # Query subscriber
        queryValue = externalId
        queryType = subQueryType
        
        return (queryType, queryValue)
        
#==========================================================
def CmdSub_removesubscriberthreshold(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
        
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # If no resource ID passed in and a balance ID was passed in, then go find it
        if resourceId in [0, 'first', 'second', 'third', 'last'] and int(lclDCT['balanceId']) > 0:
                # Get the balance in question
                balance = PRIM.getBalanceData('subscriber', externalId, lclDCT['balanceId'], resourceId, lclStartTime, lclDCT['ACTION'], subQueryType)

                # Get the resource ID
                resourceId = int(balance['ResourceId'])
        
        # If threshold ID is still non-numeric, then give it one more chance to translate, as the user may have used the CB name.
        # Since threshold names are not unique across balances, generic name translation can't be used.
        if not lclDCT['thresholdId'].isdigit(): (lclDCT['thresholdId'], thresholdAmount, percentFlag) = PRIM.getThresholdId(lclDCT['balanceId'], lclDCT['thresholdId'])
        
        # Execute primitive
        retCode = REST_UTIL.removeSubscriberThreshold(RESTInst,
                externalId,
                resourceId,
                lclDCT['thresholdId'],
                now=lclStartTime,
                queryType=subQueryType,
                isTemporaryCreditLimit=lclDCT['isTemporaryCreditLimit'],
                removeRechargeDataOnly=lclDCT['removeRechargeDataOnly'],
                removeThresholdOnly=lclDCT['removeThresholdOnly'],
                apiEventData=lclDCT['customAttr'][6],
                )

        # Query subscriber
        queryValue = externalId
        queryType = subQueryType
        
        return (queryType, queryValue)
        
#==========================================================
def CmdSub_querysubscriber(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        outputFileName = lclDCT['outputFileName']
        # End of local variables setup.
        
        # Map event pass to true/False (used by many commands).
        # NOTE. If saveData specified then the query should succeed and the eventpass is tied to the saveData option.
        if lclDCT['saveData']: eventPass = True
        
        # Get list of subscribers to query:
        subIdToSend = TRACK.retrieveTrackingData(lclDCT['ACTION'], externalId = externalId, groupId = lclDCT['groupId'], scope = lclDCT['scope'], mark=lclDCT['mark'])

        # If just querying a sub, then do here
        if lclDCT['ACTION'] == 'querySubscriber':
          # Subscriber should exist
          if externalId not in TRACK.subscriberTracking and not noChecks:
                print('ERROR: subscriber with ID "' + externalId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

          # If verbose set but no output file, then set to stdout
          if lclDCT['verbose'] in ['full', 'high'] and not outputFileName: outputFileName = 'stdout'
          
          # May be here just to get the normal output file.  Check and skip this query if so.
          if lclDCT['saveData'] or (outputFileName and outputFileName.lower() != 'none'):
             # Execute primitive
             retCode = REST_UTIL.querySubscriber(RESTInst,
                externalId,
                eventPass=eventPass,
                queryType=subQueryType,
                now=lclStartTime
                )
                
             # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
             try:
                respData = str(retCode.printElementBasedXml())
             except:
                respData = str(retCode)
                
             # If supposed to save data to variables then do that here
             if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, 'Subscriber', respData)
             
             # if supposed to store output then write to where the caller wanted it to go.  Only if not saving data.
             elif outputFileName and outputFileName.lower() != 'none': CSVQA.processDataToOutput(respData, outputFileName)

          # Query subscriber
          if eventPass: queryValue = externalId
          else:  queryValue = None
          queryType = subQueryType
        else:
                # Query each item in the list. The list we have is subscriber absolute numbers.
                for sub in subIdToSend:
                        newLine='querySubscriber;externalId=a' + sub + ';outputFileName=' + outputFileName + ';verbose=' + lclDCT['verbose']
                        print(lclDCT['ACTION'] + ': newLine = ' + newLine)
                        (step, lclStartTime, repeat, options, sessionId) = processSingleLineInput(lclDCT['testName'], lclDCT['sessionId'], newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, lclDCT['step'], 1)

                # Query nothing from this command
                queryValue = None

        return (queryType, queryValue)
        
        
#==========================================================
def CmdSub_queryeverysubevent(lclDCT, options, RESTInst, cmdLineInput):
        return CmdSub_querysubscriber(lclDCT, options, RESTInst=RESTInst)

#==========================================================
def CmdSub_queryeverysubingroupevent(lclDCT, options, RESTInst, cmdLineInput):
        return CmdSub_querysubscriber(lclDCT, options, RESTInst=RESTInst)

#==========================================================
def CmdSub_querysubscriberwallet(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
                
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']

        # May be here just to get the normal output file.  Check and skip this query if so
        if lclDCT['saveData'] or (lclDCT['outputFileName'] and lclDCT['outputFileName'].lower() != 'none'):
             # Execute primitive
             retCode = REST_UTIL.querySubscriberWallet(RESTInst,
                externalId,
                eventPass=eventPass,
                queryType=subQueryType,
                now=lclStartTime
                )
                
             # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
             try:
                respData = str(retCode.printElementBasedXml())
             except:
                respData = str(retCode)
        
             # If supposed to save data to variables then do that here
             if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, REST_UTIL.subUrl.capitalize(), respData)
             
             # if supposed to store output then write to where the caller wanted it to go.  nly if not saving data.
             elif lclDCT['outputFileName'] and lclDCT['outputFileName'].lower() != 'none': CSVQA.processDataToOutput(respData, lclDCT['outputFileName'])

        # Query subscriber
        if eventPass: queryValue = externalId
        else:  queryValue = None
        queryType = subQueryType

        return (queryType, queryValue)
        
#==========================================================
def CmdSub_subscriberadjustrolloverbalance(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
                
        # Set target
        target = 'subscriber'
        
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command 
        # times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']
        
        # Lots of reasons to adjust amount
        #print 'Subscriber adjusting balance ID ' + str(balanceId) + ', with resource ID ' + str(resourceId)
        (amount, adjustType, resourceId) = PRIM.makeAmountAdjustments(target, externalId, lclDCT)
        
        # If interval needed, then get it
        if not lclDCT['balanceIntervalId'].isdigit():
                balanceData = PRIM.getBalanceRolloverData(target, externalId, lclDCT['balanceId'], resourceId, queryType='ExternalId', lclStartTime=lclStartTime)
                pprint.pprint(balanceData)
                
                # Get numbetr of entries
                numEntries = len(balanceData)
        
                # OK; we have the data.  Now get the desired interval.
                # May be words first or last, or a negative amount for th edesired period backwards.
                if   lclDCT['balanceIntervalId'].lower() == 'last':  index = str(numEntries)
                elif lclDCT['balanceIntervalId'].lower() == 'first': index = '1'
                else:                                      index = -1 * int(lclDCT['balanceIntervalId'])
                
                # Now get the IntervalId from the data
                balanceIntervalId = balanceData[index]['IntervalId']
        
        # Execute primitive
        retCode = REST_UTIL.subscriberAdjustRolloverBalance(RESTInst,
                queryValue=externalId,
                balanceResourceId=resourceId,
                balanceIntervalId=balanceIntervalId,
                adjustType=adjustType,
                amount=str(amount),
                reason=lclDCT['reason'],
                queryType=subQueryType,
                info=lclDCT['info'],
                now=lclStartTime,
                eventPass=eventPass,
                remainingRolloverCounter=lclDCT['remainingRolloverCounter'],
                apiEventData=lclDCT['customAttr'][6],
                )
        
        # Query subscriber
        queryValue = externalId
        queryType = subQueryType

        return (queryType, queryValue)
        
#==========================================================
def CmdSub_subscriberadjustbalance(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        amount = lclDCT['amount']
        adjustType = lclDCT['adjustType']
        # End of local variables setup.
                
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']
        
        # Lots of reasons to adjust amount
        #print 'Subscriber adjusting balance ID ' + str(balanceId) + ', with resource ID ' + str(resourceId)
        # NOTE: if part of a multi-request then the balance may not exist.  need to pass down all values anbd no formulas.
        if not DATA.mrEnabled: (amount, adjustType, resourceId) = PRIM.makeAmountAdjustments('subscriber', externalId, lclDCT)

        # Execute primitive
        #print 'Balance adjust data (unit, offset, time) = ' + str(lclDCT['balanceEndTimeExtensionOffsetUnit']) + ', ' + str(lclDCT['balanceEndTimeExtensionOffset']) + ', ' + str(lclDCT['balanceEndTime'])
        
        # If doing multi-request, then need to switch RESTInst
        if DATA.mrEnabled:
                # Invoke command
                retCode = DATA.V3Builder.subscriberAdjustBalance(queryType=subQueryType,
                        queryValue=externalId,
                        balanceResourceId=resourceId,
                        adjustType=adjustType,
                        amount=str(amount),
                        reason=lclDCT['reason'],
                        info=lclDCT['info'],
                        now=lclStartTime,
                        endTimeExtensionOffsetUnit=lclDCT['balanceEndTimeExtensionOffsetUnit'],
                        endTimeExtensionOffset=lclDCT['balanceEndTimeExtensionOffset'],
                        startTime=lclDCT['balanceStartTime'],
                        endTime=lclDCT['balanceEndTime'],
                        creditLimitPolicy=lclDCT['creditLimitPolicy'],
                        )
                
                # Store request
                DATA.mrCommands.append((retCode))
                
                # Nothing to query since nothing executed
                queryValue = None
                queryType = None
        else:
                retCode = REST_UTIL.subscriberAdjustBalance(RESTInst,
                        externalId,
                        resourceId,
                        adjustType,
                        str(amount),
                        lclDCT['reason'],
                        queryType=subQueryType,
                        info=lclDCT['info'],
                        now=lclStartTime,
                        eventPass=eventPass,
                        endTimeExtensionOffsetUnit=lclDCT['balanceEndTimeExtensionOffsetUnit'],
                        endTimeExtensionOffset=lclDCT['balanceEndTimeExtensionOffset'],
                        startTime=lclDCT['balanceStartTime'],
                        endTime=lclDCT['balanceEndTime'],
                        creditLimitPolicy=lclDCT['creditLimitPolicy'],
                        componentMeterId=lclDCT['componentMeterId'],
                        executeMode=lclDCT['executeMode'],
                        apiEventData=lclDCT['customAttr'][6],
                        )
        
                # Query subscriber
                queryValue = externalId
                queryType = subQueryType
        
        return (queryType, queryValue)
        
#==========================================================
def CmdSub_subscriberclearbalance(lclDCT, options, RESTInst, cmdLineInput):
        return CmdSub_subscriberadjustbalance(lclDCT, options, RESTInst, cmdLineInput)

#==========================================================
def CmdSub_subscribertopupbalance(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
        
        # Check for invalid combination
        if lclDCT['mark'] and noChecks:
                print('ERROR:  can\'t specify a mark when noChecks is in effect')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']

        # If no resource ID passed in and a balance ID was passed in, then go find it
        if resourceId in [0, 'first', 'second', 'third', 'last'] and int(lclDCT['balanceId']) > 0:
                # Get the balance in question
                balance = PRIM.getBalanceData('subscriber', externalId, lclDCT['balanceId'], resourceId, lclStartTime, lclDCT['ACTION'], subQueryType)

                # Get the resource ID
                resourceId = int(balance['ResourceId'])

        # May be a formula here...  Need to ensure precision holds for the balance (error if not).
        amount = str(PRIM.processAmountFormula('subscriber', externalId, lclDCT['amount'], lclStartTime, lclDCT['ACTION'], precisionFlag = True, balanceId = lclDCT['balanceId'], queryType=subQueryType))
                        
        # Execute primitive
        retCode = REST_UTIL.subscriberTopupBalance(RESTInst,
                externalId,
                resourceId,
                amount,
                lclDCT['voucher'],
                queryType=subQueryType,
                now=lclStartTime,
                eventPass=eventPass,
                apiEventData=lclDCT['customAttr'][6],
                endTimeExtensionOffset = lclDCT['offerEndTimeExtensionOffset'],
                endTimeExtensionOffsetUnit = lclDCT['offerEndTimeExtensionOffsetUnit'],
                )

        # Query subscriber
        queryValue = externalId
        queryType = subQueryType

        return (queryType, queryValue)
        
#==========================================================
def CmdSub_subscribertransferbalance(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
                
        # Items should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Source object should exist
                if externalId not in TRACK.subscriberTracking:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
                # Target object should exist
                # Check subscriber or subscription
                if lclDCT['modExternalId'] and lclDCT['modExternalId'] not in TRACK.subscriberTracking:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + lclDCT['modExternalId'] + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
                
                # Target Group should exist
                if lclDCT['modGroupId'] and lclDCT['modGroupId'] not in TRACK.groupTracking and not noChecks:
                        print('ERROR: Target Group with ID "' + lclDCT['modGroupId'] + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']

        # If no originating resource ID passed in and a balance ID was passed in, then go find it
        if resourceId in [0, 'first', 'second', 'third', 'last'] and int(lclDCT['balanceId']) > 0:
                # Get the balance in question
                balance = PRIM.getBalanceData('subscriber', externalId, lclDCT['balanceId'], resourceId, lclStartTime, lclDCT['ACTION'], subQueryType)

                # Get the resource ID
                resourceId = int(balance['ResourceId'])
        
        # If no modified balance ID specified and a balance ID was input, then assume it's going to the same balance ID
        if (not lclDCT['modBalanceId']) and lclDCT['balanceId']: modBalanceId = lclDCT['balanceId']
        else: modBalanceId = lclDCT['modBalanceId']
    
        # If no target resource ID passed in and a balance ID was passed in, then go find it
        if lclDCT['modResourceId'] in [0, 'first', 'second', 'third', 'last'] and int(modBalanceId) > 0:
           # Group vs sub target call differs
           if lclDCT['modExternalId']:
                print('Getting ' + REST_UTIL.subUrl + ' ' + str(lclDCT['modExternalId']) + ' balance ' + str(modBalanceId) + ' information')
                # Get the balance in question
                balance = PRIM.getBalanceData('subscriber', lclDCT['modExternalId'], modBalanceId, lclDCT['modResourceId'], lclStartTime, lclDCT['ACTION'], lclDCT['modSubQueryType'])

                # Get the resource ID
                modResourceId = int(balance['ResourceId'])
           else:
                # Get the balance in question
                print('Getting group ' + str(lclDCT['modGroupId']) + ' balance ' + str(modBalanceId) + ' information')
                balance = PRIM.getBalanceData('group', lclDCT['modGroupId'], modBalanceId, lclDCT['modResourceId'], lclStartTime, lclDCT['ACTION'], lclDCT['modGroupQueryType'])

                # Get the resource ID
                modResourceId = int(balance['ResourceId'])
        
        else: modResourceId = lclDCT['modResourceId']

        # Set the target query type
        if lclDCT['modExternalId']: targetQueryType = lclDCT['modSubQueryType']
        else:  targetQueryType = lclDCT['modGroupQueryType']
                
        # May be a formula here...  Need to ensure precision holds for the balance (error if not).
        amount = str(PRIM.processAmountFormula('subscriber', externalId, lclDCT['amount'], lclStartTime, lclDCT['ACTION'], precisionFlag = True, balanceId = lclDCT['balanceId'], queryType=subQueryType))
                        
        # Execute primitive
        retCode = REST_UTIL.subscriberTransferBalance(RESTInst,
                queryValue = externalId,
                balanceResourceId = resourceId,
                amount = str(amount),
                queryType=subQueryType,
                amountIsPct=lclDCT['percentage'],
                targetSubscriberSearchData=lclDCT['modExternalId'],
                targetGroupSearchData=lclDCT['modGroupId'],
                targetQueryType = targetQueryType,
                targetBalanceResourceId = modResourceId,
                sourceIsEventInitiator = lclDCT['sourceIsEventInitiator'],
                creditFloorPolicy=lclDCT['creditFloorPolicy'],
                reason=lclDCT['reason'],
                info=lclDCT['info'],
                now=lclStartTime,
                eventPass=eventPass,
                apiEventData=lclDCT['customAttr'][6],
                )
        
        # Query subscriber
        queryValue = externalId
        queryType = subQueryType

        return (queryType, queryValue)
        
#==========================================================
def CmdSub_deletesubscriber(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
        
        # Check for invalid combination
        if lclDCT['mark'] and noChecks:
                print('ERROR:  can\'t specify a mark when noChecks is in effect')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Subscriber should exist
        if externalId not in TRACK.subscriberTracking and not noChecks:
                print('ERROR: subscriber with ID "' + externalId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']

        # Execute primitive
        retCode = REST_UTIL.deleteSubscriber(RESTInst,
                externalId,
                now=lclStartTime,
                deleteDevices=lclDCT['deleteDevices'],
                queryType=subQueryType,
                eventPass=eventPass,
                apiEventData=lclDCT['customAttr'][6],
                )
        
        # Remove the sub from TF data
        if eventPass: TRACK.updateTrackingData(lclDCT['ACTION'], externalId = externalId, RESTInst=RESTInst)
        
        # Query nothing
        queryValue = None
        queryType = subQueryType

        return (queryType, queryValue)
        
#==========================================================
def CmdSub_querysubscribercursor(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
                
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        if lclDCT['outputFileName'] and lclDCT['outputFileName'].strip():
             # Want to loop here until everything is retrieved
             # Execute primitive
             qcDict = {}
             (retCode, qcDict) = REST_UTIL.querySubscriberCursor(RESTInst,
                externalId,
                eventPass=eventPass,
                queryType=subQueryType,
                querySize = lclDCT['querySize'],
                now=lclStartTime,
                )
                
             # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
             try:
                        respData = str(retCode.printElementBasedXml())
             except:
                        respData = str(retCode)
        
             # Write to where the caller wanted it to go
             prefix = 'querySubscriberCursor Start:\n'
             suffix = 'querySubscriberCursor End:  \n'
             retCode = prefix + str(respData) + suffix
             CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])

             # See if any cursor returned anything
             for cursor in ['AdminGroupCursor', 'ParentGroupCursor']:
              if cursor in qcDict:
                # Get cursor value
                qc = qcDict[cursor]

                # Setup key loop parameters
                if cursor == 'AdminGroupCursor': membershipType = CSVID.membershipTypeMapping['administers']
                else:                            membershipType = CSVID.membershipTypeMapping['groups']

                # Want to loop here until everything is retrieved
                while qc != '0':
                        prefix = 'querySubscriberCursor Start: Processing cursor ' + cursor + ' with qc = ' + str(qc) + '\n'
                        suffix = 'querySubscriberCursor End:   Processing cursor ' + cursor + ' with qc = ' + str(qc) + '\n'
                        # Execute primitive
                        (retCode, qc) = REST_UTIL.querySubscriberMembership(RESTInst,
                                externalId,
                                eventPass=eventPass,
                                queryType=subQueryType,
                                querySize = lclDCT['querySize'],
                                now=lclStartTime,
                                membershipType=membershipType,
                                queryCursor=qc,
                                )
                        
                        # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
                        try:
                                respData = str(retCode.printElementBasedXml())
                        except:
                                respData = str(retCode)
        
                        # Write to where the caller wanted it to go
                        retCode = prefix + str(respData) + suffix
                        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])

        # Query group
        if eventPass: queryValue = externalId
        else:  queryValue = None
        queryType = subQueryType
        saveFunc='saveMDC'
        
        return (queryType, queryValue)
        
#==========================================================
def CmdSub_querysubscribermembership(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
                
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # May be here just to get the normal output file.  Check and skip this query if no storage is desired.
        if lclDCT['outputFileName'] and lclDCT['outputFileName'].strip():
          # Want to loop here until everything is retrieved
          respData = ''
          qc = lclDCT['queryCursor']
          while qc != '0':
             # Execute primitive
             (retCode, qc) = REST_UTIL.querySubscriberMembership(RESTInst,
                externalId,
                eventPass=eventPass,
                queryType=subQueryType,
                querySize = lclDCT['querySize'],
                now=lclStartTime,
                membershipType=lclDCT['membershipType'],
                queryCursor=qc,
                )
                
             # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
             try:
                        respData += str(retCode.printElementBasedXml())
             except:
                        respData += str(retCode)
        
          # Write to where the caller wanted it to go
          CSVQA.processDataToOutput(respData, lclDCT['outputFileName'])

        # Query group
        if eventPass: queryValue = externalId
        else:  queryValue = None
        queryType = subQueryType
        saveFunc='saveMDC'
        
        return (queryType, queryValue)
        
#==========================================================
def CmdSub_subscriberwaitforstate(lclDCT, options, RESTInst, cmdLineInput):
        return  PRIM.waitforstate(lclDCT, options, RESTInst, cmdLineInput, target='subscriber')

#==========================================================
def CmdSub_subscriberqueryeventstore(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
                
        # Nothing to query
        queryType = queryValue = None
        
        # If here to save events, then do nothing here (code after this will query/save)
        if str(lclDCT['saveEvents']) in ['1', 'True']: return (subQueryType, externalId)
        
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Call primitive
        # Force event pass to true, as we want to check the results, not the API call
        lclDCT['eventPass'] = True
        respData = CSVEVENTS.checkEvents('subscriber', subQueryType, externalId, lclDCT, RESTInst, lclStartTime, lclDCT['testName'])
        lclDCT['eventPass'] = eventPass
        
        # Write to where the caller wanted it to go
        if eventPass:
                # Make sure we found something
                if not respData.count("List"):
                        print('ERROR: query did not return any notifications or events')
                        print(respData)
                        sys.exit('Exiting due to errors')
                        
                # If user requested a specific string to check for, then validate that here
                if lclDCT['eventStringToCheckFor'] and not respData.count(lclDCT['eventStringToCheckFor']):
                        print('ERROR: query did not return expected string: "' + lclDCT['eventStringToCheckFor'] + '"')
                        print(respData)
                        sys.exit('Exiting due to errors')
                
                # See if user wants viewEventStore output
                if lclDCT['outputFileName'].lower() == 'view': 
                        # Call viewEventStore.
                        # Different options depending on subQueryType
                        if   subQueryType.lower() == 'externalid':
                                if REST_UTIL.subUrl == 'subscription':
                                        viewOption = '--subxid '
                                else:   viewOption = '-s '
                        elif subQueryType.lower() == 'objectid':
                                if REST_UTIL.subUrl == 'subscription':
                                        viewOption = '--suboid '
                                else:   viewOption = '-o '
                        elif subQueryType.lower() == 'phonenumber': viewOption = '--imsi '
                        elif subQueryType.lower() == 'accessnumber': viewOption = '--msisdn '
                        else:
                                print('NOTE: subQueryType = ' + str(subQueryType) + ', which doesn\'t translate to a viewEventStore input')
                                viewOption = ''
                        if viewOption: viewOption += str(externalId)
                        
                        # See if times were specified
                        if lclDCT['eventTimeLowerBound']:  viewOption += ' --eventTimeLowerBound ' + lclDCT['eventTimeLowerBound']
                        if lclDCT['eventTimeUpperBound']:  viewOption += ' --eventTimeUpperBound ' + lclDCT['eventTimeUpperBound']
                        
                        # Report if we know what to do
                        if viewOption:
                                cmd = 'viewEventStore.py ' + viewOption + ' --outputFile ' + str(lclDCT['outputFileName'])
                                if lclDCT['showGl']: cmd += ' --showGl'
                                print('Running command: ' + cmd)
                                print(QAUTILS.runCmd(cmd) + '\n\n')
                else:   CSVQA.processDataToOutput(respData, lclDCT['outputFileName'])
        
        else:
                # Make sure we didn't found something
                if respData.count("List"):
                        print('ERROR: query returned notifications or events and none were expected')
                        print(respData)
                        sys.exit('Exiting due to errors')
        
        return (queryType, queryValue)

#==========================================================
def CmdSub_subscribercanceloffer(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        offerId = lclDCT['offerId']
        offerEndTime = lclDCT['offerEndTime']
        # End of local variables setup.
                
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Set the offer end time to whatever the local test tool time if it's not specified via the input.
        if offerEndTime == None:
                if lclDCT['futureTime']:  offerEndTime = lclDCT['futureTime']
                else:           offerEndTime = lclStartTime
#       else: lclStartTime = offerEndTime

        print('Cancel Offer time: ' + str(offerEndTime))

        # Can provide subOfferId or offerId for this command.
        # Map to offer ID.
        if (not offerId or offerId.count('0')) and lclDCT['subOfferId']: offerId = lclDCT['subOfferId']

        # If future time, then need to retrieve the taskId of the schedueld task
        if lclDCT['futureTime']:
          # Retrieve future task ID.
          # NOTE:  at the moment only one future task ID is stored per external ID.  Will enhance this in the future.
          taskId = TRACK.subscriberTracking[externalId]['taskId']
          #print 'Retrieved Task: ' + str(taskId)

          # If no task and expecting a failure, then use a dummy task Id (negative testing)
          if not taskId and not eventPass:
                taskId = '0-1-2-3'
                print('Created a dummy value for a taskId, for negative testing: ' + taskId)

        else:
          # No task ID here
          taskId = None

          # If no resource ID passed in, then need to get using the external IDs
          if lclDCT['futureTime']: resourceId = None
          elif resourceId in [0, 'first', 'second', 'third', 'last']:
                resourceId = ''
                for idx in range(len(offerId)):
                        offerDict = PRIM.getOfferData('subscriber', externalId, 0, offerId[idx], lclStartTime, lclDCT['ACTION'], queryType=subQueryType, offerIsCatalog=lclDCT['offerIsCatalog'], resourceId=resourceId)

                        # Get the resource ID
                        resourceId += str(offerDict['ResourceId']) + '@'
#                       print 'Subscriber ' + str(externalId) + ' canceling offer with exernal ID = ' + offerId[idx] + ', resource ID ' + str(offerDict['ResourceId'])
                
                # Remove trailing list character
                resourceId = resourceId[:-1]
        
          # Convert resource ID to a list
          resourceId = resourceId.split('@')
        
        # What to print depends on catalog vs offer...
        if lclDCT['offerIsCatalog']:
                offertype = 'catalog'
        else:
                offertype = 'legacy'
        
        # Debug output
        print(REST_UTIL.subUrl.capitalize() + ' = ' + externalId + ' is cancelling ' + offertype + ' offer(s) with resource IDs ' + str(resourceId) + ' with end time ' + str(offerEndTime))

        # Execute appropriate primitive
        if lclDCT['cancelInfo']:
         retCode,response = REST_UTIL.subscriberCancelOffer(RESTInst,
                externalId,
                queryType=subQueryType,
                resourceId=resourceId,
                eventPass=eventPass,
                executeMode=lclDCT['executeMode'],
                reason=lclDCT['reason'],
                info=lclDCT['info'],
                grantCancelProrationType=lclDCT['grantProrationType'],
                chargeCancelProrationType=lclDCT['chargeProrationType'],
                cancelType=lclDCT['cancelType'],
                cancelInfo=lclDCT['cancelInfo'],
                contractCancelMode=lclDCT['contractCancelMode'],
                debtCancellationMode=lclDCT['debtCancellationMode'],
                eligibilityCheck=lclDCT['eligibilityCheck'],
                now=offerEndTime,
                apiEventData=lclDCT['customAttr'][6],
                )
         
         # Print response
         print(REST_UTIL.subUrl + ' Response: ' + response)
        
        else:
         retCode = REST_UTIL.subscriberCancelOffer(RESTInst,
                externalId,
                queryType=subQueryType,
                resourceId=resourceId,
                eventPass=eventPass,
                executeMode=lclDCT['executeMode'],
                reason=lclDCT['reason'],
                info=lclDCT['info'],
                grantCancelProrationType=lclDCT['grantProrationType'],
                chargeCancelProrationType=lclDCT['chargeProrationType'],
                cancelType=lclDCT['cancelType'],
                cancelInfo=lclDCT['cancelInfo'],
                contractCancelMode=lclDCT['contractCancelMode'],
                debtCancellationMode=lclDCT['debtCancellationMode'],
                eligibilityCheck=lclDCT['eligibilityCheck'],
                now=offerEndTime,
                apiEventData=lclDCT['customAttr'][6],
                )
        
        # Update tracking data
        if eventPass: TRACK.updateTrackingData(lclDCT['ACTION'], externalId = externalId, offerId = offerId, resourceId = resourceId, taskId=taskId)
        
        # Query subscriber
        queryValue = externalId
        queryType = subQueryType

        return (queryType, queryValue)
        
#==========================================================
def CmdSub_subscribercheckpurchaseditemcyclealignment(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        offerId = lclDCT['offerId']
        offerCycleResourceId = lclDCT['offerCycleResourceId']
        # End of local variables setup.
                
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Can provide subOfferId or offerId for this command.
        # Map to offer ID.
        if (not offerId or offerId.count('0')) and lclDCT['subOfferId']: offerId = lclDCT['subOfferId']

        '''
        # If no resource ID passed in, then need to get using the external ID
        if resourceId == 0:
                offerDict = PRIM.getOfferData('subscriber', externalId, resourceId, offerId[0], lclStartTime, lclDCT['ACTION'], queryType=subQueryType, offerIsCatalog=True)

                # Get the resource ID
                resourceId = int(offerDict['ResourceId'])
        '''
        
        # If resource IDs passed in as a non-integer, then need to get its resource ID assuming they're offer external IDs
        for param in ['offerCycleResourceId']:
                value = lclDCT[param]
                
                # See if defined and not an integer and not 0 (so not a resource ID)
                if value and not (value.isdigit() and value != '0'):
                        # Get resource ID data
                        offerDict = PRIM.getOfferData('subscriber', externalId, 0, value, lclStartTime, lclDCT['ACTION'], queryType=subQueryType, offerIsCatalog=True)
                        
                        # Get the resource ID
                        if param == 'offerCycleResourceId': offerCycleResourceId = int(offerDict['ResourceId'])
                        
                        print('Retrieved ' + param + ' = ' + offerDict['ResourceId'])
        
        print('Subscriber ' + str(externalId) + ' is checking purchased item cycle alignment for offer "' + str(offerId) + '", resource ID ' + str(offerCycleResourceId))
        
        # Execute primitive
        response = REST_UTIL.subscriberCheckPurchasedItemCycleAlignment(RESTInst,
                externalId,
                queryType=subQueryType,
                offerResourceId=offerCycleResourceId,
                eventPass=eventPass,
                now=lclStartTime,
                )
        
        print("Response:")
        print(response)
        
        # Query Nothing
        queryValue = None
        queryType = None
        
        return (queryType, queryValue)
        
#==========================================================
def CmdSub_subscribercontractdebtpayment(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        offerId = lclDCT['offerId']
        # End of local variables setup.
                
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']
        
        # If no resource ID passed in, then need to get using the external ID
        if resourceId in [0, 'first', 'second', 'third', 'last']:
                if offerId[0] == None: 
                        print('ERROR: Need to specify an offer')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
                
                offerDict = PRIM.getOfferData('subscriber', externalId, resourceId, offerId[0], lclStartTime, lclDCT['ACTION'], queryType=subQueryType, offerIsCatalog=True, resourceId=resourceId)

                # Get the resource ID
                resourceId = int(offerDict['ResourceId'])
        
        print(REST_UTIL.subUrl.capitalize() + ' ' + str(externalId) + ' is paying debt for offer "' + str(offerId) + '", resource ID ' + str(resourceId))
        
        # Execute primitive
        retCode = REST_UTIL.subscriberContractDebtPayment(RESTInst,
                externalId,
                resourceId,
                str(lclDCT['amount']),
                queryType=subQueryType,
                reason=lclDCT['reason'],
                info=lclDCT['info'],
                now=lclStartTime,
                eventPass=eventPass,
                paymentMethodResourceId=lclDCT['paymentMethodResourceId'],
                paymentGatewayId=lclDCT['paymentGatewayId'],
                chargeMethod=lclDCT['chargeMethod'],
                chargeMethodAttr=lclDCT['chargeMethodAttr'],
                nonce=lclDCT['nonce'],
                apiEventData=lclDCT['customAttr'][6],
                )
        
        # Query subscriber
        queryValue = externalId
        queryType = subQueryType

        return (queryType, queryValue)
        
#==========================================================
def CmdSub_subscribercontractprinciplepayment(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        offerId = lclDCT['offerId']
        # End of local variables setup.
                
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']
        
        # If no resource ID passed in, then need to get using the external ID
        if resourceId in [0, 'first', 'second', 'third', 'last']:
                if offerId[0] == None: 
                        print('ERROR: Need to specify an offer')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
                
                offerDict = PRIM.getOfferData('subscriber', externalId, resourceId, offerId[0], lclStartTime, lclDCT['ACTION'], queryType=subQueryType, offerIsCatalog=True, resourceId=resourceId)

                # Get the resource ID
                resourceId = int(offerDict['ResourceId'])
        
        print(REST_UTIL.subUrl.capitalize() + ' ' + str(externalId) + ' is paying debt for offer "' + str(offerId) + '", resource ID ' + str(resourceId))
        
        # Execute primitive
        retCode = REST_UTIL.subscriberMakeFinanceContractPrincipalPayment(RESTInst,
                externalId,
                resourceId,
                subQueryType,
                lclDCT['isPayoff'],
                str(lclDCT['amount']),
                paymentMethodResourceId=lclDCT['paymentMethodResourceId'],
                paymentGatewayId=lclDCT['paymentGatewayId'],
                chargeMethod=lclDCT['chargeMethod'],
                nonce=lclDCT['nonce'],
                chargeMethodAttr=lclDCT['chargeMethodAttr'],
                reason=lclDCT['reason'],
                info=lclDCT['info'],
                now=lclStartTime,
                eventPass=eventPass,
                apiEventData=lclDCT['customAttr'][6],
                )
        
        # Query subscriber
        queryValue = externalId
        queryType = subQueryType

        return (queryType, queryValue)
        
#==========================================================
def CmdSub_subscriberaddrechargeschedule(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
                
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']
        
        print(REST_UTIL.subUrl.capitalize() + ' ' + str(externalId) + ' is adding a recharge schedule')
        
        # Execute primitive
        retCode = REST_UTIL.subscriberAddRechargeSchedule(RESTInst,
                externalId,
                lclDCT['rechargeTime'],
                subQueryType,
                lclDCT['periodType'],
                lclDCT['periodCoefficient'],
                cycleTimeOfDay=lclDCT['offerCycleOffset'],
                cycleOffset=lclDCT['offerCycleOffset'],
                amount=str(lclDCT['amount']),
                paymentMethodResourceId=lclDCT['paymentMethodResourceId'],
                endTimeExtensionOffsetUnit=lclDCT['endTimeRelativeOffsetUnit'],
                endTimeExtensionOffset=lclDCT['endTimeRelativeOffset'],
                scheduledRechargeNotificationProfileId=lclDCT['elementId'],
                now=lclStartTime,
                eventPass=eventPass,
                executeMode=lclDCT['executeMode'],
                apiEventData=lclDCT['customAttr'][6],
                )
        
        # Query subscriber
        queryValue = externalId
        queryType = subQueryType

        return (queryType, queryValue)
        
#==========================================================
def CmdSub_subscribermodifyrechargeschedule(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
                
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']
        
        print(REST_UTIL.subUrl.capitalize() + ' ' + str(externalId) + ' is modifying a recharge schedule')
        
        # Execute primitive
        retCode = REST_UTIL.subscriberModifyRechargeSchedule(RESTInst,
                externalId,
                lclDCT['rechargeTime'],
                subQueryType,
                lclDCT['periodType'],
                lclDCT['periodCoefficient'],
                cycleTimeOfDay=lclDCT['offerCycleOffset'],
                cycleOffset=lclDCT['offerCycleOffset'],
                amount=str(lclDCT['amount']),
                paymentMethodResourceId=lclDCT['paymentMethodResourceId'],
                endTimeExtensionOffsetUnit=lclDCT['endTimeRelativeOffsetUnit'],
                endTimeExtensionOffset=lclDCT['endTimeRelativeOffset'],
                scheduledRechargeNotificationProfileId=lclDCT['elementId'],
                now=lclStartTime,
                eventPass=eventPass,
                executeMode=lclDCT['executeMode'],
                apiEventData=lclDCT['customAttr'][6],
                )
        
        # Query subscriber
        queryValue = externalId
        queryType = subQueryType

        return (queryType, queryValue)
        
#==========================================================
def CmdSub_subscriberremoverechargeschedule(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
                
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']
        
        print(REST_UTIL.subUrl.capitalize() + ' ' + str(externalId) + ' is removing a recharge schedule')
        
        # Execute primitive
        retCode = REST_UTIL.subscriberRemoveRechargeSchedule(RESTInst,
                externalId,
                subQueryType,
                now=lclStartTime,
                eventPass=eventPass,
                executeMode=lclDCT['executeMode'],
                apiEventData=lclDCT['customAttr'][6],
                )
        
        # Query subscriber
        queryValue = externalId
        queryType = subQueryType

        return (queryType, queryValue)
        
#==========================================================
def CmdSub_subscriberqueryrechargeschedule(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
                
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']
        
        print(REST_UTIL.subUrl.capitalize() + ' ' + str(externalId) + ' is removing a recharge schedule')
        
        # Execute primitive
        retCode = REST_UTIL.subscriberQueryRechargeSchedule(RESTInst,
                externalId,
                subQueryType,
                now=lclStartTime,
                eventPass=eventPass,
                executeMode=lclDCT['executeMode'],
                )
        
        # Print the response
        pprint.pprint(retCode)
        
        # Query Nothing
        queryValue = None
        queryType = None

        return (queryType, queryValue)
        
#==========================================================
def CmdSub_subscriberqueryrecurringrecharge(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
                
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']
        
        print(REST_UTIL.subUrl.capitalize() + ' ' + str(externalId) + ' is querying the recurring recharge')
        
        # Execute primitive
        retCode = REST_UTIL.subscriberQueryRecurringRecharge(RESTInst,
                externalId,
                subQueryType,
                now=lclStartTime,
                eventPass=eventPass,
                executeMode=lclDCT['executeMode'],
                )
        
        # Print the response
        pprint.pprint(retCode)
        
        # Query Nothing
        queryValue = None
        queryType = None

        return (queryType, queryValue)
        
#==========================================================
def CmdSub_subscribersettlepayment(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        offerId = lclDCT['offerId']
        # End of local variables setup.
                
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']
        
        # If no resource ID passed in, then get using constant
        if resourceId == 0:
                # Make sure constant is defined
                try:    resourceId = DATA.constantValue['LastSubscriberPaymentResourceId']
                except: sys.exit('ERROR: ' + lclDCT['ACTION'] + ' called without a resourceId and no payment resource ID has been previous stored via an offer purchase')
        
        print(REST_UTIL.subUrl.capitalize() + ' ' + str(externalId) + ' is setting payment for offer "' + str(offerId) + '", resource ID ' + str(resourceId))
        
        # Execute primitive
        retCode = REST_UTIL.subscriberSettlePayment(RESTInst,
                externalId,
                subQueryType,
                resourceId,
                now=lclStartTime,
                eventPass=eventPass,
                apiEventData=lclDCT['customAttr'][6],
                )
        
        # Query subscriber
        queryValue = externalId
        queryType = subQueryType

        return (queryType, queryValue)
        
#==========================================================
def CmdSub_subscriberqueryaggregation(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
                
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Execute primitive
        retCode = REST_UTIL.querySubscriberAggregation(RESTInst,
                externalId, queryType=subQueryType, eventPass=eventPass)
        
        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])
        
        # Query subscriber
        queryValue = externalId
        queryType = subQueryType
        
        return (queryType, queryValue)
        
#==========================================================
def CmdSub_subscriberquerycatalog(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
                
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Debug output
        print('Catalog query ' + REST_UTIL.subUrl + ' ' + str(externalId) + ' to ' + str(lclDCT['routingType']) + '+' + str(lclDCT['routingValue']))

        # Execute primitive
        respData = REST_UTIL.subscriberQueryCatalog(RESTInst,
                externalId,
                queryType=subQueryType,
                catalogQueryValue=lclDCT['catalogExternalId'],
                catalogQueryType=lclDCT['catalogQueryType'],
                eventPass=eventPass,
                eligibilityFilter=lclDCT['eligibilityCheck'],
                filterName=None,
                )
        
        # Process response if anything came back
        if respData:    outData = PRIM.getCatalogIDs(respData)
        else:           outData = 'None'
        
        # Add query-specific heading
        outData = 'Catalog CIs for ' + REST_UTIL.subUrl + ' ' + str(externalId) + ', Catalog ' + str(lclDCT['catalogExternalId']) + ': ' + outData
                
        # Process data if expecting success
        if eventPass:
                # If supposed to save data to variables then do that here
                if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, REST_UTIL.subUrl.capitalize(), respData)
                
                # If supposed to store output then write to where the caller wanted it to go.  Only if not saving data.
                elif outData: CSVQA.processDataToOutput(outData, lclDCT['outputFileName'])
        
        # Query nothing
        queryValue = None
        queryType = None

        return (queryType, queryValue)
        
#==========================================================
def CmdSub_subscriberqueryeligibleci(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
                
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Debug output
        #print 'Eligibility query ' + REST_UTIL.subUrl + ' ' + str(externalId) + ' to ' + str(lclDCT['routingType']) + '+' + str(lclDCT['routingValue'])

        # Execute primitive
        respData = REST_UTIL.subscriberQueryCatalogItemList(RESTInst,
                externalId,
                queryType=subQueryType,
                eventPass=eventPass,
                eligibilityFilter=lclDCT['eligibilityCheck'],
                )
        
        # Process response if anything came back
        if respData:    outData = PRIM.getCatalogIDs(respData)
        else:           outData = 'None'
        
        # Add query-specific heading
        outData = 'Eligible CIs for ' + REST_UTIL.subUrl + ' ' + str(externalId) + ': ' + outData
                
        # Process data if expecting success
        if eventPass:
                # If supposed to save data to variables then do that here
                if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, REST_UTIL.subUrl.capitalize(), respData)
                
                # If supposed to store output then write to where the caller wanted it to go.  Only if not saving data.
                elif outData: CSVQA.processDataToOutput(outData, lclDCT['outputFileName'])
        
        # Query nothing
        queryValue = None
        queryType = None

        return (queryType, queryValue)
        
#==========================================================
def CmdSub_subscriberactivateoffer(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        subQueryType = lclDCT['subQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        noChecks = lclDCT['noChecks']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
        
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking and not noChecks:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Process resource ID
        if resourceId in [0, 'first', 'second', 'third', 'last']:
                resourceData = ''
                for idx in range(len(offerId)):
                        offerDict = PRIM.getOfferData('subscriber', externalId, 0, lclDCT['offerId'][idx], lclStartTime, lclDCT['ACTION'], queryType=subQueryType, offerIsCatalog=lclDCT['offerIsCatalog'], resourceId=resourceId)

                        # Get the resource ID
                        resourceData += str(offerDict['ResourceId']) + '@'
#                       print('Subscriber ' + str(externalId) + ' canceling offer with exernal ID = ' + lclDCT['offerId'][idx] + ', resource ID ' + str(offerDict['ResourceId']))
                
                # Remove trailing list character
                resourceId = resourceData[:-1]
        
        # Execute primitive
        retCode = REST_UTIL.subscriberActivateOffer(RESTInst, 
                externalId,
                subQueryType,
                resourceId,
                now=lclStartTime,
                eventPass=eventPass,
                apiEventData=lclDCT['customAttr'][6],
                routingType=lclDCT['routingType'],
                routingValue=lclDCT['routingValue'],
                executeMode=lclDCT['executeMode'])
        
        # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
        try:
                respData = str(retCode.printElementBasedXml())
        except:
                respData = str(retCode)
        
        # If supposed to save data to variables then do that here
        if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, REST_UTIL.subUrl.capitalize(), respData)
             
        # if supposed to store output then write to where the caller wanted it to go.  nly if not saving data.
        elif lclDCT['outputFileName'] and lclDCT['outputFileName'].lower() != 'none': CSVQA.processDataToOutput(respData, lclDCT['outputFileName'])

        # Query subscriber
        queryValue = externalId
        queryType = subQueryType

        return (queryType, queryValue)
        
# ***************** Deprecated items *****************************************************

'''
#==========================================================
def CmdSub_subscriberdeletesession(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking:
                        print 'ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting'
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Execute primitive
        #retCode = REST_UTIL.deleteSubscriberSession(RESTInst, externalId, queryType=subQueryType, sessionType=sessionType, eventPass=eventPass, now=None)
        print 'WARNING: subscriberDeleteSession has been deprecated'
        
        # Save nothing; no changes to the object
        queryValue = None
        queryType = None
        lclDCT['saveFunc'] = 'saveMDC'

        return (queryType, queryValue)

#==========================================================
def CmdSub_subscriberaddpaymenttoken(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking:
                        print 'ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting'
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Payment token required
        if not paymentToken:
                print 'ERROR: paymentToken variable not defined.  Exiting'
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Build the name
        name = ''
        if firstName: name += firstName
        if lastName:
                if len(name): name += '.'
                name += lastName
        if not len(name): name = None
        
        # Execute primitive
        #retCode = REST_UTIL.subscriberAddPaymentToken(RESTInst, externalId, paymentToken, isCurrent=isCurrent, name=name, queryType=subQueryType, eventPass=eventPass, now=None)
        print 'WARNING: subscriberAddPaymentToken has been deprecated'

        # Query subscriber
        if eventPass: queryValue = externalId
        else:  queryValue = None
        queryType = subQueryType
        saveFunc='saveMDC'

        return (queryType, queryValue)

#==========================================================
def CmdSub_subscriberremovepaymenttoken(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking:
                        print 'ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting'
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Payment token required
        if not paymentToken and not resourceId:
                print 'ERROR: paymentToken and resourceId variables not defined.  Exiting'
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # If the resourceId is not passed in, then attempt to get it from the payment token
        if not resourceId:
                # Get payment data
                payment = PRIM.getPaymentData('subscriber', externalId, paymentToken, lclStartTime, lclDCT['ACTION'], subQueryType)

                # Get the resource ID
                resourceId = int(payment.find('./ResourceId').text.strip())
                
        # Execute primitive
        #retCode = REST_UTIL.subscriberRemovePaymentToken(RESTInst, externalId, resourceId, queryType=subQueryType, eventPass=eventPass, now=None)
        print 'WARNING: subscriberRemovePaymentToken has been deprecated'

        # Query subscriber
        if eventPass: queryValue = externalId
        else:  queryValue = None
        queryType = subQueryType
        saveFunc='saveMDC'

        return (queryType, queryValue)

#==========================================================
def CmdSub_subscriberquerypayment(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        
        # Item should exist.  Skip if in a multi-request.
        if not noChecks and subQueryType != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking:
                        print 'ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting'
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Execute primitive
        #retCode = REST_UTIL.subscriberQueryPayment(RESTInst, externalId, queryType=subQueryType, eventPass=eventPass, now=None)
        print 'WARNING: subscriberQueryPaymentToken has been deprecated'
        
        # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
        try:
                respData = str(retCode.printElementBasedXml())
        except:
                respData = str(retCode)
        
        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(respData, outputFileName)
        
        # Query subscriber
        if eventPass: queryValue = externalId
        else:  queryValue = None
        queryType = subQueryType
        saveFunc='saveMDC'

        return (queryType, queryValue)

#==========================================================
def CmdSub_subscriberpayment(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.

        # Subscriber should exist
        if externalId not in TRACK.subscriberTracking and not noChecks:
                print 'ERROR: subscriber with ID "' + externalId + '" is not defined.  Exiting'
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Amount required
        if not amount:
                print 'ERROR: amount variable not defined.  Exiting'
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Execute primitive
        retCode = REST_UTIL.subscriberPayment(RESTInst, externalId, amount, queryType=subQueryType, eventPass=eventPass, now=None)

        # Query subscriber
        if eventPass: queryValue = externalId
        else:  queryValue = None
        queryType = subQueryType
        saveFunc='saveMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdSub_subscribercurrencytopup(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.

        # Subscriber should exist
        if externalId not in TRACK.subscriberTracking and not noChecks:
                print 'ERROR: subscriber with ID "' + externalId + '" is not defined.  Exiting'
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Amount required
        if not amount:
                print 'ERROR: amount variable not defined.  Exiting'
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Execute primitive
        retCode = REST_UTIL.subscriberCurrencyTopup(RESTInst, externalId, amount, queryType=subQueryType, eventPass=eventPass, now=None)

        # Query subscriber
        if eventPass: queryValue = externalId
        else:  queryValue = None
        queryType = subQueryType
        saveFunc='saveMDC'

        return (queryType, queryValue)

'''
