#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:36:04
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:36:04
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:36:03

#===============================================================================
#
# Copyright 2010,2011,2012,2013,2014,2015,2016 Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

from __future__ import print_function
# from builtins import str
# from builtins import str
import copy, sys, pprint
import sigtran_test as SIGTRAN_UTIL
import csv_prim as PRIM
import csv_data as DATA
import qa_utils

# Define CCF parameter information
# ** Add CCF parameters here (taken from mtx_config.properties file)
parameters = []
parameters.append(('scenario', 'store', 'string', 'TestCall'))
parameters.append(('ccfNodeType', 'store', 'string', 'Client'))
parameters.append(('ccfPointCode', 'store', 'string', '401'))

# Camel
parameters.append(('camel_version', 'store', 'string', '2'))

# *** Adding all CAMEL items automatically as TF parameters iff file mtx_config.properties is found ***
# Command is: grep = mtx_config.properties  | cut -f2 -d'#' | cut -f1 -d'=' | grep -v ".tp_" | grep -v "camel.version" | sort -u | tr "." "_" | while read line; do echo "parameters.append(('$line', 'store', 'string', None))"; done
# NOTE: some parameters don't work as defined, e.g. map_hlr_segmentSriV2+Res.  Will need to handle them specially if needed.  Also, the parameters with "_" in their names won't work as
# that's the character I used to translate "." to (so return when sending the message).  Only a few of these and will handle them special should they be needed...
parameters.append(('alwaysLog', 'store', 'string', None))
parameters.append(('controlPort', 'store', 'string', None))
parameters.append(('correlation_etcAddressSuffixLength', 'store', 'string', None))
parameters.append(('defaultMaxConcurrentCalls', 'store', 'string', None))
parameters.append(('display_headerFreqInSecs', 'store', 'string', None))
parameters.append(('hlr_ati_privateExtension_extId', 'store', 'string', None))
parameters.append(('hlr_ati_privateExtension_extType', 'store', 'string', None))
parameters.append(('hlr_ati_subInfo_privateExtension_extId', 'store', 'string', None))
parameters.append(('hlr_ati_subInfo_privateExtension_extType', 'store', 'string', None))
parameters.append(('hlr_basicServiceCode', 'store', 'string', None))
parameters.append(('hlr_camel_oCsi_1_defaultCallHandlingRelease', 'store', 'string', None))
parameters.append(('hlr_camel_oCsi_1_scfAddress', 'store', 'string', None))
parameters.append(('hlr_camel_oCsi_1_scfAddress_noa', 'store', 'string', None))
parameters.append(('hlr_camel_oCsi_1_serviceKey', 'store', 'string', None))
parameters.append(('hlr_camel_oCsi_1_tdp', 'store', 'string', None))
parameters.append(('hlr_camel_oCsi_2_tdp', 'store', 'string', None))
parameters.append(('hlr_camel_oCsi_active', 'store', 'string', None))
parameters.append(('hlr_camel_oCsi_camelCapabilityHandling', 'store', 'string', None))
parameters.append(('hlr_camel_oCsi_notificationToCSE', 'store', 'string', None))
parameters.append(('hlr_camel_offeredCamel4_dCsi', 'store', 'string', None))
parameters.append(('hlr_camel_offeredCamel4_mgCsi', 'store', 'string', None))
parameters.append(('hlr_camel_offeredCamel4_mtSMSCsi', 'store', 'string', None))
parameters.append(('hlr_camel_offeredCamel4_oCsi', 'store', 'string', None))
parameters.append(('hlr_camel_offeredCamel4_tCsi', 'store', 'string', None))
parameters.append(('hlr_camel_offeredCamel4_vtCsi', 'store', 'string', None))
parameters.append(('hlr_camel_offeredCamel4s_psiEnhancements', 'store', 'string', None))
parameters.append(('hlr_camel_tCsi_1_defaultCallHandlingRelease', 'store', 'string', None))
parameters.append(('hlr_camel_tCsi_1_scfAddress', 'store', 'string', None))
parameters.append(('hlr_camel_tCsi_1_scfAddress_noa', 'store', 'string', None))
parameters.append(('hlr_camel_tCsi_1_serviceKey', 'store', 'string', None))
parameters.append(('hlr_camel_tCsi_1_tdp', 'store', 'string', None))
parameters.append(('hlr_camel_tCsi_2_tdp', 'store', 'string', None))
parameters.append(('hlr_camel_tCsi_active', 'store', 'string', None))
parameters.append(('hlr_camel_tCsi_camelCapabilityHandling', 'store', 'string', None))
parameters.append(('hlr_camel_tCsi_notificationToCSE', 'store', 'string', None))
parameters.append(('hlr_ccbs_ccbsPossible', 'store', 'string', None))
parameters.append(('hlr_ccbs_keepCCBSCallIndicator', 'store', 'string', None))
parameters.append(('hlr_cugInterlock', 'store', 'string', None))
parameters.append(('hlr_cugOutgoingAccess', 'store', 'string', None))
parameters.append(('hlr_cugSubscriptionFlag', 'store', 'string', None))
parameters.append(('hlr_forwardingData_ftn', 'store', 'string', None))
parameters.append(('hlr_forwardingData_ftn_noa', 'store', 'string', None))
parameters.append(('hlr_forwardingData_notificationToCallingParty', 'store', 'string', None))
parameters.append(('hlr_forwardingData_notificationToForwardingParty', 'store', 'string', None))
parameters.append(('hlr_forwardingData_reason', 'store', 'string', None))
parameters.append(('hlr_forwardingData_redirectingPresentation', 'store', 'string', None))
parameters.append(('hlr_forwardingData_subAddress', 'store', 'string', None))
parameters.append(('hlr_forwardingInterrogationRequired', 'store', 'string', None))
parameters.append(('hlr_gsmBearerCapability_protocolId', 'store', 'string', None))
parameters.append(('hlr_gsmBearerCapability_signalInfo', 'store', 'string', None))
parameters.append(('hlr_imei', 'store', 'string', None))
parameters.append(('hlr_istAlertTimer', 'store', 'string', None))
parameters.append(('hlr_locationInfo_age', 'store', 'string', None))
parameters.append(('hlr_locationInfo_ci', 'store', 'string', None))
parameters.append(('hlr_locationInfo_currentLocationRetrieved', 'store', 'string', None))
parameters.append(('hlr_locationInfo_lac', 'store', 'string', None))
parameters.append(('hlr_locationInfo_lat', 'store', 'string', None))
parameters.append(('hlr_locationInfo_long', 'store', 'string', None))
parameters.append(('hlr_locationInfo_lsaIdentity', 'store', 'string', None))
parameters.append(('hlr_locationInfo_mcc', 'store', 'string', None))
parameters.append(('hlr_locationInfo_mnc', 'store', 'string', None))
parameters.append(('hlr_locationInfo_raIdentity', 'store', 'string', None))
parameters.append(('hlr_locationInfo_rac', 'store', 'string', None))
parameters.append(('hlr_locationInfo_saiPresent', 'store', 'string', None))
parameters.append(('hlr_locationInfo_sgsnNumber', 'store', 'string', None))
parameters.append(('hlr_locationInfo_uncert', 'store', 'string', None))
parameters.append(('hlr_locationInfo_vlrNumber', 'store', 'string', None))
parameters.append(('hlr_mnpInfo_imsi', 'store', 'string', None))
parameters.append(('hlr_mnpInfo_msisdn', 'store', 'string', None))
parameters.append(('hlr_mnpInfo_msisdn_noa', 'store', 'string', None))
parameters.append(('hlr_mnpInfo_routingNumber', 'store', 'string', None))
parameters.append(('hlr_mnpInfo_routingNumber_noa', 'store', 'string', None))
parameters.append(('hlr_msClassmark', 'store', 'string', None))
parameters.append(('hlr_msNetworkCapability', 'store', 'string', None))
parameters.append(('hlr_msRadioAccessCapability', 'store', 'string', None))
parameters.append(('hlr_msrn', 'store', 'string', None))
parameters.append(('hlr_msrn_noa', 'store', 'string', None))
parameters.append(('hlr_naeaPreferredCIC', 'store', 'string', None))
parameters.append(('hlr_numberPortabilityStatus', 'store', 'string', None))
parameters.append(('hlr_psSubscriberState', 'store', 'string', None))
parameters.append(('hlr_psSubscriberState_reason', 'store', 'string', None))
parameters.append(('hlr_releaseResourcesSupported', 'store', 'string', None))
parameters.append(('hlr_scudif_allowedServices_suppressCCBS', 'store', 'string', None))
parameters.append(('hlr_scudif_allowedServices_suppressCUG', 'store', 'string', None))
parameters.append(('hlr_scudif_basicServiceCode', 'store', 'string', None))
parameters.append(('hlr_scudif_forwardingData_ftn', 'store', 'string', None))
parameters.append(('hlr_scudif_forwardingData_ftn_noa', 'store', 'string', None))
parameters.append(('hlr_scudif_forwardingData_notificationToCallingParty', 'store', 'string', None))
parameters.append(('hlr_scudif_forwardingData_notificationToForwardingParty', 'store', 'string', None))
parameters.append(('hlr_scudif_forwardingData_reason', 'store', 'string', None))
parameters.append(('hlr_scudif_forwardingData_redirectingPresentation', 'store', 'string', None))
parameters.append(('hlr_scudif_forwardingData_subAddress', 'store', 'string', None))
parameters.append(('hlr_scudif_msrn', 'store', 'string', None))
parameters.append(('hlr_scudif_msrn_noa', 'store', 'string', None))
parameters.append(('hlr_scudif_ssList', 'store', 'string', None))
parameters.append(('hlr_scudif_unavailabilityCause', 'store', 'string', None))
parameters.append(('hlr_ssList', 'store', 'string', None))
parameters.append(('hlr_subscriberState', 'store', 'string', None))
parameters.append(('hlr_subscriberState_reason', 'store', 'string', None))
parameters.append(('hlr_supportedCamelPhases', 'store', 'string', None))
parameters.append(('hlr_vmscAddress', 'store', 'string', None))
parameters.append(('hlr_vmscAddress_noa', 'store', 'string', None))
parameters.append(('hlr2_ati_privateExtension_extId', 'store', 'string', None))
parameters.append(('hlr2_ati_privateExtension_extType', 'store', 'string', None))
parameters.append(('hlr2_ati_subInfo_privateExtension_extId', 'store', 'string', None))
parameters.append(('hlr2_ati_subInfo_privateExtension_extType', 'store', 'string', None))
parameters.append(('hlr2_basicServiceCode', 'store', 'string', None))
parameters.append(('hlr2_camel_oCsi_1_defaultCallHandlingRelease', 'store', 'string', None))
parameters.append(('hlr2_camel_oCsi_1_scfAddress', 'store', 'string', None))
parameters.append(('hlr2_camel_oCsi_1_scfAddress_noa', 'store', 'string', None))
parameters.append(('hlr2_camel_oCsi_1_serviceKey', 'store', 'string', None))
parameters.append(('hlr2_camel_oCsi_1_tdp', 'store', 'string', None))
parameters.append(('hlr2_camel_oCsi_2_tdp', 'store', 'string', None))
parameters.append(('hlr2_camel_oCsi_active', 'store', 'string', None))
parameters.append(('hlr2_camel_oCsi_camelCapabilityHandling', 'store', 'string', None))
parameters.append(('hlr2_camel_oCsi_notificationToCSE', 'store', 'string', None))
parameters.append(('hlr2_camel_offeredCamel4_dCsi', 'store', 'string', None))
parameters.append(('hlr2_camel_offeredCamel4_mgCsi', 'store', 'string', None))
parameters.append(('hlr2_camel_offeredCamel4_mtSMSCsi', 'store', 'string', None))
parameters.append(('hlr2_camel_offeredCamel4_oCsi', 'store', 'string', None))
parameters.append(('hlr2_camel_offeredCamel4_tCsi', 'store', 'string', None))
parameters.append(('hlr2_camel_offeredCamel4_vtCsi', 'store', 'string', None))
parameters.append(('hlr2_camel_offeredCamel4s_psiEnhancements', 'store', 'string', None))
parameters.append(('hlr2_camel_tCsi_1_defaultCallHandlingRelease', 'store', 'string', None))
parameters.append(('hlr2_camel_tCsi_1_scfAddress', 'store', 'string', None))
parameters.append(('hlr2_camel_tCsi_1_scfAddress_noa', 'store', 'string', None))
parameters.append(('hlr2_camel_tCsi_1_serviceKey', 'store', 'string', None))
parameters.append(('hlr2_camel_tCsi_1_tdp', 'store', 'string', None))
parameters.append(('hlr2_camel_tCsi_2_tdp', 'store', 'string', None))
parameters.append(('hlr2_camel_tCsi_active', 'store', 'string', None))
parameters.append(('hlr2_camel_tCsi_camelCapabilityHandling', 'store', 'string', None))
parameters.append(('hlr2_camel_tCsi_notificationToCSE', 'store', 'string', None))
parameters.append(('hlr2_ccbs_ccbsPossible', 'store', 'string', None))
parameters.append(('hlr2_ccbs_keepCCBSCallIndicator', 'store', 'string', None))
parameters.append(('hlr2_cugInterlock', 'store', 'string', None))
parameters.append(('hlr2_cugOutgoingAccess', 'store', 'string', None))
parameters.append(('hlr2_cugSubscriptionFlag', 'store', 'string', None))
parameters.append(('hlr2_forwardingData_ftn', 'store', 'string', None))
parameters.append(('hlr2_forwardingData_ftn_noa', 'store', 'string', None))
parameters.append(('hlr2_forwardingData_notificationToCallingParty', 'store', 'string', None))
parameters.append(('hlr2_forwardingData_notificationToForwardingParty', 'store', 'string', None))
parameters.append(('hlr2_forwardingData_reason', 'store', 'string', None))
parameters.append(('hlr2_forwardingData_redirectingPresentation', 'store', 'string', None))
parameters.append(('hlr2_forwardingData_subAddress', 'store', 'string', None))
parameters.append(('hlr2_forwardingInterrogationRequired', 'store', 'string', None))
parameters.append(('hlr2_gsmBearerCapability_protocolId', 'store', 'string', None))
parameters.append(('hlr2_gsmBearerCapability_signalInfo', 'store', 'string', None))
parameters.append(('hlr2_imei', 'store', 'string', None))
parameters.append(('hlr2_istAlertTimer', 'store', 'string', None))
parameters.append(('hlr2_locationInfo_age', 'store', 'string', None))
parameters.append(('hlr2_locationInfo_ci', 'store', 'string', None))
parameters.append(('hlr2_locationInfo_currentLocationRetrieved', 'store', 'string', None))
parameters.append(('hlr2_locationInfo_lac', 'store', 'string', None))
parameters.append(('hlr2_locationInfo_lat', 'store', 'string', None))
parameters.append(('hlr2_locationInfo_long', 'store', 'string', None))
parameters.append(('hlr2_locationInfo_lsaIdentity', 'store', 'string', None))
parameters.append(('hlr2_locationInfo_mcc', 'store', 'string', None))
parameters.append(('hlr2_locationInfo_mnc', 'store', 'string', None))
parameters.append(('hlr2_locationInfo_raIdentity', 'store', 'string', None))
parameters.append(('hlr2_locationInfo_rac', 'store', 'string', None))
parameters.append(('hlr2_locationInfo_saiPresent', 'store', 'string', None))
parameters.append(('hlr2_locationInfo_sgsnNumber', 'store', 'string', None))
parameters.append(('hlr2_locationInfo_uncert', 'store', 'string', None))
parameters.append(('hlr2_locationInfo_vlrNumber', 'store', 'string', None))
parameters.append(('hlr2_mnpInfo_imsi', 'store', 'string', None))
parameters.append(('hlr2_mnpInfo_msisdn', 'store', 'string', None))
parameters.append(('hlr2_mnpInfo_msisdn_noa', 'store', 'string', None))
parameters.append(('hlr2_mnpInfo_routingNumber', 'store', 'string', None))
parameters.append(('hlr2_mnpInfo_routingNumber_noa', 'store', 'string', None))
parameters.append(('hlr2_msClassmark', 'store', 'string', None))
parameters.append(('hlr2_msNetworkCapability', 'store', 'string', None))
parameters.append(('hlr2_msRadioAccessCapability', 'store', 'string', None))
parameters.append(('hlr2_msrn', 'store', 'string', None))
parameters.append(('hlr2_msrn_noa', 'store', 'string', None))
parameters.append(('hlr2_naeaPreferredCIC', 'store', 'string', None))
parameters.append(('hlr2_numberPortabilityStatus', 'store', 'string', None))
parameters.append(('hlr2_psSubscriberState', 'store', 'string', None))
parameters.append(('hlr2_psSubscriberState_reason', 'store', 'string', None))
parameters.append(('hlr2_releaseResourcesSupported', 'store', 'string', None))
parameters.append(('hlr2_scudif_allowedServices_suppressCCBS', 'store', 'string', None))
parameters.append(('hlr2_scudif_allowedServices_suppressCUG', 'store', 'string', None))
parameters.append(('hlr2_scudif_basicServiceCode', 'store', 'string', None))
parameters.append(('hlr2_scudif_forwardingData_ftn', 'store', 'string', None))
parameters.append(('hlr2_scudif_forwardingData_ftn_noa', 'store', 'string', None))
parameters.append(('hlr2_scudif_forwardingData_notificationToCallingParty', 'store', 'string', None))
parameters.append(('hlr2_scudif_forwardingData_notificationToForwardingParty', 'store', 'string', None))
parameters.append(('hlr2_scudif_forwardingData_reason', 'store', 'string', None))
parameters.append(('hlr2_scudif_forwardingData_redirectingPresentation', 'store', 'string', None))
parameters.append(('hlr2_scudif_forwardingData_subAddress', 'store', 'string', None))
parameters.append(('hlr2_scudif_msrn', 'store', 'string', None))
parameters.append(('hlr2_scudif_msrn_noa', 'store', 'string', None))
parameters.append(('hlr2_scudif_ssList', 'store', 'string', None))
parameters.append(('hlr2_scudif_unavailabilityCause', 'store', 'string', None))
parameters.append(('hlr2_ssList', 'store', 'string', None))
parameters.append(('hlr2_subscriberState', 'store', 'string', None))
parameters.append(('hlr2_subscriberState_reason', 'store', 'string', None))
parameters.append(('hlr2_supportedCamelPhases', 'store', 'string', None))
parameters.append(('hlr2_vmscAddress', 'store', 'string', None))
parameters.append(('hlr2_vmscAddress_noa', 'store', 'string', None))
parameters.append(('idp_additionalCallingPartyNumber', 'store', 'string', None))
parameters.append(('idp_additionalCallingPartyNumber_noa', 'store', 'string', None))
parameters.append(('idp_additionalParams', 'store', 'string', None))
parameters.append(('idp_callForwardingSSPending', 'store', 'string', None))
parameters.append(('idp_calledPartyBCDNumber', 'store', 'string', None))
parameters.append(('idp_calledPartyBCDNumber_ton', 'store', 'string', None))
parameters.append(('idp_calledPartyNumber', 'store', 'string', None))
parameters.append(('idp_calledPartyNumber_noa', 'store', 'string', None))
parameters.append(('idp_callingPartyNumber', 'store', 'string', None))
parameters.append(('idp_callingPartyNumber_noa', 'store', 'string', None))
parameters.append(('idp_callingPartysCategory', 'store', 'string', None))
parameters.append(('idp_cause', 'store', 'string', None))
parameters.append(('idp_cause_location', 'store', 'string', None))
parameters.append(('idp_classMark2', 'store', 'string', None))
parameters.append(('idp_eventType', 'store', 'string', None))
parameters.append(('idp_extBasicServiceCode', 'store', 'string', None))
parameters.append(('idp_forwardingDestinationNumber', 'store', 'string', None))
parameters.append(('idp_forwardingDestinationNumber_noa', 'store', 'string', None))
parameters.append(('idp_gmscAddress', 'store', 'string', None))
parameters.append(('idp_highLayerCharacteristicsID', 'store', 'string', None))
parameters.append(('idp_imei', 'store', 'string', None))
parameters.append(('idp_informationTransferCapability', 'store', 'string', None))
parameters.append(('idp_locationInfo_age', 'store', 'string', None))
parameters.append(('idp_locationInfo_ci', 'store', 'string', None))
parameters.append(('idp_locationInfo_lac', 'store', 'string', None))
parameters.append(('idp_locationInfo_lat', 'store', 'string', None))
parameters.append(('idp_locationInfo_long', 'store', 'string', None))
parameters.append(('idp_locationInfo_mcc', 'store', 'string', None))
parameters.append(('idp_locationInfo_mnc', 'store', 'string', None))
parameters.append(('idp_locationInfo_uncert', 'store', 'string', None))
parameters.append(('idp_locationInfo_vlrNumber', 'store', 'string', None))
parameters.append(('idp_locationNumber', 'store', 'string', None))
parameters.append(('idp_locationNumber_noa', 'store', 'string', None))
parameters.append(('idp_mscAddress', 'store', 'string', None))
parameters.append(('idp_offeredCamel4Functionalities', 'store', 'string', None))
parameters.append(('idp_originalCalledPartyID', 'store', 'string', None))
parameters.append(('idp_originalCalledPartyID_noa', 'store', 'string', None))
parameters.append(('idp_redirectingPartyID', 'store', 'string', None))
parameters.append(('idp_redirectingPartyID_noa', 'store', 'string', None))
parameters.append(('idp_redirectionCounter', 'store', 'string', None))
parameters.append(('idp_redirectionReason', 'store', 'string', None))
parameters.append(('idp_serviceKey', 'store', 'string', None))
parameters.append(('idp_subscriberState', 'store', 'string', None))
parameters.append(('idp_subscriberState_reason', 'store', 'string', None))
parameters.append(('idp_supportedCamelPhases', 'store', 'string', None))
parameters.append(('idp_timeAndTimeZone_day', 'store', 'string', None))
parameters.append(('idp_timeAndTimeZone_hour', 'store', 'string', None))
parameters.append(('idp_timeAndTimeZone_minute', 'store', 'string', None))
parameters.append(('idp_timeAndTimeZone_month', 'store', 'string', None))
parameters.append(('idp_timeAndTimeZone_timeZone', 'store', 'string', None))
parameters.append(('idp_timeAndTimeZone_year', 'store', 'string', None))
parameters.append(('idp_timeAndTimeZone_second', 'store', 'string', None))
parameters.append(('idpsms_calledPartyNumber', 'store', 'string', None))
parameters.append(('idpsms_calledPartyNumber_noa', 'store', 'string', None))
parameters.append(('idpsms_callingPartyNumber', 'store', 'string', None))
parameters.append(('idpsms_callingPartyNumber_noa', 'store', 'string', None))
parameters.append(('idpsms_destinationSubscriberNumber', 'store', 'string', None))
parameters.append(('idpsms_destinationSubscriberNumber_ton', 'store', 'string', None))
parameters.append(('idpsms_eventTypeSms', 'store', 'string', None))
parameters.append(('idpsms_imei', 'store', 'string', None))
parameters.append(('idpsms_locationInfo_age', 'store', 'string', None))
parameters.append(('idpsms_locationInfo_ci', 'store', 'string', None))
parameters.append(('idpsms_locationInfo_lac', 'store', 'string', None))
parameters.append(('idpsms_locationInfo_lat', 'store', 'string', None))
parameters.append(('idpsms_locationInfo_long', 'store', 'string', None))
parameters.append(('idpsms_locationInfo_mcc', 'store', 'string', None))
parameters.append(('idpsms_locationInfo_mnc', 'store', 'string', None))
parameters.append(('idpsms_locationInfo_sgsnNumber', 'store', 'string', None))
parameters.append(('idpsms_locationInfo_uncert', 'store', 'string', None))
parameters.append(('idpsms_locationInfo_vlrNumber', 'store', 'string', None))
parameters.append(('idpsms_mscAddress', 'store', 'string', None))
parameters.append(('idpsms_redirectionCounter', 'store', 'string', None))
parameters.append(('idpsms_serviceKey', 'store', 'string', None))
parameters.append(('idpsms_sgsnNumber', 'store', 'string', None))
parameters.append(('idpsms_smscAddress', 'store', 'string', None))
#parameters.append(('idpsms_tp_protoId', 'store', 'string', None))
#parameters.append(('idpsms_tp_dataCodingScheme', 'store', 'string', None))
parameters.append(('imsiRange_size', 'store', 'string', None))
parameters.append(('imsiRange_start', 'store', 'string', None))
parameters.append(('initialResponseTimeoutInSecs', 'store', 'string', None))
parameters.append(('latencyIgnoreAborts', 'store', 'string', None))
parameters.append(('logTcapPrimitives', 'store', 'string', None))
parameters.append(('map_hlr', 'store', 'string', None))
parameters.append(('map_hlr_errorCode', 'store', 'string', None))
#parameters.append(('map_hlr_segmentSriV2+Res', 'store', 'string', None))
parameters.append(('map_msisdn', 'store', 'string', None))
parameters.append(('map_msisdn_noa', 'store', 'string', None))
parameters.append(('scenario_Connect_callHoldInSecs', 'store', 'string', None))
parameters.append(('scenario_Connect_expectActivityTest', 'store', 'string', None))
parameters.append(('scenario_Continue_callHoldInSecs', 'store', 'string', None))
parameters.append(('scenario_Continue_expectActivityTest', 'store', 'string', None))
parameters.append(('scenario_MultiAC_acPeriodOverrideInSecs', 'store', 'string', None))
parameters.append(('scenario_MultiAC_callHoldInSecs', 'store', 'string', None))
parameters.append(('scenario_MultiAC_expectCIR', 'store', 'string', None))
parameters.append(('scenario_MultiAC_expectFCI', 'store', 'string', None))
parameters.append(('scenario_MultiAC_expectSCI', 'store', 'string', None))
parameters.append(('scenario_PreCallAnnMultiAC_alwaysUseDefaultDuration', 'store', 'string', None))
parameters.append(('scenario_PreCallAnnMultiAC_annDurationInSecs', 'store', 'string', None))
parameters.append(('scenario_PreCallAnnMultiAC_annFailure', 'store', 'string', None))
parameters.append(('scenario_PreCallAnnMultiAC_requireAnnouncement', 'store', 'string', None))
parameters.append(('scenario_ProcessUssd_dcs_charSet', 'store', 'string', None))
parameters.append(('scenario_ProcessUssd_dcs_dcg', 'store', 'string', None))
parameters.append(('scenario_ProcessUssd_mapOpen_destEntityMsisdn', 'store', 'string', None))
parameters.append(('scenario_ProcessUssd_mapOpen_destEntityMsisdn_noa', 'store', 'string', None))
parameters.append(('scenario_ProcessUssd_mapOpen_origEntityAddr', 'store', 'string', None))
parameters.append(('scenario_ProcessUssd_mapOpen_origEntityAddr_noa', 'store', 'string', None))
parameters.append(('scenario_ProcessUssd_mapOpen_segment', 'store', 'string', None))
parameters.append(('scenario_ProcessUssd_mapVersion', 'store', 'string', None))
parameters.append(('scenario_ProcessUssd_msisdn', 'store', 'string', None))
parameters.append(('scenario_ProcessUssd_msisdn_noa', 'store', 'string', None))
parameters.append(('scenario_ProcessUssd_ussd_dcs_iso639LangId', 'store', 'string', None))
parameters.append(('scenario_ProcessUssd_ussd_dcs_msgClass', 'store', 'string', None))
parameters.append(('scenario_ProcessUssd_ussd_dcs_natLang', 'store', 'string', None))
parameters.append(('scenario_ProcessUssd_ussd_gsm8Charset', 'store', 'string', None))
parameters.append(('scenario_ProcessUssd_ussd_string', 'store', 'string', None))
parameters.append(('scenario_ProcessUssd_waitForNotify', 'store', 'string', None))
parameters.append(('scenario_SimpleAC_acPeriodOverrideInSecs', 'store', 'string', None))
parameters.append(('scenario_SimpleAC_callChargeInSecs', 'store', 'string', None))
parameters.append(('scenario_SimpleAC_expectCIR', 'store', 'string', None))
parameters.append(('scenario_SimpleAC_hangUpLeg', 'store', 'string', None))
parameters.append(('scenario_SmsConfirm_delayInSecs', 'store', 'string', None))
parameters.append(('scenario_SmsConfirm_smsFailureCause', 'store', 'string', None))
parameters.append(('scenario_TestCall_acPeriodOverrideInSecs', 'store', 'string', None))
parameters.append(('scenario_TestCall_alwaysUseDefaultDuration', 'store', 'string', None))
parameters.append(('scenario_TestCall_annDurationInSecs', 'store', 'string', None))
parameters.append(('scenario_TestCall_annFailure', 'store', 'string', None))
parameters.append(('scenario_TestCall_answerCI', 'store', 'string', None))
parameters.append(('scenario_TestCall_answerCall', 'store', 'string', None))
parameters.append(('scenario_TestCall_busy', 'store', 'string', None))
parameters.append(('scenario_TestCall_callHoldInSecs', 'store', 'string', None))
parameters.append(('scenario_TestCall_failToRespond', 'store', 'string', None))
parameters.append(('scenario_TestCall_hangupParty', 'store', 'string', None))
parameters.append(('scenario_TestCall_routeSelectFail', 'store', 'string', None))
parameters.append(('scenario_TestCall_sendOpsSeparately', 'store', 'string', None))
parameters.append(('scenario_TestSimulator_abortPC', 'store', 'string', None))
parameters.append(('scenario_TestSimulator_delayMS', 'store', 'string', None))
parameters.append(('scenario_TestSimulator_delayPC', 'store', 'string', None))
parameters.append(('scenario_TestSimulator_failPC', 'store', 'string', None))
parameters.append(('scenario_TestSimulator_timeoutPC', 'store', 'string', None))
parameters.append(('scenario_TestSms_delayInSecs', 'store', 'string', None))
parameters.append(('scenario_TestSms_smsFailureCause', 'store', 'string', None))
parameters.append(('sigtran_connectDelayInMS', 'store', 'string', None))
parameters.append(('sigtran_delayAfterASActiveInSecs', 'store', 'string', None))
parameters.append(('sigtran_exitOnASLoss', 'store', 'string', None))
parameters.append(('sigtran_pauseOnASLoss', 'store', 'string', None))
parameters.append(('sigtran_waitForASActiveInSecs', 'store', 'string', None))
parameters.append(('simulator_correlation_size', 'store', 'string', None))
parameters.append(('simulator_correlation_useCorrelationIdField', 'store', 'string', None))
parameters.append(('simulator_scenario_activityTestInSecs', 'store', 'string', None))
parameters.append(('simulator_scenario_applyChargesPerCall', 'store', 'string', None))
parameters.append(('simulator_scenario_armAnswerAsInterrupt', 'store', 'string', None))
parameters.append(('simulator_scenario_armDisconnectLeg2AsInterrupt', 'store', 'string', None))
parameters.append(('simulator_scenario_dra', 'store', 'string', None))
parameters.append(('simulator_scenario_hlr_ati_currentLocation', 'store', 'string', None))
parameters.append(('simulator_scenario_hlr_ati_imei', 'store', 'string', None))
parameters.append(('simulator_scenario_hlr_ati_locationInformation', 'store', 'string', None))
parameters.append(('simulator_scenario_hlr_ati_mnpRequestedInfo', 'store', 'string', None))
parameters.append(('simulator_scenario_hlr_ati_msClassmark', 'store', 'string', None))
parameters.append(('simulator_scenario_hlr_ati_subscriberState', 'store', 'string', None))
parameters.append(('simulator_scenario_hlr_query', 'store', 'string', None))
parameters.append(('simulator_scenario_hlr_queryInitialOnly', 'store', 'string', None))
parameters.append(('simulator_scenario_hlr_releaseCallAfterMS', 'store', 'string', None))
parameters.append(('simulator_scenario_hlr_scfInitiated', 'store', 'string', None))
parameters.append(('simulator_scenario_hlr_ussd_dcs_charSet', 'store', 'string', None))
parameters.append(('simulator_scenario_hlr_ussd_dcs_dcg', 'store', 'string', None))
parameters.append(('simulator_scenario_hlr_ussd_dcs_iso639LangId', 'store', 'string', None))
parameters.append(('simulator_scenario_hlr_ussd_dcs_msgClass', 'store', 'string', None))
parameters.append(('simulator_scenario_hlr_ussd_dcs_natLang', 'store', 'string', None))
parameters.append(('simulator_scenario_hlr_ussd_gsm8Charset', 'store', 'string', None))
parameters.append(('simulator_scenario_hlr_ussd_segmentOpen', 'store', 'string', None))
parameters.append(('simulator_scenario_hlr_ussd_sendResponseInNotify', 'store', 'string', None))
parameters.append(('simulator_scenario_hlr_ussd_string', 'store', 'string', None))
parameters.append(('simulator_scenario_reauth', 'store', 'string', None))
parameters.append(('simulator_scenario_releaseAtEnd', 'store', 'string', None))
parameters.append(('simulator_scenario_requestCIR', 'store', 'string', None))
parameters.append(('simulator_scenario_requestCIRLeg', 'store', 'string', None))
parameters.append(('simulator_scenario_sendFCI', 'store', 'string', None))
parameters.append(('simulator_scenario_sendSCI', 'store', 'string', None))
parameters.append(('simulator_scenario_useCancelAndyContinueNotReleaseCall', 'store', 'string', None))
parameters.append(('simulator_scenario_useInternalSRF', 'store', 'string', None))
parameters.append(('simulator_tcap_endTimerInMS', 'store', 'string', None))
parameters.append(('simulator_tcap_endType', 'store', 'string', None))
parameters.append(('ss7_m3ua_initialDaudResponse', 'store', 'string', None))
parameters.append(('ss7_sccp_dest_gt', 'store', 'string', None))
parameters.append(('ss7_sccp_dest_gt_noa', 'store', 'string', None))
parameters.append(('ss7_sccp_dest_gt_np', 'store', 'string', None))
parameters.append(('ss7_sccp_dest_gt_tt', 'store', 'string', None))
parameters.append(('ss7_sccp_dest_pc', 'store', 'string', None))
parameters.append(('ss7_sccp_dest_ri', 'store', 'string', None))
parameters.append(('ss7_sccp_map_ssn', 'store', 'string', None))
parameters.append(('ss7_sccp_map_ssn2', 'store', 'string', None))
parameters.append(('ss7_sccp_orig_gt', 'store', 'string', None))
parameters.append(('ss7_sccp_orig_gt_noa', 'store', 'string', None))
parameters.append(('ss7_sccp_orig_gt_np', 'store', 'string', None))
parameters.append(('ss7_sccp_orig_gt_tt', 'store', 'string', None))
parameters.append(('ss7_sccp_orig_pc', 'store', 'string', None))
parameters.append(('ss7_sccp_orig_ri', 'store', 'string', None))
parameters.append(('ss7_sccp_returnOnError', 'store', 'string', None))
parameters.append(('ss7_sccp_ssn', 'store', 'string', None))
parameters.append(('ss7_tcap_dialogIdleTimeoutInSecs', 'store', 'string', None))
parameters.append(('ss7_tcap_endTimerInMS', 'store', 'string', None))
parameters.append(('ss7_tcap_endType', 'store', 'string', None))
parameters.append(('subsequentResponseTimeoutInSecs', 'store', 'string', None))

# Define prefixes to use for CCF parameters
ccfPrefixList = (('correlation_', 'display_', 'hlr_', 'hlr2_', 'idp_', 'idpsms_', 'imsiRange_', 'map_', 'scenario_', 'sigtran_', 'simulator_', 'ss7_', 'camel_'))

# Support using old test framework parameters for some new CCF parameters.
# Format is CCF parameter, existing test framework parameter.  Logic is if the
# CCF parameter is None, then use the old parmaeter (else leave the specified parameter as-is).
# For used amounts, CCF tool only supports single item so always use single entry.
ccfReuseParameters = []
# Voice items
ccfReuseParameters.append(('idp_calledPartyNumber',             'calledStation','voice'))
ccfReuseParameters.append(('idp_calledPartyBCDNumber',          'calledStation','voice'))
ccfReuseParameters.append(('idp_callingPartyNumber',            'accessNumbers', 'voice', 'all', 'mo'))
ccfReuseParameters.append(('idp_callingPartyNumber',            'callingStation','voice', 'all', 'mt'))
ccfReuseParameters.append(('scenario_SimpleAC_callChargeInSecs','usedAmount[0]','voice', 'SimpleAC'))
ccfReuseParameters.append(('scenario_TestCall_callHoldInSecs',  'usedAmount[0]','voice', 'TestCall'))
ccfReuseParameters.append(('scenario_MultiAC_callHoldInSecs',   'usedAmount[0]','voice', 'MultiAC'))
ccfReuseParameters.append(('idp_calledPartyNumber_noa',         'noa',          'voice'))
ccfReuseParameters.append(('idp_locationInfo_lac',              'ulixtra1',     'voice'))
ccfReuseParameters.append(('idp_locationInfo_ci',               'ulixtra2',     'voice'))
ccfReuseParameters.append(('idp_mscAddress',                    'mscAddress',   'voice'))
ccfReuseParameters.append(('idp_locationInfo_vlrNumber',        'mscAddress',   'voice'))
# Text items
ccfReuseParameters.append(('idpsms_destinationSubscriberNumber','calledStation','text'))
ccfReuseParameters.append(('idpsms_callingPartyNumber',         'accessNumbers','text'))
ccfReuseParameters.append(('idpsms_callingPartyNumber_noa',     'noa',          'text'))
ccfReuseParameters.append(('idpsms_eventTypeSms',               '1',            'text'))
ccfReuseParameters.append(('idpsms_mscAddress',                 'mscAddress',   'text'))
ccfReuseParameters.append(('idpsms_smscAddress',                'mscAddress',   'text'))
# Time of day
ccfReuseParameters.append(('idp_timeAndTimeZone_year', 'LastYear',     'voice'))
ccfReuseParameters.append(('idp_timeAndTimeZone_month', 'LastMonth',   'voice'))
ccfReuseParameters.append(('idp_timeAndTimeZone_day',  'LastDay',      'voice'))
ccfReuseParameters.append(('idp_timeAndTimeZone_hour', 'LastHour',     'voice'))
ccfReuseParameters.append(('idp_timeAndTimeZone_minute','LastMinute',  'voice'))
ccfReuseParameters.append(('idp_timeAndTimeZone_second','LastSecond',  'voice'))
ccfReuseParameters.append(('idp_timeAndTimeZone_timeZone','TimeZone',  'voice'))

#==========================================================
def CmdCcfEvent(lclDCT, options):
        global parameters
        global ccfReuseParameters
        
        # Stores original values that were overwritten
        ORIG = {}
        
        # *** lclDCT[] has all the values.
        
        #print 'accessNumbers = ' + str(accessNumbers)
        
        # *** Figure out where to send messages to ***
        # Want to send one or more events.  How many to send depends on the action.
        # Only send if this is an event command.  Else define a dummy value so the code executes.
        if lclDCT['ACTION'].count('Event'):
                (deviceId, queryValue, queryType, deviceIdToSend, accessNumberToSend) = \
                        PRIM.getListToSendTo(lclDCT['ACTION'], lclDCT['deviceId'], lclDCT['externalId'], lclDCT['groupId'], lclDCT['mark'], lclDCT['scope'], lclDCT['accessNumbers'], allFlag=True, LoginId=lclDCT['LoginId'])
        else: accessNumberToSend = ['dummy']
        
        # Process each device to send to
        for accessNumbers in accessNumberToSend:
                # Copy old to new parameter
                for param in ccfReuseParameters:
                        # Get minimum entries
                        _sigtranParam = param[0]
                        
                        # Skip if parameter is set (i.e. was input on the command)
                        if lclDCT[_sigtranParam] != None: continue
                        
                        # "Parameter" may be a TF parameter or a constant.
                        # It also may reference an array antry, which requires different processing...
                        if param[1].count('['):
                             _data = param[1].split('[')
                             _name = _data[0]
                             _index = int(_data[1][:-1])
                             _TFParamValue = lclDCT[_name][_index]
                        elif param[1] in DATA.constantValue:    _TFParamValue = DATA.constantValue[param[1]]
                        elif param[1].isdigit():                _TFParamValue = param[1]
                        else:                                   _TFParamValue = lclDCT[param[1]]
                        #print('Looking at parameter: ' + param[1] + ', value = ' + str(_TFParamValue))
                        
                        # Skip if TF parameter not set
                        if _TFParamValue == None or str(_TFParamValue) == '': continue

                        impactedService = param[2]
                        
                        # Default stuff as needed
                        if len(param) == 5:
                                scenarioCheck = param[3]
                                _callDirection = param[4]
                        elif len(param) == 4:
                                scenarioCheck = param[3]
                                _callDirection = 'all'
                        else:
                                scenarioCheck = 'all'
                                _callDirection = 'all'
                                
                        # Skip if not the right scenario
                        if scenarioCheck.lower() != 'all' and lclDCT['scenario'].lower() != scenarioCheck.lower(): continue
                        
                        # Skip if for a different service
                        if impactedService not in ['all', 'both', lclDCT['serviceId']]: continue
                        
                        # Skip if direction not correct
                        if _callDirection.lower() not in ['all', lclDCT['callDirection'].lower()]: continue
                        
                        # Save original parameter value and set TF parameter
                        ORIG[_sigtranParam] = lclDCT[_sigtranParam]
                        lclDCT[_sigtranParam] = _TFParamValue
                
                # Set destination point code.  Annoying, but best to put here.
                # Get from config.
                gatewaysConfig = qa_utils.getDiameterRestConfig()
                ss7_sccp_dest_pc = gatewaysConfig.get('SIGTRAN', 'dpc')
                
                # Build additional parameter; only the non-None ones
                additionalParams = []
                
                # Go through each parameter (name only; first parameter in the tuple)
                for param in [x[0] for x in parameters]:
                        # Skip if not set
                        if lclDCT[param] == None: continue
                        
                        # Translate back the underscores to period
                        ccfParam = param.replace('_', '.')
                        skipString = 'misc.'
                        if ccfParam.startswith(skipString): ccfParam = ccfParam[len(skipString):]
                        
                        # Add to additional patrameters
                        if str(lclDCT[param]) == '99999': paramString = ccfParam + '='
                        else:                        paramString = ccfParam + '=' + str(lclDCT[param])
                        print('CCF setting parameter: ' + paramString)
                        additionalParams.append((paramString))
                        
                # HACK: for now add several parameters for SMS that have an underscore in their name (breaks TF design...)
                if lclDCT['serviceId'] == 'text':
                        paramString = 'idpsms.tp_protoId=0'
                        additionalParams.append((paramString))
                        print('CCF setting parameter: ' + paramString)
                        paramString = 'idpsms.tp_dataCodingScheme=0'
                        additionalParams.append((paramString))
                        print('CCF setting parameter: ' + paramString)
                
                # Invoke the desired CCF utility
                if   lclDCT['ACTION'] == 'ccfStartHlr':
                        SIGTRAN_UTIL.sigtranTestStartHlr(additionalConfigOptions=additionalParams, paramsToIgnore=None, testName=lclDCT['scenario'])
                elif lclDCT['ACTION'] == 'ccfStopHlr':
                        SIGTRAN_UTIL.sigtranTestStopHlr()
                else:   retCode = SIGTRAN_UTIL.sigtranTest(scenario=lclDCT['scenario'], imsi=accessNumbers, additionalConfigOptions=additionalParams)
                
                # Check the result code
                if retCode != lclDCT['eventPass']: sys.exit('ERROR: sigtran result code "' + str(retCode) + '" doesn\'t match expected result "' + str(lclDCT['eventPass']) + '"')
                
                # Restore parameters
                for parameter in list(ORIG.keys()): lclDCT[parameter] = ORIG[parameter]
                
        return (lclDCT['subQueryType'], lclDCT['externalId'])
        

