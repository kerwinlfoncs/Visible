#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:35:25
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:35:24
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:35:24
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
from __future__ import print_function
# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
import sys, copy, time
import QA_subscriber_management_restv3 as REST_UTIL
import qa_utils as QAUTILS
import csv_track as TRACK
import csv_prim as PRIM
import csv_data as DATA
import custSpecific as CUST

import requests, json, pprint

from primitives import primData as PRIMDATA

#===============================================================================
def clientOutputSubscriberData(response):
        # Debug output
        pprint.pprint(response)
        
        # Get outta dodge!  Having issues here, so leave the output the the pprint
        return
        
        # Header
        print('Subscriber Data:')
        
        # Print top level fields
        outstr = ''
        for parameter in ['objectId', 'subscriberContext', 'subscriberFirstName']:
                if parameter in response['result']: outstr += ', ' +  parameter + ': ' + response['result'][parameter]
        if outstr: print('Base Data: ' + outstr[2:])
        
        # Look for a currency balance
        currencyAmount = 'N/A'
        if 'money' in response['result'] and response['result']['money']:
                if 'credit' in response['result']['money'] and response['result']['money']['credit']:
                        if 'creditAmount' in response['result']['money']['credit'] and response['result']['money']['credit']['creditAmount']:
                                currencyAmount = response['result']['currency'] + str(response['result']['money']['credit']['creditAmount'])
        print('Currency: ' + currencyAmount)
        
        # Output packages
        print('Packages:')
        if 'packages' in response['result']:
                pkgformat = "%5s %15s %30s %s\n"
                sys.stdout.write(pkgformat % ('', 'Name', 'Type', 'End Date'))
                for offer in response['result']['packages']:
                        offerExternalId = offer['offerId']
                        offerType = offer['offerType']
                        if 'expiryDate' in offer: offerEndDate = offer['expiryDate']
                        else:                     offerEndDate = 'N/A'
                        sys.stdout.write(pkgformat % ('', offerExternalId, offerType, offerEndDate))
                        if 'services' in offer:
                                balformat = "%10s %15s %30s %s\n"
                                sys.stdout.write(balformat % ('', 'Offer', 'Name', 'Remainder'))
                                for balance in offer['services']:
                                        outstr = ''
                                        if 'productOfferId' in balance: offerExternalId = balance['productOfferId']
                                        else:                           offerExternalId = 'N/A'
                                        offerName = balance['name']
                                        Remainder = str(balance['remainingAmount']) + ' ' + balance['remainingUnit']
                                        sys.stdout.write(balformat % ('', offerExternalId, offerName, Remainder))
                        
        if 'promoOffers' in response['result']: print('Promos: ' + str(response['result']['promoOffers']))
        
        return
        
#===============================================================================
def clientCommandCommonFields():
        # Setup common URL header
        urlStart = "http://" + QAUTILS.gatewaysConfig.get('CLIENT', 'server') + "/" + QAUTILS.gatewaysConfig.get('CLIENT', 'accessUrl') + "/rest/"
        
        # JSON HTTP call headers (common; sometimes content type not required, but doesn't hurt)
        headers = {
                'content-type': "application/json",
                'cache-control': "no-cache",
                }       
#               'postman-token': "7e0fdfc5-5e8a-443e-330b-67fc9cc90748"
        
        return urlStart,headers

#==========================================================
def clientExecuteCommand(operation, action, url, payload, headers, exitOnError=True):
#       debugFlag = True
        debugFlag = False
        
        # Convert python to json if payload passed in
        if payload:
                # Convert to JSON
                jsonPayload = json.dumps(payload)
        else:   jsonPayload = None
        
        # Convert headers to JSON if passed in
        if headers:
                # Convert to JSON
                jsonHeaders = json.dumps(headers)
        else:   jsonHeaders = None
        jsonHeaders = headers
                
        # Debug
        if debugFlag:
                print('Start ' + operation + ' with action ' + action)
                print(url)
                print(jsonHeaders)
                print(jsonPayload)
        
        # Execute primitive
        jsonResponse = requests.request(action, url, data=jsonPayload, headers=jsonHeaders)
        
        # See response
#       print(jsonResponse.text)
#       print(jsonResponse)
        
        # Get into Python dictionary
        pythonResponse=json.loads(jsonResponse.text)
#       print(pythonResponse)
        if debugFlag: print(operation + ' result: ' + pythonResponse['message'])
        
        # Check if the action itself had a local result
        if 'result' in pythonResponse and pythonResponse['result'] and 'result' in pythonResponse['result']:
                localResult = int(pythonResponse['result']['result'])
                if localResult == None: localResult = 0
        else:   localResult = 0
        
        # Check for failure
        if pythonResponse['message']!= "Success" or localResult != 0:
                print('WARNING: Failed in ' + operation + ': ')
                print(pythonResponse)
                if exitOnError: sys.exit('Exiting due to errors and none expected')
        
        if debugFlag: print(pythonResponse)
        return pythonResponse
        
#==========================================================
def CmdClient_clientquerysubscriber(lclDCT, options):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        userId = lclDCT['userId']
        # End of local variables setup.

        # Subscriber should exist
        if lclDCT['externalId'] not in TRACK.subscriberTracking and not lclDCT['noChecks']:
                print('ERROR: subscriber with external ID "' + lclDCT['externalId'] + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # ********************          Client interface items          **************************
        # Gt the userId if not using noChecks (otherwise it better be passed in)
        if not lclDCT['noChecks']: userId = TRACK.subscriberTracking[lclDCT['externalId']]['userId']
        elif not userId:
                sys.exit('ERROR: noChecks passed in but no userId parameter entered')
        
        # Setup common URL header
        (urlStart,headers) = clientCommandCommonFields()
        
        # *** Query
        operation = 'Query'
        action = 'GET'
        payload = None
        url = urlStart + 'subscriber/' + userId
        
        # Execute the command
        response = clientExecuteCommand(operation, action, url, payload, headers)
        
        # Output data
        clientOutputSubscriberData(response)
        # Query subscriber
        queryValue = lclDCT['externalId']
        queryType = lclDCT['subQueryType']
        
        return (queryType, queryValue)
        
#==========================================================
def CmdClient_clientmodifysubscriber(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Subscriber should exist
        if lclDCT['externalId'] not in TRACK.subscriberTracking and not lclDCT['noChecks']:
                print('ERROR: subscriber with external ID "' + lclDCT['externalId'] + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # ********************          Client interface items          **************************
        # Setup common URL header
        (urlStart,headers) = clientCommandCommonFields()
        
        # Get full URL
        # Hard-coded to context value for now.  Probabaly need more logic as the API is enhanced...
        url = urlStart + 'subscriber/context/' + lclDCT['accessNumbers'] + '/' + lclDCT['contextValue']
        
        # Execute the command
        operation = 'Modify'
        action = 'PUT'
        payload = None
        response = clientExecuteCommand(operation, action, url, payload, headers, lclDCT['eventPass'])
        #print(response)
        
        # Query subscriber
        queryValue = lclDCT['externalId']
        queryType = lclDCT['subQueryType']
        
        return (queryType, queryValue)
        
#==========================================================
def CmdClient_clientsubscribetooffer(lclDCT, options):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        userId = lclDCT['userId']
        offerId = lclDCT['offerId']
        # End of local variables setup.

        # Subscriber should exist
        if lclDCT['externalId'] not in TRACK.subscriberTracking and not lclDCT['noChecks']:
                print('ERROR: subscriber with external ID "' + lclDCT['externalId'] + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # ********************          Client interface items          **************************
        # Gt the userId if not using noChecks (otherwise it better be passed in)
        if not lclDCT['noChecks']: userId = TRACK.subscriberTracking[lclDCT['externalId']]['userId']
        elif not userId:
                sys.exit('ERROR: noChecks passed in but no userId parameter entered')
        
        # Setup common URL header
        (urlStart,headers) = clientCommandCommonFields()
        
        # *** Purchase the offer (only one offer at a time for the client interface)
        operation = 'Offer Purchase'
        action = 'POST'
        if lclDCT['offerBundle']: name = lclDCT['offerBundle']
        else:           
                # Only use name in outer header (versus inside each price point)
                name = offerId[0]
                offerId[0] = None
        payload = {"externalId": name, "paymentType":lclDCT['paymentType'], "services" : []}
        
        # If additional parameters defined, then add to payload services
        if lclDCT['offerGrant'] or lclDCT['offerCharge'] or lclDCT['offerValidityUnit'] or lclDCT['offerValidityAmount']:
                # Make sure all lengths are equal
                
                # Process each entry
                for i in range(10):
                        # Add if non-Null
                        priceEntry = {}
                        if lclDCT['offerCharge'] and len(lclDCT['offerCharge']) > i and lclDCT['offerCharge'][i] and str(lclDCT['offerCharge'][i]).lower() != 'none': priceEntry['price'] = lclDCT['offerCharge'][i]
                        if lclDCT['offerGrant'] and len(lclDCT['offerGrant']) > i and lclDCT['offerGrant'][i] and str(lclDCT['offerGrant'][i]).lower() != 'none': priceEntry['volume'] = lclDCT['offerGrant'][i]
                        if lclDCT['offerValidityUnit'] and len(lclDCT['offerValidityUnit']) > i and lclDCT['offerValidityUnit'][i] and str(lclDCT['offerValidityUnit'][i]).lower() != 'none': priceEntry['validityUnit'] = lclDCT['offerValidityUnit'][i]
                        if lclDCT['offerValidityAmount'] and len(lclDCT['offerValidityAmount']) > i and lclDCT['offerValidityAmount'][i] and str(lclDCT['offerValidityAmount'][i]).lower() != 'none': priceEntry['validityAmount'] = lclDCT['offerValidityAmount'][i]
                        
                        # Skip if nothing entered
                        if priceEntry == {}: continue
                        
                        #priceEntry = {'price':ChargeAmount, 'volume':GrantAmount, "validityAmount":ValidityAmount, "validityUnit":ValidityUnit}
                        
                        # Add offer ID if present
                        pricePoint = {"pricePoint":[priceEntry]}
                        if offerId and len(offerId) > i and offerId[i] and str(offerId[i]).lower() != 'none': pricePoint['name'] = offerId[i]
                        payload["services"].append(pricePoint)
                
                # Cheat...
#               payload["services"] = [{"pricePoint":[{"price": ChargeAmount, "volume": GrantAmount, "validityAmount": ValidityAmount, "validityUnit": ValidityUnit}], "name": "Data"}]
#               payload["services"] = [{"pricePoint":[{"price": 1,"volume": 500, "validityAmount": 1, "validityUnit": "Day"}],"name": "Data"}]

        url = urlStart + 'subscriber/' + userId + '/offer'
        
        # Execute the command
        response = clientExecuteCommand(operation, action, url, payload, headers, lclDCT['eventPass'])
        #print(response)
        
        # Stuff to do if expecting to succeed
        if lclDCT['eventPass']:
                # Get the resource ID
                resourceId = response['result']['resourceIdArray']['value'][0]
#               print 'Offer resourceId = ' + resourceId
                
                # Update tracking data
                TRACK.updateTrackingData(lclDCT['ACTION'], externalId = lclDCT['externalId'], offerId = offerId, resourceId = resourceId)
        
        # Query subscriber
        queryValue = lclDCT['externalId']
        queryType = lclDCT['subQueryType']
        
        return (queryType, queryValue)
        
#==========================================================
def CmdClient_clientaddsubscriber(lclDCT, options):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        userId = lclDCT['userId']
        offerId = lclDCT['offerId']
        offerStartTime = lclDCT['offerStartTime']
        # End of local variables setup.
        
        # Want to update local start time variable, so it's ready for the next iteration.
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if offerStartTime == None:
             offerStartTime = lclDCT['lclStartTime']
        else:
             lclStartTime = offerStartTime

        # Can provide subOfferId or offerId for this command.
        # Map to offer ID.
        if (not offerId or offerId.count('0')) and lclDCT['subOfferId']: offerId = lclDCT['subOfferId']

        # If offerId is 0, then we don't want to purchase anything.  Make sure the offer external flag is False (hard to set via command line).
        if not offerId or offerId.count('0'):
                offerIsExternal = False
                offerId = 0

        # Create billing cycle data if profile id defined
        if lclDCT['profileId'] and int(lclDCT['profileId']):
                billingCycle = REST_UTIL.createBillingCycleData(lclDCT['profileId'], dateOffset=lclDCT['dateOffset'], startTime=lclDCT['startTime'])
        else:
                billingCycle = None

        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if offerStartTime:
             lclStartTime = offerStartTime
        
        # Debug output
        print('Adding subscriber ' + str(lclDCT['externalId']) + ' with status ' + str(lclDCT['subStatus']))
        
        # Debug output
        if str(offerId) != '0':
                if lclDCT['verbose'] not in ['low', 'none']:
                 print('Subscriber is purchasing offers ' + str(offerId) + ' with start/end times ' + str(offerStartTime) + '/' + str(lclDCT['offerEndTime']))

#        print lclDCT['ACTION'] + ' device = ' + deviceId + ', accessNumbers = ' + str(accessNumbers) + ', offerID = ' + str(offerId) + ', RESTInst = ' + str(RESTInst)
        
        # Print custom data
        #if lclDCT['customAttr'][1]: print 'Including subscriber custom parameters: ' + str(lclDCT['customAttr'][1])
        #if lclDCT['customAttr'][0]: print 'Including device     custom parameters: ' + str(lclDCT['customAttr'][0])
        #if lclDCT['customAttr'][3]: print 'Including offer      custom parameters: ' + str(lclDCT['customAttr'][3])
        
        # ********************          Client interface items          **************************
        # Setup common URL header
        (urlStart,headers) = clientCommandCommonFields()
        
        # *** Delete existing subscriber (no harm done if not provisioned)
        # Should delete the subscriber all the time to be safe...
        operation = 'Delete'
        action = 'DELETE'
        payload = None
        url = urlStart + 'subscriber/query/byPhone/' + lclDCT['accessNumbers']
        
        # Execute the command (but don't exit if it fails)
        response = clientExecuteCommand(operation, action, url, payload, headers, False)
        
        # *** Create new subscriber
        operation = 'Provision'
        action = 'POST'
        url = urlStart + 'subscriber/provision'
        
        # Build payload
        payload = {}
        payload["firstName"] = lclDCT['firstName']
        payload["lastName"] = lclDCT['lastName']
        payload["contactPhoneNumber"] = lclDCT['contactPhoneNumber']
        payload["contactEmail"] = lclDCT['contactEmail']
        payload["timeZone"] = lclDCT['subTimeZone']
        payload["billingCycleID"] = lclDCT['profileId'] if billingCycle else None
        payload["offers"] = offerId if str(offerId) != '0' else []
        payload["devices"] = []
        device = {"accessNumber":lclDCT['accessNumbers'], "paymentType":lclDCT['paymentType'], "imsi":lclDCT['deviceId']}
        payload["devices"].append(device)
        
        # Execute the command
        response = clientExecuteCommand(operation, action, url, payload, headers)
        
        # *** Welcome call
        operation = 'Welcome'
        action = 'GET'
        payload = None
        url = urlStart + 'onboarding/welcome'
        
        # Execute the command
        response = clientExecuteCommand(operation, action, url, payload, headers)
        
        # Get userID (needed for all future operations)
        userId = response['result']['userId']
        print('UserId: ' + userId)
        
        # *** Terms Acceptance
        operation = 'Terms'
        action = 'GET'
        payload = None
        url = urlStart + 'onboarding/terms'
        
        # Execute the command
        response = clientExecuteCommand(operation, action, url, payload, headers)
        
        # *** PIN
        # Can block this (as it requires a real phone)
        if  not lclDCT['noPin']:
                operation = 'Pin'
                action = 'GET'
                payload = None
                url = urlStart + 'onboarding/' + userId + '/requestPIN/' + lclDCT['accessNumbers']
                
                # Execute the command
                response = clientExecuteCommand(operation, action, url, payload, headers)
        
        # *** Activate
        operation = 'Activate'
        action = 'POST'
        payload = {"pin" : "00000"}
        url = urlStart + 'onboarding/' + userId + '/activateSIM/' + lclDCT['accessNumbers']
        
        # Execute the command
        response = clientExecuteCommand(operation, action, url, payload, headers)
        
        # *** Register
        operation = 'Register'
        action = 'POST'
        payload = {"paymentType" : lclDCT['paymentType'], "settlementTypes": {}}
        url = urlStart + 'subscriber/' + userId + '/registerPayment'
        
        # Execute the command
        response = clientExecuteCommand(operation, action, url, payload, headers)
        
        # *** Top-Up
        operation = 'Top-Up'
        action = 'POST'
        if not lclDCT['voucher']: voucher = "12345678901255"
        payload = {"topupType": lclDCT['topupType'], "voucherNumber" : lclDCT['voucher']}
        url = urlStart + 'subscriber/' + userId + '/topup'
        
        # Execute the command
        response = clientExecuteCommand(operation, action, url, payload, headers)
        
        # *** Register token
        operation = 'Token'
        action = 'POST'
        
        # Override original default parameter value so testers don;t need to enter (as that value has no meaning here)
        if lclDCT['deviceTypeName'] == 'generic': deviceTypeName = "ANDROID"
        
        # Build payload
        payload = {"token": "RSDFITYRUXYUGOOGO&IU", "deviceType" : lclDCT['deviceTypeName']}
        
        # Build URL
        url = urlStart + 'notifications/' + userId + '/token'
        
        # Execute the command
        response = clientExecuteCommand(operation, action, url, payload, headers)
        
        # *** Query
        operation = 'Query'
        action = 'GET'
        payload = None
        url = urlStart + 'subscriber/' + userId
        
        # Execute the command
        response = clientExecuteCommand(operation, action, url, payload, headers)
        print('Subscriber data post provisioning:')
        print(response)
        
        # **** Done with Client interactions ****
        # Stuff to do if we passed
        if lclDCT['eventPass']:
                # Update tracking data
                TRACK.updateTrackingData(lclDCT['ACTION'], externalId = lclDCT['externalId'], deviceId = lclDCT['deviceId'], accessNumbers=lclDCT['accessNumbers'], offerId = offerId, mark=lclDCT['mark'], userId=userId)
                
                # Update CSR so we can login as this access number
                if PRIMDATA.skipMyMatrixx.lower() != 'true':
                        accessNumToUse = []
                        if type(lclDCT['accessNumbers']) == type(list()):
                                accessNumToUse = lclDCT['accessNumbers']
                        else:
                                accessNumToUse.append(lclDCT['accessNumbers'])
                        for aN in accessNumToUse: QAUTILS.updateCsrData(aN)
                        
        # Query subscriber
        queryValue = lclDCT['accessNumbers']
        queryType = 'AccessNumber'
        
        return (queryType, queryValue)
        
#==========================================================
def CmdClient_clientclearnotification(lclDCT, options):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        userId = lclDCT['userId']
        # End of local variables setup.

        # Subscriber should exist
        if lclDCT['externalId'] not in TRACK.subscriberTracking and not lclDCT['noChecks']:
                print('ERROR: subscriber with external ID "' + lclDCT['externalId'] + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # ********************          Client interface items          **************************
        # Gt the userId if not using noChecks (otherwise it better be passed in)
        if not lclDCT['noChecks']: userId = TRACK.subscriberTracking[lclDCT['externalId']]['userId']
        elif not userId:
                sys.exit('ERROR: noChecks passed in but no userId parameter entered')
        
        # Setup common URL header
        (urlStart,headers) = clientCommandCommonFields()
        
        # Get full URL
        # Hard-coded to context value for now.  Probabaly need more logic as the API is enhanced...
        url = urlStart + 'notifications/readall/' + userId
        
        # Execute the command
        operation = 'Clear Notifications'
        action = 'POST'
        payload = None
        response = clientExecuteCommand(operation, action, url, payload, headers, lclDCT['eventPass'])
        #print(response)
        
        # Query subscriber
        queryValue = lclDCT['externalId']
        queryType = lclDCT['subQueryType']
        
        return (queryType, queryValue)
        
#==========================================================
def CmdClient_clientpushnotification(lclDCT, options):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        userId = lclDCT['userId']
        # End of local variables setup.

        # Subscriber should exist
        if lclDCT['externalId'] not in TRACK.subscriberTracking and not lclDCT['noChecks']:
                print('ERROR: subscriber with external ID "' + lclDCT['externalId'] + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # ********************          Client interface items          **************************
        # Gt the userId if not using noChecks (otherwise it better be passed in)
        if not lclDCT['noChecks']: userId = TRACK.subscriberTracking[lclDCT['externalId']]['userId']
        elif not userId:
                sys.exit('ERROR: noChecks passed in but no userId parameter entered')
        
        # Setup common URL header
        (urlStart,headers) = clientCommandCommonFields()
        
        # Get full URL
        # Hard-coded to context value for now.  Probabaly need more logic as the API is enhanced...
        url = urlStart + 'notifications/' + userId + 'send'
        
        # Execute the command
        operation = 'Push Notifications'
        action = 'POST'
        
        # Hard-code payload for now.  Can variablize later if desired
        payload = {     "title" : "some_title",
                        "body" : "some_body",
                        "category" : "some_category",
                        "offerId" : "FIXEDBUNDLE",
                        "resourceId" : "some_resource",
                        "actions" : "a1,a2,a3"
                   }
        
        response = clientExecuteCommand(operation, action, url, payload, headers, lclDCT['eventPass'])
        #print(response)
        
        # Query subscriber
        queryValue = lclDCT['externalId']
        queryType = lclDCT['subQueryType']
        
        return (queryType, queryValue)
        
#==========================================================
def CmdClient_clientgetnotification(lclDCT, options):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        userId = lclDCT['userId']
        # End of local variables setup.

        # Subscriber should exist
        if lclDCT['externalId'] not in TRACK.subscriberTracking and not lclDCT['noChecks']:
                print('ERROR: subscriber with external ID "' + lclDCT['externalId'] + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Sleep to allow notifications to be sent
        if int(lclDCT['amount']) == 0:    time.sleep(1)
        else:                             time.sleep(lclDCT['amount'])
        
        # ********************          Client interface items          **************************
        # Gt the userId if not using noChecks (otherwise it better be passed in)
        if not lclDCT['noChecks']: userId = TRACK.subscriberTracking[lclDCT['externalId']]['userId']
        elif not userId:
                sys.exit('ERROR: noChecks passed in but no userId parameter entered')
        
        # Setup common URL header
        (urlStart,headers) = clientCommandCommonFields()
        
        # Get full URL
        # Hard-coded to context value for now.  Probabaly need more logic as the API is enhanced...
        url = urlStart + 'notifications/' + userId + '/ANDROID/0/'
        
        # Execute the command
        operation = 'Notifications'
        action = 'GET'
        payload = None
        response = clientExecuteCommand(operation, action, url, payload, headers, lclDCT['eventPass'])
        print('Device Notification:')
        print(response)
        
        # Query subscriber
        queryValue = lclDCT['externalId']
        queryType = lclDCT['subQueryType']
        
        return (queryType, queryValue)
        
