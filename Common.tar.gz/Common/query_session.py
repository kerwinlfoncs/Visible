#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:16
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:35:58
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:34:46
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


import os,sys
import optparse
import pretty_print as PRINT
import qa_utils as QAUTILS
import QA_subscriber_management_restv3 as RESTV3

restInst = None

def main():
    global restInst

    parser = optparse.OptionParser()
    parser.add_option("-i", "--imsi", action='store', type='string', default=None)
    parser.add_option("-o", "--doid", action='store', type='string', default=None)
    parser.add_option("-t", "--type", action='store', type='string', default=None)
    parser.add_option("-s", "--session", action='store', type='string', default=None)
    parser.add_option("-v", "--validate", action='store', type='int', default=0)
    parser.add_option("-r", "--restgw", default="", help="query by REST")
    (options, args) = parser.parse_args()

    if options.imsi is None and options.doid is None:
        print('need device imis or device oid to start session query')
        sys.exit(1)

    # Get client to perform query
    gatewaysConfig = QAUTILS.getDiameterRestConfig()
    if options.restgw:
        RESTV3.setVersion('REST')
    else:
        RESTV3.setVersion('MDC')
        RESTV3.mtxflags = 1
    QAUTILS.gatewaysConfig = gatewaysConfig
    restInst = QAUTILS.getSubscInterface()

    if options.validate == 1 :
        if options.imsi:
            validateDeviceSession(options.imsi, 'Imsi', sessionId=options.session, sessionType=options.type, rest=options.restgw)
        elif options.doid:
            validateDeviceSession(options.doid, 'ObjectId', sessionId=options.session, sessionType=options.type, rest=options.restgw)
    else :
        if options.imsi:
            getDeviceSessionData(options.imsi, 'Imsi',  rest=options.restgw)
        elif options.doid:
            getDeviceSessionData(options.doid, 'ObjectId', rest=options.restgw)
		 
def getDeviceSessionData(queryValue, queryType, rest=None):
    if rest:
        print(RESTV3.queryDeviceSession(restInst, queryValue=queryValue, queryType=queryType))
    else:
        # Formatted printing for MDC specific output
        sessionMdc = RESTV3.queryDeviceSession(restInst, queryValue=queryValue, queryType=queryType)
        print(sessionMdc.printXml())

def validateDeviceSession(queryValue, queryType, sessionId=None, sessionType=None, rest=None):
    if rest:
        print(RESTV3.validateDeviceSession(restInst, queryValue=queryValue, queryType=queryType, sessionId=None, sessionType=None))
    else:
        # Formatted printing for MDC specific output
        responseMdc = RESTV3.validateDeviceSession(restInst, queryValue=queryValue, queryType=queryType, sessionId=None, sessionType=None)
	print(responseMdc.printXml())


if __name__ == '__main__':
   main()
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

