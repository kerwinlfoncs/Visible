#!/bin/bash
# DO NOT echo anything from here!  validate_balances.py code checks for anything returned and fails if so.

# Build list of strings to exclude.  Easy to extend now :-).
strToUse="IsRecurring"
strToUse=${strToUse}"|/array"
strToUse=${strToUse}"|/field"
strToUse=${strToUse}"|/struct"
strToUse=${strToUse}"|AdminCount"
strToUse=${strToUse}"|AdminGroupCount"
strToUse=${strToUse}"|AggregateBalanceCount"
strToUse=${strToUse}"|AggregateGroupId"
strToUse=${strToUse}"|AggregateResourceId"
strToUse=${strToUse}"|AggregationId"
strToUse=${strToUse}"|AssociatedEventId"
strToUse=${strToUse}"|ActivationTime"
strToUse=${strToUse}"|BalanceOwnerExternalId"
strToUse=${strToUse}"|BalanceOwnerId"
strToUse=${strToUse}"|BalanceResourceIdArray "
strToUse=${strToUse}"|CatalogItem"
strToUse=${strToUse}"|ChargeCancelProrationType"
strToUse=${strToUse}"|ChargePurchaseProrationType"
strToUse=${strToUse}"|CreatedTime"
strToUse=${strToUse}"|CurrentPeriodDuration"
strToUse=${strToUse}"|CurrentPeriodOffset"
strToUse=${strToUse}"|Cursor"
strToUse=${strToUse}"|CycleGrantAmount"
strToUse=${strToUse}"|DATETIME"
strToUse=${strToUse}"|DeleteCode"
strToUse=${strToUse}"|DeviceId"
strToUse=${strToUse}"|DeviceIdArray"
strToUse=${strToUse}"|DeviceType"
strToUse=${strToUse}"|DomainId"
strToUse=${strToUse}"|EventId"
strToUse=${strToUse}"|ExternalId"
strToUse=${strToUse}"|GET"
strToUse=${strToUse}"|GrantCancelProrationType"
strToUse=${strToUse}"|GrantPurchaseProrationType"
strToUse=${strToUse}"|GroupMemberCount"
strToUse=${strToUse}"|ImpactSource"
strToUse=${strToUse}"|Imsi"
strToUse=${strToUse}"|InitiatorExternalId"
strToUse=${strToUse}"|IntervalId"
strToUse=${strToUse}"|IsBillingCyclePeriodic"
strToUse=${strToUse}"|IsBundleImpact"
strToUse=${strToUse}"|IsCycleHolding"
strToUse=${strToUse}"|IsMainBalance"
strToUse=${strToUse}"|IsSupplemental"
strToUse=${strToUse}"|IsTentative"
strToUse=${strToUse}"|IsPurchasedItemCyclePeriodic"
strToUse=${strToUse}"|LastActivityTime"
strToUse=${strToUse}"|LoginId"
strToUse=${strToUse}"|ModifiedTime"
strToUse=${strToUse}"|MtxRequiredBalanceInfo"
strToUse=${strToUse}"|MtxTemplateAttr"
strToUse=${strToUse}"|NotificationId"
strToUse=${strToUse}"|NotificationPreference"
strToUse=${strToUse}"|NotificationState"
strToUse=${strToUse}"|NotificationTime"
strToUse=${strToUse}"|OBJECT_ID"
strToUse=${strToUse}"|ObjectExternalId"
strToUse=${strToUse}"|ObjectId"
strToUse=${strToUse}"|OfferType"
strToUse=${strToUse}"|OfferVersion"
strToUse=${strToUse}"|Origin-Host"
strToUse=${strToUse}"|OriginHost"
strToUse=${strToUse}"|Origin-Realm"
strToUse=${strToUse}"|OriginRealm"
strToUse=${strToUse}"|Origin-State-Id"
strToUse=${strToUse}"|PUT"
strToUse=${strToUse}"|ParentGroupCount"
strToUse=${strToUse}"|ParentResourceId"
strToUse=${strToUse}"|PaymentType"
strToUse=${strToUse}"|PeriodInterval"
strToUse=${strToUse}"|PeriodicBalanceForfeitureCreditFloorAdjust"
strToUse=${strToUse}"|PeriodicBalanceGrantCreditFloorAdjust"
strToUse=${strToUse}"|Priority"
strToUse=${strToUse}"|ProductOfferExternalId"
strToUse=${strToUse}"|ProductOfferExternalOwnerId"
strToUse=${strToUse}"|ProductOfferOwnerId"
strToUse=${strToUse}"|ProductOfferVersion"
strToUse=${strToUse}"|QuantityUnit"
strToUse=${strToUse}"|RecurringStart"
strToUse=${strToUse}"|RecurringStop"
strToUse=${strToUse}"|RefundInfo"
strToUse=${strToUse}"|RequiredBalanceArray"
strToUse=${strToUse}"|ReservedAmount"
strToUse=${strToUse}"|ResourceId"
strToUse=${strToUse}"|RouteId"
strToUse=${strToUse}"|ServiceTypeId"
strToUse=${strToUse}"|Session-Id"
strToUse=${strToUse}"|SessionId"
strToUse=${strToUse}"|SimpleBalanceGrantCreditFloorAdjust"
strToUse=${strToUse}"|StartPolicy"
strToUse=${strToUse}"|Status"
strToUse=${strToUse}"|OfferStatus"
strToUse=${strToUse}"|StorageId"
strToUse=${strToUse}"|SubscriberExternalId"
strToUse=${strToUse}"|SubscriberMemberCount"
strToUse=${strToUse}"|ThresholdLimit"
strToUse=${strToUse}"|TriggerTime"
strToUse=${strToUse}"|UserId"
strToUse=${strToUse}"|WalletOwnerExternalId"
strToUse=${strToUse}"|WalletOwnerId"
strToUse=${strToUse}"|container name"
strToUse=${strToUse}"|currentTime"
strToUse=${strToUse}"|endToEndId"
strToUse=${strToUse}"|flags"
strToUse=${strToUse}"|hopByHopId"
strToUse=${strToUse}"|len"
strToUse=${strToUse}"|ThresholdType"
strToUse=${strToUse}"|CycleAlignmentOwnerId"
strToUse=${strToUse}"|SubscriberId"
strToUse=${strToUse}"|PreActiveState"
strToUse=${strToUse}"|CycleTimeOfDay"
strToUse=${strToUse}"|CycleOffset"
strToUse=${strToUse}"|Expiry-Time"
strToUse=${strToUse}"|containerId"
strToUse=${strToUse}"|MSISDN"
strToUse=${strToUse}"|IsPeriodClosed"
strToUse=${strToUse}"|IsContractDebit"
strToUse=${strToUse}"|MaxSysSchemaVersion"
strToUse=${strToUse}"|IsSysInit"
strToUse=${strToUse}"|RevenueRecognitionEndDate"
strToUse=${strToUse}"|RevenueRecognitionStartDate"
strToUse=${strToUse}"|IsOneTime"
strToUse=${strToUse}"|DeviceCount"
strToUse=${strToUse}"|IsPauseMode"
strToUse=${strToUse}"|CompilationId"
strToUse=${strToUse}"|AppliedTaxIndex"
strToUse=${strToUse}"|IsPendingActivation"
strToUse=${strToUse}"|OfferStatusClass"
strToUse=${strToUse}"|OfferStatusValue"
strToUse=${strToUse}"|OfferLifecycleProfileId"

# Strings to remove for comparing event store event queries
strToUse=${strToUse}"|sessionId"

# Strings to remove if comparing event store notification queries
strToUse=${strToUse}"| 20[1-9][0-9], "
strToUse=${strToUse}"|/container"
strToUse=${strToUse}"|MtxRelatedUserObject"

strToUse=${strToUse}"|RelationshipType"
strToUse=${strToUse}"|RelatedUserArray"
strToUse=${strToUse}"|InitiatorPrimaryUserId"
strToUse=${strToUse}"|IsCurrentPeriod"
strToUse=${strToUse}"|UserCount"
strToUse=${strToUse}"|RoleInfoArray"
strToUse=${strToUse}"|PricingId"
strToUse=${strToUse}"|MtxPricingRoleInfo"
strToUse=${strToUse}"|OwnerId"
strToUse=${strToUse}"|IsCompositeMeter"
strToUse=${strToUse}"|ExternalRequest"
strToUse=${strToUse}"|InitiatorType"
strToUse=${strToUse}"|WalletOwnerType"
strToUse=${strToUse}"|AccountCount"
strToUse=${strToUse}"|IsPrivate"
strToUse=${strToUse}"|OfferLifecycleProfileId"
strToUse=${strToUse}"|OfferLifecycleProfileName"
strToUse=${strToUse}"|DebtBalanceType"
strToUse=${strToUse}"|DebtBalanceInfo"
strToUse=${strToUse}"|PaymentDueDate"
strToUse=${strToUse}"|IsCreateExternalPaymentRequest"
strToUse=${strToUse}"|MaxSubscriberCount"
strToUse=${strToUse}"|CycleStartTime"
strToUse=${strToUse}"|CycleEndTime"

# If custom fields defined, then add here
if [ "$customStrToExclude" != "" ]
then
	strToUse=${strToUse}"|$customStrToExclude"
#	echo 'Adding string to exclude: $customStrToExclude'
fi

# Default option is to exclude strings.  Customer asked for an option to only include strings...
if [ "$customStrToInclude" != "" ]
then
        strToUse="$customStrToInclude"
	operation=""
else
	operation="-v"
fi

# Debug output
#echo $strToUse
#echo $operation

# Run diff command. Ignore white space and blank lines.
# Optional 3rd parameter allows one to skip sorting. use specific value for skipping the sort.
if [ "$3" != "NoSort" ]
then
	cmd="/bin/sort"
else
	cmd="cat"
fi

# Uncomment if desired to see actual command
#echo "using command: /usr/bin/diff -wB <($cmd $1 | egrep $operation \"$strToUse\") <($cmd $2 | egrep $operation \"$strToUse\")"

# Do the diff
/usr/bin/diff -wB <($cmd $1 | egrep $operation "$strToUse") <($cmd $2 | egrep $operation "$strToUse")

# Some setting that logs the results locally
if [ "A$QAENV" == "A1" ]; then
	resultFile="/home/mtx/workspace/trunk/MTXQA/QA/Tests/main_tests_driver/results/diff_output.txt"
	echo $1 >> $resultFile
	
	# Run diff command. Ignore white space and blank lines.
	/usr/bin/diff -wB <($cmd $1 | egrep $operation "$strToUse") <($cmd $2 | egrep $operation "$strToUse") >> $resultFile
fi

