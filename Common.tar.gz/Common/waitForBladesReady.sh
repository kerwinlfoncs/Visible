bld_cnt=`print_topology.py | grep "LogicalBlade" | wc -l`
i=0
while true; do
    x=` print_blade_stats.py -C 1:1:1 | grep "active" | wc -l`
    sleep 3
    x=`expr $x - 1`
    i=`expr $i + 1`
    if [ "$x" == "$bld_cnt" ]; then
        echo `print_blade_stats.py -C 1:1:1 | grep "processing" | awk '{print $5}'`
        break
    fi
    if [ $i -gt 500 ]; then
        echo 'wait timed out. Exit testing!!!  Please check blades status.'
        exit 1
    fi
done
