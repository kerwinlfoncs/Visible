#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:06
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:35:48
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:34:38
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


# from builtins import str
# from builtins import str
import sys, os, time
import timeToMDCtime as MDCTIME
import QA_subscriber_management_restv3 as REST_UTIL
import qa_utils as QAUTILS
import data_container as MDC
import data_container_defs as MDCDEFS
import diameter_utils as DIAMU
import Setup_Env as SETUP
import customer_pricing as CUST_PRICING
import send_requests_utils

# Workhorse for this scenario
def parseMDCSendEvents(Config, users, options,testName='Default'):
    global V2inst
    extraAVP = {}
    
    # Set return to success (always plan for success :-)
    retCode=0
    
    # Step variable (four output only)
    step=0
    
    # =========================================================================================================================================================
    # Print what this step will do
    print(' Step ' + str(step) + ' - Process Input.')
    
    # Get key data from command line and/or config file
    (subscriberId, deviceId, externalId, deviceType, serviceId, offerId, generalDct)=QAUTILS.get_key_data(Config, options,os.getcwd(),users)
    sessionId = generalDct['sessionid']
    
    # Use current system time as starting point
    startTime = MDCTIME.getTime()
    
    # Scenario-specific static items - Only call if the function exists
    if hasattr(CUST_PRICING, "setupCustomerPricingData"):
	(extraAVP, serviceId, multSIMShare, custStatus, ratingGroup, deviceType, roamingPartnerIpAddress, zoneIpAddress) = CUST_PRICING.setupCustomerPricingData(options)
    else:
	# set locals to default values
        print('Using non-customer specific defaults')
	multSIMShare = 0
	custStatus = 10
	ratingGroup = 0
	roamingPartnerIpAddress = '1.2.3.4'
	zoneIpAddress = '1.2.3.4'
	extraAVP['SGSN-Address']='192.168.0.0'
    
    # Save subscriber MDC
    QAUTILS.saveMDC(deviceId, testName + '_' + str(step), queryType='PhoneNumber', queryTime = startTime)

    # =========================================================================================================================================================
    # Bump step counter
    step += 1
    
    # Print what this step will do
    print(' Step ' + str(step) + ' Send diameter event to device ' + deviceId + ' of type ' + serviceId + ' in the amount of ' + str(options.amount))

    ###### Check for pausing  #############
    QAUTILS.pauseCheck(options.pause)
    ######                    #############
    
    # Send in the request
    send_requests_utils.sendRangeRequest(int(deviceId), mbrCount=1, reqAmount=options.amount, usedAmount=options.amount,
        serviceId=serviceId, requestType='nointerim', ratingGroup=ratingGroup, extraAVP=extraAVP,
        startTime=startTime, sessionId=sessionId)

    # Save subscriber MDC
    QAUTILS.saveMDC(deviceId, testName + '_' + str(step), queryType='PhoneNumber', queryTime = startTime)
    
    # =========================================================================================================================================================
def main():
    global testErrorLogger
    global V2inst
    global testName

    # Path is always the current directory
    path = os.getcwd()

  # Setup the test name for this scenario
    testName = QAUTILS.getTestName(path)

    # Setup test
    (Config,users,options,args,V2inst,testErrorLogger)=QAUTILS.initializeTest(path)

    # Invoke event generation
    returnCode=parseMDCSendEvents(Config, users, options, testName)

    # Check for errors
    if not returnCode ==  0:
        testErrorLogger.printError(' main ==> scenario ' + testName + ' failed with returnCode=' + str(returnCode))

if __name__ ==  '__main__':
    main()

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

