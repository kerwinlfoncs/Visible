#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:41:18
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:37:02
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:22
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


import data_container as MDC
# Check if the data_container_defs.py needs to be re-created
import data_container_defs as MDCDEFS
import common_mdc as COMMON
import optparse
import os, string

xmlStatus=True
try:
    import xml_utils
except ImportError:
    xmlStatus=Flase

outputFile = ''

#-------------------------------------------------------------------------------
# Parse a task and (if configured) strip variable fields
#-------------------------------------------------------------------------------
def extractTask(mdc, stripFields):
    #
    # Write current task to a temporary file
    #
    global outputFile
    tmpTaskFileName = os.getcwd() + '/' + COMMON.resultsDir + '/current_task.txt' 
    tmpTaskFile = open(tmpTaskFileName, 'w', 0)
    print(mdc.printXml(), file=tmpTaskFile)
    tmpTaskFile.close()

    #
    # Strip variable fields from task being processed
    #
    tmpTask = open(tmpTaskFileName, 'r')
    lines = tmpTask.readlines()
    tmpTask.close()
    lines.append("</root>\n")
    lines.reverse()
    lines.append("<root>\n")
    lines.reverse()
    processedData = "".join([x for x in lines if x.strip() != ''])
    tmpTask = open(tmpTaskFileName, 'w')
    tmpTask.write(processedData)
    tmpTask.close()

    #excludeList = ['EndTime', 'CreatedTime', 'ModifiedTime', 'TriggerTime', 'ChrgInQueueId', 'GatewaySocketId',\
    #    'ObjectExternalId', 'TimeArray', 'TaskTime']
    #excludeList = ['EndTime', 'CreatedTime', 'ModifiedTime', 'ChrgInQueueId', 'GatewaySocketId', 'TimeArray', 'TaskTime']
    excludeList = []

    #for tasks set stripFields to false so that objectId is printed 
    stripFields = False

    if xmlStatus and stripFields:
        print(xml_utils.transformDoc(tmpTaskFileName, excludeList), file=outputFile)
    else:
        print(processedData, file=outputFile)

    return

#-------------------------------------------------------------------------------
# Output the scheduled tasks for each work order MDC
#-------------------------------------------------------------------------------
def extractTasks(mdc, stripFields):
    if mdc.descObj.containerKey == MDCDEFS.kMtxWorkOrderMsgMdcDesc.containerKey:
        actionList = mdc.getUsingKey(MDCDEFS.kMtxWorkOrderMsgTxnActionListFldKey)
    else:
        print("Error: Unexpected MDC type")
        return

    # Get the event list
    if actionList is None:
        return

    for action in actionList:
        if action.descObj.containerKey == MDCDEFS.kMtxTxnObjectActionDataMdcDesc.containerKey:
            if action.isPresent(MDCDEFS.kMtxTxnObjectActionDataObjectFldKey):
                object = action.getUsingKey(MDCDEFS.kMtxTxnObjectActionDataObjectFldKey)
                if object.descObj.containerKey == MDCDEFS.kMtxTaskObjectMdcDesc.containerKey:
                    extractTask(object, stripFields)

#-------------------------------------------------------------------------------
# Read each MDC in the stripped transaction log
#-------------------------------------------------------------------------------
def readCompactInput(inFile, stripFields):
    for line in inFile:
        line = line.rstrip('\n')
        if (line == ''):
            continue
        if (line.startswith('#')):
            continue

        mdc = MDC.readFromStr(line)
        if mdc == None:
            print("Error: Cannot parse input")
            return

        extractTasks(mdc, stripFields)

    return

def printTasks(testTag, stripFields = False):
    global outputFile

    path = os.getcwd()
    logFile = path + '/' + COMMON.resultsDir + '/tmpTasksLog'
    #logFile = path + '/my.log'

    if (not os.path.exists(logFile)):
        print('Error: The input file name (' + logFile + ') does not exist.')
        return -1

    inFile = open(logFile, 'r')

    outputFileName = path + '/' + COMMON.resultsDir + '/' + testTag + '_tasks'
    outputFile = open(outputFileName, 'w')

    readCompactInput(inFile, stripFields)

    inFile.close()
    outputFile.close()

    return 0
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

