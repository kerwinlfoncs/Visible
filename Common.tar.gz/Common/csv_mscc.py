#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Sat 2021-11-13T01:36:23
# @futurize --stage2 --no-diffs -n -w  : Sat 2021-11-13T01:36:23
#
# @futurize --stage1 --no-diffs -n -w  : Sat 2021-11-13T01:36:23
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

# SHOULD NOT USE!!  Adding a failing line here.
from __future__ import print_function
from __future__ import division
# from builtins import str
# from builtins import str
from past.utils import old_div
kef

import copy, os, sys
import os, sys
import csv_prim as PRIM
import csv_data as DATA
import csv_track as TRACK

# Define MSCC parameters that make up the MSCC test framework parameter
parameterNames = ['ratingGroup', 'msccServiceId', 'reqAmount', 'usedAmount', 'reportingReason', 'eventPass']

#==========================================================
def buildMsccData(ratingGroup, msccServiceId, reqAmount, usedAmount, reportingReason, eventPass):
        # Need to avoid putting "None" in there, as that's harder to get out from below...
        cmdStr = ''
        
        # Can't use exec() to dereference parameter names, so put inline here
        # Always add separator, even if nothing added
        if ratingGroup: cmdStr += str(ratingGroup)
        cmdStr += '/'
        
        if msccServiceId: cmdStr += str(msccServiceId)
        cmdStr += '/'
        
        if reqAmount: cmdStr += str(reqAmount)
        cmdStr += '/'
        
        if usedAmount: cmdStr += str(usedAmount)
        cmdStr += '/'
        
        if reportingReason: cmdStr += str(reportingReason)
        cmdStr += '/'
        
        if eventPass: cmdStr += str(eventPass)
        cmdStr += '/'
        
        # Build the entry, minus the last separator character
        multiMsccData = [(cmdStr[:-1])]

        return multiMsccData

#==========================================================
def separateMsccDataElement(msccIndividualData, request, tariffChangeUsage, lclDCT, eventPass, sessionId):
        # Probably a better way to do this, but it's late Saturday evening...
        _localDict = {}
        for j,parameter in enumerate(parameterNames):
                try:
                        # If nothing passed in, then set to None
                        if not msccIndividualData[j]:   value = 'None'
                        elif msccIndividualData[j].count(DATA.msccParamNameChar):
                                # This is parameter*value syntax
                                (parameter,value) = msccIndividualData[j].split(DATA.msccParamNameChar)
                                value = "'" + value + "'"
                        else:   value = "'" + msccIndividualData[j] + "'"

                        # Do the assignment
                        _localDict[parameter] = value
                except:
                        # Data not passed in.  Set parameter to None
                        _localDict[parameter] = None
        
        # Do assignments to keep local variable syntax (used to use exec() but can't in P3)
        ratingGroup     = _localDict['ratingGroup']
        msccServiceId   = _localDict['msccServiceId']
        reqAmount       = _localDict['reqAmount']
        usedAmount      = _localDict['usedAmount']
        reportingReason = _localDict['reportingReason']
        eventPass       = _localDict['eventPass']
        
        # Clear some of these (e.g. if init then no used, if term then no request).
        # Also make sure they're not None (need to be 0 to signal lower-level functions to skip).
        # Finally, if "x" set for used amount, change to -2 (need to wait for translations before checking session data).
        if request == 'initial': usedAmount = 0
        elif not usedAmount:     usedAmount = 0
        elif usedAmount.lower() == 'x':  usedAmount = '-2'

        if request == 'term':    reqAmount = 0
        elif not reqAmount:      reqAmount = 0

        # If mscc Service ID passed in, then set the flag
        if msccServiceId: incServiceId = True
        else:             incServiceId = False

        # OK; want to allow translations of these.  Regular translations occured a long time ago.
        # Save the dictionary
        saveLclDCT = copy.deepcopy(lclDCT)

        # Update saved dictionary with the parameters.
        # Don't lose the "None" items (i.e. can't blindly make them a string)
        for param in parameterNames: saveLclDCT[param] = _localDict[param]

        # Debug output
#       for param in parameterNames: print('Before translation: ' + param + ' = ' + str(saveLclDCT[param]))

        # Do name translations
        for parameter in DATA.parameterTranslate: PRIM.translateTextFromMapping(parameter, saveLclDCT)

        # Do unit translations
        for parameter in DATA.unitParameters: saveLclDCT[parameter] = PRIM.convertAmountsToIntegers(str(saveLclDCT[parameter]))

        # Extract saved values to locals
        ratingGroup     = saveLclDCT['ratingGroup']
        msccServiceId   = saveLclDCT['msccServiceId']
        reqAmount       = saveLclDCT['reqAmount']
        usedAmount      = saveLclDCT['usedAmount']
        reportingReason = saveLclDCT['reportingReason']
        eventPass       = saveLclDCT['eventPass']
        
        # Debug output
#       for param in parameterNames: print('After translation: ' + param + ' = ' + str(saveLclDCT[param]))

        # Want to support used unit value of "x", which means to use the granted amount.  It was changed to "-2" above.
        # Needed to wait until post-translations, as the rating group value may have been a string that was translated.
        if usedAmount == '-2':
                # Make sure the session exists
                if not TRACK.checkIfSessionTracked(sessionId, ratingGroup):
                        print('WARNING: used is supposed to ue the last granted amount, but there\'s no session for session ID/rating group ' + str(sessionId) + '/' + str(ratingGroup))
                        usedAmount = 0
                else:
                        usedAmount = TRACK.sessionGetValue(sessionId, ratingGroup, 'lastGrant')
                        print('MSCC - using last granted amount of ' + str(usedAmount))

        # Fix parameters that require non-None values
        if not usedAmount or str(usedAmount).lower() == 'none': saveLclDCT['usedAmount'] = usedAmount = '0'
        if not reqAmount  or str(reqAmount).lower()  == 'none': saveLclDCT['reqAmount']  = reqAmount = '0'

        # Debug output
#       for param in parameterNames: print(param + ' = ' + str(saveLclDCT[param]))

        # If time change parameter specified, then need to split usage between before and after
        usedDetails = []
        if tariffChangeUsage:
                if tariffChangeUsage != '3':
                        # Single value item
                        usedDetails.append([str(usedAmount), tariffChangeUsage])
                else:
                        # Need to split the used amount between before and after.
                        # For 5G issue (MTX-37081) put the after amount first.
                        usedDetails.append([str(old_div(int(usedAmount), 2)), '1'])
                        usedDetails.append([str(old_div(int(usedAmount), 2)), '0'])
        else:
                # Store non-list value
                usedDetails = usedAmount

        # Can't exec a return statement :-(.  Need to hard-code return parameter list.
        return (ratingGroup, msccServiceId, reqAmount, usedDetails, reportingReason, incServiceId, eventPass)

#==========================================================

