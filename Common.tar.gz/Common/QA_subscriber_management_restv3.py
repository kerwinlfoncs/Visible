#!/usr/bin/env python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:41:28
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:46
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:36
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================



# from builtins import str
# from builtins import str
global SUBMAN
global restVersion
global savedRestVersion
global savedRESTInst
subUrl = 'subscriber'

import common_mdc as COMMON
import timeToMDCtime as MDCTIME
import qa_mdc_defs as QA_MDCDEFS
import qa_utils as QAUTILS
import os
import csv_data as CSV

# Restore version
#====================================================================
def restoreVersion(RESTInst):
        global restVersion
        global savedRestVersion
        global savedRESTInst
        
        # Debug output
        print('\n\nSwitching back from ' + restVersion + ' to ' + savedRestVersion)
        
        # Close the connection (if supported)
        try:
                RESTInst.closeConnection()
        except: pass
        
        # Restore values
        restVersion = savedRestVersion
        
        # Set import to the right file
        setVersion(restVersion)
        
        return savedRESTInst
        
# Switch version
#====================================================================
def switchVersion(RESTInst, version):
        global restVersion
        global savedRestVersion
        global savedRESTInst
        
        # Debug output
        print('Switching from ' + restVersion + ' to ' + version)
        
        # Save values
        savedRestVersion = restVersion
        savedRESTInst = RESTInst
        
        # Set to MDC
        restVersion = version
        
        # Set import to the right file
        setVersion(restVersion)
        
        # Get new RESTInst
        RESTInst = QAUTILS.getSubscInterface()
        
        return RESTInst
        
# Determines whether to delegate to MDC level code or through REST
#====================================================================
def setVersion(version, urlPlus = None):
    global SUBMAN
    global JSON
    global restVersion
    global urlPrefix
    global fileType
    global overrideURL
    global overrideOperations
    
    # Set version
    if version == 'MDC' or version == 'mdc':
        import mdcV3 as SUBMAN
        restVersion = "MDC"
    elif version == 'REST' or version == 'rest':
        import restV3 as SUBMAN
        SUBMAN.templates= os.getenv("QADIR") + '/Common/templates/'
        restVersion = "REST"
        urlPrefix = "v3"
        fileType = ".v3"
    elif version == 'JSON' or version == 'json':
        import rest_json as SUBMAN
        SUBMAN.templates= os.getenv("QADIR") + '/Common/templates/'
        restVersion = "JSON"
        urlPrefix = "json"
        fileType = ".json"
    # Added openapi option - in progress
    elif version == 'OPENAPI' or version == 'openapi':
        import restV3 as SUBMAN
        SUBMAN.templates= os.getenv("QADIR") + '/Common/templates/'
        restVersion = "OPENAPI"
        urlPrefix = "openapi"
        fileType = ".json"
    # Added xjson to enable some apis to use restV3.py instead of rest_json.py
    elif version == 'xJSON' or version == 'xjson':
        import restV3 as SUBMAN
        SUBMAN.templates= os.getenv("QADIR") + '/Common/templates/'
        restVersion = "JSON"
        urlPrefix = "json"
        fileType = ".json"
    else:
        restVersion = "JAVA"
        import javaV3 as SUBMAN
    
    # If URL defined, set the global
    if urlPlus:
        url = urlPlus.split(',')[0]
        print('Setting custom URL "' + url + '"')
        CSV.overrideURL = url
        
        # See which operations were specified
        if len(urlPlus.split(',')) > 1:
                CSV.overrideOperations = urlPlus.split(',')[1].split('@')
                print('overrideOperations = ' + str(CSV.overrideOperations))

#=============================================================
def setSubUrl(url = 'subscriber'):
    global subUrl
    if restVersion == "OPENAPI":
        url = 'subscription'
    subUrl = url
        
#====================================================================
def getDeviceOID(V3inst=0, queryValue=None, queryType='ExternalId', now=None):
        return SUBMAN.getDeviceOID(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)

#====================================================================
def getUserOID(V3inst=0, queryValue=None, queryType='ExternalId', now=None):
        return SUBMAN.getUserOID(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)

#====================================================================
def getSubscriptionOID(V3inst=0, queryValue=None, queryType='ExternalId', now=None):
        return SUBMAN.getSubscriptionOID(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)

#====================================================================
def getSubscriberOID(V3inst=0, queryValue=None, queryType='ExternalId', now=None):
        return SUBMAN.getSubscriberOID(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)

#====================================================================
def getGroupOID(V3inst=0, queryValue=None, queryType='ExternalId', now=None):
        return SUBMAN.getGroupOID(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)

#====================================================================
def importSubscriberBalanceValue(V3inst=None, queryType='ExternalId', externalId=None, resourceId=None,
           amount=None, startTime=None, createOnDemand=True, now=None, eventPass=True, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)
        
    # Invoke SUBMAN API
    return SUBMAN.importSubscriberBalanceValue(V3inst=V3inst, queryType=queryType, externalId=externalId, resourceId=resourceId,
            amount=amount, startTime=startTime, createOnDemand=createOnDemand, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#====================================================================
def createUserAndSubscription(V3inst, 
        # User
        userId=None, userExternalId=None, firstName=None, lastName=None,
        contactEmail=None, contactPhoneNumber=None, contactPushTokenList=None, notificationPreference=None,
        language=None, userAttr=None,  userStatus=None, userApiEventData=None,
        # Subscription
        subExternalId=None, subStatus=None, timeZone=None, billingCycle=None, dateOffset=None,
        taxStatus=None, taxCertificate=None, taxLocation=None, glCenter=None, name=None, subAttr=None,
        subApiEventData=None, customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None, 
        # Role
        rolesExternalIds=None, rolesPricingIds=None,
        now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.createUserAndSubscription(V3inst=V3inst,
        # User
        userId=userId, userExternalId=userExternalId, firstName=firstName, lastName=lastName,
        contactEmail=contactEmail, contactPhoneNumber=contactPhoneNumber,
        contactPushTokenList=contactPushTokenList, notificationPreference=notificationPreference,
        language=language, userAttr=userAttr, userStatus=userStatus, userApiEventData=userApiEventData,
        # Subscription
        subExternalId=subExternalId, subStatus=subStatus, timeZone=timeZone, billingCycle=billingCycle,
        dateOffset=dateOffset, taxStatus=taxStatus, taxCertificate=taxCertificate, taxLocation=taxLocation,
        glCenter=glCenter, name=name, subAttr=subAttr, subApiEventData=subApiEventData,
        #US Tax
        customerType=customerType, serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId, exemptionCodeList=exemptionCodeList,
        # Role
        rolesExternalIds=rolesExternalIds, rolesPricingIds=rolesPricingIds,
        #
        now=now, routingType=routingType, routingValue=routingValue,
        executeMode=executeMode, eventPass=eventPass)

#====================================================================
def createSubscription(V3inst, externalId=None, status=None, timeZone=None, name=None, billingCycle=None, dateOffset=None, 
        taxStatus=None, taxCertificate=None, taxLocation=None, glCenter=None, attr=None, apiEventData=None,
        now=None, routingType=None, routingValue=None, customerType=None, serviceAddress=None,
        npa=None, nxx=None, tenantId=None, exemptionCodeList=None, executeMode=None, eventPass=True, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.createSubscription(V3inst=V3inst, externalId=externalId, status=status, timeZone=timeZone, name=name, billingCycle=billingCycle,
        dateOffset=dateOffset, taxStatus=taxStatus, taxCertificate=taxCertificate, taxLocation=taxLocation, glCenter=glCenter, 
        attr=attr, apiEventData=apiEventData, now=now, routingType=routingType, routingValue=routingValue, customerType=customerType, 
        serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId, exemptionCodeList=exemptionCodeList, executeMode=executeMode, 
        eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def querySubscription(V3inst, queryValue, queryType='ExternalId', querySize=None,
                      routingType=None, routingValue=None, eventPass=True, now=None, useResponseSubscriptionTransformer=False, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.querySubscription(V3inst=V3inst, queryValue=queryValue, queryType=queryType, querySize=querySize,
        routingType=routingType, routingValue=routingValue, eventPass=eventPass, now=now, useResponseSubscriptionTransformer=useResponseSubscriptionTransformer, multiRequestBuild=multiRequestBuild)

#====================================================================
def modifySubscription(V3inst, queryValue=None, queryType='ExternalId', externalId=None, status=None, timeZone=None, name=None, 
        billingCycle=None, dateOffset=None, immediateChange=None, billingCycleDisabled=None,
        attr=None, taxStatus=None, taxCertificate=None, taxLocation=None, glCenter=None, lastActivityUpdateTime=None,
        currentPaymentTokenResourceId=None, sysPaymentTokenResourceId=None, routingType=None, routingValue=None,
        apiEventData=None, customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.modifySubscription(V3inst=V3inst, queryValue=queryValue, queryType=queryType, externalId=externalId, status=status, timeZone=timeZone, name=name, 
        billingCycle=billingCycle, dateOffset=dateOffset, immediateChange=immediateChange, billingCycleDisabled=billingCycleDisabled,
        attr=attr, taxStatus=taxStatus, taxCertificate=taxCertificate, taxLocation=taxLocation, glCenter=glCenter,
        lastActivityUpdateTime=lastActivityUpdateTime, currentPaymentTokenResourceId=currentPaymentTokenResourceId,
        sysPaymentTokenResourceId=sysPaymentTokenResourceId, routingType=routingType, routingValue=routingValue, now=now, executeMode=executeMode,
        apiEventData=apiEventData, customerType=customerType, serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId, 
        exemptionCodeList=exemptionCodeList, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#====================================================================
def deleteSubscription(V3inst, queryValue=None, queryType='ExternalId', deleteSession=False, deleteDevices=False,
        now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True,
        apiEventData=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.deleteSubscription(V3inst=V3inst, queryValue=queryValue, queryType=queryType, deleteSession=deleteSession, 
        deleteDevices=deleteDevices, now=now, routingType=routingType, routingValue=routingValue, executeMode=executeMode, 
        eventPass=eventPass, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

#====================================================================
def createUser(V3inst, userId=None, externalId=None, firstName=None, lastName=None,
        contactEmail=None, contactPhoneNumber=None, contactPushTokenList=None, notificationPreference=None,
        language=None, attr=None,  status=None, apiEventData=None, now=None, routingType=None, routingValue=None, executeMode=None,
        tenantId=None, eventPass=True, multiRequestBuild=None, timeZone=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.createUser(V3inst=V3inst, userId=userId, externalId=externalId,
        firstName=firstName, lastName=lastName, contactEmail=contactEmail, contactPhoneNumber=contactPhoneNumber,
        contactPushTokenList=contactPushTokenList, notificationPreference=notificationPreference,
        language=language, attr=attr, status=status, apiEventData=apiEventData, now=now, routingType=routingType, routingValue=routingValue,
        tenantId=tenantId, executeMode=executeMode, eventPass=eventPass, multiRequestBuild=multiRequestBuild, timeZone=timeZone)

#=============================================================
def queryUser(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None, routingType=None, routingValue=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.queryUser(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
                            routingType=routingType, routingValue=routingValue, eventPass=eventPass, now=now, multiRequestBuild=multiRequestBuild)

#====================================================================
def modifyUser(V3inst, queryValue=None, queryType='ExternalId', userId=None, externalId=None, firstName=None, lastName=None,
        contactEmail=None, contactPhoneNumber=None, contactPushTokenList=None, notificationPreference=None,
        language=None, attr=None, status=None, now=None, routingType=None, routingValue=None, executeMode=None,
        lastActivityUpdateTime=None, tenantId=None, apiEventData=None, eventPass=True, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.modifyUser(V3inst=V3inst, queryValue=queryValue, queryType=queryType, userId=userId, externalId=externalId,
        firstName=firstName, lastName=lastName, contactEmail=contactEmail, contactPhoneNumber=contactPhoneNumber,
        contactPushTokenList=contactPushTokenList, notificationPreference=notificationPreference,
        language=language, attr=attr, status=status, routingType=routingType, routingValue=routingValue, tenantId=tenantId, now=now,
        lastActivityUpdateTime=lastActivityUpdateTime, apiEventData=apiEventData, executeMode=executeMode, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#====================================================================
def modifyUserAndAuthData(V3inst, queryValue=None, queryType='ExternalId', userId=None, externalId=None, firstName=None, lastName=None,
        contactEmail=None, contactPhoneNumber=None, contactPushTokenList=None, notificationPreference=None,
        language=None, attr=None, status=None, loginId=None, password=None ,now=None,
        routingType=None, routingValue=None, executeMode=None, eventPass=True, 
        apiEventData=None, userApiEventData=None, authApiEventData=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.modifyUserAndAuthData(V3inst=V3inst, queryValue=queryValue, queryType=queryType, userId=userId, externalId=externalId,
        firstName=firstName, lastName=lastName, contactEmail=contactEmail, contactPhoneNumber=contactPhoneNumber,
        contactPushTokenList=contactPushTokenList, notificationPreference=notificationPreference,
        language=language, attr=attr, status=status, loginId=loginId, password=password,
        routingType=routingType, routingValue=routingValue, now=now, apiEventData=apiEventData,
        userApiEventData=userApiEventData, authApiEventData=authApiEventData,
        executeMode=executeMode, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#====================================================================
def deleteUser(V3inst, queryValue=None, queryType='ExternalId', now=None, routingType=None, routingValue=None,
               deleteSubscription=None, deleteDevices=None, deleteSession=None,
               executeMode=None, eventPass=True, apiEventData=None, multiRequestBuild=None, removeExplicitMembership=False):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.deleteUser(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, routingType=routingType,
        deleteSubscription=deleteSubscription, deleteDevices=deleteDevices, deleteSession=deleteSession,
        routingValue=routingValue, executeMode=executeMode, eventPass=eventPass, apiEventData=apiEventData,
        multiRequestBuild=multiRequestBuild, removeExplicitMembership=removeExplicitMembership)

#====================================================================
def queryUserAuthData(V3inst, queryValue=None, queryType='ExternalId', now=None,
        routingType=None, routingValue=None, executeMode=None, eventPass=True, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.userQueryAuthData(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        now=now, routingType=routingType, routingValue=routingValue, executeMode=executeMode, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#====================================================================
def verifyUserAuthData(V3inst, queryValue=None, queryType='ExternalId', password=None, now=None,
        routingType=None, routingValue=None, executeMode=None, eventPass=True, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.userVerifyAuthData(V3inst=V3inst, queryValue=queryValue, queryType=queryType, password=password,
        now=now, routingType=routingType, routingValue=routingValue, executeMode=executeMode, eventPass=eventPass,
        multiRequestBuild=multiRequestBuild)

#====================================================================
def modifyUserAuthData(V3inst, queryValue=None, queryType='ExternalId', loginId=None, password=None, now=None,
        routingType=None, routingValue=None, executeMode=None, eventPass=True, isService=False,
        apiEventData=None,  multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.userModifyAuthData(V3inst=V3inst, queryValue=queryValue, queryType=queryType, loginId=loginId, password=password,
        now=now, routingType=routingType, routingValue=routingValue, executeMode=executeMode, eventPass=eventPass,
        isService=isService, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

#====================================================================
def modifyUserPassword(V3inst, queryValue=None, queryType='ExternalId', oldPassword=None, newPassword=None, now=None,
        routingType=None, routingValue=None, executeMode=None, eventPass=True, apiEventData=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.userModifyPassword(V3inst=V3inst, queryValue=queryValue, queryType=queryType, oldPassword=oldPassword, newPassword=newPassword, 
        now=now, routingType=routingType, routingValue=routingValue, executeMode=executeMode, eventPass=eventPass,
        apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)
#====================================================================
def userAddGroup(V3inst, userQueryValue=None, userQueryType='ObjectId', grpQueryValue=None, grpQueryType='ObjectId',
        rolesPricingIds=None, rolesExternalIds=None, now=None, routingType=None, routingValue=None, executeMode=None,
        eventPass=True, apiEventData=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.userAddGroup(V3inst=V3inst, userQueryValue=userQueryValue, userQueryType=userQueryType,
        grpQueryValue=grpQueryValue, grpQueryType=grpQueryType, now=now, routingType=routingType, routingValue=routingValue,
        rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds,
        executeMode=executeMode, eventPass=eventPass, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

#====================================================================
def userModifyGroup(V3inst, userQueryValue=None, userQueryType='ObjectId', grpQueryValue=None, grpQueryType='ObjectId',
        rolesPricingIds=None, rolesExternalIds=None, now=None, routingType=None, routingValue=None, executeMode=None,
        eventPass=True, apiEventData=None, multiRequestBuild=None, removeExplicitMembership=False):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.userModifyGroup(V3inst=V3inst, userQueryValue=userQueryValue, userQueryType=userQueryType,
        grpQueryValue=grpQueryValue, grpQueryType=grpQueryType, now=now, routingType=routingType, routingValue=routingValue,
        rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds,
        executeMode=executeMode, eventPass=eventPass, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild, removeExplicitMembership=removeExplicitMembership)

#====================================================================
def userRemoveGroup(V3inst, userQueryValue=None, userQueryType='ObjectId', grpQueryValue=None, grpQueryType='ObjectId',
        now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True, 
        apiEventData=None, multiRequestBuild=None, removeExplicitMembership=False):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.userRemoveGroup(V3inst=V3inst, userQueryValue=userQueryValue, userQueryType=userQueryType,
        grpQueryValue=grpQueryValue, grpQueryType=grpQueryType, now=now, routingType=routingType, routingValue=routingValue,
        executeMode=executeMode, eventPass=eventPass, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild, removeExplicitMembership=removeExplicitMembership)

#====================================================================
def userAddSubscription(V3inst, userQueryValue=None, userQueryType='ObjectId', subQueryValue=None, subQueryType='ObjectId',
        rolesPricingIds=None, rolesExternalIds=None, now=None, routingType=None, routingValue=None, executeMode=None,
        eventPass=True, apiEventData=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.userAddSubscription(V3inst=V3inst, userQueryValue=userQueryValue, userQueryType=userQueryType,
        subQueryValue=subQueryValue, subQueryType=subQueryType, rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds,
        now=now, routingType=routingType, routingValue=routingValue, executeMode=executeMode, eventPass=eventPass,
        apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

#====================================================================
def userModifySubscription(V3inst, userQueryValue=None, userQueryType='ObjectId', subQueryValue=None, subQueryType='ObjectId',
        rolesPricingIds=None, rolesExternalIds=None, now=None, routingType=None, routingValue=None, executeMode=None,
        eventPass=True, apiEventData=None, multiRequestBuild=None, removeExplicitMembership=False):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.userModifySubscription(V3inst=V3inst, userQueryValue=userQueryValue, userQueryType=userQueryType,
        subQueryValue=subQueryValue, subQueryType=subQueryType, now=now, routingType=routingType, routingValue=routingValue,
        rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds,
        executeMode=executeMode, eventPass=eventPass, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild, removeExplicitMembership=removeExplicitMembership)

#====================================================================
def userRemoveSubscription(V3inst, userQueryValue=None, userQueryType='ObjectId', subQueryValue=None, subQueryType='ObjectId',
        now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True, 
        apiEventData=None, multiRequestBuild=None, removeExplicitMembership=False):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.userRemoveSubscription(V3inst=V3inst, userQueryValue=userQueryValue, userQueryType=userQueryType,
        subQueryValue=subQueryValue, subQueryType=subQueryType, now=now, routingType=routingType, routingValue=routingValue,
        executeMode=executeMode, eventPass=eventPass, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild, removeExplicitMembership=removeExplicitMembership)

#===============================================================================
def queryUserEvent(V3inst, queryValue, queryType='ExternalId', querySize=None, queryCursor=None,
    eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypeStringArray=None, now=None, eventPass=True):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.queryUserEvent(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
                    querySize=querySize, queryCursor=queryCursor, eventTimeLowerBound=eventTimeLowerBound,
                    eventTimeUpperBound=eventTimeUpperBound, eventTypeStringArray=eventTypeStringArray, now=now, eventPass=eventPass)

#====================================================================
def groupAddUser(V3inst, userQueryValue=None, userQueryType='ObjectId', grpQueryValue=None, grpQueryType='ObjectId',
        rolesPricingIds=None, rolesExternalIds=None, now=None, routingType=None, routingValue=None, executeMode=None,
        eventPass=True, apiEventData=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupAddUser(V3inst=V3inst, userQueryValue=userQueryValue, userQueryType=userQueryType,
        grpQueryValue=grpQueryValue, grpQueryType=grpQueryType, now=now, routingType=routingType, routingValue=routingValue,
        rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds,
        executeMode=executeMode, eventPass=eventPass, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

#====================================================================
def groupModifyUser(V3inst, userQueryValue=None, userQueryType='ObjectId', grpQueryValue=None, grpQueryType='ObjectId',
        rolesPricingIds=None, rolesExternalIds=None, now=None, routingType=None, routingValue=None, executeMode=None,
        eventPass=True, apiEventData=None, multiRequestBuild=None, removeExplicitMembership=False):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupModifyUser(V3inst=V3inst, userQueryValue=userQueryValue, userQueryType=userQueryType,
        grpQueryValue=grpQueryValue, grpQueryType=grpQueryType, now=now, routingType=routingType, routingValue=routingValue,
        rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds,
        executeMode=executeMode, eventPass=eventPass, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild, removeExplicitMembership=removeExplicitMembership)

#====================================================================
def groupRemoveUser(V3inst, userQueryValue=None, userQueryType='ObjectId', grpQueryValue=None, grpQueryType='ObjectId',
        now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True,
        apiEventData=None, multiRequestBuild=None, removeExplicitMembership=False):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupRemoveUser(V3inst=V3inst, userQueryValue=userQueryValue, userQueryType=userQueryType,
        grpQueryValue=grpQueryValue, grpQueryType=grpQueryType, now=now, routingType=routingType, routingValue=routingValue,
        executeMode=executeMode, eventPass=eventPass, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild, removeExplicitMembership=removeExplicitMembership)

#====================================================================
def queryGroupUsers(V3inst, queryValue=None, queryType='ObjectId', returnExternalId=None, querySize=None, queryCursor=None,
        routingType=None, routingValue=None, eventPass=True, now=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.queryGroupUsers(V3inst=V3inst, queryValue=queryValue, queryType=queryType, returnExternalId=returnExternalId,
        querySize=querySize, queryCursor=queryCursor, routingType=routingType, routingValue=routingValue, now=now,
        multiRequestBuild=multiRequestBuild)

#====================================================================
def queryUserGroups(V3inst, queryValue=None, queryType='ObjectId', returnExternalId=None, querySize=None, queryCursor=None,
        routingType=None, routingValue=None, eventPass=True, now=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.queryUserGroups(V3inst=V3inst, queryValue=queryValue, queryType=queryType, returnExternalId=returnExternalId,
        querySize=querySize, queryCursor=queryCursor, routingType=routingType, routingValue=routingValue, now=now,
        multiRequestBuild=multiRequestBuild)

#====================================================================
def queryUserSubscriptions(V3inst, queryValue=None, queryType='ObjectId', returnExternalId=None, querySize=None, queryCursor=None,
        routingType=None, routingValue=None, eventPass=True, now=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.queryUserSubscriptions(V3inst=V3inst, queryValue=queryValue, queryType=queryType, returnExternalId=returnExternalId,
        querySize=querySize, queryCursor=queryCursor, routingType=routingType, routingValue=routingValue, now=now,
        multiRequestBuild=multiRequestBuild)

#====================================================================
def querySubscriberUsers(V3inst, queryValue=None, queryType='ObjectId', returnExternalId=None, querySize=None, queryCursor=None,
        routingType=None, routingValue=None, eventPass=True, now=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.querySubscriberUsers(V3inst=V3inst, queryValue=queryValue, queryType=queryType, returnExternalId=returnExternalId,
        querySize=querySize, queryCursor=queryCursor, routingType=routingType, routingValue=routingValue, now=now,
        multiRequestBuild=multiRequestBuild)

#====================================================================
def createSubscriber(V3inst, externalId=None, now=None, payload=None, billingCycle=None, eventPass=True,
        firstName=None, lastName=None, contactEmail=None, contactPhoneNumber=None, contactPushTokenList=None, notificationPreference=None,
        timeZone=None, attr=None,  status=None, taxStatus=None, taxCertificate=None, taxLocation=None, apiEventData=None, 
        language=None, dateOffset=None, glCenter=None, name=None, routingType=None, routingValue=None, customerType=None, serviceAddress=None, 
        npa=None, nxx=None, tenantId=None, exemptionCodeList=None, executeMode=None, multiRequestBuild=None, apiEventSecurityInfo=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.createSubscriber(V3inst=V3inst, externalId=externalId, now=now, payload=payload,
        billingCycle=billingCycle, eventPass=eventPass, firstName=firstName, lastName=lastName, 
        contactEmail=contactEmail, contactPhoneNumber=contactPhoneNumber, contactPushTokenList=contactPushTokenList,  notificationPreference=notificationPreference,
        timeZone=timeZone, attr=attr,  status=status, taxStatus=taxStatus, taxCertificate=taxCertificate, taxLocation=taxLocation,
        language=language, dateOffset=dateOffset, glCenter=glCenter, name=name, apiEventData=apiEventData,
        routingType=routingType, routingValue=routingValue, customerType=customerType, serviceAddress=serviceAddress, npa=npa, nxx=nxx, 
        tenantId=tenantId, exemptionCodeList=exemptionCodeList, executeMode=executeMode, multiRequestBuild=multiRequestBuild, apiEventSecurityInfo=apiEventSecurityInfo)

#====================================================================
def deleteUserSubscription(V3inst, queryValue=None, queryType='ExternalId', subQueryValue=None, subQueryType='ExternalId',
        now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True, apiEventData=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.deleteUserSubscription(V3inst, queryValue=queryValue, queryType=queryType, subQueryValue=subQueryValue,
        subQueryType=subQueryType, now=now, routingType=routingType, routingValue=routingValue, executeMode=executeMode,
        eventPass=eventPass, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

#=================================================================
def createUserSubscription(V3inst=0, queryValue=None, queryType=None,

    # Subscription
    subExternalId=None, subStatus=None, timeZone=None, billingCycle=None, dateOffset=None,
    taxStatus=None, taxCertificate=None, taxLocation=None, glCenter=None, name=None, subAttr=None,
    subApiEventData=None,
    #USTax
    customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
    # Role
    rolesExternalIds=None, rolesPricingIds=None,
    #
    now=None, routingType=None, routingValue=None, executeMode=None, apiEventData=None, eventPass=True):


    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.createUserSubscription(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
       # Subscription
       subExternalId=subExternalId, subStatus=subStatus, timeZone=timeZone, billingCycle=billingCycle, dateOffset=dateOffset,
       taxStatus=taxStatus, taxCertificate=taxCertificate, taxLocation=taxLocation, glCenter=glCenter, name=name, subAttr=subAttr,
       subApiEventData=subApiEventData,
       #USTax
       customerType=customerType, serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId, exemptionCodeList=exemptionCodeList,
       # Role
       rolesExternalIds=rolesExternalIds, rolesPricingIds=subAttr,
       #
       now=now, routingType=routingType, routingValue=routingType, executeMode=executeMode,
       apiEventData=apiEventData, eventPass=eventPass)

#Extended REST service for subscriberCreateDeviceAndOffer and CreateSubscriberAndDevice
#If queryValue not populated we use CreateSubscriberAndDevice otherwise subscriberCreateDeviceAndOffer
#======================================================================================
def createSubscriberAndDevice(V3inst, externalId=None, queryValue=None, queryType='ExternalId',
        # User
        userId=None, userExternalId=None, firstName=None, lastName=None,
        contactEmail=None, contactPhoneNumber=None, contactPushTokenList=None, notificationPreference=None,
        language=None, userAttr=None,  userStatus=None, userApiEventData=None,
        # Subscription
        subStatus=None, timeZone=None, billingCycle = None, dateOffset=None, subAttr = None,
        taxStatus=None, taxCertificate=None, taxLocation=None, glCenter=None, payload=None,
        subApiEventData=None,
        # Role
        rolesExternalIds=None, rolesPricingIds=None,
        # Device
        deviceId=None, deviceType=1, devAttr=None, accessNumbers=None, devStatus=None, deviceExternalId=None,
        devApiEventData=None,
        # PaymentMethod
        paymentGatewayId=None, paymentGatewayUserId=None, paymentGatewayOneTimeToken=None,
        paymentAttr=None, paymentName=None, paymentType=None, paymentIsDefault=None, paymentIsSysDefault=None,
        # Recharge Schedule
        firstRechargeTime=None, rechargePeriodType=None, rechargePeriodCoef=None, rechargeCycleTimeOfDay=None,
        rechargeCycleOffset=None, rechargeAmount=None, rechargeEndTimeExtensionOffsetUnit=None,
        rechargeEndTimeExtensionOffset=None, scheduledRechargeNotificationProfileId=None,
        # Offer
        offerId=0, catalogItemId=None, offerStartTime=None, offerEndTime=None, offerIsExternal=False, offerAttr=None,
        endTimeRelativeOffset=None, endTimeRelativeOffsetUnit=None, chargeMethod=None,
        downPayment=None, isTargetResource=None, useTargetResource=None, isRecurringFailureAllowed=None,
        chargePurchaseProrationType=None, grantPurchaseProrationType=None, reason=None, info=None, offerApiEventData=None,
        paymentDueDate=None, parameterList=None, offerStatusValue=None, offerLifecycleProfileId=None,
        # Offer Activation
        preActiveState=None, activationExpirationTime=None, activationExpirationRelativeOffsetUnit=None, activationExpirationRelativeOffset=None,
        autoActivationCycleResourceId=None, autoActivationTime=None, autoActivationRelativeOffsetUnit=None, autoActivationRelativeOffset=None,
        isPendingActivationAllowed=None,
        # Offer Cycle
        offerCycleType=None, offerCycleOffset=None, offerCycleResourceId=None, offerCycleStartTime=None,
        #
        apiEventData=None, now=None, eventPass=True, routingType=None, routingValue=None, purchaseInfo=False,
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        executeMode=None, multiRequestBuild=None, eligibilityCheck=None, geoData=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)
    if offerStartTime is not None:
        offerStartTime = MDCTIME.convertTime(offerStartTime, restVersion=restVersion)
    if offerEndTime is not None:
        offerEndTime = MDCTIME.convertTime(offerEndTime, restVersion=restVersion)

    return SUBMAN.createSubscriberAndDevice(V3inst=V3inst, externalId=externalId, queryValue=queryValue, queryType=queryType,
        # User
        userId=userId, userExternalId=userExternalId, firstName=firstName, lastName=lastName,
        contactEmail=contactEmail, contactPhoneNumber=contactPhoneNumber, contactPushTokenList=contactPushTokenList,
        notificationPreference=notificationPreference, language=language, userAttr=userAttr,  userStatus=userStatus,
        userApiEventData=userApiEventData,
        # Subscriber
        subStatus=subStatus, timeZone=timeZone, billingCycle=billingCycle, dateOffset=dateOffset, subAttr=subAttr,
        taxStatus=taxStatus, taxCertificate=taxCertificate, taxLocation=taxLocation, glCenter=glCenter, payload=payload,
        subApiEventData=subApiEventData,
        # Roles    
        rolesExternalIds=rolesExternalIds, rolesPricingIds=rolesPricingIds,
        # Device
        deviceId=deviceId, deviceType=deviceType, devAttr=devAttr, accessNumbers=accessNumbers, devStatus=devStatus,
        deviceExternalId=deviceExternalId, devApiEventData=devApiEventData,
        # PaymentMethod
        paymentGatewayId=paymentGatewayId, paymentGatewayUserId=paymentGatewayUserId, paymentGatewayOneTimeToken=paymentGatewayOneTimeToken,
        paymentAttr=paymentAttr, paymentName=paymentName, paymentType=paymentType,
        paymentIsDefault=paymentIsDefault, paymentIsSysDefault=paymentIsSysDefault,
        # Recharge Schedule
        firstRechargeTime=firstRechargeTime, rechargePeriodType=rechargePeriodType, rechargePeriodCoef=rechargePeriodCoef,
        rechargeCycleTimeOfDay=rechargeCycleTimeOfDay, rechargeCycleOffset=rechargeCycleOffset, rechargeAmount=rechargeAmount,
        rechargeEndTimeExtensionOffsetUnit=rechargeEndTimeExtensionOffsetUnit, rechargeEndTimeExtensionOffset=rechargeEndTimeExtensionOffset,
        scheduledRechargeNotificationProfileId=scheduledRechargeNotificationProfileId,
        # Offer
        chargeMethod=chargeMethod,
        offerId=offerId, catalogItemId=catalogItemId, offerStartTime=offerStartTime, offerEndTime=offerEndTime, offerIsExternal=offerIsExternal,
        offerAttr=offerAttr, endTimeRelativeOffset=endTimeRelativeOffset, endTimeRelativeOffsetUnit=endTimeRelativeOffsetUnit,
        downPayment=downPayment, isTargetResource=isTargetResource, useTargetResource=useTargetResource,
        isRecurringFailureAllowed=isRecurringFailureAllowed, chargePurchaseProrationType=chargePurchaseProrationType,
        grantPurchaseProrationType=grantPurchaseProrationType, reason=reason, info=info, offerApiEventData=offerApiEventData,
        paymentDueDate=paymentDueDate, parameterList=parameterList, offerStatusValue=offerStatusValue, offerLifecycleProfileId=offerLifecycleProfileId,
        # Offer Activation
        preActiveState=preActiveState, activationExpirationTime=activationExpirationTime,
        activationExpirationRelativeOffsetUnit=activationExpirationRelativeOffsetUnit,
        activationExpirationRelativeOffset=activationExpirationRelativeOffset,
        autoActivationCycleResourceId=autoActivationCycleResourceId, autoActivationTime=autoActivationTime,
        autoActivationRelativeOffsetUnit=autoActivationRelativeOffsetUnit, autoActivationRelativeOffset=autoActivationRelativeOffset,
        isPendingActivationAllowed=isPendingActivationAllowed,
        # Offer Cycle
        offerCycleType=offerCycleType, offerCycleOffset=offerCycleOffset, offerCycleResourceId=offerCycleResourceId, offerCycleStartTime=offerCycleStartTime,
        #
        apiEventData=apiEventData, now=now, eventPass=eventPass, routingType=routingType, routingValue=routingValue, purchaseInfo=purchaseInfo,
        #USTax
        customerType=customerType, serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId, exemptionCodeList=exemptionCodeList,
        executeMode=executeMode, multiRequestBuild=multiRequestBuild, eligibilityCheck=eligibilityCheck, geoData=geoData)

# Wrapper for creating subscriber, and optionally creating an associated device and purchasing offer
#====================================================================
def addSubscriber(V3inst, externalId = None, deviceId = None, deviceType = 1, 
        offerId = 0, catalogItemId=None, allDevices = True, offerStartTime = None, 
        offerEndTime = None, serviceId = None, payload = None, containerType = None,
        subAttr = None, devAttr = None, billingCycle = None, eventPass=True, 
        firstName=None, lastName=None, contactEmail=None, contactPhoneNumber=None, 
        contactPushTokenList=None,   notificationPreference=None, timeZone=None,
        chargeMethod=None, paymentMethodResourceId=None, paymentGatewayId=None, paymentGatewayOneTimeToken=None, 
        paymentGatewayUserId=None,
        now=None, accessNumbers=None, subStatus=None, devStatus=None,taxStatus=None, taxCertificate=None, taxLocation=None,
        language=None, offerIsExternal=False, imsi=0, offerAttr = None, dateOffset=None, glCenter=None, name=None, 
        noTouch=False, devOid=None, devQueryType = 'PhoneNumber', routingType=None, routingValue=None, preActiveState=None,
        autoActivationTime=None, autoActivationRelativeOffsetUnit=None, autoActivationRelativeOffset=None, autoActivationCycleResourceId=None,
        activationExpirationTime=None, activationExpirationRelativeOffsetUnit=None, activationExpirationRelativeOffset=None, endTimeRelativeOffset=None,
        endTimeRelativeOffsetUnit=None, offerCycleType=None, offerCycleOffset=None, offerCycleStartTime=None, chargePurchaseProrationType=None,
        isPendingActivationAllowed=None, offerLifecycleProfileId=None,
        subApiEventData=None, devApiEventData=None, offerApiEventData=None, parameterList=None, offerStatusValue=None,
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        paymentDueDate=None, grantPurchaseProrationType=None, reason=None, info=None, eligibilityCheck=None, geoData=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)
    if offerStartTime is not None:
        offerStartTime = MDCTIME.convertTime(offerStartTime, restVersion=restVersion)
    if offerEndTime is not None:
        offerEndTime = MDCTIME.convertTime(offerEndTime, restVersion=restVersion)

    return SUBMAN.addSubscriber(V3inst=V3inst, externalId=externalId, deviceId=deviceId, deviceType=deviceType,
        offerId=offerId, catalogItemId=catalogItemId, offerStartTime=offerStartTime, offerEndTime=offerEndTime,
        serviceId=serviceId, payload=payload, subAttr=subAttr, devAttr=devAttr, billingCycle=billingCycle,
        eventPass=eventPass, firstName=firstName, lastName=lastName, contactEmail=contactEmail,
        contactPhoneNumber=contactPhoneNumber, contactPushTokenList=contactPushTokenList, notificationPreference=notificationPreference, timeZone=timeZone,
        now=now, accessNumbers=accessNumbers, subStatus=subStatus,taxStatus=taxStatus, taxCertificate=taxCertificate, taxLocation=taxLocation,
        devStatus=devStatus, language=language,
        chargeMethod=chargeMethod, paymentMethodResourceId=paymentMethodResourceId, paymentGatewayId=paymentGatewayId, paymentGatewayUserId=paymentGatewayUserId,
        paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, offerIsExternal=offerIsExternal, offerAttr=offerAttr, dateOffset=dateOffset,
        glCenter=glCenter, name=name, noTouch=noTouch,devOid=devOid, devQueryType=devQueryType, routingType=routingType, routingValue=routingValue,
        preActiveState=preActiveState, autoActivationTime=autoActivationTime, autoActivationRelativeOffsetUnit=autoActivationRelativeOffsetUnit,
        autoActivationRelativeOffset=autoActivationRelativeOffset, autoActivationCycleResourceId=autoActivationCycleResourceId,
        activationExpirationTime=activationExpirationTime, activationExpirationRelativeOffsetUnit=activationExpirationRelativeOffsetUnit,
        activationExpirationRelativeOffset=activationExpirationRelativeOffset, endTimeRelativeOffset=endTimeRelativeOffset, endTimeRelativeOffsetUnit=endTimeRelativeOffsetUnit,
        offerCycleType=offerCycleType, offerCycleOffset=offerCycleOffset, offerCycleStartTime=offerCycleStartTime, chargePurchaseProrationType=chargePurchaseProrationType,
        subApiEventData=subApiEventData, devApiEventData=devApiEventData, offerApiEventData=offerApiEventData, parameterList=parameterList, offerStatusValue=offerStatusValue, 
        customerType=customerType, serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId, exemptionCodeList=exemptionCodeList,
        isPendingActivationAllowed=isPendingActivationAllowed, offerLifecycleProfileId=offerLifecycleProfileId,
        paymentDueDate=paymentDueDate, grantPurchaseProrationType=grantPurchaseProrationType, reason=reason, info=info, eligibilityCheck=eligibilityCheck, geoData=geoData)

#====================================================
# Allow for clients to parse API event data so it can be used in a template
def parseAttrMdc(attr): return SUBMAN.parseAttrMdc(attr)

#====================================================
def subscribeToOffer(V3inst, externalId, offerId=None, deviceId=None, allDevices=True, catalogItemId=None,
        offerStartTime=None, offerEndTime=None, serviceId=None, eventPass=True, queryType='ExternalId', now=None,
        offerIsExternal=False, offerId2=None, attr=None, dupAttr=True, future=False, purchaseInfo=False, executeMode=None,
        chargeMethod=None, paymentMethodResourceId=None, paymentGatewayId=None, paymentGatewayOneTimeToken=None, chargeMethodAttr=None,
        paymentGatewayUserId=None, paymentDueDate=None, deferredSettlement=None, deferredSettlementTimeout=None, deferredSettlementTimeoutAction=None,
        offerCycleType=None, offerCycleResourceId=None, offerCycleOffset=None, offerCycleStartTime=None, preActiveState=None,
        autoActivationTime=None, autoActivationRelativeOffsetUnit=None, autoActivationRelativeOffset=None, autoActivationCycleResourceId=None,
        activationExpirationTime=None, activationExpirationRelativeOffsetUnit=None, activationExpirationRelativeOffset=None, endTimeRelativeOffset=None, 
        endTimeRelativeOffsetUnit=None, downPayment=None, isTargetResource=None, useTargetResource=None,  isRecurringFailureAllowed=None,
        chargePurchaseProrationType=None, grantPurchaseProrationType=None, reason=None, info=None, apiEventData=None, offerStatusValue=None,
        contractPeriod=None, contractInterval=None, commitmentPeriod=None, commitmentPeriodInterval=None, isOpenContract=None,
        isPendingActivationAllowed=None, offerLifecycleProfileId=None,
        routingType=None, routingValue=None, parameterList=None, eligibilityCheck=None, multiRequestBuild=None, etcScheduleRangeArray=None,
        etcScheduleRangeUnit=None, paymentScheduleRangeArray=None, paymentScheduleAmountArray=None, paymentScheduleLastAmount=None, delayCharge=None, geoData=None, endAfterCycleCount=None, noEndTime=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)
    if offerStartTime is not None:
        offerStartTime = MDCTIME.convertTime(offerStartTime, restVersion=restVersion)
    if offerEndTime is not None:
        offerEndTime = MDCTIME.convertTime(offerEndTime, restVersion=restVersion)

    return SUBMAN.subscribeToOffer(V3inst=V3inst, externalId=externalId, offerId=offerId, catalogItemId=catalogItemId,
        offerStartTime=offerStartTime, offerEndTime=offerEndTime, eventPass=eventPass, queryType=queryType, now=now,
        offerIsExternal=offerIsExternal, offerId2=offerId2, attr=attr, dupAttr=dupAttr, future=future, 
        chargeMethod=chargeMethod, paymentMethodResourceId=paymentMethodResourceId, paymentGatewayId=paymentGatewayId, chargeMethodAttr=chargeMethodAttr,
        paymentGatewayUserId=paymentGatewayUserId, paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, paymentDueDate=paymentDueDate, purchaseInfo=purchaseInfo, executeMode=executeMode,
        deferredSettlement=deferredSettlement, deferredSettlementTimeout=deferredSettlementTimeout,
        deferredSettlementTimeoutAction=deferredSettlementTimeoutAction,
        offerCycleType=offerCycleType, offerCycleResourceId=offerCycleResourceId, offerCycleOffset=offerCycleOffset, offerCycleStartTime=offerCycleStartTime,
        preActiveState=preActiveState, autoActivationTime=autoActivationTime, autoActivationRelativeOffsetUnit=autoActivationRelativeOffsetUnit,
        autoActivationRelativeOffset=autoActivationRelativeOffset, autoActivationCycleResourceId=autoActivationCycleResourceId,
        activationExpirationTime=activationExpirationTime, activationExpirationRelativeOffsetUnit=activationExpirationRelativeOffsetUnit,
        activationExpirationRelativeOffset=activationExpirationRelativeOffset, endTimeRelativeOffset=endTimeRelativeOffset,
        endTimeRelativeOffsetUnit=endTimeRelativeOffsetUnit, downPayment=downPayment, isTargetResource=isTargetResource,
        useTargetResource=useTargetResource, isRecurringFailureAllowed=isRecurringFailureAllowed, apiEventData=apiEventData, offerStatusValue=offerStatusValue,
        chargePurchaseProrationType=chargePurchaseProrationType, grantPurchaseProrationType=grantPurchaseProrationType, reason=reason, info=info, eligibilityCheck=eligibilityCheck, 
        contractPeriod=contractPeriod, contractInterval=contractInterval, commitmentPeriod=commitmentPeriod, commitmentPeriodInterval=commitmentPeriodInterval, isOpenContract=isOpenContract,
        isPendingActivationAllowed=isPendingActivationAllowed, offerLifecycleProfileId=offerLifecycleProfileId,
        routingType=routingType, routingValue=routingValue, parameterList=parameterList, multiRequestBuild=multiRequestBuild, etcScheduleRangeArray=etcScheduleRangeArray,
        etcScheduleRangeUnit=etcScheduleRangeUnit, paymentScheduleRangeArray=paymentScheduleRangeArray, paymentScheduleAmountArray=paymentScheduleAmountArray,
        paymentScheduleLastAmount=paymentScheduleLastAmount, delayCharge=delayCharge,geoData=geoData, endAfterCycleCount=endAfterCycleCount, noEndTime=noEndTime)

#=============================================================
def unsubscribeFromOffer(V3inst, subscriberId, offerId=None, resourceId=0, endTime=None, eventPass=True,
        queryType='ExternalId', cancelInfo=False, executeMode=None, eligibilityCheck=None,
        apiEventData=None, multiRequestBuild=None):
    global restVersion
    if endTime is not None:
        endTime = MDCTIME.convertTime(endTime, restVersion=restVersion)

    return SUBMAN.unsubscribeFromOffer(V3inst=V3inst, subscriberId=subscriberId, resourceId=resourceId,
        endTime=endTime, eventPass=eventPass, queryType=queryType, cancelInfo=cancelInfo,
        executeMode=executeMode, eligibilityCheck=eligibilityCheck, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

#=============================================================
def subscriberCancelOffer(V3inst, queryValue, resourceId=0, cancelType=None, grantCancelProrationType=None, chargeCancelProrationType=None,
        reason=None, info=None, cancelOfferDataList='', now=None, queryType='ExternalId', cancelInfo=False, eventPass=True, executeMode=None,
        contractCancelMode=None, debtCancellationMode=None, eligibilityCheck=None, multiRequestBuild=None, isWaiveEarlyTerminationCharge=None, apiEventData=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberCancelOffer(V3inst=V3inst, queryValue=queryValue, resourceId=resourceId,
        cancelType=cancelType, grantCancelProrationType=grantCancelProrationType, chargeCancelProrationType=chargeCancelProrationType,               
        reason=reason, info=info, now=now, queryType=queryType, cancelOfferDataList=cancelOfferDataList, cancelInfo=cancelInfo,
        eventPass=eventPass, executeMode=executeMode, contractCancelMode=contractCancelMode, debtCancellationMode=debtCancellationMode, eligibilityCheck=eligibilityCheck,
        apiEventData=apiEventData, multiRequestBuild=multiRequestBuild, isWaiveEarlyTerminationCharge=isWaiveEarlyTerminationCharge)

# Update subscriber threshold
#=============================================================
def addSubscriberThreshold(V3inst, queryValue, thresholdId, resourceId=None, threshName=None, val=None, notify=None,
        eventPass=True, now=None, queryType='ExternalId', recurringStart=None, recurringStop=None, virtualCreditLimitIsPercent=None,
        rechargeAmount=None, rechargePaymentMethodResourceId=None, isTemporaryCreditLimit=None,
        apiEventData=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.addSubscriberThreshold(V3inst=V3inst, queryValue=queryValue, thresholdId=thresholdId,
        resourceId=resourceId, threshName=threshName, val=val, notify=notify, eventPass=eventPass,
        now=now, queryType=queryType, recurringStart=recurringStart, recurringStop=recurringStop,
        virtualCreditLimitIsPercent=virtualCreditLimitIsPercent, rechargeAmount=rechargeAmount,
        rechargePaymentMethodResourceId=rechargePaymentMethodResourceId, apiEventData=apiEventData,
        isTemporaryCreditLimit=isTemporaryCreditLimit, multiRequestBuild=multiRequestBuild)

# Undo updated threshold
#=============================================================
def removeSubscriberThreshold(V3inst, subscriberId, indexId, thresholdId, queryType='ExternalId', now=None,
        removeThresholdOnly=None, removeRechargeDataOnly=None, isTemporaryCreditLimit=None,
        apiEventData=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.removeSubscriberThreshold(V3inst=V3inst, subscriberId=subscriberId, indexId=indexId,
        thresholdId=thresholdId, queryType=queryType, now=now, removeThresholdOnly=removeThresholdOnly,
        removeRechargeDataOnly=removeRechargeDataOnly, isTemporaryCreditLimit=isTemporaryCreditLimit,
        apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

#=============================================================
def querySubscriberThresholdRechargeDefn(V3inst, subscriberId, balanceResourceId=None, now=None, queryType='ExternalId', eventPass=True, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.querySubscriberThresholdRechargeDefn(V3inst=V3inst, queryValue=subscriberId, queryType=queryType,
        balanceResourceId=balanceResourceId, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Create billing cycle and add to subscriber
#========================================================
def createSubscriberBillingProfile(V3inst, subscriberId, profileId, startTime=None, dateOffset=0,
        queryType='ExternalId', eventPass=True, now=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.createSubscriberBillingProfile(V3inst=V3inst, subscriberId=subscriberId, profileId=profileId,
        startTime=startTime, dateOffset=dateOffset, queryType=queryType, eventPass=eventPass, now=now, multiRequestBuild=multiRequestBuild)

# Create billing cycle and add to group
#========================================================
def createGroupBillingProfile(V3inst, groupId, profileId, startTime=None, dateOffset=0,
        queryType='ExternalId', eventPass=True, now=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.createGroupBillingProfile(V3inst=V3inst, groupId=groupId, profileId=profileId,
        startTime=startTime, dateOffset=dateOffset, queryType=queryType, eventPass=eventPass, now=now, multiRequestBuild=multiRequestBuild)

# Create Payment One Time Token
#=============================================================
def subscriberCreatePaymentOneTimeToken(V3inst, queryValue, queryType='ExternalId', paymentMethodResourceId=None, paymentAttr=None,
        eventPass=True, multiRequestBuild=None):
    global restVersion

    return SUBMAN.subscriberCreatePaymentOneTimeToken(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        paymentMethodResourceId=paymentMethodResourceId, paymentAttr=paymentAttr, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Create Payment One Time Token
#=============================================================
def groupCreatePaymentOneTimeToken(V3inst, queryValue, queryType='ExternalId', paymentMethodResourceId=None, paymentAttr=None,
        eventPass=True, multiRequestBuild=None):
    global restVersion

    return SUBMAN.groupCreatePaymentOneTimeToken(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        paymentMethodResourceId=paymentMethodResourceId, paymentAttr=paymentAttr, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Make Payment to Subscribers Main Balance
#========================================================
def subscriberPayment(V3inst, queryValue, amount, payNow=None, queryType='ExternalId', paymentMethodResourceId=None,
        paymentGatewayId=None, paymentGatewayOneTimeToken=None, info=None, reason=None, chargeMethodAttr=None,
        paymentGatewayUserId=None, apiEventData=None, eventPass=True, now=None, executeMode=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberPayment(V3inst=V3inst, queryValue=queryValue, amount=amount, payNow=payNow,
        queryType=queryType, paymentMethodResourceId=paymentMethodResourceId, chargeMethodAttr=chargeMethodAttr,
        paymentGatewayId=paymentGatewayId, paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, info=info, reason=reason,
        paymentGatewayUserId=paymentGatewayUserId, apiEventData=apiEventData, eventPass=eventPass, now=now,
         executeMode=executeMode, multiRequestBuild=multiRequestBuild)

# Make Payment to Groups Main Balance
#========================================================
def groupPayment(V3inst, queryValue, amount, payNow=None, queryType='ExternalId', paymentMethodResourceId=None,
        paymentGatewayId=None, paymentGatewayOneTimeToken=None, info=None, reason=None, chargeMethodAttr=None,
        paymentGatewayUserId=None, eventPass=True, apiEventData=None, now=None, executeMode=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupPayment(V3inst=V3inst, queryValue=queryValue, amount=amount, payNow=payNow,
        queryType=queryType, paymentMethodResourceId=paymentMethodResourceId, chargeMethodAttr=chargeMethodAttr,
        paymentGatewayId=paymentGatewayId, paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, info=info, reason=reason,
        paymentGatewayUserId=paymentGatewayUserId, apiEventData=apiEventData, eventPass=eventPass, now=now, 
        executeMode=executeMode, multiRequestBuild=multiRequestBuild)

#   Subscriber Settle Payment
#========================================================
def subscriberSettlePayment(V3inst, queryValue, queryType='ExternalId', resourceId=None, eventPass=True, now=None,
        apiEventData=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)
    return SUBMAN.subscriberSettlePayment(V3inst=V3inst, queryValue=queryValue, queryType=queryType, resourceId=resourceId,
        eventPass=eventPass, now=now, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

#  group Settle Payment
#========================================================
def groupSettlePayment(V3inst, queryValue, queryType='ExternalId', resourceId=None, eventPass=True, now=None,
        apiEventData=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)
    return SUBMAN.groupSettlePayment(V3inst=V3inst, queryValue=queryValue, queryType=queryType, resourceId=resourceId,
        eventPass=eventPass, now=now, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

# Create a subscriber create profile- LEGACY CODE! Can just specify individual fields on subscriber create...
#========================================================
def createSubscriberProfileInfo(type=None, fname=None, lname=None, notifyE=None, email=None, notifyP=None, phone=None,
        specialDateList=None, timeZone=None, attr=None):
    return COMMON.createSubscriberProfileInfo(type=type, fname=fname, lname=lname, notifyE=notifyE, email=email,
        notifyP=notifyP, phone=phone, specialDateList=specialDateList, timeZone=timeZone, attr=attr)

# Create a subscriber modification profile- LEGACY CODE! Can just specify individual fields on subscriber modify...
#========================================================
def createModifySubscriberProfileInfo(type=None, fname=None, lname=None, notifyE=None, email=None,
        notifyP=None, phone=None, specialDateList=None, timeZone=None, attr=None):
    return COMMON.createModifySubscriberProfileInfo(type=type, fname=fname, lname=lname, notifyE=notifyE, email=email,
        notifyP=notifyP, phone=phone, specialDateList=specialDateList, timeZone=timeZone, attr=attr)

#========================================================
def modifySubscriber(V3inst, queryValue, queryType='ExternalId', payload=None, now=None, eventPass=True, 
        firstName=None, lastName=None, contactEmail=None, contactPhoneNumber=None, contactPushTokenList=None, notificationPreference=None,
        timeZone=None, attr=None, billingCycle=None, status=None, taxStatus=None, taxCertificate=None, taxLocation=None,
        language=None, externalId=None, dateOffset=None, glCenter=None, name=None, paymentGatewayUserId=None,
        currentPaymentTokenResourceId=None, lastActivityUpdateTime=None, billingCycleDisabled=None, apiEventData=None, customerType=None, 
        serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,multiRequestBuild=None):
        
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.modifySubscriber(V3inst=V3inst, queryValue=queryValue, payload=payload, eventPass=eventPass, 
        queryType=queryType, now=now, firstName=firstName, lastName=lastName, contactEmail=contactEmail,
        contactPhoneNumber=contactPhoneNumber, contactPushTokenList=contactPushTokenList, notificationPreference=notificationPreference, timeZone=timeZone,
        attr=attr, billingCycle=billingCycle, status=status,taxStatus=taxStatus, taxCertificate=taxCertificate, taxLocation=taxLocation, 
        language=language, externalId=externalId, dateOffset=dateOffset, glCenter=glCenter, name=name, paymentGatewayUserId=paymentGatewayUserId,
        currentPaymentTokenResourceId=currentPaymentTokenResourceId, lastActivityUpdateTime=lastActivityUpdateTime, billingCycleDisabled=billingCycleDisabled,
        apiEventData=apiEventData, customerType=customerType, serviceAddress=serviceAddress,
        npa=npa, nxx=nxx, tenantId=tenantId, exemptionCodeList=exemptionCodeList, multiRequestBuild=multiRequestBuild,)

#=============================================================
def querySubscriber(V3inst, queryValue, queryType='ExternalId', querySize=None, eventPass=True, now=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, querySize=querySize,
        eventPass=eventPass, now=now, multiRequestBuild=multiRequestBuild)

#=============================================================
def querySubscriberWallet(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.querySubscriberWallet(V3inst=V3inst, queryValue=queryValue, queryType=queryType, 
        now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
# Support backwards compatibility
def subscriberOfferModify(V3inst, queryValue, queryType='ExternalId', resourceId=None, startTime=None, endTime=None, eventPass=True, attr=None, now=None, executeMode=None, cycleType=None, cycleResourceId=None, cycleOffset=None, cycleAlignmentDisabled=None, cycleStartTime=None, cycleEndTime=None, immediateChange=None, isRecurringFailureAllowed=None, status=None, offerStatusValue=None, modifyInfo=False, parameterList=None, apiEventData=None, multiRequestBuild=None, endTimeExtensionOffset=None, endTimeExtensionOffsetUnit=None, endAfterCycleCount=None, noEndTime=None):
    return  subscriberModifyOffer(V3inst, queryValue, queryType, resourceId, startTime, endTime, eventPass, attr, now, executeMode, cycleType, cycleResourceId, cycleOffset, cycleAlignmentDisabled, cycleStartTime, cycleEndTime, immediateChange, isRecurringFailureAllowed, status, offerStatusValue, modifyInfo, parameterList, apiEventData, multiRequestBuild=multiRequestBuild, endTimeExtensionOffset=endTimeExtensionOffset, endTimeExtensionOffsetUnit=endTimeExtensionOffsetUnit, endAfterCycleCount=endAfterCycleCount, noEndTime=noEndTime)

#=============================================================
def subscriberModifyOffer(V3inst, queryValue, queryType='ExternalId', resourceId=None, startTime=None, endTime=None, eventPass=True, attr=None, now=None, executeMode=None, cycleType=None, cycleResourceId=None, cycleOffset=None, cycleAlignmentDisabled=None, cycleStartTime=None, cycleEndTime=None, immediateChange=None, isRecurringFailureAllowed=None, status=None, offerStatusValue=None, modifyInfo=False, parameterList=None, apiEventData=None, multiRequestBuild=None, endTimeExtensionOffset=None, endTimeExtensionOffsetUnit=None, endAfterCycleCount=None, noEndTime=None):
    
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberModifyOffer(V3inst, queryValue, queryType, resourceId, now=now,
            startTime=startTime, endTime=endTime, attr=attr, eventPass=eventPass, executeMode=executeMode, cycleType=cycleType, cycleResourceId=cycleResourceId, cycleOffset=cycleOffset, cycleAlignmentDisabled=cycleAlignmentDisabled, cycleStartTime=cycleStartTime, cycleEndTime=cycleEndTime, immediateChange=immediateChange, isRecurringFailureAllowed=isRecurringFailureAllowed, status=status, offerStatusValue=offerStatusValue, modifyInfo=modifyInfo, parameterList=parameterList, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild, endTimeExtensionOffset=endTimeExtensionOffset, endTimeExtensionOffsetUnit=endTimeExtensionOffsetUnit, endAfterCycleCount=endAfterCycleCount, noEndTime=noEndTime)

# Subscriber Modify Status
#=============================================================
def subscriberModifyStatus(V3inst, queryValue=None, statusTransitionTime=None, statusValue=None, queryType='ExternalId', now=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberModifyStatus(V3inst, queryValue=queryValue, statusTransitionTime=statusTransitionTime,
       statusValue=statusValue, queryType=queryType, apiEventData=apiEventData, executeMode=executeMode, now=now,
       routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild, eventPass=eventPass)

# Subscriber Remove Scheduled Status Change
#=============================================================
def subscriberRemoveScheduledStatusChange(V3inst, queryValue=None, queryType='ExternalId', now=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberRemoveScheduledStatusChange(V3inst, queryValue=queryValue, queryType=queryType, apiEventData=apiEventData, executeMode=executeMode, now=now,
       routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild, eventPass=eventPass)

# Subscriber Suspend Offer
#=============================================================
def subscriberSuspendOffer(V3inst, queryValue=None, resourceId=None, scheduledSuspendTime=None, queryType='ExternalId', now=None,
                           autoResumeRelativeOffset=None, autoResumeRelativeOffsetUnit=None, autoResumeTime=None,
                           isPauseMode=None, grantSuspendProrationType=None, chargeSuspendProrationType=None,
                           grantResumeProrationType=None, chargeResumeProrationType=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberSuspendOffer(V3inst, queryValue=queryValue, resourceId=resourceId, 
       scheduledSuspendTime=scheduledSuspendTime, queryType=queryType, now=now,
       autoResumeRelativeOffset=autoResumeRelativeOffset, autoResumeRelativeOffsetUnit=autoResumeRelativeOffsetUnit,
       autoResumeTime=autoResumeTime, isPauseMode=isPauseMode, grantSuspendProrationType=grantSuspendProrationType,
       chargeSuspendProrationType=chargeSuspendProrationType, grantResumeProrationType=grantResumeProrationType,
       chargeResumeProrationType=chargeResumeProrationType, apiEventData=apiEventData,
       routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild, eventPass=eventPass)

# Subscriber Resume Offer
#=============================================================
def subscriberResumeOffer(V3inst, queryValue=None, resourceId=None, scheduledResumeTime=None, queryType='ExternalId', now=None,
                           resumeRelativeOffset=None, resumeRelativeOffsetUnit=None, grantResumeProrationType=None,
                           chargeResumeProrationType=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberResumeOffer(V3inst, queryValue=queryValue, resourceId=resourceId,
       scheduledResumeTime=scheduledResumeTime, queryType=queryType, now=now,
       resumeRelativeOffset=resumeRelativeOffset, resumeRelativeOffsetUnit=resumeRelativeOffsetUnit,
       grantResumeProrationType=grantResumeProrationType, 
       chargeResumeProrationType=chargeResumeProrationType, apiEventData=apiEventData,
       routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild, eventPass=eventPass)

# Subscriber Remove Scheduled Offer Status Change
#=============================================================
def subscriberRemoveScheduledOfferStatusChange(V3inst, queryValue=None, queryType='ExternalId', now=None, resourceId=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberRemoveScheduledOfferStatusChange(V3inst, queryValue=queryValue, queryType=queryType, resourceId=resourceId,
       apiEventData=apiEventData, executeMode=executeMode, now=now,
       routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild, eventPass=eventPass)

#=============================================================
def subscriberActivateOffer(V3inst, queryValue, queryType='ExternalId', resourceId=None, now=None, eventPass=True,
    routingType=None, routingValue=None, executeMode=None, apiEventData=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberActivateOffer(V3inst, queryValue, queryType, resourceId=resourceId, now=now, executeMode=executeMode,
                                          routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild,
                                          apiEventData=apiEventData, eventPass=eventPass)

#=============================================================
def subscriberCheckPurchasedItemCycleAlignment(V3inst, queryValue, queryType='ExternalId', offerExternalId=None, catalogId=None, offerId=None, offerResourceId=None, eventPass=True, now=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberCheckPurchasedItemCycleAlignment(V3inst, queryValue, queryType, offerExternalId=offerExternalId, catalogId=catalogId, offerId=offerId, offerResourceId=offerResourceId, now=now,
           eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def groupCheckPurchasedItemCycleAlignment(V3inst, queryValue, queryType='ExternalId', offerExternalId=None, catalogId=None, offerId=None, offerResourceId=None, eventPass=True, now=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupCheckPurchasedItemCycleAlignment(V3inst, queryValue, queryType, offerExternalId=offerExternalId, catalogId=catalogId, offerId=offerId, offerResourceId=offerResourceId, now=now,
           eventPass=eventPass, multiRequestBuild=multiRequestBuild)
#=============================================================
def deviceCheckPurchasedItemCycleAlignment(V3inst, queryValue, queryType='ExternalId', offerExternalId=None, catalogId=None, offerId=None, offerResourceId=None, eventPass=True, now=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.deviceCheckPurchasedItemCycleAlignment(V3inst, queryValue, queryType,  offerExternalId=offerExternalId, catalogId=catalogId, offerId=offerId, offerResourceId=offerResourceId, now=now,
           eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def createDevice(V3inst, deviceId, externalId=None, containerType=None, deviceType=None, attr=None, accessNumbers=None,
        now=None, eventPass=True, status=None,  mobile=True, tenantId=None, apiEventData=None, routingType=None, routingValue=None, executeMode=None, multiRequestBuild=None, apiEventSecurityInfo=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.createDevice(V3inst=V3inst, imsi=deviceId, externalId=externalId, deviceType=deviceType,
        attr=attr, accessNumbers=accessNumbers, now=now, eventPass=eventPass, status=status, mobile=mobile, tenantId=tenantId, apiEventData=apiEventData,
                routingType=routingType, routingValue=routingValue, executeMode=executeMode, multiRequestBuild=multiRequestBuild, apiEventSecurityInfo=apiEventSecurityInfo)

#=============================================================
def subscriberCreateDevice(V3inst, queryValue=None, queryType='ObjectId', deviceId=None, externalId=None, deviceType=None, attr=None,
        now=None, accessNumbers=None,eventPass=True, status=None, mobile=None, routingType=None, routingValue=None, executeMode=None,
        tenantId=None, returnTemplate=False, apiEventData=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberCreateDevice(V3inst, queryValue=queryValue, queryType=queryType, deviceId=deviceId, externalId=externalId,
        deviceType=deviceType, attr=attr, now=now, accessNumbers=accessNumbers, eventPass=eventPass, status=status, mobile=mobile,
        tenantId=tenantId, apiEventData=apiEventData, routingType=routingType, routingValue=routingValue, executeMode=executeMode, returnTemplate=True, multiRequestBuild=None)

#=============================================================
def createDeviceLogin(V3inst, loginId, externalId=None, status=None, deviceType=None, attr=None, accessIds=None,
        tenantId=None, apiEventData=None, now=None, eventPass=True, routingType=None, routingValue=None, multiRequestBuild=None, apiEventSecurityInfo=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.createDeviceLogin(V3inst=V3inst, loginId=loginId, externalId=externalId, deviceType=deviceType, tenantId=tenantId,
        attr=attr, accessIds=accessIds, apiEventData=apiEventData, now=now, eventPass=eventPass, status=status, multiRequestBuild=multiRequestBuild, apiEventSecurityInfo=apiEventSecurityInfo)

#=============================================================
def subscriberDeleteDevice(V3inst, queryValue=None, queryType='ObjectId', devQueryValue=None, devQueryType='ObjectId',
    now=None, eventPass=True, apiEventData=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberDeleteDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, devQueryValue=devQueryValue, devQueryType=devQueryType,
                      now=now, eventPass=eventPass, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

#=============================================================
def deleteDevice(V3inst, deviceId, queryType='Imsi', deleteSession=False, now=None, eventPass=True,
        apiEventData=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.deleteDevice(V3inst=V3inst, queryValue=deviceId, queryType=queryType, deleteSession=deleteSession, now=now, 
                               eventPass=eventPass, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

# Add device to subscriber; checks if device already exists, and if not, creates one to add to subscriber
#=============================================================
def addDeviceToSubscriber(V3inst, externalId, deviceId=None, deviceType=1, subQueryType='ExternalId',
        devQueryType='PhoneNumber', eventPass=True, attr=None, accessNumbers=None, status=None, now=None, isCreateDevice=True, 
        tenantId=None, noTouch=False, devOid=None, apiEventData=None, routingType=None, routingValue=None, multiRequestBuild=None):
    global restVersion
    global subUrl

    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.addDeviceToSubscriber(V3inst=V3inst, externalId=externalId, deviceId=deviceId, deviceType=deviceType,
        subQueryType=subQueryType, devQueryType=devQueryType, eventPass=eventPass, accessNumbers=accessNumbers, attr=attr,
        status=status, now=now, isCreateDevice=isCreateDevice, noTouch=noTouch, apiEventData=apiEventData,
        tenantId=tenantId, routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild)

# Remove device from subscriber
#=============================================================
def removeDeviceFromSubscriber(V3inst, subscriberId, deviceId, subQueryType='ExternalId', devQueryType='Imsi',
        eventPass=True, now=None, deleteSession=None, apiEventData=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.removeDeviceFromSubscriber(V3inst=V3inst, subscriberId=subscriberId, deviceId=deviceId,
        subQueryType=subQueryType, devQueryType=devQueryType, deleteSession=deleteSession, eventPass=eventPass, now=now,
        apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

#=============================================================
def modifyDevice(V3inst, queryValue, queryType='PhoneNumber', deviceType=None, attr=None, now=None, eventPass=True,
        status=None, accessNumbers=None, externalId=None, lastActivityUpdateTime=None, imsi=None, loginId=None,
        tenantId=None, apiEventData=None, executeMode=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.modifyDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, deviceType=deviceType,
        attr=attr, now=now, eventPass=eventPass, status=status, accessNumbers=accessNumbers, externalId=externalId, apiEventData=apiEventData,
        lastActivityUpdateTime=lastActivityUpdateTime, imsi=imsi, loginId=loginId, tenantId=tenantId, executeMode=executeMode, multiRequestBuild=multiRequestBuild)

#====================================================
def devicePurchaseOffer(V3inst, queryValue, offerId=None, catalogItemId=None, offerStartTime=None,
        offerEndTime=None, queryType='PhoneNumber', eventPass=True, now=None, offerIsExternal=False, attr=None,
        chargeMethod=None, paymentMethodResourceId=None, paymentGatewayId=None, paymentGatewayOneTimeToken=None, chargeMethodAttr=None, 
        paymentGatewayUserId=None, paymentScheduleRangeArray=None, paymentScheduleAmountArray=None, paymentScheduleLastAmount=None, delayCharge=None, 
        purchaseInfo=False, executeMode=None, offerCycleType=None, offerCycleResourceId=None, offerCycleOffset=None, cycleOwnerType=None, offerCycleStartTime=None,
        preActiveState=None, autoActivationTime=None, autoActivationRelativeOffsetUnit=None, autoActivationRelativeOffset=None, autoActivationCycleResourceId=None,
        activationExpirationTime=None, activationExpirationRelativeOffsetUnit=None,
        activationExpirationRelativeOffset=None, endTimeRelativeOffsetUnit=None, endTimeRelativeOffset=None, downPayment=None, isRecurringFailureAllowed=None,
        chargePurchaseProrationType=None, grantPurchaseProrationType=None, reason=None, info=None, apiEventData=None, 
        deferredSettlement=None, deferredSettlementTimeout=None, deferredSettlementTimeoutAction=None, parameterList=None,
        paymentDueDate=None, contractPeriod=None, contractInterval=None, commitmentPeriod=None, commitmentPeriodInterval=None, isOpenContract=None,
        isPendingActivationAllowed=None, offerLifecycleProfileId=None,
        routingType=None, routingValue=None, offerStatusValue=None, etcScheduleRangeArray=None, etcScheduleRangeUnit=None, multiRequestBuild=None,
        isTargetResource=None, useTargetResource=None, eligibilityCheck=None, geoData=None, endAfterCycleCount=None, noEndTime=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)
    if offerStartTime is not None:
        offerStartTime = MDCTIME.convertTime(offerStartTime, restVersion=restVersion)
    if offerEndTime is not None:
        offerEndTime = MDCTIME.convertTime(offerEndTime, restVersion=restVersion)

    return SUBMAN.devicePurchaseOffer(V3inst=V3inst, queryValue=queryValue, offerId=offerId, catalogItemId=catalogItemId,
        offerStartTime=offerStartTime, offerEndTime=offerEndTime, queryType=queryType, eventPass=eventPass, now=now,
        offerIsExternal=offerIsExternal, attr=attr, chargeMethodAttr=chargeMethodAttr,
        chargeMethod=chargeMethod, paymentMethodResourceId=paymentMethodResourceId, paymentGatewayId=paymentGatewayId,
        paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, paymentGatewayUserId=paymentGatewayUserId, purchaseInfo=purchaseInfo, paymentScheduleRangeArray=paymentScheduleRangeArray, 
        paymentScheduleAmountArray=paymentScheduleAmountArray, paymentScheduleLastAmount=paymentScheduleLastAmount, delayCharge=delayCharge,
        etcScheduleRangeArray=etcScheduleRangeArray, etcScheduleRangeUnit=etcScheduleRangeUnit,
        contractPeriod=contractPeriod, contractInterval=contractInterval, commitmentPeriod=commitmentPeriod, commitmentPeriodInterval=commitmentPeriodInterval, isOpenContract=isOpenContract,
        offerCycleType=offerCycleType, offerCycleResourceId=offerCycleResourceId, offerCycleOffset=offerCycleOffset, cycleOwnerType=cycleOwnerType,
        offerCycleStartTime=offerCycleStartTime,
        preActiveState=preActiveState, autoActivationTime=autoActivationTime, autoActivationRelativeOffsetUnit=autoActivationRelativeOffsetUnit,
        autoActivationRelativeOffset=autoActivationRelativeOffset, autoActivationCycleResourceId=autoActivationCycleResourceId,
        activationExpirationTime=activationExpirationTime, activationExpirationRelativeOffsetUnit=activationExpirationRelativeOffsetUnit,
        activationExpirationRelativeOffset=activationExpirationRelativeOffset, endTimeRelativeOffsetUnit=endTimeRelativeOffsetUnit,
        endTimeRelativeOffset=endTimeRelativeOffset, downPayment=downPayment, isRecurringFailureAllowed=isRecurringFailureAllowed,
        chargePurchaseProrationType=chargePurchaseProrationType, grantPurchaseProrationType=grantPurchaseProrationType,
        paymentDueDate=paymentDueDate, reason=reason, info=info, apiEventData=apiEventData, offerStatusValue=offerStatusValue, parameterList=parameterList,
        deferredSettlement=deferredSettlement, deferredSettlementTimeout=deferredSettlementTimeout, deferredSettlementTimeoutAction=deferredSettlementTimeoutAction,
        isPendingActivationAllowed=isPendingActivationAllowed, offerLifecycleProfileId=offerLifecycleProfileId,
        routingType=routingType, routingValue=routingValue, executeMode=executeMode, multiRequestBuild=multiRequestBuild, isTargetResource=isTargetResource,
        useTargetResource=useTargetResource, eligibilityCheck=eligibilityCheck,geoData=geoData, endAfterCycleCount=endAfterCycleCount, noEndTime=noEndTime)

#=============================================================
def deviceCancelOffer(V3inst, queryValue, resourceId=0, endTime=None, queryType='PhoneNumber',
        eventPass=True, now=None, cancelInfo=False, executeMode=None, apiEventData=None, multiRequestBuild=None, eligibilityCheck=None):
    global restVersion
    if endTime is not None:
        endTime = MDCTIME.convertTime(endTime, restVersion)

    return SUBMAN.deviceCancelOffer(V3inst=V3inst, queryValue=queryValue, resourceId=resourceId,
        endTime=endTime, queryType=queryType, eventPass=eventPass,now=now, cancelInfo=cancelInfo,
        executeMode=executeMode, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild,
        eligibilityCheck=eligibilityCheck)

#=============================================================
def deviceCancelOfferExt(V3inst, queryValue, resourceId=0, cancelType=None, grantCancelProrationType=None, chargeCancelProrationType=None,
        reason=None, info=None, cancelOfferDataList='', now=None, queryType='PhoneNumber', cancelInfo=False, eventPass=True, executeMode=None,
        contractCancelMode=None, debtCancellationMode=None, multiRequestBuild=None, isWaiveEarlyTerminationCharge=None, eligibilityCheck=None, apiEventData=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.deviceCancelOfferExt(V3inst=V3inst, queryValue=queryValue, resourceId=resourceId,
        cancelType=cancelType, grantCancelProrationType=grantCancelProrationType, chargeCancelProrationType=chargeCancelProrationType,
        reason=reason, info=info, now=now, queryType=queryType, cancelOfferDataList=cancelOfferDataList, cancelInfo=cancelInfo,
        eventPass=eventPass, executeMode=executeMode, contractCancelMode=contractCancelMode, debtCancellationMode=debtCancellationMode, multiRequestBuild=multiRequestBuild,
        isWaiveEarlyTerminationCharge=isWaiveEarlyTerminationCharge, eligibilityCheck=eligibilityCheck, apiEventData=apiEventData)

#=============================================================
def queryDevice(V3inst, queryValue, queryType='PhoneNumber', now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now,
        eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
# Map to real API call
def deviceOfferModify(V3inst, queryValue, queryType='Imsi', resourceId=None, startTime=None, endTime=None, eventPass=True, attr=None, now=None, executeMode=None,  cycleType=None, cycleResourceId=None, cycleOffset=None, cycleAlignmentDisabled=None, cycleStartTime=None, cycleEndTime=None, immediateChange=None, isRecurringFailureAllowed=None, status=None, offerStatusValue=None, modifyInfo=False, apiEventData=None, parameterList=None, multiRequestBuild=None, endTimeExtensionOffset=None, endTimeExtensionOffsetUnit=None, endAfterCycleCount=None, noEndTime=None):
        return deviceModifyOffer(V3inst, queryValue, queryType, resourceId, startTime, endTime, eventPass, attr, now, executeMode, cycleType, cycleResourceId, cycleOffset, cycleAlignmentDisabled, cycleStartTime, cycleEndTime, immediateChange, isRecurringFailureAllowed, status, offerStatusValue, modifyInfo, apiEventData, parameterList, multiRequestBuild=multiRequestBuild, endTimeExtensionOffset=endTimeExtensionOffset, endTimeExtensionOffsetUnit=endTimeExtensionOffsetUnit, endAfterCycleCount=endAfterCycleCount, noEndTime=noEndTime)

#=============================================================
def deviceModifyOffer(V3inst, queryValue, queryType='Imsi', resourceId=None, startTime=None, endTime=None, eventPass=True, attr=None, now=None, executeMode=None,  cycleType=None, cycleResourceId=None, cycleOffset=None, cycleAlignmentDisabled=None, cycleStartTime=None, cycleEndTime=None, immediateChange=None, isRecurringFailureAllowed=None, status=None, offerStatusValue=None, modifyInfo=False, apiEventData=None, parameterList=None, multiRequestBuild=None, endTimeExtensionOffset=None, endTimeExtensionOffsetUnit=None, endAfterCycleCount=None, noEndTime=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.deviceModifyOffer(V3inst, queryType, queryValue, resourceId, now=now,
            startTime=startTime, endTime=endTime, attr=attr, eventPass=eventPass, executeMode=executeMode, cycleType=cycleType, cycleResourceId=cycleResourceId, cycleOffset=cycleOffset, cycleAlignmentDisabled=cycleAlignmentDisabled, cycleStartTime=cycleStartTime, cycleEndTime=cycleEndTime, immediateChange=immediateChange, isRecurringFailureAllowed=isRecurringFailureAllowed, status=status, offerStatusValue=offerStatusValue, modifyInfo=modifyInfo, apiEventData=apiEventData, parameterList=parameterList, multiRequestBuild=multiRequestBuild, endTimeExtensionOffset=endTimeExtensionOffset, endTimeExtensionOffsetUnit=endTimeExtensionOffsetUnit, endAfterCycleCount=endAfterCycleCount, noEndTime=noEndTime)

# Device Modify Status
#=============================================================
def deviceModifyStatus(V3inst, queryValue=None, statusTransitionTime=None, statusValue=None, queryType='PhoneNumber', now=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.deviceModifyStatus(V3inst, queryValue=queryValue, statusTransitionTime=statusTransitionTime,
       statusValue=statusValue, queryType=queryType, apiEventData=apiEventData, executeMode=executeMode, now=now,
       routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild, eventPass=eventPass)

# Device Remove Scheduled Status Change
#=============================================================
def deviceRemoveScheduledStatusChange(V3inst, queryValue=None, queryType='PhoneNumber', now=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.deviceRemoveScheduledStatusChange(V3inst, queryValue=queryValue, queryType=queryType, apiEventData=apiEventData, executeMode=executeMode, now=now,
       routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild, eventPass=eventPass)

# Device Suspend Offer
#=============================================================
def deviceSuspendOffer(V3inst, queryValue=None, resourceId=None, scheduledSuspendTime=None, queryType='PhoneNumber', now=None,
                           autoResumeRelativeOffset=None, autoResumeRelativeOffsetUnit=None, autoResumeTime=None,
                           isPauseMode=None, grantSuspendProrationType=None, chargeSuspendProrationType=None,
                           grantResumeProrationType=None, chargeResumeProrationType=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.deviceSuspendOffer(V3inst, queryValue=queryValue, resourceId=resourceId,
       scheduledSuspendTime=scheduledSuspendTime, queryType=queryType, now=now,
       autoResumeRelativeOffset=autoResumeRelativeOffset, autoResumeRelativeOffsetUnit=autoResumeRelativeOffsetUnit,
       autoResumeTime=autoResumeTime, isPauseMode=isPauseMode, grantSuspendProrationType=grantSuspendProrationType,
       chargeSuspendProrationType=chargeSuspendProrationType, grantResumeProrationType=grantResumeProrationType,
       chargeResumeProrationType=chargeResumeProrationType, apiEventData=apiEventData,
       routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild, eventPass=eventPass)

# Device Resume Offer
#=============================================================
def deviceResumeOffer(V3inst, queryValue=None, resourceId=None, scheduledResumeTime=None, queryType='PhoneNumber', now=None,
                           resumeRelativeOffset=None, resumeRelativeOffsetUnit=None, grantResumeProrationType=None,
                           chargeResumeProrationType=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.deviceResumeOffer(V3inst, queryValue=queryValue, resourceId=resourceId,
       scheduledResumeTime=scheduledResumeTime, queryType=queryType, now=now,
       resumeRelativeOffset=resumeRelativeOffset, resumeRelativeOffsetUnit=resumeRelativeOffsetUnit,
       grantResumeProrationType=grantResumeProrationType,
       chargeResumeProrationType=chargeResumeProrationType, apiEventData=apiEventData,
       routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild, eventPass=eventPass)

# Device Remove Scheduled Offer Status Change
#=============================================================
def deviceRemoveScheduledOfferStatusChange(V3inst, queryValue=None, queryType='PhoneNumber', now=None, resourceId=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.deviceRemoveScheduledOfferStatusChange(V3inst, queryValue=queryValue, queryType=queryType, resourceId=resourceId,
       apiEventData=apiEventData, executeMode=executeMode, now=now,
       routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild, eventPass=eventPass)

#=============================================================
def deviceActivateOffer(V3inst, queryValue, queryType='Imsi', resourceId=None, now=None, eventPass=True,
                        routingType=None, routingValue=None, executeMode=None, multiRequestBuild=None, 
                        apiEventData=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.deviceActivateOffer(V3inst, queryValue, queryType, resourceId=resourceId, now=now, executeMode=executeMode,
                                      routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild,
                                      apiEventData=apiEventData, eventPass=eventPass)

#=============================================================
def createGroup(V3inst, groupId=None, name=None, tier=None, administrator_id=0, eventPass=True, containerType=None, status=None,
        attr=None, now=None, billingCycle=None, queryType='ExternalId', taxStatus=None, taxCertificate=None, taxLocation=None,
        timeZone=None, notificationPreference=None, dateOffset=None, groupReAuthPreference=None, glCenter=None, apiEventData=None,
        routingType=None, routingValue=None,  customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None,
        exemptionCodeList=None, executeMode=None, multiRequestBuild=None, apiEventSecurityInfo=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.createGroup(V3inst=V3inst, groupId=groupId, name=name, tier=tier, administrator_id=administrator_id, status=status, 
        eventPass=eventPass, attr=attr, now=now, billingCycle=billingCycle, queryType=queryType, notificationPreference=notificationPreference,
        taxStatus=taxStatus, taxCertificate=taxCertificate, taxLocation=taxLocation, timeZone=timeZone, groupReAuthPreference=groupReAuthPreference,
        dateOffset=dateOffset, glCenter=glCenter, apiEventData=apiEventData, routingType=routingType, routingValue=routingValue,
        customerType=customerType, serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId, exemptionCodeList=exemptionCodeList,
        executeMode=executeMode, multiRequestBuild=multiRequestBuild, apiEventSecurityInfo=apiEventSecurityInfo)


#=============================================================
def modifyGroup(V3inst, groupId, name=None, tier=None, administrator_id=0, billingCycle=None, attr=None, status=None,
        subQueryType='ExternalId', groupQueryType='ExternalId', now=None, eventPass=True, notificationPreference=None,
        taxStatus=None, taxCertificate=None, taxLocation=None, externalId=None, timeZone=None, groupReAuthPreference=None,
        dateOffset=None, glCenter=None, paymentGatewayUserId=None, currentPaymentTokenResourceId=None,
        lastActivityUpdateTime=None, executeMode=None, billingCycleDisabled=None,
        maxUserCount=None, maxSubscriberCount=None, apiEventData=None, customerType=None, serviceAddress=None, npa=None, nxx=None, 
        tenantId=None, exemptionCodeList=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.modifyGroup(V3inst=V3inst, groupId=groupId, name=name, tier=tier, status=status,
        administrator_id=administrator_id, billingCycle=billingCycle, attr=attr, subQueryType=subQueryType,
        groupQueryType=groupQueryType, now=now, eventPass=eventPass, notificationPreference=notificationPreference,
        taxStatus=taxStatus, taxCertificate=taxCertificate, taxLocation=taxLocation, externalId=externalId, timeZone=timeZone, 
        groupReAuthPreference=groupReAuthPreference, dateOffset=dateOffset, glCenter=glCenter,
        paymentGatewayUserId=paymentGatewayUserId, currentPaymentTokenResourceId=currentPaymentTokenResourceId,
        lastActivityUpdateTime=lastActivityUpdateTime, executeMode=executeMode, billingCycleDisabled=billingCycleDisabled,
        maxUserCount=maxUserCount, maxSubscriberCount=maxSubscriberCount, apiEventData=apiEventData, customerType=customerType, 
        serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId, exemptionCodeList=exemptionCodeList, multiRequestBuild=multiRequestBuild)

#=============================================================
def addSubscriberToGroup(V3inst, groupId, subscriberId, subQueryType='ExternalId', groupQueryType='ExternalId',
        apiEventData=None, eventPass=True, now=None, executeMode=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    #print "DEBUG: in QA_subscriber_management_restv3.py. subscriberId=", subscriberId
    return SUBMAN.addSubscriberToGroup(V3inst=V3inst, groupId=groupId, subscriberId=subscriberId, apiEventData=apiEventData,
        subQueryType=subQueryType, groupQueryType=groupQueryType, eventPass=eventPass, now=now, executeMode=executeMode, multiRequestBuild=multiRequestBuild)

#=============================================================
def addGroupMembership(V3inst, groupId, subscribers=None, subGroups=None, subQueryType='ExternalId',
        subGroupQueryType='ExternalId', groupQueryType='ExternalId', eventPass=True, now=None,
        admins=None, adminQueryType='ExternalId', apiEventData=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.addGroupMembership(V3inst=V3inst, groupId=groupId, subscribers=subscribers, subGroups=subGroups,
        subQueryType=subQueryType, subGroupQueryType=subGroupQueryType, groupQueryType=groupQueryType,
        eventPass=eventPass, now=now, admins=admins, adminQueryType=adminQueryType, apiEventData=apiEventData,
        multiRequestBuild=multiRequestBuild)

#=============================================================
def removeGroupMembership(V3inst, groupId, subscribers=None, subGroups=None, subQueryType='ExternalId',
        subGroupQueryType='ExternalId', groupQueryType='ExternalId', eventPass=True, now=None,
        admins=None, adminQueryType='ExternalId', apiEventData=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.removeGroupMembership(V3inst=V3inst, groupId=groupId, subscribers=subscribers, subGroups=subGroups,
        subQueryType=subQueryType, subGroupQueryType=subGroupQueryType, groupQueryType=groupQueryType,
        eventPass=eventPass, now=now, admins=admins, adminQueryType=adminQueryType, apiEventData=apiEventData,
        multiRequestBuild=multiRequestBuild)

#=============================================================
def removeSubscriberFromGroup(V3inst, groupId, subscriberId, subQueryType='ExternalId', groupQueryType='ExternalId',
        apiEventData=None, eventPass=True, now=None, executeMode=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.removeSubscriberFromGroup(V3inst=V3inst, groupId=groupId, subscriberId=subscriberId, apiEventData=apiEventData,
        subQueryType=subQueryType, groupQueryType=groupQueryType, eventPass=eventPass, now=now, executeMode=executeMode, multiRequestBuild=multiRequestBuild)

#=============================================================
def addSubGroupToGroup(V3inst, groupId, subGroupId, subQueryType='ExternalId', groupQueryType='ExternalId',
        apiEventData=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.addSubGroupToGroup(V3inst=V3inst, groupId=groupId, subGroupId=subGroupId, subQueryType=subQueryType,
        groupQueryType=groupQueryType, apiEventData=apiEventData, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def removeSubGroupFromGroup(V3inst, groupId, subGroupId, subQueryType='ExternalId', groupQueryType='ExternalId',
        apiEventData=None, eventPass=True, now=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.removeSubGroupFromGroup(V3inst=V3inst, groupId=groupId, subGroupId=subGroupId, apiEventData=apiEventData,
        subQueryType=subQueryType, groupQueryType=groupQueryType, eventPass=eventPass, now=now, multiRequestBuild=multiRequestBuild)

#=============================================================
def addAdminToGroup(V3inst, groupId, subscriberId, subQueryType='ExternalId', groupQueryType='ExternalId',
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.addAdminToGroup(V3inst=V3inst, groupId=groupId, subscriberId=subscriberId, subQueryType=subQueryType,
        groupQueryType=groupQueryType, now=now, eventPass=eventPass, executeMode=executeMode, apiEventData=apiEventData,
        multiRequestBuild=multiRequestBuild)

#=============================================================
def removeAdminFromGroup(V3inst, groupId, subscriberId, subQueryType='ExternalId', groupQueryType='ExternalId',
        eventPass=True, now=None, executeMode=None, apiEventData=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.removeAdminFromGroup(V3inst=V3inst, groupId=groupId, admins=subscriberId,
        adminQueryType=subQueryType, groupQueryType=groupQueryType, eventPass=eventPass, now=now, executeMode=executeMode,
        apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

#=============================================================
def groupSubscribeToOffer(V3inst, groupId, offerId=None, deviceId=None, allDevices=True, catalogItemId=None,
        offerStartTime=None, offerEndTime=None, serviceId=None, eventPass=True, queryType='ExternalId', now=None,
        offerIsExternal=False, attr=None, dupAttr=True, chargeMethodAttr=None, chargeMethod=None,
        paymentMethodResourceId=None, paymentGatewayUserId=None, paymentGatewayId=None, paymentGatewayOneTimeToken=None,
        paymentDueDate=None, etcScheduleRangeArray=None, etcScheduleRangeUnit=None, paymentScheduleRangeArray=None,
        paymentScheduleAmountArray=None, paymentScheduleLastAmount=None, delayCharge=None,
        deferredSettlement=None, deferredSettlementTimeout=None, deferredSettlementTimeoutAction=None,
        purchaseInfo=False, executeMode=None, offerCycleType=None, offerCycleResourceId=None, offerCycleOffset=None, offerCycleStartTime=None, 
        preActiveState=None, autoActivationTime=None, autoActivationRelativeOffsetUnit=None, autoActivationRelativeOffset=None, autoActivationCycleResourceId=None,
        activationExpirationTime=None, activationExpirationRelativeOffsetUnit=None, parameterList=None,
        contractPeriod=None, contractInterval=None, commitmentPeriod=None, commitmentPeriodInterval=None, isOpenContract=None,
        activationExpirationRelativeOffset=None, endTimeRelativeOffsetUnit=None, endTimeRelativeOffset=None, downPayment=None, isRecurringFailureAllowed=None,
        isPendingActivationAllowed=None, offerLifecycleProfileId=None,
        chargePurchaseProrationType=None, grantPurchaseProrationType=None, reason=None, info=None, apiEventData=None,
        routingType=None, routingValue=None, offerStatusValue=None, multiRequestBuild=None,  eligibilityCheck=None, geoData=None, endAfterCycleCount=None, noEndTime=None):
        
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)
    if offerStartTime is not None:
        offerStartTime = MDCTIME.convertTime(offerStartTime, restVersion=restVersion)
    if offerEndTime is not None:
        offerEndTime = MDCTIME.convertTime(offerEndTime, restVersion=restVersion)

    #print 'group subscribe to offer.  offerStartTime = ' + str(offerStartTime) + ', offerEndTime = ' + str(offerEndTime) + ', now = ' + str(now)
    return SUBMAN.groupSubscribeToOffer(V3inst=V3inst, groupId=groupId, offerId=offerId, catalogItemId=catalogItemId,
        offerStartTime=offerStartTime, offerEndTime=offerEndTime, eventPass=eventPass, queryType=queryType, now=now,
        offerIsExternal=offerIsExternal, attr=attr, dupAttr=dupAttr, chargeMethod=chargeMethod,
        paymentMethodResourceId=paymentMethodResourceId, paymentGatewayUserId=paymentGatewayUserId, paymentGatewayId=paymentGatewayId, paymentDueDate=paymentDueDate, etcScheduleRangeArray=etcScheduleRangeArray, etcScheduleRangeUnit=etcScheduleRangeUnit, paymentScheduleRangeArray=paymentScheduleRangeArray, paymentScheduleAmountArray=paymentScheduleAmountArray, paymentScheduleLastAmount=paymentScheduleLastAmount, delayCharge=delayCharge, chargeMethodAttr=chargeMethodAttr, paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, purchaseInfo=purchaseInfo, executeMode=executeMode, 
        deferredSettlement=deferredSettlement, deferredSettlementTimeout=deferredSettlementTimeout,
        deferredSettlementTimeoutAction=deferredSettlementTimeoutAction,
        offerCycleType=offerCycleType, offerCycleResourceId=offerCycleResourceId, offerCycleOffset=offerCycleOffset, offerCycleStartTime=offerCycleStartTime,
        preActiveState=preActiveState, autoActivationTime=autoActivationTime, autoActivationRelativeOffsetUnit=autoActivationRelativeOffsetUnit,
        autoActivationRelativeOffset=autoActivationRelativeOffset, autoActivationCycleResourceId=autoActivationCycleResourceId,
        activationExpirationTime=activationExpirationTime, activationExpirationRelativeOffsetUnit=activationExpirationRelativeOffsetUnit,
        activationExpirationRelativeOffset=activationExpirationRelativeOffset, endTimeRelativeOffsetUnit=endTimeRelativeOffsetUnit,
        contractPeriod=contractPeriod, contractInterval=contractInterval, commitmentPeriod=commitmentPeriod, commitmentPeriodInterval=commitmentPeriodInterval, isOpenContract=isOpenContract,
        endTimeRelativeOffset=endTimeRelativeOffset, downPayment=downPayment, isRecurringFailureAllowed=isRecurringFailureAllowed,
        isPendingActivationAllowed=isPendingActivationAllowed, offerLifecycleProfileId=offerLifecycleProfileId,
        chargePurchaseProrationType=chargePurchaseProrationType, grantPurchaseProrationType=grantPurchaseProrationType, reason=reason, info=info, routingType=routingType, routingValue=routingValue,
        apiEventData=apiEventData,  offerStatusValue=offerStatusValue, parameterList=parameterList, multiRequestBuild=multiRequestBuild,  eligibilityCheck=eligibilityCheck, geoData=geoData, endAfterCycleCount=endAfterCycleCount, noEndTime=noEndTime)

#=============================================================
def groupUnsubscribeFromOffer(V3inst, groupId, resourceIds, now=None, eventPass=True, queryType='ExternalId',
        cancelInfo=False, executeMode=None, apiEventData=None, multiRequestBuild=None, eligibilityCheck=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupUnsubscribeFromOffer(V3inst=V3inst, groupId=groupId, resourceIds=resourceIds, now=now,
        eventPass=eventPass, queryType=queryType, cancelInfo=cancelInfo, executeMode=executeMode, 
        apiEventData=apiEventData, multiRequestBuild=multiRequestBuild, eligibilityCheck=eligibilityCheck)

#========================================================
def groupCancelOffer(V3inst, queryValue, resourceId=0, cancelType=None, grantCancelProrationType=None, chargeCancelProrationType=None,
        reason=None, info=None, cancelOfferDataList='', now=None, queryType='ExternalId', cancelInfo=False, eventPass=True, executeMode=None,
        contractCancelMode=None, debtCancellationMode=None, multiRequestBuild=None, isWaiveEarlyTerminationCharge=None, eligibilityCheck=None,
        apiEventData=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupCancelOffer(V3inst=V3inst, queryValue=queryValue, resourceId=resourceId,
        cancelType=cancelType, grantCancelProrationType=grantCancelProrationType, chargeCancelProrationType=chargeCancelProrationType,
        reason=reason, info=info, now=now, queryType=queryType, cancelOfferDataList=cancelOfferDataList, cancelInfo=cancelInfo,
        eventPass=eventPass, executeMode=executeMode, contractCancelMode=contractCancelMode, debtCancellationMode=debtCancellationMode, multiRequestBuild=multiRequestBuild,
        isWaiveEarlyTerminationCharge=isWaiveEarlyTerminationCharge,  eligibilityCheck=eligibilityCheck, apiEventData=apiEventData)

# Update group threshold
#========================================================
def addGroupThreshold(V3inst, groupId, thresholdId, resourceId=None, threshName=None, val=None,
        notify=None, eventPass=True, now=None, queryType='ExternalId', recurringStart=None, recurringStop=None, virtualCreditLimitIsPercent=None,
        rechargeAmount=None, rechargePaymentMethodResourceId=None, isTemporaryCreditLimit=None,
        apiEventData=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.addGroupThreshold(V3inst=V3inst, groupId=groupId, thresholdId=thresholdId, resourceId=resourceId,
        threshName=threshName, val=val, notify=notify, eventPass=eventPass, now=now, queryType=queryType, recurringStart=recurringStart,
         recurringStop=recurringStop, virtualCreditLimitIsPercent=virtualCreditLimitIsPercent,
         rechargeAmount=rechargeAmount, rechargePaymentMethodResourceId=rechargePaymentMethodResourceId,
         isTemporaryCreditLimit=isTemporaryCreditLimit, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

# Undo custom group threshold
#========================================================
def removeGroupThreshold(V3inst, groupId, resourceId, thresholdId, now=None, queryType='ExternalId',
        removeThresholdOnly=None, removeRechargeDataOnly=None, isTemporaryCreditLimit=None,
        apiEventData=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.removeGroupThreshold(V3inst=V3inst, groupId=groupId, resourceId=resourceId, thresholdId=thresholdId,
        now=now, queryType=queryType, removeThresholdOnly=removeThresholdOnly, removeRechargeDataOnly=removeRechargeDataOnly,
        isTemporaryCreditLimit=isTemporaryCreditLimit, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

#=============================================================
def queryGroupThresholdRechargeDefn(V3inst, groupId, balanceResourceId=None, now=None, queryType='ExternalId', eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.queryGroupThresholdRechargeDefn(V3inst=V3inst, queryValue=groupId, queryType=queryType, balanceResourceId=balanceResourceId,
        now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def queryGroup(V3inst, queryValue, queryType='ExternalId', querySize=None,  now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, querySize=querySize, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def queryGroupWallet(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.queryGroupWallet(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now,
        eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
# Support old names...
def groupOfferModify(V3inst, queryValue, queryType='ExternalId', resourceId=None, startTime=None, endTime=None, eventPass=True, attr=None, now=None, executeMode=None,  cycleType=None, cycleResourceId=None, cycleOffset=None, cycleAlignmentDisabled=None, cycleStartTime=None, cycleEndTime=None, immediateChange=None, isRecurringFailureAllowed=None, status=None, offerStatusValue=None, modifyInfo=False, parameterList=None, apiEventData=None, multiRequestBuild=None, endTimeExtensionOffset=None, endTimeExtensionOffsetUnit=None, endAfterCycleCount=None, noEndTime=None):
        return groupModifyOffer(V3inst, queryValue, queryType, resourceId, startTime, endTime, eventPass, attr, now, executeMode, cycleType, cycleResourceId, cycleOffset, cycleAlignmentDisabled, cycleStartTime, cycleEndTime, immediateChange, isRecurringFailureAllowed, status, offerStatusValue, modifyInfo, parameterList, apiEventData, multiRequestBuild=multiRequestBuild, endTimeExtensionOffset=endTimeExtensionOffset, endTimeExtensionOffsetUnit=endTimeExtensionOffsetUnit, endAfterCycleCount=endAfterCycleCount, noEndTime=noEndTime)

#=============================================================
def groupModifyOffer(V3inst, queryValue, queryType='ExternalId', resourceId=None, startTime=None, endTime=None, eventPass=True, attr=None, now=None, executeMode=None,  cycleType=None, cycleResourceId=None, cycleOffset=None, cycleAlignmentDisabled=None, cycleStartTime=None, cycleEndTime=None, immediateChange=None, isRecurringFailureAllowed=None, status=None, offerStatusValue=None, modifyInfo=False, parameterList=None, apiEventData=None, multiRequestBuild=None, endTimeExtensionOffset=None, endTimeExtensionOffsetUnit=None, endAfterCycleCount=None, noEndTime=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupModifyOffer(V3inst, queryType, queryValue, resourceId, now=now,
            startTime=startTime, endTime=endTime, attr=attr, eventPass=eventPass, executeMode=executeMode, cycleType=cycleType, cycleResourceId=cycleResourceId, cycleOffset=cycleOffset, cycleAlignmentDisabled=cycleAlignmentDisabled, cycleStartTime=cycleStartTime, cycleEndTime=cycleEndTime, immediateChange=immediateChange, isRecurringFailureAllowed=isRecurringFailureAllowed, status=status, offerStatusValue=offerStatusValue, modifyInfo=modifyInfo, parameterList=parameterList, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild, endTimeExtensionOffset=endTimeExtensionOffset, endTimeExtensionOffsetUnit=endTimeExtensionOffsetUnit, endAfterCycleCount=endAfterCycleCount, noEndTime=noEndTime)

# Group Modify Status
#=============================================================
def groupModifyStatus(V3inst, queryValue=None, statusTransitionTime=None, statusValue=None, queryType='ExternalId', now=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupModifyStatus(V3inst, queryValue=queryValue, statusTransitionTime=statusTransitionTime,
       statusValue=statusValue, queryType=queryType, apiEventData=apiEventData, executeMode=executeMode, now=now,
       routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild, eventPass=eventPass)

# Group Remove Scheduled Status Change
#=============================================================
def groupRemoveScheduledStatusChange(V3inst, queryValue=None, queryType='ExternalId', now=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupRemoveScheduledStatusChange(V3inst, queryValue=queryValue, queryType=queryType, apiEventData=apiEventData, executeMode=executeMode, now=now,
       routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild, eventPass=eventPass)

# Group Suspend Offer
#=============================================================
def groupSuspendOffer(V3inst, queryValue=None, resourceId=None, scheduledSuspendTime=None, queryType='ExternalId', now=None,
                           autoResumeRelativeOffset=None, autoResumeRelativeOffsetUnit=None, autoResumeTime=None,
                           isPauseMode=None, grantSuspendProrationType=None, chargeSuspendProrationType=None,
                           grantResumeProrationType=None, chargeResumeProrationType=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupSuspendOffer(V3inst, queryValue=queryValue, resourceId=resourceId,
       scheduledSuspendTime=scheduledSuspendTime, queryType=queryType, now=now,
       autoResumeRelativeOffset=autoResumeRelativeOffset, autoResumeRelativeOffsetUnit=autoResumeRelativeOffsetUnit,
       autoResumeTime=autoResumeTime, isPauseMode=isPauseMode, grantSuspendProrationType=grantSuspendProrationType,
       chargeSuspendProrationType=chargeSuspendProrationType, grantResumeProrationType=grantResumeProrationType,
       chargeResumeProrationType=chargeResumeProrationType, apiEventData=apiEventData,
       routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild, eventPass=eventPass)

# Group Resume Offer
#=============================================================
def groupResumeOffer(V3inst, queryValue=None, resourceId=None, scheduledResumeTime=None, queryType='ExternalId', now=None,
                           resumeRelativeOffset=None, resumeRelativeOffsetUnit=None, grantResumeProrationType=None,
                           chargeResumeProrationType=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupResumeOffer(V3inst, queryValue=queryValue, resourceId=resourceId,
       scheduledResumeTime=scheduledResumeTime, queryType=queryType, now=now,
       resumeRelativeOffset=resumeRelativeOffset, resumeRelativeOffsetUnit=resumeRelativeOffsetUnit,
       grantResumeProrationType=grantResumeProrationType,
       chargeResumeProrationType=chargeResumeProrationType, apiEventData=apiEventData,
       routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild, eventPass=eventPass)

# Group Remove Scheduled Offer Status Change
#=============================================================
def groupRemoveScheduledOfferStatusChange(V3inst, queryValue=None, queryType='ExternalId', now=None, resourceId=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupRemoveScheduledOfferStatusChange(V3inst, queryValue=queryValue, queryType=queryType, resourceId=resourceId,
       apiEventData=apiEventData, executeMode=executeMode, now=now,
       routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild, eventPass=eventPass)

#=============================================================
def groupActivateOffer(V3inst, queryValue, queryType='ExternalId', resourceId=None, now=None, eventPass=True,
                       routingType=None, routingValue=None, executeMode=None, apiEventData=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupActivateOffer(V3inst, queryValue, queryType, resourceId=resourceId, now=now, executeMode=executeMode,
                                     routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild,
                                     apiEventData=apiEventData, eventPass=eventPass)

#=============================================================
def deleteGroup(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True, apiEventData=None,multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.deleteGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass,
                              apiEventData=apiEventData, multiRequestBuild=None)

#=============================================================
def deleteSubscriber(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True, deleteDevices=False, deleteSession=False,
                     apiEventData=None,multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.deleteSubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass,
            deleteDevices=deleteDevices, deleteSession=deleteSession, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)  

#api for large group
#=============================================================
def querySubscriberMembership(V3inst,queryValue, membershipType='groups', queryType='ExternalId', 
            queryCursor=None, querySize=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    (response, queryCursor) = SUBMAN.querySubscriberMembership(V3inst=V3inst, queryValue=queryValue, queryType=queryType, membershipType=membershipType,
            queryCursor=queryCursor, querySize=querySize, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)
    
    return (response, queryCursor)
    
#api for large group
#=============================================================
def queryGroupMembership(V3inst,queryValue, membershipType='1', queryType='ExternalId', 
            queryCursor=None, querySize=None, now=None, eventPass=True, returnExternalId=False, multiRequestBuild=None):
    # membershipType values are: 1 = Subscribers, 2 = Sub-Groups, 3 = Administrators
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    (response, queryCursor) =  SUBMAN.queryGroupMembership(V3inst=V3inst, queryValue=queryValue, queryType=queryType, membershipType=membershipType,
            queryCursor=queryCursor, querySize=querySize, now=now, eventPass=eventPass, returnExternalId=returnExternalId, multiRequestBuild=multiRequestBuild)
    
    return (response, queryCursor)
    
#=============================================================
def queryGroupCursor(V3inst, queryValue, queryType='ExternalId', querySize=None,  now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    (response, queryDict) = SUBMAN.queryGroupCursor(V3inst=V3inst, queryValue=queryValue, queryType=queryType, querySize=querySize, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

    return (response, queryDict)
    
#=============================================================
def querySubscriberCursor(V3inst, queryValue, queryType='ExternalId', querySize=None,  now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    (response, queryDict) = SUBMAN.querySubscriberCursor(V3inst=V3inst, queryValue=queryValue, queryType=queryType, querySize=querySize, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

    return (response, queryDict)
    
#=============================================================
# Helper function to create billing cycle data to add to subscriber or group
#=============================================================
def createBillingCycleData(templateId, dateOffset=None, startTime=None, immediateChange=None):
    return SUBMAN.createBillingCycleData(templateId=templateId, dateOffset=dateOffset, startTime=startTime, immediateChange=immediateChange)

#=============================================================
def createEventDictionary(eventTime=None, requestType=None, requestedAmount=None, usedAmount=None, testTag='',
        deviceId=0, serviceId=None, extraAVP={}):
    return {'EventTime':eventTime, 'RequestType':requestType, 'RequestedAmount':requestedAmount,
        'UsedAmount':usedAmount, 'TestTag':testTag, 'DeviceId':deviceId, 'ServiceId':serviceId, 'ExtraAVP':extraAVP}

# Adjust subscriber balance- adjustType 1 for credit, 2 for debit, 3 for meter reset
#=============================================================
def subscriberAdjustBalance(V3inst, queryValue=None, balanceResourceId=None, adjustType=None, amount=None, reason=None, queryType='PhoneNumber', componentMeterId=None,
        info=None, endTime=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None, now=None, creditLimitPolicy=None,
        apiEventData=None, startTime=None, eventPass=True, multiRequestBuild=None,executeMode=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberAdjustBalance(V3inst=V3inst, queryValue=queryValue, balanceResourceId=balanceResourceId, componentMeterId=componentMeterId, 
        adjustType=adjustType, amount=amount, reason=reason, queryType=queryType, info=info, endTime=endTime, endTimeExtensionOffsetUnit=endTimeExtensionOffsetUnit,executeMode=executeMode, endTimeExtensionOffset=endTimeExtensionOffset, now=now, creditLimitPolicy=creditLimitPolicy,
        apiEventData=apiEventData, startTime=startTime, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Transfer subscriber balance
#=============================================================
def subscriberTransferBalance(V3inst, queryValue, balanceResourceId, amount, amountIsPct=False, queryType='PhoneNumber', targetSubscriberSearchData=None,
        targetGroupSearchData=None, targetQueryType='PhoneNumber', targetBalanceResourceId=None, sourceIsEventInitiator=None, creditFloorPolicy=None,
        apiEventData=None, reason=None, info=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberTransferBalance(V3inst=V3inst, queryValue=queryValue, balanceResourceId=balanceResourceId, amount=amount, amountIsPct=amountIsPct,
        queryType=queryType, targetSubscriberSearchData=targetSubscriberSearchData, targetGroupSearchData=targetGroupSearchData, targetQueryType=targetQueryType,
        targetBalanceResourceId=targetBalanceResourceId, sourceIsEventInitiator=sourceIsEventInitiator, creditFloorPolicy=creditFloorPolicy,
        reason=reason, info=info, apiEventData=apiEventData, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def subscriberTopupBalance(V3inst, queryValue, balanceResourceId, amount, voucher, queryType='PhoneNumber', endTime=None, endTimeExtensionOffsetUnit=None,
            apiEventData=None, endTimeExtensionOffset=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberTopupBalance(V3inst=V3inst, queryValue=queryValue, balanceResourceId=balanceResourceId,
        amount=amount, voucher=voucher, queryType=queryType, endTime=endTime, endTimeExtensionOffsetUnit=endTimeExtensionOffsetUnit,
        apiEventData=apiEventData, endTimeExtensionOffset=endTimeExtensionOffset, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Recharge Subscriber
#=============================================================
def subscriberRecharge(V3inst, queryValue, amount, balanceResourceId=None, payNow=None,
        queryType='PhoneNumber', endTime=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
        paymentMethodResourceId=None, paymentGatewayId=None, paymentGatewayOneTimeToken=None, info=None, reason=None,
        paymentGatewayUserId=None, chargeMethodAttr=None, rechargeAttr=None, now=None, eventPass=True, executeMode=None,
        apiEventData=None, payload=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberRecharge(V3inst=V3inst, queryValue=queryValue, amount=amount, balanceResourceId=balanceResourceId,
        payNow=payNow, queryType=queryType, endTime=endTime, endTimeExtensionOffsetUnit=endTimeExtensionOffsetUnit,
        endTimeExtensionOffset=endTimeExtensionOffset, paymentMethodResourceId=paymentMethodResourceId, 
        paymentGatewayId=paymentGatewayId, paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, info=info,
        chargeMethodAttr=chargeMethodAttr, reason=reason, paymentGatewayUserId=paymentGatewayUserId, rechargeAttr=rechargeAttr,
        apiEventData=apiEventData, now=now, eventPass=eventPass, executeMode=executeMode, payload=payload, multiRequestBuild=multiRequestBuild)

# Subscriber Recharge Schedule
#=============================================================
def subscriberAddRechargeSchedule(V3inst, queryValue, firstRechargeTime=None, queryType='ExternalId', 
        periodType=None, periodCoef=None, cycleTimeOfDay=None, cycleOffset=None,
        amount=None, paymentMethodResourceId=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
        scheduledRechargeNotificationProfileId=None, now=None, eventPass=True, executeMode=None,
        apiEventData=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberAddRechargeSchedule(V3inst=V3inst, queryValue=queryValue, firstRechargeTime=firstRechargeTime, queryType=queryType,
        periodType=periodType, periodCoef=periodCoef, cycleTimeOfDay=cycleTimeOfDay, cycleOffset=cycleOffset,
        amount=amount, paymentMethodResourceId=paymentMethodResourceId, endTimeExtensionOffsetUnit=endTimeExtensionOffsetUnit, 
        endTimeExtensionOffset=endTimeExtensionOffset, scheduledRechargeNotificationProfileId=scheduledRechargeNotificationProfileId,
        now=now, eventPass=eventPass, executeMode=executeMode, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

# Modify Subscriber Recharge Schedule
#=============================================================
def subscriberModifyRechargeSchedule(V3inst, queryValue, nextRechargeTime=None, queryType='ExternalId',
        periodType=None, periodCoef=None, cycleTimeOfDay=None, cycleOffset=None,
        amount=None, paymentMethodResourceId=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
        scheduledRechargeNotificationProfileId=None, now=None, eventPass=True, executeMode=None,
        apiEventData=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberModifyRechargeSchedule(V3inst=V3inst, queryValue=queryValue, nextRechargeTime=nextRechargeTime, queryType=queryType,
        periodType=periodType, periodCoef=periodCoef, cycleTimeOfDay=cycleTimeOfDay, cycleOffset=cycleOffset,
        amount=amount, paymentMethodResourceId=paymentMethodResourceId, endTimeExtensionOffsetUnit=endTimeExtensionOffsetUnit,
        endTimeExtensionOffset=endTimeExtensionOffset, scheduledRechargeNotificationProfileId=scheduledRechargeNotificationProfileId,
        now=now, eventPass=eventPass, executeMode=executeMode, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

# Remove Subscriber Recharge Schedule
#=============================================================
def subscriberRemoveRechargeSchedule(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True, executeMode=None,
        apiEventData=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberRemoveRechargeSchedule(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        now=now, eventPass=eventPass, executeMode=executeMode, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

# Query Subscriber Recharge Schedule
#=============================================================
def subscriberQueryRechargeSchedule(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberQueryRechargeSchedule(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        now=now, eventPass=eventPass, executeMode=executeMode, multiRequestBuild=multiRequestBuild)

# Query Subscriber Recurring Charge
#=============================================================
def subscriberQueryRecurringRecharge(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberQueryRecurringRecharge(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        now=now, eventPass=eventPass, executeMode=executeMode, multiRequestBuild=multiRequestBuild)

# add a balance expiry recharge definition
#=============================================================
def subscriberAddBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId', balanceResourceId=None,
        durationBeforeExpiryInMinutes=None, notificationProfileId=None, paymentMethodResourceId=None, rechargeAmount=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberAddBalanceExpiryRechargeDefn(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        balanceResourceId=balanceResourceId, durationBeforeExpiryInMinutes=durationBeforeExpiryInMinutes, notificationProfileId=notificationProfileId,
        paymentMethodResourceId=paymentMethodResourceId, rechargeAmount=rechargeAmount, now=now, eventPass=eventPass,
        executeMode=executeMode, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

# modify a balance expiry recharge definition
#=============================================================
def subscriberModifyBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId', balanceResourceId=None,
        durationBeforeExpiryInMinutes=None, notificationProfileId=None, paymentMethodResourceId=None, rechargeAmount=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberModifyBalanceExpiryRechargeDefn(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        balanceResourceId=balanceResourceId, durationBeforeExpiryInMinutes=durationBeforeExpiryInMinutes, notificationProfileId=notificationProfileId,
        paymentMethodResourceId=paymentMethodResourceId, rechargeAmount=rechargeAmount, now=now, eventPass=eventPass,
        executeMode=executeMode, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

# delete a balance expiry recharge definition
#=============================================================
def subscriberRemoveBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId', balanceResourceId=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberRemoveBalanceExpiryRechargeDefn(V3inst=V3inst, queryValue=queryValue, queryType=queryType, balanceResourceId=balanceResourceId,
        now=now, eventPass=eventPass, executeMode=executeMode, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

# query a balance expiry recharge definition
#=============================================================
def subscriberQueryBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId',
        now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberQueryBalanceExpiryRechargeDefn(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        now=now, eventPass=eventPass, executeMode=executeMode, multiRequestBuild=multiRequestBuild)


# Subscriber make refund
#=============================================================
def subscriberRefundPayment(V3inst, queryValue, queryType='PhoneNumber', resourceId=None, balanceResourceId=None,
        amount=None, reason=None, info=None, apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
     
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberRefundPayment(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        balanceResourceId=balanceResourceId, resourceId=resourceId, amount=amount, reason=reason, info=info,
        apiEventData=apiEventData, now=now, eventPass=eventPass, executeMode=executeMode, multiRequestBuild=multiRequestBuild)

# Query Subscriber Payment History
#=============================================================
def subscriberQueryPaymentHistory(V3inst, queryValue, queryType='PhoneNumber', now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberQueryPaymentHistory(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        now=now, eventPass=eventPass, executeMode=executeMode, multiRequestBuild=multiRequestBuild)

# Modify Subscriber External Payments
#=============================================================
def subscriberModifyExternalPayment(V3inst, queryValue, queryType='ExternalId',
        amount=None, resourceId=None, info=None, reason=None, opType=None,
        apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberModifyExternalPayment(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        amount=amount, resourceId=resourceId, info=info, reason=reason, opType=opType,
        apiEventData=apiEventData, now=now, eventPass=eventPass, executeMode=executeMode, multiRequestBuild=multiRequestBuild)

# Query Subscriber External Payments
#=============================================================
def subscriberQueryExternalPayment(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberQueryExternalPayment(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        now=now, eventPass=eventPass, executeMode=executeMode, multiRequestBuild=multiRequestBuild)

# Estimate the Subscribers Recurring Charge
#=============================================================
def subscriberEstimateRecurringCharge(V3inst, queryValue, queryType='ObjectId', now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberEstimateRecurringCharge(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, 
        eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Adjust group balance- adjustType 1 for credit, 2 for debit, 3 for meter reset
#=============================================================
def groupAdjustBalance(V3inst, queryValue, balanceResourceId, adjustType, amount, reason, componentMeterId=None, queryType='ExternalId',
        info=None, endTime=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None, now=None, creditLimitPolicy=None,
        apiEventData=None, startTime=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupAdjustBalance(V3inst=V3inst, queryValue=queryValue, balanceResourceId=balanceResourceId, componentMeterId=componentMeterId,
        adjustType=adjustType, amount=amount, reason=reason, queryType=queryType, info=info, endTime=endTime, endTimeExtensionOffsetUnit=endTimeExtensionOffsetUnit,
        endTimeExtensionOffset=endTimeExtensionOffset, now=now, creditLimitPolicy=creditLimitPolicy,
        apiEventData=apiEventData, startTime=startTime, eventPass=eventPass, executeMode=executeMode, multiRequestBuild=multiRequestBuild)

# Transfer group balance
#=============================================================
def groupTransferBalance(V3inst, queryValue, balanceResourceId, amount, queryType='PhoneNumber', amountIsPct=False,
        targetSubscriberSearchData=None, targetGroupSearchData=None, targetQueryType='PhoneNumber', targetBalanceResourceId=None,
         sourceIsEventInitiator=None, creditFloorPolicy=None, reason=None, info=None,
         apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupTransferBalance(V3inst=V3inst, queryValue=queryValue, queryType=queryType, balanceResourceId=balanceResourceId,
        amount=amount, amountIsPct=amountIsPct,  targetSubscriberSearchData=targetSubscriberSearchData,
        targetGroupSearchData=targetGroupSearchData, targetQueryType=targetQueryType, targetBalanceResourceId=targetBalanceResourceId,
        sourceIsEventInitiator=sourceIsEventInitiator, creditFloorPolicy=creditFloorPolicy, reason=reason, info=info,
        apiEventData=apiEventData, now=now, eventPass=eventPass, executeMode=executeMode, multiRequestBuild=multiRequestBuild)

#=============================================================
def groupTopupBalance(V3inst, queryValue, balanceResourceId, amount, voucher, queryType='ExternalId', endTime=None, endTimeExtensionOffsetUnit=None,
         endTimeExtensionOffset=None, apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupTopupBalance(V3inst=V3inst, queryValue=queryValue, balanceResourceId=balanceResourceId,
        amount=amount, voucher=voucher, queryType=queryType, endTime=endTime, endTimeExtensionOffsetUnit=endTimeExtensionOffsetUnit,
        endTimeExtensionOffset=endTimeExtensionOffset, now=now, eventPass=eventPass, executeMode=executeMode,
        apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

# Recharge Group
#=============================================================
def groupRecharge(V3inst, queryValue, amount, balanceResourceId=None, payNow=None, queryType='ExternalId',
        endTime=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None, paymentGatewayUserId=None,
        paymentMethodResourceId=None, paymentGatewayId=None, paymentGatewayOneTimeToken=None, info=None, reason=None,
        chargeMethodAttr=None, rechargeAttr=None, now=None, eventPass=True, executeMode=None, payload=True,
        apiEventData=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupRecharge(V3inst=V3inst, queryValue=queryValue, amount=amount, balanceResourceId=balanceResourceId,
        payNow=payNow, queryType=queryType, endTime=endTime, endTimeExtensionOffsetUnit=endTimeExtensionOffsetUnit,
        endTimeExtensionOffset=endTimeExtensionOffset, paymentMethodResourceId=paymentMethodResourceId, 
        paymentGatewayId=paymentGatewayId, paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, info=info,
        chargeMethodAttr=chargeMethodAttr, reason=reason, paymentGatewayUserId=paymentGatewayUserId, rechargeAttr=rechargeAttr,
        now=now, eventPass=eventPass, executeMode=executeMode, payload=payload, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

# Group Recharge Schedule
#=============================================================
def groupAddRechargeSchedule(V3inst, queryValue, firstRechargeTime=None, queryType='ExternalId',
        periodType=None, periodCoef=None, cycleTimeOfDay=None, cycleOffset=None,
        amount=None, paymentMethodResourceId=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
        scheduledRechargeNotificationProfileId=None, now=None, eventPass=True, executeMode=None, 
        apiEventData=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupAddRechargeSchedule(V3inst=V3inst, queryValue=queryValue, firstRechargeTime=firstRechargeTime, queryType=queryType,
        periodType=periodType, periodCoef=periodCoef, cycleTimeOfDay=cycleTimeOfDay, cycleOffset=cycleOffset,
        amount=amount, paymentMethodResourceId=paymentMethodResourceId, endTimeExtensionOffsetUnit=endTimeExtensionOffsetUnit,
        endTimeExtensionOffset=endTimeExtensionOffset, scheduledRechargeNotificationProfileId=scheduledRechargeNotificationProfileId,
        now=now, eventPass=eventPass, executeMode=executeMode, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

# Modify Group Recharge Schedule
#=============================================================
def groupModifyRechargeSchedule(V3inst, queryValue, nextRechargeTime=None, queryType='ExternalId',
        periodType=None, periodCoef=None, cycleTimeOfDay=None, cycleOffset=None,
        amount=None, paymentMethodResourceId=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
        scheduledRechargeNotificationProfileId=None, now=None, eventPass=True, executeMode=None, 
        apiEventData=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupModifyRechargeSchedule(V3inst=V3inst, queryValue=queryValue, nextRechargeTime=nextRechargeTime, queryType=queryType,
        periodType=periodType, periodCoef=periodCoef, cycleTimeOfDay=cycleTimeOfDay, cycleOffset=cycleOffset,
        amount=amount, paymentMethodResourceId=paymentMethodResourceId, endTimeExtensionOffsetUnit=endTimeExtensionOffsetUnit,
        endTimeExtensionOffset=endTimeExtensionOffset, scheduledRechargeNotificationProfileId=scheduledRechargeNotificationProfileId,
        now=now, eventPass=eventPass, executeMode=executeMode, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

# Remove Group Recharge Schedule
#=============================================================
def groupRemoveRechargeSchedule(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True, executeMode=None,
        apiEventData=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupRemoveRechargeSchedule(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        now=now, eventPass=eventPass, executeMode=executeMode, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

# Query Group Recharge Schedule
#=============================================================
def groupQueryRechargeSchedule(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupQueryRechargeSchedule(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        now=now, eventPass=eventPass, executeMode=executeMode, multiRequestBuild=multiRequestBuild)

# Query Group Recharge Schedule
#=============================================================
def groupQueryRecurringRecharge(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupQueryRecurringRecharge(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        now=now, eventPass=eventPass, executeMode=executeMode, multiRequestBuild=multiRequestBuild)

# add a balance expiry recharge definition
#=============================================================
def groupAddBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId', balanceResourceId=None,
        durationBeforeExpiryInMinutes=None, notificationProfileId=None, paymentMethodResourceId=None, rechargeAmount=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None, apiEventSecurityInfo=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupAddBalanceExpiryRechargeDefn(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        balanceResourceId=balanceResourceId, durationBeforeExpiryInMinutes=durationBeforeExpiryInMinutes, notificationProfileId=notificationProfileId,
        paymentMethodResourceId=paymentMethodResourceId, rechargeAmount=rechargeAmount, now=now, eventPass=eventPass,
        executeMode=executeMode, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild, apiEventSecurityInfo=apiEventSecurityInfo)

# modify a balance expiry recharge definition
#=============================================================
def groupModifyBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId', balanceResourceId=None,
        durationBeforeExpiryInMinutes=None, notificationProfileId=None, paymentMethodResourceId=None, rechargeAmount=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupModifyBalanceExpiryRechargeDefn(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        balanceResourceId=balanceResourceId, durationBeforeExpiryInMinutes=durationBeforeExpiryInMinutes, notificationProfileId=notificationProfileId,
        paymentMethodResourceId=paymentMethodResourceId, rechargeAmount=rechargeAmount, now=now, eventPass=eventPass,
        executeMode=executeMode, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

# delete a balance expiry recharge definition
#=============================================================
def groupRemoveBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId', balanceResourceId=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupRemoveBalanceExpiryRechargeDefn(V3inst=V3inst, queryValue=queryValue, queryType=queryType, balanceResourceId=balanceResourceId,
        now=now, eventPass=eventPass, executeMode=executeMode, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

# query a balance expiry recharge definition
#=============================================================
def groupQueryBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId',
        now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupQueryBalanceExpiryRechargeDefn(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        now=now, eventPass=eventPass, executeMode=executeMode, multiRequestBuild=multiRequestBuild)


# Query Sys  Recurring Charge Configuration
#=============================================================
def sysQueryConfigRecurringRecharge(V3inst, eventPass=True, executeMode=None, multiRequestBuild=None):

    global restVersion

    return SUBMAN.sysQueryConfigRecurringRecharge(V3inst=V3inst, eventPass=eventPass, executeMode=executeMode, multiRequestBuild=multiRequestBuild)

# Group make refund
#=============================================================
def groupRefundPayment(V3inst, queryValue, queryType='ExternalId', balanceResourceId=None, resourceId=None,
        amount=None, reason=None, info=None, apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupRefundPayment(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        balanceResourceId=balanceResourceId, resourceId=resourceId, amount=amount, reason=reason, 
        info=info, apiEventData=apiEventData, now=now, eventPass=eventPass, executeMode=executeMode, multiRequestBuild=multiRequestBuild)

# Query Group Payment History
#=============================================================
def groupQueryPaymentHistory(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupQueryPaymentHistory(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        now=now, eventPass=eventPass, executeMode=executeMode, multiRequestBuild=multiRequestBuild)

# Modify Group External Payments
#=============================================================
def groupModifyExternalPayment(V3inst, queryValue, queryType='ExternalId',
        amount=None, resourceId=None, info=None, reason=None, opType=None,
        apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupModifyExternalPayment(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        amount=amount, resourceId=resourceId, info=info, reason=reason, opType=opType,
        apiEventData=apiEventData, now=now, eventPass=eventPass, executeMode=executeMode, multiRequestBuild=multiRequestBuild)

# Query Group External Payments
#=============================================================
def groupQueryExternalPayment(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupQueryExternalPayment(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        now=now, eventPass=eventPass, executeMode=executeMode, multiRequestBuild=multiRequestBuild)

# Estimate the Groups Recurring Charge
#=============================================================
def groupEstimateRecurringCharge(V3inst, queryValue, queryType='ObjectId', now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupEstimateRecurringCharge(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, 
        eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Get pricing metadata
#=============================================================
def pricingQueryStatus(V3inst, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingQueryStatus(V3inst=V3inst, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Get offer, default of queryType 'OfferId', 'ExternalId' for referencing offer by ExternalId
#=============================================================
def pricingQueryOffer(V3inst, offerId, queryType='OfferId', version=None, now=None, eventPass=True, useCache=False, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingQueryOffer(V3inst=V3inst, offerId=offerId, queryType=queryType, version=version, now=now, eventPass=eventPass, useCache=useCache, multiRequestBuild=multiRequestBuild)

#Per Dev, the url for cache pricing is different from non cache call, hence separate API added
#=============================================================
def pricingCacheQueryOffer(V3inst, queryValue=None, queryType='offers', version=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingCacheQueryOffer(V3inst=V3inst, queryValue=queryValue, queryType=queryType, version=version, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)
# Get offers
#=============================================================
def pricingQueryOfferList(V3inst, now=None, globalList=False, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingQueryOfferList(V3inst=V3inst, now=now, globalList=globalList, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def pricingCacheQueryOfferList(V3inst, now=None, eventPass=True, queryType='offers', multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingCacheQueryOfferList(V3inst=V3inst, now=now, queryType=queryType, eventPass=eventPass, multiRequestBuild=multiRequestBuild)
# Get balance- 'BalanceId' is only currently supported queryType
#=============================================================
def pricingQueryBalance(V3inst, balanceId, queryType='BalanceId', now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingQueryBalance(V3inst=V3inst, balanceId=balanceId, queryType=queryType, now=now,
        eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Get balances
#=============================================================
def pricingQueryBalanceList(V3inst, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingQueryBalanceList(V3inst=V3inst, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Get lifecycle based on given objectType
#=============================================================
def pricingQueryLifecycle(V3inst, objectType, lifecycleProfileId=None, now=None, eventPass=True, useCache=False, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingQueryLifecycle(V3inst=V3inst, objectType=objectType, lifecycleProfileId=lifecycleProfileId, now=now,
                                        eventPass=eventPass, useCache=useCache, multiRequestBuild=multiRequestBuild)

#=============================================================
def pricingQueryServiceType(V3inst, queryType='ServiceTypeId', queryValue=None,  now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingQueryServiceType(V3inst=V3inst, queryType=queryType, queryValue=queryValue, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)


# Get service type list
#=============================================================
def pricingQueryServiceTypeList(V3inst,  now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingQueryServiceTypeList(V3inst=V3inst, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)


# Get service context 
#=============================================================
def pricingQueryServiceContext(V3inst, serviceQueryType='ServiceTypeId', serviceQueryValue=None, contextQueryType='ContextId', contextQueryValue=None,  now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingQueryServiceContext(V3inst=V3inst, serviceQueryType=serviceQueryType, serviceQueryValue=serviceQueryValue, contextQueryType=contextQueryType,
                                           contextQueryValue=contextQueryValue,  now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Get balance class 
#=============================================================
def pricingQueryBalanceClass(V3inst, queryType='BalanceClassId', queryValue=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingQueryBalanceClass(V3inst=V3inst, queryType=queryType, queryValue=queryValue, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Get balance class list
#=============================================================
def pricingQueryBalanceClassList(V3inst, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingQueryBalanceClassList(V3inst=V3inst, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Get balance Threshold list
#=============================================================
def pricingQueryBalanceThresholdList(V3inst, queryType='BalanceId', queryValue=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingQueryBalanceThresholdList(V3inst=V3inst, queryType=queryType, queryValue=queryValue, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Get billingCycle 
#=============================================================
def pricingQueryBillingCycle(V3inst, queryType='BillingCycleId', queryValue=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingQueryBillingCycle(V3inst=V3inst, queryType=queryType, queryValue=queryValue, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)


# Get billingCycleList
#=============================================================
def pricingQueryBillingCycleList(V3inst, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingQueryBillingCycleList(V3inst=V3inst, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Query catalog for subscription
# filterName could be one item or list,  i.e. decorateCatalogItemList, removeHiddenCatalogItems  
#=============================================================
def subscriberQueryCatalog(V3inst, queryValue=None, queryType="ExternalId", catalogQueryValue=None, catalogQueryType=None, now=None, eventPass=True, eligibilityFilter=True, filterName=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberQueryCatalog(V3inst=V3inst, queryValue=queryValue, queryType=queryType, catalogQueryValue=catalogQueryValue, catalogQueryType=catalogQueryType, now=now, eventPass=eventPass, eligibilityFilter=eligibilityFilter, filterName=filterName, multiRequestBuild=multiRequestBuild)

# Query catalog for device
#=============================================================
def deviceQueryCatalog(V3inst, queryValue=None, queryType="ExternalId", catalogQueryValue=None, catalogQueryType=None, now=None, eventPass=True, eligibilityFilter=True, filterName=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.deviceQueryCatalog(V3inst=V3inst, queryValue=queryValue, queryType=queryType, catalogQueryValue=catalogQueryValue, catalogQueryType=catalogQueryType, now=now, eventPass=eventPass, eligibilityFilter=eligibilityFilter, filterName=filterName, multiRequestBuild=multiRequestBuild)

# Query catalog for group
#=============================================================
def groupQueryCatalog(V3inst, queryValue=None, queryType="ExternalId", catalogQueryValue=None, catalogQueryType=None, now=None, eventPass=True, eligibilityFilter=True, filterName=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupQueryCatalog(V3inst=V3inst, queryValue=queryValue, queryType=queryType, catalogQueryValue=catalogQueryValue, catalogQueryType=catalogQueryType, now=now, eventPass=eventPass, eligibilityFilter=eligibilityFilter, filterName=filterName, multiRequestBuild=multiRequestBuild)

# Subscriber Query One Time Offer
#=============================================================
def subscriberQueryOneTimeOffer(V3inst, queryValue=None, queryType="ExternalId", now=None, eventPass=True, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberQueryOneTimeOffer(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, 
                                              eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Device Query One Time Offer
#=============================================================
def deviceQueryOneTimeOffer(V3inst, queryValue=None, queryType="PhoneNumber", now=None, eventPass=True, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.deviceQueryOneTimeOffer(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now,
                                              eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Group Query One Time Offer
#=============================================================
def groupQueryOneTimeOffer(V3inst, queryValue=None, queryType="ExternalId", now=None, eventPass=True, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupQueryOneTimeOffer(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now,
                                              eventPass=eventPass, multiRequestBuild=multiRequestBuild)
#Query Pricing Catalog List
#=============================================================
def pricingQueryCatalogItemList(V3inst, now=None, routingType=None, routingValue=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingQueryCatalogItemList(V3inst=V3inst, now=now, routingType=routingType, 
                      routingValue=routingValue, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#Query Pricing Catalog Item
#=============================================================
def pricingQueryCatalogItem(V3inst, queryType=None, queryValue=None, now=None,
                            routingType=None, routingValue=None, eventPass=True, multiRequestBuild=None, catalogItemTime=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingQueryCatalogItem(V3inst=V3inst, queryType=queryType, queryValue=queryValue,
                      now=now, routingType=routingType, routingValue=routingValue, eventPass=eventPass, multiRequestBuild=multiRequestBuild, catalogItemTime=catalogItemTime)

#Query Pricing Catalog List
#=============================================================
def pricingCacheQueryCatalogItemList(V3inst, now=None, routingType=None, routingValue=None, eventPass=True, queryType='CatalogItem', multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingCacheQueryCatalogItemList(V3inst=V3inst, now=now, routingType=routingType,
                      routingValue=routingValue, eventPass=eventPass, queryType=queryType, multiRequestBuild=multiRequestBuild)

#Query Pricing Catalog Item
#=============================================================
def pricingCacheQueryCatalogItem(V3inst, queryValue=None, now=None,
                            routingType=None, routingValue=None, eventPass=True, queryType='CatalogItem', multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingCacheQueryCatalogItem(V3inst=V3inst, queryValue=queryValue,
                      now=now, routingType=routingType, routingValue=routingValue, eventPass=eventPass, queryType=queryType, multiRequestBuild=multiRequestBuild)

#=============================================================
def pricingQueryEventTypeList(V3inst, now=None, eventPass=True, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingQueryEventTypeList(V3inst=V3inst, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def pricingQueryEventType(V3inst, queryType='EventTypeId', queryValue=None, now=None, eventPass=True, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingQueryEventType(V3inst=V3inst, queryType=queryType, queryValue=queryValue,
               now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def pricingQueryRateTagList(V3inst, now=None,routingType=None, routingValue=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingQueryRateTagList(V3inst=V3inst, now=now, routingType=routingType, routingValue=routingValue, eventPass=eventPass, multiRequestBuild=multiRequestBuild)


#=============================================================
def pricingQueryRateTag(V3inst, queryType='RateTagId', queryValue=None, now=None, routingType=None, routingValue=None, eventPass=True, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingQueryRateTag(V3inst=V3inst, queryType=queryType, queryValue=queryValue, now=now, routingType=routingType, routingValue=routingValue,
                eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def pricingQueryRole(V3inst, queryType='ExternalId', queryValue=None, now=None, routingType=None, routingValue=None, eventPass=True, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingQueryRole(V3inst=V3inst, queryType=queryType, queryValue=queryValue, now=now, routingType=routingType, routingValue=routingValue,
                eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def pricingQueryRoleList(V3inst, now=None, routingType=None, routingValue=None, eventPass=True, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.pricingQueryRoleList(V3inst=V3inst,  now=now, routingType=routingType, routingValue=routingValue,
                eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
# sending multiRequest
def multiRequest(V3inst, requests=None, now=None, eventPass=True, routingType=None, routingValue=None):
    return SUBMAN.multiRequest(V3inst, requests, now, eventPass, routingType, routingValue)


#=============================================================
# sending multiRequest and returning response mdcs as a list
def multiRequestSaveResponse(V3inst, requests=None, now=None, eventPass=True, routingType=None, routingValue=None):
    return SUBMAN.multiRequestSaveResponse(V3inst, requests, now, eventPass, routingType, routingValue)


# create a batch of [batchSize] subscribers using multirequest
#=============================================================
def addSubscriberBatch(V3inst, batchSize, subExternalIdStartIndex, devExternalIdStartIndex, subscriberIdStartIndex, deviceIdStartIndex, deviceType, offerId, startTime=None, endTime=None, now = None, multiRequestBuild=None):
    return SUBMAN.addSubscriberBatch(V3inst, batchSize, subExternalIdStartIndex, devExternalIdStartIndex, subscriberIdStartIndex, deviceIdStartIndex, deviceType, offerId, startTime=startTime, endTime=endTime, now = now)

# modify a batch of [batchSize] subscribers using multirequest
#=============================================================
def modifySubscriberBatch(V3inst, batchSize, queryValueStartIndex, eventPass=True, queryType='ExternalId', now=None,
        firstName=None, lastName=None, contactEmail=None, contactPhoneNumberStartIndex=None, notificationPreference=None,
        timeZone=None, attr=None, billingCycle=None, status=None, taxStatus=None, taxCertificate=None, taxLocation=None, language=None,
        externalIdStartIndex=None, dateOffset=None, glCenter=None, billingCycleDisabled=None, multiRequestBuild=None):

    return SUBMAN.modifySubscriberBatch(V3inst, batchSize, queryValueStartIndex, eventPass=eventPass, queryType=queryType, now=now,
        firstName=firstName, lastName=lastName, contactEmail=contactEmail, contactPhoneNumberStartIndex=contactPhoneNumberStartIndex, notificationPreference=notificationPreference,
        timeZone=timeZone, attr=attr, billingCycle=billingCycle, status=status, taxStatus=taxStatus, taxCertificate=taxCertificate, taxLocation=taxLocation, language=language,
        externalIdStartIndex=externalIdStartIndex, dateOffset=dateOffset, glCenter=glCenter, billingCycleDisabled=billingCycleDisabled)

#qluery a batch of subscribers, returning the response MDCs as a list
#=============================================================
def querySubscriberBatch(V3inst, batchSize, queryValueStartIndex, queryType='ExternalId', querySize=None, eventPass=True, now=None, multiRequestBuild=None):
    return SUBMAN.querySubscriberBatch(V3inst, batchSize, queryValueStartIndex, queryType=queryType, querySize=querySize, eventPass=eventPass, now=now)


# Get offer, default of queryType 'OfferId', 'ExternalId' for referencing offer by ExternalId
# Helper for creating "attr" MDCs for extended objects
#=============================================================
def createAttr(containerName, fieldDct=None):
    return COMMON.createAttr(containerName, fieldDct)

# Future task scheduling items
#=============================================================
def subscriberPurchaseOfferInFuture(V3inst, queryValue, offerId=None, purchaseStartTime=None, offerStartTime=None,
                      offerEndTime=None, eventPass=True, queryType='ExternalId', now=None,
                      offerIsExternal=False, offerId2=None, attr=None, skipVtime=False, dupAttr=True, catalogItemId=None, multiRequestBuild=None):

    return SUBMAN.subscriberPurchaseOfferInFuture(V3inst, queryValue=queryValue, offerId=offerId, purchaseStartTime=purchaseStartTime, 
                      offerStartTime=offerStartTime, offerEndTime=offerEndTime, eventPass=eventPass, queryType=queryType, now=now,
                      offerIsExternal=offerIsExternal, offerId2=offerId2, attr=attr,  skipVtime=skipVtime, dupAttr=dupAttr,
                      catalogItemId=catalogItemId, multiRequestBuild=multiRequestBuild)

def groupPurchaseOfferInFuture(V3inst, queryValue, offerId=None, purchaseStartTime=None, offerStartTime=None, offerEndTime=None,
                    eventPass=True, queryType='ExternalId', now=None, offerIsExternal=False, skipVtime=False,  attr=None, dupAttr=True,
                    catalogItemId=None, multiRequestBuild=None):

    return SUBMAN.groupPurchaseOfferInFuture(V3inst,queryValue=queryValue, offerId=offerId, purchaseStartTime=purchaseStartTime, offerStartTime=offerStartTime,
                      offerEndTime=offerEndTime, eventPass=eventPass, queryType=queryType, now=now, offerIsExternal=offerIsExternal, skipVtime=skipVtime, 
                      attr=attr, dupAttr=dupAttr, catalogItemId=catalogItemId, multiRequestBuild=multiRequestBuild) 

def devicePurchaseOfferInFuture(V3inst, queryValue, offerId=None, purchaseStartTime=None, offerStartTime=None,
                      offerEndTime=None, eventPass=True, queryType='PhoneNumber', now=None,
                      offerIsExternal=False, offerId2=None, attr=None, skipVtime=False, dupAttr=True,
                      catalogItemId=None, multiRequestBuild=None):

    return SUBMAN.devicePurchaseOfferInFuture(V3inst, queryValue=queryValue, offerId=offerId, purchaseStartTime=purchaseStartTime, 
                      offerStartTime=offerStartTime, offerEndTime=offerEndTime, eventPass=eventPass, queryType=queryType, now=now,
                      offerIsExternal=offerIsExternal, offerId2=offerId2, attr=attr,  skipVtime=skipVtime, dupAttr=dupAttr,
                      catalogItemId=catalogItemId, multiRequestBuild=multiRequestBuild)

def subscriberCancelOfferInFuture(V3inst, cancelStartTime, queryType, queryValue, resourceIdList, skipVtime = False, eventPass=True, multiRequestBuild=None):
    return SUBMAN.subscriberCancelOfferInFuture(V3inst, cancelStartTime, queryType, queryValue, resourceIdList, skipVtime, eventPass, multiRequestBuild=multiRequestBuild)

def groupCancelOfferInFuture(V3inst, cancelStartTime, queryType, queryValue, resourceIdList, skipVtime = False, eventPass=True, multiRequestBuild=None):
    return SUBMAN.groupCancelOfferInFuture(V3inst, cancelStartTime, queryType, queryValue, resourceIdList, skipVtime, eventPass, multiRequestBuild=multiRequestBuild)

def deviceCancelOfferInFuture(V3inst, cancelStartTime, queryType, queryValue, resourceIdList, skipVtime = False, eventPass=True, multiRequestBuild=None):
    return SUBMAN.deviceCancelOfferInFuture(V3inst, cancelStartTime, queryType, queryValue, resourceIdList, skipVtime, eventPass, multiRequestBuild=multiRequestBuild)

# Event aggregation APIs
#===============================================================================
def querySubscriberEvent(V3inst, queryValue, queryType='ExternalId', deviceQueryType=None, deviceQueryValue=None,
    querySize=None, queryCursor=None, eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypeStringArray=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.querySubscriberEvent(V3inst=V3inst, queryValue=queryValue, queryType=queryType, deviceQueryType=deviceQueryType, 
                     deviceQueryValue=deviceQueryValue, querySize=querySize, queryCursor=queryCursor, eventTimeLowerBound=eventTimeLowerBound, 
                    eventTimeUpperBound=eventTimeUpperBound, eventTypeStringArray=eventTypeStringArray, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def queryDeviceEventstore(V3inst, queryValue, queryType='ExternalId', resultSize=None,
    eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypes=None, notificationTypes=None, notification=False,
    now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.queryDeviceEventstore(V3inst, queryValue=queryValue, queryType=queryType, resultSize=resultSize,
        eventTimeLowerBound=eventTimeLowerBound, eventTimeUpperBound=eventTimeUpperBound, eventTypes=eventTypes, notificationTypes=notificationTypes, notification=notification,
        now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)
    
#=============================================================
def querySubscriberEventstore(V3inst, queryValue=None, queryType='ExternalId', resultSize=None, deviceQueryType=None, deviceQueryValue=None,
    eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypes=None, notificationTypes=None, notification=False, searchInMemoryDatabase=True,
    applyDefaultFilter=True, routingType=None, routingValue=None, now=None, eventPass=True, multiRequestBuild=None, formatTime=True):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.querySubscriberEventstore(V3inst=V3inst, queryValue=queryValue, queryType=queryType, deviceQueryType=deviceQueryType,
                     deviceQueryValue=deviceQueryValue, resultSize=resultSize, eventTimeLowerBound=eventTimeLowerBound,
                     eventTimeUpperBound=eventTimeUpperBound, eventTypes=eventTypes, notificationTypes=notificationTypes, searchInMemoryDatabase=searchInMemoryDatabase,
                     applyDefaultFilter=applyDefaultFilter, routingType=routingType, routingValue=routingValue,
                     notification=notification, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild, formatTime=formatTime)

#=============================================================
def queryUserEventstore(V3inst, queryValue=None, queryType='ExternalId', resultSize=None,  eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypes=None, notificationTypes=None, notification=False, searchInMemoryDatabase=True,
    applyDefaultFilter=True, routingType=None, routingValue=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.queryUserEventstore(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
           resultSize=resultSize, eventTimeLowerBound=eventTimeLowerBound,
                     eventTimeUpperBound=eventTimeUpperBound, eventTypes=eventTypes, notificationTypes=notificationTypes, searchInMemoryDatabase=searchInMemoryDatabase,
applyDefaultFilter=applyDefaultFilter, routingType=routingType, routingValue=routingValue,
                     notification=notification, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def queryGroupEvent(V3inst, queryValue, queryType='ExternalId', querySize=None, queryCursor=None,
   eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypeStringArray=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.queryGroupEvent(V3inst=V3inst, queryValue=queryValue, queryType=queryType, querySize=querySize, queryCursor=queryCursor,
        eventTimeLowerBound=eventTimeLowerBound, eventTimeUpperBound=eventTimeUpperBound, eventTypeStringArray=eventTypeStringArray, now=now
        , eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def queryGroupEventstore(V3inst, queryValue, queryType='ExternalId', resultSize=None, 
   eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypes=None, notificationTypes=None, notification=False, applyDefaultFilter=True,searchInMemoryDatabase=True,
   routingType=None, routingValue=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.queryGroupEventstore(V3inst=V3inst, queryValue=queryValue, queryType=queryType, resultSize=resultSize,
        eventTimeLowerBound=eventTimeLowerBound, eventTimeUpperBound=eventTimeUpperBound, eventTypes=eventTypes, notificationTypes=notificationTypes,searchInMemoryDatabase=searchInMemoryDatabase, 
        notification=notification, applyDefaultFilter=applyDefaultFilter, 
        routingType=routingType, routingValue=routingValue,now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)
#=============================================================
def queryEventstore(V3inst, resultSize=None, eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypes=None, applyDefaultFilter=True,searchInMemoryDatabase=True,
                    routingType=None, routingValue=None, now=None, eventPass=True, multiRequestBuild=None, formatTime=True):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.queryEventstore(V3inst=V3inst, resultSize=resultSize, eventTimeLowerBound=eventTimeLowerBound, 
                                  eventTimeUpperBound=eventTimeUpperBound, eventTypes=eventTypes, applyDefaultFilter=applyDefaultFilter, searchInMemoryDatabase=searchInMemoryDatabase, 
                                  routingType=routingType, routingValue=routingValue,  now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild, formatTime=formatTime)

#=============================================================
def queryDeviceAggregation(V3inst, queryValue, queryType='PhoneNumber', now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.queryDeviceAggregation(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now,
        eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def querySubscriberAggregation(V3inst, queryValue, queryType='PhoneNumber', now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.querySubscriberAggregation(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now,
        eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def queryEventById(V3inst, queryValue, queryType='EventId', now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.eventQuery(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild) 

def queryEventstoreById(V3inst, queryValue, queryType='EventId', applyDefaultFilter=True, routingType=None, routingValue=None,searchInMemoryDatabase=True,
                         now=None, eventPass=True, multiRequestBuild=None):
     global restVersion
     if now is not None:
         now = MDCTIME.convertTime(now, restVersion=restVersion)

     return SUBMAN.queryEventstoreById(V3inst=V3inst, queryValue=queryValue, queryType=queryType, applyDefaultFilter=applyDefaultFilter,searchInMemoryDatabase=searchInMemoryDatabase,
                                       routingType=routingType, routingValue=routingValue,now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def queryDeviceSession(V3inst, queryValue, queryType='Imsi', now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.queryDeviceSession(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def validateDeviceSession(V3inst, queryValue, queryType='Imsi', sessionId=None, sessionType=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.validateDeviceSession(V3inst=V3inst, queryValue=queryValue, queryType=queryType, sessionId=sessionId, sessionType=sessionType, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def deviceEvaluateSyPolicy(V3inst, queryValue, queryType='Imsi', now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.deviceEvaluateSyPolicy(V3inst=V3inst,queryValue=queryValue , queryType=queryType,  now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def deviceEndAggregation(V3inst, queryValue, queryType='Imsi', now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.deviceEndAggregation(V3inst=V3inst,queryValue=queryValue , queryType=queryType,  now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def queryDeviceEvent(V3inst, queryValue, queryType='Imsi', queryCursor=None, querySize=None,
    eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypeStringArray=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.queryDeviceEvent(V3inst=V3inst, queryValue=queryValue , queryType=queryType, queryCursor=queryCursor, querySize=querySize,
        eventTimeLowerBound=eventTimeLowerBound, eventTimeUpperBound=eventTimeUpperBound, eventTypeStringArray=eventTypeStringArray, now=now, 
        eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def deleteDeviceSession(V3inst, queryValue, queryType='Imsi', sessionIdList=None, sessionType=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.deleteDeviceSession(V3inst=V3inst, queryValue=queryValue, queryType=queryType, sessionIdList=sessionIdList, sessionType=sessionType, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

def queryNotificationProfile(V3inst, queryValue, queryType='NotificationProfileId', eventPass=True,now=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.queryNotificationProfile(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass, multiRequestBuild=multiRequestBuild)


# Adjust subscriber rollover balance
#=============================================================
def subscriberAdjustRolloverBalance(V3inst,  queryValue, reason, balanceResourceId, queryType='PhoneNumber',balanceIntervalId=None, adjustType=None, amount=None,
        remainingRolloverCounter=None, info=None, apiEventData=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.subscriberAdjustRolloverBalance(V3inst=V3inst, queryType=queryType, queryValue=queryValue, reason=reason, balanceResourceId=balanceResourceId,
           balanceIntervalId=balanceIntervalId, adjustType=adjustType, amount=amount, info=info, remainingRolloverCounter=remainingRolloverCounter,  now=now, 
           apiEventData=apiEventData, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Adjust group rollover balance
#=============================================================
def groupAdjustRolloverBalance(V3inst,  queryValue, reason, balanceResourceId, queryType='ExternalId',balanceIntervalId=None, adjustType=None, amount=None,
        remainingRolloverCounter=None, info=None, apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.groupAdjustRolloverBalance(V3inst=V3inst, queryType=queryType, queryValue=queryValue, reason=reason, balanceResourceId=balanceResourceId,
           balanceIntervalId=balanceIntervalId, adjustType=adjustType, amount=amount, info=info, remainingRolloverCounter=remainingRolloverCounter,  now=now,
           apiEventData=apiEventData, eventPass=eventPass, executeMode=executeMode, multiRequestBuild=multiRequestBuild)

# Rehome a Subscriber (Requires a multi sub-domain engine configuration)
#=============================================================
def subscriberRehome(V3inst, queryValue, queryType='ObjectId', routingType='RouteId', routingValue=2, eventPass=True,
        apiEventData=None, multiRequestBuild=None):
    global restVersion

    return SUBMAN.subscriberRehome(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        routingType=routingType, routingValue=routingValue, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def userRehome(V3inst, queryValue, queryType='ObjectId', routingType='RouteId', routingValue=2, eventPass=True, 
        apiEventData=None, multiRequestBuild=None):
    global restVersion

    return SUBMAN.userRehome(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        routingType=routingType, routingValue=routingValue, eventPass=eventPass, apiEventData=apiEventData,
        multiRequestBuild=multiRequestBuild)

#=============================================================
def deviceRehome(V3inst, queryValue, queryType='ObjectId', routingType='RouteId', routingValue=2, eventPass=True,
        apiEventData=None, multiRequestBuild=None):
    global restVersion

    return SUBMAN.deviceRehome(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        routingType=routingType, routingValue=routingValue, eventPass=eventPass, apiEventData=apiEventData,
        multiRequestBuild=multiRequestBuild)

#=============================================================
def groupRehome(V3inst, queryValue, queryType='ObjectId', routingType='RouteId', routingValue=2, eventPass=True,
        apiEventData=None, multiRequestBuild=None):
    global restVersion

    return SUBMAN.groupRehome(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        routingType=routingType, routingValue=routingValue, eventPass=eventPass, apiEventData=apiEventData,
        multiRequestBuild=multiRequestBuild)

# Prepare the rehoming of the subscriber
#=============================================================
def subscriberRehomePrepare(V3inst, queryValue, queryType='ObjectId', eventPass=True, multiRequestBuild=None):
    global restVersion

    return SUBMAN.subscriberRehomePrepare(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def userRehomePrepare(V3inst, queryValue, queryType='ObjectId', eventPass=True, multiRequestBuild=None):
    global restVersion

    return SUBMAN.userRehomePrepare(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Prepare the rehoming of the device
#=============================================================
def deviceRehomePrepare(V3inst, queryValue, queryType='ObjectId', eventPass=True, multiRequestBuild=None):
    global restVersion

    return SUBMAN.deviceRehomePrepare(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Prepare the rehoming of the group
#=============================================================
def groupRehomePrepare(V3inst, queryValue, queryType='ObjectId', eventPass=True, multiRequestBuild=None):
    global restVersion

    return SUBMAN.groupRehomePrepare(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Attempt to rehome the subscriber (This will only work on the target Domain)
#=============================================================
def databaseRehome(V3inst, rehomeCtxList, rehomeDataList, routingType='RTID', routingValue=2, eventPass=True, multiRequestBuild=None):
    global restVersion

    return SUBMAN.databaseRehome(V3inst=V3inst, rehomeCtxList=rehomeCtxList, rehomeDataList=rehomeDataList,
        routingType=routingType, routingValue=routingValue, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Commit subscriber rehoming       
#=============================================================
def databaseRehomeCommit(V3inst, rehomeCtxList, routingType='RTID', routingValue=2, eventPass=True, multiRequestBuild=None):
    global restVersion

    return SUBMAN.databaseRehomeCommit(V3inst=V3inst, rehomeCtxList=rehomeCtxList, routingType=routingType,
        routingValue=routingValue, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Rollback the rehoming                
#=============================================================
def databaseRehomeRollback(V3inst, rehomeCtxList, routingType='RTID', routingValue=2, eventPass=True, multiRequestBuild=None):
    global restVersion

    return SUBMAN.databaseRehomeRollback(V3inst=V3inst, rehomeCtxList=rehomeCtxList, routingType=routingType,
        routingValue=routingValue, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Get Gateway Authorization Token 
#=============================================================
def getGatewayAuthorizationToken(V3inst, paymentGatewayUserId=None, paymentGatewayId=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    return SUBMAN.getGatewayAuthorizationToken(V3inst=V3inst, paymentGatewayUserId=paymentGatewayUserId, 
                      paymentGatewayId=paymentGatewayId, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Subscribers Add Payment Method
#=============================================================
def subscriberAddPaymentMethod(V3inst, queryValue, paymentGatewayUserId=None, paymentGatewayOneTimeToken=None, paymentGatewayId=0,
        paymentType=None, name=None, isDefault=True, isSysDefault=None, queryType='ExternalId', paymentAttr=None, now=None, eventPass=True,
        executeMode=None, apiEventData=None, multiRequestBuild=None):
    global restVersion

    return SUBMAN.subscriberAddPaymentMethod(V3inst=V3inst, queryValue=queryValue, paymentGatewayUserId=paymentGatewayUserId,
        paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, paymentGatewayId=paymentGatewayId, paymentType=paymentType,
        name=name, isDefault=isDefault, isSysDefault=isSysDefault, queryType=queryType, paymentAttr=paymentAttr, now=None,
        eventPass=eventPass, executeMode=executeMode, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

#Modify Subscribers Payment Method
#=============================================================
def subscriberModifyPaymentMethod(V3inst, queryValue, resourceId=None, paymentGatewayUserId=None, paymentType=None,
        paymentGatewayOneTimeToken=None, name=None, isDefault=None, isSysDefault=None, queryType='ExternalId',
        paymentAttr=None, now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):
    global restVersion

    return SUBMAN.subscriberModifyPaymentMethod(V3inst=V3inst, queryValue=queryValue, resourceId=resourceId, 
        paymentGatewayUserId=paymentGatewayUserId, paymentType=paymentType, name=name, paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, 
        isDefault=isDefault, isSysDefault=isSysDefault, queryType=queryType, paymentAttr=paymentAttr, now=None, eventPass=eventPass,
        executeMode=executeMode, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

#Validate Subscribers Payment Method
#=============================================================
def subscriberValidatePaymentMethod(V3inst, queryValue, queryType='ExternalId', resourceId=None, postalCode=None,
        eventPass=True, executeMode=None, multiRequestBuild=None):
    global restVersion

    return SUBMAN.subscriberValidatePaymentMethod(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        resourceId=resourceId, postalCode=postalCode,
        eventPass=eventPass, executeMode=executeMode, multiRequestBuild=multiRequestBuild)

# Groups Add Payment Method
#=============================================================
def groupAddPaymentMethod(V3inst, queryValue, paymentGatewayUserId=None, paymentGatewayOneTimeToken=None, paymentGatewayId=0,
        paymentType=None, name=None, isDefault=True, isSysDefault=None, queryType='ExternalId', paymentAttr=None, now=None, 
        eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):
    global restVersion

    return SUBMAN.groupAddPaymentMethod(V3inst=V3inst, queryValue=queryValue, paymentGatewayUserId=paymentGatewayUserId,
        paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, paymentGatewayId=paymentGatewayId, paymentType=paymentType,
        name=name, isDefault=isDefault, isSysDefault=isSysDefault, queryType=queryType, paymentAttr=paymentAttr, now=None,
        eventPass=eventPass, executeMode=executeMode, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

#Modify Group Payment Method
#=============================================================
def groupModifyPaymentMethod(V3inst, queryValue, resourceId=None, paymentGatewayUserId=None, paymentType=None, name=None,
        paymentGatewayOneTimeToken=None, isDefault=None, isSysDefault=None, queryType='ExternalId', paymentAttr=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):
    global restVersion

    return SUBMAN.groupModifyPaymentMethod(V3inst=V3inst, queryValue=queryValue, resourceId=resourceId,
        paymentGatewayUserId=paymentGatewayUserId, paymentType=paymentType, name=name, paymentGatewayOneTimeToken=paymentGatewayOneTimeToken,
        isDefault=isDefault, isSysDefault=isSysDefault, queryType=queryType, paymentAttr=paymentAttr, now=None, eventPass=eventPass,
        executeMode=executeMode, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)

#Validate Group Payment Method
#=============================================================
def groupValidatePaymentMethod(V3inst, queryValue, queryType='ExternalId', resourceId=None, postalCode=None,
        now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    global restVersion

    return SUBMAN.groupValidatePaymentMethod(V3inst=V3inst, queryValue=queryValue, queryType=queryType, resourceId=resourceId,
        postalCode=postalCode, now=now, eventPass=eventPass, executeMode=executeMode, multiRequestBuild=multiRequestBuild)

# Query Subscribers Payment Methods
#=============================================================
def subscriberQueryPaymentMethod(V3inst, queryValue, paymentGatewayId=None, returnDefault=None, returnSysDefault=None,
        queryType='ObjectId', now=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    return SUBMAN.subscriberQueryPaymentMethod(V3inst=V3inst, queryValue=queryValue,
        paymentGatewayId=paymentGatewayId, returnDefault=returnDefault, returnSysDefault=returnSysDefault, 
        queryType=queryType, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Query Group Payment  Methods
#=============================================================
def groupQueryPaymentMethod(V3inst, queryValue, paymentGatewayId=None, returnDefault=None, returnSysDefault=None,
        queryType='ObjectId', now=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    return SUBMAN.groupQueryPaymentMethod(V3inst=V3inst, queryValue=queryValue,
        paymentGatewayId=paymentGatewayId, returnDefault=returnDefault, returnSysDefault=returnSysDefault,
        queryType=queryType, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Remove Subscribers Payment Method
#========================================================
def subscriberRemovePaymentMethod(V3inst, queryValue, resourceId=None, queryType='ObjectId', now=None, eventPass=True,
        apiEventData=None, multiRequestBuild=None):
    global restVersion

    return SUBMAN.subscriberRemovePaymentMethod(V3inst=V3inst, queryValue=queryValue,
        resourceId=resourceId, queryType=queryType, now=now, eventPass=eventPass, apiEventData=apiEventData,
        multiRequestBuild=multiRequestBuild)

# Remove Group Payment Method
#========================================================
def groupRemovePaymentMethod(V3inst, queryValue, resourceId=None, queryType='ObjectId', now=None, eventPass=True,
        apiEventData=None, multiRequestBuild=None):
    global restVersion

    return SUBMAN.groupRemovePaymentMethod(V3inst=V3inst, queryValue=queryValue,
        resourceId=resourceId, queryType=queryType, now=now, eventPass=eventPass, apiEventData=apiEventData,
        multiRequestBuild=multiRequestBuild)

# Query SubDomains
#========================================================
def querySubDomains(V3inst, multiRequestBuild=None):
    global restVersion

    return SUBMAN.querySubDomains(V3inst, multiRequestBuild=multiRequestBuild)

#=============================================================
def serviceGroupQuery(V3inst, queryValue, queryType='ObjectId', now=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    return SUBMAN.serviceGroupQuery(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def serviceGroupAddMembers(V3inst, queryValue, queryType='ObjectId', subscribers=None, administrators=None, groups=None,
                           now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):
    global restVersion

    return SUBMAN.serviceGroupAddRemoveMembers(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now,
                                    subscribers=subscribers, administrators=administrators, groups=groups,
                                    addRemove='add', eventPass=eventPass, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)
#=============================================================
def serviceGroupRemoveMembers(V3inst, queryValue, queryType='ObjectId', subscribers=None, administrators=None, groups=None,
                               now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):
    global restVersion

    return SUBMAN.serviceGroupAddRemoveMembers(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now,
                                    subscribers=subscribers, administrators=administrators, groups=groups,
                                    addRemove='remove', eventPass=eventPass, apiEventData=apiEventData, multiRequestBuild=multiRequestBuild)
#=============================================================
def serviceGroupQueryAdministrators(V3inst, queryValue, queryType='ObjectId', querySize=None, queryCursor=None,
                                    now=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    return SUBMAN.serviceGroupQuery(V3inst=V3inst, queryValue=queryValue, queryType=queryType, querySize=querySize,
                                    queryCursor=queryCursor, returnType='administrators',  now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def serviceGroupQueryMemberBalance(V3inst, queryValue, queryType='ObjectId', resourceId=None, now=None, eventPass=True, querySize=None, memberCursor=None, subGroupCursor=None, multiRequestBuild=None):
    global restVersion

    return SUBMAN.serviceGroupQueryMemberBalance(V3inst=V3inst, queryValue=queryValue, queryType=queryType, resourceId=resourceId,
                                                 now=now, eventPass=eventPass, querySize=querySize, memberCursor=memberCursor, subGroupCursor=subGroupCursor, multiRequestBuild=multiRequestBuild)

#=============================================================
def serviceSubscriptionQueryGroups(V3inst, queryValue, queryType='ObjectId', now=None, eventPass=True,
                                  querySize=None, queryCursor=None, multiRequestBuild=None):
    global restVersion

    return SUBMAN.serviceSubscriptionQueryGroups(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
                                  querySize=querySize, queryCursor=queryCursor, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)
   
#=============================================================
def serviceQuerySubscription(V3inst, queryValue, queryType='ObjectId', now=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    return SUBMAN.serviceQuerySubscription(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
                                                 now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def serviceQueryDevice(V3inst, queryValue, queryType='ObjectId', now=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    return SUBMAN.serviceQueryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
                                                 now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def serviceGroupQuerySubGroups(V3inst, queryValue, queryType='ObjectId', querySize=None, queryCursor=None,
                               now=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    return SUBMAN.serviceGroupQuery(V3inst=V3inst, queryValue=queryValue, queryType=queryType, querySize=querySize,
                                             queryCursor=queryCursor,  returnType='subgroups', now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def serviceGroupQuerySubscribers(V3inst, queryValue, queryType='ObjectId', querySize=None, queryCursor=None,
                                 now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    return SUBMAN.serviceGroupQuery(V3inst=V3inst, queryValue=queryValue, queryType=queryType, querySize=querySize,
                                             queryCursor=queryCursor, returnType='subscribers', now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def deviceRating(V3inst, queryValue, queryType="Imsi", requestType='start', service=None, amount=None, sessionId=None, serviceContextId=None, calledStationId=None, QaUliMccMnc=None, eventPass=True, attr=None, eventTime=None, objectIdConversion = True, multiRequestBuild=None):
    global restVersion
    
    return SUBMAN.deviceRating(V3inst, queryValue, queryType=queryType, requestType=requestType, service=service, amount=amount, sessionId=sessionId, serviceContextId=serviceContextId, calledStationId=calledStationId, QaUliMccMnc=QaUliMccMnc, eventPass=eventPass, attr=attr, eventTime=eventTime, objectIdConversion = objectIdConversion, multiRequestBuild=multiRequestBuild)

# Custom code
#=============================================================
def customURLCall(V3inst, url, payload=None, operation='get', eventPass=True, multiRequestBuild=None):
    return SUBMAN.customURLCall(V3inst, url, payload=payload, operation=operation, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

# Subscriber Make Finance Contract Principal Payment
#=============================================================
def subscriberMakeFinanceContractPrincipalPayment(V3inst, queryValue, offerResourceId, queryType = 'ExternalId',
    isPayoff=True, extraPrincipalAmount=None, paymentMethodResourceId=None, chargeMethod=None, apiEventData=None, 
    paymentGatewayId=None, nonce=None, chargeMethodAttr=None, reason=None, info=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    return SUBMAN.subscriberMakeFinanceContractPrincipalPayment(V3inst=V3inst, queryValue=queryValue, offerResourceId=offerResourceId, queryType=queryType,
           isPayoff=isPayoff, extraPrincipalAmount=extraPrincipalAmount, paymentMethodResourceId=paymentMethodResourceId, chargeMethod=chargeMethod, 
           paymentGatewayId=paymentGatewayId, nonce=nonce, chargeMethodAttr=chargeMethodAttr, reason=reason, info=info,
           apiEventData=apiEventData, now=now, eventPass = eventPass, multiRequestBuild=multiRequestBuild)

# Group Make Finance Contract Principal Payment
#=============================================================
def groupMakeFinanceContractPrincipalPayment(V3inst, queryValue, offerResourceId, queryType = 'ExternalId',
    isPayoff=True, extraPrincipalAmount=None, paymentMethodResourceId=None, chargeMethod=None, apiEventData=None, 
    paymentGatewayId=None, nonce=None, chargeMethodAttr=None, reason=None, info=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    return SUBMAN.groupMakeFinanceContractPrincipalPayment(V3inst=V3inst, queryValue=queryValue, offerResourceId=offerResourceId, queryType=queryType,
           isPayoff=isPayoff, extraPrincipalAmount=extraPrincipalAmount, paymentMethodResourceId=paymentMethodResourceId, chargeMethod=chargeMethod,
           paymentGatewayId=paymentGatewayId, nonce=nonce, chargeMethodAttr=chargeMethodAttr, reason=reason, info=info, apiEventData=apiEventData,
           now=now, eventPass = eventPass, multiRequestBuild=multiRequestBuild)

#Subscriber Contract Debt Payment
#=============================================================
def subscriberContractDebtPayment(V3inst, queryValue, offerResourceId,
    amount, queryType = 'ExternalId', paymentMethodResourceId=None, chargeMethod=None, paymentGatewayId=None, apiEventData=None, 
    nonce=None, chargeMethodAttr=None, reason=None, info=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    return SUBMAN.subscriberContractDebtPayment(V3inst=V3inst, queryValue=queryValue, offerResourceId=offerResourceId, apiEventData=apiEventData,
           amount=amount, queryType=queryType, paymentMethodResourceId=paymentMethodResourceId, chargeMethod=chargeMethod, paymentGatewayId=paymentGatewayId,
           nonce=nonce, chargeMethodAttr=chargeMethodAttr, reason=reason, info=info, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#Device Contract Debt Payment
#=============================================================
def deviceContractDebtPayment(V3inst, queryValue, offerResourceId,
    amount, queryType = 'PhoneNumber', paymentMethodResourceId=None, chargeMethod=None, paymentGatewayId=None, apiEventData=None, 
    nonce=None, chargeMethodAttr=None, reason=None, info=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    return SUBMAN.deviceContractDebtPayment(V3inst=V3inst, queryValue=queryValue, offerResourceId=offerResourceId, apiEventData=apiEventData,
           amount=amount, queryType=queryType, paymentMethodResourceId=paymentMethodResourceId, chargeMethod=chargeMethod, paymentGatewayId=paymentGatewayId,
           nonce=nonce, chargeMethodAttr=chargeMethodAttr, reason=reason, info=info, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#Group Contract Debt Payment
#=============================================================
def groupContractDebtPayment(V3inst, queryValue, offerResourceId,
    amount, queryType = 'ExternalId', paymentMethodResourceId=None, chargeMethod=None, paymentGatewayId=None, apiEventData=None, 
    nonce=None, chargeMethodAttr=None, reason=None, info=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    return SUBMAN.groupContractDebtPayment(V3inst=V3inst, queryValue=queryValue, offerResourceId=offerResourceId, apiEventData=apiEventData,
           amount=amount, queryType=queryType, paymentMethodResourceId=paymentMethodResourceId, chargeMethod=chargeMethod, paymentGatewayId=paymentGatewayId,
           nonce=nonce, chargeMethodAttr=chargeMethodAttr, reason=reason, info=info, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#Pricing Query Contract List
#=============================================================
def pricingQueryContractList(V3inst, routingType=None, routingValue=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    return SUBMAN.pricingQueryContractList(V3inst=V3inst, routingType=routingType, routingValue=routingValue, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def pricingQueryContract(V3inst, queryValue, queryType='ContractId', routingType=None, routingValue=None, now=None, eventPass = True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)


    return SUBMAN.pricingQueryContract(V3inst=V3inst, queryValue=queryValue, queryType=queryType, routingType=routingType,
           routingValue=routingValue, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)


#=============================================================
def pricingCacheQueryContract(V3inst, queryValue, queryType='ContractId', routingType=None, routingValue=None, now=None, eventPass = True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)


    return SUBMAN.pricingCacheQueryContract(V3inst=V3inst, queryValue=queryValue, queryType=queryType, routingType=routingType,
           routingValue=routingValue, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)


#=============================================================
def subscriberQueryCatalogItemList(V3inst, queryValue=None, queryType='ExternalId', now=None, eventPass=True,
                             eligibilityFilter=None, multiRequestBuild=None):
    global restVersion

    return SUBMAN.subscriberQueryCatalogItemList(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
            now=now, eventPass=eventPass, eligibilityFilter=eligibilityFilter, multiRequestBuild=multiRequestBuild)

#=============================================================
def deviceQueryCatalogItemList(V3inst, queryValue=None, queryType='PhoneNumber', now=None, eventPass=True,
                             eligibilityFilter=None, multiRequestBuild=None):
    global restVersion

    return SUBMAN.deviceQueryCatalogItemList(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
            now=now,  eventPass=eventPass, eligibilityFilter=eligibilityFilter, multiRequestBuild=multiRequestBuild)


#=============================================================
def groupQueryCatalogItemList(V3inst, queryValue=None, queryType='ExternalId', now=None, eventPass=True,
                             eligibilityFilter=None, multiRequestBuild=None):
    global restVersion

    return SUBMAN.groupQueryCatalogItemList(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
            now=now,  eventPass=eventPass, eligibilityFilter=eligibilityFilter, multiRequestBuild=multiRequestBuild)


#=============================================================
def pricingQueryCatalogList(V3inst, eventPass=True, now=None, routingType=None, routingValue=None, multiRequestBuild=None):
    global restVersion

    return SUBMAN.pricingQueryCatalogList(V3inst=V3inst, eventPass=eventPass, now=now, routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild)


#=============================================================
# Cache support multiple query parameter, such as Catalog or catalog
def pricingCacheQueryCatalogList(V3inst, eventPass=True, now=None, routingType=None, routingValue=None, queryType='Catalog', multiRequestBuild=None):
    global restVersion

    return SUBMAN.pricingCacheQueryCatalogList(V3inst=V3inst, eventPass=eventPass, now=now, routingType=routingType, routingValue=routingValue, queryType=queryType, multiRequestBuild=multiRequestBuild)


#=============================================================
def pricingQueryCatalog(V3inst, queryValue=None, queryType='CatalogId', eventPass=True, now=None, routingType=None, routingValue=None, multiRequestBuild=None):
    global restVersion

    return SUBMAN.pricingQueryCatalog(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass, now=now, routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild)


#=============================================================
def pricingCacheQueryCatalog(V3inst, queryValue=None, queryType='Catalog', eventPass=True, now=None, routingType=None, routingValue=None, multiRequestBuild=None):
    global restVersion

    return SUBMAN.pricingCacheQueryCatalog(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass, now=now, routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild)

#=============================================================
def queryPricingStatus(V3inst, now=None, routingType=None, routingValue=None, eventPass=True):
    global restVersion

    return SUBMAN.queryPricingStatus(V3inst=V3inst, now=now, routingType=routingType, routingValue=routingValue,eventPass=eventPass)

#=============================================================
def pricingQueryContractPaymentScheduleList(V3inst, eventPass=True, now=None, routingType=None, routingValue=None, multiRequestBuild=None):
    global restVersion

    return SUBMAN.pricingQueryContractPaymentScheduleList(V3inst=V3inst, eventPass=eventPass, now=now, routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild)

#=============================================================
def pricingQueryContractPaymentSchedule(V3inst, queryValue=None, queryType='ContractPaymentScheduleId', eventPass=True, now=None, routingType=None, routingValue=None, multiRequestBuild=None):
    global restVersion

    return SUBMAN.pricingQueryContractPaymentSchedule(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass, now=now, routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild)

#=============================================================
def pricingQueryTenant(V3inst, queryType='TenantId', queryValue=None, now=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):
    global restVersion

    return SUBMAN.pricingQueryTenant(V3inst=V3inst, queryType=queryType, queryValue=queryValue, now=now,
                                     routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild, eventPass=eventPass)

#=============================================================
def pricingQueryTenantList(V3inst, now=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):
    global restVersion

    return SUBMAN.pricingQueryTenantList(V3inst=V3inst, now=now, routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild, eventPass=eventPass)

#=============================================================
def taxQueryProductGroupList(V3inst,  now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.taxQueryProductGroupList(V3inst=V3inst, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def taxQueryProductItemList(V3inst,  now=None, productGroup=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.taxQueryProductItemList(V3inst=V3inst, productGroup=productGroup, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def taxQueryCustomerTypeList(V3inst,  now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.taxQueryCustomerTypeList(V3inst=V3inst, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def taxQueryExemptionCodeList(V3inst,  now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.taxQueryExemptionCodeList(V3inst=V3inst, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def taxQueryStatus(V3inst,  now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.taxQueryStatus(V3inst=V3inst, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def taxQueryGeoCode(V3inst,  postalCode=None, plus4=None, npa=None, nxx=None, timeZone=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    return SUBMAN.taxQueryGeoCode(V3inst=V3inst, postalCode=postalCode, plus4=plus4, npa=npa, nxx=nxx, timeZone=timeZone, now=now, eventPass=eventPass, multiRequestBuild=multiRequestBuild)


#=========================================================================
# Helper function to create service address to add to subscriber or group or subscription
#=========================================================================
def createServiceAddressData(streetAddr=None, extendedAddr=None, locality=None, region=None, postalCode=None, extendedPostalCode=None, countryCode=None):
    return SUBMAN.createServiceAddressData(streetAddr=streetAddr, extendedAddr=extendedAddr, locality=locality,
                              region=region, postalCode=postalCode, extendedPostalCode=extendedPostalCode, countryCode=countryCode)

#=========================================================================
# Helper function to create Geo data for US Tax purchase offer 
#=========================================================================
def createGeoData(geoCode=None, postalCode=None, plus4=None, npa=None, nxx=None):
    return SUBMAN.createGeoData(geoCode=geoCode, postalCode=postalCode, plus4=plus4, npa=npa, nxx=nxx)

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

