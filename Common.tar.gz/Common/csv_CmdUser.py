#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:35:59
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:35:59
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:35:58
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
from __future__ import print_function
# from builtins import str
# from builtins import str
import sys, copy, pprint
import QA_subscriber_management_restv3 as REST_UTIL
import qa_utils as QAUTILS
import csv_track as TRACK
import csv_id as CSVID
import csv_prim as PRIM
import csv_data as DATA
import custSpecific as CUST
import csv_qa as CSVQA
import csvMain as CSV
import csv_Events as CSVEVENTS
import csv_CmdMisc as MISC
from primitives import timeToMDCtime as MDCTIME
import xml.etree.ElementTree as ET

from primitives import primGET as GET

#==========================================================
def CmdUser_removeuser(lclDCT, testName, sessionId, line, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, repeatCount):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        userId = lclDCT['userId']
        externalId = lclDCT['externalId']
        # End of local variables setup.

        # Set object type (for ease of cut/paste to other objects)
        objType='user'
        objId = userId
        objQueryType = lclDCT['userQueryType']
        
        print('Looking to remove ' + objType + ' ' + objId + ' (' + objQueryType + ')')
        
        # First order is to get subscriber data
        q = GET.getObject(objId, hostname=QAUTILS.gatewaysConfig.get('REST', 'restServer'), hostport=QAUTILS.gatewaysConfig.get('REST', 'restPort'), queryType=objQueryType, objType=objType)
        
        # If Q is empty, then nothing to do
        if q is None:
                print(objType + ' non-existent.')
        
                # Nothing to query
                queryType = queryValue = None
                
                return (queryType, queryValue)
        
        # Get OID
        try: oid = q.find('./ObjectId').text.strip()
        except:
                print('WARNING: ' + objType + ' does not have an ObjetId...')
                ET.dump(q)
        
                # Nothing to query
                queryType = queryValue = None
                
                return (queryType, queryValue)
        
        # *** Want to find time for delete.  Should match latest time that something new started in the object ***
        savedInputTime = lclStartTime
        lclStartTime = PRIM.findObjectLatestTime(q, lclStartTime, objType, objId, objQueryType)
        
        print('Remove ' + objType + ' ' + objId + ' - using time ' + lclStartTime)
        if lclStartTime != savedInputTime: print('Updated remove time from ' + savedInputTime + ' to ' + lclStartTime)
        
        # ** Move object to deletable state.  Every customer has their own states.  TF reads this into customer specific data.
        stateMap = copy.deepcopy(CUST.userStateMap)

        # Get object state
        try:
                objState = q.find('./StatusDescription').text.strip()
        except:
                objState = 'Active'

        # Debug output
        print('stateMap = ' + str(stateMap) + ', starting state = ' + objState)

        objState = objState.lower()
        while stateMap[objState] != 'Remove':
                # Get next state
                objState = stateMap[objState]

                # Modify to next state
                newLine='modifyUser;userId=' + oid + ';userQueryType=ObjectId;userStatus=' + objState + ';noChecks=True;skipStepResults=' + str(lclDCT['skipStepResults']) + ';rmvFlag=1'
                (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)

        # ** Cycle through all Subscriptions
        xmlDctName = './RelatedSubscriptionArray/MtxRelatedSubscriptionObject'
        for child in q.findall(xmlDctName):
                # Get OID
                try: childOid = child.find('./ObjectId').text.strip()
                except:
                        print('WARNING: ' + objType + ' oid ' + str(oid) + ' child subscription does not have an ObjetId')
                        ET.dump(child)
                        continue
                
                # If keepChildren not set to true then want to remove the children, else just unlink
                if not lclDCT['keepChildren']:
                        # Remove the child
                        newLine='removeSubscription;externalId=' + childOid + ';subQueryType=ObjectId;noChecks=True;skipStepResults=' + str(lclDCT['skipStepResults'])
                        (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)
                else:
                        # Unlink the child
                        newLine='removeSubscriptionFromUser;userId=' + oid + ';userQueryType=ObjectId;externalId=' + childOid + ';subQueryType=ObjectId;noChecks=True;skipStepResults=' + str(lclDCT['skipStepResults'])
                        (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)
                
        # ** Delete object
        newLine='deleteUser;userId=' + oid + ';userQueryType=ObjectId;noChecks=True;skipStepResults=' + str(lclDCT['skipStepResults'])
        (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)
                
        # Nothing to query
        queryType = queryValue = None
        
        return (queryType, queryValue)

#==========================================================
def CmdUser_createuserandsubscriptionanddevice(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        userId = lclDCT['userId']
        externalId = lclDCT['externalId']
        # End of local variables setup.

        # Stuff to check if not noChecks and not in a multi-request
        if not lclDCT['noChecks'] and not DATA.mrEnabled:
                # User should not exist
                if (userId and userId in TRACK.userTracking) or (lclDCT['userExternalId'] and lclDCT['userExternalId'] in TRACK.userTracking):
                        print('ERROR: user with ID "' + externalId + '" is already defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
                
                # Subscription should not exist
                if externalId in TRACK.subscriberTracking:
                        print('ERROR: subscription with ID "' + externalId + '" is already defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
                
                # Device should not exist
                if lclDCT['deviceId'] in TRACK.deviceTracking:
                        print('ERROR: device with ID "' + lclDCT['deviceId'] + '" is defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Create billing cycle data if profile id defined
        if lclDCT['profileId'] and int(lclDCT['profileId']):
                billingCycle = REST_UTIL.createBillingCycleData(lclDCT['profileId'], dateOffset=lclDCT['dateOffset'], startTime=lclDCT['startTime'])
        else:
                billingCycle = None
        
        # ** Now work on offers.  Can have two parameters to specify this.  Can buy by external ID or catalog ID.  Can by legacy product ID or current catalog ID.
        # ** More difficult than it should be...
        #print 'offerIsExternal/offerIsCatalog = ' + str(offerIsExternal) + '/' + str(offerIsCatalog)
        (catalogItemId,offerId) = PRIM.processOffers(lclDCT['offerId'], lclDCT['subOfferId'], lclDCT['offerIsExternal'], lclDCT['offerIsCatalog'])
        if   catalogItemId:     outStr = ' with catalog items ' + str(catalogItemId)
        elif offerId:           outStr = ' with offer IDs ' + str(offerId)
        else:                   outStr = ''
        
        # Set user external IDs if not passed in
        if not lclDCT['userExternalId'] and userId   and not lclDCT['noChecks']: userExternalId = 'U' + userId
        else: userExternalId = lclDCT['userExternalId'] # Added during Python3 migration
        if not lclDCT['devExternalId']  and lclDCT['deviceId'] and not lclDCT['noChecks']: devExternalId  = 'D' + lclDCT['deviceId']
        else: devExternalId = lclDCT['devExternalId'] # Added during Python3 migration
        
        # Build offer parameters
        try:    parameterList = PRIM.buildOfferParameters(CUST.custOfferParameterList, lclDCT)
        except: parameterList = None
        #print 'parameterList: ' + str(parameterList)
        
        # Change datetime to time
        if lclDCT['offerCycleStartTime']: offerCycleStartTime = lclDCT['offerCycleStartTime'].split('T')[1][:8]
        else: offerCycleStartTime = lclDCT['offerCycleStartTime'] # Added during Python3 migration
        
        # Build US Tax data
        serviceAddress = REST_UTIL.createServiceAddressData(streetAddr=lclDCT['streetAddr'], extendedAddr=lclDCT['extendedAddr'], locality=lclDCT['locality'], region=lclDCT['region'], postalCode=lclDCT['postalCode'], extendedPostalCode=lclDCT['extendedPostalCode'], countryCode=lclDCT['countryCode'])
        geoData = REST_UTIL.createGeoData(geoCode=lclDCT['geoCode'], postalCode=lclDCT['postalCode'], plus4=lclDCT['plus4'], npa=lclDCT['npa'], nxx=lclDCT['nxx'])
        
        # Debug output
        print('Creating user ' + str(userId) + '(U)/' + str(userExternalId) + '(X) and subscription ' + str(externalId) + ' and device ' + str(lclDCT['deviceId']) + outStr)
        
        retCode = REST_UTIL.createSubscriberAndDevice(RESTInst,
                userId=userId,
                userExternalId=userExternalId,
                userAttr=lclDCT['customAttr'][4],
                firstName=lclDCT['firstName'],
                lastName=lclDCT['lastName'],
                contactPhoneNumber=lclDCT['contactPhoneNumber'],
                contactEmail=lclDCT['contactEmail'],
                notificationPreference=lclDCT['notificationPreference'],
                language=lclDCT['language'],
                contactPushTokenList=None,
                userStatus=lclDCT['userStatus'],
                
                externalId=externalId,
                subAttr=lclDCT['customAttr'][1],
                timeZone=lclDCT['subTimeZone'],
                billingCycle=billingCycle,
                subStatus=lclDCT['subStatus'],
                taxStatus=lclDCT['taxStatus'],
                taxCertificate=lclDCT['taxCertificate'],
                taxLocation=lclDCT['taxLocation'],
                glCenter=lclDCT['glCenter'],              
                
                deviceId=lclDCT['deviceId'],
                deviceExternalId=devExternalId,
                deviceType=lclDCT['deviceType'],
                devAttr=lclDCT['customAttr'][0],
                devStatus=lclDCT['devStatus'],
                accessNumbers=lclDCT['accessNumbers'],
                
                rolesExternalIds=lclDCT['rolesExternalIds'],
                rolesPricingIds=lclDCT['rolesPricingIds'],
                
                offerId=offerId,
                offerStartTime=lclDCT['offerStartTime'],
                offerEndTime=lclDCT['offerEndTime'],
                offerIsExternal=lclDCT['offerIsExternal'],
                offerAttr=lclDCT['customAttr'][3],
                preActiveState=lclDCT['preActiveState'],
                activationExpirationTime=lclDCT['activationExpirationTime'],
                activationExpirationRelativeOffsetUnit=lclDCT['activationExpirationRelativeOffsetUnit'],
                activationExpirationRelativeOffset=lclDCT['activationExpirationRelativeOffset'],
                autoActivationTime=lclDCT['autoActivationTime'],
                autoActivationRelativeOffsetUnit=lclDCT['autoActivationRelativeOffsetUnit'],
                autoActivationRelativeOffset=lclDCT['autoActivationRelativeOffset'],
                autoActivationCycleResourceId=lclDCT['autoActivationCycleResourceId'],
                offerCycleType=lclDCT['offerCycleType'], offerCycleOffset=lclDCT['offerCycleOffset'], offerCycleResourceId=lclDCT['offerCycleResourceId'], offerCycleStartTime=offerCycleStartTime,
                parameterList=parameterList,
                                
                customerType=lclDCT['customerType'],
                serviceAddress=serviceAddress,
                npa=lclDCT['npa'],
                nxx=lclDCT['nxx'],
                tenantId=lclDCT['tenantId'], 
                exemptionCodeList=lclDCT['exemptionCodeList'],
                geoData=geoData,
                
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                routingType=lclDCT['routingType'],
                routingValue=lclDCT['routingValue'],
                executeMode=lclDCT['executeMode'],
                apiEventData=lclDCT['customAttr'][6],
                )
        
        # Stuff to do if we passed
        if lclDCT['eventPass']:
                # Update tracking data
                TRACK.updateTrackingData('createUser', externalId = userExternalId, userId = userId, mark='USER_'+lclDCT['mark'], RESTInst=RESTInst)
                TRACK.updateTrackingData('createSubscription', externalId = externalId, mark='SUBSCR_'+lclDCT['mark'], RESTInst=RESTInst)
                TRACK.updateTrackingData('createDevice', deviceId = lclDCT['deviceId'], mark='DEVICE_'+lclDCT['mark'], RESTInst=RESTInst)
                TRACK.updateTrackingData('addSubscriber', externalId = externalId, deviceId = lclDCT['deviceId'], accessNumbers=lclDCT['accessNumbers'], offerId = offerId, mark=lclDCT['mark'], RESTInst=RESTInst)
        
        # Query user
        queryValue = userId
        queryType = lclDCT['userQueryType']
        
        return (queryType, queryValue)
        
#==========================================================
def CmdUser_createusersubscription(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        userId = lclDCT['userId']
        externalId = lclDCT['externalId']
        # End of local variables setup.

        # User should not exist
        if userId in TRACK.userTracking and not lclDCT['noChecks']:
                print('ERROR: user with ID "' + externalId + '" is already defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Subscription should not exist
        if externalId in TRACK.subscriberTracking and not lclDCT['noChecks']:
                print('ERROR: subscription with ID "' + externalId + '" is already defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Create billing cycle data if profile id defined
        if lclDCT['profileId'] and int(lclDCT['profileId']):
                billingCycle = REST_UTIL.createBillingCycleData(lclDCT['profileId'], dateOffset=lclDCT['dateOffset'], startTime=lclDCT['startTime'])
        else:
                billingCycle = None
        
        # Set user external ID if not passed in
        if not lclDCT['userExternalId'] and userId and not lclDCT['noChecks']: userExternalId = 'U' + userId
        else: userExternalId = lclDCT['userExternalId'] # Added during Python3 migration
        
        # Build US Tax data
        serviceAddress = REST_UTIL.createServiceAddressData(streetAddr=lclDCT['streetAddr'], extendedAddr=lclDCT['extendedAddr'], locality=lclDCT['locality'], region=lclDCT['region'], postalCode=lclDCT['postalCode'], extendedPostalCode=lclDCT['extendedPostalCode'], countryCode=lclDCT['countryCode'])
        
        # Debug output
        print('Adding subscription ' + str(externalId) + ' to user ' + str(userId))
        
        retCode = REST_UTIL.createUserAndSubscription(RESTInst,
                subExternalId=externalId,
                subAttr=lclDCT['customAttr'][1],
                timeZone=lclDCT['subTimeZone'],
                billingCycle=billingCycle,
                subStatus=lclDCT['subStatus'],
                taxStatus=lclDCT['taxStatus'],
                taxCertificate=lclDCT['taxCertificate'],
                taxLocation=lclDCT['taxLocation'],
                glCenter=lclDCT['glCenter'],              
                subApiEventData=lclDCT['customAttr'][6],
                
                rolesExternalIds=lclDCT['rolesExternalIds'],
                rolesPricingIds=lclDCT['rolesPricingIds'],
                
                customerType=lclDCT['customerType'],
                serviceAddress=serviceAddress,
                npa=lclDCT['npa'],
                nxx=lclDCT['nxx'],
                tenantId=lclDCT['tenantId'], 
                exemptionCodeList=lclDCT['exemptionCodeList'],
                
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                routingType=lclDCT['routingType'],
                routingValue=lclDCT['routingValue'],
                executeMode=lclDCT['executeMode'],
                )
        
        # Stuff to do if we passed
        if lclDCT['eventPass']:
                # Update tracking data
                TRACK.updateTrackingData('createUser', externalId = userExternalId, userId = userId, mark='USER_'+lclDCT['mark'], RESTInst=RESTInst)
                TRACK.updateTrackingData('createSubscription', externalId = externalId, mark='SUBSCR_'+lclDCT['mark'], RESTInst=RESTInst)
        
        # Query user
        queryValue = userId
        queryType = lclDCT['userQueryType']
        
        return (queryType, queryValue)
#==========================================================
def CmdUser_createuserandsubscription(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        userId = lclDCT['userId']
        externalId = lclDCT['externalId']
        # End of local variables setup.

        # User should not exist
        if userId in TRACK.userTracking and not lclDCT['noChecks']:
                print('ERROR: user with ID "' + externalId + '" is already defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Subscription should not exist
        if externalId in TRACK.subscriberTracking and not lclDCT['noChecks']:
                print('ERROR: subscription with ID "' + externalId + '" is already defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Create billing cycle data if profile id defined
        if lclDCT['profileId'] and int(lclDCT['profileId']):
                billingCycle = REST_UTIL.createBillingCycleData(lclDCT['profileId'], dateOffset=lclDCT['dateOffset'], startTime=lclDCT['startTime'])
        else:
                billingCycle = None
        
        # Set user external ID if not passed in
        if not lclDCT['userExternalId'] and userId and not lclDCT['noChecks']: userExternalId = 'U' + userId
        else: userExternalId = lclDCT['userExternalId'] # Added during Python3 migration
        
        # Build US Tax data
        serviceAddress = REST_UTIL.createServiceAddressData(streetAddr=lclDCT['streetAddr'], extendedAddr=lclDCT['extendedAddr'], locality=lclDCT['locality'], region=lclDCT['region'], postalCode=lclDCT['postalCode'], extendedPostalCode=lclDCT['extendedPostalCode'], countryCode=lclDCT['countryCode'])
        
        # Debug output
        print('Creating user ' + str(userId) + '(U)/' + str(userExternalId) + '(X) and subscription ' + str(externalId))
        
        retCode = REST_UTIL.createUserAndSubscription(RESTInst,
                userId=userId,
                userExternalId=userExternalId,
                userAttr=lclDCT['customAttr'][4],
                firstName=lclDCT['firstName'],
                lastName=lclDCT['lastName'],
                contactPhoneNumber=lclDCT['contactPhoneNumber'],
                contactEmail=lclDCT['contactEmail'],
                notificationPreference=lclDCT['notificationPreference'],
                language=lclDCT['language'],
                contactPushTokenList=None,
                userStatus=lclDCT['userStatus'],
                userApiEventData=lclDCT['customAttr'][6],
                
                subExternalId=externalId,
                subAttr=lclDCT['customAttr'][1],
                timeZone=lclDCT['subTimeZone'],
                billingCycle=billingCycle,
                subStatus=lclDCT['subStatus'],
                taxStatus=lclDCT['taxStatus'],
                taxCertificate=lclDCT['taxCertificate'],
                taxLocation=lclDCT['taxLocation'],
                glCenter=lclDCT['glCenter'],              
                subApiEventData=lclDCT['customAttr'][6],
                
                rolesExternalIds=lclDCT['rolesExternalIds'],
                rolesPricingIds=lclDCT['rolesPricingIds'],
                
                customerType=lclDCT['customerType'],
                serviceAddress=serviceAddress,
                npa=lclDCT['npa'],
                nxx=lclDCT['nxx'],
                tenantId=lclDCT['tenantId'], 
                exemptionCodeList=lclDCT['exemptionCodeList'],
                
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                routingType=lclDCT['routingType'],
                routingValue=lclDCT['routingValue'],
                executeMode=lclDCT['executeMode'],
                )
        
        # Stuff to do if we passed
        if lclDCT['eventPass']:
                # Update tracking data
                TRACK.updateTrackingData('createUser', externalId = userExternalId, userId = userId, mark='USER_'+lclDCT['mark'], RESTInst=RESTInst)
                TRACK.updateTrackingData('createSubscription', externalId = externalId, mark='SUBSCR_'+lclDCT['mark'], RESTInst=RESTInst)
        
        # Query user
        queryValue = userId
        queryType = lclDCT['userQueryType']
        
        return (queryType, queryValue)
        
#==========================================================
def CmdUser_createuser(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        userId = lclDCT['userId']
        externalId = lclDCT['externalId']
        # End of local variables setup.

        # Stuff to check if not noChecks
        if not lclDCT['noChecks']:
                # Set user external ID and userId if not passed in
                if not lclDCT['userExternalId'] and userId: userExternalId = 'U' + userId
                else: userExternalId = lclDCT['userExternalId'] # Added during Python3 migration
                if not userId and userExternalId: userId = 'U' + userExternalId
        
                # User should not exist
                if (userExternalId and userExternalId in TRACK.userTracking) or (userId and userId in TRACK.userTracking):
                        print('ERROR: user with ID "' + externalId + '" is already defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
                
        # Debug output
        print('Creating user ' + str(userId) + '(U)/' + str(userExternalId) + '(X)')
        
        retCode = REST_UTIL.createUser(RESTInst,
                userId=userId,
                externalId=userExternalId,
                attr=lclDCT['customAttr'][4],
                firstName=lclDCT['firstName'],
                lastName=lclDCT['lastName'],
                contactPhoneNumber=lclDCT['contactPhoneNumber'],
                contactEmail=lclDCT['contactEmail'],
                notificationPreference=lclDCT['notificationPreference'],
                language=lclDCT['language'],
                contactPushTokenList=None,
                timeZone=lclDCT['userTimeZone'],
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                routingType=lclDCT['routingType'],
                routingValue=lclDCT['routingValue'],
                executeMode=lclDCT['executeMode'],
                apiEventData=lclDCT['customAttr'][6],
                status=lclDCT['userStatus'],
                )
        
        # Stuff to do if we passed
        if lclDCT['eventPass']:
                # Update tracking data
                TRACK.updateTrackingData(lclDCT['ACTION'], externalId = userExternalId, userId = userId, mark=lclDCT['mark'], RESTInst=RESTInst)
        
        # Query user
        queryValue = userId
        queryType = lclDCT['userQueryType']
        
        return (queryType, queryValue)
        
#==========================================================
def CmdUser_modifyuser(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        userId = lclDCT['userId']
        externalId = lclDCT['externalId']
        # End of local variables setup.

        # User should exist
        if userId not in TRACK.userTracking and not lclDCT['noChecks']:
                print('ERROR: user with ID "' + externalId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # OK...  We can have stuff that has been defaulted.  For modifies, only want to send in what was specifically requested to be modified.
        # Some fields (e.g. profileId) can't be modified and even setting them to the same value they were created with causes issues.
        # Build command to exec (very non-Pythonic...)
        if cmdLineInput:
         for param in DATA.userModifyList + [x[0] for x in DATA.customUserParameters]:
          if not cmdLineInput.count(param): lclDCT[param] = None
         
         # Really should recalculate Attr parameters as above lines were meant to clear those that were not input in the command line...
         (devAttr, subAttr, groupAttr, offerAttr, userAttr, loginAttr, apiEventDataAttr) = PRIM.getCustomAttributes(lclDCT, cmdLineInput)
        else:
                # Copy from dictionary
                userAttr = lclDCT['customAttr'][4]
                apiEventDataAttr = lclDCT['customAttr'][6]
        
        # Debug output
        print('Modifying user ' + str(userId))
        
        retCode = REST_UTIL.modifyUser(RESTInst,
                userId,
                queryType=lclDCT['userQueryType'],
                externalId=lclDCT['userExternalId'],
                attr=userAttr,
                firstName=lclDCT['firstName'],
                lastName=lclDCT['lastName'],
                status=lclDCT['userStatus'],
                contactPhoneNumber=lclDCT['contactPhoneNumber'],
                contactEmail=lclDCT['contactEmail'],
                notificationPreference=lclDCT['notificationPreference'],
                language=lclDCT['language'],
                contactPushTokenList=None,
                routingType=lclDCT['routingType'],
                routingValue=lclDCT['routingValue'],
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                executeMode=lclDCT['executeMode'],
                apiEventData=apiEventDataAttr,
                )
        
        # Stuff to do if we passed
        if lclDCT['eventPass']:
                # Update tracking data
                TRACK.updateTrackingData(lclDCT['ACTION'], externalId = lclDCT['userExternalId'], userId = userId, mark=lclDCT['mark'], modId=lclDCT['userExternalId'])
        
        # Query user
        queryValue = userId
        queryType = lclDCT['userQueryType']
        
        return (queryType, queryValue)
        
#==========================================================
def CmdUser_deleteuser(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        userId = lclDCT['userId']
        # End of local variables setup.

        # Check for invalid combination
        if lclDCT['mark'] and lclDCT['noChecks']:
                print('ERROR:  can\'t specify a mark when noChecks is in effect')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Set object type (for ease of cut/paste to other objects)
        objType='user'
        
        print('Looking to remove ' + objType + ' ' + userId + ' (' + lclDCT['userQueryType'] + ')')
        
        # First order is to get object data
        q = GET.getObject(userId, hostname=QAUTILS.gatewaysConfig.get('REST', 'restServer'), hostport=QAUTILS.gatewaysConfig.get('REST', 'restPort'), queryType=lclDCT['userQueryType'], objType=objType)
        
        # If Q is empty, then nothing to do
        if q is None:
                print(objType + ' non-existent.')
                
                # Nothing to query
                queryType = queryValue = None
                
                return (queryType, queryValue)
                
        # Get OID
        try:
                oid = q.find('./ObjectId').text.strip()
        except:
                print('WARNING: ' + objType + ' does not have an ObjetId...')
                
                # Nothing to query
                queryType = queryValue = None
                
                return (queryType, queryValue)
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']:   lclStartTime = lclDCT['startTime']
        else: lclStartTime = lclDCT['lclStartTime'] # Added during Python3 migration

        # Execute primitive
        retCode = REST_UTIL.deleteUser(RESTInst,
                userId,
                queryType=lclDCT['userQueryType'],
                now=lclStartTime,
                routingType=lclDCT['routingType'],
                routingValue=lclDCT['routingValue'],
                executeMode=lclDCT['executeMode'],
                eventPass=lclDCT['eventPass'],
                apiEventData=lclDCT['customAttr'][6],
                )
        
        # Stuff to do if we passed
        if lclDCT['eventPass']:
                # Update tracking data
                TRACK.updateTrackingData(lclDCT['ACTION'], userId = userId, RESTInst=RESTInst)
        
        # Query nothing
        queryValue = None
        queryType = None

        return (queryType, queryValue)
        
#==========================================================
def CmdUser_queryuser(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        userId = lclDCT['userId']
        externalId = lclDCT['externalId']
        # End of local variables setup.

        # User should exist
        if userId not in TRACK.userTracking and not lclDCT['noChecks']:
                print('ERROR: user with ID "' + externalId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # If verbose set but no output file, then set to stdout
        if lclDCT['verbose'] in ['full', 'high'] and not lclDCT['outputFileName']: outputFileName = 'stdout'
        else: outputFileName = lclDCT['outputFileName'] # Added during Python3 migration
        
        # Execute primitive
        retCode = REST_UTIL.queryUser(RESTInst,
                userId,
                queryType=lclDCT['userQueryType'],
                routingType=lclDCT['routingType'],
                routingValue=lclDCT['routingValue'],
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                )
        
        # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
        try:
                respData = str(retCode.printElementBasedXml())
        except:
                respData = str(retCode)
        
        # May be here just to get the normal output file.  Check and skip this query if so.
        if lclDCT['saveData'] or (outputFileName and outputFileName.lower() != 'none'):
                # If supposed to save data to variables then do that here
                if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, 'User', respData)
                
                # If supposed to store output then write to where the caller wanted it to go.  nly if not saving data.
                if outputFileName and outputFileName.lower() != 'none': CSVQA.processDataToOutput(respData, outputFileName)
                
                # Query nothing
                queryValue = None
                queryType = None
        else:
                # Query user
                queryValue = userId
                queryType = lclDCT['userQueryType']
                
        return (queryType, queryValue)

#==========================================================
def CmdUser_addsubscription(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        userId = lclDCT['userId']
        externalId = lclDCT['externalId']
        # End of local variables setup.

        # User should exist
        if userId not in TRACK.userTracking and not lclDCT['noChecks']:
                print('ERROR: user with ID "' + externalId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Subscription should exist
        if externalId not in TRACK.subscriberTracking and not lclDCT['noChecks']:
                print('ERROR: subscription with ID "' + externalId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Debug output
        print('Adding subscription ' + str(externalId) + ' to user ' + str(userId))
        
        retCode = REST_UTIL.userAddSubscription(RESTInst,
                userId,
                lclDCT['userQueryType'],
                externalId,
                lclDCT['subQueryType'],
                rolesPricingIds=lclDCT['rolesPricingIds'],
                rolesExternalIds=lclDCT['rolesExternalIds'],
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                routingType=lclDCT['routingType'],
                routingValue=lclDCT['routingValue'],
                executeMode=lclDCT['executeMode'],
                apiEventData=lclDCT['customAttr'][6],
                )
        
        # Stuff to do if we passed
        if lclDCT['eventPass']:
                # Update tracking data
                TRACK.updateTrackingData(lclDCT['ACTION'], externalId = externalId, userId = userId)
        
        # Query user
        queryValue = userId
        queryType = lclDCT['userQueryType']
        
        return (queryType, queryValue)
        
#==========================================================
def CmdUser_modifyusersubscription(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        userId = lclDCT['userId']
        externalId = lclDCT['externalId']
        # End of local variables setup.

        # User should exist
        if userId not in TRACK.userTracking and not lclDCT['noChecks']:
                print('ERROR: user with ID "' + externalId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Subscription should exist
        if externalId not in TRACK.subscriberTracking and not lclDCT['noChecks']:
                print('ERROR: subscription with ID "' + externalId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Debug output
        print('Adding subscription ' + str(externalId) + ' to user ' + str(userId))
        
        retCode = REST_UTIL.userModifySubscription(RESTInst,
                userId,
                lclDCT['userQueryType'],
                externalId,
                lclDCT['subQueryType'],
                rolesPricingIds=lclDCT['rolesPricingIds'],
                rolesExternalIds=lclDCT['rolesExternalIds'],
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                routingType=lclDCT['routingType'],
                routingValue=lclDCT['routingValue'],
                executeMode=lclDCT['executeMode'],
                apiEventData=lclDCT['customAttr'][6],
                )
        
        # Stuff to do if we passed
        if lclDCT['eventPass']:
                # Update tracking data
                TRACK.updateTrackingData(lclDCT['ACTION'], externalId = externalId, userId = userId)
        
        # Query user
        queryValue = userId
        queryType = lclDCT['userQueryType']
        
        return (queryType, queryValue)
        
#==========================================================
def CmdUser_removesubscriptionfromuser(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        userId = lclDCT['userId']
        externalId = lclDCT['externalId']
        # End of local variables setup.

        # User should exist
        if userId not in TRACK.userTracking and not lclDCT['noChecks']:
                print('ERROR: user with ID "' + externalId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Subscription should exist
        if externalId not in TRACK.subscriberTracking and not lclDCT['noChecks']:
                print('ERROR: subscription with ID "' + externalId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Debug output
        print('Removing subscription ' + str(externalId) + ' to user ' + str(userId))
        
        retCode = REST_UTIL.userRemoveSubscription(RESTInst,
                userId,
                lclDCT['userQueryType'],
                externalId,
                lclDCT['subQueryType'],
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                routingType=lclDCT['routingType'],
                routingValue=lclDCT['routingValue'],
                executeMode=lclDCT['executeMode'],
                apiEventData=lclDCT['customAttr'][6],
                )
        
        # Stuff to do if we passed
        if lclDCT['eventPass']:
                # Update tracking data
                TRACK.updateTrackingData(lclDCT['ACTION'], externalId = externalId, userId = userId)
        
        # Query user
        queryValue = userId
        queryType = lclDCT['userQueryType']
        
        return (queryType, queryValue)
        
#==========================================================
def CmdUser_modifyuserauthdata(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        userId = lclDCT['userId']
        externalId = lclDCT['externalId']
        # End of local variables setup.

        # User should exist
        if userId not in TRACK.userTracking and not lclDCT['noChecks']:
                print('ERROR: user with ID "' + externalId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Debug output
        print('modifying user ' + str(userId) + ' authentication data')
        
        retCode = REST_UTIL.modifyUserAuthData(RESTInst,
                userId,
                lclDCT['userQueryType'],
                loginId=lclDCT['LoginId'],
                password=lclDCT['password'],
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                routingType=lclDCT['routingType'],
                routingValue=lclDCT['routingValue'],
                executeMode=lclDCT['executeMode'],
                apiEventData=lclDCT['customAttr'][6],
                )
        
        # Stuff to do if we passed
        '''
        if eventPass:
                # Update tracking data
                TRACK.updateTrackingData(lclDCT['ACTION'], externalId = externalId, userId = userId)
        '''
        
        # Query user
        queryValue = userId
        queryType = lclDCT['userQueryType']
        
        return (queryType, queryValue)
        
#==========================================================
def CmdUser_queryuserauthdata(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        userId = lclDCT['userId']
        externalId = lclDCT['externalId']
        # End of local variables setup.

        # User should exist
        if userId not in TRACK.userTracking and not lclDCT['noChecks']:
                print('ERROR: user with ID "' + externalId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Debug output
        print('Query user ' + str(userId) + ' authentication data')
        
        # If verbose set but no output file, then set to stdout
        if lclDCT['verbose'] in ['full', 'high'] and not lclDCT['outputFileName']: outputFileName = 'stdout'
        else: outputFileName = lclDCT['outputFileName'] # Added during Python3 migration
        
        retCode = REST_UTIL.queryUserAuthData(RESTInst,
                userId,
                lclDCT['userQueryType'],
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                routingType=lclDCT['routingType'],
                routingValue=lclDCT['routingValue'],
                executeMode=lclDCT['executeMode'],
                )
        
        # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
        try:
                respData = str(retCode.printElementBasedXml())
        except:
                respData = str(retCode)
        
        # May be here just to get the normal output file.  Check and skip this query if so.
        if lclDCT['saveData'] or (outputFileName and outputFileName.lower() != 'none'):
                # If supposed to save data to variables then do that here
                if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, 'User', respData)
                
                # If supposed to store output then write to where the caller wanted it to go.  nly if not saving data.
                if outputFileName and outputFileName.lower() != 'none': CSVQA.processDataToOutput(respData, outputFileName)
                
                # Query nothing
                queryValue = None
                queryType = None
        else:
                # Query user
                queryValue = userId
                queryType = lclDCT['userQueryType']
                
        return (queryType, queryValue)

#==========================================================
def CmdUser_useraddgroup(lclDCT, options, RESTInst, cmdLineInput):
        return processUserGroupCommand(lclDCT, options, RESTInst, cmdLineInput, 'Add')

#==========================================================
def CmdUser_userremovegroup(lclDCT, options, RESTInst, cmdLineInput):
        return processUserGroupCommand(lclDCT, options, RESTInst, cmdLineInput, 'Remove')

#==========================================================
def CmdUser_usermodifygroup(lclDCT, options, RESTInst, cmdLineInput):
        return processUserGroupCommand(lclDCT, options, RESTInst, cmdLineInput, 'Modify')

#==========================================================
def processUserGroupCommand(lclDCT, options, RESTInst, cmdLineInput, cmdAction='Add'):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        userId = lclDCT['userId']
        externalId = lclDCT['externalId']
        # End of local variables setup.

        # User should exist
        if userId not in TRACK.userTracking and not lclDCT['noChecks']:
                print('ERROR: user with ID "' + externalId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Group should exist
        if lclDCT['groupId'] not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: subscription with ID "' + externalId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Debug output
        print(cmdAction + ' group ' + str(lclDCT['groupId']) + ' and user ' + str(userId))
        
        # Build common part of command
        cmd = '_a = REST_UTIL.user' + cmdAction + 'Group(RESTInst, userId, lclDCT["userQueryType"], groupId, groupQueryType,now=lclDCT["lclStartTime"], eventPass=lclDCT["eventPass"], routingType=lclDCT["routingType"], routingValue=lclDCT["routingValue"], executeMode=lclDCT["executeMode"], apiEventData=lclDCT["customAttr"][6], '
        
        # Add additional parameters if not removing
        if cmdAction != 'Remove': cmd += 'rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds,'
        
        # Close the command
        cmd += ')'
        
        # Execute the command
        exec(cmd)
        retCode = locals()['_a']
        
        # Stuff to do if we passed
        if lclDCT['eventPass']:
                # Update tracking data
                TRACK.updateTrackingData(lclDCT['ACTION'], externalId = externalId, userId = userId)
        
        # Query user
        queryValue = userId
        queryType = lclDCT['userQueryType']
        
        return (queryType, queryValue)
        
