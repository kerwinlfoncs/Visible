#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:52
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:32
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:11
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

# from builtins import input
# from builtins import str
from future import standard_library
standard_library.install_aliases()
# from builtins import input
# from builtins import str
import configparser
import copy  
import difflib  
import log_errors as LOGGER
import optparse  
import os, sys, random
import pickle  
import re  
import shutil  
import subprocess  
import timeToMDCtime as MDCTIME
import time
import common_mdc as COMMON

from xml.etree import ElementTree
import javaApiTest as JAVA

gatewaysConfig = None
LogDir = None
TxnLogDir = None
eventDct = {}
dctGeneral = {}
currentTestStartTime = 0
QACommon = ''
sessionTimeKeeper={}
MSCC = 0
msccFlag = False
diamFileLine = 0
txnLogLine = 0
tskLogLine = 0
notifLogLine = 0
stripFields = False
xmlStatus=True
path = os.getcwd()
logger = LOGGER.clErrors(path)

# Add globally referencable list of possible group tier values.  
# Ideally we tie this to the pricing file, but for now hard-code (since we don't always have access to the pricing file from here).
groupTiers = []
groupTiers.append('Corporation')
groupTiers.append('Region')
groupTiers.append('Country')
groupTiers.append('Division')
groupTiers.append('Department')
groupTiers.append('Team')
groupTiers.append('Group')
groupTiers.append('Family')


#===============================================================================
def castStringtoList(myString):
    return(eval(str(myString)))

#===============================================================================
def castStringtoListOfString(myString):
    l1 = (eval(str(myString)))
    Lst=[]
    if type(l1) == type(list()):
        for item in l1:
            Lst.append(str(item))
        return Lst
    return myString

#go thu the entire directory and search for a file name DCT_<..>  and print contents
#this is a pickled version of the dictionary
def printAllDictionaries(path) :
    allMdcFilesList = path + '/allMdcFilesList'
    if not (os.path.isfile(allMdcFilesList)):
        logger.printRes(path, 'validate_balances.txt',
            'Cannot validate: missing ' + allMdcFilesList)
        sys.exit('Cannot validate: missing ' + allMdcFilesList)

    filesList = open(allMdcFilesList,'r')
    for fp in filesList.readlines() :
        fp = fp.strip('\n')
        fp = fp.split('/')[-1]
        print('================  output for ' + fp + '=====================')
        MDC_UTILS.printPickledDictionary(path, fp)

#===============================================================================
def saveGroupMDC(groupId, testTag, queryType='ExternalId', queryTime=None, querySize=None, diffInitiator=False, diffSponsor=False, debugData=''):
    global currentTestStartTime
    global dctGeneral
    global path
    global stripFields

    initiatorOid = None
    initiatorExternalId = None
    initiatorDeviceOid = None
    sponsorOid = None
    sponsorExternalId = None

    if queryTime is not None:
        queryTime = MDCTIME.convertTime(queryTime, restVersion=QAV3.restVersion)

    diffEvents = False
    if diffInitiator or diffSponsor:
        diffEvents = True

    if dctGeneral['events']:
        (initiatorOid, initiatorExternalId, initiatorDeviceOid, sponsorOid, sponsorExternalId)=\
            parseActions('txn', 'trsf_outQueryGroup_' + str(groupId).replace(':', '_') + '_' + testTag, diffEvents, stripFields)

    if dctGeneral['notifications']:
        parseActions('notif', 'trsf_outQueryGroup_' + str(groupId).replace(':', '_') + '_' + testTag, False, stripFields)

    if dctGeneral['tasks']:
        parseActions('tasks', 'trsf_outQuery_' + str(groupId).replace(':', '_') + '_' + testTag, False, stripFields)

    parseActions('diam', 'trsf_outQueryGroup_' + str(groupId).replace(':', '_') + '_' + testTag, False, stripFields)

    print('Saving MDC for group with ' + queryType + ': ' + str(groupId))
    
    mdcConnection = getDatacontainerConnection()
    mdcFileName = GROUP.queryGroup(mdcConnection, path, groupId, testTag, queryType=queryType, querySize=querySize, queryTime=queryTime,
        diffEvents=diffEvents)
    print('mdcFile is------------------ ' + str(mdcFileName))

    # Validate initiator/sponsor if requested
    VALIDATE_EDR.validateInitiatorSponsorForGroup(restInst=mdcConnection, mdcFileName=mdcFileName,
        diffInitiator=diffInitiator, diffSponsor=diffSponsor, initiatorOid=initiatorOid,
        initiatorExternalId=initiatorExternalId, sponsorOid=sponsorOid, sponsorExternalId=sponsorExternalId,
        queryTime=queryTime, testTag=testTag)

    currentTestEndTime = time.clock()
    currentTestDuration = currentTestEndTime - currentTestStartTime
    timeFile = path + '/' + COMMON.resultsDir + '/test_duration_local.txt'
    runCmd('echo ' + str(currentTestDuration) + ' > ' + timeFile)
    
#===============================================================================
def saveDeviceMDC(queryValue, testName, queryType='PhoneNumber', queryTime=None, debugData=''):
    global dctGeneral
    global currentTestStartTime
    global path
    global stripFields

    if queryTime is not None:
        queryTime = MDCTIME.convertTime(queryTime, restVersion=QAV3.restVersion)

    if dctGeneral['events']:
        (initiatorOid, initiatorExternalId, initiatorDeviceOid, sponsorOid, sponsorExternalId)=\
            parseActions('txn', 'trsf_outQuery_' + str(queryValue).replace(':', '_') + '_' + testName, False, stripFields)

    if dctGeneral['notifications']:
        parseActions('notif', 'trsf_outQuery_' + str(queryValue).replace(':', '_') + '_' + str(testName), False, stripFields)

    if dctGeneral['tasks']:
        parseActions('tasks', 'trsf_outQuery_' + str(queryValue).replace(':', '_') + '_' + str(testName), False, stripFields)

    parseActions('diam', 'trsf_outQuery_' + str(queryValue).replace(':', '_') + '_' + str(testName), False, stripFields)

    #this will generate $path/results/outQuery_queryValue_testName
    mdcConnection = getDatacontainerConnection()
    mdcFileName = MDC_UTILS.queryDevice(mdcConnection, path, queryValue, testName, queryType = queryType,
        queryTime = queryTime)

    print('mdcFile is------------------ ' + str(mdcFileName))
    # parse this MDC into a dictionary, rest param will return a win startTim=e

    currentTestEndTime = time.clock()
    currentTestDuration = currentTestEndTime - currentTestStartTime
    timeFile = path + '/' + COMMON.resultsDir + '/test_duration_local.txt'
    runCmd('echo ' + str(currentTestDuration) + ' > ' + timeFile)

    return

#===============================================================================
def getDatacontainerConnection():
    v3Inst = RESTV3.SubscriberManagementV3Client(trace = getTrace(),
        hostName=gatewaysConfig.get('DATACONTAINER', 'hostName'),
        hostPort=int(gatewaysConfig.get('DATACONTAINER', 'hostPort')))
    return v3Inst

#===============================================================================
def checkForExpectFiles(path):
    if not os.path.isdir(path):
        return False

    if not os.path.isdir(path + '/expect'):
        return False
    list = os.listdir(path + '/expect')
    #print list
    if len(list) < 2 :
        return False
    return True

#===============================================================================
   
#this function is used to set the test startTime which is used to parse
#mtx_debug.log for any ERRORS that occured during the test runtime
def setTestStartTime(path):
    global currentTestStartTime
    #timeFile = path + '/' + COMMON.resultsDir + '/test_startTime.txt'
    #fp = open(timeFile,'w')
    currentTestStartTime = time.clock()
    #fp.close()

#===============================================================================

def setLogDir():
    global LogDir
    global TxnLogDir

    LogDir = os.getenv("MTX_TXN_LOG_DIR")
    TxnLogDir = LogDir + '/blade_' + os.getenv("MTX_ENGINE_ID") + '_' + \
        os.getenv("MTX_CLUSTER_ID") + '_' + os.getenv("MTX_LOGICAL_BLADE_ID")

#===============================================================================
def initializeTest(path, clean=True):
    global gatewaysConfig
    global logger
    global QACommon

    setLogDir()

    if re.search('subman', path.split('/')[-2]):
        COMMON.disableOutput = False

    QACommon = os.getenv("QADIR") + '/Common/'

    #if (clean):
    #    cleanConfigIniFile(path)

    # clean Summary file
    logger.printSummary(path,details=None)

    #Read Gateways : Diameter and/or REST
    gatewaysConfig = getDiameterRestConfig()

    
    # set the test startTime to parse Error log
    setTestStartTime(path)

    # Setup for a random number (no parameter means to use system time as
    # the seed value)
    random.seed()

    # Cleanup list of all MDC files
    fp = open( path + '/' + COMMON.resultsDir + '/allMdcFilesList','w')
    fp.close()
    
    if clean:
        parser = optparse.OptionParser()
        parser.add_option("-u", "--user", action='store', type='int', default=1)
        parser.add_option("-x", "--externalId", action='store', type='string', default=None)
        parser.add_option("-d", "--cduser", action='store', type='int', default=0)
        parser.add_option("-c", "--createUser", action='store', type='int', default=1)
        parser.add_option("-s", "--subscriber", action='store', help="Subscriber ID", type='string', default='10')
        parser.add_option("-e", "--deviceType", action='store', default="0", type='int', help="Device type")
        parser.add_option("-a", "--accessNumbers", action='store', default=None, type='string', help="AccessNumber")
        parser.add_option("-v", "--serviceId", action='store', default="0", help="service (voice, data, text)")
        parser.add_option("-o", "--offer", action='append', help="offer to add")
        parser.add_option("-b", "--sessionId", action='store', default="0", type='int', help="session id to start test with")
        parser.add_option("-k", "--mscc", action='store', default=0, type='int', help="mscc enabled")
        parser.add_option("-z", "--debug", action='store', default="0", type='int', help="debug Mode")
        parser.add_option("-m", "--members", action='store', default=0, type='int', help="number of members in a group")
        parser.add_option("-l", "--subsc", action='append', help="list of things")
        parser.add_option("-i", "--iteration", action='store', default=0, help="invocation iteration")
        parser.add_option("-q", "--strip", action='store', type='int', default=1, help="strip variable EDR/notification fields")
        parser.add_option("-r", "--events", action='store', type='int', default=1, help="print events")
        parser.add_option("-n", "--notifications", action='store', type='int', default=1, help="print notifications")
        parser.add_option("-w", "--tasks", action='store', type='int', default=0, help="print scheduled tasks")
        parser.add_option("-y", "--rest", action='store', type='string', default='MDC', help="rest invocation")
        parser.add_option("-t", "--convertTime", action='store', type='int', default=0, help="convert subman calls to UTC based on system time if not timezone-qualified")
        parser.add_option("", "--tz", action='store', type='string', default=None, help="system time zone to use")

	# Here are some legacy ones that probably should go the same way as the CSV items are handled below...
        parser.add_option("", "--deviceTypeName", action='store', default="generic", type='string', help="Device type name")
        parser.add_option("", "--multiSimShare", action='store', type='string', default='true', help="multi-SIM share flag")
        parser.add_option("", "--pause", action='store', type='string', default='no', help="pause flag setting (yes/no)")
        parser.add_option("", "--custStatus", action='store', type='string', default='non-premium', help="customer status")
        parser.add_option("", "--roamingPartner", action='store', default="0", type='string', help="roaming partner")
        parser.add_option("", "--zone", action='store', default="0", type='int', help="zone")

	# Process command line params
        (options, args) = parser.parse_args()
	
	# See if anything was left over.
	if args:
		print('ERROR:  unexpected arguments found: ' + str(args))
		sys.exit('Exiting due to failures')
	
        #subscriberId ='User' + str(options.user)
        #subscriberIdCreatedemo ='CDUser' + str(options.user)
    else:
        options = None
        args = None

    # Get timezone (once per invocation)
    getTimeZone(options.tz)
    
    config = configparser.ConfigParser()
    configFile = path + '/config.ini'
    if os.path.exists(configFile):
	config.read(path +'/config.ini')
	users = config.sections()
	#    print users
    else:
	# No config file.  Set to None
	users = None

    # Get structure for Subman calls
    v3Inst = JAVA.javaApiTest()

    # Set system time zone in timeToMdcTime
    setSystemTimeZone(options.tz)

    return(config, users, options, args, v3Inst, logger)

#============================================================
def setSystemTimeZone(tz):
   if tz: MDCTIME.systemTimeZone = tz
   else: 
    try:
        timeZoneFileName = os.getenv("QADIR") + '/Common/timeZone'
        timeZoneFile = open(timeZoneFileName, 'r')
        timeZone = (timeZoneFile.readline()).rstrip()
        MDCTIME.systemTimeZone = timeZone
        timeZoneFile.close()

    except IOError:
        MDCTIME.systemTimeZone = 'Etc/UTC'

   print('Test framework timezone is set to: ' + MDCTIME.systemTimeZone)

#============================================================
def getTrace():
    if gatewaysConfig.get('DATACONTAINER', 'traceMessages') == 'True':
        return True
    else:
        return False


#===============================================================================
def getFileLineCount(service):
    global path
    global msccFlag

    if service != 'diam' and service != 'notif' and service != 'tasks' and service != 'txn':
        print("Invalid argument passed to getFileLineCount(), requires 'diam', 'notif', 'tasks' or 'txn'")
        sys.exit()

    if service == 'diam':
        if msccFlag:
            fileName = path + '/' + COMMON.resultsDir + '/ECT_diameter_' + getTestName(path) + '_mscc.txt'
        else:
            fileName = path + '/' + COMMON.resultsDir + '/ECT_diameter_' + getTestName(path) + '.txt'
    elif service == 'notif':
        fileName = TxnLogDir + '/transactions_' + os.getenv("MTX_ENGINE_ID") + '_' + \
		        os.getenv("MTX_CLUSTER_ID") + '_' + os.getenv("MTX_LOGICAL_BLADE_ID") + '.log'
    elif service == 'tasks':
        fileName = TxnLogDir + '/transactions_' + os.getenv("MTX_ENGINE_ID") + '_' + \
		        os.getenv("MTX_CLUSTER_ID") + '_' + os.getenv("MTX_LOGICAL_BLADE_ID") + '.log'
    elif service == 'txn':
        fileName = TxnLogDir + '/transactions_' + os.getenv("MTX_ENGINE_ID") + '_' + \
	        os.getenv("MTX_CLUSTER_ID") + '_' + os.getenv("MTX_LOGICAL_BLADE_ID") + '.log'

    lCount = 0
    if os.path.exists(fileName):
        lCount = runCmd("wc -l " + fileName + " | cut -f1 -d' '")
        if lCount == '':
            return 0
        return int(lCount)
    else:
        return 0

    return int(lCount)


#===============================================================================
def updateFilePointer(service):
    global path
    global diamFileLine
    global txnLogLine
    global notifLogLine
    global tskLogLine

    if service != 'diam' and service != 'notif' and service != 'tasks' and service != 'txn':
        print("Invalid argument passed to updateFilePointer(), requires 'diam', 'notif', 'tasks' or 'txn'")
        sys.exit()

    if service == 'diam':
        time.sleep(.05)
    elif service == 'notif':
        time.sleep(.1)
    elif service == 'tasks':
        time.sleep(.1)
    elif service == 'txn':
        time.sleep(.1)

    # get previous log pointer value
    lCount = getFileLineCount(service)
    if service == 'diam':
        oldVal = diamFileLine
    elif service == 'notif':
        oldVal = txnLogLine
    elif service == 'tasks':
        oldVal = tskLogLine
    elif service == 'txn':
        oldVal = notifLogLine 

    if oldVal == lCount:
        return -1

    if service == 'diam':
        diamFileLine = lCount
    elif service == 'notif':
        txnLogLine = lCount
    elif service == 'tasks':
        tskLogLine = lCount
    elif service == 'txn':
        notifLogLine = lCount

    return oldVal

#===============================================================================
def getsubscriber(options, users):

    # added for create_demo
    #createDemoFile = path +  '/inAddSubscriberSet_1_Part_1.txt'
#    print 'OPTIONS = ' + str(options.user)
    if (options.cduser):
        subscriberId = 'CDUser' + str(options.cduser)
    else :
        subscriberId = 'User' + str(options.user)

    if (subscriberId not in users) :
        sys.exit(subscriberId + ' : no such user!')

    return subscriberId


#===============================================================================
def get_key_data(config, options, path, users):
    global dctGeneral
    global MSCC
    global stripFields

    dctGeneral =  getSubsc(config,'GENERAL')
#    print dctGeneral

    # Get session id
    if options.sessionId > 0:
        sessionId = options.sessionId
        dctGeneral['sessionid'] = sessionId
    
    # Always check that the user in question is in the config file.  May use it for some of the data
    if users:
    	userId =  getsubscriber(options, users)
    else:
	userId=None
    
#    print '################ using subsc=' + str(userId)

    # Where to get data depends on if it's input on the command line 
    # Start with external ID (top of the heap).  
    # This will change when we support external IDs as non-numeric strings...
    if not options.externalId:
	externalId = options.subscriber
	options.externalId = externalId
    else:
        # Use input data
        externalId = options.externalId

    # Sanity check here.  If no external ID, then you have messed up the config.
    if not externalId:
	print('ERROR:  Command did not specify external ID (-x), subscriber ID (-s) and the config file had no external ID line.  Can\'t continue.')
	sys.exit(1)

    # Subscriber default is in option line, so will be set no matter what.  Nothing special to check for here.
    
    # Next is the device ID.
    deviceId = options.subscriber
    options.deviceId = deviceId
    
    # Where to get data depends on if it's input on the command line 
    if options.mscc==1:
#        print 'setting options mscc'
        MSCC = 2

    if options.deviceType == 0 and userId:
        # Get data from config file
        deviceType = eval(config.get(userId, 'deviceType'))[0]
	options.deviceType = deviceType
    else:
        # Use input data
        deviceType = options.deviceType

    if options.serviceId == '0':
	if userId:
        	# Get data from config file
        	serviceId = eval(config.get(userId, 'deviceTypeT'))[0]
	else:
		serviceId = 'data'
	options.serviceId = serviceId
    else:
        # Use input data
        serviceId = options.serviceId

    if not options.offer :
	if userId:
         # Get data from config file
         offerIdList = eval(config.get(userId, 'offerId'))
         dctGeneral['offerId'] = offerIdList
         if type(offerIdList) == type(list()):
            offerId = offerIdList
         else:
            offerId = config.get(userId, 'offerId')
	else:
	    offerId=None
    else:
        # Use input data
        offerId = getOptionsVal(options.offer, 'offerId')

    if options.members == 0:
       if userId: 
        # Get data from config file
        if (config.has_section('GENERAL')):
            sectionItems = config.items('GENERAL')
            if 'members' in sectionItems:
                members = config.get('GENERAL', 'members')
            else:
                members = 0
        else:
            members = 0
       else:
	    members=0
       options.members = members
    else:
        # Use input data
        members = options.members


    if options.events:
        updateFilePointer('txn')
        dctGeneral['events'] = 1
#        setEventTypeTree()
        eventOutputFileName = path + '/' + COMMON.resultsDir + '/ECT_events_' + os.path.basename(path) + '.txt' 
        if os.path.exists(eventOutputFileName):
            runCmd('rm ' + eventOutputFileName)
    else:
        dctGeneral['events'] = 0

    if options.notifications:
        updateFilePointer('notif')
        dctGeneral['notifications'] = 1
        notifOutputFileName = path + '/' + COMMON.resultsDir + '/ECT_notifications_' + os.path.basename(path) + '.txt' 
        if os.path.exists(notifOutputFileName):
            runCmd('rm ' + notifOutputFileName)
    else:
        dctGeneral['notifications'] = 0

    if options.tasks:
        updateFilePointer('tasks')
        dctGeneral['tasks'] = 1
        tasksOutputFileName = path + '/' + COMMON.resultsDir + '/ECT_tasks_' + os.path.basename(path) + '.txt' 
        if os.path.exists(tasksOutputFileName):
            runCmd('rm ' + tasksOutputFileName)
    else:
        dctGeneral['tasks'] = 0

    updateFilePointer('diam')

    dctGeneral['accessNumber'] = options.accessNumbers

    if options.strip:
        stripFields = True
    else:
        stripFields = False

    MDCTIME.convert = options.convertTime

#    print 'subscriberId = ' + userId
#    print 'deviceId = ' + str(deviceId)
#    print 'externalId = ' + str(externalId)
#    print 'deviceType = ' + str(deviceType)
#    print 'serviceId = ' + serviceId
#    print 'offerId = ' + str(offerId)
#    print 'amount = ' + str(amount)
#    print 'members-group = ' + str(members)
    dctSubsc =  getSubsc(config,'User1')
    if options.subsc:
        getSubscList(options)
        dctGeneral['subscList'] = getSubscList(options)

    return (userId, deviceId, externalId, deviceType, serviceId, offerId, dctGeneral)

#===============================================================================

def getOptionsVal(optionVal, optionName, itemType='int'):
    global dctGeneral
    optionList = eval(str(optionVal[0]))
    if type(optionList) == type(tuple()):
        val = str(optionList[0])
    else:
        val = str(optionList)
    #print optionList
    if itemType == 'string':
        dctGeneral[optionName] = castStringtoListOfString(optionList)
    else:
         dctGeneral[optionName] = (optionList)
    #print '????????????????????????????????????'
    #print  dctGeneral
    #print '????????????????????????????????????'
    return(val)
#===============================================================================
#util function to check if we need debug information attached to the logs
def checkDbgMsg(debugOpt, st1, st2):
    #if (debugOpt):
#    print debugOpt
    return('!'+ st1 + '_' + st2)   #workaround so we don't want to break older tests
    #return None

#===============================================================================
def getDiameterRestConfig():
    QACommon = os.getenv("QADIR") + '/Common/'
    configIniFile = QACommon + 'config.ini'
    if not os.path.exists(configIniFile):
        configIniFile = os.getenv("MYCONFIGINI")
        configIniFile = './config.ini'
        if not configIniFile == None:
            if not os.path.exists(configIniFile):
                print('cannot find the config ini in Common or env "MYCONFIGINI"')
                sys.exit(1)
        else:
            print('cannot find the config ini in Common or env "MYCONFIGINI"')
            sys.exit(1)

#    print 'reading configuration data from ' + str(configIniFile) + '!'
    configG = configparser.ConfigParser()
    configG.read(configIniFile)
    return (configG)

#===============================================================================
#this function will extract other SECTIONS from the config.ini
#it returns a dictionary of all items in that section
def getSubsc(config,section):
    dct = {}
    if (config.has_section(section)):
        sectionItems=config.items(section)
        #print sectionItems
        for xx in  sectionItems:
            dct[xx[0]] = eval(xx[1])
    return dct

#===============================================================================
#this function is used by main test driver to setup a uniq sessionIDs for all the tests 
def initializeSessionIds(cpath,test,sessionId):
    testConfig = test + '/config.ini'
    testConfigNew =  test + '/configNew.ini'
    #testConfigNewp = open (testConfigNew,'w')
    config = configparser.ConfigParser()
    os.chdir(test)
    config.read(testConfig)
    if config.has_section('GENERAL'):
#        print "--------- "
        cmd = "sed -e 's/sessionId = .*/sessionId = " + str(sessionId) + '/\' ' + testConfig+  ' > mod.tmp'
        os.system(cmd)
        os.system("mv mod.tmp " + testConfig)
    else:
        os.system('echo [GENERAL] > ' + testConfigNew)
        os.system('echo sessionId = ' + str(sessionId)+ ' >> ' + testConfigNew)
        os.system('echo >> ' + testConfigNew)
        os.system('cat ' + testConfigNew + ' ' + testConfig + "> ./all\.tmp")
        os.system('mv ./all\.tmp ' + testConfig)
        os.system("cat " + testConfig)
    os.chdir(cpath)
    
#===============================================================================
#this fnction used to run bash scripts.        
def runCmd(cmd, output='delayed'):
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    out = p.stdout.read().strip()
    return out  #This is the stdout from the shell command
#===============================================================================
#function to return the test name based on the directory name
def getTestName(path):
    return(path.split('/')[-1])
#===============================================================================
#not needed nor should be used
def setSystemClock(timeStamp = None):
    return

#==========================================================
def iterateUsageIncDevice(count, deviceId, serviceId, use, startTime, sessionId, testName, extraAVP = {}, tag = None, deviceIdOffset = 0, eventPass = True, saveInit = True, saveTerm = True, queryTime=None):
    i = 0
    if (deviceIdOffset == 0):  #increment a deviceId starting with an offset
        deviceIdu = deviceId
    else:
        deviceIdu = str(deviceIdOffset)

    tag1 = tag
    while ( i < count):
        if tag == None:
            tag1 = '_iter' + str(i) 
        else:
            tag1 = tag + '_' + str(i) 
        sendSaveInitTerm(deviceIdu, serviceId, use, tag1, startTime, sessionId, testName, eventPass, extraAVP, saveInit, saveTerm, queryTime=queryTime)
        i = i + 1
        deviceIdu = str(int(deviceIdu) + 1)
        sessionId = sessionId + 1
    return sessionId

#==========================================================
def sendSaveInitTerm(deviceId, serviceId, use, tag, startTime, sessionId, testName, eventPass = True, extraAVP={}, saveInit = True, saveTerm = True, queryTime = None):
    addList = None
    omitList = None

    use = use
    if 'add' in extraAVP:
        addList = extraAVP['add']
    if 'omit' in extraAVP:
        omitList = extraAVP['omit']

#   print 'sending init id= ' + str(deviceId) + 'and sid=' + str(serviceId) + 'and ' + str(startTime)
    sendOneRequest(deviceId = deviceId, reqamount = use, usedamount = 0,
                requestType = 'initial', sessionId = sessionId,
                serviceId = serviceId, startTime = startTime, eventPass = eventPass, extraAVP = extraAVP)
    if saveInit:
        saveMDC(deviceId, testName + '_' + tag + '_initial',
                    '!' + str(startTime)+ '_' + str(use), queryTime = queryTime)

    #restore omit/add lists
    if addList != None:
        extraAVP['add'] = addList

    if omitList != None:
        extraAVP['omit'] = omitList

    # increase time by 600 secs of the previous time
    sendOneRequest(deviceId = deviceId, reqamount = 0, usedamount = use,
                    requestType = 'term', sessionId = sessionId,
                    serviceId = serviceId, startTime = startTime, eventPass = eventPass, extraAVP = extraAVP)


    if saveTerm:
        saveMDC(deviceId, testName + '_' + tag + '_term',
                    '!' + str(startTime)+ '_' + str(use), queryTime = queryTime)

#==========================================================
def iterateUsageSameDevice(count, deviceId, serviceId, use, startTime, sessionId, testName, tag, extraAVP = {}, eventPass = True, saveInit = True, saveTerm = True, queryTime=None):
    i = 0
    tag1 = tag
    while ( i < count):
        if tag == None:  #if tag is None , the next time you call it you will overwrite the files
            tag1 = '_iter' + str(i) 
        else:
            tag1 = tag + '_' + str(i)

        sendSaveInitTerm(deviceId, serviceId, use, tag1, startTime, sessionId, testName, eventPass, extraAVP, saveInit, saveTerm, queryTime=queryTime)
        i = i + 1
        sessionId = sessionId + 1
    return sessionId

#==========================================================
# persist the dictionatry in the results dir
def pickleAnyDictionary(path, pickleFile, tdictionary):
    dctName = path + '/' + COMMON.resultsDir + '/' + str(pickleFile) 
    myPickleFile = open(dctName,'w')
    pickle.dump(tdictionary, myPickleFile)
    myPickleFile.close()

#==========================================================
def printPickledDictionary(path,dctFile):
    dctName = path + '/' +dctFile
    if not (os.path.isfile(dctName)):
        print('printPickledDictionary: file '+ dctName + ' missing!')
        return
    pkFile = open(dctName,'rb')
    unpickledDictionary= pickle.load(pkFile)
    pprint.pprint(unpickledDictionary)
    pkFile.close()

#==========================================================
def printDct(dct):
    for val in dct:
        print(val + '=>' +  dct[val]) 

#==========================================================
def pauseCheck(pauseFlag):
    # Be user friendly as to what we accept for pausing :-).
    if (pauseFlag.lower() == "yes") | (pauseFlag.lower() == "on") | (pauseFlag.lower() == "true"):
	print(' ')
	foo=eval(input('Press enter to continue: '))
	print(' ')

#==========================================================
def getTimeZone(tz):
        # parse config file and save system time zone
        confDir = os.path.abspath(os.path.expandvars(os.getenv('MTX_CONF_DIR', '.')))
        configFileName = confDir + '/mtx_config.xml'
        if (os.path.exists(configFileName)):
            saveTimeZone(configFileName, tz)
        else:
            print('Failure saving system time zone!')
	    if not tz: tz = 'Etc/UTC'
            os.putenv("TZ", tz)

#==========================================================
def saveMDC(queryValue, testName, mdcData='', queryType='ExternalId', debugData=''):
    global path
    global stripFields

    # create an ECT_ file for other than DCT validation
    if (queryValue == 0):
        logger.printRes(path, 'ECT_'+testName + '.dat', mdcData, overwrite = True)
        logger.printRes(path, "allMdcFilesList", os.getcwd()+'/' + COMMON.resultsDir + '/ECT_'+testName + '.dat' )
        return
    #testName = str(testName) + str(debugData)
    print('Saving MDC for subscriber with ' + queryType + ': ' + str(queryValue))

    outFileName = 'outQuery_' + str(queryValue).replace(':', '_') + '_' + str(testName)
    trsfOutFileName = 'trsf_' + outFileName

    logger.printRes(path, outFileName, mdcData, overwrite=True)

    print('mdcFile is------------------ ' + str(outFileName))
    # parse this MDC into a dictionary, rest param will return a win startTim=e

    return outFileName

#==========================================================
def saveTimeZone(configFileName, tz):
    systemTimeZonePattern = re.compile(r'.*<system_time_zone_id>.*')
    qaDir = os.getenv("QADIR")
    timeZoneFileName = qaDir + '/Common/timeZone'
    
    try:
        configFile = open(configFileName, 'r')
        while 1:
            line = configFile.readline()
            if not line:
                break
            if systemTimeZonePattern.match(line):
                removeTagPattern = re.compile(r'<.*?>')
                timeZone = removeTagPattern.sub('', line)
                stripSpacesPattern = re.compile(r'\s+')
                timeZone = stripSpacesPattern.sub('', timeZone)
                cmd = 'echo "' + timeZone + '" > ' + timeZoneFileName
                subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
                break

        configFile.close()

    except IOError:
	if not tz: tz = 'Etc/UTC'
        cmd = 'echo "' + tz + '" > ' + timeZoneFileName
        subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)

#===============================================================================
# this function will save the Gy diameter dictionary to ECT files
# for diff verification

def saveDiam(diamDct=None,testName=None,keepList=None):

    ectFile = 'ECT_'+ testName + '.dat'
    if keepList :  #save the avp in the list only
        for avp in keepList :
           if avp in diamDct:
               #save the diam value
               logger.printRes(path, ectFile, avp + ' : ' + diamDct[avp] , overwrite = False)
           else :
               logger.printRes(path, ectFile, avp + ' : missing' , overwrite = False)
    else :
        for diam in diamDct :
            logger.printRes(path, ectFile, diam + ' : ' + diamDct[diam] , overwrite = False)
    logger.printRes(path, "allMdcFilesList", os.getcwd()+'/' + COMMON.resultsDir + '/'+ectFile )

#===============================================================================
# this function will save the Sy/snr diameter dictionary to ECT files
# for diff verification

def savePCRF(diamDct=None,testName=None,pcrfType='SLR',stripList=None):

    pcrfFile = 'ECT_'+ testName + '.dat'
    for diam in diamDct :
        if stripList :
            for avp in stripList :
               if avp in diamDct:
               #strip the diam value
                  diamDct[avp] = ''
        logger.printRes(path, pcrfFile, diam + ' : ' + diamDct[diam] , overwrite = False)
    logger.printRes(path, "allMdcFilesList", os.getcwd()+'/' + COMMON.resultsDir + '/'+pcrfFile )

#==========================================================
# this function saves MDC or REST event query result in XML format
# and also remove the fields in the excludeList
def saveEventQueryResult(queryResult, outFileName):
    if QAV3.restVersion == 'MDC':
        queryResult = queryResult.printXml()
        gateway = '_MDC'
    else:
        gateway = '_REST'
        #strip dynamic values to pass verification    
        queryResult = re.sub("Time>(.*)<", "Time><", queryResult, )
        queryResult = re.sub("InitiatorExternalId>(.*)<", "InitiatorExternalId>0<", queryResult, )
        queryResult = re.sub("[0-9]+-[0-9]+-[0-9]+-[0-9]+", "0-0-0-0", queryResult, )
        queryResult = re.sub("[0:9]+:[0-9]+:[0-9]+:[0-9]+", "0:0:0:0", queryResult, )

    path = os.getcwd()
    tmpEventFileName = os.getcwd() + '/' + COMMON.resultsDir + '/eventQueryResult.txt'
    # save raw query result to temp file
    tmpEventFile = open(tmpEventFileName, 'w', 0)
    print(queryResult, file=tmpEventFile) 
    tmpEventFile.close()

    excludeList = ['EventTime', 'InitiatorId', 'InitiatorExternalId', 'InitiatorDeviceId',
        'InitiatorDeviceExternalId', 'InitiatorWalletId', 'WalletId', 'EventId']
    outputFileName = os.getcwd() + '/' + COMMON.resultsDir + '/' + outFileName + gateway
    # put the result for basic validation
    #testErrorLogger.printRes(path, outFileName, str(queryResult), overwrite=True)
    outputFile = open(outputFileName, 'w', 0)
    print(xml_utils.transformDoc(tmpEventFileName, excludeList), file=outputFile)
    logger.printRes(path, 'allMdcFilesList', path + '/' + COMMON.resultsDir + '/' + outFileName + gateway)

#==========================================================


def main():
    x = setSystemClock('2012-02-01T12:30:12')
    print('x = ' + x)
    setSystemClock(x)
    sys.exit(1)
    tname = getTestName(os.getcwd())
    print('tname = ' + tname)
    cleanConfigIniFile('.')
    config = configparser.ConfigParser()
    #sendOneRequest(deviceId=123,reqamount=60,usedamount=0,requestType='initial', sessionId=1, serviceId='voice', startTime=time.time())
    config.read('./sampleini.ini')
    getSubsc(config,'CDUser2')
    subscData = getSubsc(config,'User2')
    print('id=' + str(subscData['externalid']))
    print('offers=' +  str(subscData['offerid'][2]))
    

if __name__ == '__main__':
    main()

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

