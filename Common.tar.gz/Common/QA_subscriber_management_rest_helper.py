#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:17
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:35:59
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:34:46
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================



# from builtins import map
# from builtins import str
# from builtins import map
# from builtins import str
import os,sys
import timeToMDCtime as TIME
import pdb
import log_errors as LOGGER
logger = LOGGER.clErrors(os.getcwd())
import re
import json
import qa_utils as QAUTILS
import QA_subscriber_management_restv3 as REST_UTIL
eventPass = True

def saveResultsIntoMainDriver(externalId = None, deviceId = 0):
 # What to print depends on what was passed in
    if externalId:
            print('Sending create subscriber command for external ID ' + str(externalId) + ', deviceId = ' + str(deviceId))
            cmd = '/bin/echo creating subscriber: ' + str(externalId) + ' REST >> ../main_tests_driver/results/subscs.list'
    else:
            print('Sending create subscriber command with no external ID')
            cmd = '/bin/echo creating subscriber:  REST >> ../main_tests_driver/results/subscs.list'

    QAUTILS.runCmd(cmd)  #added this for main_test_driver
    QAUTILS.runCmd('/bin/echo ../../Common/query_subsc_group.py -s ' + str(deviceId)  + \
        ' -m localhost >> ../main_tests_driver/results/subsc_list.sh')  #added this for main_test_driver

#====================================================
def removeItem(template, tag):
    #print 'template=' + template + ' and item=' + tag
    if REST_UTIL.fileType == '.json':
        if template[:1] == '{':
            patternToRemove = '.*' + tag +'.*\n'
        else:
            patternToRemove = '.*=' + tag +'\n'
        p2 = re.sub(patternToRemove,'',template)
    else:
        p0 = re.sub('\n', 'UUU', template)
        pattern = '<' + tag + '>.*</' + tag +'>'
        patternNoBlankLines = '>\n+<'
        patternRemoveNoItem = '<(.+)><\/\\1>'
        p1 = re.sub(pattern, '', p0) #template)
        pTmp = re.sub('UUU', ' \n', p1)
        p2 = re.sub(patternNoBlankLines, '><', pTmp)

    return p2

#====================================================
def removeOneWordLine(profTemplate, pattern):
        if REST_UTIL.restVersion =='JSON' or REST_UTIL.restVersion == 'OPENAPI':
            return removeLine(profTemplate, pattern)
        else:
            return(re.sub(pattern,'',profTemplate))

#====================================================
def removeLine(profTemplate, pattern):
    # Slightly different regex from the existing if we have a json format
    if profTemplate[:1] == '{':
        patternToRemove = '.*' + pattern +'.*\n'
    else:
        patternToRemove = '.*=' + pattern +'\n'
    return(re.sub(patternToRemove,'',profTemplate))

#====================================================
def checkIfDefined(param, defaultParamVal, pattern, profTemplate, xmlTag):
    # Modify the json template to the openapi format
    if REST_UTIL.restVersion == 'OPENAPI':
        profTemplate = profTemplate.replace('\"$\":', '\"mtx_container_name\":')
        profTemplate = profTemplate.replace('\"OfferRequestArray\":', '\"offerRequestArray\":')
        profTemplate = profTemplate.replace('\"SubscriberSearchData\":', '\"subscriberSearchData\":')
        xmlTagLower = xmlTag[0].lower() + xmlTag[1:]
        profTemplate = profTemplate.replace('\"' + xmlTag + '\":', '\"' + xmlTagLower + '\":')
     # See if we need to udpate
    if not param == defaultParamVal:
        # If paramater is special string, then want to blank the field
        if str(param).lower() in ['empty', 'blank']: param = ''
        elif param == True: param='1'
        elif param == False:param='0'
        
        # Update field
        #print 'In checkIfDefined, will update ' + pattern
        profTemplate = re.sub(pattern, str(param), profTemplate)
    else:
        #print 'In checkIfDefined, will remove ' + pattern + ', xmlTag = ' + str(xmlTag)
        # Need to remove something...
        if xmlTag == None:  #special case to remove an entre line from template
            #print 'REMOVING Line'
            profTemplate = removeLine(profTemplate, pattern)
        elif xmlTag == 'ONEWORDLINE': 
            #print 'REMOVING One Word'
            profTemplate = removeOneWordLine(profTemplate, pattern)
        elif REST_UTIL.restVersion == 'JSON' or REST_UTIL.restVersion == 'OPENAPI':
            #print 'REMOVING Line'
            profTemplate = removeLine(profTemplate, pattern)
        else:
            #print 'REMOVING ITEM!!!!!!!!!!' + str(xmlTag)
            profTemplate = removeItem(profTemplate, xmlTag)

    return(profTemplate)

#====================================================
def addTask(purchaseStartTime, profTemplate):

    profTemplate = re.sub('.*version=.*','',profTemplate)
    taskStartTag = '<?xml version="1.0" ?>\n<MtxRequestTaskCreate>\n   <TaskTime>' + str(purchaseStartTime) + '</TaskTime>\n   <TaskRequest>'
    taskEndTag =   '   </TaskRequest>\n</MtxRequestTaskCreate>'
    profTemplate = taskStartTag + str(profTemplate) + taskEndTag

    return profTemplate

    
#====================================================
def populateSimpleValueArray(values, restVersion):
    valueArray = None
    if values :
        if restVersion == 'REST':
            valueArray=""
            for value in values:
                valueArray += "<value>"+str(value)+"</value>"
        elif restVersion == 'JSON' or restVersion == 'OPENAPI':
            valueArray = '[' + ', '.join(map(str, values)) +']'
    return valueArray
 


#===============================================================================
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

