#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:41:00
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:39
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:16
#===============================================================================
#
# Copyright 2013 Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

# NOTE:  Please do not import any additional QA test-specific files here.  This file is used
#        as part of the debug log analysis script and needs to run stand-alone
#        (i.e. only using Python libraries).  The files already imported have been setup to
#        work in this mode.


# from builtins import input
# from builtins import str
# from builtins import range
# from builtins import input
# from builtins import str
# from builtins import range
import sys, os, re
import optparse
import csv_track as TRACK
import subprocess
from subprocess import call
from datetime import datetime

# Define statr/end of message characters
msgStartString = 'Diameter Hdr'
msgLineSkipChar = '{'
msgEndChar = '}'

# Grouped AVP strings
groupStartEndString = 'grouped_avp'
vendorNameString = 'vendor_name'
diameterHeader = 'Diameter Hdr'
hierarchyString = '->'

# Subscription ID type values
subIdMSISDNType = '0'
subIdIMSIType = '1'

subExternalId = '1'

# Setup file globals so we can keep track of CCRs and handle them when the corresponding CCA comes in
ccrStats = {}
cerStats = {}
cerIndex = -1
slrStats = {}

# Flag signaliing whether filtering is desired
filterFlag = False

# Variable that holds the file that contained the current event
FileWhereEventCameFrom = 0
FileLineCount = {}

#===============================================================================
def initTrackingData(options):
    global filterFlag
    
    deviceId = []
    accessNumbers = []
    
    # Create tracking data for generic subscriber
    TRACK.updateTrackingData('createSubscriber', externalId = subExternalId)
    
    # If entered no device ID and only an acess number, then we have a problem...
    if not options.deviceId and options.accessNumbers:
        print('ERROR:  Tool can not filter only on access number.  Need to associate it with a device Id.')
        sys.exit('Error')

    # If no devices entered, then done
    if not options.deviceId: return
    
    # May enter multiple device IDs and access numbers
    deviceId = options.deviceId.split('@')
    
    # Also may not enter any IMSI, in which case set equal to the MSISDN
    if not options.accessNumbers: accessNumbers.extend(deviceId)
    else: accessNumbers = options.accessNumbers.split('@')
    
    # Make sure the lengths are equal
    if len(deviceId) != len(accessNumbers):
	print('ERROR:  Need to enter the same number of MSISDN and IMSI')
	sys.exit('ERROR')
    
    # Process each set of MSISDN/IMSI
    for index in range(len(deviceId)):
    	# Add subscribers data
	TRACK.updateTrackingData('addSubscriber', externalId = subExternalId, deviceId = deviceId[index], accessNumbers = accessNumbers[index])
    
    # Set filter flag, as input means we only want to see these items
    filterFlag = True
    
#===============================================================================
# This fnction used to run bash scripts.
def runCmd(cmd, output='delayed'):
    #print "running command: \"" + cmd + "\""
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    out = p.stdout.read().strip()
    return out  #This is the stdout from the shell command

#===============================================================================
# This function processes command line inputs
def cmdLineInput():
    ########### Do command line processing ###################
    parser = optparse.OptionParser()
    parser.add_option("-f", "--inputFile", action='store', type='string', default=None, help='list of debug log files to process (on local server)')
    parser.add_option("-d", "--dirName", action='store', type='string', default=None, help='Directory where debug log files reside (on local server)')
    parser.add_option("-e", "--engine", action='store', type='string', default='Primary', help='Engine designation in create_config.info (e.g. Primary, Secondary, Main')
    #parser.add_option("", "--date", action='store', type='string', default=None)
    #parser.add_option("", "--debug", action='store', type='string', default=None)
    parser.add_option("", "--dict", action='store', type='string', default='/opt/mtx/conf/diameter_dictionary.xml', help='full path to diameter dictionary (including file name)')
    parser.add_option("-i", "--ip", action='store', type='string', default=None, help='IP address of any blade in engine')
    parser.add_option("-a", "--accessNumbers", action='store', default=None, type='string', help="IMSI to filter output on")
    parser.add_option("", "--deviceId", action='store', default=None, type='string', help="MSISDN to filter output on")

    # Process command line params
    (options, args) = parser.parse_args()

    # If no input directory or filename specified, then default file on local server
    if not options.dirName and not options.inputFile and not options.ip:
        print('No input directory, inputfile, or IP address specified.  Use local server file /var/log/mtx/mtx_debug.log.')
	options.inputFile = '/var/log/mtx/mtx_debug.log'

    # Check for invalid combination of inputs
    if options.ip and (options.dirName or options.inputFile):
	# Don't support this option (specify a remote server and directory/file)
	print('ERROR:  specifying an IP address will use the default debug log file from the engine specified.  Can\'t specify IP and other file parameters.')
	sys.exit('Error')
    elif options.dirName and options.inputFile: 
	# Don't support this option (specify a directory and a file name)
	print('ERROR:  specifying a directory will use all files in that directory.  Can\'t specify a subset of files.')
	sys.exit('Error')

    # If a directory was entered, then get those files
    if options.dirName:
        # Directory entered.  Process all files in that directory.
        # Specifically do NOT include any lower level directories.
        for dirName, subDirList, fileList in os.walk(options.dirName):
                # Debug output
                print('Processing directory: ' + dirName + ', files: ' + str(fileList))

                # Add all the files
                options.inputFile.extend(fileList)

                # break from the loop, as we only care about the top level directory
                break
	
    # If no date specified, default to today
#    if not options.date:
#        date = datetime.now()
#        options.date = str(date.year) + '-' + str(date.month).zfill(2) + '-' + str(date.day).zfill(2) + 'T00:00:00'
#        print 'No date entered.  Using today\'s date (midnight): ' + options.date

    return options

#===============================================================================
def gatherAllConfigFiles(options):
    # Local to store file list
    fileToProcess = []

    # Debug output
    #print 'On input to gather, input file list: ' + str(options.inputFile)

    # May need to copy the dictionary file from a target machine.
    if options.ip:
        # If list does not contain localhost, then get from specified host
        if not re.search('localhost', options.ip):
                # Want to split string and grab first element
                targetHost = options.ip.split(',')[0]

                # Copy dictionary from the target to local directory
                runCmd("scp mtx@" + targetHost + ":" + options.dict + " . ")

                # Set file to point to local copy
                options.dict = options.dict.split('/')[-1]

                # Debug output
                print('Retrieved file ' + options.dict + ' from taget ' + targetHost)
		
    # if an IP address was specified, then it's an engine address.  Want to gather all addresses for the engine
    if options.ip:
	# Save this address, in case we need it at the bottom...
	savedIpAddress = options.ip
		
	# If running locally, then grab local.  Otherwise need to grab from the specified address
	if options.ip == 'localhost':
		configFile = '/opt/mtx/custom/create_config.info'
	else:
		# Debug output
		print('Retrieving IP address for engine that contains address ' + options.ip)
	
		# File will be local
		configFile = 'create_config.info'
		
		# Copy file from the target to local directory
		runCmd("scp mtx@" + options.ip + ":" + '/opt/mtx/custom/create_config.info' + " . ")
		
	# For grins, make sure the file has the engine value.
	engines = runCmd('grep PhysicalBlade ' + configFile + ' | cut -f2 -d" " | cut -f1 -d":" | uniq | tr "\n" ","')
	
	# Is the specified engine in the config file?
	if not engines.count(options.engine):
		# Debug output
		print('WARNING: engine value ' + options.engine + ' not in config file.  Supported values are: ' + engines)
		
		# Grab first one
		options.engine = runCmd('grep PhysicalBlade ' + configFile + ' | cut -f2 -d" " | cut -f1 -d":" | uniq | head')
		
		# Debug output
		print('Will use ' + options.engine + ' for the engine')
	
	# Run the command that gets the blade IP addresses from the config file (thanks to Nick Cole for this command)
	options.ip = runCmd("egrep -e '" + options.engine + ".*PhysicalBlade' " + configFile + " | sed 's/^.*?//' | tr '\n' ','")
		
	# Get rid of any trailing "," from the above "tr" command
	if options.ip[-1] == ',': options.ip = options.ip[:-1]
	
	# One other item to check for.  If targeting a VM, then most likely the IP address in create_config.info is local host or 127.0.0.1.
	# If so, change it back to the input address (as we don;t want to read ourselves when we wanted a different address)
	if options.ip == 'localhost' or options.ip == '127.0.0.1':
		# Debug output
		print('NOTE: Retrieved blade address says "myself" (' + options.ip + '), so use input IP address.')
			
		# Restore saved address
		options.ip = savedIpAddress
			
	# Debug output
	print('IP addresses for engine: ' + str(options.ip))
	
    # There may be more than one file to process
    if options.inputFile: fileToProcess = options.inputFile.split(',')

    # May want to read files from different servers
    ipAddr = []
    if options.ip:
        # Get all the addresses
        ipAddr = options.ip.split(',')

        for index in range(len(ipAddr)):
            if ipAddr[index] == 'localhost':  fileToProcess.append('mtx_debug.log.local')
            else:
                # Want to scp the file here
                runCmd("scp mtx@" + ipAddr[index] + ":/var/log/mtx/mtx_debug.log mtx_debug.log." + ipAddr[index])

                # Add this file to the file to process list
                fileToProcess.append('mtx_debug.log.' + ipAddr[index])

    # Store file list in options
    options.inputFile = fileToProcess

    # Debug output
#    print 'Will process the following files: ' + str(options.inputFile)

    return options
    
#===============================================================================
def getDebugLogFiles(options):
    # May want to read files from different servers
    ipAddr = []
    if options.ip:
        # Get all the addresses
        ipAddr = options.ip.split(',')

	# Loop through each IP address
        for index in range(len(ipAddr)):
	    # If local host, copy official ile to local directory; else scp official file from remote server
            if ipAddr[index] == 'localhost':  	runCmd('cp /var/log/mtx/mtx_debug.log ' + options.inputFile[index])
            else: 				runCmd("scp mtx@" + ipAddr[index] + ":/var/log/mtx/mtx_debug.log " + options.inputFile[index])

#===============================================================================
def processInputFiles(filenames, groupedAVPs):
    global FileWhereEventCameFrom
    global FileLineCount
    
    # Define structure to handle messages
    diamData = {}
    dctRcvd = {}
    eventTimes = []
    
    # Dummy variable
    x = 0
    index = 0
	
    # Translate all files to array of messages
    for file in filenames:
	# Define the index we need
	diamData[str(index)] = []
		
	# Get current line count of the file
	lineCount = runCmd('wc -l ' + file + ' | cut -f1 -d" "')
	
	# Debug output
	#print 'Current line count for file ' + file + ' = ' + str(lineCount)
	
	# If we have an entry for this file, then we may need to skip lines
	if str(index) in FileLineCount:
		# Delete lines from the file that were already processed
		runCmd('sed -i "1,' + FileLineCount[str(index)] + 'd" ' + file)
	
		# Debug output
		#print 'Removed previous ' + FileLineCount[str(index)] + ' from file ' + file
	
	# Update new line count
	FileLineCount[str(index)] = str(lineCount)
		
	# Debug output
	print('Processing file: ' + file)
		
	# Convert the data
    	(diamData[str(index)], msgCount) = processDebugLogFile(file)
    
        # It's possible that nothing was returned.  In that case don't add anything to the list.
        if msgCount == 0: continue

	# Get the index we'll use
	fileIndex = 'file'+str(index)
		
	# Get the dictionary for this entry
	dctRcvd[fileIndex] = getRawDiameterDct(diamData[str(index)][0], groupedAVPs)
	
	# Bump the index
	index += 1
		
    # Output headers
    outputDataHdr();
    
    # Loop while there are events to process
    while True:
	# Set start time to way in the future (so any event will be below it)
	startTime = '3000-00-01T00:00:00.000000Z'
	
	# Set index to an invalid value (so we can check if nothing found)
	foundIndex = -1
	
	# Get the earliest event from each file
	for idx in range(index):
		# Get the index we'll use
		fileIndex = 'file'+str(idx)
		
		# If this file is empty, then skip
		if fileIndex not in dctRcvd: continue
		
		# Pull time stamp from message if it exists
		if 'Event-Timestamp' in dctRcvd[fileIndex]: 
			# Sometimes this field is output with a "not valid" string...
			if "not valid" in dctRcvd[fileIndex]['Event-Timestamp']: eventTime = dctRcvd[fileIndex]['System-Time']
			else:							 eventTime = dctRcvd[fileIndex]['Event-Timestamp'].split('(')[1].split(')')[0]
		elif 'System-Time' in dctRcvd[fileIndex]:     		 eventTime = dctRcvd[fileIndex]['System-Time']
		else: 						    		 eventTime = '2000-00-01T00:00:00.000000Z'
		
		# Debug output
		#print 'File ' + str(idx) + ' has event time: ' + eventTime
		
		# See if the event is less than the current start time
		if eventTime < startTime:
			# Record data for the earlier event
			foundIndex = idx
			startTime = eventTime
		
	# If the index is -1, then we're done processing events
	if foundIndex == -1: break
	
	# Set global
	FileWhereEventCameFrom = foundIndex
	
	# Debug output
	#print 'Taking event from file ' + str(foundIndex)
	
	# Use the index that has the eariest event time.
	# Get file index, using index found
	fileIndex = 'file'+str(foundIndex)
	
	# Sanity check the message
	if 'Cmd' in dctRcvd[fileIndex]: 
		# Debug output
		#print 'Diameter command: ' + dctRcvd[fileIndex]['Cmd']
		x = 1
	else: 
		# Debug output
		print("WARNING:  no Cmd element found in the diameter packet:\n" + str(dctRcvd[fileIndex]))
			
		# Nothing else to do with this...
		continue
		
	# Process each diameter message separately
	if   dctRcvd[fileIndex]['Cmd'] == 'Credit-Control(272)':	processCCRandCCA(dctRcvd[fileIndex])
	elif dctRcvd[fileIndex]['Cmd'] == 'Device-Watchdog(280)': 	processDWRandDWA(dctRcvd[fileIndex])
	elif dctRcvd[fileIndex]['Cmd'] == 'MtxSocketDiamMsg(430)': 	processSock(dctRcvd[fileIndex])
	elif dctRcvd[fileIndex]['Cmd'] == 'Disconnect-Peer(282)': 	processDPRandDPA(dctRcvd[fileIndex])
	elif dctRcvd[fileIndex]['Cmd'] == 'Capabilities-Exchange(257)': processCERandCEA(dctRcvd[fileIndex])
	elif dctRcvd[fileIndex]['Cmd'].startswith('Re-Auth'): 		processRARandRAA(dctRcvd[fileIndex])
	elif dctRcvd[fileIndex]['Cmd'].startswith('Spending-Limit'): 	processSLRandSLA(dctRcvd[fileIndex])
	elif dctRcvd[fileIndex]['Cmd'].startswith('Session-Terminate'): processSTRandSTA(dctRcvd[fileIndex])
	elif dctRcvd[fileIndex]['Cmd'].startswith('Spending-Status-Notification'): processSNRandSNA(dctRcvd[fileIndex])
	else: print('WARNING:  no Cmd processing function found for command ' + dctRcvd[fileIndex]['Cmd'] + ', message: ' + str(dctRcvd[fileIndex]))
	
	# Remove the entry from the overall diameter data
	if len(diamData[str(foundIndex)]) > 1:
		# Remove initial entry
		diamData[str(foundIndex)] = diamData[str(foundIndex)][1:]
		
		# Get the next dictionary for this entry
		dctRcvd[fileIndex] = getRawDiameterDct(diamData[str(foundIndex)][0], groupedAVPs)
	else:
		# Empty data item
		diamData[str(foundIndex)] = []
		
		# delete dictionary entry
		del dctRcvd[fileIndex]
	
    # Debug output
    print('\nDone Processing files\n')
    
#===============================================================================
def outputData(cmd='None', sessionId='None', deviceId='None', accessNumbers='None', originHost='None', originRealm='None', \
	       time='None', diamResult='None', msccResult='None', reqType='None', reqNum='None', misc='None'):
	global FileWhereEventCameFrom
	
	# Use same format as for the headers
	sys.stdout.write("%-10s %-15s %-15s %-6s %-6s %-7s %-4s %-50s %-s\n" % \
		(cmd+'('+str(FileWhereEventCameFrom)+')', deviceId, accessNumbers, diamResult, msccResult, reqType, reqNum, sessionId, misc))

#===============================================================================
def outputDataHdr():
	# Setup fixed width fields
	sys.stdout.write("\n%-10s %-15s %-15s %-6s %-6s %-7s %-4s %-50s %-s" % ('', '', '', 'Diam', 'MSCC', 'Req', 'Req', '', ''))
	sys.stdout.write("\n%-10s %-15s %-15s %-6s %-6s %-7s %-4s %-50s %-s\n" % ('Command', 'MSISDN', 'IMSI','Result', 'Result', 'Type', 'Num', 'Session ID', 'Misc'))
	line = '-'*160
	print(line)
    
#===============================================================================
def processCCRandCCA(dctRcvd):
    global filterFlag
    global ccrStats
    
    # Locals
    deviceId = None
    accessNumbers = None
    externalId = subExternalId
    
    # Do Request-specific work first
    if dctRcvd['CmdReq'] == '1':
	# Debug output
	#print 'Process CCR'
	
    	# Debug output
	#print 'Received Diameter dictionary: '
    	#print str(dctRcvd)
    
	# Get the IMSI and MSISDN.  May have one or two Subscrption ID structures
	if 'Subscription-Id0->Subscription-Id-Type' in dctRcvd:
		# Type says what kind of item it is
		if dctRcvd['Subscription-Id0->Subscription-Id-Type'] == subIdMSISDNType:
			deviceId = dctRcvd['Subscription-Id0->Subscription-Id-Data']
		else:   accessNumbers = dctRcvd['Subscription-Id0->Subscription-Id-Data']
		
		#print 'deviceId and aN post Sub0 data: ' + str(deviceId) + ', ' + str(accessNumbers)
	else:
		# Need at least one of these
		print('ERROR:  CCR Dictionary does not have any Subscription-Id grouped AVPs')
		print(str(dctRcvd))
		sys.exit('Exit due to error')
	
	# Second one is optional
	if 'Subscription-Id1->Subscription-Id-Type' in dctRcvd:
		# Type says what kind of item it is
		if dctRcvd['Subscription-Id1->Subscription-Id-Type'] == subIdMSISDNType:
			deviceId = dctRcvd['Subscription-Id1->Subscription-Id-Data']
		else:   accessNumbers = dctRcvd['Subscription-Id1->Subscription-Id-Data']

	# Debug output
	#print 'deviceId and aN post Sub1 data: ' + str(deviceId) + ', ' + str(accessNumbers)

	# Want to make sure the data is tracked in subscriber/device/accessNumber structures.  Create them if needed (since we may only get debug log files).
	# If only IMSI entered, then need to find device ID
	if accessNumbers and not deviceId:
		# Got IMSI only.  Need to see if we have this.  Work backwards from the IMSI to the device
		if accessNumbers in TRACK.accessNumberTracking: deviceId = accessNumberTracking[accessNumbers]['deviceId']
			
	# At this point, if no device found yet, then make one up
	if not deviceId: deviceId = subExternalId
	
	# If no device ID currently stored and filtering, then return
	if deviceId not in TRACK.deviceTracking and filterFlag: return
	
	# Check if the device ID has not already been added to the subscriber
	if not TRACK.subscriberTracking[externalId]['deviceId'].count(deviceId):
                # Add device to subscriber
       	        TRACK.updateTrackingData('addDeviceToSubscriber', externalId = externalId, deviceId = deviceId, accessNumbers = accessNumbers)
			
	# Get key pieces of data
	sessionId = dctRcvd['Session-Id']
	requestType = dctRcvd['CC-Request-Type']
	requestNumber = dctRcvd['CC-Request-Number']
	eventTime = dctRcvd['Event-Timestamp'].split('(')[1].split(')')[0]
	if 'Mscc0->Rating-Group' in dctRcvd: ratingGroup = dctRcvd['Mscc0->Rating-Group']
	else: ratingGroup = '0'
			
	if 'Mscc0->Requested-Service-UnitCC-Total-Octets' in dctRcvd: requestUnits = dctRcvd['Mscc0->Requested-Service-Unit->CC-Total-Octets']
	else: requestUnits = '0'
		
	if 'Mscc0->Used-Service-Unit->CC-Total-Octets' in dctRcvd: usedUnits = dctRcvd['Mscc0->Used-Service-Unit->CC-Total-Octets']
	else: usedUnits = '0'
	
	# May get multiple CCRs for different rating groups before we get a CCA, so address that
	overallSessionId = sessionId + '_' + ratingGroup
	
	# Sanity check that we don't have this session ID already saved...
	if overallSessionId in ccrStats:
		print('ERROR:  CCR received.  slrStats has an existing key = ' + overallSessionId)
		sys.exit('Error')
	
	# Save this data in the structure for processing when we get the CCA
	ccrStats[overallSessionId] = {}
	ccrStats[overallSessionId]['requestNumber'] = requestNumber
	ccrStats[overallSessionId]['eventTime'] = eventTime
	ccrStats[overallSessionId]['ratingGroup'] = ratingGroup
	ccrStats[overallSessionId]['sessionId'] = sessionId
	ccrStats[overallSessionId]['requestUnits'] = requestUnits
	ccrStats[overallSessionId]['deviceId'] = deviceId
	ccrStats[overallSessionId]['accessNumbers'] = accessNumbers
	ccrStats[overallSessionId]['externalId'] = externalId
	ccrStats[overallSessionId]['requestUnits'] = requestUnits
	ccrStats[overallSessionId]['usedUnits'] = usedUnits
	ccrStats[overallSessionId]['Origin-Host'] = dctRcvd['Origin-Host']
	ccrStats[overallSessionId]['Origin-Realm'] = dctRcvd['Origin-Realm']
	
	# Request type needs to be stored as string, not a number
	if requestType == '1':   ccrStats[overallSessionId]['requestType'] = 'initial'
	elif requestType == '2': ccrStats[overallSessionId]['requestType'] = 'interim'
	else:   		 ccrStats[overallSessionId]['requestType'] = 'term'
    else:
	# Debug output
	#print 'Process CCA'
	
    	# Debug output
	#print 'Received Diameter dictionary: '
    	#print str(dctRcvd)
    
	# Get key pieces of data
	sessionId = dctRcvd['Session-Id']
	diamResult = dctRcvd['Result-Code']
	if 'Mscc0->Rating-Group' in dctRcvd: ratingGroup = dctRcvd['Mscc0->Rating-Group']
	else: ratingGroup = '0'
		
	if 'Mscc0->Granted-Service-Unit->CC-Total-Octets' in dctRcvd: grantedUnits = dctRcvd['Mscc0->Granted-Service-Unit->CC-Total-Octets']
	else: grantedUnits = '0'
			
	if 'Mscc0->Result-Code' in dctRcvd: msccResult = dctRcvd['Mscc0->Result-Code']
	else: msccResult = '0'
		
	# May get multiple CCRs for different rating groups before we get a CCA, so address that
	overallSessionId = sessionId + '_' + ratingGroup
	
	# Make sure the session exists in the stats data
	if overallSessionId not in ccrStats: 
		# If filtering enabled, then this shoudlbe fine
		if filterFlag: return
		else:
			# Hmmmm.....
			print('ERROR:  CCA received with session ID ' + str(overallSessionId) + ' and it\'s not in ccrStats')
			sys.exit('Exit due to error')
		
	# Output summary
	outputData(cmd='CCR/CCA', sessionId=overallSessionId, deviceId=ccrStats[overallSessionId]['deviceId'], \
		accessNumbers=ccrStats[overallSessionId]['accessNumbers'], msccResult=msccResult, \
		time=ccrStats[overallSessionId]['eventTime'], diamResult=diamResult, \
		reqType=ccrStats[overallSessionId]['requestType'], reqNum=ccrStats[overallSessionId]['requestNumber'], \
		misc='Used/Requested/Granted Units = ' + ccrStats[overallSessionId]['usedUnits'] + '/' + ccrStats[overallSessionId]['requestUnits'] + '/' + grantedUnits)

	# Update tracking data
	TRACK.updateSessionTrackingData(\
		ccrStats[overallSessionId]['deviceId'], ccrStats[overallSessionId]['accessNumbers'], ccrStats[overallSessionId]['requestType'], \
		ccrStats[overallSessionId]['sessionId'], ccrStats[overallSessionId]['ratingGroup'], ccrStats[overallSessionId]['eventTime'], \
		ccrStats[overallSessionId]['requestUnits'], ccrStats[overallSessionId]['usedUnits'], grantedUnits, interface='gy')
		
	# Remove this session from the stats data
	del ccrStats[overallSessionId]
	
	#sys.exit('Early Exit from CCA')
	
#===============================================================================
def processSLRandSLA(dctRcvd):
    global slrStats
    global filterFlag
    
    # Locals
    deviceId = None
    accessNumbers = None
    externalId = subExternalId
    
    # Get common fields
    systemTime = dctRcvd['System-Time']
    
    # Do Request-specific work first
    if dctRcvd['CmdReq'] == '1':
	# Debug output
	#print 'Process SLR'
	
    	# Debug output
	#print 'Received Diameter dictionary: '
    	#print str(dctRcvd)
    
	# Get the IMSI and MSISDN.  May have one or two Subscrption ID structures
	if 'Subscription-Id0->Subscription-Id-Type' in dctRcvd:
		# Type says what kind of item it is
		if dctRcvd['Subscription-Id0->Subscription-Id-Type'] == subIdMSISDNType:
			deviceId = dctRcvd['Subscription-Id0->Subscription-Id-Data']
		else:   accessNumbers = dctRcvd['Subscription-Id0->Subscription-Id-Data']
		
		#print 'deviceId and aN post Sub0 data: ' + str(deviceId) + ', ' + str(accessNumbers)
	else:
		# Need at least one of these
		print('ERROR:  CCR Dictionary does not have any Subscription-Id grouped AVPs')
		print(str(dctRcvd))
		sys.exit('Exit due to error')
	
	# Second one is optional
	if 'Subscription-Id1->Subscription-Id-Type' in dctRcvd:
		# Type says what kind of item it is
		if dctRcvd['Subscription-Id1->Subscription-Id-Type'] == subIdMSISDNType:
			deviceId = dctRcvd['Subscription-Id1->Subscription-Id-Data']
		else:   accessNumbers = dctRcvd['Subscription-Id1->Subscription-Id-Data']

	#print 'deviceId and aN post Sub1 data: ' + str(deviceId) + ', ' + str(accessNumbers)

	# Want to make sure the data is tracked in subscriber/device/accessNumber structures.  Create them if needed (since we may only get debug log files).
	# If only IMSI entered, then need to find device ID
	if accessNumbers and not deviceId:
		# Got IMSI only.  Need to see if we have this.  Work backwards from the IMSI to the device
		if accessNumbers in TRACK.accessNumberTracking: deviceId = accessNumberTracking[accessNumbers]['deviceId']
			
	# At this point, if no device found yet, then make one up
	if not deviceId: deviceId = subExternalId
	
	# If no device ID currently stored and filtering, then return
	if deviceId not in TRACK.deviceTracking and filterFlag: return
	
	# Check if the device ID has not already been added to the subscriber
	if not TRACK.subscriberTracking[externalId]['deviceId'].count(deviceId):
                # Add device to subscriber
       	        TRACK.updateTrackingData('addDeviceToSubscriber', externalId = externalId, deviceId = deviceId, accessNumbers = accessNumbers)
			
	# Get key pieces of data
	sessionId = dctRcvd['Session-Id']
	
	# For SLR, the session ID is not a combination of other data
	overallSessionId = sessionId
	
	# Sanity check that we don't have this session ID already saved...
	if overallSessionId in slrStats:
		print('ERROR:  SLR received.  slrStats has an existing key = ' + overallSessionId)
		sys.exit('Error')
	
	# Save this data in the structure for processing when we get the CCA
	slrStats[overallSessionId] = {}
	slrStats[overallSessionId]['Origin-Host'] = dctRcvd['Origin-Host']
	slrStats[overallSessionId]['Origin-Realm'] = dctRcvd['Origin-Realm']
	slrStats[overallSessionId]['deviceId'] = deviceId
	slrStats[overallSessionId]['accessNumbers'] = accessNumbers
	slrStats[overallSessionId]['sessionId'] = sessionId
	if 'SL-Request-Type' in dctRcvd: slrStats[overallSessionId]['SL-Request-Type'] = dctRcvd['SL-Request-Type']
	else: slrStats[overallSessionId]['SL-Request-Type'] = '1'
	
	# Add in all the Policy Counter IDs entered
	slrStats[overallSessionId]['Pcid'] = []
	idx = 0
	while True:
		# See if the policy value was input
		pcidString = 'Pcid' + str(idx)
		if pcidString in dctRcvd: 
			# Store in the array
			slrStats[overallSessionId]['Pcid'].append(dctRcvd[pcidString])
			idx += 1
		else:
			# No more of these
			break
    else:
	# Debug output
	#print 'Process SLA'
	
    	# Debug output
	#print 'Received Diameter dictionary: '
    	#print str(dctRcvd)
    
	# Get key pieces of data
	sessionId = dctRcvd['Session-Id']
	diamResult = dctRcvd['Result-Code']

	# Use same variable name (easy cut/paste)
	overallSessionId = sessionId
	
	# Make sure the session exists in the stats data
	if overallSessionId not in slrStats: 
		# If filtering enabled, then this shoudl be fine
		if filterFlag: return
		else:
			# Hmmmm.....
			print('ERROR:  SLA received with session ID ' + str(overallSessionId) + ' and it\'s not in slrStats')
			sys.exit('Exit due to error')
		
	# Grap the policy data from the SLA
	policyData = []
	idx = 0
	while True:
		# See if the policy value was input
		pcidString = 'Pcsr' + str(idx)
		if pcidString + '->Policy-Counter-Status' in dctRcvd: 
			# Store in the array
			policyData.append([dctRcvd[pcidString + '->Policy-Counter-Status'], dctRcvd[pcidString + '->Policy-Counter-Identifier']])
			idx += 1
		else:
			# No more of these
			break
	
	# Convert request type to string
	requestString = 'initial'
	if slrStats[overallSessionId]['SL-Request-Type'] == '1': requestString = 'interim'
	
	# Output summary
	outputData(cmd='SLR/SLA', sessionId=overallSessionId, deviceId=slrStats[overallSessionId]['deviceId'], \
		accessNumbers=slrStats[overallSessionId]['accessNumbers'], reqType=requestString, \
		time=systemTime, diamResult=diamResult, misc='Policy: ' + str(policyData))

	# Update tracking data.  Send policy data in requested units variable.
	TRACK.updateSessionTrackingData(\
		slrStats[overallSessionId]['deviceId'], slrStats[overallSessionId]['accessNumbers'], requestString, \
		sessionId, '0', systemTime, \
		policyData, '0', '0', interface='sy')
		
	# Remove this session from the stats data
	del slrStats[overallSessionId]
	
#===============================================================================
def processSTRandSTA(dctRcvd):
    global slrStats
    global filterFlag
    
    # Get key pieces of data
    sessionId = dctRcvd['Session-Id']
    systemTime = dctRcvd['System-Time']

    # For SLR, the session ID is not a combination of other data
    overallSessionId = sessionId
	
    # If this is not already a session, then no need to do anything here.
    if overallSessionId+'_0' not in TRACK.sessionTracking: 
	# Debug output
	#print 'Not tracking Sy session, so message ignored'
	
	return
	
    # Do Request-specific work first
    if dctRcvd['CmdReq'] == '1':
	# Debug output
	#print 'Process STR'
	
    	# Debug output
	#print 'Received Diameter dictionary: '
    	#print str(dctRcvd)
    
	# Sanity check that we don't have this session ID already saved...
	if overallSessionId in slrStats:
		print('ERROR:  STR received.  slrStats has an existing key = ' + overallSessionId)
		sys.exit('Error')
	
	# Save this data in the structure for processing when we get the CCA
	slrStats[overallSessionId] = {}
	slrStats[overallSessionId]['Origin-Host'] = dctRcvd['Origin-Host']
	slrStats[overallSessionId]['Origin-Realm'] = dctRcvd['Origin-Realm']
	slrStats[overallSessionId]['sessionId'] = sessionId
    else:
	# Make sure the session exists in the stats data
	if overallSessionId not in slrStats: 
		# If filtering enabled, then this shoudl be fine
		if filterFlag: return
		else:
			# Hmmmm.....
			print('ERROR:  STA received with session ID ' + str(overallSessionId) + ' and it\'s not in slrStats')
			sys.exit('Exit due to error')
	
	# Get key values
	diamResult = dctRcvd['Result-Code']
	
	# Output summary
	outputData(cmd='STR/STA', sessionId=overallSessionId, reqType='term', \
		time=systemTime, diamResult=diamResult)

	# Update tracking data.  This is a term event.
	TRACK.updateSessionTrackingData(\
		TRACK.sessionTracking[overallSessionId+'_0']['deviceId'], '0', 'term', \
		sessionId, '0', systemTime, \
		'0', '0', '0', interface='sy')
		
	# Remove this session from the stats data
	del slrStats[overallSessionId]
	
#===============================================================================
def processRARandRAA(dctRcvd):
    # Get key pieces of data
    sessionId = dctRcvd['Session-Id']
    systemTime = dctRcvd['System-Time']

    # Use same variable name (easy cut/paste)
    overallSessionId = sessionId
    
    # Do Request-specific work first
    if dctRcvd['CmdReq'] == '1':
	# Debug output
	#print 'Process RAR'
	
    	# Debug output
	#print 'Received Diameter dictionary: '
    	#print str(dctRcvd)
	
	# Convert request type to string
	requestString = 'interim'
	
        # Get key items
	if 'Rating-Group' in dctRcvd: ratingGroup = dctRcvd['Rating-Group']
    	else: ratingGroup = '0'
    
    	# Get value that the session tracking uses	
    	subSession = overallSessionId+'_' + ratingGroup
    
    	# If no session ID currently stored and filtering, then return
    	if TRACK.subSession not in sessionTracking:
		# If filtering enabled, then this is fine
		if filterFlag: return
		else:
			# Hmmmm.....
			print('ERROR:  RAR received with session ID ' + str(overallSessionId) + ' and it\'s not in the session database')
			sys.exit('Exit due to error')
		
	# Output summary
	outputData(cmd='RAR', sessionId=subSession, reqType=requestString, time=systemTime, misc='Rating Group: ' + ratingGroup)
    else:
	# Debug output
	#print 'Process RAA'
	
    	# Debug output
	#print 'Received Diameter dictionary: '
    	#print str(dctRcvd)
	
	# Get specific data
	diamResult = dctRcvd['Result-Code']
	
	# Convert request type to string
	requestString = 'interim'
	
	# Output summary
	outputData(cmd='RAA', sessionId=overallSessionId, reqType=requestString, time=systemTime, diamResult=diamResult)

#===============================================================================
def processDWRandDWA(dctRcvd):
    # Get common fields
    systemTime = dctRcvd['System-Time']
    
    # Get key fields
    originHost = dctRcvd['Origin-Host']
    originRealm = dctRcvd['Origin-Realm']
	
    # Setup Misc data
    miscString = 'Origin-Host/Realm = ' + originHost + '/' + originRealm
	
    # Do Request-specific work first
    if dctRcvd['CmdReq'] == '1':
	# Debug output
#	print 'Process DWR'
	
	# Output summary
	outputData(cmd='DWR', time=systemTime, misc=miscString)

    else:
	# Debug output
#	print 'Process DWA'
	
	# Output summary
	outputData(cmd='DWA', time=systemTime, misc=miscString)

#===============================================================================
def processSNRandSNA(dctRcvd):
    # Get key pieces of data
    sessionId = dctRcvd['Session-Id']
    systemTime = dctRcvd['System-Time']

    # Use same variable name (easy cut/paste)
    overallSessionId = sessionId
    
    # Get value that the session tracking uses	
    subSession = overallSessionId+'_0'
    
    # If no session ID currently stored and filtering, then return
    if TRACK.subSession not in sessionTracking:
	# If filtering enabled, then this is fine
	if filterFlag: return
	else:
		# Hmmmm.....
		print('ERROR:  SNR received with session ID ' + str(overallSessionId) + ' and it\'s not in the session database')
		sys.exit('Exit due to error')
		
    # Do Request-specific work first
    if dctRcvd['CmdReq'] == '1':
	# Debug output
	#print 'Process SNR'
	
    	# Debug output
	#print 'Received Diameter dictionary: '
    	#print str(dctRcvd)
    
	# Grap the policy data
	policyData = []
	idx = 0
	while True:
		# See if the policy value was input
		pcidString = 'Pcsr' + str(idx)
		if pcidString + '->Policy-Counter-Status' in dctRcvd: 
			# Store in the array
			policyData.append([dctRcvd[pcidString + '->Policy-Counter-Status'], dctRcvd[pcidString + '->Policy-Counter-Identifier']])
			idx += 1
		else:
			# No more of these
			break
	
	# Convert request type to string
	requestString = 'interim'
	
	# Output summary
	outputData(cmd='SNR', sessionId=overallSessionId, reqType=requestString, time=systemTime, misc='Policy: ' + str(policyData))

	# Update tracking data.  Send policy data in requested units variable.
	TRACK.updateSessionTrackingData(\
		TRACK.sessionTracking[subSession]['deviceId'], TRACK.sessionTracking[subSession]['accessNumber'], requestString, \
		sessionId, '0', systemTime, \
		policyData, '0', '0', interface='sy')
		
    else:
	# Debug output
	#print 'Process SNA'
	
    	# Debug output
	#print 'Received Diameter dictionary: '
    	#print str(dctRcvd)
    
	# Get key values
	diamResult = dctRcvd['Result-Code']
	
	# Output summary
	outputData(cmd='SNA', sessionId=overallSessionId, reqType='interim', \
		time=systemTime, diamResult=diamResult)

#===============================================================================
def processDPRandDPA(dctRcvd):
    # Get common fields
    systemTime = dctRcvd['System-Time']
    originHost = dctRcvd['Origin-Host']
    originRealm = dctRcvd['Origin-Realm']
    
    # Setup Misc data
    miscString = 'Origin-Host/Realm = ' + originHost + '/' + originRealm
    
    # Do Request-specific work first
    if dctRcvd['CmdReq'] == '1':
	# Debug output
	#print 'Process DPR'
	
	# Get additional data
	if 'Disconnect-Cause' in dctRcvd: reason = dctRcvd['Disconnect-Cause']
	else: reason = 'None'
	
	# Add to misc string
	miscString += ', Disconenct reason = ' + reason
	
	# Output summary
	outputData(cmd='DPR', time=systemTime, misc=miscString)

    else:
	# Debug output
	#print 'Process DPA'

	# Get key fields
	diamResult = dctRcvd['Result-Code']
	
	# Output summary
	outputData(cmd='DPA', time=systemTime, diamResult=diamResult, misc=miscString)

#===============================================================================
def processSock(dctRcvd):
    # Get common fields
    systemTime = dctRcvd['System-Time']
    
    # Do Request-specific work first
    if dctRcvd['CmdReq'] == '1':
	# Debug output
	#print 'Process Socket Request'
	
	# Output summary
	outputData(cmd='SockR', time=systemTime)

    else:
	# Debug output
	#print 'Process Socket Answer'
	
	# Output summary
	outputData(cmd='SockA', time=systemTime)

#===============================================================================
def processCERandCEA(dctRcvd):
    global cerStats
    global cerIndex
    
    # Get common fields
    systemTime = dctRcvd['System-Time']
    
    # Do Request-specific work first
    if dctRcvd['CmdReq'] == '1':
	# Debug output
	#print 'Process CCR'
	
    	# Debug output
	#print 'Received Diameter dictionary: '
    	#print str(dctRcvd)
    
	# Setup next CER index
	cerIndex += 1
	cerStats[cerIndex] = {}
	
	# Get key fields
	cerStats[cerIndex]['Origin-Host'] = dctRcvd['Origin-Host']
	cerStats[cerIndex]['Origin-Realm'] = dctRcvd['Origin-Realm']
	cerStats[cerIndex]['Origin-State-Id'] = dctRcvd['Origin-State-Id']
	
    else:
	#print 'Process CEA'
	
	# Get key fields
	diamResult = dctRcvd['Result-Code']
	
	# Output summary
	miscString = 'Origin-Host/Realm = ' + cerStats[cerIndex]['Origin-Host'] + '/' + cerStats[cerIndex]['Origin-Realm']
	outputData(cmd='CER/CEA', reqType='exchg', \
		time=systemTime, diamResult=diamResult, misc=miscString)

	# Output summary
#	print 'CER/A exchange: Origin-Host/Realm = ' + cerStats[cerIndex]['Origin-Host'] + '/' + cerStats[cerIndex]['Origin-Realm'] + \
#		' Origin-State-Id = ' + cerStats[cerIndex]['Origin-State-Id'] + ', Result code = ' + diamResult
	
	# Cleanup
	del cerStats[cerIndex]
	cerIndex -= 1
	
#===============================================================================
def getRawDiameterDct(diamObj, groupedAVPs):
    # Init local multiple entry counters
    msccCounter = -1
    pcrsCounter = -1
    pcidCounter = -1
    subIdCounter = -1
    
    # Local array of group hierarchy
    grouped = []
    
    # Returned structure
    diameterDct = {}
    
    # Separate input string into an array
    diamArr = diamObj.split('\n')

    # Debug output
    #print 'Received diameter array: ' + str(diamArr)

    # Process all array entries
    for line in diamArr:
        # Skip until we get to the header line
        if not re.search(diameterHeader, line): continue

        # Break this line into fields
        hdrLine = line.split(',')

        # Process each field
        for fields in hdrLine:
                # If the field contains the Diameter header, then need to skinny it down
                if re.search(diameterHeader, fields): fields = fields.split(':')[1].strip()

                # Get the command and value (separated by an '=' character)
                command = fields.split('=')[0].strip()
                value = fields.split('=')[1].strip()

                # Add to the dictionary to be returned
                diameterDct[command] = value

        # Done processing the header line
        break

    # Process all array entries
    for line in diamArr:
	# Skip diameter header line
        if re.search(diameterHeader, line): continue  

	# Manipulate the line
        line = line.strip('\n')
        line = line.strip(',')
        line = re.sub('.*AVP: ', '', line)
	
	# Get the fields
        tmp = line.split(',')
	
	# Remove AVP codes from the AVP name
        tmp[0] = re.sub('\(\d+\)','', tmp[0]) 

	# See if this matches the input grouped AVPs
        if tmp[0] in groupedAVPs:
	    #print 'Found group: ' + tmp[0]
		
	    # Three scenatios here: (1) this is the first group,  (2) group is a child of the current group, or (3) it's not a child
	    if not len(grouped):
		# Add to the empty list
		grouped.append(tmp[0])
	    # Check for scenario 2
	    elif groupedAVPs[grouped[-1]]['avps'].count(tmp[0]):
		# Add this group to the local group depth
		grouped.append(tmp[0])
	    else:
		# Scenario 3.  Need to replace the last group hierarchy item with the new group
		grouped[-1] = tmp[0]
	    	
            # Remap and count groups that could be duplicates
            if   tmp[0] == 'Multiple-Services-Credit-Control': 	msccCounter += 1
            elif tmp[0] == 'Policy-Counter-Status-Report': 	pcrsCounter += 1
            elif tmp[0] == 'Policy-Counter-Identifier': 	pcidCounter += 1
            elif tmp[0] == 'Subscription-Id': 			subIdCounter += 1
	    
	    # Nothing more to do with this entry
            continue
	
	# OK, not a grouped AVP.  Now see if we're into groups
	while len(grouped):
		# Debug output
		#print 'Checking ' + str(groupedAVPs[grouped[-1]]['avps']) + ' for key ' + tmp[0]
		
		# If this AVP not part of the last group, then remove that group from the hierarchy
		if not groupedAVPs[grouped[-1]]['avps'].count(tmp[0]): 
			# Debug output
			#print 'Did not find ' + tmp[0] + ' in the group ' + grouped[-1]
			
			# Remove from hierarchy
			grouped = grouped[:-1]
		else: 
			# Found it
			
			# Debug output
			#print 'FOUND ' + tmp[0] + ' in the group ' + grouped[-1]
			
			# Stop hierarchy check
			break	

	# This will be the string we add to the dictionary
        avpString = ''
	
	# Build the dictionary name
	for index in range(len(grouped)):
            # Rename groups that could be duplicates
            if   grouped[index] == 'Multiple-Services-Credit-Control': avpString += 'Mscc' + str(msccCounter) 
            elif grouped[index] == 'Policy-Counter-Status-Report':     avpString += 'Pcsr' + str(pcrsCounter) 
            elif grouped[index] == 'Policy-Counter-Identifier':        avpString += 'Pcid' + str(pcidCounter) 
            elif grouped[index] == 'Subscription-Id':                  avpString += 'Subscription-Id' + str(subIdCounter) 
	    else: avpString += grouped[index]
	    
	    # Add group seperator
	    avpString += hierarchyString
		
	# Add the AVP to the string
	avpString += tmp[0]
	
	# Add to the returned dictionary
        diameterDct[avpString] = re.sub('value=', '', tmp[-1].strip())
	
	# Debug output
        #print 'saving dictionary entry ' + avpString + ' = ' + diameterDct[avpString]

    return (diameterDct)

#===============================================================================
def readGroupedAVPs(options):
    groupedAVPs = {}
    diamDict = options.dict
    groupName = ''
    rmvFile = False
    outFile = "grouped_avps"
    
    # Want to run a command to grab the grouped data.
    runCmd("awk '/<grouped_avp/,/<\/grouped_avp/' " + diamDict + " | grep [_\<]avp | grep -v TODO > " + outFile)
    
    # Flag to signal inside a grouped AVP 
    insideGroupedAVPFlag = False
    
    # Open the file
    f = open(outFile)
    
    # Go through each line
    for line in f:
	# Remove leading/trailing white space
	line = line.strip()
	
	# If an empty line, skip
	if not line: continue
	
	# Debug output
        #print 'Processing line: ' + line
	
    	# See if this is a start/end flag
	if re.search(groupStartEndString, line):
		# See if this is the start of a group
		if not insideGroupedAVPFlag:
			# Set flag that we're in a grouped AVP
			insideGroupedAVPFlag = True
			
			# Debug output
			#print 'grouped_avp line: ' + line
			
			# Get the fields.  Here's the expected string: <grouped_avp name="MtxTxnId" code="2000" vendor_name="MatrixxSoftware">
			# Vendor data is optional
			lineFields = line.split(' ')
			groupName   = lineFields[1].split('=')[1].split('"')[1]
			groupCode   = lineFields[2].split('=')[1].split('"')[1]
			if re.search(vendorNameString, line): 
			       groupVendor = lineFields[3].split('=')[1].split('"')[1]
			else:  groupVendor = 'None'
			
			# Debug output
			#print 'Found group: ' + groupName
			
			# Create entry for this group
			groupedAVPs[groupName] = {}
			groupedAVPs[groupName]['code'] = groupCode
			groupedAVPs[groupName]['vendor'] = groupVendor
			groupedAVPs[groupName]['avps'] = []
			
		else:
			# This is the end of the group
			insideGroupedAVPFlag = False
		
		# No more processing for this line
		continue
	
	# Not a grouped item, so a single AVP.  Here's the expected string: <avp name="Outgoing-Trunk-Group-Id"/>
	# Also, file may have a dummy entry (with AVP string), so skip that
	if re.search('AVP', line): continue
	
	# Get AVP name
	avpName = line.split(' ')[1].split('=')[1].split('"')[1]
	
	# Debug output
	#print 'Group ' + groupName + ', Adding AVP ' + avpName
	
	# Add to the active group
	groupedAVPs[groupName]['avps'].append(avpName)
	
    # Remove temp file
    runCmd('rm '+ outFile)
    
    # Remove dictionary if flag is set
    if rmvFile: runCmd('rm '+ diamDict)
    
    return groupedAVPs
	
#===============================================================================
def processDebugLogFile(inputFile, debugFd=None, warnFd=None):

    # Initialize return structure
    diamMsgs = []

    # Initialize local message holder
    localDiamMsg = ''
    
    # Init message count
    msgCount = 0

    # Define diameter data file
    diamDataFile = '_diamData'
    diamTimeFile = '_diamTime'
    
    # Assume this is the generic debug log file.  Want to grab only the Diameter data.
    runCmd("awk '/Diameter Hdr:/,/}/' " + inputFile + " > " + diamDataFile)

    # Need to grab system time, as not all diameter commands include time    
    runCmd('grep -B4 "Diameter Hdr:" ' + inputFile + ' | grep LM_TRACE | cut -f3-4 -d" " | tr " " "T" > ' + diamTimeFile)

    # Open the diameter data and time files
    f = open(diamDataFile)
    g = open(diamTimeFile)

    # Go through each line in the file
    msgStartFlag = False
    for line in f:
	# Remove leading/trailing white space
	line = line.strip()
	
	# If an empty line, skip
	if not line: continue
	
	# Debug output
        #print 'Processing line: ' + line
	
        # Skip until we get to the header line
	if not msgStartFlag:
		# See if at start of new message
	        if re.search(msgStartString, line): 
			# If here, then found the start of the message
			msgStartFlag = True
			
			# Save first line
			localDiamMsg = line + '\n'
		
		# No need to further process this line
		continue
		
	# If here, then past start of the message.  Go until the end of the message is found.
	# Skip the one line that starts with a skip character.
	if re.search(msgLineSkipChar, line): continue
	
	# Check if end found
	if re.search(msgEndChar, line):
		# MINOR HACK:  Wan tto have a time value in each structure.
		# Read time from time file and create a dummy AVP structure.
		systemMsgTime = g.readline()
		
		# Create a dummy AVP
		line = 'AVP: System-Time(999), len=27, V=0, M=1, P=0, VendorId=0, value=' + systemMsgTime
		
		# Store as if it was found in the Diameter message
		localDiamMsg += line + '\n'	
		
		# Save line in return structure
		diamMsgs.append(localDiamMsg)
		
		# Clear start flag
		msgStartFlag = False
		
		# Bump message counter
		msgCount += 1
		
		# Debug output
		#print 'Stored message #' + str(msgCount)
		#print 'Message is:\n' + localDiamMsg
		
		# No more processing of this line needed
		continue
		
	# If here, then it's an AVP line.  Add to local message
	localDiamMsg += line + '\n'

    # Remove temp files
    runCmd('rm ' + diamDataFile + ' ' + diamTimeFile)
    
    return diamMsgs, msgCount
	
#===============================================================================
def showData(externalId = None):
    # Debug output
    print('\nSubscriber/device/session data:\n')
    
    # Sanithy check that an external ID was added in
    if not externalId:
	# Error
	print('ERROR:  no external ID passed to showData')
	sys.exit('Error')
    
    # Show this data
    idList = []
    if type(externalId) is list: idList.extend(externalId)
    else: idList.append(externalId)
	
    # Output data 
    TRACK.showSubscriberTrackingData(idList, scope = 'full', verbose = 'high')

#===============================================================================
def gatherInputFiles(options):
    fileToProcess = []
    
    # There may be more than one file to process
    if options.inputFile: fileToProcess = options.inputFile.split(',')

    # May want to read files from different servers
    ipAddr = []
    if options.ip:
        # Get all the addresses
        ipAddr = options.ip.split(',')

    	for index in range(len(ipAddr)):
            if ipAddr[index] == 'localhost':  fileToProcess.append('/var/log/mtx/mtx_debug.log')
            else:
                # Want to scp the file here
                runCmd("scp mtx@" + ipAddr[index] + ":/var/log/mtx/mtx_debug.log mtx_debug.log." + ipAddr[index])

                # Add this file to the file to process list
                fileToProcess.append('mtx_debug.log.' + ipAddr[index])

    return fileToProcess
#===============================================================================
def main():
    global options
    groupedAVPs = []
    fileToProcess = []
    
    # Path is always the current directory
    path = os.getcwd()
    
    ########### Do command line processing ###################
    options = cmdLineInput()
    
    ########### Initialize Tracking Data ###################
    initTrackingData(options)
    
    ########### Read in grouped AVPs ###################
    groupedAVPs = readGroupedAVPs(options)
    
    ########## Gather config files ##################
    options = gatherAllConfigFiles(options)
    
    # Loop while the answer not some form of "no"...
    ans = 'y'
    while not ans.lower().startswith('n'):

    	########## Gather all required files ##################
    	getDebugLogFiles(options)
    
    	############## Process Input Data #################
    	processInputFiles(options.inputFile, groupedAVPs)	

    	########### Show subscriber (and device, session) data ###################
    	showData(externalId = subExternalId)

	# If an IP address was specified, then we may loop to keep processing things
	if options.ip:
		# prompt to continue
		print('Press Enter key to process from last point; enter "n" to terminate: ')
		ans = str(eval(input()))
	else: ans = 'n'

if __name__ ==  '__main__':
    main()



