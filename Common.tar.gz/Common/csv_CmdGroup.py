#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:35:39
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:35:39
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:35:38
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
from __future__ import print_function
# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
import os, sys, copy
import QA_subscriber_management_restv3 as REST_UTIL
import qa_utils as QAUTILS
import csvMain as CSV
import csv_track as TRACK
import csv_id as CSVID
import csv_prim as PRIM
import csv_data as DATA
import custSpecific as CUST
import csv_qa as CSVQA
import csvMain as CSV
import csv_CmdMisc as MISC
import csv_Events as CSVEVENTS
import xml.etree.ElementTree as ET
import csv_CmdPayNow as PAYNOW
from primitives import primGET as GET

#==========================================================
def CmdGroup_removegroup(lclDCT, testName, sessionId, line, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, repeatCount):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        # End of local variables setup.
        
        # Set object type (for ease of cut/paste to other objects)
        objType='group'

        print('Looking to remove ' + objType + ' ' + groupId + ' (' + lclDCT['groupQueryType'] + ')')
        
        # First order is to get subscriber data
        q = GET.getObject(groupId, hostname=QAUTILS.gatewaysConfig.get('REST', 'restServer'), hostport=QAUTILS.gatewaysConfig.get('REST', 'restPort'), queryType=lclDCT['groupQueryType'], objType=objType, querySize=lclDCT['querySize'])
        #ET.dump(q)
        
        # If Q is empty, then nothing to do
        if q is None:
                print(objType + ' non-existent (query).')

                # Nothing to query
                queryType = queryValue = None

                return (queryType, queryValue)
        
        # Get OID
        try:
                oid = q.find('./ObjectId').text.strip()
        except:
                print(objType + ' non-existent (OID).')

                # Nothing to query
                queryType = queryValue = None

                return (queryType, queryValue)
        
        # *** Want to find time for delete.  Should match latest time that something new started in the object ***
        savedInputTime = lclStartTime
        lclStartTime = PRIM.findObjectLatestTime(q, lclStartTime, objType, groupId, lclDCT['groupQueryType'])
        
        print('Remove ' + objType + ' ' + lclDCT['externalId'] + ' - using time ' + lclStartTime)
        if lclDCT['lclStartTime'] != savedInputTime: print('Updated remove time from ' + savedInputTime + ' to ' + lclStartTime)
        
        # ** Move object to deletable state.  Every customer has their own states.  TF writes this into customer specific logic.
        stateMap = copy.deepcopy(CUST.groupStateMap)

        # Get object state
        try:
                objState = q.find('./StatusDescription').text.strip()
        except:
                objState = 'Active'

        # Debug output
        #print 'stateMap = ' + str(stateMap) + ', starting state = ' + objState
        
        objState = objState.lower()
        while stateMap[objState] != 'Remove':
                # Get next state
                objState = stateMap[objState]

                # Modify to next state
                newLine='modifyGroup;groupId=' + oid + ';groupQueryType=ObjectId;groupStatus=' + objState + ';noChecks=True;skipStepResults=' + str(lclDCT['skipStepResults']) + ';rmvFlag=1'
                (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)

        # ** Process admins from the group.  
        # Admin may cross groups, so don't remove the admin from the system (only from the group).
        removedAdmins = []
        xmlDctName = './AdminIdArray/value'
        for children in q.findall(xmlDctName):
                # See if we're supposed to remove the children
                if not lclDCT['keepChildren']:
                        # Mark sub as having been processed
                        removedAdmins.append(children.text)
                        
                        # Remove the subscriber
                        newLine='removeSubscriber;externalId=' + children.text + ';subQueryType=ObjectId;noChecks=True;skipStepResults=' + str(lclDCT['skipStepResults'])
                else:
                        # Just unlink the child
                        newLine='removeAdminFromGroup;groupQueryType=ObjectId;noChecks=True;groupId=' + oid + ';externalId=' + children.text + ';subQueryType=ObjectId;skipStepResults=' + str(lclDCT['skipStepResults'])
                (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)

        # ** Remove or unlink child subscribers
        xmlDctName = './SubscriberMemberIdArray/value'
        for children in q.findall(xmlDctName):
                # If previously removed as part of admin processing, then don't try a second time
                if children.text in removedAdmins: continue
                
                # If keepChildren not set to true then want to remove the children
                if not lclDCT['keepChildren']:
                        # Remove the subscriber
                        newLine='removeSubscriber;externalId=' + children.text + ';subQueryType=ObjectId;noChecks=True;skipStepResults=' + str(lclDCT['skipStepResults'])
                else:
                        # Just unlink the child
                        newLine='removeSubscriberFromGroup;groupId=' + oid + ';groupQueryType=ObjectId;externalId=' + children.text + ';subQueryType=ObjectId;noChecks=True;skipStepResults=' + str(lclDCT['skipStepResults'])
                (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)
                        
        # ** Remove or unlink child groups
        xmlDctName = './GroupMemberIdArray/value'
        for children in q.findall(xmlDctName):
                # If keepChildren not set to true then want to remove the children
                if not lclDCT['keepChildren']:
                        # Remove the group
                        newLine='removeGroup;groupQueryType=ObjectId;noChecks=True;groupId=' + children.text + ';skipStepResults=' + str(lclDCT['skipStepResults'])
                else:
                        newLine='removeSubGroupFromGroup;groupId=' + oid + ';groupQueryType=ObjectId;subGroupId=' + children.text + ';noChecks=True;skipStepResults=' + str(lclDCT['skipStepResults'])
                (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)
                
        # If this were complete, we'd now remove subscriber from being administrator...
        
        # ** Delete object
        newLine='deleteGroup;groupId=' + oid + ';groupQueryType=ObjectId;noChecks=True;skipStepResults=' + str(lclDCT['skipStepResults'])
        (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)

        # Nothing to query
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdGroup_groupqueryevent(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        # End of local variables setup.
       
       # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Want to loop here until everything is retrieved
        qc = lclDCT['queryCursor']
        respData = ''
        while qc != 0:
                # Execute primitive
                (retCode, qc) = REST_UTIL.queryGroupEvent(RESTInst,
                        groupId,
                        queryType=lclDCT['groupQueryType'],
                        querySize=lclDCT['querySize'],
                        eventPass=lclDCT['eventPass'],
                        queryCursor = qc,
                        now=lclDCT['lclStartTime'],
                        eventTimeLowerBound=lclDCT['eventTimeLowerBound'],
                        eventTimeUpperBound=lclDCT['eventTimeUpperBound'],
                        eventTypeStringArray=lclDCT['eventTypeStringArray']
                        )
                
                # If we're expected to fail then we may get nothing back, so break from here
                if not lclDCT['eventPass']: break
                
                # Get cursor return value
                try: qc = int(qc)
                except:
                        print('Did not get back an int for qc: ' + str(qc))
                        qc = 0
                
                # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
                try:
                        respData += str(retCode.printElementBasedXml())
                except:
                        respData += str(retCode)
        
        # See if we found nothing
        if "EventList" not in respData:
                # If eventPass then this is an error
                if lclDCT['eventPass']:
                        print('ERROR: No events returned for group event store query and eventPAss set to True')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
                
                # Exit from here
                print('NO events found')
                return (None, None)
        
        # See if associates or secondary events requested
        if lclDCT['processSecondaryEvents'] or lclDCT['processAssociatedEvents']: respData = CSVEVENTS.processOtherEvents(respData, lclDCT, RESTInst)
        
        # Do work if expecting to pass
        if lclDCT['eventPass']:
                # If supposed to save data to variables then do that here
                if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, 'Event', respData)
                
                # Write to where the caller wanted it to go iff not saving data
                else: CSVQA.processDataToOutput(respData, lclDCT['outputFileName'])
                
        # Query None
        queryValue = queryType = None
        
        return (queryType, queryValue)
        
#==========================================================
def CmdGroup_creategroup(lclDCT, testName, sessionId, line, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, repeatCount):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        # End of local variables setup.
       
       # Group should not exist
        if groupId in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Create billing cycle data if profile id defined
        if lclDCT['profileId'] and int(lclDCT['profileId']):
                billingCycle = REST_UTIL.createBillingCycleData(lclDCT['profileId'], dateOffset=lclDCT['dateOffset'], startTime=lclDCT['startTime'])
        else:
                billingCycle = None

        # Check if Subscriber does not exist
        if int(lclDCT['externalId']) != 0 and lclDCT['externalId'] not in TRACK.subscriberTracking and not lclDCT['noChecks']:
                # *** Create admin subscriber.  NOTE: must have a device associated with it or else can't use the customer portal ***
                newLine='addSubscriber;externalId=' + str(lclDCT['externalId']) + ';deviceId=' + str(lclDCT['deviceId']) + ';verbose=none;firstName=Group_' + lclDCT['mark'] + ';lastName=Administrator;offerId=0'

                print(lclDCT['ACTION'] + ': newLine = ' + newLine)
                (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)
        
        # Get tier name from list
        if lclDCT['tier']: tierName = lclDCT['tier'][0]
        else:    tierName = None
        
        # Use time zone if group-specific not set
        if not lclDCT['groupTimeZone'] and lclDCT['timeZone']: groupTimeZone = lclDCT['timeZone']
        else: groupTimeZone = lclDCT['groupTimeZone'] # Added during Python3 migration
        
        serviceAddress = REST_UTIL.createServiceAddressData(streetAddr=lclDCT['streetAddr'], extendedAddr=lclDCT['extendedAddr'], locality=lclDCT['locality'], region=lclDCT['region'], postalCode=lclDCT['postalCode'], extendedPostalCode=lclDCT['extendedPostalCode'], countryCode=lclDCT['countryCode'])
        
        # If creating an object with custom parameters, output those.
        print('Looking to create group ID = ' + groupId)
        #if lclDCT['customAttr'][2]: print 'Including custom parameters: ' + str(lclDCT['customAttr'][2])
        
        # Execute primitive
        #administrator_id=int(lclDCT['externalId']),
        retCode = REST_UTIL.createGroup(RESTInst,
                groupId=groupId,
                name=lclDCT['name'],
                tier=tierName,
                attr=lclDCT['customAttr'][2],
                billingCycle=billingCycle,
                queryType=lclDCT['groupQueryType'],
                timeZone=groupTimeZone,
                now=lclStartTime,
                taxStatus=lclDCT['taxStatus'],
                taxCertificate=lclDCT['taxCertificate'],
                taxLocation=lclDCT['taxLocation'],
                notificationPreference=lclDCT['groupNotificationPreference'],
                groupReAuthPreference=lclDCT['groupReAuthPreference'],
                glCenter=lclDCT['glCenter'],
                routingType=lclDCT['routingType'],
                routingValue=lclDCT['routingValue'],
                executeMode=lclDCT['executeMode'],
                apiEventData=lclDCT['customAttr'][6],
                status=lclDCT['groupStatus'],
                
                customerType=lclDCT['customerType'],
                serviceAddress=serviceAddress,
                npa=lclDCT['npa'],
                nxx=lclDCT['nxx'],
                tenantId=lclDCT['tenantId'],
                exemptionCodeList=lclDCT['exemptionCodeList'],
                
                )

                #administrator_id=externalId,
        # Update tracking data
        if lclDCT['eventPass']: TRACK.updateTrackingData(lclDCT['ACTION'], externalId = lclDCT['externalId'], groupId = groupId, mark=lclDCT['mark'], RESTInst=RESTInst)

        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdGroup_deletegroup(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        # End of local variables setup.
        
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Execute primitive
        retCode = REST_UTIL.deleteGroup(RESTInst,
                groupId,
                queryType=lclDCT['groupQueryType'],
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                apiEventData=lclDCT['customAttr'][6],
                )
        
        # Update tracking data
        if lclDCT['eventPass']: TRACK.updateTrackingData(lclDCT['ACTION'], groupId = groupId, RESTInst=RESTInst)

        # Query group
        if lclDCT['eventPass']: queryValue = None
        else:  queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdGroup_modifygroup(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        resourceId = lclDCT['resourceId']
        # End of local variables setup.
        
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # OK...  We can have stuff that has been defaulted.  For modifies, only want to send in what was specifically requested to be modified.
        # Some fields (e.g. profileId) can't be modified and even setting them to the same value they were created with causes issues.
        if cmdLineInput:
         for param in DATA.groupModifyList + [x[0] for x in DATA.customGroupParameters]:
          if not cmdLineInput.count(param): lclDCT[param] = None

         # Really should recalculate Attr parameters as above lines were meant to clear those that were not input in the command line...
         (devAttr, subAttr, groupAttr, offerAttr, userAttr, loginAttr, apiEventDataAttr) = PRIM.getCustomAttributes(lclDCT, cmdLineInput)
        else:
                # Copy from dictionary
                groupAttr = lclDCT['customAttr'][2]
                apiEventDataAttr = lclDCT['customAttr'][6]

        # Create billing cycle data if profile id defined
        if lclDCT['profileId'] and int(lclDCT['profileId']):
                billingCycle = REST_UTIL.createBillingCycleData(lclDCT['profileId'], dateOffset=lclDCT['dateOffset'], startTime=lclDCT['startTime'], immediateChange=lclDCT['immediateChange'])
        else:
                billingCycle = None

        print('Looking to modify group ID = ' + groupId)
        #if lclDCT['customAttr'][2]: print 'Including custom parameters: ' + str(lclDCT['customAttr'][2])
        
        # If the resourceId is not passed in and paymentToken is, then attempt to get it from the payment token
        if lclDCT['paymentToken'] and not resourceId:
                # Get payment data
                payment = PRIM.getPaymentData('group', groupId, lclDCT['paymentToken'], lclDCT['lclStartTime'], lclDCT['ACTION'], lclDCT['groupQueryType'])

                # Get the resource ID
                resourceId = int(payment['ResourceId'])
                
        # Clear resourceId if set to 0
        if int(resourceId) == 0: resourceId = None
        
        # Get tier name from list
        if lclDCT['tier']: tierName = lclDCT['tier'][0]
        else:    tierName = None
        
        # Use time zone if group-specific not set
        if not lclDCT['groupTimeZone'] and lclDCT['timeZone']: groupTimeZone = lclDCT['timeZone']
        else: groupTimeZone = lclDCT['groupTimeZone'] # Added during Python3 migration
        
        serviceAddress = REST_UTIL.createServiceAddressData(streetAddr=lclDCT['streetAddr'], extendedAddr=lclDCT['extendedAddr'], locality=lclDCT['locality'], region=lclDCT['region'], postalCode=lclDCT['postalCode'], extendedPostalCode=lclDCT['extendedPostalCode'], countryCode=lclDCT['countryCode'])
        
        # Execute primitive
        retCode = REST_UTIL.modifyGroup(RESTInst,
                groupId=groupId,
                name=lclDCT['name'],
                tier=tierName,
                attr=groupAttr,
                billingCycle=billingCycle,
                groupQueryType=lclDCT['groupQueryType'],
                subQueryType=lclDCT['subQueryType'],
                timeZone=groupTimeZone,
                now=lclDCT['lclStartTime'],
                status=lclDCT['groupStatus'],
                taxStatus=lclDCT['taxStatus'],
                taxCertificate=lclDCT['taxCertificate'],
                taxLocation=lclDCT['taxLocation'],
                externalId=lclDCT['modGroupId'],
                notificationPreference=lclDCT['groupNotificationPreference'],
                groupReAuthPreference=lclDCT['groupReAuthPreference'],
                glCenter=lclDCT['glCenter'],
                paymentGatewayUserId=lclDCT['paymentGatewayUserId'], currentPaymentTokenResourceId=resourceId,
                lastActivityUpdateTime=lclDCT['lastActivityUpdateTime'],
                apiEventData=apiEventDataAttr,
                billingCycleDisabled=lclDCT['billingCycleDisabled'],
                
                customerType=lclDCT['customerType'],
                serviceAddress=serviceAddress,
                npa=lclDCT['npa'],
                nxx=lclDCT['nxx'],
                tenantId=lclDCT['tenantId'],
                exemptionCodeList=lclDCT['exemptionCodeList'],
                
                )

        # If changing external IDs, then need to update tracking data
        if lclDCT['modGroupId'] and (modGroupId != groupId):
               # Update tracking data
                TRACK.updateTrackingData(lclDCT['ACTION'], groupId = groupId, modId=lclDCT['modGroupId'])

        # Query group
        if lclDCT['modGroupId']: queryValue = lclDCT['modGroupId']
        else:          queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdGroup_addadmintogroup(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        # End of local variables setup.
        
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Subscriber or Subscription should exist
        if lclDCT['externalId'] not in TRACK.subscriberTracking and not lclDCT['noChecks']:
                print('ERROR: subscriber/subscription with ID "' + lclDCT['externalId'] + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Execute primitive
        retCode = REST_UTIL.addAdminToGroup(RESTInst,
                groupId=groupId,
                subscriberId=lclDCT['externalId'],
                subQueryType=lclDCT['subQueryType'],
                groupQueryType=lclDCT['groupQueryType'],
                eventPass=lclDCT['eventPass'],
                now=lclDCT['lclStartTime'],
                apiEventData=lclDCT['customAttr'][6],
                )

        # Update tracking data
# FIXME:  admin only tracking    if eventPass: TRACK.updateTrackingData(lclDCT['ACTION'], externalId = externalId, groupId = groupId)

        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'
        return (queryType, queryValue)
        
#==========================================================
def CmdGroup_removeadminfromgroup(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
       # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        # End of local variables setup.
       
       # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Subscriber or Subscription should exist
        if lclDCT['externalId'] not in TRACK.subscriberTracking and not lclDCT['noChecks']:
                print('ERROR: subscriber/subscription with ID "' + lclDCT['externalId'] + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Execute primitive
        retCode = REST_UTIL.removeAdminFromGroup(RESTInst,
                groupId=groupId,
                subscriberId=lclDCT['externalId'],
                subQueryType=lclDCT['subQueryType'],
                groupQueryType=lclDCT['groupQueryType'],
                eventPass=lclDCT['eventPass'],
                now=lclDCT['lclStartTime'],
                apiEventData=lclDCT['customAttr'][6],
                )

        # Update tracking data
# FIXME: admin only tracking    if eventPass: TRACK.updateTrackingData(lclDCT['ACTION'], externalId = externalId, groupId = groupId)

        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdGroup_addsubscribertogroup(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
       # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        # End of local variables setup.
        
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Item should exist.  Skip if in a multi-request.
        if not lclDCT['noChecks'] and lclDCT['subQueryType'] != 'MultiRequestIndex':
                # Check subscriber or subscription
                if lclDCT['externalId'] not in TRACK.subscriberTracking:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + lclDCT['externalId'] + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        print('Adding ' + REST_UTIL.subUrl + ' ' + lclDCT['externalId'] + ' to group ' + groupId)
        
        # Execute primitive
        retCode = REST_UTIL.addSubscriberToGroup(RESTInst,
                groupId=groupId,
                subscriberId=lclDCT['externalId'],
                subQueryType=lclDCT['subQueryType'],
                groupQueryType=lclDCT['groupQueryType'],
                eventPass=lclDCT['eventPass'],
                now=lclDCT['lclStartTime'],
                apiEventData=lclDCT['customAttr'][6],
                )

        # Update tracking data
        if lclDCT['eventPass']: TRACK.updateTrackingData(lclDCT['ACTION'], externalId = lclDCT['externalId'], groupId = groupId)

        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdGroup_removesubscriberfromgroup(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
       # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        # End of local variables setup.
        
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Item should exist.  Skip if in a multi-request.
        if not lclDCT['noChecks'] and lclDCT['subQueryType'] != 'MultiRequestIndex':
                # Check subscriber or subscription
                if lclDCT['externalId'] not in TRACK.subscriberTracking:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + lclDCT['externalId'] + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        print('Removing ' + REST_UTIL.subUrl + ' ' + lclDCT['externalId'] + ' from group ' + groupId)
        
        # Execute primitive
        retCode = REST_UTIL.removeSubscriberFromGroup(RESTInst,
                groupId=groupId,
                subscriberId=lclDCT['externalId'],
                subQueryType=lclDCT['subQueryType'],
                groupQueryType=lclDCT['groupQueryType'],
                eventPass=lclDCT['eventPass'],
                now=lclDCT['lclStartTime'],
                apiEventData=lclDCT['customAttr'][6],
                )

        # Update tracking data
        if lclDCT['eventPass'] and not lclDCT['noChecks']: TRACK.updateTrackingData(lclDCT['ACTION'], externalId = lclDCT['externalId'], groupId = groupId)
        
        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdGroup_addsubgrouptogroup(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
       # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        # End of local variables setup.
        
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Execute primitive
        retCode = REST_UTIL.addSubGroupToGroup(RESTInst,
                groupId=groupId,
                subGroupId=lclDCT['subGroupId'],
                subQueryType=lclDCT['subQueryType'],
                groupQueryType=lclDCT['groupQueryType'],
                eventPass=lclDCT['eventPass'],
                now=lclDCT['lclStartTime'],
                apiEventData=lclDCT['customAttr'][6],
                )

        # Update tracking data
        if lclDCT['eventPass']: TRACK.updateTrackingData(lclDCT['ACTION'], subGroupId = lclDCT['subGroupId'], groupId = groupId)

        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdGroup_removesubgroupfromgroup(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
       # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        # End of local variables setup.
        
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Sub Group should exist
        if lclDCT['subGroupId'] not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + lclDCT['subGroupId'] + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Execute primitive
        retCode = REST_UTIL.removeSubGroupFromGroup(RESTInst,
                groupId=groupId,
                subGroupId=lclDCT['subGroupId'],
                subQueryType=lclDCT['subQueryType'],
                groupQueryType=lclDCT['groupQueryType'],
                eventPass=lclDCT['eventPass'],
                now=lclDCT['lclStartTime'],
                apiEventData=lclDCT['customAttr'][6],
                )

        # Update tracking data
        if lclDCT['eventPass'] and not lclDCT['noChecks']: TRACK.updateTrackingData(lclDCT['ACTION'], subGroupId = lclDCT['subGroupId'], groupId = groupId)

        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdGroup_groupsubscribetooffer(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        offerStartTime = lclDCT['offerStartTime']
        # End of local variables setup.
       
       # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Set the ofer start time to whatever the local test tool time if it's not specified via the input.
        if offerStartTime == None:
                if lclDCT['futureTime']:  offerStartTime = lclDCT['futureTime']
                else:                     offerStartTime = lclStartTime
#        else: lclStartTime = offerStartTime

        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        elif lclStartTime != offerStartTime:
             print('Changing local test run time from ' + lclStartTime + ' to ' + offerStartTime + ' because offer start time parameter was specified.')
             lclStartTime = offerStartTime

        # Save updated time
        lclDCT['lclStartTime'] = lclStartTime
        
        # ** Now work on offers.  Can have two parameters to specify this.  Can buy by external ID or catalog ID.  Can by legacy product ID or current catalog ID.
        # ** More difficult than it should be...
        (catalogItemId,offerId) = PRIM.processOffers(lclDCT['offerId'], lclDCT['groupOfferId'], lclDCT['offerIsExternal'], lclDCT['offerIsCatalog'])

        # If no offers specified, then this is an error
        if not lclDCT['offerId']: sys.exit('ERROR: issued group purchase offer command but did not specify any offers (offerId or groupOfferId parameters)')
        
        if lclDCT['verbose'] not in ['low', 'none']:
         print('Group = ' + groupId + '(' + lclDCT['groupQueryType'] + ') is purchasing catalog items '  + str(lclDCT['offerId']) + ' with start/end times ' + str(lclDCT['offerStartTime']) + '/' + str(lclDCT['offerEndTime']))

        #print 'Offer attributes are: ' + str(lclDCT['customAttr'][3])
        
        # If resource IDs passed in as a non-integer, then need to get its resource ID assuming they're offer external IDs
        param = 'autoActivationCycleResourceId'
        value = lclDCT[param]
        if value and not (value.isdigit() and value != '0'):
                # Get resource ID data
                offerDict = PRIM.getOfferData('group', groupId, 0, value, lclStartTime, lclDCT['ACTION'], queryType=lclDCT['groupQueryType'], offerIsCatalog=True)
                
                # Get the resource ID
                lclDCT[param]  = int(offerDict['ResourceId'])
                
                print('Retrieved ' + param + ' = ' + offerDict['ResourceId'])
        
        param = 'offerCycleResourceId'
        value = lclDCT[param]
        if value and not (value.isdigit() and value != '0'):
                # Get resource ID data
                offerDict = PRIM.getOfferData('group', groupId, 0, value, lclStartTime, lclDCT['ACTION'], queryType=lclDCT['groupQueryType'], offerIsCatalog=True)
                
                # Get the resource ID
                lclDCT[param]  = int(offerDict['ResourceId'])
                
                print('Retrieved ' + param + ' = ' + offerDict['ResourceId'])
        
        param = 'autoActivationCycleResourceId'
        value = lclDCT[param]
        if value and not (value.isdigit() and value != '0'):
                # Get resource ID data
                offerDict = PRIM.getOfferData('group', groupId, 0, value, lclStartTime, lclDCT['ACTION'], queryType=lclDCT['groupQueryType'], offerIsCatalog=True)
                
                # Get the resource ID
                lclDCT[param]  = int(offerDict['ResourceId'])
                
                print('Retrieved ' + param + ' = ' + offerDict['ResourceId'])

        # Having fun with preActiveState and JSON.  If false set to None
        if lclDCT['preActiveState'] == False or str(lclDCT['preActiveState']).lower() == '0': preActiveState = None
        else: preActiveState = lclDCT['preActiveState'] # Added during Python3 migration
        
        # Fix down payment of 0 to be None
        if str(lclDCT['amount']) == '0': amount = None
        else: amount = lclDCT['amount'] # Added during Python3 migration
        
        # Build offer parameters
        try:    parameterList = PRIM.buildOfferParameters(CUST.custOfferParameterList, lclDCT)
        except: parameterList = None
        #print 'parameterList: ' + str(parameterList)
        
        # Convert datetime to time
        if lclDCT['offerCycleStartTime']: offerCycleStartTime = lclDCT['offerCycleStartTime'].split('T')[1][:8]
        else: offerCycleStartTime = lclDCT['offerCycleStartTime'] # Added during Python3 migration

        # Execute primitive
        if lclDCT['futureTime']:
           print('Purchasing offer in the future')
           # Execute primitive
           (retCode, taskId) = REST_UTIL.groupPurchaseOfferInFuture(RESTInst,
                groupId,
                lclDCT['offerId'],
                lclDCT['futureTime'],
                offerStartTime=offerStartTime,
                offerEndTime=lclDCT['offerEndTime'],
                eventPass=lclDCT['eventPass'],
                queryType=lclDCT['groupQueryType'],
                now=None,
                offerIsExternal=lclDCT['offerIsExternal'],
                attr=lclDCT['customAttr'][3],
                skipVtime=True,
                catalogItemId=catalogItemId,
                apiEventData=lclDCT['customAttr'][6],
                parameterList=parameterList,
                )
           
        elif lclDCT['allOffers'] and lclDCT['trace']:
        # Want a trace after each purchase
          for offerItem in lclDCT['offerId']:
           # Execute primitive
           taskId = None
           (retCode, resourceIds) = REST_UTIL.groupSubscribeToOffer(RESTInst,
                groupId=groupId,
                offerId=offerItem,
                offerStartTime=offerStartTime,
                offerEndTime=lclDCT['offerEndTime'],
                eventPass=lclDCT['eventPass'],
                queryType=lclDCT['groupQueryType'],
                now=lclStartTime,
                offerIsExternal=lclDCT['offerIsExternal'],
                attr=lclDCT['customAttr'][3],
                catalogItemId=catalogItemId,
                chargeMethod=lclDCT['chargeMethod'],
                paymentMethodResourceId=lclDCT['paymentMethodResourceId'],
                paymentGatewayId=lclDCT['paymentGatewayId'],
                paymentGatewayOneTimeToken=lclDCT['paymentGatewayOneTimeToken'],
                offerCycleType=lclDCT['offerCycleType'],
                offerCycleResourceId=lclDCT['offerCycleResourceId'],
                offerCycleOffset=lclDCT['offerCycleOffset'],
                offerCycleStartTime=offerCycleStartTime,
                preActiveState=preActiveState,
                activationExpirationTime=lclDCT['activationExpirationTime'],
                activationExpirationRelativeOffsetUnit=lclDCT['activationExpirationRelativeOffsetUnit'],
                activationExpirationRelativeOffset=lclDCT['activationExpirationRelativeOffset'],
                endTimeRelativeOffsetUnit=lclDCT['endTimeRelativeOffsetUnit'],
                endTimeRelativeOffset=lclDCT['endTimeRelativeOffset'],
                autoActivationTime=lclDCT['autoActivationTime'],
                autoActivationRelativeOffsetUnit=lclDCT['autoActivationRelativeOffsetUnit'],
                autoActivationRelativeOffset=lclDCT['autoActivationRelativeOffset'],
                autoActivationCycleResourceId=lclDCT['autoActivationCycleResourceId'],
                grantPurchaseProrationType=lclDCT['grantProrationType'],
                chargePurchaseProrationType=lclDCT['chargeProrationType'],
                reason=lclDCT['reason'],
                info=lclDCT['info'],
                isRecurringFailureAllowed=lclDCT['isRecurringFailureAllowed'],
                eligibilityCheck=lclDCT['eligibilityCheck'],
                apiEventData=lclDCT['customAttr'][6],
                contractPeriod=lclDCT['contractPeriod'],
                contractInterval=lclDCT['contractInterval'],
                commitmentPeriod=lclDCT['commitmentPeriod'],
                commitmentPeriodInterval=lclDCT['commitmentPeriodInterval'],
                isOpenContract=lclDCT['isOpenContract'],
                etcScheduleRangeArray=lclDCT['etcScheduleRangeArray'],
                etcScheduleRangeUnit=lclDCT['etcScheduleRangeUnit'],
                paymentScheduleRangeArray=lclDCT['paymentScheduleRangeArray'],
                paymentScheduleAmountArray=lclDCT['paymentScheduleAmountArray'],
                paymentScheduleLastAmount=lclDCT['paymentScheduleLastAmount'],
                delayCharge=lclDCT['delayCharge'],
                paymentDueDate=lclDCT['paymentDueDate'],
                parameterList=parameterList,
                )

           # Run trace command (output goes to std out)
           PRIM.printToScreen('saveGroupMDC', groupId, lclDCT['groupQueryType'], lclDCT, lclStartTime)
        
        else:
           taskId = None
           geoData = REST_UTIL.createGeoData(geoCode=lclDCT['geoCode'], postalCode=lclDCT['postalCode'], plus4=lclDCT['plus4'], npa=lclDCT['npa'], nxx=lclDCT['nxx'])
           (retCode, response) = REST_UTIL.groupSubscribeToOffer(RESTInst,
                groupId=groupId,
                offerId=lclDCT['offerId'],
                offerStartTime=offerStartTime,
                offerEndTime=lclDCT['offerEndTime'],
                eventPass=lclDCT['eventPass'],
                queryType=lclDCT['groupQueryType'],
                now=lclStartTime,
                offerIsExternal=lclDCT['offerIsExternal'],
                attr=lclDCT['customAttr'][3],
                catalogItemId=catalogItemId,
                chargeMethod=lclDCT['chargeMethod'],
                paymentMethodResourceId=lclDCT['paymentMethodResourceId'],
                paymentGatewayId=lclDCT['paymentGatewayId'],
                paymentGatewayOneTimeToken=lclDCT['paymentGatewayOneTimeToken'],
                purchaseInfo=True,
                offerCycleType=lclDCT['offerCycleType'],
                offerCycleResourceId=lclDCT['offerCycleResourceId'],
                offerCycleOffset=lclDCT['offerCycleOffset'],
                offerCycleStartTime=offerCycleStartTime,
                preActiveState=preActiveState,
                activationExpirationTime=lclDCT['activationExpirationTime'],
                activationExpirationRelativeOffsetUnit=lclDCT['activationExpirationRelativeOffsetUnit'],
                activationExpirationRelativeOffset=lclDCT['activationExpirationRelativeOffset'],
                autoActivationCycleResourceId=lclDCT['autoActivationCycleResourceId'],
                endTimeRelativeOffsetUnit=lclDCT['endTimeRelativeOffsetUnit'],
                endTimeRelativeOffset=lclDCT['endTimeRelativeOffset'],
                downPayment=amount,
                grantPurchaseProrationType=lclDCT['grantProrationType'],
                chargePurchaseProrationType=lclDCT['chargeProrationType'],
                reason=lclDCT['reason'],
                info=lclDCT['info'],
                isRecurringFailureAllowed=lclDCT['isRecurringFailureAllowed'],
                apiEventData=lclDCT['customAttr'][6],
                contractPeriod=lclDCT['contractPeriod'],
                contractInterval=lclDCT['contractInterval'],
                commitmentPeriod=lclDCT['commitmentPeriod'],
                commitmentPeriodInterval=lclDCT['commitmentPeriodInterval'],
                isOpenContract=lclDCT['isOpenContract'],
                etcScheduleRangeArray=lclDCT['etcScheduleRangeArray'],
                etcScheduleRangeUnit=lclDCT['etcScheduleRangeUnit'],
                paymentScheduleRangeArray=lclDCT['paymentScheduleRangeArray'],
                paymentScheduleAmountArray=lclDCT['paymentScheduleAmountArray'],
                paymentScheduleLastAmount=lclDCT['paymentScheduleLastAmount'],
                delayCharge=lclDCT['delayCharge'],
                paymentDueDate=lclDCT['paymentDueDate'],
                parameterList=parameterList,
                
                geoData=geoData,
                )
        
           # Do stuff if expecting success
           if lclDCT['eventPass']:
                # Store purchase constants
                PRIM.storeOfferConstants('group', response, catalogItemId, lclDCT['offerId'])
                
                # Update tracking data
                TRACK.updateTrackingData(lclDCT['ACTION'], offerId = lclDCT['offerId'], groupId = groupId, taskId=taskId, resourceId = [resourceId])

        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdGroup_groupunsubscribefromoffer(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        # End of local variables setup.
      
      # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Set the ofer start time to whatever the local test tool time if it's not specified via the input.
        if lclDCT['offerEndTime'] == None:
                if lclDCT['futureTime']:  offerEndTime = lclDCT['futureTime']
                else:                     offerEndTime = lclStartTime
#        else: lclStartTime = offerEndTime
        else: offerEndTime = lclDCT['offerEndTime'] # Added during Python3 migration

        # Can provide groupOfferId or offerId for this command.
        # Map to offer ID.
        if (not lclDCT['offerId'] or lclDCT['offerId'].count('0')) and lclDCT['groupOfferId']: offerId = lclDCT['groupOfferId']
        else: offerId = lclDCT['offerId'] # Added during Python3 migration

        # If future time, then need to retrieve the taskId of the schedueld task
        if lclDCT['futureTime']:
          # Retrieve future task ID.
          # NOTE:  at the moment only one future task ID is stored per external ID.  Will enhance this in the future.
          taskId = TRACK.groupTracking[groupId]['taskId']
          #print 'Retrieved Task: ' + str(taskId)

          # If no task and expecting a failure, then use a dummy task Id (negative testing)
          if not taskId and not lclDCT['eventPass']:
                taskId = '0-1-2-3'
                print('Created a dummy value for a taskId, for negative testing: ' + taskId)
        else:
          # No taskId in this scenario
          taskId = None

          # If no resource ID passed in, then need to get using the external ID
          if lclDCT['futureTime']: resourceId = None
          elif resourceId in [0, 'first', 'second', 'third', 'last']:
                resourceData = ''
                for idx in range(len(offerId)):
                        offerDict = PRIM.getOfferData('group', groupId, 0, offerId[idx], lclStartTime, lclDCT['ACTION'], queryType=lclDCT['groupQueryType'], offerIsCatalog=lclDCT['offerIsCatalog'], resourceId=resourceId)
                        
                        # Get the resource ID
                        resourceData += str(offerDict['ResourceId']) + '@'
                        
                # Remove trailing list separator char
                resourceId = resourceData[:-1]
                
          # Convert resource ID to a list
          resourceId = resourceId.split('@')
        
        # What to print depends on catalog vs offer...
        if lclDCT['offerIsCatalog']:
                offertype = 'catalog'
        else:
                offertype = 'legacy'
        print('Group = ' + groupId + ' is unsubscribing from ' + offertype + ' offer(s) with resource IDs' + str(resourceId) + ' with end time ' + str(offerEndTime))

        # Execute primitive
        if lclDCT['futureTime']:
          REST_UTIL.groupCancelOfferInFuture(RESTInst,
                lclDCT['futureTime'],
                queryType = 'ObjectId',
                queryValue = taskId,
                resourceIdList = None,
                skipVtime = True,
                eventPass=lclDCT['eventPass'],
                )
        else:
          retCode = REST_UTIL.groupUnsubscribeFromOffer(RESTInst,
                groupId=groupId,
                resourceIds=resourceId,
                queryType=lclDCT['groupQueryType'],
                now=offerEndTime,
                eventPass=lclDCT['eventPass'],
                executeMode=lclDCT['executeMode'],
                eligibilityCheck=lclDCT['eligibilityCheck'],
                apiEventData=lclDCT['customAttr'][6],
                )

        # Update tracking data
        if lclDCT['eventPass']: TRACK.updateTrackingData(lclDCT['ACTION'], offerId = offerId, groupId = groupId, resourceId = resourceId, taskId=taskId)

        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdGroup_addgroupthreshold(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        resourceId = lclDCT['resourceId']
        # End of local variables setup.
       
       # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # notify parameter is taken from notificationPreference
        if lclDCT['notificationPreference'] != '0':
                notify = True
        else:
                notify = False
        
        # VirtualCreditLimitIsPct parameter needs to be string or None instead of boolean
        if lclDCT['virtualCreditLimitIsPercent']:
                virtualCreditLimitIsPercent = '1'
        else:   virtualCreditLimitIsPercent = None
        
        # If no resource ID passed in and a balance ID was passed in, then go find it
        if resourceId in [0, 'first', 'second', 'third', 'last'] and int(lclDCT['balanceId']) > 0:
                # Get the balance in question
                balance = PRIM.getBalanceData('group', groupId, lclDCT['balanceId'], resourceId, lclDCT['lclStartTime'], lclDCT['ACTION'], lclDCT['groupQueryType'])
                
                # Get the resource ID
                resourceId = int(balance['ResourceId'])
        
        # If threshold ID is still non-numeric, then give it one more chance to translate, as the user may have used the CB name.
        # Since threshold names are not unique across balances, generic name translation can't be used.
        if not lclDCT['thresholdId'].isdigit(): (thresholdId, thresholdAmount, percentFlag) = PRIM.getThresholdId(lclDCT['balanceId'], lclDCT['thresholdId'])
        else: thresholdId = lclDCT['thresholdId'] # Added during Python3 migration
        
        # Can reference payment method by name or resource ID
        if str(lclDCT['paymentMethodResourceId']) == '999' and lclDCT['name']: paymentMethodResourceId = PAYNOW.getPaymentResourceId(groupId, lclDCT['groupQueryType'], lclDCT['name'], objType = 'Group')
        else: paymentMethodResourceId = lclDCT['paymentMethodResourceId'] # Added during Python3 migration
        
        # Execute primitive
        retCode = REST_UTIL.addGroupThreshold(RESTInst,
                groupId,
                thresholdId,
                resourceId=resourceId,
                threshName=lclDCT['name'],
                val=lclDCT['amount'],
                notify=notify,
                eventPass=lclDCT['eventPass'],
                now=lclDCT['lclStartTime'],
                recurringStart=lclDCT['recurringStart'],
                recurringStop=lclDCT['recurringStop'],
                queryType=lclDCT['groupQueryType'],
                virtualCreditLimitIsPercent=virtualCreditLimitIsPercent,
                isTemporaryCreditLimit=lclDCT['isTemporaryCreditLimit'],
                rechargeAmount=lclDCT['rechargeAmount'],
                rechargePaymentMethodResourceId=paymentMethodResourceId,
                apiEventData=lclDCT['customAttr'][6],
                )

        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdGroup_removegroupthreshold(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        resourceId = lclDCT['resourceId']
        # End of local variables setup.
       
       # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # If no resource ID passed in and a balance ID was passed in, then go find it
        if resourceId in [0, 'first', 'second', 'third', 'last'] and int(lclDCT['balanceId']) > 0:
                # Get the balance in question
                balance = PRIM.getBalanceData('group', groupId, lclDCT['balanceId'], resourceId, lclDCT['lclStartTime'], lclDCT['ACTION'], lclDCT['subQueryType'])
                
                # Get the resource ID
                resourceId = int(balance['ResourceId'])
        
        # If threshold ID is still non-numeric, then give it one more chance to translate, as the user may have used the CB name.
        # Since threshold names are not unique across balances, generic name translation can't be used.
        if not lclDCT['thresholdId'].isdigit(): (thresholdId, thresholdAmount, percentFlag) = PRIM.getThresholdId(lclDCT['balanceId'], lclDCT['thresholdId'])
        else: thresholdId = lclDCT['thresholdId'] # Added during Python3 migration
        
        # Execute primitive
        retCode = REST_UTIL.removeGroupThreshold(RESTInst,
                groupId,
                resourceId,
                thresholdId,
                now=lclDCT['lclStartTime'],
                queryType=lclDCT['groupQueryType'],
                isTemporaryCreditLimit=lclDCT['isTemporaryCreditLimit'],
                removeRechargeDataOnly=lclDCT['removeRechargeDataOnly'],
                removeThresholdOnly=lclDCT['removeThresholdOnly'],
                apiEventData=lclDCT['customAttr'][6],
                )

        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdGroup_querygroupcursor(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        # End of local variables setup.
        
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks'] and lclDCT['eventPass']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # May be here just to get the normal output file.  Check and skip this query if no storage is desired.
        if lclDCT['outputFileName'] and lclDCT['outputFileName'].strip():
             # Want to loop here until everything is retrieved
             qcDict = {}
             # Execute primitive
             (retCode, qcDict) = REST_UTIL.queryGroupCursor(RESTInst,
                groupId,
                eventPass=lclDCT['eventPass'],
                queryType=lclDCT['groupQueryType'],
                querySize = lclDCT['querySize'],
                now=lclDCT['lclStartTime'],
                )
                
             # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
             try:
                respData = str(retCode.printElementBasedXml())
             except:
                respData = str(retCode)
                
             # Write to where the caller wanted it to go
             prefix = 'queryGroupCursor Start:\n'
             suffix = 'queryGroupCursor End:  \n'
             retCode = prefix + str(respData) + suffix
                
             CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])

             # See if any cursor returned anything
             for cursor in ['AdminCursor', 'SubscriberMemberCursor', 'GroupMemberCursor']:
              if cursor in qcDict:
                # Get cursor value
                qc = str(qcDict[cursor])

                # Setup key loop parameters
                if      cursor == 'AdminCursor':                membershipType = CSVID.membershipTypeMapping['administrators']
                elif    cursor == 'SubscriberMemberCursor':     membershipType = CSVID.membershipTypeMapping['subscribers']
                else:                                           membershipType = CSVID.membershipTypeMapping['subgroups']

                # Want to loop here until everything is retrieved
                while qc != '0':
                        prefix = 'queryGroupCursor Start: Processing cursor ' + cursor + ' with qc = ' + str(qc) + '\n'
                        suffix = 'queryGroupCursor End:   Processing cursor ' + cursor + ' with qc = ' + str(qc) + '\n'
                        #print 'queryGroupCursor: Calling queryGroupMembership with params: ' + str(groupId) + ', ' + str(eventPass) + ', ' + str(groupQueryType) + ', ' + str(querySize) + ', ' + str(lclStartTime)  + ', ' + str(membershipType) + ', ' + str(qc)
                        # Execute primitive
                        # Execute primitive
                        (retCode, qc) = REST_UTIL.queryGroupMembership(RESTInst,
                                groupId,
                                eventPass=lclDCT['eventPass'],
                                queryType=lclDCT['groupQueryType'],
                                querySize = lclDCT['querySize'],
                                now=lclDCT['lclStartTime'],
                                membershipType=membershipType,
                                queryCursor=qc,
                                )
                        
                        # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
                        try:
                                respData = str(retCode.printElementBasedXml())
                        except:
                                respData = str(retCode)
                
                        # Write to where the caller wanted it to go
                        retCode = prefix + '\n' + str(respData) + suffix
                        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])

        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdGroup_querygroupmembership(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        # End of local variables setup.
        
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # May be here just to get the normal output file.  Check and skip this query if no storage is desired.
        if lclDCT['outputFileName'] and lclDCT['outputFileName'].strip():
          # Want to loop here until everything is retrieved
          qc = lclDCT['queryCursor']
          while qc != '0':
             #print 'queryGroupMembership: Calling queryGroupMembership with params: ' + str(groupId) + ', ' + str(eventPass) + ', ' + str(groupQueryType) + ', ' + str(querySize) + ', ' + str(lclStartTime)  + ', ' + str(membershipType) + ', ' + str(qc)
             # Execute primitive
             (retCode, qc) = REST_UTIL.queryGroupMembership(RESTInst,
                groupId,
                eventPass=lclDCT['eventPass'],
                queryType=lclDCT['groupQueryType'],
                querySize = lclDCT['querySize'],
                now=lclDCT['lclStartTime'],
                membershipType=lclDCT['membershipType'],
                queryCursor=qc,
                )
                
             # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
             try:
                respData = str(retCode.printElementBasedXml())
             except:
                respData = str(retCode)
                
             # Write to where the caller wanted it to go
             CSVQA.processDataToOutput(respData, lclDCT['outputFileName'])

        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
        
#==========================================================
def CmdGroup_querygroup(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        eventPass=lclDCT['eventPass']
        # End of local variables setup.
        
        # NOTE. If saveData specified then the query should succeed and the eventpass is tied to the saveData option.
        if lclDCT['saveData']: eventPass = True
        
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # If verbose set but no output file, then set to stdout
        if lclDCT['verbose'] in ['full', 'high'] and not lclDCT['outputFileName']: outputFileName = 'stdout'
        else: outputFileName = lclDCT['outputFileName'] # Added during Python3 migration
        
        # May be here just to get the normal output file.  Check and skip this query if no storage is desired.
        if lclDCT['saveData'] or (outputFileName and outputFileName.lower() != 'none'):
             # Execute primitive
             #retCode = REST_UTIL.queryGroup(RESTInst,
             retCode = REST_UTIL.queryGroup(RESTInst,
                groupId,
                eventPass=eventPass,
                queryType=lclDCT['groupQueryType'],
                querySize = lclDCT['querySize'],
                now=lclDCT['lclStartTime'],
                )

             # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
             try:
                respData = str(retCode.printElementBasedXml())
             except:
                respData = str(retCode)
                
             # If supposed to save data to variables then do that here
             if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, 'Group', respData)

             # if supposed to store output then write to where the caller wanted it to go.  Only if not saving data.
             elif outputFileName and outputFileName.lower() != 'none': CSVQA.processDataToOutput(respData, outputFileName)
        
        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdGroup_groupclearbalance(lclDCT, options, RESTInst, cmdLineInput):
        return CmdGroup_groupadjustbalance(lclDCT, options, RESTInst, cmdLineInput)

#==========================================================
def CmdGroup_groupadjustbalance(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        resourceId = lclDCT['resourceId']
        # End of local variables setup.
       
       # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Lots of reasons to adjust amount
        (amount, adjustType, resourceId) = PRIM.makeAmountAdjustments('group', groupId, lclDCT)
        
        # Execute primitive
        retCode = REST_UTIL.groupAdjustBalance(RESTInst,
                groupId,
                resourceId,
                adjustType,
                str(amount),
                lclDCT['reason'],
                queryType=lclDCT['groupQueryType'],
                info=lclDCT['info'],
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                endTimeExtensionOffsetUnit=lclDCT['balanceEndTimeExtensionOffsetUnit'],
                endTimeExtensionOffset=lclDCT['balanceEndTimeExtensionOffset'],
                endTime=lclDCT['balanceEndTime'],
                startTime=lclDCT['balanceStartTime'],
                creditLimitPolicy=lclDCT['creditLimitPolicy'],
                componentMeterId=lclDCT['componentMeterId'],
                executeMode=lclDCT['executeMode'],
                apiEventData=lclDCT['customAttr'][6],
                )
        
        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdGroup_grouptransferbalance(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        # End of local variables setup.
       
       # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Target Group should exist
        if lclDCT['modGroupId'] and lclDCT['modGroupId'] not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + lclDCT['modGroupId'] + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Target Subscriber should exist
        if lclDCT['modExternalId'] and lclDCT['modExternalId'] not in TRACK.subscriberTracking and not lclDCT['noChecks']:
                print('ERROR: subscriber with ID "' + lclDCT['modExternalId'] + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']:
             lclStartTime = lclDCT['startTime']

        # If no originating resource ID passed in and a balance ID was passed in, then go find it
        if resourceId in [0, 'first', 'second', 'third', 'last'] and int(lclDCT['balanceId']) > 0:
                # Get the balance in question
                balance = PRIM.getBalanceData('group', groupId, lclDCT['balanceId'], resourceId, lclStartTime, lclDCT['ACTION'], lclDCT['subQueryType'], returnExpiredOk=True)
                
                # Get the resource ID
                resourceId = int(balance['ResourceId'])

        # If no modified balance ID specified and a balance ID was input, then assume it's going to the same balance ID
        if (not lclDCT['modBalanceId']) and lclDCT['balanceId']: modBalanceId = lclDCT['balanceId']
        else: modBalanceId = lclDCT['modBalanceId'] # Added during Python3 migration
        
        # If no target resource ID passed in and a balance ID was passed in, then go find it
        if lclDCT['modResourceId'] in [0, 'first', 'second', 'third', 'last'] and int(modBalanceId) > 0:
           # Group vs sub target call differs
           if lclDCT['modExternalId']:
                # Get the balance in question
                balance = PRIM.getBalanceData('subscriber', lclDCT['modExternalId'], modBalanceId, lclDCT['modResourceId'], lclStartTime, lclDCT['ACTION'], lclDCT['modSubQueryType'], returnExpiredOk=True)
                
                # Get the resource ID
                modResourceId = int(balance['ResourceId'])
           else:
                # Get the balance in question
                balance = PRIM.getBalanceData('group', lclDCT['modGroupId'], modBalanceId, lclDCT['modResourceId'], lclStartTime, lclDCT['ACTION'], lclDCT['modGroupQueryType'], returnExpiredOk=True)
                
                # Get the resource ID
                modResourceId = int(balance['ResourceId'])
        else: modResourceId = lclDCT['modResourceId'] # Added during Python3 migration

        # Set the target query type
        if lclDCT['modExternalId']: targetQueryType = lclDCT['modSubQueryType']
        else:             targetQueryType = lclDCT['modGroupQueryType']

        # May be a formula here...  Need to ensure precision holds for the balance (error if not).  Probably should be lesserr of the two precisions...
        amount = str(PRIM.processAmountFormula('group', groupId, lclDCT['amount'], lclStartTime, lclDCT['ACTION'], precisionFlag = True, balanceId = lclDCT['balanceId'], queryType=lclDCT['groupQueryType']))

        # Execute primitive
        retCode = REST_UTIL.groupTransferBalance(RESTInst,
                queryValue = groupId,
                balanceResourceId = resourceId,
                amount = str(amount),
                queryType=lclDCT['groupQueryType'],
                amountIsPct=lclDCT['percentage'],
                targetSubscriberSearchData=lclDCT['modExternalId'],
                targetGroupSearchData=lclDCT['modGroupId'],
                targetQueryType = targetQueryType,
                targetBalanceResourceId = modResourceId,
                sourceIsEventInitiator = lclDCT['sourceIsEventInitiator'],
                creditFloorPolicy=lclDCT['creditFloorPolicy'],
                reason=lclDCT['reason'],
                info=lclDCT['info'],
                now=lclStartTime,
                eventPass=lclDCT['eventPass'],
                apiEventData=lclDCT['customAttr'][6],
                )
        
        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdGroup_grouptopupbalance(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        resourceId = lclDCT['resourceId']
        # End of local variables setup.
      
      # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # If no resource ID passed in and a balance ID was passed in, then go find it
        if resourceId in [0, 'first', 'second', 'third', 'last'] and int(lclDCT['balanceId']) > 0:
                # Get the balance in question
                balance = PRIM.getBalanceData('group', groupId, lclDCT['balanceId'], resourceId, lclDCT['lclStartTime'], lclDCT['ACTION'], lclDCT['groupQueryType'])
                
                # Get the resource ID
                resourceId = int(balance['ResourceId'])

        # May be a formula here...  Need to ensure precision holds for the balance (error if not).
        amount = str(PRIM.processAmountFormula('group', groupId, lclDCT['amount'], lclDCT['lclStartTime'], lclDCT['ACTION'], precisionFlag = True, balanceId = lclDCT['balanceId'], queryType=lclDCT['groupQueryType']))

        # Execute primitive
        retCode = REST_UTIL.groupTopupBalance(RESTInst,
                groupId,
                resourceId,
                amount,
                lclDCT['voucher'],
                queryType=lclDCT['groupQueryType'],
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                apiEventData=lclDCT['customAttr'][6],
                )

        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdGroup_modifygroupoffer(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        resourceId = lclDCT['resourceId']
        # End of local variables setup.
        
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Can provide groupOfferId or offerId for this command.
        # Map to offer ID.
        if (not lclDCT['offerId'] or lclDCT['offerId'].count('0')) and lclDCT['groupOfferId']: offerId = lclDCT['groupOfferId']
        else: offerId = lclDCT['offerId'] # Added during Python3 migration

        # If no resource ID passed in, then need to get using the external ID
        if resourceId in [0, 'first', 'second', 'third', 'last']:
                offerDict = PRIM.getOfferData('group', groupId, offerId, offerId[0], lclDCT['lclStartTime'], lclDCT['ACTION'], queryType=lclDCT['groupQueryType'], offerIsCatalog=True, resourceId=resourceId)

                # Get the resource ID
                resourceId = int(offerDict['ResourceId'])
                print('Group ' + str(groupId) + ' modifying offer with exernal ID = ' + offerId[0] + ', resource ID ' + str(resourceId))

        # If resource IDs passed in as a non-integer, then need to get its resource ID assuming they're offer external IDs
        param = 'offerCycleResourceId'
        value = lclDCT[param]
        if value and not (value.isdigit() and value != '0'):
                # Get resource ID data
                offerDict = PRIM.getOfferData('group', groupId, 0, value, lclStartTime, lclDCT['ACTION'], queryType=lclDCT['groupQueryType'], offerIsCatalog=True)
                
                # Get the resource ID
                lclDCT[param]  = int(offerDict['ResourceId'])
                
                print('Retrieved ' + param + ' = ' + offerDict['ResourceId'])
        
        # Build offer parameters
        try:    parameterList = PRIM.buildOfferParameters(CUST.custOfferParameterList, lclDCT)
        except: parameterList = None
        #print 'parameterList: ' + str(parameterList)
        
        # Convert datetime to time
        if lclDCT['offerCycleStartTime']: offerCycleStartTime = lclDCT['offerCycleStartTime'].split('T')[1][:8]
        else: offerCycleStartTime = lclDCT['offerCycleStartTime'] # Added during Python3 migration

        # Execute primitive
        retCode = REST_UTIL.groupOfferModify(RESTInst,
                groupId,
                resourceId=resourceId,
                startTime=lclDCT['offerStartTime'],
                endTime=lclDCT['offerEndTime'],
                attr=lclDCT['customAttr'][3],
                eventPass=lclDCT['eventPass'],
                queryType=lclDCT['groupQueryType'],
                cycleType=lclDCT['offerCycleType'],
                cycleResourceId=lclDCT['offerCycleResourceId'],
                cycleOffset=lclDCT['offerCycleOffset'],
                status=lclDCT['offerStatus'],
                cycleAlignmentDisabled=lclDCT['offerCycleAlignmentDisabled'],
                immediateChange=lclDCT['immediateChange'],
                now=lclDCT['lclStartTime'],
                apiEventData=lclDCT['customAttr'][6],
                cycleStartTime=offerCycleStartTime,
                cycleEndTime=lclDCT['offerCycleEndTime'],
                parameterList=parameterList,
                endTimeExtensionOffset = lclDCT['offerEndTimeExtensionOffset'],
                endTimeExtensionOffsetUnit = lclDCT['offerEndTimeExtensionOffsetUnit'],
                )

        # Update tracking data
        # NOTE:  if multiple resources were sent through, then need to fix the TRACK function...
        #if eventPass: TRACK.updateTrackingData(lclDCT['ACTION'], groupId = groupId, offerId = offerId, resourceId = resourceId[0])

        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdGroup_createfullgroup(lclDCT, testName, sessionId, line, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, repeatCount):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        # End of local variables setup.

        # Can't run this command with noChecks
        if lclDCT['noChecks']:
                print('ERROR: can\'t run command ' + lclDCT['ACTION'] + ' with noChecks parameter set')
                sys.exit('Error on command: ' + lclDCT['ACTION'])


        # Actions are done as follows:  (1) build a new command line, (2) invoke command line processing (recursive processing).
        # Steps for this are:
        # (a) create default admin subscriber if we're supposed to
        # (b) create group, assigning just created subscriber as admin
        # (c) add offers to the group
        # (d) add input subscribers
        # (e) add subs to the group, including offers that were in input command

        # Check if we're supposed to create a group admin
        if lclDCT['groupAddDefaultAdmin']:
                # *** Create admin subscriber.  NOTE: must have a device associated with it or else can't use the customer portal ***
                if lclDCT['useUser']:     newLine='createUserAndSubscriptionAndDevice;userId=next;externalId=next;deviceId=next;verbose=' + lclDCT['verbose'] + ';firstName=Group;lastName=Administrator;offerId=0;subOfferId=0'
                else:           newLine='addSubscriber;externalId=next;deviceId=next;verbose=' + lclDCT['verbose'] + ';firstName=Group;lastName=Administrator;offerId=0;subOfferId=0'
                if lclDCT['routingValue']: newLine += ';routingType=' + lclDCT['routingType'] + ';routingValue=' + lclDCT['routingValue']

                print(lclDCT['ACTION'] + ': newLine = ' + newLine)
                (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)
                # Set external ID string to "last"
                extId='last'
        else:
                # No admin - set string to absolute 0
                extId='a0'

        # **** Create the main group ****
        newLine='createGroup;externalId=' + extId + ';verbose=' + lclDCT['verbose'] + ';mark=' + lclDCT['mark'] + ';name=' + lclDCT['mark']
        if str(groupId).isdigit(): newLine += ';groupId=a' + groupId
        else:                      newLine += ';groupId=' + groupId
        if lclDCT['groupReAuthPreference']: newLine += ';groupReAuthPreference=' + lclDCT['groupReAuthPreference']
        if lclDCT['profileId']: newLine += ';profileId=' + lclDCT['profileId']
        if lclDCT['dateOffset']: newLine += ';dateOffset=' + lclDCT['dateOffset']
        
        # Use time zone if group-specific not set
        if not lclDCT['groupTimeZone'] and lclDCT['timeZone']: groupTimeZone = lclDCT['timeZone']
        else: groupTimeZone = lclDCT['groupTimeZone'] # Added during Python3 migration
        if groupTimeZone: newLine += ';groupTimeZone=' + groupTimeZone
        if lclDCT['routingValue']: newLine += ';routingType=' + lclDCT['routingType'] + ';routingValue=' + lclDCT['routingValue']
                
        # Set the tier for this group.  Use pre-set global for this.
        # In the future, one can define their own tier hierarchy names.
        if lclDCT['tier']: newLine += ';tier=' + lclDCT['tier'][0]
        else:    newLine += ';tier=' + QAUTILS.groupTiers[int(lclDCT['level'])]

        print(lclDCT['ACTION'] + ': newLine = ' + newLine)
        (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)

        # Can provide groupOfferId or offerId for this command.
        # Map to offer ID.
        if (not lclDCT['offerId'] or lclDCT['offerId'].count('0')) and lclDCT['groupOfferId']: offerId = lclDCT['groupOfferId']
        else: offerId = lclDCT['offerId'] # Added during Python3 migration

        # *** Add offers ***
        if offerId and not offerId.count('0'):
            newLine='groupSubscribeToOffer;groupId=last;verbose=' + lclDCT['verbose']
            offer = PRIM.convertPythonListToToolListFormat(offerId)
            newLine += ';offerId=' + offer

            # If any custom parameters need to pass through, set them here
            if hasattr(CUST, "customParams"): CUST.customParams(newLine, 'group', lclDct=lclDCT)

            # If group owner specified, then add/override here
            #if groupOwner: newLine += ';Owner=' + groupOwner

            # Copy offer start/end times
            if lclDCT['offerStartTime']: newLine += ';offerStartTime=' + str(lclDCT['offerStartTime'])
            if lclDCT['offerEndTime']:   newLine += ';offerEndTime='   + str(lclDCT['offerEndTime'])

            # Debug output
            print(lclDCT['ACTION'] + ': newLine = ' + newLine)
            (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)
           # newLine +=';offerId='
           # # OfferId is a list.  Add individually.  Figure out if we can add all at once...
           # for offer in offerId:
#               xnewLine = newLine + str(offer)
#               (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, xnewLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)

        # *** Process Subscribers.  Create and then add to the group. ***
        for i in range(int(lclDCT['members'][0])):
                # Create the sub; assume no offers to add here (will be overwritten below)
                if lclDCT['useUser']:     newLine='createUserAndSubscriptionAndDevice;userId=next;externalId=next;deviceId=next;verbose=' + lclDCT['verbose'] + ';offerId=0;subOfferId=0'
                else:           newLine='addSubscriber;externalId=next;deviceId=next;offerId=0;subOfferId=0;verbose=' + lclDCT['verbose']
                if lclDCT['routingValue']: newLine += ';routingType=' + lclDCT['routingType'] + ';routingValue=' + lclDCT['routingValue']

                # If any custom parameters need to pass through, set them here
                if hasattr(CUST, "customParams"): CUST.customParams(newLine, 'sub', lclDct=lclDCT)

                if lclDCT['profileId']: newLine += ';profileId=' + lclDCT['profileId']
                
                # Use time zone if group-specific not set
                if not lclDCT['subTimeZone'] and lclDCT['timeZone']: subTimeZone = lclDCT['timeZone']
                if lclDCT['subTimeZone']: newLine += ';subTimeZone=' + lclDCT['subTimeZone']
                
                # If subscriber owner specified, then add here
                #if subOwner: newLine += ';Owner=' + subOwner

                # Pass the mark through to subscribers, appending text so it's known what the mark will be
                if lclDCT['mark']:
                        newLine += ';mark=' + lclDCT['mark'] + '_S' + str(i)
                print(lclDCT['ACTION'] + ': newLine = ' + newLine)
                (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)

                # add to the group
                if lclDCT['useUser']:     newLine='addSubscriptionToGroup;externalId=last;verbose=' + lclDCT['verbose']
                else:           newLine='addSubscriberToGroup;externalId=last;verbose=' + lclDCT['verbose']
                if str(groupId).isdigit(): newLine += ';groupId=last'
                else:                      newLine += ';groupId=' + groupId
                print(lclDCT['ACTION'] + ': newLine = ' + newLine)
                (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)

                # Add as admin if requested
                if lclDCT['allAdmins']:
                        if lclDCT['useUser']:     newLine='addAdminToGroup;externalId=last;verbose=' + lclDCT['verbose']
                        else:           newLine='addAdminToGroup;externalId=last;verbose=' + lclDCT['verbose']
                        if str(groupId).isdigit(): newLine += ';groupId=last'
                        else:                      newLine += ';groupId=' + groupId
                        print(lclDCT['ACTION'] + ': newLine = ' + newLine)
                        (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)

                # Purchase offers after adding to the group, in case these are BYOB offers
                if lclDCT['subOfferId'] and not lclDCT['subOfferId'].count('0'):
                        offer = PRIM.convertPythonListToToolListFormat(lclDCT['subOfferId'])
                        if lclDCT['useUser']:     newLine = 'subscriptionSubscribeToOffer;externalId=last;offerId=' + offer + ';verbose=' + lclDCT['verbose']
                        else:           newLine = 'subscribeToOffer;externalId=last;offerId=' + offer + ';verbose=' + lclDCT['verbose']

                        # Copy offer start/end times
                        if lclDCT['offerStartTime']: newLine += ';offerStartTime=' + str(lclDCT['offerStartTime'])
                        if lclDCT['offerEndTime']:   newLine += ';offerEndTime='   + str(lclDCT['offerEndTime'])

                        print(lclDCT['ACTION'] + ': newLine = ' + newLine)
                        (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)

#               newLine='querySubscriber;externalId=last;outputFileName=None;verbose=' + lclDCT['verbose']
#               print lclDCT['ACTION'] + ': newLine = ' + newLine
#               (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)

        # Can't query group, as we never got the actual ID (used "next")...
        queryValue = None
        queryType = None
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdGroup_createenterprise(lclDCT, testName, sessionId, line, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, repeatCount):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        tier = lclDCT['tier']
        hierarchy = lclDCT['hierarchy']
        members = lclDCT['members']
        # End of local variables setup.
        
        # Can't run this command with noChecks
        if lclDCT['noChecks']:
                print('ERROR: can\'t run command ' + lclDCT['ACTION'] + ' with noChecks parameter set')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Sanity check that the hierarchy and members lists are the same length
        if len(hierarchy) != len(members):
                print('Error: Command = ' + lclDCT['ACTION'] + ' length of the hierarchy/members arrays are not equal: ' + str(len(hierarchy)) + '/' + str(len(members)))
                sys.exit('Done')
        # Algorithm for this is:
        # 1) create the top level group
        # 2) For each subsequent level, inject a create hierarchy command for each desired sub-group
        # 2a) Add the sub-group to the group just created

        # Error checking.  Top-most item should always be 1. Failure if not.
        if int(hierarchy[0]) != 1:
                print('Error:  Command = ' + lclDCT['ACTION'] + ' Always start a hierarchy with length 1.  Input value is: ' + str(hierarchy[0]))
                sys.exit('Done')

        if not lclDCT['mark']:
                print('Error:  Command = ' + lclDCT['ACTION'] + ' requires a mark')
                sys.exit('Done')

        # Set local verbose mode here (so easy to change)
        _verbose='none'

        # Create command to pass through
        newLine='createFullGroup;verbose=' + _verbose + ';members=' + members[0] + ';mark=' + lclDCT['mark'] + ';groupAddDefaultAdmin=' + str(lclDCT['groupAddDefaultAdmin'])
        if str(groupId).isdigit(): newLine += ';groupId=a' + groupId
        else:                      newLine += ';groupId=' + groupId
        
        if lclDCT['groupReAuthPreference']: newLine += ';groupReAuthPreference=' + lclDCT['groupReAuthPreference']
        if lclDCT['profileId']: newLine += ';profileId=' + lclDCT['profileId']
        if lclDCT['dateOffset']: newLine += ';dateOffset=' + lclDCT['dateOffset']
        if lclDCT['routingValue']: newLine += ';routingType=' + lclDCT['routingType'] + ';routingValue=' + lclDCT['routingValue']
        
        # Use time zone if group-specific not set
        if not lclDCT['groupTimeZone'] and lclDCT['timeZone']: groupTimeZone = lclDCT['timeZone']
        else: groupTimeZone = lclDCT['groupTimeZone'] # Added during Python3 migration
        if groupTimeZone: newLine += ';groupTimeZone=' + groupTimeZone
                
        # See if any offers to purchase
        if lclDCT['groupOfferId']:
            # Already converted from single item to list, so need to convert back...
            offer = PRIM.convertPythonListToToolListFormat(lclDCT['groupOfferId'])
            newLine += ';groupOfferId=' + offer
            #print 'offerID pre-conversion = ' + str(offerId) + '; offer post conversion = ' + str(offer)
        elif lclDCT['offerId'] and not lclDCT['offerId'].count('0'):
            # Already converted from single item to list, so need to convert back...
            offer = PRIM.convertPythonListToToolListFormat(lclDCT['offerId'])
            newLine += ';groupOfferId=' + offer
            #print 'offerID pre-conversion = ' + str(offerId) + '; offer post conversion = ' + str(offer)
        else:
            newLine += ';groupOfferId=None'

        # Always clear out offerId at this point
        newLine += ';offerId=0'

        # Subscribers offers must be in subOfferId for this command
        if lclDCT['subOfferId']:
            # Already converted from single item to list, so need to convert back...
            offer = PRIM.convertPythonListToToolListFormat(lclDCT['subOfferId'])
            newLine += ';subOfferId=' + offer
        else:
            newLine += ';subOfferId=None'

        # Set the tier for this group.  Use pre-set global for this.
        # In the future, one can define their own tier hierarchy names.
        if tier: newLine += ';tier=' + tier[0]
        else:    newLine += ';tier=' + QAUTILS.groupTiers[int(lclDCT['level'])]

        # Copy allAdmins parameter
        newLine += ';allAdmins=' + str(lclDCT['allAdmins'])

        # Copy offer start/end times
        if lclDCT['offerStartTime']: newLine += ';offerStartTime=' + str(lclDCT['offerStartTime'])
        if lclDCT['offerEndTime']:   newLine += ';offerEndTime='   + str(lclDCT['offerEndTime'])

        # If any custom parameters need to pass through, set them here
        if hasattr(CUST, "customParams"): CUST.customParams(newLine, 'group', lclDct=lclDCT)
        if hasattr(CUST, "customParams"): CUST.customParams(newLine, 'sub', lclDct=lclDCT)

        # If subscriber or group owner specified, then add here
        #if subOwner:   newLine += ';subOwner=' + subOwner
        #if groupOwner: newLine += ';groupOwner=' + groupOwner

        # Invoke group creation
        print(lclDCT['ACTION'] + ': newLine = ' + newLine)
        (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, lclDCT['level'])

        # Now remove the first list entry of the hierarchy and members, as we're about to call ourselves recursively
        print('hierarchy = ' + str(hierarchy))
        print('members = ' + str(members))
        
        # Always have entry 0 for these arrays
        del hierarchy[0]
        del members[0]
        
        # Tier is optional, so process
        if tier:
                # Delete the tier just processed
                del tier[0]
                
                # If more tiers specified, then convert
                if len(tier): newTier = PRIM.convertPythonListToToolListFormat(tier)
                else:         newTier = None
        else:   newTier = None
        # If anything left, then want to call ourselves recursively
        if len(hierarchy):
           # Increase the level
           level = str(int(lclDCT['level']) + 1)

           # Repeat this for every level
           for i in range(int(hierarchy[0])):
                # Always set hierarchy first element to one, as createFullGroup expects there to be only one top level group
                hierarchy[0]='1'

                # Convert lists to tool format
                newHierarchy=PRIM.convertPythonListToToolListFormat(hierarchy)
                newMembers=PRIM.convertPythonListToToolListFormat(members)

                # Build the command.  Explicitly say no group offers
                newLine='createEnterprise;offerId=0;groupOfferId=None;hierarchy=' + newHierarchy + ';members=' + newMembers + ';level=' + level + ';verbose=' + _verbose + ';groupAddDefaultAdmin=' + str(lclDCT['groupAddDefaultAdmin']) + ';groupId=next'
                if lclDCT['groupReAuthPreference']: newLine += ';groupReAuthPreference=' + lclDCT['groupReAuthPreference']

                # Append subscriber offers if specified
                if lclDCT['subOfferId']:
                    offer = PRIM.convertPythonListToToolListFormat(lclDCT['subOfferId'])
                    newLine += ';subOfferId=' + offer
                else:
                    newLine += ';subOfferId=None'

                # Append to mark.  Ideally need the level...
                newMark = lclDCT['mark'] + '_L' + level + '_G' + str(i)
                newLine += ';mark=' + newMark
                if lclDCT['routingValue']: newLine += ';routingType=' + lclDCT['routingType'] + ';routingValue=' + lclDCT['routingValue']

                # Set the tier for this group.  Use pre-set global for this.
                # In the future, one can define their own tier hierarchy names.
                if newTier: newLine += ';tier=' + newTier
                else:       newLine += ';tier=' + QAUTILS.groupTiers[int(level)]

                # Copy allAdmins parameter
                newLine += ';allAdmins=' + str(lclDCT['allAdmins'])

                # If any custom parameters need to pass through, set them here
                if hasattr(CUST, "customParams"): CUST.customParams(newLine, 'group', lclDct=lclDCT)
                if hasattr(CUST, "customParams"): CUST.customParams(newLine, 'sub', lclDct=lclDCT)

                # Ready or not...
                print(lclDCT['ACTION'] + ': newLine = ' + newLine)
                (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)

                # Add the just created group to the parent group
                newLine='addSubGroupToGroup;groupId=' + lclDCT['mark'] + ';subGroupId=' + newMark + ';verbose=' + _verbose
                print(lclDCT['ACTION'] + ': newLine = ' + newLine)
                (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)

                # Bump group counter
                i += 1

        # Query the top most group, using input verbose value.  Default
        newLine='queryGroup;groupId=' + lclDCT['mark'] + ';outputFileName=None' + ';verbose=' + lclDCT['verbose'] + ';querySize=' + lclDCT['querySize']
        print(lclDCT['ACTION'] + ': newLine = ' + newLine)
        (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)

        # Query nothing
        queryValue = queryType = None
        queryType = lclDCT['groupQueryType']

        return (queryType, queryValue)

#==========================================================
def CmdGroup_groupwaitforstate(lclDCT, options, RESTInst, cmdLineInput):
        return  PRIM.waitforstate(lclDCT, options, RESTInst, cmdLineInput, target='group')


#==========================================================
def CmdGroup_groupqueryeventstore(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        eventPass = lclDCT['eventPass']
        # End of local variables setup.
       
       # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Call primitive.
        # Reset/restore event pass as we're not checking the API call, but rather the results.
        lclDCT['eventPass'] = True
        respData = CSVEVENTS.checkEvents('group', lclDCT['groupQueryType'], groupId, lclDCT, RESTInst, lclDCT['lclStartTime'], lclDCT['testName'])
        lclDCT['eventPass'] = eventPass
        
        # Write to where the caller wanted it to go
        if eventPass:
                # Make sure we found something
                if not respData.count("List"):
                        print('ERROR: query did not return any notifications or events')
                        print(respData)
                        sys.exit('Exiting due to errors')
                
                # If user requested a specific string to check for, then validate that here
                if lclDCT['eventStringToCheckFor'] and not respData.count(lclDCT['eventStringToCheckFor']):
                        print('ERROR: query did not return expected string: "' + lclDCT['eventStringToCheckFor'] + '"')
                        print(respData)
                        sys.exit('Exiting due to errors')
                
                # See if user wants viewEventStore output
                if lclDCT['outputFileName'].lower() == 'view':
                        # Call viewEventStore.
                        # Different options depending on query type
                        if   lclDCT['groupQueryType'].lower() == 'externalid': viewOption = '-g '
                        elif lclDCT['groupQueryType'].lower() == 'objectid': viewOption = '--goid '
                        else:
                                print('NOTE: groupQueryType = ' + str(lclDCT['groupQueryType']) + ', which doesn\'t translate to a viewEventStore input')
                                viewOption = None

                        # Report if we know what to do
                        if viewOption:
                                cmd = 'viewEventStore.py ' + viewOption + str(groupId) + ' --outputFile ' + str(lclDCT['outputFileName'])
                                if lclDCT['showGl']: cmd += ' --showGl'
                                print('Running command: ' + cmd)
                                print(QAUTILS.runCmd(cmd) + '\n\n')
                else:   CSVQA.processDataToOutput(respData, lclDCT['outputFileName'])

        else:
                # Make sure we didn't found something
                if respData.count("List"):
                        print('ERROR: query returned notifications or events and none were expected')
                        print(respData)
                        sys.exit('Exiting due to errors')
        
        # Query None
        queryValue = queryType = None
        
        return (queryType, queryValue)
        
#==========================================================
def CmdGroup_groupcanceloffer(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        resourceId = lclDCT['resourceId']
        # End of local variables setup.
      
      # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Set the ofer start time to whatever the local test tool time if it's not specified via the input.
        if lclDCT['offerEndTime'] == None:
                if lclDCT['futureTime']:  offerEndTime = lclDCT['futureTime']
                else:                     offerEndTime = lclDCT['lclStartTime']
#        else: lclStartTime = offerEndTime
        else: offerEndTime = lclDCT['offerEndTime'] # Added during Python3 migration

        # Can provide groupOfferId or offerId for this command.
        # Map to offer ID.
        if (not lclDCT['offerId'] or lclDCT['offerId'].count('0')) and lclDCT['groupOfferId']: offerId = lclDCT['groupOfferId']
        else: offerId = lclDCT['offerId'] # Added during Python3 migration

        # If future time, then need to retrieve the taskId of the schedueld task
        if lclDCT['futureTime']:
          # Retrieve future task ID.
          # NOTE:  at the moment only one future task ID is stored per external ID.  Will enhance this in the future.
          taskId = TRACK.groupTracking[groupId]['taskId']
          #print 'Retrieved Task: ' + str(taskId)

          # If no task and expecting a failure, then use a dummy task Id (negative testing)
          if not taskId and not lclDCT['eventPass']:
                taskId = '0-1-2-3'
                print('Created a dummy value for a taskId, for negative testing: ' + taskId)
        else:
          # No taskId in this scenario
          taskId = None

          # If no resource ID passed in, then need to get using the external ID
          if lclDCT['futureTime']: resourceId = None
          elif resourceId in [0, 'first', 'second', 'third', 'last']:
                for idx in range(len(offerId)):
                        offerDict = PRIM.getOfferData('group', groupId, 0, offerId[idx], lclDCT['lclStartTime'], lclDCT['ACTION'], queryType=lclDCT['groupQueryType'], offerIsCatalog=lclDCT['offerIsCatalog'], resourceId=resourceId)
                        
                        # Get the resource ID
                        resourceId += str(offerDict['ResourceId']) + '@'
                        
                # Remove trailing list separator char
                resourceId = resourceId[:-1]
                
          # Convert resource ID to a list
          resourceId = resourceId.split('@')
        
        # What to print depends on catalog vs offer...
        if lclDCT['offerIsCatalog']:
                offertype = 'catalog'
        else:
                offertype = 'legacy'
        print('Group = ' + groupId + ' is unsubscribing from ' + offertype + ' offer(s) with resource IDs' + str(resourceId) + ' with end time ' + str(offerEndTime))

        # Execute primitive
        if lclDCT['cancelInfo']:
         retCode,response = REST_UTIL.groupCancelOffer(RESTInst,
                groupId=groupId,
                queryType=lclDCT['groupQueryType'],
                resourceId=resourceId,
                eventPass=lclDCT['eventPass'],
                executeMode=lclDCT['executeMode'],
                reason=lclDCT['reason'],
                info=lclDCT['info'],
                grantCancelProrationType=lclDCT['grantProrationType'],
                chargeCancelProrationType=lclDCT['chargeProrationType'],
                cancelType=lclDCT['cancelType'],
                cancelInfo=lclDCT['cancelInfo'],
                contractCancelMode=lclDCT['contractCancelMode'],
                debtCancellationMode=lclDCT['debtCancellationMode'],
                now=offerEndTime,
                apiEventData=lclDCT['customAttr'][6],
                )
         
         # Print response
         print('groupCancelOffer Response: ' + response)
        
        else:
         retCode = REST_UTIL.groupCancelOffer(RESTInst,
                groupId=groupId,
                queryType=lclDCT['groupQueryType'],
                resourceId=resourceId,
                eventPass=lclDCT['eventPass'],
                executeMode=lclDCT['executeMode'],
                reason=lclDCT['reason'],
                info=lclDCT['info'],
                grantCancelProrationType=lclDCT['grantProrationType'],
                chargeCancelProrationType=lclDCT['chargeProrationType'],
                cancelType=lclDCT['cancelType'],
                cancelInfo=lclDCT['cancelInfo'],
                contractCancelMode=lclDCT['contractCancelMode'],
                debtCancellationMode=lclDCT['debtCancellationMode'],
                now=offerEndTime,
                apiEventData=lclDCT['customAttr'][6],
                )
        
        # Update tracking data
        if lclDCT['eventPass']: TRACK.updateTrackingData(lclDCT['ACTION'], offerId = offerId, groupId = groupId, resourceId = resourceId, taskId=taskId)

        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdGroup_groupcheckpurchaseditemcyclealignment(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        # End of local variables setup.
        
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Can provide subOfferId or offerId for this command.
        # Map to offer ID.
        if (not lclDCT['offerId'] or lclDCT['offerId'].count('0')) and lclDCT['groupOfferId']: offerId = lclDCT['groupOfferId']
        else: offerId = lclDCT['offerId'] # Added during Python3 migration

        '''
        # If no resource ID passed in, then need to get using the external ID
        if resourceId == 0:
                offerDict = PRIM.getOfferData('subscriber', externalId, resourceId, offerId[0], lclStartTime, lclDCT['ACTION'], queryType=subQueryType, offerIsCatalog=True)

                # Get the resource ID
                resourceId = int(offerDict['ResourceId'])
        '''
        
        # If resource IDs passed in as a non-integer, then need to get its resource ID assuming they're offer external IDs
        param = 'offerCycleResourceId'
        value = lclDCT[param]
        if value and not (value.isdigit() and value != '0'):
                # Get resource ID data
                offerDict = PRIM.getOfferData('group', groupId, 0, value, lclStartTime, lclDCT['ACTION'], queryType=lclDCT['groupQueryType'], offerIsCatalog=True)
                
                # Get the resource ID
                lclDCT[param]  = int(offerDict['ResourceId'])
                
                print('Retrieved ' + param + ' = ' + offerDict['ResourceId'])
        
        print('Group ' + str(groupId) + ' is checking purchased item cycle alignment for offer "' + str(offerId) + '", resource ID ' + str(lclDCT['offerCycleResourceId']))
        
        # Execute primitive
        response = REST_UTIL.groupCheckPurchasedItemCycleAlignment(RESTInst,
                groupId,
                queryType=lclDCT['groupQueryType'],
                offerResourceId=lclDCT['offerCycleResourceId'],
                eventPass=lclDCT['eventPass'],
                now=lclDCT['lclStartTime'],
                )
        
        print("Response:")
        print(response)
        
        # Query Nothing
        queryValue = None
        queryType = None
        
        return (queryType, queryValue)
        
#==========================================================
def CmdGroup_groupcontractdebtpayment(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        # End of local variables setup.
       
       # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']

        # If no resource ID passed in, then need to get using the external ID
        if resourceId == 0:
                offerDict = PRIM.getOfferData('group', groupId, resourceId, lclDCT['offerId'][0], lclStartTime, lclDCT['ACTION'], queryType=lclDCT['groupQueryType'], offerIsCatalog=True)

                # Get the resource ID
                resourceId = int(offerDict['ResourceId'])

        print('Group ' + str(groupId) + ' is paying debt for offer "' + str(lclDCT['offerId']) + '", resource ID ' + str(resourceId))

        # Execute primitive
        retCode = REST_UTIL.groupContractDebtPayment(RESTInst,
                groupId,
                resourceId,
                str(lclDCT['amount']),
                queryType=lclDCT['groupQueryType'],
                reason=lclDCT['reason'],
                info=lclDCT['info'],
                now=lclStartTime,
                eventPass=lclDCT['eventPass'],
                paymentMethodResourceId=lclDCT['paymentMethodResourceId'],
                paymentGatewayId=lclDCT['paymentGatewayId'],
                chargeMethod=lclDCT['chargeMethod'],
                chargeMethodAttr=lclDCT['chargeMethodAttr'],
                nonce=lclDCT['nonce'],
                apiEventData=lclDCT['customAttr'][6],
                )

        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']

        return (queryType, queryValue)

#==========================================================
def CmdGroup_querygroupwallet(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        lclStartTime = lclDCT['lclStartTime']
        # End of local variables setup.
       
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']:
             lclStartTime = lclDCT['startTime']

        # May be here just to get the normal output file.  Check and skip this query if so
        if lclDCT['saveData'] or (lclDCT['outputFileName'] and lclDCT['outputFileName'].lower() != 'none'):
             # Execute primitive
             retCode = REST_UTIL.queryGroupWallet(RESTInst,
                groupId,
                eventPass=lclDCT['eventPass'],
                queryType=lclDCT['groupQueryType'],
                now=lclStartTime
                )

             # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
             try:
                respData = str(retCode.printElementBasedXml())
             except:
                respData = str(retCode)
                
             # If supposed to save data to variables then do that here
             if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, 'Subscriber', respData)
             
             # if supposed to store output then write to where the caller wanted it to go.  nly if not saving data.
             elif lclDCT['outputFileName'] and lclDCT['outputFileName'].lower() != 'none': CSVQA.processDataToOutput(respData, lclDCT['outputFileName'])

        # Query group
        if lclDCT['eventPass']: queryValue = groupId
        else:  queryValue = None
        queryType = lclDCT['groupQueryType']

        return (queryType, queryValue)

#==========================================================
def CmdGroup_groupcontractprinciplepayment(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        # End of local variables setup.
              
       # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']
        
        # If no resource ID passed in, then need to get using the external ID
        if resourceId == 0:
                if lclDCT['offerId'][0] == None:
                        print('ERROR: Need to specify an offer')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
                
                offerDict = PRIM.getOfferData('group', groupId, resourceId, lclDCT['offerId'][0], lclStartTime, lclDCT['ACTION'], queryType=lclDCT['groupQueryType'], offerIsCatalog=True)
                
                # Get the resource ID
                resourceId = int(offerDict['ResourceId'])
        
        print('Group ' + str(groupId) + ' is paying debt for offer "' + str(lclDCT['offerId']) + '", resource ID ' + str(resourceId))
        
        # Execute primitive
        retCode = REST_UTIL.groupMakeFinanceContractPrincipalPayment(RESTInst,
                groupId,
                resourceId,
                lclDCT['groupQueryType'],
                lclDCT['isPayoff'],
                str(lclDCT['amount']),
                paymentMethodResourceId=lclDCT['paymentMethodResourceId'],
                paymentGatewayId=lclDCT['paymentGatewayId'],
                chargeMethod=lclDCT['chargeMethod'],
                nonce=lclDCT['nonce'],
                chargeMethodAttr=lclDCT['chargeMethodAttr'],
                reason=lclDCT['reason'],
                info=lclDCT['info'],
                now=lclStartTime,
                eventPass=lclDCT['eventPass'],
                apiEventData=lclDCT['customAttr'][6],
                )
        
        # Query group
        if lclDCT['eventPass']: queryValue = groupId
        else:  queryValue = None
        queryType = lclDCT['groupQueryType']
        
        return (queryType, queryValue)

#==========================================================
def CmdGroup_groupadjustrolloverbalance(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        # End of local variables setup.
       
       # Set target
        target = 'group'
        
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Also want to update the local time if we're bumping up the time (as all command
        # times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']

        # Lots of reasons to adjust amount
        #print 'Subscriber adjusting balance ID ' + str(balanceId) + ', with resource ID ' + str(resourceId)
        (amount, adjustType, resourceId) = PRIM.makeAmountAdjustments(target, lclDCT['externalId'], lclDCT)

        # If interval needed, then get it
        if not lclDCT['balanceIntervalId'].isdigit():
                balanceData = PRIM.getBalanceRolloverData(target, groupId, lclDCT['balanceId'], resourceId, queryType='ExternalId', lclStartTime=lclStartTime)
                pprint.pprint(balanceData)

                # Get numbetr of entries
                numEntries = len(balanceData)

                # OK; we have the data.  Now get the desired interval.
                # May be words first or last, or a negative amount for th edesired period backwards.
                if   lclDCT['balanceIntervalId'].lower() == 'last':  index = str(numEntries)
                elif lclDCT['balanceIntervalId'].lower() == 'first': index = '1'
                else:                                                index = -1 * int(lclDCT['balanceIntervalId'])

                # Now get the IntervalId from the data
                balanceIntervalId = balanceData[index]['IntervalId']

        # Execute primitive
        retCode = REST_UTIL.groupAdjustRolloverBalance(RESTInst,
                queryValue=groupId,
                balanceResourceId=resourceId,
                balanceIntervalId=balanceIntervalId,
                adjustType=adjustType,
                amount=str(amount),
                reason=lclDCT['reason'],
                queryType=lclDCT['groupQueryType'],
                info=lclDCT['info'],
                now=lclStartTime,
                eventPass=lclDCT['eventPass'],
                remainingRolloverCounter=lclDCT['remainingRolloverCounter'],
                apiEventData=lclDCT['customAttr'][6],
                )

        # Query group
        if lclDCT['eventPass']: queryValue = groupId
        else:  queryValue = None
        queryType = lclDCT['groupQueryType']
        
        return (queryType, queryValue)

#==========================================================
def CmdGroup_creategroupbillingprofile(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        # End of local variables setup.
       
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Execute primitive
        retCode = REST_UTIL.createGroupBillingProfile(RESTInst,
                groupId,
                profileId=lclDCT['profileId'],
                startTime=lclDCT['startTime'],
                dateOffset=lclDCT['dateOffset'],
                queryType=lclDCT['groupQueryType'],
                eventPass=lclDCT['eventPass'],
                )
        
        # Query group
        if lclDCT['eventPass']: queryValue = groupId
        else:  queryValue = None
        queryType = lclDCT['groupQueryType']

        return (queryType, queryValue)

#==========================================================
def CmdGroup_groupaddrechargeschedule(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        lclStartTime = lclDCT['lclStartTime']
        # End of local variables setup.
       
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']
        
        print('Group ' + str(groupId) + ' is adding a recharge schedule')
        
        # Execute primitive
        retCode = REST_UTIL.groupAddRechargeSchedule(RESTInst,
                groupId,
                lclDCT['rechargeTime'],
                lclDCT['groupQueryType'],
                lclDCT['periodType'],
                lclDCT['periodCoefficient'],
                cycleTimeOfDay=lclDCT['offerCycleOffset'],
                cycleOffset=lclDCT['offerCycleOffset'],
                amount=str(lclDCT['amount']),
                paymentMethodResourceId=lclDCT['paymentMethodResourceId'],
                endTimeExtensionOffsetUnit=lclDCT['endTimeRelativeOffsetUnit'],
                endTimeExtensionOffset=lclDCT['endTimeRelativeOffset'],
                scheduledRechargeNotificationProfileId=lclDCT['elementId'],
                now=lclStartTime,
                eventPass=lclDCT['eventPass'],
                executeMode=lclDCT['executeMode'],
                apiEventData=lclDCT['customAttr'][6],
                )
        # Query group
        if lclDCT['eventPass']: queryValue = groupId
        else:  queryValue = None
        queryType = lclDCT['groupQueryType']
        
        return (queryType, queryValue)

#==========================================================
def CmdGroup_groupmodifyrechargeschedule(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        lclStartTime = lclDCT['lclStartTime']
        # End of local variables setup.
       
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']
        
        print('Group ' + str(groupId) + ' is modifying a recharge schedule')
        
        # Execute primitive
        retCode = REST_UTIL.groupModifyRechargeSchedule(RESTInst,
                groupId,
                lclDCT['rechargeTime'],
                lclDCT['groupQueryType'],
                lclDCT['periodType'],
                lclDCT['periodCoefficient'],
                cycleTimeOfDay=lclDCT['offerCycleOffset'],
                cycleOffset=lclDCT['offerCycleOffset'],
                amount=str(lclDCT['amount']),
                paymentMethodResourceId=lclDCT['paymentMethodResourceId'],
                endTimeExtensionOffsetUnit=lclDCT['endTimeRelativeOffsetUnit'],
                endTimeExtensionOffset=lclDCT['endTimeRelativeOffset'],
                scheduledRechargeNotificationProfileId=lclDCT['elementId'],
                now=lclStartTime,
                eventPass=lclDCT['eventPass'],
                executeMode=lclDCT['executeMode'],
                apiEventData=lclDCT['customAttr'][6],
                )
        # Query group
        if lclDCT['eventPass']: queryValue = groupId
        else:  queryValue = None
        queryType = lclDCT['groupQueryType']
        
        return (queryType, queryValue)

#==========================================================
def CmdGroup_groupremoverechargeschedule(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        lclStartTime = lclDCT['lclStartTime']
        # End of local variables setup.
               
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']
        
        print('Group ' + str(groupId) + ' is modifying a recharge schedule')
        
        # Execute primitive
        retCode = REST_UTIL.groupRemoveRechargeSchedule(RESTInst,
                groupId,
                lclDCT['groupQueryType'],
                now=lclStartTime,
                eventPass=lclDCT['eventPass'],
                executeMode=lclDCT['executeMode'],
                apiEventData=lclDCT['customAttr'][6],
                )
        # Query group
        if lclDCT['eventPass']: queryValue = groupId
        else:  queryValue = None
        queryType = lclDCT['groupQueryType']
        
        return (queryType, queryValue)

#==========================================================
def CmdGroup_groupqueryrechargeschedule(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        lclStartTime = lclDCT['lclStartTime']
        # End of local variables setup.
               
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']
        
        print('Group ' + str(groupId) + ' is modifying a recharge schedule')
        
        # Execute primitive
        retCode = REST_UTIL.groupQueryRechargeSchedule(RESTInst,
                groupId,
                lclDCT['groupQueryType'],
                now=lclStartTime,
                eventPass=lclDCT['eventPass'],
                executeMode=lclDCT['executeMode'],
                )
        # Query group
        if lclDCT['eventPass']: queryValue = groupId
        else:  queryValue = None
        queryType = lclDCT['groupQueryType']
        
        return (queryType, queryValue)

#==========================================================
def CmdGroup_groupqueryrecurringrecharge(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        lclStartTime = lclDCT['lclStartTime']
        # End of local variables setup.
               
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']
        
        print('Group ' + str(groupId) + ' is querying a recurring recharge')
        
        # Execute primitive
        retCode = REST_UTIL.groupQueryRecurringRecharge(RESTInst,
                groupId,
                lclDCT['groupQueryType'],
                now=lclStartTime,
                eventPass=lclDCT['eventPass'],
                executeMode=lclDCT['executeMode'],
                )
        # Query group
        if lclDCT['eventPass']: queryValue = groupId
        else:  queryValue = None
        queryType = lclDCT['groupQueryType']
        
        return (queryType, queryValue)

#==========================================================
def CmdGroup_groupsettlepayment(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        # End of local variables setup.
        
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']

        # If no resource ID passed in, then need to get using the external ID
        if resourceId == 0:
                if lclDCT['offerId'][0] == None:
                        print('ERROR: Need to specify an offer')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])

                offerDict = PRIM.getOfferData('group', groupId, resourceId, lclDCT['offerId'][0], lclStartTime, lclDCT['ACTION'], queryType=lclDCT['groupQueryType'], offerIsCatalog=True)

                # Get the resource ID
                resourceId = int(offerDict['ResourceId'])

        print('Group ' + str(groupId) + ' is setting payment for offer "' + str(lclDCT['offerId']) + '", resource ID ' + str(resourceId))

        # Execute primitive
        retCode = REST_UTIL.groupSettlePayment(RESTInst,
                groupId,
                lclDCT['groupQueryType'],
                resourceId,
                now=lclStartTime,
                eventPass=lclDCT['eventPass'],
                apiEventData=lclDCT['customAttr'][6],
                )


        # Query group
        if lclDCT['eventPass']: queryValue = groupId
        else:  queryValue = None
        queryType = lclDCT['groupQueryType']
        
        return (queryType, queryValue)

#==========================================================
def CmdGroup_groupqueryeligibleci(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        lclStartTime = lclDCT['lclStartTime']
        # End of local variables setup.
            
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']
        
        print('Group ' + str(groupId) + ' is querying eligible CIs')
        
        # Execute primitive
        retCode = REST_UTIL.groupQueryCatalogItemList(RESTInst,
                groupId,
                lclDCT['groupQueryType'],
                now=lclStartTime,
                eventPass=lclDCT['eventPass'],
                eligibilityFilter=lclDCT['eligibilityCheck'],
                )
        
        # Process response if anything came back
        if respData:    outData = PRIM.getCatalogIDs(respData)
        else:           outData = 'None'

        # Add query-specific heading
        outData = 'Eligible CIs for group ' + ' ' + str(groupId) + ': ' + outData
        
        # Write to where the caller wanted it to go
        if lclDCT['eventPass']:
                # If supposed to save data to variables then do that here
                if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, 'Event', respData)
        
                # Write to where the caller wanted it to go iff not saving data
                else: CSVQA.processDataToOutput(outData, lclDCT['outputFileName'])
        
        # Query None
        queryValue = None
        queryType = None
        
        return (queryType, queryValue)

#==========================================================
def CmdGroup_groupquerycatalog(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        lclStartTime = lclDCT['lclStartTime']
        # End of local variables setup.
            
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']
        
        # Execute primitive
        retCode = REST_UTIL.groupQueryCatalog(RESTInst,
                groupId,
                lclDCT['groupQueryType'],
                now=lclStartTime,
                eventPass=lclDCT['eventPass'],
                catalogQueryValue=lclDCT['catalogExternalId'],
                catalogQueryType=lclDCT['catalogQueryType'],
                eligibilityFilter=lclDCT['eligibilityCheck'],
                filterName=None,
                )
        
        # Process response if anything came back
        if respData:    outData = PRIM.getCatalogIDs(respData)
        else:           outData = 'None'

        # Add query-specific heading
        outData = 'Catalog CIs for group ' + ' ' + str(groupId) + ', Catalog ' + str(lclDCT['catalogExternalId']) + ': ' + outData
        
        # Write to where the caller wanted it to go
        if lclDCT['eventPass']:
                # If supposed to save data to variables then do that here
                if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, 'Event', respData)
        
                # Write to where the caller wanted it to go iff not saving data
                else: CSVQA.processDataToOutput(outData, lclDCT['outputFileName'])
        
        # Query None
        queryValue = None
        queryType = None
        
        return (queryType, queryValue)

#==========================================================
def CmdGroup_groupactivateoffer(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        resourceId = lclDCT['resourceId']
        # End of local variables setup.
        
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Process resource ID
        if resourceId in [0, 'first', 'second', 'third', 'last']:
                resourceData = ''
                for idx in range(len(lclDCT['offerId'])):
                        offerDict = PRIM.getOfferData('group', externalId, 0, lclDCT['offerId'][idx], lclDCT['lclStartTime'], lclDCT['ACTION'], queryType=lclDCT['groupQueryType'], offerIsCatalog=lclDCT['offerIsCatalog'], resourceId=resourceId)

                        # Get the resource ID
                        resourceData += str(offerDict['ResourceId']) + '@'
#                       print 'Group ' + str(groupId) + ' canceling offer with exernal ID = ' + offerId[idx] + ', resource ID ' + str(offerDict['ResourceId'])

                # Remove trailing list character
                resourceId = resourceData[:-1]

        # Execute primitive
        retCode = REST_UTIL.groupActivateOffer(RESTInst,
                groupId,
                lclDCT['groupQueryType'],
                resourceId,
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                apiEventData=lclDCT['customAttr'][6],
                routingType=lclDCT['routingType'],
                routingValue=lclDCT['routingValue'],
                executeMode=lclDCT['executeMode'])

        # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
        try:
                respData = str(retCode.printElementBasedXml())
        except:
                respData = str(retCode)

        # If supposed to save data to variables then do that here
        if saveData: MISC.CmdMisc_saveData(lclDCT, REST_UTIL.subUrl.capitalize(), respData)

        # if supposed to store output then write to where the caller wanted it to go.  nly if not saving data.
        elif lclDCT['outputFileName'] and lclDCT['outputFileName'].lower() != 'none': CSVQA.processDataToOutput(respData, lclDCT['outputFileName'])

        # Query subscriber
        queryValue = groupId
        queryType = lclDCT['groupQueryType']

        return (queryType, queryValue)

