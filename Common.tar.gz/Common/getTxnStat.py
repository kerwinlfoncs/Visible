#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:41:25
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:37:06
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:24
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================



# from builtins import str
# from builtins import str
from past.utils import old_div
import os,sys
import datetime, time
import qa_utils 

def main():

    if len(sys.argv) != 2 :
        print("missing input mtx_debug log file")
        sys.exit(0)
    else :
        inFile = sys.argv[1]
        print("============= processing ", inFile, "=================")

    #extrace usefull log info from the given log file
    #transaction log file name, open time, closing time and uline count
    print("     ------------- parse the raw log file -------------")
    cmd = "grep -i \"openLogFile\" " + inFile + " | grep -v \"\%e\" | grep -i transaction | awk '{print $3, $4, $10}'> openFile.log"
    os.system(cmd)
    cmd = "grep -i \"closeLogFile\" " + inFile + " | grep -v \"\%e\" |grep -i transaction |  awk '{print $3, $4, $10, $13}'> closeFile.log"
    os.system(cmd) 
    cmd = "join -a1 -1 3 -2 3 openFile.log closeFile.log > join.log"
    os.system(cmd) 

    # now get the stats
    print("     ------------- getting stats   -------------")
    i = 0
    ttlTps = 0
    maxTxCnt = 0
    maxFile = None

    logFileDct = {}
    txnLogs = open("join.log", 'r')
    openLogs = open("openFile.log",'r')
    line = openLogs.readline()
    while line :
        cols = line.split()
        logFileDct[cols[2]] = [cols[0],cols[1]]
#        print logFileDct[cols[2]]
        line = openLogs.readline()
#        print cols[2]
    openLogs.close()
    closedLogs = open("closeFile.log",'r')
    line = closedLogs.readline()
    while line:
        cols = line.split()
#        print cols
        if cols[2] in logFileDct:
            logFileDct[cols[2]].append(cols[0])
            logFileDct[cols[2]].append(cols[1])
            logFileDct[cols[2]].append(cols[3])
#        close.append(line.split())
        line = closedLogs.readline()
    closedLogs.close()

  #  print logFileDct
#    exit()


#    line = openLogs.readline()
    for log in logFileDct:
#    while line :
#        cols = line.split()
#        colsClosed = qa_utils.runCmd("grep "+cols[2]+" closeFile.log")
#        colsClosed = colsClosed.split()
#        print '\n *************************************************** \n'
        cols = logFileDct[log]
        if len(cols) < 5:
            print("missing file close log. skip row")
            print(log)
#            print logFileDct[log]
#            print colsClosed
#            line = openLogs.readline()
            continue
        txFile = log
        openTime = cols[0] + " " + cols[1]
        sTime = time.mktime(datetime.datetime.strptime(openTime, "%Y-%m-%d %H:%M:%S.%f").timetuple())
        closeTime = cols[2] + " " + cols[3]
        eTime = time.mktime(datetime.datetime.strptime(closeTime, "%Y-%m-%d %H:%M:%S.%f").timetuple())
        duration = eTime - sTime
        if duration == 0:
            duration = 0.05
            print("0 duration detected. readjust to 0.05")
        txCnt = cols[4].strip(')')
        txCnt = txCnt.strip('(')
        tps = old_div(int(txCnt), duration)
        #print "tps =========", txCnt, str(duration)
        i += 1
        ttlTps += tps
        if txCnt > maxTxCnt :
            maxTxCnt = txCnt
            maxFile = txFile
 #       line = openLogs.readline()

    #print str(i)
    if i > 0:
        aveTps = old_div(ttlTps, i)
    else :
        aveTps = -1   
        print("ERROR: no log found")

    print("================= Transaction stats from ", inFile, " =====================")
    print("========= Total transaction log files processed: ", str(i))
    print("========= Average TPS: ", str(aveTps))
    print("========= Maximum transaction count: ", str(maxTxCnt))
    print("========= Maximum transaction file name: ", maxFile)
    print("================= End of stats ============================================")

    #os.system("rm openFile.log closeFile.log join.log")

if __name__ == '__main__':
   main()
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

     
