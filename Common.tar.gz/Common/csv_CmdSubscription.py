#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:35:55
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:35:55
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:35:54
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
from __future__ import print_function
# from builtins import str
# from builtins import str
import sys, copy, pprint
import QA_subscriber_management_restv3 as REST_UTIL
import qa_utils as QAUTILS
import csv_track as TRACK
import csv_id as CSVID
import csv_prim as PRIM
import csv_data as DATA
import custSpecific as CUST
import csv_qa as CSVQA
import csvMain as CSV
import csv_Events as CSVEVENTS
import csv_CmdMisc as MISC
from primitives import timeToMDCtime as MDCTIME
import xml.etree.ElementTree as ET

from primitives import primGET as GET

#==========================================================
def CmdSubscription_createsubscription(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.

        # User should not exist
        if lclDCT['externalId'] in TRACK.subscriberTracking and not lclDCT['noChecks']:
                print('ERROR: subscription with ID "' + lclDCT['externalId'] + '" is already defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Create billing cycle data if profile id defined
        if lclDCT['profileId'] and int(lclDCT['profileId']):
                billingCycle = REST_UTIL.createBillingCycleData(lclDCT['profileId'], dateOffset=lclDCT['dateOffset'], startTime=lclDCT['startTime'])
        else:
                billingCycle = None
        
        serviceAddress = REST_UTIL.createServiceAddressData(streetAddr=lclDCT['streetAddr'], extendedAddr=lclDCT['extendedAddr'], locality=lclDCT['locality'], region=lclDCT['region'], postalCode=lclDCT['postalCode'], extendedPostalCode=lclDCT['extendedPostalCode'], countryCode=lclDCT['countryCode'])
        
        # Debug output
        print('Creating subscription ' + str(lclDCT['externalId']))
        
        retCode = REST_UTIL.createSubscription(RESTInst,
                externalId=lclDCT['externalId'],
                attr=lclDCT['customAttr'][1],
                timeZone=lclDCT['subTimeZone'],
                billingCycle=billingCycle,
                status=lclDCT['subStatus'],
                taxStatus=lclDCT['taxStatus'],
                taxCertificate=lclDCT['taxCertificate'],
                taxLocation=lclDCT['taxLocation'],
                glCenter=lclDCT['glCenter'],
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                routingType=lclDCT['routingType'],
                routingValue=lclDCT['routingValue'],
                executeMode=lclDCT['executeMode'],
                apiEventData=lclDCT['customAttr'][6],
                customerType=lclDCT['customerType'],
                serviceAddress=serviceAddress,
                npa=lclDCT['npa'],
                nxx=lclDCT['nxx'],
                tenantId=lclDCT['tenantId'],
                exemptionCodeList=lclDCT['exemptionCodeList'],
                
                )
        
        # Stuff to do if we passed
        if lclDCT['eventPass']:
                # Update tracking data
                TRACK.updateTrackingData('createSubscription', externalId = lclDCT['externalId'], mark=lclDCT['mark'], RESTInst=RESTInst)
        
        # Query user
        queryValue = lclDCT['externalId']
        queryType = lclDCT['subQueryType']
        
        return (queryType, queryValue)
        
#==========================================================
def CmdSubscription_modifysubscription(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.

        # Subscription should exist
        if lclDCT['externalId'] not in TRACK.subscriberTracking and not lclDCT['noChecks']:
                print('ERROR: subscription with ID "' + lclDCT['externalId'] + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Create billing cycle data if profile id defined
        if lclDCT['profileId'] and int(lclDCT['profileId']):
                billingCycle = REST_UTIL.createBillingCycleData(lclDCT['profileId'], dateOffset=lclDCT['dateOffset'], startTime=lclDCT['startTime'])
        else:
                billingCycle = None
        
        # Only update external ID if the 
        # OK...  We can have stuff that has been defaulted.  For modifies, only want to send in what was specifically requested to be modified.
        # Some fields (e.g. profileId) can't be modified and even setting them to the same value they were created with causes issues.
        # Build command to exec (very non-Pythonic...)
        if cmdLineInput:
         for param in DATA.subscriberModifyList + [x[0] for x in DATA.customSubscriberParameters]:
          if not cmdLineInput.count(param): lclDCT[param] = None
        
         # Really should recalculate Attr parameters as above lines were meant to clear those that were not input in the command line...
         (devAttr, subAttr, groupAttr, offerAttr, userAttr, loginAttr, apiEventDataAttr) = PRIM.getCustomAttributes(lclDCT, cmdLineInput)
        else:
                # Copy from dictionary
                subAttr = lclDCT['customAttr'][1]
                apiEventDataAttr = lclDCT['customAttr'][6]
        
        # Get service address data
        serviceAddress = REST_UTIL.createServiceAddressData(streetAddr=lclDCT['streetAddr'], extendedAddr=lclDCT['extendedAddr'], locality=lclDCT['locality'], region=lclDCT['region'], postalCode=lclDCT['postalCode'], extendedPostalCode=lclDCT['extendedPostalCode'], countryCode=lclDCT['countryCode'])
        
        # Debug output
        print('Modifying subscription ' + str(lclDCT['externalId']))
        
        retCode = REST_UTIL.modifySubscription(RESTInst,
                lclDCT['externalId'],
                queryType=lclDCT['subQueryType'],
                externalId=lclDCT['modExternalId'],
                attr=subAttr,
                timeZone=lclDCT['subTimeZone'],
                billingCycle=billingCycle,
                status=lclDCT['subStatus'],
                taxStatus=lclDCT['taxStatus'],
                taxCertificate=lclDCT['taxCertificate'],
                taxLocation=lclDCT['taxLocation'],
                glCenter=lclDCT['glCenter'],
                routingType=lclDCT['routingType'],
                routingValue=lclDCT['routingValue'],
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                lastActivityUpdateTime=lclDCT['lastActivityUpdateTime'],
                executeMode=lclDCT['executeMode'],
                apiEventData=apiEventDataAttr,
                billingCycleDisabled=lclDCT['billingCycleDisabled'],
                
                customerType=lclDCT['customerType'],
                serviceAddress=serviceAddress,
                npa=lclDCT['npa'],
                nxx=lclDCT['nxx'],
                tenantId=lclDCT['tenantId'],
                exemptionCodeList=lclDCT['exemptionCodeList'],
                )
        
        # Stuff to do if we passed
        if lclDCT['eventPass']:
                # Update tracking data
                TRACK.updateTrackingData('modifySubscriber', externalId = lclDCT['externalId'], modId=lclDCT['modExternalId'])
        
        # Query user.  Account for modified value
        if lclDCT['modExternalId']:       queryValue = lclDCT['modExternalId']
        else:                             queryValue = lclDCT['externalId']
        queryType = lclDCT['subQueryType']
        
        return (queryType, queryValue)
        
#==========================================================
def CmdSubscription_removesubscription(lclDCT, testName, sessionId, line, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, repeatCount):
        # *** lclDCT[] has all the values.

        # Check for invalid combination
        if lclDCT['mark'] and lclDCT['noChecks']:
                print('ERROR:  can\'t specify a mark when noChecks is in effect')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Set object type (for ease of cut/paste to other objects)
        objType='subscription'
        
        print('Looking to remove ' + objType + ' ' + lclDCT['externalId'] + ' (' + lclDCT['subQueryType'] + ')')
        
        # First order is to get object data
        q = GET.getObject(lclDCT['externalId'], hostname=QAUTILS.gatewaysConfig.get('REST', 'restServer'), hostport=QAUTILS.gatewaysConfig.get('REST', 'restPort'), queryType=lclDCT['subQueryType'], objType=objType)
        
        # If Q is empty, then nothing to do
        if q is None:
                print(objType + ' non-existent.')
                
                # Nothing to query
                queryType = queryValue = None
                
                return (queryType, queryValue)
                
        # Get OID
        try:
                oid = q.find('./ObjectId').text.strip()
        except:
                print('WARNING: ' + objType + ' does not have an ObjetId...')
                
                # Nothing to query
                queryType = queryValue = None
                
                return (queryType, queryValue)
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']:   lclStartTime = lclDCT['startTime']
        
        # *** Want to find time for delete.  Should match latest time that something new started in the object ***
        savedInputTime = lclStartTime
        ###lclStartTime = PRIM.findObjectLatestTime(q, lclStartTime, objType, externalId, subQueryType)
        
        print('Remove ' + objType + ' ' + lclDCT['externalId'] + ' - using time ' + lclStartTime)
        if lclStartTime != savedInputTime: print('Updated remove time from ' + savedInputTime + ' to ' + lclStartTime)
        
        # ** Move object to deletable state.  Every customer has their own states.  TF reads this into customer specific data.
        # ** For now, subscription seems to match subscriber states...
        stateMap = copy.deepcopy(CUST.subStateMap)
        
        # Get object state
        try:
                objState = q.find('./StatusDescription').text.strip()
        except:
                objState = 'Active'
        
        # Debug output
        #print 'stateMap = ' + str(stateMap) + ', starting state = ' + objState
        
        objState = objState.lower()
        while stateMap[objState] != 'Remove':
                # Get next state
                objState = stateMap[objState]
                
                # Modify to next state
                newLine='modifySubscription;externalId=' + oid + ';subQueryType=ObjectId;subStatus=' + objState + ';noChecks=True;skipStepResults=' + str(lclDCT['skipStepResults'])
                (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)
        
        # ** Cycle through all devices
        xmlDctName = './DeviceIdArray/value'
        for children in q.findall(xmlDctName):
                # If keepChildren not set to true then want to remove the children
                if not lclDCT['keepChildren']:
                        # Remove the device
                        newLine='removeDevice;deviceId=' + children.text + ';devQueryType=ObjectId;noChecks=True;skipStepResults=' + str(lclDCT['skipStepResults'])
                else:
                        # Just unlink the child
                        newLine='removeDeviceFromSubscription;externalId=' + oid + ';subQueryType=ObjectId;deviceId=' + children.text + ';devQueryType=ObjectId;deleteSessions=true;noChecks=True;skipStepResults=' + str(lclDCT['skipStepResults'])
                (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)
        
        # ** Cycle through all Users
        xmlDctName = './RelatedUserArray/MtxRelatedUserObject'
        for child in q.findall(xmlDctName):
                # Get OID
                try: parentOid = child.find('./ObjectId').text.strip()
                except:
                        print('WARNING: ' + objType + ' oid ' + str(oid) + ' parent user does not have an ObjetId')
                        ET.dump(child)
                        continue
                
                # Unlink the child
                newLine='removeSubscriptionFromUser;userId=' + parentOid + ';userQueryType=ObjectId;externalId=' + oid + ';subQueryType=ObjectId;noChecks=True;skipStepResults=' + str(lclDCT['skipStepResults'])
                (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)
                
        # ** Delete object
        newLine='deleteSubscription;externalId=' + oid + ';subQueryType=ObjectId;noChecks=True;skipStepResults=' + str(lclDCT['skipStepResults'])
        (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)
        
        # Stuff to do if we passed
        if lclDCT['eventPass']:
                # Update tracking data
                TRACK.updateTrackingData(lclDCT['ACTION'], externalId = lclDCT['externalId'])
        
        # Query nothing
        queryValue = None
        queryType = None

        return (queryType, queryValue)
        
#==========================================================
def CmdSubscription_querysubscription(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.

        # Subscription should exist
        if lclDCT['externalId'] not in TRACK.subscriberTracking and not lclDCT['noChecks']:
                print('ERROR: subscription with ID "' + lclDCT['externalId'] + '" is already defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # If verbose set but no output file, then set to stdout
        if lclDCT['verbose'] in ['full', 'high'] and not lclDCT['outputFileName']: outputFileName = 'stdout'
        else: outputFileName = lclDCT['outputFileName'] # Added during Python3 migration
        
        # Execute primitive
        retCode = REST_UTIL.querySubscription(RESTInst,
                lclDCT['externalId'],
                queryType=lclDCT['subQueryType'],
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                routingType=lclDCT['routingType'],
                routingValue=lclDCT['routingValue'],)
        
        # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
        try:
                respData = str(retCode.printElementBasedXml())
        except:
                respData = str(retCode)
        
        # May be here just to get the normal output file.  Check and skip this query if so.
        if lclDCT['saveData'] or (outputFileName and outputFileName.lower() != 'none'):
                # If supposed to save data to variables then do that here
                if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, 'Subscription', respData)
                
                # If supposed to store output then write to where the caller wanted it to go.  nly if not saving data.
                if outputFileName and outputFileName.lower() != 'none': CSVQA.processDataToOutput(respData, outputFileName)
                
                # Query nothing
                queryValue = None
                queryType = None
        else:
                # Query subscription
                queryValue = lclDCT['externalId']
                queryType = lclDCT['subQueryType']
                
        return (queryType, queryValue)

#==========================================================
def CmdSubscription_deletesubscription(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.

        # Subscription should exist
        if lclDCT['externalId'] not in TRACK.subscriberTracking and not lclDCT['noChecks']:
                print('ERROR: subscription with ID "' + lclDCT['externalId'] + '" is already defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # If verbose set but no output file, then set to stdout
        if lclDCT['verbose'] in ['full', 'high'] and not lclDCT['outputFileName']: outputFileName = 'stdout'
        else: outputFileName = lclDCT['outputFileName'] # Added during Python3 migration
        
        # Execute primitive
        retCode = REST_UTIL.deleteSubscription(RESTInst,
                lclDCT['externalId'],
                queryType=lclDCT['subQueryType'],
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                routingType=lclDCT['routingType'],
                routingValue=lclDCT['routingValue'],
                apiEventData=lclDCT['customAttr'][6],
                )
        
        # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
        try:
                respData = str(retCode.printElementBasedXml())
        except:
                respData = str(retCode)
        
        # May be here just to get the normal output file.  Check and skip this query if so.
        if lclDCT['saveData'] or (outputFileName and outputFileName.lower() != 'none'):
                # If supposed to save data to variables then do that here
                if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, 'Subscription', respData)
                
                # If supposed to store output then write to where the caller wanted it to go.  nly if not saving data.
                if outputFileName and outputFileName.lower() != 'none': CSVQA.processDataToOutput(respData, outputFileName)
                
        # Update tracking data if event expected to pass
        if lclDCT['eventPass']: TRACK.updateTrackingData('deleteSubscriber', externalId = lclDCT['externalId'], RESTInst=RESTInst)
        
        # Query nothing
        queryValue = None
        queryType = None
                
        return (queryType, queryValue)

