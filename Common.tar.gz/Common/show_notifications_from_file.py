#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:32
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:13
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:34:57
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


import data_container as MDC
# Check if the data_container_defs.py needs to be re-created
import data_container_defs as MDCDEFS
import common_mdc as COMMON
import optparse
import os, string,re

xmlStatus=True
try:
    import xml_utils
except ImportError:
    xmlStatus=Flase

outputFile = ''

#-------------------------------------------------------------------------------
# Parse a notification and (if configured) strip variable fields
#-------------------------------------------------------------------------------
def extractNotification(mdc, stripFields):
    #
    # Write current notification to a temporary file
    #
    global outputFile
    tmpNotificationFileName = os.getcwd() + '/' + COMMON.resultsDir + '/current_notification.txt' 
    tmpNotificationFile = open(tmpNotificationFileName, 'w')
    print(mdc.printXml(), file=tmpNotificationFile)
    tmpNotificationFile.close()

    #
    # Strip variable fields from notification being processed
    #
    tmpNotification = open(tmpNotificationFileName, 'r')
    lines = tmpNotification.readlines()
    tmpNotification.close()
    lines.append("</root>\n")
    lines.reverse()
    lines.append("<root>\n")
    lines.reverse()
    processedData = "".join([x for x in lines if x.strip() != ''])
    tmpNotification = open(tmpNotificationFileName, 'w')
    tmpNotification.write(processedData)
    tmpNotification.close()

    #excludeList = ['EndTime', 'CreatedTime', 'ModifiedTime', 'TriggerTime', 'ChrgInQueueId', 'GatewaySocketId',\
    #    'ObjectExternalId', 'TimeArray', 'NotificationTime']
    excludeList = ['EndTime', 'CreatedTime', 'ModifiedTime', 'TriggerTime', 'ChrgInQueueId', 'GatewaySocketId',\
        'TimeArray', 'NotificationTime']

    if xmlStatus and stripFields:
        print(xml_utils.transformDoc(tmpNotificationFileName, includeValue=True), file=outputFile)
    else:
        print(processedData, file=outputFile)

    return

#-------------------------------------------------------------------------------
# Output the notifications for each work order MDC
#-------------------------------------------------------------------------------
def extractNotifications(mdc, stripFields):
    if mdc.descObj.containerKey == MDCDEFS.kMtxWorkOrderMsgMdcDesc.containerKey:
        actionList = mdc.getUsingKey(MDCDEFS.kMtxWorkOrderMsgTxnActionListFldKey)
    else:
        print("Error: Unexpected MDC type")
        return

    # Get the event list
    if actionList is None:
        return

    for action in actionList:
        if action.descObj.containerKey == MDCDEFS.kMtxTxnObjectActionDataMdcDesc.containerKey:
            if action.isPresent(MDCDEFS.kMtxTxnObjectActionDataObjectFldKey):
                object = action.getUsingKey(MDCDEFS.kMtxTxnObjectActionDataObjectFldKey)
                if object.descObj.containerKey == MDCDEFS.kMtxNotificationObjectMdcDesc.containerKey:
                    #check notificaiton trigger time.  Only triggered notifications count
                    triggerTime = object.getUsingKey(MDCDEFS.kMtxObjectSysDataTriggerTimeFldKey)
                    changeCounter = object.getUsingKey(MDCDEFS.kMtxObjectSysDataChangeCounterFldKey)
                    if triggerTime != 0 and changeCounter == 1 :
                        extractNotification(object, stripFields)

#-------------------------------------------------------------------------------
# Read each MDC in the stripped transaction log
#-------------------------------------------------------------------------------
def readCompactInput(inFile, stripFields):
    for line in inFile:
        line = line.rstrip('\n')
        if (line == ''):
            continue
        if (line.startswith('#')):
            continue

        mdc = MDC.readFromStr(line)
        if mdc == None:
            print("Error: Cannot parse input")
            return

        extractNotifications(mdc, stripFields)

    return

def printNotifications(testTag, stripFields = False):
    global outputFile

    path = os.getcwd()
    logFile = path + '/' + COMMON.resultsDir + '/tmpNotifLog'

    if (not os.path.exists(logFile)):
        print('Error: The input file name (' + logFile + ') does not exist.')
        return -1

    inFile = open(logFile, 'r')

    outputFileName = path + '/' + COMMON.resultsDir + '/' + testTag + '_notifications'
    outputFile = open(outputFileName, 'w')

    readCompactInput(inFile, stripFields)

    inFile.close()
    outputFile.close()

    return 0
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

