#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:41:03
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:47
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:37

# from builtins import str
# from builtins import object
# from builtins import str
# from builtins import object
import re
import sys
from collections import deque
import diameter as DIAM
    
class diamPacket(object):
    __tree = {}
    __CmdFlagProxiable = False
    __diamPacket = None
    __DEBUG = False

    def __init__(self, CmdFlagProxiable, msgId=272, appId=4, hopByHopId=1001, endToEndId=2001, skip=False, answerFlag=False, CmdFlagReTransmit=False):
        if skip : return
        
        # Build the ID.  Starts with the msgId.
        Id = int(msgId)
        
        # If not an answer (i.e. is a request) then set Request bit
        if not answerFlag: Id += DIAM.CmdFlagRequest

        # Set the proxy flag if proxy parameter true
        if CmdFlagProxiable: Id += DIAM.CmdFlagProxiable
        
        # Set the duplicate flag if parameter true
        if CmdFlagReTransmit:
                print('Setting retransmit: ID += ' + str(DIAM.CmdFlagReTransmit))
                Id += DIAM.CmdFlagReTransmit
        
        # Create the packet with the proper header values
        self.__diamPacket = DIAM.createPacket(appId, Id, hopByHopId, endToEndId)

    #creates a branch in the tree dct 
    def addAvps(self, addListAvps, diamPacketDct):
        buildListofAVPsToAdd = {}
        for avp in addListAvps:
            self.printOut('adding AVP ========', avp)
            arr = avp.split(':')
            existAvp = []
            #create a list of values in case we have multiple instances of the same AVP
            buildListofAVPsToAdd[arr[0]] = ':'.join(arr[1:])

        diamPacketDct.update(buildListofAVPsToAdd)
        return diamPacketDct

    #this function builds the whole branch of a given node or grouped AVP
    #input: key which is full path AVP such as: MSCC|Requested-Units|CC-Time:33
    #diamPacketDct holds the value of this AVP. we will not get here for an AVP size 1
    def addGroupNode(self, key, diamPacketDct):
        self.printOut("addGroupNode:" , self.__tree, "key is:", key)
        arr = key.split('|')
        firstChild = arr[0]
        subKey = '|'.join(arr[1:])
        if firstChild not in self.__tree:  #a new branch starting at root
            groupedNode = self.createSubDct(subKey, None, key, diamPacketDct) #create the branch
            self.__tree[firstChild] = groupedNode

        else:            #insert into an existing branch
            addToThisChild = self.__tree[firstChild]
            if type(addToThisChild) != type({}):  #if we have a Grouped node we are adding to it
                addToThisChild = None
            groupedNode = self.createSubDct(subKey, None, key, diamPacketDct, addToThisChild)
            self. __tree[firstChild] = groupedNode


    #function to build a custom group nodes coming in as a list of AVPs in the add list
    #this is used in create_diameter_pkt_base module
    def buildCustomNode(self, customAvpNode, iter):
        tmpDctList = []
        dup = iter
        tmpList = []
        tmpAvpDct = {}
        tag = '$'+ str(iter)
        customAvpNodeList = sorted(customAvpNode,key=len, reverse=1)
        self.printOut('customAvpNodeList=', customAvpNodeList)
        for avp in customAvpNodeList:
           if type(avp) == type([]):
               sys.exit('no support for nested list')
           newAvp1 = avp.replace('|', tag + '|')
           newAvp = newAvp1.replace(':', tag + ':' )  #avp = 'A1|B1:2'
           tmpList = [x for x in tmpDctList if x.split(':')[0].startswith(newAvp.split(':')[0])]
           if tmpList != []: #we have a duplicate
               self.printOut('^'*60,'we have duplicate tmpList:', tmpList)
               dup += 1
               newAvp = newAvp1.replace(':', '$' + str(dup) + ':' )  #avp = 'A1|B1:2'

           tmpDctList.append(newAvp)
        self.printOut("'-'*50\n", tmpDctList)
        return tmpDctList, iter

    #this function provides some order to the way AVPs will be printed in the diam pkt
    def createDiamTree(self):
        wantedorder = ['Session-Id', 'jnk', 'Origin-Host', 'Origin-Realm', 'Destination-Realm',
                       'Auth-Application-Id', 'Service-Context-Id', 'Service-Identifier',
                       'Value-Digits', 'Exponent', 
                       'CC-Request-Type', 'CC-Request-Number', 'Destination-Host',
                       'User-Name', 'Event-Timestamp', 'Subscription-Id', 'SGSN-Address', 
                       'Requested-Service-Unit', 'Used-Service-Unit', 'Service-Information']

        existingKeys = list(self.__tree.keys())
        newOrderedList = [] 
        for x in wantedorder:
            for y in existingKeys:
                if y.split('$')[0] == x:
                    newOrderedList.append(y)
        randomOrderList = [ x for x in existingKeys if x not in newOrderedList]
        self.createDiamTreeParts(newOrderedList)
        self.createDiamTreeParts(randomOrderList)
        return self.__diamPacket
        
    def createDiamTreeParts(self, listIterator):
        l1 = []
        self.printOut('='*80)
        if self.__DEBUG : self.printADct(self.__tree)
        for key in listIterator:
        #for key,val in self.__tree.iteritems():
            val = self.__tree[key]
            self.printOut('key=', key,' value=', val)
            if not type(val) == type({}):
                if val == 'Grouped':
                    self.__diamPacket.appendAvp(self.strippedKey(key),'')
                else: 
                    self.__diamPacket.appendAvp(self.strippedKey(key), val)  #1st level node

            else:  #grouped AVP
                listNode = []
                listNode = self.__getNode(key, val, listNode) #need to traverse branch
                self.__diamPacket.appendAvpObj(listNode)

    #this function will  build the sub-branch of addGroupNode
    def createSubDct(self, subKey, value, keyToAdd, diamPacketDct, branch=None):
        self.printOut("createSubDct=========>> ", subKey, value, keyToAdd, "branch:", branch)
        arr = subKey.split('|')
        currentAvpName = arr[0]
        if len(arr) == 1:   #if we reached last element
            if branch == 'Grouped':
                 tmpDct = {}
            elif branch != None:
                tmpDct = branch
            else:
                tmpDct = {}  #TODO:  if we override must use the value passed in
            if keyToAdd in diamPacketDct:
                #print ' diamPacketDct[keyToAdd]=',  diamPacketDct[keyToAdd]
                tmpDct[currentAvpName] = diamPacketDct[keyToAdd]
            else: 
                #print 'vlllll does not exist:', value
                tmpDct[currentAvpName] = value
            return tmpDct
        
        if branch == None:   #child node does not exist like child Grouped AVP
            childDct = {}
        else: 
            childDct = branch
    
        if currentAvpName in childDct:   #child already exist
            self.printOut(arr[0] , " does exist!!!!!!!!!!!!!!!!")
            branch = branch[currentAvpName]
        else:                          #new child
            self.printOut(arr[0] , " does not exist!!!!!!!!!!!!!!!!")
            branch = None
        nextChild = '|'.join(arr[1:])  #need to build the rest of the branch
            
        childOfCurrentAvpName = arr[1]
        childDct[currentAvpName] = self.createSubDct(nextChild, childOfCurrentAvpName, keyToAdd, diamPacketDct, branch)
        return childDct

    def createTree(self, diamPacketDct):
        l1 = []
        self.__tree={}
        
        #print '*'*80
        for key,val in list(diamPacketDct.items()):
            if not re.search('\|', key):
                if key not in self.__tree:   #adding a top grouped node
                    self.__tree[key] = diamPacketDct[key]
                else:
                    if key in diamPacketDct: #update existing key
                        if diamPacketDct[key] != 'Grouped':
                            self.__tree[key] = diamPacketDct[key]
            else:
                self.addGroupNode(key, diamPacketDct)

        for x in  self.__tree:
            self.printOut('post tree create tree has :', x, self.__tree[x])
            self.printOut('node:'+ x, self.__tree[x])
        #sys.exit(1)
        return self.__tree
    
    def deleteAvpNode(self, subKey, branch=None):
        self.printOut("=========>> ", subKey, " branch is :" , branch)
        arr = subKey.split('|')
        if len(arr) == 1:   #if we reached last element
            if branch != None:
                if arr[0] in branch:
                    ##print "deleting..................", arr[0]
                    del branch[arr[0]]
                    return branch
 
        if arr[0] in branch:   #child already exist
            nextChild = '|'.join(arr[1:])  #need to traverse the rest of the branch
            self.deleteAvpNode(nextChild, branch[arr[0]])
        return branch
    
    # this function returns 1 diameter-AVP line or grouped AVP which would 
    #be AVPobject which is listNode
    def __getNode(self, keyDct, val=None, listNode=[]):
        self.printOut("keyDct ", keyDct, " type of:", type(keyDct))
        if type(val)== type({}):  #if grouped node
            listN = []
            for item, val in list(val.items()):
                if type(val) == type([]):
                    for x in val:
                        listN.append(self.__getNode(item, x, listN))
                else:
                    listN.append(self.__getNode(item, val, listN))
            avpObject = DIAM.Avp(self.strippedKey(keyDct), listN)
            return(avpObject)
        else:
            if val == "Grouped":
                val = []
            child=DIAM.Avp(self.strippedKey(keyDct), val)
            return child

    def printADct(self, dct):
        for x in list(dct.items()):
            print(x)

    def printOut(self, *args):
        msg = ''
        if self.__DEBUG:
            for a in args:
               msg = msg + str(a) 
            print(msg)

    def removeAvp(self, omitListAvps, diamPacketDct):
        existingAvps = list(diamPacketDct.keys())
        if omitListAvps==[] or omitListAvps==None:
            return diamPacketDct
        for avp in omitListAvps:
            existAvp = [x for x in existingAvps if x.startswith(avp)]
            ##print existAvp
            for anyAvp in existAvp:
               #print "deleting:", anyAvp
               if anyAvp in diamPacketDct:
                   del diamPacketDct[anyAvp]
        return diamPacketDct


    def strippedKey(self, key):
        x = key.split('$')
        return x[0]

    

    def updateAvps(self, addListAvps, diamPacketDct):
        existAvp = []
        for avp in addListAvps:
            arr = avp.split(':')
            currentAvpName = arr[0]
            currentAvpValue = arr[1]
  
            existingAvps = list(diamPacketDct.keys())
            ##print existingAvps
            existAvp = [x for x in existingAvps if x == currentAvpName]
            if existAvp == []: #does not exist we cannot update 
                print('cannot update a non-existing AVP .please add it first')
            else:
                if type(currentAvpValue) == type([]):
                    sys.exit('cannot update multiple instances of an AVP.remove then add with new values')
                else:
                    diamPacketDct[currentAvpName] = currentAvpValue
        return diamPacketDct

    def removeAvp2(self, omitListAvps):
        for avp in omitListAvps:
            arr = avp.split('|')
            if arr[0] not in self.__tree:
                #print "nothing to delete: maybe did not give full path to AVP"
                continue
            if len(arr) == 1:
                if arr[0] in self.__tree:
                    del self.__tree[arr[0]]
            else:
                #print "Deleting a node in a sub-group:avp is :", avp
                self.__tree[arr[0]] = self.deleteAvpNode('|'.join(arr[1:]), self.__tree[arr[0]])
    
               

    
    def children(self, token, __tree):
        "returns a list of every child"
        child_list = []
        to_crawl = deque([token])
        #print to_crawl
        while to_crawl:
            current = to_crawl.popleft()
            ##print "child_list.append:" + str(child_list)
            node_children = __tree[current]
            if type(node_children) == type([]):
                to_crawl.extend(node_children)
                #print "\nto crawl:" + str(to_crawl)
        return child_list
    
    
