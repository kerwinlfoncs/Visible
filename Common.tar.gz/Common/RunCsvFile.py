#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:35:00
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:35:00
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:34:59
#
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
from __future__ import print_function
# from builtins import str
# from builtins import str
from datetime import date, datetime
from dateutil.parser import parse
from dateutil.tz import *
import sys, os, time, random, copy, pytz, pprint, re
import log_errors as LOGGER
import diameter_utils as DIAMUTILS
import create_diameter_pkt as DIAMPKT
import common_mdc as COMMON
import csv_5G as FIVEG
import csv_CmdMisc as MISC

##import QA_subscriber_management_restv3 as REST_UTIL
import QA_subscriber_management_restv3 as REST_UTIL
from optparse import OptionParser
import qa_utils as QAUTILS
try:
    import QA_subscriber_management_direct as MDC_UTILS
except ImportError:
    sys.stderr.write("Error: Can't find QA_subscriber_management_direct.py")
    sys.stderr.write("\nAppend PYTHONPATH to Common!!!")
    sys.exit(1)
import subprocess
import data_container_defs as MDCDEFS
import csvMain as CSV
import csv_id as ID
import csv_prim as PRIM
import csv_data as DATA
import csv_ccf as CCF
import csv_track as TRACK
from primitives import primGeneric as GENERIC
from primitives import primGET as GET
from primitives import primData as PRIMDATA
from primitives import timeToMDCtime as MDCTIME
from primitives import cbRestPrim  as CB

#from modulefinder import ModuleFinder

try:
   import custSpecific as CUST
except ImportError:
   os.system(' echo \"\" > custSpecific.py ')

try:
    from rich.traceback import install
    install(show_locals=True)
except: pass

extraAVP={}

def parseMDCSendEvents(Config, users, options,testName='Default'):
    # ====================== Initialize variables; Process input parameters ======================================
    
    global RESTInst
    
#    finder = ModuleFinder()
#    finder.run_script('/home/mtx/workspace/trunk/MTXQA/TESTS_HA/common/ha_apis.py')
#
#    print 'Loaded modules:'
#    for name, mod in finder.modules.iteritems():
#       print '%s: ' % name,
#       print ','.join(mod.globalnames.keys()[:3])
#
    # Save noCheck data in TRACK global (since this was added late and we want to avoid updating tracking data if no checks are on)
    TRACK.noCheckFlag = options.noChecks
    
    # Set the time zone based on input data.
    # NOTE: QAUTILS function sets QA system time zone global.  TF has a primitive that stores this, as it's needed for standalone tools.
    #       Set the TF global based on the return from teh QA function (so they're always equal).
    if   options.timeZone:  MDCTIME.systemTimeZone = QAUTILS.setSystemTimeZone(options.timeZone)
    elif options.subTimeZone:   MDCTIME.systemTimeZone = QAUTILS.setSystemTimeZone(options.subTimeZone)
    elif options.groupTimeZone: MDCTIME.systemTimeZone = QAUTILS.setSystemTimeZone(options.groupTimeZone)
    else:
         # Want to use engine time zone if present, else default to server.
         cmd = 'grep "^What is the system time zone" /opt/mtx/custom/create_config.info 2>/dev/null | head -1 | cut -f2 -d"?"'
         try:    MDCTIME.systemTimeZone = QAUTILS.setSystemTimeZone(QAUTILS.runCmd(cmd))
         except: MDCTIME.systemTimeZone = QAUTILS.setSystemTimeZone()
    
    # Set time to be now in the target timezone
    GET.commandTime = startTime = GENERIC.getTimeNow(MDCTIME.systemTimeZone)
    print('Start time at beginning: ' + startTime)

    # MEF file number init (so we don't look at old values).
    # NOTE: Do this after TZ setup as this changes the output timestamps of "ls".
    PRIM.initMefFileValues()

    # Set local variable to the above
    lclStartTime = startTime
    
    # Set the saved time level 0 to this time (default)
    TRACK.saveTime['0'] = lclStartTime
    
    # Debug output
    if (options.debug > 0):
        print('Input User #: ' + str(options.user))

    # Set return to success (always plan for success :-)
    retCode=0

    '''
    # NOTE:  always want notifications on.  Turn on here
    options.notifications = 1
    '''
    
    # Get key data from command line and/or config file
    print('Reading Input Data')
    (subscriberId, deviceId, externalId, deviceType, serviceId, offerId, generalDct)=QAUTILS.get_key_data(Config, options,os.getcwd(),users)
 
    # OK, minor kludge.  There's a feature where we create a subscriber ID by concatenating the external ID (string) with the subscriber number (int).
    # Can either explicitly do this using an input command option (mergeSubIds) or can specify both -x and -s on the command line.
    # Code is written to assume command line option.  Set this if it's not already set AND if the externalId is not the same as the subscriber ID
#    if (not options.mergeSubIds) and (externalId != options.subscriber):
#   # Set the command field (as if entered on the command line)
#   options.mergeSubIds = 1
#    
#    if options.mergeSubIds:
#   # Copy the external ID into a spare options field (parameter added, but will never be specified)
#   options.mergeExternalId = externalId
#   
#   # Set the external ID to the sub ID
#   externalId = options.subscriber
    
    # Fudge back in some of the items that were derived from options
    options.deviceId = deviceId
    options.offerId = offerId
    options.externalId = externalId
    
    # Access numbers not returned from the above key_data call.  Thus can't
    # unconditionally set based on a local variable.  If it's not
    # set then set it.
    #if not options.accessNumbers: options.accessNumbers = deviceId
    if not options.accessNumbers: options.accessNumbers = '0'
    
    # If no imei entered, then default to device ID
    if options.imei == '0': options.imei = deviceId
    
    # *** Address default values for objects that share a name space ***
    # What to use as the basis depends on if external ID and subscriber entered
    if options.subscriber and (options.externalId != options.subscriber):
        valueToUse = options.subscriber
    else:   valueToUse = options.externalId
    basis = 1000000
        
    # If no groupId entered and subscriber is external ID, then default to a fixed amount above the external Id
    if options.groupId == '0' and options.subQueryType == 'ExternalId':
        # Set default group ID relative to subscriber
        if valueToUse:  options.groupId = str(int(valueToUse) + basis)
        else:       options.groupId = str(basis)
    
    basis += 1000000
    # If no userId entered and subscriber is external ID, then default to a fixed amount above the external Id
    if options.userId == '0' and options.subQueryType == 'ExternalId':
        # Set default group ID relative to subscriber
        if valueToUse:  options.userId = str(int(valueToUse) + basis)
        else:       options.userId = str(basis)
    
    # If no sub group ID entered, then default to the group ID
    if options.subGroupId == '': options.subGroupId = options.groupId
    
    # Default external IDs to be a single character in front of the object external ID (excluding any external ID prefix).
    # This is needed for commands that create multiple objects.  
    # Don't set if noChecks in play, as then a modifyDevice command will change the external ID...
    #if not options.devExternalId  and options.externalId and not options.noChecks: options.devExternalId  = 'D' + options.externalId
    #if not options.userExternalId and options.userId     and not options.noChecks: options.userExternalId = 'U' + options.userId
    
    # *** End of default values for objects that share a name space ***
    
    # Set global variable around used units being entered
    # First convert any input in case it's not in pure numerical format.
    if options.usedAmount != '-1': options.usedAmount = str(PRIM.convertAmountsToIntegers(options.usedAmount))
    if int(options.usedAmount) > 0: CSV.usedAmountInput = True
    
    # Setup maximum ID values.  Session ID may change, so return it here.
    options.refundSessionId = options.sessionId = ID.setupMaxIdValues(options)
    
    # Append QA parameters to DATA.  Can't redefine them, so make them usable by the CSV framework
    cmd = 'grep parser.add_option /home/mtx/workspace/trunk/MTXQA/Common/qa_utils.py | cut -f2 -d"," | cut -f3 -d"-" | cut -f1 -d\'"\' | sort'
    qaParameters = str(QAUTILS.runCmd(cmd)).split("\n")
    for parameter in qaParameters:
#       print 'Adding QA parameter ' + parameter
        DATA.parameters.append((parameter, None))
    
    # Debug output
    print('\nDefault IDs after input:')
    print('external ID = ' + str(options.externalId))
    if options.mergeSubIds: 
        print('Subscriber ID = ' + str(options.subscriber))
        print('merge External ID = ' + options.mergeExternalId)
    print('User ID = ' + str(options.userId))
    print('Group ID = ' + str(options.groupId))
    print('SubGroup ID = ' + str(options.subGroupId))
    print('Device ID = ' + str(options.deviceId))
    print('Access Numbers ID = ' + str(options.accessNumbers))
    print('Session ID = ' + str(options.sessionId))
    print('Start time = ' + lclStartTime)
    print('\n')
    
    # Force setTime constants to be set
    lclDCT = {}
    lclDCT['origStartTime'] = lclStartTime
    lclDCT['startTime'] = lclStartTime
    MISC.CmdMisc_settime(lclDCT, options, None)

    # Scenario-specific static items
    (extraAVP, options) = PRIM.setupCustomerOptions(options)

    # Save extraAVP (need to reset during file processing)
    lclExtraAvp = copy.deepcopy(extraAVP)

    # Setup interface connections if required
    if options.useGyInterface:
        if not options.diameterDestinationIpAddressGy: options.diameterDestinationIpAddressGy = QAUTILS.gatewaysConfig.get('DIAMETER','hostname')
        PRIM.connectToDiameterGateway(options.diameterDestinationIpAddressGy, 'gy', options=options, mark='GyStart')

    if options.useSyInterface: 
        if not options.diameterDestinationIpAddressSy: options.diameterDestinationIpAddressSy = QAUTILS.gatewaysConfig.get('DIAMETER','hostname')
        PRIM.connectToDiameterGateway(options.diameterDestinationIpAddressSy, 'sy', options=options, mark='SyStart')

    if options.useGxInterface: 
        if not options.diameterDestinationIpAddressGx: options.diameterDestinationIpAddressGx = QAUTILS.gatewaysConfig.get('DIAMETER','hostname')
        PRIM.connectToDiameterGateway(options.diameterDestinationIpAddressGx, 'gx', options=options, mark='GxStart')

    # Here we delete any parameters that shouldn't take effect after the initial setup
    options.diameterDestinationIpAddressGy = None
    options.diameterDestinationIpAddressSy = None
    options.diameterDestinationIpAddressGx = None

    # User can input a series of files.  Process them one at a time
    dataFileList = options.dataFile.split(DATA.inputFileSepChar)
    
    # Initialize line count (so output file name numbers match file line number)
    step = 0
    
    # Make a copy of the option values (as we may overwrite them)
    CSV.optionsSave = copy.deepcopy(options)
    
    # If trace enabled then start trace
    if options.trace: QAUTILS.runCmd('testSetup')
    
    # Get list of all TF parameters
    DATA.fullList = []
    DATA.fullList.extend(DATA.parameters)
    DATA.fullList.extend(DATA.customSubscriberParameters)
    DATA.fullList.extend(DATA.customDeviceParameters)
    DATA.fullList.extend(DATA.customGroupParameters)
    DATA.fullList.extend(DATA.customOfferParameters)
    DATA.fullList.extend(DATA.customUserParameters)
    DATA.fullList.extend(DATA.customLoginParameters)
    DATA.fullList.extend(DATA.custom5GRequestParameters)
    DATA.fullList.extend(DATA.customApiEventDataParameters)

    # Debug output
    #pprint.pprint(DATA.fullList)
    
    # Get list of TF variables
    DATA.TFVariables = [x[0] for x in DATA.fullList]
    
    # Loop through each file in the input list
    saveResult = False
    for dataFile in dataFileList:
        # Get unique test name
        if testName != 'Default': lclTestName = testName + DATA.fileChar + dataFile
        else: lclTestName = dataFile
    
        # Process single data file
        (step, lclStartTime, options, saveResult) = CSV.processDataFileInput(lclTestName, lclExtraAvp, options, lclStartTime, RESTInst, step, dataFile)
    
        if options.debug > 0: print('\n\nCompleted processing data file "' + dataFile + '"')

    # Some space after we're done...
    print('\n\n')
    
    # If trace enabled then stop trace
    if options.trace: QAUTILS.runCmd('testEnd')
    
    # If there are diameter AVP files in the results Dir, then change the name so they can be validated.
    # These would be created if the command specified --diamDebug on the command line.
    for diamFile in ['diameter_recv_pkts.txt', 'diameter_sent_pkts.txt']:
      # See if file exists
      if os.path.isfile(COMMON.resultsDir + '/' + diamFile):
        # *** Need to change "len=" part of the file as this is excluded in the standard qaDiff.sh file ***
        QAUTILS.runCmd('sed -i "s/len=/kef=/g" ' + COMMON.resultsDir + '/' + diamFile)
        
        # Rename so validation can pick it up
        QAUTILS.runCmd('mv ' + COMMON.resultsDir + '/' + diamFile + ' ' + COMMON.resultsDir + '/ECT_' + lclTestName + '_' + diamFile)
        
        # Also add to file validation list
        QAUTILS.runCmd('echo ' + COMMON.resultsDir + '/ECT_' + lclTestName + '_' + diamFile + ' >> ' + COMMON.resultsDir + '/allMdcFilesList')
    
    # See if we should save results for the test run
    if options.saveResults:
      print('Saving files for test name: ' + lclTestName)
      fname = './' + COMMON.resultsDir + '/allMdcFilesList'
      outName = './' + COMMON.resultsDir + '/validationFiles'
      cmd = 'grep trsf_.*' + lclTestName + '_* ' + fname + ' > ' + outName
      QAUTILS.runCmd(cmd)
      cmd = 'grep ECT_.*' + lclTestName + '_* ' + fname + ' >> ' + outName
      QAUTILS.runCmd(cmd)
    
      PRIM.saveTestResults(lclTestName, fileOfFilesToSave=outName, dirToSaveTo='expect')

    # If validation of one test is desired, do that
    if options.validate: PRIM.validateResults(lclTestName)
    
    # If no results files desired, then remove anything in the results directory
    if options.noResults:
        print('\n\n\n*** Removing results files for test ' + lclTestName)
        QAUTILS.runCmd('rm ' + COMMON.resultsDir + '/[b-z,A-Z]* >/dev/null 2>&1')

#==========================================================
# Need to address if subscriber external ID doesn't exist.
def tweakOptions(options):
    # Process subscriber
    if options.externalId:
      # Could be : or - for specifying OID
      for seperator in [':', '-']:
        # See if separator in input
        if options.externalId.count(seperator):
            # Set query type to be OID
            options.subQueryType = 'ObjectId'
            
            # No need to check other value
            break
    
    # Process modified subscriber
    if options.modExternalId:
      # Could be : or - for specifying OID
      for seperator in [':', '-']:
        # See if separator in input
        if options.modExternalId.count(seperator):
            # Set query type to be OID
            options.modSubQueryType = 'ObjectId'
            
            # No need to check other value
            break
    
    # Process group
    if options.groupId:
      # Could be : or - for specifying OID
      for seperator in [':', '-']:
        # See if separator in input
        if options.groupId.count(seperator):
            # Set query type to be OID
            options.groupQueryType = 'ObjectId'
            
            # No need to check other value
            break
    
    # Process modified group
    if options.modGroupId:
      # Could be : or - for specifying OID
      for seperator in [':', '-']:
        # See if separator in input
        if options.modGroupId.count(seperator):
            # Set query type to be OID
            options.modGroupQueryType = 'ObjectId'
            
            # No need to check other value
            break
    
    # Process device or access number
    #print str(options.subscriber) + '/' + str(options.deviceId) + '/' + str(options.accessNumbers)
    if options.deviceId and str(options.deviceId) != "10":
      # Could be : or - for specifying OID
      for seperator in [':', '-']:
        # See if separator in input
        if options.deviceId.count(seperator):
            # Set query type to be OID
            options.devQueryType = 'ObjectId'
            
            # No need to check other value
            break
    
    # If subscriber is default and device is not OID, then assume we don't want to use the default if IMSI was specified
    if str(options.subscriber) == '10' and options.devQueryType != 'ObjectId' and options.deviceId:
        options.subQueryType = options.devQueryType
        options.subscriber = options.deviceId
     
    elif options.accessNumbers and str(options.accessNumbers) != '10':
        # Device query type is access number
        options.devQueryType = 'AccessNumber'
        options.deviceId = options.accessNumbers
    
    # I don;t recall why I added this a second time, but options.deviceId could be set in the elif statement above...
    # If subscriber is default and device is not OID, then assume we don't want to use the default if IMSI was specified
    if str(options.subscriber) == '10' and options.devQueryType != 'ObjectId' and options.deviceId:
        options.subQueryType = options.devQueryType
        options.subscriber = options.deviceId
       
    return options
    
#==========================================================
def processPricingLoaded():
    # If restore, then want performance during init.  Disable stuff that's not required during a performance run.
    if PRIMDATA.regressionRun.lower() == 'restore':
      DIAMPKT.diameterFileDebugFlag = False
      DIAMUTILS.diameterFileDebugFlag = False
      COMMON.disableOutput = True
    
#==========================================================
def main():
    global testErrorLogger
    global RESTInst
    
    # ** Basic setup work
    
    # Set time to be now in the target timezone
    GET.commandTime = startTime = PRIM.getTimeNow()
    
    
    # IP address checks
    PRIM.checkIpAddress()

    # Path is always the current directory
    path = os.getcwd()
    
    # Get actual directory without all the preceeding directories
    currentDir = path.split('/')[-1]

    # Setup the starting test name for this scenario
    testName = currentDir
    
    # If a customer variable is set, then preface the test name with this
    if os.path.expandvars('$customer'):
      testName = os.path.expandvars('$customer') + DATA.fileChar + testName
    
    # Remove previous random results directories
    #QAUTILS.runCmd('rm -rf results[0-9]* >/dev/null 2>&1')
    
    # Print TF SVN version
    version = str(QAUTILS.runCmd('print_tf_version'))
    print('\n')
    if version.startswith('Revision'):  print('Test Framework SVN revision: ' + version)
    else:               print('Test Framework SVN revision: UNKNOWN')
    
    # ** Pre-init work ***
    
    # Get services config data 
    DATA.servicesConfig = PRIM.getServiceConfig()
    
    # Store release in user-friendly variable
    DATA.release = DATA.servicesConfig['release']
    
    # Process pricing loaded
    processPricingLoaded()
    
    # ** Post-init massaging of input parametes and global data
    
    # If CUST normalizer to mappings specified, do that here
    if hasattr(CUST, 'normalizerMappingList') and PRIMDATA.skipMyMatrixx.lower() != 'true':
      # May want to restore or save these.
      if PRIMDATA.regressionRun != 'None':
        extraString = '.  regressionRun action = ' + PRIMDATA.regressionRun
      else:   extraString = ''
      print('Doing custom normalizer mapping' + extraString)
      PRIM.normalizerMapping(PRIMDATA.regressionRun)
    elif PRIMDATA.skipMyMatrixx.lower() == 'true': print('** Skipping MyMatrixx reads due to environment variable skipMyMatrixx set to true **')
    
    # Get offer parameters
    PRIM.getAllParameterData(PRIMDATA.regressionRun)
    
    # Extend customer specific lists (needed from the start)
    PRIM.extendCustomerSpecifcLists(DATA.servicesConfig)
    
    # Update csv_data parameters to account for other system parameters (e.g. CCF).
    DATA.parameters.extend(CCF.parameters)
       
    # Make all binary paramerers map to True/False mappings.  Was done in csv_data.py, but now moved here to accomodate other files with theri specific parameters.
    # Want to auto-map all store_true and store_false parameters to the TrueFalse translation.  Avoid having to remember to do this each time a parameter is added.
    for param in [x[0] for x in DATA.parameters if x[1] in ['store_true', 'store_false']]: DATA.parameterTranslate.append((param, 'TrueFalse'))
    
    # ** Setup test - All parameters need to be defined by this point
    (Config,users,options,args,RESTInst,testErrorLogger) = QAUTILS.initializeTest(path)
    
    # Update alwaysIncludeParameters if additional ones passed in.
    # Setup so normal list processing works
    if options.addlIncludeParameters: options.addlIncludeParameters = options.addlIncludeParameters.replace(',', '@')
    
    # If diameter debug is desired, then enable debug flags
    if options.diamDebug:
      DIAMPKT.diameterFileDebugFlag = True
      DIAMUTILS.diameterFileDebugFlag = True
      COMMON.disableOutput = True

    # Make results directory if needed
    if options.randomizeResults: COMMON.resultsDir += str(random.randint(1,1000000))
    elif options.resultsDir:     COMMON.resultsDir = options.resultsDir
    
    # For some reason this always returns false.  Not sure why...  For now the only user is regresison and that code 
    # ensures the directory exists before invoking this code.
    d = path + '/' + COMMON.resultsDir
    if not os.path.isdir(d):
      print('RunCsvFile: Making directory "' + d + '"')
      os.makedirs(d)
      print('Results will be in directory "' + COMMON.resultsDir + '"')
    
    # Sanity check:  Get current domain loaded:
    cmdStart = GENERIC.primGetCurlUrlStart(options)
    
    # Get usage service types
    cmd = cmdStart + "/rsgateway/data/json/pricing/service_types | grep -B1 \"ParentId.*: 0\" | grep Name | cut -f4 -d'\"'"
    DATA.productList.extend(str(QAUTILS.runCmd(cmd)).split('\n'))
    DATA.productList = set(DATA.productList)
    #print 'Product List: ' + str(DATA.productList)
    # *** TO DO: Service types allow one to query each service (http://restgw:8080/rsgateway/data/v3/pricing/service_type/<num>), which gives the EventTypeId
    #        Then can query the event type (http://restgw:8080/rsgateway/data/v3/pricing/event_type/<EventTypeId>) to get the ContainerName.
    #        ContainerName is then used in saveData if the user specified a product.
    
    # OK; no good way to setup inputs if user specifies object ID.  Do that here. *****
    tweakOptions(options)
    
    # Get CB mappings (for ease of test generation).
    # Not really custom data (so should change the names...)
    #print('DATA.release = ' + DATA.release)
    PRIM.getCustomMappings(options.skipFriendlyNames, DATA.release, PRIMDATA.regressionRun)
    
    # Easy way to view custom data to see where stuff is...
    #pprint.pprint(GENERIC.CustomData)
    #sys.exit()
    
    # if testNameExtension input, then extend the test name by this
    if options.testNameExtension: testName += PRIM.fileChar + options.testNameExtension
    
    # HACK Alert:  had to put special characters in place of spaces for input parameters.  
    # Wherever that was done, undo here
    if options.offerId: options.offerId = options.offerId.replace('~',' ')
    
    # Set random value (for use with CER messages - allows multiple scripts to run at once)
    options.randomValue = str(random.randint(1,1000000))
    
    # *** Invoke event generation ***
    returnCode=parseMDCSendEvents(Config, users, options, testName)
    
    # *** Post test work ***
    
    # Logout from MyMatrixx
    CB.cbLogout()
    
    # Output subscriber AQM data
    TRACK.aqmSubscriberLogData(options.aqmFunction)
    
    # Output group AQM data
    TRACK.aqmGroupLogData(options.aqmFunction)
    
    # Close connections (if open)
    if TRACK.diamConnectionGx: 
      print('Closing Gx connection')
      TRACK.diamConnectionGx.close()
    if TRACK.diamConnectionGy: 
      print('Closing Gy connection')
      TRACK.diamConnectionGy.close()
    if TRACK.diamConnectionSy: 
      print('Closing Sy connection')
      TRACK.diamConnectionSy.close()
    if TRACK.diamConnectionSh: 
      print('Closing Sh connection')
      TRACK.diamConnectionSh.close()
    
    # Remove any temp files that may be left around
    QAUTILS.runCmd('rm _latestSub _saved* >/dev/null 2>&1')
    
    # If 5G server started by us, then kill it
    httpFile = os.getcwd() + '/' + COMMON.resultsDir + '/httpCreated'
    if FIVEG.FiveGServerRunning == True:
        print(QAUTILS.runCmd("killHTTP " + os.getcwd() + '/' + COMMON.resultsDir + '/httpCreated'))
        FIVEG.FiveGServerRunning = False
    
    # Check for errors
    if returnCode and returnCode != 0:
        testErrorLogger.printError(' main ==> scenario ' + testName + ' failed with returnCode=' + str(returnCode))

    # Report where results are if not in the default directory
    if COMMON.resultsDir != 'results': print('Results directory is "' + COMMON.resultsDir + '"')
    
    # Readability
    print('\n\n')
    
if __name__ ==  '__main__':
    main()

#===============================================================================
#
# Copyright 2011 - 2022, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

