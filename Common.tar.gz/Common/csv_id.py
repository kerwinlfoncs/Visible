#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:36:08
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:36:08
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:36:07
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

# NOTE:  Please do not import any additional QA test-specific files here.  This file is used
#        as part of the debug log analysis script and needs to run stand-alone
#        (i.e. only using Python libraries).  The files already imported have been setup to
#        work in this mode.

from __future__ import print_function
# from builtins import str
# from builtins import str
import csv_track as TRACK
import csv_data as DATA
import csv_prim as PRIM
import random, sys, copy, string, pprint
from primitives import timeToMDCtime as MDCTIME
#from string import maketrans
from primitives import primGeneric as GENERIC

#==========================================================
def setupMaxIdValues(options):
    # Process each ID value
    for param in DATA.idParameter:
        name = param[0]
        value = getattr(options, name)

        # Set max assigned IDs if the variable is defined, else set to 1
        if value and value.isdigit():   DATA.maxAssignedIds[name] = str(int(value) - 1)
        else:                           DATA.maxAssignedIds[name] = 1
    
    # If session ID was set by input, then use it as the current high, else get a random number
    sessionId = options.sessionId
    if int(sessionId) > 0:
        DATA.maxAssignedIds['sessionId'] = str(sessionId)
    else:
        DATA.maxAssignedIds['sessionId'] = str(random.randint(1,1073741824))

    # Copy max assigned values to last referenced values
    DATA.lastRefIds = copy.deepcopy(DATA.maxAssignedIds)
    
    # Return the session ID, as that may have changed in this function
    return DATA.maxAssignedIds['sessionId']
    
#==========================================================
def getAbsoluteIdValue(options, name, value, markAllowed):
    # Exit right away if nothing defined
    if not value: return (value, None)

    # Make sure the value is in string format
    value = str(value)
    
    # If passing in a parameter that shares an ID, then use the base parameter name
    if   name in ['modExternalId', 'referralExternalId']:
         name = 'externalId'
    elif name == 'modGroupId':
         name = 'groupId'
    elif name == 'refundSessionId':
         name = 'sessionId'
    elif name in ['imsi', 'newImsi']:
         name = 'deviceId'
    elif name == 'msisdn':
         name = 'accessNumbers'
    
    # Get the options value
    optionsVal = getattr(options, name)
    
    # Get max ID value
    maxID = DATA.maxAssignedIds[name]
    
    # Debug
    #if name == 'deviceId': print 'Device ID input = ' + str(value) + ', options value = ' + str(optionsVal)
    
    # Access numbers could be in the form of "a@b@c".  The input file way to specify a list.
    # If so, split here before doing the algorithm below
    valToUse = []
    if type(value) != type(list()):
        # Check if list character is present
        if DATA.listChar in value:
                # Convert to a list
                valToUse = value.split(DATA.listChar)
        else:
                # Single item - put into a list
                valToUse.append(value)
    else:
        # Is a list, so just copy over
        valToUse = copy.deepcopy(value)

    # Process each list item
    idx = 0
    for item in valToUse:
        # IDs are absolute or relative to their default values.  Need to adjust accordingly.
        if item[0] == 'a' and item[1:].isdigit():
                # Absolute number.  Remove leading 'a'
                valToUse[idx] = valToUse[idx].lstrip('a')
                
        # Also can be keywords.  Do those first;
        elif item.lower() == 'first':
                # Set to starting ID
                valToUse[idx] = optionsVal
        elif item.lower() == 'last':
                # Set to current highest ID
                valToUse[idx] = maxID
        elif item.lower() == 'lastref':
                # Set to last referenced ID
                valToUse[idx] = DATA.lastRefIds[name]
        elif item.lower() == 'next':
                # Set to next highest ID
                DATA.maxAssignedIds[name] = str(int(DATA.maxAssignedIds[name]) + 1)
                valToUse[idx] = DATA.maxAssignedIds[name]
                
        elif markAllowed and not item.isdigit() and item != '-1':
                # Put all possible types here...
                if name == 'externalId' or name == 'modExternalId':
                 # Can be a mark or an external ID
                 if item in TRACK.subscriberTracking:
                        # OK.  Now need to determine if it's a mark or the external ID string
                        if type(TRACK.subscriberTracking[item]) == type(dict()):
                                # This is an external ID.  Use as-is
                                print('Subscriber external ID "' + item + '" will be used')
                                valToUse[idx] = item
                        else:
                                # This is the mark.  
                                print('Subscriber mark "' + item + '" is tied to externalId ' + TRACK.subscriberTracking[item])
                                valToUse[idx] = TRACK.subscriberTracking[item]
                 else:
                        # Need to treat this as a new string ID
                        print('Using new external ID = ' + item)
                        valToUse[idx] = item
        
                elif name == 'userId':
                 # Can be a mark or an external ID
                 if item in TRACK.userTracking:
                        # OK.  Now need to determine if it's a mark or the external ID string
                        if type(TRACK.userTracking[item]) == type(dict()):
                                # This is an external ID.  Use as-is
                                print('User external ID "' + item + '" will be used')
                                valToUse[idx] = item
                        else:
                                # This is the mark.  
                                print('User mark "' + item + '" is tied to userId ' + TRACK.userTracking[item])
                                valToUse[idx] = TRACK.userTracking[item]
                 else:
                        # Need to treat this as a new string ID
                        print('Using new user ID = ' + item)
                        valToUse[idx] = item
        
                elif name == 'deviceId':
                 if item in TRACK.deviceTracking:
                        # OK.  Now need to determine if it's a mark or the external ID string
                        if type(TRACK.deviceTracking[item]) == type(dict()):
                                # This is an external ID.  Use as-is.
                                # Really shouldn't get here for now, as devices are required to be phone numbers (all numeric)...
                                print('Device external ID "' + item + '" will be used')
                                valToUse[idx] = item
                        else:
                                # This is the mark.
                                print('Device mark "' + item + '" is tied to deviceId ' + TRACK.deviceTracking[item])
                                valToUse[idx] = TRACK.deviceTracking[item]
                 else:
                        # Need to treat this as a new string ID
                        print('Using new device ID = ' + item)
                        valToUse[idx] = item

                elif name == 'groupId' or name == 'subGroupId' or name == 'modGroupId':
                 if item in TRACK.groupTracking:
                        # OK.  Now need to determine if it's a mark or the external ID string
                        if type(TRACK.groupTracking[item]) == type(dict()):
                                # This is an external ID.  Use as-is
                                print('Group external ID "' + item + '" will be used')
                                valToUse[idx] = item
                        else:
                                # This is the mark.
                                print('Group mark "' + item + '" is tied to externalId ' + TRACK.groupTracking[item])
                                valToUse[idx] = TRACK.groupTracking[item]
                 else:
                        # Need to treat this as a new string ID
                        print('Using new group ID = ' + item)
                        valToUse[idx] = item

        # Data line may not have specified the external ID, in which case it's already using the default one (which is fine).
        # Only override if it't not the default value AND if it's not negative (signal to not include in the Diameter event or to set to next highest value).
        # ISSUE:  if the relative offset equals the starting base ID (e.g. 1), then this fails.  This is documented in the tool guide, so leave as-is.
        elif optionsVal and item.isdigit() and int(item) >= 0 and int(item) != int(optionsVal):
                # Want to add the offset here to the default value
                valToUse[idx] = str(int(optionsVal) + int(item))
        
        # Set item to what was just calculated.  If none of the above applied (e.g. session ID that's a string), then use the value as-is.
        item = valToUse[idx]
        
        # Debug
#       if name == 'deviceId': print 'Device ID at the end = ' + str(item) + ', options value = ' + str(optionsVal)
        
        # If max used is above the max stored, then change
        if item.isdigit() and int(item) > int(maxID): # and item != optionsVal:
                DATA.maxAssignedIds[name] = item
        
        # Set last referenced value unless zero was passed in (which means ignore this)
        if (item.isdigit() and int(item) != 0) or not item.isdigit(): 
                DATA.lastRefIds[name] = item
        
        # Bump index counter
        idx += 1
        
    # Either return the list or a single element.  Depends on what was input
    if type(value) == type(list()) or DATA.listChar in value: return (valToUse, None)

    # Some extra processing if deviceId is the name and not a list and is digits
    elif name == 'deviceId' and not options.separateAccessNumbers and valToUse[0].isdigit(): return (valToUse[0], 'a' + valToUse[0])
        
    else: return (valToUse[0], None)

#==========================================================
def translate_data(name, value, mapping, exitOnNoMapping):
        #print 'In translate_data, name = ' + name + ', value = ' + str(value) + ', mapping = ' + str(mapping)
        
        # If parameter is not defined, then exit
        if not value: return value
        
        # If boolean, then leave as-is
        if isinstance(value, bool): return value
        
        # Convert to string for analysis
        value = str(value)
        
        # Numbers starting with a special character are passed through untouched.
        if value[0] in ['+']: return value
        
        # See if key is not in global
        if value.lower() not in mapping and value not in mapping and value.upper() not in mapping:
                # Be nice - check if case is only difference
                found = False
                for key in mapping:
                   # User try/except to allow for non-ASCII characters in the names
                   try:
                        if  value.lower() == str(key).lower():
                                print('Warning: input parameter "' + name + '" value "' + value + '" matches but mixed case values wrong.  Using value "' + key + '"')
                                found = True
                                value = key
                                break
                   except: pass
                
                # See if still not found
                if not found:
                        # If hex digits, then return them as-is
                        if len(value) > 1 and all(c in string.hexdigits for c in value.replace('.','0')): return value
                        
                        # If numeric, return as-is
                        # Can also be an IP address here.  If so, that's fine as well (i.e. don't translate).
                        # Can also be single characters, which are not hex digits (so allow translation).
                        intab = "*#"
                        outtab = "00"
                        trantab = str.maketrans(intab, outtab)
                        if str(value).translate(trantab).isdigit(): return value
                        
                        # If set to error on no mapping, then exit
                        if exitOnNoMapping:
                                print('ERROR:  translation of ' + name + ' entered with invalid value: ' + str(value))
                                print('Valid values are:')
                                pprint.pprint(mapping)
                                sys.exit('Exiting due to errors')
                        else: 
                                # Debug data
                                #print 'Didn\'t find ' + value + ' in table ' + str(mapping)
                                
                                # Return the value
                                return value
        
        # Return translated value (check in expected order)
        if   value in mapping:
                #print 'Returning value = ' + str(mapping[value])
                return mapping[value]
        elif value.lower() in mapping:
                #print 'Returning value = ' + str(mapping[value.lower()])
                return mapping[value.lower()]
        else:
                #print 'Returning value = ' + str(mapping[value.upper()])
                return mapping[value.upper()]
        
#===============================================================================
def getDataInMiddle(constantKey, parameter, lclDCT):
        # Get parameter value
        constant = lclDCT[parameter]
        
        # Loop until done with parameter
        idx = 0
        result = ''
        while idx < len(constant):
                # Stop if nothing else found
                start = constant[idx:].find(constantKey+'{')
                if start < 0:
                        # Copy remainder of input
                        result += constant[idx:]
                        break
                
                # Copy up to the start of the field
                result += constant[idx:idx+start]
                
                # Get end of the field
                end = constant[idx+start+2:].find('}')
                
                # Get the parameter.  What to do depends on the constant key value.
                if constantKey == '$':
                        # Constants
                        localConstant = constantKey + constant[idx+start+2:idx+start+2+end]
                        
                        # Get the value
                        result += getConstantValue(parameter, localConstant, output=True)
                else:
                        # Variable
                        localParameter = constant[idx+start+2:idx+start+2+end]
                        
                        # Get the data value
                        result += getDataValue(lclDCT, localParameter, output=True)
                
                # Set new index
                idx += start + 2 + end + 1
        
        return result

#===============================================================================
def getData(constantKey, parameter, lclDCT):
        if constantKey == '$':  return getConstantValue(parameter, lclDCT[parameter], output=False)
        else:                   return getDataValue(lclDCT, parameter, output=False)
        
#===============================================================================
def getDataValue(lclDCT, parameter, output=True):
        #print('getDataValue: processing parameter ' + parameter)
        
        # If not defined as a constant, then skip
        if parameter not in lclDCT:
                # Print warning if this looks like a variable
                print('Warning: it appears as if parameter "' + parameter + '" is referencing a TF parameter that\'s not defined')
                retVal = None
        else:
                # Replace the value with the constant
                retVal = lclDCT[parameter]
                
                # Catch indirection.  Use try/except in case parameter is boolean
                try:
                  if retVal[0] == '*':
                        print('Parameter value is ' + retVal + ', so getting the value of ' + retVal[1:])
                        retVal = lclDCT[retVal[1:]]
                except: pass
                
                if output: print('TF parameter "' + parameter + '" has value: "' + str(retVal) + '"')
        
        return  str(retVal)

#===============================================================================
def getConstantValue(parameter, constant, output=True):
        retVal = constant
        
        # Remove leading constant character
        constant = constant[1:]

        # If not defined as a constant, then skip
        if constant not in DATA.constantValue:
                # Print warning if this looks like a variable
                # If a float then use as-is
                if constant.replace('.','',1).isdigit(): print('Assuming constant is a monetary amount as all characters are int/float')
                else:
                        # Return value without leading constant character
                        print('Warning: it appears as if parameter "' + parameter + '" is referencing a constant that\'s not yet been set (' + constant + ')')
                        retVal = '"' + constant + '"'
        else:
                # Replace the value with the constant
                retVal = DATA.constantValue[constant]
                if output: print('Constant "' + constant + '" has value: "' + str(retVal) + '"')
        
        return  str(retVal)

#===============================================================================
def getCommandLineTime(parameter, inputTime, currentTime, sepChar):
        # Split time as if a list (but not a TF list parameter - much too late to make startTime parameter a list)
        inputTime = inputTime.split('@')
        for inTime in inputTime:
                # Save value
                prevTime = currentTime
                
                # Process input
                currentTime = MDCTIME.getCommandLineTime(parameter, inTime, currentTime, sepChar)
                
                # Remove usec from times
                currentTime = currentTime.split('.')
                if len(currentTime) > 1: currentTime = currentTime[0] + currentTime[1][6:]
                else:                   currentTime = currentTime[0]
                
                prevTime = prevTime.split('.')
                if len(prevTime) > 1:   prevTime = prevTime[0] + prevTime[1][6:]
                else:                   prevTime = prevTime[0]
                
                # If a list then report all changes
                if len(inputTime) > 1: print('Intermediate change from time ' + prevTime + ' to time ' + currentTime + ' from input "' + inTime + '"')
                
        # Return last value
        return currentTime

#==========================================================

def main():
    x = 1


if __name__ == '__main__':
    main()

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


