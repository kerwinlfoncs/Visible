#!yusr/bin/python
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:35:29
#
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:35:29
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:35:27
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
from __future__ import print_function
# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
import sys, copy, pprint, json
import QA_subscriber_management_restv3 as REST_UTIL
import csv_track as TRACK
import csv_qa as CSVQA
import custSpecific as CUST
import csv_prim as PRIM
import csv_data as DATA
import qa_utils as QAUTILS
import csvMain as CSV
import csv_CmdMisc as MISC
import csv_Events as CSVEVENTS
import xml.etree.ElementTree as ET
import diameter_utils as DIAMU
import commonDefs as COMMON

from primitives import primGET as GET
from primitives import primGeneric as GENERIC
from primitives import primData as PRIMDATA

# Global for device rating
RefundData = {}

#==========================================================
def CmdDev_removedevice(lclDCT, testName, sessionId, line, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, repeatCount):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        accessNumbers = lclDCT['accessNumbers']
        # End of local variables setup.

        # Set object type (for ease of cut/paste to other objects)
        objType='device'
        
        # Get parameter to pass in (using devQueryType)
        if   devQueryType == 'LoginId':         device = lclDCT['LoginId']
        elif devQueryType == 'ExternalId':      device = lclDCT['devExternalId']
        elif devQueryType == 'PhoneNumber':     device = accessNumbers[0] if type(accessNumbers) == type(list()) else accessNumbers
        else:                                   device = deviceId
        
        print('Looking to remove ' + objType + ' ' + str(device) + ' (' + devQueryType + ')')

        # First order is to get object data
        q = GET.getObject(device, hostname=QAUTILS.gatewaysConfig.get('REST', 'restServer'), hostport=QAUTILS.gatewaysConfig.get('REST', 'restPort'), queryType=devQueryType, objType=objType)
        
        # If Q is empty, then nothing to do
        if q is None:
                print(objType + ' ' + str(deviceId) + '(' + devQueryType + ') non-existent.')

                # Nothing to query
                queryType = queryValue = None

                return (queryType, queryValue)
        
        # Get OID
        #ET.dump(q)
        # Get OID
        try:
                oid = q.find('./ObjectId').text.strip()
        except:
                print(objType + ' ' + str(deviceId) + '(' + devQueryType + ') non-existent.')

                # Nothing to query
                queryType = queryValue = None

                return (queryType, queryValue)
        
        # *** Want to find time for delete.  Should match latest time that something new started in the object ***
        savedInputTime = lclStartTime
        lclStartTime = PRIM.findObjectLatestTime(q, lclStartTime, objType, deviceId, devQueryType)
        
        # See if device is attached to a subscriber
        try:
                subOid = q.find('./SubscriberId').text.strip()
        except:
                subOid = None
        if subOid:
                newLine = 'removeDeviceFromSubscriber;devQueryType=ObjectId;deviceId=' + oid + ';subQueryType=ObjectId;externalId=' + subOid + ';deleteSessions=true;noChecks=True;skipStepResults=' + str(lclDCT['skipStepResults'])
                (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)
                
        # ** Now want remove the object.  Every customer has their own states.  TF writes these into customer specific logic.
        stateMap = copy.deepcopy(CUST.devStateMap)
        
        # Get object state
        try:
                objState = q.find('./StatusDescription').text.strip()
        except:
                objState = 'Active'
        
        # Debug output
        #print 'stateMap = ' + str(stateMap) + ', starting state = ' + objState
        
        # Get parameter to pass in (using devQueryType)
        if   devQueryType == 'LoginId':         devData = 'LoginId=' + lclDCT['LoginId']
        elif devQueryType == 'ExternalId':      devData = 'devExternalId=' + lclDCT['devExternalId']
        elif devQueryType == 'PhoneNumber':     devData = 'accessNumbers=' + accessNumbers[0] if type(accessNumbers) == type(list()) else accessNumbers
        else:
                # Use OID
                devData = 'deviceId=' + oid
                devQueryType='ObjectId'
        
        objState = objState.lower()
        while stateMap[objState] != 'Remove':
                # Get next state
                objState = stateMap[objState]
                
                # Modify to next state.  Need to use input ID and query type as login devices are treated different from non-login devices.
                newLine='modifyDevice;deviceId=' + devData + ';devQueryType=' + devQueryType + ';devStatus=' + objState + ';noChecks=True;skipStepResults=' + str(lclDCT['skipStepResults']) + ';rmvFlag=1'
                (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)
                
        # Delete object
        newLine='deleteDevice;deviceId=' + oid + ';devQueryType=ObjectId;noChecks=True;skipStepResults=' + str(lclDCT['skipStepResults'])
        (step, lclStartTime, repeat, options, sessionId, saveResult) = CSV.processSingleLineInput(testName, sessionId, newLine, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, 1)
        
        # Nothing to query
        queryType = queryValue = None
        
        return (queryType, queryValue)
        
#==========================================================
def CmdDev_createdevice(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        LoginId = lclDCT['LoginId']
        devExternalId = lclDCT['devExternalId']
        accessNumbers = lclDCT['accessNumbers']
        # End of local variables setup.

        # Get parameter to pass in (using devQueryType)
        if   devQueryType == 'LoginId':         device = LoginId
        elif devQueryType == 'ExternalId':      device = devExternalId
        elif devQueryType == 'AccessNumber':    device = accessNumbers[0] if type(accessNumbers) == type(list()) else accessNumbers
        else:                                   device = deviceId

        # Device should not exist
        if device in TRACK.deviceTracking and not lclDCT['noChecks'] and not DATA.mrEnabled:
                print('ERROR: device with ID "' + device + '" is defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        #print 'creating device ID ' + deviceId + ' with access number ' + str(accessNumbers)
        
        # Debug output
        print('Creating device External ID = ' + str(lclDCT['devExternalId']) + ', ID = ' + str(device) + ', accessNumbers = ' + str(lclDCT['accessNumbers']))
        #if lclDCT['customAttr'][0]: print 'Including custom parameters: ' + str(lclDCT['customAttr'][0])
        
        # Code to allow input of 0 to not send one of the values
        if deviceId.isdigit() and int(deviceId) == 0: deviceId = None
        if accessNumbers:
           an = accessNumbers[0] if type(accessNumbers) == type(list()) else accessNumbers
           if int(an == 0): accessNumbers = None

        
        # Execute primitive
        retCode = REST_UTIL.createDevice(RESTInst,
                        deviceId,
                        externalId=lclDCT['devExternalId'],
                        deviceType=lclDCT['deviceType'],
                        attr=lclDCT['customAttr'][0],
                        accessNumbers=lclDCT['accessNumbers'],
                        now=lclStartTime,
                        eventPass=lclDCT['eventPass'],
                        status=lclDCT['devStatus'],
                        routingType=lclDCT['routingType'],
                        routingValue=lclDCT['routingValue'],
                        multiRequestBuild=DATA.V3Builder,
                        apiEventData=lclDCT['customAttr'][6],
                        tenantId=lclDCT['tenantId'],
                        )
                
        # Update tracking data, even if a Multi request (as we want to know about this device)
        if lclDCT['eventPass']: TRACK.updateTrackingData(lclDCT['ACTION'], deviceId = device, accessNumbers = lclDCT['accessNumbers'], mark=lclDCT['mark'], RESTInst=RESTInst)
                
        # If doing multi-request, then need to switch RESTInst
        if DATA.mrEnabled:
                # Store request
                DATA.mrCommands.append((retCode))
                
                # Store multi request index in case it's used later in the MR
                DATA.mrIndexObjectExternalId.append((deviceId))
                
                # Query nothing
                queryValue = None
                queryType = None
        else:
                # Query device
                lclDCT['saveFunc'] = 'saveDeviceMDC'
                queryValue = device
                queryType = devQueryType
                
        return (queryType, queryValue)
        
#==========================================================
def CmdDev_deletedevice(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        accessNumbers = lclDCT['accessNumbers']
        # End of local variables setup.

        # Get parameter to pass in (using devQueryType)
        if   devQueryType == 'LoginId':
                # Command may have specified deviceId and no LoginId...
                if (not lclDCT['LoginId']) and deviceId: LoginId = deviceId
                else: LoginId = lclDCT['LoginId']
                device = LoginId
        elif devQueryType == 'ExternalId':
                device = lclDCT['devExternalId']
        elif devQueryType == 'PhoneNumber':
                device = accessNumbers[0] if type(accessNumbers) == type(list()) else accessNumbers
        else:   
                device = deviceId
        
        # Device should exist
        if deviceId not in TRACK.deviceTracking and not lclDCT['noChecks']:
                print('ERROR: device with ID "' + deviceId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        print('Deleting device ' + str(device))
        # Execute primitive
        retCode = REST_UTIL.deleteDevice(RESTInst,
                device,
                now=lclStartTime,
                eventPass=lclDCT['eventPass'],
                queryType=devQueryType,
                deleteSession=lclDCT['deleteSessions'],
                apiEventData=lclDCT['customAttr'][6],
                )

        # Update tracking data if event expected to pass
        if lclDCT['eventPass']: TRACK.updateTrackingData(lclDCT['ACTION'], deviceId = deviceId, RESTInst=RESTInst)

        # Query nothing here
        queryValue = queryType = None

        return (queryType, queryValue)
        
#==========================================================
def CmdDev_modifydevice(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        accessNumbers = lclDCT['accessNumbers']
        # End of local variables setup.

        # Get parameter to pass in (using devQueryType)
        if   devQueryType == 'LoginId':
                # Command may have specified deviceId and no LoginId...
                if (not lclDCT['LoginId']) and deviceId: LoginId = deviceId
                else: LoginId = lclDCT['LoginId']
                device = LoginId
        elif devQueryType == 'ExternalId':
                device = lclDCT['devExternalId']
        elif devQueryType == 'PhoneNumber':
                device = accessNumbers[0] if type(accessNumbers) == type(list()) else accessNumbers
        else:   
                device = deviceId
        
        # Device should exist
        if device not in TRACK.deviceTracking and not lclDCT['noChecks']:
                print('ERROR: device with ID "' + device + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # OK...  We can have stuff that has been defaulted.  For modifies, only want to send in what was specifically requested to be modified.
        # Some fields (e.g. profileId) can't be modified and even setting them to the same value they were created with causes issues.
        # Build command to exec (very non-Pythonic...)
        if cmdLineInput:
         for param in DATA.deviceModifyList + [x[0] for x in DATA.customDeviceParameters]:
                if not cmdLineInput.count(param): lclDCT[param] = None
         
         # Really should recalculate Attr parameters as above lines were meant to clear those that were not input in the command line...
         (devAttr, subAttr, groupAttr, offerAttr, userAttr, loginAttr, apiEventDataAttr) = PRIM.getCustomAttributes(lclDCT, cmdLineInput)
        else:
                # Copy from dictionary
                apiEventDataAttr = lclDCT['customAttr'][6]
                devAttr = lclDCT['customAttr'][5] if devQueryType in ['LoginId', 'PhoneNumber'] else lclDCT['customAttr'][0]
          
        # If removing, then don't update stuff
        if lclDCT['rmvFlag'] in ['1', True]:
                devAttr = None
                accessNumbers = None
                deviceType = None
                newImsi = None
        else:
                accessNumbers = lclDCT['accessNumbers']
                deviceType = lclDCT['deviceType']
                newImsi = lclDCT['newImsi']
        
        # Clear access numbers if not input (value of 0 means not desired)
        if str(accessNumbers) == '0': accessNumbers = None
        
        # Minor hack.  May end with the same external ID 
        # Debug output
        print('Modifying device ' + device + ' with access number ' + str(accessNumbers))
        #if lclAttr: print 'encluding custom parameters: ' + str(devAttr)

        # Execute primitive
        retCode = REST_UTIL.modifyDevice(RESTInst,
                device,
                loginId=lclDCT['modLoginId'],
                externalId=lclDCT['modExternalId'],
                queryType=devQueryType,
                deviceType=deviceType,
                attr=devAttr,
                accessNumbers=accessNumbers,
                now=lclStartTime,
                eventPass=lclDCT['eventPass'],
                status=lclDCT['devStatus'],
                lastActivityUpdateTime=lclDCT['lastActivityUpdateTime'],
                imsi=newImsi,
                apiEventData=apiEventDataAttr,
                )

        # Update tracking data
        if lclDCT['eventPass'] and not lclDCT['noChecks']: TRACK.updateTrackingData(lclDCT['ACTION'], deviceId = device, accessNumbers = accessNumbers, modId=newImsi)

        # Query device
        lclDCT['saveFunc'] = 'saveDeviceMDC'
        queryType = devQueryType
        
        # Want to query based on the new login ID if it changed
        if queryType == 'LoginId' and lclDCT['modLoginId']: LoginId = lclDCT['modLoginId']
        
        # Deice ID may have changed
        if newImsi:
                # Query the new value
                queryValue = newImsi
                
                '''
                # Also update input options, as this contains the "imsi" input value
                if options.imsi:        options.imsi = newImsi
                if options.deviceId:    options.deviceId = newImsi
                '''
        elif devQueryType == 'LoginId'  and lclDCT['modLoginId']:         queryValue = LoginId
        elif devQueryType == 'PhoneNumber' and accessNumbers:             queryValue = accessNumbers[0] if type(accessNumbers) == type(list()) else accessNumbers
        elif devQueryType == 'ExternalId' and lclDCT['modExternalId']:    queryValue = lclDCT['modExternalId']
        else:                                                             queryValue = device

        return (queryType, queryValue)
        
#==========================================================
def CmdDev_removedevicefromsubscriber(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        accessNumbers = lclDCT['accessNumbers']
        # End of local variables setup.

        # Item should exist.  Skip if in a multi-request.
        if not lclDCT['noChecks'] and lclDCT['subQueryType'] != 'MultiRequestIndex':
                # Check subscriber or subscription
                if lclDCT['externalId'] not in TRACK.subscriberTracking:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + lclDCT['externalId'] + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Get parameter to pass in (using devQueryType)
        if   devQueryType == 'LoginId':         device = lclDCT['LoginId']
        elif devQueryType == 'ExternalId':      device = lclDCT['devExternalId']
        elif devQueryType == 'PhoneNumber':     device = accessNumbers[0] if type(accessNumbers) == type(list()) else accessNumbers
        else:                                   device = deviceId
        
        # Device should exist
        if device not in TRACK.deviceTracking and not lclDCT['noChecks']:
                print('ERROR: device with ID "' + str(device) + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        print('removing device ID ' + device + ' from ' + REST_UTIL.subUrl + ' ' + lclDCT['externalId'] + ' with delete session option = ' + str(lclDCT['deleteSessions']))
        # Execute primitive
        retCode = REST_UTIL.removeDeviceFromSubscriber(RESTInst,
                lclDCT['externalId'],
                deviceId=device,
                subQueryType=lclDCT['subQueryType'],
                devQueryType=devQueryType,
                now=lclStartTime,
                eventPass=lclDCT['eventPass'],
                deleteSession=lclDCT['deleteSessions'],
                apiEventData=lclDCT['customAttr'][6],
                )

        # Update tracking data
        if lclDCT['eventPass'] and not lclDCT['noChecks']: TRACK.updateTrackingData(lclDCT['ACTION'], externalId = lclDCT['externalId'], deviceId = device)

        # Query device
        lclDCT['saveFunc'] = 'saveDeviceMDC'
        queryValue = device
        queryType = devQueryType

        return (queryType, queryValue)
        
#==========================================================
def CmdDev_adddevicetosubscriber(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        accessNumbers = lclDCT['accessNumbers']
        # End of local variables setup.

        # Item should exist.  Skip if in a multi-request.
        if not lclDCT['noChecks'] and lclDCT['subQueryType'] != 'MultiRequestIndex':
                # Check subscriber or subscription
                if lclDCT['externalId'] not in TRACK.subscriberTracking:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + lclDCT['externalId'] + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Clear access numbers if not input (value of 0 means not desired)
        if str(lclDCT['accessNumbers']) == '0': accessNumbers = None
        else: accessNumbers = lclDCT['accessNumbers']
        
        # Get parameter to pass in (using devQueryType)
        if   devQueryType == 'LoginId':         device = lclDCT['LoginId']
        elif devQueryType == 'ExternalId':      device = lclDCT['devExternalId']
        elif devQueryType == 'PhoneNumber':     device = accessNumbers[0] if type(accessNumbers) == type(list()) else accessNumbers
        else:                                   device = deviceId
        
        # Debug output
        print('adding device ID ' + str(device) + ' to ' + REST_UTIL.subUrl + ' ' + lclDCT['externalId'] + ' with access numbers ' + str(accessNumbers))
        if lclDCT['subQueryType'] == 'MultiRequestIndex': print(REST_UTIL.subUrl.capitalize() + ' external ID = ' + str(DATA.mrIndexObjectExternalId[int(externalId)]))
        if devQueryType == 'MultiRequestIndex': print('Device     external ID = ' + str(DATA.mrIndexObjectExternalId[int(deviceId)]))
        #if lclDCT['customAttr'][0]: print 'Including custom parameters: ' + str(lclDCT['customAttr'][0])
        
        # Execute primitive
        retCode = REST_UTIL.addDeviceToSubscriber(RESTInst,
                        lclDCT['externalId'],
                        deviceId=device,
                        deviceType=lclDCT['deviceType'],
                        subQueryType=lclDCT['subQueryType'],
                        devQueryType=devQueryType,
                        attr=lclDCT['customAttr'][0],
                        accessNumbers=accessNumbers,
                        now=lclStartTime,
                        eventPass=lclDCT['eventPass'],
                        status=lclDCT['devStatus'],
                        multiRequestBuild=DATA.V3Builder,                       
                        apiEventData=lclDCT['customAttr'][6],
                        )

        # Stuff to do if we passed
        if lclDCT['eventPass']:
                # If doing a multi-request then update IDs 
                if lclDCT['subQueryType'] == 'MultiRequestIndex': externalId = DATA.mrIndexObjectExternalId[int(lclDCT['externalId'])]
                if devQueryType == 'MultiRequestIndex': deviceId   = DATA.mrIndexObjectExternalId[int(deviceId)]
                
                # Update tracking data
                TRACK.updateTrackingData(lclDCT['ACTION'], externalId = lclDCT['externalId'], deviceId = device, accessNumbers = accessNumbers)
        
                # Update CSR so we can login as this access number
                if PRIMDATA.skipMyMatrixx.lower() != 'true':
                        accessNumToUse = []
                        if type(accessNumbers) == type(list()):
                                accessNumToUse = accessNumbers
                        else:
                                accessNumToUse.append(accessNumbers)
                                for aN in accessNumToUse: QAUTILS.updateCsrData(aN)
                        
        # If doing multi-request, then need to switch RESTInst
        if DATA.mrEnabled:
                # Store request
                DATA.mrCommands.append((retCode))
                
                # Query nothing
                queryValue = None
                queryType = None
        else:
                # Query device
                lclDCT['saveFunc'] = 'saveDeviceMDC'
                queryValue = device
                queryType = devQueryType

        return (queryType, queryValue)
        
#==========================================================
def CmdDev_devicemodifyoffer(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        offerStartTime = lclDCT['offerStartTime']
        # End of local variables setup.

        # Device should exist
        if deviceId not in TRACK.deviceTracking and not lclDCT['noChecks']:
                print('ERROR: device with ID "' + deviceId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        #print 'In Device Purchase offer code'

        # Want to update local start time variable, so it's ready for the next iteration.
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        # Set the ofer start time to whatever the local test tool time if it's not specified via the input.
        if offerStartTime == None:
                if lclDCT['futureTime']:  offerStartTime = lclDCT['futureTime']
                else:           offerStartTime = lclStartTime
#        else: lclStartTime = offerStartTime

        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        elif lclStartTime != offerStartTime:
             print('Changing local test run time from ' + lclStartTime + ' to ' + offerStartTime + ' because offer start time parameter was specified.')
             lclStartTime = offerStartTime

        # Save updated time
        lclDCT['lclStartTime'] = lclStartTime

        # If the deviceId is negative, then use the accessNumbers
        if not deviceId.isdigit():
                # Change the query type
                devQueryType = 'LoginId'
                queryValue = deviceId
                queryType = 'LoginId'
        elif int(deviceId) < 0:
                # Assume we have an access number in this scenario...
                deviceId=lclDCT['accessNumbers']

                # Also change the query type
                devQueryType = 'AccessNumber'
                queryValue = deviceId
                queryType = 'AccessNumber'
        else:
                queryValue = deviceId
                queryType = 'PhoneNumber'

        # Can provide devOfferId or offerId for this command.
        # Map to offer ID.
        if (not lclDCT['offerId'] or lclDCT['offerId'].count('0')) and lclDCT['devOfferId']: offerId = lclDCT['devOfferId']
        else: offerId = lclDCT['offerId']
        
        # If no resource ID passed in, then need to get using the external ID
        if resourceId == 0:
                offerDict = PRIM.getOfferData('device', queryValue, resourceId, offerId[0], lclStartTime, lclDCT['ACTION'], queryType=queryType, offerIsCatalog=True)

                # Get the resource ID
                resourceId = int(offerDict['ResourceId'])
        print('Device ' + str(queryValue) + ' modifying offer with exernal ID = ' + offerId[0] + ', resource ID ' + str(resourceId))
        
        # Build offer parameters
        try:    parameterList = PRIM.buildOfferParameters(CUST.custOfferParameterList, lclDCT)
        except: parameterList = None
        #print 'parameterList: ' + str(parameterList)
        
        # Execute primitive
        retCode = REST_UTIL.deviceOfferModify(RESTInst,
                queryValue,
                resourceId=resourceId,
                startTime=offerStartTime,
                endTime=lclDCT['offerEndTime'],
                attr=lclDCT['customAttr'][3],
                eventPass=lclDCT['eventPass'],
                queryType=queryType,
                cycleType=lclDCT['offerCycleType'],
                cycleResourceId=lclDCT['offerCycleResourceId'],
                cycleOffset=lclDCT['offerCycleOffset'],
                status=lclDCT['offerStatus'],
                cycleAlignmentDisabled=lclDCT['offerCycleAlignmentDisabled'],
                immediateChange=lclDCT['immediateChange'],
                now=lclStartTime,
                apiEventData=lclDCT['customAttr'][6],
                cycleStartTime=lclDCT['offerCycleStartTime'],
                cycleEndTime=lclDCT['offerCycleEndTime'],
                parameterList=parameterList,
                endTimeExtensionOffset = lclDCT['offerEndTimeExtensionOffset'],
                endTimeExtensionOffsetUnit = lclDCT['offerEndTimeExtensionOffsetUnit'],
                )

        # Update tracking data
        # NOTE:  if multiple resources were sent through, then need to fix the TRACK function...
        #if eventPass: TRACK.updateTrackingData(lclDCT['ACTION'], deviceId = groupId, offerId = offerId, resourceId = resourceId[0])
        
        lclDCT['saveFunc'] = 'saveDeviceMDC'

        return (devQueryType, deviceId)
        
#==========================================================
def CmdDev_devicesubscribetooffer(lclDCT, options, RESTInst, cmdLineInput):
        # Overloaded purchase offer command
        return CmdDev_devicepurchaseoffer(lclDCT, options, RESTInst, cmdLineInput)
        
#==========================================================
def CmdDev_devicepurchaseoffer(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        offerStartTime = lclDCT['offerStartTime']
        autoActivationCycleResourceId = lclDCT['autoActivationCycleResourceId']
        # End of local variables setup.

        # Device should exist
        if deviceId not in TRACK.deviceTracking and not lclDCT['noChecks']:
                print('ERROR: device with ID "' + deviceId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        #print 'In Device Purchase offer code'

        # Want to update local start time variable, so it's ready for the next iteration.
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        # Set the ofer start time to whatever the local test tool time if it's not specified via the input.
        if offerStartTime == None:
                if lclDCT['futureTime']:  offerStartTime = lclDCT['futureTime']
                else:           offerStartTime = lclStartTime
#        else: lclStartTime = offerStartTime

        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        elif lclStartTime != offerStartTime:
             print('Changing local test run time from ' + lclStartTime + ' to ' + offerStartTime + ' because offer start time parameter was specified.')
             lclStartTime = offerStartTime

        # Save updated time
        lclDCT['lclStartTime'] = lclStartTime

        # If the deviceId is negative, then use the accessNumbers
        if not deviceId.isdigit():
                # Change the query type
                devQueryType = 'LoginId'
                queryValue = deviceId
                queryType = 'LoginId'
        elif int(deviceId) < 0:
                # Assume we have an access number in this scenario...
                deviceId=lclDCT['accessNumbers']

                # Also change the query type
                devQueryType = 'AccessNumber'
                queryValue = deviceId
                queryType = 'AccessNumber'
        else:
                queryValue = deviceId
                queryType = 'PhoneNumber'
        
        # ** Now work on offers.  Can have two parameters to specify this.  Can buy by external ID or catalog ID.  Can by legacy product ID or current catalog ID.
        # ** More difficult than it should be...
        (catalogItemId,offerId) = PRIM.processOffers(lclDCT['offerId'], lclDCT['devOfferId'], lclDCT['offerIsExternal'], lclDCT['offerIsCatalog'])
        
        # If no offers specified, then this is an error
        if not offerId: sys.exit('ERROR: issued device purchase offer command but did not specify any offers (offerId or devOfferId parameters)')
        
        # Debug output
        print('Device = ' + deviceId + '(' + devQueryType + ') is purchasing catalog item '  + str(offerId) + ' with start/end times ' + str(offerStartTime) + '/' + str(lclDCT['offerEndTime']))
        
        # Having fun with preActiveState and JSON.  If false set to None
        if lclDCT['preActiveState'] == False or str(lclDCT['preActiveState']).lower() == '0': preActiveState = None
        else: preActiveState = lclDCT['preActiveState']
        
        # Fix down payment of 0 to be None
        if str(lclDCT['amount']) == '0': amount = None
        else: amount = lclDCT['amount']
        
        # If resource IDs passed in as a non-integer, then need to get its resource ID assuming they're offer external IDs
        for param in ['autoActivationCycleResourceId', 'offerCycleResourceId']:
                # Get the local parameter value
                value = lclDCT[param]
                
                # See if defined and not an integer and not 0 (so not a resource ID)
                if value and not (value.isdigit() and value != '0'):
                        # Get resource ID data
                        offerDict = PRIM.getOfferData('device', deviceId, 0, value, lclStartTime, lclDCT['ACTION'], queryType=devQueryType, offerIsCatalog=True)
                        
                        # Get the resource ID
                        if   param == 'autoActivationCycleResourceId': autoActivationCycleResourceId = int(offerDict['ResourceId'])
                        elif param == 'offerCycleResourceId':          offerCycleResourceId = int(offerDict['ResourceId'])
                        
                        print('Retrieved ' + param + ' = ' + offerDict['ResourceId'])
        
        # Build offer parameters
        try:    parameterList = PRIM.buildOfferParameters(CUST.custOfferParameterList, lclDCT)
        except: parameterList = None
        #print 'parameterList: ' + str(parameterList)
        
        # Build US Tax data
        geoData = REST_UTIL.createGeoData(geoCode=lclDCT['geoCode'], postalCode=lclDCT['postalCode'], plus4=lclDCT['plus4'], npa=lclDCT['npa'], nxx=lclDCT['nxx'])
        
        if lclDCT['allOffers'] and lclDCT['trace']:
           # Want a trace after each purchase
           for offerItem in offerId:
            # Execute primitive
            (retCode, resourceIds) = REST_UTIL.devicePurchaseOffer(RESTInst,
                deviceId,
                offerItem,
                offerStartTime=offerStartTime,
                offerEndTime=lclDCT['offerEndTime'],
                eventPass=lclDCT['eventPass'],
                queryType=devQueryType,
                now=lclStartTime,
                offerIsExternal=lclDCT['offerIsExternal'],
                attr=lclDCT['customAttr'][3],
                catalogItemId=catalogItemId,
                chargeMethod=lclDCT['chargeMethod'],
                paymentMethodResourceId=lclDCT['paymentMethodResourceId'],
                paymentGatewayId=lclDCT['paymentGatewayId'],
                paymentGatewayOneTimeToken=lclDCT['paymentGatewayOneTimeToken'],
                purchaseInfo=lclDCT['purchaseInfo'],
                cycleOwnerType=lclDCT['cycleOwnerType'],
                offerCycleType=lclDCT['offerCycleType'],
                offerCycleResourceId=lclDCT['offerCycleResourceId'],
                offerCycleOffset=lclDCT['offerCycleOffset'],
                offerCycleStartTime=lclDCT['offerCycleStartTime'],
                preActiveState=preActiveState,
                activationExpirationTime=lclDCT['activationExpirationTime'],
                activationExpirationRelativeOffsetUnit=lclDCT['activationExpirationRelativeOffsetUnit'],
                activationExpirationRelativeOffset=lclDCT['activationExpirationRelativeOffset'],
                endTimeRelativeOffsetUnit=lclDCT['endTimeRelativeOffsetUnit'],
                endTimeRelativeOffset=lclDCT['endTimeRelativeOffset'],
                grantPurchaseProrationType=lclDCT['grantProrationType'],
                chargePurchaseProrationType=lclDCT['chargeProrationType'],
                apiEventData=lclDCT['customAttr'][6],
                contractPeriod=lclDCT['contractPeriod'],
                contractInterval=lclDCT['contractInterval'],
                commitmentPeriod=lclDCT['commitmentPeriod'],
                commitmentPeriodInterval=lclDCT['commitmentPeriodInterval'],
                isOpenContract=lclDCT['isOpenContract'],
                etcScheduleRangeArray=lclDCT['etcScheduleRangeArray'],
                etcScheduleRangeUnit=lclDCT['etcScheduleRangeUnit'],
                paymentScheduleRangeArray=lclDCT['paymentScheduleRangeArray'],
                paymentScheduleAmountArray=lclDCT['paymentScheduleAmountArray'],
                paymentScheduleLastAmount=lclDCT['paymentScheduleLastAmount'],
                delayCharge=lclDCT['delayCharge'],
                parameterList=parameterList,
                
                geoData=geoData,
                
                )

            # Run trace command (output goes to std out)
            PRIM.printToScreen('saveDeviceMDC', deviceId, devQueryType, lclDCT, lclStartTime)

        else:
          # Check if multiple IDs requested
          if lclDCT['everyDevInGroup']:
                msisdnList = TRACK.retrieveTrackingData('EveryAccessNumberInGroupEvent', groupId = lclDCT['groupId'])
                devQueryType = 'AccessNumber'
          else: msisdnList = [deviceId]
          
          for Id in msisdnList:
           print('Executing command for ID ' + str(Id))

           # Execute primitive
           (retCode, response) = REST_UTIL.devicePurchaseOffer(RESTInst,
                Id,
                offerId,
                offerStartTime=offerStartTime,
                offerEndTime=lclDCT['offerEndTime'],
                eventPass=lclDCT['eventPass'],
                queryType=devQueryType,
                now=lclStartTime,
                offerIsExternal=lclDCT['offerIsExternal'],
                attr=lclDCT['customAttr'][3],
                catalogItemId=catalogItemId,
                cycleOwnerType=lclDCT['cycleOwnerType'],
                chargeMethod=lclDCT['chargeMethod'],
                paymentMethodResourceId=lclDCT['paymentMethodResourceId'],
                paymentGatewayId=lclDCT['paymentGatewayId'],
                paymentGatewayOneTimeToken=lclDCT['paymentGatewayOneTimeToken'],
                purchaseInfo=True,
                offerCycleType=lclDCT['offerCycleType'],
                offerCycleResourceId=lclDCT['offerCycleResourceId'],
                offerCycleOffset=lclDCT['offerCycleOffset'],
                offerCycleStartTime=lclDCT['offerCycleStartTime'],
                preActiveState=preActiveState,
                activationExpirationTime=lclDCT['activationExpirationTime'],
                activationExpirationRelativeOffsetUnit=lclDCT['activationExpirationRelativeOffsetUnit'],
                activationExpirationRelativeOffset=lclDCT['activationExpirationRelativeOffset'],
                endTimeRelativeOffsetUnit=lclDCT['endTimeRelativeOffsetUnit'],
                endTimeRelativeOffset=lclDCT['endTimeRelativeOffset'],
                autoActivationTime=lclDCT['autoActivationTime'],
                autoActivationRelativeOffsetUnit=lclDCT['autoActivationRelativeOffsetUnit'],
                autoActivationRelativeOffset=lclDCT['autoActivationRelativeOffset'],
                autoActivationCycleResourceId=autoActivationCycleResourceId,
                downPayment=amount,
                grantPurchaseProrationType=lclDCT['grantProrationType'],
                chargePurchaseProrationType=lclDCT['chargeProrationType'],
                reason=lclDCT['reason'],
                info=lclDCT['info'],
                isRecurringFailureAllowed=lclDCT['isRecurringFailureAllowed'],
                apiEventData=lclDCT['customAttr'][6],
                contractPeriod=lclDCT['contractPeriod'],
                contractInterval=lclDCT['contractInterval'],
                commitmentPeriod=lclDCT['commitmentPeriod'],
                commitmentPeriodInterval=lclDCT['commitmentPeriodInterval'],
                isOpenContract=lclDCT['isOpenContract'],
                etcScheduleRangeArray=lclDCT['etcScheduleRangeArray'],
                etcScheduleRangeUnit=lclDCT['etcScheduleRangeUnit'],
                paymentScheduleRangeArray=lclDCT['paymentScheduleRangeArray'],
                paymentScheduleAmountArray=lclDCT['paymentScheduleAmountArray'],
                paymentScheduleLastAmount=lclDCT['paymentScheduleLastAmount'],
                delayCharge=lclDCT['delayCharge'],
                parameterList=parameterList,
                )
                
           # Do stuff if expecting success
           if lclDCT['eventPass']:
                # Store purchase constants
                PRIM.storeOfferConstants('device', response, catalogItemId, offerId)
                
                # Update tracking data
                TRACK.updateTrackingData(lclDCT['ACTION'], deviceId = deviceId, offerId = offerId, resourceId = [resourceId])

        lclDCT['saveFunc'] = 'saveDeviceMDC'

        return (devQueryType, deviceId)
        
#==========================================================
def CmdDev_deviceunsubscribefromoffer(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        # End of local variables setup.

        # Device should exist
        if deviceId not in TRACK.deviceTracking and not lclDCT['noChecks']:
                print('ERROR: device with ID "' + deviceId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Set ofer end time to local time if it's not already set
        if not lclDCT['offerEndTime']: offerEndTime = lclStartTime
        else: offerEndTime = lclDCT['offerEndTime']

        # If the deviceId is negative, then use the accessNumbers
        if not deviceId.isdigit():
                # Change the query type
                devQueryType = 'LoginId'
                queryValue = deviceId
                queryType = 'LoginId'
        elif int(deviceId) < 0:
                # Assume we have an access number in this scenario...
                deviceId=lclDCT['accessNumbers']

                # Also change the query type
                devQueryType = 'AccessNumber'
                queryValue = deviceId
                queryType = 'AccessNumber'
        else:
                queryValue = deviceId
                queryType = 'PhoneNumber'

        # Can provide devOfferId or offerId for this command.
        # Map to offer ID.
        if (not lclDCT['offerId'] or lclDCT['offerId'].count('0')) and lclDCT['devOfferId']: offerId = lclDCT['devOfferId']
        else: offerId = lclDCT['offerId']
        
        # If no resource ID passed in, then need to get using the external ID
        if resourceId in [0, 'first', 'second', 'third', 'last']:
                resourceData = ''
                for idx in range(len(offerId)):
                        offerDict = PRIM.getOfferData('device', deviceId, 0, offerId[idx], lclStartTime, lclDCT['ACTION'], queryType=devQueryType, offerIsCatalog=lclDCT['offerIsCatalog'])
                        
                        # Get the resource ID
                        resourceData += str(offerDict['ResourceId']) + '@'
                
                # Remove trailing list character
                resourceId = resourceData[:-1]

        # Convert resource ID to a list
        resourceId = resourceId.split('@')
        
        # Set ofer end time to local time if it's not already set
        if not offerEndTime: offerEndTime = lclStartTime

        # Execute primitive
        retCode = REST_UTIL.deviceCancelOffer(RESTInst,
                deviceId,
                resourceId=resourceId,
                endTime=offerEndTime,
                eventPass=lclDCT['eventPass'],
                queryType=devQueryType,
                eligibilityCheck=lclDCT['eligibilityCheck'],
                now=offerEndTime,
                apiEventData=lclDCT['customAttr'][6],
                )

        # Update tracking data
        if lclDCT['eventPass']: TRACK.updateTrackingData(lclDCT['ACTION'], deviceId = deviceId, resourceId = resourceId)

        lclDCT['saveFunc'] = 'saveDeviceMDC'
        return (devQueryType, deviceId)
        
#==========================================================
def CmdDev_querydevice(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        outputFileName = lclDCT['outputFileName']
        accessNumbers = lclDCT['accessNumbers']
        # End of local variables setup.

        # NOTE. If saveData specified then the query should succeed and the eventpass is tied to the saveData option.
        if lclDCT['saveData']: eventPass = True
        else: eventPass = lclDCT['eventPass']
        
        # Get parameter to pass in (using devQueryType)
        if   devQueryType == 'LoginId':         device = lclDCT['LoginId']
        elif devQueryType == 'ExternalId':      device = lclDCT['devExternalId']
        elif devQueryType == 'PhoneNumber':     device = accessNumbers[0] if type(accessNumbers) == type(list()) else accessNumbers
        else:
                # Standard device ID
                device = deviceId
                
                # If the deviceId is negative, then use the accessNumbers
                try: 
                        x = int(deviceId)
                        intFlag = True
                except: intFlag = False
                 
                if intFlag and int(device) < 0:
                        # Assume we have an access number in this scenario...
                        device=lclDCT['accessNumbers']
                        
                        # Also change the query type
                        devQueryType = 'AccessNumber'
                        queryValue = deviceId
                        queryType = 'AccessNumber'
                else:
                        # Device should exist
                        if device not in TRACK.deviceTracking and not lclDCT['noChecks'] and eventPass:
                                print('WARNING: device with ID "' + device + '" is not defined')
                                sys.exit('Error on command: ' + lclDCT['ACTION'])
                        
                        queryValue = device
                        queryType = 'PhoneNumber'
        
        # If verbose set but no output file, then set to stdout
        if lclDCT['verbose'] in ['full', 'high'] and not outputFileName: outputFileName = 'stdout'
        
        # May be here just to get the normal output file.  Check and skip this query if so
        if lclDCT['saveData'] or (outputFileName and outputFileName.lower() != 'none'):
             # Execute primitive
             retCode = REST_UTIL.queryDevice(RESTInst,
                device,
                eventPass=eventPass,
                queryType=devQueryType,
                now=lclStartTime
                )

             # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
             try:
                respData = str(retCode.printElementBasedXml())
             except:
                respData = str(retCode)
                
             # If supposed to save data to variables then do that here
             if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, 'Device', respData)

             # if supposed to store output then write to where the caller wanted it to go.  Only if not saving data.
             elif outputFileName and outputFileName.lower() != 'none': CSVQA.processDataToOutput(respData, outputFileName)

        lclDCT['saveFunc'] = 'saveDeviceMDC'
        if not eventPass: queryValue = None
        return (devQueryType, device)
        
#==========================================================
def CmdDev_modifydeviceoffer(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        offerStartTime = lclDCT['offerStartTime']
        # End of local variables setup.

        # If the deviceId is negative, then use the accessNumbers
        if not deviceId.isdigit():
                # Change the query type
                devQueryType = 'LoginId'
                queryValue = deviceId
                queryType = 'LoginId'
        elif int(deviceId) < 0:
                # Assume we have an access numbe rin this scenario...
                deviceId=lclDCT['accessNumbers']

                # Also change the query type
                devQueryType = 'AccessNumber'
                queryValue = deviceId
                queryType = 'AccessNumber'
        else:
                # Device should exist
                if deviceId not in TRACK.deviceTracking and not lclDCT['noChecks']:
                        print('WARNING: device with ID "' + deviceId + '" is not defined')
#                       sys.exit('Error on command: ' + lclDCT['ACTION'])

                queryValue = deviceId
                queryType = 'PhoneNumber'
        
        # If no resource ID passed in, then need to get using the external ID.
        if resourceId == 0:
                offerDict = PRIM.getOfferData('device', queryValue, resourceId, lclDCT['offerId'][0], lclStartTime, lclDCT['ACTION'], queryType=queryType, offerIsCatalog=True)

                # Get the resource ID
                resourceId = int(offerDict['ResourceId'])
                print('Device ' + str(lclDCT['externalId']) + ' modifying offer with exernal ID = ' + lclDCT['offerId'][0] + ', resource ID ' + str(resourceId))
        
        # If resource IDs passed in as a non-integer, then need to get its resource ID assuming they're offer external IDs
        for param in ['offerCycleResourceId']:
                # Get the local parameter value
                value = lclDCT[param]
                
                # See if defined and not an integer and not 0 (so not a resource ID)
                if value and not (value.isdigit() and value != '0'):
                        # Get resource ID data
                        offerDict = PRIM.getOfferData('device', deviceId, 0, value, lclStartTime, lclDCT['ACTION'], queryType=devQueryType, offerIsCatalog=True)
                        
                        # Get the resource ID
                        if param == 'offerCycleResourceId':          offerCycleResourceId = int(offerDict['ResourceId'])
                        
                        print('Retrieved ' + param + ' = ' + offerDict['ResourceId'])
        
        # Can provide devOfferId or offerId for this command.
        # Map to offer ID.
        if (not lclDCT['offerId'] or lclDCT['offerId'].count('0')) and lclDCT['devOfferId']: offerId = lclDCT['devOfferId']
        else: offerId = lclDCT['offerId']

        # Execute primitive
        retCode = REST_UTIL.deviceOfferModify(RESTInst,
                deviceId,
                queryType=queryType,
                resourceId=resourceId,
                startTime=offerStartTime,
                endTime=lclDCT['offerEndTime'],
                attr=lclDCT['customAttr'][3],
                eventPass=lclDCT['eventPass'],
                cycleType=lclDCT['offerCycleType'],
                cycleResourceId=lclDCT['offerCycleResourceId'],
                cycleOffset=lclDCT['offerCycleOffset'],
                status=lclDCT['offerStatus'],
                cycleAlignmentDisabled=lclDCT['offerCycleAlignmentDisabled'],
                immediateChange=lclDCT['immediateChange'],
                apiEventData=lclDCT['customAttr'][6],
                )

        lclDCT['saveFunc'] = 'saveDeviceMDC'
        return (devQueryType, deviceId)
        
#==========================================================
def CmdDev_devicequeryaggregation(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        # End of local variables setup.

        # Device should exist
        if deviceId not in TRACK.deviceTracking and not lclDCT['noChecks']:
                print('WARNING: device with ID "' + deviceId + '" is not defined')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Execute primitive
        retCode = REST_UTIL.queryDeviceAggregation(RESTInst,
                deviceId, queryType=devQueryType, eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])

        # Save device
        queryValue = deviceId
        queryType = devQueryType
        lclDCT['saveFunc'] = 'saveDeviceMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdDev_devicedeletesession(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        # End of local variables setup.

        # Device should exist
        if deviceId not in TRACK.deviceTracking and not lclDCT['noChecks']:
                print('WARNING: device with ID "' + deviceId + '" is not defined')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # If a mark was entered, then get diameter details
        subSession = 0
        if lclDCT['mark']:
                (mark, externalId, deviceId, accessNumbers, subSession, sessionId, ratingGroup, interface) = \
                        PRIM.getDiamMark(lclDCT['mark'], lclDCT['subMark'], lclDCT, lclDCT['requestType'], lclDCT['externalId'], deviceId, lclDCT['accessNumbers'], subSession, lclDCT['sessionId'], lclDCT['ratingGroup'], lclDCT['interface'], verbose=lclDCT['verbose'])

                # Set diamConnection
                if (not interface) or (interface.lower() == 'gy'):
                        diamConnection = TRACK.diamConnectionGy
                        sessionType=1
                elif interface.lower() == 'sy':
                        diamConnection = TRACK.diamConnectionSy
                        sessionType=2
                else:
                        diamConnection = TRACK.diamConnectionGx
                        sessionType=3
        else:
                sessionType = lclDCT['sessionType']
                sessionId = lclDCT['sessionId']
        
        # If no session ID entered, then delete them all
        if int(sessionId) == 0: sessionId = None
        
        # Execute primitive
        retCode = REST_UTIL.deleteDeviceSession(RESTInst, deviceId, queryType=devQueryType, sessionIdList=sessionId, sessionType=sessionType, eventPass=lclDCT['eventPass'], now=None)
        
        # Save nothing; no changes to the object
        queryValue = None
        queryType = None
        lclDCT['saveFunc'] = 'saveDeviceMDC'

        return (queryType, queryValue)

#==========================================================
def CmdDev_devicevalidatesession(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        # End of local variables setup.

        # Device should exist
        if deviceId not in TRACK.deviceTracking and not lclDCT['noChecks']:
                print('WARNING: device with ID "' + deviceId + '" is not defined')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Execute primitive
        retCode = REST_UTIL.validateDeviceSession(RESTInst, deviceId, queryType=devQueryType, sessionId=lclDCT['sessionId'], sessionType=lclDCT['sessionType'], eventPass=lclDCT['eventPass'], now=None)
        
        # Save nothing; no changes to the object
        queryValue = None
        queryType = None
        lclDCT['saveFunc'] = 'saveDeviceMDC'

        return (queryType, queryValue)

#==========================================================
def CmdDev_devicequerysession(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        # End of local variables setup.

        # Device should exist
        if deviceId not in TRACK.deviceTracking and not lclDCT['noChecks']:
                print('WARNING: device with ID "' + deviceId + '" is not defined')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Execute primitive
        retCode = REST_UTIL.queryDeviceSession(RESTInst, deviceId, queryType=devQueryType, eventPass=lclDCT['eventPass'], now=None)
        
        # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
        try:
                respData = str(retCode.printElementBasedXml())
        except:
                respData = str(retCode)
                
        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(respData, lclDCT['outputFileName'])

        # Save nothing; no changes to the object
        queryValue = None
        queryType = None
        lclDCT['saveFunc'] = 'saveDeviceMDC'

        return (queryType, queryValue)

#==========================================================
def CmdDev_deviceevaluatesypolicy(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        # End of local variables setup.

        # Device should exist
        if deviceId not in TRACK.deviceTracking and not lclDCT['noChecks']:
                print('WARNING: device with ID "' + deviceId + '" is not defined')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Execute primitive
        retCode = REST_UTIL.deviceEvaluateSyPolicy(RESTInst, deviceId ,queryType=devQueryType, now=None, eventPass=lclDCT['eventPass'])
        
        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])

        # Save nothing; no changes to the object
        queryValue = None
        queryType = None
        lclDCT['saveFunc'] = 'saveDeviceMDC'

        return (queryType, queryValue)
#==========================================================
def CmdDev_devicequeryevent(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        # End of local variables setup.

        # Device should exist
        if deviceId not in TRACK.deviceTracking and not lclDCT['noChecks']:
                print('ERROR: Device with ID "' + deviceId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Want to loop here until everything is retrieved
        qc = lclDCT['queryCursor']
        respData = ''
        while qc != 0:
                # Execute primitive
                (retCode, qc) = REST_UTIL.queryDeviceEvent(RESTInst,
                        deviceId,
                        queryType=devQueryType,
                        querySize=lclDCT['querySize'],
                        eventPass=lclDCT['eventPass'],
                        queryCursor = qc,
                        now=lclStartTime,
                        eventTimeLowerBound=lclDCT['eventTimeLowerBound'],
                        eventTimeUpperBound=lclDCT['eventTimeUpperBound'],
                        eventTypeStringArray=lclDCT['eventTypeStringArray']
                        )
                
                # If we're expected to fail then we may get nothing back, so break from here
                if not lclDCT['eventPass']: break
                
                # Get cursor value.  Seeing it's not always returned...
                try: qc = int(qc)
                except:
                        print('Did not get back an int for qc: ' + str(qc))
                        qc = 0
                
                # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
                try:
                        respData += str(retCode.printElementBasedXml())
                except:
                        respData += str(retCode)
        
        # See if we're supposed to process assoiated or secondary events
        #print respData
        if lclDCT['processSecondaryEvents'] or lclDCT['processAssociatedEvents']: respData = CSVEVENTS.processOtherEvents(respData, lclDCT, RESTInst)
        
        # Write to where the caller wanted it to go
        if lclDCT['eventPass']:
                # If supposed to save data to variables then do that here
                if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, 'Event', respData)

                # Write to where the caller wanted it to go iff not saving data
                else: CSVQA.processDataToOutput(respData, lclDCT['outputFileName'])
                
        # Query None
        queryValue = queryType = None
        lclDCT['saveFunc'] = 'saveDeviceMDC'

        return (queryType, queryValue)

#==========================================================
def CmdDev_createdevicelogin(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        # End of local variables setup.

        # Command may have specified deviceId and no LoginId...
        if (not lclDCT['LoginId']) and deviceId: LoginId = deviceId
        else: LoginId = lclDCT['LoginId']
        
        # Login should not exist
        if LoginId in TRACK.deviceTracking and not lclDCT['noChecks']:
                print('ERROR: Device login with ID "' + LoginId + '" is defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Don't include access number if none specified
        if str(lclDCT['accessNumbers']) == '0': accessNumbers = None
        else: accessNumbers = lclDCT['accessNumbers']
        
        # Debug output
        print('Creating device external ID = ' + str(lclDCT['devExternalId']) + ', login ID = ' + str(LoginId) + ', accessNumbers = ' + str(accessNumbers))
        #if lclDCT['customAttr'][5]: print 'Including custom parameters: ' + str(lclDCT['customAttr'][5])

        # Execute primitive
        retCode = REST_UTIL.createDeviceLogin(RESTInst,
                loginId=LoginId,
                externalId = lclDCT['devExternalId'],
                deviceType=lclDCT['deviceType'],
                attr=lclDCT['customAttr'][5],
                accessIds=accessNumbers,
                now=lclStartTime,
                eventPass=lclDCT['eventPass'],
                status=lclDCT['devStatus'],
                routingType=lclDCT['routingType'],
                routingValue=lclDCT['routingValue'],
                multiRequestBuild=DATA.V3Builder,
                apiEventData=lclDCT['customAttr'][6],
                tenantId=lclDCT['tenantId'],
                )

        # Query device
        lclDCT['saveFunc'] = 'saveDeviceMDC'
        queryType = devQueryType
        
        # Query value van be one of several
        if   devQueryType == 'LoginId':         queryValue = LoginId
        elif devQueryType == 'ExternalId':      queryValue = lclDCT['devExternalId']
        else:                                   queryValue = accessNumbers[0]

        # Update tracking data
        if lclDCT['eventPass']: TRACK.updateTrackingData(lclDCT['ACTION'], deviceId = queryValue, accessNumbers = accessNumbers, mark=lclDCT['mark'])

        # If doing multi-request, then need to switch RESTInst
        if DATA.mrEnabled:
                # Store request
                DATA.mrCommands.append((retCode))
                
                # Store multi request index in case it's used later in the MR
                DATA.mrIndexObjectExternalId.append((deviceId))
                
                # Query nothing
                queryValue = None
                queryType = None
        
        return ('LoginId', LoginId)
        
#==========================================================
def CmdDev_devicewaitforstate(lclDCT, options, RESTInst, cmdLineInput):
        return  PRIM.waitforstate(lclDCT, options, RESTInst, cmdLineInput, target='device')


#==========================================================
def CmdDev_devicequeryeventstore(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        # End of local variables setup.

        # Device should exist
        if deviceId not in TRACK.deviceTracking and not lclDCT['noChecks']:
                print('ERROR: Device with ID "' + deviceId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Call primitive
        # Force event pass to true, as we want to check the results, not the API call
        eventPass = lclDCT['eventPass']
        lclDCT['eventPass'] = True
        respData = CSVEVENTS.checkEvents('device', devQueryType, deviceId, lclDCT, RESTInst, lclStartTime, lclDCT['testName'])
        lclDCT['eventPass'] = eventPass
        
        # Write to where the caller wanted it to go
        if lclDCT['eventPass']:
                # Make sure we found something
                if not respData.count("List"):
                        print('ERROR: query did not return any notifications or events')
                        print(respData)
                        sys.exit('Exiting due to errors')
                
                # If user requested a specific string to check for, then validate that here
                if lclDCT['eventStringToCheckFor'] and not respData.count(lclDCT['eventStringToCheckFor']):
                        print('ERROR: query did not return expected string: "' + lclDCT['eventStringToCheckFor'] + '"')
                        print(respData)
                        sys.exit('Exiting due to errors')
                
                # See if user wants viewEventStore output
                if lclDCT['outputFileName'].lower() == 'view':
                        # Call viewEventStore.
                        # Different options depending on query type
                        if   devQueryType.lower() == 'phonenumber': viewOption = '--imsi '
                        elif devQueryType.lower() == 'accessnumber': viewOption = '--msisdn '
                        elif devQueryType.lower() == 'objectid': viewOption = '--doid '
                        else:
                                print('NOTE: devQueryType = ' + str(devQueryType) + ', which doesn\'t translate to a viewEventStore input')
                                viewOption = None

                        # Report if we know what to do
                        if viewOption:
                                cmd = 'viewEventStore.py ' + viewOption + str(deviceId) + ' --outputFile ' + str(lclDCT['outputFileName'])
                                if lclDCT['showGl']: cmd += ' --showGl'
                                print('Running command: ' + cmd)
                                print(QAUTILS.runCmd(cmd) + '\n\n')
                else:   CSVQA.processDataToOutput(respData, lclDCT['outputFileName'])

        else:
                # Make sure we didn't found something
                if respData.count("List"):
                        print('ERROR: query returned notifications or events and none were expected')
                        print(respData)
                        sys.exit('Exiting due to errors')       
        
        # Query None
        queryValue = queryType = None
        lclDCT['saveFunc'] = 'saveDeviceMDC'

        return (queryType, queryValue)

#==========================================================
def CmdDev_devicerating(lclDCT, options, RESTInst, cmdLineInput):
        global RefundData
        
        # Assume no refund
        refundInformation = None
        
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        # End of local variables setup.

        # Query subscriber (saveFunc dictates this)
        queryValue = deviceId
        queryType = devQueryType

        # Device should exist
        if deviceId not in TRACK.deviceTracking and not lclDCT['noChecks']:
                print('ERROR: device with ID "' + deviceId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Set start/stop value
        if   lclDCT['requestType'].count('init'):
                rt = 'start'
                amount = lclDCT['reqAmount'][0]
        elif lclDCT['requestType'] == 'event':
                rt = 'start'
                amount = lclDCT['reqAmount'][0]
                
                # If doing a refund then get refund information
                if lclDCT['requestAction'] == '1':
                        # Need to have saved the refund information or overridden it
                        if lclDCT['refundOverride'] == '0':
                                print('Refund override indicates no Refund-Information AVP for session ID ' + str(lclDCT['sessionId']))
                                refundInformation = None
                        elif lclDCT['refundOverride']:
                                print('Refund override indicates ' + lclDCT['refundOverride'] + ' to be sent in the Refund-Information AVP for session ID ' + str(lclDCT['sessionId']))
                                refundInformation = lclDCT['refundOverride']
                        elif str(lclDCT['sessionId']) in RefundData:
                                refundInformation = RefundData[lclDCT['sessionId']]
                                print('Saved refund data ' + refundInformation + ' to be sent in the Refund-Information AVP for session ID ' + str(lclDCT['sessionId']))
                        else:   sys.exit('ERROR: refund session ' + str(lclDCT['sessionId']) + ' was not saved.')
        else:
                rt = 'stop'
                amount = lclDCT['usedAmount'][0]
        
        # Need quantity type and units.  Tied to service ID.
        # NOTE: Need to address currency...
        quantitySelector = DIAMU.getQuantitySelector(lclDCT['serviceId'], mscc = True)
        if quantitySelector == 'totalData':
                quantity = 'TotalDataQuantity'
                unitVal = '200'
                unit = 'DataUnit'
        elif quantitySelector == 'inData':
                quantity = 'InDataQuantity'
                unitVal = '200'
                unit = 'DataUnit'
        elif quantitySelector == 'outData':
                quantity = 'OutDataQuantity'
                unitVal = '200'
                unit = 'DataUnit'
        elif quantitySelector == 'actualDuration':
                quantity = 'ActualDurationQuantity'
                unitVal = '100'
                unit = 'DurationUnit'
        elif quantitySelector == 'monetary':
                quantity = 'MonetaryQuantity'
                unitVal = None
                unit = None
        else:
                quantity = 'Quantity'
                unitVal = None
                unit = None
                
                # For SMS/MMS one can pass in currency.  Address that here.
                if str(amount).startswith(DATA.localCurrency[DATA.localCurrencyToUse]):
                        # Get rid of currency characters
                        amount = str(amount)[len(DATA.localCurrency[DATA.localCurrencyToUse]):]
                        
                        # Set the unit to Monetary
                        quantity = 'MonetaryQuantity'
                        
                        # Clear other fields
                        unitVal = unit = None
        
        # Build the attr dictionary
        attr = {}
        attr['ratingGroup'] = lclDCT['ratingGroup']
        #attr['serviceId'] = ratingGroup
        attr['eventTime'] = lclStartTime
        attr['quantity'] = quantity
        attr['unitVal'] = unitVal
        attr['unitType'] = unit
        attr['refundInformation'] = refundInformation
        attr['requestType'] = rt
        attr['calledStation'] = lclDCT['calledStation']
        attr['requestAction'] = lclDCT['requestAction']
        attr['TgppSgsnMccMnc'] = lclDCT['TgppSgsnMccMnc']
        
        # *** Dictionary entry to store custom DiamRoMsg and MSCC parameters
        attr['DiamRoParams'] = {}
        attr['MsccParams'] = {}
#       pprint.pprint( GENERIC.CustomData['DiamRoMsg'])
        
        # Store custom DiamRoMsg fields here (so 1:1 mapping)
        try:
                for param in GENERIC.CustomData['DiamRoMsg']['customFields']:
                        if param in lclDCT and lclDCT[param] not in [None, '']: attr['DiamRoParams'][param] = str(lclDCT[param])
        except: pass
        
        # Add custom MSCC fields here
        '''
        try:
                for param in GENERIC.CustomData['MultiServiceData']['customFields']:
                        if param in lclDCT and lclDCT[param] not in [None, '']: attr['MsccParams'][param] = str(lclDCT[param])
        except: pass
        '''
        
        # *** Add custom names to attr.
        for item in [('customName', 'MtxDiamRoMsg'), ('customMsccName', 'MtxMultiServiceData')]:
                # Split names
                (name, value) = item
                
                # Store custom name if present, stripping of leading 'Mtx'
                try:
                        #pprint.pprint(GENERIC.CustomData)
                        attr[name] = GENERIC.CustomData[value[3:]]['customName']
                except: pass
                
                # Make sure something is set (if no custom DiamRoMsg defined)
                if name not in attr or not attr[name]: attr[name] = value
        
        # Hack until we can set the Op field
        '''
        if requestType == 'event':      attr['PrefixIn'] = 'KEF'
        else:                           attr['PrefixIn'] = None
        '''
        
        # Map rt value to Op
        if lclDCT['requestType'] == 'event': attr['op'] = 1
        elif rt == 'start':                  attr['op'] = 2
        elif rt == 'stop':                   attr['op'] = 4
        else:                                attr['op'] = 3
        
        # Set template based on current rest version
        attr['templateFile'] = 'usage_adv_' + rt + '.' + REST_UTIL.restVersion.lower()
        
        # Slight hack.  Some VAS services need external service type set.  Set to None here 
        #               so the template will be processed properly (i.e. line removed if no ExternalServiceType specified).
        attr['ExternalType'] = None
        
        # *** DO NOT set any attr items below here.  Custom code can override whatever they want. ***
        
        # Allow for per-customer customizations
        if hasattr(CUST, "custDeviceRatingAttributes"): CUST.custDeviceRatingAttributes(lclDCT, attr)
        '''
        print 'deviceRating: attr = '
        pprint.pprint(attr)
        '''
        
        # CUST code may decide not to run the command.  This would be a value in dictionary entry "doNotRunCommand"
        if "doNotRunCommand" in lclDCT:
                # CUST code wants to skip command execution
                print('Custom code custDeviceRatingAttributes() defined entry "doNotRunCommand", so skipping command execution')
                return (queryType, queryValue)
        
        # Debug output
        if lclDCT['verbose'] in ['medium', 'high']:
                print('Rating device ID ' + deviceId + ' ' + lclDCT['requestType'])
                pprint.pprint(attr) 
                print()
        
        '''
        # Send funky session ID and see what happens (it works)
        sessionId="'$trans'"
        '''
        
        # Execute primitive
        response = REST_UTIL.deviceRating(RESTInst,
                deviceId,
                queryType=devQueryType,
                amount=amount,
                service=COMMON.serviceIdDefs[lclDCT['serviceId']]['serviceIdDct'],
                sessionId=lclDCT['sessionId'],
                serviceContextId=COMMON.serviceIdDefs[lclDCT['serviceId']]['serviceIdContextDct'],
                eventPass=lclDCT['eventPass'],
                attr=attr)

        # Debug output
        if lclDCT['verbose'] in ['medium', 'high']: print(str(response))
        
        # Author trying to find a common way to process both JSON and XML returns. For now just process JSON.
        if REST_UTIL.restVersion == 'JSON':
         # Look for any result code.
         index = 0
         searchStr = '"Result": '
         for i in range(response.count(searchStr)):
                # Go to just past the current substring
                valueIdx = response[index:].find(searchStr) + len(searchStr)
                
                # Grab the result value
                value = int(response[index+valueIdx:].split(',')[0].strip())
                if value: print('Result string: ' + str(value))
                
                # See if it matches expected results
                if ((value != 0) and lclDCT['eventPass']) or ((value == 0) and not lclDCT['eventPass']):
                        # Command failed
                        print('ERROR: expected result is ' + str(lclDCT['eventPass']) + ', and result code was ' + str(value))
                        
                        # If not continuing past the error then exit here.
                        if not int(lclDCT['continuePastError']): sys.exit('Exiting due to errors')
                        
                        # Exit here, as we're continuing past errors but nothing more to do here.
                        return (queryType, queryValue)
                
                # Bump starting point beyond the current result
                index += valueIdx
                
                # Looks like we should break when first failure found, as otherwise the outer success 
                # will mess up expected failures...
                if value != 0: break
                
         # Search for refund info if the type is event and debiting and expected to pass.
         if lclDCT['requestType'] == 'event' and lclDCT['requestAction'] == '0' and lclDCT['eventPass']:
                # Find the start of the refund info string
                start = response.find('"RefundInfo": "')
                if start == -1: print('Hmmm.  No refund information returned')
                else:
                        # Get start of refund info
                        start += len('"RefundInfo": "')
                        
                        # Find the end of the refund info
                        end = response.find('"', start)
                        
                        # Get the refund string
                        refundInfo = response[start:end]
                        print('Found refund information: ' + refundInfo + ' for session ID ' + str(lclDCT['sessionId']))
        
                        # Save in global data
                        RefundData[lclDCT['sessionId']] = refundInfo

        # Update tracking data if event expected to pass and not a diameter event
        if lclDCT['eventPass'] and not lclDCT['noChecks'] and lclDCT['requestType'] != 'event': TRACK.updateTrackingData(lclDCT['ACTION'], deviceId=deviceId, mark=lclDCT['mark'])

        return (queryType, queryValue)

#==========================================================
def CmdDev_devicecanceloffer(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        # End of local variables setup.

        # Device should exist
        if deviceId not in TRACK.deviceTracking and not lclDCT['noChecks']:
                print('ERROR: device with ID "' + deviceId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Set ofer end time to local time if it's not already set
        if not lclDCT['offerEndTime']: offerEndTime = lclStartTime
        else: offerEndTime = lclDCT['offerEndTime']

        # If the deviceId is negative, then use the accessNumbers
        if int(deviceId) < 0:
                # Assume we have an access number in this scenario...
                deviceId=lclDCT['accessNumbers']

                # Also change the query type
                devQueryType = 'AccessNumber'
                queryValue = deviceId
                queryType = 'AccessNumber'
        else:
                queryValue = deviceId
                queryType = 'PhoneNumber'

        # Can provide devOfferId or offerId for this command.
        # Map to offer ID.
        if (not lclDCT['offerId'] or lclDCT['offerId'].count('0')) and lclDCT['devOfferId']: offerId = lclDCT['devOfferId']
        else: offerId = lclDCT['offerId']
        
        # If no resource ID passed in, then need to get using the external ID
        if resourceId == 0:
                resourceId = ''
                for idx in range(len(offerId)):
                        offerDict = PRIM.getOfferData('device', deviceId, 0, offerId[idx], lclStartTime, lclDCT['ACTION'], queryType=devQueryType, offerIsCatalog=lclDCT['offerIsCatalog'])
                        
                        # Get the resource ID
                        resourceId += str(offerDict['ResourceId']) + '@'
        

                # Remove trailing list character
                resourceId = resourceId[:-1]

        # Convert resource ID to a list
        resourceId = resourceId.split('@')
        
        # What to print depends on catalog vs offer...
        if lclDCT['offerIsCatalog']:
                offertype = 'catalog'
        else:
                offertype = 'legacy'
        
        # Debug output
        print('Subscriber = ' + lclDCT['externalId'] + ' is cancelling ' + offertype + ' offer(s) with resource IDs ' + str(resourceId) + ' with end time ' + str(offerEndTime))
        
        retCode = REST_UTIL.deviceCancelOfferExt(RESTInst,
                deviceId,
                queryType=devQueryType,
                resourceId=resourceId,
                eventPass=lclDCT['eventPass'],
                executeMode=lclDCT['executeMode'],
                reason=lclDCT['reason'],
                info=lclDCT['info'],
                grantCancelProrationType=lclDCT['grantProrationType'],
                chargeCancelProrationType=lclDCT['chargeProrationType'],
                cancelType=lclDCT['cancelType'],
                cancelInfo=lclDCT['cancelInfo'],
                debtCancellationMode=lclDCT['debtCancellationMode'],
                eligibilityCheck=lclDCT['eligibilityCheck'],
                apiEventData=lclDCT['customAttr'][6],
                )
        
        # Update tracking data
        if lclDCT['eventPass']: TRACK.updateTrackingData(lclDCT['ACTION'], deviceId = deviceId, resourceId = resourceId)
        
        lclDCT['saveFunc'] = 'saveDeviceMDC'
        return (devQueryType, deviceId)
        
#==========================================================
def CmdDev_devicecheckpurchaseditemcyclealignment(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        # End of local variables setup.

        # Device should exist
        if deviceId not in TRACK.deviceTracking and not lclDCT['noChecks']:
                print('ERROR: device with ID "' + deviceId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Can provide subOfferId or offerId for this command.
        # Map to offer ID.
        if (not lclDCT['offerId'] or lclDCT['offerId'].count('0')) and lclDCT['devOfferId']: offerId = lclDCT['devOfferId']
        else: offerId = lclDCT['offerId']

        '''
        # If no resource ID passed in, then need to get using the external ID
        if resourceId == 0:
                offerDict = PRIM.getOfferData('subscriber', externalId, resourceId, offerId[0], lclStartTime, lclDCT['ACTION'], queryType=subQueryType, offerIsCatalog=True)

                # Get the resource ID
                resourceId = int(offerDict['ResourceId'])
        '''
        
        # If resource IDs passed in as a non-integer, then need to get its resource ID assuming they're offer external IDs
        for param in ['offerCycleResourceId']:
                # Get the local parameter value
                value = lclDCT[param]
                
                # See if defined and not an integer and not 0 (so not a resource ID)
                if value and not (value.isdigit() and value != '0'):
                        # Get resource ID data
                        offerDict = PRIM.getOfferData('device', deviceId, 0, value, lclStartTime, lclDCT['ACTION'], queryType=devQueryType, offerIsCatalog=lclDCT['offerIsCatalog'])
                        
                        # Get the resource ID
                        if param == 'offerCycleResourceId':          offerCycleResourceId = int(offerDict['ResourceId'])
                        
                        print('Retrieved ' + param + ' = ' + offerDict['ResourceId'])
        
        print('Device ' + str(deviceId) + ' is checking purchased item cycle alignment for offer "' + str(offerId) + '", resource ID ' + str(offerCycleResourceId))
        
        # Execute primitive
        response = REST_UTIL.deviceCheckPurchasedItemCycleAlignment(RESTInst,
                deviceId,
                queryType=devQueryType,
                offerResourceId=lclDCT['offerCycleResourceId'],
                eventPass=lclDCT['eventPass'],
                now=lclStartTime,
                )
        
        print("Response:")
        print(response)
        
        # Query Nothing
        queryValue = None
        queryType = None
        
        return (queryType, queryValue)
        
#==========================================================
def CmdSub_devicecontractdebtpayment(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        # End of local variables setup.

        # Device should exist
        if deviceId not in TRACK.deviceTracking and not lclDCT['noChecks']:
                print('ERROR: device with ID "' + deviceId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']

        # If no resource ID passed in, then need to get using the external ID
        if resourceId == 0:
                offerDict = PRIM.getOfferData('device', deviceId, resourceId, lclDCT['offerId'][0], lclStartTime, lclDCT['ACTION'], queryType=devQueryType, offerIsCatalog=True)

                # Get the resource ID
                resourceId = int(offerDict['ResourceId'])

        print('Device ' + str(deviceId) + ' is paying debt for offer "' + str(lclDCT['offerId']) + '", resource ID ' + str(resourceId))

        # Execute primitive
        retCode = REST_UTIL.deviceContractDebtPayment(RESTInst,
                deviceId,
                resourceId,
                str(lclDCT['amount']),
                queryType=devQueryType,
                reason=lclDCT['reason'],
                info=lclDCT['info'],
                now=lclStartTime,
                eventPass=lclDCT['eventPass'],
                paymentMethodResourceId=lclDCT['paymentMethodResourceId'],
                paymentGatewayId=lclDCT['paymentGatewayId'],
                chargeMethod=lclDCT['chargeMethod'],
                chargeMethodAttr=lclDCT['chargeMethodAttr'],
                nonce=lclDCT['nonce'],
                apiEventData=lclDCT['customAttr'][6],
                )

        # Query device
        queryValue = deviceId
        queryType = devQueryType

        return (queryType, queryValue)

#==========================================================
def CmdDev_devicequeryeligibleci(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        # End of local variables setup.

        # Device should exist
        if deviceId not in TRACK.deviceTracking and not lclDCT['noChecks']:
                print('ERROR: Device with ID "' + deviceId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Execute primitive
        respData = REST_UTIL.deviceQueryCatalogItemList(RESTInst,
                deviceId,
                queryType=devQueryType,
                eventPass=lclDCT['eventPass'],
                now=lclStartTime,
                eligibilityFilter=lclDCT['eligibilityCheck'],
                )
                
        # Process response if anything came back
        if respData:    outData = PRIM.getCatalogIDs(respData)
        else:           outData = 'None'

        # Add query-specific heading
        outData = 'Eligible CIs for device ' + ' ' + str(deviceId) + ': ' + outData
        
        # Write to where the caller wanted it to go
        if lclDCT['eventPass']:
                # If supposed to save data to variables then do that here
                if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, 'Event', respData)

                # Write to where the caller wanted it to go iff not saving data
                else: CSVQA.processDataToOutput(outData, lclDCT['outputFileName'])
                
        # Query None
        queryValue = queryType = None
        lclDCT['saveFunc'] = 'saveDeviceMDC'

        return (queryType, queryValue)

#==========================================================
def CmdDev_devicequerycatalog(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        # End of local variables setup.

        # Device should exist
        if deviceId not in TRACK.deviceTracking and not lclDCT['noChecks']:
                print('ERROR: Device with ID "' + deviceId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Execute primitive
        respData = REST_UTIL.deviceQueryCatalog(RESTInst,
                deviceId,
                queryType=devQueryType,
                eventPass=lclDCT['eventPass'],
                now=lclStartTime,
                catalogQueryValue=lclDCT['catalogExternalId'],
                catalogQueryType=lclDCT['catalogQueryType'],
                eligibilityFilter=lclDCT['eligibilityCheck'],
                filterName=None,
                )
                
        # Process response if anything came back
        if respData:    outData = PRIM.getCatalogIDs(respData)
        else:           outData = 'None'

        # Add query-specific heading
        outData = 'Catalog CIs for device ' + ' ' + str(deviceId) + ', Catalog ' + str(lclDCT['catalogExternalId']) + ': ' + outData
        
        # Write to where the caller wanted it to go
        if lclDCT['eventPass']:
                # If supposed to save data to variables then do that here
                if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, 'Event', respData)

                # Write to where the caller wanted it to go iff not saving data
                else: CSVQA.processDataToOutput(outData, lclDCT['outputFileName'])
                
        # Query None
        queryValue = queryType = None
        lclDCT['saveFunc'] = 'saveDeviceMDC'

        return (queryType, queryValue)

#==========================================================
def CmdDev_deviceactivateoffer(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        deviceId = lclDCT['deviceId']
        devQueryType = lclDCT['devQueryType']
        lclStartTime = lclDCT['lclStartTime']
        resourceId = lclDCT['resourceId']
        # End of local variables setup.

        # Device should exist
        if deviceId not in TRACK.deviceTracking and not lclDCT['noChecks']:
                print('ERROR: Device with ID "' + deviceId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Process resource ID
        if resourceId in [0, 'first', 'second', 'third', 'last']:
                resourceData = ''
                for idx in range(len(lclDCT['offerId'])):
                        offerDict = PRIM.getOfferData('device', lclDCT['externalId'], 0, lclDCT['offerId'][idx], lclStartTime, lclDCT['ACTION'], queryType=lclDCT['groupQueryType'], offerIsCatalog=lclDCT['offerIsCatalog'], resourceId=resourceId)

                        # Get the resource ID
                        resourceData += str(offerDict['ResourceId']) + '@'
#                       print 'Device ' + str(deviceId) + ' canceling offer with exernal ID = ' + offerId[idx] + ', resource ID ' + str(offerDict['ResourceId'])

                # Remove trailing list character
                resourceId = resourceData[:-1]

        # Execute primitive
        retCode = REST_UTIL.deviceActivateOffer(RESTInst,
                deviceId,
                devQueryType,
                resourceId,
                now=lclStartTime,
                eventPass=lclDCT['eventPass'],
                apiEventData=lclDCT['customAttr'][6],
                routingType=lclDCT['routingType'],
                routingValue=lclDCT['routingValue'],
                executeMode=lclDCT['executeMode'])

        # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
        try:
                respData = str(retCode.printElementBasedXml())
        except:
                respData = str(retCode)

        # If supposed to save data to variables then do that here
        if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, REST_UTIL.subUrl.capitalize(), respData)

        # if supposed to store output then write to where the caller wanted it to go.  nly if not saving data.
        elif lclDCT['outputFileName'] and lclDCT['outputFileName'].lower() != 'none': CSVQA.processDataToOutput(respData, lclDCT['outputFileName'])

        # Query device
        queryValue = deviceId
        queryType = devQueryType

        return (queryType, queryValue)

