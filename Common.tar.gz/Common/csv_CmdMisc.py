#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:35:43
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:35:43
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:35:42
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
#import json, xmltodict
#from dicttoxml import dicttoxml
from __future__ import print_function
# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
import sys, time, string, os, pprint, re, copy, parser, random, datetime, calendar, decimal
import qa_utils as QAUTILS
import csvMain as CSV
import csv_track as TRACK
import csv_id as CSVID
import csv_prim as PRIM
import csv_data as DATA
import cbPrim as CBPRIM
import csv_CmdCombo as CMDCOMBO
import csv_qa as CSVQA
import custSpecific as CUST
import common_mdc as COMMON
from primitives import timeToMDCtime as MDCTIME
import QA_subscriber_management_restv3 as REST_UTIL
from primitives import primGET as GET
import xml.etree.ElementTree as ET
from primitives import primXML as XML
from primitives import primGeneric as GENERIC
from primitives import primData as PRIMDATA
from primitives import engineRestPrim as ENGINE

# File-specific global data
emptyNormChar = '+'

# Line within the debug log to check for additional debug messages
ThresholdCheckDebugLogFileLine = 0

SavedData = {}

includeFileList = {}

TopLevelField = None

#==========================================================
# *** NOTE: This command has been removed from TF.  [It was never actually published :-).]  
# ***       One needs to save the event to really compare GL properly.  This ended up check a lot, but not enough, of GL data.
def CmdMisc_checkgldata(lclDCT, options, line, RESTInst):
        # *** lclDCT[] has all the values.
        
        # Get the prefix to use
        try: prefix = CUST.customPrefix
        except: prefix = 'Mtx'
        
        # Query the catalog item - get the total charge from the template
        totalCharge = ENGINE.getCatalogItemTemplateParameterByExternalId(lclDCT['offerId'][0], prefix, 'TotalCharge')
        
        print('Operation = ' + str(lclDCT['eventTypeStringArray']) + ',  totalCharge = ' + str(totalCharge))
        
        # The operation determins what to check
        # 1) Query MEF data using previous command time
        # 2) Add up charges
        # 3) Compare to the previously read totalCharge value
        # 4) Check the number of GL entries (nothing deferred)
        
        # For now it's subscriber events we're validating
        queryCmd = 'curl -s  -H "Cache-Control: no-cache" -L -k   http://restgw:8080/rsgateway/data/v3/eventstore/subscriber/' + lclDCT['subQueryType'] + '+' + str(lclDCT['externalId']) + '?applyDefaultFilter=false'
        if lclDCT['eventTypeStringArray']: queryCmd += '\&eventTypes=' + ",".join(lclDCT['eventTypeStringArray'])
        if lclDCT['eventTimeLowerBound']:  queryCmd += '\&eventTimeLowerBound='  + lclDCT['eventTimeLowerBound']
        if lclDCT['eventTimeUpperBound']:  queryCmd += '\&eventTimeUpperBound='  + lclDCT['eventTimeUpperBound']
        
        # Execute the command
        #print queryCmd
        respData = QAUTILS.runCmd(queryCmd)
        
        # Convert to library
        q = ET.fromstring(respData)
        
        # Get Gl Info
        glData = []
        reportedAmount = 0.0
        
        # Process input operations (eventTypeStringArray was translated, so need both input)
        for opr in lclDCT['operation']:
            # Could be custom prefix or generic one.  Try both.
            for cmdPrefix in [prefix, 'Mtx']:
                # Build string to decode XML
                xml = './EventList/EventQueryEventInfo/EventDetails/' + cmdPrefix + opr.capitalize() + 'Event/GlInfoArray/MtxEventGlInfo'
                
                # Loop through all structs we find
                for child in q.findall(xml):
                        '''
                        print 'Child:'
                        ET.dump(child)
                        '''
                        
                        # Get key fields
                        for field in ['Account1', 'Account2', 'TxnType', 'UpdateType', 'Amount']:
                                assignment = field + ' = child.find("' + field + '").text'
                                #print assignment
                                exec(assignment)
                        
                        # Add to GL data
                        record = Account1 + ',' + Account2 + ',' + TxnType + ',' + UpdateType + ',' + Amount
                        glData.append(record)
                        
                        # Update reported amount
                        reportedAmount += float(lclDCT['amount'])
        
        # Debug data
        print('GL Data:')
        pprint.pprint(glData)
        
        # Need to:
        # 1) open/read file
        # 2) Remove entries from glData that are in the file (erroir if not there)
        # 3) If any records left from the file, then error
        # * ** Not validating amount, since that's tricy (for now).  Same amount shows up in multiple entries when deferred is present.
        
        # 1)
        expectedGlData = open(lclDCT['dataFile']).read().split("\n")
        
        # Seeing empty lines and there could be lines with comments.  Remove all of that, as well as any white space in the entry.
        expectedGlData = [x.strip() for x in expectedGlData if len(x.strip()) and x.strip()[0] != '#']
        
        # 2)
        for i in reversed(list(range(len(glData)))):
                # See if in the file
                try:
                        del expectedGlData[expectedGlData.index(str(glData[i]))]
                        #print 'Found "' + str(glData[i]) + '" in expectedGlData'
                        del glData[i]
                except: 
                        print('ERROR: did not find "' + str(glData[i]) + '" in expectedGlData')
                        print('Command run to query the events: ' + queryCmd)
                        pprint.pprint(expectedGlData)
                        sys.exit('Exiting due to errors')
                
        # 3)  Getting blank entry in expected data.  Check for this (and then fix above).
        if len(expectedGlData) and expectedGlData[0]:
                print('ERROR: did not find everything in expectedGlData.')
                print('Command run to query the events: ' + queryCmd)
                pprint.pprint(expectedGlData)
                sys.exit('Exiting due to errors')
                
        # Nothing to query on the return
        return None, None
        
#==========================================================
def CmdMisc_mrstart(lclDCT, testName, sessionId, line, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, repeatCount, cmdLineInput):
        # Sanity check
        if DATA.mrEnabled:
                print('WARNING: Multi-Request mode already enabled.  Continuing in this mode.')
        else:
                # Set multi request flag
                DATA.mrEnabled = True
                
                # Empty MR array
                DATA.mrCommands = []
                        
                # See if builder data defined
                if not DATA.V3Builder: DATA.V3Builder = QAUTILS.getSubscInterface(mode = 'BuildRequest')
                
                # Debug output
                print('Starting Multi-Request processing')
        
                # Set index to -1, which allows us to bump the index at start of every command withn a MR
                DATA.mrIndex = -1
                
        # Nothing to query here
        return (None, None)
        
#==========================================================
def CmdMisc_mrstop(lclDCT, testName, sessionId, line, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, repeatCount, cmdLineInput):
        # Sanity check
        if not DATA.mrEnabled:
                print('WARNING: Multi-Request mode already disabled.  Continuing in this mode.')
        else:
                # Clear multi request flag
                DATA.mrEnabled = False
                
                # Debug output
                print('Stopping Multi-Request processing')
        
        # Sanity check that something is queued
        if not len(DATA.mrCommands):
                sys.exit('ERROR: mrStop command encountered but no MR commands queued')
                
        # Execue the multi-request
        multiResponse = REST_UTIL.multiRequest(RESTInst, requests = DATA.mrCommands, now = lclStartTime, eventPass=lclDCT['eventPass'])
        print('multirequest response', multiResponse)

        # Nothing to query here
        return (None, None)
        
#==========================================================
#==========================================================
def balanceSet(data, object, lclDCT, options, RESTInst, cmdLineInput):
        # Get start/stop values
        start = data['start']
        stop  = data['end']
#       print 'start/stop = ' + start + '/' + stop
                                
        # Need to pick a value that's between the start and stop values.
        # One of them could be infinity, so need to address that.
        # If start is infinity, then it's a negative infinity.  If stop is infinity, then it's positive infinity.
        # If there's one range from negative infinity to positive infinity, then the code will error out...
        if   'infinity' in start: value = float(stop) - 0.1
        elif 'infinity' in stop:  value = float(start) + 0.1
        else:                     value = float(stop) - 0.1
                                
        # NOTE: There could be problems for balances with significant digits set to 0 and the divide by 2.  Resolve that when it's an issue.
        # At the moment, the engine seems to set balances to the specified amount, regardless of their configured precision...
                                
        # Save dictionary data
        amount = lclDCT['amount']
        ACTION = lclDCT['ACTION']
        balanceId = lclDCT['balanceId']
        
        # Set data.
        # Use the balance ID from within the normalizer (so parameter value is not used).
        lclDCT['balanceId'] = object['selectedBalance']
        lclDCT['amount'] = str(value)
                                
        # Invoke the balance set command.  Need to figure out whether to set a group balance or a subscriber balance...
        if 'groupId' in cmdLineInput: 
                lclDCT['ACTION'] = 'Group'
                CMDCOMBO.CmdCombo_setgroupbalancevalue(lclDCT, options, RESTInst)
                id = lclDCT['groupId']
        else:                         
                lclDCT['ACTION'] = 'Subscriber'
                CMDCOMBO.CmdCombo_setsubscriberbalancevalue(lclDCT, options, RESTInst)
                id = lclDCT['externalId']
                                
        print('Set ' + lclDCT['ACTION'] + ' ' + str(id) + ' balance ' + lclDCT['balanceId'] + ' to ' + lclDCT['amount'])
                                
        # Restore data
        lclDCT['amount'] = amount
        lclDCT['ACTION'] = ACTION
        lclDCT['balanceId'] = balanceId
        
#==========================================================
def getNormDataForLevelLoopCombination(normalizerData, level, index, parameters, lclDCT, options, RESTInst, cmdLineInput):
        global emptyNormChar
        
        # Default loop extra parameter to nothing found
        extraParams = ""
        
        # Get normalizer values to use
        normData = normalizerData[level]['data'][index]
        normObject = normalizerData[level]['object']
#       print 'getNormDataForLevelLoopCombination, level = ' + str(level) + ', index = ' + str(index)
#       print str(normData)
#       print str(normObject)
                
        # If values exist, then add to the extra parameters
        if normData != emptyNormChar:
                # If the normalizer type is a a balance, then need to set the balance value to within the range
                if normObject['datatype'] == 'balance': balanceSet(normData, normObject, lclDCT, options, RESTInst, cmdLineInput)
                else:
                        # Get this normalizers parameter name and value
                        param = parameters[level]
                        value = normData['value']
                        
                        # Add to the extra parameters
                        extraParams = DATA.paramSepChar + param + '=' + value
        
        return extraParams
                        
#==========================================================
def CmdMisc_stopdiffdata(lclDCT, options, line):
        # Clear global diff enable flag
        DATA.diffEnableFlag = False
        
        # Remove temp files
        QAUTILS.runCmd('rm _saved*')
        
        # Nothing to query here
        return (None, None)
        
#==========================================================
def CmdMisc_startdiffdata(lclDCT, options, line):
        objectType = lclDCT['objectType']
        
        # See what to setup
        if   objectType == 'all': elements = ['Sub', 'Dev', 'Group']
        elif objectType == DATA.objectTypeMapping['subscriber']:elements = ['Sub']
        elif objectType == DATA.objectTypeMapping['Group']:     elements = ['Group']
        else:                                                   elements = ['Dev']
        
        # Save data for each object
        for obj in elements: CmdMisc_savedata(lclDCT, obj)
        
        # Set global diff enable flag
        DATA.diffEnableFlag = True
        
        # Nothing to query here
        return (None, None)
        
#==========================================================
def CmdMisc_subsavedata(lclDCT, options, line):
        return CmdMisc_savedata(lclDCT, 'Sub')

#==========================================================
def CmdMisc_devsavedata(lclDCT, options, line):
        return CmdMisc_savedata(lclDCT, 'Dev')

#==========================================================
def CmdMisc_groupsavedata(lclDCT, options, line):
        return CmdMisc_savedata(lclDCT, 'Group')

#==========================================================
def CmdMisc_savedata(lclDCT, obj, fname = '_saved'):
        # *** lclDCT[] has all the values.
        
        # Save obj name (ease of copying)
        if obj == 'Sub':
                saveType = 'saveMDC'
                queryValue = lclDCT['externalId']
                queryType = lclDCT['subQueryType']
        elif obj == 'Dev':
                saveType = 'saveDeviceMDC'
                queryValue = lclDCT['deviceId']
                queryType = lclDCT['devQueryType']
        else:
                saveType = 'saveGroupMDC'
                queryValue = lclDCT['groupId']
                queryType = lclDCT['groupQueryType']
        
        # Call out to print to screen function, giving it a file name
        PRIM.printToScreen(saveType, queryValue, queryType, lclDCT, lclDCT['lclStartTime'], outputFileName=fname+obj)
        
        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)
        
#==========================================================
def CmdMisc_subdiffdata(lclDCT, options, line):
        return CmdMisc_diffdata(lclDCT, 'Sub')

#==========================================================
def CmdMisc_devdiffdata(lclDCT, options, line):
        return CmdMisc_diffdata(lclDCT, 'Dev')

#==========================================================
def CmdMisc_groupdiffdata(lclDCT, options, line):
        return CmdMisc_diffdata(lclDCT, 'Group')

#==========================================================
def CmdMisc_diffdata(lclDCT, obj, fname='_latest', savedFname='_saved'):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        name = lclDCT['name']
        # End of local variables setup.  
        
        # Account for obj sometimes being the full object name
        for name in ['Dev', 'Sub', 'Group']:
                if obj.startswith(name):
                        obj = name
                        break
        
        # Save obj name (ease of copying)
        CmdMisc_savedata(lclDCT, obj, fname)
        
        # Now diff the two files
        diff = QAUTILS.runCmd('diff ' + savedFname + obj + ' ' + fname + obj + ' | grep [\>\<] | grep -v \'**** Data For \'')
        
        # Output debug
        if lclDCT['verbose'].lower() not in ['none']:
                if not diff: print('\nNo differences\n')
                else:  print(diff + '\n')
        
        # Want to move this to the saved file unless the noResults field is set
        if lclDCT['noResults']:
                print('Retaining previously saved state for future diff')
        else:
                # debug output
                #print 'Saving current state for future diff'
                QAUTILS.runCmd('cp ' + fname + obj + ' ' + savedFname + obj)
        
        # Return diff buffer
        return diff

#==========================================================
def CmdMisc_include(lclDCT, testName, sessionId, line, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, repeatCount, cmdLineInput):
        global emptyNormChar
        global includeFileList
        
        # *** lclDCT[] has all the values.
        
        dataFile = lclDCT['dataFile']
        normParameters = lclDCT['normParameters']
        
        # Default to no extra params
        extraParams = ''
        
        # Minor hack: if doing normalizer testing then the "amount" parameter is for the normalizer limit.  Don't pass the command.
        if lclDCT['normalizers']: DATA.notIncludeParameters.append('amount')
        
        # If any parameters were passed in after the dataFile item, then want to include in the invocation.
        # These will be passed to the first command of the included file.
        # See if there is more than one separater character in the line
        if line.count(DATA.paramSepChar) > 1:
                # Remove parameters that should not be included.  Actually build up those that should...
                # Remove first parameter (action).
                line2 = line.split(DATA.paramSepChar)[1:]

                # Remove first parameter; change parameter separater into spaces, so easy to change to a list.
#                line3 = line2[2].replace(DATA.paramSepChar, ' ', 50)

                # Process each parameter (list item at this point)
                for param in line2:
                        # Separate out parameter from data
                        param2 = param.partition('=')

                        # If parameter not excluded, then add to extra param string
                        if not DATA.notIncludeParameters.count(param2[0]):
                                # Add to extra params
                                extraParams += DATA.paramSepChar + param2[0] + param2[1] + param2[2]
        
        # Minor hack: if doing normalizer testing then the "amount" parameter is for the normalizer limit.  Remove entry that was added.
        if lclDCT['normalizers']: DATA.notIncludeParameters = DATA.notIncludeParameters[:-1]
        
        # If the datafile name starts with "default", then we want to replace it with the local variable default#.  This allows the same file
        # to invoke different include files by specifying the default name in the command line.
        if dataFile.lower().startswith('default'):
                # Make sure this parameter is setup
                if dataFile not in lclDCT:
                        print('ERROR: default data file ' + dataFile + ' not defined')
                        sys.exit('Exiting early due to errors')

                # Debug output
                print('Using default file ' + lclDCT[dataFile])

                # Set local variable to the default name
                dataFile = lclDCT[dataFile]
        
        # Make sure we'r enot in a loop of includes
        if dataFile in includeFileList: sys.exit('ERROR: data file ' + dataFile + ' already being processed. Can\'t loop on same file')
        includeFileList[dataFile] = True
        
        # The ability to test normalizer combinations is a new feature added to include processing.  
        normalizerData = []
        
        # If normalizers and parameters were specified, then we have more to do here...
#       print 'normalizers = ' + str(normalizers)
        if lclDCT['normalizers'] and normParameters:
                # User wants to run through a series of parameters, using normalizer data as the key
                # Make sure the lengths are the same
                if len(lclDCT['normalizers']) != len(normParameters): 
                        print('ERROR: input normalizer length doesn;t match input parameter length')
                        sys.exit('Exiting early due to errors')
                
                # There can be a variable number of normalizers specified, so hard (for this coder) to construct
                # variable number of for loops to gather all the combinations.
                # Cheat and limit the number of normalizers to 3 and proceed.
                if len(lclDCT['normalizers']) > 3:
                        print('ERROR: input normalizer length must be <= 3')
                        sys.exit('Exiting early due to errors')
                
                # Need to read in all the normalizers
                for i in range(len(lclDCT['normalizers'])): normalizerData.append(CBPRIM.cbQueryAndReturnNormalizerValues(lclDCT['normalizers'][i]))
        
                # We have a feature clash.  normalizerMapping requires the parameter to use the value of the normaliser.  This feature uses the
                # input values.  Need to add a mapping that says it's OK to not find an entry (just for this command)
                for x in normParameters:
                        # Want to update the data parameter translation of this parameter to not fail if input value used (versus expected value)
                        for i in range(len(DATA.parameterTranslate)):
                                y = DATA.parameterTranslate[i]
                                if y[0] == x:
                                        print('Updating parameter ' + x + ' so mapping is false')
                                        # Can't update tuple, so del and add one with False as the last parameter
                                        del DATA.parameterTranslate[i]
                                        DATA.parameterTranslate.append((x, None, False))
                                        #pprint.pprint(DATA.parameterTranslate)
                                        break
                                        
                                        # Really should save original value and restore it, but this is a low-runner feature and the liklihood 
                                        # of someone entering a bad value in a subsequent command is very low (and would only make debugging harder, so not really breaking anything)
                
                        else:
                                # Might be a custom parameter
                                try:
                                        for i in range(len(CUST.custParameterTranslate)):
                                                y = CUST.custParameterTranslate[i]
                                                if y[0] == x:
                                                        print('Updating CUST parameter ' + x + ' so mapping is false')
                                                        del CUST.custParameterTranslate[i]
                                                        CUST.custParameterTranslate.append((x, None, False))
                                                        #pprint.pprint(CUST.custParameterTranslate)
                                                        break
                                except: pass
                
        # If length of the normalizer data is less than 3, then append the empty structure
        data = {}
        data['object'] = None
        data['data'] = []
        data['data'].append(emptyNormChar)
        while len(normalizerData) < 3: normalizerData.append(data)
        
        # Default extra parameters to nothing found
        extraParameters = []
        extraParameters.append('')
        extraParameters.append('')
        extraParameters.append('')
                
        # Set data levels
        level = 0
        lp1 = lclDCT['level'] + 1
        lp2 = lclDCT['level'] + 2
                
        # Loop through the levels of normalizer.
        # Probably can do this much cleaner using yeild...
        # Parameter "amount" limits the number of items done per level
        for lvl1,i in enumerate(range(len(normalizerData[lclDCT['level']]['data']))):
                # If random specified, then use a random value
                if lclDCT['randomValue']: idx = random.randint(0,len(normalizerData[lclDCT['level']]['data'])-1)
                else:           idx = i
                
                # Get the normalizer data for this level/index combination
                extraParameters[lclDCT['level']] = getNormDataForLevelLoopCombination(normalizerData, lclDCT['level'], idx, normParameters, lclDCT, options, RESTInst, cmdLineInput)
                
                # Check for a second normalizer
                for lvl2,j in enumerate(range(len(normalizerData[lp1]['data']))):
                        # If random specified, then use a random value
                        if lclDCT['randomValue']: jdx = random.randint(0,len(normalizerData[lp1]['data'])-1)
                        else:           jdx = j
                
                        # Get the normalizer data for this level/index combination
                        extraParameters[lp1] = getNormDataForLevelLoopCombination(normalizerData, lp1, jdx, normParameters, lclDCT, options, RESTInst, cmdLineInput)
                        
                        # Check for a third normalizer
                        for lvl3,k in enumerate(range(len(normalizerData[lp2]['data']))):
                                # If random specified, then use a random value
                                if lclDCT['randomValue']: kdx = random.randint(0,len(normalizerData[lp2]['data'])-1)
                                else:           kdx = k
                
                                # Get the normalizer data for this level/index combination
                                extraParameters[lp2] = getNormDataForLevelLoopCombination(normalizerData, lp2, kdx, normParameters, lclDCT, options, RESTInst, cmdLineInput)
                                
                                # Build extra params string
                                finalExtraParams = extraParams + extraParameters[0] + extraParameters[1] + extraParameters[2]
                                
                                # Debug output
                                print('sending through include command extraParams = "' + finalExtraParams + '" for i/j/k ' + str(idx) + '/' + str(jdx) + '/' + str(kdx))
        
                                # Want to invoke another data file at this point.
                                # TO DO:  Make sure infinite loop is avoided.
                                print('\nStarting processing include file ' + dataFile + '\n')
                                (lclDCT['step'], lclDCT['lclStartTime'], options, saveResult) = CSV.processDataFileInput(lclDCT['testName']+'_'+dataFile.split('/')[-1], lclExtraAvp, options, lclDCT['lclStartTime'], RESTInst, step, dataFile, extraParams=finalExtraParams, incFile=True)
                                print('\nCompleted processing include file ' + dataFile + '\n')
                                
                                # Break early if desired.  Account for loop starting at 0.
                                if int(lclDCT['amount']) and lvl3 >= int(lclDCT['amount']) - 1: break
                
                        # Break early if desired.  Account for loop starting at 0.
                        if int(lclDCT['amount']) and lvl2 >= int(lclDCT['amount']) - 1: break
                
                # Break early if desired.  Account for loop starting at 0.
                if int(lclDCT['amount']) and lvl1 >= int(lclDCT['amount']) - 1: break
        
        # Remove entry from list
        del includeFileList[dataFile]
        
        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)

#==========================================================
def CmdMisc_savetime(lclDCT, options, line):
        # *** lclDCT[] has all the values.

        print('Saving local time: ' + lclDCT['lclStartTime'] + ' at index ' + str(lclDCT['level']))

        # Set the local start time to this value
        TRACK.saveTime[str(lclDCT['level'])] = lclDCT['lclStartTime']

        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)

#==========================================================
def CmdMisc_restoretime(lclDCT, options, line):
        # *** lclDCT[] has all the values.

        # Make sure we have something saved for this index
        if str(lclDCT['level']) not in TRACK.saveTime:
                print('ERROR:  nothing saved at index ' + str(lclDCT['level']) + ' - Exiting')
                sys.exit(1)

        print('Restoring saved time: ' + TRACK.saveTime[str(lclDCT['level'])] + ' from index ' + str(lclDCT['level']))

        # Set the local start time to this value
        lclDCT['lclStartTime'] = TRACK.saveTime[str(lclDCT['level'])]

        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)

#==========================================================
def CmdMisc_settime(lclDCT, options, line):
        # *** lclDCT[] has all the values.
        
        # Remove usec
        origStartTime = lclDCT['origStartTime'].split('.')
        if len(origStartTime) > 1:      origStartTime = origStartTime[0] + origStartTime[1][6:]
        else:                           origStartTime = origStartTime[0]
        
        startTime = lclDCT['startTime'].split('.')
        
        # Want to set Last constants or year/month/day/hour/min/sec
        dates = startTime[0].split('T')[0].split('-')
        #print('dates = ' + str(dates))
        DATA.constantValue['LastYear']  = dates[0]
        DATA.constantValue['LastMonth'] = dates[1].lstrip('0')
        DATA.constantValue['LastDay']   = dates[2].lstrip('0')
        
        times = startTime[0].split('T')[1].split(':')
        #print('startTime = ' + str(startTime) + ', times = ' + str(times))
        DATA.constantValue['LastHour']   = times[0].lstrip('0')
        DATA.constantValue['LastMinute'] = times[1].lstrip('0')
        
        # Want to get seconds.  Need to remove timezone, which could be - or +
        if   times[2].lower().count('Z'):
                DATA.constantValue['LastSecond'] = times[2][:-1]
        elif times[2].count('-'):
                DATA.constantValue['LastSecond'] = times[2].lstrip('0').split('-')[0]
        else:
                DATA.constantValue['LastSecond'] = times[2].lstrip('0').split('+')[0]
        
        # Get day of the week constant
        DATA.constantValue['DayOfTheWeek'] = calendar.day_name[datetime.datetime(int(DATA.constantValue['LastYear']), int(DATA.constantValue['LastMonth']), int(DATA.constantValue['LastDay'])).weekday()]
        #print('Weekday: ' + DATA.constantValue['DayOfTheWeek'])
        
        # Also want to store timezone in number format (for CCF calls)
        if len(startTime) > 1:
                tzData = startTime[1][6:]
        else:   tzData = startTime[0][19:]
        #print('tzData: ' + tzData)

        # See what the sign is
        if   tzData[0].lower() == 'z':
               # Reset data to offset 0 for UTC time
               negFlag = 1
               tzData='+00:00'
        elif tzData[0] == '-':
               negFlag = -1
        else:
               negFlag = 1

        # Calculate time
        tzValue = tzData[1:].split(':')
        #print('tzValue: ' + str(tzValue) + ', negFlag = ' + str(negFlag))
        try:    DATA.constantValue['TimeZone'] = negFlag * ((int(tzValue[0])*4) + int(tzValue[1]))
        except: DATA.constantValue['TimeZone'] = 0
        #print('TimeZone = ' + str(DATA.constantValue['TimeZone']))
        
        # Build start timeback up
        if len(startTime) > 1:  startTime = startTime[0] + startTime[1][6:]
        else:                   startTime = startTime[0]
        
        # Only debug if processing a line
        if line: print('Changing local time from: ' + lclDCT['origStartTime'] + ' to: ' + startTime)
        
        # Set into constants
        DATA.constantValue['PreviousTime'] = lclDCT['origStartTime']
        DATA.constantValue['LastSetTime'] = startTime
        #pprint.pprint(DATA.constantValue)
        
        # Set the local start time to this value
        lclDCT['lclStartTime'] = startTime

        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)

#==========================================================
def CmdMisc_increment(lclDCT, options, line):
        # *** lclDCT[] has all the values.
        
        # Loop replaced with below commands for Python3 migration.
        name = lclDCT['name']
        # End of local variables setup.  
                
        # If amount is 0 (not specified) then set to 0
        amount = int(lclDCT['amount'])
        if lclDCT['amount'] == 0: amount = 1
        
        # See if a TF parameter or a constant
        if      name in DATA.TFVariables:   value = int(getattr(options, name))
        elif    name in DATA.constantValue: value= int(DATA.constantValue[name])
        else:
                        print('ERROR: "' + name + '" not previously defined as a constant and it\'s not a TF variable.  This is an error.')
                        sys.exit('Exiting due to errors')
         
        # Add amount to increment
        value += amount
        
        # Store in dictionary (common location for parameter or constant setting)
        lclDCT = {}
        lclDCT['paramName']  = name
        lclDCT['paramValue'] = str(value)
                
        # Check if a TF variable or constant
        if name in DATA.TFVariables:    CmdMisc_changeparametervalue(lclDCT, options)
        else:                           CmdMisc_setconstantvalue(lclDCT, options)
                
        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)
        
#==========================================================
def CmdMisc_echo(lclDCT, options, line):
        # *** lclDCT[] has all the values.

        # Output string will have been printed above.  Output the string to the debug log
        # Translate apostrophies to @ (so command doesn't blow up)
        outputString = lclDCT['outputString'].replace("'", "@")
        
        # Honor outputFile, or else default to debug log
        if not lclDCT['outputFileName']: outputFileName = "/var/log/mtx/mtx_debug.log"
        
        command = 'echo -e "\n\n**** ' + lclDCT['outputString'] + ' ****\n\n" >> ' + lclDCT['outputFileName']
        #print 'command to run: ' + command
        QAUTILS.runCmd(command)
        
        # Log to std out
        command = 'echo -e "\n\n**** ' + lclDCT['outputString'] + ' ****\n\n"'
        #print 'command to run: ' + command
        QAUTILS.runCmd(command)

        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)

#==========================================================
def CmdMisc_runcmd(lclDCT, options, line):
        # *** lclDCT[] has all the values.

        # Blindly run the command
        print('Running command: ' + lclDCT['command'])
        stdOut = QAUTILS.runCmd(lclDCT['command'])
        
        # If verbose is not none, then output
        if lclDCT['verbose'].lower() != 'none': print(stdOut)
        
        # Add validation to this command.  Look for the response to be a simple "fail"
        if lclDCT['validate']:
          if stdOut.lower() == 'fail':
                # Debug output
                print('Validation of runCmd returned fail')
                
                # If expecting pass then exit
                if lclDCT['eventPass']: sys.exit('ERROR: exiting due to unepxected failure\n\n')
                else:  print('Failure expected so overall result is pass')
          else:
                # Debug output
                print('Validation of runCmd returned success')
                
                # If expecting falure then exit
                if not lclDCT['eventPass']: sys.exit('ERROR: exiting due to unepxected success\n\n')      
                else:  print('Success expected so overall result is pass')
        
        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)

#==========================================================
def CmdMisc_exit(lclDCT, options, line):
        # *** lclDCT[] has all the values.

        # Exit :-)
        sys.exit("Exiting due to exit command")
        
        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)

#==========================================================
def CmdMisc_pause(lclDCT, options, line):
        # *** lclDCT[] has all the values.

        # Pause unless global overide enabled
        if not lclDCT['noPause']:
                # Wait for a response from the user
                response = QAUTILS.pauseCheck('yes', prompt=lclDCT['outputString'])
                
                # Put in constant "response" so scripts can use if desired
                DATA.constantValue['response'] = response
        
        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)
        
#==========================================================
def CmdMisc_sleep(lclDCT, options, line):
        # *** lclDCT[] has all the values.

        # Make sure amount is positive
        if lclDCT['amount']: amount = int(lclDCT['amount'])
        else:                amount = int(lclDCT['timeToWait'])
        if amount <= 0: amount = 1

        # Debug
        print('Sleeping for ' + str(amount) + ' seconds')

        # Sleep for input amount of seconds
        time.sleep(amount)

        # Debug
        print('Done sleeping for ' + str(amount) + ' seconds')

        # Increase tool time by this number of seconds
        oldTime = lclDCT['lclStartTime']
        lclStartTime = MDCTIME.getTime(delta=amount, timeUnit='sec', startTime=lclDCT['lclStartTime'], tz=lclDCT['subTimeZone'])
        print('Changed relative tool time as part of action ' + lclDCT['ACTION'] + ' from ' + oldTime + ' to ' + lclDCT['lclStartTime'])
        
        # Save new local time
        lclDCT['lclStartTime'] = lclStartTime
        
        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)

#==========================================================
def CmdMisc_setspooftime(lclDCT, options, line):
        # *** lclDCT[] has all the values.

        # If startTime not input, then use local time
        if not lclDCT['startTime']: startTime = lclDCT['lclStartTime']
        else: startTime = lclDCT['startTime'] # Added during Python3 migration

        # Set system time to specified time.  No sleep required.
        MDCTIME.spoofTime(startTime=lclDCT['startTime'], sleep=0)

        # Bump overall timer, so it's used in all subsequent commands
        oldTime = lclDCT['lclStartTime']
        lclStartTime = startTime
        print('Changed relative tool time as part of action ' + lclDCT['ACTION'] + ' from ' + lclDCT['origStartTime'] + ' to ' + lclDCT['startTime'])
        
        # Save new local time
        lclDCT['lclStartTime'] = lclStartTime
        
        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)
        
#==========================================================
def CmdMisc_clearspooftime(lclDCT, options, line):
        # *** lclDCT[] has all the values.

        # clear system spoofed time
        MDCTIME.clearSpoofTime()
        
        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)
        
#==========================================================
def CmdMisc_purgesubscriberbalances(lclDCT, options, line):
        # *** lclDCT[] has all the values.

        # Build the command
        command = '/opt/mtx/examples/purge_expired_balances/purge_expired_balances.py -e ' + lclDCT['externalId']

        # If info is set, then set to dry-run mode
        if lclDCT['info']: command += ' -n'

        # Blindly run the command
        stdOut = QAUTILS.runCmd(command)

        # If verbose is not none, then output
        if lclDCT['verbose'].lower() != 'none': print(stdOut)
        
        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)

#==========================================================
def CmdMisc_changeassignedvalue(lclDCT, options, line):
        # *** lclDCT[] has all the values.
        
        # Allow to be a formula.  Hard to tell the difference, so try and if fails set to value as-is.
        try:
                # Don't allow time to be changed to a built-in function.  Same for object IDs.
                # Now running into values that compile to None (e.g. Database)...
                if not lclDCT['paramValue'].count(',min')  and \
                   not lclDCT['paramValue'].count(',hour') and \
                   not lclDCT['paramValue'].count(',week') and \
                   not lclDCT['paramValue'].count(',month')and \
                   lclDCT['paramName'].lower()  not in ['objectid']:
                        # Save this - avoid compiler changing things to None
                        saveParamValue = lclDCT['paramValue']
                        
                        # Compile this
                        code = parser.expr(lclDCT['paramValue']).compile()
                        paramValue = eval(code)
                        
                        # If result is None then return to original value
                        if str(lclDCT['paramValue']) == 'None': paramValue = str(saveParamValue)
        except:
                pass
        
        # Save the current value
        CSVID.maxAssignedIdsSave[lclDCT['paramName']] = CSVID.maxAssignedIds[lclDCT['paramName']]
        CSVID.maxAssignedIds[lclDCT['paramName']] = str(paramValue)
        print('Changed value for maxAssignedIds[' + lclDCT['paramName'] + '] from ' + CSVID.maxAssignedIdsSave[lclDCT['paramName']] + ' to ' + str(CSVID.maxAssignedIds[lclDCT['paramName']]))
        
        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)
        
#==========================================================
def CmdMisc_restoreassignedvalue(lclDCT, options, line):
        # *** lclDCT[] has all the values.

        # Restore the value from the saved structure
        old = CSVID.maxAssignedIds[lclDCT['paramName']]
        CSVID.maxAssignedIds[lclDCT['paramName']] = CSVID.maxAssignedIdsSave[lclDCT['paramName']]
        if lclDCT['verbose'] not in ['low', 'none']:
         print('Restored value for maxAssignedIds[' + lclDCT['paramName'] + '] from ' + str(old) + ' to ' + str(CSVID.maxAssignedIds[lclDCT['paramName']]))

        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)
        
#==========================================================
def CmdMisc_changeparametervalue(lclDCT, options, line=None):
        # Allow to be a formula.  Hard to tell the difference, so try and if fails set to value as-is.
        try:
                # Don't allow time to be changed to a built-in function.  Same for object IDs.
                # Now running into values that compile to None (e.g. Database)...
                if not lclDCT['paramValue'].count(',min')  and \
                   not lclDCT['paramValue'].count(',hour') and \
                   not lclDCT['paramValue'].count(',week') and \
                   not lclDCT['paramValue'].count(',month')and \
                   lclDCT['paramName'].lower() not in ['objectid'] and \
                   not lclDCT['paramValue'].isdigit():
                        # Save this - avoid compiler changing things to None
                        saveParamValue = lclDCT['paramValue']
                        
                        # Compile this
                        code = parser.expr(lclDCT['paramValue']).compile()
                        paramValue = eval(code)
                        
                        # If result is None then return to original value
                        if str(lclDCT['paramValue']) == 'None': paramValue = str(saveParamValue)
        except:
                pass
        
        # Save the current value
        setattr(CSV.optionsSave, lclDCT['paramName'], getattr(options, lclDCT['paramName']))
        old = getattr(CSV.optionsSave, lclDCT['paramName'])
        
        # Set the new value.
        # If true/false then set to 0/1.
        # If none, then set to None.
        # Else set to input value.
        if str(lclDCT['paramValue']).lower() == 'true': 
                print('Setting options.' + lclDCT['paramName'] + ' = True')
                setattr(options, lclDCT['paramName'], True)
        elif str(lclDCT['paramValue']).lower() == 'false': 
                print('Setting options.' + lclDCT['paramName'] + ' = False')
                setattr(options, lclDCT['paramName'], False)
        elif str(lclDCT['paramValue']).lower() == 'none':
                print('Setting options.' + lclDCT['paramName'] + ' = None')
                setattr(options, lclDCT['paramName'], None)
        else:
                print('Setting options.' + lclDCT['paramName'] + ' = ' + str(lclDCT['paramValue']))
                
                # Need to check if int or flot or string and assign accordingly
                try: result = int(lclDCT['paramValue'])
                except:
                     try:     result = float(lclDCT['paramValue'])
                     except:  result = str(lclDCT['paramValue'])
                setattr(options, lclDCT['paramName'], result)
        
        print('Changed value for options.' + lclDCT['paramName'] + ' from ' +  str(old) + ' to ' + str(lclDCT['paramValue']))
        
        # If this is an ID parameter, then update ID data to show reference
        if lclDCT['paramName'] in DATA.idParameter: CSVID.getAbsoluteIdValue(options, lclDCT['paramName'], lclDCT['paramValue'], False)
                
        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)
        
#==========================================================
def CmdMisc_restoreparametervalue(lclDCT, options, line):
        # Restore the value from the saved structure
        old = getattr(options, lclDCT['paramName'])
        
        # Set and read
        setattr(options, lclDCT['paramName'], getattr(CSV.optionsSave, lclDCT['paramName']))
        new = getattr(options, lclDCT['paramName'])
        print('Restored value for options.' + lclDCT['paramName'] + ' from ' +  str(old) + ' to ' + str(new))
        
        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)

#==========================================================
def CmdMisc_cleardebuglog(lclDCT, options, line):
        # Get file name
        debugFile = os.path.expandvars(os.getenv('MTX_LOG_DIR', '/var/log/mtx')) + '/mtx_debug.log'
        
        # Check that the debug log file exists AND the local file exists.  if local file doesn;t exist
        # it means tracing not enabled, so no need to do this
        if   not os.path.exists(debugFile): print('NOTE: debug log file doesn;t exist.  Nothing to monitor')
        elif not os.path.exists('_debugStartingLine'): print('NOTE: tracing not enabled, so no need to update sync file')
        else:
                # Clear the log file
                command = 'wc -l ' + debugFile + ' > _debugStartingLine'
                stdOut = QAUTILS.runCmd(command)
                
                # Debug output
                print('Will ignore prior contents in file ' + debugFile)
                
                # If verbose is not none, then output
                if lclDCT['verbose'].lower() != 'none': print(stdOut)
                
        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)

#==========================================================
def CmdMisc_savedebuglog(lclDCT, options, line):
        # *** lclDCT[] has all the values.

        # Get file name
        debugLogFile = os.path.expandvars(os.getenv('MTX_LOG_DIR', '/var/log/mtx')) + '/mtx_debug.log'
        
        # If thsi is a ccf action, then there's a results file that has sigtran test data.
        if ACTION.startswith('ccf'): ccfToolOutput = './' + COMMON.lclDCT['resultsDir'] + '/ECT_sigtran_*'
        else: ccfToolOutput = ''
        
        # add test tool file + debug log into the dataFile
        command = 'cat ' + ccfToolOutput + ' ' + debugLogFile + ' > ' + lclDCT['dataFile']
        #print command
        stdOut = QAUTILS.runCmd(command)
        
        # Debug output
        if len(ccfToolOutput) > 1:      print('Copied ' + ccfToolOutput + ' and ' + lclDCT['dataFile'] + ' to ' + lclDCT['dataFile'])
        else:                           print('Copied ' + debugLogFile + ' to ' + lclDCT['dataFile'])
        
        # If verbose is not none, then output
        if lclDCT['verbose'].lower() != 'none': print(stdOut)
        
        # If we're supposed to empty the file, do that
        if lclDCT['operation'] and lclDCT['operation'][0].lower() == 'empty': CmdMisc_cleardebuglog(lclDCT, options, line)
        
        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)

#==========================================================
def CmdMisc_notificationcheck(lclDCT, options, line):
        # *** lclDCT[] has all the values.

        # Call local function so command can be called via a parameter or as a separate command
        return notificationcheck(lclDCT['balanceClassId'], lclDCT['balanceId'], lclDCT['thresholdId'], lclDCT['amount'], lclDCT['eventPass'])

#==========================================================
def notificationcheck(balanceClassId, balanceId, thresholdId, amount, eventPass):
        global ThresholdCheckDebugLogFileLine
        
        # See if we need to get the threshold ID for this balance
        if thresholdId and thresholdId != '0' and ((type(thresholdId) is not int) and not thresholdId.isdigit()): (thresholdId, thresholdAmount, percentFlag) = PRIM.getThresholdId(balanceId, thresholdId)
        
        #  build string to check for
        stringToCheck = ''
        if thresholdId and int(thresholdId): stringToCheck += 'threshold Id=' + str(thresholdId) + '.*'
        if balanceClassId: stringToCheck += 'balance class Id=' + balanceClassId
        
        # See if we need to remove starting lines of the file (i.e. this is a subsequent notification check command)
        if ThresholdCheckDebugLogFileLine > 0:
                fileToCheck = '/tmp/debugLog'
                cmd = 'sed 1,' + str(ThresholdCheckDebugLogFileLine) + 'd /var/log/mtx/mtx_debug.log > ' + fileToCheck
                QAUTILS.runCmd(cmd)
                
        else:   fileToCheck = '/var/log/mtx/mtx_debug.log'
        
        # Now set the global to the current length of the debug log file
        cmd = 'wc -l /var/log/mtx/mtx_debug.log | cut -f1 -d" "'
        ThresholdCheckDebugLogFileLine = int(QAUTILS.runCmd(cmd))
        
        # Run the command
        cmd = 'grep -A3 "Notifications at end of " ' + fileToCheck + ' | grep -B 1 amount'
        if stringToCheck: cmd += ' | grep "' + stringToCheck + '"'
        
        # Get command count
        cmd1 = cmd + ' | wc -l'
        notCount = int(QAUTILS.runCmd(cmd1))
        
        # Debug putput
        print('\nFound notifications for balanceClassId/balanceId/thresholdId/amount ' + str(balanceClassId) + '/' + str(balanceId) + '/' + str(thresholdId) + '/' + str(amount) + '\n')
        if notCount: print(QAUTILS.runCmd(cmd))
        
        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)
        
#==========================================================
# *** DO NOT USE options or line parameters in this function.  Used by multiple places and those parameters are not populated. ***
def CmdMisc_setconstantvalue(lclDCT, options, line=None):
        # *** lclDCT[] has all the values.

        paramName = lclDCT['paramName']
        paramValue = lclDCT['paramValue']
        
        '''
        # See if we should translate
        result = [x for x in CUST.custParameterTranslate + DATA.parameterTranslate if x[0] == paramName]
        if len(result):
                # Translate the parameter
                myDict = {}
                myDict[paramName] = paramValue
                savedParamValue = paramValue
                paramValue = PRIM.translateTextFromMapping(result, myDict)
                print('CmdMisc_setconstantvalue: changed parameter ' + paramName + ' from ' + str(savedParamValue) + ' to ' + str(paramValue))
        '''
                
        # Set the constant.  No save/restore for now.
        DATA.constantValue[paramName] = str(paramValue)
        
        # Allow to be a formula.  Hard to tell the difference, so try and if fails set to value as-is.
        try:
                # Don't allow time to be changed to a built-in function.  Same for any ID (multiple dashes - below code evaluates the last one as a negative number)..
                # Now running into values that compile to None (e.g. Database)...
                # Also allow if all digits (else lose leading zeros below)
                if not paramValue.count(',min')  and \
                   not paramValue.count(',hour') and \
                   not paramValue.count(',week') and \
                   not paramValue.count(',month')and \
                   paramName[-2:].lower() != 'id' and \
                   not paramValue.isdigit():
                        # Save this - avoid compiler changing things to None
                        saveParamValue = paramValue
                        
                        # Compile this.
                        # NOTE: This seems to drop leading 0s (e.g. voice prefixes).  Need to see if we can better check if this is a formula vs a string...
                        code = parser.expr(paramValue).compile()
                        DATA.constantValue[paramName] = decimal.Decimal(eval(code))
                        
                        # If result is None then return to original value
                        if str(DATA.constantValue[paramName]) == 'None': DATA.constantValue[paramName] = str(saveParamValue)
        except:
                # If string has any escape character and then an arithmetic chacatrer (e.g. '\*'), then remove the escape character ('\').  They were added to keep thie string from being treated as an equation!
                DATA.constantValue[paramName] = DATA.constantValue[paramName].replace('\\*','*').replace('\\-','-').replace('\\+','+').replace('\\\\','\\')
                pass
        
        # If precision specified and string is not an integer, then try to map to that precision.
        # If not a float then nothing will change.  
        # NOTE: function sometimes called standalone, so can't assume dictionary entries will be present and thus need to check if in the dictionary.
        if 'precision' in lclDCT and lclDCT['precision'] and not str(DATA.constantValue[paramName]).isdigit():
                '''
                decimal.getcontext().prec = int(lclDCT['precision'])
                DATA.constantValue[paramName] = decimal.Decimal(DATA.constantValue[paramName])
                '''
                
                try:
                        cmd = "DATA.constantValue[paramName]=('%." + lclDCT['precision'] + "f' % float(DATA.constantValue[paramName]))"
                        exec(cmd)
                        print(cmd)
                except: pass
        
        print('Set constant value "' + paramName + '" to "' + str(DATA.constantValue[paramName]) + '"')
        
        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)
        
#==========================================================
# Set 5G constants
def CmdMisc_save5GData(lclDCT, objType, data):
        global SavedData
        
        # If no data specified, then copy from saved data
        if not data: data = copy.deepcopy(SavedData)
       # Debug if desired
        if lclDCT['verbose'].lower() in ['high', 'full']:
                print('Saving 5G data.  Returned dictionary is:')
                pprint.pprint(data)

        # Process each element individually.
        for entry in lclDCT['saveData']:
                # Split entry (required for diameter: contstant name = dictionary entry)
                if len(entry.split('=')) > 1: (name,value) = entry.split('=')
                else:
                        name = None
                        value = entry

                # Now walk the value to get to the desired data.  Look for keywords that may be comma separated.
                # Get copy of keys to play with.
                tmpData = copy.deepcopy(data)

                # Debug if desired
                if lclDCT['verbose'].lower() in ['high', 'full']:
                        pprint.pprint(tmpData)
                        print('Processing keys: ' + str(name) + ' = ' + value)

                # Get dictionary entries that have the desired string, limiting it for each string
                keyStr = ''
                for i,key in enumerate(value.split(',')):
                        '''
                        print 'Save5G processing data for key: ' + str(key)
                        pprint.pprint(tmpData)
                        '''
                        
                        # See if any replacements are needed (friendly shortcuts)
                        for item in [   ('mscc',        'multipleUnitInformation'),
                                        ('psinfo',      'pDUSessionChargingInformation'),
                                        ('gsu',         'grantedUnit'),
                                        ('amount',      'totalVolume'),
                                        ('result',      'resultCode'),
                                    ]:
                                # Split out pieces
                                (strToFind, strToUse) = item

                                # If not a match then skip
                                if key != strToFind: continue

                                # Replace key with desired string
                                key = strToUse

                                break

                        # See if in returned data.
                        # Current iem may be a list, so address here
                        if type(tmpData) is list:
                                _data = copy.deepcopy(tmpData)
                                tmpData = None
                                for item in _data:
                                        if key in item:
                                                tmpData = copy.deepcopy(item[key])
                                                break
                        
                        else:
                                try: tmpData = tmpData[key]
                                except:
                                        tmpData = None
                        
                        # See if nothing found
                        if not tmpData:
                                print('Warning: key ' + key + ' not in returned message')
                                break
                
                # Skip if entry not present
                if not tmpData: break
                
                # If here, then we have something.
                # See if name input.
                if name:
                        # See if more than one item found
                        try:
                                # Set the constant
                                # Set dictionary entries for constant setting
                                lclDCT['paramName'] = name
                                lclDCT['paramValue'] = tmpData
                                
                                # Call function to set constant
                                CmdMisc_setconstantvalue(lclDCT, None, None)
                        
                        except: print('Warning: constant "' + name + '" returned more than one item: ' + str(tmpData))
                        
                        # Done with this entry
                        continue
                
                # If here, then may have multiple entries
                for key in tmpData:
                        # Using MDC field name.  Change dashes.
                        keyName = key.replace('-','_')
                        
                        # Set the constant
                        # Set dictionary entries for constant setting
                        lclDCT['paramName'] = keyName
                        lclDCT['paramValue'] = tmpData[key]
                        
                        # Call function to set constant
                        CmdMisc_setconstantvalue(lclDCT, None, None)
                
#==========================================================
# Set Diameter constants
def CmdMisc_saveDiameterData(lclDCT, objType, data):
        global SavedData
        
        # If no data specified, then copy from saved data
        if not data: data = copy.deepcopy(SavedData)
        
        # Debug if desired
        if lclDCT['verbose'].lower() in ['high', 'full']:
                print('Saving Diameter data.  Returned dictionary is:')
                pprint.pprint(data)
        
        # Process each element individually.
        for entry in lclDCT['saveData']:
                # Split entry (required for diameter: contstant name = dictionary entry)
                if len(entry.split('=')) > 1: (name,value) = entry.split('=')
                else:
                        name = None
                        value = entry
                
                # Now walk the value to get to the desired data.  Look for keywords that may be comma separated
                # Get copy of keys to play with
                tmpData = [x for x in list(data.keys())]
                
                # Debug if desired
                if lclDCT['verbose'].lower() in ['high', 'full']:
                        pprint.pprint(tmpData)
                        print('Processing keys: ' + value)
                
                # Get dictionary entries that have the desired string, limiting it for each string
                keyStr = ''
                for i,key in enumerate(value.split(',')):
                        # Append new key to existing key.  Prefix '->' if not the first iteration.
                        if i: keyStr += '->'
                        keyStr += key
                        
                        # See if any replacements are needed (friendly shortcuts)
                        found = False
                        for item in [   ('mscc',        'Mscc'),
                                        ('psinfo',      'Service-Information->PS-Information'),
                                        ('smsinfo',     'Service-Information->SMS-Information'),
                                        ('mmsinfo',     'Service-Information->MMS-Information'),
                                        ('imsinfo',     'Service-Information->IMS-Information'),
                                        ('vcsinfo',     'Service-Information->VCS-Information'),
                                        ('gsu',         'Granted-Service-Unit'),
                                        ('amount',      'CC-'),
                                        ('result',      'Result-Code'),
                                    ]:
                                # Split out pieces
                                (strToFind, strToUse) = item
                                
                                # Repeat until search string no longer present.
                                # Most of the strings will only appear once, but keep logic common for those that appear multiple times.
                                while keyStr.count(strToFind):
                                        found = True
                                        
                                        # Get starting index
                                        start = keyStr.find(strToFind)
                                        
                                        # HACK: if MSCC then need to ensure there's a digit after the string
                                        if strToFind == 'mscc' and ((len(keyStr) < start+len(strToFind)+1) or (not keyStr[start+len(strToFind)].isdigit())): strToUse += '0'
                                        
                                        # Update keyString string to be pre-string, replacement string, post string (which may not exist)
                                        saveStr = keyStr
                                        keyStr = keyStr[:start] + strToUse
                                        try: keyStr += saveStr[start+len(strToFind):]
                                        except: pass
                                
                                # Will only match one string    
                                if found: break
                                
                        # Now find subset of entries based on the keyStr.
                        # The word "all" means use everything.  
                        if keyStr[0] == '^':            tmpData = [x for x in tmpData if x.startswith(keyStr[1:])]
                        elif keyStr.lower() != 'all':   tmpData = [x for x in tmpData if x.count(keyStr)] 
                        
                        # Debug if desired
                        if lclDCT['verbose'].lower() in ['high', 'full']: print('Loop ' + str(i) + ', key = ' + key + ', resulting keys are: ' + str(tmpData))
                
                # Now want to make the assignment(s).  
                # See if nothing found
                if not len(tmpData):
                        print('Warning: item ' + value + ' not in returned message')
                        pprint.pprint(data)
                        continue
                        
                # See if name input
                if name:
                        # See if more than one item found
                        if len(tmpData) > 1:
                                print('Warning: constant "' + name + '" returned more than one item: ' + str(tmpData))
                        else:
                                # Set the constant
                                # Set dictionary entries for constant setting
                                lclDCT['paramName'] = name
                                lclDCT['paramValue'] = data[tmpData[0]]
                                
                                # Call function to set constant
                                CmdMisc_setconstantvalue(lclDCT, None, None)
                        
                        # Done with this entry
                        continue
                
                # If here, then may have multiple entries
                for key in tmpData:
                        # Using MDC field name.  Always get last name of the key.  Change dashes.
                        keyName = key.split('>')[-1].replace('-','_')
                        
                        # Set the constant
                        # Set dictionary entries for constant setting
                        lclDCT['paramName'] = keyName
                        lclDCT['paramValue'] = data[key]
                        
                        # Call function to set constant
                        CmdMisc_setconstantvalue(lclDCT, None, None)
                
#==========================================================
def CmdMisc_saveOtherData(lclDCT, objType, data):
        global SavedData
        
        # Read data into ET structure.  If more than one record exists then returned data is NOT XML compliant - it's a buch of independent events.
        # In that case we need to put a heading on it so the ET library can manage this (as it expects a single record).
        i = 0
        while i <= 1:
                try:
                        # Normal case - single evnt returned
                        q = ET.fromstring(data)
                        break
                except:
                        # Failed - most likely because multiple records in here.
                        # Add a header the first time and loop around
                        if i == 0: data = '<kef>\n' + data + '\n</kef>'
                
                # Bump counter so we know where in the loop we passed (or didn't pass)
                i += 1
        
        # Set expected header depending on where in the loop we broke out of.
        if   i == 0: header = '.'
        elif i == 1: header = './MtxResponseEventInfo'
        else:
                print('ERROR converting returned data to ET format.  Top and bottom "kef" headings were added by this code and wer enot paet of what was returned by the engine.')
                print(str(data))
                sys.exit('Exiting due to errors')
        
        # Debug
        #ET.dump(q)
        
        # Process each saveData parameter
        for item in lclDCT['saveData']:
                # Set saved to False
                SavedData = False
        
                # Split entry (comma separated)
                entry = item.split(',')
                
                # Process uhe entry.  Need to iterate through the function.
                iterateThrouthFields(lclDCT, q, entry, objType, heading=header)
                
                # See if nothing saved for entry
                if lclDCT['saveDataIgnore']:
                        # Ignore save data results
                        print('saveDataIgnore set, so ignoring if we found anything')
                        continue
                elif not SavedData:
                        print('Nothing saved for criteria: ' + str(item))
                        
                        # If the name starts with Mtx and ends in Event, then it's probabaly the event name and shouldn't be listed.
                        for name in entry:
                                if name.startswith('Mtx') and name.endswith('Event'): print('NOTE: search criteria includes a name of "' + name + '", which is most likely the event container.  Event containers should not be in the search criteria.  Remove and try again.')
                        
                        # If expected to pass, then exit
                        if lclDCT['eventPass']:
                                print('Error: nothing found and event expected to pass')
                                ET.dump(q)
                                sys.exit('Exiting due errors')
                elif not lclDCT['eventPass']:
                        # If expected to fail, then exit
                                print('Error: something found and event expected to fail')
                                ET.dump(q)
                                sys.exit('Exiting due errors')
                
#==========================================================
# Set constants
def CmdMisc_saveData(lclDCT, objType, data):
        global TopLevelField
        
        TopLevelField = None
        
        # Sanity check the input
        if objType.lower() not in ['subscriber', 'device', 'group', 'diameter', 'event', 'user', 'subscription', 'gy', '5g', '5gsy', 'gx', 'sy']:
                sys.exit('ERROR: called CmdMisc_saveData with invalid object type: ' + objType)
        
        '''
        # If JSON, then convert to XML
        if REST_UTIL.restVersion == 'JSON':
                print 'ERROR: Having issues converting JSON to XML.  Only use savaData with REST or MDC input\n\n'
                return
                
                print 'Converting JSON to XML.\nJSON input:'
                print data
                
                # Need to add top-level header
                data = json.loads('{ "KEF": ' + data + ', }')
                
                print 'Converting JSON to XML.\nJSON input:'
                print 'Length of data: ' + str(len(data))
                print data
        
                data = xmltodict.unparse(data, pretty=True)
                #data = dicttoxml(data, root=False, attr_type=False)
                
                print '\nXML output:'
                print data
        else:
                print 'Non-JSON data:'
                print data
        '''
        # 5G
        if objType.lower() in ['5g', '5gsy']: return CmdMisc_save5GData(lclDCT, objType, data)
        
        # *************  Diameter here ***************
        # Diameter data is a dictionary.  User needs to specify specific element.
        if objType.lower() in ['diameter', 'gy', 'sy', 'gx']: return CmdMisc_saveDiameterData(lclDCT, objType, data)
        
        # *************  Non-Diameter here ***************
        return CmdMisc_saveOtherData(lclDCT, objType, data)
        
#==========================================================
# Iterative function
def iterateThrouthFields(lclDCT, q, entry, objType, value=None, heading='.'):
        global TopLevelField
        
        '''
        print 'entry = ' + str(entry)
        ET.dump(q)
        '''
        
        # Different actions report data under different groupings.
        # Action not input, so require data to identify the action.
        
        # Process top item in the entry list
        field = entry[0]
        
        # Assume no children to look for here
        xmlName = None
        
        # Assume single item was requested
        singleFlag = True
                
        # Need customer prefix
        custName = GENERIC.CustomData['Subscriber']['customName']
        prefix = custName[:custName.find('Subscriber')]
        
        # See if there's a field name
        if field.count('='):
                #print str(field)
                
                # Split the field
                (name,value) = field.split('=')
                
                # If value setup as a default parameter, then set here (valuable for looping through balance names)     
                while value.count('defaultParam'):
                        # Really sholdn't be here anymore...
                        print('Hmmm.  Doing defaultParam logic in iterateThrouthFields, when it should all have been done from csvMain.py...')
                        
                        # Get default parameter ID
                        paramId = value[value.find('defaultParam') + len('defaultParam')]
                        
                        # Get parameter name
                        paramName = 'defaultParam'+paramId
                        
                        # See if defined
                        if lclDCT['paramName'] not in lclDCT:
                                print('Warning: command referenced ' + lclDCT['paramName'] + ' but that\'s not in the set of default parameters')
                                print('Test will most likely fail.  Default param translation stopped for this parameter.')
                                break
                        elif not paramName:
                                print('Warning: command referenced ' + lclDCT['paramName'] + ' but that\'s not set')
                                print('Test will most likely fail.  Default param translation stopped for this parameter.')
                                break
                        else:
                                value = value.replace('defaultParam'+paramId, lclDCT[paramName])
                                print('Default Param logic: Updated parameter ' + name + ' to ' + value)
                        
                # Set string to find based on name
                if   name in[ 'offerId', 'purchaseOffer']:
                        xmlName = [heading+'/PurchasedOfferArray/MtxPurchasedOfferInfo']
                        xmlTags = ['CatalogItemId', 'CatalogItemExternalId']
                elif name == 'balanceId':
                        xmlName = [heading+'/BalanceArray/MtxBalanceInfo', heading+'/BalanceArray/MtxBalanceInfoSimple', heading+'/BalanceArray/MtxBalanceInfoPeriodic']
                        xmlTags = ['Name', 'TemplateId']
                elif name == 'thresholdId':
                        xmlName = [heading+'/ThresholdArray/MtxThresholdInfo']
                        xmlTags = ['Name', 'ThresholdId']
                else:
                        # Convert TF parameter names to XML output field names
                        if   name in ['resourceId', 'notificationPreference', 'timeZone', 'language']:
                                # Ensure first letter is upper case and none of the rest are changed
                                name = name[0].upper() + name[1:]
                        
                        elif name in ['subStatus', 'groupStatus', 'devStatus']:
                                name = 'Status'
                        
                        #  Only want to check tag for a match
#                       print name + ' search'
                        if q.find(name) is None: return
#                       print name + ' exists'
                        
                        # Add translations here.  primData has some (e.g. UpdateType).
                        if not value.isdigit():
                                try:
                                        cmd = '_a = PRIMDATA.' + name + 'Mapping[value]'
                                        exec(cmd)
                                        value = locals()['_a']
                                except: pass
                                
                                # Special case for balance template ID.  Convert name to template ID
                                if name == 'BalanceTemplateId':
                                        oldValue = value
                                        value = str(DATA.balanceIdMapping[value.lower()])
                                        print('Converted balance name "' + oldValue + '" to template ' + value)
                                
                        # Make sure the value of the record equals the input value
                        if q.find(name).text.strip() != value: return
#                       print name + ' matches value ' + value
                        
                        # Found a match.  If more criteria then keep iterating
                        if len(entry) > 1: return(iterateThrouthFields(lclDCT, q, entry[1:], objType))
                        else:
#                               print name + ' is last criteria'
                                # Set flag that a single item was not requested
                                singleFlag = False
        else:
                # Nothing to split - this better be the field...
                name = field
                        
                # If looking for custom fields and the object is subscription, change to subscriber
                if name.lower() in ['custom', 'all'] and objType == 'Subscription': objType = 'Subscriber'
                if name.lower() in ['customoffer']: objType = 'Offer'
                
                # Convert TF parameter names to XML output field names
                if   name in ['resourceId', 'notificationPreference', 'timeZone', 'language']:
                        # Ensure first letter is upper case and none of the rest are changed
                        name = name[0].upper() + name[1:]
                
                elif name == 'balanceId':
                        xmlName = [heading+'/BalanceArray/MtxBalanceInfo', heading+'/BalanceArray/MtxBalanceInfoSimple', heading+'/BalanceArray/MtxBalanceInfoPeriodic']
                        xmlTags = ['all']
                # Non Event 
                elif name.lower() == 'purchaseoffer':
                        # Get usage data from the event
                        xmlName = [heading+'/PurchasedOfferArray/MtxPurchasedOfferInfo']
                        xmlTags = ['all']
                
                elif name in ['subStatus', 'groupStatus', 'devStatus']:
                        name = 'Status'
                        
                elif name.lower() == 'customoffer'                              and \
                     'customName' in GENERIC.CustomData[objType]        and \
                     not GENERIC.CustomData[objType]['customName'].startswith('Mtx'):
                        # Get custom fields
                        xmlName = [heading+'/Attr/' + GENERIC.CustomData[objType]['customName']+'Extension']
                        xmlTags = ['all']
                        #print 'Going to look for custom names for object ' + objType + ', custom name ' + GENERIC.CustomData[objType]['customName'] + ', xmlName = ' + str(xmlName)
                        #ET.dump(q)
                elif name.lower() == 'custom'                           and \
                     'customName' in GENERIC.CustomData[objType]        and \
                     not GENERIC.CustomData[objType]['customName'].startswith('Mtx'):
                        # Get custom fields
                        xmlName = [heading+'/Attr/' + GENERIC.CustomData[objType]['customName']+'Extension']
                        xmlTags = ['all']
                        #print 'Going to look for custom names for object ' + objType + ', custom name ' + GENERIC.CustomData[objType]['customName'] + ', xmlName = ' + str(xmlName)
                        #ET.dump(q)
                elif name.lower() == 'base':
                        # Get base fields
                        xmlName = ['.']
                        xmlTags = ['all']
                elif name.lower() == 'cycleinfo':
                        # Get fields
                        xmlName = [heading+'CycleInfo/MtxPurchasedItemCycleInfo']
                        xmlTags = ['all']
                elif name.lower() == 'all':
                        # Get base + custom fields
                        xmlName = ['.', heading+'/Attr/' + GENERIC.CustomData[objType]['customName']+'Extension']
                        xmlTags = ['all']
                elif name.lower() in list(DATA.eventTypeStringArrayMapping.keys()) + [x.replace('_', '-') for x in list(DATA.eventTypeStringArrayMapping.keys())]:
                        # These are all event names.
                        
                        # Change any underscore to a dash (either is fine for input)
                        name = name.replace('_', '-')
                        
                        # Set top level field.
                        TopLevelField = name.lower()
                        
                        # If starts with cust- then remove that
                        if TopLevelField.startswith('cust-'): TopLevelField = TopLevelField[5:]
                        
                        # Pull in official and custom fileds (if defined) as options.
                        # Event names use capital per word (and the input is words separated with dashed).
                        eventNameSuffix = "".join([x.capitalize() for x in name.split('-')]) + 'Event'
                        
                        # Try with default prefix
                        keyName = 'Mtx'+ eventNameSuffix
                        xmlName = ['./EventList/'+ keyName]
                        
                        # Try with custom prefix
                        keyName = prefix + eventNameSuffix
                        if keyName in GENERIC.CustomData: xmlName.append(('./EventList/' + GENERIC.CustomData[keyName]['customName']))
                        
                        # Also check if the name works as-is works (last ditch effort...)
                        keyName = prefix + "".join([x for x in name.split('-')]) + 'Event'
                        if keyName in GENERIC.CustomData: xmlName.append(('./EventList/' + GENERIC.CustomData[keyName]['customName']))
                        
                        xmlTags = ['all']
                        #print 'XML tag for name ' + name + ': ' + str(xmlName)
                elif set([name.lower(), name, name.upper(), name.lower().capitalize()]) & set(DATA.productList):
                        # Requeting a product name.  This means an event.
                        
                        # Check if we have a custom name for this event.  Use same names as were checked in the elif line.
                        for keyName in [name.lower(), name, name.upper(), name.lower().capitalize()]:
                                # Build key name
                                keyName = prefix + keyName + 'Event'
                                #print 'Checking for event ' + keyName
                                #pprint.pprint(GENERIC.CustomData)
                                
                                # See if we have a match
                                if keyName in GENERIC.CustomData:
                                        xmlName = [heading+'/EventList/' + GENERIC.CustomData[keyName]['customName']]
                                        
                                        # Will only ever have one of these.
                                        break
                        else:
                                # Use non-custom name using default naming convention if no custom name found
                                keyName = 'Mtx'+ name.lower().capitalize() + 'Event'
                                xmlName = [heading+'/EventList/'+ keyName]
                        
                        xmlTags = ['all']
                        #print 'XML tag for name ' + name + ': ' + str(xmlName)
                elif name.lower() == 'usage':
                        # Get usage data from the event
                        xmlName = [heading+'/UsageQuantityList/MtxEventUsageQuantity']
                        xmlTags = ['all']
                elif name.lower() == 'offer':
                        # Where to go depends on top level field
                        if   TopLevelField in ['usage', 'recurring']:
                                xmlName = [heading+'/AppliedOfferArray/MtxEventAppliedOffer']
                        elif TopLevelField == 'purchase':
                                xmlName = [heading+'/OfferInfoArray/MtxPurchaseEventOfferInfo']
                        xmlTags = ['all']
                elif name.lower() == 'bundle':
                        # Get usage data from the event
                        if   TopLevelField in ['usage', 'recurring']:
                                xmlName = [heading+'/AppliedBundleArray/MtxEventAppliedBundle']
                        elif TopLevelField == 'purchase':
                                xmlName = [heading+'/BundleInfoArray/MtxPurchaseEventBundleInfo']
                        xmlTags = ['all']
                elif name.lower() == 'catalog':
                        # Get usage data from the event
                        xmlName = [heading+'/AppliedCatalogItemArray/MtxEventAppliedCatalogItem']
                        xmlTags = ['all']
                elif name.lower() == 'catalogitem':
                        # Get usage data from the event
                        xmlName = [heading+'/AppliedCatalogItemArray/MtxEventAppliedCatalogItem/CatalogItemTemplateAttr/' + prefix + 'CatalogItems']
                        xmlTags = ['all']
                elif name.lower() == 'cycledata':
                        # Get cycle data
                        xmlName = [heading+'/CycleInfo/MtxPurchasedItemCycleInfo']
                        xmlTags = ['all']
                elif name.lower() == 'template':
                        # Get usage data from the event
                        xmlName = [heading+'/CatalogItemTemplateAttr/' + prefix + 'CatalogItems']
                        xmlTags = ['all']
                elif name.lower() == 'tax':
                        # Get usage data from the event
                        xmlName = [heading+'/AppliedTaxArray/MtxEventAppliedTax']
                        xmlTags = ['all']
                elif name.lower() == 'balance':
                        # Get usage data from the event
                        xmlName = [heading+'/BalanceUpdateArray/MtxBalanceUpdate']
                        xmlTags = ['all']
                elif name.lower() == 'charge':
                        # Get usage data from the event
                        xmlName = [heading+'/ChargeList/MtxEventCharge']
                        xmlTags = ['all']
                elif name.lower() == 'gl':
                        # Get item data
                        xmlName = [heading+'/GlInfoArray/MtxEventGlInfo']
                        xmlTags = ['all']
                elif name.lower() == 'meter':
                        # Get item data
                        xmlName = [heading+'/MeterUpdateArray/MtxMeterUpdate']
                        xmlTags = ['all']
                else:
                        # Use the field as-is
                        xmlName = [heading+'/'+name]
                        xmlTags = ['all']
                        
        # See if we need to find children
        if xmlName:
         for xml in xmlName:
                # Debug
                #print 'Processing XML name: ' + xml
                
                # Name may be the lowest rung
                if q.find(name) is not None:
                   # Seeing case where a field is returned with an empty string value.  q reads this as a value of None...
                   if q.find(name).text is None:
                        print('Found a field where the value is an empty string.  Not saving anything.')
                        return
                        
                   elif q.find(name).text.strip():
                        #print 'Found "' + name + '" with value = ' + str(q.find(name).text.strip())
                        # Found the item in question.
                        # Check if more entries (which would be an error)
                        if len(entry) > 1: sys.exit('ERROR: saveData entry "' + name + '" has a value - can\'t iterate past this.')
                        return setValues(lclDCT, q, True, name)
                
                # Process all children with this heading
                for child in q.findall(xml):
                        #print 'Child:'
                        #ET.dump(child)
                        
                        # See if the field value matches the child entry
                        for tag in xmlTags:
                           # A tag of all means to always process it.
                           if tag != 'all':
#                               print 'Looking for tag: ' + tag + ' for value ' + str(value)
                                # Skip if tag not a match
                                if child.find(tag) is None: continue
#                               print 'Value is ' + child.find(tag).text.strip()
                                if child.find(tag).text.strip() != value: continue
#                               print 'Found tag: ' + tag + ', value = ' + str(value)
                                
                           # Found a match.  If more criteria then keep iterating
                           if len(entry) > 1:
                                #print 'Iterating again - entry is length ' + str(len(entry))
                                iterateThrouthFields(lclDCT, child, entry[1:], objType)
                           else:
                                #print 'Setting xmlName name ' + name
                                setValues(lclDCT, child, False, None)
        else:
                #print 'Setting non-xml name ' + name
                setValues(lclDCT, q, singleFlag, name)

#==========================================================
# Save values into constants
def setValues(lclDCT, q, singleFlag, name):
        global SavedData

        # Check if single or multiple 
        if singleFlag:
                # Set dictionary entries for constant setting
                lclDCT['paramName'] = name
                
                # Typos won't exist, so check for that here
                try:
                        lclDCT['paramValue'] = q.find(name).text.strip()
                except:
                        name = str(name)
                        print('Nothing saved for name: ' + name)
                        return
                
                # Call function to set constant
                CmdMisc_setconstantvalue(lclDCT, None, None)
        else:
           # Create constants for all base fields.
           dctRcv = {}
           dctRcv = XML.getObjectBaseFields(q, dctRcv)
           
           for key in dctRcv:
                # Set dictionary entries for constant setting
                lclDCT['paramName'] = key
                lclDCT['paramValue'] = dctRcv[key]
                
                # Call function to set constant
                CmdMisc_setconstantvalue(lclDCT, None, None)
        
        # Set global flag
        SavedData = True
                        
#==========================================================
# Compare operands against operations
def CmdMisc_compare(lclDCT, options, line, _validate=True):
        # *** lclDCT[] has all the values.
        
        # Walk operations
        result = False
        for i,opr in enumerate(lclDCT['operation']):
                # Run the operation
                code = parser.expr(opr).compile()
                result = eval(code)
                print('Operation "' + opr + '" evaluated to ' + str(result))
                
                # See if no more operations to perform
                if i >= len(lclDCT['operation']) - 1: break
                
                # More commands to perform
                operator = lclDCT['operators'][i]
                
                # Now check for and/or commands
                if operator.lower() == 'and':
                        # Skip here is current result is False
                        if not result:
                                print('Skipping operation "' + opr + '" becuase current result is ' + str(result)  + ' and the operation is ' + operator.lower())
                                break
                        
                        # Reset result to false
                        result = False
                        
                elif operator.lower() == 'or':
                        # Skip here is current result is true
                        if result:
                                print('Skipping operation "' + opr + '" becuase current result is ' + str(result) + ' and the operation is ' + operator.lower())
                                break
        print('Compare result is ' + str(result))
        
        # Can be called as part of "if" command processing.  Then validate is False and we want the result returned
        if not _validate: return result
        
        # If the result doesn't match the expected result, then we have an issue
        if result != lclDCT['eventPass']:
                print('ERROR: comparison failed expected results.')
                if not lclDCT['continuePastError']: sys.exit('Error on command: ' + lclDCT['ACTION'])
                else:                     print('Continuing as continuePastError is set to True')
        
        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)
        
#==========================================================
# Compare operands against operations
def CmdMisc_clearmef(lclDCT, options, line):
        '''
        # *** lclDCT[] has all the values.
        '''
        
        # Get count of files
        cmd = 'ls -lt $MTX_SHARED_DIR/event_files/*gz | wc -l'
        count = QAUTILS.runCmd(lclDCT['cmd'])

        # Remove files from shared memory, event files directory
        if int(count) > 0:
                print('Removing ' + str(count) + ' files from $MTX_SHARED_DIR/event_files/*gz')
                cmd = 'rm -f $MTX_SHARED_DIR/event_files/*gz'
                QAUTILS.runCmd(lclDCT['cmd'])
        else:   print('There are no files in $MTX_SHARED_DIR/event_files/*gz')
        
        return (None, None)
        
#==========================================================
# Compare operands against operations
def CmdMisc_queryevent(lclDCT, options, line):
        # *** lclDCT[] has all the values.
        
        # Invoke API
        retCode = REST_UTIL.queryEventstoreById(V3inst,
                        lclDCT['elementId'],
                        queryType = 'EventId',
                        applyDefaultFilter=lclDCT['applyDefaultFilter'],
                        routingType=lclDCT['routingType'],
                        routingValue=lclDCT['routingValue'],
                        eventPass=lclDCT['eventPass'],
                        searchInMemoryDatabase=lclDCT['searchInMemoryDatabase'],
                        )
        
        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])
        
        # Nothing to query from this command
        return (None, None)
