#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:48
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:28
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:08
# from builtins import str
# from builtins import str
import os, sys
import log_errors as LOGGER
import QA_subscriber_management_direct as MDC_UTILS
import data_container_defs as MDCDEFS
import QA_group_management_direct as GROUP

path = os.getcwd()
logger = LOGGER.clErrors(path)


def validateInitiatorSponsorForGroup(restInst, mdcFileName, diffInitiator=False, diffSponsor=False, initiatorOid=None,
        initiatorExternalId=None, sponsorOid=None, sponsorExternalId=None, queryTime=None, testTag=None):
    mdcFile = open(mdcFileName, 'r')
    mdcFileLines = mdcFile.readlines()
    mdcFile.close()

    # If we are expecting the saved group to be the initiator, validate this
    if diffInitiator:
        diffInitiatorOidForGroup(restInst, mdcFileLines, initiatorOid, testTag, queryTime)

        diffInitiatorExternalIdForGroup(restInst, mdcFileLines, initiatorExternalId, testTag, queryTime)

    # If we are expecting the saved group to be the sponsor, validate this
    elif diffSponsor:
        diffSponsorOidForGroup(restInst, mdcFileLines, sponsorOid, testTag, queryTime)

        diffSponsorExternalIdForGroup(restInst, mdcFileLines, sponsorExternalId, testTag, queryTime)


def validateInitiatorSponsorForSub(restInst, mdcFileName, diffInitiator=False, diffSponsor=False, initiatorOid=None,
        initiatorExternalId=None, initiatorDeviceOid=None, sponsorOid=None, sponsorExternalId=None, queryTime=None,
        testTag=None):
    mdcFile = open(mdcFileName, 'r')
    mdcFileLines = mdcFile.readlines()
    mdcFile.close()

    # If we are expecting the saved subscriber to be the initiator, validate this
    if diffInitiator:
        diffInitiatorOidForSub(restInst, mdcFileLines, initiatorOid, testTag, queryTime)

        diffInitiatorDeviceOidForSub(restInst, mdcFileLines, initiatorDeviceOid, testTag, queryTime)

        diffInitiatorExternalIdForSub(restInst, mdcFileLines, initiatorExternalId, testTag, queryTime)

    # If we are expecting the saved subscriber to be the sponsor, validate this
    elif diffSponsor:
        diffSponsorOidForSub(restInst, mdcFileLines, sponsorOid, testTag, queryTime)

        diffSponsorExternalIdForSub(restInst, mdcFileLines, sponsorExternalId, testTag, queryTime)


def diffInitiatorOidForGroup(restInst, mdcFileLines, initiatorOid, testTag, queryTime):
    # No initiator OID found in EDR
    if initiatorOid is None:
        logger.printSummary(path, testTag + ' ==> Failed (No Initiator Found)')
        return

    # Get data for group corresponding to initiator OID 
    oidFileName = GROUP.queryGroup(restInst, path, initiatorOid, testTag + '_OID',
        queryType='ObjectId', queryTime=queryTime, diffEvents=True)
    oidFile = open(oidFileName, 'r')
    oidFileLines = oidFile.readlines()
    oidFile.close()

    # Diff original group and initiator OID
    oidDiffs = [line for line in mdcFileLines if line not in oidFileLines]

    # If there are differences, output them in readable diff format
    if oidDiffs:
        oidDiffs = difflib.context_diff(mdcFileLines, oidFileLines)
        logger.printSummary(path, testTag + ' ==> Failed (Saved group does not match initiator OID)')
        logger.printSummary(path, ''.join(oidDiffs))
        return

    logger.printSummary(path, testTag + ' ==> Success (Saved group matches initiator OID)')


def diffInitiatorExternalIdForGroup(restInst, mdcFileLines, initiatorExternalId, testTag, queryTime):
    # Diff original group and initiator ExternalId if it has one
    if initiatorExternalId is not None:
        # Get data for group corresponding to initiator ExternalId
        externalIdFileName = GROUP.queryGroup(restInst, path, initiatorExternalId,
            testTag + '_ExternalId', queryType = 'ExternalId', queryTime = queryTime, diffEvents=True)
        externalIdFile = open(externalIdFileName, 'r')
        externalIdFileLines = externalIdFile.readlines()
        externalIdFile.close()

        # Diff original group and initiator ExternalId
        externalIdDiffs = [line for line in mdcFileLines if line not in externalIdFileLines]

        # If there are differences, output them in readable diff format
        if externalIdDiffs:
            externalIdDiffs = difflib.context_diff(mdcFileLines, externalIdFileLines)
            logger.printSummary(path, testTag + ' ==> Failed (Saved group does not match initiator ExternalId)')
            logger.printSummary(path, ''.join(externalIdDiffs))
            return

        logger.printSummary(path, testTag + ' ==> Success (Saved group matches initiator ExternalId)')


def diffSponsorOidForGroup(restInst, mdcFileLines, sponsorOid, testTag, queryTime):
    # No sponsor OID found in EDR
    if sponsorOid is None:
        logger.printSummary(path, testTag + ' ==> Failed (No Sponsor Found)')
        return

    # Get data for group corresponding to sponsor OID 
    oidFileName = GROUP.queryGroup(restInst, path, sponsorOid, testTag + '_OID',
        queryType='ObjectId', queryTime=queryTime, diffEvents=True)
    oidFile = open(oidFileName, 'r')
    oidFileLines = oidFile.readlines()
    oidFile.close()

    # Diff original group and sponsor OID
    oidDiffs = [line for line in mdcFileLines if line not in oidFileLines]

    # If there are differences, output them in readable diff format
    if oidDiffs:
        oidDiffs = difflib.context_diff(mdcFileLines, oidFileLines)
        logger.printSummary(path, testTag + ' ==> Failed (Saved group does not match sponsor OID)')
        logger.printSummary(path, ''.join(oidDiffs))
        return

    logger.printSummary(path, testTag + ' ==> Success (Saved group matches sponsor OID)')


def diffSponsorExternalIdForGroup(restInst, mdcFileLines, sponsorExternalId, testTag, queryTime):
    # Diff original group and sponsor ExternalId if it has one
    if sponsorExternalId is not None:

        # Get data for group corresponding to sponsor ExternalId
        externalIdFileName = GROUP.queryGroup(restInst, path, sponsorExternalId,
            testTag + '_ExternalId', queryType = 'ExternalId', queryTime = queryTime, diffEvents=True)
        externalIdFile = open(externalIdFileName, 'r')
        externalIdFileLines = externalIdFile.readlines()
        externalIdFile.close()

        # Diff original group and sponsor ExternalId
        externalIdDiffs = [line for line in mdcFileLines if line not in externalIdFileLines]

        # If there are differences, output them in readable diff format
        if externalIdDiffs:
            externalIdDiffs = difflib.context_diff(mdcFileLines, externalIdFileLines)
            logger.printSummary(path, testTag + ' ==> Failed (Saved group does not match sponsor ExternalId)')
            logger.printSummary(path, ''.join(externalIdDiffs))
            return

        logger.printSummary(path, testTag + ' ==> Success (Saved group matches sponsor ExternalId)')


def diffInitiatorOidForSub(restInst, mdcFileLines, initiatorOid, testTag, queryTime):
    # No initiator OID found in EDR
    if initiatorOid is None:
        logger.printSummary(path, testTag + ' ==> Failed (No Initiator Found)')
        return

    # Get data for sub corresponding to initiator OID 
    oidFileName = MDC_UTILS.querySubscriber(restInst, path, initiatorOid, testTag + '_OID',
        queryType='ObjectId', queryTime=queryTime, diffEvents=True)
    oidFile = open(oidFileName, 'r')
    oidFileLines = oidFile.readlines()
    oidFile.close()

    # Diff original sub and initiator OID
    oidDiffs = [line for line in mdcFileLines if line not in oidFileLines]

    # If there are differences, output them in readable diff format
    if oidDiffs:
        oidDiffs = difflib.context_diff(mdcFileLines, oidFileLines)
        logger.printSummary(path, testTag + ' ==> Failed (Saved subscriber does not match initiator OID)')
        logger.printSummary(path, ''.join(oidDiffs))
        return

    logger.printSummary(path, testTag + ' ==> Success (Saved subscriber matches initiator OID)')


def diffInitiatorDeviceOidForSub(restInst, mdcFileLines, initiatorDeviceOid, testTag, queryTime):
    if initiatorDeviceOid:
        deviceResult=restInst.deviceQuery(queryType='ObjectId', queryValue=str(initiatorDeviceOid), now=queryTime)
        if not hasattr(deviceResult, "printXml"):
            logger.printSummary(path, testTag + ' ==> Failed (Event initiator diff failed to parse device!)')
            return

        initiatorDeviceSubscriberId  = deviceResult.getUsingKey(MDCDEFS.kMtxResponseDeviceSubscriberIdFldKey)
        initiatorDeviceSubscriberFileName = MDC_UTILS.querySubscriber(restInst, path,
            initiatorDeviceSubscriberId, testTag + '_DeviceIdSubscriber', queryType = 'ObjectId',
            queryTime=queryTime, diffEvents=True)

        # Diff original subscriber and initiator device subscriber
        initiatorDeviceSubscriberFile = open(initiatorDeviceSubscriberFileName, 'r')
        initiatorDeviceSubscriberFileLines = initiatorDeviceSubscriberFile.readlines()
        initiatorDeviceSubscriberFile.close()

        # Diff original sub and subcriber referenced by device
        initiatorDeviceSubscriberDiffs = \
            [line for line in mdcFileLines if line not in initiatorDeviceSubscriberFileLines]

        # If there are differences, output them in readable diff format
        if initiatorDeviceSubscriberDiffs:
            initiatorDeviceSubscriberDiffs = difflib.context_diff(mdcFileLines, initiatorDeviceSubscriberFileLines)
            logger.printSummary(path, testTag + \
                ' ==> Failed (Saved subscriber does not match initiator device SubscriberId)')
            logger.printSummary(path, ''.join(initiatorDeviceSubscriberDiffs))
            return

        logger.printSummary(path, testTag + ' ==> Success (Saved subscriber matches initiator device\'s subscriber)')


def diffInitiatorExternalIdForSub(restInst, mdcFileLines, initiatorExternalId, testTag, queryTime):
    if initiatorExternalId is not None:
        # Get data for sub corresponding to initiator ExternalId
        externalIdFileName = MDC_UTILS.querySubscriber(restInst, path, initiatorExternalId,
            testTag + '_ExternalId', queryType='ExternalId', queryTime=queryTime, diffEvents=True)
        externalIdFile = open(externalIdFileName, 'r')
        externalIdFileLines = externalIdFile.readlines()
        externalIdFile.close()

        # Diff original subscriber and sponsor ExternalId
        externalIdDiffs = [line for line in mdcFileLines if line not in externalIdFileLines]

        # If there are differences, output them in readable diff format
        if externalIdDiffs:
            externalIdDiffs = difflib.context_diff(mdcFileLines, externalIdFileLines)
            logger.printSummary(path, testTag + ' ==> Failed (Saved subscriber does not match initiator ExternalId)')
            logger.printSummary(path, ''.join(externalIdDiffs))
            return
        logger.printSummary(path, testTag + ' ==> Success (Saved subscriber matches initiator ExternalId)')


def diffSponsorOidForSub(restInst, mdcFileLines, sponsorOid, testTag, queryTime):
        if sponsorOid is None:
            logger.printSummary(path, testTag + ' ==> Failed (No Sponsor Found)')
            return

        # Get data from sub corresponding to sponsor OID
        oidFileName = MDC_UTILS.querySubscriber(restInst, path, sponsorOid, testTag + '_OID',
            queryType='ObjectId', queryTime=queryTime, diffEvents=True)
        oidFile = open(oidFileName, 'r')
        oidFileLines = oidFile.readlines()
        oidFile.close()

        # Diff original subscriber and sponsor OID
        oidDiffs = difflib.context_diff(mdcFileLines, oidFileLines)

        # If there are differences, output them in readable diff format
        if oidDiffs:
            logger.printSummary(path, testTag + ' ==> Failed (Saved subscriber does not match sponsor OID)')
            logger.printSummary(path, ''.join(oidDiffs))
            return

        logger.printSummary(path, testTag + ' ==> Success (Saved subscriber matches sponsor OID)')


def diffSponsorExternalIdForSub(restInst, mdcFileLines, sponsorExternalId, testTag, queryTime):
    if sponsorExternalId is not None:
        # Get data for sub corresponding to initiator ExternalId
        externalIdFileName = MDC_UTILS.querySubscriber(restInst, path, sponsorExternalId,
            testTag + '_ExternalId', queryType = 'ExternalId', queryTime = queryTime, diffEvents=True)
        externalIdFile = open(externalIdFileName, 'r')
        externalIdFileLines = externalIdFile.readlines()
        externalIdFile.close()

        # Diff original subscriber and sponsor ExternalId
        externalIdDiffs = difflib.context_diff(mdcFileLines, externalIdFileLines)

        # If there are differences, output them in readable diff format
        if externalIdDiffs:
            logger.printSummary(path, testTag + \
                ' ==> Failed (Saved subscriber does not match sponsor ExternalId)')
            logger.printSummary(path, ''.join(externalIdDiffs))
            return

        logger.printSummary(path, testTag + ' ==> Success (Saved subscriber matches sponsor ExternalId)')
