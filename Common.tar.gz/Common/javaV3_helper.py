
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:31
#
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:13
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:34:57
#!/home/mtx/workspace/jython/jython
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

# from builtins import str
# from builtins import object
# from builtins import str
# from builtins import object
import sys
sys.path.append("/home/mtx/workspace/trunk/MTXQA/QA/Tests/mtx_tests_java/java_common/")
sys.path.append("/home/mtx/workspace/trunk/MTXQA/QA/Tests/mtx_tests_java/java_common/QaTests.jar")

class submanTest(object):
    _userDct = {}
    _dctList = []

    def __init__(self, userDctIn):
        self._userDct= [] 
        self._dctList = eval(userDctIn)
        #print "==============================================="
        #print self._dctList
        #print "==============================================="

    def sendRequest(self, func):
        sys.path.append("QaTests.jar")
        import com.matrixx.test
        from java.math import BigInteger
        classTest = com.matrixx.test.QaTests()

        if (func == "multiReqCreateSubscriberAndDevice"):
            print("===============================================")
            i = 0
            offerList = []
            userDevice = []
            externalId = None
            #print  self._dctList
            for list1 in self._dctList:
               # print list1
                for y in list1:
                    #print y
                    if "ProductOfferId" in y:
                        offerList.append(y)
                    elif "Imsi" in y:
                        externalId = y["Imsi"]
                if offerList == []:
                    userDevice.append(list1)                   
            
            print(userDevice)
            print("===============================================")
            print(offerList)
            classTest.multiReqCreateSubscriberAndDevice(userDevice[0], offerList,100, int(externalId))

        if (func == "addSubscriber"):
            #assuming always getting a list of DCTs
            print("===============================================")
            print("SENDING FOR THIS REQUEST")
            print(self._dctList)
            print("===============================================")
            classTest.createSubscriber(self._dctList)

        elif (func == "addSubscriberDevice"):
            #assuming always getting a list of DCTs
            dct0 =  self._dctList[0]
            print("===============================================")
            print(dct0)
            print("===============================================")
            #if dct0.has_key("containerName"):  List[1]
            #else :  self._userDct = self._dctList[0]

            ExternalId = str(self._userDct['ExternalId'])
            #self._userDct["ExternalId"] = self._userDct["ExternalId"] + 1
            #print self._userDct
            classTest.createSubscriberAndDevice(self._dctList, BigInteger(ExternalId))

        elif (func == "deviceImsiPurchaseOffer"): 
            offerList = []
            imsiDct = {}
            #extract the Imsi
            offerList = [x for x in  self._dctList if "Imsi" not in x]
            imsiDct = [x for x in  self._dctList if "Imsi" in x]
            imsi = imsiDct[0]["Imsi"] #using deviceId as externalId ? TODO:fix
            #recreate the collection :[{'ProductOfferId': 9, 'StartTime': 'None', 'EndTime': 'None'}]
            print("===============================================")
            print("SENDING FOR THIS REQUEST")
            print(offerList)
            print(imsi)
            print("===============================================")
            classTest.createDeviceImsiPurchaseOffer(offerList, imsi)

        elif (func == "createDeviceMobile"):
            imsiDct = [x for x in  self._dctList if "Imsi" in x]
            imsi = str(imsiDct[0]["Imsi"])
            #print self._dctList
            print("===============================================")
            print("SENDING FOR THIS REQUEST")
            print(self._dctList)
            print(BigInteger(imsi))
            print("===============================================")
            classTest.deviceCreate(self._dctList, "Mobile", BigInteger(imsi))

        elif (func == "subscriberAddDevice"): 
            externalId =  self._dctList[0]["ExternalId"]
            imsi = self._dctList[0]["Imsi"]
            print("===============================================")
            print("SENDING FOR THIS REQUEST")
            print(externalId)
            print(BigInteger(imsi))
            print("===============================================")
            classTest.subscriberAddDevice(externalId, BigInteger(imsi))

        elif (func == "subscriberQueryWallet"):
            print(self._dctList)
            classTest.subscriberQueryWallet(self._dctList)

        elif (func == "deviceQuery"):
            print(self._dctList)
            classTest.deviceQuery(self._dctList)

        elif (func == "deleteDevice"):
            print(self._dctList)
            classTest.deviceDelete(self._dctList)

        elif (func == "deviceModify"):
            print(self._dctList)
            classTest.deviceModify(self._dctList)



def main(func = "addSubscriber", args = {'ExternalId':'45'}):
    submanTest(str(args)).sendRequest(func)

def doNothing():
    print("nothing to do")

# converting the 2nd arg to a dictionary for now
#example:
#[{"Field1":39999,"containerName":"DemoSubscriberObjectExtension"},{"hostPort":"4060","ContactPhoneNumber":None,"VatClass":None,"LastName":None,"hostName":"10.10.146.239","Language":None,"VatCertificate":None,"NotificationPreference":1,"BillingCycle":None,"Status":None,"SharedWalletQuery":None,"ExternalId":292334,"FirstName":None,"ContactEmail":None,"TimeZone":None}]

if __name__ == '__main__':
    arrDct = sys.argv[2:]
    arrDct = ''.join( sys.argv[2:])
    #newDct = {}
    #newDct = eval(userDct)
    print(arrDct)
    #print arrDct
    main(func = sys.argv[1], args=arrDct)
    #sys.exit(1)
