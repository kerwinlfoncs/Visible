#!/usr/bin/python3
import socket

import h2.connection
import h2.events
import h2.config
from optparse import OptionParser
import json, ast, pprint

# ------------------------------------------------------------------------------
# Define input
def commandInput():
        # -----------------------------------------------------------------------------
        # Program Usage and Options
        # -----------------------------------------------------------------------------
        #define the options and parameter
        parser = OptionParser(usage="usage: %prog [options] ",
                      version="%prog 0.1")

        parser.add_option("-v", "--verbose",
                      action="store",
                      dest="verbose",
                      default='normal',
                      help="Reporting verbosity")

        parser.add_option("-i", "--ip",
                      action="store",
                      dest="ip",
                      default='0.0.0.0',
                      help="http2 server IP address")

        parser.add_option("-p", "--port",
                      action="store",
                      dest="port",
                      default=8000,
                      help="http2 server port")

        # Set the subman mode of operation
        (options, args) = parser.parse_args()
        
        return options, args

def send_response(conn, event):
    stream_id = event.stream_id
    conn.send_headers(
        stream_id=stream_id,
        headers=[
            (':status', '200'),
            ('server', 'basic-h2-server/1.0')
        ],
    )
    conn.send_data(
        stream_id=stream_id,
        data=b'it works!',
        end_stream=True
    )

#===============================================================================
# Process data within a thread
def processData(threadData):
        lclSession = []

        # Split data
        (sock, conn, data) = threadData

        # Output spacing
        if options.verbose not in ['low', 'none']: print('\n\nMessage Started\n')

        connBuffer = ''

        # Get events
        events = conn.receive_data(data)

        # Process each event
        for event in events:
            if options.verbose not in ['low', 'none']: print('Event: ' + str(event))
            if isinstance(event, RequestReceived):
                (session,connBuffer) = receive_request(conn, event, connBuffer)

                # Check and store session
                if event.stream_id in idToSession:
                        # Shouldn't be here
                        print('ERROR: stream_id ' + str(event.stream_id) + ' is in idToSession when a request was received')

                # Always update with the latest ID to session data
                idToSession[event.stream_id] = session

            elif isinstance(event, DataReceived):
                # Session better be in global data
                if event.stream_id not in idToSession:
                        # Shouldn be here
                        print('ERROR: stream_id ' + str(event.stream_id) + ' is not in idToSession when a data request was received')
                        return

                # Get the session from global data
                session = idToSession[event.stream_id]

                connBuffer = receive_data(conn, event, session, connBuffer)
            elif isinstance(event, StreamEnded):
                # Session better be in global data
                if event.stream_id not in idToSession:
                        # Shouldn be here
                        print('ERROR: stream_id ' + str(event.stream_id) + ' is not in idToSession when a stream end request was received')
                        return

                # Get the session from global data
                session = idToSession[event.stream_id]

                # Remove from global data
                del idToSession[event.stream_id]

                # Process message
                lclSession.append(stream_complete(conn, event, session, connBuffer, sock))

        # Send if anything queued to send
        data_to_send = conn.data_to_send()
        if data_to_send: sock.sendall(data_to_send)

       # Get response from client.
        # *** Move back to inside stream_complete()- then can return failures if needed.  Here the SBA has already been replied to.
        # *** Was having timing issues (SBA expects a response quicker than TF was sending due to messages coming randomly (and TF commands look for a specific message).
        for session in lclSession:
                # Build dictionary (kludgy...)
                lclDCT = {}
                lclDCT['sessionId'] = session
                lclDCT['timeToWait'] = 5
                lclDCT['timeToWaitInterval'] = 0.5
                lclDCT['interface'] = 'HTTP'
                lclDCT['eventPass'] = True
                lclDCT['verbose'] = options.verbose
                msg = FIVEG.getHttpServerMessage(lclDCT, "HTTP")

                # Debug
                if options.verbose not in ['low', 'none']: print('Stream Complete.  Received response from client for session ' + session)

        # Output spacing
        if options.verbose not in ['low', 'none']: print('\nMessage Ended\n')

#===============================================================================
def handle(sock):
    headerDCT = {}
    data2 = ''
    config = h2.config.H2Configuration(client_side=False)
    conn = h2.connection.H2Connection(config=config)
    conn.initiate_connection()
    sock.sendall(conn.data_to_send())

    while True:
        data = sock.recv(65535)
        if not data: break

        events = conn.receive_data(data)
        #print('RequestsReceived: ' + str(h2.events.RequestReceived))
        for event in events:
           #print('Received event: ')
           #print(event)
           if isinstance(event, h2.events.RequestReceived):
            #print(event.headers)
            send_response(conn, event)
            for entry in event.headers:
                # Split into parts
                (name,value) = entry
                headerDCT[name] = value
           elif isinstance(event, h2.events.DataReceived):
            #data2 = json.loads(event.data)
            data2 = event.data.decode("utf-8")
           elif isinstance(event, h2.events.StreamEnded):
            if headerDCT[':path'].split('/')[-1] == 'notify':
             fileName = '/home/mtx/' + headerDCT[':path'].split('/')[-2].split('?')[0]
            else:
             fileName = '/home/mtx/' + headerDCT[':path'].split('/')[-1].split('?')[0]

            print('Headers:')
            pprint.pprint(headerDCT)
            print(fileName)
            print('Data:')
            print(data2)
            f = open(fileName, 'w')
            f.write(str(data2))
            f.close()
            
        # All events processed.  Respond.
        data_to_send = conn.data_to_send()
        if data_to_send: sock.sendall(data_to_send)

# Get inputs
(options, args) = commandInput()

sock = socket.socket()
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
sock.bind((options.ip, int(options.port)))
sock.listen(5)

while True:
    handle(sock.accept()[0])

