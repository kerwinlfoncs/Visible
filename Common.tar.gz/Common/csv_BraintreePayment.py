#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:35:21
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:35:21
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:35:21
#===============================================================================
#
# Copyright 2011 - 2017, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
from __future__ import print_function
# from builtins import str
# from builtins import str
import sys, pprint
import csv_qa as CSVQA
import csv_track as TRACK
from primitives import primGET as GET
import qa_utils as QAUTILS
import ast
try:
        import braintree
except:
        kef = 1

# Flag signalling if setup already happened
braintreeSetpFlag = False

#==========================================================
def CmdPayment(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Query subscriber
        if lclDCT['eventPass']: queryValue = lclDCT['externalId']
        else:  queryValue = None
        queryType = lclDCT['subQueryType']
        saveFunc='saveMDC'
        
        # Subscriber should exist
        if lclDCT['externalId'] not in TRACK.subscriberTracking and not lclDCT['noChecks']:
                print('ERROR: subscriber with ID "' + lclDCT['externalId'] + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # If payment ID not input then use external ID
        if not lclDCT['paymentId']: paymentId = str(lclDCT['externalId'])
        else: paymentId = lclDCT['paymentId'] # Added during Python3 migration
        
        # Do payment setup
        paymentSetup(lclDCT['merchantId'], lclDCT['publicKey'], lclDCT['privateKey'])
        
        # If deleting then do that here
        if lclDCT['ACTION'].lower() == 'paymentdelete':
                # Delete if it exists
                paymentCustomerAccountDelete(paymentId)
        
                # Return from here
                return (None, None)
        
        # Check if account needs to be created
        paymentCustomerAccountCreate(paymentId, lclDCT['ACTION'])
        
        # ** Starting in 5100 need to call subscriberAddPaymentmethod() versus doing it here via paymentAdd **
        return (None, None)
        
        # If creating then all done
        if lclDCT['ACTION'].lower() == 'paymentcreate': return (None, None)
        
        # Need OID for subsequent calls
        if lclDCT['subQueryType'] != 'ObjectId': 
                # Get object OID
                externalId = getOid(lclDCT['externalId'], lclDCT['subQueryType'], 'subscriber')
                
                # Set query type
                subQueryType = 'ObjectId'
        else: externalId = lclDCT['externalId'] # Added during Python3 migration
        
        # Do Add work
        if lclDCT['ACTION'].lower() == 'paymentadd':
                # Get the payment token
                pymToken = getPaymentToken(externalId, paymentId, lclDCT['eventPass'])
                
                # Now set the default payment
                paymentSetDefault(externalId, pymToken, lclDCT['eventPass'])
        
                return (None, None)

        # Now how did we get here...
        sys.exit('ERROR: unknown payment action: ' + lclDCT['ACTION'])
        
# *********************************************************************************************
def paymentSetup(merchantId, publicKey, privateKey):
        global braintreeSetpFlag
        
        # Need to configure once per test
        if not braintreeSetpFlag:
                # Set flag
                braintreeSetpFlag = True
                
                # Setup environment (required)
                braintree.Configuration.configure(braintree.Environment.Sandbox,
                        merchant_id=merchantId,
                        public_key=publicKey,
                        private_key=privateKey)
        
# *********************************************************     
def getOid(externalId, subQueryType, objType='subscriber'):
        # Get object data
        q = GET.getObject(externalId, hostname=QAUTILS.gatewaysConfig.get('REST', 'restServer'), hostport=QAUTILS.gatewaysConfig.get('REST', 'restPort'), queryType=subQueryType, objType=objType)
        
        # If Q is empty, then nothing to do
        if q is None: sys.exit('ERROR: ' + objType + ' ' + str(externalId) + '(' + subQueryType + ') non-existent.')
        
        # Get OID
        try:
                oid = q.find('./ObjectId').text.strip()
        except:
                sys.exit('ERROR: ' + objType + ' ' + str(externalId) + '(' + subQueryType + ') OID not set.')
        
        return oid

# *********************************************************     
def getPaymentToken(externalId, paymentId, eventPass):
        # Now build the command
        # Returned value is a string that looks like a dictionary
        url = '/rsgateway/data/pmt/subscriber/' + externalId + '/method/' + paymentId + '/fake-valid-nonce'
        retDict = GET.curlToETFormat(url, operation='PUT', output='RAW')
        #print 'getPaymentToken before: response string: ' + retDict
        
        # Null values are not returned in quotes.  Breaks ast...
        # Seems some null strings are valid.  This will be a pain.  For now exclude null_ and _null from conversion.
        if not retDict.count("null_") and not retDict.count("_null"): retDict = retDict.replace('null', '"null"')
        #print 'getPaymentToken after: response string: ' + retDict
        
        # Convert "string that looks like a dictionary" to a dictionary :-).
        retDict = ast.literal_eval(retDict)
        
        # Debug output
#       pprint.pprint(retDict)
        
        # Check return code
        if (retDict['status'] != 'OK' and eventPass) or (retDict['status'] == 'OK' and not eventPass):
                # Unexpected result
                print('ERROR: command "' + cmd + '" returned unexpected result of ' + retDict['status'])
                pprint.pprint(retDict)
                sys.exit('Exiting due to errors')
        
        # If expecting to fail then return here
        if not eventPass: return (queryType, queryValue)
        
        # Get payment token
        pymToken = retDict['result']['paymentToken']
        
        print('\n\nPayment token = ' + pymToken + '\n\n')
        
        return pymToken
        
# *********************************************************     
def paymentCustomerAccountCreate(paymentId, ACTION):
        # See if we need to create the account
        try:
                customer = braintree.Customer.find(paymentId)
                print('\n\nPayment Id ' + paymentId + ': matches customer ' + str(customer))
                
                # Extra output if create was requested
                if  ACTION.lower() == 'paymentcreate': print('Nothing created')
                print('\n\n')
        except:
                print('\n\nWill create customer with paymenti ID ' + paymentId + '\n\n')
                
                # Create the account
                result = braintree.Customer.create({
                        "id": paymentId,
                        "first_name": "Jen",
                        "last_name": "Smith",
                        "company": "Braintree",
                        "email": "jen@example.com",
                        "phone": "312.555.1234",
                        "fax": "614.555.5678",
                        "website": "www.example.com"
                        })
                # Debug output
                print(str(result))
        
# *********************************************************     
def paymentSetDefault(externalId, pymToken, eventPass):
        url = '/rsgateway/data/pmt/subscriber/'+ externalId + '/current/' + pymToken
        # Returned value is a string that looks like a dictionary
        retDict = GET.curlToETFormat(url, operation='PUT', output='RAW')
        
        # Convert "string that looks like a dictionary" to a dictionary :-).
        retDict = ast.literal_eval(retDict)
        
        # Debug output
#       pprint.pprint(retDict)
        
        # Check return code
        if (retDict['status'] != 'OK' and eventPass) or (retDict['status'] == 'OK' and not eventPass):
                # Unexpected result
                print('ERROR: command "' + cmd + '" returned unexpected result of ' + retDict['status'])
                pprint.pprint(retDict)
                sys.exit('Exiting due to errors')
        
# *********************************************************     
def paymentCustomerAccountDelete(paymentId):
        # See if we need to create the account
        try:
                # Will generate an error if not found
                customer = braintree.Customer.find(paymentId)
                
                print('\n\nPayment Id ' + paymentId + ': customer found - will be delete\n\n')
                # Delete the account
                braintree.Customer.delete(paymentId)
        except:
                print('\n\nPayment Id ' + paymentId + ': customer not found - nothing to delete\n\n')
        
