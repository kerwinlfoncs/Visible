#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:54
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:33
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:12
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


import os,sys
import optparse
import subscriber_mgmt_v3 as RESTV3

#####  need modify for remote queries #################
hostName = '127.0.0.1'
hostPort = 4060   #8080 for REST  4060: for mdc gwy
mode  = 'Normal' #as opposed to batch
trace = False
########### end of section to modify ##################


REST = False
if hostPort == 8080:
    REST = True

restInst = None
def main():
    global REST
    global hostName
    global hostPort
    global mode 
    global trace
    global restInst

    parser = optparse.OptionParser()
    parser.add_option("-s", "--subscid", action='store', type='int', default=0)
    parser.add_option("-a", "--subexternalid", action='store', type='string', default=None)
    parser.add_option("-b", "--devexternalid", action='store', type='string', default=None)
    parser.add_option("-c", "--groupexternalid", action='store', type='string', default=None)
    parser.add_option("-i", "--imsi", action='store', type='string', default=None)
    parser.add_option("-o", "--soid", action='store', type='string', default=None)
    parser.add_option("-w", "--doid", action='store', type='string', default=None)
    parser.add_option("-g", "--groupid", action='store', type='string', default=None)
    parser.add_option("-v", "--groupoid", action='store', type='string', default=None)
    parser.add_option("-l", "--level", action='store', type='int', default=1)
    parser.add_option("-t", "--time", action='store', type='string', default='None')
    parser.add_option("-m", "--mdcgw", default="1", help="query by mdc gw")
    parser.add_option("-r", "--restgw", default="MDC", help="query by REST")
    (options, args) = parser.parse_args()

    # Get client to perform query
    v3Inst = None

    if options.restgw == 'MDC':
        RESTV3.mtxflags = 1
        version = 'MDC'
        restInst = RESTV3.SubscriberManagementV3Client(trace, hostName, hostPort, mode)
        restInst.openConnection()

    elif options.restgw == 'REST':
        REST = True
        version = "REST"
        resInst = restV3.RestClient(hostName, hostPort)
    else:
        print('unsupported Subscriber Interface Used: JAVA!!!')

    if options.time == 'None':
        options.time = None

    if options.imsi:
        getDeviceData(options.imsi, 'Imsi', options.level, options.time, options.restgw)
    elif options.doid:
        getDeviceData(options.doid, 'ObjectId', options.level, options.time, options.restgw)
    elif options.devexternalid:
        getDeviceData(options.devexternalid, 'ExternalId', options.level, options.time, options.restgw)

    elif options.soid:
        getSubscriberData(options.soid, 'ObjectId', options.level, options.time, options.restgw)
    elif options.subscid:
        getSubscriberData(options.subscid, 'PhoneNumber', options.level, options.time, options.restgw)
    elif options.subexternalid:
        getSubscriberData(options.subexternalid, 'ExternalId', options.level, options.time, options.restgw)
    elif options.groupid:
        getGroupData(options.groupid, 'ExternalId', options.level, options.time, options.restgw)
    elif options.groupexternalid:
        getGroupData(options.groupoid, 'ExternalId', options.level, options.time, options.restgw)
    elif options.groupoid:
        getGroupData(options.groupexternalid, 'ObjectId', options.level, options.time, options.restgw)
    else:
        print('done!!!!!!!!!!!')
		 
def getGroupData(queryValue, queryType, level, time, rest=None):
        print(restInst.groupQuery(queryType, queryValue, now=time))
        print(restInst.groupQueryWallet(queryType, queryValue, now=time))

def getSubscriberData(queryValue, queryType, level, time, rest=None):
        print(restInst.subscriberQuery(queryValue=queryValue, queryType=queryType, now=time))
        print(restInst.subscriberQueryWallet(queryValue=queryValue, queryType=queryType, now=time))

def getDeviceData(queryValue, queryType, level, time, rest=None):
        deviceMdc = restInst.deviceQuery(queryValue=queryValue, queryType=queryType, now=time)
	print(deviceMdc)

if __name__ == '__main__':
   main()
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

