#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:35:33
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:35:33
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:35:32
#===============================================================================
#
# Copyright 2011 - 2018 Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
from __future__ import print_function
# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
import copy, os, sys, pprint
import diameter_utils
import create_diameter_pkt_base
import csv_track as TRACK
import custSpecific as CUST
import csv_data as DATA
import csv_prim as PRIM
from lxml import etree
import xml.etree.ElementTree as ET

# Define globals
lastSnrDct = {}
lastPnrDct = {}

# =========================================================================================
# ===========================  Diameter Sh commands ==== ==================================
# =========================================================================================

#==========================================================
def retrieveAndValidateShUserData(diamDct, lclDCT, printFlag = False):
        #pprint.pprint(diamDct)
        
        # See if the policy value was input
        pcidString = 'Sh-User-Data'
        try: userData = diamDct[pcidString].decode("hex")
        except: userData = ''
        
        # Comment out until needed (ET gives nice XML parsing capabilities)
        # See if we can translate the XML to a nicer format
        try:
                # Convert to element
#               x = ET.fromstring(userData)
                
                # If printing and anything to print, then output
                if printFlag and len(userData):
                        print('Sh User Data: ')
                        root = etree.fromstring(userData)
                        print(etree.tostring(root, pretty_print=True))
#                       ET.dump(x)
        except:
                # If printing and anything to print, then output
                if printFlag and len(userData): print('Sh User Data: ' + userData)
        
        return userData

#==========================================================
def validateShMessage(diamDct, field, lclDCT):
        # *** For now ***
        return True
        
#       print 'Validating Sh message.  Field = ' + field
        foundCount = 0
        
        # Get policy info to validate
        policyIdentifier = lclDCT['policyIdentifier']
        policyStatus = lclDCT['policyStatus']
        
        # Check if we should evaluate policy
        evaluatePolicy = PRIM.policyValidationInputChecks(lclDCT)
        
        # Evaluate if we should
        if evaluatePolicy:
                # Walk the list of returned policy.  These are not in an array; they're individual fields.  Max at 50 for now.
                for i in range(50):
                        # Build dictionary key
                        nameKey = 'Pcsr' + str(i) + '->Policy-Counter-Identifier'
                        
                        # If key not present, then break out (as keys will be sequential)
                        if nameKey not in diamDct: break
                        
                        # If here, then we found the key.  Get the name
                        policyName = diamDct[nameKey]
                        
                        # Get the value
                        valueKey = 'Pcsr' + str(i) + '->Policy-Counter-Status'
                        policyValue = diamDct[valueKey]
                        
                        # Compare this against the input data.  First need to make sure we have this name in the validation item
                        try:
                                index = policyIdentifier.index(policyName)
                        except:
                                print('ERROR:  policy "' + policyName + '" not in command line policy Identifiers (' + str(policyIdentifier) + ')')
                                return False
                        
                        # Cover input errors, where the length of the status != length of the identifers
                        if len(policyStatus) <= index:
                                print('ERROR:  length of command line policyStatus is ' + str(len(policyStatus)) + ' while the length of the policyIdentifier is ' + str(len(policyIdentifier)))
                                return False
                        
                        # See if the values match
                        if policyStatus[index] != policyValue:
                                print('ERROR:  policy "' + policyName + '" command line value "' + str(policyStatus[index]) + '" doesn\'t match returned value of "' + str(policyValue) + '"')
                                return False
                        
                        # Increment found count
                        print('Validated Sy policy ' + policyName + '= ' + policyValue)
                        foundCount += 1
                
                # If here, then everything matched.  Want to make sure everything that was expected was returned
                if foundCount != len(policyIdentifier):
                        print('ERROR: ' + str(len(policyIdentifier)) + ' policy status expected, but only ' + str(foundCount) + ' returned.')
                        print('Command line policy identifiers: ' + str(policyIdentifier))
                        print('Returned Dictionary: ' + str(diamDct))
                        return False
                
        # If here, then all went well
        return True
        
#==========================================================
def CmdDiam_diameterreceivepushnotificationrequest(lclDCT, options, diamConnection):
        global lastPnrDct
        
        eventPass = lclDCT['eventPass']
        
        # Always Sh for this command
        diamConnection = TRACK.diamConnectionSh

        # Get message ID.  May be customized or default
        try:    msgId = CUST.diameterMessageIds['PNR'][1]
        except: msgId = DATA.DiameterMessageIds['ShPNR'] 

        # Receive message
        (diamDct, diamResp) = diameter_utils.receiveDiameterPacket(diamConnection=diamConnection, msgId = msgId, timeout=lclDCT['timeToWait'])
        
        # Check response
        if (not diamResp and eventPass) or (diamResp and not eventPass):
                if eventPass: sys.exit('CmdDiam_diameterreceivespendnotificationrequest() received a unexpected failure from diameter_utils.receiveDiameterPacket()')
                else:         sys.exit('CmdDiam_diameterreceivespendnotificationrequest() received a unexpected success from diameter_utils.receiveDiameterPacket()')
        
        # Nothing to query in this scenario
        queryType = queryValue = None
        
        # If failure expected, then return here
        if not eventPass: return (queryType, queryValue)
        
        # Debug output
        #print 'Received PNR.  Packet contents: ' + pprint.pprint(diamDct)
        
        # Validate response if input specified.
        for param in DATA.parameterShValidate:
                cmd = 'if ' + param + ': _a = validateShMessage(diamDct, param, lclDCT) \n'
                cmd += 'else: _a = True'
                exec(cmd)
                retVal = locals()['_a']
                
                # Check response
                if not retVal: sys.exit('Failed Sh validation.  Exiting')
        
        # Output policy data
        policyData = retrieveAndValidateShUserData(diamDct, lclDCT, printFlag=True)
        
        # Reply if we're supposed to
        if not lclDCT['noReply']:
                print('Sending PNA')

                # Turn around a PNA
                create_diameter_pkt_base.sendPushNotificationAnswer(diamConnection, diamDct, eventPass=eventPass)

        else:
                # Save last message (so answer can use it if response is delayed)
                 lastPnrDct = copy.deepcopy(diamDct)

        return (queryType, queryValue)
        
#==========================================================
def CmdDiam_diametersendspendnotificationanswer(lclDCT, options, diamConnection):
        global lastSnrDct
        
        eventPass = lclDCT['eventPass']
        
        # Always Sy for this command
        diamConnection = TRACK.diamConnectionSy

        # Send SNR.  Use last saved SNR dictionary (command needs data from previous SNR command)
        create_diameter_pkt_base.sendSpendNotificationAnswer(diamConnection, lastSnrDct, eventPass=eventPass)
        
        # Clear global
        lastSnrDct = {}
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)

