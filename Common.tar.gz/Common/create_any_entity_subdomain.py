#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:55
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:35
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:13
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


# from builtins import str
# from builtins import str
import os,sys,re,ast
import optparse
import pretty_print as PRINT
import qa_utils as QAUTILS
import QA_subscriber_management_restv3 as RESTV3
import timeToMDCtime as MDCTIME
import subscriber_mgmt_v3 as SUBMAN

restInst = None
routeToSubdomain = 7

def main():
    global restInst

    parser = optparse.OptionParser()
    parser.add_option("-s", "--subscid", action='store', type='int', default=0, help="creates both subscriber and device, and add the device to the newly created subscriber")
    parser.add_option("-x", "--externalid", action='store', type='string', default=None, help="creates subscriber only")
    parser.add_option("-i", "--imsi", action='store', type='string', default=None)
    parser.add_option("-n", "--containerName", action='store', type='string', default=None)
    parser.add_option("-f", "--fieldDct", action='store', type='string', default=None,help="ex. \"{'manufacturer':'test','imsi':'789'}\"")
    parser.add_option("-d", "--deviceType", action='store', type='string', default=None)
    parser.add_option("-a", "--daccess", action='store', type='string', default=None)
    parser.add_option("-b", "--dexternal", action='store', type='string', default=None)
    parser.add_option("-g", "--groupid", action='store', type='int', default=0)
    parser.add_option("-l", "--level", action='store', type='int', default=1)
    parser.add_option("-t", "--time", action='store', type='string', default=None)
    parser.add_option("-m", "--mdcgw", default="1", help="query by mdc gw")
    parser.add_option("-r", "--restgw", default="", help="query by REST")
    parser.add_option("-y", "--status", default=None, type='string', help="entity status")
    parser.add_option("-v", "--values", default=None, type='string',help="comma separated name=value pairs")
    parser.add_option("--ol", dest="offerList",action='store', type='string', default=None)
    parser.add_option("--os", dest="offerStartTime",action='store', type='string', default=None)
    parser.add_option("--oe", dest="offerEndTime",action='store', type='string', default=None)
    (options, args) = parser.parse_args()

    # Get client to perform query
    gatewaysConfig = QAUTILS.getDiameterRestConfig()
    if options.restgw:
        RESTV3.setVersion('REST')
    else:
        RESTV3.setVersion('MDC')
        RESTV3.mtxflags = 1
    QAUTILS.gatewaysConfig = gatewaysConfig
    restInst = QAUTILS.getSubscInterface()

    if options.time is not None :
        time = MDCTIME.getTime(time)
    else :
        time = None

    attrMdc = None
    if options.containerName:
        if options.fieldDct == None :
           attr=createAttr(options.containerName,options.fieldDct)
        else :
           print(options.fieldDct)
           attr=createAttr(options.containerName,eval(options.fieldDct))

    if options.imsi:
	pass
        #createDevice(options.imsi, options.dexternal,options.deviceType,options.daccess, options.status, time, options.restgw)
    elif options.externalid :  #create subsc without device
        createSubscriber(options.externalid, options.subscid, False, options.values,  attrMdc, options.offerList, 
                  options.offerStartTime, options.offerEndTime, options.status, time, routeToSubdomain, options.restgw)
    elif options.subscid :   #create subsc with device
        createSubscriber(options.externalid, options.subscid, True, options.values,  attrMdc, options.offerList, 
                  options.offerStartTime, options.offerEndTime, options.status, time, routeToSubdomain, options.restgw)
    elif options.groupid:
        createGroup(options.groupid, options.values, options.level, attrMdc, options.offerList, 
                  options.offerStartTime, options.offerEndTime, time, options.restgw)
    else:
        print('no entity to be created, need imsi for device,  external id for subscriber, groupid for group')

def createAttr(containerName,fieldDct):
        attrMdc= RESTV3.createAttr(containerName,fieldDct)		 
        print(attrMdc)

def createGroup(groupid, values,  level, attrMdc, offerList, offerStartTime, offerEndTime, time, rest=None):
    gName = "MTX-GRP-" + str(groupid)
    tier = None
    administrator_id=0
    notificationPreference=None
    timeZone=None
    billingCycle=None
    attr=None
    billCycleMdc=None

    if values is not None:
        uParames = values.split(',')
        if len(uParames) < 1:
            print("missing values.")
            print("the new values should be a string with name=value pairs separated by ','")
            return -1
        else :
            for pair in uParames :
                name=pair.split('=')[0]
                val=pair.split('=')[1]
                if name.lower() == 'name' :
                    gName = val
                if name.lower() == 'tier' :
                    tier = val
                elif name.lower() == 'timezone' :
                    timeZone = val
                if name.lower() == 'administrator_id' :
                    administrator_id = val
                elif name.lower() == 'billingcycle' :
                    vals = val.split('/')
                    if len(vals) > 1 :
                        tId = vals[0]
                        offset = vals[1]
                    else :
                        tId = vals[0]
                        offset = None
                    # create billCycle MDC
                    billCycleMdc = SUBMAN.newBillingCycleData(tId, offset)

    groupMdc = RESTV3.createGroup(restInst,groupid, name=gName, tier=tier, administrator_id=administrator_id, 
                               attr=attrMdc,  now=time, billingCycle=billCycleMdc, timeZone=timeZone)

    if offerList is not None :
        offerId = offerList.split(',')
        result = RESTV3.groupSubscribeToOffer(restInst, groupid, offerId, offerStartTime=offerStartTime, offerEndTime=offerEndTime, now=time)

    print(groupMdc)

def createSubscriber(externalid, subscid, createDevice, values,  attrMdc,  offerList, offerStartTime, offerEndTime, status, time, subdomainID, rest=None):

    firstName = None
    lastName = None
    contactEmail=None
    contactPhoneNumber=None
    notificationPreference=None
    timeZone=None
    billingCycle=None
    attr=None
    language=None
    billCycleMdc=None

    if values is not None:
        uParames = values.split(',')
        if len(uParames) < 1:
            print("missing new values.")
            print("the new values should be a string with name=value pairs separated by ','")
            return -1
        else :
            for pair in uParames :
                name=pair.split('=')[0]
                val=pair.split('=')[1]
                if name.lower() == 'firstname' :
                    firstName = val
                if name.lower() == 'lastname' :
                    lastName = val
                elif name.lower() == 'timezone' :
                    timeZone = val
                if name.lower() == 'contactemail' :
                    contactEmail = val
                if name.lower() == 'contactphonenumber' :
                    contactPhoneNumber = val
                elif name.lower() == 'billingcycle' :
                    vals = val.split('/')
                    if len(vals) > 1 :
                        tId = vals[0]
                        offset = vals[1]
                    else :
                        tId = vals[0]
                        offset = None
                    # create billCycle MDC
                    billCycleMdc = SUBMAN.newBillingCycleData(tId, offset)
                elif name.lower() == 'language' :
                    language = val

    if offerList is not None:
        offerId = offerList.split(',')
    else :
        offerId = 0

    if createDevice :
        deviceId = subscid
    else :
        deviceId = None

    if externalid is None :
        externalid = subscid

    subscMdc = RESTV3.addSubscriber(restInst,externalId=externalid, deviceId = deviceId, offerId = offerId, 
                                    offerStartTime = offerStartTime, offerEndTime = offerEndTime, subStatus=status,
                                    subAttr=attrMdc, now=time, firstName=firstName, lastName=lastName, contactEmail=contactEmail,
                                    contactPhoneNumber=contactPhoneNumber, timeZone=timeZone, 
                                    billingCycle=billCycleMdc, language=language, routingType="RTID", routingValue=subdomainID)
    
    print(subscMdc)
     
def createDevice(deviceId, ExternalId, deviceType, AccessNumber, status, time,  rest=None):
    deviceMdc = RESTV3.createDevice(restInst, deviceId, externalId = ExternalId, deviceType=deviceType,  accessNumbers=AccessNumber, subStatus=status,  now=time)
    print(deviceMdc)

if __name__ == '__main__':
   main()
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

