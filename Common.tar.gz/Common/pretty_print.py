#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:41:26
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:43
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:24
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


# from builtins import str
# from builtins import str
import data_container as MDC
import data_container_defs as MDCDEFS
from xml.etree import ElementTree

restClient = None
level = None
AdminGroupIdArray = None
ParentGroupIdArray = None
DeviceIdArray = None
PurchasedOfferArray = None
SubscriberMemberIdArray = None
GroupMemberIdArray = None
AdminIdArray = None

# Fetch subscriber/group/device arrays into global variables for later outputting
def setupArrays(arrays):
    global AdminGroupIdArray
    global ParentGroupIdArray
    global DeviceIdArray
    global PurchasedOfferArray
    global SubscriberMemberIdArray
    global GroupMemberIdArray
    global AdminIdArray

    AdminGroupIdArray = []
    ParentGroupIdArray = []
    DeviceIdArray = []
    PurchasedOfferArray = []
    SubscriberMemberIdArray = []
    GroupMemberIdArray = []
    AdminIdArray = []

    for array in arrays:
        if array.attrib['name'] == 'AdminGroupIdArray':
            for oid in array.findall('value'):
                AdminGroupIdArray.append(oid.text)
        elif array.attrib['name'] == 'ParentGroupIdArray':
            for oid in array.findall('value'):
                ParentGroupIdArray.append(oid.text)
        elif array.attrib['name'] == 'DeviceIdArray':
            for oid in array.findall('value'):
                DeviceIdArray.append(oid.text)
        elif array.attrib['name'] == 'PurchasedOfferArray':
            for oid in array.findall('value'):
                PurchasedOfferArray.append(oid.text)
        elif array.attrib['name'] == 'SubscriberMemberIdArray':
            for oid in array.findall('value'):
                SubscriberMemberIdArray.append(oid.text)
        elif array.attrib['name'] == 'GroupMemberIdArray':
            for oid in array.findall('value'):
                GroupMemberIdArray.append(oid.text)
        if array.attrib['name'] == 'AdminIdArray':
            for oid in array.findall('value'):
                AdminIdArray.append(oid.text)

# Print subscriber output data
def printSubscriberContactData(fields):
    contactFields = ['FirstName', 'LastName', 'ContactEmail', 'ContactPhoneNumber', 'Status', 'NotificationPreference',\
        'TimeZone']
    printFields(fields, contactFields, 'Contact Details: ')

# Print an individual field
def printField(fields, fieldName):
    value = 'None'
    for field in fields:
        if field.attrib['name'] == fieldName:
            value = field.attrib['value']

    if value != 'None' and value != '':
        print(fieldName + ': ' + value)

# Print a list of fields
def printFields(fields, fieldList, initStr = ''):
    outputStr = initStr
    for field in fieldList:
        for field2 in fields:
            if field2.attrib['name'] == field:
                fieldValue = field2.attrib['value']
                if fieldValue != 'None' and fieldValue != '':
                    outputStr += field + ' ' + fieldValue + ' '

    print(outputStr)

# Fetch the value of the field for outputting
def getField(fields, fieldName):
    for field in fields:
        if field.attrib['name'] == fieldName:
            return field.attrib['value']

    return None

# Print subscriber object and associated devices at relevant debug level
def printSubscriber(restInst, subscriberMdc, debugLevel):
    global AdminGroupIdArray
    global ParentGroupIdArray
    global level
    global restClient

    level = debugLevel
    restClient = restInst

    try:
        tree = ElementTree.XML(subscriberMdc.printXml())
    except Exception as inst:
        print("Unexpected error reading subscriber: %s" % (inst))
        return None

    subscriberFields = tree.findall('field')
    subscriberArrays = tree.findall('array')
    setupArrays(subscriberArrays)

    externalId = getField(subscriberFields, 'ExternalId')
    externalIdStr = str(externalId)
    if externalIdStr == 'None':
        externalIdStr = ''
    print('\nData for Subscriber ' + externalIdStr + '\n')

    printParentGroupIdArray()

    printAdminGroupIdArray()

    printOffers(subscriberArrays)

    printDevices()

    if level > 2:
        printSubscriberContactData(subscriberFields)

# Print group object at relevant debug level
def printGroup(restInst, groupMdc, debugLevel):
    global level
    global restClient

    level = debugLevel
    restClient = restInst

    try:
        tree = ElementTree.XML(groupMdc.printXml())
    except Exception as inst:
        print("Unexpected error reading subscriber: %s" % (inst))
        return None

    groupFields = tree.findall('field')

    externalId = getField(groupFields, 'ExternalId')
    basicStr = '\nData for Group ' + str(externalId) + ': '

    if level > 1:
        basicStr += getFieldStr(groupFields, 'Name')
    if level > 2:
        basicStr += getFieldStr(groupFields, 'Tier')

    basicStr += getFieldStr(groupFields, 'SubscriberCount')
    print(basicStr)

    groupArrays = tree.findall('array')
    setupArrays(groupArrays)

    printAdminIdArray()

    parentGroupOid = getField(groupFields, 'ParentGroupId')
    if parentGroupOid:
        externalId = fetchGroupExternalIdByOid(parentGroupOid)
        print('ParentGroupId: ' + str(externalId))

    printSubscriberMemberIdArray()

    printGroupMemberIdArray()

    printOffers(groupArrays)

# Print subscriber or group wallet
def printWallet(restInst, walletMdc, debugLevel):
    global level
    global restClient

    level = debugLevel
    restClient = restInst

    try:
        tree = ElementTree.XML(walletMdc.printXml())
    except Exception as inst:
        print("Unexpected error reading query response: %s" % (inst))
        pass

    arrays = tree.findall('array')
    if arrays is None:
        return

    balanceArray = None
    for array in arrays:
        if array.attrib['name'] == 'BalanceArray':
            balanceArray = array

    # No balances found
    if balanceArray is None:
        return

    printBalances(balanceArray)

# Find a subscriber's externalId if given an OID
def fetchSubscriberExternalIdByOid(oid):
    global restClient

    try:
        subQuery = restClient.subscriberQuery(queryValue=oid, queryType='ObjectId')
        externalId = subQuery.getUsingKey(MDCDEFS.kMtxResponseSubscriberExternalIdFldKey)
    except:
        externalId = 'None'

    return externalId

# Find a group's externalId if given an OID
def fetchGroupExternalIdByOid(oid):
    global restClient

    try:
        groupQuery = restClient.groupQuery(queryValue=oid, queryType='ObjectId')
        externalId = groupQuery.getUsingKey(MDCDEFS.kMtxResponseGroupExternalIdFldKey)
    except:
        externalId = 'None'

    return externalId

# Print subscriber member array
def printSubscriberMemberIdArray():
    global SubscriberMemberIdArray

    if SubscriberMemberIdArray == []:
        return

    print('Subscriber Member(s): ' + getSubs(SubscriberMemberIdArray))

# Print externalIds for array of subscribers
def getSubs(array):
    subStr = ''
    for sub in array:
        externalId = fetchSubscriberExternalIdByOid(sub)
        subStr += str(externalId) + ' '
    return subStr

# Print externalIds for array of groups
def getGroups(array):
    groupStr = ''
    for group in array:
        externalId = fetchGroupExternalIdByOid(group)
        groupStr += str(externalId) + ' '
    return groupStr

# Print admin groups
def printAdminGroupIdArray():
    global AdminGroupIdArray

    if AdminGroupIdArray == []:
        return

    print('Admin Group(s): ' + getGroups(AdminGroupIdArray))

# Print admin subs
def printAdminIdArray():
    global AdminIdArray

    if AdminIdArray == []:
        return

    print('Admin(s): ' + getGroups(AdminIdArray))

# Print parent groups
def printParentGroupIdArray():
    global ParentGroupIdArray

    if ParentGroupIdArray == []:
        return

    print('Parent Group(s): ' + getGroups(ParentGroupIdArray))

# Print group members
def printGroupMemberIdArray():
    global GroupMemberIdArray

    if GroupMemberIdArray == []:
        return

    print('Group Member(s): ' + getGroups(GroupMemberIdArray))

# Fetch PhoneNumber from device query response
def getDevicePhoneNumber(deviceMdc):
    try:
        deviceAttr = deviceMdc.getUsingKey(MDCDEFS.kMtxResponseDeviceAttrFldKey)
        phoneNumber = str(deviceAttr.getUsingKey(MDCDEFS.kMtxMobileDeviceExtensionImsiFldKey))
    except:
        phoneNumber = 'No PhoneNumber'

    return phoneNumber

# Fetch the externalId of the subscriber associated with the device
def getDeviceSubscriberExternalIdStr(deviceFields):
    subscriberOid = getField(deviceFields, 'SubscriberId')
    if subscriberOid:
        try:
            subQuery = restClient.subscriberQuery(queryValue=subscriberOid, queryType='ObjectId')
            externalId = subQuery.getUsingKey(MDCDEFS.kMtxResponseSubscriberExternalIdFldKey)
        except:
            return 'No SubscriberExternalId '
        return 'SubscriberExternalId ' + str(externalId) + ' '
    else:
        return 'No SubscriberExternalId '

# Print devices
def printDevices():
    global DeviceIdArray

    if DeviceIdArray == []:
        return

    print('')
    for device in DeviceIdArray:
        printDevice(device)

# Return a string of field names/values
def getFieldStr(fields, fieldName):
    field = getField(fields, fieldName)
    fieldStr = str(field)
    if fieldStr == 'None' or fieldStr == '':
        fieldStr = ''
    if fieldStr == '':
        return ''
    else:
        return fieldName + ' ' + fieldStr + ' '

# Print an individual device
def printDevice(device):
    global restClient
    global level

    deviceStr = ''
    deviceQuery = restClient.deviceQuery(queryValue=device, queryType='ObjectId')

    try:
        tree = ElementTree.XML(deviceQuery.printXml())
    except Exception as inst:
        print("Unexpected error reading device: %s" % (inst))
        return None

    deviceFields = tree.findall('field')
    deviceStr += 'Device ' + getDevicePhoneNumber(deviceQuery) + ': ' + getFieldStr(deviceFields, 'ExternalId') + \
        getDeviceSubscriberExternalIdStr(deviceFields) + getFieldStr(deviceFields, 'DeviceType')

    if level > 2:
        deviceStr += getStatusStr(deviceFields)

    print(deviceStr)

    deviceArrays = tree.findall('array')
    printOffers(deviceArrays)

# Fetch status in readable format
def getStatusStr(fields):
    status = getField(deviceFields, 'Status')
    if status is None:
        return 'No Status '
    else:
        status = int(status)
        if status == 1:
            statusStr = 'Activated'
        elif status == 2:
            statusStr = 'Deactivated'
        elif status == 3:
            statusStr = 'Suspended'
        elif status == 4:
            statusStr = 'Closed'
        elif status == 5:
            statusStr = 'Unknown'

        return 'Status ' + statusStr + ' '

# Print associated offers
def printOffers(arrays):
    offerArray = None
    for array in arrays:
        if array.attrib['name'] == 'PurchasedOfferArray':
            offerArray = array

    if offerArray is None:
        return

    for offer in offerArray:
        printOffer(offer)        

# Print individual offer
def printOffer(offer):
    offerFields = offer.findall('field')
    offerStr = 'Offer ' + getField(offerFields, 'ProductOfferId') + ': ' + \
        getFieldStr(offerFields, 'ResourceId') + getFieldStr(offerFields, 'StartTime') +\
            getFieldStr(offerFields, 'EndTime') + getFieldStr(offerFields, 'PurchaseTime')

    print(offerStr)

# Print associated balances
def printBalances(balanceArray):
    print('')
    for balance in balanceArray.findall('struct'):
        printBalance(balance)

# Print individual balance
def printBalance(balance):
    global level

    periodic = False
    balanceStr = ''

    if balance.attrib['name'] == 'MtxBalanceInfoPeriodic':
        periodic = True

    if periodic:
        balanceStr += 'Processing periodic balance '
    else:
        balanceStr += 'Processing simple balance '

    basicBalanceInfo = balance.find('container')
    balanceFields = basicBalanceInfo.findall('field')

    balanceStr += getFieldStr(balanceFields, 'Name')
    balanceStr += getFieldStr(balanceFields, 'ResourceId')
    balanceStr += getFieldStr(balanceFields, 'ClassId')

    if level > 2:
        balanceStr += getFieldStr(balanceFields, 'ClassName')
        balanceStr += getFieldStr(balanceFields, 'TemplateId')

        # Fix these up to print text strings rather than int values!
        balanceStr += getFieldStr(balanceFields, 'Category')
        balanceStr += getFieldStr(balanceFields, 'IsPrepaid')
        balanceStr += getFieldStr(balanceFields, 'IsPeriodic')
        balanceStr += getFieldStr(balanceFields, 'IsAggregate')
        balanceStr += getFieldStr(balanceFields, 'IsVirtual')

    balanceArrays = balance.findall('array')
    balancePeriodArray = None
    balanceThresholdArray = None
    for element in balanceArrays:
        if element.attrib['name'] == 'BalancePeriodArray':
            balancePeriodArray = element
        if element.attrib['name'] == 'ThresholdArray':
            balanceThresholdArray = element

    if periodic:
        balanceStr += '\n' + getPeriodsStr(balancePeriodArray)
    else:
        balanceStr += '\n'

    balanceStr += 'Basic balance info:\n'
    balanceStr += getFieldStr(balanceFields, 'StartTime') + '\n'
    balanceStr += getFieldStr(balanceFields, 'EndTime') + '\n'
    balanceStr += getFieldStr(balanceFields, 'Amount') + '\n'
    balanceStr += getFieldStr(balanceFields, 'CreditLimit') + '\n'
    balanceStr += getFieldStr(balanceFields, 'ReservedAmount') + '\n'
    balanceStr += getFieldStr(balanceFields, 'AvailableAmount') + '\n'

    print(balanceStr)

    printThresholds(balanceThresholdArray)

# Print balance period info
def getPeriodsStr(balancePeriodArray):
    global level

    periodStr = 'Balance periods:\n'
    periods = balancePeriodArray.findall('struct')
    for period in periods:
        fields = period.findall('field')
        periodStr += getFieldStr(fields, 'Amount') + '\n'
        periodStr += getFieldStr(fields, 'StartTime') + '\n'
        periodStr += getFieldStr(fields, 'EndTime') + '\n'

    return periodStr

# Print balance thresholds
def printThresholds(balanceThresholdArray):
    thresholds = balanceThresholdArray.findall('struct')
    for threshold in thresholds:
        printThreshold(threshold)
    print('')

# Print individual balance threshold
def printThreshold(threshold):
    fields = threshold.findall('field')
    thresholdStr = 'Threshold ID ' + getField(fields, 'ThresholdId') + ': '
    thresholdStr += getFieldStr(fields, 'Type')
    thresholdStr += getFieldStr(fields, 'Amount')
    thresholdStr += getFieldStr(fields, 'Name')
    thresholdStr += getFieldStr(fields, 'NotificationState')
    print(thresholdStr)
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

