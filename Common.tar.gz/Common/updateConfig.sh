# Update QA config if file exists
file=${QACOMMON}/config.ini
if [ -f $file ]
then
#        echo "Updating $file"

        # Only update if the data is in /etc/hosts
        string="rest"
        num=`grep $string /etc/hosts | cut -f2 -d" "`
        if [ "$num" != "" ]
        then
                # Update the config file entry
                sed -i "/[Rest]/,/restPort/s/restServer.*/restServer: ${num}/" $file
        fi

        # If diameter in /etc/hosts, then update that ebtry
        string="diameter"
        num=`grep $string /etc/hosts | cut -f2 -d" "`
        if [ "$num" != "" ]
        then
                # Update the config file entry
                sed -i "/[DIAMETER]/,/port/s/hostname.*/hostname=${num}/" $file
                sed -i "/[DATACONTAINER]/,/hostPort/s/hostName.*/hostName : ${num}/" $file
        fi
fi

# Update services if file exists
file="/opt/mtx/services/config/config_primitives.ini"
if [ -f $file ]
then
#        echo "Updating $file"

        # Get the top host name/port values
        hostname=`grep ^hostname $file | head -1`
        hostport=`grep ^hostport $file | head -1`

        # Change all instances of hostname and port
        sed -i "s/^hostname.*/hostname : $CatalogBuilderHost/g" $file
        sed -i "s/^hostport.*/hostport : $CatalogBuilderPort/g" $file

        # Restore first one
        sed -i "0,/hostname :.*/s/hostname :.*/$hostname/1" $file
        sed -i "0,/hostport :.*/s/hostport :.*/$hostport/1" $file

        # Update CB domain items
        sed -i "s/^domain.*/domain : $pricingdomain/" $file
        sed -i "s/^userName.*/userName : $CatalogUserName/" $file
        sed -i "s/^password.*/password : $CatalogPassword/" $file

fi

