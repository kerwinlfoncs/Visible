#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:28
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:10
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:34:55
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


from io import StringIO
import sys

lxmlStatus=True
try:
    from lxml import etree
except ImportError:
    lxmlStatus=False

#the list has all the parameters that will not be saved into the expect file as the change dynamically
def getExclusionString(excludeList = []):
    exclusionString = ''
    excludesList = ['StartTime', 'EndTime', 'ExternalId', 'ObjectId', 'TemplateId', 'SubscriberId','ThresholdId', 'Name', 'ParentGroupId', 'PurchaseTime','EffectiveTime', 'CurrentPeriodEndTime', 'AdminId', 'AdminIdArray', 'ClassId', 'IsAggregate', 'Imsi']
    if excludeList is not None:
        for item in excludeList:
            excludesList.append(item)

    for exclusionItems in excludesList:
        exclusionString = exclusionString + 'not(@name=\'' + exclusionItems + '\') and '
    #remove the last hanging 'and'
    exclusionString = exclusionString.rsplit(' ', 2)[0]
    #print exclusionString
    return exclusionString



#define the xslt transformation: remove some fields out from the v3 return call
def createExclusionTransformer(excludeList = [], includeValue = False):
    exclusionString = getExclusionString(excludeList)
    if lxmlStatus:
        if not includeValue:
            xslt_root = etree.XML('''\
            <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
            <xsl:output method="xml" indent="yes"/>
            <xsl:strip-space elements="*"/>
            <xsl:template match="@* | node()">
            <xsl:copy>
               <xsl:apply-templates select="@* | node()[''' + exclusionString + ''' ]"/>
            </xsl:copy>
            </xsl:template>
            <xsl:template match="value">
            </xsl:template>
            </xsl:stylesheet>''')
        else:
            xslt_root = etree.XML('''\
            <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
            <xsl:output method="xml" indent="yes"/>
            <xsl:strip-space elements="*"/>
            <xsl:template match="@* | node()">
            <xsl:copy>
               <xsl:apply-templates select="@* | node()[''' + exclusionString + ''' ]"/>
            </xsl:copy>
            </xsl:template>
            </xsl:stylesheet>''')

        transform = etree.XSLT(xslt_root)
    else:
        transform='etree package not supported in this environment'
    return transform

#get the mdc xml form and transform it using the above stylesheet
def transformDoc(xmlObject, excludeList = [], includeValue=False):
    transform = createExclusionTransformer(excludeList, includeValue)
    if lxmlStatus:
        doc = etree.parse(xmlObject)
        resultTtree = transform(doc)
    else:
        resultTtree = 'etree package not supported in this environment'
    
    return resultTtree

def main():
    createTransformer()

if __name__ == '__main__':
    main()
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

