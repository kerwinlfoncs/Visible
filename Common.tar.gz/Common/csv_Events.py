#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:36:01
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:36:01
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:36:00
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
from __future__ import print_function
# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
import sys, time, string, os, pprint, re, copy, json
import qa_utils as QAUTILS
import csvMain as CSV
import csv_track as TRACK
import csv_id as CSVID
import csv_prim as PRIM
import csv_data as DATA
import csv_CmdCombo as CMDCOMBO
import csv_CmdMisc as CMDMISC
import custSpecific as CUST
from primitives import timeToMDCtime as MDCTIME
import QA_subscriber_management_restv3 as REST_UTIL
import xml.etree.ElementTree as ET
import qa_utils as QAUTILS
from primitives import primXML as XML
from primitives import primGET as GET
from primitives import primGeneric as GENERIC
from primitives import primData as PRIMDATA

# Define event query substring start/end strings
eventSubStrings = {}
eventSubStrings['gl'] = "<GlInfoArray>,</GlInfoArray>"
eventSubStrings['balance'] = "<BalanceUpdateArray>,</BalanceUpdateArray>"
eventSubStrings['ci'] = "<AppliedCatalogItemArray>,</AppliedCatalogItemArray>"

# Define mapping of input parameter values to JSON strings
mappings = {}
# Event names
mappings['purchase']    = ['PurchaseEvent', None]
mappings['recurring']   = ['RecurringEvent', None]
mappings['data']        = ['DataEvent', None]
mappings['text']        = ['TextEvent', None]
mappings['voice']       = ['VoiceEvent', None]
mappings['status']      = ['StatusChangeEvent', None]
mappings['create']      = ['CreateEvent', None]
mappings['delete']      = ['DeleteEvent', None]
mappings['suspend']     = ['SuspendEvent', None]
mappings['secondary']   = ['SecondaryEvent', None]
mappings['balanceadjust']= ['BalanceAdjustEvent', None]
mappings['autorenew']   = ['AutoRenewEvent', None]
mappings['recharge']    = ['RechargeEvent', None]
mappings['rechargerequest']     = ['RechargeRequestEvent', None]
mappings['balancethreshold']    = ['BalanceThresholdEvent', None]
mappings['rollover']    = ['BalanceRolloverEvent', None]
mappings['topup']       = ['BalanceTopupEvent', None]
mappings['transfer']    = ['BalanceTransferEvent', None]
mappings['firstusage']  = ['FirstUsageEvent', None]
mappings['forfeit']     = ['ForfeitureEvent', None]

# Field names
mappings['bundle']      = ['AppliedBundleArray', 'array']
mappings['catalog']     = ['AppliedCatalogItemArray', 'array']
mappings['offer']       = ['AppliedOfferArray', 'array']
mappings['tax']         = ['AppliedTaxArray', 'array']
mappings['balance']     = ['BalanceUpdateArray', 'array']
mappings['charge']      = ['ChargeList', 'array']
mappings['gl']          = ['GlInfoArray', 'array']
mappings['usage']       = ['UsageQuantityList', 'array']
mappings['meter']       = ['MeterUpdateArray', 'array']

#==========================================================
def streamcompare(lclDCT, options, lclStartTime, RESTInst, queryValue, queryType, target):
        # Store event retrieved from event store query
        events = []
        
        # Limit time to wait for stream files to appear
        maxLoops = 6
        
        # Get saveData into local
        saveData = lclDCT['saveData']
        
        # Get events
        response = checkEvents(target, queryType, queryValue, lclDCT, RESTInst, lclStartTime)
        
        # Import to Python dictionary
        j = json.loads(response)
        
        # Debug output
        #print json.dumps(j, sort_keys=True, indent=4, separators=(',', ': '))
        
        # Check if anything returned
        if "EventList" not in j:
                print('WARNING: No events queried from the DB')
                return
        
        # Get event IDs
        for event in j["EventList"]: events.append((event["EventDetails"]["EventId"]))
        
        # Process each event
        for eventId in events:
                # Get desired file
                fName = eventId.replace(':','-') + '.mdc'
                fileDir = os.path.expandvars(os.getenv('streamFileDir', '/var/log/mtx/events'))
                fileToUse = fileDir + '/' + fName
                print('Retrieving file ' + fileToUse)
                
                # Create the command to copy the stream file local
                cmd = 'scp ' + os.path.expandvars(os.getenv('streamServer', 'restgw')) + ':' + fileToUse + ' . 2>/dev/null'
                
                # Loop across all files on a limited amount of time
                while maxLoops:
                        # Execute the command
                        QAUTILS.runCmd(cmd)
                        
                        # Break if local file exists
                        if os.path.exists(fName): break
                        
                        # Sleep to let file be written.  These are tied to MEF until 5100.
                        print('Sleeping until Stream files are written: ' + str(maxLoops) + ' tries remaining')
                        time.sleep(10)
                
                        # Decrement loop counter
                        maxLoops = maxLoops - 1
                
                # If we've exceeded our limit then exit
                if not maxLoops: sys.exit("ERROR: Didn't find all expected stream files in restricted time")
                
                # Process/remove file. Data end sup in a Python dictionary
                f = open(fName, 'r')
                k = json.loads(f.read())
                f.close()
                os.remove(fName)
                
                # Debug data - saveData not specified
                if not saveData: print(json.dumps(k, sort_keys=True, indent=4, separators=(',', ': ')))
                else:
                 # Make sure event type matches
                 for item in saveData:
                        # Split item based on commas
                        item = item.split(',')
                        #print 'saveData item: ' + str(item)
                        
                        # First element is always the event type
                        if item[0] not in mappings:
                                print('ERROR: function streamcompare: input event type "' + item[0] + '" not in mappings global data')
                                sys.exit('Exiting due to errors')
                        
                        # See if this matches the file we're processing.  Only look for string match, as custom names will always preface this and we don't need to match those.
                        eventString = mappings[item[0]][0]
                        if not k['$'].strip('"').count(eventString): continue
                        #print 'Event Type: ' + k['$']
                
                        # We found the event.  Process rest of the fields.
                        # Always want to walk all the saveData items as there may be multiple per event (so don;t look at return from processRemainder)
                        if len(item) > 1: processRemainder(k, item[1:], lclDCT)
                        else:             setRemainder(k, lclDCT)

def setRemainder(dctRcv, lclDCT):
        # Set each item in the dictionary that's not a list or a dictionary
        for key in dctRcv:
                # Only set if scaler
                if type(dctRcv[key]) not in [list, dict]: 
                        # Set dictionary entries for constant setting
                        # Matrixx JSON has a "$" key.  Change to "selectedItemName" in this case
                        if key == '$':  lclDCT['paramName'] = 'selectedItemName'
                        else:           lclDCT['paramName'] = key
                        lclDCT['paramValue'] = dctRcv[key]
                        
                        # Call function to set constant
                        CMDMISC.CmdMisc_setconstantvalue(lclDCT, None, None)

def processRemainder(k, item, lclDCT):
        found = False
        
        # If the item list is empty, then process each element in k
        if not len(item):
                #pprint.pprint(k)
                
                # Process entire item
                setRemainder(k, lclDCT)
                return True
                
        # Process current item
        # Split entry
        #pprint.pprint(item)
        entry = item[0].split('=')
        
        # See if entry is another list
        if entry[0] in mappings:
                # For ease of reading
                listName = mappings[entry[0]][0]
                
                # Process each list item
                for listItem in k[listName]:
                        result = processRemainder(listItem, item[1:], lclDCT)
                        
                        # Stop if we found something
                        if result: break
        
        elif len(entry) > 1:
                # If here then looking for a specific field and value
                if k[entry[0]] == entry[1].strip('"'):
                        # We found an entry
                        found = True
                        
                        # If an additional parameter then only want that, else set all of them
                        data = {}
                        if len(item) > 1: 
                                data[item[1]] = k[item[1]]
                        else:   data = copy.deepcopy(k)
                        setRemainder(data, lclDCT)
        # Just get the one field
        elif entry[0] in k:
                found = True
                data = {}
                data[entry[0]] = k[entry[0]]
                setRemainder(data, lclDCT)
        
        return found
        
#==========================================================
def checkmeffiles(lclDCT):
        timeToSleep = 60
        print('mefProcessingData parameter processing.  Need to sleep ' + str(timeToSleep) + ' so current command MEF data is written.')
        time.sleep(timeToSleep)
        print('Completed waiting for current command MEF files to drain')
        print('Checking MEF files')
        
        # Get MEF files created as part of this test
        filesToProcess = PRIM.findMefFilesToProcess()

        # Debug output
        if len(filesToProcess) == 0:
                print('No additional MEF files found from base time ')
        else:
                print('Additional MEF files to process: ')
                pprint.pprint(filesToProcess)

        # Start processing files
        for fileName in filesToProcess:
                # print file name
                print('Looking in file: ' + fileName)

#==========================================================
def checkEvents(target, queryType, queryValue, lclDCT, RESTInst, inputStartTime, testName=None, lclDecode=True, substring=None):
        # *** lclnnDCT[] has all the values.
        
        # See if this is notification processing or event processing
        if not lclDCT['eventProcessing']: eventProcessing = 'event'
        else: eventProcessing = lclDCT['eventProcessing'] # Added during Python3 migration
        if eventProcessing.lower().startswith('noti'):
                # Notification processing
                notification = True
                notificationTypes = lclDCT['notificationTypeStringArray']
                eventTypes = None
        else:
                # Event processing
                notification = False
                notificationTypes = None
                eventTypes = lclDCT['eventTypeStringArray']
        
        # Minor Hack: if the action was a diameter event then we really want the subscriber event query,
        #             as there is no device event store query.
#       print 'target = ' + target + ', action = ' + lclDCT['ACTION']
        if target.lower() == 'device' and (lclDCT['ACTION'].lower().count('diameter') or lclDCT['ACTION'].lower().count('ccf')):
                queryValue = lclDCT['externalId']
                queryType = lclDCT['subQueryType']
                target = 'Subscriber'
        
        # Query events
        # ** Changed eventTimeLowerBound=inputStartTime in calls below
        if   target.lower() == 'device':
                response = REST_UTIL.querySubscriberEventstore(RESTInst,
                        deviceQueryValue=lclDCT['deviceId'],
                        deviceQueryType='PhoneNumber',
                        resultSize=lclDCT['querySize'],
                        eventTimeLowerBound=lclDCT['eventTimeLowerBound'],
                        eventTimeUpperBound=lclDCT['eventTimeUpperBound'],
                        eventTypes=eventTypes,
                        notification=notification,
                        notificationTypes=notificationTypes,
                        now=inputStartTime,
                        eventPass=lclDCT['eventPass'],
                        searchInMemoryDatabase=lclDCT['searchInMemoryDatabase'],
                        applyDefaultFilter=lclDCT['applyDefaultFilter'],
                        )
        elif target.lower() == 'subscriber':
                response = REST_UTIL.querySubscriberEventstore(RESTInst,
                        queryValue=queryValue,
                        queryType=queryType,
                        resultSize=lclDCT['querySize'],
                        eventTimeLowerBound=lclDCT['eventTimeLowerBound'],
                        eventTimeUpperBound=lclDCT['eventTimeUpperBound'],
                        eventTypes=eventTypes,
                        notification=notification,
                        notificationTypes=notificationTypes,
                        now=inputStartTime,
                        eventPass=lclDCT['eventPass'],
                        searchInMemoryDatabase=lclDCT['searchInMemoryDatabase'],
                        applyDefaultFilter=lclDCT['applyDefaultFilter'],
                        )
        elif target.lower() == 'group':
                response = REST_UTIL.queryGroupEventstore(RESTInst,
                        queryValue,
                        queryType=queryType,
                        resultSize=lclDCT['querySize'],
                        eventTimeLowerBound=lclDCT['eventTimeLowerBound'],
                        eventTimeUpperBound=lclDCT['eventTimeUpperBound'],
                        eventTypes=eventTypes,
                        notification=notification,
                        notificationTypes=notificationTypes,
                        now=inputStartTime,
                        eventPass=lclDCT['eventPass'],
                        searchInMemoryDatabase=lclDCT['searchInMemoryDatabase'],
                        applyDefaultFilter=lclDCT['applyDefaultFilter'],
                        )
        else:
                print('WARNING: invalid target value received: ' + str(target) + '.  Skipping event processing')
                return
        
        # If we expected to fail then exit
        if not lclDCT['eventPass']: return
        
        # If we're checking streaming data, then return the response
        if lclDCT['ACTION'].startswith('streamCompare'): return response
        
        # See if decode desired
        if lclDecode:
         # Can only decode REST.  EventStore doesn't support MDC, so it converts this to REST.
         if REST_UTIL.restVersion != 'REST':
                print('WARNING: Can only decode REST events')
                eventProcessing = REST_UTIL.restVersion
         else:
                # See if user specified if they want raw, summary, or both
                eventProcessing = eventProcessing.split(',')
                if len(eventProcessing) > 1:
                        requestedAction = eventProcessing[1].lower()
                else:   requestedAction = 'both'
                
                # See if raw desired
                if requestedAction in ['both', 'raw']:
                        # Output locally
                        print('Events Received:')
                        print(response)
                
                if requestedAction in ['both', 'summary']:
                        # Print summary record
                        printSummaryMefRecord(response, target, queryType, queryValue, lclDCT, RESTInst, inputStartTime)
                
                # Restore eventProcessing local
                eventProcessing = ','.join(eventProcessing)
        
        # Remove custom data events that may cause validation problems
        if hasattr(CUST, "eventFieldsToSkipValidation") and  response:
               for item in CUST.eventFieldsToSkipValidation: response = re.sub(item+">(.*)<", item+">0<", response, )
        
        # If substring specified, then only get lines between these strings
        if substring:
                #print 'Response at beginning: ' + response
                
                # Split response into lines
                response = response.split('\n')
                
                # Can have an array of items wanted from events
                result = []
                for substr in substring:
                        # Map substring to start/end lines
                        try:
                                startString = eventSubStrings[substr].split(',')[0]
                                endString = eventSubStrings[substr].split(',')[1]
                        except:
                                print('ERROR: checking events with an unknown substring element: ' + substr)
                                sys.exit('Exiting due to errors')
                        
                        # Get start/end indices
                        startIndices = [i for i in range(len(response)) if response[i].count(startString)]
                        endIndices   = [i for i in range(len(response)) if response[i].count(endString)]
                        
                        # Sanity check that they're the same length
                        if len(startIndices) != len(endIndices):
                                print('ERROR: checking events with substring: ' + substr + ' led to different number of start and end indices.')
                                print('Start string: ' + startString + ', end string: ' + endString + ', start indices: ' + str(startIndices) + ', end indices: ' + str(endIndices))
                                print('Response:')
                                print("\n".join(response))
                                sys.exit('Exiting due to errors')
                        elif not len(startIndices):
                                # Nothing found
                                print('ERROR: checking events with substring: ' + substr + ' led to nothing found.')
                                print('Response:')
                                print("\n".join(response))
                                sys.exit('Exiting due to errors')
                        
                        # Grab ranges from response
                        for i in range(len(startIndices)):
                                # Grab the substring (add 1 to include the ending string)
                                result.extend(response[startIndices[i]:endIndices[i]+1])
                        
                # Put back into response
                response = '<KEF> \n' + "\n".join(result) + '\n </KEF>'
                #print 'Response at end: ' + response
        
        # Save for validation
        if REST_UTIL.restVersion == 'REST':
                # Get desired file name.  May not want the step included if user specified saveOutputFileName
                testName = 'trsf_'+testName
                if not lclDCT['saveOutputFileName']: testName += '_' + str(lclDCT['step'])
                testName += '_' + target + '_' + eventProcessing + '_eventDBQuery'
                
                # Save the data to the file
                QAUTILS.saveEventQueryResult(response, testName, convert=True, override=lclDCT['saveEvents'])
        
        return response
#==========================================================
def printSummaryMefRecord(response, target, queryType, queryValue, lclDCT, RESTInst, inputStartTime):
#       print '\n\n'
#       pprint.pprint(GENERIC.CustomData)
#       print '\n\n'
        
        # Seeing that timeouts don't always return XML data...
        try:
                q = ET.fromstring(response)
#               ET.dump(q)
        except:
                print('ERROR: returned data is not in XML format')
                return
        
        # Loop through response
        xmlDctName = './EventList/EventQueryEventInfo/EventDetails'
        
        # Default dictionary
        dctRcv = {}
        events = {}
        
        # Process the response for events
        for item in q.findall(xmlDctName):
                # Get data into a dictionary
                events = XML.getObjectBaseFields(item, events)
                pprint.pprint(events)
                
                # See what we have
                for event in events:
#                       print 'Processing event ' + event
                        eventProcess(event, item, inputStartTime)
        

#==========================================================
def eventGetDictionaryInfo(individual, key, childKey):
#       print 'Processing ' + key
        
        # Set data to empty list
        retData = []
        
        # Get data into an array - list order matters
        for element in individual.findall('./' + key + '/' + childKey):
#               print 'Adding to key ' + key
#               ET.dump(element)
                # Get top level fields
                retDct = {}
                retDct = XML.getObjectBaseFields(element, retDct)
#               pprint.pprint(retDct)
                retData.append(retDct)
#               pprint.pprint(retData)
        
#       print 'Returning array:'
#       pprint.pprint(retData)
        
        return retData
        
#==========================================================
def eventSpecificProcessing(event, individual, dctRcv):
        _kef = 1
        
#==========================================================
def eventSpecificOutput(event, individual, dctRcv):
        # If usage specified, then output here
        if 'UsageQuantityList' not in dctRcv: return
        
        # Loop through usage entries
        for entry in dctRcv['UsageQuantityList']:
                # Debug output
                #pprint.pprint(dctRcv['UsageQuantityList'])
                
                # If not RatingAmount then we didn;t use this
                if 'RatingAmount' not in entry: continue
                
                # Translate data to real words
                if entry['QuantityUnit'] in DATA.QuantityUnitMapping:
                        quantityUnit = DATA.QuantityUnitMapping[entry['QuantityUnit']]
                else:   quantityUnit = 'Unknown'
                
                # Don't report "none"
                if quantityUnit.lower() == 'none': quantityUnit = ''
                
                if entry['QuantityType'] in DATA.QuantityTypeMapping:
                        quantityType = DATA.QuantityTypeMapping[entry['QuantityType']]
                else:   quantityType = 'Unknown'
                
                # Output the entry
                print('Reported Amount: ' + entry['MsgAmount'] + ', Rated Amount: ' + entry['RatingAmount'] + ' ' + quantityUnit + ' (' + quantityType + ')\n')
                
#==========================================================
def eventProcess(event, item, inputStartTime):
#       print 'GENERIC Data:'
#       pprint.pprint(GENERIC.CustomData)
        
        # Space is always a good thing...
        print('\n')
        
        # Get data for this event
        for individual in item.findall('./'+event):
                # Box the event
                print('*'*20 + ' Event: ' + event + ' ' + '*'*20)
                
                print('Event XML Data:')
                ET.dump(individual)
                print('\n\n')
                
                # Initialize dictionary
                dctRcv = {}
                
                # Get common data
                eventCommonInput(individual, dctRcv)
                
                # With MDC event calls one can't specify lower time bound.
                # Manage that here
                eventTime = dctRcv['EventTime']
                lowerTimeBound = inputStartTime
                if not MDCTIME.checkIfTime2GreaterOrEqualTime1(lowerTimeBound, eventTime):
                        print('Rejected event ' + event + ' because event time ' + eventTime + ' is less than input time ' + lowerTimeBound)
                        continue
                
                # Here do event-specific processing
                eventSpecificProcessing(event, individual, dctRcv)
                
                # Output common header
                eventCommonOutputHeader(event, dctRcv)
                
                # Output event specific custom fields
                eventCustomFieldOutput(event, individual, dctRcv)
                
                # Here do event-specific output
                eventSpecificOutput(event, individual, dctRcv)
                
                # Outputs charge data
                eventChargeOutput(dctRcv)
                
                # Outputs G/L data
                eventGlOutput(dctRcv)
                
                # Box the event
                print('*'*60  + '\n')
                
#==========================================================
def eventCustomFieldOutput(event, individual, dctRcv):
        # If a usage event, then need to use MtxUsageEvent custom fields
        if event.count('Data') or event.count('Voice') or event.count('Text') or event.count('MMS'):
                lclEvent = 'MtxUsageEvent'
        # Get the main event name from the custom name
        elif event.startswith('Mtx'):
                lclEvent = event
        else:
                # Need to walk the custom data list, as the custom names are not the keys (base names are).  
                for entry in GENERIC.CustomData:
                        # Only want dictionary entrues
                        if type(GENERIC.CustomData[entry]) != type(dict()): continue
                        
                        # See if we hav a match
                        if GENERIC.CustomData[entry]['customName'] == event:
                                # Use base name
                                lclEvent = entry
                                break
        
        # See if this is event is in custom data (should be)
        if lclEvent not in GENERIC.CustomData: return
        
        # Sum the fields to check (just the one now; there were more earlier)
        fieldsToCheck = GENERIC.CustomData[lclEvent]['customFields']
        
        # Skip if no fields defined
        if not len(fieldsToCheck): return
        
        # Print each custom field
        i = 0
        outStr = ''
#       pprint.pprint(fieldsToCheck)
#       pprint.pprint(dctRcv)
        for field in fieldsToCheck:
                # Skip if not present
                if field not in dctRcv: continue
                
                # Output header only once
                if not i: outStr += 'Custom Fields: '
                        
                # Bump counter
                i += 1
                
                # Add to output string
                outStr += field + ' = ' + dctRcv[field] + ', '
                        
                # Print custom data after three queued up
                if not (i%5):
                        # Print data (minus trailing comma)
                        print(outStr[:-2])
                                
                        # Reset counters
                        outStr = ' ' * len('Custom Fields: ')
                        i = 1
        
        # If any output left, print it (minus trailing comma)
        if outStr: print(outStr[:-2])
        
        # Add space if anything output
#       if i: print '\n'
        
#==========================================================
def eventCommonOutputHeader(event, dctRcv):
                # Output information.
                # Get common header information
                str2 = 'Event ID:'
                str3 = 'Time:'
                format = '%-9s %-10s %5s %s\n'
                sys.stdout.write(format % \
                                (\
                                str2,  \
                                dctRcv['EventId'], \
                                str3,  \
                                dctRcv['EventTime']))
                
                # Output object IDs
                outStr = ''
                for obj in ['Initiator', 'WalletOwner', 'InitiatorDevice']:
                        if obj+'ExternalId' not in dctRcv: continue
                        
                        # Get item
                        outStr += obj + ': ' + dctRcv[obj+'ExternalId']
                        
                        # If ID present, then add
                        if obj+'Id' in dctRcv: outStr += '(' + dctRcv[obj+'Id'] + ')'
                        
                        # Always add comma seperator
                        outStr += ', '
                
                # Print if defined
                if len(outStr): print(outStr[:-2])
                
                # If primary or secondary events referenced, output here
                outStr = ''
                if 'PrimaryEventId'       in dctRcv: outStr += 'Primary Event ID: ' + dctRcv['PrimaryEventId']
                if 'SecondaryEventIdList' in dctRcv: outStr += 'Secondary Event IDs: ' + str(dctRcv['SecondaryEventIdList'])
                if outStr: print(outStr)
                
                str1 = 'ID'
                str2 = 'Ext ID'
                str3 = 'Start Time'
                str4 = 'End Time'
                format = '%-5s %-30s %-32s %s\n'
                        
                # Now print what's this event specific
                for element in ['BundleInfoArray', 'OfferInfoArray']:
                        if element not in dctRcv: continue
                        #pprint.pprint(dctRcv[element])
                        
                        # Output catalog items.  FIXME:  Need to reorg code so we can manage multiple bundles.  This covers 95% of the cases...
                        if 'CatalogItemId' in dctRcv[element][0]:
                                cid = dctRcv[element][0]['CatalogItemId']
                                if 'CatalogItemExternalId' in dctRcv[element][0]:
                                        ceid = dctRcv[element][0]['CatalogItemExternalId']
                                else:   ceid = ''
                                print("Catalog Data:")
                                sys.stdout.write(format % \
                                       (\
                                        cid,  \
                                        ceid,  \
                                        '',  \
                                        ''))
                                print('\n')
                                
                        print(element[:-9] + " Data:")
                        sys.stdout.write(format % \
                              (\
                                str1,  \
                                str2,  \
                                str3,  \
                                str4))
                        for item in dctRcv[element]:
                                # Not all item have an external ID
                                if 'ExternalId' not in item: item['ExternalId'] = '<Not Assigned>'
                                if 'StartTime' not in item or item['StartTime'].startswith('1-01-01'): item['StartTime'] = 'None'
                                if 'EndTime' not in item or item['EndTime'].startswith('65535'): item['EndTime'] = 'None'
                                sys.stdout.write(format % \
                                       (\
                                        item[element[:-9]+'Id'],  \
                                        item['ExternalId'],  \
                                        item['StartTime'],  \
                                        item['EndTime']))
                
                        print('\n')
                
#==========================================================
def eventCommonInput(individual, dctRcv):
        # Get top-level info data into a dictionary
        XML.getObjectBaseFields(individual, dctRcv)
        
        # Get pieces
        for entry in [  ('BundleInfoArray', 'MtxPurchaseEventBundleInfo'), \
                        ('OfferInfoArray', 'MtxPurchaseEventOfferInfo'),   \
                        ('AppliedBundleArray', 'MtxEventAppliedBundle'),   \
                        ('AppliedOfferArray', 'MtxEventAppliedOffer'),     \
                        ('BalanceUpdateArray', 'MtxBalanceUpdate'),        \
                        ('ChargeList', 'MtxEventCharge'),                  \
                        ('GlInfoArray', 'MtxEventGlInfo'),                 \
                        ('UsageQuantityList', 'MtxEventUsageQuantity'),    \
                     ]:
                (key, childKey) = entry
                if key in dctRcv:
                        dctRcv[key] = []
                        dctRcv[key].extend(copy.deepcopy(eventGetDictionaryInfo(individual, key, childKey)))
        
#       print 'Event Common Input Dictionary Data:'
#       pprint.pprint(dctRcv)
        print('\n')
                
#==========================================================
def eventGlOutput(dctRcv):
        key = 'GlInfoArray'
        
        # If nothing charged, then nothing to output
        if key not in dctRcv: return
        
        # Output header
        str1 = 'G/L #'
        str2 = 'Amount'
        str3 = 'Balance (C/T)'
        str4 = 'Account 1'
        str5 = 'Account 2'
        str6 = 'TxnType'
        str7 = 'RevenueRecognitionType'
        
        format = '%-8s %10s %-50s %-20s %-20s %-8s %s\n'
                
        sys.stdout.write(format % \
                    (\
                str1,  \
                str2,  \
                str3,  \
                str4,  \
                str5,  \
                str6,  \
                str7))
                
        # Walk the charge list
        for i,item in enumerate(dctRcv[key]):
                str1 = str(i)
                str2 = item['Amount']
                if 'BalanceUpdateIndex' in item:
                        # Get the balance data
                        balance = dctRcv['BalanceUpdateArray'][int(item['BalanceUpdateIndex'])]
                        
                        # Get names of balance and class
                        try:
                                balanceClassId = balance['BalanceClassId']
                                balanceClassName = DATA.balanceClassNameMapping[balanceClassId]
                                balanceTemplateId = balance['BalanceTemplateId']
                                balanceTemplateName = DATA.balanceNameMapping[balanceTemplateId] 
                        except:
                                print('Hmmm.  eventGlOutput() balance data not complete.')
                                pprint.pprint(balance)
                                pprint.pprint(DATA.balanceClassNameMapping)
                                pprint.pprint(DATA.balanceNameMapping)
                                balanceClassName = balanceClassId = balanceTemplateName = balanceTemplateId = "Unknown"
                        
                        # Report class and template name and ID
                        str3  = balanceClassName + '(' + balanceClassId + ')/' 
                        str3 += balanceTemplateName + '(' + balanceTemplateId + ')'
                else:   str3 = 'No Balance Data'
                str4 = item['Account1']
                str5 = item['Account2']
                str6 = item['TxnType']
                if 'RevenueRecognitionType' not in item:
                        str7 = 'Not Populated'
                elif item['RevenueRecognitionType'] in PRIMDATA.RevenueRecognitionTypeMapping:
                        str7 = PRIMDATA.RevenueRecognitionTypeMapping[item['RevenueRecognitionType']]
                else:   str7 = 'MISSING VALUE'
                str7 += '(' + item['RevenueRecognitionType'] + ')'
                
                # Print the item
                sys.stdout.write(format % \
                    (\
                        str1,  \
                        str2,  \
                        str3,  \
                        str4,  \
                        str5,  \
                        str6,  \
                        str7))
                
        print('\n')
        
#==========================================================
def eventChargeOutput(dctRcv):
        key = 'ChargeList'
        
        # If nothing charged, then nothing to output
        if key not in dctRcv: return
        
        # Output header
        str1 = 'Charge #'
        str2 = 'Amount'
        str3 = 'Balance (C/T)'
        str6 = 'Type'
        str7 = 'G/L #'
        str4 = 'Offer'
        str5 = 'Bundle'
        format = '%-8s %10s %-50s %-10s %-9s %-40s %s\n'
                
        sys.stdout.write(format % \
                    (\
                str1,  \
                str2,  \
                str3,  \
                str6,  \
                str7,  \
                str4,  \
                str5))
                
        # Walk the charge list
        for i,item in enumerate(dctRcv[key]):
                offer = None
#               pprint.pprint(item)
                str1 = str(i)
                str2 = item['Amount']
                if 'BalanceUpdateIndex' in item:
                        balance = dctRcv['BalanceUpdateArray'][int(item['BalanceUpdateIndex'])]
                        
                        # Get names of balance and class
                        balanceClassId = balance['BalanceClassId']
                        balanceClassName = DATA.balanceClassNameMapping[balanceClassId]
                        balanceTemplateId = balance['BalanceTemplateId']
                        balanceTemplateName = DATA.balanceNameMapping[balanceTemplateId] 
                        
                        # Report class and template name and ID
                        str3  = balanceClassName + '(' + balanceClassId + ')/' 
                        str3 += balanceTemplateName + '(' + balanceTemplateId + ')'
                else:   str3 = 'No Balance Data'
                if 'AppliedOfferIndex' in item:
                        offer = dctRcv['AppliedOfferArray'][int(item['AppliedOfferIndex'])]
                        if 'ProductOfferExternalId' in offer: str4 = offer['ProductOfferExternalId'] + '(' + offer['ProductOfferId'] + ')'
                        else: str4 = offer['ProductOfferId']
                else:   str4 = 'No Offer Data'
                if offer and 'AppliedBundleIndex' in offer:
                        bundle = dctRcv['AppliedBundleArray'][int(offer['AppliedBundleIndex'])]
                        if 'BundleExternalId' in bundle: str5 = bundle['BundleExternalId'] + '(' + bundle['BundleId'] + ')'
                        else: str5 = bundle['BundleId']
                else:   str5 = 'No Bundle Data'
                if 'UpdateType' in item:
                        if item['UpdateType'] in PRIMDATA.UpdateTypeMapping:
                                str6 = PRIMDATA.UpdateTypeMapping[item['UpdateType']]
                        else:   str6 = 'MISSING VALUE'
                        str6 += '(' + item['UpdateType'] + ')'
                else:   str7 = 'N/A'
                
                if 'GlInfoIndex' in item:
                        str7 = item['GlInfoIndex']
                else:   str7 = 'N/A'
                
                # Output offer
                sys.stdout.write(format % \
                    (\
                        str1,  \
                        str2,  \
                        str3,  \
                        str6,  \
                        str7,  \
                        str4,  \
                        str5))
                
        print('\n')
        
#==========================================================
def processOtherEvents(respData, lclDCT, RESTInst):
        # *** lclDCT[] has all the values.

        # Force the string to be there
#        respData += '''
#       <AssociatedEventIdList>
#        <value>HBC0:1:52:7101</value>
#        </AssociatedEventIdList>
#       '''

        # Secondary has priority over associated. See if any are present
        if   lclDCT['processSecondaryEvents']  and 'SecondaryEventIdList'  in respData: searchString = 'SecondaryEventIdList>'
        elif  lclDCT['processAssociatedEvents'] and 'AssociatedEventIdList' in respData: searchString = 'AssociatedEventIdList>'
        else:
                print('Warning: requested secondary/associated event data but none was present in the response')
                return None

        # Get event list (only ever element 0).  Use partition like grep :-).
        # Index 2 is the part after the specified string and index 0 is the part before.  Index 1 is the string.
        # Find (1) after the first string 'SecondaryEventIdList>', (2) before the seoond instance of that string, (3) after the first '>', (4) before the first '<'.
        eventId = respData.partition(searchString)[2].partition(searchString)[0].partition('>')[2].partition('<')[0]
        print('Looking for ' + searchString[:-12] + ' event ID ' + eventId)

        # Go fetch the secondary event
        retCode = REST_UTIL.queryEventstoreById(RESTInst,
                eventId,
                queryType = 'EventId',
                applyDefaultFilter=lclDCT['applyDefaultFilter'],
                routingType=lclDCT['routingType'],
                routingValue= lclDCT['routingValue'],
                eventPass=lclDCT['eventPass'],
                searchInMemoryDatabase=lclDCT['searchInMemoryDatabase'],
                apiEventData=lclDCT['apiEventData'],)

        # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
        try:
                respData = str(retCode.printElementBasedXml())
        except:
                respData = str(retCode)
        #print searchString[:-12] + ' event data: ' + respData

        return respData

#==========================================================
