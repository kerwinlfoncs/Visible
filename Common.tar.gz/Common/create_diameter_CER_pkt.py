#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:10
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:35:52
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:34:41
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

# from builtins import str
# from builtins import str
import diameter as DIAM
import re
#
# This program will create CER packets and send them to the
# Diameter Gateway.
####################################################################
def main(diamConnection, reqDct, extraAVP = {}):
#    logger =  LOGGER.clErrors(path)

    finalRetCode = 0
    fileNameList = []
    OriginHost = reqDct['Origin-Host']
    OriginRealm = reqDct['Origin-Realm']
    if extraAVP != {}:
        if 'add' in extraAVP:
            myList = extraAVP['add']
            for avp in myList :
              if re.search('Origin-Host',str(avp)):
                  OriginHost = avp.split(":")[1].strip()
              if re.search('Origin-Realm',str(avp)):
                  OriginRealm = avp.split(":")[1].strip()
    # Create the input data
    diamPacket = DIAM.createPacket(0, 257 + DIAM.CmdFlagRequest, 1001, 2001)
    diamPacket.appendAvp('Origin-Host', OriginHost)
    diamPacket.appendAvp('Origin-Realm', OriginRealm)
    diamPacket.appendAvp('Host-IP-Address', '10.10.126.51')
    diamPacket.appendAvp('Vendor-Id', 11)
    diamPacket.appendAvp('Product-Name', 'Mtx Interface')
    diamPacket.appendAvp('Origin-State-Id', 1094807040)
    diamPacket.appendAvp('Supported-Vendor-Id', 10415)
    diamPacket.appendAvp('Auth-Application-Id', 4)
    diamPacket.appendAvp('Acct-Application-Id', 0)
    diamPacket.appendAvp('Firmware-Revision', 1)

    diamResp = diamConnection.send(diamPacket)
    
if __name__ == '__main__':
    main()
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

