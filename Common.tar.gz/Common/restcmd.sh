#this file is a sample on how to run REST APIs from a cmd line
if [ $# -lt 1 ] ; then
    python -c 'import restV3; restV3.printAll()'
    echo "#####################################################"
    echo "note: always make V3inst = 0"
    echo "example:  sh restcmd.sh \"addSubscriber(V3inst = 0, externalId = 18082, deviceId = 19092, deviceType = 1,  offerId = 2, printResp = True)\""
    echo "#####################################################"
else
    python -c "import restV3; restV3.$1"
fi
