#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:09
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:35:51
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:34:41
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

# from builtins import input
# from builtins import str
from future import standard_library
standard_library.install_aliases()
# from builtins import input
# from builtins import str
import common_mdc as COMMON
#import configparser
try:
    import configparser
except:
    from six.moves import configparser
import copy  
import create_diameter_CER_pkt  
import create_diameter_pkt_base as DIAMPKT
import data_container_defs as MDCDEFS
import diameter as DIAM
import diameter_utils as DIAMU
import difflib  
import log_errors as LOGGER
import diff_initiator_sponsor as VALIDATE_EDR
import optparse  
import os, sys, random
import pickle  
import QA_group_management_direct as GROUP
import QA_subscriber_management_direct as MDC_UTILS
import QA_subscriber_management_restv3 as QAV3
import re  
import restV3, rest_json
import show_events_from_file as EVENTS
import show_notifications_from_file as NOTIFICATIONS
import show_scheduled_tasks_from_file as TASKS
import show_tracking_from_file as TRACKING
import shutil  
import io
import subprocess  
import subscriber_mgmt_v3 as RESTV3
import timeToMDCtime as MDCTIME
import time
import xml_utils
from xml.etree import ElementTree
import csv_qa as CSVQA
import glob
import binascii
import qa_mdc_defs as QA_MDC
import json

# Value indicating send NULL for the IMSI and/or MSISDN
sendNullValue = '998877665544332'

gatewaysConfig = None
LogDir = None
TxnLogDir = None
eventDct = {}
dctGeneral = {}
currentTestStartTime = 0
QACommon = ''
sessionTimeKeeper={}
MSCC = 0
msccFlag = False
diamFileLine = 0
txnLogLine = 0
tskLogLine = 0
notifLogLine = 0
trackLogLine = 0
stripFields = False
xmlStatus=True
path = os.getcwd()
logger = LOGGER.clErrors(path)

# Debug setting.  Make it easy to enable globally debug information.
# Tie to the debug option
DebugLevel=0

# Add globally referencable list of possible group tier values.  
# Ideally we tie this to the pricing file, but for now hard-code (since we don't always have access to the pricing file from here).
groupTiers = []
groupTiers.append('Corporation')
groupTiers.append('Region')
groupTiers.append('Country')
groupTiers.append('Division')
groupTiers.append('Department')
groupTiers.append('Team')
groupTiers.append('Group')
groupTiers.append('Family')

#===============================================================================

import atexit

@atexit.register
def goodbye():
#    global path
#    CurrentTestEndTime = time.clock()
#    CurrentTestDuration = CurrentTestEndTime - CurrentTestStartTime
#    timeFile = path + '/' + COMMON.resultsDir + '/test_duration_local.txt'
#    fp = open(timeFile,'w')
#    fp.write('Test_duration = ' + str(CurrentTestDuration))
#    fp.close()

    #print 'Exiting test - called from goodbye function'
    # If spoof time is in effect, then clear it
    if MDCTIME.spoofTimeEnabled:
        # Unconditionally clear any spoofed time at the end of a test
        MDCTIME.clearSpoofTime()

        # Clear the flag (for good measure)
        MDCTIME.spoofTimeEnabled = False

    # Check for any core files
    coreDir = '/var/mtx/'
    fileList = glob.glob(coreDir + 'core.*')
    if len(fileList):
        print('\n\n***** WARNING: there are core files in directory ' + coreDir + ': *****')
        print(str(fileList))
        print('\n\n')
    
    # May want to clean up HTTP server (if test created it)
    runCmd("killHTTP " + os.getcwd() + '/' + COMMON.resultsDir + '/httpCreated')
    
#===============================================================================
def getFunctionName():
        return sys._getframe(1).f_code.co_name

#===============================================================================
def castStringtoList(myString):
    return(eval(str(myString)))

#===============================================================================
def castStringtoListOfString(myString):
    l1 = (eval(str(myString)))
    Lst=[]
    if type(l1) == type(list()):
        for item in l1:
            Lst.append(str(item))
        return Lst
    return myString

#go thu the entire directory and search for a file name DCT_<..>  and print contents
#this is a pickled version of the dictionary
def printAllDictionaries(path) :
    allMdcFilesList = path + '/allMdcFilesList'
    if not (os.path.isfile(allMdcFilesList)):
        logger.printRes(path, 'validate_balances.txt',
            'Cannot validate: missing ' + allMdcFilesList)
        sys.exit('Cannot validate: missing ' + allMdcFilesList)

    filesList = open(allMdcFilesList,'r')
    for fp in filesList.readlines() :
        fp = fp.strip('\n')
        fp = fp.split('/')[-1]
        print('================  output for ' + fp + '=====================')
        MDC_UTILS.printPickledDictionary(path, fp)

#===============================================================================
def saveGroupMDC(groupId, testTag, debugData = '', queryType='ExternalId', queryTime=None, querySize=None, diffInitiator=False, diffSponsor=False, verbose='full'):
    global currentTestStartTime
    global dctGeneral
    global path
    global stripFields

    initiatorOid = None
    initiatorExternalId = None
    initiatorDeviceOid = None
    sponsorOid = None
    sponsorExternalId = None

    if queryTime is not None:
        queryTime = MDCTIME.convertTime(queryTime, restVersion=QAV3.restVersion)

    # create an ECT_ file for other than DCT validation
    if (groupId == 0):
        if ((QAV3.restVersion == 'REST'  or QAV3.restVersion == 'JSON') and isinstance(debugData,bytes)):
           debugData = debugData.decode('utf-8')  #fix for python3
        logger.printRes(path, 'ECT_'+testName + '.dat', debugData, overwrite = True) 
        logger.printRes(path, "allMdcFilesList", os.getcwd()+'/' + COMMON.resultsDir + '/ECT_'+testName + '.dat' ) 
        return
    
    diffEvents = False
    if diffInitiator or diffSponsor:
        diffEvents = True

    if dctGeneral['events']:
        (initiatorOid, initiatorExternalId, initiatorDeviceOid, sponsorOid, sponsorExternalId)=\
            parseActions('txn', 'trsf_outQueryGroup_' + str(groupId).replace(':', '_') + '_' + testTag, diffEvents, stripFields)

    if dctGeneral['notifications']:
        parseActions('notif', 'trsf_outQueryGroup_' + str(groupId).replace(':', '_') + '_' + testTag, False, stripFields)

    if dctGeneral['tasks']:
        parseActions('tasks', 'trsf_outQuery_' + str(groupId).replace(':', '_') + '_' + testTag, False, stripFields)

    if dctGeneral['diam']:
        parseActions('diam', 'trsf_outQueryGroup_' + str(groupId).replace(':', '_') + '_' + testTag, False, stripFields)

    if verbose not in ['low', 'none']: print('Saving MDC for group with ' + queryType + ': ' + str(groupId))
    
    #testName = str(testName) + str(debugData)
    
    mdcConnection = getDatacontainerConnection()
    mdcFileName = GROUP.queryGroup(mdcConnection, path, groupId, testTag, queryType=queryType, querySize=querySize, queryTime=queryTime,
        diffEvents=diffEvents)
    if verbose not in ['low', 'none', '5g']: print('mdcFile is------------------ ' + str(mdcFileName))

    # Validate initiator/sponsor if requested
    VALIDATE_EDR.validateInitiatorSponsorForGroup(restInst=mdcConnection, mdcFileName=mdcFileName,
        diffInitiator=diffInitiator, diffSponsor=diffSponsor, initiatorOid=initiatorOid,
        initiatorExternalId=initiatorExternalId, sponsorOid=sponsorOid, sponsorExternalId=sponsorExternalId,
        queryTime=queryTime, testTag=testTag)

    currentTestEndTime = time.clock()
    currentTestDuration = currentTestEndTime - currentTestStartTime
    timeFile = path + '/' + COMMON.resultsDir + '/test_duration_local.txt'
    runCmd('echo ' + str(currentTestDuration) + ' > ' + timeFile)
    
#===============================================================================
# this function will query MDC gateway for a subsc/group ID
# result is sent for parsing and presisting in a pickled dct
# in case there is no MDC involved like a "grep to some file"
# the grep results which is the param debugData is saved
# rest param: to indicate if I want the balance startTime or not
 
def saveMDC(queryValue, testName, debugData = '', rest = False, queryType='PhoneNumber', queryTime=None,
        diffInitiator=False, diffSponsor=False, verbose='full'):
    global dctGeneral
    global currentTestStartTime
    global path
    global stripFields

    initiatorOid = 0
    initiatorExternalId = 0
    initiatorDeviceOid = 0
    sponsorOid = 0
    sponsorExternalId = 0

    if queryTime is not None:
        queryTime = MDCTIME.convertTime(queryTime, restVersion=QAV3.restVersion)

    # create an ECT_ file for other than DCT validation
    if (queryValue == 0):
        if ((QAV3.restVersion == 'REST' or QAV3.restVersion == 'JSON') and isinstance(debugData,bytes)):
           debugData = debugData.decode('utf-8')  #fix for python3
        logger.printRes(path, 'ECT_'+testName + '.dat', debugData, overwrite = True) 
        logger.printRes(path, "allMdcFilesList", os.getcwd()+'/' + COMMON.resultsDir + '/ECT_'+testName + '.dat' ) 
        return
    
    diffEvents = False
    if diffInitiator or diffSponsor:
        diffEvents = True

    if dctGeneral['events']:
        (initiatorOid, initiatorExternalId, initiatorDeviceOid, sponsorOid, sponsorExternalId)=\
            parseActions('txn', 'trsf_outQuery_' + str(queryValue).replace(':', '_') + '_' + testName, diffEvents, stripFields)
#            parseActions('txn', 'trsf_outQuery_' + str(queryValue) + '_' + testName, diffEvents, stripFields)

    if dctGeneral['notifications']:
        parseActions('notif', 'trsf_outQuery_' + str(queryValue).replace(':', '_') + '_' + str(testName), False, stripFields)

    if dctGeneral['tasks']:
        parseActions('tasks', 'trsf_outQuery_' + str(queryValue).replace(':', '_') + '_' + str(testName), False, stripFields)

    if dctGeneral['tracking']:
        parseActions('tracking', 'trsf_outQuery_' + str(queryValue).replace(':', '_') + '_' + testName, diffEvents, stripFields)

    if dctGeneral['diam']:
        parseActions('diam', 'trsf_outQuery_' + str(queryValue).replace(':', '_') + '_' + str(testName), False, stripFields)

    #testName = str(testName) + str(debugData)
    if verbose not in ['low', 'none']: print('Saving MDC for subscriber with ' + queryType + ': ' + str(queryValue))

    #this will generate $path/results/outQuery_queryValue_testName
    mdcConnection = getDatacontainerConnection()
    mdcFileName = MDC_UTILS.querySubscriber(mdcConnection, path, queryValue, testName, queryType = queryType,
        queryTime = queryTime, debugData = debugData, diffEvents = diffEvents)

    if verbose not in ['low', 'none', '5g']: print('mdcFile is------------------ ' + str(mdcFileName))
    # parse this MDC into a dictionary, rest param will return a win startTim=e

    #collect events for EDR tests
    VALIDATE_EDR.validateInitiatorSponsorForSub(restInst=mdcConnection, mdcFileName=mdcFileName,
        diffInitiator=diffInitiator, diffSponsor=diffSponsor, initiatorOid=initiatorOid,
        initiatorExternalId=initiatorExternalId, sponsorOid=sponsorOid, sponsorExternalId=sponsorExternalId,
        queryTime=queryTime, testTag=testName)

    time1 = None
    # some workaround because startTime on Simple Balances in the mdc is not set
    if rest:
        if (time1 == None):
             time1 = MDCTIME.getTime(0)
        elif (not len(time1) == 19): 
            time1 = MDCTIME.getTime(0)
    
    currentTestEndTime = time.clock()
    currentTestDuration = currentTestEndTime - currentTestStartTime
    timeFile = path + '/' + COMMON.resultsDir + '/test_duration_local.txt'
    runCmd('echo ' + str(currentTestDuration) + ' > ' + timeFile)

    return time1

#===============================================================================
def saveDeviceMDC(queryValue, testName, debugData = '', queryType='PhoneNumber', queryTime=None, verbose='full'):
    global dctGeneral
    global currentTestStartTime
    global path
    global stripFields

    if queryTime is not None:
        queryTime = MDCTIME.convertTime(queryTime, restVersion=QAV3.restVersion)

    # create an ECT_ file for other than DCT validation
    if (queryValue == 0):
        if ((QAV3.restVersion == 'REST'  or QAV3.restVersion == 'JSON') and isinstance(debugData,bytes)):
            debugData = debugData.decode('utf-8')  #fix for python3
        logger.printRes(path, 'ECT_'+testName + '.dat', debugData, overwrite = True) 
        logger.printRes(path, "allMdcFilesList", os.getcwd()+'/' + COMMON.resultsDir + '/ECT_'+testName + '.dat' ) 
        return
    
    if dctGeneral['events']:
        (initiatorOid, initiatorExternalId, initiatorDeviceOid, sponsorOid, sponsorExternalId)=\
            parseActions('txn', 'trsf_outQuery_' + str(queryValue).replace(':', '_') + '_' + testName, False, stripFields)

    if dctGeneral['notifications']:
        parseActions('notif', 'trsf_outQuery_' + str(queryValue).replace(':', '_') + '_' + str(testName), False, stripFields)

    if dctGeneral['tasks']:
        parseActions('tasks', 'trsf_outQuery_' + str(queryValue).replace(':', '_') + '_' + str(testName), False, stripFields)

    if dctGeneral['diam']:
        parseActions('diam', 'trsf_outQuery_' + str(queryValue).replace(':', '_') + '_' + str(testName), False, stripFields)

    #testName = str(testName) + str(debugData)
    
    #this will generate $path/results/outQuery_queryValue_testName
    mdcConnection = getDatacontainerConnection()
    mdcFileName = MDC_UTILS.queryDevice(mdcConnection, path, queryValue, testName, queryType = queryType,
        queryTime = queryTime)

    if verbose not in ['low', 'none', '5g']: print('mdcFile is------------------ ' + str(mdcFileName))
    # parse this MDC into a dictionary, rest param will return a win startTim=e

    currentTestEndTime = time.clock()
    currentTestDuration = currentTestEndTime - currentTestStartTime
    timeFile = path + '/' + COMMON.resultsDir + '/test_duration_local.txt'
    runCmd('echo ' + str(currentTestDuration) + ' > ' + timeFile)

    return

#===============================================================================
def saveUserMDC(queryValue, testName, debugData = '', queryType='ExternalId', queryTime=None, verbose='full'):
    global dctGeneral
    global currentTestStartTime
    global path
    global stripFields

    if queryTime is not None:
        queryTime = MDCTIME.convertTime(queryTime, restVersion=QAV3.restVersion)

    # create an ECT_ file for other than DCT validation
    if (queryValue == 0):
        if ((QAV3.restVersion == 'REST'  or QAV3.restVersion == 'JSON') and isinstance(debugData,bytes)):
           debugData = debugData.decode('utf-8')  #fix for python3
        logger.printRes(path, 'ECT_'+testName + '.dat', debugData, overwrite = True)
        logger.printRes(path, "allMdcFilesList", os.getcwd()+'/results/ECT_'+testName + '.dat' )
        return

    if dctGeneral['events']:
        (initiatorOid, initiatorExternalId, initiatorDeviceOid, sponsorOid, sponsorExternalId)=\
            parseActions('txn', 'trsf_outQuery_' + str(queryValue).replace(':', '_') + '_' + testName, False, stripFields)

    if dctGeneral['notifications']:
        parseActions('notif', 'trsf_outQuery_' + str(queryValue).replace(':', '_') + '_' + str(testName), False, stripFields)

    if dctGeneral['tasks']:
        parseActions('tasks', 'trsf_outQuery_' + str(queryValue).replace(':', '_') + '_' + str(testName), False, stripFields)

    if dctGeneral['diam']:
        parseActions('diam', 'trsf_outQuery_' + str(queryValue).replace(':', '_') + '_' + str(testName), False, stripFields)

    #testName = str(testName) + str(debugData)

    #this will generate $path/results/outQuery_queryValue_testName
    mdcConnection = getDatacontainerConnection()
    mdcFileName = MDC_UTILS.queryUser(mdcConnection, path, queryValue, testName, queryType = queryType,
        queryTime = queryTime)

    if verbose not in ['low', 'none', '5g']: print('mdcFile is------------------ ' + str(mdcFileName))
    # parse this MDC into a dictionary, rest param will return a win startTim=e

    currentTestEndTime = time.clock()
    currentTestDuration = currentTestEndTime - currentTestStartTime
    timeFile = path + '/results/test_duration_local.txt'
    runCmd('echo ' + str(currentTestDuration) + ' > ' + timeFile)

    return

#===============================================================================
def getDatacontainerConnection():
    v3Inst = RESTV3.SubscriberManagementV3Client(trace = getTrace(),
        hostName=gatewaysConfig.get('DATACONTAINER', 'hostName'),
        hostPort=int(gatewaysConfig.get('DATACONTAINER', 'hostPort')))
    return v3Inst

#===============================================================================
def getDiamConnection(diameterDestinationIpAddress=None, commandType=None):
    diamConnection = diameterClient(diameterDestinationIpAddress, commandType=commandType)
    diamConnection.open()
    hostname = runCmd('hostname')
#    if re.search('load', hostname):
#        create_diameter_CER_pkt.main(diamConnection)
#    create_diameter_CER_pkt.main(diamConnection)

    return(diamConnection)

def getSigtranConfig(config):  #uses getSubsc which is misnamed since it can read any section
    sigDct = {}
    if (config.has_section(section)):
        sigDct = getSubsc(config, 'SIGTRAN') 
    return sigDct

#===============================================================================
def checkForExpectFiles(path):
    if not os.path.isdir(path):
        return False

    if not os.path.isdir(path + '/expect'):
        return False
    list = os.listdir(path + '/expect')
    #print list
    if len(list) < 1 :
        return False
    return True
#===============================================================================
def sendOneRequest(deviceId = 0,reqamount = 0, usedamount = 0, requestType = 'term', sessionId = 0, serviceId = 'voice', startTime = 0, eventPass = True, extraAVP = {}, msccAvpListToAppend = None, stripList = None, accessNumber = 0, diamConnection=None, commandType='gy', SkipCERFlag=False, exponent = None, currencyCode = None, originHost=None, originRealm=None, sendOnlyFlag=False, loginId=None, accessId=None, verbose=None, duplicateFlag=False):
    global MSCC
    global path

    # Create a diameter connection if one was not passed in
    if not diamConnection: diamConnection = getDiamConnection(commandType=commandType)
    
    # test name is the last part of the full path
    testName = path.split('/')[-1]
    
    # Get a fully qualified start time in UTC time
    if startTime == None :
        startTime =  MDCTIME.getTime(0)
    #startTime = (MDCTIME.convertTime(startTime, forceUtc=True)).rstrip('Z')
    startTime = MDCTIME.convertTime(startTime, forceUtc=True)

    # Debug logging
    if DIAMU.diameterFileDebugFlag: 
        logger.printRes(path, 'eventTimes.txt','sending request '  + str(requestType) + '=>' + str(startTime))

    # Create/retrieve session ID
    if (requestType == 'initial'):
        if 'reqNum' in extraAVP:
            sessionTimeKeeper[str(sessionId) + '-reqNum'] = extraAVP['reqNum']
            del extraAVP['reqNum']
        else:    
            sessionTimeKeeper[str(sessionId) + '-reqNum'] = '1'

        sessionTimeKeeper[sessionId] =  startTime
    else:
        # check if init request was ommitted in a session
#        print '!!!! !!! create new entry in session keeper for sessionId = ' + str(sessionId)
        if sessionId not in sessionTimeKeeper:
            if 'reqNum' in extraAVP:
                sessionTimeKeeper[str(sessionId) + '-reqNum'] = extraAVP['reqNum']
                del extraAVP['reqNum']
            else:
                sessionTimeKeeper[str(sessionId) + '-reqNum'] = '1'
            sessionTimeKeeper[sessionId] =  startTime
        else:
            if 'reqNum' in extraAVP:
                # May be "last" or a number
                sessionTimeKeeper[str(sessionId) + '-reqNum'] = extraAVP['reqNum']
                del extraAVP['reqNum']
            elif duplicateFlag:
                # Keep same request number
                sessionTimeKeeper[str(sessionId) + '-reqNum'] = str(sessionTimeKeeper[str(sessionId) + '-reqNum'])
            else:
                # Bump request by 1
                sessionTimeKeeper[str(sessionId) + '-reqNum'] = str(int(sessionTimeKeeper[str(sessionId) + '-reqNum']) + 1)
    
#    print '==================================================='
#    print '=                                                 ='
#    print '=    EventTime = ' + str(sessionTimeKeeper[sessionId]) +' for sessionId= '+str(sessionId) 
#    print '==================================================='

    # No idea what this does...
    extraAVPToOverrideList = ['Called-Station-Id', 'SGSN-Address', '3GPP-MS-TimeZone', 'Service-Context-Id', 
                               'serviceIdName', 'Destination-Host', 'calledId', 'Origin-Host']

    # Start building dictionary to be used for building Diameter message
    reqDct = {}

    # KEF: Copy verbose flag
    reqDct['verbose'] = verbose
    
    # Define fields common to all messages
    reqDct['sessionId'] = sessionId
    reqDct['requestType'] = requestType
    reqDct['Destination-Host']='localhost'
    try:
        reqDct['eventTime'] = DIAM.convertStringTimeToDiameterTime(startTime,dst=0)
    except:
        reqDct['eventTime'] = DIAM.convertStringTimeToDiameterTime(startTime)
    
    # Orig host/realm can be variable
    if originHost:      reqDct['Origin-Host'] = str(originHost)
    else:               reqDct['Origin-Host'] = 'GatewayService-7-10-1.shsae21.customer.com'
    if originRealm:     reqDct['Origin-Realm'] = str(originRealm)
    else:               reqDct['Origin-Realm'] = 'origrealm.net'
    
    # Grab IMSI and/or MSISDN, depending on input params
    if int(deviceId) > 0:       reqDct['Subscription-Id-Type-IMSI'] = deviceId
    if int(accessNumber) > 0:   reqDct['Subscription-Id-Type-MSISDN'] = accessNumber
    
    # TESTING NEED: If IMSI or MSISDN is reserved value, then set to empty
    try:
        if reqDct['Subscription-Id-Type-IMSI']   == sendNullValue: reqDct['Subscription-Id-Type-IMSI']   = ''
        if reqDct['Subscription-Id-Type-MSISDN'] == sendNullValue: reqDct['Subscription-Id-Type-MSISDN'] = ''
    except: pass
    
    #added for Non-Mobile device , mtx-14174, customer can set accessId and loginId from any of
    # these 3 diameter avp . SIP_URI, NAI and Private
    if accessId:                reqDct ['Subscription-Id-Type-NAI'] = accessId
    if loginId:                 reqDct['Subscription-Id-Type-SIP-URI'] = loginId
    #if loginId:                 reqDct['Subscription-Id-Type-PRIVATE'] = loginId

    # if a term event reaches and no initial event preceeded it
    if sessionId not in sessionTimeKeeper:
        try:
                reqDct['Start-Time'] = DIAM.convertStringTimeToDiameterTime(startTime,dst=0)
        except:
                reqDct['Start-Time'] = DIAM.convertStringTimeToDiameterTime(startTime)
    else:
        try:
                reqDct['Start-Time'] = DIAM.convertStringTimeToDiameterTime(sessionTimeKeeper[sessionId],dst=0)
        except:
                reqDct['Start-Time'] = DIAM.convertStringTimeToDiameterTime(sessionTimeKeeper[sessionId])

    # Minor hack.  TF uses rx, not rxstr.  So if rx and a term message, then update here to rxstr
    #print '\n\n In sendOneRequest, requestType = ' + requestType + ', commandType = ' + commandType
    if requestType.startswith('term') and commandType.lower() == 'rx':
        #print 'Changing command to rxstr'
        commandType = 'rxstr'
     
    # Perform command specific actions
    if commandType.lower() == 'gy':
     reqDct['reqNum'] =  str(sessionTimeKeeper[str(sessionId) + '-reqNum'])
     if DIAMU.diameterFileDebugFlag: logger.printRes(path, 'reqNum.txt', reqDct['reqNum'])
     reqDct['deviceId'] = deviceId
     reqDct['Called-Station-Id'] = '100999'
     reqDct['SGSN-Address'] = '1.2.3.4'
     reqDct['3GPP-MS-TimeZone'] = '0000'
     reqDct['reqamount'] = reqamount
     reqDct['usedamount'] = usedamount
     reqDct['serviceId'] = serviceId
     reqDct['calledId'] = '100'
     reqDct['exponent'] = exponent
     reqDct['currencyCode'] = currencyCode
#    reqDct['Subscription-Id-Type'] = '1'
     reqDct['Service-Context-Id'] = DIAMU.getServiceIdContext(reqDct['serviceId'])
     reqDct['serviceIdName'] = DIAMU.getServiceId(reqDct['serviceId'])

     if MSCC == 2 and (msccAvpListToAppend == None): #MSCC is enabled with -k 1 
        extraAVP['MSCC'] = 2
     else:
        MSCC = 0 # just in case MSCC specific tests run with -k 1
    
     # run old tests with MSCC packets -k 1 has to be enabled.
     # MsccManual added for new tests that must have mscc enabled by default and want to use default mscc pkt creation.
     MSCCManual = False   #TODO : revisit this code
     if extraAVP != None:
        if 'MsccManual' in extraAVP:
            if int(extraAVP['MsccManual']) == 1:  MSCCManual = True

     if MSCC == 2 or MSCCManual: 
         extraAVP['MSCC'] = 1 #msccAvpListToAppend, extraAVP = DIAMU.getMsccAvpListToAppend(serviceId, usedamount, reqamount, localExtraAVP)

     # Invoke CCR function
     dctRcvd = DIAMPKT.createCreditControlRequest(path, reqDct, diamConnection, eventPass, extraAVP, SkipCERFlag=SkipCERFlag, sendOnlyFlag=sendOnlyFlag, duplicateFlag=duplicateFlag)
    elif commandType.lower() == 'sy':
     # Invoke SLR function
        dctRcvd = DIAMPKT.createSpendLimitOrSpendTermRequest(path, reqDct, diamConnection, eventPass, extraAVP, SkipCERFlag=SkipCERFlag)

    elif commandType.lower() == 'gx':
        reqDct['reqNum'] =  str(sessionTimeKeeper[str(sessionId) + '-reqNum'])
        if DIAMU.diameterFileDebugFlag: logger.printRes(path, 'reqNum.txt', reqDct['reqNum'])
        reqDct['deviceId'] = deviceId
        reqDct['Called-Station-Id'] = '100999'
        reqDct['SGSN-Address'] = '1.2.3.4'
        reqDct['3GPP-MS-TimeZone'] = '0000'
        reqDct['serviceId'] = serviceId
        reqDct['Service-Context-Id'] = DIAMU.getServiceIdContext(reqDct['serviceId'])
        reqDct['serviceIdName'] = DIAMU.getServiceId(reqDct['serviceId'])
        # Invoke CCR Gx function
        dctRcvd = DIAMPKT.createCreditControlRequestGx(path, reqDct, diamConnection, eventPass, extraAVP, SkipCERFlag=SkipCERFlag)
    elif commandType.lower() == 'str':
     # Invoke STR function
        dctRcvd = DIAMPKT.createSessionTermRequest(path, reqDct, diamConnection, eventPass, extraAVP, SkipCERFlag=SkipCERFlag)
    elif commandType.lower() == 'sh':
        dctRcvd = DIAMPKT.createSubscribeNotificationRequest(path, reqDct, diamConnection, eventPass, extraAVP, SkipCERFlag=SkipCERFlag)
    elif commandType.lower() == 'rx':
        dctRcvd = DIAMPKT.createAARequestRx(path, reqDct, diamConnection, eventPass, extraAVP, sendOnlyFlag=sendOnlyFlag, SkipCERFlag=SkipCERFlag) 

    elif commandType.lower() == 'rxstr':
        dctRcvd = DIAMPKT.createSessionTermRequestRx(path, reqDct, diamConnection, eventPass, extraAVP, SkipCERFlag=SkipCERFlag)

    else:
     # Input message not understood...
     sys.exit('unknown commandType parameter sent to sendOneRequest - "' +  commandType + '".  Exiting script')
    
    # Cleanup if session has ended
    if requestType in ['term', 'event']:
        del sessionTimeKeeper[sessionId]
        del sessionTimeKeeper[str(sessionId) + '-reqNum']
   
    # Return the response we got back
    return dctRcvd

#===============================================================================
   
#this function is used to set the test startTime which is used to parse
#mtx_debug.log for any ERRORS that occured during the test runtime
def setTestStartTime(path):
    global currentTestStartTime
    #timeFile = path + '/' + COMMON.resultsDir + '/test_startTime.txt'
    #fp = open(timeFile,'w')
    currentTestStartTime = time.clock()
    #fp.close()

#===============================================================================

def setLogDir():
    global LogDir
    global TxnLogDir

    LogDir = os.getenv("MTX_TXN_LOG_DIR")
    TxnLogDir = LogDir + '/blade_' + os.getenv("MTX_ENGINE_ID") + '_' + \
        os.getenv("MTX_CLUSTER_ID") + '_' + os.getenv("MTX_LOGICAL_BLADE_ID")

#===============================================================================
def initializeTest(path, clean=True):
    global gatewaysConfig
    global logger
    global QACommon
    global DebugLevel

    setLogDir()

    if re.search('subman', path.split('/')[-2]):
        COMMON.disableOutput = False

    QACommon = os.getenv("QADIR") + '/Common/'

    #if (clean):
    #    cleanConfigIniFile(path)

    # clean Summary file
    logger.printSummary(path,details=None)

    #Read Gateways : Diameter and/or REST
    gatewaysConfig = getDiameterRestConfig()

    
    # set the test startTime to parse Error log
    setTestStartTime(path)

    # Setup for a random number (no parameter means to use system time as
    # the seed value)
    random.seed()

    # Ensure resultsDir exists
    try:        os.mkdir(path + '/' + COMMON.resultsDir)
    except:     pass
    
    # Cleanup list of all MDC files
    fp = open( path + '/' + COMMON.resultsDir + '/allMdcFilesList','w')
    fp.close()
    
    if clean:
        parser = optparse.OptionParser()
        parser.add_option("-u", "--user", action='store', type='int', default=1)
        parser.add_option("-x", "--externalId", action='store', type='string', default=None)
        parser.add_option("", "--imsi", action='store', type='string', default=None)
        parser.add_option("", "--msisdn", action='store', type='string', default=None)

        parser.add_option("", "--originhost", action='store', type='string', default="hostA.realmA")
        parser.add_option("", "--originrealm", action='store', type='string', default="realmA")
        parser.add_option("", "--destinationipaddress", action='store', type='string', default="10.22.209.220")
        parser.add_option("", "--exitnow", action='store', type='string', default=True)

        parser.add_option("-d", "--cduser", action='store', type='int', default=0)
        parser.add_option("-c", "--createUser", action='store', type='int', default=1)
        parser.add_option("-f", "--fileName", action='store', type = 'string', help="Name of file to import information")
        parser.add_option("-s", "--subscriber", action='store', help="Subscriber ID", type='string', default='10')
        parser.add_option("-e", "--deviceType", action='store', default="0", type='int', help="Device type")
        parser.add_option("-a", "--accessNumbers", action='store', default=None, type='string', help="AccessNumber")
        parser.add_option("-v", "--serviceId", action='store', default="0", help="service (voice, data, text)")
        parser.add_option("-o", "--offer", action='append', help="offer to add")
        parser.add_option("-b", "--sessionId", action='store', default="0", type='int', help="session id to start test with")
        parser.add_option("-k", "--mscc", action='store', default=0, type='int', help="mscc enabled")
        parser.add_option("-z", "--debug", action='store', default="0", type='int', help="debug Mode")
        parser.add_option("-m", "--members", action='store', default=0, type='int', help="number of members in a group")
        parser.add_option("-l", "--subsc", action='append', help="list of things")
        parser.add_option("-i", "--iteration", action='store', default=0, help="invocation iteration")
        parser.add_option("-q", "--strip", action='store', type='int', default=1, help="strip variable EDR/notification fields")
        parser.add_option("-r", "--events", action='store', type='int', default=1, help="print events")
        parser.add_option("-n", "--notifications", action='store', type='int', default=1, help="print notifications")
        parser.add_option("",   "--diam", action='store', type='int', default=1, help="print diameter")
        parser.add_option("-w", "--tasks", action='store', type='int', default=0, help="print scheduled tasks")
        parser.add_option("-g", "--tracking", action='store', type='int', default=0, help="print balance tracking")
        parser.add_option("-y", "--rest", action='store', type='string', default='MDC', help="rest invocation")
        parser.add_option("-t", "--convertTime", action='store', type='int', default=0, help="convert subman calls to UTC based on system time if not timezone-qualified")
        parser.add_option("", "--tz", action='store', type='string', default=None, help="system time zone to use")

        # Here are some legacy ones that probably should go the same way as the CSV items are handled below...
        parser.add_option("", "--deviceTypeName", action='store', default="generic", type='string', help="Device type name")
        parser.add_option("", "--multiSimShare", action='store', type='string', default='true', help="multi-SIM share flag")
        parser.add_option("", "--pause", action='store', type='string', default='no', help="pause flag setting (yes/no)")
        parser.add_option("", "--custStatus", action='store', type='string', default='non-premium', help="customer status")
        parser.add_option("", "--roamingPartner", action='store', default="0", type='string', help="roaming partner")
        parser.add_option("", "--zone", action='store', default="0", type='int', help="zone")
        
        # Additional items
        parser.add_option("", "--delay", action='store', type='int', default=10, help="delay in minutes for command to finish")
        parser.add_option("", "--randomizeResults", action='store_true', default=False, help="Randomize resuls directory (so can run multiple tests at the same time)")
        parser.add_option("", "--resultsDir", action='store', type='string', default=None, help="Results directory name (so can run multiple tests at the same time)")
        
        # Define additional I/O parameters that are needed for non-standard processing (e.g. customer-specific items)
        parser = CSVQA.addCsvInputArgs(parser)
        
        # Append arguments defined in input files
        args = CSVQA.appendContentsOfCommandLineInputFiles(sys.argv[1:])
        #sys.exit('Done')
        
        # Process command line params
        (options, args) = parser.parse_args(args=args)
        
        # See if anything was left over.
        if args:
                print('ERROR:  unexpected arguments found: ' + str(args))
                sys.exit('Exiting due to failures')
        
        #subscriberId ='User' + str(options.user)
        #subscriberIdCreatedemo ='CDUser' + str(options.user)
    else:
        options = None
        args = None

    # Get timezone (once per invocation)
    getTimeZone(options.tz)
    
    config = configparser.ConfigParser()
    configFile = path + '/config.ini'
    if os.path.exists(configFile):
        config.read(path +'/config.ini')
        users = config.sections()
        #    print users
    else:
        # No config file.  Set to None
        users = None

    QAV3.setVersion(options.rest, urlPlus=options.overrideURL)
    
    # Set updates for baisc authentication
    if options.httpAuthUsername:
        restV3.basicAuthUserName = options.httpAuthUsername
        restV3.basicAuthPassword = options.httpAuthPassword
        rest_json.basicAuthUserName = options.httpAuthUsername
        rest_json.basicAuthPassword = options.httpAuthPassword

    # use subscriber REST urls by default
    QAV3.setSubUrl("subscriber")
    
    # Get structure for Subman calls
    v3Inst = getSubscInterface()

    # Set system time zone in timeToMdcTime
    # options.timeZone can take priority over options.tz.
    if options.timeZone: options.tz = options.timeZone
    setSystemTimeZone(options.tz)

    # Set global debug level
    DebugLevel = int(options.debug)
    
    # Copy msisdn and imsi options to their original hoems if those not specified
    if options.msisdn and not options.accessNumbers: options.accessNumbers = options.msisdn
    if options.imsi and not options.deviceId: options.deviceId = options.imsi
    
    # If msisdn and imsi specified, or accessNumbers and deviceId, then set separate AccessNumbers
    if (options.msisdn or options.accessNumbers) and (options.imsi or options.deviceId): options.separateAccessNumbers = True
   
    return(config, users, options, args, v3Inst, logger)

#============================================================
def setSystemTimeZone(tz=None):
   if tz: MDCTIME.systemTimeZone = tz
   else: 
    try:
        timeZoneFileName = os.getenv("QADIR") + '/Common/timeZone'
        timeZoneFile = open(timeZoneFileName, 'r')
        timeZone = (timeZoneFile.readline()).rstrip()
        MDCTIME.systemTimeZone = timeZone
        timeZoneFile.close()

    except IOError:
        MDCTIME.systemTimeZone = 'Etc/UTC'

   print('Test framework timezone is set to: ' + MDCTIME.systemTimeZone)
   
   return MDCTIME.systemTimeZone
   
#============================================================
def setEventTypeTree():
    try:
        confDir = os.path.abspath(os.path.expandvars(os.getenv('MTX_CONF_DIR', '.')))
        eventTypeTreeFile = open(confDir + '/eventTypes', 'r')
        eventTypes = ''
        while 1:
            line = eventTypeTreeFile.readline()
            if not line:
                break
            eventTypes += line
        eventTypeTreeFile.close()
        EVENTS.EventTypeTree = ElementTree.XML(eventTypes)
    except:
        print('Warning - problem parsing event type tree')

#============================================================
def updateCsrData(accessNumber):
        # Get CSR host information
        (hostname, hostport) =  getCsrData()
        
        # If not defined, then exit
        if not hostname: return
        
        # Sed the file
        cmd = 'sed "s/ACCESSNUMBER/' + str(accessNumber) + '/" ' + os.path.abspath(os.path.expandvars(os.getenv('QACOMMON', '.'))) + '/auth > auth.exec'

        # Run the command
        #print 'Running command: ' + cmd
        runCmd(cmd)

        # Build command string to invoke the REST command
        cmd = 'curl -s -X POST -d @auth.exec http://' + hostname + ':' + hostport + '/rsgateway/data/v3 --header "Content-Type:text/xml"'

        # Run the command
        #print 'Running command: ' + cmd
        runCmd(cmd)
        
        # Remove the temp file
        cmd = 'rm -f auth.exec'
        #print 'Running command: ' + cmd
        runCmd(cmd)
        
        return
        
#============================================================
def getCsrData():
        try:
                hostName=gatewaysConfig.get('CSR', 'hostName')
                hostPort=gatewaysConfig.get('CSR', 'hostPort')
        except:
                hostName = hostPort = None
        
        return hostName, hostPort

#============================================================
def getTrace():
    if gatewaysConfig.get('DATACONTAINER', 'traceMessages') == 'True':
        return True
    else:
        return False

#============================================================
def getSubscInterface(mode = 'Normal',  basePath = None):
    v3Inst = None
    if mode == 'BuildRequest' :
        v3Inst = RESTV3.SubscriberManagementV3Client(trace = getTrace(),
            hostName=gatewaysConfig.get('DATACONTAINER', 'hostName'),
            hostPort=int(gatewaysConfig.get('DATACONTAINER', 'hostPort')), mode = mode)
    else :
        if QAV3.restVersion == 'MDC':
            v3Inst = RESTV3.SubscriberManagementV3Client(trace = getTrace(),
                hostName=gatewaysConfig.get('DATACONTAINER', 'hostName'),
                hostPort=int(gatewaysConfig.get('DATACONTAINER', 'hostPort')), mode = mode)
            v3Inst.openConnection()

        elif QAV3.restVersion == 'REST' or QAV3.restVersion == 'JSON' or QAV3.restVersion == 'OPENAPI':
            if not basePath: v3Inst = restV3.RestClient(gatewaysConfig.get('REST', 'restServer'),gatewaysConfig.get('REST', 'restPort'))
            else:            v3Inst = restV3.RestClient(gatewaysConfig.get('REST', 'restServer'),gatewaysConfig.get('REST', 'restPort'), basePath = basePath)
        else:
            print('unsupported Subscriber Interface Used: JAVA!!!')

    return v3Inst

#============================================================
def getSubscInterfaceMDC(mode = 'Normal'):
    #Read Gateways : Diameter and/or REST
    gatewaysConfig = getDiameterRestConfig()

    v3Inst = None
    v3Inst = RESTV3.SubscriberManagementV3Client(
        hostName=gatewaysConfig.get('DATACONTAINER', 'hostName'),
        hostPort=int(gatewaysConfig.get('DATACONTAINER', 'hostPort')), mode = mode)
    v3Inst.openConnection()
    return v3Inst
    
#===============================================================================
def getFileLineCount(service):
    global path
    global msccFlag

    if service != 'diam' and service != 'notif' and service != 'tasks' and service != 'txn' and service != 'tracking':
        print("Invalid argument passed to getFileLineCount(), requires 'diam', 'notif', 'tasks' or 'txn'")
        sys.exit()

    if service == 'diam':
        if msccFlag:
            fileName = path + '/' + COMMON.resultsDir + '/ECT_diameter_' + getTestName(path) + '_mscc.txt'
        else:
            fileName = path + '/' + COMMON.resultsDir + '/ECT_diameter_' + getTestName(path) + '.txt'
    elif service == 'notif':
        fileName = TxnLogDir + '/transactions_' + os.getenv("MTX_ENGINE_ID") + '_' + \
                        os.getenv("MTX_CLUSTER_ID") + '_' + os.getenv("MTX_LOGICAL_BLADE_ID") + '.log'
    elif service == 'tasks':
        fileName = TxnLogDir + '/transactions_' + os.getenv("MTX_ENGINE_ID") + '_' + \
                        os.getenv("MTX_CLUSTER_ID") + '_' + os.getenv("MTX_LOGICAL_BLADE_ID") + '.log'
    elif service == 'txn':
        fileName = TxnLogDir + '/transactions_' + os.getenv("MTX_ENGINE_ID") + '_' + \
                os.getenv("MTX_CLUSTER_ID") + '_' + os.getenv("MTX_LOGICAL_BLADE_ID") + '.log'
    elif service == 'tracking':
        fileName = TxnLogDir + '/transactions_' + os.getenv("MTX_ENGINE_ID") + '_' + \
            os.getenv("MTX_CLUSTER_ID") + '_' + os.getenv("MTX_LOGICAL_BLADE_ID") + '.log'


    lCount = 0
    if os.path.exists(fileName):
        lCount = runCmd("wc -l " + fileName + " | cut -f1 -d' '")
        if lCount == '':
            return 0
        return int(lCount)
    else:
        return 0

    return int(lCount)


#===============================================================================
def updateFilePointer(service):
    global path
    global diamFileLine
    global txnLogLine
    global notifLogLine
    global tskLogLine
    global trackLogLine

    if service != 'diam' and service != 'notif' and service != 'tasks' and service != 'txn' and service != 'tracking':
        print("Invalid argument passed to updateFilePointer(), requires 'diam', 'notif', 'tasks','txn' or 'tracking'")
        sys.exit()

    if service == 'diam':
        time.sleep(.05)
    elif service == 'notif':
        time.sleep(.1)
    elif service == 'tasks':
        time.sleep(.1)
    elif service == 'txn':
        time.sleep(.1)
    elif service == 'tracking':
        time.sleep(.1)


    # get previous log pointer value
    lCount = getFileLineCount(service)
    if service == 'diam':
        oldVal = diamFileLine
    elif service == 'notif':
        oldVal = txnLogLine
    elif service == 'tasks':
        oldVal = tskLogLine
    elif service == 'txn':
        oldVal = notifLogLine 
    elif service == 'tracking':
        oldVal = trackLogLine

    if oldVal == lCount:
        return -1

    if service == 'diam':
        diamFileLine = lCount
    elif service == 'notif':
        txnLogLine = lCount
    elif service == 'tasks':
        tskLogLine = lCount
    elif service == 'txn':
        notifLogLine = lCount
    elif service == 'tracking':
        trackLogLine = lCount

    return oldVal


#===============================================================================
def parseActions(service, testTag, diffEvents=False, stripFields=False):
    global LogDir
    global TxnLogDir
    global TskLogDir
    global path
    global msccFlag

    if service != 'diam' and service != 'notif' and service != 'tasks' and service != 'txn' and service != 'tracking':
        print("Invalid argument passed to parseActions(), requires 'diam', 'notif', 'txn' or tracking")
        sys.exit()

    if service == 'diam':
        if msccFlag:
            inFileName = path + '/' + COMMON.resultsDir + '/ECT_diameter_' + getTestName(path) + '_mscc.txt'
        else:
            inFileName = path + '/' + COMMON.resultsDir + '/ECT_diameter_' + getTestName(path) + '.txt'
        outFileName = path + '/' + COMMON.resultsDir + '/' + testTag + '_diameter'
        tmpFileName = outFileName
    elif service == 'notif':
        outFileName = path + '/' + COMMON.resultsDir + '/' + testTag + '_notifications'
        inFileName = TxnLogDir + '/transactions_' + os.getenv("MTX_ENGINE_ID") + '_' + \
                        os.getenv("MTX_CLUSTER_ID") + '_' + os.getenv("MTX_LOGICAL_BLADE_ID") + '.log'
        tmpFileName = path + '/' + COMMON.resultsDir + '/tmpNotifLog'
    elif service == 'tasks':
        outFileName = path + '/' + COMMON.resultsDir + '/' + testTag + '_tasks'
        inFileName = TxnLogDir + '/transactions_' + os.getenv("MTX_ENGINE_ID") + '_' + \
                        os.getenv("MTX_CLUSTER_ID") + '_' + os.getenv("MTX_LOGICAL_BLADE_ID") + '.log'
        tmpFileName = path + '/' + COMMON.resultsDir + '/tmpTasksLog'
    elif service == 'txn':
        outFileName = path + '/' + COMMON.resultsDir + '/' + testTag + '_events'
        inFileName = TxnLogDir + '/transactions_' + os.getenv("MTX_ENGINE_ID") + '_' + \
                        os.getenv("MTX_CLUSTER_ID") + '_' + os.getenv("MTX_LOGICAL_BLADE_ID") + '.log'
        tmpFileName = path + '/' + COMMON.resultsDir + '/tmpTxnLog'
    elif service == 'tracking':
        outFileName = path + '/' + COMMON.resultsDir + '/' + testTag + '_baltracking'
        inFileName = TxnLogDir + '/transactions_' + os.getenv("MTX_ENGINE_ID") + '_' + \
                os.getenv("MTX_CLUSTER_ID") + '_' + os.getenv("MTX_LOGICAL_BLADE_ID") + '.log'
        tmpFileName = path + '/' + COMMON.resultsDir + '/tmpTrackingLog'


#    logger.printRes(path, 'allMdcFilesList', outFileName)

    oldVal = updateFilePointer(service)
    lCount = getFileLineCount(service)
    if oldVal == -1 or not os.path.exists(inFileName):
        outFile = open(outFileName, 'w')
        print('', file=outFile)
        outFile.close()
        return (None, None, None, None, None)

    runCmd("sed -n " + str(oldVal + 1) + "," + str(lCount) + "p " + inFileName + " > " + tmpFileName)

    if service == 'txn':
        (initiatorOid, initiatorExternalId, initiatorDeviceOid, sponsorOid, sponsorExternalId) =\
            EVENTS.printEvents(testTag, diffEvents, stripFields)
        runCmd("rm " + tmpFileName)
        return (initiatorOid, initiatorExternalId, initiatorDeviceOid, sponsorOid, sponsorExternalId)

    elif service == 'notif':
        NOTIFICATIONS.printNotifications(testTag, stripFields)
        runCmd("rm " + tmpFileName)

    elif service == 'tasks':
        #print "service == ", service
        # grep tasks workorders to avoid duplicates        
        cmd = "grep \"\[,<1,1,1,343\" " + tmpFileName + " > 1.out"
        runCmd(cmd)
        cmd = "mv 1.out " + tmpFileName
        runCmd(cmd)
        TASKS.printTasks(testTag, stripFields)
        runCmd("rm " + tmpFileName)
    
    elif service == 'tracking':
        TRACKING.printTrackingRecords(testTag, diffEvents, stripFields)
        runCmd("rm " + tmpFileName)

#===============================================================================
def getsubscriber(options, users):

    # added for create_demo
    #createDemoFile = path +  '/inAddSubscriberSet_1_Part_1.txt'
#    print 'OPTIONS = ' + str(options.user)
    if (options.cduser):
        subscriberId = 'CDUser' + str(options.cduser)
    else :
        subscriberId = 'User' + str(options.user)

    if (subscriberId not in users) :
        sys.exit(subscriberId + ' : no such user!')

    return subscriberId


#===============================================================================
def get_key_data(config, options, path, users):
    global dctGeneral
    global MSCC
    global stripFields

    dctGeneral =  getSubsc(config,'GENERAL')
    #print dctGeneral

    # Get session id
    if options.sessionId > 0:
        sessionId = options.sessionId
        dctGeneral['sessionid'] = sessionId
    
    # Always check that the user in question is in the config file.  May use it for some of the data
    if users:
        userId =  getsubscriber(options, users)
    else:
        userId=None
    
#    print '################ using subsc=' + str(userId)

    # Where to get data depends on if it's input on the command line 
    # Start with external ID (top of the heap).  
    # This will change when we support external IDs as non-numeric strings...
    if not options.externalId:
        externalId = options.subscriber
        options.externalId = externalId
    else:
        # Use input data
        externalId = options.externalId

    # Subscriber default is in option line, so will be set no matter what.  Nothing special to check for here.
    
    # Next is the device ID.
    if options.deviceId:
        deviceId = options.deviceId
    elif options.imsi:
        deviceId = options.imsi
        options.deviceId = deviceId
    else:
        deviceId = options.subscriber
        options.deviceId = deviceId
    
    # May have input msisdn instead of accessNumbers
    if (not options.accessNumbers) and options.msisdn: options.accessNumbers = options.msisdn
    dctGeneral['accessNumber'] = options.accessNumbers

    # Sanity check here.  If no external ID, device ID, or no input accessNumbers, then you have messed up the config.
    if not (externalId or deviceId or options.accessNumbers):
        print('ERROR:  Command did not specify external ID (-x), subscriber ID (-s), device ID (--msisdn or --deviceId) or access number (--imsi or --accessNumbers) and the config file had no external ID line.  Can\'t continue.')
        sys.exit(1)

    # Where to get data depends on if it's input on the command line 
    if options.mscc==1:
#        print 'setting options mscc'
        MSCC = 2

    if options.deviceType == 0 and userId:
        # Get data from config file
        deviceType = eval(config.get(userId, 'deviceType'))[0]
        options.deviceType = deviceType
    else:
        # Use input data
        deviceType = options.deviceType

    if options.serviceId == '0':
        if userId:
                # Get data from config file
                serviceId = eval(config.get(userId, 'deviceTypeT'))[0]
        else:
                serviceId = 'data'
        options.serviceId = serviceId
    else:
        # Use input data
        serviceId = options.serviceId

    if not options.offer :
        if userId:
         # Get data from config file
         offerIdList = eval(config.get(userId, 'offerId'))
         dctGeneral['offerId'] = offerIdList
         if type(offerIdList) == type(list()):
            offerId = offerIdList
         else:
            offerId = config.get(userId, 'offerId')
        else:
            offerId=None
    else:
        # Use input data
        offerId = getOptionsVal(options.offer, 'offerId')

    # CSV processing uses the command line parameter "offerId" (versus "offer" above).
    # If this is specified, then go off and process that input.
    if options.offerId and options.offerId != '0':
        offerId = CSVQA.convertToolListToPythonList(options.offerId)

    if options.members == 0:
       if userId: 
        # Get data from config file
        if (config.has_section('GENERAL')):
            sectionItems = config.items('GENERAL')
            if 'members' in sectionItems:
                members = config.get('GENERAL', 'members')
            else:
                members = 0
        else:
            members = 0
       else:
            members=0
       options.members = members
    else:
        # Use input data
        members = options.members


    if options.events:
        updateFilePointer('txn')
        dctGeneral['events'] = 1
#        setEventTypeTree()
        eventOutputFileName = path + '/' + COMMON.resultsDir + '/ECT_events_' + os.path.basename(path) + '.txt' 
        if os.path.exists(eventOutputFileName):
            runCmd('rm ' + eventOutputFileName)
    else:
        dctGeneral['events'] = 0

    if options.notifications:
        updateFilePointer('notif')
        dctGeneral['notifications'] = 1
        notifOutputFileName = path + '/' + COMMON.resultsDir + '/ECT_notifications_' + os.path.basename(path) + '.txt' 
        if os.path.exists(notifOutputFileName):
            runCmd('rm ' + notifOutputFileName)
    else:
        dctGeneral['notifications'] = 0

    if options.tasks:
        updateFilePointer('tasks')
        dctGeneral['tasks'] = 1
        tasksOutputFileName = path + '/' + COMMON.resultsDir + '/ECT_tasks_' + os.path.basename(path) + '.txt' 
        if os.path.exists(tasksOutputFileName):
            runCmd('rm ' + tasksOutputFileName)
    else:
        dctGeneral['tasks'] = 0

    if options.tracking:
        updateFilePointer('tracking')
        dctGeneral['tracking'] = 1
#        setEventTypeTree()
        eventOutputFileName = path + '/' + COMMON.resultsDir + '/ECT_tracking_' + os.path.basename(path) + '.txt'
        if os.path.exists(eventOutputFileName):
            runCmd('rm ' + eventOutputFileName)
    else:
        dctGeneral['tracking'] = 0

    if options.diam:
        updateFilePointer('diam')
        dctGeneral['diam'] = 1
    else:
        dctGeneral['diam'] = 0

    if options.strip:
        stripFields = True
    else:
        stripFields = False

    MDCTIME.convert = options.convertTime

#    print 'subscriberId = ' + userId
#    print 'deviceId = ' + str(deviceId)
#    print 'externalId = ' + str(externalId)
#    print 'deviceType = ' + str(deviceType)
#    print 'serviceId = ' + serviceId
#    print 'offerId = ' + str(offerId)
#    print 'amount = ' + str(amount)
#    print 'members-group = ' + str(members)
    dctSubsc =  getSubsc(config,'User1')
    if options.subsc:
        getSubscList(options)
        dctGeneral['subscList'] = getSubscList(options)

    # add section for sigtran in config.ini
  #  sigtranDct = {}
  #  sigtranDct = getSubsc(gatewaysConfig, 'SIGTRAN')
    #print "sigtranDct", sigtranDct
  #  if sigtranDct != {}:  
  #      dctGeneral['SIGTRAN']= sigtranDct
    
    return (userId, deviceId, externalId, deviceType, serviceId, offerId, dctGeneral)

#===============================================================================

def getOptionsVal(optionVal, optionName, itemType='int'):
    global dctGeneral
    optionList = eval(str(optionVal[0]))
    if type(optionList) == type(tuple()):
        val = str(optionList[0])
    else:
        val = str(optionList)
    #print optionList
    if itemType == 'string':
        dctGeneral[optionName] = castStringtoListOfString(optionList)
    else:
         dctGeneral[optionName] = (optionList)
    #print '????????????????????????????????????'
    #print  dctGeneral
    #print '????????????????????????????????????'
    return(val)
#===============================================================================
#util function to check if we need debug information attached to the logs
def checkDbgMsg(debugOpt, st1, st2):
    #if (debugOpt):
#    print debugOpt
    return('!'+ st1 + '_' + st2)   #workaround so we don't want to break older tests
    #return None

#===============================================================================
def getDiameterRestConfig():
    QACommon = os.getenv("QADIR") + '/Common/'
    configIniFile = QACommon + 'config.ini'
    if not os.path.exists(configIniFile):
        configIniFile = os.getenv("MYCONFIGINI")
        configIniFile = './config.ini'
        if not configIniFile == None:
            if not os.path.exists(configIniFile):
                print('cannot find the config ini in Common or env "MYCONFIGINI"')
                sys.exit(1)
        else:
            print('cannot find the config ini in Common or env "MYCONFIGINI"')
            sys.exit(1)

#    print 'reading configuration data from ' + str(configIniFile) + '!'
    configG = configparser.ConfigParser()
    configG.read(configIniFile)
    return (configG)

#===============================================================================
def diameterClient(diameterDestinationIpAddress=None, commandType=None):
    # If input specified a diameter client, then use that, else get from config file.
    if diameterDestinationIpAddress: 
        # Hostname is the first part of the parameter
        hostname = diameterDestinationIpAddress.split(':')[0]
        
        # See if someone tried to be silly and enter just a port...
        if not hostname: hostname = gatewaysConfig.get('DIAMETER','hostname')
        
        # If there's a ":" character, then the port is also included.
        # System will error if input does not contain the port value.
        if diameterDestinationIpAddress.count(':'): 
                # Get second part of parameter
                port = int(diameterDestinationIpAddress.split(':')[1])
                
        else: port = int(gatewaysConfig.get('DIAMETER','port'))
    else:
        # Nothing input.  Use defaults
        hostname = gatewaysConfig.get('DIAMETER','hostname')
        port = int(gatewaysConfig.get('DIAMETER','port'))
    
    diamConnection = DIAM.DiameterClientConnection(hostname, port, tracePackets = False)

    return(diamConnection)

#===============================================================================
#this function will extract other SECTIONS from the config.ini
#it returns a dictionary of all items in that section
def getSubsc(config,section):
    dct = {}
    if (config.has_section(section)):
        sectionItems=config.items(section)
        #print sectionItems
        for xx in  sectionItems:
            dct[xx[0]] = eval(xx[1])
    return dct

#===============================================================================
#this function is used by main test driver to setup a uniq sessionIDs for all the tests 
def initializeSessionIds(cpath,test,sessionId):
    testConfig = test + '/config.ini'
    testConfigNew =  test + '/configNew.ini'
    #testConfigNewp = open (testConfigNew,'w')
    config = configparser.ConfigParser()
    os.chdir(test)
    config.read(testConfig)
    if config.has_section('GENERAL'):
#        print "--------- "
        cmd = "sed -e 's/sessionId = .*/sessionId = " + str(sessionId) + '/\' ' + testConfig+  ' > mod.tmp'
        os.system(cmd)
        os.system("mv mod.tmp " + testConfig)
    else:
        os.system('echo [GENERAL] > ' + testConfigNew)
        os.system('echo sessionId = ' + str(sessionId)+ ' >> ' + testConfigNew)
        os.system('echo >> ' + testConfigNew)
        os.system('cat ' + testConfigNew + ' ' + testConfig + "> ./all\.tmp")
        os.system('mv ./all\.tmp ' + testConfig)
        os.system("cat " + testConfig)
    os.chdir(cpath)
    
#===============================================================================
#this fnction used to run bash scripts.        
def runCmd(cmd, output='delayed'):
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    out = p.stdout.read().strip()
    #fix for python3, covert byte to str 
    if isinstance(out, bytes):
        out = out.decode('utf-8')

    return out  #This is the stdout from the shell command
#===============================================================================
#function to return the test name based on the directory name
def getTestName(path):
    return(path.split('/')[-1])
#===============================================================================
#not needed nor should be used
def setSystemClock(timeStamp = None):
    return

#==========================================================
def iterateUsageIncDevice(count, deviceId, serviceId, use, startTime, sessionId, testName, extraAVP = {}, tag = None, deviceIdOffset = 0, eventPass = True, saveInit = True, saveTerm = True, queryTime=None):
    i = 0
    if (deviceIdOffset == 0):  #increment a deviceId starting with an offset
        deviceIdu = deviceId
    else:
        deviceIdu = str(deviceIdOffset)

    tag1 = tag
    while ( i < count):
        if tag == None:
            tag1 = '_iter' + str(i) 
        else:
            tag1 = tag + '_' + str(i) 
        sendSaveInitTerm(deviceIdu, serviceId, use, tag1, startTime, sessionId, testName, eventPass, extraAVP, saveInit, saveTerm, queryTime=queryTime)
        i = i + 1
        deviceIdu = str(int(deviceIdu) + 1)
        sessionId = sessionId + 1
    return sessionId

#==========================================================
def sendSaveInitTerm(deviceId, serviceId, use, tag, startTime, sessionId, testName, eventPass = True, extraAVP={}, saveInit = True, saveTerm = True, queryTime = None):
    addList = None
    omitList = None

    use = use
    if 'add' in extraAVP:
        addList = extraAVP['add']
    if 'omit' in extraAVP:
        omitList = extraAVP['omit']

#   print 'sending init id= ' + str(deviceId) + 'and sid=' + str(serviceId) + 'and ' + str(startTime)
    sendOneRequest(deviceId = deviceId, reqamount = use, usedamount = 0,
                requestType = 'initial', sessionId = sessionId,
                serviceId = serviceId, startTime = startTime, eventPass = eventPass, extraAVP = extraAVP)
    if saveInit:
        saveMDC(deviceId, testName + '_' + tag + '_initial',
                    '!' + str(startTime)+ '_' + str(use), queryTime = queryTime)

    #restore omit/add lists
    if addList != None:
        extraAVP['add'] = addList

    if omitList != None:
        extraAVP['omit'] = omitList

    # increase time by 600 secs of the previous time
    sendOneRequest(deviceId = deviceId, reqamount = 0, usedamount = use,
                    requestType = 'term', sessionId = sessionId,
                    serviceId = serviceId, startTime = startTime, eventPass = eventPass, extraAVP = extraAVP)


    if saveTerm:
        saveMDC(deviceId, testName + '_' + tag + '_term',
                    '!' + str(startTime)+ '_' + str(use), queryTime = queryTime)

#==========================================================
def iterateUsageSameDevice(count, deviceId, serviceId, use, startTime, sessionId, testName, tag, extraAVP = {}, eventPass = True, saveInit = True, saveTerm = True, queryTime=None):
    i = 0
    tag1 = tag
    while ( i < count):
        if tag == None:  #if tag is None , the next time you call it you will overwrite the files
            tag1 = '_iter' + str(i) 
        else:
            tag1 = tag + '_' + str(i)

        sendSaveInitTerm(deviceId, serviceId, use, tag1, startTime, sessionId, testName, eventPass, extraAVP, saveInit, saveTerm, queryTime=queryTime)
        i = i + 1
        sessionId = sessionId + 1
    return sessionId

#==========================================================
# persist the dictionatry in the results dir
def pickleAnyDictionary(path, pickleFile, tdictionary):
    dctName = path + '/' + COMMON.resultsDir + '/' + str(pickleFile) 
    myPickleFile = open(dctName,'wb')
    print('tdict = ',tdictionary)
    pickle.dump(tdictionary, myPickleFile)
    myPickleFile.close()

#==========================================================
def printPickledDictionary(path,dctFile):
    dctName = path + '/' +dctFile
    if not (os.path.isfile(dctName)):
        print('printPickledDictionary: file '+ dctName + ' missing!')
        return
    pkFile = open(dctName,'rb')
    unpickledDictionary= pickle.load(pkFile)
    pprint.pprint(unpickledDictionary)
    pkFile.close()

#==========================================================
def printDct(dct):
    for val in dct:
        print(val + '=>' +  dct[val]) 

#==========================================================
def pauseCheck(pauseFlag, prompt=None):
    foo = ''
    
    # Be user friendly as to what we accept for pausing :-).
    if pauseFlag.lower() in ["yes", "on", "true"]:
        # Spacing
        print(' ')
        
        # If prompt entered use it, else use canned string
        if not prompt: prompt = 'Press enter to continue: '
        try: eval(input(prompt))
        except: pass
        
        # Spacing
        print(' ')
    
    # Return whatever was enterd - may be useful for non-pause scenarios
    return foo

#==========================================================
def getTimeZone(tz):
        # parse config file and save system time zone
        confDir = os.path.abspath(os.path.expandvars(os.getenv('MTX_CONF_DIR', '.')))
        configFileName = confDir + '/mtx_config.xml'
        if (os.path.exists(configFileName)):
            saveTimeZone(configFileName, tz)
        else:
            print('Failure saving system time zone!')
            if not tz: tz = 'Etc/UTC'
            os.putenv("TZ", tz)


#==========================================================
def saveTimeZone(configFileName, tz):
    qaDir = os.getenv("QADIR")
    timeZoneFileName = qaDir + '/Common/timeZone'
    
    try:
        # Just get the data from the file using grep (only ever one item in the file)
        cmd = 'grep system_time_zone_id /opt/mtx/conf/mtx_config.xml | cut -f2 -d">" | cut -f1 -d"<" > ' + timeZoneFileName
        subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        
        # Old code...
        '''
        systemTimeZonePattern = re.compile(r'.*<system_time_zone_id>.*')
        configFile = open(configFileName, 'r')
        while 1:
            line = configFile.readline()
            if not line:
                break
            if systemTimeZonePattern.match(line):
                removeTagPattern = re.compile(r'<.*?>')
                timeZone = removeTagPattern.sub('', line)
                stripSpacesPattern = re.compile(r'\s+')
                timeZone = stripSpacesPattern.sub('', timeZone)
                cmd = 'echo "' + timeZone + '" > ' + timeZoneFileName
                subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
                break

        configFile.close()
        '''

    except IOError:
        if not tz: tz = 'Etc/UTC'
        cmd = 'echo "' + tz + '" > ' + timeZoneFileName
        subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)

#===============================================================================
# this function will save the Gy diameter dictionary to ECT files
# for diff verification

def saveDiam(diamDct=None,testName=None,keepList=None):

    # Skip if performance is enabled
    if not DIAMU.diameterFileDebugFlag: return
    
    ectFile = 'ECT_'+ testName + '.dat'
    if keepList :  #save the avp in the list only
        for avp in keepList :
           if avp in diamDct:
               #save the diam value
               logger.printRes(path, ectFile, avp + ' : ' + diamDct[avp] , overwrite = False)
           else :
               logger.printRes(path, ectFile, avp + ' : missing' , overwrite = False)
    else :
        for diam in diamDct :
            logger.printRes(path, ectFile, diam + ' : ' + diamDct[diam] , overwrite = False)
    logger.printRes(path, "allMdcFilesList", os.getcwd()+'/' + COMMON.resultsDir + '/'+ectFile )

#===============================================================================
# this function will save the Sy/snr diameter dictionary to ECT files
# for diff verification

def savePCRF(diamDct=None,testName=None,pcrfType='SLR',stripList=None):

    # Skip if performance is enabled
    if not DIAMU.diameterFileDebugFlag: return
    
    pcrfFile = 'ECT_'+ testName + '.dat'
    for diam in diamDct :
        if "Charging-Rule-Name" in diam :
             tmpList = str(binascii.unhexlify(diamDct[diam]).decode('utf-8')).split("_")
            #only chop off last element , if there are more than one element in the list
             if len(tmpList) > 1 :
                diamDct[diam] = str("_".join(tmpList[:-1])) 

        if stripList :
            for avp in stripList :
               if avp in diamDct:
                  diamDct[avp] = ''

        logger.printRes(path, pcrfFile, diam + ' : ' + diamDct[diam] , overwrite = False)
    logger.printRes(path, "allMdcFilesList", os.getcwd()+'/' + COMMON.resultsDir + '/'+pcrfFile )

#==========================================================
# this function saves MDC or REST event query result in XML format
# and also remove the fields in the excludeList
def saveEventQueryResult(queryResult, outFileName, convert=True, override=False):
    # Skip if performance is enabled and not overridden (i.e. specifically want event data saved)
    if not DIAMU.diameterFileDebugFlag and str(override) not in ['1', 'True']: return
    
    # If in MDC format then need to translate to something readable
    if isinstance(queryResult, bytes):
        queryResult = queryResult.decode('utf-8')
       
    if QAV3.restVersion == 'MDC':
        if convert: queryResult = queryResult.printXml()
        gateway = '_MDC'
    elif QAV3.restVersion == 'JSON':
        saveEventQueryResultJson(queryResult, outFileName)
        return
    else:
        gateway = '_REST'
        #strip dynamic values to pass verification    
        queryResult = re.sub("Time>(.*)<", "Time><", queryResult )
        
        # Zero some fields (not sure why they'r enot exluded below...)
        for item in ['InitiatorExternalId','WalletOwnerExternalId','InitiatorPrimaryUserExternalId']: queryResult = re.sub(item+">(.*)<", item+">0<", queryResult, )
        
        # Change time values
        queryResult = re.sub("[0-9]+-[0-9]+-[0-9]+-[0-9]+", "0-0-0-0", queryResult )
        queryResult = re.sub("[0:9]+:[0-9]+:[0-9]+:[0-9]+", "0:0:0:0", queryResult )
        
    path = os.getcwd()
    tmpEventFileName = os.getcwd() + '/' + COMMON.resultsDir + '/eventQueryResult.txt'
    # save raw query result to temp file
    tmpEventFile = open(tmpEventFileName, 'w')
    print(queryResult, file=tmpEventFile) 
    tmpEventFile.close()

    excludeList = [     'EventTime', 'InitiatorId', 'InitiatorExternalId', 'InitiatorDeviceId',
                        'InitiatorDeviceExternalId', 'InitiatorWalletId', 'WalletId', 'EventId'
                  ]
    outputFileName = os.getcwd() + '/' + COMMON.resultsDir + '/' + outFileName + gateway
    # put the result for basic validation
    #testErrorLogger.printRes(path, outFileName, str(queryResult), overwrite=True)
    outputFile = open(outputFileName, 'w')
    print(xml_utils.transformDoc(tmpEventFileName, excludeList), file=outputFile)
    logger.printRes(path, 'allMdcFilesList', path + '/' + COMMON.resultsDir + '/' + outFileName + gateway)

def cleanTransactionLog():

    setLogDir()
    fileName = TxnLogDir + '/transactions_' + os.getenv("MTX_ENGINE_ID") + '_' + \
                        os.getenv("MTX_CLUSTER_ID") + '_' + os.getenv("MTX_LOGICAL_BLADE_ID") + '.log'
    if os.path.exists(fileName):
       runCmd('echo "" > ' + fileName)
#==========================================================
#This function used to rotate the transaction log file
#
def rotateTransactionLog():

    setLogDir()
    currentTime =  MDCTIME.getTime()
    currentTime = MDCTIME.stripDecimal(currentTime)
    print(currentTime) 
    print('TxnLogDir =',TxnLogDir)
    fileName = TxnLogDir + '/transactions_' + os.getenv("MTX_ENGINE_ID") + '_' + \
                        os.getenv("MTX_CLUSTER_ID") + '_' + os.getenv("MTX_LOGICAL_BLADE_ID") + '.log'
    roratedFileName = TxnLogDir + '/transactions_' + os.getenv("MTX_ENGINE_ID") + '_' + \
                        os.getenv("MTX_CLUSTER_ID") + '_' + os.getenv("MTX_LOGICAL_BLADE_ID") + '_' +  str(currentTime) + '.log' 
    print('fileName=', currentTime)
    print('roratedFileName=', roratedFileName)
    #copy old transaction log file to be log file with currrent timestamp, set the transaction log file size to zero
    if os.path.exists(fileName):
       runCmd('cp ' + fileName + ' ' + roratedFileName + ' ; echo "" > ' + fileName)

#==========================================================
#This is a function that checks the Event Extractor Gtc Sorter 
def checkEventExtractorGtcSorter(lowGtc, highGtc, currentCount, maxCount, maxSize):

    #Checks important information.
    bufferEmpty = currentCount == 0
    bufferThrottlingWorking = maxCount != maxSize

    return bufferEmpty and bufferThrottlingWorking

#==========================================================
#This is an continually growing parent function that evaluates the condition of the event streaming server by collecting and parsing information and calling children functions to evaluate the information.
#As the developers are working on porting tests to print_blade_stats.py and sysdump, this function and new children function will grow/be added
def checkEventStreamingServer(publishing_engine_number = 1, publishing_cluster_number =2 , publishing_blade_number=1, sleepTime = 0):

    #Sleep to give the publishing blade time to collect information as its going through the streaming server
    time.sleep(sleepTime)



    #Collecting all of the information. Explicit for future debugging purposes
    printBladeStatsStreamServerOutput = runCmd('print_blade_stats.py --stream -e {} -c {} -b {}'.format(publishing_engine_number, publishing_cluster_number, publishing_blade_number))



    #Parsing all the information. Explicit for future debugging purposes
    eventExtractorGtcSorterInformation = printBladeStatsStreamServerOutput.split('\n')[-1].split()
    eventExtractorGtcSorterLowGtc = int(eventExtractorGtcSorterInformation[0])
    eventExtractorGtcSorterHighGtc = int(eventExtractorGtcSorterInformation[1])
    eventExtractorGtcSorterCurrentCount = int(eventExtractorGtcSorterInformation[2])
    eventExtractorGtcSorterMaxCount = int(eventExtractorGtcSorterInformation[3])
    eventExtractorGtcSorterMaxSize = int(eventExtractorGtcSorterInformation[4])

    
     
    #All of the children evaluate functions. Explicit for future debugging purposes
    returnCodeEventExtractorGtcSorter = checkEventExtractorGtcSorter(eventExtractorGtcSorterLowGtc,eventExtractorGtcSorterHighGtc,eventExtractorGtcSorterCurrentCount,eventExtractorGtcSorterMaxCount,eventExtractorGtcSorterMaxSize)


    return returnCodeEventExtractorGtcSorter
    
    
#=========================================================
# The first 4 are required,  expectedCatalogItemId is int type
# eventPass : True or False
def verifyOfferEligibilityResult(eventPass, response, testName, expectedCatalogItemId, expectedRuleType=None, expectedObjectType=None, expectedEntityType=None, expectedRuleName=None, expectedRuleValue=None, expectedResult=None, actionType='purchase'):
    if response is None:
       return
    if not eventPass:
       if actionType == 'purchase':
         eligibilityCatalogItemId = QA_MDC.getEligibilityCatalogItemId(response)
         saveMDC(0, testName+ '_verify_eligibilityCatalogItemId_'+actionType+"_"+str(expectedCatalogItemId),  str(eligibilityCatalogItemId == str(expectedCatalogItemId)))

       #Only the first reason will return for the eligibility failure
       verifyEligibilityResult(QA_MDC.getEligibilityResultList(response, actionType)[0], testName, expectedCatalogItemId, expectedRuleType=expectedRuleType, expectedObjectType=expectedObjectType, expectedEntityType=expectedEntityType, expectedRuleName=expectedRuleName, expectedRuleValue=expectedRuleValue, expectedResult=expectedResult, actionType=actionType)

    else:
       eligibilityCatalogItemId = QA_MDC.getEligibilityCatalogItemId(response)
       eligibilityResultList = QA_MDC.getEligibilityResultList(response)

       saveMDC(0, testName+ '_verify_eligibilityCatalogItemId_'+actionType+"_"+str(expectedCatalogItemId),  str(eligibilityCatalogItemId is None))
       saveMDC(0, testName+ '_verify_eligibilityResult_'+actionType+"_"+str(expectedCatalogItemId)+'_eligibilityResultList', str( eligibilityResultList is None))


#=========================================================
def verifyEligibilityResult(actualEligibilityResult, testName, expectedCatalogItemId, expectedRuleType=None, expectedObjectType=None, expectedEntityType=None, expectedRuleName=None, expectedRuleValue=None, expectedResult=None, actionType='purchase'):

   print("actual eligiblity result:", actualEligibilityResult)
   saveMDC(0, testName+ '_verify_eligibilityResult_'+actionType+"_"+str(expectedCatalogItemId)+'_catalogItemId', str(actualEligibilityResult[0] == expectedCatalogItemId))
   if expectedRuleType is not None:
      saveMDC(0, testName+ '_verify_eligibilityResult_'+actionType+"_"+str(expectedCatalogItemId)+'_ruleType', str(actualEligibilityResult[1] == expectedRuleType))
   if expectedObjectType is not None:
      saveMDC(0, testName+ '_verify_eligibilityResult_'+actionType+"_"+str(expectedCatalogItemId)+'_objectType', str(actualEligibilityResult[2] == expectedObjectType))
   if expectedEntityType is not None:
      saveMDC(0, testName+ '_verify_eligibilityResult_'+actionType+"_"+str(expectedCatalogItemId)+'_entityType', str(actualEligibilityResult[3] == expectedEntityType))
   if expectedRuleName is not None:
      saveMDC(0, testName+ '_verify_eligibilityResult_'+actionType+"_"+str(expectedCatalogItemId)+'_ruleName', str(actualEligibilityResult[4] == expectedRuleName))
   if expectedRuleValue is None:
      saveMDC(0, testName+ '_verify_eligibilityResult_'+actionType+"_"+str(expectedCatalogItemId)+'_ruleValue', str(actualEligibilityResult[5] is None))
   else :
      saveMDC(0, testName+ '_verify_eligibilityResult_'+actionType+"_"+str(expectedCatalogItemId)+'_ruleValue', str(actualEligibilityResult[5] == expectedRuleValue))
   if expectedResult is not  None:
      saveMDC(0, testName+ '_verify_eligibilityResult_'+actionType+"_"+str(expectedCatalogItemId)+'_result', str(actualEligibilityResult[6] == expectedResult))


#=========================================================
def verifyPurchaseOfferEligibilityResult(eventPass, response, testName, expectedCatalogItemId, expectedRuleType=None, expectedObjectType=None, expectedEntityType=None, expectedRuleName=None, expectedRuleValue=None, expectedResult=None):

    return verifyOfferEligibilityResult(eventPass, response, testName, expectedCatalogItemId,expectedRuleType, expectedObjectType, expectedEntityType, expectedRuleName, expectedRuleValue, expectedResult, actionType='purchase')


#=========================================================
def verifyCancelOfferEligibilityResult(eventPass, response, testName, expectedCatalogItemId, expectedRuleType=None, expectedObjectType=None, expectedEntityType=None, expectedRuleName=None, expectedRuleValue=None, expectedResult=None):

    return verifyOfferEligibilityResult(eventPass, response, testName, expectedCatalogItemId,expectedRuleType, expectedObjectType, expectedEntityType, expectedRuleName, expectedRuleValue, expectedResult, actionType='cancel')


#=========================================================
# expectedSearchResult: True or False
# when eligibilityFilter is false, response will include ineligible catalog item
# will be used by query catalog item by pricing, by subscriber/device/group
def verifyQueryCatalogItem(response, testName, searchCatalogItemId, expectedSearchResult=None, expectedEligibilityResult=None):
    catalogItemIds = QA_MDC.getCatalogItemList(response)
    actualSearchResult = False
    if len(catalogItemIds) != 0 and searchCatalogItemId in catalogItemIds:
       actualSearchResult = True
    #print str(searchCatalogItemId)+" actual search result:", actualSearchResult

    saveMDC(0, testName+ '_has_'+str(searchCatalogItemId), str(actualSearchResult == expectedSearchResult))

    if expectedEligibilityResult is not None and expectedSearchResult :
        actualEligibilityResult = QA_MDC.getEligibilityResultForCatalogItem(response, searchCatalogItemId)
        verifyEligibilityResult(actualEligibilityResult[0], testName, expectedEligibilityResult[0], expectedEligibilityResult[1], expectedEligibilityResult[2], expectedEligibilityResult[3], expectedEligibilityResult[4], expectedEligibilityResult[5], expectedEligibilityResult[6], actionType='query')


#=========================================================
# expectedSearchResult: True or False
# will be used by query catalog item by pricing, by subscriber/device/group
def verifyQueryCatalogItemRev(response, testName, expectedCatalogItemId, expectedRev, expectedTemplateRev, expectedExtId=None, expectedTemplateAttrName=None, expectedTemplateAttrFirstFieldName=None):
 
    (catalogItemId, catalogItemRev, catalogItemTemplateRev, catalogItemExtId, catalogItemTemplateAttrName, catalogItemTemplateAttrFirstFieldName) = QA_MDC.getCatalogItemRev(response)

    saveMDC(0, testName+'_'+ str(expectedCatalogItemId)+'_catalog_item_id', str( str(expectedCatalogItemId)  == catalogItemId))
    saveMDC(0, testName+'_'+ str(expectedCatalogItemId)+ '_rev',  str( expectedRev  == catalogItemRev))
    saveMDC(0, testName+'_'+ str(expectedCatalogItemId)+ '_template_rev',  str( expectedTemplateRev  == catalogItemTemplateRev))
    
    if expectedExtId is not None:
        print("expected:", expectedExtId)
        print("actual:", catalogItemExtId)
        saveMDC(0, testName+'_'+ str(expectedCatalogItemId)+ '_external_id',  str( expectedExtId  == catalogItemExtId))
    if expectedTemplateAttrName is not None:
        saveMDC(0, testName+'_'+ str(expectedCatalogItemId)+ '_template_attr_name',  str( expectedTemplateAttrName  == catalogItemTemplateAttrName))
    if expectedTemplateAttrFirstFieldName is not None:
        saveMDC(0, testName+'_'+ str(expectedCatalogItemId)+ '_template_attr_first_field_name',  str( expectedTemplateAttrFirstFieldName  == catalogItemTemplateAttrFirstFieldName))
   


#=========================================================
# expectedSearchResult: True or False
def verifyQueryCatalog(response, testName, searchCatalogId, expectedSearchResult=None):
    catalogIds = QA_MDC.getCatalogIds(response)
    actualSearchResult = False
    if len(catalogIds) != 0 and searchCatalogId in catalogIds:
       actualSearchResult = True

    saveMDC(0, testName+ '_has_'+str(searchCatalogId), str(actualSearchResult == expectedSearchResult))


#=========================================================
# eventPass : True or False
# hasSearchContent: True or False
def verifyQueryCatalogItemForCatalog(response, testName, searchCatalogItemId, expectedSearchResult=None):
    catalogItemIds = QA_MDC.getCatalogItemIdsForCatalog(response)
    actualSearchResult = False
    if len(catalogItemIds) != 0 and searchCatalogItemId in catalogItemIds:
       actualSearchResult = True

    saveMDC(0, testName+ '_has_'+str(searchCatalogItemId), str(actualSearchResult == expectedSearchResult))

#========================================================
def saveSpecificItemFromListQueryResult(urlPrefix, queryResult, outFileName, searchKeyName, searchKeyValue,  tagsList=None):
    if urlPrefix == 'json':
        saveSpecificItemFromJsonListResult(queryResult, outFileName, searchKeyName, searchKeyValue, tagsList=tagsList)
    elif urlPrefix == 'v3':
        saveSpecificItemFromXmlListResult(queryResult, outFileName, searchKeyName, searchKeyValue, tagsList=tagsList)

#========================================================
def saveSpecificItemFromXmlListResult(listResult, outFileName, searchKeyName, searchKeyValue, tagsList=None):
    try:
        respXml = ElementTree.fromstring(listResult)
    except Exception as inst:
        print(inst)
        return (999, 'Could not parse response')
    
    firstTag = respXml[0].tag
    #print "first tag:", firstTag
    targetResult =""
    resultList = respXml.findall(firstTag)
    for result in resultList:
        if result.find(searchKeyName).text == str(searchKeyValue):
           targetResult = result
           break
    
    if tagsList == None:
        saveMDC(0, outFileName, ElementTree.tostring(targetResult))
    else:
        saveSpecificTagsFromXmlResult(ElementTree.tostring(targetResult), outFileName, tagsList)

#========================================================
def saveSpecificItemFromJsonListResult(listResult, outFileName, searchKeyName, searchKeyValue, tagsList=None):
    try:
        respDict = json.loads(listResult)
    except Exception as inst:
        print(inst)
        return (999, 'Could not parse response')

    resultArray = respDict['Results']
    targetResult =""
    #print "key:", searchKeyName
    #print "value:", searchKeyValue
    for result in resultArray:
        if result[searchKeyName] == searchKeyValue:
           targetResult = result
           break

    if tagsList == None:
        targetResult = json.dumps(targetResult, sort_keys=True, indent=4, separators=(',', ': '))
        saveMDC(0, outFileName, targetResult)
    else:
        saveSpecificTagsFromJsonResult(json.dumps(targetResult), outFileName, tagsList)

#========================================================
def saveSpecificTagsFromResult(urlPrefix,result, outFileName, tagsList):

    if urlPrefix == 'json':
        saveSpecificTagsFromJsonResult(result, outFileName, tagsList)
    elif urlPrefix == 'v3':
        saveSpecificTagsFromXmlResult(result, outFileName, tagsList)

#========================================================
def saveSpecificTagsFromXmlResult(result, outFileName, tagsList):
    try:
        root = ElementTree.fromstring(result)
    except Exception as inst:
        print(inst)
        return (999, 'Could not parse response')

    tagsXmlResult=ElementTree.Element('result')

    for tag in tagsList:
      if root.find(tag) is not None:
          tagsXmlResult.append(root.find(tag))
    saveMDC(0, outFileName, ElementTree.tostring(tagsXmlResult))

#========================================================
def saveSpecificTagsFromJsonResult(result, outFileName, tagsList):
    try:
        respDict = json.loads(result)
    except Exception as inst:
        print(inst)
        return (999, 'Could not parse response')

    tagsJsonDict={}
    for tag in tagsList:
      if tag in respDict:
          tagsJsonDict[tag] = respDict[tag]

    saveMDC(0, outFileName, json.dumps(tagsJsonDict, sort_keys=True, indent=4, separators=(',', ': ')))

#========================================================
def saveMemberBalanceResult(urlPrefix,result, outFileName):
    if urlPrefix == 'json':
        return saveMemberBalanceFromJsonResult(result, outFileName)
    elif urlPrefix == 'v3':
        return saveMemberBalanceFromXmlResult(result, outFileName)

#========================================================
def saveMemberBalanceFromJsonResult(result, outFileName):
    try:
        respDict = json.loads(result)
        memberBalanceSize = len(respDict["SubscriptionArray"])
        subGroupBalanceSize = len(respDict["SubGroupArray"])
        saveMDC(0, outFileName+'_member_size', str(memberBalanceSize))
        saveMDC(0, outFileName+'_subgroup_size', str(subGroupBalanceSize))

        memberCursor = respDict["SubscriptionCursor"]
        subGroupCursor = respDict["SubGroupCursor"]
        return (memberCursor, subGroupCursor)
    except Exception as inst:
        print(inst)
        print("Warning: Could not parse response")
        return (-1, -1)

#========================================================
def saveMemberBalanceFromXmlResult(result, outFileName):
    try:
        root = ElementTree.fromstring(result)
        memberBalanceSize=len(root.find("SubscriptionArray").getchildren())
        subGroupBalanceSize=len(root.find("SubGroupArray").getchildren())
        saveMDC(0, outFileName+'_member_size', str(memberBalanceSize))
        saveMDC(0, outFileName+'_subgroup_size', str(subGroupBalanceSize))
        memberCursor = root.findtext("SubscriptionCursor")
        subGroupCursor = root.findtext("SubGroupCursor")
        return memberCursor, subGroupCursor
    except Exception as inst:
        print(inst)
        print("Warning: Could not parse response")
        return (-1, -1)

#========================================================
def saveSubExternalPayment(testTag, queryValue, queryType='ExternalId', queryTime=None):
    restVersion=QAV3.restVersion 
    restInst = getSubscInterface()

    if queryTime is not None:
       queryTime = MDCTIME.convertTime(queryTime, restVersion=restVersion)

    rspMdc = QAV3.subscriberQueryExternalPayment(restInst, queryValue=queryValue, queryType=queryType, now=queryTime)

    if restVersion == 'MDC':
       rsp = rspMdc.printXml()
       gateway = '_MDC'
    elif restVersion == 'REST':
       gateway = '_REST'
       rsp = rspMdc
    elif restVersion == 'JSON':
       gateway = '_JSON'
       rsp = rspMdc

    saveMDC(0, testTag+gateway, rsp)
    
#========================================================
def saveGroupExternalPayment(testTag, queryValue, queryType='ExternalId', queryTime=None):
    restVersion=QAV3.restVersion 
    restInst = getSubscInterface()

    if queryTime is not None:
       queryTime = MDCTIME.convertTime(queryTime, restVersion=restVersion)

    rspMdc = QAV3.groupQueryExternalPayment(restInst, queryValue=queryValue, queryType=queryType, now=queryTime)

    if restVersion == 'MDC':
       rsp = rspMdc.printXml()
       gateway = '_MDC'
    elif restVersion == 'REST':
       gateway = '_REST'
       rsp = rspMdc
    elif restVersion == 'JSON':
       gateway = '_JSON'
       rsp = rspMdc

    saveMDC(0, testTag+gateway, rsp)

def saveEventQueryResultJson(queryResult, outFileName):
    gateway = '_JSON'
    path = os.getcwd()

    if isinstance(queryResult, bytes):
        queryResult = queryResult.decode('utf-8')

    # Save raw output to file
    tmpEventFileName = os.getcwd() + '/' + COMMON.resultsDir + '/eventQueryResult.txt'
    tmpEventFile = open(tmpEventFileName, 'w')
    print(queryResult, file=tmpEventFile)
    tmpEventFile.close()

    # Format for readability
    queryResult = queryResult.replace('\\n', '\n').replace('\\t','\t').replace('\\"','"')

    excludeList = [     'EventTime', 'InitiatorId', 'InitiatorExternalId', 'InitiatorDeviceId',
                        'InitiatorDeviceExternalId', 'InitiatorWalletId', 'WalletId', 'EventId',
                        'BalanceEndTime', 'BalanceStartTime', 'StartTime', 'parentGroupId'
                  ]

    # Remove excludList
    outputFileName = os.getcwd() + '/' + COMMON.resultsDir + '/' + outFileName + gateway
    outputFile = open(outputFileName, 'w')
    tmp = ''
    s = io.StringIO(queryResult)
    for line in s:
        if not any([x in line for x in excludeList]):
            tmp += line

    # Output result to file
    print(tmp, file=outputFile)
    logger.printRes(path, 'allMdcFilesList', path + '/' + COMMON.resultsDir + '/' + outFileName + gateway)
    return

#=========================================================
# expectedSearchResult: True or False
def verifyQueryContractPaymentSchedule(response, testName, searchContractPaymentScheduleId, expectedSearchResult=None):
    contractPaymentScheduleIds = QA_MDC.getContractPaymentScheduleIds(response)
    actualSearchResult = False
    if len(contractPaymentScheduleIds) != 0 and searchContractPaymentScheduleId in contractPaymentScheduleIds:
       actualSearchResult = True

    saveMDC(0, testName+ '_has_'+str(searchContractPaymentScheduleId), str(actualSearchResult == expectedSearchResult))

#=========================================================
def saveQueryResponse(testName, queryName, queryResponse):
    #global restInst
    if QAV3.restVersion == 'MDC':
        queryResponse = queryResponse.printXml()
        saveMDC(0, testName + '_'+ queryName+'_mdc', str(queryResponse))
    elif QAV3.restVersion == 'REST':
        saveMDC(0, testName + '_'+ queryName+'_rest', queryResponse)
    elif QAV3.restVersion == 'JSON':
        saveMDC(0, testName + '_'+ queryName+'_json', queryResponse)


def saveActionTransitionTime(testName, tagName, dateTimeFieldName):
    #2018-06-03T00:00:00.591422Z
    # due to machine load different, we just verify up to mins
    cmd = "grep " + dateTimeFieldName+" results/tr*" +tagName+" | cut -d'\"' -f6 | cut -d'.' -f 1 | cut -d':' -f 1-2"
    res = runCmd(cmd)
    saveMDC(0, testName+tagName+'_TransitionTime', res)
    
#=========================================================
def main():
    x = setSystemClock('2012-02-01T12:30:12')
    print('x = ' + x)
    setSystemClock(x)
    sys.exit(1)
    tname = getTestName(os.getcwd())
    print('tname = ' + tname)
    cleanConfigIniFile('.')
    config = configparser.ConfigParser()
    #sendOneRequest(deviceId=123,reqamount=60,usedamount=0,requestType='initial', sessionId=1, serviceId='voice', startTime=time.time())
    config.read('./sampleini.ini')
    getSubsc(config,'CDUser2')
    subscData = getSubsc(config,'User2')
    print('id=' + str(subscData['externalid']))
    print('offers=' +  str(subscData['offerid'][2]))

if __name__ == '__main__':
    main()

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

