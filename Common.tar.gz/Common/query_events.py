#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:41:04
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:46
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:36
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


import os,sys
import optparse
import pretty_print as PRINT
import qa_utils as QAUTILS
import QA_subscriber_management_restv3 as RESTV3

restInst = None

def main():
    global restInst

    parser = optparse.OptionParser()
    parser.add_option("-s", "--subscid", action='store', type='int', default=0)
    parser.add_option("-i", "--imsi", action='store', type='string', default=None)
    parser.add_option("-e", "--eventId", action='store', type='string', default=None)
    parser.add_option("-o", "--soid", action='store', type='string', default=None)
    parser.add_option("-w", "--doid", action='store', type='string', default=None)
    parser.add_option("-c", "--goid", action='store', type='string', default=None)
    parser.add_option("-g", "--groupid", action='store', type='int', default=0)
    parser.add_option("-r", "--restgw", default="", help="query by REST")
    (options, args) = parser.parse_args()

    # Get client to perform query
    gatewaysConfig = QAUTILS.getDiameterRestConfig()
    if options.restgw:
        RESTV3.setVersion('REST')
    else:
        RESTV3.setVersion('MDC')
        RESTV3.mtxflags = 1
    QAUTILS.gatewaysConfig = gatewaysConfig
    restInst = QAUTILS.getSubscInterface()

    if options.imsi:
        getDeviceData(options.imsi, 'Imsi', options.restgw)
    elif options.doid:
        getDeviceData(options.doid, 'ObjectId', options.restgw)

    elif options.soid:
        getSubscriberData(options.soid, 'ObjectId', options.restgw)
    elif options.subscid:
        getSubscriberData(options.subscid, 'PhoneNumber',  options.restgw)
    elif options.groupid:
        getGroupData(options.groupid, 'ExternalId', options.restgw)
    elif options.goid:
        getGroupData(options.goid, 'ObjectId', options.restgw)
    elif options.eventId:
        getEventData(options.eventId, 'EventId', options.restgw)
    else:
        print('done!!!!!!!!!!!')
		 
def getGroupData(queryValue, queryType, rest=None):
    if rest:
        print(RESTV3.queryGroupEvent(restInst, queryValue=queryValue, queryType=queryType))
    else:
        # Formatted printing for MDC specific output
        groupMdc = RESTV3.queryGroupEvent(restInst, queryValue=queryValue, queryType=queryType)
        print(groupMdc[0].printXml())

def getSubscriberData(queryValue, queryType, rest=None):
    if rest:
        print(restInst.subscriberQueryEvent(queryValue=queryValue, queryType=queryType))
    else:
        # Formatted printing for MDC specific output
        subscriberMdc = restInst.subscriberQueryEvent(queryValue=queryValue, queryType=queryType)
	print(subscriberMdc.printXml())

def getDeviceData(queryValue, queryType, rest=None):
        print("querying ", queryValue, " by queryType=", queryType)
        #deviceMdc = restInst.deviceQuery(queryValue=queryValue, queryType=queryType, now=time)
	#print deviceMdc

def getEventData(queryValue, queryType, rest=None):
        print("querying by event id ", queryValue)
        eventMdc = restInst.eventQuery(queryType=queryType, queryValue=queryValue)
        print(eventMdc.printXml())

if __name__ == '__main__':
   main()
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

