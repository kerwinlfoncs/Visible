#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:41:09
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:51
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:26
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


import os,sys
import optparse
import pretty_print as PRINT
import qa_utils as QAUTILS
import QA_subscriber_management_restv3 as RESTV3

restInst = None

def main():
    global restInst

    parser = optparse.OptionParser()
    parser.add_option("-s", "--subscid", action='store', type='int', default=0)
    parser.add_option("-x", "--externalid", action='store', type='string', default=None)
    parser.add_option("-i", "--imsi", action='store', type='string', default=None)
    parser.add_option("-o", "--soid", action='store', type='string', default=None)
    parser.add_option("-w", "--doid", action='store', type='string', default=None)
    parser.add_option("-c", "--goid", action='store', type='string', default=None)
    parser.add_option("-f", "--uoid", action='store', type='string', default=None)
    parser.add_option("-a", "--daccess", action='store', type='string', default=None)
    parser.add_option("-b", "--dexternal", action='store', type='string', default=None)
    parser.add_option("-g", "--groupid", action='store', type='int', default=0)
    parser.add_option("-z", "--userid", action='store', type='string', default=None)
    parser.add_option("-u", "--uexternal", action='store', type='string', default=None)
    parser.add_option("-l", "--level", action='store', type='int', default=1)
    parser.add_option("-t", "--time", action='store', type='string', default='None')
    parser.add_option("-m", "--mdcgw", default="1", help="query by mdc gw")
    parser.add_option("-r", "--restgw", default="", help="query by REST")
    parser.add_option("-q", "--querysize", action='store', type='int', default=1, help="querySize")
    (options, args) = parser.parse_args()

    # Get client to perform query
    gatewaysConfig = QAUTILS.getDiameterRestConfig()
    if options.restgw:
        RESTV3.setVersion('REST')
    else:
        RESTV3.setVersion('MDC')
        RESTV3.mtxflags = 1
    QAUTILS.gatewaysConfig = gatewaysConfig
    restInst = QAUTILS.getSubscInterface()

    if options.time == 'None':
        options.time = None
    if options.imsi:
        getDeviceData(options.imsi, 'Imsi', options.level, options.time, options.restgw)
    elif options.doid:
        getDeviceData(options.doid, 'ObjectId', options.level, options.time, options.restgw)
    elif options.daccess:
        getDeviceData(options.daccess, 'AccessNumber', options.level, options.time, options.restgw)
    elif options.dexternal:
        getDeviceData(options.dexternal, 'ExternalId', options.level, options.time, options.restgw)

    elif options.soid:
        getSubscriberData(options.soid, 'ObjectId', options.level, options.time, options.restgw)
    elif options.subscid:
        getSubscriberData(options.subscid, 'PhoneNumber', options.level, options.time, options.restgw)
    elif options.externalid:
        getSubscriberData(options.externalid, 'ExternalId', options.level, options.time, options.restgw)
    elif options.groupid:
        getGroupData(options.groupid, 'ExternalId', options.level, options.time, options.querysize, options.restgw)
    elif options.goid:
        getGroupData(options.goid, 'ObjectId', options.level, options.time, options.querysize, options.restgw)
    elif options.uoid:
        getUserData(options.uoid, 'ObjectId', options.level, options.time, options.restgw)
    elif options.userid:
        getUserData(options.userid, 'UserId', options.level, options.time, options.restgw)
    elif options.uexternal:
        getUserData(options.uexternal, 'ExternalId', options.level, options.time, options.restgw)
    else:
        print('done!!!!!!!!!!!')
                 
def getGroupData(queryValue, queryType, level, time, querySize, rest=None):
    if rest:
        print(RESTV3.queryGroup(restInst, queryValue=queryValue, queryType=queryType, querySize=querySize, now=time))
        print(RESTV3.queryGroupWallet(restInst, queryValue=queryValue, queryType=queryType, now=time))
    else:
        # Formatted printing for MDC specific output
        groupMdc = RESTV3.queryGroup(restInst, queryValue=queryValue, queryType=queryType, querySize=querySize, now=time)
        print(groupMdc)
        PRINT.printGroup(restInst, groupMdc, level)
        walletMdc = RESTV3.queryGroupWallet(restInst, queryValue=queryValue, queryType=queryType, now=time)
        print(walletMdc)
        PRINT.printWallet(restInst, walletMdc, level)

def getSubscriberData(queryValue, queryType, level, time, rest=None):
    if rest:
        print(restInst.subscriberQuery(queryValue=queryValue, queryType=queryType, now=time))
        print(restInst.subscriberQueryWallet(queryValue=queryValue, queryType=queryType, now=time))
    else:
        # Formatted printing for MDC specific output
        subscriberMdc = restInst.subscriberQuery(queryValue=queryValue, queryType=queryType, now=time)
        print(subscriberMdc)
        PRINT.printSubscriber(restInst, subscriberMdc, level)
        walletMdc = restInst.subscriberQueryWallet(queryValue=queryValue, queryType=queryType, now=time)
        print(walletMdc)
        PRINT.printWallet(restInst, walletMdc, level)

def getDeviceData(queryValue, queryType, level, time, rest=None):
        print("querying ", queryValue, " by queryType=", queryType)
        deviceMdc = restInst.deviceQuery(queryValue=queryValue, queryType=queryType, now=time)
        print(deviceMdc)

def getUserData(queryValue, queryType, level, time, rest=None):
    if rest:
        print(restInst.userQuery(queryValue=queryValue, queryType=queryType, now=time))
    else:
        # Formatted printing for MDC specific output
        userMdc = restInst.userQuery(queryValue=queryValue, queryType=queryType, now=time)
        print(userMdc)
#        PRINT.printUser(restInst, subscriberMdc, level)

if __name__ == '__main__':
   main()
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

