#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:10
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:35:52
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:34:41
#===============================================================================
#
# Copyright 2010-2016, MATRIXX Software, Inc. All rights reserved.
#
#===============================================================================
#

# from builtins import str
# from builtins import str
import optparse
import os, string

statsHeading = []
databaseSegmentStats = []
databseObjectStats = []
databaseOIDIndexStats = []

def printDatabaseSegmentStats():
    databaseSegmentStats.sort()
    print(' ')
    print('Start Date/Time: ' + statStartDate)
    print('End Date/Time  : ' + statEndDate)
    print('-------------------------------------------------------------------------------------------------------------------------')
    print('{0:6} {1:40} {2:13} {3:11} {4:17} {5:15} {6:12}'.format(
          'PoolId','Database Segment Stats', 'segCountStart', 'segCountEnd', 'segCountUsedStart', 'segCountUsedEnd', '     segSize'))
    print('-------------------------------------------------------------------------------------------------------------------------')
    for item in databaseSegmentStats:
        print('{0:6} {1:40} {2:13} {3:11} {4:17} {5:15} {6:12}'.format(
               item[0], item[1], item[2], item[3], item[4], item[5], item[6]))
    print('-------------------------------------------------------------------------------------------------------------------------')
    print('Values taken from the first/last Database Segment Stats record')

def printDatabaseObjectStats():
    databseObjectStats.sort()
    print(' ')
    print('Start Date/Time: ' + statStartDate)
    print('End Date/Time  : ' + statEndDate)
    print('-----------------------------------------------------------------------------------------------------------')
    print('{0:6} {1:6} {2:40} {3:12} {4:12} {5:12} {6:12}'.format(
           'PoolId', 'TypeId', 'Database Object Stats', '       Start', '         End', '  Difference', '     Maximum'))
    print('-----------------------------------------------------------------------------------------------------------')
    for item in databseObjectStats:
        print('{0:6} {1:6} {2:40} {3:12} {4:12} {5:12} {6:12}'.format(
            item[0], item[1], item[2], item[3], item[4], item[4] - item[3], item[5]))
    print('-----------------------------------------------------------------------------------------------------------')
    print('Values taken from the first/last Database Object Stats record apart from')
    print('Maximum, which is the maximum of all Database Object Stats for that database.')

def printOidIndexStats():
    databaseOIDIndexStats.sort()
    print(' ')
    print('Start Date/Time: ' + statStartDate)
    print('End Date/Time  : ' + statEndDate)
    print('-----------------------------------------------------------------------------------------------------------------------------------------')
    print('{0:6} {1:40} {2:16} {3:16} {4:16} {5:11} {6:11} {7:13}'.format(
          'PoolId', 'Database OID Index Stats', ' startIndexCount', '   endIndexCount', '  max_IndexCount', ' startChain', '   EndChain', 'max_ChainSize'))
    print('-----------------------------------------------------------------------------------------------------------------------------------------')
    for item in databaseOIDIndexStats:
        print('{0:6} {1:40} {2:16} {3:16} {4:16} {5:11} {6:11} {7:13}'.format(
               item[0], item[1], item[2], item[3], item[7], item[4], item[5], item[6]))
    print('-----------------------------------------------------------------------------------------------------------------------------------------')
    print('Values taken from the first/last Database OID Index Stats record apart from')
    print('Max_ChainSize and max_IndexCount, which is the maximum of all Database OID Index Stats for that database.')

def getFileDetails(in_file, start_date, end_date):
    #Work out where the first record starts and more importantly the last record
    i = 0
    dateTimeList = []
    dateTimeList = (['',0,'',0,0])
    vDateTime = ''
    vLineNumber = 0

    inFile = open(in_file, 'r')

    for line in inFile:
        line = line.rstrip('\n')
        i+=1
        #Start of stats, get a Date/Time
        if 'time' == line[:4]:
            sDateTime = line.split()[3]
            sDate = sDateTime[:10]
            sLineNumber = i

            #Make sure the end date is from a record with valid stats
            if (sDate > end_date and not dateTimeList[2]):
                dateTimeList[2] = vDateTime
                dateTimeList[3] = vLineNumber
                dateTimeList[4] = sLineNumber

        #Make sure we have some stats before saving the details
        if ('Sys Stats' == line[:9]):   
            vDateTime = sDateTime
            vLineNumber = sLineNumber

            #Make sure the start details have valid stats
            if (sDate >= start_date and not dateTimeList[0]):
                dateTimeList[0] = vDateTime
                dateTimeList[1] = vLineNumber

    # If we haven't saved end details and we are at the end of the file
    #then save the last details where we had definately had stats
    if not dateTimeList[2]:
        dateTimeList[2] = vDateTime
        dateTimeList[3] = vLineNumber
        dateTimeList[4] = i

    inFile.close()
    print('First Record Dated ' + dateTimeList[0] + ' at line number: ' + str(dateTimeList[1]))
    print('Last  Record Dated ' + dateTimeList[2] + ' at line number: ' + str(dateTimeList[3]))
    return dateTimeList 

def main():

    ## Read command line arguments
    parser = optparse.OptionParser(usage='''\
    %prog [options]
    This script is used to

    From a file containing multiple print_blade_stats, extract:
    a. Extract Database Segment Stats, from the first and last records  
    b. Extract Database Object Stats from the first and last records and also maximum values 
    c. Extract Database OID Index Stats from the first and last records and also maximum values ''')
    parser.add_option('--in_file', '-f', action='store',
        type='string', default='print_blade_stats',
        help='The name of the file containing print_blade_stats')
    parser.add_option('--start_date', '-s', action='store',
        type='string', default='0000-00-00',
        help='Start Date of the Compare: yyyy-mm-dd (Default 0000-00-00)')
    parser.add_option('--end_date', '-e', action='store',
        type='string', default='9999-99-99',
        help='End Date of the Compare: yyyy-mm-dd (Default 9999-99-99)')
    (options, arguments) = parser.parse_args()

    global statStartDate
    global statEndDate
    statsSection = ''
    lineCount = 0

    #Need to reference the sections we are interested in and the following section
    statsHeading.append('Database Segment Stats')
    statsHeading.append('Database Object Stats')
    statsHeading.append('Database Index Stats')
    statsHeading.append('Database OID Index Stats')
    statsHeading.append('Diameter PDU Stats')

    inFile = open(options.in_file, 'r')
    os.system('clear')
    print('Reading file: ' + options.in_file)
    
    #Get the Date and Line Number of the last set of stats 
    #So that we know where to get the last set of stats instead 
    fileDetails =  getFileDetails(options.in_file, options.start_date, options.end_date )
    statStartDate = fileDetails[0]
    statEndDate = fileDetails[2]
    startDateRecord = 0
    endDateRecord = 0

    for line in inFile:
        line = line.rstrip('\n')
        lineCount+=1

        if line == '':
            statsSectionStart = 1
            continue

        if (line[:4] in ['    ', '  Id', 'Pool', '----', '====']):
            continue

        if 'time' == line[:4]:
            startDateRecord = 0
            endDateRecord = 0

        #We are at the start/end date
        if lineCount == fileDetails[1]:
            startDateRecord = 1
            continue
        if lineCount == fileDetails[3]:
            endDateRecord = 1
            continue

        #Don't bother looking any further if we are not in our date/time range
        if (lineCount < fileDetails[1] or lineCount > fileDetails[4]):
            continue

        #Work out which section of stats we are in
        #Assumes that once we hit an empty line, the next line we should then find a section title
        if statsSectionStart:
            for item in statsHeading:
                if item in line:
                    statsSection = item
                    previousValue = ''
                    break
            statsSectionStart = 0
            continue

        #We are not in this stuff to ignore it
        if (statsSection not in ['Database Segment Stats', 'Database Object Stats', 'Database OID Index Stats']):
            continue

        #We are only interested in the 1st and last records for this one
        if (statsSection == 'Database Segment Stats' and startDateRecord == 0 and endDateRecord == 0):
            continue

        #All we should have left now are the stats we are interested in

        if (statsSection == 'Database Segment Stats'):
            thisValue = line[6:35].rstrip()
            if thisValue != previousValue:
                gotIt = 0
                for item in databaseSegmentStats:
                    if thisValue == item[1]:
                        gotIt = 1
                        break
                if not gotIt:
                    databaseSegmentStats.append ([int(line[:4]),thisValue,0,0,0,0,0])
                previousValue = thisValue

            for item in databaseSegmentStats:
                if item[1] == thisValue:
                    #Count the spaces in each title, so we know where the Count value will be
                    objectOffset = item[1].count(' ')
                    segmentId = int(line.split()[objectOffset + 2])
                    segmentMemoryUsed = int(line.split()[objectOffset + 4])

                    #0: segCountStart 1: segCountEnd 2:segCountUsedStart 3:segCountUsedEnd  4: segSize
                    if startDateRecord:
                        if segmentId:
                            item[2] += 1
                        if segmentMemoryUsed > 0:
                            item[4] += 1
                    if endDateRecord:
                        if segmentId:
                            item[3] += 1
                        if segmentMemoryUsed > 0:
                            item[5] += 1
                    if segmentMemoryUsed > item[6]:
                        item[6] = segmentMemoryUsed

        if (statsSection == 'Database Object Stats'):

            thisValue = line[12:52].rstrip()
            if thisValue != previousValue:
                gotIt = 0
                for item in databseObjectStats:
                    if thisValue == item[2]:
                        gotIt = 1
                        break
                if not gotIt:
                    databseObjectStats.append([int(line[:4]),int(line[7:11]),thisValue,0,0,0,0,0])
                previousValue = thisValue

            for item in databseObjectStats:
                if item[2] == thisValue:
                    #Count the spaces in each title, so we know where the Count value will be
                    objectOffset = item[2].count(' ')
                    objectCount = int(line.split()[objectOffset + 3])
                    maximumObjectCount = int(line.split()[objectOffset + 5])

                    if startDateRecord:
                        item[3] = objectCount
                    if endDateRecord:
                        item[4] = objectCount
                    if (maximumObjectCount > int(item[5])):
                        item[5] = maximumObjectCount

        if (statsSection == 'Database OID Index Stats'):
            thisValue = line[6:35].rstrip()
            if thisValue != previousValue:
                gotIt = 0
                for item in databaseOIDIndexStats:
                    if thisValue == item[1]:
                        gotIt = 1
                        break
                if not gotIt:
                    databaseOIDIndexStats.append([int(line[:4]),thisValue,0,0,0,0,0,0])
                previousValue = thisValue

            for item in databaseOIDIndexStats:
                if item[1] == thisValue:
                    #Count the spaces in each title, so we know where the Count value will be
                    objectOffset = item[1].count(' ')
                    indexCount = int(line.split()[objectOffset + 2])
                    chainSize = int(line.split()[objectOffset + 6])

                    if startDateRecord:
                        item[2] = indexCount
                        item[4] = chainSize
                    if endDateRecord:
                        item[3] = indexCount
                        item[5] = chainSize
                    if chainSize > int(item[6]):
                        item[6] = chainSize
                    if indexCount > int(item[7]):
                        item[7] = indexCount

    #Print the results
    printDatabaseSegmentStats()
    printDatabaseObjectStats()
    printOidIndexStats()

if __name__ ==  '__main__':
    main()
