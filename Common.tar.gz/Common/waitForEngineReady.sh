origX=0
while true; do
    # Get curent process count
    x=`ps -eo %a|grep "mtx -e"| grep -v grep|wc -l`
    
    # See if we're done
    if [ $x == 7 ]
    then
    	echo x= $x
	echo "SUCCESS:  Engine fully up"
        break
    fi
    
    # See if we digressed (then exit)
    if [ $x -lt $origX ]
    then
	echo "FAIL: number of active processes has declined.  Engine not coming up."
	exit 1
    fi
    
    # Update original number to match current number
    origX=$x
    
    # Sleep until next test
    sleep 3
    
done
