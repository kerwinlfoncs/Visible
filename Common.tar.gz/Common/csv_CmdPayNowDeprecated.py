#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:35:47
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:35:47
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:35:46
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
from __future__ import print_function
import os, sys, copy
import QA_subscriber_management_restv3 as REST_UTIL
import qa_utils as QAUTILS
import csvMain as CSV
import csv_track as TRACK
import csv_id as CSVID
import csv_prim as PRIM
import csv_data as DATA
import custSpecific as CUST
import csv_qa as CSVQA
import csvMain as CSV
import csv_CmdMisc as MISC
import csv_Events as CSVEVENTS
import xml.etree.ElementTree as ET

from primitives import primGET as GET

#==========================================================
# !!!!!!!!!!!!!! START:  Deprecated APIs !!!!!!!!!!!!!!!!!!
#==========================================================
def CmdPayNow_subscriberaddpaymenttoken(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.

        # Group should exist
        if externalId not in TRACK.groupTracking and not noChecks:
                print('ERROR: Group with ID "' + externalId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])


        # Payment token required
        if not paymentToken:
                print('ERROR: paymentToken variable not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Build the name
        name = ''
        if firstName: name += firstName
        if lastName:
                if len(name): name += '.'
                name += lastName
        if not len(name): name = None

        # Execute primitive
        retCode = REST_UTIL.groupAddPaymentToken(RESTInst, externalId, paymentToken, isCurrent=isCurrent, name=name, queryType=subQueryType, eventPass=eventPass, now=None)

        # Query group
        queryValue = externalId
        queryType = subQueryType
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdPayNow_subscriberremovepaymenttoken(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.

        # Group should exist
        if externalId not in TRACK.groupTracking and not noChecks:
                print('ERROR: Group with ID "' + externalId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])


        # Payment token or resource ID required
        if not paymentToken and not resourceId:
                print('ERROR: paymentToken and resourceId variables not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # If the resourceId is not passed in, then attempt to get it from the payment token
        if not resourceId:
                # Get payment data
                payment = PRIM.getPaymentData('group', externalId, paymentToken, lclStartTime, lclDCT['ACTION'], subQueryType)

                # Get the resource ID
                resourceId = int(payment['ResourceId'])
                
        # Execute primitive
        retCode = REST_UTIL.groupRemovePaymentToken(RESTInst, externalId, resourceId, queryType=subQueryType, eventPass=eventPass, now=None)

        # Query group
        queryValue = externalId
        queryType = subQueryType
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdPayNow_groupaddpaymenttoken(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.

        # Group should exist
        if groupId not in TRACK.groupTracking and not noChecks:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])


        # Payment token required
        if not paymentToken:
                print('ERROR: paymentToken variable not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Build the name
        name = ''
        if firstName: name += firstName
        if lastName:
                if len(name): name += '.'
                name += lastName
        if not len(name): name = None

        # Execute primitive
        retCode = REST_UTIL.groupAddPaymentToken(RESTInst, groupId, paymentToken, isCurrent=isCurrent, name=name, queryType=groupQueryType, eventPass=eventPass, now=None)

        # Query group
        queryValue = groupId
        queryType = groupQueryType
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdPayNow_groupremovepaymenttoken(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.

        # Group should exist
        if groupId not in TRACK.groupTracking and not noChecks:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])


        # Payment token or resource ID required
        if not paymentToken and not resourceId:
                print('ERROR: paymentToken and resourceId variables not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # If the resourceId is not passed in, then attempt to get it from the payment token
        if not resourceId:
                # Get payment data
                payment = PRIM.getPaymentData('group', groupId, paymentToken, lclStartTime, lclDCT['ACTION'], groupQueryType)

                # Get the resource ID
                resourceId = int(payment['ResourceId'])
                
        # Execute primitive
        retCode = REST_UTIL.groupRemovePaymentToken(RESTInst, groupId, resourceId, queryType=groupQueryType, eventPass=eventPass, now=None)

        # Query group
        queryValue = groupId
        queryType = groupQueryType
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
# !!!!!!!!!!!!!! END:  Deprecated APIs   !!!!!!!!!!!!!!!!!!
#==========================================================
