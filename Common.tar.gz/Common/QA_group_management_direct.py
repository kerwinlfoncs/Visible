#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:25
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:07
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:34:53
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


# from builtins import str
# from builtins import str
import os, sys
import data_container as MDC
import log_errors as LOGGER
import common_mdc as COMMON
import subscriber_mgmt_v3 as REST

xmlStatus=True
try:
    import xml_utils
except ImportError:
    xmlStatus=False

global testErrorLogger
path=os.getcwd()
testErrorLogger=LOGGER.clErrors(path)

def queryGroup(mdcConnection, path, groupId, testName, queryType='ExternalId', queryTime=None, querySize=None, diffEvents=False, debugData = ''):
    outFileName = 'outQueryGroup_' + str(testName)
    if diffEvents:
        outFileName = 'outQueryGroup_' + str(testName)
    else:
        outFileName = 'outQueryGroup_' + str(groupId).replace(':', '_') + '_' + str(testName)

    trsfOutFileName = 'trsf_' + outFileName

    # Generate XML data and output to file 
    # Output group info
    mdcResult = mdcConnection.groupQuery(queryType=queryType, queryValue=groupId,querySize=querySize,  now=queryTime)
    if hasattr(mdcResult, "printXml"):
        mdc = mdcResult.printXml()
    else:
        print('Group query failed!!')
        print(mdcResult)
        sys.exit()

    if not REST.checkResultSuccess(mdcResult):
        print('Group query on ' + queryType + ' with value ' + str(groupId) + ' failed!')
        print(mdcResult.printXml())
        sys.exit()

    testErrorLogger.printRes(path, outFileName, mdc, overwrite=True)

    # Output offer info for validate_balances
    COMMON.outputOfferInfo(path, testName, queryType, groupId, 'Group', mdc, debugData, queryTime)

    # Output wallet
    mdcResult = mdcConnection.groupQueryWallet(queryType=queryType, queryValue=groupId, now=queryTime)
    if not REST.checkResultSuccess(mdcResult):
        print('Group wallet query on ' + queryType + ' with value ' + str(groupId) + ' failed!')
        sys.exit()

    if hasattr(mdcResult, "printXml"):
        mdc = mdcResult.printXml()
    else:
        print('Group wallet query failed!!')
        sys.exit()
    testErrorLogger.printRes(path, outFileName, mdc, overwrite=False)

    # Output balance info for validate_balances
    COMMON.outputBalanceInfo(path, testName, queryType, groupId, 'Group', mdc)

    # Get data from file, add root container, output to same file
    outFileName = path + '/' + COMMON.resultsDir + '/' + outFileName
    xmlOutput = open(outFileName, 'r')
    lines = xmlOutput.readlines()
    xmlOutput.close()
    lines.append("</root>\n")
    lines.reverse()
    lines.append("<root>\n")
    lines.reverse()
    processedData = "".join([x for x in lines if x.strip() != ''])
    xmlOutput = open(outFileName, 'w')
    xmlOutput.write(processedData)
    xmlOutput.close()
    if xmlStatus:
        mdcTransformed = xml_utils.transformDoc(outFileName)
        #print mdcTransformed
        testErrorLogger.printRes(path, trsfOutFileName, str(mdcTransformed), overwrite = True)

    # Add output file to the file list
    #outFileName = '/' + COMMON.resultsDir + '/' + outFileName
    testErrorLogger.printRes(path, 'allMdcFilesList', path + '/' + COMMON.resultsDir + '/' + trsfOutFileName) 
    return outFileName

def main():
    fileName='oo'
    if os.path.isfile(fileName):
       inFile = open(fileName, 'r')
       print('Reading file: ' + fileName)
       for line in inFile:
           #this loop will iterate for each subscriberId
           line = line.rstrip('\n')
           if (line == ''):
               continue
           if (line.startswith('#')):
               continue
           print(' Another MDC-----------------------------')
           mdc = MDC.readFromStr(line)
           mdcGroupObject(mdc)

if __name__ == '__main__':
    main()
