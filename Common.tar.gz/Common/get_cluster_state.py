#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:40
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:20
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:02
#===============================================================================
#
# Copyright 2011,2012,2013,2014,2015,2016 Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


import topology

def getBladeState(clusterId, bladeId):
        nbladeId = None
        l = getLogicalBladesObjList(clusterId)
        for bladeObj in l:
            nbladeId = bladeObj.getFqId()
            if nbladeId == bladeId: break

        if nbladeId == None: return 'Error'
        l = bladeObj.getStateStr()
        print(" returning blade state=", l)
        return l


def getLogicalBladesObjList(clusterId):
        clusterObjList = getAllClustersObjDct()
        clusterObj = clusterObjList[clusterId]
        l = clusterObj.getLogicalBlades()
        return l

def getAllClustersObjDct():
        clustersObjList = []
        print(topology.kClusterFqIdToObjectDictionary)
        return topology.kClusterFqIdToObjectDictionary


def main():
    getBladeState('1:1','1:1:1')

if __name__ == '__main__':
    main()

#===============================================================================
#
# Copyright 2011,2012,2013,2014,2015,2016 Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


