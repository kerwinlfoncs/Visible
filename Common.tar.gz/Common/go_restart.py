#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:07
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:35:48
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:34:39
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


import optparse
import os, sys
import qa_utils as QAUTILS
import qa_utils_5G as QAUTILS5G
import fcntl
import get_config as CONFIG
import smtplib

#==========================================================

def sendEmail(emailTo, msg):
   print('Sending email to '+emailTo+' with message:'+msg)
   try:
       smtpObj = smtplib.SMTP('localhost')
       message = 'Subject: {0}\n\n'.format(msg)
       smtpObj.sendmail("noreply_go_restart@matrixx.com", emailTo, message)
       print("Email sent to: ", emailTo)
   except smtplib.SMTPException:
       print("Error: unable to send email")

def main():
    # Process input args
    (options, args) = CONFIG.initializeTest()
    print(options)
    # Overwrite default customer if environment variable is set
    if os.path.expandvars('$customer'):
        defCustomer = os.path.expandvars('$customer')
    else:
        defCustomer = 'QA'

    if 'cch_tax_vtime' in options.testSuiteName:
       options.override = 'cch_tax_vtime'
    # suite could be cch_tax_base or cch_tax_rest
    elif 'cch_tax' in options.testSuiteName:
       options.override = 'cch_tax'
    elif 'vtime' in options.testSuiteName:
       options.override = 'vtime'


    # Invoke config script
    customer = CONFIG.processInput(options, defCustomer)
    print(customer , options.testSuiteName)

    gateway = 'mdc'
    cpath = os.getcwd()
    
    if (options.testSuiteName == 'rest') or (options.testSuiteName == 'ccf_rest' or options.testSuiteName == 'cch_tax_rest'):
       gateway = 'rest'
       if os.path.exists(cpath + "/exclusion/exclude4500_rest.txt") :
            QAUTILS.runCmd('cp' +  ' ' + cpath + '/exclusion/exclude4500_rest.txt' + ' ' + cpath + '/exclusion/current_exclude_list.txt')
       else:
            print('\n\n no exclude4500_rest.txt found, using default current_exclude_list.txt\n')
    else:
        if os.path.exists(cpath + "/exclusion/exclude4500.txt") :
            QAUTILS.runCmd('cp' +  ' ' + cpath + '/exclusion/exclude4500.txt' + ' ' + cpath + '/exclusion/current_exclude_list.txt')
        else:
            print('\n\n no exclude4500.txt found, using default current_exclude_list.txt\n')

    #if running 5G quite, get the SBA ip
    sba = ""
    if (options.testSuiteName == "5g_base") or (options.testSuiteName == "5g_vtime"):
        sbaEnvDct = QAUTILS5G.setupEnv("SBA")
        if sbaEnvDct!= {}:
            url = QAUTILS5G.getSbaInfo(sbaEnvDct, "url")
            sba = url.split(":")[1].strip("/")
        else:
            sys.exit("no SBA url defined on MTXQA/Common/config.ini")

    # Execute command to update multi-cast address
    cmd = 'sh go_restart_p2.sh ' + customer + ' ' + options.testSuiteName + ' ' + gateway + ' ' + sba
    print('\n\nCommand is: ' + cmd)
    os.system(cmd)

    if options.notify:
        myhost = os.uname()[1]
        msg = options.testSuiteName + " finished on " + myhost +"!"
        sendEmail(options.notify, msg)

    # All Done!
    #sys.exit(0)
    
if __name__ == '__main__':
    main()

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
