#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:06
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:35:48
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:34:38
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================



# from builtins import bytes
# from builtins import str
# from builtins import object
from future import standard_library
standard_library.install_aliases()
# from builtins import bytes
# from builtins import str
# from builtins import object
import http.client, pprint
#pylint: disable=import-error,multiple-imports
#pylint: disable=import-error,multiple-imports
#pylint: disable=import-error,multiple-imports
#pylint: disable=import-error,multiple-imports
import urllib.request, urllib.parse, urllib.error
import QA_subscriber_management_rest_helper as RESTHELPER
import QA_subscriber_management_restv3 as RESTV3
from xml.etree import ElementTree as ET
import common_mdc as COMMON
import data_container_defs as MDCDEFS
import data_container as MDC
import re, sys , os
#import configparser
try:
    import configparser
except:
    from six.moves import configparser
import time
import socket
import qa_utils as QAUTILS
import timeToMDCtime as MDCTIME
import urllib as URL
import commonDefs as cd
import json
import restV3 as SUBMAN
import csv_data as CSV
import QA_subscriber_management_restv3 as RESTV3
#V3inst = 0
templates = ''

# Supports basic authentication.  Will be overridden by other code.
basicAuthUserName = None
basicAuthPassword = None

#
# Socket wrapper to enable socket.TCP_NODELAY
#
realsocket = socket.socket

def socketwrap(family=socket.AF_INET, type=socket.SOCK_STREAM, proto=0):
        sockobj = realsocket(family, type, proto)
        sockobj.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        return sockobj

socket.socket = socketwrap

class RestClient(object):
    def __init__(self, host, port, basePath = '/rsgateway/data'):
        self._host = host
        self._port = port
        self._basePath = basePath 
        self.status = 0
        self.reason = ""
        self.connection = http.client.HTTPConnection(self._host, self._port)
        try:
            services = self.get("/json")
        except:
            raise RuntimeError("unable to connect to the rsgateway name=" + host + " port=" + str(port))
        if services == None:
            raise RuntimeError("unable to connect to the rsgateway")
        if self.getStatus() != 200:
            raise RuntimeError("error getting services from the rsgateway " + self.getReason())

    def getStatus(self):
        return self.status

    def getReason(self):
        return self.reason

        
    def _makeRequest(self, method, resource, payload=None):
        # Refresh the connection.  Long duration tests leave the connection hung so ensure it's always fresh.
        # NOTE: try/except logic below manages resetting connection if errors occurred.
        #self.connection = httplib.HTTPConnection(self._host, self._port)
        url = self._basePath + str(resource)
      #  print payload

        # Support basic auth
        if basicAuthUserName:
                authCredsEnc = base64.b64encode(bytes(basicAuthUserName + ':' + basicAuthPassword))
                headers = {'Connection':'Keep-alive', 'Authorization':'Basic ' + authCredsEnc}
        else:
                headers = {'Connection':'Keep-alive'}
        
        # Sometimes the request fails
        try:
            # Normal case
            self.connection.request(method, url, payload, headers)
        except:
            print('WARNING: received httplib request error "' + str(e) + '".  Making a new connection and retrying.')
            self.connection = http.client.HTTPConnection(self._host, self._port)

            # Retry the request
            self.connection.request(method, url, payload, headers)

        # Sometimes the response fails when the send doesn't...
        try:
                response = self.connection.getresponse()
        except:
                print('WARNING: received httplib response error.  Making a new connection and retrying.')
                self.connection = http.client.HTTPConnection(self._host, self._port)

                # Retry the request
                self.connection.request(method, url, payload, headers)

                # Retry the response
                response = self.connection.getresponse()

        self.status = response.status
        self.reason = response.reason
        msg = response.read()

        if (isinstance(msg,bytes)):
            msg = msg.decode('utf-8')
 
        return msg

    # GET operation
    def get(self, resource, time=None, amp=False):
        return self._makeRequest("GET", resource + getTimeStampStr(time, amp=amp))

    # PUT operation
    def put(self, resource, payload=None, time=None):
        return self._makeRequest("PUT", resource + getTimeStampStr(time), payload)

    # POST operation
    def post(self, resource, payload, time=None):
        return self._makeRequest("POST", resource + getTimeStampStr(time), payload)

    # DELETE operation
    def delete(self, resource, time=None, amp=False):
        return self._makeRequest("DELETE", resource + getTimeStampStr(time, amp=amp))

#=============================================================
def getTimeStampStr(time = None, amp=False):

    if time is None:
        return ''
    time = urllib.parse.quote(time,':')
    if amp is True:
       return '&timestamp=' + str(time)
    else:
       return '?timestamp=' + str(time)

#=============================================================
def getResultStatus(response):
    try:
        resp_dict = json.loads(response)
    except Exception as inst:
        return (999, 'Could not parse response')

    # response could have 2 possibilies: _resultCode or Result 
    res = '_resultCode'
    resText = '_resultText'                 

    if resp_dict.get('Result'):
        res = 'Result'
    if resp_dict.get('ResultText'):
        resText = 'ResultText'

    try:
        result = resp_dict[res]
    except Exception as inst:
        return (998, 'Result field not present')

    try:
        resultText = resp_dict[resText]
    except Exception as inst:
        return (997, 'ResultText field not present')

    # CSV code needs to store these values as constants
    try:
        CSV.constantValue['LastProvisioningResult'] = result
        CSV.constantValue['LastProvisioningResultText'] = resultText
    except: pass

    return (result, resultText)
    
#=============================================================
def getParam(response, param):
    try:
        resp_dict = json.loads(response)
    except Exception as inst:
        return (999, 'Could not parse response')

    try:
        result = resp_dict[param]
    except Exception as inst:
        return (998, 'Result field not present')

    return result

#=============================================================
def getSubscriberId(response):
    try:
        resp_dict = json.loads(response)
    except Exception as inst:
        return None

    try:
        result = resp_dict['SubscriberId']
    except Exception as inst:
        return None

    return result

#=============================================================
def getIMSI(response):
    try:
        resp_dict = json.loads(response)
    except Exception as inst:
        return None

    try:
        result = resp_dict['Imsi']
    except Exception as inst:
        return None

    return result

#=============================================================
def getOID(response):
    try:
        resp_dict = json.loads(response)
    except Exception as inst:
        return None

    try:
        result = resp_dict['ObjectId']
    except Exception as inst:
        return None

    return result

#=============================================================
def getAggregateGroupId(response):
    try:
        resp_dict = json.loads(response)
        responseXml = ET.XML(response)
    except Exception as inst:
        return None

    return responseXml.findtext('.//AggregateGroupId')

#=============================================================
def getResourceId(response):
    try:
        resp_dict = json.loads(response)
        responseXml = ET.XML(response)
    except Exception as inst:
        return None

    resourceIdArray = responseXml.find('ResourceIdArray')
    if resourceIdArray is not None:
        return resourceIdArray.findtext('value')

    return None

#=============================================================
def getSessionId(response):
    try:
        responseXml = ET.XML(response)
    except Exception as inst:
        return None

    ratingResponse = responseXml.find('RatingResponse')
    msg = ratingResponse.find('MtxDiamRoMsg')
    if msg is not None:
        return msg.findtext('SessionId')

    return None

#=============================================================
def getFUI(response):
    try:
        responseXml = ET.XML(response)
    except Exception as inst:
        return None

    ratingResponse = responseXml.find('RatingResponse')
    msg = ratingResponse.find('MtxDiamRoMsg')
    if msg is None:
        msg = ratingResponse.find('DemoDiamRoMsg')
    if msg is not None:
        multiList = msg.find('MultiServiceList')
        multiData = multiList.find('MtxMultiServiceData')
        info = multiData.find('LastUnitInfo')
        return ET.tostring(info)
    return None

#=============================================================
def getMsg(response):
    try:
        p_dict = json.loads(response)
    except Exception as inst:
        return None

    try:
        result = resp_dict['ResultText']
    except Exception as inst:
        return None

    return result

#=============================================================
def getSubscriptionOID(V3inst=0, queryValue=None, queryType='ExternalId', now=None):
        return getSubscriberOID(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)

#=============================================================
def getSubscriberOID(V3inst=0, queryValue=None, queryType='ExternalId', now=None):
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=None)
        if queryResponse: return getOID(queryResponse)
        else:             return None

#=============================================================
def getGroupOID(V3inst=0, queryValue=None, queryType='ExternalId', now=None):
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=None)
        if queryResponse: return getOID(queryResponse)
        else:             return None

#=============================================================
def getDeviceOID(V3inst=0, queryValue=None, queryType='ExternalId', now=None):
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=None)
        if queryResponse: return getOID(queryResponse)
        else:             return None

#=============================================================
def getUserOID(V3inst=0, queryValue=None, queryType='ExternalId', now=None):
        queryResponse = queryUser(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=None)
        if queryResponse: return getOID(queryResponse)
        else:             return None

#=============================================================
def parseParameterList(parameterList):
    parameterArray = "["
  
    for parameter in parameterList:
        parameterString = '{ "$": "MtxParameterData",'
        for i in parameter:
            if i in ('ParameterName', 'ParameterDefnId'):
                parameterString += ' "' + str(i) + '" : "' + str(parameter[i]) + '", '
        for i in parameter:
            if i not in ('ParameterName', 'ParameterDefnId'):
                parameterString += '"Value" : {"$": "MtxParameter' + str(i) + '",  "Value" : "' + str(parameter[i]) + '"}'

        parameterString += '},'
        
        parameterArray += parameterString 
   
    parameterArray += ']'
    return parameterArray

#=============================================================
def parseAttrMdc(attr):
    if attr is None:
        return None

    fieldPresent = False
    
    # Open attribute XML item and if that fails just return the attr as is
    try:
        attrStr = '{ "$": "' + attr.getDescriptorName() + '"'
    except:
        return attr

    # Process all containers sent in (usually only one)
    for container in attr.descObj.descObjList:
        # Process each field in the container
        for fieldName in container.fieldNameList:
            # Only care if field is populated
            if attr.isPresent(fieldName):
                fieldPresent = True
                
                # Get field value
                fieldValue = attr.getUsingName(fieldName)

                # See if a list (extra processing if so)
                if type(fieldValue) is list:
                    # Open XML item
                    attrStr += ', "' + fieldName + '": ['

                    # Process each list item
                    cnt = len(fieldValue)
                    for value in fieldValue: 
                        attrStr += '"' + str(value) + '"'
                        if cnt > 1:
                            attrStr += ','
                            cnt -= 1
                    attrStr += ']'
                elif fieldName == 'ShippingAddress' or fieldName == 'BillingAddress':
                    attrStr += ', "' + fieldName + '": '
                    attrStr +=  parseAttrMdc(fieldValue)
                else:
                    # Just a single value. Add to overall structure iff defined
                    fieldValue = attr.getUsingName(fieldName)
                        
                    # If the field value is in a special set, then want to clear the parameter
                    if str(fieldValue).lower() in ['empty', 'blank']: fieldValue = ''
                    
                    attrStr += ', "' + fieldName + '": "' + str(fieldValue) + '"'

    # Close attribute XML item
    if fieldPresent:    attrStr += '}'
    else:               attrStr = None

    return attrStr

#=============================================================
def validateResponse(response, method, shouldPass=True, returnParam=None):
    # Remove comment for debugging
    (result, text) = getResultStatus(response)
    if returnParam:
        foundParam = getParam(response, returnParam)

    if result != 0 or str(text).upper() != 'OK':

        if shouldPass is None:
            return False

        if returnParam:
            return (COMMON.debugFailure(method=method, status=result, msg=text, shouldPass=shouldPass), foundParam)
        else:
            return COMMON.debugFailure(method=method, status=result, msg=text, shouldPass=shouldPass)

    if shouldPass is None:
        return True

    if returnParam:
        return (COMMON.debugSuccess(method=method, shouldPass=shouldPass), foundParam)
    else:
        return COMMON.debugSuccess(method=method, shouldPass=shouldPass)

#=============================================================
def failed(eventPass = True):
    if eventPass:
        return False
    else:
        return True

#=============================================================
def passed(eventPass = True):
    if eventPass:
        return True
    else:
        return False

#=============================================================
def createAttr(containerName, fieldDct=None):
        rtnAttr = '{"$":"' + str(containerName) + '"'
        if fieldDct:
            for key, value in list(fieldDct.items()):
                rtnAttr += ', "' + str(key) + '": "' + str(value) + '"'
        rtnAttr += '}'
        return rtnAttr

#=============================================================
def getRoleArray(rolesPricingIds=None, rolesExternalIds=None):
    roleArray = ''
    if rolesPricingIds:
        if type(rolesPricingIds) is list:
            for pricingId in rolesPricingIds:
                roleArray += '{"$": "MtxRoleData", "PricingId": ' + str(pricingId) + '}'
        else:
            roleArray += '{"$": "MtxRoleData", "PricingId": ' + str(rolesPricingIds) + '}'

    if rolesExternalIds:
        if type(rolesExternalIds) is list:
            for externalId in rolesExternalIds:
                roleArray += '{"$": "MtxRoleData", "ExternalId": "' + str(externalId) + '"}'
        else:
            roleArray += '{"$": "MtxRoleData", "ExternalId": "' + str(rolesExternalIds) + '"}'

    return roleArray

#=============================================================
def importSubscriberBalanceValue(V3inst=0, queryType='ExternalId', externalId=None, resourceId=None,
            amount=0, startTime=None, createOnDemand=True, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Need in OID format
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=externalId, queryType=queryType, now=now)
        externalId = getOID(queryResponse)

    profTemplate = open(templates + 'subscriber_import_balance.json').read()
    profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'SUBSCRIBERSEARCHDATA', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(resourceId, None, 'BALANCERESOURCEID', profTemplate,
        'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(startTime, None, 'STARTTIME', profTemplate, 'StartTime')
    profTemplate = RESTHELPER.checkIfDefined(createOnDemand, None, 'CREATEONDEMAND', profTemplate, 'CreateOnDemand')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    
    url = '/json'
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    # Must use multi-request to send this through, as there is no URL for this action.
    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    #print response
    return validateResponse(response=response, method='multiRequest', shouldPass=eventPass, returnParam='ObjectId')

#====================================================================
def deleteUserSubscription(V3inst, queryValue=None, queryType='ExternalId', subQueryValue=None, subQueryType='ExternalId',
        now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True,
        apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/json/service/user/' + str(queryType) + '+' + str(queryValue) + '/subscription/' + str(subQueryType) + '+' + str(subQueryValue)

    amp = False
    delim = '?'

    if routingType and routingValue :
        url += '?TrafficRouteData='+routingType + str(routingValue)
        delim = '&'
        amp = True

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += '&ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=================================================================
def createUserSubscription(V3inst=0, queryValue=None, queryType=None,
    # Subscription
    subExternalId=None, subStatus=None, timeZone=None, billingCycle=None, dateOffset=None,
    taxStatus=None, taxCertificate=None, taxLocation=None, glCenter=None, name=None, subAttr=None,
    subApiEventData=None, 
    customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
    # Role
    rolesExternalIds=None, rolesPricingIds=None,
    #
    apiEventData=None, now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    subscription = createSubscription(V3inst, externalId=subExternalId, status=subStatus, timeZone=timeZone,
                          billingCycle=billingCycle, dateOffset=dateOffset, taxStatus=taxStatus,
                          taxCertificate=taxCertificate, taxLocation=taxLocation, glCenter=glCenter, name=name, attr=subAttr,
                          customerType=customerType, serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId,
                          exemptionCodeList=exemptionCodeList,
                          returnTemplate=True)
    subscription = subscription.rstrip('\n')

    roleArray = None
    if rolesPricingIds or rolesExternalIds:
        roleArray = getRoleArray(rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds)

    template = 'user_create_subscription.json'

    profTemplate = open(templates + template).read()
    profTemplate = RESTHELPER.checkIfDefined(subscription, None, 'SUBSCRIPTION', profTemplate, 'Subscription')
    profTemplate = RESTHELPER.checkIfDefined(roleArray, None, 'ROLES', profTemplate, 'Role')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')

    url = '/json/service/user/' + str(queryType) + '+' + str(queryValue) + '/subscription'
    if routingType and routingValue :
        url = '?TrafficRouteData=' + str(routingType) + str(routingValue)


    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    # Must use multi-request to send this through, as there is no URL for this action.
    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    #print response
    return validateResponse(response=response, method='createUserSubscription', shouldPass=eventPass, returnParam='ObjectId')

#Create Subscriber, Device and Purchase Offer
#=============================================================
def createSubscriberAndDevice(V3inst=0, externalId=None, queryValue=None, queryType=None,
        # User
        userId=None, userExternalId=None, firstName=None, lastName=None, contactEmail=None, contactPhoneNumber=None,
        contactPushTokenList=None, notificationPreference=None, language=None, userAttr=None,  userStatus=None,
        userApiEventData=None, 
        # Subscription
        subStatus=None, timeZone=None, billingCycle=None, dateOffset=None, subAttr=None, taxStatus=None, taxCertificate=None,
        taxLocation=None, glCenter=None, payload=None, subApiEventData=None,
        # Role
        rolesExternalIds=None, rolesPricingIds=None,
        # Device
        deviceId=None, deviceType=1, devAttr=None, accessNumbers=None, devStatus=None, deviceExternalId=None,
        devApiEventData=None,
        # PaymentMethod
        paymentGatewayId=None, paymentGatewayUserId=None, paymentGatewayOneTimeToken=None, paymentAttr=None, paymentName=None,
        paymentType=None, paymentIsDefault=None, paymentIsSysDefault=None, paymentApiEventData=None, 
        # Recharge Schedule
        firstRechargeTime=None, rechargePeriodType=None, rechargePeriodCoef=None, rechargeCycleTimeOfDay=None, rechargeCycleOffset=None,
        rechargeAmount=None, rechargeEndTimeExtensionOffsetUnit=None, rechargeEndTimeExtensionOffset=None, scheduledRechargeNotificationProfileId=None,
        rechargeApiEventData=None,
        # Offer
        chargeMethod=None, offerId=0, catalogItemId=None, offerStartTime=None, offerEndTime=None, offerIsExternal=None,
        offerAttr=None, endTimeRelativeOffset=None, endTimeRelativeOffsetUnit=None, downPayment=None,
        isTargetResource=None, useTargetResource=None, isRecurringFailureAllowed=None, parameterList=None,
        chargePurchaseProrationType=None, grantPurchaseProrationType=None, reason=None, info=None, offerApiEventData=None,
        paymentDueDate=None, offerStatusValue=None,
        # Offer Activation
        preActiveState=None, activationExpirationTime=None, activationExpirationRelativeOffsetUnit=None, activationExpirationRelativeOffset=None,
        autoActivationCycleResourceId=None, autoActivationTime=None, autoActivationRelativeOffsetUnit=None, autoActivationRelativeOffset=None,
        # Offer Cycle
        offerCycleType=None, offerCycleOffset=None, offerCycleResourceId=None, offerCycleStartTime=None,
        #
        apiEventData=None, now=None, eventPass=True, routingType=None, routingValue=None, purchaseInfo=False, executeMode=None,
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        multiRequestBuild=None, eligibilityCheck=True, geoData=None):

    subscriber = None
    subscription = None
    user = None
    roleArray = None
    device = None
    paymentMethod = None
    rechargeSchedule = None
    offer = None

    if now is None:
        now = offerStartTime
    # No queryValue, so create user/subscription/subscriber
    if not queryValue:
        # Create User, Subscription and Role
        if RESTV3.subUrl == 'user' or userId:
            url = '/json/service/user'
            funcName = 'createUserSubscriptionAndDevice'
            template = 'user_create_subscription_device_offer.json'
            # Populate the User Payload
            user = createUser(V3inst, userId=userId, externalId=userExternalId, firstName=firstName,
                      lastName=lastName, contactEmail=contactEmail, contactPhoneNumber=contactPhoneNumber,
                      contactPushTokenList=contactPushTokenList, notificationPreference=notificationPreference,
                      language=language, attr=userAttr, status=userStatus, apiEventData=userApiEventData,
                      returnTemplate=True)
            user = user.rstrip('\n')

            # Populate the subscription Payload
            subscription = createSubscription(V3inst, externalId=externalId, status=subStatus, timeZone=timeZone,
                      billingCycle=billingCycle, dateOffset=dateOffset, taxStatus=taxStatus,
                      taxCertificate=taxCertificate, taxLocation=taxLocation, glCenter=glCenter, attr=subAttr,
                      customerType=customerType, serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId,
                      exemptionCodeList=exemptionCodeList,
                      apiEventData=subApiEventData, returnTemplate=True)
            subscription = subscription.rstrip('\n')

            # Populate the roleArray Payload
            if rolesPricingIds or rolesExternalIds:
                roleArray = getRoleArray(rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds)

        # Create Subscription
        elif RESTV3.subUrl == 'subscription':
            url = '/json/service/subscription'
            funcName = 'createSubscriptionAndDevice'
            template = 'subscription_create_with_device_and_offer.json'
            subscription = createSubscription(V3inst, externalId=externalId, status=subStatus, timeZone=timeZone,
                      billingCycle=billingCycle, dateOffset=dateOffset, taxStatus=taxStatus,
                      taxCertificate=taxCertificate, taxLocation=taxLocation, glCenter=glCenter, attr=subAttr,
                      customerType=customerType, serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId,
                      exemptionCodeList=exemptionCodeList,
                      apiEventData=subApiEventData, returnTemplate=True)
            subscription = subscription.rstrip('\n')

        # Create Subscriber
        else:
            url = '/json/service/subscriber'
            funcName = 'createSubscriberAndDevice'
            template = 'subscriber_create_with_device_and_offer.json'
            subscriber = createSubscriber(V3inst=V3inst, externalId=externalId, now=now, payload=payload, billingCycle=billingCycle, dateOffset=dateOffset,
                eventPass=eventPass, firstName=firstName, lastName=lastName, contactEmail=contactEmail, contactPhoneNumber=contactPhoneNumber,
                contactPushTokenList=contactPushTokenList, notificationPreference=notificationPreference, timeZone=timeZone, attr=subAttr, status=subStatus,
                taxStatus=taxStatus, taxCertificate=taxCertificate, taxLocation=taxLocation, language=language, glCenter=glCenter,
                customerType=customerType, serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId,
                exemptionCodeList=exemptionCodeList,
                apiEventData=subApiEventData, returnTemplate=True )
            subscriber = subscriber.rstrip('\n')

    # We have an queryValue, so we must have an existing Subscriber/Subscription
    # We do not have an Offer of CatalogItem, so we just need to add a Device
    elif offerId == 0  and catalogItemId == None:
        url = '/json/service/' + RESTV3.subUrl + '/' + str(queryType) + '+' + str(queryValue) + '/device'
        funcName = 'subscriberCreateDevice'
        template = 'subscriber_create_device.json'

    # We have an queryValue, so we must have an existing Subscriber/Subscription
    # We do have an OfferId/CatalogItem so we need to add a Device and Purchase an Offer/Catalog
    else:
        funcName = 'subscriberCreateDeviceAndOffer'
        template = 'subscriber_add_device_and_offer.json'
        url = '/json/service/' + RESTV3.subUrl + '/' + str(queryType) + '+' + str(queryValue) + '/deviceandoffer'

    # So by now we have worked out Which Template, URL and function to use
    # ====================================================================

    # If we have a DeviceId, populate the device Payload
    if deviceId is not None:
        device = createDevice(V3inst, deviceId, externalId=deviceExternalId, deviceType=deviceType, attr=devAttr,
            now=now, accessNumbers=accessNumbers, status=devStatus, mobile=None, apiEventData=devApiEventData,
            executeMode=executeMode, returnTemplate=True)
        device = device.rstrip('\n')

    # If we have a Paymanr Method, populate the paymentMethod Payload
    if paymentGatewayId is not None and paymentGatewayOneTimeToken is not None:
        paymentMethod = subscriberAddPaymentMethod(V3inst, queryValue = None, paymentGatewayUserId=paymentGatewayUserId,
        paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, paymentGatewayId=paymentGatewayId,
        paymentType=paymentType, name=paymentName, isDefault=paymentIsDefault, isSysDefault=paymentIsSysDefault, queryType='ObjectId',
        paymentAttr=paymentAttr, now=now, eventPass=eventPass, executeMode=executeMode, returnTemplate=True)
        paymentMethod = paymentMethod.rstrip('\n')

    # If we have a rechargeSchedule, populate the rechargeSchedule Payload
    if rechargePeriodType is not None and rechargeAmount is not None:
        rechargeSchedule = subscriberAddRechargeSchedule(V3inst, queryValue = None, firstRechargeTime=firstRechargeTime, queryType='ObjectId',
        periodType= rechargePeriodType, periodCoef=rechargePeriodCoef, cycleTimeOfDay=rechargeCycleTimeOfDay, cycleOffset=rechargeCycleOffset,
        amount=rechargeAmount, paymentMethodResourceId=None, endTimeExtensionOffsetUnit=rechargeEndTimeExtensionOffsetUnit,
        endTimeExtensionOffset=rechargeEndTimeExtensionOffset,
        scheduledRechargeNotificationProfileId=scheduledRechargeNotificationProfileId, now=now, eventPass=eventPass, executeMode=executeMode, returnTemplate=True)
        rechargeSchedule = rechargeSchedule.rstrip('\n')

    # If we have a Offer/Catalog, populate the offer Payload
    #Put the offerId and/or catalogItemId into a list, that way we pick up the correct template on purchase
    #Set queryType to ObjectId to stop subscribeToOffer from doing a subscriber query
    if offerId != 0 or catalogItemId:
        if catalogItemId and type(catalogItemId) is not list:
            catalogItemId = [catalogItemId]
        if offerId != 0 and type(offerId) is not list:
            offerId = [offerId]
        offer = subscribeToOffer(V3inst=V3inst, externalId=None, queryType='ObjectId', offerId=offerId, catalogItemId=catalogItemId,
            offerStartTime=offerStartTime, offerEndTime=offerEndTime, offerIsExternal=offerIsExternal, attr=offerAttr,
            preActiveState=preActiveState, autoActivationTime=autoActivationTime,
            autoActivationRelativeOffsetUnit=autoActivationRelativeOffsetUnit, autoActivationRelativeOffset=autoActivationRelativeOffset,
            autoActivationCycleResourceId=autoActivationCycleResourceId, activationExpirationTime=activationExpirationTime,
            activationExpirationRelativeOffsetUnit=activationExpirationRelativeOffsetUnit, activationExpirationRelativeOffset=activationExpirationRelativeOffset,
            chargeMethod=chargeMethod, paymentMethodResourceId=None, paymentGatewayId=paymentGatewayId,
            paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, paymentGatewayUserId=paymentGatewayUserId, purchaseInfo=purchaseInfo, returnDataTemplate=True,
            offerCycleType=offerCycleType, offerCycleOffset=offerCycleOffset, offerCycleResourceId=offerCycleResourceId, offerCycleStartTime=offerCycleStartTime,
            endTimeRelativeOffsetUnit=endTimeRelativeOffsetUnit, endTimeRelativeOffset=endTimeRelativeOffset, downPayment=downPayment,
            isTargetResource=isTargetResource, useTargetResource=useTargetResource, isRecurringFailureAllowed=None,
            chargePurchaseProrationType=chargePurchaseProrationType, grantPurchaseProrationType=grantPurchaseProrationType, offerStatusValue=offerStatusValue,
            paymentDueDate=paymentDueDate, reason=reason, info=info, apiEventData=offerApiEventData, eligibilityCheck=eligibilityCheck, parameterList=parameterList)
        offer = offer.rstrip('\n')

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    # We now need to populate the Service Payload with any Payloads we have populated above
    profTemplate = open(templates + template).read()
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(subscriber, None, 'SUBSCRIBER', profTemplate, 'Subscriber')
    profTemplate = RESTHELPER.checkIfDefined(user, None, 'USER', profTemplate, 'User')
    profTemplate = RESTHELPER.checkIfDefined(subscription, None, 'SUBSCRIPTION', profTemplate, 'Subscription')
    profTemplate = RESTHELPER.checkIfDefined(roleArray, None, 'ROLES', profTemplate, 'Role')
    profTemplate = RESTHELPER.checkIfDefined(device, None, 'DEVICE', profTemplate, 'Device')
    profTemplate = RESTHELPER.checkIfDefined(paymentMethod, None, 'PAYMENTMETHOD', profTemplate, 'PaymentMethod')
    profTemplate = RESTHELPER.checkIfDefined(rechargeSchedule, None, 'RECHARGESCHEDULE', profTemplate, 'RechargeSchedule')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(eligibilityCheck, None, 'ELIGIBILITYCHECK', profTemplate, 'EligibilityCheck')

    # Attempt to Populate both, only one will actually work
    profTemplate = RESTHELPER.checkIfDefined(offer, None, 'OFFER', profTemplate, 'SubscriptionOfferArray')
    profTemplate = RESTHELPER.checkIfDefined(offer, None, 'OFFER', profTemplate, 'SubscriberOfferArray')

    if routingType and routingValue :
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if purchaseInfo:
       return (passed(eventPass), response)
    else:
       return validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='ObjectId')

#=============================================================
def addSubscriber(V3inst = 0, externalId = None, deviceId = None, deviceType = 1, offerId = 0, catalogItemId=None,
        offerStartTime = None, offerEndTime = None, serviceId = None, payload = None, subAttr = None, devAttr = None,
        billingCycle = None, eventPass=True, firstName=None, lastName=None, contactEmail=None, contactPhoneNumber=None,
        notificationPreference=None, timeZone=None, sharedWalletQuery=None, now=None, accessNumbers=None,
        subStatus=None, devStatus=None, taxStatus=None, taxCertificate=None, taxLocation=None, language=None,
        offerIsExternal=False, offerAttr=None, dateOffset=None, glCenter=None, name=None, noTouch=False, devOid=None,
        devQueryType='PhoneNumber', chargeMethod=None, paymentMethodResourceId=None, paymentGatewayId=None,
        paymentGatewayOneTimeToken=None, routingType=None, routingValue=None, offerCycleType=None, offerCycleStartTime=None,
        paymentGatewayUserId=None, offerCycleResourceId=None, offerCycleOffset=None, preActiveState=None,
        autoActivationTime=None, autoActivationRelativeOffsetUnit=None, autoActivationRelativeOffset=None, autoActivationCycleResourceId=None,
        activationExpirationTime=None, activationExpirationRelativeOffsetUnit=None,
        activationExpirationRelativeOffset=None, contactPushTokenList=None, endTimeRelativeOffset=None,
        endTimeRelativeOffsetUnit=None, chargeMethodAttr=None, chargePurchaseProrationType=None, grantPurchaseProrationType=None,
        subApiEventData=None, devApiEventData=None, offerApiEventData=None, parameterList=None,
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        paymentDueDate=None, offerStatusValue=None, reason=None, info=None, eligibilityCheck=True, geoData=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    #RESTHELPER.saveResultsIntoMainDriver(externalId, deviceId)
    time.sleep(0.09)
    if now is None:
        now = offerStartTime
    # Issue subscriber create command.  Validate response
    (retValue, oid) = createSubscriber(V3inst=V3inst, externalId = externalId, now = now,
        payload = payload, billingCycle = billingCycle, eventPass = eventPass, firstName = firstName,
        lastName = lastName, contactEmail = contactEmail, contactPhoneNumber = contactPhoneNumber, contactPushTokenList=contactPushTokenList,
        notificationPreference = notificationPreference, timeZone = timeZone, sharedWalletQuery = sharedWalletQuery,
        attr = subAttr, apiEventData=subApiEventData, status = subStatus, taxStatus=taxStatus, taxCertificate=taxCertificate, taxLocation=taxLocation, 
        customerType=customerType, serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId, exemptionCodeList=exemptionCodeList,
        language = language, dateOffset=dateOffset, glCenter=glCenter, name=name, routingType=routingType, routingValue=routingValue)
       

    # create a new device if a deviceId is provided
    if deviceId is not None:
        # Add device to the subscriber if one was specified.
        (retCode, deviceOid) = addDeviceToSubscriber(V3inst, oid, deviceId, deviceType, accessNumbers=accessNumbers,
            subQueryType = 'ObjectId', devQueryType = devQueryType, eventPass = eventPass, status=devStatus, attr = devAttr,
            apiEventData=devApiEventData, now = now, routingType=routingType, routingValue=routingValue)
        if not retCode:
            return (failed(eventPass), oid)

    if offerId != 0 or catalogItemId:
        if not subscribeToOffer(V3inst = V3inst, externalId = oid, offerId = offerId, catalogItemId=catalogItemId,
                offerStartTime = offerStartTime, offerEndTime = offerEndTime, eventPass = eventPass,
                queryType = 'ObjectId', now=now, offerIsExternal=offerIsExternal, attr=offerAttr,
                chargeMethod=chargeMethod, paymentMethodResourceId=paymentMethodResourceId,
                paymentGatewayId=paymentGatewayId, paymentGatewayOneTimeToken=paymentGatewayOneTimeToken,
                offerCycleType=offerCycleType, offerCycleResourceId=offerCycleResourceId, offerCycleOffset=offerCycleOffset, offerCycleStartTime=offerCycleStartTime,
                chargeMethodAttr=chargeMethodAttr, preActiveState=preActiveState, autoActivationTime=autoActivationTime,
                autoActivationRelativeOffsetUnit=autoActivationRelativeOffsetUnit, paymentGatewayUserId=None, 
                autoActivationRelativeOffset=autoActivationRelativeOffset, autoActivationCycleResourceId=autoActivationCycleResourceId,
                activationExpirationTime=activationExpirationTime, activationExpirationRelativeOffsetUnit=activationExpirationRelativeOffsetUnit,
                activationExpirationRelativeOffset=activationExpirationRelativeOffset, endTimeRelativeOffsetUnit=endTimeRelativeOffsetUnit,
                apiEventData=offerApiEventData, endTimeRelativeOffset=endTimeRelativeOffset, eligibilityCheck=eligibilityCheck,
                paymentDueDate=paymentDueDate, offerStatusValue=offerStatusValue, parameterList=parameterList):
              
            return (failed(eventPass), oid)

    return (passed(eventPass), oid)

#====================================================================
def createSubscription(V3inst=None, externalId=None, status=None, timeZone=None, billingCycle=None, attr=None,
        dateOffset=None, taxStatus=None, taxCertificate=None, taxLocation=None, glCenter=None, name=None, apiEventData=None,
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True, returnTemplate=False, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    global templates

    attrStr = None
    if attr is not None:
        #print 'Create subscriber:  attr = ' + str(attr)
        attrStr = parseAttrMdc(attr)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

   #check if we passed a string for billingCycle and convert it to a billing cycle template
    if billingCycle and type(billingCycle) is int :
        billingCycle = createBillingCycleData(int(billingCycle), startTime=now, dateOffset=dateOffset)

    profTemplate = open(templates + 'subscription_create.json').read()
    profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'EXTERNALID', profTemplate, 'ExternalId')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    profTemplate = RESTHELPER.checkIfDefined(timeZone, None, 'TIMEZONE', profTemplate, 'TimeZone')
    profTemplate = RESTHELPER.checkIfDefined(billingCycle, None, 'BILLINGCYCLE', profTemplate, 'BillingCycle')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(customerType, None, 'CUSTOMERTYPE', profTemplate, 'CustomerType')
    profTemplate = RESTHELPER.checkIfDefined(serviceAddress, None, 'SERVICEADDRESS', profTemplate, 'ServiceAddress')
    profTemplate = RESTHELPER.checkIfDefined(npa, None, 'NPA', profTemplate, 'Npa')
    profTemplate = RESTHELPER.checkIfDefined(nxx, None, 'NXX', profTemplate, 'Nxx')
    profTemplate = RESTHELPER.checkIfDefined(tenantId, None, 'TENANTID', profTemplate, 'TenantId')
    profTemplate = RESTHELPER.checkIfDefined(exemptionCodeList, None, 'EXEMPTIONCODELIST', profTemplate, 'ExemptionCodeList')
    profTemplate = RESTHELPER.checkIfDefined(taxStatus, None, 'TAXsTATUS', profTemplate, 'TaxStatus')
    profTemplate = RESTHELPER.checkIfDefined(taxCertificate, None, 'TAXCERTIFICATE', profTemplate, 'TaxCertificate')
    profTemplate = RESTHELPER.checkIfDefined(taxLocation, None, 'TAXLOCATION', profTemplate, 'TaxLocation')
    profTemplate = RESTHELPER.checkIfDefined(glCenter, None, 'GLCENTER', profTemplate, 'GlCenter')
    profTemplate = RESTHELPER.checkIfDefined(name, None, 'NAME', profTemplate, 'Name')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    if returnTemplate: return profTemplate

    url = '/json/subscription'
    if routingType and routingValue :
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)
    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method='createSubscription', shouldPass=eventPass, returnParam='ObjectId')

#=============================================================
def querySubscription(V3inst, queryValue, queryType='ExternalId', querySize=None, eventPass=True, now=None,
                      routingType=None, routingValue=None, useResponseSubscriptionTransformer=False, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    # Add value
    url = '/json/subscription/' + str(queryType) + '+' + str(queryValue)

    amp = False
    delim = '?'

    # Add query size if specified
    if querySize:
        amp = True
        url += delim + 'querySize=' + str(querySize)
        delim='&'
    else: amp = False
    if routingType and routingValue :
        url += delim + 'TrafficRouteData=' + str(routingType) + str(routingValue)

    if useResponseSubscriptionTransformer:
        #{[""]} escape code , see ASCII Encoding Reference
        url +=delim +'filter=%7Bresponse:%5B%22ResponseSubscriptionTransformer%22%5D%7D'


    response = V3inst.get(url, time=now, amp=amp)
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#====================================================================
def modifySubscription(V3inst, queryValue=None, queryType='ExternalId', externalId=None, status=None, timeZone=None, name=None, 
        billingCycle=None, dateOffset=None, immediateChange=None, billingCycleDisabled=None,
        attr=None, taxStatus=None, taxCertificate=None, taxLocation=None, glCenter=None, lastActivityUpdateTime=None,
        currentPaymentTokenResourceId=None, sysPaymentTokenResourceId=None, paymentGatewayUserId=None,
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        apiEventData=None, routingType=None, routingValue=None, now=None, executeMode=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    global templates

    attrStr = None
    if attr is not None:
        attrStr = parseAttrMdc(attr)

    if billingCycleDisabled:
        billingCycleDisabled='true'
    elif billingCycleDisabled == False:
        billingCycleDisabled='false'

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    #check if we passed a string for billingCycle and convert it to a billing cycle template
    if billingCycle and type(billingCycle) is int :
        billingCycle = createBillingCycleData(int(billingCycle), startTime=now, dateOffset=dateOffset, immediateChange=immediateChange)

    profTemplate = open(templates + 'subscription_modify.json').read()
    profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'EXTERNALID', profTemplate, 'ExternalId')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    profTemplate = RESTHELPER.checkIfDefined(timeZone, None, 'TIMEZONE', profTemplate, 'TimeZone')
    profTemplate = RESTHELPER.checkIfDefined(name, None, 'NAME', profTemplate, 'Name')
    profTemplate = RESTHELPER.checkIfDefined(billingCycle, None, 'BILLINGCYCLE', profTemplate, 'BillingCycle')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(taxStatus, None, 'TAXsTATUS', profTemplate, 'TaxStatus')
    profTemplate = RESTHELPER.checkIfDefined(taxCertificate, None, 'TAXCERTIFICATE', profTemplate, 'TaxCertificate')
    profTemplate = RESTHELPER.checkIfDefined(taxLocation, None, 'TAXLOCATION', profTemplate, 'TaxLocation')
    profTemplate = RESTHELPER.checkIfDefined(glCenter, None, 'GLCENTER', profTemplate, 'GlCenter')
    profTemplate = RESTHELPER.checkIfDefined(lastActivityUpdateTime, None, 'LASTACTIVITYUPDATETIME',
        profTemplate, 'LastActivityUpdateTime')
    profTemplate = RESTHELPER.checkIfDefined(currentPaymentTokenResourceId, None, 'CURRENTPAYMENTTOKENRECOURCEID',
        profTemplate, 'CurrentPaymentTokenResourceId')
    profTemplate = RESTHELPER.checkIfDefined(sysPaymentTokenResourceId, None, 'SYSPAYMENTTOKENRECOURCEID',
        profTemplate, 'SysPaymentTokenResourceId')
    profTemplate = RESTHELPER.checkIfDefined(billingCycleDisabled, None, 'billingCYCLEDISABLED', profTemplate, 'BillingCycleDisabled')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(customerType, None, 'CUSTOMERTYPE', profTemplate, 'CustomerType')
    profTemplate = RESTHELPER.checkIfDefined(serviceAddress, None, 'SERVICEADDRESS', profTemplate, 'ServiceAddress')
    profTemplate = RESTHELPER.checkIfDefined(npa, None, 'NPA', profTemplate, 'Npa')
    profTemplate = RESTHELPER.checkIfDefined(nxx, None, 'NXX', profTemplate, 'Nxx')
    profTemplate = RESTHELPER.checkIfDefined(tenantId, None, 'TENANTID', profTemplate, 'TenantId')
    profTemplate = RESTHELPER.checkIfDefined(exemptionCodeList, None, 'EXEMPTIONCODELIST', profTemplate, 'ExemptionCodeList')

    url = '/json/subscription/' + str(queryType) + '+' + str(queryValue)
    if routingType and routingValue :
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#====================================================================
def deleteSubscription(V3inst, queryValue=None, queryType='ExternalId', deleteSession=False, deleteDevices=False,
        now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True,
        apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/json/subscription/' + str(queryType) + '+' + str(queryValue)

    # URL extension for delete devices
    if deleteDevices == True or deleteDevices == '1' or deleteDevices == 1:
                 url += '?deleteDevice=True'
    else:        url += '?deleteDevice=False'
    amp=True
    if deleteSession == True:
        url += '&deleteSession=True'
    if routingType and routingValue :
        url += '&TrafficRouteData=' + str(routingType) + str(routingValue)
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += '&ApiEventData=' +URL.quote_plus(apiEventDataStr)
        
    # Debug output if globally setZZ
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
   
    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#====================================================================
def createUserAndSubscription(V3inst,
        # User
        userId=None, userExternalId=None, firstName=None, lastName=None,
        contactEmail=None, contactPhoneNumber=None, contactPushTokenList=None, notificationPreference=None,
        language=None, userAttr=None,  userStatus=None, userApiEventData=None,
        # Subscription
        subExternalId=None, subStatus=None, timeZone=None, billingCycle=None, dateOffset=None,
        taxStatus=None, taxCertificate=None, taxLocation=None, glCenter=None, name=None, subAttr=None,
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        subApiEventData=None,
        # Role
        rolesExternalIds=None, rolesPricingIds=None,
        #
        apiEventData=None, now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True):

        # User
        (uRetCode, uOid) = createUser(V3inst, userId=userId, externalId=userExternalId, firstName=firstName,
                              lastName=lastName, contactEmail=contactEmail, contactPhoneNumber=contactPhoneNumber,
                              contactPushTokenList=contactPushTokenList, notificationPreference=notificationPreference,
                              language=language, attr=userAttr, status=userStatus,
                              now=now, routingType=routingType, routingValue=routingValue, executeMode=executeMode,
                              eventPass=eventPass)
        # Subscription
        (sRetCode, sOid) = createSubscription(V3inst, externalId=subExternalId, status=subStatus, timeZone=timeZone,
                              billingCycle=billingCycle, dateOffset=dateOffset, taxStatus=taxStatus,
                              taxCertificate=taxCertificate, taxLocation=taxLocation, glCenter=glCenter, name=name, attr=subAttr,
                              customerType=customerType, serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId,
                              now=now, routingType=routingType, routingValue=routingValue, executeMode=executeMode,
                              eventPass=eventPass)

        # userAddSubscription
        retCode = userAddSubscription(V3inst, userQueryValue=uOid, subQueryValue=sOid,
                  rolesExternalIds=rolesExternalIds, rolesPricingIds=rolesPricingIds,
                  now=now, routingType=routingType, routingValue=routingValue, executeMode=executeMode, eventPass=eventPass)

        # For nor just assume it passes
        return (COMMON.debugSuccess(method='createUserAndSubscription', shouldPass=eventPass), uOid, sOid)

#=============================================================
def createUser(V3inst, userId=None, externalId=None, firstName=None, lastName=None,
        contactEmail=None, contactPhoneNumber=None, contactPushTokenList=None, notificationPreference=None,
        language=None, attr=None, status=None, now=None, routingType=None, routingValue=None, executeMode=None,
        tenantId=None, apiEventData=None, eventPass=True, returnTemplate=False, multiRequestBuild=None, timeZone=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    global templates

    attrStr = None
    if attr is not None:
        #print 'Create subscriber:  attr = ' + str(attr)
        attrStr = parseAttrMdc(attr)
    if contactPushTokenList:
        if type(contactPushTokenList) is not list:
            contactPushTokenList=[contactPushTokenList]

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'user_create.json').read()
    profTemplate = RESTHELPER.checkIfDefined(userId, None, 'USERID', profTemplate, 'UserId')
    profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'EXTERNALID', profTemplate, 'ExternalId')
    profTemplate = RESTHELPER.checkIfDefined(firstName, None, 'FIRSTNAME', profTemplate, 'FirstName')
    profTemplate = RESTHELPER.checkIfDefined(lastName, None, 'LASTNAME', profTemplate, 'LastName')
    profTemplate = RESTHELPER.checkIfDefined(contactEmail, None, 'EMAIL', profTemplate, 'ContactEmail')
    profTemplate = RESTHELPER.checkIfDefined(contactPhoneNumber, None, 'PHONENUMBER', profTemplate, 'ContactPhoneNumber')
    if contactPushTokenList:
        contactPushTokenList = str(contactPushTokenList).replace("'", '"')
    profTemplate = RESTHELPER.checkIfDefined(contactPushTokenList, None, 'PUSHTOKENLIST',
                         profTemplate,'ContactPushTokenList')
    profTemplate = RESTHELPER.checkIfDefined(notificationPreference, None, 'NOTIFICATION', profTemplate,
        'NotificationPreference')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(language, None, 'LANGUAGE', profTemplate, 'Language')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    profTemplate = RESTHELPER.checkIfDefined(tenantId, None, 'TENANTID', profTemplate, 'TenantId')
    profTemplate = RESTHELPER.checkIfDefined(timeZone, None, 'TIMEZONE', profTemplate, 'TimeZone')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    if returnTemplate: return profTemplate

    url = '/json/user'
    if routingType and routingValue :
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)
    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method='createUser', shouldPass=eventPass, returnParam='ObjectId')

#=============================================================
def queryUser(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None, routingType=None, routingValue=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    # Get start of URL
    if   queryType == 'ObjectId':       url = '/json/user/'
    elif queryType == 'ExternalId':     url = '/json/user/ExternalId+'
    elif queryType == 'UserId':         url = '/json/user/UserId+'
    elif queryType == 'GroupObjectId':  url ='/json/user/GroupObjectId+'
    elif queryType == 'GroupExternalId': url = '/json/user/GroupExternalId+'


    # Add value
    url += str(queryValue)

    if routingType and routingValue :
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response
    
#====================================================================
def modifyUserAndAuthData(V3inst, queryValue=None, queryType='ExternalId', userId=None, externalId=None, firstName=None, lastName=None,
        contactEmail=None, contactPhoneNumber=None, contactPushTokenList=None, notificationPreference=None,
        language=None, attr=None, status=None, loginId=None, password=None, userApiEventData=None,
        routingType=None, routingValue=None, now=None, executeMode=None, eventPass=True, authApiEventData=None,
        lastActivityUpdateTime=None, apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    global templates

    userData = None
    authData = None

    userData = modifyUser(V3inst=V3inst, queryValue=queryValue, queryType=queryType, userId=userId, externalId=externalId,
        firstName=firstName, lastName=lastName, contactEmail=contactEmail, contactPhoneNumber=contactPhoneNumber,
        contactPushTokenList=contactPushTokenList, notificationPreference=notificationPreference,
        language=language, attr=attr, status=status, lastActivityUpdateTime=lastActivityUpdateTime,
        apiEventData=userApiEventData, returnTemplate=True)
    userData = userData.rstrip('\n')

    authData = userModifyAuthData(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        loginId=loginId, password=password, apiEventData=authApiEventData, returnTemplate=True)
    authData = authData.rstrip('\n')

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'user_modify_user_and_authdata.json').read()
    profTemplate = RESTHELPER.checkIfDefined(userData, None, 'USER', profTemplate, 'User')
    profTemplate = RESTHELPER.checkIfDefined(authData, None, 'AUTHDATA', profTemplate, 'AuthData')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')

    url = '/'+RESTV3.urlPrefix+'/service/user/' + str(queryValue)
    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)
           
#====================================================================
def modifyUser(V3inst, queryValue=None, queryType='ExternalId', userId=None, externalId=None, firstName=None, lastName=None,
        contactEmail=None, contactPhoneNumber=None, contactPushTokenList=None, notificationPreference=None,
        language=None, attr=None, status=None, routingType=None, routingValue=None, now=None, executeMode=None, eventPass=True,
        lastActivityUpdateTime=None, tenantId=None, apiEventData=None, returnTemplate=False, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    global templates
    attrStr = None
    if attr is not None:
        #print 'Create subscriber:  attr = ' + str(attr)
        attrStr = parseAttrMdc(attr)
    if contactPushTokenList:
        if type(contactPushTokenList) is not list:
            contactPushTokenList=[contactPushTokenList]

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'user_modify.json').read()
    profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'EXTERNALID', profTemplate, 'ExternalId')
    profTemplate = RESTHELPER.checkIfDefined(userId, None, 'USERID', profTemplate, 'UserId')
    profTemplate = RESTHELPER.checkIfDefined(firstName, None, 'FIRSTNAME', profTemplate, 'FirstName')
    profTemplate = RESTHELPER.checkIfDefined(lastName, None, 'LASTNAME', profTemplate, 'LastName')
    profTemplate = RESTHELPER.checkIfDefined(contactEmail, None, 'EMAIL', profTemplate, 'ContactEmail')
    profTemplate = RESTHELPER.checkIfDefined(contactPhoneNumber, None, 'PHONENUMBER', profTemplate, 'ContactPhoneNumber')
    if contactPushTokenList:
        contactPushTokenList = str(contactPushTokenList).replace("'", '"')
    profTemplate = RESTHELPER.checkIfDefined(contactPushTokenList, None, 'PUSHTOKENLIST',
                         profTemplate,'ContactPushTokenList')
    profTemplate = RESTHELPER.checkIfDefined(notificationPreference, None, 'NOTIFICATION', profTemplate,
        'NotificationPreference')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(language, None, 'LANGUAGE', profTemplate, 'Language')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    profTemplate = RESTHELPER.checkIfDefined(lastActivityUpdateTime, None, 'LASTACTIVITYUPDATETIME',
        profTemplate, 'LastActivityUpdateTime')
    profTemplate = RESTHELPER.checkIfDefined(tenantId, None, 'TENANTID', profTemplate, 'TenantId')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    if returnTemplate:
        return profTemplate

    url = '/json/user/' + str(queryType) + '+' + str(queryValue)
  
    if routingType and routingValue :
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#====================================================================
def deleteUser(V3inst, queryValue=None, queryType='ExternalId', userId=None,
        deleteSubscription=False, deleteDevices=False, deleteSession=False,
        now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True,
        apiEventData=None, multiRequestBuild=None, removeExplicitMembership=False):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/json/user/' + str(queryType) + '+' + str(queryValue)
    delim = '?'
    amp = True

    if routingType and routingValue :
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)
        delim = '&'
        amp = True

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += delim + 'ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True
                delim = '&'

    if deleteDevices == True or deleteDevices == '1' or deleteDevices == 1:
        url += str(delim) + 'deleteDevice=True'
    else: url += delim + 'deleteDevice=False'
    delim = '&'
    amp = True

    if deleteSubscription == True or deleteSubscription == '1' or deleteSubscription == 1:
        url += str(delim) + 'deleteSubscription=True'
    else: url += delim + 'deleteDevice=False'

    if deleteSession == True or deleteSession == '1' or deleteSession == 1:
        url += str(delim) + 'deleteSession=True'
    else: url += delim + 'deleteDevice=False'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#====================================================================
def userQueryAuthData(V3inst, queryValue=None, queryType='ExternalId', now=None,
        routingType=None, routingValue=None, executeMode=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/json/user/' + str(queryType) + '+' + str(queryValue) + '/authentication'
    if routingType and routingValue :
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)

    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def userVerifyAuthData(V3inst, queryValue=None, queryType='ExternalId', password='pwd', now=None,
        routingType=None, routingValue=None, executeMode=None, eventPass=True, multiRequestBuild=None):

   # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryUser(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    profTemplate = open(templates + 'user_verify_authdata'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(password, None, 'PASSWORD', profTemplate, 'Password')

    url = '/'+RESTV3.urlPrefix+'/service/user/' + str(queryValue) + '/authentication/verify'
    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
            print(funcName + ' url: ' + url)
            print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def userModifyAuthData(V3inst, queryValue=None, queryType='ExternalId', loginId=None, password=None, now=None,
        routingType=None, routingValue=None, executeMode=None, eventPass=True, isService=False, returnTemplate=False,
        apiEventData=None, multiRequestBuild=None):

   # Get function name
    funcName = QAUTILS.getFunctionName()

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'user_modify_authdata.json').read()
    profTemplate = RESTHELPER.checkIfDefined(loginId, None, 'LOGINID', profTemplate, 'LoginId')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(password, None, 'PASSWORD', profTemplate, 'Password')
    if returnTemplate:
        return profTemplate

    serviceUrl=''
    if isService :
        serviceUrl ='/service'

    url = '/'+RESTV3.urlPrefix+serviceUrl+'/user/' + str(queryType) + '+' + str(queryValue) + '/authentication'
    if routingType and routingValue :
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
            print(funcName + ' url: ' + url)
            print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def userModifyPassword(V3inst, queryValue=None, queryType='ExternalId', oldPassword='old', newPassword='new', now=None,
        routingType=None, routingValue=None, apiEventData=None, executeMode=None, eventPass=True, multiRequestBuild=None):

   # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryUser(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'user_modify_password'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(oldPassword, None, 'OLDPASSWORD', profTemplate, 'OldPassword')
    profTemplate = RESTHELPER.checkIfDefined(newPassword, None, 'NEWPASSWORD', profTemplate, 'NewPassword')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    url = '/'+RESTV3.urlPrefix+'/service/user/' + str(queryValue) + '/password'
    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
            print(funcName + ' url: ' + url)
            print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def userAddGroup(V3inst, userQueryValue=None, userQueryType='ObjectId', grpQueryValue=None, grpQueryType='ObjectId',
        rolesPricingIds=None, rolesExternalIds=None, now=None, routingType=None, routingValue=None, executeMode=None,
        eventPass=True, apiEventData=None, multiRequestBuild=None):

   # Get function name
    funcName = QAUTILS.getFunctionName()

    roleArray=None
    if rolesPricingIds or rolesExternalIds:
        roleArray = getRoleArray(rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'user_roles.json').read()
    profTemplate = RESTHELPER.checkIfDefined('MtxRequestUserAddGroup', None, 'STARTTAG', profTemplate, '$')
    profTemplate = RESTHELPER.checkIfDefined(roleArray, None, 'ROLES', profTemplate, 'RoleArray')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')

    url = '/json/user/' +str(userQueryType) + '+' + str(userQueryValue) + '/group/' +str(grpQueryType)+ '+' + str(grpQueryValue)
    if routingType and routingValue :
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: 
        print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def userModifyGroup(V3inst, userQueryValue=None, userQueryType='ObjectId', grpQueryValue=None, grpQueryType='ObjectId',
        rolesPricingIds=None, rolesExternalIds=None, now=None, routingType=None, routingValue=None, executeMode=None,
        eventPass=True, apiEventData=None, multiRequestBuild=None, removeExplicitMembership=False):

   # Get function name
    funcName = QAUTILS.getFunctionName()

    roleArray=None
    if rolesPricingIds or rolesExternalIds:
        roleArray = getRoleArray(rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'user_roles.json').read()
    profTemplate = RESTHELPER.checkIfDefined('MtxRequestUserModifyGroup', None, 'STARTTAG', profTemplate, '$')
    profTemplate = RESTHELPER.checkIfDefined(roleArray, None, 'ROLES', profTemplate, 'RoleArray')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')

    url = '/json/user/' +str(userQueryType) + '+' + str(userQueryValue) + '/group/' +str(grpQueryType)+ '+' + str(grpQueryValue)
    if routingType and routingValue :
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: 
        print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def userRemoveGroup(V3inst, userQueryValue=None, userQueryType='ObjectId', grpQueryValue=None, grpQueryType='ObjectId',
        now=None, routingType=None, routingValue=None, apiEventData=None, executeMode=None, eventPass=True, multiRequestBuild=None, removeExplicitMembership=False):

   # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/json/user/' + str(userQueryType) + '+' + str(userQueryValue) + '/group/' + str(grpQueryType) + '+' + str(grpQueryValue)
    delim = '?'
    amp = False

    if routingType and routingValue :
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)
        delim = '&'
        amp = True

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += 'ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def userAddSubscription(V3inst, userQueryValue=None, userQueryType='ObjectId', subQueryValue=None, subQueryType='ObjectId',
        rolesPricingIds=None, rolesExternalIds=None, now=None, routingType=None, routingValue=None, executeMode=None,
        eventPass=True, apiEventData=None, multiRequestBuild=None):

   # Get function name
    funcName = QAUTILS.getFunctionName()

    roleArray=None
    if rolesPricingIds or rolesExternalIds:
        roleArray = getRoleArray(rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'user_roles.json').read()
    profTemplate = RESTHELPER.checkIfDefined('MtxRequestUserAddSubscription', None, 'STARTTAG', profTemplate, '$')
    profTemplate = RESTHELPER.checkIfDefined(roleArray, None, 'ROLES', profTemplate, 'RoleArray')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')

    url = '/json/user/' +str(userQueryType) + '+' + str(userQueryValue) + '/subscription/' +str(subQueryType)+ '+' + str(subQueryValue)
    if routingType and routingValue :
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: 
        print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def userModifySubscription(V3inst, userQueryValue=None, userQueryType='ObjectId', subQueryValue=None, subQueryType='ObjectId',
        rolesPricingIds=None, rolesExternalIds=None, now=None, routingType=None, routingValue=None, executeMode=None,
        eventPass=True, apiEventData=None, multiRequestBuild=None, removeExplicitMembership=False):

   # Get function name
    funcName = QAUTILS.getFunctionName()

    roleArray=None
    if rolesPricingIds or rolesExternalIds:
        roleArray = getRoleArray(rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
    profTemplate = open(templates + 'user_roles.json').read()

    profTemplate = RESTHELPER.checkIfDefined('MtxRequestUserModifySubscription', None, 'STARTTAG', profTemplate, '$')
    profTemplate = RESTHELPER.checkIfDefined(roleArray, None, 'ROLES', profTemplate, 'RoleArray')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')

    url = '/json/user/' +str(userQueryType) + '+' + str(userQueryValue) + '/subscription/' +str(subQueryType)+ '+' + str(subQueryValue)
    if routingType and routingValue :
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: 
        print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def userRemoveSubscription(V3inst, userQueryValue=None, userQueryType='ObjectId', subQueryValue=None, subQueryType='ObjectId',
        now=None, routingType=None, routingValue=None, apiEventData=None, executeMode=None, eventPass=True, multiRequestBuild=None, removeExplicitMembership=False):

   # Get function name
    funcName = QAUTILS.getFunctionName()

    delim = '?'
    amp = False

    url = '/json/user/' + str(userQueryType) + '+' + str(userQueryValue) + '/subscription/' + str(subQueryType) + '+' + str(subQueryValue)
    if routingType and routingValue :
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)
        delim = '?'
        amp = True

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += delim +'ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#============================================================
def queryUserEvent(V3inst, queryValue, queryType='ExternalId', querySize=None, queryCursor=None,
    eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypeStringArray =None, now=None, eventPass=True):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    # Some parameters should be lists of strings
    if eventTypeStringArray:
        if type(eventTypeStringArray) is list:  eventTypeStringArray = [str(i) for i in eventTypeStringArray]
        else:                                   eventTypeStringArray = [str(eventTypeStringArray)]

    # Translate subscriber to OID if needed
    if not eventPass and queryValue is None :
        queryValue = "9-9-9-9"

    # Assume optional parameters in the URL
    amp = False
    delim = '?'
    # Build the URL
    url = '/json/user/' + str(queryType) + '+' + str(queryValue) + '/events'

    if querySize is not None:
        url += delim + 'querySize=' + str(querySize)
        amp = True
        delim = '&'
    if queryCursor is not None:
        url += delim + 'queryCursor=' + str(queryCursor)
        amp = True
        delim = '&'
    if eventTimeLowerBound is not None:
        url += delim + 'eventTimeLowerBound=' + convertTimeToUrlFormat(eventTimeLowerBound)
        amp = True
        delim = '&'
    if eventTimeUpperBound is not None:
        url += delim + 'eventTimeUpperBound=' + convertTimeToUrlFormat(eventTimeUpperBound)
        amp = True
        delim = '&'
    if eventTypeStringArray is not None:
        url += delim + 'eventTypes=' + ",".join(eventTypeStringArray)
        amp = True
        delim = '&'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    # Make the REST call
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    (result, cursor) = validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='QueryCursor')
    if result : return (response,cursor)

#=============================================================
def groupAddUser(V3inst, userQueryValue=None, userQueryType='ObjectId', grpQueryValue=None, grpQueryType='ObjectId',
        rolesPricingIds=None, rolesExternalIds=None, now=None, routingType=None, routingValue=None, executeMode=None,
        apiEventData=None, eventPass=True, multiRequestBuild=None):

   # Get function name
    funcName = QAUTILS.getFunctionName()

    roleArray=None
    if rolesPricingIds or rolesExternalIds:
        roleArray = getRoleArray(rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'user_roles.json').read()
    profTemplate = RESTHELPER.checkIfDefined('MtxRequestGroupAddUser', None, 'STARTTAG', profTemplate, '$')
    profTemplate = RESTHELPER.checkIfDefined(roleArray, None, 'ROLES', profTemplate, 'RoleArray')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')

    url = '/json/group/' +str(grpQueryType) + '+' + str(grpQueryValue) + '/user/' +str(userQueryType)+ '+' + str(userQueryValue)
    if routingType and routingValue :
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: 
        print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupModifyUser(V3inst, userQueryValue=None, userQueryType='ObjectId', grpQueryValue=None, grpQueryType='ObjectId',
        rolesPricingIds=None, rolesExternalIds=None, now=None, routingType=None, routingValue=None, executeMode=None,
        apiEventData=None, eventPass=True, multiRequestBuild=None, removeExplicitMembership=False):

   # Get function name
    funcName = QAUTILS.getFunctionName()

    roleArray=None
    if rolesPricingIds or rolesExternalIds:
        roleArray = getRoleArray(rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'user_roles.json').read()
    profTemplate = RESTHELPER.checkIfDefined('MtxRequestGroupModifyUser', None, 'STARTTAG', profTemplate, '$')
    profTemplate = RESTHELPER.checkIfDefined(roleArray, None, 'ROLES', profTemplate, 'RoleArray')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')

    url = '/json/group/' +str(grpQueryType) + '+' + str(grpQueryValue) + '/user/' +str(userQueryType)+ '+' + str(userQueryValue)
    if routingType and routingValue :
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: 
        print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupRemoveUser(V3inst, userQueryValue=None, userQueryType='ObjectId', grpQueryValue=None, grpQueryType='ObjectId',
        apiEventData=None, now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True, multiRequestBuild=None, removeExplicitMembership=False):

   # Get function name
    funcName = QAUTILS.getFunctionName()

    delim = '?'
    amp = False

    url = '/json/group/' + str(grpQueryType) + '+' + str(grpQueryValue) + '/user/' + str(userQueryType) + '+' + str(userQueryValue)
    if routingType and routingValue :
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)
        delim = '&'
        amp = True

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += delim +'ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def queryGroupUsers(V3inst, queryValue=None, queryType='ObjectId', returnExternalId=None, querySize=None, queryCursor=None,
        routingType=None, routingValue=None, eventPass=True, now=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    # Assume optional parameters in the URL
    amp = False
    delim = '?'
    # Build the URL
    url = '/json/group/' + str(queryType) + '+' + str(queryValue) + '/users'

    if querySize is not None:
        url += delim + 'querySize=' + str(querySize)
        amp = True
        delim = '&'
    if queryCursor is not None:
        url += delim + 'queryCursor=' + str(queryCursor)
        amp = True
        delim = '&'
    if returnExternalId is not None:
        url += delim + 'returnExternalId=' + str(returnExternalId)
        amp = True
        delim = '&'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    # Make the REST call
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    (result, cursor) = validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='queryCursor')
    if result : return (response,cursor)

#=============================================================
def queryUserGroups(V3inst, queryValue=None, queryType='ObjectId', returnExternalId=None, querySize=None, queryCursor=None,
        routingType=None, routingValue=None, eventPass=True, now=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    # Assume optional parameters in the URL
    amp = False
    delim = '?'
    # Build the URL
    url = '/json/user/' + str(queryType) + '+' + str(queryValue) + '/groups'

    if querySize is not None:
        url += delim + 'querySize=' + str(querySize)
        amp = True
        delim = '&'
    if queryCursor is not None:
        url += delim + 'queryCursor=' + str(queryCursor)
        amp = True
        delim = '&'
    if returnExternalId is not None:
        url += delim + 'returnExternalId=' + str(returnExternalId)
        amp = True
        delim = '&'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    # Make the REST call
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    (result, cursor) = validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='queryCursor')
    if result : return (response,cursor)

#=============================================================
def queryUserSubscriptions(V3inst, queryValue=None, queryType='ObjectId', returnExternalId=None, querySize=None, queryCursor=None,
        routingType=None, routingValue=None, eventPass=True, now=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    # Assume optional parameters in the URL
    amp = False
    delim = '?'
    # Build the URL
    url = '/json/user/' + str(queryType) + '+' + str(queryValue) + '/subscriptions'

    if querySize is not None:
        url += delim + 'querySize=' + str(querySize)
        amp = True
        delim = '&'
    if queryCursor is not None:
        url += delim + 'queryCursor=' + str(queryCursor)
        amp = True
        delim = '&'
    if returnExternalId is not None:
        url += delim + 'returnExternalId=' + str(returnExternalId)
        amp = True
        delim = '&'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    # Make the REST call
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    (result, cursor) = validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='QueryCursor')
    if result : return (response,cursor)

#=============================================================
def querySubscriberUsers(V3inst, queryValue=None, queryType='ObjectId', returnExternalId=None, querySize=None, queryCursor=None,
        routingType=None, routingValue=None, eventPass=True, now=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    # Assume optional parameters in the URL
    amp = False
    delim = '?'
    # Build the URL
    url = '/json/'+RESTV3.subUrl+'/' + str(queryType) + '+' + str(queryValue) + '/users'

    if querySize is not None:
        url += delim + 'querySize=' + str(querySize)
        amp = True
        delim = '&'
    if queryCursor is not None:
        url += delim + 'queryCursor=' + str(queryCursor)
        amp = True
        delim = '&'
    if returnExternalId is not None:
        url += delim + 'returnExternalId=' + str(returnExternalId)
        amp = True
        delim = '&'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    # Make the REST call
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    (result, cursor) = validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='queryCursor')
    if result : return (response,cursor)


#=============================================================
def createSubscriber(V3inst, externalId=None, now=None, payload=None, billingCycle=None, eventPass=True,
        firstName=None, lastName=None, contactEmail=None, contactPhoneNumber=None, notificationPreference=None,
        timeZone=None, attr=None, sharedWalletQuery=None, status=None, taxStatus=None, taxCertificate=None, taxLocation=None,
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        language=None, dateOffset=None, glCenter=None, name=None, routingType=None, routingValue=None, executeMode=None,
        contactPushTokenList=None, apiEventData=None, returnTemplate=False, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    global templates
    if payload:
        firstName = payload['firstName'] 
        lastName = payload['lastName']
        contactEmail = payload['contactEmail']
        contactPhoneNumber = payload['contactPhoneNumber']
        timeZone = payload['timeZone']
        attr = payload['attr']
        notificationPreference = payload['notificationPreference']

    attrStr = None
    if attr is not None:
        #print 'Create subscriber:  attr = ' + str(attr)
        attrStr = parseAttrMdc(attr)

    if contactPushTokenList:
        if type(contactPushTokenList) is not list:
            contactPushTokenList=[contactPushTokenList]

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    #print 'Create subscriber:  attrStr = ' + attrStr
    #check if we passed a string for billingCycle and convert it to a billing cycle template
    if billingCycle and type(billingCycle) is int :
        billingCycle = createBillingCycleData(int(billingCycle), startTime=now, dateOffset=dateOffset)

    profTemplate = open(templates + 'subscriber_create.json').read()
    profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'EXTERNALID', profTemplate, 'ExternalId')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    profTemplate = RESTHELPER.checkIfDefined(firstName, None, 'FIRSTNAME', profTemplate, 'FirstName')
    profTemplate = RESTHELPER.checkIfDefined(lastName, None, 'LASTNAME', profTemplate, 'LastName')
    profTemplate = RESTHELPER.checkIfDefined(contactEmail, None, 'EMAIL', profTemplate, 'ContactEmail')
    profTemplate = RESTHELPER.checkIfDefined(contactPhoneNumber, None, 'PHONENUMBER', profTemplate,
        'ContactPhoneNumber')
    if contactPushTokenList:
        contactPushTokenList = str(contactPushTokenList).replace("'", '"')
    profTemplate = RESTHELPER.checkIfDefined(contactPushTokenList, None, 'PUSHTOKENLIST', profTemplate,
        'ContactPushTokenList')
    profTemplate = RESTHELPER.checkIfDefined(notificationPreference, None, 'NOTIFICATION', profTemplate,
        'NotificationPreference')
    profTemplate = RESTHELPER.checkIfDefined(timeZone, None, 'TIMEZONE', profTemplate, 'TimeZone')
    profTemplate = RESTHELPER.checkIfDefined(billingCycle, None, 'BILLINGCYCLE', profTemplate, 'BillingCycle')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(sharedWalletQuery, None, 'SHAREDWALLETDATA', profTemplate,
        'SharedWalletData')
    profTemplate = RESTHELPER.checkIfDefined(taxStatus, None, 'TAXsTATUS', profTemplate, 'TaxStatus')
    profTemplate = RESTHELPER.checkIfDefined(taxCertificate, None, 'TAXCERTIFICATE', profTemplate, 'TaxCertificate')
    profTemplate = RESTHELPER.checkIfDefined(taxLocation, None, 'TAXLOCATION', profTemplate, 'TaxLocation')
    profTemplate = RESTHELPER.checkIfDefined(glCenter, None, 'GLCENTER', profTemplate, 'GlCenter')
    profTemplate = RESTHELPER.checkIfDefined(name, None, 'NAME', profTemplate, 'Name')
    profTemplate = RESTHELPER.checkIfDefined(language, None, 'LANGUAGE', profTemplate, 'Language')
    profTemplate = RESTHELPER.checkIfDefined(customerType, None, 'CUSTOMERTYPE', profTemplate, 'CustomerType')
    profTemplate = RESTHELPER.checkIfDefined(serviceAddress, None, 'SERVICEADDRESS', profTemplate, 'ServiceAddress')
    profTemplate = RESTHELPER.checkIfDefined(npa, None, 'NPA', profTemplate, 'Npa')
    profTemplate = RESTHELPER.checkIfDefined(nxx, None, 'NXX', profTemplate, 'Nxx')
    profTemplate = RESTHELPER.checkIfDefined(tenantId, None, 'TENANTID', profTemplate, 'TenantId')
    profTemplate = RESTHELPER.checkIfDefined(exemptionCodeList, None, 'EXEMPTIONCODELIST', profTemplate, 'ExemptionCodeList')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')

#    profTemplate = RESTHELPER.checkIfDefined(routeData, None, 'ROUTEDATA', profTemplate, 'RouteData')
    
#    profTemplate = RESTHELPER.checkIfDefined(now, None, 'ROUTINGTYPE', profTemplate, 'RoutingType')
#    profTemplate = RESTHELPER.checkIfDefined(now, None, 'ROUTINGVALUE', profTemplate, 'RoutingValue')
    if returnTemplate:
        return profTemplate

    if routingType and routingValue :
        url = '/json/subscriber?TrafficRouteData='+routingType + str(routingValue)
    else:
        url = '/json/subscriber'
        
    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    
    return validateResponse(response=response, method='createSubscriber', shouldPass=eventPass, returnParam='ObjectId')

#========================================================
def modifySubscriber(V3inst, queryValue, payload=None, eventPass=True, queryType='ExternalId',
        firstName=None, lastName=None, contactEmail=None, contactPhoneNumber=None, notificationPreference=None,
        timeZone=None, attr=None, billingCycle=None, now=None, status=None, taxStatus=None, taxCertificate=None, taxLocation=None,
        language=None, externalId=None, dateOffset=None, glCenter=None, name=None, paymentGatewayUserId=None, currentPaymentTokenResourceId=None,
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        apiEventData=None, lastActivityUpdateTime=None, executeMode=None, billingCycleDisabled=None, contactPushTokenList=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    global templates

    # Get subscriber OID if queryType is not ObjectId
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    if payload:
        firstName = payload['firstName'] 
        lastName = payload['lastName']
        contactEmail = payload['contactEmail']
        contactPhoneNumber = payload['contactPhoneNumber']
        timeZone = payload['timeZone']
        attr = payload['attr']
        notificationPreference = payload['notificationPreference']

    attrStr = None
    if attr is not None:
        #print 'Create subscriber:  attr = ' + str(attr)
        attrStr = parseAttrMdc(attr)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    if contactPushTokenList:
        if type(contactPushTokenList) is not list:
            contactPushTokenList=[contactPushTokenList]
    if billingCycleDisabled:
        billingCycleDisabled='true'
    else:
        billingCycleDisabled='false'

    if billingCycle and type(billingCycle) is int :
        billingCycle = createBillingCycleData(int(billingCycle), startTime=now, dateOffset=dateOffset)

    profTemplate = open(templates + 'subscriber_modify.json').read()
    profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'EXTERNALID', profTemplate, 'ExternalId')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    profTemplate = RESTHELPER.checkIfDefined(firstName, None, 'FIRSTNAME', profTemplate, 'FirstName')
    profTemplate = RESTHELPER.checkIfDefined(lastName, None, 'LASTNAME', profTemplate, 'LastName')
    profTemplate = RESTHELPER.checkIfDefined(contactEmail, None, 'EMAIL', profTemplate, 'ContactEmail')
    profTemplate = RESTHELPER.checkIfDefined(contactPhoneNumber, None, 'PHONENUMBER', profTemplate,
        'ContactPhoneNumber')
    if contactPushTokenList:
        contactPushTokenList = str(contactPushTokenList).replace("'", '"')
    profTemplate = RESTHELPER.checkIfDefined(contactPushTokenList, None, 'PUSHTOKENLIST', profTemplate,
        'ContactPushTokenList')
    profTemplate = RESTHELPER.checkIfDefined(notificationPreference, None, 'NOTIFICATION', profTemplate,
        'NotificationPreference')
    profTemplate = RESTHELPER.checkIfDefined(timeZone, None, 'TIMEZONE', profTemplate, 'TimeZone')
    profTemplate = RESTHELPER.checkIfDefined(billingCycle, None, 'BILLINGCYCLE', profTemplate, 'BillingCycle')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(taxStatus, None, 'TAXsTATUS', profTemplate, 'TaxStatus')
    profTemplate = RESTHELPER.checkIfDefined(taxCertificate, None, 'TAXCERTIFICATE', profTemplate, 'TaxCertificate')
    profTemplate = RESTHELPER.checkIfDefined(taxLocation, None, 'TAXLOCATION', profTemplate, 'TaxLocation')
    profTemplate = RESTHELPER.checkIfDefined(glCenter, None, 'GLCENTER', profTemplate, 'GlCenter')
    profTemplate = RESTHELPER.checkIfDefined(name, None, 'NAME', profTemplate, 'Name')
    profTemplate = RESTHELPER.checkIfDefined(language, None, 'LANGUAGE', profTemplate, 'Language')
    profTemplate = RESTHELPER.checkIfDefined(paymentGatewayUserId, None, 'PAYMENTGATEWAYUSERID', profTemplate, 'PaymentGatewayUserId')
    profTemplate = RESTHELPER.checkIfDefined(currentPaymentTokenResourceId, None, 'CURRENTPAYMENTTOKENRECOURCEID',
        profTemplate, 'CurrentPaymentTokenResourceId')
    profTemplate = RESTHELPER.checkIfDefined(lastActivityUpdateTime, None, 'LASTACTIVITYUPDATETIME', 
        profTemplate, 'LastActivityUpdateTime')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(billingCycleDisabled, None, 'billingCYCLEDISABLED', profTemplate, 'BillingCycleDisabled')
    profTemplate = RESTHELPER.checkIfDefined(customerType, None, 'CUSTOMERTYPE', profTemplate, 'CustomerType')
    profTemplate = RESTHELPER.checkIfDefined(serviceAddress, None, 'SERVICEADDRESS', profTemplate, 'ServiceAddress')
    profTemplate = RESTHELPER.checkIfDefined(npa, None, 'NPA', profTemplate, 'Npa')
    profTemplate = RESTHELPER.checkIfDefined(nxx, None, 'NXX', profTemplate, 'Nxx')
    profTemplate = RESTHELPER.checkIfDefined(tenantId, None, 'TENANTID', profTemplate, 'TenantId')
    profTemplate = RESTHELPER.checkIfDefined(exemptionCodeList, None, 'EXEMPTIONCODELIST', profTemplate, 'ExemptionCodeList')

    url = '/json/subscriber/ObjectId+' + str(queryValue)
    
    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

# Rehome a Subscriber (Requires a multi sub-domain engine configuration)
#=============================================================
def subscriberRehome(V3inst, queryValue, queryType='ObjectId', routingType='RouteId', routingValue=2, eventPass=True,
        apiEventData=None, multiRequestBuild=None):
    global restVersion

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass)
        queryValue = getOID(queryResponse)

    url = '/json/'+RESTV3.subUrl+'/ObjectId+' + str(queryValue) + '/rehome/' + str(routingType) + '+' + str(routingValue)

    amp = False
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += '?ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True
    
    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        
    response = V3inst.put(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    #print response
    if validateResponse(response=response, method='subscriberRehome', shouldPass=eventPass):
        return response

#=============================================================
def userRehome(V3inst, queryValue, queryType='ObjectId', routingType='RouteId', routingValue=2, eventPass=True,
        apiEventData=None, multiRequestBuild=None):
    global restVersion

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryUser(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass)
        queryValue = getOID(queryResponse)

    url = '/json/user/' + str(queryValue) + '/rehome/' + str(routingType) + '+' + str(routingValue)

    amp = False
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += '?ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True
    
    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.put(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    #print response
    if validateResponse(response=response, method='userRehome', shouldPass=eventPass):
        return response


#====================================================
def subscribeToOffer(V3inst, externalId, offerId=None, catalogItemId=None, offerStartTime=None,
        offerEndTime=None, eventPass=True, queryType='ExternalId', now=None, offerIsExternal=False,
        offerId2=None, attr=None,dupAttr=True,future=False, purchaseInfo=False, executeMode=None,
        chargeMethod=None, paymentMethodResourceId=None, paymentGatewayId=None, paymentGatewayOneTimeToken=None, chargeMethodAttr=None,
        paymentGatewayUserId=None, paymentDueDate=None, deferredSettlement=None, deferredSettlementTimeout=None, deferredSettlementTimeoutAction=None,
        returnDataTemplate=False, offerCycleType=None, offerCycleResourceId=None, offerCycleOffset=None, offerCycleStartTime=None,
        preActiveState=None, autoActivationTime=None, autoActivationRelativeOffsetUnit=None, autoActivationRelativeOffset=None,
        autoActivationCycleResourceId=None, activationExpirationTime=None, activationExpirationRelativeOffsetUnit=None,
        activationExpirationRelativeOffset=None, endTimeRelativeOffsetUnit=None, endTimeRelativeOffset=None, downPayment=None,
        isTargetResource=None, useTargetResource=None, isRecurringFailureAllowed=None, apiEventData=None,
        chargePurchaseProrationType=None, grantPurchaseProrationType=None, reason=None, info=None, eligibilityCheck=True,
        contractPeriod=None, contractInterval=None, commitmentPeriod=None, commitmentPeriodInterval=None, isOpenContract=None,
        parameterList=None, offerStatusValue=None, etcScheduleRangeArray=None, etcScheduleRangeUnit=None, paymentScheduleRangeArray=None, paymentScheduleAmountArray=None, paymentScheduleLastAmount=None, delayCharge=None, multiRequestBuild=None, geoData=None):
    global templates

    parameterArray = None
    if parameterList:
        parameterArray = parseParameterList(parameterList)

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if now is None :
        now = offerStartTime
    
    # Need to force preactive as logic below doesn't work if set to False
    if preActiveState and str(preActiveState).lower() in ['1', 'true']:
          preActiveState = '1'
    else: preActiveState = None
    if deferredSettlement:
        deferredSettlement='true'
    if isRecurringFailureAllowed:
        isRecurringFailureAllowed='true'
    elif isRecurringFailureAllowed == False:
        isRecurringFailureAllowed='false'

    # Get subscriber OID if queryType is not ObjectId
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=externalId, queryType=queryType, eventPass=None, now=now)
        externalId = getOID(queryResponse)
    
    # Process any input attributes
    attrStr = None
    if attr is not None:
        #print 'Create subscriber:  attr = ' + str(attr)
        attrStr = parseAttrMdc(attr)
    chargeMethodAttrStr = None
    if chargeMethodAttr is not None:
        chargeMethodAttrStr = parseAttrMdc(chargeMethodAttr)
    
    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    # Allow for custom URLs (for BGAPI code)
    if CSV.overrideURL and 'purchase' in CSV.overrideOperations: custom = '/' + CSV.overrideURL
    else: custom = ''
    url = '/json' + custom + '/'+ RESTV3.subUrl+'/' + str(externalId) + '/offers'
        
    if type(catalogItemId) is list:
        offerId = catalogItemId

    offerArray = ''


    # populate contractParameterOverrideDataTemplate, which only support single one at moment
    contractParameterOverrideDataTemplate = createContractParameterOverrideData(etcScheduleRangeArray=etcScheduleRangeArray, etcScheduleRangeUnit=etcScheduleRangeUnit, paymentScheduleRangeArray=paymentScheduleRangeArray, paymentScheduleAmountArray=paymentScheduleAmountArray, paymentScheduleLastAmount=paymentScheduleLastAmount, delayCharge=delayCharge,contractPeriod=contractPeriod, contractInterval=contractInterval, commitmentPeriod=commitmentPeriod, commitmentPeriodInterval=commitmentPeriodInterval, isOpenContract=isOpenContract)

    # Input may be a list or may be a single item
    if type(offerId) is list:
        offerRequestArray = ""
        # Purchase offer and validate for each, append created resource id to list
        profTemplate = open(templates + 'xsubscriber_purchase_offer.json').read()
        for offer in offerId:
            dataTemplate = open(templates + 'OfferRequestArray.json').read()


            # populate paymentDueDate
            if type(paymentDueDate) is list:
                i = offerId.index(offer)
                dataTemplate = RESTHELPER.checkIfDefined(paymentDueDate[i], None, 'PAYMENTDUEDATE', dataTemplate, 'PaymentDueDate')
            else:
                dataTemplate = RESTHELPER.checkIfDefined(paymentDueDate, None, 'PAYMENTDUEDATE', dataTemplate, 'PaymentDueDate')

            # populate contractParameterOverrideData
            if contractParameterOverrideDataTemplate:
                dataTemplate = RESTHELPER.checkIfDefined(contractParameterOverrideDataTemplate, None, 'CONTRACTPARAMETEROVERRIDEDATA', dataTemplate, 'ONEWORDLINE')
            else:
                dataTemplate = RESTHELPER.removeOneWordLine(dataTemplate, 'CONTRACTPARAMETEROVERRIDEDATA')


            # Conditionally select product offer by ExternalId or ProductOfferId
            if offerIsExternal:
                dataTemplate = RESTHELPER.removeLine(dataTemplate, 'ProductOfferId')
                dataTemplate = RESTHELPER.removeLine(dataTemplate, 'CatalogItemId')
                dataTemplate = RESTHELPER.checkIfDefined(offer, None, 'OFFEREXTID', dataTemplate, 'ExternalId')
            else:
                dataTemplate = RESTHELPER.removeLine(dataTemplate, 'ExternalId')
                if catalogItemId:
                    dataTemplate = RESTHELPER.removeLine(dataTemplate, 'ProductOfferId')
                    dataTemplate = RESTHELPER.checkIfDefined(offer, None, 'CATALOGITEMID', dataTemplate, 'CatalogItemId')
                else:
                    dataTemplate = RESTHELPER.removeLine(dataTemplate, 'CatalogItemId')
                    dataTemplate = RESTHELPER.checkIfDefined(offer, None, 'OFFERID', dataTemplate, 'ProductOfferId')

            dataTemplate = RESTHELPER.checkIfDefined(offerStartTime, None, 'STARTTIME', dataTemplate, 'StartTime')
            dataTemplate = RESTHELPER.checkIfDefined(offerStatusValue, None, 'OFFERSTATUSVALUE', dataTemplate, 'OfferStatusValue')
            dataTemplate = RESTHELPER.checkIfDefined(offerEndTime, None, 'ENDTIME', dataTemplate, 'EndTime')
            dataTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', dataTemplate, 'Attr')
            dataTemplate = RESTHELPER.checkIfDefined(parameterArray, None, 'PARAMETERARRAY', dataTemplate, 'ParameterArray')
            dataTemplate = RESTHELPER.checkIfDefined(preActiveState, None, 'PREACTIVESTATE', dataTemplate, 'PreActiveState')
            dataTemplate = RESTHELPER.checkIfDefined(autoActivationTime, None, 'AUTOACTIVATIONTIME', dataTemplate, 'AutoActivationTime')
            dataTemplate = RESTHELPER.checkIfDefined(autoActivationRelativeOffsetUnit, None, 'AUTOACTIVATIONRELATIVEOFFSETUNIT', dataTemplate, 'AutoActivationRelativeOffsetUnit')
            dataTemplate = RESTHELPER.checkIfDefined(autoActivationRelativeOffset, None, 'aUTOACTIVATIONRELATIVEOFFSET', dataTemplate, 'AutoActivationRelativeOffset')
            dataTemplate = RESTHELPER.checkIfDefined(autoActivationCycleResourceId, None, 'AUTOACTIVATIONCYCLERESOURCEID', dataTemplate, 'AutoActivationCycleResourceId')

            if type(chargePurchaseProrationType) is list:
                i = offerId.index(offer)
                dataTemplate = RESTHELPER.checkIfDefined(chargePurchaseProrationType[i], None, 'CHARGEPURCHASEPRORATIONTYPE', dataTemplate, 'ChargePurchaseProrationType')
                dataTemplate = RESTHELPER.checkIfDefined(grantPurchaseProrationType[i], None, 'GRANTPURCHASEPRORATIONTYPE', dataTemplate, 'GrantPurchaseProrationType')
                dataTemplate = RESTHELPER.checkIfDefined(reason[i], None, 'REASON', dataTemplate, 'Reason')
                dataTemplate = RESTHELPER.checkIfDefined(info[i], None, 'INFO', dataTemplate, 'Info')
            else:
                dataTemplate = RESTHELPER.checkIfDefined(chargePurchaseProrationType, None, 'CHARGEPURCHASEPRORATIONTYPE', dataTemplate, 'ChargePurchaseProrationType')
                dataTemplate = RESTHELPER.checkIfDefined(grantPurchaseProrationType, None, 'GRANTPURCHASEPRORATIONTYPE', dataTemplate, 'GrantPurchaseProrationType')
                dataTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', dataTemplate, 'Reason')
                dataTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', dataTemplate, 'Info')

            if offerCycleType or offerCycleResourceId or offerCycleOffset or offerCycleStartTime:
                cycleTemplate = open(templates + 'xoffer_cycle_data.json').read()
                cycleTemplate = RESTHELPER.checkIfDefined(offerCycleType, None, 'CYCLETYPE', cycleTemplate, 'CycleType')
                cycleTemplate = RESTHELPER.checkIfDefined(offerCycleResourceId, None, 'CYCLERESOURCEID', cycleTemplate, 'CycleResourceId')
                cycleTemplate = RESTHELPER.checkIfDefined(offerCycleOffset, None, 'CYCLEOFFSET', cycleTemplate, 'CycleOffset')
                cycleTemplate = RESTHELPER.checkIfDefined(offerCycleStartTime, None, 'CYCLEsTARTTIME', cycleTemplate, 'CycleStartTime')
                cycleTemplate = RESTHELPER.removeLine(cycleTemplate, 'ImmediateChange')
                cycleTemplate = RESTHELPER.removeLine(cycleTemplate, 'CycleAlignmentDisabled')
                cycleTemplate = RESTHELPER.removeLine(cycleTemplate, 'CycleOwnerType')
                cycleTemplate = cycleTemplate.rstrip('\n')
            else:
                cycleTemplate = None
            dataTemplate = RESTHELPER.checkIfDefined(cycleTemplate, None, 'CYCLEDATA', dataTemplate, 'CycleData')

            dataTemplate = RESTHELPER.checkIfDefined(activationExpirationTime, None, 'ACTIVATIONEXPIRATIONTIME', dataTemplate, 'ActivationExpirationTime')
            dataTemplate = RESTHELPER.checkIfDefined(activationExpirationRelativeOffsetUnit, None, 'ACTIVATIONEXPIRATIONRELATIVEOFFSETUNIT', dataTemplate,
                'ActivationExpirationRelativeOffsetUnit')
            dataTemplate = RESTHELPER.checkIfDefined(activationExpirationRelativeOffset, None, 'aCTIVATIONEXPIRATIONRELATIVEOFFSET', dataTemplate,
                'ActivationExpirationRelativeOffset')

            dataTemplate = RESTHELPER.checkIfDefined(downPayment, None, 'DOWNPAYMENT', dataTemplate, 'DownPayment')
            dataTemplate = RESTHELPER.checkIfDefined(isRecurringFailureAllowed, None, 'ISRECURRINGFAILUREALLOWED', dataTemplate, 'IsRecurringFailureAllowed')
            dataTemplate = RESTHELPER.checkIfDefined(endTimeRelativeOffsetUnit, None, 'ENDTIMERELATIVEOFFSETUNIT', dataTemplate, 'EndTimeRelativeOffsetUnit')
            dataTemplate = RESTHELPER.checkIfDefined(endTimeRelativeOffset, None, 'ENDTIMERELATIVEOFFSET', dataTemplate, 'EndTimeRelativeOffset')
            
            dataTemplate = dataTemplate.rstrip('\n')
            if offerArray:
                offerArray += ', '
            offerArray += str(dataTemplate)

        if returnDataTemplate:
            return offerArray

        profTemplate = RESTHELPER.checkIfDefined(offerArray, None, 'OFFERREQUESTARRAY',profTemplate, 'OFFERREQUESTARRAY')
        if chargeMethod or paymentMethodResourceId or paymentGatewayId or paymentGatewayOneTimeToken or chargeMethodAttr:
            chargeMethodData = open(templates + 'charge_method_data.json').read()
            chargeMethodData = RESTHELPER.checkIfDefined(chargeMethod, None, 'CHARGEMETHOD', chargeMethodData, 'ChargeMethod')
            chargeMethodData = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', chargeMethodData, 'PaymentMethodResourceId')
            chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayId, None, 'PAYMENTGATEWAYID', chargeMethodData, 'PaymentGatewayId')
            chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayUserId, None, 'PAYMENTGATEWAYUSERID', chargeMethodData, 'PaymentGatewayUserId')
            chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayOneTimeToken, None, 'PAYMENTGATEWAYONETIMETOKEN', chargeMethodData, 'PaymentGatewayOneTimeToken')
            chargeMethodData = RESTHELPER.checkIfDefined(chargeMethodAttrStr, None, 'ATTR', chargeMethodData, 'ChargeMethodAttr')
            chargeMethodData = RESTHELPER.checkIfDefined(deferredSettlement, None, 'DEFERREDSETTLEMENT', chargeMethodData, 'DeferredSettlement')
            chargeMethodData = RESTHELPER.checkIfDefined(deferredSettlementTimeout, None, 'DEFERREDsETTLEMENTTIMEOUT', chargeMethodData, 'DeferredSettlementTimeout')
            chargeMethodData = RESTHELPER.checkIfDefined(deferredSettlementTimeoutAction, None, 'DEFERREDsETTLEMENTtIMEOUTACTION', chargeMethodData, 'DeferredSettlementTimeoutAction')
            chargeMethodData = chargeMethodData.rstrip('\n')
        else:
            chargeMethodData = None
        profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')
        profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
        profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
        if future: profTemplate = RESTHELPER.removeLine(profTemplate, 'EventTime')
        else:      profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
        profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'SUBID', profTemplate, 'ObjectId')
        profTemplate = RESTHELPER.checkIfDefined(eligibilityCheck, None, 'ELIGIBILITYCHECK', profTemplate, 'EligibilityCheck')

        # If future, then more work to do
        if future:
                # Return from here, as we're scheuling future purchases as a task
                return profTemplate
        
        # If Debug if globally set
        if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + profTemplate)
        
        response = V3inst.put(url, payload=profTemplate)
        if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
        
        (success, resourceId) = validateResponse(response=response, method=funcName,
            shouldPass=eventPass, returnParam='ResourceIdArray')

        if purchaseInfo:
           return (passed(eventPass), response)
        else :
           return (passed(eventPass), resourceId)
    else:
        # Purchase offer and validate, return created resourceId
        profTemplate = open(templates + 'xsubscriber_purchase_offer.json').read()
        dataTemplate = open(templates + 'OfferRequestArray.json').read()

        # Conditionally select product offer by ExternalId or ProductOfferId
        if offerIsExternal:
            #print offerId2
            #profTemplate = RESTHELPER.removeLine(profTemplate, 'ProductOfferId')
            if catalogItemId:
                dataTemplate = RESTHELPER.checkIfDefined(catalogItemId, None, 'OFFEREXTID', dataTemplate, 'ExternalId')
                dataTemplate = RESTHELPER.checkIfDefined(offerId2, None, 'CATALOGITEMID', dataTemplate, 'CatalogItemId')
                dataTemplate = RESTHELPER.removeLine(dataTemplate, 'ProductOfferId')
            else:
                dataTemplate = RESTHELPER.checkIfDefined(offerId, None, 'OFFEREXTID', dataTemplate, 'ExternalId')
                dataTemplate = RESTHELPER.checkIfDefined(offerId2, None, 'OFFERID', dataTemplate, 'ProductOfferId')
                dataTemplate = RESTHELPER.removeLine(dataTemplate, 'CatalogItemId')
        else:
            #dataTemplate = RESTHELPER.removeLine(dataTemplate, 'ExternalId')
            #print offerId2
            dataTemplate = RESTHELPER.checkIfDefined(catalogItemId, None, 'CATALOGITEMID', dataTemplate, 'CatalogItemId')
            dataTemplate = RESTHELPER.checkIfDefined(offerId, None, 'OFFERID', dataTemplate, 'ProductOfferId')
            dataTemplate = RESTHELPER.checkIfDefined(offerId2, None, 'OFFEREXTID', dataTemplate, 'ExternalId')

        dataTemplate = RESTHELPER.checkIfDefined(offerStartTime, None, 'STARTTIME', dataTemplate, 'StartTime')
        dataTemplate = RESTHELPER.checkIfDefined(paymentDueDate, None, 'PAYMENTDUEDATE', dataTemplate, 'PaymentDueDate')

        dataTemplate = RESTHELPER.checkIfDefined(offerStatusValue, None, 'OFFERSTATUSVALUE', dataTemplate, 'OfferStatusValue')

        # populate ContractParameterOverriderData
        if contractParameterOverrideDataTemplate:
            dataTemplate = RESTHELPER.checkIfDefined(contractParameterOverrideDataTemplate, None, 'CONTRACTPARAMETEROVERRIDEDATA', dataTemplate, 'ONEWORDLINE')
        else:
            dataTemplate = RESTHELPER.removeOneWordLine(dataTemplate, 'CONTRACTPARAMETEROVERRIDEDATA')


        if offerCycleType or offerCycleResourceId or offerCycleOffset or offerCycleStartTime:
            cycleTemplate = open(templates + 'xoffer_cycle_data.json').read()
            cycleTemplate = RESTHELPER.checkIfDefined(offerCycleType, None, 'CYCLETYPE', cycleTemplate, 'CycleType')
            cycleTemplate = RESTHELPER.checkIfDefined(offerCycleResourceId, None, 'CYCLERESOURCEID', cycleTemplate, 'CycleResourceId')
            cycleTemplate = RESTHELPER.checkIfDefined(offerCycleOffset, None, 'CYCLEOFFSET', cycleTemplate, 'CycleOffset')
            cycleTemplate = RESTHELPER.checkIfDefined(offerCycleStartTime, None, 'CYCLEsTARTTIME', cycleTemplate, 'CycleStartTime')
            cycleTemplate = RESTHELPER.removeLine(cycleTemplate, 'ImmediateChange')
            cycleTemplate = RESTHELPER.removeLine(cycleTemplate, 'CycleAlignmentDisabled')
            cycleTemplate = RESTHELPER.removeLine(cycleTemplate, 'CycleOwnerType')
            cycleTemplate = cycleTemplate.rstrip('\n')
        else:
            cycleTemplate = None
        dataTemplate = RESTHELPER.checkIfDefined(cycleTemplate, None, 'CYCLEDATA', dataTemplate, 'CycleData')
        dataTemplate = RESTHELPER.checkIfDefined(endTimeRelativeOffsetUnit, None, 'ENDTIMERELATIVEOFFSETUNIT', dataTemplate, 'EndTimeRelativeOffsetUnit')
        dataTemplate = RESTHELPER.checkIfDefined(endTimeRelativeOffset, None, 'ENDTIMERELATIVEOFFSET', dataTemplate, 'EndTimeRelativeOffset')
        dataTemplate = RESTHELPER.checkIfDefined(offerEndTime, None, 'ENDTIME', dataTemplate, 'EndTime')
        dataTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', dataTemplate, 'Attr')
        dataTemplate = RESTHELPER.checkIfDefined(parameterArray, None, 'PARAMETERARRAY', dataTemplate, 'ParameterArray')
        dataTemplate = RESTHELPER.checkIfDefined(preActiveState, None, 'PREACTIVESTATE', dataTemplate, 'PreActiveState')
        dataTemplate = RESTHELPER.checkIfDefined(autoActivationTime, None, 'AUTOACTIVATIONTIME', dataTemplate, 'AutoActivationTime')
        dataTemplate = RESTHELPER.checkIfDefined(autoActivationRelativeOffsetUnit, None, 'AUTOACTIVATIONRELATIVEOFFSETUNIT', dataTemplate, 'AutoActivationRelativeOffsetUnit')
        dataTemplate = RESTHELPER.checkIfDefined(autoActivationRelativeOffset, None, 'aUTOACTIVATIONRELATIVEOFFSET', dataTemplate, 'AutoActivationRelativeOffset')
        dataTemplate = RESTHELPER.checkIfDefined(autoActivationCycleResourceId, None, 'AUTOACTIVATIONCYCLERESOURCEID', dataTemplate, 'AutoActivationCycleResourceId')
        dataTemplate = RESTHELPER.checkIfDefined(activationExpirationRelativeOffsetUnit, None, 'ACTIVATIONEXPIRATIONRELATIVEOFFSETUNIT', dataTemplate, 'ActivationExpirationRelativeOffsetUnit')
        dataTemplate = RESTHELPER.checkIfDefined(activationExpirationRelativeOffset, None, 'aCTIVATIONEXPIRATIONRELATIVEOFFSET', dataTemplate, 'ActivationExpirationRelativeOffset')
        dataTemplate = RESTHELPER.checkIfDefined(activationExpirationTime, None, 'ACTIVATIONEXPIRATIONTIME', dataTemplate, 'ActivationExpirationTime')
        dataTemplate = RESTHELPER.checkIfDefined(downPayment, None, 'DOWNPAYMENT', dataTemplate, 'DownPayment')
        dataTemplate = RESTHELPER.checkIfDefined(isRecurringFailureAllowed, None, 'ISRECURRINGFAILUREALLOWED', dataTemplate, 'IsRecurringFailureAllowed')
        dataTemplate = RESTHELPER.checkIfDefined(chargePurchaseProrationType, None, 'CHARGEPURCHASEPRORATIONTYPE', dataTemplate, 'ChargePurchaseProrationType')
        dataTemplate = RESTHELPER.checkIfDefined(grantPurchaseProrationType, None, 'GRANTPURCHASEPRORATIONTYPE', dataTemplate, 'GrantPurchaseProrationType')
        dataTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', dataTemplate, 'Reason')
        dataTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', dataTemplate, 'Info')

        offerArray = dataTemplate.replace("\n","")
        profTemplate = RESTHELPER.checkIfDefined(offerArray, None, 'OFFERREQUESTARRAY',profTemplate, 'OfferRequestArray')

        if chargeMethod or paymentMethodResourceId or paymentGatewayId or paymentGatewayOneTimeToken or chargeMethodAttr:
            chargeMethodData = open(templates + 'charge_method_data.json').read()
            chargeMethodData = RESTHELPER.checkIfDefined(chargeMethod, None, 'CHARGEMETHOD', chargeMethodData, 'ChargeMethod')
            chargeMethodData = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', chargeMethodData, 'PaymentMethodResourceId')
            chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayId, None, 'PAYMENTGATEWAYID', chargeMethodData, 'PaymentGatewayId')
            chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayUserId, None, 'PAYMENTGATEWAYUSERID', chargeMethodData, 'PaymentGatewayUserId')
            chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayOneTimeToken, None, 'PAYMENTGATEWAYONETIMETOKEN', chargeMethodData, 'PaymentGatewayOneTimeToken')
            chargeMethodData = RESTHELPER.checkIfDefined(chargeMethodAttrStr, None, 'ATTR', chargeMethodData, 'ChargeMethodAttr')
            chargeMethodData = RESTHELPER.checkIfDefined(deferredSettlement, None, 'DEFERREDSETTLEMENT', chargeMethodData, 'DeferredSettlement')
            chargeMethodData = RESTHELPER.checkIfDefined(deferredSettlementTimeout, None, 'DEFERREDsETTLEMENTTIMEOUT', chargeMethodData, 'DeferredSettlementTimeout')
            chargeMethodData = RESTHELPER.checkIfDefined(deferredSettlementTimeoutAction, None, 'DEFERREDsETTLEMENTtIMEOUTACTION', chargeMethodData, 'DeferredSettlementTimeoutAction')
            chargeMethodData = chargeMethodData.replace("\n","")
        else:
            chargeMethodData = None
        profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')
        profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
        profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

        if future: profTemplate = RESTHELPER.removeLine(profTemplate, 'EventTime')
        else:      profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
        profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'SUBID', profTemplate, 'ObjectId')
        profTemplate = RESTHELPER.checkIfDefined(eligibilityCheck, None, 'ELIGIBILITYCHECK', profTemplate, 'EligibilityCheck')

        if future:
                # Return from here, as we're scheuling future purchases as a task
#               print 'profTemplate from future: ' + profTemplate
                return profTemplate

        # Debug output if globally set
        if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + profTemplate)
        
        response = V3inst.put(url, payload=profTemplate)
        if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

        # Debug output if globally set
        if QAUTILS.DebugLevel > 0: print(funcName + '  response: ' + response)
        
        (success, resourceId) = validateResponse(response=response, method=funcName,
            shouldPass=eventPass, returnParam='ResourceIdArray')
        if purchaseInfo:
           return (passed(eventPass), response)
        else:
           return (passed(eventPass), resourceId)

#=============================================================
def unsubscribeFromOffer(V3inst, subscriberId, resourceId=0, endTime=None, eventPass=True, apiEventData=None, 
        queryType='ExternalId', cancelInfo=False, executeMode=None, multiRequestBuild=None, eligibilityCheck=True):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Build resource id list if resourceId is list
    if type(resourceId) is list:
        numEntries = len(resourceId)
        entryCounter = 1
        resourceIdList = resourceId
        resourceId = ''
        for resource in resourceIdList:
            resourceId += str(resource)
            if entryCounter != numEntries:
                entryCounter += 1
                resourceId += ','

    url = '/json/'+RESTV3.subUrl+'/' + str(queryType) + '+' + str(subscriberId) + '/offers/' + str(resourceId)

    delim = '?'
    amp = False

    if executeMode is not None:
        url+= '?executeMode=' + str(executeMode)
        delim = '&'
        amp = True

    if endTime is not None:
        url+= delim + 'timestamp=' + endTime
        endTime=None
        delim = '&'
        amp = True
    
    if eligibilityCheck is not None:
        url+= delim + 'eligibilityCheck=' + str(eligibilityCheck).lower()
        delim = '&'
        amp = True

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += delim +'ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        
    response = V3inst.delete(url, time=endTime, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if cancelInfo :
        return (validateResponse(response=response, method=funcName, shouldPass=eventPass), response)
    else:
        return validateResponse(response=response, method=funcName, shouldPass=eventPass)
#=============================================================
def subscriberCancelOffer(V3inst, queryValue, resourceId=0, cancelType=None, grantCancelProrationType=None, chargeCancelProrationType=None,
        reason=None, info=None, now=None, queryType='ExternalId', cancelInfo=False, cancelOfferDataList='', eventPass=True, executeMode=None,
        apiEventData=None, contractCancelMode=None, debtCancellationMode=None, multiRequestBuild=None, isWaiveEarlyTerminationCharge=None, eligibilityCheck=True):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    profTemplate = open(templates + 'subscriber_cancel_offer.json').read()

    if type(resourceId) is not list:
        resourceId = [resourceId]
    cancelTemplate=''
    idArray = None

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    if cancelOfferDataList:
        for cancelOfferData in cancelOfferDataList:
            template = open(templates + 'cancel_offer_data.json').read()
            template = RESTHELPER.checkIfDefined(cancelOfferData["ResourceId"], None, 'RESOURCEID', template, 'ResourceId')
            template = RESTHELPER.checkIfDefined(cancelOfferData["CancelType"], None, 'CANCELTYPE', template, 'CancelType')
            template = RESTHELPER.checkIfDefined(cancelOfferData["GrantCancelProrationType"], None, 'GRANTCANCELPRORATIONTYPE', template, 'GrantCancelProrationType')
            template = RESTHELPER.checkIfDefined(cancelOfferData["ChargeCancelProrationType"], None, 'CHARGECANCELPRORATIONTYPE', template, 'ChargeCancelProrationType')
            template = RESTHELPER.checkIfDefined(cancelOfferData["ContractCancelMode"], None, 'CONTRACTCANCELMODE', template, 'ContractCancelMode')
            template = RESTHELPER.checkIfDefined(cancelOfferData["DebtCancellationMode"], None, 'DEBTCANCELLATIONMODE', template, 'DebtCancellationMode')

            template = RESTHELPER.checkIfDefined(cancelOfferData["IsWaiveEarlyTerminationCharge"], None, 'ISWAIVEEARLYTERMINATIONCHARGE', template, 'IsWaiveEarlyTerminationCharge')
            template = RESTHELPER.checkIfDefined(cancelOfferData["Reason"], None, 'REASON', template, 'Reason')
            template = RESTHELPER.checkIfDefined(cancelOfferData["Info"], None, 'INFO', template, 'Info')
            cancelTemplate += template
    elif cancelType or grantCancelProrationType or chargeCancelProrationType or reason or info or contractCancelMode or debtCancellationMode:
        for id in resourceId:
            template = open(templates + 'cancel_offer_data.json').read()
            template = RESTHELPER.checkIfDefined(id, None, 'RESOURCEID', template, 'ResourceId')
            template = RESTHELPER.checkIfDefined(cancelType, None, 'CANCELTYPE', template, 'CancelType')
            template = RESTHELPER.checkIfDefined(grantCancelProrationType, None, 'GRANTCANCELPRORATIONTYPE', template, 'GrantCancelProrationType')
            template = RESTHELPER.checkIfDefined(chargeCancelProrationType, None, 'CHARGECANCELPRORATIONTYPE', template, 'ChargeCancelProrationType')
            template = RESTHELPER.checkIfDefined(contractCancelMode, None, 'CONTRACTCANCELMODE', template, 'ContractCancelMode')
            template = RESTHELPER.checkIfDefined(debtCancellationMode, None, 'DEBTCANCELLATIONMODE', template, 'DebtCancellationMode')
            template = RESTHELPER.checkIfDefined(isWaiveEarlyTerminationCharge, None, 'ISWAIVEEARLYTERMINATIONCHARGE', template, 'IsWaiveEarlyTerminationCharge')
            template = RESTHELPER.checkIfDefined(reason, None, 'REASON', template, 'Reason')
            template = RESTHELPER.checkIfDefined(info, None, 'INFO', template, 'Info')
            cancelTemplate += template
    else:
        idArray = resourceId

    profTemplate = RESTHELPER.checkIfDefined(cancelTemplate, '', 'CANCELDATAARRAY', profTemplate, 'CancelDataArray')
    profTemplate = RESTHELPER.checkIfDefined(idArray, None, 'RESOURCEIDARRAY', profTemplate, 'ResourceIdArray')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(eligibilityCheck, None, 'ELIGIBILITYCHECK', profTemplate, 'EligibilityCheck')

    url = '/json/'+RESTV3.subUrl+'/' + str(queryType) + '+' + str(queryValue) + '/offers'
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if cancelInfo :
        return (validateResponse(response=response, method=funcName, shouldPass=eventPass), response)
    else:
        return validateResponse(response=response, method=funcName, shouldPass=eventPass)


#=============================================================
def addSubscriberThreshold(V3inst, queryValue, thresholdId, resourceId, threshName, val, notify, eventPass=True,
        now=None, queryType='ExternalId', recurringStart = None, recurringStop = None, virtualCreditLimitIsPercent = None,
        rechargeAmount=None, rechargePaymentMethodResourceId=None, executeMode=None, 
        isTemporaryCreditLimit=None, apiEventData=None, multiRequestBuild=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if notify:
        thresholdNotification = 'true'
    elif notify == None:
        thresholdNotification = None
    else:
        thresholdNotification = 'false'

    if virtualCreditLimitIsPercent:
        virtualCreditLimitIsPercent = 'true'
    else:
        virtualCreditLimitIsPercent = None
    if isTemporaryCreditLimit:
        isTemporaryCreditLimit = 'true'
    elif isTemporaryCreditLimit == None:
        isTemporaryCreditLimit = None
    else:
        isTemporaryCreditLimit = 'false'

    if resourceId is None:
        v3inst = QAUTILS.getDatacontainerConnection()
        walletMdc = v3inst.subscriberQueryWallet(queryType=queryType, queryValue=queryValue, now=now)
        resourceId = COMMON.getResourceId(walletMdc, thresholdId)
        if resourceId is None:
            return COMMON.debugFailure(method='addSubscriberThreshold', status=1, msg='ThresholdId not found')

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_add_threshold.json').read()
    profTemplate = RESTHELPER.checkIfDefined(thresholdId, None, 'THRESHOLDID', profTemplate, 'ThresholdId')
    profTemplate = RESTHELPER.checkIfDefined(threshName, None, 'NAME', profTemplate, 'Name')
    profTemplate = RESTHELPER.checkIfDefined(val, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(recurringStart, None, 'RECURRINGSTART', profTemplate, 'RecurringStart')
    profTemplate = RESTHELPER.checkIfDefined(recurringStop, None, 'RECURRINGSTOP', profTemplate, 'RecurringStop')
    profTemplate = RESTHELPER.checkIfDefined(thresholdNotification, None, 'NOTIFICATIONSTATE', profTemplate,
        'NotificationState')
    profTemplate = RESTHELPER.checkIfDefined(virtualCreditLimitIsPercent, None, 'VIRTUALCREDITLIMITISPERCENT', profTemplate,
        'VirtualCreditLimitIsPct')
    if rechargeAmount or rechargePaymentMethodResourceId:
        rechargeData = open(templates + 'recharge_threshold_data.json').read()
        rechargeData = RESTHELPER.checkIfDefined(rechargeAmount, None, 'RECHARGEAMOUNT', rechargeData, 'Amount')
        rechargeData = RESTHELPER.checkIfDefined(rechargePaymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID',
            rechargeData, 'PaymentMethodResourceId')
    else:
        rechargeData = None
    profTemplate = RESTHELPER.checkIfDefined(rechargeData, None, 'RECHARGEDATA', profTemplate, 'RechargeData')
    profTemplate = RESTHELPER.checkIfDefined(isTemporaryCreditLimit, None, 'ISTEMPORARYCREDITLIMIT', profTemplate, 'IsTemporaryCreditLimit')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')

    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')

    url = '/json/'+RESTV3.subUrl+'/ObjectId+' + str(queryValue) + '/wallet/' + str(resourceId) + '/thresholds'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def removeSubscriberThreshold(V3inst, subscriberId, indexId, thresholdId, queryType='ExternalId', now=None,
    removeThresholdOnly=None, removeRechargeDataOnly=None, isTemporaryCreditLimit=False,
    apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=subscriberId, queryType=queryType, now=now)
        subscriberId = getOID(queryResponse)

    url = '/json/'+RESTV3.subUrl+'/ObjectId+' + str(subscriberId) + '/wallet/' + str(indexId) + '/thresholds/' + str(thresholdId)

    delim = '?'
    amp = False

    if removeThresholdOnly:
        url += '?removeThresholdOnly=true'
        delim = '&'
        amp = True

    if removeRechargeDataOnly:
        url += delim + 'removeRechargeDataOnly=true'
        delim = '&'
        amp = True

    if isTemporaryCreditLimit:
        url += delim + 'isTemporaryCreditLimit=true'
        delim = '&'
        amp = True

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += delim +'ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName)

#=============================================================
def querySubscriberThresholdRechargeDefn(V3inst, queryValue, balanceResourceId=None, now=None, queryType='ExternalId', eventPass=True,
        apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass, now=now)
        queryValue = getOID(queryResponse)

    url = '/json/'+RESTV3.subUrl+'/' + str(queryValue) + '/threshold_recharge_defn'
    if balanceResourceId:
        url += '?resourceId=' + str(balanceResourceId)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def addSubscriberBalance(V3inst, subscriberId, balanceList, now=None, queryType='ExternalId', eventPass=True, executeMode=None,
        apiEventData=None, multiRequestBuild=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=subscriberId, queryType=queryType, now=now)
        subscriberId = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    # Make separate REST calls for each balance to add
    for balance in balanceList:
        templateId = balance['BalanceTemplateId']
        if balance['InitAmount']:
            initAmount = balance['InitAmount']
        profTemplate = open(templates + 'subscriber_add_balance.json').read()
        profTemplate = RESTHELPER.checkIfDefined(templateId, None, 'TEMPLATEID', profTemplate, 'BalanceTemplateId')
        profTemplate = RESTHELPER.checkIfDefined(initAmount, None, 'INITAMOUNT', profTemplate, 'InitAmount')
        profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
        profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
        profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
        url = '/json/'+RESTV3.subUrl+'/ObjectId+' + str(subscriberId)
           
        # Debug output if globally set
        if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + profTemplate)
        
        response = V3inst.put(url, payload=profTemplate)
        if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
        return validateResponse(response=response, method='addSubscriberBalance', shouldPass=eventPass)


#=============================================================
def multiQuery(V3inst, subscriberValues = [], groupValues = [], deviceValues = [], userValues = [], subscriptionValues = [],
               queryType='ExternalId', eventPass=True, now=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    amp = False
    request = '/json/service/multiquery?'
    if queryType == 'ObjectId':
        for s in subscriberValues:
            request = request + 'subscriber='+s+'&'
        for g in groupValues:
            request = request + 'group='+g+'&'
        for d in deviceValues:
            request = request + 'device='+d+'&'
        for u in userValues:
            request = request + 'user='+u+'&'
        for t in subscriptionValues:
            request = request + 'subscription='+t+'&'
    else:
        for s in subscriberValues:
            request = request + 'subscriber='+queryType+'+'+s+'&'
        for g in groupValues:
            request = request + 'group='+queryType+'+'+g+'&'
        for d in deviceValues:
            request = request + 'device='+queryType+'+'+d+'&'
        for u in userValues:
            request = request + 'user='+queryType+'+'+u+'&'
        for t in subscriptionValues:
            request = request + 'subscription='+queryType+'+'+t+'&'

    request = request[:-1]

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + request)
        
    response = V3inst.get(request, time=now, amp=False)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method='multiquery', shouldPass=eventPass):
        return response

#=============================================================
def querySubscriber(V3inst, queryValue, queryType='ExternalId', querySize=None, eventPass=True, now=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Get start of URL
    url = '/json/'+RESTV3.subUrl+'/' + str(queryType) + '+' + str(queryValue)

 
    # Add query size if specified
    if querySize:
        amp = True
        url += '?querySize=' + str(querySize)
    else: amp = False
        
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def querySubscriberCursor(V3inst, queryValue, queryType='ExternalId', querySize=None, eventPass=True, now=None, multiRequestBuild=None):
    # Query the sub
    response = querySubscriber(V3inst, queryValue, queryType=queryType, querySize=querySize, eventPass=eventPass, now=now)
        
    # Want to extract any QueryCursor value.  
    # There has to be a better way then this...
    # Assume nothing found
    queryCursor = {}
    
    # Split response into dictionary per line
    respDict = response.split('\n')
    # Look at each line
    for item in respDict:
     for cursor in ['AdminGroupCursor', 'ParentGroupCursor']:
        # See if string is in this entry
        if cursor in item:
                # Get value
                queryCursor[cursor] = str(item.split('>')[1].split('<')[0])
                
    # Debug output
    #print 'queryCursor = ' + str(queryCursor)
    
    # Return response and dictionary
    return (response, queryCursor)

#=============================================================
def queryGroupCursor(V3inst, queryValue, queryType='ExternalId', querySize=None, eventPass=True, now=None, multiRequestBuild=None):
    # Query the sub
    response = queryGroup(V3inst, queryValue, queryType=queryType, querySize=querySize, eventPass=eventPass, now=now)
        
    # Want to extract any QueryCursor value.  
    # There has to be a better way then this...
    # Assume nothing found
    queryCursor = {}
    
    # Split response into dictionary per line
    respDict = response.split('\n')
    
    # Look at each line
    for item in respDict:
     for cursor in ['AdminCursor', 'SubscriberMemberCursor', 'GroupMemberCursor']:
        # See if string is in this entry
        if cursor in item:
                # Get value
                queryCursor[cursor] = item.split(' ')[1].split(',')[0]
                
    # Debug output
    #print 'queryCursor = ' + str(queryCursor)
    
    # Return response and dictionary
    return (response, queryCursor)

#========================================================
def subscriberModifyOffer(V3inst, queryValue, queryType, resourceId, now=None, startTime=None, endTime=None, attr=None,
    cycleType=None, cycleResourceId=None, cycleOffset=None, cycleAlignmentDisabled=None, cycleStartTime=None, cycleEndTime=None, immediateChange=None, isRecurringFailureAllowed=None, status=None,
    offerStatusValue=None, apiEventData=None, eventPass=True, executeMode=None, modifyInfo=False, parameterList=None, multiRequestBuild=None, endTimeExtensionOffset=None, endTimeExtensionOffsetUnit=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Get subscriber OID if queryType is not ObjectId
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    attrStr = None
    if attr is not None:
        #print 'Create subscriber:  attr = ' + str(attr)
        attrStr = parseAttrMdc(attr)
    
    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    parameterArray = None
    if parameterList:
        parameterArray = parseParameterList(parameterList)

    # Need to force binary items to None if false as Engine interprets a value of "False" as set.
    if cycleAlignmentDisabled and str(cycleAlignmentDisabled).lower() in ['1', 'true']:
          cycleAlignmentDisabled = '1'
    else: cycleAlignmentDisabled = None
    if immediateChange and str(immediateChange).lower() in ['1', 'true']:
          immediateChange = '1'
    else: immediateChange = None
    
    profTemplate = open(templates + 'subscriber_modify_offer.json').read()
    profTemplate = RESTHELPER.checkIfDefined(startTime, None, 'STARTTIME', profTemplate, 'StartTime')
    profTemplate = RESTHELPER.checkIfDefined(endTime, None, 'ENDTIME', profTemplate, 'EndTime')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(parameterArray, None, 'PARAMETERARRAY', profTemplate, 'ParameterArray')
    profTemplate = RESTHELPER.checkIfDefined(offerStatusValue, None, 'OFFERSTATUSVALUE', profTemplate, 'OfferStatusValue')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    if cycleType or cycleResourceId or cycleOffset or cycleAlignmentDisabled or cycleStartTime or cycleEndTime or immediateChange or isRecurringFailureAllowed:
        cycleTemplate = open(templates + 'xoffer_cycle_data.json').read()
        cycleTemplate = RESTHELPER.checkIfDefined(cycleType, None, 'CYCLETYPE', cycleTemplate, 'CycleType')
        cycleTemplate = RESTHELPER.checkIfDefined(cycleResourceId, None, 'CYCLERESOURCEID', cycleTemplate, 'CycleResourceId')
        cycleTemplate = RESTHELPER.checkIfDefined(cycleOffset, None, 'CYCLEOFFSET', cycleTemplate, 'CycleOffset')
        cycleTemplate = RESTHELPER.checkIfDefined(cycleAlignmentDisabled, None, 'CYCLEALIGNMENTDISABLED', cycleTemplate, 'CycleAlignmentDisabled')
        cycleTemplate = RESTHELPER.checkIfDefined(cycleStartTime, None, 'CYCLEsTARTTIME', cycleTemplate, 'CycleStartTime')
        cycleTemplate = RESTHELPER.checkIfDefined(cycleEndTime, None, 'CYCLEENDTIME', cycleTemplate, 'CycleEndTime')
        cycleTemplate = RESTHELPER.checkIfDefined(immediateChange, None, 'IMMEDIATECHANGE', cycleTemplate, 'ImmediateChange')
        cycleTemplate = RESTHELPER.checkIfDefined(isRecurringFailureAllowed, None, 'ISRECURRINGFAILUREALLOWED', cycleTemplate, 'IsRecurringFailureAllowed')
        cycleTemplate = RESTHELPER.removeLine(cycleTemplate, 'CycleOwnerType')
        cycleTemplate = cycleTemplate.rstrip('\n')
    else:
        cycleTemplate = None
    profTemplate = RESTHELPER.checkIfDefined(cycleTemplate, None, 'CYCLEDATA', profTemplate, 'CycleData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    # Allow for custom URLs (for BGAPI code)
    if CSV.overrideURL and 'modify' in CSV.overrideOperations: custom = '/' + CSV.overrideURL
    else: custom = ''
    url = '/json' + custom + '/subscriber/ObjectId+' + str(queryValue) + '/offers/' + str(resourceId)
#    url = '/json/'+RESTV3.subUrl+'/ObjectId+' + str(queryValue) + '/offers/' + str(resourceId)
           
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if modifyInfo:
         return (validateResponse(response=response, method=funcName, shouldPass=eventPass), response) 
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#========================================================
def subscriberActivateOffer(V3inst, queryValue, queryType, resourceId=None, now=None, executeMode=None,
                             routingType=None, routingValue=None, eventPass=True, apiEventData=None, multiRequestBuild=None):

    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/json/subscription/' + str(queryType) + '+' + str(queryValue) + '/offers/' + str(resourceId) + '/activate'

    delim = '?'
    amp = False

    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType+str(routingValue)
        delim = '&'
        amp = True

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += delim +'ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.put(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#========================================================
def groupModifyOffer(V3inst, queryType, queryValue, resourceId, now=None, startTime=None, endTime=None, attr=None,
    cycleType=None, cycleResourceId=None, cycleOffset=None, cycleAlignmentDisabled=None, cycleStartTime=None, cycleEndTime=None, immediateChange=None, isRecurringFailureAllowed=None, status=None,
    offerStatusValue=None, apiEventData=None, eventPass=True, executeMode=None, parameterList=None, modifyInfo=False,
    multiRequestBuild=None, endTimeExtensionOffset=None, endTimeExtensionOffsetUnit=None):

    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Get group OID if queryType is not ObjectId
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    attrStr = None
    if attr is not None:
        #print 'Create subscriber:  attr = ' + str(attr)
        attrStr = parseAttrMdc(attr)

    # Need to force binary items to None if false as Engine interprets a value of "False" as set.
    if cycleAlignmentDisabled and str(cycleAlignmentDisabled).lower() in ['1', 'true']:
          cycleAlignmentDisabled = '1'
    else: cycleAlignmentDisabled = None
    if immediateChange and str(immediateChange).lower() in ['1', 'true']:
          immediateChange = '1'
    else: immediateChange = None
    
    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    parameterArray = None
    if parameterList:
        parameterArray = parseParameterList(parameterList)

    profTemplate = open(templates + 'group_modify_offer.json').read()
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(startTime, None, 'STARTTIME', profTemplate, 'StartTime')
    profTemplate = RESTHELPER.checkIfDefined(endTime, None, 'ENDTIME', profTemplate, 'EndTime')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(parameterArray, None, 'PARAMETERARRAY', profTemplate, 'ParameterArray')
    profTemplate = RESTHELPER.checkIfDefined(offerStatusValue, None, 'OFFERSTATUSVALUE', profTemplate, 'OfferStatusValue')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    if cycleType or cycleResourceId or cycleOffset or cycleAlignmentDisabled or cycleStartTime or cycleEndTime or immediateChange or isRecurringFailureAllowed:
        cycleTemplate = open(templates + 'xoffer_cycle_data.json').read()
        cycleTemplate = RESTHELPER.checkIfDefined(cycleType, None, 'CYCLETYPE', cycleTemplate, 'CycleType')
        cycleTemplate = RESTHELPER.checkIfDefined(cycleResourceId, None, 'CYCLERESOURCEID', cycleTemplate, 'CycleResourceId')
        cycleTemplate = RESTHELPER.checkIfDefined(cycleOffset, None, 'CYCLEOFFSET', cycleTemplate, 'CycleOffset')
        cycleTemplate = RESTHELPER.checkIfDefined(cycleAlignmentDisabled, None, 'CYCLEALIGNMENTDISABLED', cycleTemplate, 'CycleAlignmentDisabled')
        cycleTemplate = RESTHELPER.checkIfDefined(cycleStartTime, None, 'CYCLEsTARTTIME', cycleTemplate, 'CycleStartTime')
        cycleTemplate = RESTHELPER.checkIfDefined(cycleEndTime, None, 'CYCLEENDTIME', cycleTemplate, 'CycleEndTime')
        cycleTemplate = RESTHELPER.checkIfDefined(immediateChange, None, 'IMMEDIATECHANGE', cycleTemplate, 'ImmediateChange')
        cycleTemplate = RESTHELPER.checkIfDefined(isRecurringFailureAllowed, None, 'ISRECURRINGFAILUREALLOWED', cycleTemplate, 'IsRecurringFailureAllowed')
        cycleTemplate = RESTHELPER.removeLine(cycleTemplate, 'CycleOwnerType')
        cycleTemplate = cycleTemplate.rstrip('\n')
    else:
        cycleTemplate = None
    profTemplate = RESTHELPER.checkIfDefined(cycleTemplate, None, 'CYCLEDATA', profTemplate, 'CycleData')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    # Allow for custom URLs (for BGAPI code)
    if CSV.overrideURL and 'modify' in CSV.overrideOperations: custom = '/' + CSV.overrideURL
    else: custom = ''
    url = '/json' + custom + '/group/ObjectId+' + str(queryValue) + '/offers/' + str(resourceId)
#    url = '/json/group/ObjectId+' + str(queryValue) + '/offers/' + str(resourceId)
           
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if modifyInfo:
         return (validateResponse(response=response, method=funcName, shouldPass=eventPass), response) 
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#========================================================
def groupActivateOffer(V3inst, queryValue, queryType, resourceId=None, now=None, executeMode=None,
                      apiEventData=None, routingType=None, routingValue=None, eventPass=True, multiRequestBuild=None):

    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/json/group/' + str(queryType) + '+' + str(queryValue) + '/offers/' + str(resourceId) + '/activate'

    delim = '?'
    amp = False

    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType+str(routingValue)
        delim = '&'
        amp = True

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += delim +'ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.put(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)
#=============================================================
def deviceModifyOffer(V3inst, queryType, queryValue, resourceId, now=None, startTime=None, endTime=None, attr=None,
    cycleType=None, cycleResourceId=None, cycleOffset=None, cycleAlignmentDisabled=None, cycleStartTime=None, cycleEndTime=None, immediateChange=None, isRecurringFailureAllowed=None, status=None,
    offerStatusValue=None, apiEventData=None, eventPass=True, executeMode=None, modifyInfo=False, parameterList=None, multiRequestBuild=None, endTimeExtensionOffset=None, endTimeExtensionOffsetUnit=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    attrStr = None
    if attr is not None:
        #print 'Create subscriber:  attr = ' + str(attr)
        attrStr = parseAttrMdc(attr)
    
    # Need to force binary items to None if false as Engine interprets a value of "False" as set.
    if cycleAlignmentDisabled and str(cycleAlignmentDisabled).lower() in ['1', 'true']:
          cycleAlignmentDisabled = '1'
    else: cycleAlignmentDisabled = None
    if immediateChange and str(immediateChange).lower() in ['1', 'true']:
          immediateChange = '1'
    else: immediateChange = None
    
    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    parameterArray = None
    if parameterList:
        parameterArray = parseParameterList(parameterList)

    profTemplate = open(templates + 'subscriber_modify_offer.json').read()
    profTemplate = open(templates + 'device_modify_offer.json').read()
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(startTime, None, 'STARTTIME', profTemplate, 'StartTime')
    profTemplate = RESTHELPER.checkIfDefined(parameterArray, None, 'PARAMETERARRAY', profTemplate, 'ParameterArray')
    profTemplate = RESTHELPER.checkIfDefined(endTime, None, 'ENDTIME', profTemplate, 'EndTime')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(offerStatusValue, None, 'OFFERSTATUSVALUE', profTemplate, 'OfferStatusValue')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    if cycleType or cycleResourceId or cycleOffset or cycleAlignmentDisabled or cycleStartTime or cycleEndTime or immediateChange or isRecurringFailureAllowed:
        cycleTemplate = open(templates + 'xoffer_cycle_data.json').read()
        cycleTemplate = RESTHELPER.checkIfDefined(cycleType, None, 'CYCLETYPE', cycleTemplate, 'CycleType')
        cycleTemplate = RESTHELPER.checkIfDefined(cycleResourceId, None, 'CYCLERESOURCEID', cycleTemplate, 'CycleResourceId')
        cycleTemplate = RESTHELPER.checkIfDefined(cycleOffset, None, 'CYCLEOFFSET', cycleTemplate, 'CycleOffset')
        cycleTemplate = RESTHELPER.checkIfDefined(cycleAlignmentDisabled, None, 'CYCLEALIGNMENTDISABLED', cycleTemplate, 'CycleAlignmentDisabled')
        cycleTemplate = RESTHELPER.checkIfDefined(cycleStartTime, None, 'CYCLEsTARTTIME', cycleTemplate, 'CycleStartTime')
        cycleTemplate = RESTHELPER.checkIfDefined(cycleEndTime, None, 'CYCLEENDTIME', cycleTemplate, 'CycleEndTime')
        cycleTemplate = RESTHELPER.removeLine(cycleTemplate, 'CycleOwnerType')
        cycleTemplate = RESTHELPER.checkIfDefined(immediateChange, None, 'IMMEDIATECHANGE', cycleTemplate, 'ImmediateChange')
        cycleTemplate = RESTHELPER.checkIfDefined(isRecurringFailureAllowed, None, 'ISRECURRINGFAILUREALLOWED', cycleTemplate, 'IsRecurringFailureAllowed')
        cycleTemplate = cycleTemplate.rstrip('\n')
    else:
        cycleTemplate = None
    profTemplate = RESTHELPER.checkIfDefined(cycleTemplate, None, 'CYCLEDATA', profTemplate, 'CycleData')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    # Allow for custom URLs (for BGAPI code)
    if CSV.overrideURL and 'modify' in CSV.overrideOperations: custom = '/' + CSV.overrideURL
    else: custom = ''
    url = '/json' + custom + '/device/ObjectId+' + str(queryValue) + '/offers/' + str(resourceId)
#    url = '/json/device/ObjectId+' + str(queryValue) + '/offers/' + str(resourceId)
           
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if modifyInfo:
         return (validateResponse(response=response, method=funcName, shouldPass=eventPass), response) 
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#========================================================
def deviceActivateOffer(V3inst, queryValue, queryType, resourceId=None, now=None, executeMode=None,
                        apiEventData=None, routingType=None, routingValue=None, eventPass=True, multiRequestBuild=None):

    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/json/device/' + str(queryType) + '+' + str(queryValue) + '/offers/' + str(resourceId) + '/activate'

    delim = '?'
    amp = False

    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType+str(routingValue)
        delim = '&'
        amp = True

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += delim +'ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.put(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def queryMembership(V3inst,queryValue, membershipType, queryCursor=None, querySize=None, object='subscriber', now=None,
        returnExternalId=False, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Map membershipType to URL string
    if object == 'subscriber':
        if membershipType == '1':
                membershipTypeStr = 'groups'
        elif membershipType == '2':
                membershipTypeStr = 'administers'
        else:
                return COMMON.debugFailure(method='querySubscriberMembership', status=10, msg=str(membershipType) + ' is not a valid subscriber membership type value')  
    else:
        if membershipType == '1':
                membershipTypeStr = 'subscribers'
        elif membershipType == '2':
                membershipTypeStr = 'subgroups'
        elif membershipType == '3': 
                membershipTypeStr = 'administrators'
        else:
                return COMMON.debugFailure(method='queryGroupMembership', status=10, msg=str(membershipType) + ' is not a valid group membership type value')   

    # Build URL string
    amp = False
    url = '/json/' + object + '/ObjectId+' + str(queryValue) + '/' + membershipTypeStr
    if returnExternalId: url += '?returnExternalId='+ str(returnExternalId)

    # If either query parameter is specified
    if querySize or queryCursor:
        # Add question mark
        url += '?'
        amp = True
        
        # Add querySize
        if querySize:
                url += 'querySize=' + str(querySize)
                # Add ampersand if also have other parameter
                if queryCursor: url += '&'
        
        # Add queryCursor
        if queryCursor: url += 'queryCursor=' + str(queryCursor)
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        
    # Get the data
    response = V3inst.get(url,  time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    
    # Debug output
    #print 'Object ' + object + '  response: ' + response     
    
    # Want to extract any QueryCursor value.  
    # There has to be a better way then this...
    # Assume nothing found
    queryCursor = '0'
    
    # Split response into dictionary per line
    respDict = response.split('\n')
    
    return (response, queryCursor)
    
#=============================================================
def querySubscriberMembership(V3inst,queryValue, membershipType=None, queryType='ExternalId', queryCursor=None, querySize=None, now=None, eventPass=True,
        returnExternalId=False, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # get object OID if not passed in   
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, querySize=querySize, eventPass=eventPass, now=now)
        queryValue = getOID(queryResponse)

    # Complete membership event
    (response, queryCursor) = queryMembership(V3inst,queryValue, membershipType, queryCursor=queryCursor, querySize=querySize, object='subscriber',
                                  now=now, returnExternalId=returnExternalId)
    
    # Validate
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return (response, queryCursor)

#=============================================================
def queryGroupMembership(V3inst,queryValue, membershipType=None, queryType='ExternalId', queryCursor=None,
        querySize=None, now=None, eventPass=True, returnExternalId=False, multiRequestBuild=None):
  
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Map membershipType to URL string
    # get object OID if not passed in
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, querySize=querySize, eventPass=eventPass, now=now)
        queryValue = getOID(queryResponse)

    # Complete membership event
    (response, queryCursor) = queryMembership(V3inst,queryValue, membershipType, queryCursor=queryCursor, querySize=querySize, object='group', now=now, returnExternalId=returnExternalId)

    # Validate
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return (response, queryCursor)

#=============================================================
def querySubscriberWallet(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass, now=now)
        queryValue = getOID(queryResponse)
    
    url = '/json/'+RESTV3.subUrl+'/ObjectId+' + str(queryValue) + '/wallet'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        
    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberCheckPurchasedItemCycleAlignment(V3inst, queryValue, queryType='ExternalId', offerExternalId=None, catalogId=None,
    offerId=None, offerResourceId=None, now=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if offerResourceId:
        profTemplate = open(templates + 'subscriber_check_alignment_resource.json').read()
        profTemplate = RESTHELPER.checkIfDefined(offerResourceId, None, 'OFFERRESOURCEID', profTemplate, 'OfferResourceId')

    else:
        profTemplate = open(templates + 'subscriber_check_alignment.json').read()
        profTemplate = RESTHELPER.checkIfDefined(offerExternalId, None, 'OFFEREXTID', profTemplate, 'ExternalId')
        profTemplate = RESTHELPER.checkIfDefined(offerId, None, 'OFFERID', profTemplate, 'ProductOfferId')
        profTemplate = RESTHELPER.checkIfDefined(catalogId, None, 'CATALOGITEMID', profTemplate, 'CatalogItemId')

    url = '/json/'+RESTV3.subUrl+'/' + str(queryType) + '+' + str(queryValue) + '/cycle_alignment'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    print(profTemplate)
    response = V3inst.put(url, time=now, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def deviceCheckPurchasedItemCycleAlignment(V3inst, queryValue, queryType='ExternalId', offerExternalId=None, catalogId=None,
    offerId=None, offerResourceId=None, now=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if offerResourceId:
        profTemplate = open(templates + 'device_check_alignment_resource.json').read()
        profTemplate = RESTHELPER.checkIfDefined(offerResourceId, None, 'OFFERRESOURCEID', profTemplate, 'OfferResourceId')

    else:
        profTemplate = open(templates + 'device_check_alignment.json').read()
        profTemplate = RESTHELPER.checkIfDefined(offerExternalId, None, 'OFFEREXTID', profTemplate, 'ExternalId')
        profTemplate = RESTHELPER.checkIfDefined(offerId, None, 'OFFERID', profTemplate, 'ProductOfferId')
        profTemplate = RESTHELPER.checkIfDefined(catalogId, None, 'CATALOGITEMID', profTemplate, 'CatalogItemId')

    url = '/json/device/' + str(queryType) + '+' + str(queryValue) + '/cycle_alignment'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    print(profTemplate)
    response = V3inst.put(url, time=now, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def groupCheckPurchasedItemCycleAlignment(V3inst, queryValue, queryType='ExternalId', offerExternalId=None, catalogId=None,
    offerId=None, offerResourceId=None, now=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()


    if offerResourceId:
        profTemplate = open(templates + 'group_check_alignment_resource.json').read()
        profTemplate = RESTHELPER.checkIfDefined(offerResourceId, None, 'OFFERRESOURCEID', profTemplate, 'OfferResourceId')

    else:
        profTemplate = open(templates + 'group_check_alignment.json').read()
        profTemplate = RESTHELPER.checkIfDefined(offerExternalId, None, 'OFFEREXTID', profTemplate, 'ExternalId')
        profTemplate = RESTHELPER.checkIfDefined(offerId, None, 'OFFERID', profTemplate, 'ProductOfferId')
        profTemplate = RESTHELPER.checkIfDefined(catalogId, None, 'CATALOGITEMID', profTemplate, 'CatalogItemId')

    url = '/json/group/' + str(queryType) + '+' + str(queryValue) + '/cycle_alignment'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    print(profTemplate)
    response = V3inst.put(url, time=now, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def createDevice(V3inst, imsi, externalId=None, deviceType=None, attr=None, now=None, accessNumbers=None,
        eventPass=True, status=None, mobile=None, routingType=None, routingValue=None, executeMode=None,
        tenantId=None, apiEventData=None, returnTemplate=False, multiRequestBuild=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if accessNumbers is not None and type(accessNumbers) is not list:
        accessNumbers = [accessNumbers]

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    attrStr = None
    if attr is None:
        try:
            attr = MDCDEFS.kMtxMobileDeviceExtensionMdcDesc.create()
        except:
            return COMMON.debugFailure(method='createDevice', status=9, msg='Error creating attr',
                shouldPass=eventPass)

    if imsi is not None:
        try:
            attr.setUsingKey(MDCDEFS.kMtxMobileDeviceExtensionImsiFldKey, imsi)
        except:
            return COMMON.debugFailure(method='createDevice', status=10, msg='Error setting imsi in attr',
                shouldPass=eventPass)

    if accessNumbers is not None:
        try:
            attr.setUsingKey(MDCDEFS.kMtxMobileDeviceExtensionAccessNumberArrayFldKey, accessNumbers)
        except:
            return COMMON.debugFailure(method='createDevice', status=11, msg='Error setting access numbers in attr',
                shouldPass=eventPass)

    attrStr = parseAttrMdc(attr)
    profTemplate = open(templates + 'device_create.json').read()
    profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'EXTERNALID', profTemplate, 'ExternalId')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    profTemplate = RESTHELPER.checkIfDefined(deviceType, None, 'DEVICETYPE', profTemplate, 'DeviceType')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(tenantId, None, 'TENANTID', profTemplate, 'TenantId')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    #print 'Create device:  payload = ' + str(profTemplate)
    if returnTemplate:
        return profTemplate

    if routingType and routingValue:
                url = '/json/device?TrafficRouteData='+routingType+str(routingValue)
    else:       url = '/json/device'
           
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method='createDevice', shouldPass=eventPass, returnParam='ObjectId')

#=============================================================
def subscriberCreateDevice(V3inst, queryValue=None, queryType='ObjectId', deviceId=None, externalId=None, deviceType=None, attr=None,
        now=None, accessNumbers=None,eventPass=True, status=None, mobile=None, routingType=None, routingValue=None, executeMode=None,
        tenantId=None, apiEventData=None, returnTemplate=False, multiRequestBuild=None):

    funcName = QAUTILS.getFunctionName()

    profTemplate = createDevice(V3inst, deviceId, externalId=None, deviceType=deviceType, attr=attr, apiEventData=apiEventData,
            now=now, accessNumbers=accessNumbers, status=status, mobile=None, executeMode=executeMode, returnTemplate=True)
    profTemplate = re.sub('.*xml version.*\n?','',profTemplate)

    url = '/json/service/'+RESTV3.subUrl+'/' + str(queryType) + '+' + str(queryValue) + '/device'
    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType+str(routingValue)

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def createDeviceLogin(V3inst, loginId, externalId=None, deviceType=None, attr=None, now=None, apiEventData=None,
        tenantId=None, accessIds=None, eventPass=True, status=None, routingType=None, routingValue=None, executeMode=None, multiRequestBuild=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if accessIds is not None and type(accessIds) is not list:
        accessIds = [accessIds]

    attrStr = None
    if attr is None:
        try:
            attr = MDCDEFS.kMtxLoginDeviceExtensionMdcDesc.create()
        except:
            return COMMON.debugFailure(method='createDeviceLogin', status=9, msg='Error creating attr',
                shouldPass=eventPass)

    if loginId is not None:
        try:
            attr.setUsingKey(MDCDEFS.kMtxLoginDeviceExtensionLoginIdFldKey, loginId)
        except:
            return COMMON.debugFailure(method='createDeviceLogin', status=10, msg='Error setting login in attr',
                shouldPass=eventPass)

    if accessIds is not None:
        try:
            attr.setUsingKey(MDCDEFS.kMtxLoginDeviceExtensionAccessIdArrayFldKey, accessIds)
        except:
            return COMMON.debugFailure(method='createDeviceLogin', status=11, msg='Error setting access ids in attr',
                shouldPass=eventPass)

    attrStr = None
    if attr is not None:
        #print 'Create subscriber:  attr = ' + str(attr)
        attrStr = parseAttrMdc(attr)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'device_create.json').read()
    profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'EXTERNALID', profTemplate, 'ExternalId')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    profTemplate = RESTHELPER.checkIfDefined(deviceType, None, 'DEVICETYPE', profTemplate, 'DeviceType')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    
    if routingType and routingValue:
                url = '/json/device?TrafficRouteData='+routingType+str(routingValue)
    else:       url = '/json/device'
           
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method='createDeviceLogin', shouldPass=eventPass, returnParam='ObjectId')
                                                                                                    
#=============================================================
def subscriberDeleteDevice(V3inst, queryValue=None, queryType='ObjectId', devQueryValue=None, devQueryType='ObjectId', now=None, eventPass=True,
        apiEventData=None, multiRequestBuild=None):


    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/json/service/subscriber/' + str(queryType) + '+' + str(queryValue) + '/device/' + str(devQueryType) + '+' + str(devQueryValue)
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += '?ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True
    
    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def deleteDevice(V3inst, queryValue, queryType='Imsi', deleteSession=False, now=None, eventPass=True,
        apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/json/device/ObjectId+' + str(queryValue)

    delim = '?'
    amp = False

    if deleteSession:
        url += '?deleteSession=True'
        delim = '&'
        amp = True
       
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += delim +'ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.delete(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def addDeviceToSubscriber(V3inst, externalId, deviceId=None, deviceType=1, subQueryType='ExternalId',
        devQueryType='PhoneNumber', eventPass=True, accessNumbers=None, attr=None, status=None, now=None, apiEventData=None, 
        tenantId=None, isCreateDevice=True, noTouch=False, devOid=None, routingType=None, routingValue=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # for negative tests that do not want to create device
    if deviceId and not isCreateDevice :
        queryValue = None
        # Need to get object OID values
        if subQueryType != 'ObjectId':
                queryResponse = querySubscriber(V3inst=V3inst, queryValue=externalId, queryType=subQueryType, now=now)
                externalId = getOID(queryResponse)
        if devQueryType != 'ObjectId':
             queryResponse = queryDevice(V3inst=V3inst, queryValue=deviceId, queryType=devQueryType, eventPass=eventPass,now=now)
             queryValue = getOID(queryResponse)

        if not eventPass and queryValue is None:
            pass
        else:
             deviceId = queryValue

        url = '/json/'+RESTV3.subUrl+'/ObjectId+' + str(externalId) + '/device/' + str(deviceId)
    
        amp = False

        if apiEventData is not None:
            apiEventDataStr = parseAttrMdc(apiEventData)
            if apiEventDataStr:
                    url += '?ApiEventData=' +URL.quote_plus(apiEventDataStr)
                    amp = True
    
        # If Debug if globally set
        if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
    
        # Send in the command
        response = V3inst.put(url, time=now, amp=amp)
        if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
        success = validateResponse(response=response, method=funcName, shouldPass=eventPass)
        return (success, deviceId)

    # Check if the device already exists
    existed = True
    if deviceId:
        if (devQueryType == 'PhoneNumber' or devQueryType == 'LoginId')  and eventPass:
            if noTouch:
                #if using the noTouch option, device must not exist OR device oid must be passed in
                if devOid:
                    oid = devOid
                else:
                    existed = False
            elif not queryDevice(V3inst=V3inst, queryType=devQueryType, queryValue=deviceId, eventPass=None, now=now):
                # Device does not exist.
                existed = False
            if not existed:
                # If device ID passed in, then go ahead and create device.
                if deviceId is not None and devQueryType == 'PhoneNumber':
                    (retCode, deviceId) = createDevice(V3inst, imsi=deviceId, deviceType=deviceType,
                        accessNumbers=accessNumbers, eventPass=eventPass, attr=attr, status=status, now=now, routingType=routingType, routingValue=routingValue)
                    if not retCode:
                        return (COMMON.debugFailure(method=funcName, status=21,
                            msg='could not create device with id ' + str(deviceId), shouldPass=eventPass), None)
                elif deviceId is not None and devQueryType == 'LoginId' : #and eventPass:
                     (retCode, deviceId) = createDeviceLogin(V3inst, loginId=deviceId, deviceType=deviceType,
                           attr=attr, accessIds=accessNumbers, status=status, now=now, routingType=routingType, routingValue=routingValue)
                     if not retCode:
                         return (COMMON.debugFailure(method=funcName, status=21,
                           msg='could not create device with login id ' + str(deviceId), shouldPass=eventPass), None)
                # If call is expected to pass, device does not exist, and no ID is passed in, should fail!
                elif eventPass:
                    return (COMMON.debugFailure(method=funcName, status=20,
                        msg='no device id passed in', shouldPass=True), None)

                # Continue on for negative testing
                elif not eventPass:
                    oid = None

    else:
        return (COMMON.debugFailure(method=funcName, status=20, msg='no device id passed in',
            shouldPass=True), None)

    # Get device OID if queryType is not ObjectId
    if existed and devQueryType != 'ObjectId' and not noTouch:
        queryResponse = queryDevice(V3inst=V3inst, queryValue=deviceId, queryType=devQueryType, now=now)
        deviceId = getOID(queryResponse)
    
    if noTouch:
        pass
    # Check if device already has an owner (devices can only belong to one subscriber)
    elif existed or eventPass:
        queryResponse = queryDevice(V3inst=V3inst, queryValue=deviceId, queryType='ObjectId', now=now)
        if getSubscriberId(queryResponse):
            if not existed:
                return (COMMON.debugFailure(method=funcName, status=19,
                    msg='Device is already associated with a subscriber', shouldPass=eventPass), deviceId)
            else:
                return (COMMON.debugFailure(method=funcName, status=19,
                    msg='Device is already associated with a subscriber', shouldPass=eventPass), None)

    # Get subscriber OID if queryType is not ObjectId
    if subQueryType != 'ObjectId' and not noTouch:
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=externalId, queryType=subQueryType, now=now)
        externalId = getOID(queryResponse)

    url = '/json/'+RESTV3.subUrl+'/ObjectId+' + str(externalId) + '/device/' + str(deviceId)
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += '?ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True
    
    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    # Now add the device to the subscriber
    response = V3inst.put(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    success = validateResponse(response=response, method=funcName, shouldPass=eventPass)
    if not existed:
        return (success, deviceId)
    else:
        return (success, None)

#=============================================================
def removeDeviceFromSubscriber(V3inst, subscriberId, deviceId, subQueryType, devQueryType, deleteSession, eventPass, now,
        apiEventData=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if subQueryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=subscriberId, queryType=subQueryType, now=now,eventPass=eventPass)
        subscriberId = getOID(queryResponse)
    if devQueryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=deviceId, queryType=devQueryType, eventPass=None,now=now)
        deviceId = getOID(queryResponse)
    
    url = '/json/'+RESTV3.subUrl+'/ObjectId+' + str(subscriberId) + '/device/' + str(deviceId)
    amp = False
    delim = '?'

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += delim + 'ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True
                delim = '&'
        
    # Delete session can be boolean, string, or int
    if deleteSession == True or deleteSession == '1' or deleteSession == 1:
        url += delim + 'deleteSession=true'
        amp = True

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def modifyDevice(V3inst, queryValue, queryType='PhoneNumber', deviceType=None, attr=None, now=None, eventPass=True,
                  status=None, accessNumbers=None, externalId=None, lastActivityUpdateTime=None, imsi=None,
                  tenantId=None, apiEventData=None, loginId=None, executeMode=None, multiRequestBuild=None):

    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if accessNumbers is not None and type(accessNumbers) is not list:
       accessNumbers = [accessNumbers]

    attrStr = None
    if attr is None and accessNumbers is not None:
        try:
            if queryType=='LoginId' or queryType=='AccessId':
               attr = MDCDEFS.kMtxLoginDeviceExtensionMdcDesc.create()

            else:
               attr = MDCDEFS.kMtxMobileDeviceExtensionMdcDesc.create()

        except:
            return COMMON.debugFailure(method='modifyDevice', status=9, msg='Error setting access numbers in attr',
                shouldPass=eventPass)
            
    if accessNumbers is not None:
        try:
            if queryType=='LoginId' or  queryType=='AccessId':
               attr.setUsingKey(MDCDEFS.kMtxLoginDeviceExtensionAccessIdArrayFldKey, accessNumbers)

            else:
                attr.setUsingKey(MDCDEFS.kMtxMobileDeviceExtensionAccessNumberArrayFldKey, accessNumbers)
        except:
            return COMMON.debugFailure(method='modifyDevice', status=9, msg='Error setting access numbers in attr',
                shouldPass=eventPass)

    attrStr = None
    if attr is not None:
        #print 'Create subscriber:  attr = ' + str(attr)
        attrStr = parseAttrMdc(attr)
    # Get subscriber OID if queryType is not ObjectId
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)
    
    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'device_modify.json').read()
    profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'EXTERNALID', profTemplate, 'ExternalId')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    profTemplate = RESTHELPER.checkIfDefined(deviceType, None, 'DEVICETYPE', profTemplate, 'DeviceType')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(lastActivityUpdateTime, None, 'LASTACTIVITYUPDATETIME',
        profTemplate, 'LastActivityUpdateTime')
    profTemplate = RESTHELPER.checkIfDefined(tenantId, None, 'TENANTID', profTemplate, 'TenantId')
    profTemplate = RESTHELPER.checkIfDefined(imsi, None, 'IMSI', profTemplate, 'Imsi')
    profTemplate = RESTHELPER.checkIfDefined(loginId, None, 'LOGINID', profTemplate, 'LoginId')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    
    url = '/json/device/ObjectId+' + str(queryValue)
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

# Rehome a Device (Requires a multi sub-domain engine configuration)
#=============================================================
def deviceRehome(V3inst, queryValue, queryType='ObjectId', routingType='RouteId', routingValue=2, eventPass=True,
        apiEventData=None, multiRequestBuild=None):
    global restVersion

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass)
        queryValue = getOID(queryResponse)

    url = '/json/device/ObjectId+' + str(queryValue) + '/rehome/' + str(routingType) + '+' + str(routingValue)
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += '?ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        
    response = V3inst.put(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if validateResponse(response=response, method='deviceRehome', shouldPass=eventPass):
        return response

#====================================================
def devicePurchaseOffer(V3inst, queryValue, offerId=None, catalogItemId=None, offerStartTime=None,
        offerEndTime=None, queryType='PhoneNumber', eventPass=True, now=None, offerIsExternal=False,
        attr=None, chargeMethod=None, paymentMethodResourceId=None, paymentGatewayId=None, paymentGatewayOneTimeToken=None,
        purchaseInfo=False, executeMode=None, offerCycleType=None, offerCycleResourceId=None, offerCycleOffset=None, cycleOwnerType=None,
        offerCycleStartTime=None, etcScheduleRangeArray=None, etcScheduleRangeUnit=None, paymentScheduleRangeArray=None, paymentScheduleAmountArray=None, paymentScheduleLastAmount=None, delayCharge=None, deferredSettlement=None, deferredSettlementTimeout=None, deferredSettlementTimeoutAction=None,
        contractPeriod=None, contractInterval=None, commitmentPeriod=None, commitmentPeriodInterval=None, isOpenContract=None,
        preActiveState=None, autoActivationTime=None, autoActivationRelativeOffsetUnit=None, autoActivationRelativeOffset=None,
        autoActivationCycleResourceId=None, activationExpirationTime=None, activationExpirationRelativeOffsetUnit=None, 
        activationExpirationRelativeOffset=None, chargeMethodAttr=None, endTimeRelativeOffsetUnit=None, endTimeRelativeOffset=None,
        downPayment=None, paymentGatewayUserId=None, isRecurringFailureAllowed=None, multiRequestBuild=None, isTargetResource=None,
        useTargetResource=None, chargePurchaseProrationType=None, grantPurchaseProrationType=None, reason=None, info=None,
        apiEventData=None, parameterList=None, offerStatusValue=None, eligibilityCheck=True, geoData=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if now is None:
        now = offerStartTime
    
    # Need to force preactive as logic below doesn't work if set to False
    if preActiveState and str(preActiveState).lower() in ['1', 'true']:
          preActiveState = '1'
    else: preActiveState = None
    if isRecurringFailureAllowed:
        isRecurringFailureAllowed='true'
    elif isRecurringFailureAllowed == False:
        isRecurringFailureAllowed='false'
    if deferredSettlement:
        deferredSettlement='true'

    # Get device OID if queryType is not ObjectId
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    # Process any input attributes
    attrStr = None
    if attr is not None:
        #print 'Create subscriber:  attr = ' + str(attr)
        attrStr = parseAttrMdc(attr)
    chargeMethodAttrStr = None
    if chargeMethodAttr is not None:
        chargeMethodAttrStr = parseAttrMdc(chargeMethodAttr)
    offerArray = ''
    
    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    parameterArray = None
    if parameterList:
        parameterArray = parseParameterList(parameterList)

    # Allow for custom URLs (for BGAPI code)
    if CSV.overrideURL and 'purchase' in CSV.overrideOperations: custom = '/' + CSV.overrideURL
    else: custom = ''
    url = '/json' + custom + '/device/ObjectId+' + str(queryValue) + '/offers'
    
    # Input may be a list or may be a single item
    if type(catalogItemId) is list:
        offerId = catalogItemId

    # populate contractParameterOverrideDataTemplate, which only support single one at moment
    contractParameterOverrideDataTemplate = createContractParameterOverrideData(etcScheduleRangeArray=etcScheduleRangeArray, etcScheduleRangeUnit=etcScheduleRangeUnit, paymentScheduleRangeArray=paymentScheduleRangeArray, paymentScheduleAmountArray=paymentScheduleAmountArray, paymentScheduleLastAmount=paymentScheduleLastAmount, delayCharge=delayCharge, contractPeriod=contractPeriod, contractInterval=contractInterval, commitmentPeriod=commitmentPeriod, commitmentPeriodInterval=commitmentPeriodInterval, isOpenContract=isOpenContract)

    if type(offerId) is list:
        createResourceIds = []
        for offer in offerId:
            # Purchase offer and validate for each, append created resource id to list
            profTemplate = open(templates + 'OfferRequestArray.json').read()
            profTemplate = RESTHELPER.removeLine(profTemplate, 'PaymentDueDate')
            if offerIsExternal:
                profTemplate = RESTHELPER.removeLine(profTemplate, 'ProductOfferId')
                profTemplate = RESTHELPER.removeLine(profTemplate, 'CatalogItemId')
                profTemplate = RESTHELPER.checkIfDefined(offer, None, 'OFFEREXTID', profTemplate, 'ExternalId')
            else:
                profTemplate = RESTHELPER.removeLine(profTemplate, 'ExternalId')
                if catalogItemId:
                    profTemplate = RESTHELPER.checkIfDefined(offer, None, 'CATALOGITEMID', profTemplate, 'CatalogItemId')
                    profTemplate = RESTHELPER.removeLine(profTemplate, 'ProductOfferId')
                else:
                    profTemplate = RESTHELPER.checkIfDefined(offer, None, 'OFFERID', profTemplate, 'ProductOfferId')
                    profTemplate = RESTHELPER.removeLine(profTemplate, 'CatalogItemId')

            profTemplate = RESTHELPER.checkIfDefined(offerStartTime, None, 'STARTTIME', profTemplate, 'StartTime')
            profTemplate = RESTHELPER.checkIfDefined(offerStatusValue, None, 'OFFERSTATUSVALUE', profTemplate, 'OfferStatusValue')
            profTemplate = RESTHELPER.checkIfDefined(endTimeRelativeOffsetUnit, None, 'ENDTIMERELATIVEOFFSETUNIT', profTemplate, 'EndTimeRelativeOffsetUnit')
            profTemplate = RESTHELPER.checkIfDefined(endTimeRelativeOffset, None, 'ENDTIMERELATIVEOFFSET', profTemplate, 'EndTimeRelativeOffset')
            profTemplate = RESTHELPER.checkIfDefined(offerEndTime, None, 'ENDTIME', profTemplate, 'EndTime')
            if offerCycleType or offerCycleResourceId or offerCycleOffset or cycleOwnerType or offerCycleStartTime:
                cycleTemplate = open(templates + 'xoffer_cycle_data.json').read()
                cycleTemplate = RESTHELPER.checkIfDefined(offerCycleType, None, 'CYCLETYPE', cycleTemplate, 'CycleType')
                cycleTemplate = RESTHELPER.checkIfDefined(offerCycleResourceId, None, 'CYCLERESOURCEID', cycleTemplate, 'CycleResourceId')
                cycleTemplate = RESTHELPER.checkIfDefined(offerCycleOffset, None, 'CYCLEOFFSET', cycleTemplate, 'CycleOffset')
                cycleTemplate = RESTHELPER.checkIfDefined(offerCycleStartTime, None, 'CYCLEsTARTTIME', cycleTemplate, 'CycleStartTime')
                cycleTemplate = RESTHELPER.checkIfDefined(cycleOwnerType, None, 'CYCLEOWNERTYPE', cycleTemplate, 'CycleOwnerType')
                cycleTemplate = RESTHELPER.removeLine(cycleTemplate, 'CycleAlignmentDisabled')
                cycleTemplate = RESTHELPER.removeLine(cycleTemplate, 'ImmediateChange')
                cycleTemplate = RESTHELPER.removeLine(cycleTemplate, 'CycleEndTime')
                cycleTemplate = cycleTemplate.replace("\n","")
            else:
                cycleTemplate = None
            profTemplate = RESTHELPER.checkIfDefined(cycleTemplate, None, 'CYCLEDATA', profTemplate, 'CycleData')
            profTemplate = RESTHELPER.checkIfDefined(parameterArray, None, 'PARAMETERARRAY', profTemplate, 'ParameterArray')
            profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
            profTemplate = RESTHELPER.checkIfDefined(preActiveState, None, 'PREACTIVESTATE', profTemplate, 'PreActiveState')
            profTemplate = RESTHELPER.checkIfDefined(autoActivationTime, None, 'AUTOACTIVATIONTIME', profTemplate, 'AutoActivationTime')
            profTemplate = RESTHELPER.checkIfDefined(autoActivationRelativeOffsetUnit, None, 'AUTOACTIVATIONRELATIVEOFFSETUNIT', profTemplate, 'AutoActivationRelativeOffsetUnit')
            profTemplate = RESTHELPER.checkIfDefined(autoActivationRelativeOffset, None, 'aUTOACTIVATIONRELATIVEOFFSET', profTemplate, 'AutoActivationRelativeOffset')
            profTemplate = RESTHELPER.checkIfDefined(autoActivationCycleResourceId, None, 'AUTOACTIVATIONCYCLERESOURCEID', profTemplate, 'AutoActivationCycleResourceId')
            profTemplate = RESTHELPER.checkIfDefined(activationExpirationTime, None, 'ACTIVATIONEXPIRATIONTIME', profTemplate, 
                'ActivationExpirationTime')
            profTemplate = RESTHELPER.checkIfDefined(activationExpirationRelativeOffsetUnit, None, 'ACTIVATIONEXPIRATIONRELATIVEOFFSETUNIT',
                profTemplate, 'ActivationExpirationRelativeOffsetUnit')
            profTemplate = RESTHELPER.checkIfDefined(activationExpirationRelativeOffset, None, 'aCTIVATIONEXPIRATIONRELATIVEOFFSET', profTemplate,
                'ActivationExpirationRelativeOffset')
            profTemplate = RESTHELPER.checkIfDefined(downPayment, None, 'DOWNPAYMENT', profTemplate, 'DownPayment')
            profTemplate = RESTHELPER.checkIfDefined(isRecurringFailureAllowed, None, 'ISRECURRINGFAILUREALLOWED', profTemplate, 'IsRecurringFailureAllowed')
            profTemplate = RESTHELPER.checkIfDefined(chargePurchaseProrationType, None, 'CHARGEPURCHASEPRORATIONTYPE', profTemplate, 'ChargePurchaseProrationType')     
            profTemplate = RESTHELPER.checkIfDefined(grantPurchaseProrationType, None, 'GRANTPURCHASEPRORATIONTYPE', profTemplate, 'GrantPurchaseProrationType')
            profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
            profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')

            # populate contractParameterOverride
            if contractParameterOverrideDataTemplate:
                profTemplate = RESTHELPER.checkIfDefined(contractParameterOverrideDataTemplate, None, 'CONTRACTPARAMETEROVERRIDEDATA', profTemplate, 'ONEWORDLINE')
            else:
                profTemplate = RESTHELPER.removeOneWordLine(profTemplate, 'CONTRACTPARAMETEROVERRIDEDATA')


            profTemplate = profTemplate.replace("\n","")
            if offerArray:
                offerArray += ', '
            offerArray += str(profTemplate)

        profTemplate = open(templates + 'xdevice_purchase_offer.json').read()
        if chargeMethod or paymentMethodResourceId or paymentGatewayId or paymentGatewayOneTimeToken or chargeMethodAttr:
            chargeMethodData = open(templates + 'charge_method_data.json').read()
            chargeMethodData = RESTHELPER.checkIfDefined(chargeMethod, None, 'CHARGEMETHOD', chargeMethodData, 'ChargeMethod')
            chargeMethodData = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', chargeMethodData, 'PaymentMethodResourceId')
            chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayId, None, 'PAYMENTGATEWAYID', chargeMethodData, 'PaymentGatewayId')
            chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayUserId, None, 'PAYMENTGATEWAYUSERID', chargeMethodData, 'PaymentGatewayUserId')
            chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayOneTimeToken, None, 'PAYMENTGATEWAYONETIMETOKEN', chargeMethodData, 'PaymentGatewayOneTimeToken')
            chargeMethodData = RESTHELPER.checkIfDefined(chargeMethodAttrStr, None, 'ATTR', chargeMethodData, 'ChargeMethodAttr')
            chargeMethodData = RESTHELPER.checkIfDefined(deferredSettlement, None, 'DEFERREDSETTLEMENT', chargeMethodData, 'DeferredSettlement')
            chargeMethodData = RESTHELPER.checkIfDefined(deferredSettlementTimeout, None, 'DEFERREDsETTLEMENTTIMEOUT', chargeMethodData, 'DeferredSettlementTimeout')
            chargeMethodData = RESTHELPER.checkIfDefined(deferredSettlementTimeoutAction, None, 'DEFERREDsETTLEMENTtIMEOUTACTION', chargeMethodData, 'DeferredSettlementTimeoutAction')
            chargeMethodData = chargeMethodData.replace("\n","")
        else:
            chargeMethodData = None
        profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')
        profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
        profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
        profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
        profTemplate = RESTHELPER.checkIfDefined(offerArray, None, 'OFFERREQUESTARRAY', profTemplate, None)
        profTemplate = RESTHELPER.checkIfDefined(eligibilityCheck, None, 'ELIGIBILITYCHECK', profTemplate, 'EligibilityCheck')
            
        # Debug output if globally set
        if QAUTILS.DebugLevel > 0:
            print(funcName + ' url: ' + url)
            print(funcName + ' payload:\n' + profTemplate)
        
        response = V3inst.put(url, payload=profTemplate)
        if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
        (success, resourceId) = validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='ResourceIdArray')
        createResourceIds.append(resourceId)

        if purchaseInfo:
           return (passed(eventPass), response)
        else:
           return (passed(eventPass), createResourceIds)
    else:
        # Purchase offer and validate, return created resourceId
        profTemplate = open(templates + 'OfferRequestArray.json').read()

        profTemplate = RESTHELPER.removeLine(profTemplate, 'PaymentDueDate')

        # populate contractParameterOverride
        if contractParameterOverrideDataTemplate:
            profTemplate = RESTHELPER.checkIfDefined(contractParameterOverrideDataTemplate, None, 'CONTRACTPARAMETEROVERRIDEDATA', profTemplate, 'ONEWORDLINE')
        else:
            profTemplate = RESTHELPER.removeOneWordLine(profTemplate, 'CONTRACTPARAMETEROVERRIDEDATA')

        if offerIsExternal:
            profTemplate = RESTHELPER.removeLine(profTemplate, 'ProductOfferId')
            profTemplate = RESTHELPER.removeLine(profTemplate, 'CatalogItemId')
            if catalogItemId:
                profTemplate = RESTHELPER.checkIfDefined(catalogItemId, None, 'OFFEREXTID', profTemplate, 'ExternalId')
            else:
                profTemplate = RESTHELPER.checkIfDefined(offerId, None, 'OFFEREXTID', profTemplate, 'ExternalId')
        else:
            profTemplate = RESTHELPER.removeLine(profTemplate, 'ExternalId')
            profTemplate = RESTHELPER.checkIfDefined(offerId, None, 'OFFERID', profTemplate, 'ProductOfferId')
            profTemplate = RESTHELPER.checkIfDefined(catalogItemId, None, 'CATALOGITEMID', profTemplate, 'CatalogItemId')

        profTemplate = RESTHELPER.checkIfDefined(offerStartTime, None, 'STARTTIME', profTemplate, 'StartTime')
        profTemplate = RESTHELPER.checkIfDefined(offerStatusValue, None, 'OFFERSTATUSVALUE', profTemplate, 'OfferStatusValue')
        profTemplate = RESTHELPER.checkIfDefined(endTimeRelativeOffsetUnit, None, 'ENDTIMERELATIVEOFFSETUNIT', profTemplate, 'EndTimeRelativeOffsetUnit')
        profTemplate = RESTHELPER.checkIfDefined(endTimeRelativeOffset, None, 'ENDTIMERELATIVEOFFSET', profTemplate, 'EndTimeRelativeOffset')
        profTemplate = RESTHELPER.checkIfDefined(offerEndTime, None, 'ENDTIME', profTemplate, 'EndTime')
        if offerCycleType or offerCycleResourceId or offerCycleOffset or cycleOwnerType or offerCycleStartTime:
            cycleTemplate = open(templates + 'xoffer_cycle_data.json').read()
            cycleTemplate = RESTHELPER.checkIfDefined(offerCycleType, None, 'CYCLETYPE', cycleTemplate, 'CycleType')
            cycleTemplate = RESTHELPER.checkIfDefined(offerCycleResourceId, None, 'CYCLERESOURCEID', cycleTemplate, 'CycleResourceId')
            cycleTemplate = RESTHELPER.checkIfDefined(offerCycleOffset, None, 'CYCLEOFFSET', cycleTemplate, 'CycleOffset')
            cycleTemplate = RESTHELPER.checkIfDefined(offerCycleStartTime, None, 'CYCLEsTARTTIME', cycleTemplate, 'CycleStartTime')
            cycleTemplate = RESTHELPER.checkIfDefined(cycleOwnerType, None, 'CYCLEOWNERTYPE', cycleTemplate, 'CycleOwnerType')
            cycleTemplate = RESTHELPER.removeLine(cycleTemplate, 'CycleAlignmentDisabled')
            cycleTemplate = RESTHELPER.removeLine(cycleTemplate, 'ImmediateChange')
            cycleTemplate = RESTHELPER.removeLine(cycleTemplate, 'CycleEndTime')
            cycleTemplate = cycleTemplate.replace("\n","")
        else:
            cycleTemplate = None
        profTemplate = RESTHELPER.checkIfDefined(cycleTemplate, None, 'CYCLEDATA', profTemplate, 'CycleData')
        profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
        profTemplate = RESTHELPER.checkIfDefined(parameterArray, None, 'PARAMETERARRAY', profTemplate, 'ParameterArray')
        profTemplate = RESTHELPER.checkIfDefined(preActiveState, None, 'PREACTIVESTATE', profTemplate, 'PreActiveState')
        profTemplate = RESTHELPER.checkIfDefined(autoActivationTime, None, 'AUTOACTIVATIONTIME', profTemplate, 'AutoActivationTime')
        profTemplate = RESTHELPER.checkIfDefined(autoActivationRelativeOffsetUnit, None, 'AUTOACTIVATIONRELATIVEOFFSETUNIT', profTemplate, 'AutoActivationRelativeOffsetUnit')
        profTemplate = RESTHELPER.checkIfDefined(autoActivationRelativeOffset, None, 'aUTOACTIVATIONRELATIVEOFFSET', profTemplate, 'AutoActivationRelativeOffset')
        profTemplate = RESTHELPER.checkIfDefined(autoActivationCycleResourceId, None, 'AUTOACTIVATIONCYCLERESOURCEID', profTemplate, 'AutoActivationCycleResourceId')
        profTemplate = RESTHELPER.checkIfDefined(activationExpirationTime, None, 'ACTIVATIONEXPIRATIONTIME', profTemplate, 
            'ActivationExpirationTime')
        profTemplate = RESTHELPER.checkIfDefined(activationExpirationRelativeOffsetUnit, None, 'ACTIVATIONEXPIRATIONRELATIVEOFFSETUNIT',
            profTemplate, 'ActivationExpirationRelativeOffsetUnit')
        profTemplate = RESTHELPER.checkIfDefined(activationExpirationRelativeOffset, None, 'aCTIVATIONEXPIRATIONRELATIVEOFFSET', profTemplate,
            'ActivationExpirationRelativeOffset')
        profTemplate = RESTHELPER.checkIfDefined(downPayment, None, 'DOWNPAYMENT', profTemplate, 'DownPayment')
        profTemplate = RESTHELPER.checkIfDefined(isRecurringFailureAllowed, None, 'ISRECURRINGFAILUREALLOWED', profTemplate, 'IsRecurringFailureAllowed')
        profTemplate = RESTHELPER.checkIfDefined(chargePurchaseProrationType, None, 'CHARGEPURCHASEPRORATIONTYPE', profTemplate, 'ChargePurchaseProrationType') 
        profTemplate = RESTHELPER.checkIfDefined(grantPurchaseProrationType, None, 'GRANTPURCHASEPRORATIONTYPE', profTemplate, 'GrantPurchaseProrationType')
        profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
        profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')

        offerArray = profTemplate.replace("\n","")

        profTemplate = open(templates + 'xdevice_purchase_offer.json').read()
        profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
        profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
        profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
        if chargeMethod or paymentMethodResourceId or paymentGatewayId or paymentGatewayOneTimeToken or chargeMethodAttr:
            chargeMethodData = open(templates + 'charge_method_data.json').read()
            chargeMethodData = RESTHELPER.checkIfDefined(chargeMethod, None, 'CHARGEMETHOD', chargeMethodData, 'ChargeMethod')
            chargeMethodData = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', chargeMethodData, 'PaymentMethodResourceId')
            chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayId, None, 'PAYMENTGATEWAYID', chargeMethodData, 'PaymentGatewayId')
            chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayUserId, None, 'PAYMENTGATEWAYUSERID', chargeMethodData, 'PaymentGatewayUserId')
            chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayOneTimeToken, None, 'PAYMENTGATEWAYONETIMETOKEN', chargeMethodData, 'PaymentGatewayOneTimeToken')
            chargeMethodData = RESTHELPER.checkIfDefined(chargeMethodAttrStr, None, 'ATTR', chargeMethodData, 'ChargeMethodAttr')
            chargeMethodData = RESTHELPER.checkIfDefined(deferredSettlement, None, 'DEFERREDSETTLEMENT', chargeMethodData, 'DeferredSettlement')
            chargeMethodData = RESTHELPER.checkIfDefined(deferredSettlementTimeout, None, 'DEFERREDsETTLEMENTTIMEOUT', chargeMethodData, 'DeferredSettlementTimeout')
            chargeMethodData = RESTHELPER.checkIfDefined(deferredSettlementTimeoutAction, None, 'DEFERREDsETTLEMENTtIMEOUTACTION', chargeMethodData, 'DeferredSettlementTimeoutAction')
            chargeMethodData = chargeMethodData.replace("\n","")
        else:
            chargeMethodData = None
        profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')
        profTemplate = RESTHELPER.checkIfDefined(offerArray, None, 'OFFERREQUESTARRAY', profTemplate, None)
        profTemplate = RESTHELPER.checkIfDefined(eligibilityCheck, None, 'ELIGIBILITYCHECK', profTemplate, 'EligibilityCheck')

        # If future, then more work to do
        #if future:
                # Return from here, as we're scheuling future purchases as a task
        #       return profTemplate

        # Debug output if globally set
        if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + profTemplate)
        
        response = V3inst.put(url, payload=profTemplate)
        if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
        (success, resourceId) = validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='ResourceIdArray')

        if purchaseInfo:
           return (passed(eventPass), response)
        else:
           return (passed(eventPass), resourceId)

#=============================================================
def deviceCancelOffer(V3inst, queryValue, resourceId=0, endTime=None, eventPass=True, queryType='PhoneNumber', attr=None, now=None,  
        cancelInfo=False, apiEventData=None, executeMode=None, multiRequestBuild=None, eligibilityCheck=True):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Build resource id list if resourceId is list
    if type(resourceId) is list:
        numEntries = len(resourceId)
        entryCounter = 1
        resourceIdList = resourceId
        resourceId = ''
        for resource in resourceIdList:
            resourceId += str(resource)
            if entryCounter != numEntries:
                entryCounter += 1
                resourceId += ','
    else:
        resourceId = str(resourceId) + ','

    url = '/json/device/' + str(queryType) + '+' + str(queryValue) + '/offers/' + str(resourceId)
    delim = '?'
    amp = False

    if executeMode is not None:
        url+= '?executeMode=' + str(executeMode)
        delim = '&'
        amp = True

    if endTime is not None:
        url+= delim + 'timestamp=' + endTime
        delim = '&'
        amp = True
        endTime=None
    
    if eligibilityCheck is not None:
        url+= delim + 'eligibilityCheck=' + str(eligibilityCheck).lower()
        amp = True
        endTime=None

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += '?ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        
    response = V3inst.delete(url, time=endTime, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if cancelInfo:
        return (validateResponse(response=response, method=funcName, shouldPass=eventPass), response)
    else:
        return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def deviceCancelOfferExt(V3inst, queryValue, resourceId=0, cancelType=None, grantCancelProrationType=None, chargeCancelProrationType=None,
        reason=None, info=None, now=None, queryType='PhoneNumber', cancelInfo=False, cancelOfferDataList='',
        apiEventData=None, contractCancelMode=None, debtCancellationMode=None, isWaiveEarlyTerminationCharge=None, eventPass=True, executeMode=None, multiRequestBuild=None, eligibilityCheck=True):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    profTemplate = open(templates + 'device_cancel_offer.json').read()

    if type(resourceId) is not list:
        resourceId = [resourceId]
    cancelTemplate=''
    idArray = None

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    if cancelOfferDataList:
        for cancelOfferData in cancelOfferDataList:
            template = open(templates + 'cancel_offer_data.json').read()
            template = RESTHELPER.checkIfDefined(cancelOfferData["ResourceId"], None, 'RESOURCEID', template, 'ResourceId')
            template = RESTHELPER.checkIfDefined(cancelOfferData["CancelType"], None, 'CANCELTYPE', template, 'CancelType')
            template = RESTHELPER.checkIfDefined(cancelOfferData["GrantCancelProrationType"], None, 'GRANTCANCELPRORATIONTYPE', template, 'GrantCancelProrationType')
            template = RESTHELPER.checkIfDefined(cancelOfferData["ChargeCancelProrationType"], None, 'CHARGECANCELPRORATIONTYPE', template, 'ChargeCancelProrationType')
            template = RESTHELPER.checkIfDefined(cancelOfferData["ContractCancelMode"], None, 'CONTRACTCANCELMODE', template, 'ContractCancelMode')
            template = RESTHELPER.checkIfDefined(cancelOfferData["DebtCancellationMode"], None, 'DEBTCANCELLATIONMODE', template, 'DebtCancellationMode')
            template = RESTHELPER.checkIfDefined(cancelOfferData["IsWaiveEarlyTerminationCharge"], None, 'ISWAIVEEARLYTERMINATIONCHARGE', template, 'IsWaiveEarlyTerminationCharge')

            template = RESTHELPER.checkIfDefined(cancelOfferData["Reason"], None, 'REASON', template, 'Reason')
            template = RESTHELPER.checkIfDefined(cancelOfferData["Info"], None, 'INFO', template, 'Info')
            cancelTemplate += template
    elif cancelType or grantCancelProrationType or chargeCancelProrationType or reason or info or  contractCancelMode or debtCancellationMode:
        for id in resourceId:
            template = open(templates + 'cancel_offer_data.json').read()
            template = RESTHELPER.checkIfDefined(id, None, 'RESOURCEID', template, 'ResourceId')
            template = RESTHELPER.checkIfDefined(cancelType, None, 'CANCELTYPE', template, 'CancelType')
            template = RESTHELPER.checkIfDefined(grantCancelProrationType, None, 'GRANTCANCELPRORATIONTYPE', template, 'GrantCancelProrationType')
            template = RESTHELPER.checkIfDefined(chargeCancelProrationType, None, 'CHARGECANCELPRORATIONTYPE', template, 'ChargeCancelProrationType')
            template = RESTHELPER.checkIfDefined(contractCancelMode, None, 'CONTRACTCANCELMODE', template, 'ContractCancelMode')
            template = RESTHELPER.checkIfDefined(debtCancellationMode, None, 'DEBTCANCELLATIONMODE', template, 'DebtCancellationMode')

            template = RESTHELPER.checkIfDefined(isWaiveEarlyTerminationCharge, None, 'ISWAIVEEARLYTERMINATIONCHARGE', template, 'IsWaiveEarlyTerminationCharge')
            template = RESTHELPER.checkIfDefined(reason, None, 'REASON', template, 'Reason')
            template = RESTHELPER.checkIfDefined(info, None, 'INFO', template, 'Info')
            cancelTemplate += template
    else:
        idArray = resourceId

    profTemplate = RESTHELPER.checkIfDefined(cancelTemplate, '', 'CANCELDATAARRAY', profTemplate, 'CancelDataArray')
    profTemplate = RESTHELPER.checkIfDefined(idArray, None, 'RESOURCEIDARRAY', profTemplate, 'ResourceIdArray')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(eligibilityCheck, None, 'ELIGIBILITYCHECK', profTemplate, 'EligibilityCheck')

    url = '/json/device/' + str(queryType) + '+' + str(queryValue) + '/offers'
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if cancelInfo :
        return (validateResponse(response=response, method=funcName, shouldPass=eventPass), response)
    else:
        return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def queryDevice(V3inst, queryValue, queryType='PhoneNumber', eventPass=True, now=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType == 'ObjectId':         url = '/json/device/'
    elif queryType == 'ExternalId':
        queryValue = URL.quote(queryValue,'')
        url = '/json/device/query/ExternalId/'
    elif queryType == 'PhoneNumber':    url = '/json/device/query/PhoneNumber/'
    elif queryType == 'Imsi':           url = '/json/device/query/PhoneNumber/'
    elif queryType == 'AccessNumber':   url = '/json/device/query/AccessNumber/'
    elif queryType == 'LoginId':        url = '/json/device/query/LoginId/'
    elif queryType == 'AccessId':       url = '/json/device/query/AccessId/'

    # Add ID
    url += str(queryValue)

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def deviceRating(V3inst, queryValue, queryType="Imsi", requestType='start', service=None, amount=None, sessionId=None,
    serviceContextId=None, calledStationId = None, QaUliMccMnc=None, eventPass=True, attr=None, eventTime=None, objectIdConversion=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # If attributes passed in, then extract those.
    if attr:
        # Set to local variables
        for parameter in attr:
                cmd = parameter + ' = attr["' + parameter + '"]'
                exec(cmd)

    # Make sure to get OID
    if objectIdConversion and queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType)
        queryValue = getOID(queryResponse)

        
    # Get template file.  template file may not have been passed in.  I suppose one
    # one could have checked if templateFile in attr versus try/except...
    try:
        # If template file variable starts with '/' or '.' then use as-is.  Else add as suffix.
        if templateFile[0] in ['.', '/']: fileToUse = templateFile
        else:                             fileToUse = templates + templateFile
        
    except:
        # Use default
        fileToUse = templates + 'usage_simple.json'

    # Open the file
    profTemplate = open(fileToUse).read()
    profTemplate = RESTHELPER.checkIfDefined(calledStationId, None, 'CALLEDSTATIONID', profTemplate, 'CalledStationId')
    profTemplate = RESTHELPER.checkIfDefined(QaUliMccMnc, None, 'QAULIMCCMNC', profTemplate, 'QaUliMccMnc')
    profTemplate = RESTHELPER.checkIfDefined(eventTime, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(service, None, 'SERVICE', profTemplate, 'Service')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(sessionId, None, 'SESSIONID', profTemplate, 'SessionId')
    profTemplate = RESTHELPER.checkIfDefined(serviceContextId, None, 'serviceCONTEXTID', profTemplate, 'ServiceContextId')
    
    # Check attributes
    if attr:
        # HACK alert: "OP" is a parameter but also conflicts with prefix names (e.g. OPL).
        # Need to do this first parameter first.
        parameter = 'op'
        if parameter in attr:
                # Assume template key to search for is the capitalized name of the parameter
                cmd = "profTemplate = RESTHELPER.checkIfDefined(" + parameter + ", None, '" + parameter.upper() + "', profTemplate, '" + parameter + "')"
                exec(cmd)
                
                # Remove this from the list
                del attr[parameter]
        
        # Process each one
        for parameter in attr:
                # Special code for adding custom parameters
                if parameter in ['DiamRoParams', 'MsccParams']:
                        # Define template insertion point string
                        if parameter == 'DiamRoParams': templateInsertionPoint = 'DIAMPARAMS'
                        else:                           templateInsertionPoint = 'CUSTMSCCPARAMS'
                        
                        # Proces each item in this array
                        for item in attr[parameter]:
                                # Store values (readability)
                                name = item
                                value = str(attr[parameter][item])

                                # Add to template
                                profTemplate = re.sub(templateInsertionPoint, templateInsertionPoint + '\n        "' + name + '": "' + value + '",', profTemplate)
                        
                        # Remove insertion line
                        profTemplate = RESTHELPER.checkIfDefined(None, None, templateInsertionPoint, profTemplate, None)
                else:
                        # Assume template key to search for is the capitalized name of the parameter
                        cmd = "profTemplate = RESTHELPER.checkIfDefined(" + parameter + ", None, '" + parameter.upper() + "', profTemplate, '" + parameter + "')"
                        exec(cmd)
        
    # URL may have been passed in in attr structure.  Not sure best way to check if local variable set, so use try/except.
    try:
        kef = url
    except:
        additionalUrl = ''
        if not objectIdConversion and queryType != 'ObjectId':
            additionalUrl += str(queryType) + '+'
        url = '/json/service/device/' + additionalUrl + str(queryValue) + '/rating/' + str(requestType)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=True):
        return response

#=============================================================
def deviceRatingCompleteFormat(V3inst, queryValue, queryType="Imsi", requestType='start', service=None, amount=None, sessionId=None, serviceContextId=None, QaUliMccMnc=None, eventPass=True, objectIdConversion = True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    # Make sure to get OID
    if objectIdConversion and queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType)
        queryValue = getOID(queryResponse)

    profTemplate = open(templates + 'usage.json').read()
    profTemplate = RESTHELPER.checkIfDefined(service, None, 'SERVICE', profTemplate, 'Service')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(sessionId, None, 'SESSIONID', profTemplate, 'SessionId')
    profTemplate = RESTHELPER.checkIfDefined(serviceContextId, None, 'serviceCONTEXTID', profTemplate, 'ServiceContextId')

    additionalUrl = ''
    if not objectIdConversion and queryType != 'ObjectId':
        additionalUrl += str(queryType) + '+'
    url = '/json/service/device/' + additionalUrl + str(queryValue) + '/rating/' + str(requestType)
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
    print(profTemplate)
    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def simulateUsage(V3inst, queryValue, queryType="Imsi", serviceType=None, quantity=None, timestamp=None, callee=None, networkId=None, sourceHost=None, sourceRealm=None, destHost=None, destRealm=None, objectIdConversion=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if objectIdConversion and queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType)
        queryValue = getOID(queryResponse)


    profTemplate = open(templates + 'simulate.json').read()
    profTemplate = RESTHELPER.checkIfDefined(timestamp, None, 'TIMESTAMP', profTemplate, 'Timestamp')
    profTemplate = RESTHELPER.checkIfDefined(quantity, None, 'QUANTITY', profTemplate, 'Quantity')
    profTemplate = RESTHELPER.checkIfDefined(serviceType, None, 'SERVICETYPE', profTemplate, 'ServiceType')
    profTemplate = RESTHELPER.checkIfDefined(callee, None, 'CALLEE', profTemplate, 'Callee')
    profTemplate = RESTHELPER.checkIfDefined(networkId, None, 'NETWORKID', profTemplate, 'NetworkId')
    profTemplate = RESTHELPER.checkIfDefined(sourceHost, None, 'SOURCEHOST', profTemplate, 'SourceHost')
    profTemplate = RESTHELPER.checkIfDefined(sourceRealm, None, 'SOURCEREALM', profTemplate, 'SourceRealm')
    profTemplate = RESTHELPER.checkIfDefined(destHost, None, 'DESTHOST', profTemplate, 'DestHost')
    profTemplate = RESTHELPER.checkIfDefined(destRealm, None, 'DESTREALM', profTemplate, 'DestRealm')

    additionalUrl = ''
    if not objectIdConversion and queryType != 'ObjectId':
        additionalUrl += str(queryType) + '+'
    url = '/json/service/device/' + additionalUrl + str(queryValue) + '/rating/simulate'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    print('------------------')
    print(url)
    print(profTemplate)
    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=True):
        return response

#=============================================================
def createGroup(V3inst, groupId=None, name=None, tier=None, administrator_id=0, eventPass=True, attr=None, now=None, status=None,
        billingCycle=None, queryType='ExternalId', taxStatus=None, taxCertificate=None, taxLocation=None, timeZone=None,
        notificationPreference=None, dateOffset=None, groupReAuthPreference=None, glCenter=None,
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        apiEventData=None, routingType=None, routingValue=None, executeMode=None, multiRequestBuild=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    adminStr = ''
    if type(administrator_id) is list:
        for admin in administrator_id:
            adminStr += '{"$": "MtxSubscriberSearchData", "' + str(queryType) + '": "' + str(admin) + '"}'
    elif administrator_id > 0:
        adminStr = '{"$": "MtxSubscriberSearchData", "' + str(queryType) + '": "' + str(administrator_id) + '"}'
    else:
        adminStr=None
        
    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    #check if we passed a string for billingCycle and convert it to a billing cycle template
    if billingCycle and type(billingCycle) is int:
        billingCycle = createBillingCycleData(int(billingCycle), startTime=now, dateOffset=dateOffset)
    
    url = '/json/group'
    
    attrStr = None
    if attr is not None:
        #print 'Create subscriber:  attr = ' + str(attr)
        attrStr = parseAttrMdc(attr)
    profTemplate = open(templates + 'group_create.json').read()
    profTemplate = RESTHELPER.checkIfDefined(groupId, None, 'EXTERNALID', profTemplate, 'ExternalId')
    profTemplate = RESTHELPER.checkIfDefined(name, None, 'NAME', profTemplate, 'Name')
    profTemplate = RESTHELPER.checkIfDefined(tier, None, 'TIER', profTemplate, 'Tier')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    profTemplate = RESTHELPER.checkIfDefined(billingCycle, None, 'BILLINGCYCLE', profTemplate, 'BillingCycle')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(adminStr, None, 'ADMINIDS', profTemplate, 'AdminArray')
    profTemplate = RESTHELPER.checkIfDefined(taxStatus, None, 'TAXsTATUS', profTemplate, 'TaxStatus')
    profTemplate = RESTHELPER.checkIfDefined(taxCertificate, None, 'TAXCERTIFICATE', profTemplate, 'TaxCertificate')
    profTemplate = RESTHELPER.checkIfDefined(taxLocation, None, 'TAXLOCATION', profTemplate, 'TaxLocation')
    profTemplate = RESTHELPER.checkIfDefined(glCenter, None, 'GLCENTER', profTemplate, 'GlCenter')
    profTemplate = RESTHELPER.checkIfDefined(timeZone, None, 'TIMEZONE', profTemplate, 'TimeZone')
    profTemplate = RESTHELPER.checkIfDefined(notificationPreference, None, 'NOTIFPREFERENCE', profTemplate, 'NotificationPreference')
    profTemplate = RESTHELPER.checkIfDefined(groupReAuthPreference, None, 'GROUPREAUTHPREFERENCE', profTemplate, 'GroupReAuthPreference')
    profTemplate = RESTHELPER.checkIfDefined(customerType, None, 'CUSTOMERTYPE', profTemplate, 'CustomerType')
    profTemplate = RESTHELPER.checkIfDefined(serviceAddress, None, 'SERVICEADDRESS', profTemplate, 'ServiceAddress')
    profTemplate = RESTHELPER.checkIfDefined(npa, None, 'NPA', profTemplate, 'Npa')
    profTemplate = RESTHELPER.checkIfDefined(nxx, None, 'NXX', profTemplate, 'Nxx')
    profTemplate = RESTHELPER.checkIfDefined(tenantId, None, 'TENANTID', profTemplate, 'TenantId')
    profTemplate = RESTHELPER.checkIfDefined(exemptionCodeList, None, 'EXEMPTIONCODELIST', profTemplate, 'ExemptionCodeList')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
#    print 'Create group:  payload = ' + str(profTemplate)
        
    # Add to URL if needed
    if routingType and routingValue: url += '?TrafficRouteData='+routingType+str(routingValue)
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='ObjectId')

#=============================================================
def modifyGroup(V3inst, groupId, name=None, tier=None, administrator_id=0, billingCycle=None, attr=None,
        subQueryType='ExternalId', groupQueryType='ExternalId', now=None, status=None, eventPass=True, notificationPreference = None,
        taxStatus=None, taxCertificate=None, taxLocation=None, externalId=None, timeZone=None, groupReAuthPreference=None,
        dateOffset = None, glCenter=None, paymentGatewayUserId=None, currentPaymentTokenResourceId=None,
        apiEventData=None, lastActivityUpdateTime=None, executeMode=None, billingCycleDisabled=None, multiRequestBuild=None,
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        maxUserCount=None, maxSubscriberCount=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    admin_groupId = groupId
    # Get group OID if queryType is not ObjectId
    if groupQueryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=groupId, queryType=groupQueryType, now=now)
        groupId = getOID(queryResponse)

    if administrator_id != 0:
        if not addAdminToGroup(V3inst, admin_groupId, administrator_id, subQueryType=subQueryType, groupQueryType=groupQueryType, now=now):
            return False

    if billingCycleDisabled:
        billingCycleDisabled='true'
    else:
        billingCycleDisabled='false'

    attrStr = None
    if attr is not None:
        #print 'Create subscriber:  attr = ' + str(attr)
        attrStr = parseAttrMdc(attr)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_modify.json').read()
    profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'EXTERNALID', profTemplate, 'ExternalId')
    profTemplate = RESTHELPER.checkIfDefined(name, None, 'NAME', profTemplate, 'Name')
    profTemplate = RESTHELPER.checkIfDefined(tier, None, 'TIER', profTemplate, 'Tier')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    profTemplate = RESTHELPER.checkIfDefined(billingCycle, None, 'BILLINGCYCLE', profTemplate, 'BillingCycle')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(taxStatus, None, 'TAXsTATUS', profTemplate, 'TaxStatus')
    profTemplate = RESTHELPER.checkIfDefined(taxCertificate, None, 'TAXCERTIFICATE', profTemplate, 'TaxCertificate')
    profTemplate = RESTHELPER.checkIfDefined(taxLocation, None, 'TAXLOCATION', profTemplate, 'TaxLocation')
    profTemplate = RESTHELPER.checkIfDefined(glCenter, None, 'GLCENTER', profTemplate, 'GlCenter')
    profTemplate = RESTHELPER.checkIfDefined(timeZone, None, 'TIMEZONE', profTemplate, 'TimeZone')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(notificationPreference, None, 'NOTIFPREFERENCE', profTemplate, 'NotificationPreference')
    profTemplate = RESTHELPER.checkIfDefined(groupReAuthPreference, None, 'GROUPREAUTHPREFERENCE', profTemplate, 'GroupReAuthPreference')
    profTemplate = RESTHELPER.checkIfDefined(paymentGatewayUserId, None, 'PAYMENTGATEWAYUSERID', profTemplate, 'PaymentGatewayUserId')
    profTemplate = RESTHELPER.checkIfDefined(currentPaymentTokenResourceId, None, 'CURRENTPAYMENTTOKENRECOURCEID',
        profTemplate, 'CurrentPaymentTokenResourceId')
    profTemplate = RESTHELPER.checkIfDefined(lastActivityUpdateTime, None, 'LASTACTIVITYUPDATETIME',
        profTemplate, 'LastActivityUpdateTime')
    profTemplate = RESTHELPER.checkIfDefined(maxUserCount, None, 'MAXUSERCOUNT', profTemplate, 'MaxUserCount')
    profTemplate = RESTHELPER.checkIfDefined(maxSubscriberCount, None, 'MAXSUBSCRIBERCOUNT', profTemplate, 'MaxSubscriberCount')
    profTemplate = RESTHELPER.checkIfDefined(customerType, None, 'CUSTOMERTYPE', profTemplate, 'CustomerType')
    profTemplate = RESTHELPER.checkIfDefined(serviceAddress, None, 'SERVICEADDRESS', profTemplate, 'ServiceAddress')
    profTemplate = RESTHELPER.checkIfDefined(npa, None, 'NPA', profTemplate, 'Npa')
    profTemplate = RESTHELPER.checkIfDefined(nxx, None, 'NXX', profTemplate, 'Nxx')
    profTemplate = RESTHELPER.checkIfDefined(tenantId, None, 'TENANTID', profTemplate, 'TenantId')
    profTemplate = RESTHELPER.checkIfDefined(exemptionCodeList, None, 'EXEMPTIONCODELIST', profTemplate, 'ExemptionCodeList')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(billingCycleDisabled, None, 'billingCYCLEDISABLED', profTemplate, 'BillingCycleDisabled')

    url = '/json/group/ObjectId+' + str(groupId)
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

# Rehome a group (Requires a multi sub-domain engine configuration)
#=============================================================
def groupRehome(V3inst, queryValue, queryType='ObjectId', routingType='RouteId', routingValue=2, eventPass=True,
        apiEventData=None, multiRequestBuild=None):
    global restVersion

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass)
        queryValue = getOID(queryResponse)

    url = '/json/group/ObjectId+' + str(queryValue) + '/rehome/' + str(routingType) + '+' + str(routingValue)

    amp = False
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += '?ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.put(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    #print response
    if validateResponse(response=response, method='groupRehome', shouldPass=eventPass):
        return response

#=============================================================
def groupSubscribeToOffer(V3inst, groupId, offerId=None, catalogItemId=None, offerStartTime=None,
        offerEndTime=None, eventPass=True, queryType='ExternalId', now=None, offerIsExternal=False,
        attr=None, dupAttr=True, chargeMethod=None, paymentMethodResourceId=None, paymentGatewayId=None,
        chargeMethodAttr=None, paymentGatewayOneTimeToken=None, paymentDueDate=None, future=False, purchaseInfo=False, executeMode=None, etcScheduleRangeArray=None, etcScheduleRangeUnit=None, paymentScheduleRangeArray=None, paymentScheduleAmountArray=None, paymentScheduleLastAmount=None, delayCharge=None, deferredSettlement=None, deferredSettlementTimeout=None, deferredSettlementTimeoutAction=None,
        contractPeriod=None, contractInterval=None, commitmentPeriod=None, commitmentPeriodInterval=None, isOpenContract=None,
        offerCycleType=None, offerCycleResourceId=None, offerCycleOffset=None, offerCycleStartTime=None, preActiveState=None,
        autoActivationTime=None, autoActivationRelativeOffsetUnit=None, autoActivationRelativeOffset=None, autoActivationCycleResourceId=None,
        activationExpirationTime=None, activationExpirationRelativeOffsetUnit=None, activationExpirationRelativeOffset=None,
        endTimeRelativeOffsetUnit=None, endTimeRelativeOffset=None, downPayment=None, paymentGatewayUserId=None, 
        isRecurringFailureAllowed=None, chargePurchaseProrationType=None, grantPurchaseProrationType=None, reason=None, info=None, 
        apiEventData=None, parameterList=None, offerStatusValue=None, multiRequestBuild=None, eligibilityCheck=True, geoData=None):

    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if now is None:
        now = offerStartTime
    
    # Need to force preactive as logic below doesn't work if set to False
    if preActiveState and str(preActiveState).lower() in ['1', 'true']:
          preActiveState = '1'
    else: preActiveState = None
    if deferredSettlement:
        deferredSettlement='true'
    if isRecurringFailureAllowed:
        isRecurringFailureAllowed='true'
    elif isRecurringFailureAllowed == False:
        isRecurringFailureAllowed='false'

    # Get group OID if queryType is not ObjectId
    if eventPass and queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=groupId, queryType=queryType, now=now)
        groupId = getOID(queryResponse)

    # Process any input attributes
    
    attrStr = None
    if attr is not None:
        #print 'Create subscriber:  attr = ' + str(attr)
        attrStr = parseAttrMdc(attr)
    chargeMethodAttrStr = None
    if chargeMethodAttr is not None:
        chargeMethodAttrStr = parseAttrMdc(chargeMethodAttr)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    parameterArray = None
    if parameterList:
        parameterArray = parseParameterList(parameterList)

    # Allow for custom URLs (for BGAPI code)
    if CSV.overrideURL and 'purchase' in CSV.overrideOperations: custom = '/' + CSV.overrideURL
    else: custom = ''
    url = '/json' + custom + '/group/ObjectId+' + str(groupId) + '/offers'
        
    offerArray = ''
    
    # Input may be a list or may be a single item
    if type(catalogItemId) is list:
        offerId = catalogItemId

    # populate contractParameterOverrideDataTemplate, which only support single one at moment
    contractParameterOverrideDataTemplate = createContractParameterOverrideData(etcScheduleRangeArray=etcScheduleRangeArray, etcScheduleRangeUnit=etcScheduleRangeUnit, paymentScheduleRangeArray=paymentScheduleRangeArray, paymentScheduleAmountArray=paymentScheduleAmountArray, paymentScheduleLastAmount=paymentScheduleLastAmount, delayCharge=delayCharge, contractPeriod=contractPeriod, contractInterval=contractInterval, commitmentPeriod=commitmentPeriod, commitmentPeriodInterval=commitmentPeriodInterval, isOpenContract=isOpenContract)

    if type(offerId) is list:
        createResourceIds = []
        for offer in offerId:
            # Purchase offer and validate for each, append created resource id to list
            profTemplate = open(templates + 'OfferRequestArray.json').read()

            # populate paymentDueDate
            if type(paymentDueDate) is list:
                i = offerId.index(offer)
                profTemplate = RESTHELPER.checkIfDefined(paymentDueDate[i], None, 'PAYMENTDUEDATE', profTemplate, 'PaymentDueDate')
            else:
                profTemplate = RESTHELPER.checkIfDefined(paymentDueDate, None, 'PAYMENTDUEDATE', profTemplate, 'PaymentDueDate')

            # populate contractParameterOverride
            if contractParameterOverrideDataTemplate:
                profTemplate = RESTHELPER.checkIfDefined(contractParameterOverrideDataTemplate, None, 'CONTRACTPARAMETEROVERRIDEDATA', profTemplate, 'ONEWORDLINE')
            else:
                profTemplate = RESTHELPER.removeOneWordLine(profTemplate, 'CONTRACTPARAMETEROVERRIDEDATA')

            # Conditionally select product offer by ExternalId or ProductOfferId
            if offerIsExternal:
                profTemplate = RESTHELPER.removeLine(profTemplate, 'ProductOfferId')
                profTemplate = RESTHELPER.removeLine(profTemplate, 'CatalogItemId')
                profTemplate = RESTHELPER.checkIfDefined(offer, None, 'OFFEREXTID', profTemplate, 'ExternalId')
            else:
                profTemplate = RESTHELPER.removeLine(profTemplate, 'ExternalId')
                if catalogItemId:
                    profTemplate = RESTHELPER.checkIfDefined(offer, None, 'CATALOGITEMID', profTemplate, 'CatalogItemId')
                    profTemplate = RESTHELPER.removeLine(profTemplate, 'ProductOfferId')
                else:
                    profTemplate = RESTHELPER.checkIfDefined(offer, None, 'OFFERID', profTemplate, 'ProductOfferId')
                    profTemplate = RESTHELPER.removeLine(profTemplate, 'CatalogItemId')

            profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
            profTemplate = RESTHELPER.checkIfDefined(parameterArray, None, 'PARAMETERARRAY', profTemplate, 'ParameterArray')
            profTemplate = RESTHELPER.checkIfDefined(preActiveState, None, 'PREACTIVESTATE', profTemplate, 'PreActiveState')
            profTemplate = RESTHELPER.checkIfDefined(autoActivationTime, None, 'AUTOACTIVATIONTIME', profTemplate, 'AutoActivationTime')
            profTemplate = RESTHELPER.checkIfDefined(autoActivationRelativeOffsetUnit, None, 'AUTOACTIVATIONRELATIVEOFFSETUNIT', profTemplate, 'AutoActivationRelativeOffsetUnit')
            profTemplate = RESTHELPER.checkIfDefined(autoActivationRelativeOffset, None, 'aUTOACTIVATIONRELATIVEOFFSET', profTemplate, 'AutoActivationRelativeOffset')
            profTemplate = RESTHELPER.checkIfDefined(autoActivationCycleResourceId, None, 'AUTOACTIVATIONCYCLERESOURCEID', profTemplate, 'AutoActivationCycleResourceId')
            profTemplate = RESTHELPER.checkIfDefined(activationExpirationTime, None, 'ACTIVATIONEXPIRATIONTIME', profTemplate,
                'ActivationExpirationTime')
            profTemplate = RESTHELPER.checkIfDefined(activationExpirationRelativeOffsetUnit, None, 'ACTIVATIONEXPIRATIONRELATIVEOFFSETUNIT',
                profTemplate, 'ActivationExpirationRelativeOffsetUnit')
            profTemplate = RESTHELPER.checkIfDefined(activationExpirationRelativeOffset, None, 'aCTIVATIONEXPIRATIONRELATIVEOFFSET', profTemplate,
                'ActivationExpirationRelativeOffset')
            profTemplate = RESTHELPER.checkIfDefined(downPayment, None, 'DOWNPAYMENT', profTemplate, 'DownPayment')
            profTemplate = RESTHELPER.checkIfDefined(isRecurringFailureAllowed, None, 'ISRECURRINGFAILUREALLOWED', profTemplate, 'IsRecurringFailureAllowed')
            profTemplate = RESTHELPER.checkIfDefined(endTimeRelativeOffsetUnit, None, 'ENDTIMERELATIVEOFFSETUNIT', profTemplate, 'EndTimeRelativeOffsetUnit')
            profTemplate = RESTHELPER.checkIfDefined(endTimeRelativeOffset, None, 'ENDTIMERELATIVEOFFSET', profTemplate, 'EndTimeRelativeOffset')
            profTemplate = RESTHELPER.checkIfDefined(chargePurchaseProrationType, None, 'CHARGEPURCHASEPRORATIONTYPE', profTemplate, 'ChargePurchaseProrationType')     
            profTemplate = RESTHELPER.checkIfDefined(grantPurchaseProrationType, None, 'GRANTPURCHASEPRORATIONTYPE', profTemplate, 'GrantPurchaseProrationType')
            profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
            profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
            if offerCycleType or offerCycleResourceId or offerCycleOffset or offerCycleStartTime:
                cycleTemplate = open(templates + 'xoffer_cycle_data.json').read()
                cycleTemplate = RESTHELPER.checkIfDefined(offerCycleType, None, 'CYCLETYPE', cycleTemplate, 'CycleType')
                cycleTemplate = RESTHELPER.checkIfDefined(offerCycleResourceId, None, 'CYCLERESOURCEID', cycleTemplate, 'CycleResourceId')
                cycleTemplate = RESTHELPER.checkIfDefined(offerCycleOffset, None, 'CYCLEOFFSET', cycleTemplate, 'CycleOffset')
                cycleTemplate = RESTHELPER.checkIfDefined(offerCycleStartTime, None, 'CYCLEsTARTTIME', cycleTemplate, 'CycleStartTime')
                cycleTemplate = RESTHELPER.removeLine(cycleTemplate, 'CycleAlignmentDisabled')
                cycleTemplate = RESTHELPER.removeLine(cycleTemplate, 'CycleOwnerType')
                cycleTemplate = RESTHELPER.removeLine(cycleTemplate, 'CycleEndTime')
                cycleTemplate = RESTHELPER.removeLine(cycleTemplate, 'ImmediateChange')
                cycleTemplate = cycleTemplate.replace("\n","")
            else:
                cycleTemplate = None
            profTemplate = RESTHELPER.checkIfDefined(cycleTemplate, None, 'CYCLEDATA', profTemplate, 'CycleData')
            profTemplate = RESTHELPER.checkIfDefined(offerStartTime, None, 'STARTTIME', profTemplate, 'StartTime')
            profTemplate = RESTHELPER.checkIfDefined(offerStatusValue, None, 'OFFERSTATUSVALUE', profTemplate, 'OfferStatusValue')
            profTemplate = RESTHELPER.checkIfDefined(offerEndTime, None, 'ENDTIME', profTemplate, 'EndTime')

            profTemplate = profTemplate.replace("\n","")
            if offerArray:
                offerArray += ', '
            offerArray += str(profTemplate)

        profTemplate = open(templates + 'xgroup_purchase_offer.json').read()
        if future: profTemplate = RESTHELPER.removeLine(profTemplate, 'EventTime')
        else:      profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
        if chargeMethod or paymentMethodResourceId or paymentGatewayId or paymentGatewayOneTimeToken or chargeMethodAttr:
            chargeMethodData = open(templates + 'charge_method_data.json').read()
            chargeMethodData = RESTHELPER.checkIfDefined(chargeMethod, None, 'CHARGEMETHOD', chargeMethodData, 'ChargeMethod')
            chargeMethodData = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', chargeMethodData, 'PaymentMethodResourceId')
            chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayId, None, 'PAYMENTGATEWAYID', chargeMethodData, 'PaymentGatewayId')
            chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayUserId, None, 'PAYMENTGATEWAYUSERID', chargeMethodData, 'PaymentGatewayUserId')
            chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayOneTimeToken, None, 'PAYMENTGATEWAYONETIMETOKEN', chargeMethodData, 'PaymentGatewayOneTimeToken')
            chargeMethodData = RESTHELPER.checkIfDefined(chargeMethodAttrStr, None, 'ATTR', chargeMethodData, 'ChargeMethodAttr')
            chargeMethodData = RESTHELPER.checkIfDefined(deferredSettlement, None, 'DEFERREDSETTLEMENT', chargeMethodData, 'DeferredSettlement')
            chargeMethodData = RESTHELPER.checkIfDefined(deferredSettlementTimeout, None, 'DEFERREDsETTLEMENTTIMEOUT', chargeMethodData, 'DeferredSettlementTimeout')
            chargeMethodData = RESTHELPER.checkIfDefined(deferredSettlementTimeoutAction, None, 'DEFERREDsETTLEMENTtIMEOUTACTION', chargeMethodData, 'DeferredSettlementTimeoutAction')
            chargeMethodData = chargeMethodData.replace("\n","")
        else:
            chargeMethodData = None
        profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')
        profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, None)
        profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
        profTemplate = RESTHELPER.checkIfDefined(offerArray, None, 'OFFERREQUESTARRAY', profTemplate, None)
        profTemplate = RESTHELPER.checkIfDefined(groupId, None, 'GROUPSEARCHDATA', profTemplate, 'ObjectId')
        profTemplate = RESTHELPER.checkIfDefined(eligibilityCheck, None, 'ELIGIBILITYCHECK', profTemplate, 'EligibilityCheck')

        # populate contractParameterOverride
        if contractParameterOverrideDataTemplate:
            profTemplate = RESTHELPER.checkIfDefined(contractParameterOverrideDataTemplate, None, 'CONTRACTPARAMETEROVERRIDEDATA', profTemplate, 'ONEWORDLINE')
        else:
            profTemplate = RESTHELPER.removeOneWordLine(profTemplate, 'CONTRACTPARAMETEROVERRIDEDATA')

            
            # If future, then don't send via this API
        if future:
            # Return from here, as we're scheuling future purchases as a task
            #print 'profTemplate from future: ' + profTemplate
            return profTemplate
            
            # Debug output if globally set
        if QAUTILS.DebugLevel > 0:
            print(funcName + ' url: ' + url)
            print(funcName + ' payload:\n' + profTemplate)
        
            # Send in the message
        response = V3inst.put(url, payload=profTemplate)
        if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
        (success, resourceId) = validateResponse(response=response, method='groupSubscribeToOffer',
            shouldPass=eventPass, returnParam='ResourceIdArray')
        createResourceIds = resourceId
     
        if purchaseInfo:
           return (passed(eventPass), response)
        else: 
           return (passed(eventPass), createResourceIds)
    else:
        # Purchase offer and validate, return created resourceId
        profTemplate = open(templates + 'OfferRequestArray.json').read()

        # populate contractParameterOverride
        if contractParameterOverrideDataTemplate:
            profTemplate = RESTHELPER.checkIfDefined(contractParameterOverrideDataTemplate, None, 'CONTRACTPARAMETEROVERRIDEDATA', profTemplate, 'ONEWORDLINE')
        else:
            profTemplate = RESTHELPER.removeOneWordLine(profTemplate, 'CONTRACTPARAMETEROVERRIDEDATA')

        # Conditionally select product offer by ExternalId or ProductOfferId
        if offerIsExternal:
            profTemplate = RESTHELPER.removeLine(profTemplate, 'ProductOfferId')
            profTemplate = RESTHELPER.removeLine(profTemplate, 'CatalogItemId')
            if catalogItemId:
                profTemplate = RESTHELPER.checkIfDefined(catalogItemId, None, 'OFFEREXTID', profTemplate, 'ExternalId')
            else:
                profTemplate = RESTHELPER.checkIfDefined(offerId, None, 'OFFEREXTID', profTemplate, 'ExternalId')
        else:
            profTemplate = RESTHELPER.removeLine(profTemplate, 'ExternalId')
            profTemplate = RESTHELPER.checkIfDefined(offerId, None, 'OFFERID', profTemplate, 'ProductOfferId')
            profTemplate = RESTHELPER.checkIfDefined(catalogItemId, None, 'CATALOGITEMID', profTemplate, 'CatalogItemId')

        profTemplate = RESTHELPER.checkIfDefined(paymentDueDate, None, 'PAYMENTDUEDATE', profTemplate, 'PaymentDueDate')

        profTemplate = RESTHELPER.checkIfDefined(offerStartTime, None, 'STARTTIME', profTemplate, 'StartTime')
        profTemplate = RESTHELPER.checkIfDefined(offerStatusValue, None, 'OFFERSTATUSVALUE', profTemplate, 'OfferStatusValue')
        profTemplate = RESTHELPER.checkIfDefined(offerEndTime, None, 'ENDTIME', profTemplate, 'EndTime')
        profTemplate = RESTHELPER.checkIfDefined(parameterArray, None, 'PARAMETERARRAY', profTemplate, 'ParameterArray')
        profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
        profTemplate = RESTHELPER.checkIfDefined(preActiveState, None, 'PREACTIVESTATE', profTemplate, 'PreActiveState')
        profTemplate = RESTHELPER.checkIfDefined(autoActivationTime, None, 'AUTOACTIVATIONTIME', profTemplate, 'AutoActivationTime')
        profTemplate = RESTHELPER.checkIfDefined(autoActivationRelativeOffsetUnit, None, 'AUTOACTIVATIONRELATIVEOFFSETUNIT', profTemplate, 'AutoActivationRelativeOffsetUnit')
        profTemplate = RESTHELPER.checkIfDefined(autoActivationRelativeOffset, None, 'aUTOACTIVATIONRELATIVEOFFSET', profTemplate, 'AutoActivationRelativeOffset')
        profTemplate = RESTHELPER.checkIfDefined(autoActivationCycleResourceId, None, 'AUTOACTIVATIONCYCLERESOURCEID', profTemplate, 'AutoActivationCycleResourceId')
        profTemplate = RESTHELPER.checkIfDefined(activationExpirationTime, None, 'ACTIVATIONEXPIRATIONTIME', profTemplate,
            'ActivationExpirationTime')
        profTemplate = RESTHELPER.checkIfDefined(activationExpirationRelativeOffsetUnit, None, 'ACTIVATIONEXPIRATIONRELATIVEOFFSETUNIT',
             profTemplate, 'ActivationExpirationRelativeOffsetUnit')
        profTemplate = RESTHELPER.checkIfDefined(activationExpirationRelativeOffset, None, 'aCTIVATIONEXPIRATIONRELATIVEOFFSET', profTemplate,
            'ActivationExpirationRelativeOffset')
        profTemplate = RESTHELPER.checkIfDefined(downPayment, None, 'DOWNPAYMENT', profTemplate, 'DownPayment')
        profTemplate = RESTHELPER.checkIfDefined(isRecurringFailureAllowed, None, 'ISRECURRINGFAILUREALLOWED', profTemplate, 'IsRecurringFailureAllowed')
        profTemplate = RESTHELPER.checkIfDefined(endTimeRelativeOffsetUnit, None, 'ENDTIMERELATIVEOFFSETUNIT', profTemplate, 'EndTimeRelativeOffsetUnit')
        profTemplate = RESTHELPER.checkIfDefined(endTimeRelativeOffset, None, 'ENDTIMERELATIVEOFFSET', profTemplate, 'EndTimeRelativeOffset')
        profTemplate = RESTHELPER.checkIfDefined(chargePurchaseProrationType, None, 'CHARGEPURCHASEPRORATIONTYPE', profTemplate, 'ChargePurchaseProrationType') 
        profTemplate = RESTHELPER.checkIfDefined(grantPurchaseProrationType, None, 'GRANTPURCHASEPRORATIONTYPE', profTemplate, 'GrantPurchaseProrationType')
        profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
        profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
        if offerCycleType or offerCycleResourceId or offerCycleOffset or offerCycleStartTime:
            cycleTemplate = open(templates + 'xoffer_cycle_data.json').read()
            cycleTemplate = RESTHELPER.checkIfDefined(offerCycleType, None, 'CYCLETYPE', cycleTemplate, 'CycleType')
            cycleTemplate = RESTHELPER.checkIfDefined(offerCycleResourceId, None, 'CYCLERESOURCEID', cycleTemplate, 'CycleResourceId')
            cycleTemplate = RESTHELPER.checkIfDefined(offerCycleOffset, None, 'CYCLEOFFSET', cycleTemplate, 'CycleOffset')
            cycleTemplate = RESTHELPER.checkIfDefined(offerCycleStartTime, None, 'CYCLEsTARTTIME', cycleTemplate, 'CycleStartTime')
            cycleTemplate = RESTHELPER.removeLine(cycleTemplate, 'CycleAlignmentDisabled')
            cycleTemplate = RESTHELPER.removeLine(cycleTemplate, 'CycleEndTime')
            cycleTemplate = RESTHELPER.removeLine(cycleTemplate, 'CycleOwnerType')
            cycleTemplate = RESTHELPER.removeLine(cycleTemplate, 'ImmediateChange')
            cycleTemplate = cycleTemplate.replace("\n","")
        else:
            cycleTemplate = None
        profTemplate = RESTHELPER.checkIfDefined(cycleTemplate, None, 'CYCLEDATA', profTemplate, 'CycleData')
        offerArray = profTemplate.replace("\n","")

        profTemplate = open(templates + 'xgroup_purchase_offer.json').read()
        if future: profTemplate = RESTHELPER.removeLine(profTemplate, 'EventTime')
        else:      profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
        if chargeMethod or paymentMethodResourceId or paymentGatewayId or paymentGatewayOneTimeToken or chargeMethodAttr:
            chargeMethodData = open(templates + 'charge_method_data.json').read()
            chargeMethodData = RESTHELPER.checkIfDefined(chargeMethod, None, 'CHARGEMETHOD', chargeMethodData, 'ChargeMethod')
            chargeMethodData = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', chargeMethodData, 'PaymentMethodResourceId')
            chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayId, None, 'PAYMENTGATEWAYID', chargeMethodData, 'PaymentGatewayId')
            chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayUserId, None, 'PAYMENTGATEWAYUSERID', chargeMethodData, 'PaymentGatewayUserId')
            chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayOneTimeToken, None, 'PAYMENTGATEWAYONETIMETOKEN', chargeMethodData, 'PaymentGatewayOneTimeToken')
            chargeMethodData = RESTHELPER.checkIfDefined(chargeMethodAttrStr, None, 'ATTR', chargeMethodData, 'ChargeMethodAttr')
            chargeMethodData = RESTHELPER.checkIfDefined(deferredSettlement, None, 'DEFERREDSETTLEMENT', chargeMethodData, 'DeferredSettlement')
            chargeMethodData = RESTHELPER.checkIfDefined(deferredSettlementTimeout, None, 'DEFERREDsETTLEMENTTIMEOUT', chargeMethodData, 'DeferredSettlementTimeout')
            chargeMethodData = RESTHELPER.checkIfDefined(deferredSettlementTimeoutAction, None, 'DEFERREDsETTLEMENTtIMEOUTACTION', chargeMethodData, 'DeferredSettlementTimeoutAction')
            chargeMethodData = chargeMethodData.replace("\n","")
        else:
            chargeMethodData = None
        profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')
        profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
        profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
        profTemplate = RESTHELPER.checkIfDefined(offerArray, None, 'OFFERREQUESTARRAY', profTemplate, None)
        profTemplate = RESTHELPER.checkIfDefined(groupId, None, 'GROUPSEARCHDATA', profTemplate, 'ObjectId')
        profTemplate = RESTHELPER.checkIfDefined(eligibilityCheck, None, 'ELIGIBILITYCHECK', profTemplate, 'EligibilityCheck')
        
        # If future, then don't send via this API
        if future:
            # Return from here, as we're scheuling future purchases as a task
            # print 'profTemplate from future: ' + profTemplate
            return profTemplate
            
        # Debug output if globally set
        if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + profTemplate)
        
        # Send in the message
        response = V3inst.put(url, payload=profTemplate)
        if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
        (success, resourceId) = validateResponse(response=response, method=funcName,
            shouldPass=eventPass, returnParam='ResourceIdArray')

        if purchaseInfo:
           return (passed(eventPass), response)
        else:
           return (passed(eventPass), resourceId)

#=============================================================
def groupUnsubscribeFromOffer(V3inst, groupId, resourceIds, now=None, eventPass=True, queryType='ExternalId', 
        cancelInfo=False, apiEventData=None, executeMode=None, multiRequestBuild=None, eligibilityCheck=True):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Get group OID if queryType is not ObjectId
    if eventPass and queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=groupId, queryType=queryType, now=now)
        groupId = getOID(queryResponse)

    # Build resource id list if resourceId is list
    if type(resourceIds) is list:
        numEntries = len(resourceIds)
        entryCounter = 1
        resourceIdList = resourceIds
        resourceIds = ''
        for resource in resourceIdList:
            resourceIds += str(resource)
            if entryCounter != numEntries:
                entryCounter += 1
                resourceIds += ','

    url = '/json/group/ObjectId+' + str(groupId) + '/offers/' + str(resourceIds)
    delim = '?'
    amp = False

    if executeMode is not None:
        url+= '?executeMode=' + str(executeMode)
        delim = '&'
        amp = True
        
    if now is not None:
        url+= delim + 'timestamp=' + now
        now=None
        delim = '&'
        amp = True
            
    if eligibilityCheck is not None:
        url+= delim + 'eligibilityCheck=' + str(eligibilityCheck).lower()
        delim = '&'
        amp = True

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += delim +'ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.delete(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if cancelInfo:
        return (validateResponse(response=response, method=funcName, shouldPass=eventPass), response)
    else:
        return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupCancelOffer(V3inst, queryValue, resourceId=0, cancelType=None, grantCancelProrationType=None, chargeCancelProrationType=None,
        reason=None, info=None, now=None, queryType='ExternalId', cancelInfo=False, cancelOfferDataList='', eventPass=True, executeMode=None,
        apiEventData=None, contractCancelMode=None, debtCancellationMode=None, isWaiveEarlyTerminationCharge=None, multiRequestBuild=None, eligibilityCheck=True):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    profTemplate = open(templates + 'group_cancel_offer.json').read()

    if type(resourceId) is not list:
        resourceId = [resourceId]
    cancelTemplate=''
    idArray = None

    if cancelOfferDataList:
        for cancelOfferData in cancelOfferDataList:
            template = open(templates + 'cancel_offer_data.json').read()
            template = RESTHELPER.checkIfDefined(cancelOfferData["ResourceId"], None, 'RESOURCEID', template, 'ResourceId')
            template = RESTHELPER.checkIfDefined(cancelOfferData["CancelType"], None, 'CANCELTYPE', template, 'CancelType')
            template = RESTHELPER.checkIfDefined(cancelOfferData["GrantCancelProrationType"], None, 'GRANTCANCELPRORATIONTYPE', template, 'GrantCancelProrationType')
            template = RESTHELPER.checkIfDefined(cancelOfferData["ChargeCancelProrationType"], None, 'CHARGECANCELPRORATIONTYPE', template, 'ChargeCancelProrationType')
            template = RESTHELPER.checkIfDefined(cancelOfferData["ContractCancelMode"], None, 'CONTRACTCANCELMODE', template, 'ContractCancelMode')
            template = RESTHELPER.checkIfDefined(cancelOfferData["DebtCancellationMode"], None, 'DEBTCANCELLATIONMODE', template, 'DebtCancellationMode')
            template = RESTHELPER.checkIfDefined(cancelOfferData["IsWaiveEarlyTerminationCharge"], None, 'ISWAIVEEARLYTERMINATIONCHARGE', template, 'IsWaiveEarlyTerminationCharge')

            template = RESTHELPER.checkIfDefined(cancelOfferData["Reason"], None, 'REASON', template, 'Reason')
            template = RESTHELPER.checkIfDefined(cancelOfferData["Info"], None, 'INFO', template, 'Info')
            cancelTemplate += template
    elif cancelType or grantCancelProrationType or chargeCancelProrationType or reason or info or contractCancelMode or debtCancellationMode:
        for id in resourceId:
            template = open(templates + 'cancel_offer_data.json').read()
            template = RESTHELPER.checkIfDefined(id, None, 'RESOURCEID', template, 'ResourceId')
            template = RESTHELPER.checkIfDefined(cancelType, None, 'CANCELTYPE', template, 'CancelType')
            template = RESTHELPER.checkIfDefined(grantCancelProrationType, None, 'GRANTCANCELPRORATIONTYPE', template, 'GrantCancelProrationType')
            template = RESTHELPER.checkIfDefined(chargeCancelProrationType, None, 'CHARGECANCELPRORATIONTYPE', template, 'ChargeCancelProrationType')
            template = RESTHELPER.checkIfDefined(contractCancelMode, None, 'CONTRACTCANCELMODE', template, 'ContractCancelMode')
            template = RESTHELPER.checkIfDefined(debtCancellationMode, None, 'DEBTCANCELLATIONMODE', template, 'DebtCancellationMode')

            template = RESTHELPER.checkIfDefined(reason, None, 'REASON', template, 'Reason')
            template = RESTHELPER.checkIfDefined(info, None, 'INFO', template, 'Info')
            cancelTemplate += template
    else:
        idArray = resourceId

    profTemplate = RESTHELPER.checkIfDefined(cancelTemplate, '', 'CANCELDATAARRAY', profTemplate, 'CancelDataArray')
    profTemplate = RESTHELPER.checkIfDefined(idArray, None, 'RESOURCEIDARRAY', profTemplate, 'ResourceIdArray')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(eligibilityCheck, None, 'ELIGIBILITYCHECK', profTemplate, 'EligibilityCheck')

    url = '/json/group/' + str(queryType) + '+' + str(queryValue) + '/offers'
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if cancelInfo :
        return (validateResponse(response=response, method=funcName, shouldPass=eventPass), response)
    else:
        return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def addGroupThreshold(V3inst, groupId, thresholdId, resourceId, threshName, val, notify, eventPass=True, now=None,
        queryType='ExternalId', recurringStart=None, recurringStop=None, virtualCreditLimitIsPercent=0,
        rechargeAmount=None, rechargePaymentMethodResourceId=None, executeMode=None, 
        isTemporaryCreditLimit=None, apiEventData=None, multiRequestBuild=None):

    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if notify:
        thresholdNotification = 'true'
    elif notify == None:
        thresholdNotification = None
    else:
        thresholdNotification = 'false'

    if virtualCreditLimitIsPercent:
        virtualCreditLimitIsPercent = 'true'
    else:
        virtualCreditLimitIsPercent = None

    if isTemporaryCreditLimit:
        isTemporaryCreditLimit = 'true'
    elif isTemporaryCreditLimit == None:
        isTemporaryCreditLimit = None
    else:
        isTemporaryCreditLimit = 'false'

    # Use helper to look for resourceId based on thresholdId if not passed in
    if resourceId is None:
        v3inst = QAUTILS.getDatacontainerConnection()
        walletMdc = v3inst.groupQueryWallet(queryType=queryType, queryValue=groupId, now=now)
        resourceId = COMMON.getResourceId(walletMdc, thresholdId)
        if resourceId is None:
            return COMMON.debugFailure(method='addGroupThreshold', status=1, msg='ThresholdId not found')

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=groupId, queryType=queryType, now=now)
        groupId = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_add_threshold.json').read()
    profTemplate = RESTHELPER.checkIfDefined(thresholdId, None, 'THRESHOLDID', profTemplate, 'ThresholdId')
    profTemplate = RESTHELPER.checkIfDefined(threshName, None, 'NAME', profTemplate, 'Name')
    profTemplate = RESTHELPER.checkIfDefined(val, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(thresholdNotification, None, 'NOTIFICATIONSTATE', profTemplate, 'NotificationState')
    profTemplate = RESTHELPER.checkIfDefined(recurringStart, None, 'RECURRINGSTART', profTemplate, 'RecurringStart')
    profTemplate = RESTHELPER.checkIfDefined(recurringStop, None, 'RECURRINGSTOP', profTemplate, 'RecurringStop')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(virtualCreditLimitIsPercent, None, 'VIRTUALCREDITLIMITISPERCENT', profTemplate,
        'VirtualCreditLimitIsPct')
    if rechargeAmount or rechargePaymentMethodResourceId:
        rechargeData = open(templates + 'recharge_threshold_data.json').read()
        rechargeData = RESTHELPER.checkIfDefined(rechargeAmount, None, 'RECHARGEAMOUNT', rechargeData, 'Amount')
        rechargeData = RESTHELPER.checkIfDefined(rechargePaymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID',
            rechargeData, 'PaymentMethodResourceId')
    else:
        rechargeData = None
    profTemplate = RESTHELPER.checkIfDefined(rechargeData, None, 'RECHARGEDATA', profTemplate, 'RechargeData')
    profTemplate = RESTHELPER.checkIfDefined(isTemporaryCreditLimit, None, 'ISTEMPORARYCREDITLIMIT', profTemplate, 'IsTemporaryCreditLimit')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    url = '/json/group/ObjectId+' + str(groupId) + '/wallet/' + str(resourceId) + '/thresholds'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def removeGroupThreshold(V3inst, groupId, resourceId, thresholdId, now=None, queryType='ExternalId',
    removeThresholdOnly=None, removeRechargeDataOnly=None, isTemporaryCreditLimit=False, apiEventData=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=groupId, queryType=queryType, now=now)
        groupId = getOID(queryResponse)

    url = '/json/group/ObjectId+' + str(groupId) + '/wallet/' + str(resourceId) + '/thresholds/' + str(thresholdId)
    delim = '?'
    amp = False

    if removeThresholdOnly:
        url += '?removeThresholdOnly=true'
        delim = '&'
        amp = True

    if removeRechargeDataOnly:
        url += delim + 'removeRechargeDataOnly=true'
        delim = '&'
        amp = True

    if isTemporaryCreditLimit:
        url += delim + 'isTemporaryCreditLimit=true'
        delim = '&'
        amp = True

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += delim +'ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method='removeGroupThreshold')

#=============================================================
def queryGroupThresholdRechargeDefn(V3inst, queryValue, balanceResourceId=None, now=None, queryType='ExternalId', eventPass=True,
         multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass, now=now)
        queryValue = getOID(queryResponse)

    url = '/json/group/' + str(queryValue) + '/threshold_recharge_defn'
    if balanceResourceId:
        url += '?resourceId=' + str(balanceResourceId)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def addAdminToGroup(V3inst, groupId, subscriberId, subQueryType='ExternalId', groupQueryType='ExternalId',
        eventPass=True, now=None, apiEventData=None, executeMode=None, multiRequestBuild=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    adminStr = ''
   
    if type(subscriberId) is list:
        for sub in subscriberId:
            adminStr += '{"$": "MtxSubscriberSearchData", "' + str(subQueryType) + '": "' + str(sub) + '"}'
    elif subscriberId > 0:
        adminStr = '{"$": "MtxSubscriberSearchData", "' + str(subQueryType) + '": "' + str(subscriberId) + '"}'
    else:
        adminStr = None

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_add_admins.json').read()
    profTemplate = RESTHELPER.checkIfDefined(adminStr, None, 'ADMINIDS', profTemplate, None)
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, None)
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, None)

    url = '/json/group/' + str(groupQueryType) + '+' + str(groupId) + '/add_members'

    # if Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def removeAdminFromGroup(V3inst, groupId, admins, adminQueryType='ExternalId', groupQueryType='ObjectId',
        eventPass=True, now=None, executeMode=None, apiEventData=None, multiRequestBuild=None):
    global templates
    
    # Get function name
    funcName = QAUTILS.getFunctionName()
    adminStr = ''
    
    if type(admins) is list:
        for admin in admins:
            adminStr += '{"$": "MtxSubscriberSearchData", "' + str(adminQueryType) + '": "' + str(admin) + '"}'
    elif admins > 0:
        adminStr = '{"$": "MtxSubscriberSearchData", "' + str(adminQueryType) + '": "' + str(admins) + '"}'
    else:
        adminStr = None

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_remove_admins.json').read()
    profTemplate = RESTHELPER.checkIfDefined(adminStr, None, 'ADMINIDS', profTemplate, 'AdminArray')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')    
            
    url = '/json/group/' + str(groupQueryType) + '+' + str(groupId) + '/remove_members/'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if not validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return False
    return True

#=============================================================
def addSubscriberToGroup(V3inst, groupId, subscriberId, subQueryType='ExternalId', groupQueryType='ExternalId',
        apiEventData=None, eventPass=True, now=None, executeMode=None, multiRequestBuild=None):
    global templates
    
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    subscriberArray = ''
    if type(subscriberId) is not list:
        subscriberId = [subscriberId]

    for subId in subscriberId:
        subscriberArray += '{"$": "MtxSubscriberSearchData", "' + str(subQueryType) + '": "' + str(subId) + '"}'

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_add_subscriber.json').read()
    profTemplate = RESTHELPER.checkIfDefined(subscriberArray, None, 'SUBSCRIBERARRAY', profTemplate, None)
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')

    url = '/json/group/' + str(groupQueryType) + '+' + str(groupId) + '/add_members'

    # if Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def removeSubscriberFromGroup(V3inst, groupId, subscriberId, subQueryType='ExternalId', groupQueryType='ExternalId',
        apiEventData=None, eventPass=True, now=None, executeMode=None, multiRequestBuild=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    subscriberArray = []
    if type(subscriberId) is not list:
        subscriberId = [subscriberId]
    for subId in subscriberId:
        subscriberArray.append('{"$": "MtxSubscriberSearchData", "' + str(subQueryType) + '": "' + str(subId) + '"}')

    profTemplate = open(templates + 'group_remove_subscriber.json').read()
    profTemplate = RESTHELPER.checkIfDefined(subscriberArray, None, 'SUBSCRIBERARRAY', profTemplate, 'SubscriberArray')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
            
    url = '/json/group/' + str(groupQueryType) + '+' + str(groupId) + '/remove_members/'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def addSubGroupToGroup(V3inst, groupId, subGroupId, subQueryType='ExternalId', groupQueryType='ExternalId',
        apiEventData=None, eventPass=True, now=None, executeMode=None, multiRequestBuild=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    groupArray = []
    if type(subGroupId) is not list:
        subGroupId = [subGroupId]
    for group in subGroupId:
        groupArray.append('{"$": "MtxGroupSearchData", "' + str(subQueryType) + '": "' + str(group) + '"}')

    profTemplate = open(templates + 'group_add_group.json').read()
    profTemplate = RESTHELPER.checkIfDefined(groupArray, None, 'GROUPARRAY', profTemplate, None)
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    url = '/json/group/' + str(groupQueryType) + '+' + str(groupId) + '/add_members'

    # if Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def removeSubGroupFromGroup(V3inst, groupId, subGroupId, subQueryType='ExternalId', groupQueryType='ExternalId',
        apiEventData=None, eventPass=True, now=None, executeMode=None, multiRequestBuild=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    groupArray = []
    if type(subGroupId) is not list:
        subGroupId = [subGroupId]
    for group in subGroupId:
        groupArray.append('{"$": "MtxGroupSearchData", "' + str(subQueryType) + '": "' + str(group) + '"}')

    profTemplate = open(templates + 'group_remove_group.json').read()
    profTemplate = RESTHELPER.checkIfDefined(groupArray, None, 'GROUPARRAY', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    url = '/json/group/' + str(groupQueryType) + '+' + str(groupId) + '/remove_members/'
            
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if not validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return False

    return True

#=============================================================
def addGroupMembership(V3inst, groupId, subscribers=None, subGroups=None, subQueryType='ExternalId',
        subGroupQueryType='ExternalId', groupQueryType='ExternalId', eventPass=True, now=None,
        admins=None, adminQueryType='ExternalId', apiEventData=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    subPassed = False
    groupPassed = False
    adminPassed = False
    if subscribers:
        if addSubscriberToGroup(V3inst, groupId, subscribers, subQueryType=subQueryType,
                groupQueryType=groupQueryType, apiEventData=apiEventData, now=now):
            subPassed = True

    if subGroups:
        if addSubGroupToGroup(V3inst, groupId, subGroups, subQueryType=subGroupQueryType, groupQueryType=groupQueryType,
                apiEventData=apiEventData, now=now):
            groupPassed = True

    if admins:
        if not addAdminToGroup(V3inst, groupId, admins, subQueryType=subQueryType, groupQueryType=groupQueryType, now=now):
            adminPassed = True

    if eventPass:
        if not subPassed or not groupPassed or not adminPassed:
            return False
    else:
        if subPassed and groupPassed and adminPassed:
            return False

    return True

#=============================================================
def removeGroupMembership(V3inst, groupId, subscribers=None, subGroups=None, subQueryType='ExternalId',
        subGroupQueryType='ExternalId', groupQueryType='ExternalId', eventPass=True, now=None,
        admins=None, adminQueryType='ExternalId', apiEventData=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if subscribers:
        if not removeSubscriberFromGroup(V3inst, groupId, subscribers, subQueryType=subQueryType,
                groupQueryType=groupQueryType, eventPass=eventPass, now=now):
            return False

    if subGroups:
        if not removeSubGroupFromGroup(V3inst, groupId, subGroups, subQueryType=subQueryType,
                groupQueryType=groupQueryType, eventPass=eventPass, now=now):
            return False

    if admins:
        if not removeAdminFromGroup(V3inst, groupId, admins, adminQueryType=subQueryType, groupQueryType=groupQueryType,
                now=now):
            return False

    return True

#=============================================================
def addGroupBalance(V3inst, groupId, balanceList, now=None, queryType='ExternalId', eventPass=True, executeMode=None,
        apiEventData=None, multiRequestBuild=None):

    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=groupId, queryType=queryType, now=now)
        groupId = getOID(queryResponse)

    # Make separate REST calls for each balance to add
    for balance in balanceList:
        templateId = balance['BalanceTemplateId']
        if balance['InitAmount']:
            initAmount = balance['InitAmount']
        profTemplate = open(templates + 'group_add_balance.json').read()
        profTemplate = RESTHELPER.checkIfDefined(templateId, None, 'TEMPLATEID', profTemplate, 'BalanceTemplateId')
        profTemplate = RESTHELPER.checkIfDefined(initAmount, None, 'INITAMOUNT', profTemplate, 'InitAmount')
        profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
        profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    
        url = '/json/group/ObjectId+' + str(groupId)
        
        # Debug output if globally set
        if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + profTemplate)
        
        response = V3inst.put(url, payload=profTemplate)
        if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
        return validateResponse(response=response, method='addGroupBalance', shouldPass=eventPass)
    
#=============================================================
def queryGroup(V3inst, queryValue, queryType='ExternalId', querySize=None, eventPass=True, now=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    amp = False

    url = '/json/group/' + str(queryType) + '+' + str(queryValue)
        
   
    # Add size if specified
    if querySize:
        url += '?querySize=' + str(querySize)
        amp = True
    else: amp = False
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def queryGroupWallet(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass, now=now)
        queryValue = getOID(queryResponse)

    url = '/json/group/ObjectId+' + str(queryValue) + '/wallet'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def deleteGroup(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True,
        apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/json/group/ObjectId+' + str(queryValue)
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += '?ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.delete(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#========================================================
def deleteSubscriber(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True, deleteDevices=False,
        deleteSession=False, apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Get subscriber OID if queryType is not ObjectId
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/json/subscriber/ObjectId+' + str(queryValue)
    

    # URL extension for delete devices
    if deleteDevices == True or deleteDevices == '1' or deleteDevices == 1:
                 url += '?deleteDevice=True'
    else:        url += '?deleteDevice=False'

    delim = '&'
    amp = True

    if deleteSession == True:
        url += delim + 'deleteSession=True'

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += delim + 'ApiEventData=' +URL.quote_plus(apiEventDataStr)
            
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#========================================================
def createBillingCycleData(templateId, dateOffset=None, startTime=None, immediateChange=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    billingCycle = '{"$": "MtxBillingCycleData",'

    if dateOffset:
        billingCycle += '"DateOffset": "' + str(dateOffset) + '",'

    billingCycle += '"BillingCycleId": "' + str(templateId) + '"}'

    return billingCycle

#========================================================
def createSubscriberBillingProfile(V3inst, subscriberId, profileId, startTime=None, dateOffset=0,
        queryType='ExternalId', eventPass=True, now=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if now is None:
        now = startTime
    billingCycle = createBillingCycleData(templateId=profileId, dateOffset=dateOffset, startTime=startTime)

    return modifySubscriber(V3inst, subscriberId, queryType=queryType, billingCycle=billingCycle, now=now,
        eventPass=eventPass)

#========================================================
def createGroupBillingProfile(V3inst, groupId, profileId, startTime=None, dateOffset=0,
        queryType='ExternalId', eventPass=True, now=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if now is None:
        now = startTime
    billingCycle = createBillingCycleData(templateId=profileId, dateOffset=dateOffset, startTime=startTime)

    return modifyGroup(V3inst, groupId, groupQueryType=queryType, billingCycle=billingCycle, now=now,
        eventPass=eventPass)

#=============================================================
def getGatewayAuthorizationToken(V3inst, paymentGatewayUserId=None, paymentGatewayId=0, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/json/system/payment_client/' + str(paymentGatewayId) + '/token/' 
    if paymentGatewayUserId:
        url += str(paymentGatewayUserId)

    response = V3inst.post(url, payload=None)

    if QAUTILS.DebugLevel > 0:
        print(' url: ' + url)
        print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberAddPaymentMethod(V3inst, queryValue, paymentGatewayUserId=None, paymentGatewayOneTimeToken=None, paymentGatewayId=0,
        paymentType=None, name=None, isDefault=True, isSysDefault=None, queryType='ExternalId', paymentAttr=None, now=None,
        eventPass=True, executeMode=None, returnTemplate=False, apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if isDefault:
        isDefault = 'true'
    elif isDefault == False:
        isDefault = 'false'

    attrStr = None
    if paymentAttr is not None:
        attrStr = parseAttrMdc(paymentAttr)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_add_payment_method.json').read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(paymentGatewayUserId, None, 'PAYMENTGATEWAYUSERID', profTemplate, 'PaymentGatewayUserId')
    profTemplate = RESTHELPER.checkIfDefined(paymentGatewayOneTimeToken, None, 'PAYMENTGATEWAYONETIMETOKEN', profTemplate, 'PaymentGatewayOneTimeToken')
    profTemplate = RESTHELPER.checkIfDefined(paymentGatewayId, None, 'PAYMENTGATEWAYID', profTemplate, 'PaymentGatewayId')
    profTemplate = RESTHELPER.checkIfDefined(paymentType, None, 'PAYMENTTYPE', profTemplate, 'PaymentType')
    profTemplate = RESTHELPER.checkIfDefined(name, None, 'NAME', profTemplate, 'Name')
    profTemplate = RESTHELPER.checkIfDefined(isDefault, None, 'ISDEFAULT', profTemplate, 'IsDefault')
    profTemplate = RESTHELPER.checkIfDefined(isSysDefault, None, 'ISSYSDEFAULT', profTemplate, 'IsSysDefault')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'PAYMENTATTR', profTemplate, 'PaymentAttr')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    if returnTemplate:
        return profTemplate

    url = '/json/'+RESTV3.subUrl+'/' + str(queryType) + '+' + str(queryValue) + '/payment_method/' + str(paymentGatewayId)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#========================================================
def subscriberCreatePaymentOneTimeToken(V3inst, queryValue, queryType='ExternalId', paymentMethodResourceId=None, paymentAttr=None,
    eventPass=True, apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType)
        queryValue = getOID(queryResponse)

    if not paymentMethodResourceId:
        paymentMethodResourceId=0

    profTemplate = open(templates + 'subscriber_request_payment_token.json').read()
    profTemplate = RESTHELPER.checkIfDefined(paymentMethodResourceId, 0, 'PAYMENTMETHODRESOURCEID', profTemplate, 'PaymentMethodResourceId')
    profTemplate = RESTHELPER.checkIfDefined(paymentAttr, None, 'PAYMENTATTR', profTemplate, 'PaymentAttr')

    url = '/json/'+RESTV3.subUrl+'/' + str(queryValue) + '/payment_token/' + str(paymentMethodResourceId) + '/create_one_time'

   # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload: ' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)

    if QAUTILS.DebugLevel > 0: print(funcName + ' response: ' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#========================================================
def subscriberModifyPaymentMethod(V3inst, queryValue, resourceId=None, paymentGatewayUserId=None, paymentType=None, name=None,
        paymentGatewayOneTimeToken=None, isDefault=True, isSysDefault=None, queryType='ExternalId', paymentAttr=None, now=None,
        eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if isDefault:
        isDefault = 'true'
    elif isDefault == False:
        isDefault = 'false'

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_modify_payment_method.json').read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(resourceId, None, 'RESOURCEID', profTemplate, 'ResourceId')
    profTemplate = RESTHELPER.checkIfDefined(paymentGatewayUserId, None, 'PAYMENTGATEWAYUSERID', profTemplate, 'PaymentGatewayUserId')
    profTemplate = RESTHELPER.checkIfDefined(paymentGatewayOneTimeToken, None, 'PAYMENTGATEWAYONETIMETOKEN', profTemplate, 'PaymentGatewayOneTimeToken')
    profTemplate = RESTHELPER.checkIfDefined(paymentType, None, 'PAYMENTTYPE', profTemplate, 'PaymentType')
    profTemplate = RESTHELPER.checkIfDefined(name, None, 'NAME', profTemplate, 'Name')
    profTemplate = RESTHELPER.checkIfDefined(isDefault, None, 'ISDEFAULT', profTemplate, 'IsDefault')
    profTemplate = RESTHELPER.checkIfDefined(isSysDefault, None, 'ISSYSDEFAULT', profTemplate, 'IsSysDefault')
    profTemplate = RESTHELPER.checkIfDefined(paymentAttr, None, 'PAYMENTATTR', profTemplate, 'PaymentAttr')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    url = '/json/'+RESTV3.subUrl+'/' + str(queryType) + '+' + str(queryValue) + '/payment_method/' + str(resourceId)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#========================================================
def subscriberValidatePaymentMethod(V3inst, queryValue, queryType='ExternalId', resourceId=None, postalCode=None,
        now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    paymentMethodValidationData = None
    if postalCode is not None:
        paymentMethodValidationData = parseAttrMdc(RESTV3.createAttr('MtxAddressData', {'PostalCode':postalCode}))

    url = '/json/subscription/' + str(queryValue) + '/validate_payment_method'

    profTemplate = open(templates + 'subscriber_validate_payment_method.json').read()
    profTemplate = RESTHELPER.checkIfDefined(paymentMethodValidationData, None, 'ADDRESSDATA', profTemplate, 'AddressData')
    profTemplate = RESTHELPER.checkIfDefined(resourceId, None, 'RESOURCEID', profTemplate, 'ResourceId')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#========================================================
def subscriberQueryPaymentMethod(V3inst, queryValue, paymentGatewayId=None, returnDefault=None, returnSysDefault=None,
        queryType='ObjectId', now=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

        
    url = '/json/'+RESTV3.subUrl+'/' + str(queryType) + '+' + str(queryValue) + '/payment_method'
    if paymentGatewayId or paymentGatewayId == 0 or returnDefault:
        url +=  '?'
        if paymentGatewayId or paymentGatewayId == 0 or returnDefault or returnSysDefault:
            url +=  'gatewayId=' + str(paymentGatewayId)
            if returnDefault or returnSysDefault:
                url += '&'
        if returnDefault:
            url += 'returnDefault=' + str(returnDefault)
        if returnSysDefault:
            url += 'returnSysDefault=' + str(returnSysDefault)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#========================================================
def subscriberRemovePaymentMethod(V3inst, queryValue, resourceId=None, queryType='ObjectId', now=None, eventPass=True,
        apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/json/'+RESTV3.subUrl+'/' + str(queryType) + '+' + str(queryValue) + '/payment_method/' + str(resourceId)
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += '?ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupAddPaymentMethod(V3inst, queryValue, paymentGatewayUserId=None, paymentGatewayOneTimeToken=None, paymentGatewayId=0,
        paymentType=None, name=None, isDefault=True, isSysDefault=None, queryType='ExternalId', paymentAttr=None, now=None, 
        eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if isDefault:
        isDefault = 'true'
    elif isDefault == False:
        isDefault = 'false'

    attrStr = None
    if paymentAttr is not None:
        attrStr = parseAttrMdc(paymentAttr)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_add_payment_method.json').read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(paymentGatewayUserId, None, 'PAYMENTGATEWAYUSERID', profTemplate, 'PaymentGatewayUserId')
    profTemplate = RESTHELPER.checkIfDefined(paymentGatewayOneTimeToken, None, 'PAYMENTGATEWAYONETIMETOKEN', profTemplate, 'PaymentGatewayOneTimeToken')
    profTemplate = RESTHELPER.checkIfDefined(paymentGatewayId, None, 'PAYMENTGATEWAYID', profTemplate, 'PaymentGatewayId')
    profTemplate = RESTHELPER.checkIfDefined(paymentType, None, 'PAYMENTTYPE', profTemplate, 'PaymentType')
    profTemplate = RESTHELPER.checkIfDefined(name, None, 'NAME', profTemplate, 'Name')
    profTemplate = RESTHELPER.checkIfDefined(isDefault, None, 'ISDEFAULT', profTemplate, 'IsDefault')
    profTemplate = RESTHELPER.checkIfDefined(isSysDefault, None, 'ISSYSDEFAULT', profTemplate, 'IsSysDefault')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'PAYMENTATTR', profTemplate, 'PaymentAttr')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    url = '/json/group/' + str(queryType) + '+' + str(queryValue) + '/payment_method/' + str(paymentGatewayId)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#========================================================
def groupCreatePaymentOneTimeToken(V3inst, queryValue, queryType='ExternalId', paymentMethodResourceId=None, paymentAttr=None,
    eventPass=True, apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType)
        queryValue = getOID(queryResponse)

    if not paymentMethodResourceId:
        paymentMethodResourceId=0

    profTemplate = open(templates + 'group_request_payment_token.json').read()
    profTemplate = RESTHELPER.checkIfDefined(paymentMethodResourceId, 0, 'PAYMENTMETHODRESOURCEID', profTemplate, 'PaymentMethodResourceId')
    profTemplate = RESTHELPER.checkIfDefined(paymentAttr, None, 'PAYMENTATTR', profTemplate, 'PaymentAttr')

    url = '/json/group/' + str(queryValue) + '/payment_token/' + str(paymentMethodResourceId) + '/create_one_time'

   # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload: ' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)

    if QAUTILS.DebugLevel > 0: print(funcName + ' response: ' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#========================================================
def groupModifyPaymentMethod(V3inst, queryValue, resourceId=None, paymentGatewayUserId=None, paymentType=None, name=None,
        paymentGatewayOneTimeToken=None, isDefault=None, isSysDefault=None, queryType='ExternalId', paymentAttr=None,
        apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if isDefault:
        isDefault = 'true'
    elif isDefault == False:
        isDefault = 'false'

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_modify_payment_method.json').read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(resourceId, None, 'RESOURCEID', profTemplate, 'ResourceId')
    profTemplate = RESTHELPER.checkIfDefined(paymentGatewayUserId, None, 'PAYMENTGATEWAYUSERID', profTemplate, 'PaymentGatewayUserId')
    profTemplate = RESTHELPER.checkIfDefined(paymentGatewayOneTimeToken, None, 'PAYMENTGATEWAYONETIMETOKEN', profTemplate, 'PaymentGatewayOneTimeToken')
    profTemplate = RESTHELPER.checkIfDefined(paymentType, None, 'PAYMENTTYPE', profTemplate, 'PaymentType')
    profTemplate = RESTHELPER.checkIfDefined(name, None, 'NAME', profTemplate, 'Name')
    profTemplate = RESTHELPER.checkIfDefined(isDefault, None, 'ISDEFAULT', profTemplate, 'IsDefault')
    profTemplate = RESTHELPER.checkIfDefined(isSysDefault, None, 'ISSYSDEFAULT', profTemplate, 'IsSysDefault')
    profTemplate = RESTHELPER.checkIfDefined(paymentAttr, None, 'PAYMENTATTR', profTemplate, 'PaymentAttr')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    url = '/json/group/' + str(queryType) + '+' + str(queryValue) + '/payment_method/' + str(resourceId)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#========================================================
def groupValidatePaymentMethod(V3inst, queryValue, queryType='ExternalId', resourceId=None, postalCode=None,
        now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    paymentMethodValidationData = None
    if postalCode is not None:
        paymentMethodValidationData = parseAttrMdc(RESTV3.createAttr('MtxAddressData', {'PostalCode':postalCode}))

    url = '/json/group/' + str(queryValue) + '/validate_payment_method'

    profTemplate = open(templates + 'group_validate_payment_method.json').read()
    profTemplate = RESTHELPER.checkIfDefined(paymentMethodValidationData, None, 'ADDRESSDATA', profTemplate, 'AddressData')
    profTemplate = RESTHELPER.checkIfDefined(resourceId, None, 'RESOURCEID', profTemplate, 'ResourceId')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#========================================================
def groupQueryPaymentMethod(V3inst, queryValue, paymentGatewayId=None, returnDefault=None, returnSysDefault=None,
        queryType='ObjectId', now=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/json/group/' + str(queryType) + '+' + str(queryValue) + '/payment_method'
    if paymentGatewayId or paymentGatewayId == 0 or returnDefault:
        url +=  '?'
        if paymentGatewayId or paymentGatewayId == 0 or returnDefault or returnSysDefault:
            url +=  'gatewayId=' + str(paymentGatewayId)
            if returnDefault or returnSysDefault:
                url += '&'
        if returnDefault:
            url += 'returnDefault=' + str(returnDefault)
        if returnSysDefault:
            url += 'returnSysDefault=' + str(returnSysDefault)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#========================================================
def groupRemovePaymentMethod(V3inst, queryValue, resourceId=None, queryType='ObjectId', now=None, eventPass=True,
        apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/json/group/' + str(queryType) + '+' + str(queryValue) + '/payment_method/' + str(resourceId)
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += '?ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def subscriberPayment(V3inst, queryValue, amount, payNow=None, queryType='ExternalId', 
        paymentMethodResourceId=None, paymentGatewayId=None, paymentGatewayOneTimeToken=None, info=None, apiEventData=None, 
        paymentGatewayUserId=None, chargeMethodAttr=None, reason=None, eventPass=True, now=None, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    chargeMethodAttrStr = None
    if chargeMethodAttr is not None:
        chargeMethodAttrStr = parseAttrMdc(chargeMethodAttr)

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_payment.json').read()
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(payNow, None, 'PAYNOW', profTemplate, 'PayNow')
    if paymentMethodResourceId or paymentGatewayId or paymentGatewayOneTimeToken or chargeMethodAttr:
        chargeMethodData = open(templates + 'charge_method_data.json').read()
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'CHARGEMETHOD', chargeMethodData, 'ChargeMethod')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', chargeMethodData, 'PaymentMethodResourceId')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayId, None, 'PAYMENTGATEWAYID', chargeMethodData, 'PaymentGatewayId')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayUserId, None, 'PAYMENTGATEWAYUSERID', chargeMethodData, 'PaymentGatewayUserId')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayOneTimeToken, None, 'PAYMENTGATEWAYONETIMETOKEN', chargeMethodData, 'PaymentGatewayOneTimeToken')
        chargeMethodData = RESTHELPER.checkIfDefined(chargeMethodAttrStr, None, 'ATTR', chargeMethodData, 'ChargeMethodAttr')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDSETTLEMENT', chargeMethodData, 'DeferredSettlement')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDsETTLEMENTTIMEOUT', chargeMethodData, 'DeferredSettlementTimeout')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDsETTLEMENTtIMEOUTACTION', chargeMethodData, 'DeferredSettlementTimeoutAction')
    else:
        chargeMethodData = None
    profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    url = '/json/'+RESTV3.subUrl+'/ObjectId+' + str(queryValue) + '/payment/' + str(amount) 
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def groupPayment(V3inst, queryValue, amount, payNow=None, queryType='ExternalId',
        paymentMethodResourceId=None, paymentGatewayId=None, paymentGatewayOneTimeToken=None, info=None, apiEventData=None,
        paymentGatewayUserId=None, chargeMethodAttr=None, reason=None, eventPass=True, now=None, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    chargeMethodAttrStr = None
    if chargeMethodAttr is not None:
        chargeMethodAttrStr = parseAttrMdc(chargeMethodAttr)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    profTemplate = open(templates + 'group_payment.json').read()
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(payNow, None, 'PAYNOW', profTemplate, 'PayNow')
    if paymentMethodResourceId or paymentGatewayId or paymentGatewayOneTimeToken:
        chargeMethodData = open(templates + 'charge_method_data.json').read()
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'CHARGEMETHOD', chargeMethodData, 'ChargeMethod')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', chargeMethodData, 'PaymentMethodResourceId')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayId, None, 'PAYMENTGATEWAYID', chargeMethodData, 'PaymentGatewayId')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayUserId, None, 'PAYMENTGATEWAYUSERID', chargeMethodData, 'PaymentGatewayUserId')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayOneTimeToken, None, 'PAYMENTGATEWAYONETIMETOKEN', chargeMethodData, 'PaymentGatewayOneTimeToken')
        chargeMethodData = RESTHELPER.checkIfDefined(chargeMethodAttrStr, None, 'ATTR', chargeMethodData, 'ChargeMethodAttr')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDSETTLEMENT', chargeMethodData, 'DeferredSettlement')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDsETTLEMENTTIMEOUT', chargeMethodData, 'DeferredSettlementTimeout')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDsETTLEMENTtIMEOUTACTION', chargeMethodData, 'DeferredSettlementTimeoutAction')
    else:
        chargeMethodData = None
    profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    url = '/json/group/ObjectId+' + str(queryValue) + '/payment/' + str(amount)
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberSettlePayment(V3inst, queryValue, queryType='ExternalId', resourceId=None, eventPass=True, now=None,
        apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/json/'+RESTV3.subUrl+'/' + str(queryValue) + '/settle_payment/' + str(resourceId)
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += '?ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.put(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def groupSettlePayment(V3inst, queryValue, queryType='ExternalId', resourceId=None, eventPass=True, now=None,
        apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/json/group/' + str(queryValue) + '/settle_payment/' + str(resourceId)
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += '?ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True


    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.put(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response
#=============================================================
def subscriberAdjustBalance(V3inst=None, queryValue=None, balanceResourceId=None, componentMeterId=None, adjustType=None, amount=None,
        reason=None, queryType='PhoneNumber', info=None, endTime=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,now=None,
        apiEventData=None, creditLimitPolicy=None, startTime=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_adjust_balance.json').read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEID', profTemplate,
        'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(componentMeterId, None, 'COMPONENTMETERID', profTemplate,
        'componentMeterId')
    profTemplate = RESTHELPER.checkIfDefined(adjustType, None, 'ADJUSTTYPE', profTemplate, 'AdjustType')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(endTime, None, 'ENDTIME', profTemplate, 'EndTime')
    profTemplate = RESTHELPER.checkIfDefined(startTime, None, 'STARTTIME', profTemplate, 'StartTime')
    #use endTIMEEXTENSIONOFFSETUNIT and endTIMEEXTENSIONOFFSET pattern to differentiate from ENDTIME pattern for the prefix
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffsetUnit, None, 'endTIMEEXTENSIONOFFSETUNIT', profTemplate, 'EndTimeExtensionOffsetUnit')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffset, None, 'endTIMEEXTENSIONOFFSET', profTemplate, 'EndTimeExtensionOffset')
    profTemplate = RESTHELPER.checkIfDefined(creditLimitPolicy, None, 'CREDITLIMITPOLICY', profTemplate, 'CreditLimitPolicy')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/json/'+RESTV3.subUrl+'/ObjectId+' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/adjustment'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def subscriberTransferBalance(V3inst=None, queryValue=None, queryType='PhoneNumber', balanceResourceId=None, amount=None, amountIsPct=False,
        targetSubscriberSearchData=None, targetGroupSearchData=None, targetQueryType='PhoneNumber', targetBalanceResourceId=None,
        apiEventData=None, sourceIsEventInitiator=None, creditFloorPolicy=None, reason=None, info=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    if (targetGroupSearchData and targetQueryType != 'ObjectId'):
        queryResponse = queryGroup(V3inst=V3inst, queryValue=targetGroupSearchData, queryType=targetQueryType, now=now)
        targetGroupSearchData = getOID(queryResponse)

    if (targetSubscriberSearchData and targetQueryType != 'ObjectId'):
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=targetSubscriberSearchData, queryType=targetQueryType, now=now)
        targetSubscriberSearchData = getOID(queryResponse)

    if amountIsPct:
        amountIsPct = 'true'
    else:
        amountIsPct = 'false'

    if sourceIsEventInitiator:
        sourceIsEventInitiator = 'true'
    elif (not sourceIsEventInitiator and sourceIsEventInitiator is not None):
        sourceIsEventInitiator = 'false'

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_transfer_balance.json').read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'SOURCEOBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'SOURCEBALANCERESOURCEID', profTemplate, 'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(amountIsPct, None, 'amountISPCT', profTemplate, 'AmountIsPct')
    profTemplate = RESTHELPER.checkIfDefined(targetSubscriberSearchData, None, 'TARGETSUBSCRIBERSEARCHDATA', profTemplate, 'TargetSubscriberSearchData')
    profTemplate = RESTHELPER.checkIfDefined(targetGroupSearchData, None, 'TARGETGROUPSEARCHDATA', profTemplate, 'TargetGroupSearchData')
    profTemplate = RESTHELPER.checkIfDefined(targetBalanceResourceId, None, 'TARGETBALANCERESOURCEID', profTemplate, 'TargetBalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(sourceIsEventInitiator, None, 'SOURCEISEVENTINITIATOR', profTemplate, 'SourceIsEventInitiator')
    profTemplate = RESTHELPER.checkIfDefined(creditFloorPolicy, None, 'CREDITFLOORPOLICY', profTemplate, 'CreditFloorPolicy')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    url = '/json/'+RESTV3.subUrl+'/ObjectId+' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/transfer'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def subscriberTopupBalance(V3inst=None, queryValue=None, balanceResourceId=None, amount=None, voucher=None,
        queryType='PhoneNumber', endTime=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None, 
         apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):      
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_topup_balance.json').read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEID', profTemplate,
        'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(voucher, None, 'VOUCHER', profTemplate, 'Voucher')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(endTime, None, 'ENDTIME', profTemplate, 'EndTime')
    #use endTIMEEXTENSIONOFFSETUNIT and endTIMEEXTENSIONOFFSET pattern to differentiate from ENDTIME pattern for the prefix
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffsetUnit, None, 'endTIMEEXTENSIONOFFSETUNIT', profTemplate, 'EndTimeExtensionOffsetUnit')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffset, None, 'endTIMEEXTENSIONOFFSET', profTemplate, 'EndTimeExtensionOffset')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/json/'+RESTV3.subUrl+'/ObjectId+' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/topup'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method='subscriberTopupBalance', shouldPass=eventPass)

#=============================================================
def subscriberRecharge(V3inst=None, queryValue=None, amount=None, balanceResourceId=None, payNow=None, queryType='PhoneNumber',
        endTime=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None, chargeMethodAttr=None,
        paymentMethodResourceId=None, paymentGatewayId=None, paymentGatewayOneTimeToken=None, info=None, reason=None,
        apiEventData=None, paymentGatewayUserId=None, rechargeAttr=None, now=None, eventPass=True, executeMode=None, payload=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    chargeMethodAttrStr = None
    if chargeMethodAttr is not None:
        chargeMethodAttrStr = parseAttrMdc(chargeMethodAttr)

    rechargeAttrStr = None
    if rechargeAttr is not None:
        rechargeAttrStr = parseAttrMdc(rechargeAttr)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    profTemplate = open(templates + 'subscriber_recharge.json').read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEID', profTemplate, 'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(payNow, None, 'PAYNOW', profTemplate, 'PayNow')
    if paymentMethodResourceId or paymentGatewayId or paymentGatewayOneTimeToken or chargeMethodAttrStr:
        chargeMethodData = open(templates + 'charge_method_data.json').read()
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'CHARGEMETHOD', chargeMethodData, 'ChargeMethod')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', chargeMethodData, 'PaymentMethodResourceId')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayId, None, 'PAYMENTGATEWAYID', chargeMethodData, 'PaymentGatewayId')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayUserId, None, 'PAYMENTGATEWAYUSERID', chargeMethodData, 'PaymentGatewayUserId')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayOneTimeToken, None, 'PAYMENTGATEWAYONETIMETOKEN', chargeMethodData, 'PaymentGatewayOneTimeToken')
        chargeMethodData = RESTHELPER.checkIfDefined(chargeMethodAttrStr, None, 'ATTR', chargeMethodData, 'ChargeMethodAttr')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDSETTLEMENT', chargeMethodData, 'DeferredSettlement')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDsETTLEMENTTIMEOUT', chargeMethodData, 'DeferredSettlementTimeout')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDsETTLEMENTtIMEOUTACTION', chargeMethodData, 'DeferredSettlementTimeoutAction')
    else:
        chargeMethodData = None
    profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')
    profTemplate = RESTHELPER.checkIfDefined(rechargeAttrStr, None, 'RECHARGEATTR', profTemplate, 'RechargeAttr')
    profTemplate = RESTHELPER.checkIfDefined(endTime, None, 'ENDTIME', profTemplate, 'EndTime')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    #use endTIMEEXTENSIONOFFSETUNIT and endTIMEEXTENSIONOFFSET pattern to differentiate from ENDTIME pattern for the prefix
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffsetUnit, None, 'endTIMEEXTENSIONOFFSETUNIT', profTemplate, 'EndTimeExtensionOffsetUnit')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffset, None, 'endTIMEEXTENSIONOFFSET', profTemplate, 'EndTimeExtensionOffset')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    if not balanceResourceId:
        balanceResourceId = 'default'
    url = '/json/'+RESTV3.subUrl+'/ObjectId+' + str(queryValue) + '/recharge/' + str(amount)
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        if payload:
            print(funcName + ' payload:\n' + profTemplate)
        
    if payload:
        response = V3inst.put(url, payload=profTemplate)
    else:
        response = V3inst.put(url, payload=None)

    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def subscriberAddRechargeSchedule(V3inst=None, queryValue=None, firstRechargeTime=None, queryType='ExternalId',
        periodType=None, periodCoef=None, cycleTimeOfDay=None, cycleOffset=None,
        amount=None, paymentMethodResourceId=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
        scheduledRechargeNotificationProfileId=None, now=None, eventPass=True, executeMode=None, returnTemplate=False,
        apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_add_recharge_schedule.json').read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(firstRechargeTime, None, 'FIRSTRECHARGETIME', profTemplate, 'FirstRechargeTime')
    if periodType or periodCoef or cycleTimeOfDay or cycleOffset:
        dataTemplate = open(templates + 'recharge_cycle_data.json').read()
        dataTemplate = RESTHELPER.checkIfDefined(periodType, None, 'PERIODTYPE', dataTemplate, 'PeriodType')
        dataTemplate = RESTHELPER.checkIfDefined(periodCoef, None, 'PERIODCOEF', dataTemplate, 'PeriodCoef')
        dataTemplate = RESTHELPER.checkIfDefined(cycleTimeOfDay, None, 'CYCLETIMEOFDAY', dataTemplate, 'CycleTimeOfDay')
        dataTemplate = RESTHELPER.checkIfDefined(cycleOffset, None, 'CYCLEOFFSET', dataTemplate, 'CycleOffset')
    else:
        dataTemplate=None
    profTemplate = RESTHELPER.checkIfDefined(dataTemplate, None, 'CYCLEDEFN', profTemplate, 'CycleDefn')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', profTemplate, 'PaymentMethodResourceId')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffsetUnit, None, 'ENDTIMEEXTENSIONOFFSETUNIT', profTemplate, 'EndTimeExtensionOffsetUnit')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffset, None, 'ENDTIMEEXTENSIONOFFSET', profTemplate, 'EndTimeExtensionOffset')
    profTemplate = RESTHELPER.checkIfDefined(scheduledRechargeNotificationProfileId, None, 'SCHEDULEDRECHARGENOTIFICATIONPOFILEID', profTemplate,
        'ScheduledRechargeNotificationProfileId')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    if returnTemplate:
        return profTemplate
    url = '/json/'+RESTV3.subUrl+'/ObjectId+' + str(queryValue) + '/recharge_schedule'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def subscriberModifyRechargeSchedule(V3inst=None, queryValue=None, nextRechargeTime=None, queryType='ExternalId',
        periodType=None, periodCoef=None, cycleTimeOfDay=None, cycleOffset=None,
        amount=None, paymentMethodResourceId=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
        scheduledRechargeNotificationProfileId=None, now=None, eventPass=True, executeMode=None,
        apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_modify_recharge_schedule.json').read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(nextRechargeTime, None, 'NEXTRECHARGETIME', profTemplate, 'NextRechargeTime')
    if periodType or periodCoef or cycleTimeOfDay or cycleOffset:
        dataTemplate = open(templates + 'recharge_cycle_data.json').read()
        dataTemplate = RESTHELPER.checkIfDefined(periodType, None, 'PERIODTYPE', dataTemplate, 'PeriodType')
        dataTemplate = RESTHELPER.checkIfDefined(periodCoef, None, 'PERIODCOEF', dataTemplate, 'PeriodCoef')
        dataTemplate = RESTHELPER.checkIfDefined(cycleTimeOfDay, None, 'CYCLETIMEOFDAY', dataTemplate, 'CycleTimeOfDay')
        dataTemplate = RESTHELPER.checkIfDefined(cycleOffset, None, 'CYCLEOFFSET', dataTemplate, 'CycleOffset')
    else:
        dataTemplate=None
    profTemplate = RESTHELPER.checkIfDefined(dataTemplate, None, 'CYCLEDEFN', profTemplate, 'CycleDefn')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', profTemplate, 'PaymentMethodResourceId')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffsetUnit, None, 'ENDTIMEEXTENSIONOFFSETUNIT', profTemplate, 'EndTimeExtensionOffsetUnit')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffset, None, 'ENDTIMEEXTENSIONOFFSET', profTemplate, 'EndTimeExtensionOffset')
    profTemplate = RESTHELPER.checkIfDefined(scheduledRechargeNotificationProfileId, None, 'SCHEDULEDRECHARGENOTIFICATIONPOFILEID', profTemplate,
        'ScheduledRechargeNotificationProfileId')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/json/'+RESTV3.subUrl+'/ObjectId+' + str(queryValue) + '/recharge_schedule'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def subscriberRemoveRechargeSchedule(V3inst=None, queryValue=None, queryType='ExternalId', now=None, eventPass=True, executeMode=None,
        apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/json/'+RESTV3.subUrl+'/ObjectId+' + str(queryValue) + '/recharge_schedule'
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += '?ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberQueryRechargeSchedule(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/json/'+RESTV3.subUrl+'/ObjectId+' + str(queryValue) + '/recharge_schedule'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberQueryRecurringRecharge(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/json/'+RESTV3.subUrl+'/ObjectId+' + str(queryValue) + '/recurring_recharge'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberAddBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId', balanceResourceId=None,
        durationBeforeExpiryInMinutes=None, notificationProfileId=None, paymentMethodResourceId=None, rechargeAmount=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_create_balance_expiry_recharge_defn.json').read()
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEID', profTemplate, 'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(durationBeforeExpiryInMinutes, None, 'DURATIONBEFOREEXPIRYINMINUTES', profTemplate, 'DurationBeforeExpiryInMinutes')
    profTemplate = RESTHELPER.checkIfDefined(notificationProfileId, None, 'NOTIFICATIONPROFILEID', profTemplate, 'NotificationProfileId')
    profTemplate = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', profTemplate, 'PaymentMethodResourceId')
    profTemplate = RESTHELPER.checkIfDefined(rechargeAmount, None, 'RECHARGEAMOUNT', profTemplate, 'RechargeAmount')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/json/'+RESTV3.subUrl+'/' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/balance_expiry_recharge_defn'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
     return response

#=============================================================
def subscriberModifyBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId', balanceResourceId=None,
        durationBeforeExpiryInMinutes=None, notificationProfileId=None, paymentMethodResourceId=None, rechargeAmount=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_modify_balance_expiry_recharge_defn.json').read()
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEID', profTemplate, 'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(durationBeforeExpiryInMinutes, None, 'DURATIONBEFOREEXPIRYINMINUTES', profTemplate, 'DurationBeforeExpiryInMinutes')
    profTemplate = RESTHELPER.checkIfDefined(notificationProfileId, None, 'NOTIFICATIONPROFILEID', profTemplate, 'NotificationProfileId')
    profTemplate = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', profTemplate, 'PaymentMethodResourceId')
    profTemplate = RESTHELPER.checkIfDefined(rechargeAmount, None, 'RECHARGEAMOUNT', profTemplate, 'RechargeAmount')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    url = '/json/'+RESTV3.subUrl+'/' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/balance_expiry_recharge_defn'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
     return response

#=============================================================
def subscriberRemoveBalanceExpiryRechargeDefn(V3inst=None, queryValue=None, queryType='ExternalId', balanceResourceId=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/json/'+RESTV3.subUrl+'/' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/balance_expiry_recharge_defn'
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += '?ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberQueryBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/json/'+RESTV3.subUrl+'/' + str(queryValue) + '/balance_expiry_recharge_defn'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberRefundPayment(V3inst=None, queryValue=None, queryType='PhoneNumber', balanceResourceId=None, 
        apiEventData=None, resourceId=None, amount=None, reason=None, info=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_refund_payment.json').read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEiD', profTemplate, 'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(resourceId, None, 'RESOURCEID', profTemplate, 'ResourceId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/json/'+RESTV3.subUrl+'/' + str(queryType) + '+' + str(queryValue) + '/payment_history/' + str(resourceId) + '/refund'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def subscriberQueryPaymentHistory(V3inst=None, queryValue=None, queryType='PhoneNumber',
        now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/json/'+RESTV3.subUrl+'/' + str(queryType) + '+' + str(queryValue) + '/payment_history/'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberModifyExternalPayment(V3inst=None, queryValue=None, queryType='ExternalId', resourceId=None, apiEventData=None,
        amount=None, reason=None, info=None, opType=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_modify_external_payment.json').read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(opType, None, 'OPTYPE', profTemplate, 'OpType')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/json/'+RESTV3.subUrl+'/' + str(queryValue) + '/external_payment/' + str(resourceId)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def subscriberQueryExternalPayment(V3inst=None, queryValue=None, queryType='ExternalId',
        now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/json/'+RESTV3.subUrl+'/' + str(queryValue) + '/external_payment'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now, amp=False)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberAdjustRolloverBalance(V3inst=None, queryValue=None, reason=None, balanceResourceId=None,
           queryType='PhoneNumber', balanceIntervalId=None, adjustType=None, amount=None, info=None, remainingRolloverCounter=None,
           apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_adjust_rollover_balance.json').read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEID', profTemplate,
        'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(adjustType, None, 'ADJUSTTYPE', profTemplate, 'AdjustType')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(remainingRolloverCounter, None, 'REMAININGROLLOVERCOUNTER', profTemplate, 'RemainingRolloverCounter')
    profTemplate = RESTHELPER.checkIfDefined(balanceIntervalId, None, 'BALANCEINTERVALID', profTemplate, 'BalanceIntervalId')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/json/'+RESTV3.subUrl+'/ObjectId+' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/adjust_rollover'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupAdjustBalance(V3inst=None, queryValue=None, balanceResourceId=None, componentMeterId=None, adjustType=None, amount=None,
        reason=None, queryType='ExternalId', info=None, endTime=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None, now=None,
        apiEventData=None, creditLimitPolicy=None, startTime=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_adjust_balance.json').read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEID', profTemplate,
        'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(componentMeterId, None, 'COMPONENTMETERID', profTemplate,
        'componentMeterId')
    profTemplate = RESTHELPER.checkIfDefined(adjustType, None, 'ADJUSTTYPE', profTemplate, 'AdjustType')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(endTime, None, 'ENDTIME', profTemplate, 'EndTime')
    profTemplate = RESTHELPER.checkIfDefined(startTime, None, 'STARTTIME', profTemplate, 'StartTime')
    #use endTIMEEXTENSIONOFFSETUNIT and endTIMEEXTENSIONOFFSET pattern to differentiate from ENDTIME pattern for the prefix
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffsetUnit, None, 'endTIMEEXTENSIONOFFSETUNIT', profTemplate, 'EndTimeExtensionOffsetUnit')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffset, None, 'endTIMEEXTENSIONOFFSET', profTemplate, 'EndTimeExtensionOffset')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(creditLimitPolicy, None, 'CREDITLIMITPOLICY', profTemplate, 'CreditLimitPolicy')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/json/group/ObjectId+' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/adjustment'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupTransferBalance(V3inst=None, queryValue=None, queryType='PhoneNumber', balanceResourceId=None, amount=None, amountIsPct=False,
        targetSubscriberSearchData=None, targetGroupSearchData=None, targetQueryType='PhoneNumber', targetBalanceResourceId=None,
        apiEventData=None, sourceIsEventInitiator=None, creditFloorPolicy=None, reason=None, info=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    if (targetGroupSearchData and targetQueryType != 'ObjectId'):
        queryResponse = queryGroup(V3inst=V3inst, queryValue=targetGroupSearchData, queryType=targetQueryType, now=now)
        targetGroupSearchData = getOID(queryResponse)

    if (targetSubscriberSearchData and targetQueryType != 'ObjectId'):
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=targetSubscriberSearchData, queryType=targetQueryType, now=now)
        targetSubscriberSearchData = getOID(queryResponse)

    if amountIsPct:
        amountIsPct = 'true'
    else:
        amountIsPct = 'false'

    if sourceIsEventInitiator:
        sourceIsEventInitiator = 'true'
    elif (not sourceIsEventInitiator and sourceIsEventInitiator is not None):
        sourceIsEventInitiator = 'false'

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_transfer_balance.json').read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'SOURCEOBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'SOURCEBALANCERESOURCEID', profTemplate, 'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(amountIsPct, None, 'amountISPCT', profTemplate, 'AmountIsPct')
    profTemplate = RESTHELPER.checkIfDefined(targetSubscriberSearchData, None, 'TARGETSUBSCRIBERSEARCHDATA', profTemplate, 'TargetSubscriberSearchData')
    profTemplate = RESTHELPER.checkIfDefined(targetGroupSearchData, None, 'TARGETGROUPSEARCHDATA', profTemplate, 'TargetGroupSearchData')
    profTemplate = RESTHELPER.checkIfDefined(targetBalanceResourceId, None, 'TARGETBALANCERESOURCEID', profTemplate, 'TargetBalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(sourceIsEventInitiator, None, 'SOURCEISEVENTINITIATOR', profTemplate, 'SourceIsEventInitiator')
    profTemplate = RESTHELPER.checkIfDefined(creditFloorPolicy, None, 'CREDITFLOORPOLICY', profTemplate, 'CreditFloorPolicy')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    url = '/json/group/ObjectId+' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/transfer'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)


#=============================================================
def groupTopupBalance(V3inst=None, queryValue=None, balanceResourceId=None, amount=None, voucher=None,
        apiEventData=None, queryType='PhoneNumber', endTime=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)
    profTemplate = open(templates + 'group_topup_balance.json').read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEID', profTemplate,
        'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(voucher, None, 'VOUCHER', profTemplate, 'Voucher')
    profTemplate = RESTHELPER.checkIfDefined(endTime, None, 'ENDTIME', profTemplate, 'EndTime')
    #use endTIMEEXTENSIONOFFSETUNIT and endTIMEEXTENSIONOFFSET pattern to differentiate from ENDTIME pattern for the prefix
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffsetUnit, None, 'endTIMEEXTENSIONOFFSETUNIT', profTemplate, 'EndTimeExtensionOffsetUnit')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffset, None, 'endTIMEEXTENSIONOFFSET', profTemplate, 'EndTimeExtensionOffset')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/json/group/ObjectId+' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/topup'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupRecharge(V3inst=None, queryValue=None, amount=None, balanceResourceId=None, payNow=None, queryType='ExternalId',
        endTime=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None, chargeMethodAttr=None,
        paymentMethodResourceId=None, paymentGatewayId=None, paymentGatewayOneTimeToken=None, info=None, reason=None,
        apiEventData=None, paymentGatewayUserId=None, rechargeAttr=None, now=None, eventPass=True, executeMode=None, payload=True, multiRequestBuild=None):

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    chargeMethodAttrStr = None
    if chargeMethodAttr is not None:
        chargeMethodAttrStr = parseAttrMdc(chargeMethodAttr)

    rechargeAttrStr = None
    if rechargeAttr is not None:
        rechargeAttrStr = parseAttrMdc(rechargeAttr)

    profTemplate = open(templates + 'group_recharge.json').read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEID', profTemplate, 'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(payNow, None, 'PAYNOW', profTemplate, 'PayNow')
    if paymentMethodResourceId or paymentGatewayId or paymentGatewayOneTimeToken or chargeMethodAttr:
        chargeMethodData = open(templates + 'charge_method_data.json').read()
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'CHARGEMETHOD', chargeMethodData, 'ChargeMethod')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', chargeMethodData, 'PaymentMethodResourceId')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayId, None, 'PAYMENTGATEWAYID', chargeMethodData, 'PaymentGatewayId')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayUserId, None, 'PAYMENTGATEWAYUSERID', chargeMethodData, 'PaymentGatewayUserId')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayOneTimeToken, None, 'PAYMENTGATEWAYONETIMETOKEN', chargeMethodData, 'PaymentGatewayOneTimeToken')
        chargeMethodData = RESTHELPER.checkIfDefined(chargeMethodAttrStr, None, 'ATTR', chargeMethodData, 'ChargeMethodAttr')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDSETTLEMENT', chargeMethodData, 'DeferredSettlement')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDsETTLEMENTTIMEOUT', chargeMethodData, 'DeferredSettlementTimeout')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDsETTLEMENTtIMEOUTACTION', chargeMethodData, 'DeferredSettlementTimeoutAction')
    else:
        chargeMethodData = None
    profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')
    profTemplate = RESTHELPER.checkIfDefined(rechargeAttrStr, None, 'RECHARGEATTR', profTemplate, 'RechargeAttr')
    profTemplate = RESTHELPER.checkIfDefined(endTime, None, 'ENDTIME', profTemplate, 'EndTime')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    #use endTIMEEXTENSIONOFFSETUNIT and endTIMEEXTENSIONOFFSET pattern to differentiate from ENDTIME pattern for the prefix
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffsetUnit, None, 'endTIMEEXTENSIONOFFSETUNIT', profTemplate, 'EndTimeExtensionOffsetUnit')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffset, None, 'endTIMEEXTENSIONOFFSET', profTemplate, 'EndTimeExtensionOffset')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    if not balanceResourceId:
        balanceResourceId = 'default'
    url = '/json/group/ObjectId+' + str(queryValue) + '/recharge/' + str(amount)
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        if payload:
            print(funcName + ' payload:\n' + profTemplate)
        
    if payload:
        response = V3inst.put(url, payload=profTemplate)
    else:
        response = V3inst.put(url, payload=None)

    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupAddRechargeSchedule(V3inst=None, queryValue=None, firstRechargeTime=None, queryType='ExternalId',
        periodType=None, periodCoef=None, cycleTimeOfDay=None, cycleOffset=None,
        amount=None, paymentMethodResourceId=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
        scheduledRechargeNotificationProfileId=None, now=None, eventPass=True, executeMode=None,
        apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_add_recharge_schedule.json').read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(firstRechargeTime, None, 'FIRSTRECHARGETIME', profTemplate, 'FirstRechargeTime')
    if periodType or periodCoef or cycleTimeOfDay or cycleOffset:
        dataTemplate = open(templates + 'recharge_cycle_data.json').read()
        dataTemplate = RESTHELPER.checkIfDefined(periodType, None, 'PERIODTYPE', dataTemplate, 'PeriodType')
        dataTemplate = RESTHELPER.checkIfDefined(periodCoef, None, 'PERIODCOEF', dataTemplate, 'PeriodCoef')
        dataTemplate = RESTHELPER.checkIfDefined(cycleTimeOfDay, None, 'CYCLETIMEOFDAY', dataTemplate, 'CycleTimeOfDay')
        dataTemplate = RESTHELPER.checkIfDefined(cycleOffset, None, 'CYCLEOFFSET', dataTemplate, 'CycleOffset')
    else:
        dataTemplate= None
    profTemplate = RESTHELPER.checkIfDefined(dataTemplate, None, 'CYCLEDEFN', profTemplate, 'CycleDefn')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', profTemplate, 'PaymentMethodResourceId')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffsetUnit, None, 'ENDTIMEEXTENSIONOFFSETUNIT', profTemplate, 'EndTimeExtensionOffsetUnit')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffset, None, 'ENDTIMEEXTENSIONOFFSET', profTemplate, 'EndTimeExtensionOffset')
    profTemplate = RESTHELPER.checkIfDefined(scheduledRechargeNotificationProfileId, None, 'SCHEDULEDRECHARGENOTIFICATIONPOFILEID', profTemplate,
        'ScheduledRechargeNotificationProfileId')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/json/group/ObjectId+' + str(queryValue) + '/recharge_schedule'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupModifyRechargeSchedule(V3inst=None, queryValue=None, nextRechargeTime=None, queryType='ExternalId',
        periodType=None, periodCoef=None, cycleTimeOfDay=None, cycleOffset=None,
        amount=None, paymentMethodResourceId=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
        scheduledRechargeNotificationProfileId=None, now=None, eventPass=True, executeMode=None,
        apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_modify_recharge_schedule.json').read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(nextRechargeTime, None, 'NEXTRECHARGETIME', profTemplate, 'NextRechargeTime')
    if periodType or periodCoef or cycleTimeOfDay or cycleOffset:
        dataTemplate = open(templates + 'recharge_cycle_data.json').read()
        dataTemplate = RESTHELPER.checkIfDefined(periodType, None, 'PERIODTYPE', dataTemplate, 'PeriodType')
        dataTemplate = RESTHELPER.checkIfDefined(periodCoef, None, 'PERIODCOEF', dataTemplate, 'PeriodCoef')
        dataTemplate = RESTHELPER.checkIfDefined(cycleTimeOfDay, None, 'CYCLETIMEOFDAY', dataTemplate, 'CycleTimeOfDay')
        dataTemplate = RESTHELPER.checkIfDefined(cycleOffset, None, 'CYCLEOFFSET', dataTemplate, 'CycleOffset')
    else:
        dataTemplate=None
    profTemplate = RESTHELPER.checkIfDefined(dataTemplate, None, 'CYCLEDEFN', profTemplate, 'CycleDefn')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', profTemplate, 'PaymentMethodResourceId')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffsetUnit, None, 'ENDTIMEEXTENSIONOFFSETUNIT', profTemplate, 'EndTimeExtensionOffsetUnit')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffset, None, 'ENDTIMEEXTENSIONOFFSET', profTemplate, 'EndTimeExtensionOffset')
    profTemplate = RESTHELPER.checkIfDefined(scheduledRechargeNotificationProfileId, None, 'SCHEDULEDRECHARGENOTIFICATIONPOFILEID', profTemplate,
        'ScheduledRechargeNotificationProfileId')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/json/group/ObjectId+' + str(queryValue) + '/recharge_schedule'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupRemoveRechargeSchedule(V3inst=None, queryValue=None, queryType='ExternalId', now=None, eventPass=True, executeMode=None,
        apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/json/group/ObjectId+' + str(queryValue) + '/recharge_schedule'
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += '?ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def groupQueryRechargeSchedule(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/json/group/ObjectId+' + str(queryValue) + '/recharge_schedule'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def groupQueryRecurringRecharge(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/json/group/ObjectId+' + str(queryValue) + '/recurring_recharge'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def groupAddBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId', balanceResourceId=None,
        durationBeforeExpiryInMinutes=None, notificationProfileId=None, paymentMethodResourceId=None, rechargeAmount=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_create_balance_expiry_recharge_defn.json').read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEID', profTemplate, 'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(durationBeforeExpiryInMinutes, None, 'DURATIONBEFOREEXPIRYINMINUTES', profTemplate, 'DurationBeforeExpiryInMinutes')
    profTemplate = RESTHELPER.checkIfDefined(notificationProfileId, None, 'NOTIFICATIONPROFILEID', profTemplate, 'NotificationProfileId')
    profTemplate = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', profTemplate, 'PaymentMethodResourceId')
    profTemplate = RESTHELPER.checkIfDefined(rechargeAmount, None, 'RECHARGEAMOUNT', profTemplate, 'RechargeAmount')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    url = '/json/group/' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/balance_expiry_recharge_defn'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def groupModifyBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId', balanceResourceId=None,
        durationBeforeExpiryInMinutes=None, notificationProfileId=None, paymentMethodResourceId=None, rechargeAmount=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_modify_balance_expiry_recharge_defn.json').read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEID', profTemplate, 'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(durationBeforeExpiryInMinutes, None, 'DURATIONBEFOREEXPIRYINMINUTES', profTemplate, 'DurationBeforeExpiryInMinutes')
    profTemplate = RESTHELPER.checkIfDefined(notificationProfileId, None, 'NOTIFICATIONPROFILEID', profTemplate, 'NotificationProfileId')
    profTemplate = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', profTemplate, 'PaymentMethodResourceId')
    profTemplate = RESTHELPER.checkIfDefined(rechargeAmount, None, 'RECHARGEAMOUNT', profTemplate, 'RechargeAmount')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    url = '/json/group/' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/balance_expiry_recharge_defn'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def groupRemoveBalanceExpiryRechargeDefn(V3inst=None, queryValue=None, queryType='ExternalId', balanceResourceId=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/json/group/' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/balance_expiry_recharge_defn'
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr:
                url += '?ApiEventData=' +URL.quote_plus(apiEventDataStr)
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def groupQueryBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/json/group/' + str(queryValue) + '/balance_expiry_recharge_defn'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response
    
#=============================================================
def sysQueryConfigRecurringRecharge(V3inst, eventPass=True, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/json/system/configuration/recurring_recharge'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response
#=============================================================

def groupRefundPayment(V3inst=None, queryValue=None, queryType='ExternalId', balanceResourceId=None,
        apiEventData=None, resourceId=None, amount=None, reason=None, info=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_refund_payment.json').read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEiD', profTemplate, 'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(resourceId, None, 'RESOURCEID', profTemplate, 'ResourceId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    url = '/json/group/' + str(queryType) + '+' + str(queryValue) + '/payment_history/' + str(resourceId) + '/refund'
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupQueryPaymentHistory(V3inst=None, queryValue=None, queryType='ExternalId',
        now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/json/group/' + str(queryType) + '+' + str(queryValue) + '/payment_history/'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def groupModifyExternalPayment(V3inst=None, queryValue=None, queryType='ExternalId', resourceId=None, apiEventData=None,
        amount=None, reason=None, info=None, opType=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querygroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_modify_external_payment'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(opType, None, 'OPTYPE', profTemplate, 'OpType')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/json/group/' + str(queryValue) + '/external_payment/' + str(resourceId)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupQueryExternalPayment(V3inst=None, queryValue=None, queryType='ExternalId',
        now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/json/group/' + str(queryValue) + '/external_payment'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now, amp=False)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response


#=============================================================
def groupAdjustRolloverBalance(V3inst=None, queryValue=None, reason=None, balanceResourceId=None,
           queryType='ExternalId', balanceIntervalId=None, adjustType=None, amount=None, info=None, remainingRolloverCounter=None,
           apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_adjust_rollover_balance.json').read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEID', profTemplate,
        'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(adjustType, None, 'ADJUSTTYPE', profTemplate, 'AdjustType')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(remainingRolloverCounter, None, 'REMAININGROLLOVERCOUNTER', profTemplate, 'RemainingRolloverCounter')
    profTemplate = RESTHELPER.checkIfDefined(balanceIntervalId, None, 'BALANCEINTERVALID', profTemplate, 'BalanceIntervalId')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/json/group/ObjectId+' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/adjust_rollover'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def subscriberEstimateRecurringCharge(V3inst, queryValue=None, queryType='ObjectId', now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    # Need in OID format
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/json/'+RESTV3.subUrl+'/ObjectId+' + str(queryValue) + '/recurringcharge'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return (passed(eventPass), response)

#=============================================================
def groupEstimateRecurringCharge(V3inst, queryValue=None, queryType='ObjectId', now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
   
    # Need in OID format
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/json/group/ObjectId+' + str(queryValue) + '/recurringcharge'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return (passed(eventPass), response)

#=============================================================
def pricingQueryStatus(V3inst, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    response = V3inst.get('/json/pricing/status', time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method='pricingQueryStatus', shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryLifecycle(V3inst, objectType, lifecycleProfileId=None, now=None, eventPass=True, useCache=False, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    print('life cycle REST query for object ' + str(objectType))
    url = '/json/pricing/lifecycle/'+str(objectType)
    if objectType == 'offer':
        if lifecycleProfileId:
            url += '/' + str(lifecycleProfileId)
        else:
            url += '/default'

    if QAUTILS.DebugLevel > 0: print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method='pricingQueryStatus', shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryOffer(V3inst, offerId, queryType='OfferId', version=None, now=None, eventPass=True, useCache=False, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType == 'OfferId' and version is None:
        response = V3inst.get('/json/pricing/offers/' + str(offerId), time=now)
    elif queryType == 'OfferId' and version is not None:
        response = V3inst.get('/json/pricing/offers/' + str(offerId) + '/version/' + str(version))
    elif queryType == 'ExternalId':
        offerId = URL.quote(offerId,'')
        response = V3inst.get('/json/pricing/offers/query/' + str(offerId), time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if validateResponse(response=response, method='pricingQueryOffer', shouldPass=eventPass):
        return response

#=============================================================
def pricingCacheQueryOffer(V3inst, queryValue=None, queryType='offers', version=None, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/' + RESTV3.urlPrefix + '/cache/pricing/'+queryType+'/'+str(queryValue)
    if version is not None :
        url += '/'+str(version)

    if QAUTILS.DebugLevel > 0: print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method='pricingCacheQueryOffer', shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryOfferList(V3inst, now=None, globalList=False, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if globalList:
       response = V3inst.get('/json/pricing/offers?globalOffersOnly=true', time=now) 
    else:
       response = V3inst.get('/json/pricing/offers', time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    print(response)
    if validateResponse(response=response, method='pricingQueryOfferList', shouldPass=eventPass):
        return response

#=============================================================
def pricingCacheQueryOfferList(V3inst, now=None, queryType='offers', eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/cache/pricing/'+queryType
    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    # some bundle has PhoneNumber field wthout double quote added, which  causing json loads exception
    # we need to add double quote for phone number
    if RESTV3.urlPrefix == 'json':
        response = re.sub(r'"PhoneNumber": (.*)', r'"PhoneNumber": "\1"', response)

    if validateResponse(response=response, method='pricingCacheQueryOfferList', shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryBalance(V3inst, balanceId, queryType='BalanceId', now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    response = V3inst.get('/json/pricing/balance/' + str(balanceId), time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method='pricingQueryBalance', shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryBalanceList(V3inst, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    response = V3inst.get('/json/pricing/balances', time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method='pricingQueryBalanceList', shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryServiceType(V3inst, queryType='ServiceTypeId', queryValue = None, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    response = V3inst.get('/json/pricing/service_type/ObjectId+' + str(queryValue) , time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method='pricingQueryServiceType', shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryServiceTypeList(V3inst, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    response = V3inst.get('/json/pricing/service_types' , time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method='pricingQueryServiceContext', shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryServiceContext(V3inst, serviceQueryType='ServiceTypeId', serviceQueryValue=None, contextQueryType='ContextId', contextQueryValue=None
                               , now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    response = V3inst.get('/json/pricing/service_context/' + str(serviceQueryValue) + '/' + str(contextQueryValue) , time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method='pricingQueryServiceContext', shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryBalanceClass(V3inst, queryType='BalanceClassId', queryValue = None, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    response = V3inst.get('/json/pricing/balance_class/ObjectId+' + str(queryValue) , time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method='pricingQueryBalanceClass', shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryBalanceClassList(V3inst, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    response = V3inst.get('/json/pricing/balance_classes'  , time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method='pricingQueryBalanceClassList', shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryBalanceThresholdList(V3inst,queryType='BalanceId', queryValue = None, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    response = V3inst.get('/json/pricing/balance/ObjectId+' + str(queryValue) + '/thresholds' , time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method='pricingQueryBalanceThresholdList', shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryBillingCycle(V3inst, queryType='BillingCycleId', queryValue = None, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    response = V3inst.get('/json/pricing/billing_cycle/ObjectId+' + str(queryValue) , time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method='pricingQueryBillingCycle', shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryBillingCycleList(V3inst, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    response = V3inst.get('/json/pricing/billing_cycles'  , time=now)

    if validateResponse(response=response, method='pricingQueryBillingCycleList', shouldPass=eventPass):
        return response

#=============================================================
# Query One Time Offers
def subscriberQueryOneTimeOffer(V3inst, queryValue=None, queryType=None, now=None, eventPass=True, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/subscription/' + str(queryType) + '+' + str(queryValue) + '/cancelable_one_time_offer'

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
# Query One Time Offers
def deviceQueryOneTimeOffer(V3inst, queryValue=None, queryType=None, now=None, eventPass=True, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/device/' + str(queryType) + '+' + str(queryValue) + '/cancelable_one_time_offer'

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
# Query One Time Offers
def groupQueryOneTimeOffer(V3inst, queryValue=None, queryType=None, now=None, eventPass=True, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryType) + '+' + str(queryValue) + '/cancelable_one_time_offer'

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response


#Query Pricing Catalog List
#=============================================================
def pricingQueryCatalogItemList(V3inst, now=None, routingType=None, routingValue=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    url='/json/pricing/CatalogItem'
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)

    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#Query Pricing Catalog List
#=============================================================
def pricingCacheQueryCatalogItemList(V3inst, now=None, routingType=None, routingValue=None, eventPass=True, queryType='CatalogItem', multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url='/'+RESTV3.urlPrefix+'/cache/pricing/'+queryType
    
    if queryType not in ['CatalogItem', 'catalogItem']:
        print('ERROR: Query CatalogItemList parameter queryType has an unsupported value (' + queryType + ')')


    response = V3inst.get(url, time=now)

    if QAUTILS.DebugLevel > 0: print(funcName + ' url:'+ url + ' response:\n' + response)
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#Query Pricing Catalog Item
#=============================================================
def pricingQueryCatalogItem(V3inst, queryType=None, queryValue=None, now=None,
                            routingType=None, routingValue=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType == 'CatalogItemId':
        url = '/json/pricing/CatalogItem/PricingId+' + str(queryValue)
    elif queryType == 'ExternalId':
        url='/json/pricing/CatalogItem/ExternalId+' + str(queryValue)
    else:
        url='/json/pricing/CatalogItem/' + str(queryValue)

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)

    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response


#Query Pricing Catalog Item
#=============================================================
def pricingCacheQueryCatalogItem(V3inst, queryValue=None, now=None,
                            routingType=None, routingValue=None, eventPass=True, queryType='CatalogItem', multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url='/'+RESTV3.urlPrefix+'/cache/pricing/'+queryType+'/' + str(queryValue)


    response = V3inst.get(url, time=now)

    if QAUTILS.DebugLevel > 0: print(funcName + ' url: ' + url +' response:\n' + response)
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryEventTypeList(V3inst, now=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    url='/json/pricing/event_types/'

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)

    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryEventType(V3inst, queryType=None, queryValue=None, now=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    url='/json/pricing/event_type/' + str(queryValue)

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)

    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def getDiameterRestConfig():
    QACommon = os.getenv("QADIR") + '/Common/'
    configIniFile = QACommon + 'config.ini'
    if not os.path.exists(configIniFile):
        configIniFile = os.getenv("MYCONFIGINI")
        if not configIniFile == None:
            if not os.path.exists(configIniFile):
                print('cannot find the config ini in ../../Common or env "MYCONFIGINI"')
                sys.exit(1)
        else:
            print('cannot find the config ini in ../../Common or env "MYCONFIGINI"')
            sys.exit(1)

    print('reading configuration data from ' + str(configIniFile) + '!')
    configG = configparser.ConfigParser()
    configG.read(configIniFile)
    return (configG)

#=============================================================
def subscriberPurchaseOfferInFuture(V3inst, queryValue, offerId, purchaseStartTime, offerStartTime=None,
                      offerEndTime=None, eventPass=True, queryType='ExternalId', now=None,
                      offerIsExternal=False, offerId2=None, attr=None,  skipVtime=False, dupAttr=True,
                      catalogItemId=None, multiRequestBuild=None):
 
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Get subscriber OID if queryType is not ObjectId
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass)
        queryValue = getOID(queryResponse)
 
    profTemplate = subscribeToOffer(V3inst, externalId=queryValue, offerId=offerId, catalogItemId=catalogItemId,
                                    offerStartTime=offerStartTime, offerEndTime=offerEndTime, eventPass=eventPass,
                                    queryType='ObjectId', now=now, offerIsExternal=offerIsExternal, offerId2=offerId2,
                                    attr=attr, dupAttr=dupAttr, future=True)

    profTemplate = '{"$": "MtxRequestTaskCreate", "TaskTime": "' + str(purchaseStartTime) + '", "TaskRequest": ' + str(profTemplate) + '}'

    url = '/json'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + str(profTemplate))
        
    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    (success, objectId) = validateResponse(response=response, method=funcName , shouldPass=eventPass, returnParam='ObjectId')
    #print 'Future subscriber purchase ObjectId = ' + str(objectId)
    return objectId

#=============================================================
def subscriberCancelOfferInFuture(V3inst, cancelStartTime, queryType = 'ExternalId', queryValue = 0, resourceIdList = [], skipVtime = False, eventPass=True, multiRequestBuild=None):
        # Get function name
        funcName = QAUTILS.getFunctionName()
    
        return deleteTask(V3inst, resourceIdList, funcName, eventPass)

#=============================================================
def groupPurchaseOfferInFuture(V3inst, queryValue, offerId=None, purchaseStartTime=None, offerStartTime=None,
                      offerEndTime=None, eventPass=True, queryType='ExternalId', now=None,
                      offerIsExternal=False, offerId2=None, attr=None,  skipVtime=False, dupAttr=True,
                      catalogItemId=None, multiRequestBuild=None):
 
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Get subscriber OID if queryType is not ObjectId
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass)
        queryValue = getOID(queryResponse)
 
    profTemplate = groupSubscribeToOffer(V3inst, queryValue, offerId=offerId, catalogItemId=catalogItemId,
                                    offerStartTime=offerStartTime, offerEndTime=offerEndTime, eventPass=eventPass,
                                    queryType='ObjectId', now=now, offerIsExternal=offerIsExternal, attr=attr, 
                                    dupAttr=dupAttr, future=True)

    profTemplate = RESTHELPER.addTask(purchaseStartTime,profTemplate)  

    #print 'profTemplate =', profTemplate
    response = V3inst.post('/json', payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    (success, objectId) = validateResponse(response=response, method=funcName , shouldPass=eventPass, returnParam='ObjectId')
    #print 'Future group purchase ObjectId = ' + str(objectId)
    return objectId

#=============================================================
def groupCancelOfferInFuture(V3inst, cancelStartTime, queryType = 'ExternalId', queryValue = 0, resourceIdList = [], skipVtime = False, eventPass=True, multiRequestBuild=None):
        # Get function name
        funcName = QAUTILS.getFunctionName()
    
        return deleteTask(V3inst, resourceIdList, funcName, eventPass)

#=============================================================
def devicePurchaseOfferInFuture(V3inst, queryValue, offerId=None, purchaseStartTime=None, offerStartTime=None,
                      offerEndTime=None, eventPass=True, queryType='PhoneNumber', now=None,
                      offerIsExternal=False, offerId2=None, attr=None,  skipVtime=False, dupAttr=True,
                      catalogItemId=None, multiRequestBuild=None):
 
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Get OID if queryType is not ObjectId
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass)
        queryValue = getOID(queryResponse)
 
    profTemplate = devicePurchaseOffer(V3inst, queryValue, offerId=offerId, catalogItemId=catalogItemId,
                                    offerStartTime=offerStartTime, offerEndTime=offerEndTime, eventPass=eventPass,
                                    queryType='ObjectId', now=now, offerIsExternal=offerIsExternal, attr=attr,
                                    dupAttr=dupAttr, future=True)
    profTemplate = RESTHELPER.addTask(purchaseStartTime,profTemplate)  

    url = '/json'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + str(profTemplate))
        
    response = V3inst.post(url, payload=profTemplate)
    #print 'response=',response
    
    (success, objectId) = validateResponse(response=response, method=funcName , shouldPass=eventPass, returnParam='ObjectId')
    #print 'Future device purchase ObjectId = ' + str(objectId)
    return objectId

#=============================================================
def deviceCancelOfferInFuture(V3inst, cancelStartTime, queryType = 'PhoneNumber', queryValue = 0, resourceIdList = [], skipVtime = False, eventPass=True, multiRequestBuild=None):
        # Get function name
        funcName = QAUTILS.getFunctionName()
    
        return deleteTask(V3inst, resourceIdList[1], funcName, eventPass)

#=============================================================
def deleteTask(V3inst, taskId, fcn, eventPass=True, multiRequestBuild=None):
        # Get function name
        funcName = QAUTILS.getFunctionName()
    
        # Get task cancel 
        profTemplate = open(templates + 'task_delete.json').read()

        # Always have an object ID for task deletion
        profTemplate = RESTHELPER.checkIfDefined(taskId, None, 'OBJID', profTemplate, 'ObjectId')
    
        url = '/json'
    
        # Debug output if globally set
        if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + str(profTemplate))
        
        response = V3inst.post(url, payload=profTemplate)
        #print 'deleteTask response = ' + response
        return validateResponse(response=response, method=fcn, shouldPass=eventPass)

#=============================================================
def multiRequest(V3inst, requests=None, now=None, eventPass=True, routingType=None, routingValue=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    requestMdc = MDCDEFS.kMtxRequestMultiMdcDesc.create()
    if now != None:
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestEventTimeFldKey, now)
    requestMdc.setUsingKey(
        MDCDEFS.kMtxRequestMultiRequestListFldKey, requests)
    requestXml = requestMdc.printElementBasedXml(indentStr='  ')

    f = open("/tmp/myMultiRequest.xml", "w")
    f.write(requestXml)
    f.close()
    cmd = 'java -jar /opt/mtx/bin/converter.jar -config:/opt/mtx/data/mdc_config_system.xml -json -in:xml /tmp/myMultiRequest.xml'
    payload=QAUTILS.runCmd(cmd)
    QAUTILS.runCmd('rm -rf /tmp/myMultiRequest.xml')

    if routingType and routingValue :
        url = '/json?TrafficRouteData='+routingType + str(routingValue)
    else:
        url = '/json'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + str(payload))
        
    response = V3inst.post(url, payload=payload)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    #print response
    return validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='ObjectId')

#=============================================================
def multiRequestSaveResponse(V3inst, requests, now=None, eventPass=True, routingType=None, routingValue=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    requestMdc = MDCDEFS.kMtxRequestMultiMdcDesc.create()
    if now != None:
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestEventTimeFldKey, now)
    requestMdc.setUsingKey(
        MDCDEFS.kMtxRequestMultiRequestListFldKey, requests)
    requestXml = requestMdc.printElementBasedXml(indentStr='  ')

    f = open("/tmp/myMultiRequest.xml", "w")
    f.write(requestXml)
    f.close()
    cmd = 'java -jar /opt/mtx/bin/converter.jar -config:/opt/mtx/conf/mtx_config.xml -json -in:xml /tmp/myMultiRequest.xml'
    payload=QAUTILS.runCmd(cmd)

    QAUTILS.runCmd('rm -rf /tmp/myMultiRequest.xml')
    if routingType and routingValue :
        url = '/json?TrafficRouteData='+routingType + str(routingValue)
    else:
        url = '/json'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + str(payload))
        
    response = V3inst.post(url, payload=payload)
    #print response
    return (validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='ObjectId'), response)

#============================================================
def querySubscriberEvent(V3inst, queryValue, queryType='ExternalId', deviceQueryType=None, deviceQueryValue=None,
    querySize=None, queryCursor=None, eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypeStringArray =None, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Some parameters should be lists of strings
    if eventTypeStringArray:
        if type(eventTypeStringArray) is list:  eventTypeStringArray = [str(i) for i in eventTypeStringArray]
        else:                                   eventTypeStringArray = [str(eventTypeStringArray)]
    
    # Translate subscriber to OID if needed
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)
        if not eventPass and queryValue is None : 
            queryValue = "9-9-9-9"

    # Translate device to OID if needed
    if deviceQueryType and deviceQueryValue and deviceQueryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=deviceQueryValue, queryType=deviceQueryType, now=now)
        deviceQueryValue = getOID(queryResponse)

    # Assume optional parameters in the URL
    amp = False
    delim = '?'
    # Build the URL
    url = '/json/'+RESTV3.subUrl+'/' + queryValue + '/events'
    if deviceQueryValue: url += '/' + deviceQueryValue

    if querySize is not None:
        url += delim + 'querySize=' + str(querySize)
        amp = True
        delim = '&'
    if queryCursor is not None:
        url += delim + 'queryCursor=' + str(queryCursor)
        amp = True
        delim = '&'
    if eventTimeLowerBound is not None:
        url += delim + 'eventTimeLowerBound=' + convertTimeToUrlFormat(eventTimeLowerBound)
        amp = True
        delim = '&'
    if eventTimeUpperBound is not None:
        url += delim + 'eventTimeUpperBound=' + convertTimeToUrlFormat(eventTimeUpperBound)
        amp = True
        delim = '&'
    if eventTypeStringArray is not None:
        url += delim + 'eventTypes=' + ",".join(eventTypeStringArray)
        amp = True
        delim = '&'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    # Make the REST call
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    (result, cursor) = validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='QueryCursor')
    if result : return (response,cursor)
    
#=============================================================
# No device event store query.  Map to device event query (nothing better to do except fail...).
def queryDeviceEventstore(V3inst, queryValue, queryType='ExternalId', resultSize=None,
    eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypes=None, notificationTypes=None, notification=False,
    now=None, eventPass=True, multiRequestBuild=None):
        # Call device event API
        (response, cursor) = queryDeviceEvent(V3inst, queryValue, queryType=queryType, querySize=resultSize, queryCursor = None,
                eventTimeLowerBound=eventTimeLowerBound, eventTimeUpperBound=eventTimeUpperBound, eventTypeStringArray=eventTypes,
                now=now, eventPass=eventPass)
    
        return response
#=============================================================
def querySubscriberEventstore(V3inst, queryValue=None, queryType='ExternalId', resultSize=None, deviceQueryType=None, deviceQueryValue=None,
    eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypes=None, notificationTypes=None, notification=False,searchInMemoryDatabase=True,
    applyDefaultFilter=True, routingType=None, routingValue=None, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    # Some parameters should be lists of strings
    if eventTypes:
        if type(eventTypes) is list:    eventTypes = [str(i) for i in eventTypes]
        else:                           eventTypes = [str(eventTypes)]
    if notificationTypes:
        if type(notificationTypes) is list:     notificationTypes = [str(i) for i in notificationTypes]
        else:                                   notificationTypes = [str(notificationTypes)]

    if deviceQueryType and deviceQueryValue:
        if deviceQueryType in ['ObjectId', 'ExternalId']:
            print('WARNING: ' + funcName + ': Current code doesns\';t handle device information passed in other than AccessNumber or PhoneNumber.')

            if not (queryValue and queryType): sys.exit('ERROR: Either queryValue or queryType is not set so can\'t use subscriber infor for this call')
        else:
            queryType = deviceQueryType
            queryValue = deviceQueryValue

    # Assume optional parameters in the URL
    amp = False
    delim = '?'
    # Build the URL
    if notification:
        url = '/json/eventstore/notification/subscriber/' + str(queryType) + '+' + str(queryValue)
    else:
        url = '/json/eventstore/subscriber/' + str(queryType) + '+' + str(queryValue)

    if resultSize is not None:
        url += delim + 'resultSize=' + str(resultSize)
        amp = True
        delim = '&'
    if eventTypes is not None:
        url += delim + 'eventTypes=' + ",".join(eventTypes)
        amp = True
        delim = '&'
    if notificationTypes is not None:
        url += delim + 'notificationTypes=' + ",".join(notificationTypes)
        amp = True
        delim = '&' 
    if eventTimeLowerBound is not None:
        url += delim + 'eventTimeLowerBound=' + convertTimeToUrlFormat(eventTimeLowerBound)
        amp = True
        delim = '&'
    if eventTimeUpperBound is not None:
        url += delim + 'eventTimeUpperBound=' + convertTimeToUrlFormat(eventTimeUpperBound)
        amp = True
        delim = '&'
    if not applyDefaultFilter:
        url += delim + 'applyDefaultFilter=false'
        amp = True
        delim = '&'
    if not searchInMemoryDatabase:
        url += delim + 'searchInMemoryDatabase=false'
        amp = True
        delim = '&' 
    if routingType and routingValue :
        url += delim + 'TrafficRouteData=' + str(routingType) + str(routingValue)
        amp = True
        delim = '&'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    # Make the REST call
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    result = validateResponse(response=response, method=funcName, shouldPass=eventPass)
    if result : return response

#=============================================================
def queryGroupEvent(V3inst, queryValue, queryType='ExternalId', querySize=None, queryCursor = None,
    eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypeStringArray=None, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Some parameters should be lists of strings
    if eventTypeStringArray:
        if type(eventTypeStringArray) is list:  eventTypeStringArray = [str(i) for i in eventTypeStringArray]
        else:                                   eventTypeStringArray = [str(eventTypeStringArray)]
    
    # Translate subscriber to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)
    
    # Assume optional parameters in the URL
    amp = False
    delim = '?'
    
    if not eventPass : queryValue = "9-9-9-9"
    # Build the URL
    url = '/json/group/' + queryValue + '/events'
    if querySize is not None:
        url += delim + 'querySize=' + str(querySize)
        amp = True
        delim = '&'
    if queryCursor is not None:
        url += delim + 'queryCursor=' + str(queryCursor)
        amp = True
        delim = '&'
    if eventTimeLowerBound is not None:
        url += delim + 'eventTimeLowerBound=' + convertTimeToUrlFormat(eventTimeLowerBound)
        amp = True
        delim = '&'
    if eventTimeUpperBound is not None:
        url += delim + 'eventTimeUpperBound=' + convertTimeToUrlFormat(eventTimeUpperBound)
        amp = True
        delim = '&'
    if eventTypeStringArray is not None:
        url += delim + 'eventTypes=' + ",".join(eventTypeStringArray)
        amp = True
        delim = '&'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    # Make the REST call
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    (result, cursor) =  validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='QueryCursor')
    if result: return (response, cursor)
    
#=============================================================
def queryGroupEventstore(V3inst, queryValue, queryType='ExternalId', resultSize=None,
    eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypes=None, notificationTypes=None, notification=False,searchInMemoryDatabase=True,
    applyDefaultFilter=True, routingType=None, routingValue=None, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Some parameters should be lists of strings
    if eventTypes:
        if type(eventTypes) is list:    eventTypes = [str(i) for i in eventTypes]
        else:                           eventTypes = [str(eventTypes)]
    if notificationTypes:
        if type(notificationTypes) is list:     notificationTypes = [str(i) for i in notificationTypes]
        else:                                   notificationTypes = [str(notificationTypes)]
    
    # Translate subscriber to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)

    # Assume optional parameters in the URL
    amp = False
    delim = '?'

    if not eventPass : queryValue = "9-9-9-9"
    # Build the URL
    if notification:
        url = '/json/eventstore/notification/group/' + queryValue
    else:
        url = '/json/eventstore/group/' + queryValue

    if resultSize is not None:
        url += delim + 'resultSize=' + str(resultSize)
        amp = True
        delim = '&'
    if eventTypes is not None:
        url += delim + 'eventTypes=' +  ",".join(eventTypes)
        amp = True
        delim = '&'
    if notificationTypes is not None:
        url += delim + 'notificationTypes=' +  ",".join(notificationTypes)
        amp = True
        delim = '&'
    if eventTimeLowerBound is not None:
        url += delim + 'eventTimeLowerBound=' + convertTimeToUrlFormat(eventTimeLowerBound)
        amp = True
        delim = '&'
    if eventTimeUpperBound is not None:
        url += delim + 'eventTimeUpperBound=' + convertTimeToUrlFormat(eventTimeUpperBound)
        amp = True
        delim = '&'
    if not applyDefaultFilter:
        url += delim + 'applyDefaultFilter=false'
        amp = True
        delim = '&'
    if not searchInMemoryDatabase:
        url += delim + 'searchInMemoryDatabase=false'
        amp = True
        delim = '&'
    if routingType and routingValue :
        url += delim + 'TrafficRouteData=' + str(routingType) + str(routingValue)
        amp = True
        delim = '&'


    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    # Make the REST call
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    
    result =  validateResponse(response=response, method=funcName, shouldPass=eventPass)
    if result: return response

#=============================================================
def queryEventstore(V3inst,  resultSize=None, eventTimeLowerBound=None, eventTimeUpperBound=None, applyDefaultFilter=True, routingType=None,searchInMemoryDatabase=True,
                    routingValue=None, eventTypes=None,now=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Some parameters should be lists of strings
    if eventTypes:
        if type(eventTypes) is list:    eventTypes = [str(i) for i in eventTypes]
        else:                           eventTypes = [str(eventTypes)]
    
    # Assume optional parameters in the URL
    amp = False
    delim = '?'
    
    url = '/json/eventstore/query'

    if resultSize is not None:
        url += delim + 'resultSize=' + str(resultSize)
        amp = True
        delim = '&'
    if eventTypes is not None:
        url += delim + 'eventTypes=' + ",".join(eventTypes)
        amp = True
        delim = '&'
    if eventTimeLowerBound is not None:
        url += delim + 'eventTimeLowerBound=' + convertTimeToUrlFormat(eventTimeLowerBound)
        amp = True
        delim = '&'
    if eventTimeUpperBound is not None:
        url += delim + 'eventTimeUpperBound=' + convertTimeToUrlFormat(eventTimeUpperBound)
        amp = True
        delim = '&'
    if not applyDefaultFilter:
        url += delim + 'applyDefaultFilter=false'
        amp = True
        delim = '&'
    if not searchInMemoryDatabase:
        url += delim + 'searchInMemoryDatabase=false'
        amp = True
        delim = '&'
    if routingType and routingValue :
        url += delim + 'TrafficRouteData=' + str(routingType) + str(routingValue)
        amp = True
        delim = '&'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    # Make the REST call
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    result =  validateResponse(response=response, method=funcName, shouldPass=eventPass)
    if result: return response

#============================================================
def querySubDomains(V3inst, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/json/service/subDomains'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    # Make the REST call
    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return response

#=============================================================
def serviceGroupQuery(V3inst, queryValue, queryType='ObjectId', querySize=None, queryCursor=None, returnType=None,
                      now=None, eventPass=True, multiRequestBuild=None):
    funcName = QAUTILS.getFunctionName() + str(returnType).capitalize()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)

    url = '/json/service/group/' + str(queryValue)
    if returnType in ['administrators', 'subgroups', 'subscribers']:
        url += '/' + str(returnType)

        # Assume optional parameters in the URL
        amp = False
        delim = '?'

        if querySize is not None:
            url += delim + 'querySize=' + str(querySize)
            amp = True
            delim = '&'
        if queryCursor is not None:
            url += delim + 'queryCursor=' + str(queryCursor)
            amp = True
            delim = '&'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    # Make the REST call
    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return response

#=============================================================
def serviceGroupAddRemoveMembers(V3inst, queryValue, queryType='ObjectId', subscribers=None, administrators=None, groups=None,
       addRemove='add', now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)

    subscriberStr = ''
    groupStr = ''
    administratorStr = ''

    if type(subscribers) is list:
        for value in subscribers:
            subscriberStr += str(value) + ','
    elif subscribers:
        subscriberStr = subscribers

    if type(groups) is list:
        for value in groups:
            groupStr += str(value) + ','
    elif groups:
        groupStr = groups

    if type(administrators) is list:
        for value in administrators:
            administratorStr += str(value) + ','
    elif administrators:
        administratorStr = administrators

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'manage_group_membership.json').read()
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(subscriberStr, '', 'SUBSCRIBERS', profTemplate, 'SubscriberArray')
    profTemplate = RESTHELPER.checkIfDefined(groupStr, '', 'GROUPS', profTemplate, 'GroupArray')
    profTemplate = RESTHELPER.checkIfDefined(administratorStr, '', 'ADMINISTRATORS', profTemplate, 'AdministratorArray')

    url = '/json/service/group/' + str(queryValue)
    if addRemove =='remove':
        url += '/remove_members'
    else:
        url += '/add_members'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if not validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return False

    return True

#=============================================================
def serviceGroupQueryMemberBalance(V3inst, queryValue, queryType='ObjectId', resourceId=None, now=None, eventPass=True, querySize=None, memberCursor=None, subGroupCursor=None, multiRequestBuild=None):

    funcName = QAUTILS.getFunctionName()

    url = '/json/service/group/' + str(queryType) + '+' + str(queryValue) + '/memberbalance/' + str(resourceId)

    delim = '?'
    if querySize is not None:
        url += delim + 'querySize=' + str(querySize)
        delim = '&'
    if memberCursor is not None:
        url += delim + 'subscriptionCursor=' + str(memberCursor)
        delim = '&'
    if subGroupCursor is not None:
        url += delim + 'subGroupCursor=' + str(subGroupCursor)
        delim = '&'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    # Make the REST call
    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return response

#=============================================================
def serviceSubscriptionQueryGroups(V3inst, queryValue, queryType='ObjectId', now=None, eventPass=True,
                                  querySize=None, queryCursor=None, multiRequestBuild=None):

    funcName = QAUTILS.getFunctionName()

    url = '/json/service/subscription/' + str(queryType) + '+' + str(queryValue) + '/groups'

    delim = '?'

    if querySize is not None:
        url += delim + 'querySize=' + str(querySize)
        delim = '&'
        amp=True
    if queryCursor is not None:
        url += delim + 'queryCursor=' + str(queryCursor)
        amp=True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    # Make the REST call
    response = V3inst.get(url, amp=amp, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    (result, cursor) =  validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='QueryCursor')
    if result: return (response, cursor)

#============================================================
def serviceQuerySubscription(V3inst, queryValue, queryType='ObjectId', now=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/json/service/subscription/' + str(queryType) + '+' + str(queryValue)
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    # Make the REST call
    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return response

#============================================================
def serviceQueryDevice(V3inst, queryValue, queryType='ObjectId', now=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/json/service/device/' + str(queryType) + '+' + str(queryValue)
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    # Make the REST call
    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return response


#============================================================
def convertTimeToUrlFormat(timeData):
        #print 'timeData: ' + timeData
        usec = '.000000'
        
        # Input may not contain usec, which this function expects
        if not timeData.count('.'):
                # Add before timezone information
                for key in ['+', '-']:
                        if timeData[-6] == key: timeData = timeData[:-6] + usec + timeData[-6:]
                if timeData[-1].lower() == 'z': timeData = timeData[:-1] + usec + timeData[-1]
                
        # Change colon to URL equivalent characters and split time from remainder (msec + tzone)
        timeData = timeData.replace(":", "%3A").split(".")
        
        # Get time part
        timeString = timeData[0]
        
        # Add time zone if included (looking at remainder of input).
        # URL encode the +/- character.
        tzone = timeData[1].split('+')
        if len(tzone) > 1: timeString += '%2B' + tzone[1]
        tzone = timeData[1].split('-')
        if len(tzone) > 1: timeString += '%2D' + tzone[1]
        
        #print 'timeString: ' + timeString
        return timeString
        
#============================================================
def queryDeviceEvent(V3inst, queryValue, queryType='ExternalId', querySize=None, queryCursor = None,
    eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypeStringArray=None, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Some parameters should be lists of strings
    if eventTypeStringArray:
        if type(eventTypeStringArray) is list:  eventTypeStringArray = [str(i) for i in eventTypeStringArray]
        else:                                   cweventTypeStringArrayeventTypes = [str(eventTypeStringArray)]
    
    # Translate subscriber to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)
        if not eventPass and queryValue is None : 
            queryValue = "9-9-9-9"

    # Default optional parameters not in the URL
    amp = False
    delim = '?'
    # Build the URL
    url = '/json/device/' + queryValue + '/events'
    
    if querySize is not None:
        url += delim + 'querySize=' + str(querySize)
        amp = True
        delim = '&'
    if queryCursor is not None:
        url += delim + 'queryCursor=' + str(queryCursor)
        amp = True
        delim = '&'
    if eventTypeStringArray is not None:
        url += delim + 'eventTypes=' + ",".join(eventTypeStringArray)
        amp = True
        delim = '&'
    if eventTimeLowerBound is not None:
        url += delim + 'eventTimeLowerBound=' + convertTimeToUrlFormat(eventTimeLowerBound)
        amp = True
        delim = '&'
    if eventTimeUpperBound is not None:
        url += delim + 'eventTimeUpperBound=' + convertTimeToUrlFormat(eventTimeUpperBound)
        amp = True
        delim = '&'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    # Make the REST call
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    (result, cursor) = validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='queryCursor')
    if result : return (response,cursor)
    
#=============================================================
def queryDeviceAggregation(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Translate subscriber to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)
        if queryValue is None : queryValue = '9-9-9-9'

    # Build the URL
    url = '/json/device/' + queryValue + '/aggregation'
   
    # Make the REST call
    response = V3inst.get(url, time=now, amp=False)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method='queryDeviceAggregation', shouldPass=eventPass): return response

#=============================================================
def querySubscriberAggregation(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Translate subscriber to OID if needed
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)
        if queryValue is None : queryValue = '9-9-9-9'

    # Build the URL
    url = '/json/'+RESTV3.subUrl+'/' + queryValue + '/aggregation'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    # Make the REST call
    response = V3inst.get(url, time=now, amp=False)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method=funcName, shouldPass=eventPass): return response

#=============================================================
def eventQuery(V3inst, queryValue, queryType = 'EventId', eventPass=True, now=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    url = '/json/event/query/EventId/'+queryValue
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.get(url  , time=now, amp=False)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def queryDeviceSession(V3inst, queryValue, queryType='Imsi', eventPass=True, now=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Translate device to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)
        if queryValue is None : queryValue = '0-1-5-999'

    # Build the URL
    url = '/json/device/' + queryValue + '/session'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    # Make the REST call
    response = V3inst.get(url, time=now, amp=False)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method=funcName, shouldPass=eventPass): return response

#=============================================================
def validateDeviceSession(V3inst, queryValue, queryType='Imsi', sessionId=None, sessionType=None, eventPass=True, now=None, multiRequestBuild=None):
    global templates
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Translate device to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)
        if queryValue is None : queryValue = '0-1-5-999'
    
    # Define base URL string
    url = '/json/device/' + queryValue + '/session/validate'
    
    # Adjust session ID if only numbers passed in
    if sessionId is not None and sessionId.isdigit():
        # Need proper session prefix.  Usually nothing specified or Gy, so check that first.  Gy also a catch-all for invalid values.
        if not sessionType or sessionType == '1': sessionId = cd.GySessionIdPrefix + sessionId
        elif sessionType == '2':                  sessionId = cd.SySessionIdPrefix + sessionId
        elif sessionType == '3':                  sessionId = cd.GxSessionIdPrefix + sessionId
        else:
                print('WARNNING:  validateDeviceSession() invalid value passed in for sessionType: ' + str(sessionType) + '.  Defaulting to Gy.')
                sessionId = cd.GySessionIdPrefix + sessionId

    # Add rest of URL - mutually exclusive parameters
    if   sessionId is not None:         url += '?sessionId=' + str(sessionId)
    elif sessionType is not None :      url += '?sessionType=' + str(sessionType)
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.post(url, payload=None)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)


#=============================================================
def deviceEvaluateSyPolicy(V3inst, queryValue ,queryType='Imsi',  now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Translate device to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)
        if queryValue is None : queryValue = '0-1-5-999'

    # Build the URL
    url = '/json/device/' + queryValue + '/policycounter'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    # Make the REST call
    response = V3inst.get(url, time=now, amp=False)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method=funcName, shouldPass=eventPass): return response

#=============================================================
def deleteDeviceSession(V3inst, queryValue, queryType='Imsi', sessionIdList=None, sessionType=None, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Translate device to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)
        if queryValue is None : queryValue = '0-1-5-999'

    # Define base URL string
    url = '/json/device/' + queryValue + '/session'
    
    # NOTE:  need to support multiple session IDs (need REST syntax)
    sessionId = "" 
    #check if session is list, parse the session and add & to each session Id
    #the url will be like /json/device/1-2-3-4/session?sessionId=X&sessionId=Y&sessionId=Z
    if type(sessionIdList) is list: 
      #skip to add sessionId= to the first element
      sessionId += str(sessionIdList[0]) +'&'
      for i in sessionIdList[1:]:
             sessionId += 'sessionId='+str(i) +'&'
      #trim the extra & at the end
      sessionId = sessionId.rstrip('&')
    else:
      sessionId = sessionIdList
  
    # Adjust session ID if only numbers passed in
    if sessionId is not None and sessionId.isdigit():
        # Need proper session prefix.  Usually nothing specified or Gy, so check that first.  Gy also a catch-all for invalid values.
        if not sessionType or sessionType == '1': sessionId = cd.GySessionIdPrefix + sessionId
        elif sessionType == '2':                  sessionId = cd.SySessionIdPrefix + sessionId
        elif sessionType == '3':                  sessionId = cd.GxSessionIdPrefix + sessionId
        else:
                print('WARNNING:  deleteDeviceSession() invalid value passed in for sessionType: ' + str(sessionType) + '.  Defaulting to Gy.')
                sessionId = cd.GySessionIdPrefix + sessionId

    # Add rest of URL - mutually exclusive parameters
    if sessionId is not None :          url += '?sessionId='+str(sessionId)
    elif sessionType is not None :      url += '?sessionType='+str(sessionType)
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.delete(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method=funcName, shouldPass=eventPass): return response

#=============================================================
def queryNotificationProfile(V3inst, queryType='NotifictionProfileId', queryValue = None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    url = '/json/pricing/notificationProfile/' + str(queryValue)
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def pricingCacheBalanceTemplates(V3inst, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    url = '/json/pricing/cache/balance'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def pricingCacheBalanceId(V3inst, balanceId = None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    url = '/json/pricing/cache/balance/' + str(balanceId)
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def customURLCall(V3inst, url, payload=None, operation='get', eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ':')
        print('url: ' + url)
        print('operation: ' + operation)
        print('payload: ' + str(payload))

    # Build the command start
    cmd = 'response = V3inst.' + operation.lower() + '(url'

    # Add payload if specified
    if payload: cmd += ', payload=payload'

    # Close the command
    cmd += ')'

    # Execute the command
    exec(cmd)

    # Debug output
    if QAUTILS.DebugLevel > 0: print(funcName + 'response: ' + response)

    # Return response
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def queryEventStreamingSessionList(V3inst, routingType = None, routingValue = None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()


    url = '/json/stream_info'
    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType+str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        sessionIdList = getEventStreamingSessionIdList(response)
        return (response, sessionIdList)

#=============================================================
def queryEventStreamingSession(V3inst, queryValue, routingType = None, routingValue = None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/json/stream_info/' + queryValue
    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType+str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        sessionId = getEventStreamingSessionId(response)
        streamCursor = getEventStreamingSessionCursor(response)
        return (response, sessionId, streamCursor)

#=============================================================
def createEventStreamingSession(V3inst, sessionId, streamCursor = None, routingType = None, routingValue = None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/json/stream_info/' + sessionId
    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType+str(routingValue)


    profTemplate = open(templates + 'event_streaming_create_session.json').read()
    profTemplate = RESTHELPER.checkIfDefined(streamCursor, None, 'STREAMCURSOR', profTemplate, 'StreamCursor')


    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)


    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def modifyEventStreamingSession(V3inst, queryValue, streamCursor, routingType = None, routingValue = None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/json/stream_info/'+queryValue
    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType+str(routingValue)


    profTemplate = open(templates + 'event_streaming_modify_session.json').read()
    profTemplate = RESTHELPER.checkIfDefined(streamCursor, None, 'STREAMCURSOR', profTemplate, 'StreamCursor')


    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)


    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def deleteEventStreamingSession(V3inst, sessionId, routingType = None, routingValue = None,  eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/json/stream_info/' + sessionId
    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType+sessionId

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberMakeFinanceContractPrincipalPayment(V3inst, queryValue, offerResourceId, queryType = 'ExternalId',
    isPayoff=True, extraPrincipalAmount=None, paymentMethodResourceId=None, chargeMethod=None,
    paymentGatewayId=None, nonce=None, chargeMethodAttr=None, reason=None, info=None, apiEventData=None, now=None, eventPass=True, multiRequestBuild=None):
    #Get function Name
    funcName = QAUTILS.getFunctionName()

    # Translate subscriber to OID if needed
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates  + 'subscriber_additional_principal_payment.json').read()

    profTemplate = RESTHELPER.checkIfDefined(offerResourceId, None, 'RESOURCEID', profTemplate, 'ResourceId')
    profTemplate = RESTHELPER.checkIfDefined(isPayoff, None, 'ISPAYOFF', profTemplate, 'IsPayoff')
    profTemplate = RESTHELPER.checkIfDefined(extraPrincipalAmount, None, 'EXTRAPRINCIPALAMOUNT', profTemplate, 'ExtraPrincipalAmount')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    if chargeMethod or paymentMethodResourceId or paymentGatewayId or nonce or chargeMethodAttr:
        chargeMethodData = open(templates + 'charge_method_data.json').read()
        chargeMethodData = RESTHELPER.checkIfDefined(chargeMethod, None, 'CHARGEMETHOD', chargeMethodData, 'ChargeMethod')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', chargeMethodData, 'PaymentMethodResourceId')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayId, None, 'PAYMENTGATEWAYID', chargeMethodData, 'PaymentGatewayId')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'PAYMENTGATEWAYUSERID', chargeMethodData, 'PaymentGatewayUserId')
        chargeMethodData = RESTHELPER.checkIfDefined(nonce, None, 'PAYMENTGATEWAYONETIMETOKEN', chargeMethodData, 'PaymentGatewayOneTimeToken')
        chargeMethodData = RESTHELPER.checkIfDefined(chargeMethodAttr, None, 'ATTR', chargeMethodData, 'ChargeMethodAttr')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDSETTLEMENT', chargeMethodData, 'DeferredSettlement')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDSETTLEMENTTIMEOUT', chargeMethodData, 'DeferredSettlementTimeout')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDsETTLEMENTtIMEOUTACTION', chargeMethodData, 'DeferredSettlementTimeoutAction')
    else:
        chargeMethodData = None
    profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')


    url = '/json/'+RESTV3.subUrl+'/' + str(queryValue) + '/contract/' + str(offerResourceId) + '/payment'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)


    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupMakeFinanceContractPrincipalPayment(V3inst, queryValue, offerResourceId, queryType = 'ExternalId',
    isPayoff=True, extraPrincipalAmount=None, paymentMethodResourceId=None, chargeMethod=None,
    paymentGatewayId=None, nonce=None, chargeMethodAttr=None, reason=None, info=None, apiEventData=None, now=None, eventPass=True, multiRequestBuild=None):
    #Get function Name
    funcName = QAUTILS.getFunctionName()

    # Translate group to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates  + 'group_additional_principal_payment.json').read()

    profTemplate = RESTHELPER.checkIfDefined(offerResourceId, None, 'RESOURCEID', profTemplate, 'ResourceId')
    profTemplate = RESTHELPER.checkIfDefined(isPayoff, None, 'ISPAYOFF', profTemplate, 'IsPayoff')
    profTemplate = RESTHELPER.checkIfDefined(extraPrincipalAmount, None, 'EXTRAPRINCIPALAMOUNT', profTemplate, 'ExtraPrincipalAmount')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    if chargeMethod or paymentMethodResourceId or paymentGatewayId or nonce or chargeMethodAttr:
        chargeMethodData = open(templates + 'charge_method_data.json').read()
        chargeMethodData = RESTHELPER.checkIfDefined(chargeMethod, None, 'CHARGEMETHOD', chargeMethodData, 'ChargeMethod')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', chargeMethodData, 'PaymentMethodResourceId')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayId, None, 'PAYMENTGATEWAYID', chargeMethodData, 'PaymentGatewayId')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'PAYMENTGATEWAYUSERID', chargeMethodData, 'PaymentGatewayUserId')
        chargeMethodData = RESTHELPER.checkIfDefined(nonce, None, 'PAYMENTGATEWAYONETIMETOKEN', chargeMethodData, 'PaymentGatewayOneTimeToken')
        chargeMethodData = RESTHELPER.checkIfDefined(chargeMethodAttr, None, 'ATTR', chargeMethodData, 'ChargeMethodAttr')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDSETTLEMENT', chargeMethodData, 'DeferredSettlement')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDSETTLEMENTTIMEOUT', chargeMethodData, 'DeferredSettlementTimeout')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDsETTLEMENTtIMEOUTACTION', chargeMethodData, 'DeferredSettlementTimeoutAction')
    else:
        chargeMethodData = None
    profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')


    url = '/json/group/' + str(queryValue) + '/contract/' + str(offerResourceId) + '/payment'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)


    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def subscriberContractDebtPayment(V3inst, queryValue, offerResourceId, amount, queryType = 'ExternalId', paymentMethodResourceId=None, chargeMethod=None,
    paymentGatewayId=None, nonce=None, chargeMethodAttr=None, reason=None, info=None, now=None, apiEventData=None, eventPass=True, multiRequestBuild=None):
    #Get function Name
    funcName = QAUTILS.getFunctionName()

    # Translate subscriber to OID if needed
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates  + 'subscriber_contract_debt_payment.json').read()

    profTemplate = RESTHELPER.checkIfDefined(offerResourceId, None, 'RESOURCEID', profTemplate, 'ResourceId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'IsPayoff')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    if chargeMethod or paymentMethodResourceId or paymentGatewayId or nonce or chargeMethodAttr:
        chargeMethodData = open(templates + 'charge_method_data.json').read()
        chargeMethodData = RESTHELPER.checkIfDefined(chargeMethod, None, 'CHARGEMETHOD', chargeMethodData, 'ChargeMethod')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', chargeMethodData, 'PaymentMethodResourceId')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayId, None, 'PAYMENTGATEWAYID', chargeMethodData, 'PaymentGatewayId')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'PAYMENTGATEWAYUSERID', chargeMethodData, 'PaymentGatewayUserId')
        chargeMethodData = RESTHELPER.checkIfDefined(nonce, None, 'PAYMENTGATEWAYONETIMETOKEN', chargeMethodData, 'PaymentGatewayOneTimeToken')
        chargeMethodData = RESTHELPER.checkIfDefined(chargeMethodAttr, None, 'ATTR', chargeMethodData, 'ChargeMethodAttr')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDSETTLEMENT', chargeMethodData, 'DeferredSettlement')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDSETTLEMENTTIMEOUT', chargeMethodData, 'DeferredSettlementTimeout')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDsETTLEMENTtIMEOUTACTION', chargeMethodData, 'DeferredSettlementTimeoutAction')
    else:
        chargeMethodData = None
    profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')


    url = '/json/'+RESTV3.subUrl+'/' + str(queryValue) + '/contract/' + str(offerResourceId) + '/debt_payment'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)


    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def deviceContractDebtPayment(V3inst, queryValue, offerResourceId, amount, queryType = 'ExternalId', paymentMethodResourceId=None, chargeMethod=None,
    paymentGatewayId=None, nonce=None, chargeMethodAttr=None, reason=None, info=None, apiEventData=None, now=None, eventPass=True, multiRequestBuild=None):
    #Get function Name
    funcName = QAUTILS.getFunctionName()

    # Translate device to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates  + 'device_contract_debt_payment.json').read()

    profTemplate = RESTHELPER.checkIfDefined(offerResourceId, None, 'RESOURCEID', profTemplate, 'ResourceId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'IsPayoff')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    if chargeMethod or paymentMethodResourceId or paymentGatewayId or nonce or chargeMethodAttr:
        chargeMethodData = open(templates + 'charge_method_data.json').read()
        chargeMethodData = RESTHELPER.checkIfDefined(chargeMethod, None, 'CHARGEMETHOD', chargeMethodData, 'ChargeMethod')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', chargeMethodData, 'PaymentMethodResourceId')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayId, None, 'PAYMENTGATEWAYID', chargeMethodData, 'PaymentGatewayId')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'PAYMENTGATEWAYUSERID', chargeMethodData, 'PaymentGatewayUserId')
        chargeMethodData = RESTHELPER.checkIfDefined(nonce, None, 'PAYMENTGATEWAYONETIMETOKEN', chargeMethodData, 'PaymentGatewayOneTimeToken')
        chargeMethodData = RESTHELPER.checkIfDefined(chargeMethodAttr, None, 'ATTR', chargeMethodData, 'ChargeMethodAttr')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDSETTLEMENT', chargeMethodData, 'DeferredSettlement')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDSETTLEMENTTIMEOUT', chargeMethodData, 'DeferredSettlementTimeout')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDsETTLEMENTtIMEOUTACTION', chargeMethodData, 'DeferredSettlementTimeoutAction')
    else:
        chargeMethodData = None
    profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')


    url = '/json/device/' + str(queryValue) + '/contract/' + str(offerResourceId) + '/debt_payment'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)


    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupContractDebtPayment(V3inst, queryValue, offerResourceId, amount, queryType = 'ExternalId', paymentMethodResourceId=None, chargeMethod=None,
    paymentGatewayId=None, nonce=None, chargeMethodAttr=None, reason=None, info=None, apiEventData=None, now=None, eventPass=True, multiRequestBuild=None):
    #Get function Name
    funcName = QAUTILS.getFunctionName()

    # Translate group to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates  + 'group_contract_debt_payment.json').read()

    profTemplate = RESTHELPER.checkIfDefined(offerResourceId, None, 'RESOURCEID', profTemplate, 'ResourceId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'IsPayoff')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    if chargeMethod or paymentMethodResourceId or paymentGatewayId or nonce or chargeMethodAttr:
        chargeMethodData = open(templates + 'charge_method_data.json').read()
        chargeMethodData = RESTHELPER.checkIfDefined(chargeMethod, None, 'CHARGEMETHOD', chargeMethodData, 'ChargeMethod')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', chargeMethodData, 'PaymentMethodResourceId')
        chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayId, None, 'PAYMENTGATEWAYID', chargeMethodData, 'PaymentGatewayId')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'PAYMENTGATEWAYUSERID', chargeMethodData, 'PaymentGatewayUserId')
        chargeMethodData = RESTHELPER.checkIfDefined(nonce, None, 'PAYMENTGATEWAYONETIMETOKEN', chargeMethodData, 'PaymentGatewayOneTimeToken')
        chargeMethodData = RESTHELPER.checkIfDefined(chargeMethodAttr, None, 'ATTR', chargeMethodData, 'ChargeMethodAttr')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDSETTLEMENT', chargeMethodData, 'DeferredSettlement')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDSETTLEMENTTIMEOUT', chargeMethodData, 'DeferredSettlementTimeout')
        chargeMethodData = RESTHELPER.checkIfDefined(None, None, 'DEFERREDsETTLEMENTtIMEOUTACTION', chargeMethodData, 'DeferredSettlementTimeoutAction')
    else:
        chargeMethodData = None
    profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')


    url = '/json/group/' + str(queryValue) + '/contract/' + str(offerResourceId) + '/debt_payment'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)


    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def pricingQueryContractList(V3inst, routingType=None, routingValue=None, now=None, eventPass=True, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    url = '/json/pricing/contract'
    if routingType and routingValue:
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time = now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryContract(V3inst, queryValue, queryType='ContractId', routingType=None, routingValue=None, now=None, eventPass=True, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    url = '/json/pricing/contract/' 
    if queryType == 'ContractId':
        url += str(queryValue)
    elif queryType == 'ExternalId':
        contractId = URL.quote(queryValue,'')
        url += '/ExternalId+'+ str(contractId)

    if routingType and routingValue:
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time = now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def pricingCacheQueryContract(V3inst, queryValue, queryType='Contract', routingType=None, routingValue=None, now=None, eventPass=True, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/cache/pricing/'+queryType+'/'+str(queryValue)

    if queryType not in ['Contract', 'contract']:
        print('ERROR: Query Contract  parameter queryType has an unsupported value (' + queryType + ')')

    if routingType and routingValue:
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time = now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryRole(V3inst, queryValue, queryType='PricingId', routingType=None, routingValue=None, now=None, eventPass=True, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    url = '/json/pricing/user_role/' + str(queryValue)
    if routingType and routingValue:
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryRoleList(V3inst, routingType=None, routingValue=None, now=None, eventPass=True, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    url = '/json/pricing/user_role'
    if routingType and routingValue:
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberQueryCatalogItemList(V3inst, queryValue=None, queryType=None, now=None, eventPass=True,
                             eligibilityFilter=True):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/json/'+RESTV3.subUrl+'/'
    #Need to check how many SearchTerm support
    print("query type:", queryType)
    if queryType == 'ExternalId':
        url += 'ExternalId+'+str(queryValue)
    elif queryType == 'ObjectId':
        url += str(queryValue)
    else: sys.exit('ERROR: querySubscriber parameter queryType has an unsupported value (' + queryType + ')')

    #if subscriber, only support catalogitem
    #if subscription, only support CatalogItem
    # see MTX-28513
    if 'subscriber' in url:
        url += '/catalogitem'
    else:
        url += '/CatalogItem'

    url += '?eligibilityFilter='+str(eligibilityFilter).lower()

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    #if QAUTILS.DebugLevel > 0: print funcName + ' response:\n' + response

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response


#=============================================================
def deviceQueryCatalogItemList(V3inst, queryValue=None, queryType=None, now=None, eventPass=True,
                             eligibilityFilter=True):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    if queryType == 'ObjectId':         url = '/json/device/'
    elif queryType == 'ExternalId':     url = '/json/device/ExternalId+'
    elif queryType == 'PhoneNumber':    url = '/json/device/PhoneNumber+'
    elif queryType == 'Imsi':           url = '/json/device/PhoneNumber+'
    elif queryType == 'AccessNumber':   url = '/json/device/AccessNumber+'
    elif queryType == 'LoginId':        url = '/json/device/LoginId+'
    elif queryType == 'AccessId':       url = '/json/device/AccessId+'
    else:  sys.exit('ERROR: queryDevice parameter queryType has an unsupported value (' + queryType + ')')

    url += str(queryValue)+'/CatalogItem?eligibilityFilter='+str(eligibilityFilter)

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    #if QAUTILS.DebugLevel > 0: print funcName + ' response:\n' + response

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response


#=============================================================
def groupQueryCatalogItemList(V3inst, queryValue=None, queryType=None, now=None, eventPass=True,
                             eligibilityFilter=True):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    if   queryType == 'ObjectId':       url = '/json/group/'
    elif queryType == 'ExternalId':     url = '/json/group/ExternalId+'
    elif queryType == 'PhoneNumber':    url = '/json/group/PhoneNumber+'
    else:  sys.exit('ERROR: queryGroup parameter queryType has an unsupported value (' + queryType + ')')

    url += str(queryValue)+'/CatalogItem?eligibilityFilter='+str(eligibilityFilter)

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    #if QAUTILS.DebugLevel > 0: print funcName + ' response:\n' + response

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response


#=============================================================
def pricingQueryCatalogList(V3inst, eventPass=True, now=None, routingType=None, routingValue=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/json/pricing/Catalog'

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def pricingCacheQueryCatalogList(V3inst, eventPass=True, now=None, routingType=None, routingValue=None, queryType='Catalog', multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/cache/pricing/'+queryType

    if queryType not in ['Catalog', 'catalog']:
        print('ERROR: Query CatalogList parameter queryType has an unsupported value (' + queryType + ')')

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response


#=============================================================
def pricingQueryCatalog(V3inst, queryValue=None, queryType='CatalogId', eventPass=True, now=None, routingType=None, routingValue=None, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    if queryType == 'CatalogId':        url = '/json/pricing/Catalog/'
    elif queryType == 'ExternalId':     url = '/json/pricing/Catalog/ExternalId+'
    else:  sys.exit('ERROR: queryCatalog parameter queryType has an unsupported value (' + queryType + ')')

    url += str(queryValue)

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def pricingCacheQueryCatalog(V3inst, queryValue=None, queryType='Catalog', eventPass=True, now=None, routingType=None, routingValue=None, useCache=False, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/cache/pricing/'+queryType+'/'+str(queryValue)
    if queryType not in ['Catalog', 'catalog']:
        print('ERROR: Query Catalog parameter queryType has an unsupported value (' + queryType + ')')

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response


#=============================================================
def queryPricingStatus(V3inst, now=None, routingType=None, routingValue=None, eventPass=True):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/pricing/status'

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def createContractParameterOverrideData(etcScheduleRangeArray=None, etcScheduleRangeUnit=None, paymentScheduleRangeArray=None, paymentScheduleAmountArray=None, paymentScheduleLastAmount=None, delayCharge=None, contractPeriod=None, contractInterval=None, commitmentPeriod=None, commitmentPeriodInterval=None, isOpenContract=None):

    contractParameterOverrideDataTemplate =None
    if etcScheduleRangeArray or etcScheduleRangeUnit or paymentScheduleRangeArray or paymentScheduleAmountArray or paymentScheduleLastAmount or delayCharge:

        print(" file type:", RESTV3.fileType)
        template = 'offer_contract_parameter_override_data' + RESTV3.fileType

        contractParameterOverrideDataTemplate = open(templates + template).read()
        etcScheduleRangeArray = RESTHELPER.populateSimpleValueArray(etcScheduleRangeArray, RESTV3.restVersion)
        paymentScheduleRangeArray = RESTHELPER.populateSimpleValueArray(paymentScheduleRangeArray, RESTV3.restVersion)
        paymentScheduleAmountArray = RESTHELPER.populateSimpleValueArray(paymentScheduleAmountArray, RESTV3.restVersion)
        
        contractParameterOverrideDataTemplate = RESTHELPER.checkIfDefined(contractPeriod, None, 'CONTRACTPERIOD', contractParameterOverrideDataTemplate, 'ContractPeriod')
        contractParameterOverrideDataTemplate = RESTHELPER.checkIfDefined(contractInterval, None, 'CONTRACTINTERVAL', contractParameterOverrideDataTemplate, 'ContractInterval')
        contractParameterOverrideDataTemplate = RESTHELPER.checkIfDefined(commitmentPeriodInterval, None, 'COMMITMENTPERIODINTERVAL', contractParameterOverrideDataTemplate, 'CommitmentPeriodInterval')
        contractParameterOverrideDataTemplate = RESTHELPER.checkIfDefined(commitmentPeriod, None, 'COMMITMENTPERIOD', contractParameterOverrideDataTemplate, 'CommitmentPeriod')
        contractParameterOverrideDataTemplate = RESTHELPER.checkIfDefined(isOpenContract, None, 'ISOPENCONTRACT', contractParameterOverrideDataTemplate, 'IsOpenContract')
        
        contractParameterOverrideDataTemplate = RESTHELPER.checkIfDefined(etcScheduleRangeArray, None, 'ETCSCHEDULERANGEARRAY', contractParameterOverrideDataTemplate, 'EtcScheduleRangeArray')
        contractParameterOverrideDataTemplate = RESTHELPER.checkIfDefined(etcScheduleRangeUnit, None, 'ETCSCHEDULERANGEUNIT', contractParameterOverrideDataTemplate, 'EtcScheduleRangeUnit')
        contractParameterOverrideDataTemplate = RESTHELPER.checkIfDefined(paymentScheduleAmountArray, None, 'PAYMENTSCHEDULEAMOUNTARRAY', contractParameterOverrideDataTemplate, 'PaymentScheduleAmountArray')
        contractParameterOverrideDataTemplate = RESTHELPER.checkIfDefined(paymentScheduleRangeArray, None, 'PAYMENTSCHEDULERANGEARRAY', contractParameterOverrideDataTemplate, 'PaymentScheduleRangeArray')
        contractParameterOverrideDataTemplate = RESTHELPER.checkIfDefined(paymentScheduleLastAmount, None, 'PAYMENTSCHEDULELASTAMOUNT', contractParameterOverrideDataTemplate, 'PaymentScheduleLastAmount')
        contractParameterOverrideDataTemplate = RESTHELPER.checkIfDefined(delayCharge, None, 'DELAYCHARGE', contractParameterOverrideDataTemplate, 'DelayCharge')
        contractParameterOverrideDataTemplate = contractParameterOverrideDataTemplate.rstrip('\n')

    return contractParameterOverrideDataTemplate

#=============================================================
def pricingQueryContractPaymentScheduleList(V3inst, eventPass=True, now=None, routingType=None, routingValue=None, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/pricing/contractPaymentSchedule'

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryContractPaymentSchedule(V3inst, queryValue=None, queryType='ContractPaymentScheduleId', eventPass=True, now=None, routingType=None, routingValue=None, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/pricing/contractPaymentSchedule/'
    if queryType == 'ContractPaymentScheduleId':        url +=str(queryValue)
    elif queryType == 'ExternalId':     url += 'ExternalId+'+str(queryValue)
    else:  sys.exit('ERROR: queryContractPaymentSchedule parameter queryType has an unsupported value (' + queryType + ')')

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response


#=============================================================
def  printAll():

    print("addSubscriber(V3inst=None, externalId = None, deviceId = None, deviceType = 1, offerId = 0, allDevices = True,")
    print("createSubscriber(V3inst, externalId=None, now=None, payload=None, billingCycle=None, eventPass=True,")
    print("modifySubscriber(V3inst, queryValue, payload=None, eventPass=True, queryType='ExternalId',")
    print("subscribeToOffer(V3inst, externalId, offerId, offerStartTime=None, offerEndTime=None, eventPass=True,")
    print("unsubscribeFromOffer(V3inst, subscriberId, resourceId=0, endTime=None, eventPass=True,")
    print("addSubscriberThreshold(V3inst, subscriberId, resourceId, thresholdId, threshName, isCredit, isPercent,")
    print("removeSubscriberThreshold(V3inst, subscriberId, indexId, thresholdId, queryType='ExternalId'):")
    print("querySubscriber(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None):")
    print("querySubscriberWallet(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None):")
    print("createDevice(V3inst, imsi, externalId=None, deviceType=None, attr=None, now=None,")
    print("addDeviceToSubscriber(V3inst, externalId, deviceId=0, deviceType=1, subQueryType='ExternalId',")
    print("modifyDevice(V3inst, queryValue, queryType='PhoneNumber', deviceType=None, attr=None, now=None, eventPass=True):")
    print("devicePurchaseOffer(V3inst, queryValue, offerId, offerStartTime=None, offerEndTime=None, queryType='PhoneNumber',")
    print("deviceCancelOffer(V3inst, queryValue, resourceId=0, endTime=None, eventPass=True, queryType='PhoneNumber'):")
    print("queryDevice(V3inst, queryValue, queryType='PhoneNumber', eventPass=True, now=None):")
    print("createGroup(V3inst, groupId=None, name=None, tier=None, administrator_id=0, eventPass=True, attr=None, now=None,")
    print("modifyGroup(V3inst, groupId, name=None, tier=None, administrator_id=0, billingCycle=None, attr=None,")
    print("groupSubscribeToOffer(V3inst, groupId, offerId, offerStartTime=None, offerEndTime=None, eventPass=True,")
    print("groupUnsubscribeFromOffer(V3inst, groupId, resourceIds, now=None, eventPass=True, queryType='ExternalId'):")
    print("addGroupThreshold(V3inst, groupId, resourceId, thresholdId, threshName, isCredit, isPercent,")
    print("removeGroupThreshold(V3inst, groupId, resourceId, thresholdId, now=None, queryType='ExternalId'):")
    print("addSubscriberToGroup(V3inst, groupId, subscriberId, subQueryType='ExternalId', groupQueryType='ExternalId',")
    print("removeSubscriberFromGroup(V3inst, groupId, subscriberId, subQueryType='ExternalId', groupQueryType='ExternalId',")
    print("addSubGroupToGroup(V3inst, groupId, subGroupId, subQueryType='ExternalId', groupQueryType='ExternalId',")
    print("removeSubGroupFromGroup(V3inst, groupId, subGroupId, subQueryType='ExternalId', groupQueryType='ExternalId',")
    print("addGroupMembership(V3inst, groupId, subscribers=None, subGroups=None, subQueryType='ExternalId',")
    print("removeGroupMembership(V3inst, groupId, subscribers=None, subGroups=None, subQueryType='ExternalId',")
    print("queryGroup(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None):")
    print("queryGroupWallet(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True):")
    print("createBillingCycleData(templateId, dateOffset=None, startTime=None):")
    print("createSubscriberBillingProfile(V3inst, subscriberId, profileId, startTime=None, dateOffset=0,")
    print("queryCatalogItemList(V3inst, eventPass=True, now=None, routingType=None, routingValue=None)")
    print("queryCatalogItem(V3inst, queryValue=None, queryType='Id', eventPass=True, now=None, routingType=None, routingValue=None)")
    print("subscriberQueryCatalogItemList(V3inst, queryValue=None, queryType=None, now=None, eventPass=True,eligibilityFilter=True)")
    print("deviceQueryCatalogItemList(V3inst, queryValue=None, queryType=None, now=None, eventPass=True,eligibilityFilter=True)")
    print("groupQueryCatalogItemList(V3inst, queryValue=None, queryType=None, now=None, eventPass=True,eligibilityFilter=True)")
    print("pricingQueryCatalogList(V3inst, eventPass=True, now=None, routingType=None, routingValue=None)")
    print("pricingQueryCatalog(V3inst, queryValue=None, queryType='CatalogId', eventPass=True, now=None, routingType=None, routingValue=None)")

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


