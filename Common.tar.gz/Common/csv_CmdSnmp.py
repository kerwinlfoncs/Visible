#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:35:50
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:35:50
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:35:49
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
import snmp as SNMP

#==========================================================
def CmdSnmp_snmpbase(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        SNMP.SNMPPre(lclDCT['snmpMIBs'])

        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)

#==========================================================
def CmdSnmp_snmpdelta(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        SNMP.SNMPPost(lclDCT['outputFileName'], lclDCT['snmpMIBs'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)

