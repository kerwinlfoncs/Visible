#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:35:02
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:35:02
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:35:01
from __future__ import print_function
# from builtins import str
# from builtins import str
import sys, os, random
import optparse
from subprocess import call
import qa_utils as QAUTILS
import xml.etree.cElementTree as ET

# Flag to signal login has occurred
cbLoginFlag = False

# Get unique name for cookie file
cookieFile="cookie" + str(random.randint(1,1000000)) + "File"

#===============================================================================
# This function will login to the CB server
def cbLogin():
    global cbLoginFlag
    
    # Skip if already done
    if cbLoginFlag: return
    
    # Set flag that we've logged in
    cbLoginFlag = True
    
    # Get Catalog Builder data needed for web call (environment variables or defaults)
    ipAddress = os.path.expandvars('$CatalogBuilderHost')
    if not ipAddress: ipAddress = 'localhost'

    port = os.path.expandvars('$CatalogBuilderPort')
    if not port: port = '8080'

    userName = os.path.expandvars('$CatalogUserName')
    if not userName: userName = 'guest'

    pswd = os.path.expandvars('$CatalogPassword')
    if not pswd: pswd = 'guest'

    domain = os.path.expandvars('$pricingdomain')
    if not domain: domain = 'Functional_Tests'

    # Remove old tool files
    lclRunCmd('rm login* body* query* ' + cookieFile + ' >/dev/null 2&>1')

    # Login (required so we can get the data)
    cmd='curl -s -c ' + cookieFile + ' http://' + ipAddress + ':' + port + '/matrixx/data/objects/login?username='+ userName + '\&password=' + pswd+ '\&domain=' + domain + ' >/dev/null 2&>1'
    #print 'Executing command: ' + cmd
    lclRunCmd(cmd)

#===============================================================================
# This function is used to run bash scripts.
def lclRunCmd(cmd):
#    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
#    out = p.stdout.read().strip()
#    return out  #This is the stdout from the shell command
    return call(cmd, shell=True)

#===============================================================================
# This function will create catalog items
def cbCreateCatalogItems(action, id=None):
        # Get template function
        templates= os.getenv("QADIR") + '/Common/templates/'
        
#===============================================================================
# This function will query the CB for a desired object
def cbQuery(action, id=None):
    # Ensure we've logged in once per test run
    cbLogin()
    
    # Need to set the type of object in the URL.  Depends on the input action.
    if action == 'cbQueryNormalizer':
        objType='Normalizer'
    elif action == 'cbQueryRateTable':
        objType='Matrix'
    elif action == 'cbQueryPriceComponent':
        objType='Price'
    elif action == 'cbQueryOffer':
        objType='Offer'
    elif action == 'cbQueryOfferList':
        objType='OfferList'
    else:
        print('ERROR:  unknown action passed to cbQueryNormalizer: "' + action + '"')
        sys.exit()

    # If not offer list and no ID passed in, then an error
    if objType != 'OfferList' and not id:
            print('ERROR: cbId parameter must be entered and be non-zero for command: ' + lclDCT['ACTION'])
            sys.exit('Error on command: ' + lclDCT['ACTION'])
        
    # Build URL.
    # For now, always use "default" for the object-specific portion of the URL.  
    # Otherwise would need to map ID to different strings (not pretty....)
    url = '/matrixx/data/objects/' + objType + '/default/'
    
    # Get IP/port from environment variables
    ipAddress = os.path.expandvars('$CatalogBuilderHost')
    port = os.path.expandvars('$CatalogBuilderPort')
    
    # Build/print/execute command
    cmd='curl -s -b ' + cookieFile + ' -c ' + cookieFile + ' http://' + ipAddress + ':' + port + url
    if id: cmd += id
    
    #print 'Executing command: ' + cmd
    normData = QAUTILS.runCmd(cmd)
    return normData

#===============================================================================
# This function will query the CB for a desired object AND retrieve the values that are mapped 
def cbQueryAndReturnNormalizerValues(normalizerId):
        # Read in the data
        normData = cbQuery('cbQueryNormalizer', normalizerId)

        #print 'Read normalizer ' + str(normalizerId)
        #print normData

        # Pre/post pend data (shouldn't need to do that here...)
        normData = "<kef>\n" + normData + "\n</kef>"

        # Put into ET structure
        q = ET.fromstring(normData)
        
        # Init return data
        normData = {}
        normData['object'] = {}
        
        # See what type the normalizer is.
        for child in q.findall("./object/normalizer"): 
                # Store every attribute
                for attr in list(child.keys()):
                        cmd = "normData['object']['" + attr + "'] = child.get('" + attr + "')"
                        exec(cmd)
        
        # Get the results for this normalizer
        normData['data'] = []
        for child in q.findall("./object/normalizer/results/result"):
                # Local dictionary to store attributes
                data = {}
                
                # Store every attribute
                for attr in list(child.keys()):
                    cmd = "data['" + attr + "'] = child.get('" + attr + "')"
                    exec(cmd)
        
                # Special processing for non-balance normalizers (so IP processing works)
                if normData['object']['datatype'] != 'balance':
                        # Get the single value
                        # Cut out any IP mask (so this works fine for non-IP and IP normalizers).
                        value = child.get('value').split('/')[0]
                
                        # OK, IP address 0.0.0.0 always used to signal not found.  Skip this one, as it always triggers a deny.
                        if value == '0.0.0.0': data = None
                
                # Append if data defined
                if data: normData['data'].append((data))
                
        print('Found ' + str(len(normData['data'])) + ' values for normalizer ID ' + str(normalizerId) + ' type ' + normData['object']['datatype'])
        
        return normData

if __name__ ==  '__main__':
    main()


