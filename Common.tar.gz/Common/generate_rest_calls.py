#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Wed 2021-08-25T17:30:19
# @futurize --stage2 --no-diffs -n -w  : Wed 2021-08-25T17:30:16
#
# @futurize --stage1 --no-diffs -n -w  : Wed 2021-08-25T17:30:14
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


# from builtins import str
# from builtins import str
import common_mdc as COMMON

def main(path,PARAMS):
    print(PARAMS)
    externalId = PARAMS['externalId']
    allDevices= PARAMS['DeviceId']
    fileName = 'rv2_' + str(externalId) + '.py'
    f=open(fileName,'w')
#!/usr/bin/python3


def main():
    '''
    f.write(str1)
    f.write('    outputFile = \'' + path + '/' + COMMON.resultsDir + '/rv2_' + str(externalId) + '_results.txt\'')
    str1=
    fOut = open(outputFile,'w')

    '''
    f.write(str1)
    blankLine= '\'\\n\')'

    f.write('\n    W=C.getSubscriber(' + '\'' + str(externalId) + '\')')
    f.write('\n    fOut.write('+ blankLine)
    f.write('\n    fOut.write(\'******getSubscriber ID=' +  str(externalId)+'\')')
    f.write('\n    fOut.write('+ blankLine)
    f.write('\n    fOut.write(str(W))')
    f.write('\n    fOut.write('+ blankLine)
    f.write('\n')
    ####################################
    f.write('\n    W=C.getSubscriberProfile(' + '\'' + str(externalId) + '\')')
    f.write('\n    fOut.write('+ blankLine)
    f.write('\n    fOut.write(\'******getSubscriberProfile ID=' +  str(externalId)+'\')')
    f.write('\n    fOut.write('+ blankLine)
    f.write('\n    fOut.write(str(W))')
    f.write('\n    fOut.write('+ blankLine)
    f.write('\n')
    ####################################
    f.write('\n    W=C.getSubscriberBillingProfile(' + '\'' + str(externalId) + '\')')
    f.write('\n    fOut.write('+ blankLine)
    f.write('\n    fOut.write(\'******getSubscriberBillingProfile ID=' +  str(externalId)+'\')')
    f.write('\n    fOut.write('+ blankLine)
    f.write('\n    fOut.write(str(W))')
    f.write('\n    fOut.write('+ blankLine)
    f.write('\n')
    ####################################
    f.write('\n\n    W=C.getWallet(' + '\'' + str(externalId) + '\')')
    f.write('\n    fOut.write('+ blankLine)
    f.write('\n    fOut.write(\'******getWallet ID=' +  str(externalId)+'\')')
    f.write('\n    fOut.write('+ blankLine)
    f.write('\n    fOut.write(str(W))')

    for deviceId in allDevices:
       f.write ('\n\n')
       f.write('\n    fOut.write('+ blankLine)
       f.write ('    #---------get subscriberByDevice deviceID :' + str(deviceId)+ '-----\n')
       f.write('\n    W=C.querySubscriberByDevice(' + '\'' + str(deviceId) + '\')')
       f.write('\n    fOut.write('+ blankLine)
       f.write('\n    fOut.write(\'******querySubscriber ID=' +  str(deviceId)+'\')')
       f.write('\n    fOut.write('+ blankLine)
       f.write('\n    fOut.write(str(W))')
       f.write('\n    fOut.write('+ blankLine)
       f.write('\n')
       ####################################
       f.write('\n\n    W=C.getDevice(' + '\'' + str(externalId) + '\',\'' + str(deviceId) + '\')')

       f.write('\n    fOut.write('+ blankLine)
       f.write('\n    fOut.write(\'******getDevice ID=' +  str(externalId)+'\')')
       f.write('\n    fOut.write('+ blankLine)
       f.write('\n    fOut.write(str(W))')
       ####################################


    f.write('\n\nmain()')

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

