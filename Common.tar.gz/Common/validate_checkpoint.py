#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:41:19
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:37:01
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:19
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================



# from builtins import str
# from builtins import str
from past.utils import old_div
import time, optparse
import os, sys, shutil
import qa_utils as QAUTILS
import ha_utils as HAUTILS

#==========================================================

def main():
    
    global validateDir
    global ckptDir
    validateDir = '/opt/mtx/examples/validate_export/'
    E1Ckpt = None
    E2Ckpt = None

    #------ parse command line options ---------------
    parser = optparse.OptionParser()
    parser.add_option("-t", "--duration", action='store', type='int', default=0, help="test duration, in hours"
)
    (options, args) = parser.parse_args()

    #========== get settings from config file  =========================
    configFile = os.getenv("MTX_CUSTOM_DIR")+"/create_config.info"
    ckptInterval = QAUTILS.runCmd('grep "interval between database checkpoints" ' + configFile + ' | head -1').split("?")[1]
    ckptDir = QAUTILS.runCmd('grep "use for archiving transaction log files and checkpoints" ' + configFile ).split("?")[1]

    HASetup = HAUTILS.thisSetup()
    try :
        mgmE1 = HASetup.getMgmtBlade('1:1')
        mgmE1IP = HASetup.getBladeIP(mgmE1)
    except Exception :
        print("E1 is not up")

    try :    
        mgmE2 = HASetup.getMgmtBlade('2:1')
        mgmE2IP = HASetup.getBladeIP(mgmE2)
    except Exception :
        print("E2 is not up")

    if mgmE1IP is None and mgmE2IP is None :
        print("Both E1 and E2 are not up.  Quit!!!!!")
        killTest()
        sys.exit(0)
    else :
        print(ckptInterval, ckptDir, mgmE1IP, mgmE2IP)

    #------ convert checkpoint interval from min to sec ----
    print("The script will run for ", options.duration, " hours.")
    print("It will check checkpoints every ", ckptInterval, " minutes")
    ckptInterval = int(ckptInterval)*60 + 10  
    cnt = old_div(options.duration * 3600, ckptInterval) + 1

    while cnt > 0 :
        #------  check E1 first ------------------------
        if mgmE1IP is not None :
            checkpoint = getLatestCheckpoint(mgmE1IP)
            print("E1 === ",checkpoint)
            if checkpoint != E1Ckpt :
                E1Ckpt = checkpoint
                ckPass = validateCheckpoint(mgmE1IP, checkpoint)
                if not ckPass :
                    saveCheckpoint(mgmE1IP, checkpoint)
                    killTest()
                    break
                else :
                    cleanValidationLog(mgmE1IP)

        #------  then check E2  ------------------------
        if mgmE2IP is not None :
            checkpoint = getLatestCheckpoint(mgmE2IP)
            print("E2 ==== ", checkpoint)
            if checkpoint != E2Ckpt :
                E2Ckpt = checkpoint
                ckPass = validateCheckpoint(mgmE2IP, checkpoint)
                if not ckPass :
                    saveCheckpoint(mgmE2IP, checkpoint)
                    killTest()
                    break
                else :
                    cleanValidationLog(mgmE1IP)
        
        print("NO ERROR.  Sleep for ", str(ckptInterval))
        time.sleep(ckptInterval)
        cnt = cnt - 1

def getLatestCheckpoint(svrIP) :
    cmd = 'ssh ' + svrIP + ' "ls -t ' + ckptDir + '/checkpoints ' + '| head -1"'
    print(cmd)
    ckpt = QAUTILS.runCmd(cmd) 
    return ckpt

def validateCheckpoint(IP, checkpoint) :
    cmd = 'cd ' + validateDir + '; ./validate_export.py ' + ckptDir + '/checkpoints/' + checkpoint
    sshCmd = 'ssh ' + IP + ' "' + cmd + '"'
    print(sshCmd)
    QAUTILS.runCmd(sshCmd)
    #-- check if the log file is created ----
    sshCmd = 'ssh ' + IP + ' "ls ' + validateDir + 'validate_export.log | wc -l"'
    cnt = QAUTILS.runCmd(sshCmd)
    if cnt == "1" :
        sshCmd = 'ssh ' + IP + ' "grep ERROR ' + validateDir + 'validate_export.log | wc -l"'
        print(sshCmd)
        errCnt = QAUTILS.runCmd(sshCmd)
        print("found total errors ====: ", errCnt)
        if errCnt is not 0 :
            print("DETECTED ERROR IN CHECKPOINT ==== QUIT !!!!")
            return False
        else :
            return True
    else :
        print("FAILED to generate validate_export.log file!!!")
        print("KILL TEST and QUIT !!!!!")
        return False

def saveCheckpoint(IP, checkpoint):
    checkpoint = ckptDir + '/checkpoints/'+checkpoint
    sshCmd = 'ssh ' + IP + ' "cp -r ' + checkpoint + ' ' + validateDir + '"'
    print(sshCmd)
    print("save checkpoint to === : ", validateDir)
    QAUTILS.runCmd(sshCmd)
    
def cleanValidationLog(IP):
    sshCmd = 'ssh ' + IP + ' "cd ' + validateDir + '; rm validate_export.log"'
    QAUTILS.runCmd(sshCmd)

def killTest():
    cmd = "pgrep -o -x create_and_send "
    pid = QAUTILS.runCmd(cmd)
    print(pid)
    QAUTILS.runCmd("kill -9 " + pid)


#*******************************************************************
#*******************************************************************

if __name__ == '__main__':
    main()

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
