#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:35:45
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:35:45
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:35:45
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
from __future__ import print_function
# from builtins import str
# from builtins import str
import os, sys, copy, pprint
import QA_subscriber_management_restv3 as REST_UTIL
import qa_utils as QAUTILS
import csvMain as CSV
import csv_track as TRACK
import csv_id as CSVID
import csv_prim as PRIM
import csv_data as DATA
import custSpecific as CUST
import csv_qa as CSVQA
import csvMain as CSV
import csv_CmdMisc as MISC
import csv_Events as CSVEVENTS
import xml.etree.ElementTree as ET

from primitives import primGET as GET
from primitives import primXML as XML
from primitives import primHTTP as HTTP
from primitives import primGeneric as GENERIC

# Add global data here
SubscriberPaymentData = {}

#==========================================================
def CmdPayNow_groupquerypaymenthistory(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        # End of local variables setup.
        
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])


        # Execute primitive
        retCode = REST_UTIL.groupQueryPaymentHistory(RESTInst, groupId, queryType=lclDCT['groupQueryType'], eventPass=lclDCT['eventPass'], now=None, executeMode=lclDCT['executeMode'], apiEventData=lclDCT['apiEventData'],)

        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdPayNow_grouppayment(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        # End of local variables setup.
        
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])


        # Execute primitive
        retCode = REST_UTIL.groupPayment(RESTInst, groupId, lclDCT['amount'], queryType=lclDCT['groupQueryType'], eventPass=lclDCT['eventPass'], now=None, apiEventData=lclDCT['apiEventData'],)

        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdPayNow_grouprefundpayment(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        resourceId = lclDCT['resourceId']
        # End of local variables setup.

        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])


        # Execute primitive
        retCode = REST_UTIL.groupPayment(RESTInst,
                groupId,
                queryType=lclDCT['groupQueryType'],
                resourceId=resourceId,
                reason=lclDCT['reason'],
                info=lclDCT['info'],
                amount=str(lclDCT['amount']),
                eventPass=lclDCT['eventPass'],
                now=None,
                executeMode=lclDCT['executeMode'],
                )

        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdPayNow_grouprecharge(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        resourceId = lclDCT['resourceId']
        # End of local variables setup.
        
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']
        else: lclStartTime = lclDCT['lclStartTime'] # Added during Python3 migration
        
        # Lots of reasons to adjust amount
        if lclDCT['balanceId']: (amount, adjustType, resourceId) = PRIM.makeAmountAdjustments('group', groupId, lclDCT)
        else: amount = lclDCT['amount'] # Added during Python3 migration
        
        # Resource ID is optional.  If 0 then set to None
        if int(resourceId) == 0: resourceId = None
        
        print('CmdPayNow_grouprecharge: resourceId = ' + str(resourceId) + ', noPayload = ' + str(lclDCT['noPayload']))
        
        # Execute primitive
        retCode = REST_UTIL.groupRecharge(RESTInst,
                groupId,
                queryType=lclDCT['groupQueryType'],
                balanceResourceId=resourceId,
                amount=str(amount),
                now=lclStartTime,
                eventPass=lclDCT['eventPass'],
                endTimeExtensionOffsetUnit=lclDCT['balanceEndTimeExtensionOffsetUnit'],
                endTimeExtensionOffset=lclDCT['balanceEndTimeExtensionOffset'],
                endTime=lclDCT['balanceEndTime'],
                executeMode=lclDCT['executeMode'],
                payload=not lclDCT['noPayload'],
                payNow=lclDCT['payNow'],
                reason=lclDCT['reason'],
                info=lclDCT['info'],
                apiEventData=lclDCT['apiEventData'],
                )
        
        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
#==========================================================
def CmdPayNow_groupaddpaymentmethod(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        # End of local variables setup.
        
        # Payment APIs expect True/False inputs
        if lclDCT['isDefault'] in ['1', True, 'true', 'yes']:
                isDefault = True
        else:   isDefault = False
        if lclDCT['isSysDefault'] in ['1', True, 'true', 'yes']:
                isSysDefault = True
        else:   isSysDefault = False

        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        
        # Execute primitive
        retCode = REST_UTIL.groupAddPaymentMethod(RESTInst,
                groupId,
                queryType=lclDCT['groupQueryType'],
                paymentGatewayId=lclDCT['paymentGatewayId'],
                paymentGatewayUserId=lclDCT['paymentGatewayUserId'],
                paymentGatewayOneTimeToken=lclDCT['paymentGatewayOneTimeToken'],
                paymentType=lclDCT['paymentType'],
                paymentAttr=lclDCT['paymentAttr'],
                isDefault=isDefault,
                isSysDefault=isSysDefault,
                name=lclDCT['name'],
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                executeMode=lclDCT['executeMode'],
                apiEventData=lclDCT['apiEventData'],)
        
        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdPayNow_groupmodifypaymentmethod(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        groupId = lclDCT['groupId']
        resourceId = lclDCT['resourceId']
        # End of local variables setup.
        
        # Payment APIs expect True/False inputs
        if lclDCT['isDefault'] in ['1', True, 'true', 'yes']:
                isDefault = True
        else:   isDefault = False
        if lclDCT['isSysDefault'] in ['1', True, 'true', 'yes']:
                isSysDefault = True
        else:   isSysDefault = False

        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Can reference payment method by name or resource ID
        if not resourceId: resourceId = getPaymentResourceId(externalId, lclDCT['subQueryType'], lclDCT['name'], objType = 'Subscriber')
        
        # Execute primitive
        retCode = REST_UTIL.groupModifyPaymentMethod(RESTInst,
                groupId,
                resourceId=resourceId,
                queryType=lclDCT['groupQueryType'],
                paymentGatewayId=lclDCT['paymentGatewayId'],
                paymentGatewayUserId=lclDCT['paymentGatewayUserId'],
                paymentType=lclDCT['paymentType'],
                paymentAttr=lclDCT['paymentAttr'],
                isDefault=isDefault,
                isSysDefault=isSysDefault,
                name=lclDCT['name'],
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                executeMode=lclDCT['executeMode'],
                apiEventData=lclDCT['apiEventData'],)
        
        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdPayNow_groupquerypaymentmethod(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        # End of local variables setup.
        
        # Payment APIs expect True/False inputs
        if lclDCT['isDefault'] in ['1', True, 'true', 'yes']:
                isDefault = True
        else:   isDefault = False
        if lclDCT['isSysDefault'] in ['1', True, 'true', 'yes']:
                isSysDefault = True
        else:   isSysDefault = False

        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        
        # Execute primitive
        retCode = REST_UTIL.groupQueryPaymentMethod(RESTInst,
                groupId,
                queryType=lclDCT['groupQueryType'],
                paymentGatewayId=lclDCT['paymentGatewayId'],
                returnDefault=isDefault,
                returnSysDefault=isSysDefault,
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                apiEventData=lclDCT['apiEventData'],)
        
        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdPayNow_groupremovepaymentmethod(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        groupId = lclDCT['groupId']
        resourceId = lclDCT['resourceId']
        # End of local variables setup.
        
        # Group should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Can reference payment method by name or resource ID
        if not resourceId: resourceId = getPaymentResourceId(externalId, lclDCT['subQueryType'], lclDCT['name'], objType = 'Subscriber')
        
        # Execute primitive
        retCode = REST_UTIL.groupRemovePaymentMethod(RESTInst,
                groupId,
                queryType=lclDCT['groupQueryType'],
                resourceId=resourceId,
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                apiEventData=lclDCT['apiEventData'],)
        
        # Query group
        queryValue = groupId
        queryType = lclDCT['groupQueryType']
        lclDCT['saveFunc'] = 'saveGroupMDC'

        return (queryType, queryValue)
        
#==========================================================
# Estimate recurring charge for Group
def CmdPayNow_groupestimaterecurringcharge(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        groupId = lclDCT['groupId']
        outputFileName = lclDCT['outputFileName']
        # End of local variables setup.
        
        # Object should exist
        if groupId not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: Group with ID "' + groupId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Execute primitive
        status,response = REST_UTIL.groupEstimateRecurringCharge(RESTInst,
                groupId,
                queryType=lclDCT['groupQueryType'],
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                apiEventData=lclDCT['apiEventData'],)
                #filterName=filterName,
        
        # If expected to pass, then output data
        if lclDCT['eventPass']:
         # If saving data and not redirecting the output, then force to stdout
         if (not lclDCT['saveData']) and (not outputFileName): outputFileName = 'stdout'

         # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
         try:
                respData = str(response.printElementBasedXml())
         except:
                respData = str(response)
        
         # If supposed to save data to variables then do that here
         if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, 'Subscriber', respData)
        
         # If supposed to store output then write to where the caller wanted it to go
         if outputFileName and outputFileName.lower() != 'none': CSVQA.processDataToOutput(respData, outputFileName)
        
        # Query nothing
        queryValue = None
        queryType = None

        return (queryType, queryValue)
        
#==========================================================
def CmdPayNow_subscriberquerypaymenthistory(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        # End of local variables setup. 
        
        # Item should exist.  Skip if in a multi-request.
        if not lclDCT['noChecks'] and lclDCT['subQueryType'] != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Execute primitive
        retCode = REST_UTIL.subQueryPaymentHistory(RESTInst, externalId, queryType=lclDCT['groupQueryType'], eventPass=lclDCT['eventPass'], now=None, executeMode=lclDCT['executeMode'], apiEventData=lclDCT['apiEventData'],)

        # Query group
        queryValue = externalId
        queryType = lclDCT['subQueryType']
        lclDCT['saveFunc'] = 'saveMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdPayNow_subscriberpayment(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        # End of local variables setup. 
                
        # Item should exist.  Skip if in a multi-request.
        if not lclDCT['noChecks'] and lclDCT['subQueryType'] != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Execute primitive
        retCode = REST_UTIL.subscriberPayment(RESTInst, externalId, lclDCT['amount'], queryType=lclDCT['subQueryType'], eventPass=lclDCT['eventPass'], now=None, apiEventData=lclDCT['apiEventData'],)

        # Query group
        queryValue = externalId
        queryType = lclDCT['subQueryType']
        lclDCT['saveFunc'] = 'saveMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdPayNow_subscriberrefundpayment(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        resourceId = lclDCT['resourceId']
        # End of local variables setup. 
                
        # Item should exist.  Skip if in a multi-request.
        if not lclDCT['noChecks'] and lclDCT['subQueryType'] != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Execute primitive
        retCode = REST_UTIL.subscriberPayment(RESTInst,
                externalId,
                queryType=lclDCT['subQueryType'],
                resourceId=resourceId,
                reason=lclDCT['reason'],
                info=lclDCT['info'],
                amount=str(lclDCT['amount']),
                eventPass=lclDCT['eventPass'],
                now=None,
                executeMode=lclDCT['executeMode'],
                )

        # Query group
        queryValue = externalId
        queryType = lclDCT['subQueryType']
        lclDCT['saveFunc'] = 'saveMDC'

        return (queryType, queryValue)
        
#==========================================================
def CmdPayNow_subscriberrecharge(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        resourceId = lclDCT['resourceId']
        # End of local variables setup. 
                
        # Item should exist.  Skip if in a multi-request.
        if not lclDCT['noChecks'] and lclDCT['subQueryType'] != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']
        else: lclStartTime = lclDCT['lclStartTime'] # Added during Python3 migration
        
        # Lots of reasons to adjust amount
        if lclDCT['balanceId']: (amount, adjustType, resourceId) = PRIM.makeAmountAdjustments('group', externalId, lclDCT)
        else: amount = lclDCT['amount'] # Added during Python3 migration
        
        # Resource ID is optional.  If 0 then set to None
        if int(resourceId) == 0: resourceId = None
        
        print('CmdPayNow_' + REST_UTIL.subUrl + 'recharge: resourceId = ' + str(resourceId) + ', noPayload = ' + str(lclDCT['noPayload']))
        
        # Execute primitive
        retCode = REST_UTIL.subscriberRecharge(RESTInst,
                externalId,
                queryType=lclDCT['subQueryType'],
                balanceResourceId=resourceId,
                amount=str(amount),
                now=lclStartTime,
                eventPass=lclDCT['eventPass'],
                endTimeExtensionOffsetUnit=lclDCT['balanceEndTimeExtensionOffsetUnit'],
                endTimeExtensionOffset=lclDCT['balanceEndTimeExtensionOffset'],
                endTime=lclDCT['balanceEndTime'],
                executeMode=lclDCT['executeMode'],
                payload=not lclDCT['noPayload'],
                payNow=lclDCT['payNow'],
                reason=lclDCT['reason'],
                info=lclDCT['info'],
                apiEventData=lclDCT['apiEventData'],
                )
        
        # Query group
        queryValue = externalId
        queryType = lclDCT['subQueryType']

        return (queryType, queryValue)
        
#==========================================================
#==========================================================
def CmdPayNow_subscriberaddpaymentmethod(lclDCT, options, RESTInst, cmdLineInput):
        global SubscriberPaymentData
        
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        # End of local variables setup. 
                
        # Item should exist.  Skip if in a multi-request.
        if not lclDCT['noChecks'] and lclDCT['subQueryType'] != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Execute primitive
        retCode = REST_UTIL.subscriberAddPaymentMethod(RESTInst,
                externalId,
                queryType=lclDCT['subQueryType'],
                paymentGatewayId=lclDCT['paymentGatewayId'],
                paymentGatewayUserId=lclDCT['paymentGatewayUserId'],
                paymentGatewayOneTimeToken=lclDCT['paymentGatewayOneTimeToken'],
                paymentType=lclDCT['paymentType'],
                paymentAttr=lclDCT['paymentAttr'],
                isDefault=lclDCT['isDefault'],
                isSysDefault=lclDCT['isSysDefault'],
                name=lclDCT['name'],
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                executeMode=lclDCT['executeMode'],
                apiEventData=lclDCT['apiEventData'],)
        
        # Query group
        queryValue = externalId
        queryType = lclDCT['subQueryType']

        return (queryType, queryValue)
        
#==========================================================
def getPaymentResourceId(queryValue, queryType, name, objType = 'Subscriber'):
        # Really should have returned the resource ID here, but QA doesn't want to change their code...
        # ***** Process payment method
        # Read data
        url = GET.urlObjectStart + objType.lower() + '/' + queryType + '+' + queryValue + '/payment_method'
        x = GET.curlToETFormat(url)
        
        # Payment method array
        lclDctName = 'PaymentMethod'
        xmlDctName = './PaymentMethodInfoList/MtxPaymentMethodInfo'
        customName = None
        addlStructures = []
        dctRcv = XML.getArrayData(xmlDctName, customName, x, None, addlStructures)
        
        # Debug
        #pprint.pprint(dctRcv)
        
        # Add to global data
        for entry in dctRcv:
                if entry['Name'].lower() == name.lower(): break
        else: sys.exit('ERROR: didn\'t find ' + objType + ' ' + queryValue + ' (' + queryType + ') payment name of "' + name + '"')
        
        return entry['ResourceId']
        
#==========================================================
def CmdPayNow_subscribermodifypaymentmethod(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        resourceId = lclDCT['resourceId']
        # End of local variables setup.
                
        # Item should exist.  Skip if in a multi-request.
        if not lclDCT['noChecks'] and lclDCT['subQueryType'] != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Can reference payment method by name or resource ID
        if not resourceId: resourceId = getPaymentResourceId(externalId, lclDCT['subQueryType'], lclDCT['name'], objType = 'Subscriber')
        
        # Execute primitive
        retCode = REST_UTIL.subscriberModifyPaymentMethod(RESTInst,
                externalId,
                resourceId=resourceId,
                queryType=lclDCT['subQueryType'],
                paymentGatewayId=lclDCT['paymentGatewayId'],
                paymentGatewayUserId=lclDCT['paymentGatewayUserId'],
                paymentType=lclDCT['paymentType'],
                paymentAttr=lclDCT['paymentAttr'],
                isDefault=lclDCT['isDefault'],
                isSysDefault=lclDCT['isSysDefault'],
                name=lclDCT['name'],
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                executeMode=lclDCT['executeMode'],
                apiEventData=lclDCT['apiEventData'],)
        
        # Query group
        queryValue = externalId
        queryType = lclDCT['subQueryType']

        return (queryType, queryValue)
        
#==========================================================
def CmdPayNow_subscriberquerypaymentmethod(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        outputFileName = lclDCT['outputFileName']
        # End of local variables setup.
        
        # Item should exist.  Skip if in a multi-request.
        if not lclDCT['noChecks'] and lclDCT['subQueryType'] != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Execute primitive
        response = REST_UTIL.subscriberQueryPaymentMethod(RESTInst,
                externalId,
                queryType=lclDCT['subQueryType'],
                paymentGatewayId=lclDCT['paymentGatewayId'],
                returnDefault=lclDCT['isDefault'],
                returnSysDefault=lclDCT['isSysDefault'],
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                )
        
        # If expected to pass, then output data
        if lclDCT['eventPass']:
         # If saving data and not redirecting the output, then force to stdout
         if (not lclDCT['saveData']) and (not outputFileName): outputFileName = 'stdout'

         # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
         try:
                respData = str(response.printElementBasedXml())
         except:
                respData = str(response)

         # If supposed to save data to variables then do that here
         if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, 'Subscriber', respData)
         
         # If supposed to store output then write to where the caller wanted it to go
         if outputFileName and outputFileName.lower() != 'none': CSVQA.processDataToOutput(respData, outputFileName)
        
        # Query group
        queryValue = externalId
        queryType = lclDCT['subQueryType']

        return (queryType, queryValue)
        
#==========================================================
def CmdPayNow_subscriberremovepaymentmethod(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        resourceId = lclDCT['resourceId']
        # End of local variables setup.
        
        # Item should exist.  Skip if in a multi-request.
        if not lclDCT['noChecks'] and lclDCT['subQueryType'] != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Can reference payment method by name or resource ID
        if not resourceId: resourceId = getPaymentResourceId(externalId, lclDCT['subQueryType'], lclDCT['name'], objType = 'Subscriber')
        
        # Execute primitive
        retCode = REST_UTIL.subscriberRemovePaymentMethod(RESTInst,
                externalId,
                queryType=lclDCT['subQueryType'],
                resourceId=resourceId,
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                apiEventData=lclDCT['apiEventData'],
                )
        
        # Query group
        queryValue = externalId
        queryType = lclDCT['subQueryType']

        return (queryType, queryValue)
        
#==========================================================
# Get Nounce for dong anything with a payment gateway
def CmdPayNow_getgatewayauthorizationtoken(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.getGatewayAuthorizationToken(RESTInst,
                paymentGatewayUserId=None,
                paymentGatewayId=lclDCT['paymentGatewayId'],
                eventPass=lclDCT['eventPass'],
                apiEventData=lclDCT['apiEventData'],
                )

        # Query nothing
        queryValue = None
        queryType = None

        return (queryType, queryValue)

#==========================================================
# Estimate recurring charge for Sub
def CmdPayNow_subscriberestimaterecurringcharge(lclDCT, options, RESTInst, cmdLineInput):
        # *** lclDCT[] has all the values.
        # Loop replaced with below commands for Python3 migration.
        externalId = lclDCT['externalId']
        outputFileName = lclDCT['outputFileName']
        # End of local variables setup.
        
        # Item should exist.  Skip if in a multi-request.
        if not lclDCT['noChecks'] and lclDCT['subQueryType'] != 'MultiRequestIndex':
                # Check subscriber or subscription
                if externalId not in TRACK.subscriberTracking:
                        print('ERROR: ' + REST_UTIL.subUrl + ' with external ID "' + externalId + '" is not defined.  Exiting')
                        sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Execute primitive
        status,response = REST_UTIL.subscriberEstimateRecurringCharge(RESTInst,
                externalId,
                queryType=lclDCT['subQueryType'],
                now=lclDCT['lclStartTime'],
                eventPass=lclDCT['eventPass'],
                apiEventData=lclDCT['apiEventData'],
                )
                #filterName=filterName,
        
        # If expected to pass, then output data
        if lclDCT['eventPass']:
         # If saving data and not redirecting the output, then force to stdout
         if (not lclDCT['saveData']) and (not outputFileName): outputFileName = 'stdout'

         # If MDC then need to convert to XML.  If already XML then try will fail and we just want to use string as-is.
         try:
                respData = str(response.printElementBasedXml())
         except:
                respData = str(response)

         # If supposed to save data to variables then do that here
         if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, 'Subscriber', respData)
         
         # If supposed to store output then write to where the caller wanted it to go
         if outputFileName and outputFileName.lower() != 'none': CSVQA.processDataToOutput(respData, outputFileName)
        
        # Query nothing
        queryValue = None
        queryType = None

        return (queryType, queryValue)

