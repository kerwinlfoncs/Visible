#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:24
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:06
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:34:52

# from builtins import str
# from builtins import str
import qa_utils as QAUTILS
import common_mdc as COMMON
import QA_subscriber_management_restv3
import restV3
import sys
import optparse




def main():



        diameterRestConfig = QAUTILS.getDiameterRestConfig()
        V3Inst = restV3.RestClient(diameterRestConfig.get('REST', 'restServer'), diameterRestConfig.get('REST', 'restPort'))
        QA_subscriber_management_restv3.setVersion('REST')
        COMMON.disableOutput = True



        parser = optparse.OptionParser()
        parser.add_option("-a", "--action", action='store', type='string', default= 'list')
        parser.add_option("-s", "--sessionId", action='store', type='string', default=None)
        parser.add_option("-c", "--streamCursor", action='store', type='string', default=None)
        parser.add_option("-t", "--routingType", action='store', type='string', default=None)
        parser.add_option("-v", "--routingValue", action='store', type='string', default=None)

        args = sys.argv[1:]
        (options, args) = parser.parse_args(args=args)

        if args:
                print('Unexpected arguments found: ' + str(args))
                sys.exit('Exiting due to failures')





      
        action = options.action
        sessionId = options.sessionId
        streamCursor = options.streamCursor
        routingType = options.routingType
        routingValue = options.routingValue





        if action == 'list':
            if not sessionId and not streamCursor:
                response, sessionIdList = restV3.queryEventStreamingSessionList(V3Inst, routingType=routingType, routingValue=routingValue, eventPass= True)
                print('SessionIdList: ' + str(sessionIdList))
            else:
                print('Requires no SessionId and no Stream Cursor')
                sys.exit('Exiting due to failures')

        elif action == 'query':
            if sessionId and not streamCursor:
                response, sessionId, streamCursor = restV3.queryEventStreamingSession(V3Inst, queryValue=sessionId, routingType=routingType, routingValue=routingValue, eventPass = True)
                print('SessionId: ' + sessionId)
                print('StreamCursor: ' + streamCursor)
            else:
                print('Requires a SessionId and no Stream Cursor')
                sys.exit('Exiting due to failures')

        elif action == 'create':
           if sessionId:
               response = restV3.createEventStreamingSession(V3Inst, sessionId=sessionId, streamCursor=streamCursor, routingType=routingType, routingValue=routingValue, eventPass=True)
               print('SessionId ' + sessionId + ' has been created')
           else:
               print('Requires a SessionId')
               sys.exit('Exiting due to failures')

        elif action == 'modify':
            if sessionId:
                response = restV3.modifyEventStreamingSession(V3Inst, queryValue=sessionId, streamCursor=streamCursor, routingType=routingType, routingValue=routingValue, eventPass=True)
                print('SessionId ' + sessionId + ' has been modified')
            else:
                print('Requires a SessionId')
                sys.exit('Exiting due to failures')

        elif action == 'delete':
            if sessionId and not streamCursor:
                response = restV3.deleteEventStreamingSession(V3Inst, sessionId=sessionId, routingType=routingType, routingValue=routingValue, eventPass=True)
                print('SessionId ' + sessionId + ' has been deleted')
            else:
                print('Requires a SessionId and no Stream Cursor')
                sys.exit('Exiting due to failures')

        else:
            print('Do not understand request')
            sys.exit('Exiting due to failures')
        

if __name__ ==  '__main__':
    main()
