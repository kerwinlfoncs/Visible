#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:41:22
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:37:03
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:20
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


# from builtins import str
# from builtins import str
import sys
import os
import time
import re
import data_container as MDC
import commonDefs
# Check if the data_container_defs.py needs to be re-created
import data_container_defs as MDCDEFS
import timeToMDCtime as MDCTIME
from xml.etree import ElementTree
import log_errors as LOGGER

logger = None
ID_MASK    = 0x0000FFFFFFFFFFFF
TYPE_MASK  = 0xFFFF000000000000
TYPE_SHIFT = 48
disableOutput = False

# Define results directory name
resultsDir = 'results'

# Helper for creating "attr" MDCs for extended objects
#=============================================================
def createAttr(containerName, fieldDct=None):
    if not re.search('Extension$', containerName) and containerName != 'MtxAddressData' and 'Romcard' not in containerName:
        containerName += 'Extension'

    print("containerNamecontainerNamecontainerName=", containerName)
    # Create container for custom attribute extension
    if hasattr(MDCDEFS, 'k' + containerName + 'MdcDesc'):
        try:
            print("fieldName=",containerName)
            mdcDesc = getattr(MDCDEFS, 'k' + containerName + 'MdcDesc')
            attrMdc = getattr(mdcDesc, 'create')()
        except Exception:
            print('Error creating container ' + containerName)
            return None
    else:
        return None

    # If just creating a custom object 'attr' with no set fields, return now
    if fieldDct is None:
        return attrMdc

    # Set fields in fieldDct
    for fieldName in fieldDct:
        try:
            print("fieldName=", fieldName)
            attrMdc.setUsingName(fieldName, fieldDct[fieldName])

        except Exception:
            print('Error setting field key ' + fieldName + ' on container ' + containerName)
            return attrMdc

    return attrMdc

# Helper for getting ResourceId for threshold based on ThresholdId- note that this assumes only one instance
#===============================================================================
def getResourceId(walletMdc, thresholdId):
    try:
        tree = ElementTree.XML(walletMdc.printXml())
    except Exception as inst:
        print("Unexpected error reading wallet query response: %s" % (inst))
        return None

    balanceArray = tree.find('array')
    if len(balanceArray) == 0:
        return None

    balances = balanceArray.findall('struct')
    for balance in balances:
        balanceArrays = balance.findall('array')
        for array in balanceArrays:
            if array.attrib['name'] == 'ThresholdArray':
                thresholds = array.findall('struct')
                for threshold in thresholds:
                    thresholdFields = threshold.findall('field')
                    for field in thresholdFields:
                        if field.attrib['name'] == 'ThresholdId' and str(field.attrib['value']) == str(thresholdId):
                            baseContainer = balance.find('container')
                            for field2 in baseContainer.findall('field'):
                                if field2.attrib['name'] == 'ResourceId':
                                    return field2.attrib['value']

    return None

# Legacy helper code for creating a subscriber create profile (Can just specify individual fields on subscriber create)
#===============================================================================
def createSubscriberProfileInfo(type=None, fname=None, lname=None, notifyE=None, email=None, notifyP=None, phone=None,
        specialDateList=None, timeZone=None, attr=None):
    profTemplate = {}
    profTemplate['firstName'] = fname
    profTemplate['lastName'] = lname
    profTemplate['contactEmail'] = email
    profTemplate['contactPhoneNumber'] = phone
    profTemplate['timeZone'] = timeZone
    profTemplate['attr'] = attr
    notificationState = 0
    if notifyE:
        notificationState += 1
    if notifyP:
        notificationState += 2
    profTemplate['notificationPreference'] = notificationState
    return profTemplate

# Legacy helper code for creating a subscriber modify profile (Can just specify individual fields on subscriber modify)
#===============================================================================
def createModifySubscriberProfileInfo(type=None, fname=None, lname=None, notifyE=None, email=None,
        notifyP=None, phone=None, specialDateList=None, timeZone=None, attr=None):
    profTemplate = {}
    profTemplate['firstName'] = fname
    profTemplate['lastName'] = lname
    profTemplate['contactEmail'] = email
    profTemplate['contactPhoneNumber'] = phone
    profTemplate['timeZone'] = timeZone
    profTemplate['attr'] = attr
    notificationState = 0
    if notifyE:
        notificationState += 1
    if notifyP:
        notificationState += 2
    profTemplate['notificationPreference'] = notificationState
    return profTemplate

# Debug subman operation failure
#===============================================================================
def debugFailure(method='', status=0, msg=None, shouldPass=True, response=None):
    # If we don't care, then always return true
    if shouldPass == None: return True
    
    return checkResponse(method=method, status=status, msg=msg, success=False, shouldPass=shouldPass, response=response)

# Debug subman operation success
#===============================================================================
def debugSuccess(method='', shouldPass=True, response=None):
    # If we don't care, then always return true
    if shouldPass == None: return True
    
    return checkResponse(method=method, success=True, shouldPass=shouldPass, response=response)

# Handles the debugging of subman operation success/failure
#===============================================================================
def checkResponse(method='', status=0, msg=None, success=True, shouldPass=True, response=None):
    global disableOutput
    global logger

    if not logger: logger = LOGGER.clErrors(os.getcwd())
    
    path = os.getcwd()
    testName = path.split('/')[-1]
    if success:
        if shouldPass:
            # Expected success- log in summary
            if not disableOutput:
                logger.printSummary(path, testName + '_' + method + ' ==> Passed')
            return True
        else:
            # Unexpected success- log in summary
            if not disableOutput:
                logger.printSummary(path, testName + '_' + method + ' ==> Failed (Unexpected Success)')
            sys.exit(method + " ==> !!! REST call unexpectedly succeeded !!!")
    else:
        # Output debugging information
        printReturnMsg(method, msg, status)
        if not disableOutput:
            logger.printRes(path, 'debug_REST_' + testName + '.txt', testName + '_' + method + ' ==> Failed')

            # Give more details on failure if there is msg
            if msg:
                logger.printRes(path, 'debug_REST_' + testName + '.txt',  msg)

        # Unexpected failure- log in summary
        if shouldPass:
            if not disableOutput:
                # Unexpected failure
                logger.printSummary(path, testName + '_' + method + ' ==> Failed')
            
            # If an eligibility failure, then print entire response.
            # This helps debugging.
           # if str(msg).count('eligibility failure') and response: print(response)
            
            # Exit
            #sys.exit(method + " ==> !!! REST call failed !!!")

        # Expected failure- log in summary
        if not disableOutput:
            logger.printSummary(path, testName + '_' + method + ' ==> Passed (Expected Failure)')
        return True

# Output information from REST request
#===============================================================================
def printReturnMsg(method, msg, status):
    print('=========================================')
    print('REST Call return message!')
    print('=========================================')
    print('method = ' + str(method))
    print('msg = ' + str(msg))
    print('status = ' + str(status))
    print('=================END========================')

# Fetch subscriber's devices for outputting them in saveMDC calls
#===============================================================================
def getDeviceArray(subscriberResponse):
    try:
        tree = ElementTree.XML(subscriberResponse)
    except Exception as inst:
        print("Unexpected error reading subscriber query response: %s" % (inst))
        return None

    deviceArray = None
    oidArray = tree.find('array')

    if oidArray is None:
        return None

    if oidArray.attrib['name'] == 'DeviceIdArray':
        deviceArray = []
        for oid in oidArray.findall('value'):
            deviceArray.append(oid.text)

    return deviceArray



# Output subscriber/group offers (must specify which with objectType) for validate_balances
#===============================================================================
def outputOfferInfo(path, testName, queryType, queryValue, objectType, mdc, debugData= '', queryTime=None):
    global resultsDir
    validateBalsLocation = path + '/' + resultsDir + '/validate_balances.txt'

    # Check if validate_balances file already exists.
    createValidateBalsFile = False
    try:
        validateBalsFile = open(validateBalsLocation, 'r')
        validateBalsFile.close()
    except IOError:
        createValidateBalsFile = True
        pass

    # If validate_balances does not yet exist, create it.
    if createValidateBalsFile:
        validateBalsFile = open(validateBalsLocation, 'w')

    # If validate_balances already exists, append to it.
    else:
        validateBalsFile = open(validateBalsLocation, 'a')

    validateBalsFile.write('----------------------------------------------------------------------\n')
    validateBalsFile.write('------TestName = ' + testName + '  - ' + str(objectType) + ' by ' + str(queryType) + \
        '==> ' + str(queryValue) + ' ----' + '\n')
    validateBalsFile.write('------QueryTime = ' + str(queryTime) + '\n')
    validateBalsFile.write('------EventInfo = ' + debugData + '\n')
    validateBalsFile.write('----------------------------------------------------------------------\n')

    try:
        tree = ElementTree.XML(mdc)

        arrays = tree.findall('array')
        purchasedOfferArray = None
        for array in arrays:
            if array.attrib['name'] == 'PurchasedOfferArray':
                purchasedOfferArray = array

        validateBalsFile.write('\n')

        if purchasedOfferArray is None:
            validateBalsFile.write(testName + ': No associated offers\n\n')

        else:
            # PurchasedOfferArray found, output information for each offer
            for offer in purchasedOfferArray.findall('struct'):
                validateBalsFile.write('Purchased Offer\n')
                offerFields = offer.findall('field')

                # OfferId
                for field in offerFields:
                    if field.attrib['name'] == 'ProductOfferId':
                        validateBalsFile.write(testName + ': OfferId: ' + field.attrib['value'] + '\n')

                # StartTime
                for field in offerFields:
                    if field.attrib['name'] == 'StartTime':
                        validateBalsFile.write(testName + ': StartTime: ' + field.attrib['value'] + '\n')

                # EndTime
                for field in offerFields:
                    if field.attrib['name'] == 'EndTime':
                        validateBalsFile.write(testName + ': EndTime: ' + field.attrib['value'] + '\n')

                # PurchaseTime
                for field in offerFields:
                    if field.attrib['name'] == 'PurchaseTime':
                        validateBalsFile.write(testName + ': PurchaseTime: ' + field.attrib['value'] + '\n')

                validateBalsFile.write('\n')

    except Exception as inst:
        print("Unexpected error reading query response: %s" % (inst))
        pass

    validateBalsFile.close()

# Output balances in wallet for validate_balances
#===============================================================================
def outputBalanceInfo(path, testName, queryType, queryValue, objectType, mdc, debugData= ''):
    global resultsDir
    validateBalsLocation = path + '/' + resultsDir + '/validate_balances.txt'

    # Check if validate_balances file already exists.
    createValidateBalsFile = False
    try:
        validateBalsFile = open(validateBalsLocation, 'r')
        validateBalsFile.close()
    except IOError:
        createValidateBalsFile = True
        pass

    # If validate_balances does not yet exist, create it.
    if createValidateBalsFile:
        validateBalsFile = open(validateBalsLocation, 'w')

    # If validate_balances already exists, append to it.
    else:
        validateBalsFile = open(validateBalsLocation, 'a')

    try:
        tree = ElementTree.XML(mdc)

        arrays = tree.findall('array')
        balanceArray = None
        for array in arrays:
            if array.attrib['name'] == 'BalanceArray':
                balanceArray = array

        # No balances found
        if balanceArray is None:
            validateBalsFile.write(testName + ': No associated balances\n')

        else:
            # Balances are present, so output them.
            for balance in balanceArray.findall('struct'):
                periodic = False

                # If periodic balance, output periodic-specific information
                if balance.attrib['name'] == 'MtxBalanceInfoPeriodic':
                    periodic = True
                    parseBalancePeriodInfo(balance, validateBalsFile, testName)

                # Output balance info common to simple and periodic balances
                parseBasicBalanceInfo(balance, validateBalsFile, testName, periodic)
                validateBalsFile.write('\n')

    except Exception as inst:
        print("Unexpected error reading query response: %s" % (inst))
        pass

    validateBalsFile.close()

# Output balance info common to simple and periodic balances for validate_balances
#===============================================================================
def parseBasicBalanceInfo(balance, file, testName, periodic):
    if not periodic:
        file.write('Simple Balance\n')

    basicBalanceInfo = balance.find('container')
    balanceFields = basicBalanceInfo.findall('field')

    for field in balanceFields:
        # Name
        if field.attrib['name'] == 'Name':
            file.write(testName + ': Name: ' + field.attrib['value'] + '\n')

    for field in balanceFields:
        # CreditLimit
        if field.attrib['name'] == 'CreditLimit':
            file.write(testName + ': Credit Limit: ' + field.attrib['value'] + '\n')

    for field in balanceFields:
        # Amount
        if field.attrib['name'] == 'Amount':
            file.write(testName + ': Amount: ' + field.attrib['value'] + '\n')

    for field in balanceFields:
        # ReservedAmount
        if field.attrib['name'] == 'ReservedAmount':
            file.write(testName + ': Reserved Amount: ' + field.attrib['value'] + '\n')

    for field in balanceFields:
        # UnreservedAmount
        if field.attrib['name'] == 'AvailableAmount':
            file.write(testName + ': Available Amount: ' + field.attrib['value'] + '\n')

    for field in balanceFields:
        # ThresholdLimit 
        if field.attrib['name'] == 'ThresholdLimit':
            file.write(testName + ': Threshold Limit: ' + field.attrib['value'] + '\n')

    for field in balanceFields:
        # StartTime
        if field.attrib['name'] == 'StartTime':
            file.write(testName + ': Start Time: ' + field.attrib['value'] + '\n')

    for field in balanceFields:
        # UnreservedAmount
        if field.attrib['name'] == 'EndTime':
            file.write(testName + ': End Time: ' + field.attrib['value'] + '\n')

# Output balance info exclusive to periodic balances (i.e. period info) for validate_balances
#===============================================================================
def parseBalancePeriodInfo(balance, file, testName):
    file.write('Periodic Balance\n')
    balanceArrays = balance.findall('array')
    for element in balanceArrays:
        if element.attrib['name'] == 'BalancePeriodArray':
            periods = element.findall('struct')
            periodCount = 0
            for period in periods:
                periodCount += 1
                fields = period.findall('field')
                for field in fields:
                    if periodCount == 1:
                        if field.attrib['name'] == 'StartTime':
                            periodStart = field.attrib['value']
                            file.write(testName + ': Period ' + str(periodCount) + ' Start: ' + str(periodStart) + '\n')
                        if field.attrib['name'] == 'EndTime':
                            periodEnd = field.attrib['value']
                            file.write(testName + ': Period ' + str(periodCount) + ' End: ' + str(periodEnd) + '\n')
                            file.write(testName + ': Period ' + str(periodCount) + ' Amount: ' + str(amount) + '\n')
                    if field.attrib['name'] == 'Amount':
                        amount = field.attrib['value']
                        if amount != '0.0' and periodCount != 1:
                            file.write(testName + ': Period ' + str(periodCount) + ' Amount: ' + str(amount) + '\n')


# Determine BalanceId based on BalanceTemplateId
#===============================================================================
def getBalanceIdFromTemplateId(templateId):
    # Main processing starts here
    global ID_MASK
    global TYPE_MASK
    global TYPE_SHIFT
    idValue = int(templateId)

    objType = (idValue & TYPE_MASK) >> TYPE_SHIFT
    objId = (idValue & ID_MASK)

    return str(objId)

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

