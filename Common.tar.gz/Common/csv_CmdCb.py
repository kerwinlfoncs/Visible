#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:35:23
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:35:23
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:35:22
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
from __future__ import print_function
import sys
import csv_qa as CSVQA
import cbPrim as CBPRIM

#==========================================================
def CmdCbQuery(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Verify something was input for the object ID
        if lclDCT['ACTION'] != 'cbQueryOfferList' and not lclDCT['cbId']:
                print('ERROR: cbId parameter must be entered and be non-zero for command: ' + lclDCT['ACTION'])
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Execute primitive
        retCode = CBPRIM.cbQuery(lclDCT['ACTION'], lclDCT['cbId'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])

        # Query nothing
        queryType = queryValue = None
        
        return (queryType, queryValue)


