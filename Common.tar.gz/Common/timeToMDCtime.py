#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:36
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:17
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:00
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

# NOTE:  Please do not import any QA test-specific files here.  This file is used 
#        as part of the debug log analysis script and needs to run stand-alone
#        (i.e. only using Python libraries).



# from builtins import str
# from builtins import str
from past.utils import old_div
import time
import calendar
import re
from datetime import date, datetime
import subprocess
import sys
from pytz import timezone
#import pytz, datetime
from dateutil.parser import parse
from dateutil.tz import *
global convert
convert=True

from dateutil.relativedelta import relativedelta
#systemTimeZone = 'Asia/Hong_Kong' #Etc/UTC'
systemTimeZone = 'Etc/UTC'
timeFormat = '%Y-%m-%dT%H:%M:%S'
timeFormatZ = '%Y-%m-%dT%H:%M:%S%Z'
timeFormatz = '%Y-%m-%dT%H:%M:%S%z'

# Flag signaling whether spoof time is active
spoofTimeEnabled = False

#===============================================================================
# this function will change the time in a date time :2011-31-12T12:30:15 and clockTime 03:44:51
#the return will be :2011-31-12T03:44:51
def adjustClock(timeIn , clockTime):
    startTimeChar = timeIn.split('T') 
    startTime = startTimeChar[0] + 'T'
    startTime = startTime + clockTime
    return (getTime(startTime=startTime))

#===============================================================================
# Add decimal ending for timezone-qualified REST calls... timezone qualification is ignored otherwise.
def addDecimal(timeStr):
    x = parse(timeStr)
    dtStr =  x.strftime("%Y-%m-%dT%H:%M:%S.000000%z")
    #print dtStr
    if dtStr[-5:] == '+0000':
        dtStr = dtStr[:-5] + 'Z'
    elif dtStr[-5] in '+-':
        dtStr = dtStr[:-2] + ':' + dtStr[-2:]
    return dtStr

#===============================================================================
# Remove the decimal ending (which was added to support timezone qualification) for REST GET calls.
# Bad URL otherwise...
def stripDecimal(timeStr):
    time0 = parse(timeStr)
    timeStr = time0.strftime(timeFormat)
    return timeStr

#===============================================================================
def addYear(startTime , delta):
    months = 12 * delta
    return(getDaysFromAddingMonth(startTime , months))

#===============================================================================
#return time2 - time1 in desired units
def timeDelta(time1, time2, unit='sec'):
    t1 = parse(time1)
    t2 = parse(time2)
    delta = (t2 - t1)
    #print 'timeDelta: t2 = ' + str(t2) + ', t1 = ' + str(t1) + ', delta = ' + str(delta)
    
    # Split into array; set to integers
    # May get X days, hours:min:sec
    daysHours = str(delta).split(',')
    if len(daysHours) == 1: 
        days = 0
        timeUnits = str(daysHours[0]).split(':')
    else:
        days = int(daysHours[0].split(' ')[0])
        timeUnits = str(daysHours[1]).split(':')
        
    # Set to integers
    hours   = int(timeUnits[0])
    minutes = int(timeUnits[1])
    seconds = int(timeUnits[2].split(".")[0])
        
    # Convert the delta time to the desired units.
    if unit.lower().startswith('sec'):
        # Go to seconds
        delta = (days * 86400) + (hours * 3600) + (minutes * 60) + seconds
    
    elif unit.lower().startswith('min'):
        # Go to min
        delta = (days * 1440) + (hours * 60) + minutes + (old_div(seconds, 60))
    
    elif unit.lower().startswith('hour'):
        # Go to hour
        delta = (days * 24) + hours + (old_div(minutes, 60)) + (old_div(seconds, 3600))
        
    else:
        print('ERROR:  timeDelta only accepts sec/min/hour as units.  API called with ' + str(unit))
        sys.exit("Exiting due to errors")
    
    # Return delta amount
    return delta
#===============================================================================
#return True for time2 > time1 , otherwise false
def checkIfTime2GreaterOrEqualTime1(time1, time2):
    import datetime
    t1 = parse(time1)
    t2 = parse(time2)
    delta= (t2 - t1)
    zeroSeconds = datetime.timedelta(seconds=0)
    #print ''
    #print 't1 = ', str(t1)
    #print 't2 = ', str(t2)
    #print 'Delta = ', str(delta)
    #print 'zeroSeconds = ', str(zeroSeconds)
    return delta >= zeroSeconds

#===============================================================================
#return True for time2 > time1 , otherwise false
def checkIfTime2GreaterTime1(time1, time2):
    import datetime
    t1 = parse(time1)
    t2 = parse(time2)
    delta= (t2 - t1)
    zeroSeconds = datetime.timedelta(seconds=0)
    #print ''
    #print 't1 = ', str(t1)
    #print 't2 = ', str(t2)
    #print 'Delta = ', str(delta)
    #print 'zeroSeconds = ', str(zeroSeconds)
    return delta > zeroSeconds

#===============================================================================
def clearSpoofTime():
    global spoofTimeEnabled
    
    cmd = 'vtime --delete'
    print('cmd issued: ' + cmd)
    subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)

    # Clear global
    spoofTimeEnabled = False

#===============================================================================
#this is used in qa_utils 
# If a time is not qualified, convert it to UTC, unless it's for Diameter, in which case conversion is forced
def convertTime(timeStr, forceUtc=False, restVersion="MDC"):
    global convert

    # If the time must be converted to UTC (e.g. diameter), do it
    if forceUtc:
        return getUTCTime(timeStr, forceUtc)

    # If the flag to convert is enabled (the default) and the time value is not qualified, do it
    if convert and not isQualified(timeStr):
        return getUTCTime(timeStr, forceUtc)

    if restVersion == "REST" and isQualified(timeStr):
        return addDecimal(timeStr)

    # Otherwise, return as is
    return timeStr

#===============================================================================
#function takes an unqualified time and returns this format:2013-01-13T22:10:12-08:00
#convertTimeZones("2013-01-14T01:10:12", "US/Eastern", "US/Pacific")
def convertTimeZones(startTime, fromZone, toZone):
    import pytz
    if not isQualified(startTime):
        startTime = qualifyNaiveTime(startTime, fromZone)
    local = timezone(fromZone)
    zone2 =  timezone(toZone)
    inTime = parse(startTime) #datetime.strptime(startTime, fmt)
    time = inTime.astimezone(zone2)
    startTimeZone2Formatted = time.strftime(timeFormatz)
    return startTimeZone2Formatted


#===============================================================================
def firstDayOfDate(startTime):
    month = startTime[5:7]
    year = startTime[0:4]
    startTimeB = year + '-' + month + '-' + '01' + startTime[10:29]
    return startTimeB

#===============================================================================
#get the date of the next weekday
#input is a valid 3-letter weekday : Mon, Tue, etc..
#return: date of that weekeday
def getDateOfWeekday(dayOfWeek , startTime = 0 , numOfWeeks = 0):
    targetIndex = 0
    daysLeft = 0
    daysOfWeek = {'Mon':'Tue' , 'Tue':'Wed', 'Wed':'Thu' , 'Thu':'Fri', 'Fri':'Sat' , 'Sat':'Sun', 'Sun':'Mon'}
    if (startTime == 0):
        startTime = getTime(0)
    t = parse(startTime)
    dayOffset = t.strftime("%A")[0:3] #to grab fir 3 letter like Thu
    iter = 1
    nextDay = dayOffset
    if dayOfWeek not in daysOfWeek:
        return startTime
    
    while True:
        t2 = daysOfWeek[nextDay]
        if t2 == dayOfWeek:
            break
        iter += 1
        nextDay = t2

    if numOfWeeks > 0:
        daysLeft = (numOfWeeks - 1 ) * 7  #get the number of days for the other weeks

    iter += daysLeft 
    newDay = getTime(iter, 'day',startTime)
    return newDay

#===============================================================================
#assuming always gets time like 2011-02-12T02:12:34
#this function will add x month to a time
#this function returns a float :1362042612.0
def getDaysFromAddingMonth(timeStamp , delta):
    return getTime(delta=delta , timeUnit='month' , startTime=timeStamp , extraSecs=0)

#===============================================================================
def getLocalTimeZoneMtxFormat():
    # Get seconds offset from UTC
    secOffset = time.timezone

    # offset time is opposite what timezone returns
    if secOffset >=0: offsetString = '-'
    else:             offsetString = '+'

    # Get hour offset
    hour = str(old_div(abs(secOffset), 3600))

    # Get the seconds offset
    sec = str(abs(secOffset) % 3600)

    # Return the string
    #print 'Returning time zone ' + offsetString + hour.zfill(2) + ':' + sec.zfill(2)
    return offsetString + hour.zfill(2) + ':' + sec.zfill(2)

#===============================================================================
# the input can be either float or a %Y-%m-%dT%H:%M:%S format
def getTimeOfDay(startTime, hour=0, min=0, sec=0):
    # Get the time + offset
    time = getTime(0, startTime=startTime)
#    print 'in getTimeOfDay, time=' + time 

    # Split the time, using the date separator as the split character
    arr = time.split('-')

    # Want timezone.  Splitting on a character that may be part of the timezone makes this a bit tricky.
    # If there is a "+" character, then the timezone
    if time.endswith('Z'):
        timeZone = 'Z'
    else:
        tzl = time.split('+')
        if len(tzl) > 1:
            tzl = time.split('+')
            # Timezone is the second item in this list
            timeZone = '+' + tzl[1]
        else:
            # Timezone is negative, so take from the 4th item in the previous split
            timeZone = '-' + arr[3]

    # Get time into strings
    hour = '{0:0>2}'.format(str(hour))
    min  = '{0:0>2}'.format(str(min))
    sec  = '{0:0>2}'.format(str(sec))
    
    # Get formatted time
    nextPeriod = arr[0] + '-' + arr[1] + '-' + arr[2][0:3] + hour + ':' + min + ':' + sec + timeZone

    return nextPeriod
#===============================================================================
# the input can be either float or a %Y-%m-%dT%H:%M:%S format
def getPeriod(delta=0 , timeUnit='none' , startTime=0 , extraSecs=0):
    # Get the time + offset
    time = getTime(delta, timeUnit, startTime, extraSecs)
#    print 'in getPeriod, time=' + time + ', timeunit=' + str(timeUnit)

    # Split the time, using the date separator as the split character
    arr = time.split('-')

    # Get the time part (skip over date and 'T' character).
    # Make sure to only grab time (timezone may fall into this if the offset is positive).
    timeArr = arr[2][3:11]
#    print 'in getPeriod, timeArr=' + str(timeArr)
#    print 'hour=' + timeArr[0:2]
#    print 'min=' + timeArr[3:5]
#    print 'sec=' + timeArr[6:8]

    # Want timezone.  Splitting on a character that may be part of the timezone makes this a bit tricky.
    # If there is a "+" character, then the timezone
    if time.endswith('Z'):
        timeZone = 'Z'
    else:
        tzl = time.split('+')
        if len(tzl) > 1:
            tzl = time.split('+')
            # Timezone is the second item in this list
            timeZone = '+' + tzl[1]
        else:
            # Timezone is negative, so take from the 4th item in the previous split
            timeZone = '-' + arr[3]

    # Get the start of the next period
    if timeUnit.startswith('day') or timeUnit.startswith('week'):
        nextPeriod = arr[0] + '-' + arr[1] + '-' + arr[2][0:3] + '00:00:00' + timeZone

    elif timeUnit.startswith('month'):
        nextPeriod = arr[0] + '-' + arr[1] + '-' + '01T00:00:00' + timeZone

    elif timeUnit.startswith('year'):
        nextPeriod = arr[0] + '-01-01T00:00:00' + timeZone

    elif timeUnit.startswith('hour'):
        nextPeriod = arr[0] + '-' + arr[1] + '-' + arr[2][0:3] + timeArr[0:2] + ':00:00' + timeZone

    elif timeUnit.startswith('min'):
        nextPeriod = arr[0] + '-' + arr[1] + '-' + arr[2][0:3] + timeArr[0:2] + ':' + timeArr[3:5] + ':00' + timeZone

    else:  # assume seconds
        nextPeriod = arr[0] + '-' + arr[1] + '-' + arr[2][0:3] + timeArr[0:2] + ':' + timeArr[3:5] + ':' + timeArr[6:8] + timeZone

    return nextPeriod
#===============================================================================
def getTextTimeFromDiameterTime(timestamp):
#    print timestamp
    startTimeChar =  time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(timestamp - 2208988800))
    return startTimeChar

#===============================================================================
# This function will add or substract time from the currentTime
# Input should be the number of timeUnit(s) to add or substract from now()
# The default for timeUnit assumes the delta is in secs
# the input can be either float or a %Y-%m-%dT%H:%M:%S format
def getTime(delta=0 , timeUnit='none' , startTime=0 , extraSecs=0, addTz=True, tz = None, usec = False):
    #print 'delta=',delta, ' timeUnit=', timeUnit, ' startTime=', startTime
    global timeFormat
    timeZone = None
    import pytz

    if (startTime == 0):   #this will be localize to the local zone like PST for CA
        startTime = datetime.now(tzlocal())
        timeZone = startTime.tzinfo  #save the timezone
        startTime = startTime.strftime(timeFormatz)
        
    startTime = parse(startTime)

    if not startTime.tzinfo:
        # Input is TZ-naive; teach it about given TZ or system TZ.
        tzinfo = pytz.timezone(tz) if tz else pytz.timezone(systemTimeZone)
        startTime = tzinfo.localize(startTime)

    elif tz:
        # Input is TZ-aware; convert it to given TZ if possible.
        tzinfo = pytz.timezone(tz)
        startTime = tzinfo.normalize(startTime.astimezone(tzinfo))
    else:
        tzinfo = None

    if delta == 0:
        pass
    elif timeUnit.startswith('year'):
        startTime += relativedelta(years=delta)
    elif timeUnit.startswith('month'):
        startTime += relativedelta(months=delta)
    elif timeUnit.startswith('week'):
        startTime += relativedelta(weeks=delta)
    elif timeUnit.startswith('day'):
        startTime += relativedelta(days=delta)
    elif timeUnit.startswith('hour'):
        startTime += relativedelta(hours=delta)
    elif timeUnit.startswith('min'):
        startTime += relativedelta(minutes=delta)
    elif timeUnit.startswith('sec') or timeUnit == 'none':
        startTime += relativedelta(seconds=delta)
    startTime += relativedelta(extraSecs)
    if tzinfo:
     # Normalize using operating TZ.
        startTime = tzinfo.normalize(startTime)

    # Convert to string.
    global timeFormat
    dtStr = startTime.strftime(timeFormat + '.%%06u%z')
    dtStr = dtStr % (startTime.microsecond)
    if dtStr[-5:] == '+0000':
        dtStr = dtStr[:-5] + 'Z'
    elif dtStr[-5] in '+-':
        dtStr = dtStr[:-2] + ':' + dtStr[-2:]
    return dtStr

#===============================================================================
# Fetch the timezone suffix from a qualified time string
def getTimeZone(timeStr):
    x = parse(timeStr)
    tz = x.strftime("%z")
    if tz != None:
        return  tz[:-2] + ':' + tz[-2:]
    return ''
#===============================================================================

# Convert unqualified time to UTC based on system time zone
def getUTCTime(startTime, forceUtc=False):
    import pytz
    global systemTimeZone
    global timeFormatZ, timeFormatz,timeFormat

    #print 'START:================================', startTime

    if type(startTime) is not type('a'):  #convert a timestamp
         x = pytz.utc.localize(datetime.utcfromtimestamp(startTime))
         #print 'x= ',  x.strftime(timeFormat+"Z")
         return x.strftime(timeFormat+"Z")

    elif isQualified(startTime):   #convert a qualified time
        if not forceUtc:
            return startTime
        inTime = parse(startTime)
        utc_dt = inTime.astimezone(pytz.utc)
        y = parse(str(utc_dt))
        #print 'getUTCTime:', y.strftime(timeFormat+"Z")
        return y.strftime(timeFormat+"Z")
        
    else:   #convert a non-qualified time
        x = convertTimeZones(startTime, fromZone = systemTimeZone, toZone='UTC')
        y = parse(x)
        return y.strftime(timeFormat+"Z")
        
#===============================================================================
def getVTime(timeStr):
    if not re.search('float' , str(type(timeStr))):
        time1 = parse(timeStr)
        timeStr =  calendar.timegm(time1.timetuple()) #returns float like :1298664012.0

    return time.strftime('%m%d%Y%H%M', time.gmtime(timeStr))


#===============================================================================
# Check if time is qualified with a timezone suffix
def isQualified(timeStr):
    #print 'IN:', timeStr
    if timeStr == None : return False

    if type(timeStr) == type('a'):
       startTime = parse(timeStr)
       if (startTime.tzinfo) != None:
           return True
    return False   #we got a floas timestamp or not qualified

#===============================================================================
# Check if time is UTC
def isUTC(timeStr):
    if re.search(utcSuffix, timeStr):
        return True
    return False

#===============================================================================
#converts an unqualified time to a time in the zone specified in the 2nd param
#output ex: to utc: 2012-03-11T01:59:59Z  or to 'US/Pacific':2012-03-11T01:59:59-0800
def qualifyNaiveTime(startTime, inZone = systemTimeZone):
    if startTime == None : return
    if isQualified(startTime): return startTime
    else:
        time1 = parse(startTime)
        if inZone == 'UTC': 
            return time1.strftime(timeFormat+"Z")

        qualifyInZone = timezone(inZone)
        #print 'inZone=', inZone, ' qualifyInZone=', qualifyInZone
        time2 = qualifyInZone.localize(time1)
        time = time2.strftime(timeFormat)
        tz =  time2.strftime("%z")
        tz = tz[:-2] + ':' + tz[-2:]
        return time+tz

#workaround so that we dont break tests          
def convertNaiveTimetoQualified(startTime, inZone, toZone):
    return qualifyNaiveTime(startTime, inZone)
#===============================================================================
def spoofTime(delta=0, timeUnit='none', startTime=0, sleep=0):
    global spoofTimeEnabled
    
    # Advance the time by the necesssary interval
    advancedTime = getTime(delta, timeUnit, startTime)

    # Convert to UTC relative to system time
    utcTime = getUTCTime(advancedTime, forceUtc=True)
    #print 'utcTimeutcTime=', utcTime, ' and utcTime[0:-1]:', utcTime[0:-1]
    # Format for vtime
    spoofTime = getVTime(utcTime[0:-1])

    cmd = 'vtime --set ' + str(spoofTime) + ' -r '
    print('cmd issued: ' + cmd)
    subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    if sleep != 0:
        print('Sleeping for ' + str(sleep) + ' seconds')
        time.sleep(sleep)
        print('Done sleeping')

    # Set global
    spoofTimeEnabled = True

    return getTime(delta, timeUnit, startTime)

#===============================================================================
# Remove timezone suffix from a qualified time strin
def stripTimeZone(timeStr):
    x = parse(timeStr)
    return x.strftime(timeFormat)
#================================================================================
#get the offsed days from the end of the month. used when you want for example 15 days 
#from the end of the month

def getNdaysFromMonthEnd(startTime, numOfDays = 0): 
    dateTimeObject = parse(startTime)
    startTime =  datetime.strftime(dateTimeObject, "%Y-%m-%d %H:%M:%S")

    month = int(datetime.strftime(dateTimeObject,"%m"))
    year = int(datetime.strftime(dateTimeObject,"%Y"))
    daysLegal = calendar.monthrange(year , month)[1]
    day1 = daysLegal - 15
    newDateString = datetime.replace(dateTimeObject, day=day1)
    #print "newDateString=", newDateString
    startTimeSec =  calendar.timegm(newDateString.timetuple())
    startTime =  time.strftime('%Y-%m-%dT%H:%M:%S%z', time.gmtime(startTimeSec))
    #print startTime
    return startTime

#================================================================================

def getEarlierTime(time1, time2):
    time1WithTimeZone = getTime(0,'second', startTime=time1)
    time2WithTimeZone = getTime(0,'second', startTime=time2)
    earlierTime =''
    if checkIfTime2GreaterTime1( time1WithTimeZone, time2WithTimeZone) :
       earlierTime = time1WithTimeZone
    else :
       earlierTime = time2WithTimeZone
    return earlierTime


#===============================================================================

#just for testing this module
def main():
    print("checkIfTime2GreatedTime1('2012-01-17T12:23:21-07:00','2012-01-17T12:23:21-08:00') = ", str(checkIfTime2GreatedTime1('2012-01-17T12:23:21-07:00','2012-01-17T12:23:21-08:00')))
    print("checkIfTime2GreatedTime1('2012-01-17T12:23:21-08:00','2012-01-17T12:23:21-08:00') = ", str(checkIfTime2GreatedTime1('2012-01-17T12:23:21-08:00','2012-01-17T12:23:21-08:00')))
    print("checkIfTime2GreatedTime1('2012-01-17T12:23:21-09:00','2012-01-17T12:23:21-08:00') = ", str(checkIfTime2GreatedTime1('2012-01-17T12:23:21-09:00','2012-01-17T12:23:21-08:00')))
    print("checkIfTime2GreatedTime1('2012-01-17T12:23:21','2012-01-17T12:23:20') = ", str(checkIfTime2GreatedTime1('2012-01-17T12:23:21','2012-01-17T12:23:20')))
    print("checkIfTime2GreatedTime1('2012-01-17T12:23:21','2012-01-17T12:23:22') = ", str(checkIfTime2GreatedTime1('2012-01-17T12:23:21','2012-01-17T12:23:22')))
    sys.exit(1)
    
    t1 = getTimeOfDay(getTime(0),hour=3,min=23,sec=45)
    print('  getTimeOfDay(\'getTime(),hour=3,min=23,sec=45\') ' + t1)
    t1 = getTimeOfDay(getTime(0),min=30)
    print('  getTimeOfDay(\'getTime(),min=30\') ' + t1)
    sys.exit(1)
    t1 = getDateOfWeekday('Mon')
    print('  getDateOfWeekday(\'Mon1\') ' + t1)
    t1 = getDateOfWeekday('Mon' , '2012-01-17T12:23:21')
    print('  ====getDateOfWeekday(\'Mon\') ' + t1)
   # sys.exit(1)
    
    print(getTime(startTime = '2012-03-11T09:50:00 PST'))
    print(getDaysFromAddingMonth('2012-03-01T09:50:00 PST',1))
    print(getDaysFromAddingMonth('2012-03-01T09:50:00 PST',-1))
    sys.exit(1)

    print(getDaysFromAddingMonth("2013-11-10T03:00:00",1))
    print(getDaysFromAddingMonth("2013-11-10T03:00:00",-1))
    print(getDaysFromAddingMonth("2013-11-10T03:00:00",3))
    print(getDaysFromAddingMonth("2013-11-10T03:00:00",21))
    print(getDaysFromAddingMonth("2013-11-10T03:00:00",-21))
    sys.exit(1)
    print(addDecimal('2012-03-11T09:50:00Z'))
    sys.exit(1)
    #print getTime()
    startTime = '2012-03-11T09:50:00'
    print(getTime(startTime = startTime))
    sys.exit(1)
    sub1TimeZone='Asia/Hong_Kong'
    #print getTime(startTime = startTime)
    startTime = qualifyNaiveTime(startTime, sub1TimeZone)
    print(startTime)
    print(getTime(startTime = startTime))

    print('Offer start time: ' + startTime)
    sys.exit(1)

    startTime = '2012-07-01T12:34:00'
    startTime = getTime(startTime=startTime)
    print(getTime(8, 'months', startTime))
    print(getPeriod(8, 'months', startTime))
    sys.exit(1)
    x = getTime() #startTime = '2011-10-31T12:00:12-08:00')
    print(getPeriod(1, 'hour',x))
    print(getTime(1, 'year',x))
    print(getTime(startTime = '2011-10-31T12:00:12'))

    t1 = getDateOfWeekday('Thu',numOfWeeks =4)
    print('  getDateOfWeekday(Mon) ' + str(t1))

    print(qualifyNaiveTime("2012-03-11T01:59:59", 'UTC')) #S/Pacific')
    print(qualifyNaiveTime("2012-03-11T01:59:59", 'US/Pacific'))
    convertTimeZones("2013-01-14T01:10:12", "US/Eastern", "US/Pacific")
    convertTimeZones("2012-03-11T02:00:00", "US/Eastern", "US/Pacific")
    convertTimeZones("2012-03-12T02:00:00", "US/Eastern", "US/Pacific")
    sys.exit(1)
 
    getUTCTime("2012-03-11T01:59:59", forceUtc = True)  #old:2013-01-14T01:10:12Z
    getUTCTime("2012-03-11T02:59:59", forceUtc = True)  #old:2013-01-14T01:10:12Z
    #getTime(delta=3 , timeUnit='hours' , startTime="2012-02-28T01:10:12-0800" , extraSecs=0, addTz=True)
    sys.exit(1)
    getUTCTime("2013-01-14T01:10:12", forceUtc = True)  #old:2013-01-14T01:10:12Z
    getUTCTime(1143408899) 
    getUTCTime("2013-10-14T01:10:12-0800") #old error
    getUTCTime("2013-01-14T01:10:12", forceUtc = True)  #old:2013-01-14T01:10:12Z
    getUTCTime("2013-01-12T01:10:15Z") #old: nothing

 
    isQualified("2013-01-14T010:12:13+0800")
    sys.exit(1)
    t1 = getTime(30, 'sec', getDateOfWeekday('Mon' ))
    print('  getDateOfWeekday(\'Mon\' ) ' + t1)
    sys.exit(1)
    t1 = 0
    t0 = getTextTimeFromDiameterTime(3556210080)
    t1 = getPeriod(2 , 'hour','2013-01-31T12:23:40')
    print(' getPeriod(12 , \'hour\'): ' + t1)

    t1 = getPeriod(1 , 'day','2013-01-31T12:23:00')
    print(' getPeriod(1 , \'day\'): ' + t1)

    t1 = getPeriod(2 , 'month','2013-01-31T12:23:00')
    print(' getPeriod(1 , \'month\'): ' + t1)
    sys.exit(1)

    t1 = getTime(1 , 'month' , '2011-10-31T12:00:12')
    print(' getTime(1 , \'month\' , \'2011-10-31T12:00:12\'): ' + t1)

    t1 = getTime(1 , 'month' , '2012-01-30T12:00:12')
    print(' getTime(-1 , \'month\' , \'2012-01-30T12:00:12\'): ' + t1)
    sys.exit(1)

    t1 = getTime(4 , 'month')
    print(' getTime(1 , \'month\'): ' + t1)
    t1 = getTime(5 , 'month')
    print(' getTime(5 , \'month\'): ' + t1)
    return
    t1 = getDateOfWeekday('Mon')
    print('  getDateOfWeekday(\'Mon1\') ' + t1)
    t1 = getDateOfWeekday('Mon' , '2012-01-17T12:23:21')
    print('  ====getDateOfWeekday(\'Mon\') ' + t1)
    #return
    t1 = getTime(0)
    print(' getTime(0): ' + t1)
    t1 = getTime(10)
    print(' getTime(10): ' + t1)
    t1 = getTime(10 , 'years')
    print(' getTime(10 , \'years\'): ' + t1)
    #TS = getDaysFromAddingMonth('2011-12-31T12:00:12' , 2)
    #TS = getDaysFromAddingMonth('2011-01-29T12:00:12' , 1)
    m1 = getTime(19 , 'month') 
    #m = getTime(-1 , 'hour' , m) 
    #m = getTime(2 , 'month' , '2011-02-25T12:00:12')
    #m = getTime(2 , 'hour') 
    m1 = getTime(2 , 'hour' , '2011-02-25T12:00:12')
    #print 'm-11111111=' + str(m1)
    m1 =  adjustClock(m1, '23:24:33:4444')
    print('m-22222222=' + str(m1))

#===============================================================================
if __name__ == '__main__':
    main()

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

