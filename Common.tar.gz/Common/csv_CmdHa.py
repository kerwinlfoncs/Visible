#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:35:41
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:35:41
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:35:40
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
import sys
import QA_subscriber_management_restv3 as REST_UTIL
import qa_utils as QAUTILS
import csv_track as TRACK
import csv_prim as PRIM
import ha_apis as HA

#==========================================================
def CmdHa_verifyrpm(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.verifyRpm(lclDCT['fqdn'], lclDCT['rpmInfo'])
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_processcheckpoint(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.processCheckpoint(lclDCT['fqdn'], lclDCT['checkpointInfo'], apply)
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None

#==========================================================
def CmdHa_processpricing(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.processPricing(lclDCT['fqdn'], lclDCT['pricingInfo'], apply)
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None

#==========================================================
def CmdHa_processrpm(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.processRpm(lclDCT['fqdn'], lclDCT['rpmInfo'], apply)
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None

#==========================================================
def CmdHa_stopandverifyblade(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        (retCode,newFqdn) = HA.stopAndVerifyBlade(lclDCT['fqdn'], expectError=(not lclDCT['eventPass']))
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None

#==========================================================
def CmdHa_startandverifyblade(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        (retCode,newFqdn) = HA.startAndVerifyBlade(lclDCT['fqdn'], expectError=(not lclDCT['eventPass']))
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_startandverifyengine(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        (retCode,newFqdn) = HA.startAndVerifyEngine(lclDCT['fqdn'], expectError=(not lclDCT['eventPass']))
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_stopandverifyengine(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        (retCode,newFqdn) = HA.stopAndVerifyEngine(lclDCT['fqdn'], expectError=(not lclDCT['eventPass']))
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_stophighestnumberedactiveprocessingblade(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        (retCode,newFqdn) = HA.stopHighestNumberedActiveProcessingBlade(lclDCT['fqdn'], expectError=(not lclDCT['eventPass']))
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_rollengine(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.rollEngine(lclDCT['fqdn'], specialInfo, apply, lclDCT['noMgmt'])
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_rollingupgrade(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.rollingUpgrade(lclDCT['fqdn'], specialInfo, apply, lclDCT['noMgmt'])
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_restartbladesall(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.restartBladesAll(lclDCT['fqdn'])
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_restartbladesnomgmt(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.restartBladesNoMgmt(lclDCT['fqdn'])
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_restartengine(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.restartEngine(lclDCT['fqdn'])
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_engineupgrade(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.engineUpgrade(lclDCT['fqdn'], specialInfo, apply)
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_execprintbladestats(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.execPrintBladeStats(lclDCT['fqdn'], lclDCT['cmdOptions'], lclDCT['printFlag'])
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_startengine(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        (retCode, newFqdn) = HA.startEngine(lclDCT['fqdn'], expectError=(not lclDCT['eventPass']), background=lclDCT['background'])
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_stopengine(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.stopEngine(lclDCT['fqdn'], expectError=(not lclDCT['eventPass']), background=lclDCT['background'])
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_getandprocesssnmpquery(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.getAndProcessSnmpQuery(lclDCT['query'], lclDCT['fqdn'])
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_startblade(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.startBlade(lclDCT['fqdn'], expectError=(not lclDCT['eventPass']), background=lclDCT['background'])
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_stopblade(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.stopBlade(lclDCT['fqdn'], expectError=(not lclDCT['eventPass']), background=lclDCT['background'])
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_getactivemanagementblade(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.getActiveManagementBlade(lclDCT['fqdn'])
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_getnonactivemanagementblade(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.getNonActiveManagementBlade(lclDCT['fqdn'])
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_getmanagementblades(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.getManagementBlades(lclDCT['fqdn'])
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_getprocessingblades(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.getProcessingBlades(lclDCT['fqdn'])
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_getactiveprocessingblades(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.getActiveProcessingBlades(lclDCT['fqdn'])
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_getnonactiveprocessingblades(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.getNonActiveProcessingBlades(lclDCT['fqdn'])
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_getallblades(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.getAllBlades(lclDCT['fqdn'])
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_getallactiveblades(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.getAllActiveBlades(lclDCT['fqdn'])
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_runsshcmd(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.runSshCmd(lclDCT['fqdn'], lclDCT['cmd'])
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_createcheckpoint(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.createCheckpoint(lclDCT['fqdn'])
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_killmanagementblade(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.killManagementBlade(lclDCT['fqdn'])
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_killbladeprocess(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.killBladeProcess(lclDCT['fqdn'], lclDCT['processToKill'])
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_verifyenginestatus(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        retCode = HA.verifyEngineStatus(lclDCT['fqdn'], lclDCT['engineStatus'])
        
        # If failure, then exit
        if lclDCT['eventPass'] != retCode: sys.exit('Exiting due to command failure')
        
        # Nothing to query
        return None,None
        
#==========================================================
def CmdHa_hasetup(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Execute the primitive
        HA.haSetup()
        
        # Nothing to query
        return None,None
        
