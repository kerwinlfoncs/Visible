
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:07
#
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:35:49
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:34:39
#!/usr/bin/env jython
#===============================================================================
#
# Copyright 2011,2012,2013,2014 Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

# from builtins import object
# from builtins import object
import sys
from datetime import datetime
sys.path.append("/opt/mtx/bin/JavaApiGenerator.jar")

import com.matrixx.datacontainer.Containers
from com.matrixx.datacontainer import MtxObjectId
from com.matrixx.datacontainer import SubscriberManagementApi
from  com.matrixx.datacontainer import SendMessage
from com.matrixx.datacontainer.mdc import MtxRequestMulti
from com.matrixx.datacontainer.mdc import MtxRequestSubscriberCreate
from com.matrixx.datacontainer.mdc import MtxRequest
from com.matrixx.datacontainer.mdc import MtxRequestDeviceCreate
from com.matrixx.datacontainer.mdc import MtxRequestSubscriberAddDevice
from com.matrixx.datacontainer.mdc import MtxRequestSubscriberPurchaseOffer
from com.matrixx.datacontainer.mdc import MtxDeviceSearchData
from com.matrixx.datacontainer.mdc import MtxSubscriberSearchData
from com.matrixx.datacontainer.mdc import MtxResponseMulti
from com.matrixx.datacontainer.mdc import MtxResponse
from com.matrixx.datacontainer.mdc import MtxResponseCreate
from com.matrixx.datacontainer.mdc import MtxRequestSubscriberQuery
from com.matrixx.datacontainer.mdc import MtxResponseSubscriber
from com.matrixx.datacontainer.mdc import MtxRequestDeviceQuery
from com.matrixx.datacontainer.mdc import MtxResponseDevice
from com.matrixx.datacontainer.mdc import MtxRequestDevicePurchaseOffer
from com.matrixx.datacontainer.mdc import MtxPurchasedOfferData
from com.matrixx.datacontainer.mdc import MtxResponseAdd
from com.matrixx.datacontainer.mdc import MtxRequestSubscriberQueryWallet
from com.matrixx.datacontainer.mdc import MtxRequestDeviceDelete
from com.matrixx.datacontainer.mdc import MtxRequestDeviceModify
from com.matrixx.datacontainer.mdc import *
import com.matrixx.mdcGenerator.LoadedConfiguration

from java.util import ArrayList
from java.lang import Object
from java.math import BigInteger

class javaApiTest(object) :

    def __init__(self, m_addr="localhost", m_port="4060"):
        m_sender = SendMessage(m_addr, m_port)
        self.m_api = SubscriberManagementApi(m_sender)

    def querySubscriber (self, queryValue, queryType="ExternalId", querySize=None):
        m_subSearch = MtxSubscriberSearchData()
        if queryType == "ExternalId" :
            m_subSearch.setExternalId(queryValue)
        elif queryType == "Imsi" : 
            m_subSearch.setImsi(queryValue)
        elif queryType == "ObjectId" : 
            m_subSearch.setObjectId(queryValue)
        elif queryType == "AccessNumber" : 
            m_subSearch.setAccessNumber(queryValue)
        else :
	    print("invalid subscriber queryType: ", queryType)

        m_subSearchReq = MtxRequestSubscriberQuery()
        m_subSearchReq.setSubscriberSearchData(m_subSearch)
        if querySize is not None :
            m_subSearchReq.setQuerySize(querySize)
        
        response = self.m_api.subscriberQuery(m_subSearchReq)
        mdc = response.mdc()
        return  mdc.toCompactXml()        

    def createSubscriber (self, externalId, deviceId=None, offerIds=None, offerStartTime=None, offerEndTime=None, offerVersion=None, billingCycleTemplateId=None, firstName=None, lastName=None, language=None, notificationPreference=None, status=None, taxCertificate=None, taxLocation=None, taxStatus=None, timeZone=None, contactEmail=None, contactPhoneNumber=None, subAttr=None):
        m_req = MtxRequestSubscriberCreate()
        m_req.setExternalId(externalId)
        if firstName : m_req.setFirstName(firstName)
        if lastName : m_req.setLastName(lastName)
        if contactEmail: m_req.setContactEmail(contactEmail)
        if contactPhoneNumber: m_req.setContactPhoneNumber(contactPhoneNumber)
        if status : m_req.setStatus(status)
        if language : m_req.setLanguage(language)
        if notificationPreference : m_req.setNotificationPreference(notificationPreference)
        if taxCertificate : m_req.setTaxCertificate(taxCertificate)
        if taxLocation : m_req.setTaxLocation(taxLocation)
        if taxStatus : m_req.setTaxStatus(taxStatus)
        if timeZone : m_req.setTimeZone(timeZone)

        if billingCycleTemplateId :
            billingCycleData = self.createBillingCycle(billingCycleTemplateId)
            m_req.setBillingCycle(billingCycleData) 

        if subAttr :
            #TODO
            pass

        m_resp = self.m_api.subscriberCreate(m_req)
        oId = m_resp.getObjectId()

        if offerIds :
            m_subSearch = MtxSubscriberSearchData()
            m_subSearch.setObjectId(oId)
            m_req = MtxRequestSubscriberPurchaseOffer()
            m_req.setSubscriberSearchData(m_subSearch)
            for id in offerIds :
                offerData = self.buildOfferData(id, offerStartTime, offerEndTime, offerVersion)
                m_req.appendOfferRequestArray(offerData)
            m_resp = self.m_api.subscriberPurchaseOffer(m_req) 

    def querySubscriberWallet (self, queryValue, queryType="ExternalId"):
        m_subSearch = MtxSubscriberSearchData()
        if queryType == "ExternalId" :
            m_subSearch.setExternalId(queryValue)
        elif queryType == "Imsi" : 
            m_subSearch.setImsi(queryValue)
        elif queryType == "ObjectId" : 
            m_subSearch.setObjectId(queryValue)
        elif queryType == "AccessNumber" : 
            m_subSearch.setAccessNumber(queryValue)
        else :
	    print("invalid subscriber queryType: ", queryType)

        m_subSearchReq = MtxRequestSubscriberQueryWallet()
        m_subSearchReq.setSubscriberSearchData(m_subSearch)
        response = self.m_api.subscriberQueryWallet(m_subSearchReq)
        print(response.getTaxLocation())
        mdc = response.mdc()
        return mdc.toCompactXml()        


    def buildOfferData (self, offerId, startTime=None, endTime=None,externalId=None, offerVersion=None):
        offerData = MtxPurchasedOfferData()
        offerData.setProductOfferId(BigInteger.valueOf(offerId))
        if startTime : 
            sTime=MtxTimestamp(startTime)
            offerData.setStartTime(sTime)

        if endTime :
            eTime=MtxTimestamp(endTime)
            offerData.setEndTime(eTime)
 
        if offerVersion : offerData.setProductOfferVersion(offerVersion)

        return offerData

    def buildSubscriber (self, externalId, deviceId=None, offerIds=None, offerStartTime=None, offerEndTime=None, offerVersion=None, billingCycleTemplateId=None, firstName=None, lastName=None, language=None, notificationPreference=None, status=None, taxCertificate=None, taxLocation=None, taxStatus=None, timeZone=None, contactEmail=None, contactPhoneNumber=None, subAttr=None): 
        m_req = MtxRequestSubscriberCreate()
        m_req.setExternalId(externalId)
        if firstName : m_req.setFirstName(firstName)
        if lastName : m_req.setLastName(lastName)
        if contactEmail: m_req.setContactEmail(contactEmail)
        if contactPhoneNumber: m_req.setContactPhoneNumber(contactPhoneNumber)
        if status : m_req.setStatus(status)
        if language : m_req.setLanguage(language)
        if notificationPreference : m_req.setNotificationPreference(notificationPreference)
        if taxCertificate : m_req.setTaxCertificate(taxCertificate)
        if taxLocation : m_req.setTaxLocation(taxLocation)
        if taxStatus : m_req.setTaxStatus(taxStatus)
        if timeZone : m_req.setTimeZone(timeZone)

        if billingCycleTemplateId :
            billingCycleData = self.createBillingCycle(billingCycleTemplateId)
            m_req.setBillingCycle(billingCycleData)

        if subAttr :
            #TODO
            pass

