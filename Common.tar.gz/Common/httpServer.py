#! /usr/bin/python3
#
# @2to3-3 --no-diffs -x input -w  : Thu 2022-02-03T10:22:48
#===============================================================================
#
# Copyright 2019, MATRIXX Software, Inc. All rights reserved.
#
#-------------------------------------------------------------------------------
#
# @file
# @author     original: Shane Beasley
# @author     last modified by: $Author: shirley.zou $
# @date       $Date: 2019-09-03 14:24:36 -0700 (Tue, 03 Sep 2019) $
#
# $Id: common_functions.py 66102 2019-09-03 21:24:36Z shirley.zou $
#
# @futurize --stage2 --no-diffs -n -w  : Thu 2022-02-03T10:22:44
#
# @futurize --stage1 --no-diffs -n -w  : Thu 2022-02-03T10:22:39
#
#===============================================================================

from __future__ import print_function
# from builtins import next
# from builtins import str
# from builtins import range
from future import standard_library
standard_library.install_aliases()
# from builtins import next
# from builtins import str
# from builtins import range
import http.server
import datetime
import json
import queue
import socketserver
import string
import sys
import threading
import urllib.parse
import pprint, os, time
import csv_5G as FIVEG
from optparse import OptionParser

# Define where to write the temp files
tempFileDir='/home/mtx/'

# Pass this value to functions that accept an optional timeout so that they still wait forever
# but will nevertheless be interruptible by SIGINT (Ctrl-C).
MAX_TIMEOUT = getattr(threading, 'MAX_TIMEOUT', sys.maxsize)
options = None

# ------------------------------------------------------------------------------
# Define input
def commandInput():
        global options

        # -----------------------------------------------------------------------------
        # Program Usage and Options
        # -----------------------------------------------------------------------------
        #define the options and parameter
        parser = OptionParser(usage="usage: %prog [options] ",
                      version="%prog 0.1")

        parser.add_option("-v", "--verbose",
                      action="store",
                      dest="verbose",
                      default='normal',
                      help="Reporting verbosity")

        parser.add_option("-i", "--ip",
                      action="store",
                      dest="ip",
                      default='0.0.0.0',
                      help="http2 server IP address")

        parser.add_option("-p", "--port",
                      action="store",
                      dest="port",
                      default='8000',
                      help="http2 server port")

        # Set the subman mode of operation
        (options, args) = parser.parse_args()

#===============================================================================
# Setup thread for processing the request
class processingThread(threading.Thread):
    def __init__(self,threadNum,queue):
        threading.Thread.__init__(self)
        self.threadNum=threadNum
        self.input_queue=queue

    def run(self):
        count = 0
        
        # Loop forever
        while True:
                # Get a request from the queue
                request = self.input_queue.get(block=True)
                print('Thread ' + str(self.threadNum) + ' retrieved request from queue ')

                # Bump the count
                count += 1

                # Put content into JSON
                content = json.loads(request.content)
                
                # For readability (code was already using this variable)
                headers = request.headers
                
                # Build output file content
                outStr = ''
                outStr += 'Path: ' + request.path + '\n'
                session = request.path.split('?')[0].split('/')[-1]
                outStr += 'Session: ' + session + '\n'
                outStr += 'Headers:\n'
                for h in headers: outStr += h + ': ' + request.headers.get(h) + '\n'
                outStr += 'Content: ' + str(content)
                
                # Send message to client processing SBA messages
                FIVEG.sendHttpServerMessage(outStr, session, 'HTTP')
                
                # Get response from client
                # Build dictionary (kludgy...)
                lclDCT = {}
                lclDCT['sessionId'] = session
                lclDCT['timeToWait'] = 5 
                lclDCT['timeToWaitInterval'] = 0.5
                lclDCT['interface'] = 'HTTP'
                lclDCT['eventPass'] = True
                msg = FIVEG.getHttpServerMessage(lclDCT, "HTTP")
                
                # Debug
                print('HTTP - Notify response message for session ' + session + ': ')
                print(msg)
                
                # For now get only the first line
                response = int(msg.strip().split('\n')[0])
                
                # Reply with no content if reply is 0, else if reply is positive then reply with error, or if negative then no reply.
                if   response == 0:
                        print('Replying success for session ' + session)
                        request.reply()
                elif response > 0: 
                        print('Replying failure for session ' + session)
                        request.reply(code=response, content=json.loads('TF: Requested Failure'))
                else:   print('Not replying for session ' + session)

class AsyncHTTPHandler(http.server.BaseHTTPRequestHandler):
    '''Enqueues self on each request and blocks for response from main thread.'''
    def __init__(self, *args, **kwargs):
        self.content = self.cond = None
        self.protocol_version = 'HTTP/1.1'  # required for Content: Keep-Alive
        http.server.BaseHTTPRequestHandler.__init__(self, *args, **kwargs)

    def doStuff(self):
        '''Enqueues self on each request and blocks for response from main thread.'''
        self.content = self.rfile.read(int(self.headers.getheader('content-length', 0)))
        # acquire condition, enqueue for handling in other thread, and wait for condition notification
        self.cond = threading.Condition()
        self.cond.acquire()
        self.server.Q.put(self, timeout=MAX_TIMEOUT)
        self.cond.wait(timeout=MAX_TIMEOUT)
        self.cond.release()

    # use doStuff to do all of this stuff
    do_GET = do_POST = do_PUT = do_PATCH = do_DELETE = doStuff

    def reply(self, content=None, code=204, message=None, headers=None):
        '''
        Call in main thread to return a reponse with the given data and unblock doStuff().
        reply(code=404, message="Foo", headers={"Bar":"Baz"}, content="Blah\n") yields:

        HTTP/1.1 404 Foo
        Server: BaseHTTP/0.3 Python/2.7.5
        Date: Tue, 10 Sep 2019 02:35:53 GMT
        Content-type: text/plain
        Content-length: 5
        Bar: Baz

        Blah
        '''

        # HTTP/1.1 <code> <message>
        self.send_response(code, message)

        if not headers:
            headers = dict()
        # HTTP headers are case-insensitive. Build & check lower-case key set.
        headerKeys = set(x.lower() for x in headers)
        hasType, hasLength = (header in headerKeys for header in ('content-type', 'content-length'))
        if isinstance(content, dict):
            if not hasType:
                headers['Content-Type'] = 'application/json'
            content = json.dumps(content)
        elif content is not None:
            if not hasType:
                headers['Content-Type'] = 'text/plain'
            content = str(content)
        if content is not None and not hasLength:
            headers['Content-Length'] = len(content)
        # transmit headers
        for header in list(headers.items()):
            self.send_header(*header)
        self.end_headers()
        # transmit content
        if content is not None:
            self.wfile.write(content)
            self.wfile.flush()
        # unblock doStuff.
        self.setReplySent()

    def setReplySent(self):
        '''Unblock doStuff. Normally called by reply() after sending HTTP response.'''
        self.cond.acquire()
        self.cond.notify()
        self.cond.release()

class AsyncHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    '''
    HTTP server that runs itself and each request in separate threads, each queueing
    one request into a Queue.Queue to be fetched and handled by the main thread in
    any order. "Hello world" example:

      with AsyncHTTPServer('localhost', 8000) as listener:
          for request in listener:
              request.reply()
    '''
    def __init__(self, host, port):
        self.daemon_threads = True
        self.Q = self.thread = None
        http.server.HTTPServer.__init__(self, (host, port), AsyncHTTPHandler)
    def __enter__(self):
        self.open()
        return self
    def __exit__(self, *args):
        self.close()
    def __iter__(self):
        return self
    def __next__(self):
        return next(self)
    def open(self):
        self.Q = queue.Queue()
        # serve_forever also runs in its own thread
        self.thread = threading.Thread(None, self.serve_forever)
        self.thread.daemon = True
        self.thread.start()
    def __next__(self):
        return self.Q.get(timeout=MAX_TIMEOUT)
    def server_close(self):
        # stop serve_forever() in other thread
        self.shutdown()
        # wait for thread
        self.thread.join()
        # do base stuff
        http.server.HTTPServer.server_close(self)
        # reset
        self.Q = self.thread = None
    close = server_close

def main():
    # Get inputs
    commandInput()

    # *** Queue and thread setup ***
    # Set up a queue
    q=queue.Queue()
    
    # Create threads and start them
    pool=[]
    for i in range(20):
          t=processingThread(i,q)
          pool.append(t)
          t.daemon = True
          t.start()
    
    # listen on *:8000
    listener = AsyncHTTPServer(options.ip, int(options.port))
    listener.open()
    
    # Loo[p forever
    while True:
        # Get notification
        request = next(listener)
        
        # Put into the queue
        q.put(request)

    # Close the socket
    listener.close()

if __name__ == '__main__':
    main()

