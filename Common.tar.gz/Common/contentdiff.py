#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:46
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:26
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:06

# from builtins import range
# from builtins import range
import sys,os
import qa_utils as QAUTILS
import optparse


def main():

    parser = optparse.OptionParser()
    parser.add_option("-a", "--filea", action='store', type='string', default=None, help="e.g /home/mtx/dirOfcheckpoint1/content.gz ")
    parser.add_option("-b", "--fileb", action='store', type='string', default=None, help="e.g /home/mtx/dircheckpoint2/content.gz ")
    (options, args) = parser.parse_args()

    contentOne = contentTwo = {}
    if options.filea :
        contentOne = print_files(options.filea) 
    if options.fileb :
        contentTwo = print_files(options.fileb)
    diff_content(contentOne,contentTwo)

def diff_content(contentOne,contentTwo) :
    for key in list(contentOne.keys()) :
        if key not in contentTwo:
            print('unknown content ' + key + ', not found in file B  ' , contentTwo)
        elif contentOne[key] != contentTwo[key]:
            print('different ' + key + ' ,file A : '+ contentOne[key] +' ,file B : ' + contentTwo[key] + '\n')
        else :
            print('same ' + key + ' : ' + contentOne[key] + '\n')
    
    for key in list(contentTwo.keys()) :
       if key not in contentOne:
           print('unknown content ' + key + ', not found in file A  ' ,contentOne)
        
def print_files(contentfile) :
    outOne = outTwo = []
    content = {}
    binDir = os.path.abspath(os.path.expandvars(os.getenv('MTX_BIN_DIR', '.')))

    cmdOne = 'python ' + binDir + '/print_data_container_file.py -f ' + contentfile + ' | grep FileName | awk \'{print $8}\''
    cmdTwo = 'python ' + binDir + '/print_data_container_file.py -f ' +  contentfile + ' | grep \"1 TxnCount\" | awk  \'{print $8}\''
    outOne = str.split(QAUTILS.runCmd(cmdOne),'\n')
    outTwo = str.split(QAUTILS.runCmd(cmdTwo),'\n')
    for i in range(len(outOne)) :
        content[outOne[i]] = outTwo[i]

    return content 


################################################################################
if __name__ == '__main__':
    main()
