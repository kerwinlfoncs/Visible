#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:36:14
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:36:14
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:36:11
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
from __future__ import print_function
from __future__ import division
# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
from past.utils import old_div
import copy, time, sys, socket, parser, pprint, re, random, string, os, pytz, itertools , decimal, shutil
from datetime import date, datetime
from dateutil.parser import parse
from dateutil.tz import *
import dateutil.parser
import xml.etree.cElementTree as ET
import data_container_defs as MDCDEFS
from primitives import timeToMDCtime as MDCTIME
import csv_id as CSVID
import csv_track as TRACK
import csv_qa as CSVQA
import csv_data as DATA
import csv_ccf as CCF
import csv_CmdMisc as MISC
import qa_utils as QAUTILS
import create_diameter_pkt_base as DIAMPKT
import diameter as DIAM
import numpy as NP
import restV3 as RESTV3
import csv_Events as CSVEVENTS
import common_mdc as COMMON
from primitives import primGeneric as GENERIC
from primitives import primGET as GET
from primitives import primXML as XML
from primitives import primHTTP    as HTTP
from primitives import cbRestPrim  as CB
from operator import itemgetter, attrgetter, methodcaller
from primitives import engineRestPrim  as ENGINE
from primitives import primData  as PRIMDATA
try:
   import custSpecific as CUST
except ImportError:
   os.system(' echo \"\" > custSpecific.py ')

# Define random string prefix
randomPrefix = 'rr'

#==========================================================
def buildOfferParameters(paramList, lclDCT):
        # If nothing defined, return None
        if not len(paramList): return None
        
        #pprint.pprint(paramList)
        
        # Initialize return structure
        result = []
        
        # Process each parameter
        for param in paramList:
                # Split entry into parameters
                (name,valueType) = param
                
                # If paramete rnot set then skip
                if lclDCT[name] == None: continue
                
                # Store into structure. Second element matters, as this is replaces XXX in the MtxParameterXXXValue API grouping.
                #result.append({'ParameterName': name, 'DecimalValue': decimal.Decimal(lclDCT[name])})
                if   valueType.startswith('bool'):      result.append({'ParameterName': name, 'BoolValue': boolean(lclDCT[name])})
                elif valueType.startswith('uint'):      result.append({'ParameterName': name, 'Unsigned'+valueType[1:].capitalize()+'Value': int(lclDCT[name])})
                elif valueType.startswith('int'):       result.append({'ParameterName': name, valueType.capitalize()+'Value': int(lclDCT[name])})
                elif valueType.startswith('datetime'):  result.append({'ParameterName': name, 'DateTimeValue': lclDCT[name]})
                elif valueType == 'decimal':            result.append({'ParameterName': name, valueType.capitalize()+'Value': decimal.Decimal(lclDCT[name])})
                else:                                   result.append({'ParameterName': name, valueType.capitalize()+'Value': str(lclDCT[name])})
        
        return result
        
#==========================================================
def randomParameters(lclDCT, lclStartTime):
        # Process every key
        for key in lclDCT:
                # Skip if not set or not requestin grandom value
                if not lclDCT[key] or not isinstance(lclDCT[key],str) or not lclDCT[key].lower().startswith('random') or key == 'aqmFunction': continue
                
                # Split the key
                fields = lclDCT[key].split('-')
                
                # Debug output
                print('Parameter ' + key + ' will apply algorithm: ' + str(fields))
                        
                # See what type of randomness is desired
                if fields[0].lower() in ['randomint', 'randomfloat']:
                        # Get random number.  Assumption is start/end will be integers.  Can;t get random value betwen floats.
                        # See if start/end values specified
                        if len(fields) == 1:
                                # Nothing specified
                                start = '-10000000'
                                stop = '10000000'
                        elif len(fields) == 2:
                                # Stop specified.  Start assumed to be 0
                                start = '0'
                                stop = fields[1]
                        else:
                                start = fields[1]
                                stop = fields[2]
                        
                        # Dash used for field separator.  Letter N indicates negative.
                        # Factor that here.
                        if start[0].lower() == 'n': start = '-' + start[1:]
                        if stop[0].lower()  == 'n': stop  = '-' + stop[1:]
                        
                        # Always start with a random integer
                        if fields[0].lower() == 'randomint': lclDCT[key] = random.randint(int(start), int(stop))
                        else:                                lclDCT[key] = random.uniform(float(start), float(stop))
                        
                elif fields[0].lower() in ['randomstring']:
                        # Length defaults to 10 if not specified
                        if len(fields) > 1: length = int(fields[1])
                        else:               length = 10
                        
                        # Format defaults to ascii_letters if not specified.
                        # Supported strings: ascii_letters, ascii_lowercase, ascii_uppercase, digits, hexdigits, letters,
                        #                    lowercase, octdigits, punctuation, printable, uppercase, whitespace
                        if len(fields) > 2:  strings = fields[2]
                        else:                strings = 'ascii_letters'
                        
                        # Generate command to execute.  Seems you can't put assignment within an eval()...
                        cmd = "''.join(random.choice(string." + strings + ") for m in range(length))"
                        lclDCT[key] = eval(cmd)
                        
                elif fields[0].lower() in ['randomdate']:
                        # Starting date is the second parameter.  If missing or set to "now" then use input time.
                        if len(fields) == 1 or fields[1].lower() == 'now':
                                startDate = lclStartTime
                        else:
                                # API needs dash but input was comma, so replace that here
                                startDate = fields[1].replace(',', '-')
                                
                        # If input time has time zone specified, then grab it
                        if len(startDate) > 6 and startDate[-6] in ['-', '+']:
                                tz = startDate[-6:]
                        else:   tz = None
                        
                        # If input date has usec then need to get rid of these.
                        usecIndex = startDate.find('.')
                        if usecIndex != -1: startDate = startDate[:usecIndex]
                        
                        # Replace T in the middle with a space (for API call)
                        startDate = startDate.replace('T', ' ')
                        
                        # If 3rd param specified then use as possible offset, else choose 30
                        if len(fields) > 2:  offset = fields[2]
                        else:                offset = 30
                        
                        #print 'Input time/offset: ' + startDate + '/' + str(offset)
                        
                        # From https://stackoverflow.com/questions/41006182/generate-random-dates-within-a-range-in-numpy
                        offset_to_add = NP.arange(0, int(offset))
                        lclDCT[key] = NP.datetime64(startDate) + NP.random.choice(int(offset))
                        lclDCT[key] = str(lclDCT[key])
                        
                        # Replace output time zone with input time zone if both present.
                        # Output TZ doesn't include ":" so offset back is different from input variable check
                        if tz and len(lclDCT[key]) > 5 and lclDCT[key][-5] in ['-', '+']: lclDCT[key] = lclDCT[key][:-5] + tz
                elif fields[0].lower() in ['randomparameter']:
                        # Want to get from a parameter that was (most likely) set from normalizer mapping
                        mapValue = fields[1]
                        
                        # Make sure this parameter exists and has mapping data
                        try:
                                combinedDct = {}
                                cmd  =  'if hasattr(DATA, "' + mapValue + 'Mapping"): combinedDct.update(DATA.' + mapValue + 'Mapping[]) \n'
                                cmd +=  'if hasattr(CUST, "' + mapValue + 'Mapping"): combinedDct.update(CUST.' + mapValue + 'Mapping[]) \n'
                                #print cmd
                                exec(cmd)
                                pprint.pprint(combinedDct)
                                lclDCT[key] = random.choice(list(combinedDct))
                        except:
                                sys.exit('ERROR: parameter ' + key + ' has invalid random request: ' + lclDCT[key])
                else:
                        sys.exit('ERROR: parameter ' + key + ' has invalid random request: ' + lclDCT[key])
        
                # Set to string
                lclDCT[key] = str(lclDCT[key])
                        
                print('Parameter ' + key + ' result: ' + lclDCT[key])
#==========================================================
def dereferenceMarks(lclDCT, options):
        # Process every key
        for key in lclDCT:
                # Skip if not set or if a list (can walk a list later)
                if not lclDCT[key] or type(lclDCT[key]) is list: continue

                # Offer names may have colon, so don't check those (here's where special cases start to break stuff...)
#               if lclDCT[key].count('Offer'): continue

                # See if key has mark reference format
                specialString = str(lclDCT[key]).split(':')

                # If no colon then don't do anything
                if len(specialString) != 2: continue

                # Convert mark reference
                for item in ['group', 'sub', 'device']:
                        if specialString[0].startswith(item):
                                lclDCT[key] = TRACK.findObjectMark(options, specialString)
                                break

#==========================================================
def getBalanceAmount(queryObjType, queryVal, balanceId, lclStartTime, command, queryType, noUnits, resourceId=0):
        balance = getBalanceData(queryObjType, queryVal, balanceId, resourceId, lclStartTime, command, queryType=queryType)
        #print 'getBalanceAmount balance ' + balanceId + ': ' + str(balance)
                
        # In this case always want a positive number
        if balance['Amount'][0] == '-': amount = balance['Amount'][1:]
        else:                           amount = balance['Amount']
                
        # Convert using the balance unit if conversion is desired
        if balance['QuantityUnit'] and noUnits == False:
                if   balance['QuantityUnit'].startswith('kilo'): result = str(convertAmountsToIntegers(amount + 'KB'))
                elif balance['QuantityUnit'].startswith('mega'): result = str(convertAmountsToIntegers(amount + 'MB'))
                elif balance['QuantityUnit'].startswith('giga'): result = str(convertAmountsToIntegers(amount + 'GB'))
                elif balance['QuantityUnit'].startswith('min'):  result = str(convertAmountsToIntegers(amount + 'min'))
                elif balance['QuantityUnit'].startswith('hour'): result = str(convertAmountsToIntegers(amount + 'hour'))
                elif balance['QuantityUnit'].startswith('day'):  result = str(convertAmountsToIntegers(amount + 'day'))
                elif balance['QuantityUnit'].startswith('week'): result = str(convertAmountsToIntegers(amount + 'week'))
                elif balance['QuantityUnit'].startswith('month'):result = str(convertAmountsToIntegers(amount + 'month'))
                elif balance['QuantityUnit'].startswith('year'): result = str(convertAmountsToIntegers(amount + 'year'))
                else: result = amount
        else:   result = amount
                
        return result
        
#==========================================================
def processAmountFormula(queryObjType, queryVal, formula, lclStartTime, command, precisionFlag = False, balanceId = None, queryType = 'ExternalId', noUnits = True, resourceId=0):
        global randomPrefix
        
        # Convert to string
        formula = str(formula)
        
        # If formula characters not present then do nothing
        if formula[0] != '(' or formula[-1] != ')': return formula
                
        # Define new list entry
        result = ''
                
        # STEP 0: if starts with random string prefix, then a random number is desired
        if formula[1:].lower().startswith(randomPrefix):
                # Split into parts
                randonRange = formula[1+len(randomPrefix):].split('-')
                if len(randonRange) == 1:
                        start = 0
                        stop = convertAmountsToIntegers(randonRange[0])
                else:
                        start = convertAmountsToIntegers(randonRange[0])
                        stop = convertAmountsToIntegers(randonRange[1])
                
                # Account for negative flag
                if start < 0: start = -1 * start
                
                # Get random number in this range.  If the person entered a floating point number, then ensure we're dealing with an int...
                result = str(random.randint(int(start),int(stop)))
                print('Random Formula between ' + str(start) + ' and ' + str(stop) + ' evaluates to ' + result)
            
                # Return the calculated formula
                return result
        
        # If starting with an 's' and the next character is a dash, then the user wants a randon string
        if (formula[1].lower() == 's') and (len(formula) > 1) and (formula[2] == '-'):
                # Want a random string.  
                data = formula[3:].split('-')
                length = data[0]
                if len(data) > 1: dataSetIdentifier = data[1]
                else:             dataSetIdentifier = ascii_letters
                
                # Get actual data set
                cmd = "string." + dataSetIdentifier
                dataSet = eval(cmd)
                
                # Get result
                result = ''.join(random.choice(dataSet) for m in range(length))
                print('Random string of length ' + str(length) + ' evaluates to ' + result)
            
                # Return the calculated formula
                return result
        
        # *** STEP 1: find names within double quotes.  This allows names to contain operator characters.
        query = '"'
        r = re.compile(query)

        # Get index of every query string
        output = [m.start() for m in r.finditer(formula)]
        #print output
        index = 0
        result=''
        formulaIndex = 0
        while index < len(output):
                # Copy up to the start of the quoted string
                result += formula[formulaIndex:output[index]]
                
                # Copy the string between quotes
                balanceName = formula[output[index]+1:output[index+1]]
                #print 'Balance name: ' + balanceName
                
                # Point to beyond the closing quote
                formulaIndex = output[index+1] + 1
                
                # Get balance data.  Balance name should be in balance mappings.
                amount = getBalanceAmount(queryObjType, queryVal, DATA.balanceIdMapping[balanceName.lower()], lclStartTime, command, queryType, noUnits, resourceId)
                
                # Debug output
                print('processAmountFormula: Balance ' + balanceName + ' has amount ' + amount)
                
                # Add to result
                result += amount
                
                # We looked at two indices
                index += 2
        
        # Copy remainder of the formula.
        result += formula[formulaIndex:]
        
        # Copy back to formula
        formula = result
        
        # Debug output
        #print formula
        
        # *** STEP 2: look for strings starting with TID (template ID).  We use these as direct inputs to the balance function
        query = 'TID'
        r = re.compile(query)
        
        # Get index of every query string
        output = [m.start() for m in r.finditer(formula)]
        #print output
        index = 0
        result=''
        formulaIndex = 0
        while index < len(output):
                # Copy up to the next quoted string
                result += formula[formulaIndex:output[index]]
                
                # Copy the 5 characters after the string (fixed length balance template size)
                balanceStart = output[index]+len(query)
                balanceId = formula[balanceStart:balanceStart+5]
                #print 'Balance ID: ' + balanceId
                
                # Point to beyond the balance ID
                formulaIndex = balanceStart + 5
                
                # Get balance data
                amount = getBalanceAmount(queryObjType, queryVal, balanceId, lclStartTime, command, queryType, noUnits)
                
                # Debug output
                print('processAmountFormula: Balance ' + balanceId + ' has amount ' + amount)
                
                # Add to result
                result += amount
                
                # We looked at one index
                index += 1
        
        # Copy remainder of the formula.
        result += formula[formulaIndex:]
        
        # Copy back to formula
        formula = result
        
        # Debug output
        #print formula
        
        # *** STEP 3: look for non-numeric strings (balance names not in quotes)
        result = ''
        
        # Start with non-numerics
        patternStart = re.compile(r'[a-z,A-Z]')
        
        # End with operator or parenthesis
        patternEnd = re.compile(r'[*/+\-)(]')
        
        # Set index to start
        formulaIndex = 0
        
        # Loop while we find something
        while patternStart.search(formula[formulaIndex:]):
                # Get the start/end of the name
                start = patternStart.search(formula[formulaIndex:]).start()
                end   = patternEnd.search(formula[formulaIndex+start+1:]).start()
        
                # Copy up to the start
                result += formula[formulaIndex:formulaIndex+start]
                
                # Get object name
                balanceName = formula[formulaIndex+start:formulaIndex+start+end+1].strip()
                
                # Could be a balance name or a unit.  If unit then skip until next section
                if balanceName.lower() in ['sec', 'min', 'hour', 'day', 'week', 'year', 'item', 'number', 'cent', 'dollar', 'kb', 'mb', 'gb', 'b']:
                        # Set the "amount" to the string so common code usable
                        amount = balanceName
                else:
                        # Debug utput
                        #print 'String in range ' + str(formulaIndex+start) + ':' + str(formulaIndex+start+end) + ' = ' + balanceName
                        
                        # Get balance amount.  Balance name should be in balance mappings.
                        amount = getBalanceAmount(queryObjType, queryVal, DATA.balanceIdMapping[balanceName.lower()], lclStartTime, command, queryType, noUnits, resourceId)
                        
                        # Debug output
                        print('processAmountFormula: Balance ' + balanceName + ' has amount ' + amount)
                
                # Add to result
                result += amount
                
                # Bump index
                formulaIndex += start+end+1
        
        # Copy remainder of the formula.
        result += formula[formulaIndex:]
        
        # Copy back to formula
        formula = result
        
        # Debug output
        #print 'End of step 3: ' + formula
        
        # *** STEP 4: Convert units to amounts
        # Keep going through the formula until no units remain.
        # Loop through entire string for each unit, as there can be multiple entries and they can occur in any order
        while True:
                # All possible unit strings
                for unit in ['sec', 'min', 'hour', 'day', 'week', 'year', 'item', 'number', 'cent', 'dollar', 'kb', 'mb', 'gb', 'b']:
                        # Look for string
                        idx = formula.lower().find(unit)
                        
                        # If found then break
                        if idx != -1: break
                        
                # If nothing found then break
                if idx == -1: break
                
                # End of the formula is after the length of the unit
                end = idx + len(unit)
                
                # Now need to find the coefficient.
                # Go backwards to find the first digit.
                # I'm sure re.search() can do this faster/easier, but that's sooo complicated to understand...
                idx = idx - 1
                while idx >= 0:
                        # Break once we found a digit
                        if formula[idx].isdigit(): break
                        
                        # Keep going backwards
                        idx = idx - 1
                
                # Sanity check we found something
                if idx < 0:
                        print('ERROR: formula missing coefficint for unit ' + unit)
                        print('Formula: ' + formula)
                        sys.exit('Exiting due to errors')
                
                # Now repeat until a non-digit is found.
                # I'm sure re.search() can do this faster/easier, but that's sooo complicated to understand...
                idx = idx - 1
                while idx >= 0:
                        # Skip once we found a non-digit
                        if not formula[idx].isdigit(): break
                        
                        # Keep going backwards
                        idx = idx - 1
                
                # Formula starts with so will always find a non-digit: no sanity checks needed here
                # Start of the string is now the index
                start = idx
                
                # Convert to an amount
                amount = convertAmountsToIntegers(formula[start:end])
                
                # Update formula 
                formula = formula[:start] + str(amount) + formula[end:]
        
        # Debug output
        #print formula
        
        # *** STEP 5: Evaluate the formula
        print('Evaluating formula: ' + formula)
        code = parser.expr(formula).compile()
        result = str(eval(code))
        
        # Account for precision of the balance
        result = acountForPrecision(balanceId, result, precisionFlag=precisionFlag)

        # Return the calculated formula
        print('Formula evaluates to ' + result + ' post precision checks.')
        return result

#==========================================================
def acountForPrecision(balanceId, amount, precisionFlag=True):
        # If no precision, then return here
        if not precisionFlag: return str(amount)
        
        # Amount should be a string
        origResult = amount = str(amount)
        
        # Formula may exceed precision of the balance (error), so need to account for that here.
        # Read balance template
        url = '/rsgateway/data/v3/pricing/balance/' + balanceId + GENERIC.getTimeStampStr(GET.commandTime)
        q = GET.curlToETFormat(url)
        
        #ET.dump(q)
        path = './BalanceInfo/MtxPricingBalanceDetailInfo'
        for id in q.findall(path):
                precision = id.find('Precision').text
                break
#       print 'precision = ' + precision + ', amount = ' + amount
        
        # Round to the proper precision
        amount = str(round(float(amount), int(precision)))
        
        # Report if we did anything
        if float(origResult) != float(amount): print('Truncated value from ' + origResult + ' to ' + amount + ' due to balance precision limit of ' + precision)
        
        return amount
        
#==========================================================
def waitforstate(lclDCT, options, RESTInst, cmdLineInput, target='subscriber'):
        # Get desired object status state
        if   target == 'subscriber':
                objectStatus = lclDCT['subStatus']
                objectId = lclDCT['externalId']
                queryType = lclDCT['subQueryType']
                saveFunc = 'saveMDC'
        elif target == 'group':
                objectStatus = lclDCT['groupStatus']
                objectId = lclDCT['groupId']
                queryType = lclDCT['groupQueryType']
                saveFunc = 'saveGroupMDC'
        else:
                objectStatus = lclDCT['devStatus']
                objectId = lclDCT['deviceId']
                queryType = lclDCT['devQueryType']
                saveFunc = 'saveDeviceMDC'

        # Get desired state
        if not objectStatus:
                print('ERROR: ' + target + ' status parameter required for this command')
                sys.exit('Exiting due to errors')

        # Debug putput
        print('Waiting for ' + target + ' ' + objectId + ' state to change to ' + str(objectStatus))

        # Prepare for loop
        currentStatus = -1
        amount = int(lclDCT['amount'])
        inputAmount = amount

        # Loop until states match or time exceeded
        while True:
                # Get the status
                url =  '/rsgateway/data/v3/' + target + '/query/' + queryType + '/' + objectId + GENERIC.getTimeStampStr(lclDCT['startTime'])
                q = GET.curlToETFormat(url)
                
                # Query object
                currentStatus = q.find('./Status').text.strip()

                # Break if equal
                if int(currentStatus) == int(objectStatus): break

                # Decrement amount
                amount -= 1

                # Break if done
                if amount <= 0: break

                # Sleep for 1 secnd
                time.sleep(1)

        # See if we found the desired state
        if ((currentStatus != objectStatus) and lclDCT['eventPass']) or ((currentStatus == objectStatus) and not lclDCT['eventPass']):
                print('ERROR unexpected states after ' + str(inputAmount) + ' seconds:  current state = ' + str(currentStatus) + ', desired state = ' + str(objectStatus))
                sys.exit('Exiting due to errors')

        # Print final state
        print(target + ' ' + objectId + ' state = ' + str(objectStatus))

        # Save nothing; no changes to the object
        queryValue = objectId
        queryType = queryType
        lclDCT['saveFunc'] = saveFunc

        return (queryType, queryValue)

#==========================================================
def policyValidationInputChecks(lclDCT):
        # Get policy info to validate
        policyIdentifier = lclDCT['policyIdentifier']
        policyStatus = lclDCT['policyStatus']
        
        # Sanity check the policy data
        if policyIdentifier and policyStatus:
                # Both set.  Make sure lengths are the same
                if len(policyIdentifier) != len(policyStatus):
                        print('WARNING: policyStatus and policyIdentifier input parameter are not the same length.  No policy validation done for this command')
                        evaluatePolicy = False
                else:
                        # All good!
                        evaluatePolicy = True
        else:
                # One or both not set, so don;t evaluate policy
                evaluatePolicy = False
                
                # See if one set and not the other
                if (not policyIdentifier and policyStatus) or (not policyStatus and policyIdentifier):
                        print('WARNING: policyStatus and policyIdentifier parameters are not in sync(one set; the other not).  No policy validation done for this command')
                        print('policyStatus: ' + str(policyStatus))
                        print('policyIdentifier: ' + str(policyIdentifier))
        
        return evaluatePolicy
        
#==========================================================
# Extract policy data from Gx/RX messages
def retrieveAndValidatePolicyRules(diamDct, lclDCT, printFlag = False, interface='gx'):
        # Define heading
        heading = interface.capitalize() + ' Rules updates: '
        
        # Clear misc data
        misc = ''
        
        # Debug output
        #pprint.pprint(diamDct)
        
        # Get policy info to validate
        policyIdentifier = lclDCT['policyIdentifier']
        policyStatus = lclDCT['policyStatus']
        
        # Check if we should evaluate policy
        evaluatePolicy = policyValidationInputChecks(lclDCT)
        
        # Add Gx rule install/remove
        errorFlag = False
        for keyStart in ['Remove', 'Install']:
                rules=''
                for i in range(10):
                        # If we run out of items, then break.
                        # First entry may not have a number after it, so address that possibility here.
                        key1 = 'Charging-Rule-' + keyStart          + '->Charging-Rule-Name'
                        key2 = 'Charging-Rule-' + keyStart + str(i) + '->Charging-Rule-Name'
                        key3 = 'Charging-Rule-' + keyStart          + '->Charging-Rule-Base-Name'
                        key4 = 'Charging-Rule-' + keyStart + str(i) + '->Charging-Rule-Base-Name'
                        
                        if   i == 0 and key1 in diamDct: key = key1
                        elif i == 0 and key3 in diamDct: key = key3
                        elif key2 in diamDct: key = key2
                        elif key4 in diamDct: key = key4
                        else: break
                        
                        # Add value to string
                        data = diamDct[key].split(':')
                        if len(data) > 1: data = data[2][:-1]
                        
                        # Data may be encoded.  So an ascii "a" is two characters ('61').
                        # It's also in a list here, so need to map the entry to a string.
                        data = ', '.join(data)
#                       print 'policy extraction data: ' + data
                        
                        # If all hex characters and even, then convert.
                        # There are issues if a rule group is all digits...
                        try:
                                if (all(c in string.hexdigits for c in data)) and (len(data)%2 == 0): data = data.decode("hex")
                        except:
                                kef = 1
                        
                                # b16decode was maybe working.  Need to figure this out...
#                               try:
#                                       data = base64.b16decode(data.upper())
#                               except:
#                                       kef = 1
                        
                        # See if activation and/or deactivation time specified
                        activationEntry = key.split('>')[0] + '>Rule-Activation-Time'
                        if activationEntry in diamDct:
                                activationEntry = diamDct[activationEntry].split('(')[1].split(')')[0]
                        else:   activationEntry = None
                        deactivationEntry = key.split('>')[0] + '>Rule-Deactivation-Time'
                        if deactivationEntry in diamDct:
                                deactivationEntry = diamDct[deactivationEntry].split('(')[1].split(')')[0]
                        else:   deactivationEntry = None
                        if activationEntry or deactivationEntry:
                                data += '('
                                if activationEntry: data += activationEntry + '[A], '
                                if deactivationEntry: data += deactivationEntry + '[D]'
                                data += ')'
                        
                        # Add to output; start new line for new rule
                        rules += data
                        rules += '\n' + ' '*(len(keyStart)+2) + ' '*len(heading)
                        
                        # Validate against policy if defined
                        if evaluatePolicy:
                                # Local check flag
                                found = False
#                               print 'Validating returned policy ' + str(data) + ' with value ' + keyStart
#                               pprint.pprint(policyIdentifier)
#                               pprint.pprint(policyStatus)
                                
                                # Process each expected policy item
                                for j in range(len(policyIdentifier)):
                                        # Check if not None, it matches the input or the validation says to match anything, and the action is correct (install/remove).
                                        # Note that the "data" local has activation times if present.  Need to remove those from any comparison (so split the data variable).
                                        if policyIdentifier[j]                                                                                  and \
                                           (policyIdentifier[j].lower() == data.lower().split('(')[0] or policyIdentifier[j].lower() == 'any')  and \
                                           policyStatus[j].lower() == keyStart.lower():
                                                # Debug output
                                                print('Validated Gx policy ' + data + ' was ' + keyStart)
                                                
                                                # Local flag indicating we found what was expected
                                                found = True
                                                
                                                # Clear this expected entry so it can only satisfy one returned rule.
                                                # Probably should del policyIdentifier[j]...
                                                policyIdentifier[j] = None
                                                
                                                # No need to check more in this loop
                                                break
                                
                                # See if current loop failed and partial policy is not enabled
                                if not found and not lclDCT['policyPartial']:
                                        print('ERROR: policy ' + data + ' was unexpectedly ' + keyStart)
                                        
                                        # Set overall failure flag so we fail regardless of other successes
                                        errorFlag = True
                                
                # If we added anything, then append to misc (skipping initial "," character)
                if rules:
                        misc += ' ' + keyStart + ': ' + rules
                        
                        # Go to new line and indent if at end of first pass
                        if keyStart == 'Remove': misc += '\n' + ' '*(len(heading)-1)
        
        # Remove leading space if anything in misc
        if len(misc): misc = misc[1:]
        
        # If printing and anything to print, then output
        if printFlag and len(misc): print(heading + misc)
        
        # Exit here is errors
        if errorFlag:
                if not printFlag: print('Gx Rules updates: ' + misc)
                sys.exit('Gx Rules updates: Exiting due to errors falg sets')
                
        # Validate that if policy checked then all policies input were returned
        if evaluatePolicy:
                for i in range(len(policyIdentifier)):
                        if policyIdentifier[i]:
                                print('ERROR: Policy ' + policyIdentifier[i] + ' was expected to be returned but was not')
                                if not printFlag: print('Gx Rules updates: ' + misc)
                                sys.exit('Gx Rules updates: Exiting due to not all expected policies returned')
        
        return misc

#==========================================================
# Run viewObject to see what imapcts the command had
def printToScreen(saveFunc, queryValue, queryType, lclDCT, lclTime, outputFileName=None):
        # Tired of passing 
        ssl = lclDCT['ssl']
        on = lclDCT['on']
        off = lclDCT['off']
        scope = lclDCT['scope']
        hideExpired = lclDCT['hideExpired']
        hideHidden = lclDCT['hideHidden']
        httpAuthUsername = lclDCT['httpAuthUsername']
        httpAuthPassword = lclDCT['httpAuthPassword']
        hideTemplateData = lclDCT['hideTemplateData']
        hideCustomData = lclDCT['hideCustomData']
        hideOfferData = lclDCT['hideOfferData']
        
        # See what type of object we're dealing with
        if saveFunc == 'saveMDC':
                # Subscriber
                if queryType == 'AccessNumber':  fmt = '--accessNumber ' + queryValue
                elif queryType == 'PhoneNumber': fmt = '--deviceId ' + queryValue
                elif queryType == 'ExternalId':  fmt = '-s ' + queryValue
                elif queryType == 'LoginId':     fmt = '--LoginId ' + queryValue
                else:                            fmt = '--soid ' + queryValue
        elif saveFunc == 'saveDeviceMDC':
                # Device
                if queryType == 'AccessNumber':  fmt = '--msisdn ' + queryValue
                elif queryType == 'PhoneNumber': fmt = '--imsi ' + queryValue
                elif queryType == 'LoginId':     fmt = '--LoginId ' + queryValue
                elif queryType == 'AccessId':    fmt = '--accessId ' + queryValue
                elif queryType == 'ExternalId':  fmt = '--deviceId ' + queryValue
                else:                            fmt = '--doid ' + queryValue
        elif saveFunc == 'saveUser':
                # User
                if queryType == 'UserId':       fmt = '-u ' + queryValue
                elif queryType == 'ExternalId': fmt = '--uxid ' + queryValue
                else:                           fmt = '--uoid ' + queryValue
        elif saveFunc == 'saveSubscription':
                # Subscription
                if queryType == 'ExternalId':   fmt = '--subxid ' + queryValue
                else:                           fmt = '--suboid ' + queryValue
        else:
                # Group
                if queryType == 'ExternalId':   fmt = '-g ' + queryValue
                else:                           fmt = '--goid ' + queryValue
        
        # Add common options for viewObject and viewEventStore
        if scope and scope.lower() != 'local': fmt += ' --scope ' + scope
        if httpAuthUsername: fmt += ' --httpAuthUsername ' + httpAuthUsername + ' --httpAuthPassword ' + httpAuthPassword
        if ssl: fmt += ' --ssl '
        
        # Add in other options for viewObject only
        fmt2 = ''
        if on:  fmt2 += ' --on ' + on
        if off: fmt2 += ' --off ' + off
        if lclTime: fmt2 += ' --date ' + lclTime
        if hideExpired: fmt2 += ' --hideExpired '
        if hideHidden: fmt2 += ' --hideHidden '
        if hideTemplateData: fmt2 += ' --hideTemplateData '
        if hideCustomData: fmt2 += ' --hideCustomData '
        if hideOfferData: fmt2 += ' --hideOfferData '
        
        # Return to common items
        fmt3 = ''
        if outputFileName: fmt3 += ' > ' + outputFileName
        
        # Execute command to print the data
        cmd = 'viewObject.py ' + fmt + fmt2 + fmt3
        print('\nRunning command "' + cmd  + '"\n')
        print(QAUTILS.runCmd(cmd))
        
        # If events enabled then run that command
        if lclDCT['viewEvents']: 
                # Want to view the events.  The events patameter has the lower bound time to use, so add to the command line
                cmd = 'viewEventStore.py ' + fmt
                if lclDCT['viewEvents'] != True: cmd += lclDCT['viewEvents'] 
                cmd += fmt3
                print('\nRunning command "' + cmd + '"\n')
                print(QAUTILS.runCmd(cmd))
        
#==========================================================
def custAddCustomData(servicesConfig):
        # Get custom data
        custData = GENERIC.getCustomData(servicesConfig)
        #print 'custAddCustomData:'
        
        # For some #$%^% reason Python seems to be linking arrays.  I append to one array and 
        # it shows up in multiple arrays.  No idea why as they're all created separately...
        # Fix it here by doing a copy
        for obj in GENERIC.customItemsToCheckFor:
                for entry in custData[obj]: custData[obj][entry] = custData[obj][entry][:]
        
        # Process Diameter ditionary base AVPs
        print('Adding Diameter AVP mappings')
        if hasattr(CUST, "diameterGroupMappings"):
                # Process data
                DATA.DiameterAVPs = GENERIC.getDiameterAVPs(CUST.diameterGroupMappings)
                
                # Extend custom data to add AVP/MDC to custKeyAVPs
                for protocol in ['Gy', 'Gx', 'Sy']:
                        # See if anything defined for this protocol (entry defined and some entries in there)
                        if 'AVP_AVP_'+protocol in DATA.DiameterAVPs and len(DATA.DiameterAVPs['AVP_AVP_'+protocol]):
                                custData['AVP_AVP_'+protocol].extend(DATA.DiameterAVPs['AVP_AVP_'+protocol])
                                custData['AVP_MDC_'+protocol].extend(DATA.DiameterAVPs['AVP_MDC_'+protocol])
        else:   DATA.DiameterAVPs = GENERIC.getDiameterAVPs([])
        
        # Debug output
        #pprint.pprint(GENERIC.CustomDataZip)

        # Define fields already defined.  Need to address the case where the same parameter is defined in multiple custom objects.
        # User will be required to addres this.
        fieldsAlreadyDefined = {}
        if hasattr(CUST, "custCustomSubscriberParameters"):
                for i,field in enumerate(CUST.custCustomSubscriberParameters): fieldsAlreadyDefined[field[0]] = 'Subscriber'
        if hasattr(CUST, "custCustomDeviceParameters"):
                for i,field in enumerate(CUST.custCustomDeviceParameters): fieldsAlreadyDefined[field[0]] = 'Device'
        if hasattr(CUST, "custCustomOfferParameters"):
                for i,field in enumerate(CUST.custCustomOfferParameters): fieldsAlreadyDefined[field[0]] = 'Offer'
        if hasattr(CUST, "custCustomGroupParameters"):
                for i,field in enumerate(CUST.custCustomGroupParameters): fieldsAlreadyDefined[field[0]] = 'Group'
        if hasattr(CUST, "custCustomUserParameters"):
                for i,field in enumerate(CUST.custCustomUserParameters): fieldsAlreadyDefined[field[0]] = 'User'
        if hasattr(CUST, "custCustomLoginParameters"):
                for i,field in enumerate(CUST.custCustomLoginParameters): fieldsAlreadyDefined[field[0]] = 'Login'
        if hasattr(CUST, "custCustom5GRequestParameters"):
                for i,field in enumerate(CUST.custCustom5GRequestParameters): fieldsAlreadyDefined[field[0]] = '5GRequest'
        if hasattr(CUST, "custCustomApiEventDataParameters"):
                for i,field in enumerate(CUST.custCustom5GRequestParameters): fieldsAlreadyDefined[field[0]] = 'ApiEventData'
#       print 'fieldsAlreadyDefined = ' + str(fieldsAlreadyDefined)
        
        # Need to move creation of objects outside the following loop, as we can't exec creation from Python 3 onwards
        if not hasattr(CUST, 'custParameters'):                 CUST.custParameters = []
        if not hasattr(CUST, 'custCustomSubscriberParameters'): CUST.custCustomSubscriberParameters = []
        if not hasattr(CUST, 'custCustomGroupParameters'):      CUST.custCustomGroupParameters = []
        if not hasattr(CUST, 'custCustomOfferParameters'):      CUST.custCustomOfferParameters = []
        if not hasattr(CUST, 'custCustomUserParameters'):               CUST.custCustomUserParameters = []
        if not hasattr(CUST, 'custCustomLoginParameters'):      CUST.custCustomLoginParameters = []
        if not hasattr(CUST, 'custCustomApiEventDataParameters'):       CUST.custCustomApiEventDataParameters = []
        if not hasattr(CUST, 'custCustomMultiServiceDataParameters'):   CUST.custCustomMultiServiceDataParameters = []
        if not hasattr(CUST, 'custCustom5GChargingDataRequestParameters'):CUST.custCustom5GChargingDataRequestParameters = []
        if not hasattr(CUST, 'custCustomMultiUnitUsageDataParameters'): CUST.custCustomMultiUnitUsageDataParameters = []
        
        # Start processing.  Assume we have all the custom structures here.  Will error out if not (which is fine at this point).
        for object in GENERIC.customItemsToCheckFor:
                # If a device and using the default custom device, then do nothing here
                if object == 'Device' and custData[object]['customName'] == 'MtxMobileDevice': continue
                
                # Map a few strings so this works for Diameter as well as objects
                if object not in ['DiamRoMsg', 'DiamGxCCMsg']:  custObjName = 'custCustom' + object + 'Parameters'
                else:                                           custObjName = 'custParameters'
                
                # Go through all custom fields
                for i,field in enumerate(custData[object]['customFields']):
                        # If we've already encountered this field, then print and skip
                        if field in fieldsAlreadyDefined:
                                print('WARNING: field ' + field + ' already processed.  Detecting additional entry in custom object ' + object)
                                #continue
                        
                        # Update custom data
                        cmd= 'updateCustomData(custData, i, object, CUST.' + custObjName + ', fieldsAlreadyDefined)'
                        exec(cmd)
                        
                        # Process structs
                        if custData[object]['customFieldTypes'][i] == 'struct':
                                # Walk the struct, finding all non-structs and adding them.
                                updateCustomStruct(i, object, custObjName, fieldsAlreadyDefined, field)
        '''     
        try: print str(CUST.custCustomApiEventDataParameters)
        except: pass
        '''     
        
        # Update custKeyAVPs[] using AVP information
        if hasattr(CUST, 'custKeyAVPs'):
           # Suporting a limited set of protocol
           for protocol in ['Gy', 'Gx', 'Sy', 'Sh']:
             # Get key names
             avpEntry = 'AVP_AVP_' + protocol
             mdcEntry = 'AVP_MDC_' + protocol

             # See if anything defined for this
             if avpEntry in custData:
               # Debug output
#               print 'Protocol ' + avpEntry + ': ' + str(custData[avpEntry])
#               print 'Protocol ' + mdcEntry + ': ' + str(custData[mdcEntry])

               # Process all AVP/MDC mappings for this protocol
               for i in range(len(custData[avpEntry])):
                        # Get the mapping components
                        avp = custData[avpEntry][i]
                        mdc = custData[mdcEntry][i]

                        # Now see if the MDC field is already defined in this custom structure
                        found = False
                        for j,parameter in enumerate(CUST.custKeyAVPs):
                                if CUST.custKeyAVPs[j][1] == mdc:
                                        found = True
                                        break
                        
                        # Add if not found
                        if not found:
                                #print 'Adding MDC/AVP mapping ' + mdc + '/' + avp + ' to custKeyAVPs for protocol ' + protocol
                                
                                # Don't specify service.  Use defaults.  Service not known in create_config, 
                                # so default of "all" is all we can do.
                                # Next enhancement will be to recognize service.
                                CUST.custKeyAVPs.append([avp, mdc, avp, protocol.lower(), 'all'])
                                
                                # AVP may reference existing MDC field.  This then needs to be made a parameter
                                if mdc not in fieldsAlreadyDefined:
                                        # Add to custom structs.  Perhaps should do this in primGeneric...
                                        custData['DiamRoMsg']['customFields'].append(mdc)
                                        custData['DiamRoMsg']['customFieldTypes'].append('string')
                                        
                                        # Really shouldn't assume parameter is not a list...
                                        custData['DiamRoMsg']['customFieldlist'].append('n')
                                        
                                        # Update custom data
                                        idx = len(custData['DiamRoMsg']['customFields']) - 1
                                        updateCustomData(custData, idx, 'DiamRoMsg', CUST.custParameters, fieldsAlreadyDefined)
        
        # Update custKeyAVPs[] using 5G information
        message = '5GChargingDataRequest'
        if hasattr(CUST, 'custKeyAVPs') and message in custData:
                # This protocl is 5G
                interface = '5G'
                
                # Process each entry
                for i in range(len(custData[message]['customFields'])):
                        # Skip if delete schema is not zero (i.e. field is deleted)
                        if custData[message]['deletedSchemaList'][i] != '0': continue
                        
                        # Skip if a struct
                        if custData[message]['customFieldTypes'][i] == 'struct': continue
                        
                        # Get field (default TF parameter) name
                        parameter = custData[message]['customFields'][i]
                        
                        # NOTE: Some people (not named Bob Stones) want to map top-level message fields to different MDCs.
                        # The code here maps input fields to MDCs 1:1.  In order to allow for this non-1:1 (where the mapping
                        # is specified in custSpecifc.py), see if the parameter is already in there for this interface.
                        try:    parameter = CUST.nameChange[parameter]
                        except: pass
                        
                        # Always add to top level (don;t know path if we need to add this)
                        field = parameter
                        
                        # Add to interface.  Send for all services (can't distinguish yet voice/data/text/etc.).
                        if not len([x[1] for x in CUST.custKeyAVPs if len(x) >= 4 and x[1] == parameter and x[3].lower() == interface.lower()]):
                                print('Adding 5G ' + message + ' custom parameter "' + parameter + '" to CUST.custKeyAVPs')
                                
                                # Check if this is already defined in main data or custom data (add if not; warn if so)
                                if      len([x[1] for x in CUST.custKeyAVPs    if x[1] == parameter]) or \
                                        len([x[1] for x in DATA.keyAVPs        if x[1] == parameter]) or \
                                        len([x[0] for x in CUST.custParameters if x[0] == parameter]) or \
                                        len([x[0] for x in DATA.parameters     if x[0] == parameter]):
                                        print('WARNING: Parameter"' + parameter + '" already defined.  Please check csv_data.py and custSpecific.py to see if defined (and then remove).')
                                else: CUST.custKeyAVPs.append([field,        parameter,      field,    interface, 'all'])
                        else: print('NOTE: not adding a 1:1 mapping for ' + message + ' field "' + parameter + '" since a maping already exists in custKeyAVPs.')
                
                '''
                print '5G custKey data: '
                pprint.pprint([x for x in CUST.custKeyAVPs if x[3] == interface])
                sys.exit('Early Exit')
                '''
        
        return custData

#========================================================================
def updateCustomStruct(i, obj, custObjName, fieldsAlreadyDefined, structHierarchy):
#       pprint.pprint(GENERIC.CustomDataZip)
        
        # Get the field in question
        structField = GENERIC.CustomDataZip[obj][i][0]
        
        # Get the struct being pointed to
        structure = GENERIC.CustomDataZip[obj][i][2]
        
        # See if structure was defined in config file.  If not, then we don;t know about it.
        if structure not in GENERIC.CustomDataZip:
                print('Warning: object ' + obj + ' field ' + structField + ' references structure ' + structure + ' which is not defined in create_config.info.  TF can\'t create automatic mappings for this')
                return
        
        # Debug output
        #print 'Processing object ' + obj + ' structure field ' + structField + ' structure: ' + structure
        
        # Walk the sructure
        for j,entry in enumerate(GENERIC.CustomDataZip[structure]):
                #print 'Processing entry ' + str(entry)
                
                # Get key items in the entry
                fieldName = entry[0]
                fieldType = entry[1]
                
                # Add field (struct or base)
                cmd = "updateCustomData(GENERIC.CustomData, j, structure, CUST." + custObjName + ", fieldsAlreadyDefined, structHierarchy)"
                exec(cmd)
        
                # If this is a struct then iterate, else add the field
                if fieldType == 'struct':
                        #print obj + ' custom parameters: Encountered struct ' + fieldName
                        updateCustomStruct(j, structure, custObjName, fieldsAlreadyDefined, structHierarchy+'|'+fieldName)
#========================================================================
def updateCustomData(custData, i, object, custObjData, fieldsAlreadyDefined, structHierarchy=''):
                        # Set the field
                        field = custData[object]['customFields'][i]
                        
                        # Loop through all the custom object parameters
                        found = False
                        for j,parameter in enumerate(custObjData):
                                # See if the field exists
                                if field == custObjData[j][0]:
                                        found = True
                                        break

                        # See if we broke early
                        if found: return
                        
                        # If here, then we need to append to the custom parameter
                        if   custData[object]['customFieldTypes'][i] == 'binary':
                                operation = "store_true"
                                storeType = None
                        elif custData[object]['customFieldTypes'][i].count('int'):
                                operation = "store"
                                storeType = 'int'
                        else:
                                # Default everything else to a string
                                operation = "store"
                                storeType = 'string'
                        
                        # Add if a field
                        if operation: custObjData.append((field, operation, storeType, None, None, None, structHierarchy ))
                        
                        # Add to dictionary of processed fields
                        fieldsAlreadyDefined[field] = object
                        
                        # If an integer or decimal, then allow for unit translation 
                        if custData[object]['customFieldTypes'][i] in ['decimal'] or custData[object]['customFieldTypes'][i].count('int'):
                                # Add list if not defined
                                if not hasattr(CUST, 'custUnitParameters'): CUST.custUnitParameters = []
                                
                                # Only add if not already defined (as some parameters may use other parameter translation data)
                                found = False
                                for j,parameter in enumerate(CUST.custUnitParameters):
                                        if CUST.custUnitParameters[j][0] == field:
                                                found = True
                                                break
                                if not found:
                                        #print 'Adding ' + field + ' to unit list'
                                        CUST.custUnitParameters.append(field)
                        
                        # If a string, integer or decimal, then allow for name translations
                        if custData[object]['customFieldTypes'][i] in ['decimal', 'string', 'binary'] or custData[object]['customFieldTypes'][i].count('int'):
                                # Add list if not defined
                                if not hasattr(CUST, 'custParameterTranslate'): CUST.custParameterTranslate = []
                                
                                found = False
                                for j,parameter in enumerate(CUST.custParameterTranslate):
                                        if CUST.custParameterTranslate[j][0] == field:
                                                found = True
                                                break
                                if not found:
                                        #print 'Adding ' + field + ' to translate list'
                                        
                                        # Bool can use the TrueFalse table; non-binary uses itself
                                        if custData[object]['customFieldTypes'][i] != 'binary':
                                                CUST.custParameterTranslate.append((field, None, False))
                                        else:   
                                                #print 'Adding boolean field ' + field + ' to TrueFalse translate'
                                                CUST.custParameterTranslate.append((field, 'TrueFalse', False))

                        # If a list, then allow for lists
                        if custData[object]['customFieldlist'][i] == 'y':
                                # Add list if not defined
                                if not hasattr(CUST, 'custListParameters'): CUST.custListParameters = []
                                
                                #print 'Adding ' + field + ' to list lists'
                                CUST.custListParameters.append(field)
        
#==========================================================
# Extend custom lists based on create_config data.
# Update parameter data.
def extendCustomerSpecifcListsUsingCreateConfig(servicesConfig):
        # Extend the custom lists
        custData = custAddCustomData(servicesConfig)

        # Override custom object names
        for object in GENERIC.customItemsToCheckFor:
                # Skip if not populated
                if object not in custData or object not in ['Subscriber', 'Device', 'Group', 'User', 'Login', 'Offer', 'ApiEventData']: continue
                
                # If custom name defined, then override parameters here
                if custData[object]['customName']: 
                        # Get first part of custom name (as remainder may be lists within the object)
                        customName = custData[object]['customName'].split("/")[0].strip()
                        
                        # Remove the item
                        if   object == 'Subscriber':    paramName = 'customSubName'
                        elif object == 'Device':        paramName = 'customDevName'
                        elif object == 'Group':         paramName = 'customGroupName'
                        elif object == 'User':          paramName = 'customUserName'
                        elif object == 'Login':         paramName = 'customLoginName'
                        elif object == 'ApiEventData':  paramName = 'customApiEventDataName'
                        else:                           paramName = 'customOfferName'
                        #print 'Storing ' + paramName + ' : ' + customName
                        DATA.parameters.remove((paramName, 'store', 'string', ''))
                        DATA.parameters.append((paramName, 'store', 'string', customName))
                                        
#==========================================================
# Extend lists depending on what a specific customer has defined in their customer specific file
def extendCustomerSpecifcLists(servicesConfig):
        # This takes time, so output something
        print('Reading/Extending custom fields')
        
        # Append custom defined objects to custom parameters
        extendCustomerSpecifcListsUsingCreateConfig(servicesConfig)
        
        # Add custom lists to private lists
        if hasattr(CUST, "custParameters"):                     DATA.parameters.extend(CUST.custParameters)
        if hasattr(CUST, "custCustomSubscriberParameters"):     DATA.customSubscriberParameters.extend(CUST.custCustomSubscriberParameters)
        if hasattr(CUST, "custKeyAVPs"):                        DATA.keyAVPs.extend(CUST.custKeyAVPs)
        if hasattr(CUST, "custListParameters"):                 DATA.listParameters.extend(CUST.custListParameters)
        if hasattr(CUST, "custTimeParameters"):                 DATA.timeParameters.extend(CUST.custTimeParameters)
        if hasattr(CUST, "custIdParameters"):                   DATA.idParameter.extend(CUST.custIdParameters)
        if hasattr(CUST, "custUnitParameters"):                 DATA.unitParameters.extend(CUST.custUnitParameters)
        if hasattr(CUST, "custCustomGroupParameters"):          DATA.customGroupParameters.extend(CUST.custCustomGroupParameters)
        if hasattr(CUST, "custCustomOfferParameters"):          DATA.customOfferParameters.extend(CUST.custCustomOfferParameters)
        if hasattr(CUST, "custCustomUserParameters"):           DATA.customUserParameters.extend(CUST.custCustomUserParameters)
        if hasattr(CUST, "custCustomDeviceParameters"):         DATA.customDeviceParameters.extend(CUST.custCustomDeviceParameters)
        if hasattr(CUST, "custCustomLoginParameters"):          DATA.customLoginParameters.extend(CUST.custCustomLoginParameters)
        if hasattr(CUST, "custCustomApiEventDataParameters"):   DATA.customApiEventDataParameters.extend(CUST.custCustomApiEventDataParameters)
        if hasattr(CUST, "custParameterTranslate"):             DATA.parameterTranslate.extend(CUST.custParameterTranslate)
        if hasattr(CUST, "custParameterGyValidate"):            DATA.parameterGyValidate.extend(CUST.custParameterGyValidate)
        if hasattr(CUST, "custParameterSyValidate"):            DATA.parameterSyValidate.extend(CUST.custParameterSyValidate)
        if hasattr(CUST, "custParameterShValidate"):            DATA.parameterShValidate.extend(CUST.custParameterShValidate)
        
        # 5G items
        if hasattr(CUST, "custCustom5GChargingDataRequestParameters"): DATA.custom5GRequestParameters.extend(CUST.custCustom5GChargingDataRequestParameters)
        
        # Custom CCF goes to CCF file parameters
        if hasattr(CUST, "custCcfReuseParameters"):             CCF.ccfReuseParameters.extend(CUST.custCcfReuseParameters)
        if hasattr(CUST, "custCcfParameters"):                  CCF.parameters.extend(CUST.custCcfParameters)
        
        # Now meed to loop through some and pick-off the key values
        if hasattr(CUST, "custCustomSubscriberParameters"):     
#               print 'Found custom subscriber parameters.  Length = ' + str(len(CUST.custCustomSubscriberParameters))
                for i in range(len(CUST.custCustomSubscriberParameters)): DATA.subscriberModifyList.append((CUST.custCustomSubscriberParameters[i][0]))
        if hasattr(CUST, "custCustomGroupParameters"):  
                for i in range(len(CUST.custCustomGroupParameters)): DATA.groupModifyList.append((CUST.custCustomGroupParameters[i][0]))
        if hasattr(CUST, "custCustomDeviceParameters"):         
                for i in range(len(CUST.custCustomDeviceParameters)): DATA.deviceModifyList.append((CUST.custCustomDeviceParameters[i][0]))
        if hasattr(CUST, "custCustomUserParameters"):   
                for i in range(len(CUST.custCustomUserParameters)): DATA.userModifyList.append((CUST.custCustomUserParameters[i][0]))
        if hasattr(CUST, "custCustomLoginParameters"):  
                for i in range(len(CUST.custCustomLoginParameters)): DATA.loginModifyList.append((CUST.custCustomLoginParameters[i][0]))
        
        # Sanity check one of these
#       print 'custom subscriber parameters: ' + str(customSubscriberParameters)

#==========================================================
# Top-level function for reading pricing and extending custom data
def getCustomMappings(skipFriendlyNames=False, release='5100', regressionRun='None'):
        print('Getting pricing data from engine REST queries')
        
        # Always want status life cycle.  Need this for the TF remove<Object> command.  So more than a friendly name...
        getCustomLifeCycleMappings(regressionRun, release=release)
        
        # Get event types
        DATA.eventTypeStringArrayMapping = merge_two_dicts(DATA.eventTypeStringArrayMapping, getEventTypeMappings(regressionRun))
        
        # Rest of this is just to make TF scripts more user friendly.  One customer asked to not support this
        # (want all scripts to look like what the real world would do).  Soooo....
        if not skipFriendlyNames:
                getCustomOfferMappings(release, regressionRun)
                getCustomBalanceMappings(regressionRun)
                getCustomBillingProfileMappings(regressionRun)
                if int(release) >= 5120: DATA.rolesPricingIdsMapping = getUserRoles(regressionRun)
                
                # Catalog items replace offer IDs.  Get offer fucntion now reads catalog items.
#               getCustomCatalogItemIdMappings(regressionRun)

#==========================================================
# Extend default mappings for life cycle data
def getCustomLifeCycleMappings(regressionRun='None', release="5100"):
        # Get life cycle data for the target and extend global mapping data
        dctRcv = getLifeCycles('subscriber', regressionRun)
        DATA.subStatusMapping.update(dctRcv)
        
        dctRcv = getLifeCycles( 'device', regressionRun)
        DATA.devStatusMapping.update(dctRcv)
        
        dctRcv = getLifeCycles('group', regressionRun)
        DATA.groupStatusMapping.update(dctRcv)
        
        try:
               if int(release) >= 5120:
                dctRcv = getLifeCycles('user', regressionRun)
                DATA.userStatusMapping.update(dctRcv)
        except: pass
        
#==========================================================
# Extend default mappings for billing profile data
def getCustomBillingProfileMappings(regressionRun='None'):
        dctRcv = getBillingProfiles(regressionRun)
        DATA.profileIdMapping.update(dctRcv)
        
#==========================================================
# Extend default mappings for offer data
def getCustomOfferMappings(release='5100', regressionRun='None'):
        # Get offer name to external ID and name to ID mappings
        (dctNameToExtId,dctExtIdToId) = getOffers(release, regressionRun)

        # Extend the current lists
        DATA.offerIdMapping.update(dctNameToExtId)
        DATA.offerExtIdToId.update(dctExtIdToId)
        
#==========================================================
# Extend default mappings for ocatalog item data
def getCustomCatalogItemIdMappings(regressionRun='None'):
        # Should never call this function
        sys.exit('getCustomCatalogItemIdMappings: should never call this function')
        
        # Get all balance and Class data so mapping is done automatically
        dctOffer = getCatalogItemId()

        # Extend the current lists
        DATA.catalogItemIdMapping.update(dctOffer)
        
#==========================================================
# Extend default mappings for balance data
def getCustomBalanceMappings(regressionRun='None'):
        # Get all balance and Class data so mapping is done automatically
        (dctBal, dctClass, dctBalName, dctClassName) = getBalances(regressionRun)

        # Extend the current lists for name to ID
        DATA.modBalanceIdMapping.update(dctBal)
        DATA.balanceIdMapping.update(dctBal)
        DATA.balanceClassIdMapping.update(dctClass)
        
        # Extend the current lists for ID to name
        DATA.balanceNameMapping.update(dctBalName)
        DATA.balanceClassNameMapping.update(dctClassName)
        
#==========================================================
# Translate parameters from text to int
def translateTextFromMapping(parameter, lclDCT):
    # Get entries - Name is required
    name = parameter[0]
    
    # Get value into local.  Not all items in the list are parameters, so address that.
    try:
        value = lclDCT[name]
    except:
#       print 'WARNING:  parameter "' + name + '" is in the parameter translate list but not in the overall parameter list'
        return None
    
    # Work to do iff lclDCT parameter is not null
    #print 'Parameter ' + name + ' Input list: ' + str(value)
    if not value:
        # NOTE: this changes all False to None, which is what API parameters expect.
        lclDCT[name] = None
        return lclDCT[name]
    
    #print('Looking to translate parameter ' + name + ' with input value: ' + str(value))

    # Mapping is optional
    if len(parameter) > 1:  mapping = parameter[1]
    else:                   mapping = None
    
    # exit on failure is optional
    if len(parameter) > 2:  exitOnMapping = parameter[2]
    else:                   exitOnMapping = True
    
    # Initialize modified and return lists
    newList = []
    updatedList = []
    
    # May receive a list or a single item
    if type(value) is list: newList.extend(value)
    else:                   newList.append(value)
    #print 'Parameter ' + name + ' Input list: ' + str(newList)
    
    # Look at each item in the list
    for item in newList:
        # If not defined, then skip
        if item == None: continue
        
        #print('inputs to translate are: name=' + name + ', value=' + str(item))
        
        # Move check for all digits to inside the translate, as one may translate all digits.
        if False: kef = 1
        #if str(item).translate(trantab).isdigit(): retval = item
        else:
                # If a mapping was provided, then use it, else use default parameter name
                if mapping: mapValue = mapping
                else:       mapValue = name
        
                # Make sure there's translate data defined (else possible error).
                # Custom entries take precedence over default ones (update action overwrites duplicate entries).
                combinedDct = {}
                cmd  =  'if hasattr(DATA, "' + mapValue + 'Mapping"): combinedDct.update(DATA.' + mapValue + 'Mapping) \n'
                cmd +=  'if hasattr(CUST, "' + mapValue + 'Mapping"): combinedDct.update(CUST.' + mapValue + 'Mapping) \n'
                #print('translateTextFromMapping: custom translate exec command: "' + cmd + '"')
                exec(cmd)
                
                # Now process combined dictionary
                if combinedDct: retval = CSVID.translate_data(name, item, combinedDct, exitOnMapping)
                elif not exitOnMapping: retval = item 
                else: sys.exit("ERROR: supposed to translate parameter ' + name + ' but no DATA or CUST ' + mapValue + ' Mapping data exists.")

        # Append calculated value
        if type(retval) in [list]: 
                #print 'Input '+ item + ' returned a translated list of ' + str(retval)
                updatedList.extend(retval)
        elif type(retval) in [bool]: 
                updatedList.append(retval)
        else:   updatedList.append(str(retval).strip("'"))
        
    # What is returned depends on what was input and if we have an integer value or not.
    # NOTE: this funtion can return a string (ugh).  If the input is all digits, then it returns the input (which is a string).
    if type(value) is list:     lclDCT[name] = copy.deepcopy(updatedList)
    elif len(updatedList) == 0: lclDCT[name] = None
    else:                       lclDCT[name] = updatedList[0]
    
    #print('translateTextFromMapping: returning: ' + str(lclDCT[name]))
    return lclDCT[name]
    
#==========================================================
def _convertAmountsToIntegers(coefficient, scale):
        return int(coefficient * scale)
        
#==========================================================
# Convert individual elements of input lists in case they have short-nad notation
def convertAmountsToIntegers(inputItem):
    # Add defines for common units to their base amount
    # Volume (Data)
    B = 1
    KB = 1024 * B
    MB = 1024 * KB
    GB = 1024 * MB
    TB = 1024 * GB

    # Duration (Time)
    SEC = 1
    MIN = 60 * SEC
    HOUR = 60 * MIN
    DAY = 24 * HOUR
    WEEK = 7 * DAY
    YEAR = 365 * DAY

    # For text/MMS, always use 1
    ITEM = NUMBER = 1
    
    # Initialize modified and return lists
    newList = []
    updatedList = []
    
    # May receive a list or a single item
    if type(inputItem) is list: newList.extend(inputItem)
    else: newList.append(inputItem)
    #print 'Input list: ' + str(newList)
    
    # Look at each item in the list
    for item in newList:
        # If not defined, then skip
        if item == None: continue
        
        # Signal nothing found
        strFound = ''
        
        # See if the entry contains any of the key fields.
        # Check larger words first, so smaller ones don't incorrectly match a string in the larger words.
        for strToCheck in 'sec', 'min', 'hour', 'day', 'week', 'year', 'item', 'number', 'cent', 'dollar', 'kb', 'mb', 'gb', 'tb', 'b':
                # check for 
                if str(item).lower().count(strToCheck):
                        strFound = strToCheck
                        break
                
        # If we found the string, and it's not part of a formula, then process the data
        if strFound and item[0] != '(':
                #print 'item ' + item + ' has a unit string'
                # Split the item, using the string as the delimiter
                itemSplit = item.lower().split(strFound)
                
                # The coefficient is the first element.  Allow for a space or a comma between the number and the unit.  
                coefficient = float(itemSplit[0].strip().rstrip(',').rstrip())
                
                # Deal with $ separately
                if strFound == 'cent':
                        # Put into dollars format, with leading dollar sign (tells the tool this is a currency value)
                        dollars = int(old_div(coefficient, 100))
                        cents   = int(coefficient % 100)
                        result  = '$' + str(dollars) + '.' + '{0:02}'.format(cents)
                        #print 'Dollars = ' + str(dollars) + ', cents = ' + str(cents) + ', resulting currency: ' + result
                elif strFound == 'dollar':
                        # Put into dollars format, with leading dollar sign (tells the tool this is a currency value)
                        result  = '$' + str(coefficient)
                else:
                        # Build the Python command to get the results
                        cmd = "_a = _convertAmountsToIntegers(coefficient, " + strFound.upper() + ")"
                        #print("cmd = " + cmd)
                        exec(cmd)
                        result = locals()['_a']
                        
                # Append the result to the udpated list
                updatedList.append(result)
        else:
                # Use value as-is
                updatedList.append(item)
    
#    print 'returning list: ' + str(updatedList)
    
    # What is returned depends on what was input and if we have an integer value or not
    if type(inputItem) is list: return updatedList
    elif len(updatedList) == 0: return None
    elif str(updatedList[0]).isdigit(): return int(updatedList[0])
    else: return updatedList[0]
    
#==========================================================
def setupCustomerOptions(options):
    # Setup default extraAVP structure
    extraAVP={}
    extraAVP['omit'] = []
    extraAVP['add'] = []
    
    # Set if using MSCC
#    if not options.noMscc: extraAVP['MSCC'] = 1
    
    # Default events to data if not set
    if options.serviceId == '0':
        options.serviceId = 'data'

    # Old code.  Really should get rid of it or move it to customer specific code...
    # Look to setup zone IP address.  Only if it's not set via input
    if options.zoneIpAddress == '':
     # OK, need to ensure we have something for the zone.  If it's 0, set to 1.
     if options.zone == 0:
        options.zone = 1

     # Map zone
     if options.zone > 4:
        # Bad input
        print('Zone entry too high (' + str(options.zone) + ').  Must be between 1-4.')
        sys.exit('Exiting because of bad input for the zone.')
     elif options.zone > 0:
        options.zoneIpAddress = '10'+str(options.zone)+'.0.0.1'
     else:
        options.zoneIpAddress = ''

    # Re-used ratingGroup from other scenarios.  It's default is text (web, facebook, email, etc.).
    # Expecting a numeral for Swisscom.  If set to the default ("web") then change to 1.
    if options.ratingGroup == 'web':
        options.ratingGroup = '1'

    # Return data
    return (extraAVP, options)

#==========================================================
def convertPythonListToToolListFormat(list):

        # Object is a list.  Need to convert to tool list format.
        retList = DATA.listChar.join(list)
        #print 'retList = ' + retList
        return retList
        
#        retList = str(list)
#       print 'retList = ' + retList
#        retList = retList.strip("[]")
#       print 'retList = ' + retList
#        retList = retList.replace("'", "")
#       print 'retList = ' + retList
#       retList = retList.lstrip().rstrip()
#       print 'retList = ' + retList
#        retList = retList.replace("', '",listChar)
#       print 'retList = ' + retList
#
#       return retList

#==========================================================
# Appear this is an old function...
def OLD_appendContentsOfCommandLineInputFiles(args):
        # Define list to track input files (so we don;t go into a recursive loop)
        FileProcessed = {}
        
        # Process until no more files in an input argument
        while DATA.inputFileString in args:
                # Get file parameter index
                index = args.index(DATA.inputFileString)
                
                # Get file name value.  Could be a comma separated list...
                fileNames = args[index+1]
        
                # Now want to remove the input file parameter from the args list, along with the file name, and then insert these args at that location
                args.pop(index)
                args.pop(index)
                
                # Convert argument to a list
                filesToProcess = fileNames.split(DATA.inputFileSepChar)
                
                for fileName in filesToProcess:
                 # Expand the name in case any ENV variables are there
                 fileName = os.path.expandvars(fileName)
                 
                 # Check if we've processed this already
                 if fileName in FileProcessed:
                        print('ERROR:  input files are circular.  Files encountered are: ' + str(FileProcessed) + '. Trying to import file "' + fileName + '" a second time.')
                        sys.exit(1)
                
                 print('Processing command line parameter file ' + fileName)
                
                 # Add entry for this file
                 FileProcessed[fileName] = '1'
                
                 # Clear local args list for this file
                 lclArgs = []
                
                 # Open the file for reading
                 try:
                  f = open(fileName, 'r')
                 except IOError as e:
                  print('I/O error({0}) on opening of file "' + fileName + '". Error details: {1}'.format(e.errno, e.strerror))
                  sys.exit('Done')
                 
                 for line in f:
                        # If a blank line before strip, then it's EOF
                        if not line:
                                break
                        
                        # Remove leading/trailing white space (including the newline char - very annoying!)
                        line = line.rstrip()
                        line = line.lstrip()

                        # If a blank line after a strip, then skip (treat as a comment)
                        if not line:
                                continue

                        # If this starts with a comment character, then it's a comment line and we want to skip it
                        if line[0] in DATA.commentChar:
                                continue
                        
                        # Finaly!  We are at a line to include.   Make sure to split the line as the command and the value are treated as two parameters in Python.
                        # Only split to the first white space, as offers can have white space in their name (this bug took over an hour to figure out!!)
                        # [This will work with the case where there is no white space as well (e.g. -ffile), but we're not doing that here...]
                        lclArgs = line.split(None,1)
                        
                        # Now insert the parameter and argument starting from where the inputfile parameter was present (so we retain order if that ever matters)
                        # Some parameters are binary and thus may not have a value associated with them.
                        args.insert(index, lclArgs[0])
                        index += 1
                        if len(lclArgs) > 1:
                                args.insert(index, lclArgs[1])
                                index += 1
                        
                        #print 'Inserted "' + str(lclArgs) + '" to the args list.  New args list is: "' + str(args)
                        
                # Close the file
                f.close()
                
         #print 'Final args list is: "' + str(args)
        
        # Return final args list
        return args
        
#==========================================================
def dataFileSetup(file, step):
    # Open data file
    try:
     with open(file) as f:
       dataFile = list(f.read().splitlines())
    except IOError as e:
     print('I/O error({0}) on opening of file "' + file + '". Error details: {1}'.format(e.errno, e.strerror))
     sys.exit('Done')

    # Get first non-blank line
    while len(dataFile) and not dataFile[0].strip():
        del dataFile[0]
        step += 1
    
    # Loop until we have a non-comment line
    while len(dataFile) and dataFile[0][0] in DATA.commentChar:
        del dataFile[0]
        step += 1
    
    # If line is empty here, then file didn't contain any non-comment/blank lines
    if not len(dataFile): sys.exit('ERROR: file "' + file + '" did not contain any non-comment or non-blank lines.')
    
    # At first real line.  Get headers
    headers = dataFile[0].split(DATA.paramSepChar)

    # Account for header line
    step += 1
    
    return (dataFile[1:], headers, step)

#==========================================================
def dataFileProcessLine(line, headers, fullList, dontFailOnError=0):
    # Get line into list variable
    lineVals = line.split(DATA.paramSepChar)
    
    #print 'lineVals before:'
    #pprint.pprint(lineVals)
    
    # May have escaped DATA.paramSepChar (using "\" as the predecessor)
    for index in range(len(lineVals)-1, 0, -1):
        # Skip if zero length
        if not len(lineVals[index-1]): continue
        
        # See if previous index ends with the escape character
        if lineVals[index-1][-1] == '\\':
                # Add entry to previous entry with DATA.paramSepChar between them.  Drop the escape character.
                lineVals[index-1] = lineVals[index-1][0:-1] + DATA.paramSepChar + lineVals[index]
                
                # Remove the current entry
                del lineVals[index]
    
        
    #print 'lineVals after:'
    #pprint.pprint(lineVals)
    
    
    #print 'line "' + line + '" is broken into ' + str(len(lineVals)) + ' parts'
    # Loop through line and extract to a dictionary
    index = 0
    lclDCT = {}
    lclDCT['fileHeaders'] = []

    # Want to use length of the line just read.  Mixing subman and diameter in the same file leads to lines with different number of parameters.
    while index < len(lineVals):
        # OK, here it gets fun.  Cell entry may be just the value, or it may be header=value syntax.
        # Check if the latter and override top line headers.  [Use case is where the top line
        # has no meaning; all headers are in the cells.]
        value = lineVals[index].strip()
        
        # Check if assignment.
        # NOTE: if a constant assignment command then can have assignmentChar in the string (can have any character except a ";").
        if DATA.assignmentChar in value and not (value[0] in ['*', '$']):
            # Separate out header and value portions.  Value itself may have the assignment character, so allow for that.
            header = value.split(DATA.assignmentChar)[0].strip()
            val = "=".join(value.split(DATA.assignmentChar)[1:]).strip()
            
            # Sanity check that the parameter is one we expect (and error out if not).
            # Not sure the best way to say "does [0] of any list item = this"...
            found = False
            # First check if exact match (as some custom fields have case difference)
            for entry in fullList:
             if entry[0] == header:
                # Set found flag and break
                found = True
                break;
                
            # If we didn't find the parameter, then see if there's a case mis-match (because we're nice...)
            if not found:
             for entry in fullList:
                if entry[0].lower() == header.lower():
                        # For kicks, see if wrong case and warn user
                        if entry[0] != header:
                                # Warning message
                                print('WARNING: input parameter "' + header + '" has the wrong case as framework parameter "' + entry[0] + '".')
                                print('Test will use framework parameter "' + entry[0] + '".')
                                
                                # Overwrite header so it has the right case
                                header = entry[0]
                        
                        # Set found flag and break
                        found = True
                        break;
                
            # If not found, then a problem...
            if not found:
                print('Error:  invalid parameter found: "' + header + '"')
                pprint.pprint(sorted(fullList, key=lambda entry: entry[0]))
                
                # Exit
                sys.exit('Exiting due to errors')
        else:
            # Use top line header.  Cell is only the value.
            # Sanity check that the user doesn't have a stray seperator beyond the length of the headers.
            if index >= len(headers): 
              # May get here is within a comment string.  Don't want to fail things if in a comment string...
              if dontFailOnError: return lclDCT
              else:
                # Error - can't map this to any parameter
                print('Error:  parameter at position ' + str(index) + ' of line "' + line + '" doesn\'t specify a parameter and is beyond the header list.')
                print('Parameter is: "' + value + '"')
                print('Headers are: ' + str(headers))
                sys.exit('Exiting due to errors')
            
            # If here, than all is good.  Get the header name from the default headers and the value from the command line
            header = headers[index].strip()
            val = value

        # Store into dictionary
        #print 'Storing header ' + header + ' with value ' + str(val) + ' with type = ' + str(type(val))
        lclDCT[header] = val
        
        # Record header
        lclDCT['fileHeaders'].append(header)

        # Bump loop counter
        index += 1
        
        # Special parameter "template" means to grab template file and add to command line
        if header.lower() == 'template' and lclDCT[header]:
            files = val.split(DATA.listChar)
            for inputFile in files:
                # Create command to run
                cmd = 'cat ' + inputFile

                # Run command - translate to array
                data = QAUTILS.runCmd(cmd).split('\n')
                
                # Remove any trailing line from template file
                if data[-1] == '': data = data[:-1]
                
                # Debug
                print('template file ' + inputFile + ' data = ' + str(data))
                
                # Add to line array
                lineVals.extend(data)
        
    # Store all line values
    lclDCT['lineVals'] = copy.deepcopy(lineVals)
    
    # Caller gets the just-built dictionary
    return lclDCT

#==========================================================
def getVarValue(options, cmdLineInput, extraAVP, lclDCT, key):
        debugKey='freter'
        
        # Set local to default value (from options)
        retVal = getattr(options, key)
        
        if key == debugKey: print('Key ' + key + ' after options = "' + str(retVal) + '"')
        
        # If set to None, then skip details
        # See if the input data references this key
        if key in lclDCT and lclDCT[key] != None:
                # If not null, then set flag signaling command line input for this parameter
                if lclDCT[key] != '': cmdLineInput.append(key)
                
                # If null, then add to omit.
                # NOTE:  Need to check why we add input parameters to extraAVP - doesn't seem right...
                if lclDCT[key] == '': extraAVP['omit'].append(key)
                
                # If not a list and set to "use default", then use the value
                elif not type(lclDCT[key]) == type(list()):
                   if lclDCT[key].lower() != DATA.useDefaultChar:
                        retVal = lclDCT[key]
                        
                        # If input is "skip" or "none", then set to None
                        if retVal.lower() == 'skip' or retVal.lower() == 'none': retVal = None
        
        # If a binary value then set to binary
        if   str(retVal).lower() == 'false': retVal = False
        elif str(retVal).lower() == 'true':  retVal = True
        
        # At this time make sure lclDCT reflects all non-null and non-None values to use.
        #if retVal != "" and retVal != None: lclDCT[key] = retVal
        lclDCT[key] = retVal
        
        if key == debugKey: print('returning ' + key + ' = "' + str(retVal) + '"')
        
        return retVal

#===============================================================================
def _getCustomAttributes(value):
    return value

#===============================================================================
def _checkCustomAttributes(value):
    if value:   return True
    else:       return False

#===============================================================================
def getCustomAttributes(lclDCT, cmdLineInput=None):
    # Define tuples used to build custom data for subman API calls
    customObjects=[]
    customObjects.append(('customSubName',   DATA.customSubscriberParameters, 'subAttr'))
    customObjects.append(('customDevName',   DATA.customDeviceParameters,     'devAttr'))
    customObjects.append(('customGroupName', DATA.customGroupParameters,      'groupAttr'))
    customObjects.append(('customOfferName', DATA.customOfferParameters,      'offerAttr'))
    customObjects.append(('customUserName',  DATA.customUserParameters,       'userAttr'))
    customObjects.append(('customLoginName', DATA.customLoginParameters,      'loginAttr'))
    customObjects.append(('customApiEventDataName', DATA.customApiEventDataParameters,      'apiEventAttr'))
    #print 'In getCustomAttributes: DATA.customApiEventDataParameters = ' + str(DATA.customApiEventDataParameters)
    
    # Need to build attr structures outside the loop below, as we can't use exec() to create variables from Python 3 onwards
    cmd = '_a = _getCustomAttributes(MDCDEFS.k' + lclDCT['customSubName'] + 'ExtensionMdcDesc.create())'
    try:
        exec(cmd)
        subAttr = locals()['_a']
    except:     subAttr = None
    
    cmd = '_a = _getCustomAttributes(MDCDEFS.k' + lclDCT['customDevName'] + 'ExtensionMdcDesc.create())'
    try:
        exec(cmd)
        devAttr = locals()['_a']
    except:     devAttr = None
    
    cmd = '_a = _getCustomAttributes(MDCDEFS.k' + lclDCT['customGroupName'] + 'ExtensionMdcDesc.create())'
    try:
        exec(cmd)
        groupAttr = locals()['_a']
    except:     groupAttr = None
    
    cmd = '_a = _getCustomAttributes(MDCDEFS.k' + lclDCT['customLoginName'] + 'ExtensionMdcDesc.create())'
    try:
        exec(cmd)
        loginAttr = locals()['_a']
    except:     loginAttr = None
    
    cmd = '_a = _getCustomAttributes(MDCDEFS.k' + lclDCT['customOfferName'] + 'ExtensionMdcDesc.create())'
    try:
        exec(cmd)
        offerAttr = locals()['_a']
    except:     offerAttr = None
    
    cmd = '_a = _getCustomAttributes(MDCDEFS.k' + lclDCT['customUserName'] + 'MdcDesc.create())'
    try:
        exec(cmd)
        userAttr = locals()['_a']
    except:     userAttr = None
    
    cmd = '_a = _getCustomAttributes(MDCDEFS.k' + lclDCT['customApiEventDataName'] + 'MdcDesc.create())'
    try:
        exec(cmd)
        apiEventAttr = locals()['_a']
    except:     apiEventAttr = None
    
    # Process each of these
    for customObj in customObjects:
        key = customObj[0]
        params = customObj[1]
        variable = customObj[2]
        
        # Build custom structure if anything input for this custom object.
        if key in lclDCT and lclDCT[key] != '' and lclDCT[key] != None:
                cmd = '_a = _checkCustomAttributes(' + variable + ')'
                exec(cmd)
                result = locals()['_a']
                if not result: continue
                
                if variable in ['userAttr', 'apiEventAttr']:
                       extension = ''
                else:  extension = 'Extension'

                # Process each custom object parameter
                for parameterTuple in params:
                  # Get parameter value from the tuple
                  parameter = parameterTuple[0]
                  
                  # Debug output
                  #if key == 'customSubName': print('Checking custom parameter: ' + parameter)
                 
                  # Add if it's not null.
                  if lclDCT[parameter] != "" and lclDCT[parameter] != None:
                        # One more possible indirection.  Multiple containers may use the same custom field name (e.g. "Sharing").
                        # Since the test tool assumes unique parameter names, one needs to map the tool parameter names to the container name.
                        # Only do this if there's something defined for the mapping (else assume 1:1 tool to container name).
                        if len(parameterTuple) >= 6 and parameterTuple[5]:
                                paramName = parameterTuple[5]
                        else:   paramName = parameter
                        
                        # Debug output
                        #print variable + ': Adding custom parameter: ' + paramName + ' with value ' + str(lclDCT[parameter])
                 
                        # See if this is a hierarchical element
                        if len(parameterTuple) >= 7 and parameterTuple[6]:
                                paramName = parameterTuple[6].replace('|','') + paramName
#                               print 'Encountered a struct element: ' + str(parameterTuple) + ', using parameter name ' + paramName
                                
                                # ** If this is a list of structs, then need to skip.  TF doesn't really support a list of structs...
                                problem = False
                                for element in parameterTuple[6].split('|'):
                                        # Sanity check the data
                                        if element not in GENERIC.CustomDataZip:
                                                print('WARNING: Inconsistent data.  Parameter ' + element + ' is not in GENERIC.CustomDataZip.')
                                                #pprint.pprint(GENERIC.CustomDataZip)
                                                problem = True
                                                break
                                        
                                        # See if a list
                                        if GENERIC.CustomDataZip[element][3].lower() == 'y':
                                                print('WARNING: Parameter ' + parameter + ' has a parent structure that\'s a list: ' + element + ':  This is not supported.')
                                                problem = True
                                                break
                                        
                                # If a problem then skip
                                if problem: continue
                        
                        # Build/execute command name
                        if type(lclDCT[parameter]) != type(list()):
                                if   lclDCT[parameter] == False: valToAdd = str(False)
                                elif lclDCT[parameter] == True:  valToAdd = str(True)
                                else:                            valToAdd = "'" + str(lclDCT[parameter]) + "'"
                                cmd = variable + '.setUsingKey(MDCDEFS.k' + lclDCT[key] + extension + paramName + 'FldKey, ' + valToAdd + ')'
                        else:
                                # If the list is supposed to be empty, then set to nothing
                                if len(lclDCT[parameter]) == 1 and lclDCT[parameter][0].lower() == 'empty':
                                        cmd = variable + '.setUsingKey(MDCDEFS.k' + lclDCT[key] + extension + paramName + 'FldKey, [])'
                                else:   cmd = variable + '.setUsingKey(MDCDEFS.k' + lclDCT[key] + extension + paramName + 'FldKey, ' + str(lclDCT[parameter]) + ')'
                        #print('getCustomAttributes command: ' + cmd)
                        try: exec(cmd)
                        except: pass

    # Return all the variables.  
    # Not sure exec of a return works (so don't build the list of variables to return and exec the return...)
    return(devAttr, subAttr, groupAttr, offerAttr, userAttr, loginAttr, apiEventAttr)
    
#==========================================================
def additionalAVPs(lclDCT, extraAVP, options, startTime = None, serviceId=None, interface = None, calledStation = None):
        # Sanity check the input data
        if not lclDCT: return 
        
        # Enhance AVPs prior to keyAVP processing
        try:    CUST.preKeyAVPs(extraAVP, lclDct=lclDCT, serviceId=serviceId)
        except: pass
        
        # Process key AVPs that we may want to include/exclude in Diameter messages.
        '''
        print 'additionalAVPs: before call to processKeyAVPs: '
        pprint.pprint(extraAVP)
        '''
        processKeyAVPs(lclDCT, extraAVP, options)
        '''
        print 'additionalAVPs: after call to processKeyAVPs: '
        pprint.pprint(extraAVP)
        '''
        
        # Set debug flag stuff
        if lclDCT['viewDiam']:
                # Make sure add entry exists
                if not 'add' in extraAVP: extraAVP['add'] = []
                
                # Add debug entry
                extraAVP['add'].append(('debug'))

        # Set locals if not passed in
        if not serviceId: serviceId = lclDCT['serviceId']
        if not interface: serviceId = lclDCT['interface']
        if not calledStation: calledStation = lclDCT['calledStation']
        
        # Process AVP lists
        if hasattr(CUST, "custListAVPData"):    addListAVPs(CUST.custListAVPData, extraAVP, lclDCT=lclDCT, serviceId=serviceId)
        if hasattr(DATA, "listAVPData"):        addListAVPs(DATA.listAVPData,     extraAVP, lclDCT=lclDCT, serviceId=serviceId)

        # Process additional Hard/Soft coded entries
        hardCodeAVPs(extraAVP, lclDct=lclDCT, serviceId=serviceId, options=options, interface=interface)
        softCodeAVPs(extraAVP, startTime=startTime, calledStation=calledStation, lclDct=lclDCT)

#==========================================================
def _processKeyAVPs(value):
        return type(value) is int
        
#==========================================================
def processKeyAVPs(lclDCT, extraAVP, options):
        # Sanity check the input data
        if not lclDCT: return 
        
        # Loop through list of key AVPs
        #print 'keyAVPs: ' + str(keyAVPs)
        for index,keyTuple in enumerate(DATA.keyAVPs):
#         print 'keyAVP: ' + str(keyTuple)
#         print 'Stored interface = ' + str(lclDCT['interface'])
#         print 'Stored serviceId = ' + str(lclDCT['serviceId'])
          
          # AVP location of the original key
          extraAVPDefaultKey = keyTuple[0]
          
          # If set to "none", then set None
          if extraAVPDefaultKey and extraAVPDefaultKey.lower() == 'none': extraAVPDefaultKey = None
          
          # Test Framework parameter.  Parameter can can substring format in it (e.g. [2:5]) so support that
          param = str(keyTuple[1]).split('[')
          lclDCTKey = param[0]
          if len(param) > 1:    substring = '[' + param[1]
          else:                 substring = None
        
          # ** NOTE: value could be a constant as well as a parameter name.  Check for this.
          if lclDCTKey and (lclDCTKey not in lclDCT):
                # Assume a static value
                lclDCTKey = 'TEMPKEY'
                lclDCT[lclDCTKey] = keyTuple[1]
          
          # If not set, then skip
          if lclDCTKey == None:
                print('WARNING: Test framework parameter NONE at index ' + str(index) + ' of combined keyAVPs.  Skipping this entry.')
                continue
  
          # *** Optional Parameters ***
          # The destintion AVP.  Generally is the same, but we allow them to be different.
          try:
                extraAVPDesiredKey = keyTuple[2]
          except:
                extraAVPDesiredKey = extraAVPDefaultKey
          
          # If the word "same" is set, then copy the original value
          if not extraAVPDesiredKey or extraAVPDesiredKey.lower() == 'same': extraAVPDesiredKey = extraAVPDefaultKey
          
          # The protocol to use.  Default to Gy.  Input allows for multiple values.
          try:
                interface = keyTuple[3]
          except:
                interface = 'gy'
          
          # Skip if not the same type
          if lclDCT['interface'].lower() not in interface.lower().split('|'): continue
          
          # Service-specific.  Input allows for multiple values.
          try:
                service = keyTuple[4]
          except:
                service = 'all'
        
          # Get service to check.  May be child service or main service.
          if 'childService' in lclDCT and lclDCT['childService']:
                serviceToCheck = lclDCT['childService']
          else: serviceToCheck = lclDCT['serviceId']
          
          # Skip if not matching the service.  "service" could be a list, separated by "|"
          #print 'Service = ' + str(service.split('|')) + ', serviceToCheck = ' + str(serviceToCheck)
          if service != 'all' and serviceToCheck not in service.split('|'): continue
          
          # Message-specific.  Input allows for multiple values.
          try:
                message = keyTuple[5]
          except:
                message = 'all'
          if message != 'all' and lclDCT['currenctUsageCommandRequest'] not in message.lower().split('|'): continue
        
          # **** End optional parameter processing ****
          
          # Debug output
          '''
          if lclDCTKey: print 'In processKeyAVPs: lclDCT[' + str(lclDCTKey) + '] = ' + str(lclDCT[lclDCTKey])
          else:         print 'In processKeyAVPs: key lclDCTKey is empty'
          '''
          
          # Map key value to desired action
          if str(lclDCTKey) == '':
                # Key blank.  Remove default only.
                if extraAVPDefaultKey:
                        #print 'Removing AVP ' + extraAVPDefaultKey 
                        extraAVP['omit'].append(extraAVPDefaultKey)
          elif lclDCT[lclDCTKey] == None:
                # Key is set to None.  Remove default only.
                if extraAVPDefaultKey: extraAVP['omit'].append(extraAVPDefaultKey)
          elif str(lclDCT[lclDCTKey]).lower() != DATA.useDefaultChar:
                # If old location defined, then omit
                if extraAVPDefaultKey: extraAVP['omit'].append(extraAVPDefaultKey)
                
                # If old location not defined or defined and not equal to new location, then omit new location for good measure
                if (not extraAVPDefaultKey) or extraAVPDefaultKey != extraAVPDesiredKey: extraAVP['omit'].append(extraAVPDesiredKey)
                
                # Add support for a key being a list parameter
                if type(lclDCT[lclDCTKey]) != type(list()):
                        listToUse = [lclDCT[lclDCTKey]]
                else: listToUse = copy.deepcopy(lclDCT[lclDCTKey])
                
                # Process every item in the list
                for i, item in enumerate(listToUse):
                        # Process substring if defined
                        if substring: 
                                substring = "item" + substring
                                item = eval(substring)
                                #print 'item updated to ' + item
                        
                        # Get key prefix
                        keyPrefix = extraAVPDesiredKey.split('|')
                        
                        # Get the actual AVP being written
                        avpBeingWritten = keyPrefix[-1]
                        
                        '''
                        print 'Processing item ' + item + ', keyPrefix/avpBeingWritten = ' + str(keyPrefix) + '/' + avpBeingWritten
                        print 'Type of lclDCT[' + lclDCTKey + '] = ' + str(type(lclDCT[lclDCTKey]))
                        pprint.pprint(extraAVP['add'])
                        '''
                        
                        # Check if need to add iteration value.  
                        
                        # For sure if input parameter is a list
                        if i: keyPrefix[0] += '$' + str(i)
                        
                        # NOTE: This only works for outer lists.  If there's a list within a group then need to build that manually in hardCode() function.
                        # It doesn't really work here at all, as this would be a grouping scenario and there's not a good way to manage groups 
                        # via custkeys[] when it's tied to one parameter value (e.g. Service-Parameter-Info has a constant Type value but that's tied to the parameter holding the Value).
#                       else:
#                               # If avp being writen already resides in the list, then need to add an index
#                               entries = []
#                               for entry in extraAVP['add']:
#                                       if entry.startswith(keyPrefix[0]): entries.append(keyPrefix[0])
#                               
#                               # See if we have any
#                               if len(entries):
#                                       # Default to the second one in the list
#                                       idxToUse = 1
#                                       for entry in entries:
#                                               # Get index.  Assumes there's less than 10 of the same type.  
#                                               # Otherwise need to split on $ and if second entry exists then use that...
#                                               lclIdx = entry[-1]
#                                               
#                                               # Skip if this is not an indexed entry
#                                               if not lclIdx.isdigit(): continue
#                                               
#                                               # See if last digit is >= than the current index
#                                               if int(lclIdx) >= idxToUse: idxToUse = int(lclIdx) + 1
#                                       
#                                       # Add index to entry. Entry may r may not already have a index so remove the $ if present and add in
#                                       keyPrefix[0] = keyPrefix[0].split('$')[0] + '$' + str(idxToUse)
#                                       print 'Adding list index for AVP grouping ' + keyPrefix[0]
                        
                        # Rebuild avp to write
                        keyPrefix = "|".join(keyPrefix)
                        
                        # ***   Start special key processing ***
                        #       This covers both special AVPs and converting generic AVP type values
                        # Remove code that was specific to this one AVP.  It's causing issues (and things work fine without this code).
                        # Author doesn;t recall why it was added to begin with...
                        '''
                        elif avpBeingWritten == '3GPP-SGSN-Address':
                                # Convert IP address string to hex value
                                IpAddress = item.split('.')
                                shift = 24
                                value = 0
                                for nibble in IpAddress:
                                        value += int(nibble) << shift
                                        shift -= 8
                                item = str(hex(value))[2:]
                        '''
                        # Minor hack here:  Not a good way to set Unit-Value exponents (at least not one built in yet).
                        # Sooooo, do the following: (a) split using decimal point, (b) if length is 2 and both 
                        # parts are all integers, then assume a real number.
                        # Real numbers use the exponent and value notation (as Diameter seems to have never really used Float 32/64 types...)
                        decimalCheck = str(item).split('.')
                        if avpBeingWritten == 'Unit-Value':
                                if len(decimalCheck) == 2 and decimalCheck[0].isdigit() and decimalCheck[1].isdigit():
                                        extraAVP['add'].append(keyPrefix+'|Value-Digits:'+decimalCheck[0]+decimalCheck[1])
                                        extraAVP['add'].append(keyPrefix+'|Exponent:'+str(-1*len(decimalCheck[1])))
                        
                        elif avpBeingWritten == '3GPP-User-Location-Info':
                                # Diameter gateway handles this octet string already...
                                item = item
                        
                        # May not be in the AVP list if here for a 5G command...
                        elif avpBeingWritten in GENERIC.AvpData:
                         if GENERIC.AvpData[avpBeingWritten] in ['Time']:
                                # Don't want msec here
                                timeSplit =  item.split('.')
                                if len(timeSplit) > 1:
                                        # msec included.  Need to remove them (6 digits)
                                        item = timeSplit[0] + timeSplit[1][6:]
                                
                                # Call magic APIs to convert to a diameter time
                                item = MDCTIME.convertTime(item, forceUtc=True)
                                item = DIAM.convertStringTimeToDiameterTime(item, dst=0)
                        
                         elif GENERIC.AvpData[avpBeingWritten] == 'OctetString':
                                # Sometimes an integer passed in; other times a string.
                                # Need try/except to handle TEMPKEY logic (which is not in options).
                                try:    intFlag = type(getattr(options, lclDCTKey)) is int
                                except: intFlag = False
                                if intFlag:
                                        # Debug extra output 
                                        if lclDCT['verbose'].lower() in ['full', 'high']: print('INT variable ' + lclDCTKey + ' used with OctetString')
                                        
                                        # Convert to hex with no leading 0x characters.  OctetString is a string representing hex digits (not representing an integer)...
                                        ## Need to validate this change befor eenabling:  item = hex(int(item))[2:]
                                        item = str(item)
                                        
                                        # Want even number of digits for integers represented by octet string format.
                                        if len(item) % 2: item = '0' + item
                                else: item = DIAM.convertStringToHexStr(item)
                                
                        # *** End special key processing ***
                        #print 'Adding key data: ' + keyPrefix+':'+str(item) + '. Type of item is ' + str(type(item))
                        
                        # Now want to add key to array.  5G adds another layer of complexity...
                        # 5G requires knowing if the parameter is an int or string.  Payload format is different.
                        if not lclDCT['interface'].lower().startswith('5g'):
                                # No special processing for non-5G messages
                                extraAVP['add'].append(keyPrefix+':'+str(item))
                                
                                # Can skip rest of loop (save indenting)
                                continue
                        
                        # If here, then a 5G event
                        # Specific value gets tricky.  If all digits (or a float)then assume an integer.
                        # "_INT" prefix means don't put as a string into the message.
                        if lclDCTKey == 'TEMPKEY':
                                #print 'Looking at value ' + str(lclDCT[lclDCTKey])
                                if isinstance(lclDCT[lclDCTKey], int) or isinstance(lclDCT[lclDCTKey], float): 
                                        extraAVP['add'].append(keyPrefix+':_INT_'+str(item))
                                else:   extraAVP['add'].append(keyPrefix+':'+str(item))
                                
                                # Can skip rest of loop (save indenting)
                                continue 
                                        
                        # If here then have a real TF parameter in a 5G message.  Need to decide if we pass in INT prefix
                        entry = [x for x in DATA.parameters + DATA.custom5GRequestParameters if x[0] == lclDCTKey]
                        
                        # ** DESIGN ALERT: To store stuff at the top level, we need a prefix to detect this.  TF uses "5G_".
                        if len(keyPrefix.split('|')) == 1: keyPrefix = '5G_' + keyPrefix
                        
                        # Sanity check that we found this
                        #print 'Adding 5G entry to extraAVP: ' + str(entry) + ' with keyPrefix = ' + keyPrefix + ' and item = ' + str(item)
                        if not len(entry):
                                # Didn't find parameter in overall parameter list.  
                                print('Hmmm.  Did not find parameter "' + lclDCTKey + '" in DATA.parameters.  Will default to string behavior.')
                                extraAVP['add'].append(keyPrefix+':'+str(item))
                        elif len(entry) > 1:
                                print('Hmmm.  Found more than one parameter "' + lclDCTKey + '" in DATA.parameters.  Will default to string behavior.')
                                extraAVP['add'].append(keyPrefix+':'+str(item))
                                
                        # Look at parameter type and if an int add special prefix
                        elif entry[0][2] in ['int', 'float']:
                                extraAVP['add'].append(keyPrefix+':_INT_'+str(item))
                        elif entry[0][1] in ['store_true']:
                                # Change true/false to 1/0
                                item = str(item).lower()
                                extraAVP['add'].append(keyPrefix+':'+str(item))
                        else:   extraAVP['add'].append(keyPrefix+':'+str(item))
                        
        # Return the result
#       for entry in ['add', 'omit']: print 'extraAVP[\'' + entry + '\']: ' + str(extraAVP[entry])
        return 

#==========================================================
def addListAVPs(avpsToAdd, extraAVP, lclDCT=None, serviceId=None, options=None, diamInterface=None):
        # Debug only for Rx
        if 'rx' in avpsToAdd:
                print('addListAVPs: avpsToAdd: ')
                pprint.pprint(avpsToAdd)
        
        # Process all interfaces
        for interface in avpsToAdd:
                # Skip if not the same type
                try:
                        if diamInterface and diamInterface.lower() != 'all' and avpsToAdd['interface'].lower() not in diamInterface.lower().split('|'): continue
                except: pass
                        
                # Process each service in this interface
                for service in avpsToAdd[interface]:
                        # Get service to check.  May be child service or main service.
                        if 'childService' in lclDCT and lclDCT['childService']:
                                serviceToCheck = lclDCT['childService']
                        else: serviceToCheck = lclDCT['serviceId']
                        
                        # Skip if not matching the service.  "service" could be a list, separated by "|"
                        #print 'service = ' + str(service) + ', serviceToCheck = ' + str(serviceToCheck)
                        if service != 'all' and serviceToCheck not in service.split('|'): continue
                        
                        # Walk the avp list
                        for mainAvp in avpsToAdd[interface][service]:
                                # array index is per avp
                                index = 0
                                
                                # Message-specific
                                try:    message = avpsToAdd[interface][service][mainAvp]['message'].lower()
                                except: message = 'all'
                                #print 'message = ' + str(message) + ', requestType = ' + str(lclDCT['currenctUsageCommandRequest'])
                                if message != 'all' and lclDCT['currenctUsageCommandRequest'] not in message.split('|'): continue
                                
                                # Process each entry.  
                                # same level AVPs are under the 'topLevel'
                                if 'topLevel' in avpsToAdd[interface][service][mainAvp]:
                                 for entry in list(avpsToAdd[interface][service][mainAvp]['topLevel'].keys()):
                                        addAVPToExtraAVP(index, mainAvp, entry, avpsToAdd[interface][service][mainAvp]['topLevel'][entry], lclDCT, extraAVP)
                                
                                # These are non-5G entries (under 'AVP')
                                if 'AVP' in avpsToAdd[interface][service][mainAvp]:
                                 for entry in avpsToAdd[interface][service][mainAvp]['AVP']:
                                        #print "Processing entry " + str(entry)
                                        # Can have lists of dictionaries and lists of scalers
                                        if type(entry) == dict:
                                                # Process each entry
                                                for avp in entry: 
                                                        #print 'Processing avp ' + str(avp)
                                                        result = addAVPToExtraAVP(index, mainAvp, avp, entry[avp], lclDCT, extraAVP)
                                                        if not result: break
                                        else:   result = addAVPToExtraAVP(index, mainAvp, None, entry, lclDCT, extraAVP)        
                                        
                                        # Bump the index if successful.
                                        # HACK: Skip for Rx for now (working on lists of lists...)
                                        if result and (interface != 'rx'): index += 1
                                
                                # Process 5G items.  Always a dictionary here.
                                if '5G' in avpsToAdd[interface][service][mainAvp]:
                                 for entry in avpsToAdd[interface][service][mainAvp]['5G']:
                                        # Set flag indicating we didn;t find a empty value
                                        noneFlag = False
                                        
                                        # Restart string
                                        finalStr = '['
                                        
                                        # Artificial maximum
                                        maxIterations = 100
                                        i = 0
                                        while i < maxIterations:
                                         # Init output string
                                         finalStr += '{'
                                         
                                         # Process each entry (param + value), ignoring opening/closing brackers
                                         for element in entry[1:-1].split(','):
                                                # Split item into param + name
                                                (name,param) = element.split(':')
                                                #print 'name/param = ' + name + '/' + param
                                                
                                                # Name is always added in parenthesis
                                                finalStr += '"' + name + '":'
                                                
                                                # If parameter starts with a ", then add here
                                                if param[0] == '"':
                                                        finalStr += '"'
                                                        param = param[1:-1]
                                                        stringFlag = True
                                                else:   stringFlag = False
                                                
                                                # Now see if name is a parameter or a constant
                                                value = lclDCT[param]
                                                try: value = lclDCT[param]
                                                except: value = param
                                                #print 'name/value = ' + name + '/' + str(value)
                                                
                                                # If a list, then address here
                                                if type(value) is list:
                                                        # set iteration count to be the length of this list
                                                        maxIterations = len(value)
                                                        
                                                        # set to array entry
                                                        value = value[i]
                                                else:   maxIterations = 1
                                                #print 'name/value = ' + name + '/' + str(value)
                                                
                                                if value == None:
                                                        # Set flag and break
                                                        noneFlag = True
                                                        break
                                                
                                                # Add to final string
                                                finalStr += value
                                                if stringFlag: finalStr += '"'
                                                
                                                # Add seperator
                                                finalStr += ','
                                        
                                         # If we exited then break from this (i.e. nothing to save)
                                         if noneFlag: break
                                                
                                         # Complete string.  Remove last sperator, add closing brackets, and include dictionary seperator.
                                         finalStr = finalStr[:-1] + '}@'
                                         
                                         # Increment loop counter
                                         i += 1
                                        
                                        # If we exited then break from this (i.e. nothing to save)
                                        if noneFlag: break
                                                
                                        # Complete string.  Remove last sperator and add closing brackets.
                                        finalStr = finalStr[:-1] + ']'
                                
                                        # Add final string to list
                                        extraAVP['add'].append(mainAvp+':'+finalStr)
        '''                      
        print 'addListAVPs:'
        pprint.pprint(extraAVP['add'])
        '''                      
         
#==========================================================
def addAVPToExtraAVP(index, key, avp, entry, lclDct, extraAVP):
        # The key is the AVP.  The value may be a variable or a static value.  
        # There may also be a function to execute against the data.
        # Get the value
        values = entry.split(',')
        value = values[0].strip()
        
        # If data is not defined, then skip
        if value == None: return index
        
        # Extract function (if specified)
        if len(values) > 1: function = values[1].strip()
        else:               function = None
                                        
        # The "value" may be a parameter name or a static value.  Parameter has priority.
        if lclDct and value in lclDct:
                oldValue = value
                value = lclDct[value]
                
                # If parameter is not defined, then skip
                if value == None: return index
                
                # Debug
                #print 'Replacing TF parameter "' + str(oldValue) + '" with "' + str(value) + '"'
        
        # Debug
        #print 'AVP ' + key + '|' + avp + ' = "' + value + '" with function ' + str(function)
        
        # Build command to execute
        cmd = "extraAVP['add'].append('" + key
        
        # Add index if desired
        if index != -1: cmd += '$' + str(index)
        
        # May have a next level AVP
        if avp: cmd += '|' + avp
        
        # AVP always closes with a colon
        cmd += ':'
        
        # See if data needs a function call
        if function:    cmd += "'+" + function + '(str(value))'
        else:           cmd += str(value) + "'"
        
        # Close the command
        cmd += ')'
        
        # Execute the command
        #print 'cmd = ' + cmd
        exec(cmd)
        
        return index + 1
        
#==========================================================
def hardCodeAVPs(extraAVP, lclDct=None, serviceId=None, options=None, interface=None):
        # Add AVPs for a customer.
        if hasattr(CUST, "hardCodeAVPs"): CUST.hardCodeAVPs(extraAVP, lclDct=lclDct, serviceId=serviceId)
        
        # If no dictionary passed in, then exit
        if not lclDct: return
        
        # If here, then we want to add omit fields if any defined
        if lclDct['omit'] and len(lclDct['omit']):
                for entry in lclDct['omit']: extraAVP['omit'].append(entry)
        
        # Pass through specific parameters, so they're available to lower level functions (as lclDct is CSV-code specific)
        extraAVP['uliOnlyOnFirstMessage'] = lclDct['uliOnlyOnFirstMessage']
        
        # Set MSCC flag based on noMscc parameter
        if not lclDct['noMscc']: extraAVP['MSCC'] = 1
        
        # Set extraAVP fields based on certain parameters
        for param in (('CmdFlagProxiable', 'appId', 'msgId', 'hopByHopId', 'endToEndId')):
                if lclDct[param]: extraAVP[param] = lclDct[param]
        
        # Setup host/realm data
        if options and interface:
                if interface.lower() == 'gy':
                        extraAVP['add'].append('Origin-Host:'  + options.originHostGy + '.' + options.randomValue)
                        extraAVP['add'].append('Origin-Realm:' + options.originRealmGy)
                elif interface.lower() == '5g':
                        extraAVP['add'].append('Origin-Host:5G')
                        extraAVP['add'].append('Origin-Realm:5G')
                elif interface.lower() == 'gx':
                        extraAVP['add'].append('Origin-Host:'  + options.originHostGx + '.' + options.randomValue)
                        extraAVP['add'].append('Origin-Realm:' + options.originRealmGx)
                elif interface.lower() == 'sh':
                        extraAVP['add'].append('Origin-Host:'  + options.originHostSh + '.' + options.randomValue)
                        extraAVP['add'].append('Origin-Realm:' + options.originRealmSh)
                elif interface.lower() == 'rx':
                        extraAVP['add'].append('Origin-Host:'  + options.originHostRx + '.' + options.randomValue)
                        extraAVP['add'].append('Origin-Realm:' + options.originRealmRx)
                else:
                        extraAVP['add'].append('Origin-Host:'  + options.originHostSy + '.' + options.randomValue)
                        extraAVP['add'].append('Origin-Realm:' + options.originRealmSy)
        
#==========================================================
def softCodeAVPs(extraAVP, startTime=None, calledStation=None, lclDct=None):
        # Add AVPs for a customer.
        if hasattr(CUST, "softCodeAVPs"): CUST.softCodeAVPs(extraAVP, startTime=startTime, calledStation=calledStation, lclDct=lclDct)

#==========================================================
def getAbsoluteOfferIdValue(offerId, options):
    if offerId:
        # Exact same processing as if this was on the command line
        offerId = CSVQA.convertToolListToPythonList(offerId)
        
    return offerId

#==========================================================
# Return List of Catalog Items
def getOfferList(offerIsExternal=True, offersToBlock=None, startTime=None):
        return ENGINE.getOfferList(offerIsExternal, offersToBlock, startTime)
        
#==========================================================
# Return balance data from REST query
def getOfferData(target, value, offerId, offerExternalId, lclStartTime, command, queryType='ExternalId', offerIsCatalog=False, resourceId=None):
        return ENGINE.getOfferData(target, value, offerId, offerExternalId, lclStartTime, command, queryType, offerIsCatalog, resourceId)

#==========================================================
# Merge two dictionaries        
def merge_two_dicts(x, y):
    '''Given two dicts, merge them into a new dict as a shallow copy.'''
    z = x.copy()
    z.update(y)
    return z

#==========================================================
# Return All offer data from REST query
def getOffers(release='5100', regressionRun='None'):
        return ENGINE.getOffers(release, regressionRun)

#==========================================================
# Return All catalog item data from REST query
def getCatalogItemId():
        return ENGINE.getCatalogItemId()
        
#==========================================================
# Return All balance threshold data from REST query
def getBalanceThresholds(balanceId):
        return ENGINE.getBalanceThresholds(balanceId)
        
#==========================================================
def getThresholdId(balanceId, thresholdId):
        return ENGINE.getThresholdId(balanceId, thresholdId)

#==========================================================
# Return All life cycle data.
# Need two pieces of data: (1) simple mapping of name to number for test commands
#                          (2) state map so we can remove an object (so traverse until we arrive at a state that can be deleted from)
def getLifeCycles(target, regressionRun='None', dctRcv = {}):
        (dctRcv, stateMap) =  ENGINE.getLifeCycles(target, dctRcv, regressionRun)

        # Now copy to CUST data
        if   target.lower() == 'subscriber':    CUST.subStateMap = copy.deepcopy(stateMap)
        elif target.lower() == 'device':        CUST.devStateMap = copy.deepcopy(stateMap)
        elif target.lower() == 'group':         CUST.groupStateMap = copy.deepcopy(stateMap)
        elif target.lower() == 'user':          CUST.userStateMap = copy.deepcopy(stateMap)

        '''
        print target + ':'
        pprint.pprint(stateMap)
        '''
        
        return dctRcv
        
#==========================================================
# Return All event type data from REST query
def getEventTypeMappings(regressionRun='None'):
        return ENGINE.getEventTypeMappings(regressionRun)
        
#==========================================================
# Return All balance data from REST query
def getBalances(regressionRun='None', dctRcvBal = {}, dctRcvClass = {}, dctRcvBalName = {}, dctRcvClassName = {}):
        return ENGINE.getBalances(regressionRun, dctRcvBal, dctRcvClass, dctRcvBalName, dctRcvClassName)
        
#==========================================================
# Return payment data from REST query
def getPaymentData(target, value, paymentToken, lclStartTime, command, queryType='ExternalId', haltOnError=True):
        return ENGINE.getPaymentData(target, value, paymentToken, lclStartTime, command, queryType, haltOnError)
        
#==========================================================
# Rollover processing
def getBalanceRolloverData(target, value, balanceId, resourceId, queryType='ExternalId', lclStartTime=None):
        return ENGINE.getBalanceRolloverData(target, value, balanceId, resourceId, queryType, lclStartTime)
        
#==========================================================
# Return balance data from REST query
def getBalanceData(target, value, balanceId, resourceId, lclStartTime, command, queryType='ExternalId', haltOnError=True, returnExpiredOk=False):
        return ENGINE.getBalanceData(target, value, balanceId, resourceId, lclStartTime, command, queryType, haltOnError, returnExpiredOk)

#==========================================================
# Return All billing profile data
def getBillingProfiles(regressionRun='None', dctRcv = {}):
        return ENGINE.getBillingProfiles(regressionRun,dctRcv)

#==========================================================
# Return All user roles
def getUserRoles(regressionRun='None'):
        return ENGINE.getuserRoles(regressionRun)

#==========================================================
def getRequestList(totalToUse, maxToUse, amount, requestType, maxCommands):
         requestList = []
        
         # Sanity check the requestType
         if requestType not in ['initial', 'term', 'interim', 'session']: 
                print('ERROR: requestType has an invalid value: ' + str(requestType) + ".  Must be one of: 'initial', 'term', 'interim', 'session'.")
                sys.exit('Exiting')
         
         # Override default for max commands
         if maxCommands == 0: maxCommands = 1000
        
         # If single command and no max/total usage specified
         if requestType == 'initial' or requestType == 'term' or ((requestType == 'interim') and (int(totalToUse) == -1) and (int(maxToUse) == -1)):
                requestList.append(requestType)

                # Append the proper number of commands (in amount parameter) if this is an interim message (doesn't make sense for others)
                if amount and requestType == 'interim': requestList.extend([requestType] * (amount-1))

         # Interim message with total or max usage specified
         elif requestType == 'interim' and ((int(totalToUse) != -1) or (int(maxToUse) != -1)):
                # All interims here
                requestList.append(requestType)

                # Append lots of interims.  Not sure how many are needed given the desired amount to use.
                requestList.extend([requestType] * maxCommands)

         # A session
         elif requestType == 'session':
                # Start with an initial
                requestList.append('initial')

                # For the feature where we want to use a specific amount for a session or across session, set the amount high (and we'll skip un-needed iterations)
                if (int(totalToUse) != -1) or (int(maxToUse) != -1): amount = maxCommands

                # Append the proper number of interims (in amount parameter)
                if amount:
                        print('Adding ' + str(amount) + ' interim commands to a session')
                        requestList.extend(['interim'] * amount)

                # Add a term
                requestList.append('term')

         return requestList

#==========================================================
def getListToSendTo(action, deviceId, externalId, groupId, mark, scope, accessNumbers, allFlag=False, LoginId=None):
         deviceIdToSend = []
         accessNumberToSend = []

         # Assume we're querying by IMSI unless we find it needs to be MSISDN
         queryValue = deviceId
         queryType = 'PhoneNumber'
         
         # If single event or Sx message
         if action in ['diameterEvent', 'ccfEvent'] or action.count('Notifications') or action.count('Spend') or action.count('SessionTerminate'):
           # Need some good way of knowing whether to use the device ID or not.  If it's negative, this is a signal not to use it.
           if LoginId:
                deviceId = '-1'
                accessNumbers = '-1'

                # Query by LoginId
                queryValue = LoginId
                queryType = 'LoginId'
                
                # Add device to the list
                deviceIdToSend.append(queryValue)
                accessNumberToSend.append(accessNumbers)

           else:
            if int(deviceId) < 0:
                deviceId = '-1'

                # Query by MSISDN
                queryValue = accessNumbers
                queryType = 'AccessNumber'

            # Make sure access numbers are not used if below 0
            if int(accessNumbers) < 0: accessNumbers = '-1'

            # Add device to the list
            deviceIdToSend.append(deviceId)
            accessNumberToSend.append(accessNumbers)

         elif action.count('EverySubEvent') or \
              action.count('EverySubInGroupEvent'):
           # retrieve tracking data
           deviceIdToSend = TRACK.retrieveTrackingData(action, externalId = externalId, groupId = groupId, mark = mark, scope = scope)

           # Make sure something was found...
           if len(deviceIdToSend):
                accessNumberToSend = ['0'] * len(deviceIdToSend)
                queryValue = deviceIdToSend[0]
           else:
                queryValue = None
                print('WARNING:  command ' + action + ' found nothing to query.')

         elif action.count('EveryDeviceEvent') or \
              action.count('EveryDeviceInSubEvent') or \
              action.count('EveryDeviceInGroupEvent'):
           # retrieve tracking data
           deviceIdToSend = TRACK.retrieveTrackingData(action, externalId = externalId, groupId = groupId, mark = mark, scope = scope)

           # Make sure something was found...
           if len(deviceIdToSend):
                accessNumberToSend = ['0'] * len(deviceIdToSend)
                queryValue = deviceIdToSend[0]
           else:
                queryValue = None
                print('WARNING:  command ' + lclDCT['ACTION'] + ' found nothing to query.')

         elif action.count('EveryAccessNumberEvent') or \
              action.count('EveryAccessNumberInGroupEvent') or \
              action.count('EveryAccessNumberInSubEvent'):
           # retrieve tracking data
           accessNumberToSend = TRACK.retrieveTrackingData(action, externalId = externalId, groupId = groupId, mark = mark, scope = scope)

           # Make sure something was found...
           if len(accessNumberToSend):
                deviceIdToSend = ['0'] * len(accessNumberToSend)
                queryValue = accessNumberToSend[0]
                queryType = 'AccessNumber'
           else:
                queryValue = None
                print('WARNING:  command ' + action + ' found nothing to query.')

         return (deviceId, queryValue, queryType, deviceIdToSend, accessNumberToSend)

#==========================================================
def totalAndMaxToUse(totalToUse, maxToUse, used, requestType, reportingReason, request, requested, SkipFlag, currentResv, type='current'):
#       if type == 'current': print 'used/total/max/requestType/currentResv on input: ' + str(used) + '/' + str(totalToUse) + '/' + str(maxToUse) + '/' + str(requestType) + '/' + str(currentResv)
#       print type + ': used/total/max/requestType/currentResv on input: ' + str(used) + '/' + str(totalToUse) + '/' + str(maxToUse) + '/' + str(requestType) + '/' + str(currentResv)

        # Make key items ints
        totalToUse = int(totalToUse)
        maxToUse = int(maxToUse)
        used = int(used)

        # For totalToUse feature, may adjust used amount so we don't go over desired amount
        if totalToUse >= 0:
                # See if this last amount would put us over
                if used + currentResv >= totalToUse:
                        # Limit usage to rest of the amount
                        used = max(0, totalToUse - currentResv)

                        # Minimal request
                        requested = 0

                        # Set flag to skip remainder of messages
                        SkipFlag = True

                        # Change request to be term iff this wasn't a interim session
                        if requestType != 'interim': request = 'term'

                        # If this is an interim session AND no reporting reason was input, then set to QHT (1) so nothing additional granted.
                        elif not reportingReason:  reportingReason='1'

                        print(type + ': Limiting used to ' + str(used) + ' due to hitting total to use amount, reporting reason = ' + str(reportingReason))
                # Decrement amount used from total (so we know what's let to use)
                totalToUse -= used

        # May futher reduce this if there's a group total defined and we're crossing that
        if maxToUse >= 0:
                # Check if we'd exceed the limit
                if used + currentResv >= maxToUse:
                        # Limit usage to rest of the amount
                        used = max(0, maxToUse - currentResv)

                        # Minimal request
                        requested = 0

                        # Set flag to skip remainder of messages
                        SkipFlag = True

                        # Change request to be term iff this wasn't a interim session
                        if requestType != 'interim': request = 'term'

                        # If this is an interim session AND no reporting reason was input, then set to QHT (1) so nothing additional granted.
                        elif not reportingReason:  reportingReason='1'

                        print(type + ': Limiting used to ' + str(used) + ' due to hitting maximum to use amount, reporting reason = ' + str(reportingReason) + '.  Time delta warning will follow (need to fix this...)')
                # Decrement amount used from total (so we know what's left to use)
                maxToUse -= used

#       if type == 'current': print type + ' used/total/max/request on exit: ' + str(used) + '/' + str(totalToUse) + '/' + str(maxToUse) + '/' + str(request)
        return (used, totalToUse, maxToUse, reportingReason, request, requested, SkipFlag)

#==========================================================
# NOTE: Called before diameter usage function, so need to be careful looking at stuff like reqAmount
def getDiamMark(mark, subMark, lclDCT, requestType, externalId, deviceId, accessNumbers, subSession, sessionId, ratingGroup, interface, verbose='full'):
        # Mark only valid for single diameter message
        if lclDCT['ACTION'].count('Every'):
                print('WARNING: can\'t mark multi-diameter actions (' + lclDCT['ACTION'] + ').  Only single events can be marked.  Ignoring the mark.')
                mark = None
        # Can't mark a session or event action (all done in one command, so no benefit)
        elif requestType == 'session':
                # Treat mark as a subscriber mark.  Get device and access number from this.
                if mark not in TRACK.subscriberTracking:
                        print('WARNING: No subscriber marked with value "' + mark + '".  Ignoring the mark')
                        mark = None
                else:
                        # Use data from saved subscriber
                        externalId = TRACK.subscriberTracking[mark]
                        if len(TRACK.subscriberTracking[externalId]['deviceId']) == 0:
                                print('WARNING: subscriber ' + str(externalId) + '" does not have an associated device.  Ignoring the mark')
                                mark = None
                        else:
                                # Only get device (could get access number but then need additional checks to avoid crash...)
                                deviceId = TRACK.subscriberTracking[externalId]['deviceId'][0]
                                if 'accessNumbers' in TRACK.deviceTracking[deviceId]:
                                        # Original code is the except line.  Field says the try line is correct.
                                        try:    accessNumbers = TRACK.sessionTracking[subSession]['accessNumber']
                                        except: accessNumbers = TRACK.deviceTracking[deviceId]['accessNumbers'][0]
                                        ##accessNumbers = '-1'

        # Check if mark exists for a non-init messages
        elif not requestType.startswith('init'):
                # Give priority to the mark input
                if mark in TRACK.sessionTracking:
                        # Use data from saved session
                        subSession = TRACK.sessionTracking[mark]
                        deviceId = TRACK.sessionTracking[subSession]['deviceId']
                        if 'accessNumbers' in TRACK.deviceTracking[deviceId]:
                                # Original code is the except line.  Field says the try line is correct.
                                try:    accessNumbers = TRACK.sessionTracking[subSession]['accessNumber']
                                except: accessNumbers = TRACK.deviceTracking[deviceId]['accessNumbers'][0]
                        sessionId = TRACK.sessionTracking[subSession]['id'].split('_')[0]
                        ratingGroup = TRACK.sessionTracking[subSession]['id'].split('_')[1]
                        interface = TRACK.sessionTracking[subSession]['interface']
                        if verbose not in ['low', 'none']:
                         print('Restored deviceID=' + deviceId + ', accessNumber=' + accessNumbers + ', session ID=' + sessionId + ', rating Group=' + ratingGroup + ', interface=' + interface + ' for session mark ' + mark)
                        
                        # RG may have been None to begine with; stored as a string.  Return to None if so.
                        if ratingGroup == 'None': ratingGroup = None
                # Allow for the subMark to also influence here (so we can mark sub context as well as the main context)
                elif subMark and subMark in TRACK.subscriberTracking:
                        externalId = TRACK.subscriberTracking[subMark]
                        deviceId = TRACK.subscriberTracking[externalId]['deviceId'][0]
                        if 'accessNumbers' in TRACK.deviceTracking[deviceId]:
                                # Original code is the except line.  Field says the try line is correct.
                                try:    accessNumbers = TRACK.sessionTracking[subSession]['accessNumber']
                                except: accessNumbers = TRACK.deviceTracking[deviceId]['accessNumbers'][0]
                                ##accessNumbers = '-1'
                else:
                        if verbose not in ['low', 'none']:
                         print('WARNING: No session marked with value "' + mark + '".  Ignoring the mark')
                        mark = None

        # If initial and subscriber mark exists, then use that.
        # Note:  on an initial command, can't specify a mark since the session doesn't exist.
        #        Hence check for subMark specifically here (versus checking for "mark" above).
#       elif requestType == 'initial' and subMark and subMark in TRACK.subscriberTracking:
#               externalId = TRACK.subscriberTracking[subMark]
#               deviceId = TRACK.subscriberTracking[externalId]['deviceId'][0]
#               accessNumbers = '-1'

        return (mark, externalId, deviceId, accessNumbers, subSession, sessionId, ratingGroup, interface)

#==========================================================
def connectToDiameterGateway(ipAddress, interface, options=None, lclDCT=None, mark=None):
        global DiameterHostName
        global MyHostName

        # if both options and lclDCT are passed in, then confusion reigns
        if options and lclDCT:
                print('ERROR: can\'t use both options and lclDCT when connecting to a diameter gateway')
                sys.exit('Exiting')

        # First check if we're switching to an existing set of connections.  Use mark for this.
        if mark and not ipAddress:
                # Track items by their mark
                if interface.lower() == 'gy' and mark in TRACK.diamConnectionGyDict:
                        # Found it - only need to change values
                        TRACK.diamConnectionGy = TRACK.diamConnectionGyDict[mark]['diamConnection']
                        diamConnection = TRACK.diamConnectionGy

                        # Debug output
                        print('Restored ' + interface.lower() + ' Diameter connection using mark = ' + mark)

                        # *** Always echo to Gy connection ****
                        # Get Diameter hostname
                        DiameterHostName = TRACK.diamConnectionGyDict[mark]['ipAddress'].split(':')[0]

                        # Get my host name (IP address used to connect to Diameter host).
                        # Do this by connecting to the Diameter gateway and seeing which IP address was used for that connection.
                        s = RESTV3.realsocket(socket.AF_INET, socket.SOCK_DGRAM)
                        s.connect((DiameterHostName, 80))
                        MyHostName = s.getsockname()[0]
                        s.close()
                        del s
                
                elif interface.lower() == 'gx' and mark in TRACK.diamConnectionGxDict:
                        # Found it - only need to change values
                        TRACK.diamConnectionGx = TRACK.diamConnectionGxDict[mark]['diamConnection']
                        diamConnection = TRACK.diamConnectionGx

                        # Debug output
                        print('Restored ' + interface.lower() + ' Diameter connection using mark = ' + mark)

                elif interface.lower() == 'sy' and mark in TRACK.diamConnectionSyDict:
                        # Found it - only need to change values
                        TRACK.diamConnectionSy = TRACK.diamConnectionSyDict[mark]['diamConnection']
                        diamConnection = TRACK.diamConnectionSy

                        # Debug output
                        print('Restored ' + interface.lower() + ' Diameter connection using mark = ' + mark)

                elif interface.lower() == 'sh' and mark in TRACK.diamConnectionShDict:
                        # Found it - only need to change values
                        TRACK.diamConnectionSh = TRACK.diamConnectionShDict[mark]['diamConnection']
                        diamConnection = TRACK.diamConnectionSh
                        
                        # Debug output
                        print('Restored ' + interface.lower() + ' Diameter connection using mark = ' + mark)
                
                elif interface.lower() == 'rx' and mark in TRACK.diamConnectionRxDict:
                        # Found it - only need to change values
                        TRACK.diamConnectionRx = TRACK.diamConnectionRxDict[mark]['diamConnection']
                        diamConnection = TRACK.diamConnectionRx

                        # Debug output
                        print('Restored ' + interface.lower() + ' Diameter connection using mark = ' + mark)
                
                # Return no matter what if we were here
                return

        # If here, then we need new connections
        # Connect to the input IP address
        # Set to different values per interface
        if interface.lower() == 'gy':
                TRACK.diamConnectionGy = QAUTILS.getDiamConnection(ipAddress, commandType=interface)
                diamConnection = TRACK.diamConnectionGy

                # Update global data with this mark
                if mark:
                        print('Storing connection data for mark: ' + mark)
                        TRACK.diamConnectionGyDict[mark] = {}
                        TRACK.diamConnectionGyDict[mark]['diamConnection'] = diamConnection
                        TRACK.diamConnectionGyDict[mark]['ipAddress'] = ipAddress
        
        elif interface.lower() == 'gx':
                TRACK.diamConnectionGx = QAUTILS.getDiamConnection(ipAddress, commandType=interface)
                diamConnection = TRACK.diamConnectionGx

                # Update global data with this mark
                if mark:
                        print('Storing connection data for mark: ' + mark)
                        TRACK.diamConnectionGxDict[mark] = {}
                        TRACK.diamConnectionGxDict[mark]['diamConnection'] = diamConnection
                        TRACK.diamConnectionGxDict[mark]['ipAddress'] = ipAddress
        
        elif interface.lower() == 'sh':
                TRACK.diamConnectionSh = QAUTILS.getDiamConnection(ipAddress, commandType=interface)
                diamConnection = TRACK.diamConnectionSh

                # Update global data with this mark
                if mark:
                        print('Storing connection data for mark: ' + mark)
                        TRACK.diamConnectionShDict[mark] = {}
                        TRACK.diamConnectionShDict[mark]['diamConnection'] = diamConnection
                        TRACK.diamConnectionShDict[mark]['ipAddress'] = ipAddress
                
        elif interface.lower() == 'rx':
                TRACK.diamConnectionRx = QAUTILS.getDiamConnection(ipAddress, commandType=interface)
                diamConnection = TRACK.diamConnectionRx

                # Update global data with this mark
                if mark:
                        print('Storing connection data for mark: ' + mark)
                        TRACK.diamConnectionRxDict[mark] = {}
                        TRACK.diamConnectionRxDict[mark]['diamConnection'] = diamConnection
                        TRACK.diamConnectionRxDict[mark]['ipAddress'] = ipAddress

        else:
                TRACK.diamConnectionSy = QAUTILS.getDiamConnection(ipAddress, commandType=interface)
                diamConnection = TRACK.diamConnectionSy

                # Update global data with this mark
                if mark:
                        print('Storing connection data for mark: ' + mark)
                        TRACK.diamConnectionSyDict[mark] = {}
                        TRACK.diamConnectionSyDict[mark]['diamConnection'] = diamConnection
                        TRACK.diamConnectionSyDict[mark]['ipAddress'] = ipAddress

        # Build origin data
        extraAVP = {}
        extraAVP['add'] = []
        extraAVP['omit'] = []

        # Always want to use Gy/Sx origin data
        extraAVP['omit'].append('Origin-Host')
        extraAVP['omit'].append('Origin-Realm')

        # If options passed in, then need to build enough of lclDCT function, as we need one structure going forward
        if options:
                # Set to different values per interface
                if interface.lower() == 'gy':
                        extraAVP['add'].append('Origin-Host:'  + options.originHostGy + '.' + options.randomValue)
                        extraAVP['add'].append('Origin-Realm:' + options.originRealmGy)
                        
                        # Save data (may use for special test cases below)
                        host = options.originHostGy + '.' + options.randomValue
                        realm = options.originRealmGy
                        
                elif interface.lower() == 'gx':
                        extraAVP['add'].append('Origin-Host:'  + options.originHostGx + '.' + options.randomValue)
                        extraAVP['add'].append('Origin-Realm:' + options.originRealmGx)
                elif interface.lower() == 'sh':
                        extraAVP['add'].append('Origin-Host:'  + options.originHostSh + '.' + options.randomValue)
                        extraAVP['add'].append('Origin-Realm:' + options.originRealmSh)
                else:
                        extraAVP['add'].append('Origin-Host:'  + options.originHostSy + '.' + options.randomValue)
                        extraAVP['add'].append('Origin-Realm:' + options.originRealmSy)
        else:
                # Get a random value
                randomValue = str(random.randint(1,1000000))
                
                # Set to different values per interface
                if interface.lower() == 'gy':
                        extraAVP['add'].append('Origin-Host:'  + lclDCT['originHostGy'] + '.' + randomValue)
                        extraAVP['add'].append('Origin-Realm:' + lclDCT['originRealmGy'])
                        
                        # Save data (may use for special test cases below)
                        host = lclDCT['originHostGy'] + '.' + randomValue
                        realm = lclDCT['originRealmGy']
                        
                elif interface.lower() == 'gx':
                        extraAVP['add'].append('Origin-Host:'  + lclDCT['originHostGx'] + '.' + randomValue)
                        extraAVP['add'].append('Origin-Realm:' + lclDCT['originRealmGx'])
                elif interface.lower() == 'sh':
                        extraAVP['add'].append('Origin-Host:'  + lclDCT['originHostSh'] + '.' + randomValue)
                        extraAVP['add'].append('Origin-Realm:' + lclDCT['originRealmSh'])
                else:
                        extraAVP['add'].append('Origin-Host:'  + lclDCT['originHostSy'] + '.' + randomValue)
                        extraAVP['add'].append('Origin-Realm:' + lclDCT['originRealmSy'])

        # Send CER on this connection (required to process any Diameter packets)
        DIAMPKT.createCapabilityExchangeRequest(diamConnection=diamConnection, extraAVP=extraAVP)

        # Force second identical CER
        errFlag = False
        if errFlag:
         if interface.lower() == 'gy':
                # Build origin data
                extraAVP = {}
                extraAVP['add'] = []
                extraAVP['omit'] = []
                
                # Always want to use Gy origin data
                extraAVP['omit'].append('Origin-Host')
                extraAVP['omit'].append('Origin-Realm')
                
                extraAVP['add'].append('Origin-Host:'  + host)
                extraAVP['add'].append('Origin-Realm:' + realm)
                DIAMPKT.createCapabilityExchangeRequest(diamConnection=diamConnection, extraAVP=extraAVP)

                # Force error CER
                DIAMPKT.createCapabilityExchangeRequest(diamConnection=diamConnection, extraAVP=extraAVP, eventPass=False)
        
        # If the interface is not gy, then skip the rest
        if interface.lower() != 'gy': return

        # *** Always echo to Gy connection ****
        # Get Diameter hostname
        if ipAddress:
                DiameterHostName = ipAddress.split(':')[0]
        else:
                DiameterHostName = QAUTILS.gatewaysConfig.get('DIAMETER','hostname')

        # Get my host name (IP address used to connect to Diameter host).
        # Do this by connecting to the Diameter gateway and seeing which IP address was used for that connection.
        s = RESTV3.realsocket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect((DiameterHostName, 80))
        MyHostName = s.getsockname()[0]
        s.close()
        del s

        # Output IP addresses
        #print 'Diameter IP address is: ' + DiameterHostName
        #print 'Local IP address is: ' + MyHostName

        return

#==========================================================
def saveCsvMDC(queryValue, queryType, lclDCT, repeatCount, step, testName, RESTInst):
        # Skip saving MDC if:
        # * action doesn't expect a query
        # * action was expected to fail (DO ON EXPECTED FAIL - many saved tests expect a MDC file in these cases)
        # * tool is not tracking results
        # * this is not a Gy command (QUERY ON ALL INTERFACE COMMANDS)
        # * command parameter set to not output data
        # Otherwise, if command parameter has specifically asked for the data or we're at the end of the command,
        # then print messages for all reasons not to query output
        #print('repeat = ' + str(lclDCT['repeat']) + ', repeatCount = ' + str(repeatCount) + ', verbose = ' + lclDCT['verbose'])
        if not queryValue:      print('Not querying data as command does not impact OCS group/subscriber/device object')
        elif lclDCT['ACTION'].startswith('query') and not lclDCT['eventPass']: print('Not querying data since query event failure is expected (framework issue)')
        elif (lclDCT['skipStepResults'] or lclDCT['stopCountingSteps']) and not lclDCT['saveEvents'] and not lclDCT['saveNotifications']:
                # May still want to see output
                # If verbose not disabled then run trace command (output goes to std out)
                if lclDCT['verbose'].lower() not in ['none', 'no', 'low']:
                        printToScreen(lclDCT['saveFunc'], queryValue, queryType, lclDCT, lclDCT['lclStartTime'])
                
                print('\n\nNot saving data as parameter skipStepResults is set and no saveXXX parameter specified')
                
        elif ((int(lclDCT['repeat']) == int(repeatCount)) or lclDCT['verbose'].lower() in ['full', 'high']):
                # Define common file name starting string.  
                # Always grab the last part of the name (as we don't want any leading directories in where we're going to save the data).
                name = testName.split('/')[-1] + DATA.fileChar
                
                # Use either the step or the saveOutputFileName
                if lclDCT['saveOutputFileName']:
                        name += lclDCT['saveOutputFileName']
                else:
                        formatted_step = u'%03d' % step
                        name += str(formatted_step)
                
                # Want to use the new test name
                saveTestName = lclDCT['testName']
                lclDCT['testName'] = name
                
                # For diameter events we want to add the request type to the string
                if lclDCT['ACTION'].startswith('diameter'): name += DATA.fileChar + lclDCT['requestType']

                # Add common ending to the file name
                name += DATA.fileChar + lclDCT['ACTION']
                #print('testname = ' + testName + ', name = ' + name)
                
                # If doing diffOnly then want to save that data versus a default save
                # Save query value
                saveQueryVal = queryValue
                if lclDCT['diffOnly']:
                        # Set query value to 0 so QA function does the right thing
                        queryValue = 0
                        
                        # Gather diff data
                        if   lclDCT['saveFunc'] == 'saveMDC':       
                                debugData = MISC.CmdMisc_diffdata(lclDCT, 'Sub')
                        elif lclDCT['saveFunc'] == 'saveDeviceMDC':
                                debugData = MISC.CmdMisc_diffdata(lclDCT, 'Dev')
                        else:   debugData = MISC.CmdMisc_diffdata(lclDCT, 'Group')
                elif "doNotRunCommand" in lclDCT:
                        # Set query value to 0 so QA function does the right thing
                        queryValue = 0
                        
                        # Set debug data to value of dictionary entry
                        debugData = lclDCT['doNotRunCommand']
                else:   debugData = ''
                
                # Minor hack:  if verbose setting is default (normal) and this is a 5G operation, then we want to not output one of the print statements in the save functions...
                if lclDCT['verbose'] == 'normal' and lclDCT['interface'].lower().startswith('5g'):
                        verbose = '5g'
                else:   verbose = lclDCT['verbose']
                
                # If doing a custom command then do NOT pass in the time, as these tend to take longer and thus we're not seeing values returned properly in the query
                if name.count('cust'):  queryTime=None
                else:                   queryTime = lclDCT['lclStartTime']
                
                # Now do the query if not skipping results and not skipping counting of step files.
                if not lclDCT['skipStepResults'] and not lclDCT['stopCountingSteps']:
                        if   lclDCT['saveFunc'] == 'saveMDC':       QAUTILS.saveMDC(queryValue, name, debugData = debugData, queryType=queryType, queryTime=queryTime, verbose=verbose)
                        elif lclDCT['saveFunc'] == 'saveDeviceMDC': QAUTILS.saveDeviceMDC(queryValue, name, debugData = debugData, queryType=queryType, queryTime=queryTime, verbose=verbose)
                        else:                                       QAUTILS.saveGroupMDC(queryValue, name, debugData = debugData, queryType=queryType, queryTime=queryTime, querySize=lclDCT['querySize'], verbose=verbose)
                
                # Check here for other data to save.  NOTE: will do this even if skipStepResults is set, as this is special data (versus generic save data that changes often)
                for item in ['events', 'notifications']:
                 element = 'save'+ item.capitalize()
                 if lclDCT[element]:
                        # Indicate events
                        lclDCT['eventProcessing'] = item
                        
                        # Notifications use Notification Done event, which requires system time.
                        # Events can use TF time
                        if item == 'events':
                                timeToUse = DATA.timeOfLastCommand
                        else:   timeToUse = lclDCT['systemTime']
                        
                        # Now do the query
                        if   lclDCT['saveFunc'] == 'saveMDC':           CSVEVENTS.checkEvents('subscriber', lclDCT['subQueryType'],   lclDCT['externalId'], lclDCT, RESTInst, timeToUse, name, False, lclDCT[element+'Substring'])
                        elif lclDCT['saveFunc'] == 'saveDeviceMDC':     CSVEVENTS.checkEvents('device',     lclDCT['devQueryType'],   lclDCT['deviceId'],   lclDCT, RESTInst, timeToUse, name, False, lclDCT[element+'Substring'])
                        else:                                           CSVEVENTS.checkEvents('group',      lclDCT['groupQueryType'], lclDCT['groupId'],    lclDCT, RESTInst, timeToUse, name, False, lclDCT[element+'Substring'])
                        
                # If verbose not disabled then run trace command (output goes to std out)
                if queryValue and lclDCT['verbose'].lower() not in ['none', 'no', 'low']:
                        printToScreen(lclDCT['saveFunc'], queryValue, queryType, lclDCT, lclDCT['lclStartTime'])
                
                # Restore query value
                queryValue = saveQueryVal
                
                # Restore test name
                lclDCT['testName'] = saveTestName
                
#==========================================================
# Right now this processes simple normlizers (1:1 mapping of value to result).  Future iterations can account for ranges.
# Balance ranges get trickier as one needs to know the algorithm to know what to choose for the range value.
def processNorm(_config, normId, tier = 1, mapping = {}, useDescription=False):
    #print 'Looking at normalizer: ' + str(normId)
    norm = CB.getNormalizer(_config, normId)
    #pprint.pprint(norm)

    # Process each value.
    # NOTE: Result "index" attribute maps to name "id" attribute (not the name "index" parameter).  Store "id" value here.
    # Variable names to avoid here: color, index, description, name, id
    nameResult = {}
    # For consistency, if item is not a lst then make it one
    if type(norm['object']['normalizer']['values']['value']) != type(list()): norm['object']['normalizer']['values']['value'] = [norm['object']['normalizer']['values']['value']]
    for entry in norm['object']['normalizer']['values']['value']:
        for item in entry['attrib']:
                (field,assignment) = item
                
                # Add escapes so the value can have double quotes
                if   field == 'description': description = assignment.replace('"', r'\"')
                elif field == 'name': name = assignment.replace('"', r'\"')
                elif field == 'id':   id = assignment.replace('"', r'\"')
        
        # Store name or description
        if useDescription: nameResult[id] = description
        else:              nameResult[id] = name
        
    #pprint.pprint(norm)

    # Process each result.
    # NOTE: Result "index" attribute maps to name "id" attribute (not the name "index" parameter).  Store "index" value here.
    # Variable names to avoid here: index, exact, value
    resultResult = {}
    # For consistency, if item is not a lst then make it one
    if type(norm['object']['normalizer']['results']['result']) != type(list()): norm['object']['normalizer']['results']['result'] = [norm['object']['normalizer']['results']['result']]
    
    # Make sure there are some results returned
    if 'result' not in norm['object']['normalizer']['results']:
        print(norm['object']['attrib']['filename'] + ' has no results.  Please check this.')
        return mapping

    for entry in norm['object']['normalizer']['results']['result']:
        for item in entry['attrib']:
                (field,assignment) = item
                
                # Add escapes so the value can have double quotes
                if   field == 'index': index = assignment.replace('"', r'\"')
                elif field == 'value': value = assignment.replace('"', r'\"')
                
        # Can have an array of items pointing to a single index
        if index not in resultResult: resultResult[index] = []
        resultResult[index].append(value)
#    print 'resultResult'
#    pprint.pprint(resultResult)

    # Map name/result to the mapping function.  Can use common value for index since name/result vaues above were stored using proper attribute.
    for index in nameResult:
        if index in resultResult and len(resultResult[index]):
                # FIXME: Really shoul dloop here so we can have depth of more than 2.  Right now teir 3 or higher does;t work...
                if tier == 1:   mapping[nameResult[index]] = resultResult[index][0]
                else:
#                        print 'Looking to map index ' + str(index) + ' nameResult ' + str(nameResult[index]) + ' result ' + str(resultResult[index][0])
                        # Sanity check the mappings - will help find inconsistent CB items
                        idx = resultResult[index][0]
                        if idx not in mapping:
                                print('WARNING: normalizer ID ' + str(normId) + ' value ' + idx + ' not defined.  Can not map to index ' + nameResult[index])
                                mapping[nameResult[index]] = 'NOT MAPPED'
                        else:   mapping[nameResult[index]] = mapping[idx]
        else:   mapping[nameResult[index]] = 'NOT MAPPED'

    # If this is a phone match normalizer then we want to eliminate the wild card characters
    found = None
    for attr in norm['object']['normalizer']['attrib']:
        (param,value) = attr
        if param == 'algorithm':
                found = value
                break
    
    # If not found, that's not good
    if not found: print('WARNING: did not find an algorithm attribute for normalizer ' + str(normId))
    elif found == 'phonePattern': mapping = resolvePhonePattern(mapping)
    
    # Finally done....
    return mapping

#==========================================================
def resolvePhonePattern(mapping):
        #pprint.pprint(mapping)
        
        # Process each entry
        for key in mapping:
                # Get entry
                orig = new = mapping[key]
                
                # If only digits then nothing to do
                if orig.isdigit(): continue
        
                # Replace single digit and multi-digit wild cards with a '9'
                new = new.replace('?', '9')
                new = new.replace('*', '9')
                
                # If no brackets then we're done with this entry
                if not new.count('['): 
                        #print 'Modified entry "' + key + '" from "' + orig + '" to "' + new + '"'
                        mapping[key] = new
                        continue
                
                # Now for the fun stuff (brackets).  Probabaly a better way to do this...
                # Split into fields
                entryFields = new.split('[')
                
                # Now first element is fine as-is.
                # Subsequent elements are start of open brackets + end + anything to the next start.
                new = entryFields[0]
                
                # Process remaining entries
                for i in range(1,len(entryFields)):
                        # Use first character of bracket
                        new += entryFields[i][0]
                        
                        # Now split from the close of the bracket
                        remainder = entryFields[i].split(']')
                        if len(remainder) > 1: new += remainder[1]
                
                #print 'Modified entry "' + key + '" from "' + orig + '" to "' + new + '"'
                
                # Store updated entry
                mapping[key] = new
                
#==========================================================
def findNormId(normList,nameToFind):
    normId = None
    for entry in normList['NormalizerList']['Normalizer']:
        #pprint.pprint(entry)
        # Name takes priority over external ID
        if 'NAME' in entry:     value = 'NAME'
        else:                   value = 'EXTERNAL_ID'
        
        # See if we found it
        if 'value' in entry[value] and entry[value]['value'] == nameToFind:
                # Get the ID of this normalizer
                normId = entry['ID']['value']
                
                # Only one normalizer should match the name...
                break

    return normId

#==========================================================
def processNormalizerFromName(normList, normName, tier, mapping, useDescription):
        # Find normaliser if non-digits entered
        if not str(normName).isdigit(): normId = findNormId(normList, normName)
        else:                           normId = normName
        
        if normId == None: 
                print('ERROR: did not find normalizer: ' + normName)
                return False

        # Process normalizer
#        print 'Processng normalizer ' + str(normId)
        processNorm(CB._config, normId, tier, mapping=mapping, useDescription=useDescription)
#        pprint.pprint(mapping)
        
        return True

#==========================================================
def getAllParameterData(action='None'):
        # This wil be used for save/restore operations
        parameter = 'AllParameters'
        
        # If restoring, then restore and continue
        if action.lower() == 'restore':
                print('Restoring "' + parameter + 'MappingFile"')

                # Restore from saved file
                paramList = GENERIC.restoreDictionary(PRIMDATA.savedEngineData + "AllParametersMappingFile")
        else:
                # Login
                CB.cbLogin(CB._config)

                # Get data
                try:
                        paramList = CB.getAllParameterData(CB._config)

                        # See if errors returned
                        if 'ErrorResponse' in paramList:
                            print('Parameter read returned errors.')
                            pprint.pprint(paramList)
                            paramList = None
                        elif 'ParameterDefnList' in paramList and 'ErrorResponse' in paramList['ParameterDefnList']:
                            print('Parameter read returned errors.')
                            pprint.pprint(paramList)
                            paramList = None

                except: paramList = None
        
        # If we should save, then save here
        if action.lower() == 'save':
                
                # Save to file
                cmd = 'GENERIC.saveDictionary(paramList, PRIMDATA.savedEngineData + "' + parameter + 'MappingFile")'
                #print cmd
                exec(cmd)
                        
        # If nothing defined, then exit
        if not paramList: return
        
        # Create custom objects of not defined
        if not hasattr(CUST, 'custOfferParameterList'): CUST.custOfferParameterList = []
        if not hasattr(CUST, 'custParameters'): CUST.custParameters = []
        
        # Add to both structures
        for entry in paramList:
                # Get array entries to local variables
                for item in paramList[entry]['object']['parameter_definition']['attrib']:
                        if   item[0] == 'name': name = item[1]
                        elif item[0] == 'valuetype': valuetype = item[1]
                        
                # If the name has any spaces, then need to change to underscore, as space is not a valid variable (which these will become)
                if name.count(" "):
                        print('Replacing offer parameter name "' + name + '" so spaces are underscores.')
                        name = name.replace(" ", "_")
                        print('TF parameter name : ' + name)
                
                # Add name to list of parameters iff not already present
                if not CUST.custOfferParameterList.count((name, valuetype)):
                        #print('Adding parameter "' + name + '/' + valuetype + '" to custOfferParameterList')
                        CUST.custOfferParameterList.append((name, valuetype))
                
                # Add to parameter list iff not already present
                if not len([x for x in CUST.custParameters if x[0] == name]):
                        # Add as a string for now.  Could look at "valuetype" and set the type and default values differently, but for now leave as a string.
                        #print('Adding parameter "' + name + '" to custParameters')
                        CUST.custParameters.append((name, 'store', 'string', None))
                
#==========================================================
def _setValue(index, varaible, value):
        varaible[index] = value
        
#==========================================================
def normalizerMapping(action="None"):
        failFlag = False
        warnParameterList = []
        processFileList = []
        
        # If not restoring, then stuff to do
        if action.lower() != 'restore':
                # Login 
                CB.cbLogin(CB._config)
                
                # Get normalizer list
                normList = CB.getAllNormalizerData(CB._config, processAll=-1)
#               pprint.pprint(normList)

        # Process a list of normalizers
        for entry in CUST.normalizerMappingList:
                # Get values.  Several optional parameters (there must be a more pythonic way to do this...)
                parameter = entry[0]
                
                # If restoring, then restore and continue
                if action.lower() == 'restore' and parameter + 'MappingFile' not in processFileList:
                        print('Restoring "' + parameter + 'MappingFile"')
                        
                        # Restore from saved file
                        cmd = 'CUST.' + parameter + 'Mapping = GENERIC.restoreDictionary(PRIMDATA.savedEngineData + "' + parameter + 'MappingFile")'
                        exec(cmd)
                        
                        # Add to processed list
                        processFileList.append((parameter + 'MappingFile'))
                
                # Resume processing normalizer list items
                normName = entry[1]
                if len(entry) > 2:      tier = entry[2]
                else:                   tier = 1
                if len(entry) > 3:      home = entry[3]
                else:                   home = None
                if len(entry) > 4:      roam = entry[4]
                else:                   roam = None
                if len(entry) > 5:      useDescription = entry[5]
                else:                   useDescription = False
                if len(entry) > 6:      defaultValue = entry[6]
                else:                   defaultValue = None
                
                # *** To be nice:
                # 1) Create custom parameter mapping dictionary if not defined
                cmd = "if not hasattr(CUST, '" + parameter + "Mapping'): CUST." + parameter + "Mapping = {}"
                exec(cmd)
                
                # 2) Create custom translate array if not defined
                if not hasattr(CUST,'custParameterTranslate'): CUST.custParameterTranslate = []
                
                # 3) Add entry to custom translate array if not there for parameter
                found = False
                for entry in CUST.custParameterTranslate + DATA.parameterTranslate:
                        param = entry[0]
                        if param == parameter:
                                found = True
                                break
                if not found:
#                       print 'Adding parameter ' + parameter + ' to CUST.custParameterTranslate'
                        CUST.custParameterTranslate.append((parameter, None, True))
                
                # 4) Create custom parameter array if not defined
                if not hasattr(CUST,'custParameters'): CUST.custParameters = []
                
                # 5) Remove from default if defined (cust definitions of default params take precedence)
                found = False
                for i,entry in enumerate(DATA.parameters + CUST.custParameters):
                        param = entry[0]
                        if param == parameter:
                                # Set flag to found
                                found = True
                                
                                # Only ever one entry per parameter
                                break
                
                # 6) Add to custParameters if not found
                if not found:
#                       print 'Adding parameter ' + parameter + ' to CUST.custParameters'
                        CUST.custParameters.append((parameter, 'store', 'string', defaultValue))
                elif entry[3] != defaultValue and parameter not in warnParameterList:
                        # Debug output
                        print('WARNING: Didn\'t update base parameter ' + parameter + ' default value of "' + str(entry[3]) + '" to "' + str(defaultValue) + '"')
                        
                        # Add to list of parameters that have already been warned
                        warnParameterList.append(parameter)
                
                # ** Done being nice...
                
                # If not restoring, then process normalizer
                if action.lower() != 'restore':
                        # Process entry, using existing parameter mappings as the baseline
                        #print('Parameter ' + parameter + ' adding mappings from normalizer "' + normName + '"')
                        cmd = '_a = processNormalizerFromName(normList, normName, tier, CUST.' + parameter + 'Mapping, useDescription)'
                        exec(cmd)
                        normCheck = locals()['_a']
                
                        # Detect local failure
                        if not normCheck: failFlag = True
                        
                        # If overall failure then do nothing here as we're going to exit anyways.
                        if failFlag: continue
                        
                        # Add home entry (always seems to be desired)
                        if home: 
                                if home.isdigit():      cmd = '_setValue("home", CUST.' + parameter + 'Mapping, ' + home + ')'
                                else:                   cmd = '_setValue("home", CUST.' + parameter + 'Mapping, CUST.' + parameter + 'Mapping["' + home + '"])'
                                #print(cmd)
                                exec(cmd)
                                
                        # Add roam entry (always seems to be desired)
                        if roam: 
                                if roam.isdigit():      cmd = '_setValue("roam", CUST.' + parameter + 'Mapping, ' + roam + ')'
                                else:                   cmd = '_setValue("roam", CUST.' + parameter + 'Mapping, CUST.' + parameter + 'Mapping["' + roam + '"])'
                                #print(cmd)
                                exec(cmd)
                        
                # Debug output
                #cmd = 'pprint.pprint(CUST.' + parameter + 'Mapping)'
                #exec(cmd)
                
                # If saving, then record it needs to be saved.  Record only once.
                if action.lower() == 'save' and parameter not in processFileList: processFileList.append((parameter))
        
        # Logout if not restoring
        #if action.lower() != 'restore': CB.cbLogout(CB._config)
        
        # If we should save, then save here
        if action.lower() == 'save':
                for parameter in processFileList:
                        print('Saving parameter "' + parameter + '"')
                
                        # Save to file
                        cmd = 'GENERIC.saveDictionary(CUST.' + parameter + 'Mapping, PRIMDATA.savedEngineData + "' + parameter + 'MappingFile")'
                        #print cmd
                        exec(cmd)
                        
        # If we encountered any normalizer errors, then exit
        if failFlag:
                # Need to remove saved data, as we may have saved partial information (so subsequent runs will fail)
                print('Removing saved data in ' + PRIMDATA.savedEngineData + ' due to failing normalizer reads')
                shutil.rmtree(PRIMDATA.savedEngineData)
                
                # Exit
                sys.exit('Exiting due to failures when looking for normalizers')
        
#==========================================================
def initMefFileValues(printFlag=True):
        print('SKIPPING MEF time init for now...')
        return
        
        # Really only need to look at files higher than the latest one now.
#       print 'initMefFileValues: Running command: ' + DATA.mefFileCmdLatest
        
        # Get rid of consecutive spaces, then split on spaces
        DATA.mefFilesProcessedTime = ' '.join(QAUTILS.runCmd(DATA.mefFileCmdLatest).strip().split()).split(" ")
        
        # Reverse sort 
        DATA.mefFilesProcessedTime = sorted(DATA.mefFilesProcessedTime, key=itemgetter(5,6), reverse=True)[0]
        print('DATA.mefFilesProcessedTime = ' + str(DATA.mefFilesProcessedTime))
        
        # If nothing returned use "now" minus msec
        if not DATA.mefFilesProcessedTime:
                print('No MEF files found - using "now" as the base time')
                DATA.mefFilesProcessedTime = GENERIC.getTimeNow().split(".")[0]
        else:
                # Put into MTX format.  Remove msec (primitve used to check time doesn't care for this)
                DATA.mefFilesProcessedTime = DATA.mefFilesProcessedTime[5] + 'T' + DATA.mefFilesProcessedTime[6].split(".")[0]
        
        # Debug output if desired
        if printFlag: print('MEF files base water mark: ' + DATA.mefFilesProcessedTime)
        
#==========================================================
def findMefFilesToProcess():
        filesToProcess = []
        
        print('SKIPPING MEF file process for now...')
        return filesToProcess
        
        # Store current MEF file time
        mefFilesProcessedTime = DATA.mefFilesProcessedTime
        
        # Get new MEF file time now so we don't pull in old data after this
        initMefFileValues(printFlag=False)
        
        # Look at complete MEF files from latest to newest (as many environments don't allow MEF file deletion)
#       print 'findMefFilesToProcess: Running command: ' + DATA.mefFileCmd
        mefFileList = QAUTILS.runCmd(DATA.mefFileCmd).split('\n')
#       print 'findMefFilesToProcess: filesToProcess: mefFileList:'
#       pprint.pprint(mefFileList)
        
        # Process until we find a file <= the last time
        for mefFile in sorted(mefFileList, key=itemgetter(5,6), reverse=True):
                # Get MEF line processed
                mefFile = ' '.join(mefFile.strip().split()).split(" ")
                
                # If size too small, then can ignore
                if int(mefFile[4])< 500: continue
                
                # Get file time in MTX format
                fileTimeStamp = mefFile[5] + 'T' + mefFile[6].split(".")[0]
                
                # Get file name
                mefFileName = mefFile[8]
                
                # If file time stamp > current time stamp, then add the file, else break from the loop.
                if MDCTIME.checkIfTime2GreaterTime1(mefFilesProcessedTime, fileTimeStamp):
                        filesToProcess.append(mefFileName)
                else:   break
        
        return filesToProcess
        
#==========================================================
def getTimeNow():
    # Use primitive function for this
    return GENERIC.getTimeNow()
    
    ### Set time to be now in the target timezone
    # Set environment variable used by pytz libraries to local timezone
    #currentDT = datetime.now()
    #print currentDT.strftime("%Y-%m-%dT%H:%M:%S%z")
    #print currentDT.strftime("%Z")
    
    # From https://stackoverflow.com/questions/1398674/python-display-the-time-in-a-different-time-zone
    localTimeZone = pytz.timezone(MDCTIME.systemTimeZone)
    startTime = localTimeZone.localize(datetime.now())
    startTime = startTime.strftime("%Y-%m-%dT%H:%M:%S%z")
    print('getTimeNow: startTime = ' + str(startTime) + ', system time zone = ' + MDCTIME.systemTimeZone)
    os.environ['TZ'] = MDCTIME.systemTimeZone
    return startTime
    
    # *** Old code: was causing me lots of headaches...
    os.environ['TZ'] = datetime.now(tzlocal()).tzname()
    #os.environ['TZ'] = datetime.now(pytz.utc).tzname()

    # Get local time accountng for timezone
    time.tzset()
    startTime = time.strftime("%Y-%m-%dT%H:%M:%S%z")
    print('getTimeNow: TZ = ' + str(os.environ['TZ']) + ', startTime = ' + str(startTime) + ', system time zone = ' + MDCTIME.systemTimeZone)
    
    # Convert to desired timezone
    startTime = MDCTIME.getTime(startTime=startTime, tz=MDCTIME.systemTimeZone)
    
    return startTime
    
#==========================================================
def checkIpAddress():
        # Make sure /etc/hosts has required defines
        for item in ['diametergw', 'restgw', 'cbhost']:
                result = QAUTILS.runCmd('cat /etc/hosts | grep "^[1-9]" | grep ' + item + ' | wc -l')
                if int(result) != 1: sys.exit('ERROR: file /etc/hosts missing entry for ' + item + '.  It needs to have defines for diametergw, restgw and cbhost')
        
        # Make sure /etc/hosts has desired defines
        for item in ['mongo', 'notgw']:
                result = QAUTILS.runCmd('cat /etc/hosts | grep "^[1-9]" | grep ' + item + ' | wc -l')
                if int(result) != 1: print('WARNING: file /etc/hosts missing entry for ' + item + '.  It should have defines for mongo and notgw')
        
        # Get address where we're sending Diameter traffic
        diameterIpAddr = QAUTILS.runCmd('cat /etc/hosts | grep -v "^#" | grep diametergw | cut -f1 -d" "')

        # Get address of local server
        myIpAddr = QAUTILS.runCmd('ifconfig | grep "inet [1-9]" | cut -c9- | cut -f2 -d" "').split('\n')

        # See if tool is running on blade where diameter traffic will be sent
        if diameterIpAddr not in myIpAddr:
            print('WARNING: Test Framework not running on PROC blade ' + diameterIpAddr + ' configured in /etc/hosts.  Some validation may not be performed.')
            DATA.runningLocal = False

#==========================================================
def makeAmountAdjustments(obj, objId, lclDCT):
        # Easier to set everything versus passing in parameters...
        # *** lclDCT[] has all the values.
        
        # Need amount to be a string here
        amount = str(lclDCT['amount'])
        
        # Read balance
        balance = getBalanceData(obj, objId, lclDCT['balanceId'], lclDCT['resourceId'], lclDCT['lclStartTime'], lclDCT['ACTION'], lclDCT['subQueryType'], returnExpiredOk=True)

        # Get the resource ID if needed.
        # Resource ID may be a number or a string (first, last).
        if (not isinstance(lclDCT['resourceId'], int)) or (lclDCT['resourceId'] == 0): resourceId = int(balance['ResourceId'])
        else: resourceId = lclDCT['resourceId'] # Added during Python3 migration

        # Flag to see if we need to calculate delta for adjustment from current balance
        needToCalculateDeltaFlag = False

        # If clearing, then set desired amount to 0
        if lclDCT['ACTION'].count('ClearBalance'):
                # Amount will be a delta to the current balance value
                needToCalculateDeltaFlag = True

                # Set the desired amount
                amount = '0'
                
        # If a threshold ID passed in then want to adjust relative to it
        elif str(lclDCT['thresholdId']) != '0':
                # Amount will be a delta to the current balance value
                needToCalculateDeltaFlag = True

                # Get threshold data
                (thresholdId, thresholdAmount, percentFlag) = getThresholdId(lclDCT['balanceId'], lclDCT['thresholdId'])
                print('Called threshold function for thresholdId = ' + str(thresholdId) + ', returned amount/pct = ' + thresholdAmount + '/' + percentFlag + ', amount = ' + str(amount))

                # Append threshold amount to whatever amount was entered (unless the default and then overwrite).
                # This allows one to specify above/below in the amount when specifying a threshold.
                if amount[0] in [DATA.adjustAboveChar, DATA.adjustBelowChar]:   amount = amount[0] + thresholdAmount
                else:                                                           amount = thresholdAmount

                # If a percentage then add trailing adjustPercentChar character if not already present
                if percentFlag == 'true': amount += DATA.adjustPercentChar
        
        # If a percentage adjustment desired, then calculate that
        adjustment = 0
        if amount[-1] == DATA.adjustPercentChar:
                # Amount will be a delta to the current balance value
                needToCalculateDeltaFlag = True

                (amount, adjustment) = getBalancePercentage(balance, amount)
        elif amount.startswith(DATA.adjustAboveChar):
                # Amount will be a delta to the current balance value
                needToCalculateDeltaFlag = True

                # Convert remaining amount to number
                if len(amount) > 1: amount = float(amount[1:])
                else:               amount = 0

                adjustment = 1
        
        elif amount.startswith(DATA.adjustBelowChar):
                # Amount will be a delta to the current balance value
                needToCalculateDeltaFlag = True

                # Convert remaining amount to number
                if len(amount) > 1: amount = float(amount[1:])
                else:               amount = 0

                adjustment = -1

        # May be a formula here...  Need to ensure precision holds for the balance (error if not).
        amount = str(processAmountFormula(obj, objId, str(amount), lclDCT['lclStartTime'], lclDCT['ACTION'], precisionFlag = True, balanceId = lclDCT['balanceId'], queryType=lclDCT['subQueryType'], resourceId=resourceId))
        
        # If amount starts with a -, then it means amount remaining
        if amount[0] == '-':  
                # Will need delta to get to this point
                needToCalculateDeltaFlag = True
        
                # If not prepaid then the desired amount is positive
                if balance['IsPrepaid'].lower() == 'false': amount = amount[1:]

        # If need to calculate delta from amount, do that here
        if needToCalculateDeltaFlag: (amount,adjustType) = findAdjustmentFromBalanceAmount(amount, balance, adjustment)
        else: adjustType = lclDCT['adjustType'] # Added during Python3 migration

        # Account for precision of the balance
        amount = acountForPrecision(balance['TemplateId'], amount)

        return amount, adjustType, resourceId
        
#==========================================================
def getBalancePercentage(balance, amount):
        # Remove percent character
        amount = amount[:-1]

#       print 'Detected percentage.  Remaining amount is ' + amount

        # Next character can be DATA.adjustBelowChar (before), DATA.adjustAboveChar (after), or anything else (equal).  Default is equal.
        if not amount[0].isdigit():
                # Use integer to avoid the whole precision issue (can't adjust a balance with a value that has more precision than the balance)
                if   amount[0].lower() == DATA.adjustAboveChar: adjustment = 1
                elif amount[0].lower() == DATA.adjustBelowChar: adjustment = -1
                else:                                           adjustment = 0

                # Remove leading character
                amount = amount[1:]

#               print 'Detected relative value.  Remaining amount is ' + amount

        else:   adjustment = 0

        # Make sure threshold is not infinity (can't take percentage of infinity)
        if balance['ThresholdLimit'].lower() == 'infinity': sys.exit('ERROR: trying to percentage adjust a threshold that\'s set to infinity')
        
        # Get float amount
        balanceThresholdLimit = float(balance['ThresholdLimit'])

        # Set desired amount to be threshold * percentage input
        desiredAmount = balanceThresholdLimit * float(amount) / 100
        
        # If prepaid then the desired amount is negative
        if balance['IsPrepaid'].lower() == 'true': desiredAmount = -1 * desiredAmount

        return desiredAmount, adjustment

#==========================================================
def findAdjustmentFromBalanceAmount(desiredAmount, balance, adjustment):
        # Want to set to just below a percentage of the balance
        balanceAmount = float(balance['Amount'])
        
        # See if prepaid
        prepaidFlag = balance['IsPrepaid'].lower()
        
        # Get delta to adjust
        delta = balanceAmount - float(desiredAmount)

        # Account for adjustment
        amount = delta - float(adjustment)
        
        # If amount is positive then is a credit, else a debit
        if amount > 0:  adjustName = 'credit'
        else:           adjustName = 'debit'
        
        # Amounts are always positive
        amount = abs(amount)
        
        # Set adjust type
        adjustType = DATA.adjustTypeMapping[adjustName]
        
        # Debug output
        print('Adjustment: ' + adjustName + ' of ' + str(amount) + ' to reach desired value of ' + str(desiredAmount) + ' from current value ' + str(balanceAmount))

        return amount, adjustType


#==========================================================
def getNextBillCycleStartTime(lclDCT, lclStartTime, failFlag = True):
        # Get the current bill cycle
        # Need object ID to be backwards compatible
        subObjValue = DATA.objectTypeMapping['subscriber']
        groupObjValue = DATA.objectTypeMapping['group']
        if lclDCT['objectType'] == subObjValue:
                name = 'subscriber'
                objType = lclDCT['subQueryType']
        else:
                name = 'group'
                objType = lclDCT['groupQueryType']

#       print 'Doing bill cycle work.  objectType = ' + lclDCT['objectType'] + ', subQueryType = ' + lclDCT['subQueryType'] + ', groupQueryType = ' + lclDCT['groupQueryType']
        if (lclDCT['objectType'] == subObjValue         and lclDCT['subQueryType']   != 'ObjectId') or \
           (lclDCT['objectType'] == groupObjValue       and lclDCT['groupQueryType'] != 'ObjectId'):
                # Get ID to use
                if lclDCT['objectType'] == subObjValue:
                        idToQuery = lclDCT['externalId']
                else:   idToQuery = lclDCT['groupId']
                
                # Save for error reporting
                saveIdToQuery = idToQuery

                # Get command syntax
                url = '/rsgateway/data/v3/' + name + '/query/' + objType + '/' + idToQuery + GENERIC.getTimeStampStr(lclStartTime)
                q = GET.curlToETFormat(url)
                try:
                        idToQuery = q.find('./ObjectId').text.strip()
                except: idToQuery = None
                
        elif lclDCT['objectType'] == subObjValue: idToQuery = lclDCT['externalId']
        else:                                     idToQuery = lclDCT['groupId']
        
        # Sanity check that we got an OID back
        if (not idToQuery) or len(idToQuery) < 2:
                if failFlag:    sys.exit('ERROR: no subscriber found for ' + name + ' '  + saveIdToQuery + '(' + objType + ')')
                else:
                        print('Warning: getNextBillCycleStartTime() did not find a subscriber for ' + name + ' '  + saveIdToQuery + '(' + objType + ').  Returning as fail flag not set.')
                        return None

        # Query the wallet, then get the next time
        url =  '/rsgateway/data/v3/' + name + '/' + idToQuery + '/wallet' + GENERIC.getTimeStampStr(lclStartTime)
        q = GET.curlToETFormat(url)
        try:
                nextTime = q.find('./CurrentPeriodEndTime').text.strip().split('.')
        except: nextTime = None
        
        # Sanity check that we got a bill cycle back (may not be set)
        if (not nextTime) or len(nextTime) < 2:
                if failFlag:    sys.exit('ERROR: no bill cycle found for ' + name + ' '  + saveIdToQuery + '(' + objType + ')')
                else:
                        print('Warning: getNextBillCycleStartTime() did not find a bill cycle for ' + name + ' '  + saveIdToQuery + '(' + objType + ').  Returning as fail flag not set.')
                        return None

        # Remove usec
        nextTime = nextTime[0] + nextTime[1][6:]

        print('Next bill cycle time for ' + name + ' ' + saveIdToQuery + '(' + objType + '): ' + nextTime)
        
        return nextTime
        
#==========================================================
def validateResults(lclTestName):
        # Debug output
        currentDir = os.getcwd().split('/')[-1]
        print('\n\n\n*** Validating test ' + lclTestName + ' in directory ' + currentDir)

        resultsFile = COMMON.resultsDir + '/Summary_*' + currentDir + '*.txt'
        command = 'rm -f ' + resultsFile + '; validate_balances.py --resultsDir ' + COMMON.resultsDir + ' --string ' + lclTestName
        QAUTILS.runCmd(command)
        command = 'grep Fail ' + resultsFile + ' 2>/dev/null | grep -v Expected | wc -l'
        failCount = QAUTILS.runCmd(command)
        #print 'failCount = ' + failCount
        if failCount == '0':
                print('Validation of test ' + lclTestName + ' passed')
        else:
                print('Validation of test ' + lclTestName + ' failed')
                print('File ' + resultsFile + ':')
                command = 'cat ' + resultsFile
                print(QAUTILS.runCmd(command))
        print('\n\n')

#==========================================================
def saveTestResults(lclTestName, fileOfFilesToSave, dirToSaveTo):
        # Debug output
        print('\n\n\n*** Saving data for test ' + lclTestName)
        
        # Remove/commit currently saved files for this test.
        # Having minor issues redirecting SVN output, as I don;t want errors if the files don;t exist.
        # So do it the old fashoined way: See if any files are there via wc -l and if so do the work
        command = 'ls ' + dirToSaveTo + '/*' + lclTestName + '* > /dev/null 2>&1 | wc -l'
        count = QAUTILS.runCmd(command)
        
        # See if svn is installed.  I'm sure there's a better way...
        command = 'svn info ' + dirToSaveTo + ' | wc -l'
        svnResult = QAUTILS.runCmd(command)
        
        # If no saved files then nothing to do
        if count == 0: pass
        elif int(svnResult) > 2:
                # SVN installed.  Can run SVN commands
                print('Expect directory under SVN.  Will do all SVN work for test: ' + lclTestName)
                
                # Something to remove
                print('Removing files previously saved for test: ' + lclTestName)
                command = 'svn remove ' + dirToSaveTo + '/*' + lclTestName + '*'
                QAUTILS.runCmd(command)
                command = 'svn ci -m "TF auto removing ' + dirToSaveTo + ' files with name ' + lclTestName + '" ' + dirToSaveTo
                QAUTILS.runCmd(command)
        else:
                # SVN not installed.  Can only copy files.
                print(dirToSaveTo + ' directory NOT under SVN.  Will only replace files.')

                command = 'rm -f ' + dirToSaveTo + '/*_' + lclTestName + '_*'
                QAUTILS.runCmd(command)

        # Copy files to directory to save them
        f = open(fileOfFilesToSave, 'r')
        for fileName in f:
                fileName = fileName.strip()
                
                # Might have a blank line in here...
                if not fileName: continue
                
                # Build cp command.  Need to get rid trailing newline
                command = 'cp ' + fileName + ' ./' + dirToSaveTo
                print(command)
                QAUTILS.runCmd(command)

        # SVN add/commit if SVN installed
        if int(svnResult) > 2:
                print('SVN adding files for test: ' + lclTestName)
                command = 'svn add ' + dirToSaveTo + '/*' + lclTestName + '*'
                QAUTILS.runCmd(command)
                command = 'svn ci -m "TF auto adding ' + dirToSaveTo + ' files with name ' + lclTestName + '" ' + dirToSaveTo
                QAUTILS.runCmd(command)

#==========================================================
def perCommandNotificationCheck(lclDCT):
        for entry in lclDCT['notificationCheck']:
                # Separate entry items.
                # API allows for not all values to be present.
                entry = entry.split(',')
                if entry[0].lower() == 'all': balanceClassId = balanceId = thresholdId = amount = None
                else:
                        balanceClassId = entry[0]
                        if len(entry) > 1: balanceId = entry[1]
                        else:              balanceId = None
                        if len(entry) > 2: thresholdId = entry[2]
                        else:              thresholdId = None
                        if len(entry) > 3: amount = entry[3]
                        else:              amount = None
                        
                # Convert None values to real None value
                if balanceClassId and balanceClassId.lower() == 'none': balanceClassId = None
                if balanceId and balanceId.lower() == 'none': balanceId = None
                if thresholdId and thresholdId.lower() == 'none': thresholdId = None
                
                # Translate the above parameters (to support friendly names)
                myDCT = {}
                myDCT['balanceClassId'] = balanceClassId
                parameter = ['balanceClassId', 'balanceClassId', True]
                balanceClassId = translateTextFromMapping(parameter, myDCT)
                myDCT['balanceId'] = balanceId
                parameter = ['balanceId', 'balanceId', True]
                balanceId = translateTextFromMapping(parameter, myDCT)
                
                # Invoke command
                MISC.notificationcheck(balanceClassId, balanceId, thresholdId, amount, lclDCT['eventPass'])
                
#==========================================================
def getServiceConfig():
        return GENERIC.getServiceConfig()

'''
#==========================================================
# Example on the web for getting permutations for a variable number of items.
# This is beyond the author's Python abilities...
# Gets all permutations of multiple lists
def funnyperms(first, *rest):
    for i in itertools.product([first], *(itertools.permutations(j) for j in rest)):
        yield  tuple(zip(*i))
'''

#==========================================================
def generateCommandCombinations(line, lclDCT):
        # Process each field in the line.  User header values and line values that were determined when line was originally processed.
        if len(lclDCT['lineVals']) != len(lclDCT['fileHeaders']):
                print('ERROR: analysis found ' + str(len(lclDCT['lineVals'])) + ' line values but only ' + str(len(lclDCT['fileHeaders'])) + ' headers.  Something aint right...')
                print('Not generating command combinations')
                return
        
        # Get all the fields that have <all> as their value
        indices = []
        fields = []
        for i in range(len(lclDCT['lineVals'])):
                # See if this is one of them
                if lclDCT['lineVals'][i] == '<all>': 
                        # Debug output
                        print('Header ' + lclDCT['fileHeaders'][i] + ' set to ' + lclDCT['lineVals'][i])
                        
                        # Store in indices
                        indices.append(i)
                        
                        # Add field mapping name.
                        # Limit to 20 for now.
                        cmd = 'fields.append(list(CUST.'+lclDCT['fileHeaders'][i]+'Mapping.keys()))'
#                       print cmd
                        exec(cmd)
        
        # OK, I can't *args working, or yield, so need to do this the dumb way...
        if   len(indices) == 1: entries = list(itertools.product(fields[0]))
        elif len(indices) == 2: entries = list(itertools.product(fields[0], fields[1]))
        elif len(indices) == 3: entries = list(itertools.product(fields[0], fields[1], fields[2]))
        elif len(indices) == 4: entries = list(itertools.product(fields[0], fields[1], fields[2],fields[3]))
        else:
                print('ERROR: too many fields with "all" specified (' + str(len(indices)) + '.  Can\'t generate that many combinations')
                sys.exit('Exiting due to command complications')
        
        # Debug output
        print('Generate ' + str(len(entries)) + ' combinations from ' + str(len(indices)) + ' dimensions')
        #pprint.pprint(entries) 
        #pprint.pprint(indices)
        
        # Generate command line for each combination
        result = ''
        for entry in entries:
                entryIndex = 0
                line = ''
                
                # Loop through all header values
                for i in range(len(lclDCT['lineVals'])):
                        # Header is always the same
                        header = lclDCT['fileHeaders'][i]
                        
                        # Skip output file for generated commands
                        if header == 'outputFileName': continue
                        
                        # Value may be the line value of take from the field.
                        # See if this matches the index to replace
                        if i == indices[entryIndex]:
                                # Get value from entry
                                value = entry[entryIndex]
                                
                                # Bump to next index iff any left
                                if len(indices) > entryIndex+1: entryIndex += 1
                        else:   value = lclDCT['lineVals'][i]
                        
                        # Add parameter to the line
                        line += ';' + header + '=' + value
                
                # Remove leading semi-colon and add a new line
                result += line[1:] + '\n'
        
        # Done generating commands.  Write to desired location.
        CSVQA.processDataToOutput(result, lclDCT['outputFileName'])
                
#==========================================================
def findObjectLatestTime(q, lclStartTime, objType, objId, queryType):
        # Check offer times
        for item in q.findall('./PurchasedOfferArray/MtxPurchasedOfferInfo'):
                #ET.dump(item)

                # Query was from "now".  Future purchased items may not have start times, so best we can do is try...
                try:
                        startTime = item.find('./StartTime').text.strip()
                        if startTime and MDCTIME.checkIfTime2GreaterTime1(lclStartTime,startTime): lclStartTime = startTime
                except: pass

                # Cycle start time also needs to be factored in
                for cycle in item.findall("./CycleInfo/MtxPurchasedItemCycleInfo"):
                        # Not sure if cycle time required (this is a new item)...
                        try:
                                # Get cycle end time
                                startTime = cycle.find('./CycleStartTime').text.strip()
                                if startTime and MDCTIME.checkIfTime2GreaterTime1(lclStartTime,startTime): lclStartTime = startTime
                        except: pass


        # Check balance times
        for item in q.findall('./BalanceArray/MtxBalanceInfo'):
                #ET.dump(item)

                # Query was from "now".  Future purchased items may not have start times, so best we can do is try...
                try:
                        startTime = item.find('./StartTime').text.strip()
                        if startTime and MDCTIME.checkIfTime2GreaterTime1(lclStartTime,startTime): lclStartTime = startTime
                except: pass

        # Check last activiy time
        try:
                startTime = q.find('./LastActivityTime').text.strip()
                if startTime and MDCTIME.checkIfTime2GreaterTime1(lclStartTime,startTime): lclStartTime = startTime
        except: pass
        
        # If input is an object without a wallet then exit here.  Remainder assumes a wallet.
        if objType not in ['subscriber', 'group']: return lclStartTime
        
        # Check bill cycle.  Not all input objects have a wallet, so use try/except here.
        try:
                q2 = GET.getObjectWallet(objId, hostname=QAUTILS.gatewaysConfig.get('REST', 'restServer'), hostport=QAUTILS.gatewaysConfig.get('REST', 'restPort'), queryType=queryType, objType=objType)

                # Get cycle end time
                for cycle in q2.findall('./BillingCycle/MtxBillingCycleInfo'):
                        #ET.dump(cycle)
                        # Get start of bill cycle
                        startTime = cycle.find('./CurrentPeriodStartTime').text.strip()
                        if startTime and MDCTIME.checkIfTime2GreaterTime1(lclStartTime,startTime): lclStartTime = startTime
                        break
        except: pass

        return lclStartTime

#==========================================================
def convertOfferExtIdToCatalogId(offerId):
        # Process all offers
        for i,offer in enumerate(offerId):
                try:
                        offerId[i] = DATA.offerExtIdToId[offer]
                except:
                        # If input is numerical then it's fine
                        if offer.isdigit(): continue
                        
                        # If here, then a non-digit entered and no mapping...
                        print('ERROR: offer external ID "' + offer + '" doesn\'t have a mapping from DATA.offerExtIdToId')
                        pprint.pprint(DATA.offerExtIdToId)
                        sys.exit('Exiting due to errors')

#==========================================================
def processOffers(offerId, objOfferId, offerIsExternal, offerIsCatalog, allOffers=False):
        # Check if purchasing all offers
        if allOffers:
                # May have a list of offers to block (or may not).
                try:
                        offersToBlock = copy.deepcopy(CUST.custSubOfferBlock)
#                       print 'sub offers to block: ' + str(offersToBlock)
                except:
                        offersToBlock = None

                # Get the list of offers to purchase
                offerId = getOfferList(offerIsExternal, offersToBlock, startTime)
        
        # Can provide objOfferId or offerId for this command.
        # Map to offer ID.
        if ((not offerId) or offerId.count('0')) and objOfferId: offerId = objOfferId

        # If offerId is 0, then we don't want to purchase anything.  Make sure the offer external flag is False (hard to set via command line).
        if not offerId or offerId.count('0'):
                offerIsExternal = '0'
                offerId = 0

        # If user wants catalog item IDs, then translate here (as default translation is name to external ID)
        if (not offerIsExternal) and (offerId != 0):
                # Convert external IDs to catalog item IDs
                convertOfferExtIdToCatalogId(offerId)

        # Last conversion:  if offer is catalog item then set the catalogItemId parameter, else clear it
        if offerIsCatalog:
                # Need this set to offerId for called API to set the right field
                catalogItemId = offerId
        else:   catalogItemId = None

        return catalogItemId,offerId

#==========================================================
def storeOfferConstants(target, response, catalogItemId, offerId):
                # Need to get information, as we need more than the resource IDs
                q = ET.fromstring(response)

                # Get reource ID
                for offer in q.findall('./PurchaseInfoArray/MtxPurchaseInfo'):
                        # Get field
                        resourceId = offer.find('./ResourceId').text.strip()

                        # Only want the first one
                        break
                else:
                        print('Warning: did not find a resource ID from the last puchase')
                        return
                
                # If resource ID is 0, then this was a one-time offer and don't overwrite vaues since not in the wallet
                if int(resourceId) == 0: 
                        print('NOTE: Resource ID is 0.  Not saving since this was one-time offer.')
                        return
                        
                # Save as constant
                DATA.constantValue['LastOfferPurchaseResourceId'] = resourceId
                DATA.constantValue['Last'+target.capitalize()+'OfferPurchaseResourceId'] = resourceId

                # Store ID of what was purchased
                if catalogItemId: purchasedId = catalogItemId
                else:             purchasedId = offerId
                DATA.constantValue['LastOfferPurchaseId'] = purchasedId
                DATA.constantValue['Last'+target.capitalize()+'OfferPurchaseId'] = purchasedId

                # Payment resource ID is optional
                field = GET.getObjectField(q, 'PaymentResourceId')
                if field: DATA.constantValue['LastPaymentResourceId'] = DATA.constantValue['Last'+target.capitalize()+'PaymentResourceId'] = field

                # Debug output
                outStr = 'Tracking: Last'+target.capitalize()+'OfferPurchaseResourceId = ' + resourceId + ', Last'+target.capitalize()+'OfferPurchaseId = ' + str(purchasedId[0])
                if field: outStr += ', Last'+target.capitalize()+'PaymentResourceId = ' + field
                print(outStr)

#===============================================================================
# Process API response and extract ctaalog item ID + external ID
def getCatalogIDs(respData):
        outData = ''
        
        # Convert to Python object
        q = ET.fromstring(respData)
        #ET.dump(q)
        
        # Get CIs.  Check for all possible response headings
        for responseString in ['./CatalogItemList/MtxPricingCatalogItemInfo', './CatalogInfo/MtxPricingCatalogDetailInfo/CatalogItemList/MtxPricingCatalogItemInfo']:
            #print 'Check for string: ' + responseString
            for child in q.findall(responseString):
                '''
                print 'Looking at child:'
                ET.dump(child)
                '''
                
                # Get CI data
                try:    extId = child.find('ExternalId').text.strip()
                except: extId = 'N/A'
                
                try:    Id = child.find('CatalogItemId').text.strip()
                except: Id = 'N/A'
                
                # Add to output data
                outData += Id + '(' + extId + ')\n'
        
        # Add header if anything found
        if outData: outData = '\n' + outData
        else:       outData = 'None'
        
        return outData
        
#===============================================================================
def main():
    x = 1


if __name__ == '__main__':
    main()

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


