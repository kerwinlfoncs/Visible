#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:41:20
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:37:03
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:20
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

import qa_utils as QAUTILS
import os, string,sys, time
import socket 

def startConsume(topic='all'):
    pid=None
    consumeCmd="/usr/bin/java -jar /opt/mtx/bin/mtx_notification_client.jar -address:tcp://127.0.0.1:61616 matrixx."+topic +"  >> ./results/ECT_notification.dat 2>&1 &"
    #print consumeCmd
    QAUTILS.runCmd(consumeCmd)
    pid=QAUTILS.runCmd('ps -ef | grep mtx_notification_client.jar | grep -v grep |  awk {\'print $2\'}')
    if pid:
       return pid
    else:
       return None

def stopConsume():
    pid=None
    pid=QAUTILS.runCmd('ps -ef | grep  mtx_notification_client.jar |grep -v grep | awk {\'print $2\'}')
    return QAUTILS.runCmd('kill -9 ' + pid)
 
def killProxy():
    pid=None
    pid=QAUTILS.runCmd('ps -ef | grep gateway_proxy.jar | grep -v grep |  awk {\'print $2\'}')
    #print 'kill proxy pid=',pid
    return QAUTILS.runCmd('kill -9 ' + pid)

def startProxy():
    pid=None
    return QAUTILS.runCmd('start_proxy.py | cut -d\'=\' -f2')

def killAmq():
    pid=None
    cmd='ps -ef | grep apache-activemq-5.*.* | grep -v grep | awk {\'print $2\'}'
    pid=QAUTILS.runCmd(cmd) 
    return QAUTILS.runCmd('kill -9 ' + pid)

def startAmq(amqpath='/opt/Activemq'):
    pid=None
    if  os.path.exists(amqpath) is False:
       return "amq path not found"
    cmd=amqpath + '/apache-activemq-5.*.*/bin/activemq start'
    QAUTILS.runCmd(cmd)
    pid=QAUTILS.runCmd('ps -ef | grep pache-activemq-5.*.* | grep -v grep | awk {\'print $2\'}')
    time.sleep(5)
    portListen=QAUTILS.runCmd('netstat -an | grep 61616')  
    if pid and len(portListen) !=0: 
      return pid #amq started
    else:
      return None #fail to start amq

def killAmqConnector():
    pid=None
    cmd='ps -ef | grep activemq_connector | grep -v grep | awk {\'print $2\'}'
    pid=QAUTILS.runCmd(cmd)
    killcmd='"kill -9 ' + pid +'"'
    return QAUTILS.runCmd('sudo su - mtx_activemq -c ' + killcmd)
    
def startAmqConnector():
    pid=None
    cmd='"/opt/mtx_activemq_connector/bin/start_activemq_connector.py"'
    QAUTILS.runCmd('sudo su - mtx_activemq -c ' + cmd)
    pid=QAUTILS.runCmd('ps -ef | grep activemq_connector | grep -v grep | awk {\'print $2\'}')
    time.sleep(5)
    return pid


def killNotifier():
    pid=None
    cmd='ps -ef | grep mtx_notifier_camel.jar | grep -v grep | awk {\'print $2\'}'
    pid=QAUTILS.runCmd(cmd)
    return QAUTILS.runCmd('kill -9 ' + pid)
    

def startNotifier():
    pid=None
    QAUTILS.runCmd('start_notifier.sh >> /dev/null')
    pid=QAUTILS.runCmd('ps -ef | grep mtx_notifier_camel.jar | grep -v grep | awk {\'print $2\'}')
    time.sleep(1)
    return pid

def configAmqAckQueue(mode='1',engineIp='127.0.0.1'):
    if mode !='1' and mode != '0':
       return 'not a valid mode, only allow value 0 or 1'

    #validate if engineIP is a valid ip address
    if engineIp != 'localhost':
        try:
           socket.inet_pton(socket.AF_INET, engineIp)
        except AttributeError:  # no inet_pton here
           try:
              socket.inet_aton(engineIp)
           except socket.error:
              return 'not a valid ip'
           return address.count('.') == 3
        except socket.error:  # not a valid address
           return 'not a valid ip'
    cmd='\"sed -i \\"s/<use_activemq_ack_queue>.*</<use_activemq_ack_queue>'+mode+'</\\" /opt/mtx_activemq_connector/conf/mtx_config.xml;sed -i \\"s/<diameter_address>.*</<diameter_address>'+engineIp+':3868</\\" /opt/mtx_activemq_connector/conf/mtx_config.xml\"'
    #print 'cmd = ', cmd
    return QAUTILS.runCmd('sudo su - mtx_activemq -c ' + cmd)


def updateNotifierProp(proxy=True):
    notifierProp='/var/run/mtx/mtx_notifier.properties'
    if  os.path.exists(notifierProp) is False:
       return "notifier.properties file  not found"

    #delete all entries for update.xxx: xxx
    delcmd='sed -i \"/update/d\"  ' +  notifierProp
   
    if proxy is True:
       #add update.address and update.port entries
       addcmd='sed -i \"$ a\\update.address:     localhost  \\nupdate.port:      4070\" ' +  notifierProp
    else:
       #add update.file entry
       addcmd='sed -i \"$ a\\update.file:      /opt/mtx/conf/mtx_config.xml\"  '   +  notifierProp

    retMsgDel=QAUTILS.runCmd(delcmd)
    retMsgAdd=QAUTILS.runCmd(addcmd)
    return retMsgDel, retMsgAdd

def stopComponents(all=False,component=None,amqpath='/opt/Activemq'):
    allcmd='stop_proxy.py;;' + amqpath + '/apache-activemq-5.*.*/bin/activemq stop'

    if all is True:
       return QAUTILS.runCmd(allcmd)

    if component is None:
       return 'no component to be stopped'
    
    if component == 'proxy':
       return QAUTILS.runCmd('stop_proxy.py')

    if component == 'notifier':
       return QAUTILS.runCmd('stop_notifier.sh')
  
    if component == 'amq':
       return QAUTILS.runCmd(amqpath + '/apache-activemq-5.*.*/bin/activemq stop')

    return 'not a valid component to be stopped'

def getNtStat():
    return QAUTILS.runCmd(os.getenv('QADIR')+'/Tools/getNotificationStat.py')

def checkProxyLogErrors():
    #QAUTILS.runCmd(os.getenv('QADIR')+'/Tools/get_log_errors.sh -p')
    return QAUTILS.runCmd('grep -ciR \'ERR \| Exception\' $MTX_LOG_DIR/gateway_proxy.log')

def checkAmqLogErrors():
    #return QAUTILS.runCmd(os.getenv('QADIR')+'/Tools/get_log_errors.sh -c')
    return QAUTILS.runCmd('grep -ciR \'ERR \| LM_WARN\' $MTX_LOG_DIR/../mtx_activemq_connector/mtx_debug.log')

def checkNotifierLogErrors():
    #return QAUTILS.runCmd(os.getenv('QADIR')+'/Tools/get_log_errors.sh -n')
    return QAUTILS.runCmd('grep -ciR \'ERR \| Exception\' $MTX_LOG_DIR/mtx_notifier_camel.log')

def checkEngineLogErrors():
    #return QAUTILS.runCmd(os.getenv('QADIR')+'/Tools/get_log_errors.sh -e')
    return QAUTILS.runCmd('grep -c ERR $MTX_LOG_DIR/mtx_debug.log')

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

