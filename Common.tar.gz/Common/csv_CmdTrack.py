#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:35:57
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:35:57
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:35:56
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
from __future__ import print_function
import sys
import csv_track as TRACK

#==========================================================
def CmdTrack_setsubscribermark(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Can't run this command with noChecks
        if lclDCT['noChecks']:
                print('ERROR: can\'t run command ' + lclDCT['ACTION'] + ' with noChecks parameter set')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Subscriber should exist
        if lclDCT['externalId'] not in TRACK.subscriberTracking:
                print('ERROR: subscriber with ID "' + lclDCT['externalId'] + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Check if overwriting a mark
        if lclDCT['mark'] in TRACK.subscriberTracking:
                print('WARNING: overwriting existing subscriber mark "' + lclDCT['mark'] + '"')

        # Update marks
        TRACK.subscriberTracking[lclDCT['mark']] = lclDCT['externalId']
        TRACK.subscriberTracking[lclDCT['externalId']]['mark'].append(lclDCT['mark'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)

#==========================================================
def CmdTrack_setgroupmark(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Can't run this command with noChecks
        if lclDCT['noChecks']:
                print('ERROR: can\'t run command ' + lclDCT['ACTION'] + ' with noChecks parameter set')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Group should exist
        if lclDCT['groupId'] not in TRACK.groupTracking:
                print('ERROR: Group with ID "' + lclDCT['groupId'] + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Check if overwriting a mark
        if lclDCT['mark'] in TRACK.groupTracking:
                print('WARNING: overwriting existing group mark "' + lclDCT['mark'] + '"')

        # Update marks
        TRACK.groupTracking[lclDCT['mark']] = lclDCT['groupId']
        TRACK.groupTracking[lclDCT['groupId']]['mark'].append(lclDCT['mark'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)

#==========================================================
def CmdTrack_setdevicemark(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Can't run this command with noChecks
        if lclDCT['noChecks']:
                print('ERROR: can\'t run command ' + lclDCT['ACTION'] + ' with noChecks parameter set')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Check if overwriting a mark
        if lclDCT['mark'] in TRACK.deviceTracking:
                print('WARNING: overwriting existing device mark "' + lclDCT['mark'] + '"')

        # Update marks
        TRACK.deviceTracking[lclDCT['mark']] = lclDCT['deviceId']
        TRACK.deviceTracking[lclDCT['deviceId']]['mark'].append(lclDCT['mark'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)

#==========================================================
def CmdTrack_showsubscriberdata(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Can't run this command with noChecks
        if lclDCT['noChecks']:
                print('ERROR: can\'t run command ' + lclDCT['ACTION'] + ' with noChecks parameter set')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Subscriber should exist
        if lclDCT['externalId'] not in TRACK.subscriberTracking:
                print('ERROR: subscriber with ID "' + lclDCT['externalId'] + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Put ID into a list
        idList = []
        idList.append(lclDCT['externalId'])
        TRACK.showSubscriberTrackingData(idList, scope = lclDCT['scope'], verbose = lclDCT['verbose'], outputFileName = lclDCT['outputFileName'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)

#==========================================================
def CmdTrack_showgroupdata(lclDCT, options):
        # *** lclDCT[] has all the values.

        # Can't run this command with noChecks
        if lclDCT['noChecks']:
                print('ERROR: can\'t run command ' + lclDCT['ACTION'] + ' with noChecks parameter set')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Group should exist
        if lclDCT['groupId'] not in TRACK.groupTracking:
                print('ERROR: Group with ID "' + lclDCT['groupId'] + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Put ID into a list
        idList = []
        idList.append(lclDCT['groupId'])
        TRACK.showGroupTrackingData(idList, 0,scope = lclDCT['scope'], verbose = lclDCT['verbose'], outputFileName = lclDCT['outputFileName'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)

