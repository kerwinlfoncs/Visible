# Now need to get the IP address of the machine I'm running on, change the last nibble to 224,
# then update the multi-cast address in create_config.info, and finally run create_config.py
cd /opt/mtx/custom
_ipaddr=`/sbin/ip address | grep "10.10" | head -1 |   cut -f3-4 -d. | cut -f1 -d/`
_ipaddr=239.192.${_ipaddr}
echo "Updating create_config.info so the multi-cast address is the IP address 236.(last 3 bytes of server address): $_ipaddr"
sed -i "s/What multi-cast IP address and port do you want to use for the data messages for this cluster?.*:/What multi-cast IP address and port do you want to use for the data messages for this cluster?${_ipaddr}:/" create_config.info

sed -i "s/What multi-cast IP address and port do you want to use for the control messages for this cluster?.*:/What multi-cast IP address and port do you want to use for the control messages for this cluster?${_ipaddr}:/" create_config.info

sed -i "s/What multi-cast IP address and port do you want to use for the cluster management messages for this cluster?.*:/What multi-cast IP address and port do you want to use for the cluster management messages for this cluster?${_ipaddr}:/" create_config.info

# Now run create_config
create_config.py --use_default_values > /dev/null

