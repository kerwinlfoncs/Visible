#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Wed 2021-08-25T00:11:56
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:11
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:34:55
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


import sys,os
import time
from datetime import datetime 
import common_mdc as COMMON

class clErrors(object) :

    def __init__(self,path):
        errorsFilePrefix='ERRORS_' + os.path.split(path)[-1]
        self._errorsFile= path+ '/' + COMMON.resultsDir + '/' + errorsFilePrefix + '.txt'
        if (os.path.isfile(self._errorsFile)):
            os.remove(self._errorsFile)
        self._testStartTime = time.localtime(time.time())

 
    def parse_mtx_logfileErrors(self,currentPath,logPath):
        logFile= logPath + '/mtx_debug.log'
        timeFile = currentPath + '/' + COMMON.resultsDir + '/test_startTime.txt'
        testName = currentPath.split('/')[-1]
        if not (os.path.isfile(timeFile)):
            testStartTime = self._testStartTime
        else :
            f = open(timeFile,'r')
            tTime = f.read().strip('\n')
            testStartTime = time.strptime(tTime,'%Y-%m-%dT%H:%M:%S')
      
        print('logFile ====' + logFile)
        print('testStartTime considered:',testStartTime)
        f=os.popen("grep ERROR " + logFile)
        for i in f.readlines():
            logLine = i.split()
            time1 = logLine[2] + 'T' +str(logLine[3].split('.')[0])
            cTime = time1.strip('\n')
            from datetime import datetime
            dateInLog = time.strptime(cTime,'%Y-%m-%dT%H:%M:%S')
            #get only errors for this test time - if tests running in parallel this might be a misleading log.
            if (testStartTime <= dateInLog):
                print(i)
                self.printError(testName +' - '+i)

    def printError(self,errorVal):
       f = open(self._errorsFile,'a')
       f.write('\n')
       f.write(errorVal)
       f.write('\n')
       f.close()

    def printRes(self,path,fName,val,overwrite = False):
      #use full path for outputFile val is a string
       if (isinstance(val,bytes)):
          val = val.decode('utf-8')  #fix for python3
       if (not os.path.exists(path + '/' + COMMON.resultsDir + '/')):
          sys.exit('no ' + COMMON.resultsDir + ' directory exist in :' + path)
       outputFile= path + '/' + COMMON.resultsDir + '/' + fName 
       if (overwrite):
           f = open(outputFile,'w')
       else:
           f = open(outputFile,'a')

       val = str(val)
       f.write(val)
       f.write('\n')
       f.close()

    def printSummary(self,path,details=None):
       #use full path for outputFile
       if (not os.path.exists(path)):
           sys.exit('path specified to output results does not exist:'+path)
       filePrefix= os.path.split(path)[-1]
       if not os.path.exists(path + '/' + COMMON.resultsDir):  return
       fName = '/' + COMMON.resultsDir + '/Summary_' + filePrefix + '.txt'
       outputFile= path + fName 
       if (details == None) :
           f = open(outputFile,'w')
           f.close()
           return

       f = open(outputFile,'a')
       f.write( details )    
       f.write('\n')
       f.close()



#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

