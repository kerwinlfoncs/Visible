#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:35:49
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:35:48
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:35:48
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
# from builtins import str
# from builtins import str
import sys
import QA_subscriber_management_restv3 as REST_UTIL
import csv_qa as CSVQA
import csv_data as DATA
import csv_prim as PRIM

#==========================================================
def CmdTax_taxqueryproductgrouplist(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.taxQueryProductGroupList(RESTInst, eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdTax_taxqueryproductitemlist(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.taxQueryProductItemList(RESTInst, eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdTax_taxquerycustomertypelist(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.taxQueryCustomerTypeList(RESTInst, eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdTax_taxqueryexemptioncodelist(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.taxQueryExemptionCodeList(RESTInst, eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdTax_taxquerystatus(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.taxQueryStatus(RESTInst, eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdTax_taxquerygeocode(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.taxQueryGeoCode(RESTInst, postalCode=lclDCT['postalCode'], plus4=lclDCT['plus4'], npa=lclDCT['npa'], nxx=lclDCT['nxx'], timeZone=lclDCT['timeZone'], eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
