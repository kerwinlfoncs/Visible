#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:41:00
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:39
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:16
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


# from builtins import str
# from builtins import str
import os,sys
import optparse
import qa_utils as QAUTILS
import subscriber_mgmt_v3 as REST

restInst = None

def main():
    global restInst

    parser = optparse.OptionParser()
    parser.add_option("-s", "--externalid", action='store', type='int', default=0)
    parser.add_option("-o", "--offerid", action='store', type='string', default=0)
    parser.add_option("-t", "--starttime", action='store', type='string', default=None)
    parser.add_option("-e", "--endtime", action='store', type='string', default=None)
    parser.add_option("-i", "--imsi", action='store', type='int', default=0)
    (options, args) = parser.parse_args()
    QAUTILS.gatewaysConfig = QAUTILS.getDiameterRestConfig()
    restInst = QAUTILS.getDatacontainerConnection()

    offerList = [{'ProductOfferId':options.offerid, 'StartTime':options.starttime, 'EndTime':options.endtime}]

    queryType = queryValue = None
    if options.externalid:
       queryType = 'ExternalId'
       queryValue = options.externalid

    if options.imsi:
       queryType = 'PhoneNumber'
       queryValue = options.imsi
       
    responseMdc = restInst.subscriberPurchaseOffer(queryType=queryType, queryValue=queryValue,
        offerList=offerList, now=options.starttime)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        print('Failed with code ' + str(retCode) + ': ' + str(retText))
        return

    print('Subscriber ' + str(queryValue) + ' succesfully purchased offer ' + str(options.offerid))

if __name__ == '__main__':
   main()
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

