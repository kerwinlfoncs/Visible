#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:26
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:08
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:34:53
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


# from builtins import str
# from builtins import str
import data_container_defs as MDCDEFS
import common_functions
import os, sys
import log_errors as LOGGER
import common_mdc as COMMON
import subscriber_mgmt_v3 as REST

global xmlStatus
xmlStatus=True
try:
    import xml_utils
except ImportError:
    xmlStatus=False

global testErrorLogger
path=os.getcwd()
testErrorLogger=LOGGER.clErrors(path)

def querySubscriber(mdcConnection, path, queryValue, testName, queryType='PhoneNumber', queryTime = None,
        debugData = '', diffEvents = False):
    if diffEvents:
        outFileName = 'outQuery_' + str(testName)
    else:
        outFileName = 'outQuery_' + str(queryValue).replace(':', '_') + '_' + str(testName)
    
    trsfOutFileName = 'trsf_' + outFileName

    # Generate XML data and output to file

    # Output subscriber info
    subResult = mdcConnection.subscriberQuery(queryType=queryType, queryValue=str(queryValue), now=queryTime)
    if hasattr(subResult, "printXml"):
        subscriberMdc = subResult.printXml()
    else:
        print('Subscriber query failed!!')
        print(subResult)
        sys.exit()

    if not REST.checkResultSuccess(subResult):
        print('Subscriber query on ' + queryType + ' with value ' + str(queryValue) + ' failed!')
        print(subResult.printXml())
        sys.exit()

    testErrorLogger.printRes(path, outFileName, subscriberMdc, overwrite=True)

    # Output offer info for validate_balances
    COMMON.outputOfferInfo(path, testName, queryType, queryValue, 'Subscriber', subscriberMdc, debugData, queryTime)

    # Get device array from subscriber response
    deviceArray = COMMON.getDeviceArray(subscriberMdc)

    # Output wallet
    walletResult = mdcConnection.subscriberQueryWallet(queryType=queryType, queryValue=str(queryValue), now=queryTime)
    if not REST.checkResultSuccess(walletResult):
        print('Subscriber wallet query on ' + queryType + ' with value ' + str(queryValue) + ' failed!')
        sys.exit()

    if hasattr(walletResult, "printXml"):
        walletMdc = walletResult.printXml()
    else:
        print('Subscriber wallet query failed!!')
        print(walletResult)
        sys.exit()
    testErrorLogger.printRes(path, outFileName, walletMdc, overwrite=False)

    # Output balance info for validate_balances
    COMMON.outputBalanceInfo(path, testName, queryType, queryValue, 'Subscriber', walletMdc, debugData)

    # Output devices
    if deviceArray:
        for device in deviceArray:
            deviceResult = mdcConnection.deviceQuery(queryType='ObjectId', queryValue=device, now=queryTime)
            if not REST.checkResultSuccess(deviceResult):
                print('Device query on ObjectId with value ' + str(device) + ' failed!')
                sys.exit()

            deviceMdc = deviceResult.printXml()
            testErrorLogger.printRes(path, outFileName, deviceMdc, overwrite=False)

    # Add output file to the file list
    testErrorLogger.printRes(path, 'allMdcFilesList', path + '/' + COMMON.resultsDir + '/' + trsfOutFileName)

    # Get data from file, add root container, output to same file
    outFileName = path + '/' + COMMON.resultsDir + '/' + outFileName
    xmlOutput = open(outFileName, 'r')
    lines = xmlOutput.readlines()
    xmlOutput.close()
    lines.append("</root>\n")
    lines.reverse()
    lines.append("<root>\n")
    lines.reverse()
    processedData = "".join([x for x in lines if x.strip() != ''])
    xmlOutput = open(outFileName, 'w')
    xmlOutput.write(processedData)
    xmlOutput.close()
    if xmlStatus:
        mdcTransformed = xml_utils.transformDoc(outFileName)
        #print mdcTransformed
        testErrorLogger.printRes(path, trsfOutFileName, str(mdcTransformed), overwrite = True)

    return outFileName

def queryUser(mdcConnection, path, queryValue, testName, queryType='ExternalId', queryTime = None, debugData=''):
    outFileName = 'outQuery_' + str(queryValue).replace(':', '_') + '_' + str(testName)
    trsfOutFileName = 'trsf_' + outFileName

    # Generate XML data and output to file

    # Output User info
    userResult = mdcConnection.userQuery(queryType=queryType, queryValue=str(queryValue), now=queryTime)
    if hasattr(userResult, "printXml"):
        userMdc = userResult.printXml()
    else:
        print('User query failed!!')
        print(userResult)
        sys.exit()

    if not REST.checkResultSuccess(userResult):
        print('User query on ' + queryType + ' with value ' + str(queryValue) + ' failed!')
        print(userResult.printXml())
        sys.exit()

    testErrorLogger.printRes(path, outFileName, userMdc, overwrite=True)

    # Output offer info for validate_balances
    COMMON.outputOfferInfo(path, testName, queryType, queryValue, 'User', userMdc, debugData, queryTime)

    # Add output file to the file list
    testErrorLogger.printRes(path, 'allMdcFilesList', path + '/results/' + trsfOutFileName)

    # Get data from file, add root container, output to same file
    outFileName = path + '/results/' + outFileName
    xmlOutput = open(outFileName, 'r')
    lines = xmlOutput.readlines()
    xmlOutput.close()
    lines.append("</root>\n")
    lines.reverse()
    lines.append("<root>\n")
    lines.reverse()
    processedData = "".join([x for x in lines if x.strip() != ''])
    xmlOutput = open(outFileName, 'w')
    xmlOutput.write(processedData)
    xmlOutput.close()
    if xmlStatus:
        mdcTransformed = xml_utils.transformDoc(outFileName)
        #print mdcTransformed
        testErrorLogger.printRes(path, trsfOutFileName, str(mdcTransformed), overwrite = True)

    return outFileName

def queryDevice(mdcConnection, path, queryValue, testName, queryType='PhoneNumber', queryTime = None, debugData=''):
    outFileName = 'outQuery_' + str(queryValue).replace(':', '_') + '_' + str(testName)
    trsfOutFileName = 'trsf_' + outFileName

    # Generate XML data and output to file

    # Output device info
    devResult = mdcConnection.deviceQuery(queryType=queryType, queryValue=str(queryValue), now=queryTime)
    if hasattr(devResult, "printXml"):
        devMdc = devResult.printXml()
    else:
        print('Device query failed!!')
        print(devResult)
        sys.exit()

    if not REST.checkResultSuccess(devResult):
        print('Device query on ' + queryType + ' with value ' + str(queryValue) + ' failed!')
        print(devResult.printXml())
        sys.exit()

    testErrorLogger.printRes(path, outFileName, devMdc, overwrite=True)

    # Output offer info for validate_balances
    COMMON.outputOfferInfo(path, testName, queryType, queryValue, 'Device', devMdc, debugData, queryTime)

    # Add output file to the file list
    testErrorLogger.printRes(path, 'allMdcFilesList', path + '/' + COMMON.resultsDir + '/' + trsfOutFileName)

    # Get data from file, add root container, output to same file
    outFileName = path + '/' + COMMON.resultsDir + '/' + outFileName
    xmlOutput = open(outFileName, 'r')
    lines = xmlOutput.readlines()
    xmlOutput.close()
    lines.append("</root>\n")
    lines.reverse()
    lines.append("<root>\n")
    lines.reverse()
    processedData = "".join([x for x in lines if x.strip() != ''])
    xmlOutput = open(outFileName, 'w')
    xmlOutput.write(processedData)
    xmlOutput.close()
    if xmlStatus:
        mdcTransformed = xml_utils.transformDoc(outFileName)
        #print mdcTransformed
        testErrorLogger.printRes(path, trsfOutFileName, str(mdcTransformed), overwrite = True)

    return outFileName

def main():
    main()

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

