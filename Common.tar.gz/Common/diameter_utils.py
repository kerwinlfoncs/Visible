
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:58
#
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:37
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:15

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

# from builtins import hex
# from builtins import str
# from builtins import range
# from builtins import hex
# from builtins import str
# from builtins import range
from past.utils import old_div
import os, sys, pprint, copy
import qa_utils as QAUTILS
import log_errors as LOGGER
import re
import diameter as DIAM
import commonDefs as cd
import diameter_utils_base as PKTBASE
import create_diameter_pkt_base
import timeToMDCtime as MDCTIME
import common_mdc as COMMON

try:
   import custSpecific as CUST
except ImportError:
   os.system(' echo > custSpecific.py ')
   import custSpecific as CUST

MsccFlag = False

logger = LOGGER.clErrors('./')

# Define strings that have lists embedded in lists.
# First value is the outer list, second value is the inner list.
embeddedLists = []
embeddedLists.append(('Multiple-Services-Credit-Control', 'Service-Specific-Info'))

# Performance debug flag
diameterFileDebugFlag = True

#======================================================
# Encoding as per 3GPP 24-229 version f-10, section 7.2A.4
def encodeAccessNetwork(lclDCT):
        # Default return string
        accessNetwork = ''
        
        # Check access type
        if lclDCT['accessType'] == '3GPP-E-UTRAN-FDD':
                # Build access network string
                accessNetwork += lclDCT['accessType']
                accessNetwork += ';utran-cell-id-3gpp='
                
                # Add MccMnc
                accessNetwork += lclDCT['TgppSgsnMccMnc']
                
                # Add padding if less than 6 characters
                if len(lclDCT['TgppSgsnMccMnc']) == 5: accessNetwork += '0'
                
                # Add area code + cellId
                accessNetwork += lclDCT['areaCode'] + lclDCT['cellId']
                
                # Convert string to hex
                print('accessNetwork before: ' + accessNetwork)
#               accessNetwork = DIAM.convertStringToHexStr(accessNetwork)
                
        else:
                print('WARNING: Unsupported access type entered: ' + lclDCT['accessType'])
        
        return accessNetwork
        
#======================================================
# Encoding as per 3GPP TS 29.060, section 7.7.51
def encode3GPPUserLocationInfo(encodeType='00', mcc=0, mnc=0, xtra1='1234', xtra2='5678'):
        #print 'On input encodeType = ' + encodeType + ', mcc/mnc = ' + mcc + '/' + mnc + ', uli extra = ' + xtra1 + '/' + xtra2
        
        # Separate out MCC and MNC into digits
        mccHundred = mcc[0]
        mccTen     = mcc[1]
        mccOne     = mcc[2]
        
        # Some tests only pass through the MCC.  If nothing here, then set to 0 (as the test doesn't care)
        try:
                mncHundred = mnc[0]
                mncTen     = mnc[1]
        except:
                mncHundred = mncTen = '0'
        
        # May only have two digits for the MNC
        try:
                mncOne     = mnc[2]
        except:
                mncOne     = 'f'

        # lnitialize the ULI string
        uliString = encodeType
        
        # Add in extra fields.  Not all encodeType values use both extra bytes.
        # A bit messy here.  Input is expected to be the integer desired, but input as a string (so translation works).
        # Convert to int, then to hex, put into a string, remove leading '0x' and ensure it's the proper characters in length.
        if encodeType in ['00', '01', '02']:
                # Add MCC/MNC + additional two fields (LAC/CI, LAC/SAC, LAC/RAC)
                uliString += mccTen + mccHundred + mncOne + mccOne + mncTen + mncHundred
                uliString += str(hex(int(xtra1)))[2:].rjust(4, '0')
                uliString += str(hex(int(xtra2)))[2:].rjust(4, '0')
        
        # TAI or TAI and ECGI
        if encodeType in ['80', '82']:
                # Add MCC/MNC + additional field (TAC)
                uliString += mccTen + mccHundred + mncOne + mccOne + mncTen + mncHundred
                uliString += str(hex(int(xtra1)))[2:].rjust(4, '0')
                
        # ECGI or TAI and ECGI
        if encodeType in ['81', '82']:
                # Add MCC/MNC + additional field (ECI).  Note different length for second extra entry.
                uliString += mccTen + mccHundred + mncOne + mccOne + mncTen + mncHundred
                uliString += str(hex(int(xtra2)))[2:].rjust(8, '0')
                
        #print 'Encoded ULI: "' + uliString + '"'
        return uliString
        
#======================================================
#check if we have custom AVPs to add or Omit
def checkAdditionalAvps(extraAVP):
    omitList = []
    addList = []
    
    # Process customer specific common directory and test framework common directory
    path1 = os.path.expandvars(os.getenv('QADIR', '.'))+'/Common'
    path2 = os.path.expandvars(os.getenv('QADIR', '.'))+'/'+os.getenv('customer', '.')+'/Common'
    for dir in path1, path2:
     if os.path.isfile(dir+'/skipthisDir.txt'): continue
     addition = dir + '/addAVPs.txt'
     omit     = dir + '/omitAVPs.txt'
     
     ####### Process add file
     #print 'Processing file: ' + addition
     if os.path.isfile(addition):
        fp = open(addition, 'r')
        for AVP in fp:
            if AVP.startswith('#'): continue
            x  = AVP.rstrip('\n')
            if x.startswith('@'):  #we need to calculate the value of this AVP
                arr1 = x.split('@')
                arr = arr1[1].split(':')
                avpCalculated = eval(arr[1])
                x = arr[0] + ':' + str(avpCalculated)
            addList.append(x)

     if addList != [] :
        if 'add' in extraAVP:
            extraAVP['add'].extend(addList)
        else:
            extraAVP['add'] = addList

     ####### Process omit file
     #print 'Processing file: ' + omit
     if os.path.isfile(omit):
        fp = open(omit, 'r')
        for AVP in fp:
            if AVP.startswith('#'): continue
            x = AVP.rstrip('\n')
            omitList.append(x)

     if omitList != [] :
        if 'omit' in extraAVP:
            extraAVP['omit'].extend(omitList)
        else:
            extraAVP['omit'] = omitList

    # Return resulting extraAVP list
    return extraAVP

#======================================================
#this adds an MSCC AVP to the AVP in the list mssSpecificList. this will allow test to work with or without mscc
def adjustList(inList, msccAvp):
    if inList == None or inList == []:
        return
    #print inList
    newList = []
    msccSpecificList=['Used-Service-Unit', 'Requested-Service-Unit']
    if not msccAvp:
        return inList
    #print "mscc=", msccAvp
    if msccAvp:
        for x in inList:
            #print "incoming value:", x
            for avp in msccSpecificList:
                #print 'avp:', avp, ' and x is:', x
                if x.startswith(avp):
                    x = 'Multiple-Services-Credit-Control|' + x
                    newList.append(x)
                    break
    deltaList = [x for x in inList if x not in msccSpecificList]
    return(newList + deltaList)

#======================================================
def getQuantitySelector(serviceId, mscc = False):
    if mscc:    return getServiceId(serviceId, field = 'serviceContextQSMsccDct')
    else:       return getServiceId(serviceId, field = 'serviceContextQSDct')

#======================================================
def getServiceId(serviceId, field = 'serviceIdDct'):
#    print "getting " + str(field) + " for service " + str(serviceId)
    if serviceId in cd.serviceIdDefs and field in cd.serviceIdDefs[serviceId] and cd.serviceIdDefs[serviceId][field]:
        return(cd.serviceIdDefs[serviceId][field])
    else:
        sys.exit("no non-None value is defined in cd.serviceIdDefs['" + str(serviceId) + "']['" + field + "']")

#======================================================
def getServiceIdContext(serviceId, field = 'serviceIdContextDct'):
        return getServiceId(serviceId, field)

#======================================================
def getRequestType(requestType):
    reqDct = cd.reqTypeDct
    if requestType in reqDct: return reqDct[requestType]
    else: sys.exit('no requestType is available for ' + str(requestType) + '..exiting....')

#======================================================
#this function sets the used or requested units.  the default is the amount passed in
#as use or request from sendOneRequest.  you can override any of them by setting it in 
#extraAVP dictionary
def getAvpRequestedOrUsedServiceUnit(diamPacketDct, quantitySelector, amountIn,  AVP, mscc, exponent=None, currencyCode=None):
    # If the amount in is negative (flag value), then exit
#    print 'quantitySelector = ' + quantitySelector + ', amountIn = ' + str(amountIn)
    if int(amountIn) == -1: return diamPacketDct
    
    if mscc != None:
        mscc = mscc + '|'
    else:
        mscc=""
    if exponent is not None:
         diamPacketDct[str(mscc) + str(AVP) +'|CC-Money|Unit-Value|Exponent'] = exponent 
         diamPacketDct[str(mscc) + str(AVP) +'|CC-Money|Unit-Value|Value-Digits'] = amountIn
         if currencyCode: diamPacketDct[str(mscc) + str(AVP) +'|CC-Money|Currency-Code'] = currencyCode
         #print 'Setting currency data: exponent = ' + str(exponent) + ', amountIn = ' + str(amountIn)
    elif quantitySelector == 'serviceSpecific':
        diamPacketDct[str(mscc) + str(AVP) + '|CC-Service-Specific-Units'] = amountIn

    elif quantitySelector == 'totalData':
        diamPacketDct[str(mscc) + str(AVP) + '|CC-Total-Octets'] = amountIn

    elif quantitySelector == 'inData':
        diamPacketDct[str(mscc) + str(AVP) + '|CC-Input-Octets'] = amountIn

    elif quantitySelector == 'outData':
        diamPacketDct[str(mscc) + str(AVP) + '|CC-Output-Octets'] = amountIn
    
    elif quantitySelector == 'monetary' and exponent is not None:
         diamPacketDct[str(mscc) + str(AVP) +'|CC-Money|Unit-Value|Exponent'] = exponent 
         diamPacketDct[str(mscc) + str(AVP) +'|CC-Money|Unit-Value|Value-Digits'] = amountIn
    else:
###        print str(mscc) + str(AVP) + '|CC-Time'
        diamPacketDct[str(mscc) + str(AVP) + '|CC-Time'] = amountIn

    return diamPacketDct

#======================================================
#this function is called by create_diameter_packets to diff the 
#diam packet sent and the response packet
def checkDiamPkts(path, diamSent, diamRcvd, reqType, stripList=None):
    global logger 
    logger = LOGGER.clErrors(path)
    retCode = 0
    diamSentFiltered = None
    diamRcvdFiltered = None
    dctSent = None
    dctRcvd = None
    testName = path.split('/')[-1]
    #diamSedSent = runCmd('sed -f ' + path + '/../Common/diameter.sed ' + path + '/' + COMMON.resultsDir + '/' + diamSentFile)
    (dctSent, diamSentFiltered) = getDiameterDct(path, str(diamSent), stripList)
    (dctRcvd, diamRcvdFiltered) = getDiameterDct(path, str(diamRcvd), stripList)
    printDiamPkts(path, diamSentFiltered, diamRcvdFiltered, testName, reqType)
    
    retCode = diffDiamDct(path, dctSent, dctRcvd, reqType, testName)
    n1 = ''
    n2 = ''
    n3 = ''
    n4 = ''

    if retCode > 0 and diameterFileDebugFlag:
        if 'User-Name(1)' in dctSent:       n1 = str(dctSent['User-Name(1)'])
        if 'Session-Id(263)' in dctSent:    n2 = dctSent['Session-Id(263)']
        if 'Error-Message(281)' in dctRcvd: n3 = dctRcvd['Error-Message(281)']
        if 'Result-Code(268)' in dctRcvd:   n4 = str(dctRcvd['Result-Code(268)'])

        msg = testName + ' Failure: ' + 'DeviceId:'+ n1 + ', SessionId:' + n2 + '==>>Error-Message:' +  n3 + ', ResultCode:' + n4 + '\n'
        logger.printRes(path,'Summary_diameter_' + testName + '.txt',msg)
        return dctRcvd
#    print '==***********************************************'
#======================================================
#compare 2 diam pkts in the form of dictionaries
def diffDiamDct(path, dctSent, dctRcvd, reqType, testName):
    global logger 
    logger = LOGGER.clErrors(path)
    retCode = 0
    msg = ''
    outputFile =  'debug_diameter_' + testName + '.txt'

    for key in dctRcvd:
        if re.search('Result-Code', key):
            if not re.search('2001', dctRcvd[key]):
                if reqType:  #if the test is not expected to fail
                    retCode = retCode + 1 
                    msg = msg + '\nDIAMETER-VALIDATE: Result-Code=' + str(dctRcvd[key])

        elif re.search('Error-Message', key):
            if not re.search('OK', dctRcvd[key]):
                if reqType:  #if the test is not expected to fail
                    retCode = retCode + 1 
                    msg = msg + '\nDIAMETER-VALIDATE: Error-Message=' + str(dctRcvd[key])

        #if the diam pkt is missing a field
        elif key not in dctSent:
            retCode = retCode + 1 
            msg = msg + '\nDIAMETER-VALIDATE: missing key:'+ key + '=>' + dctRcvd[key]

        elif not dctSent[key] == dctRcvd[key]:
            retCode = retCode + 1 
            msg = msg + '\nDIAMETER-VALIDATE: rcvd= '+ key + '<>' + dctRcvd[key] + ' expected=' + dctSent[key]
    if retCode > 0 and diameterFileDebugFlag:
        logger.printRes(path, outputFile, msg)
        logger.printRes(path, outputFile, 'SENT:' + str(dctSent))
        logger.printRes(path, outputFile, '\n---eventPass=' + str(reqType) + '\n')
        logger.printRes(path, outputFile, 'RECEIVED:' + str(dctRcvd))
        logger.printRes(path, outputFile, '\n******* RET_CODE:' + str(retCode))
        logger.printRes(path, outputFile, '===============================\n')

    return(retCode)
#======================================================
#print diam pkts in the form of dictionaries
def printDiamPkts(path, dctSent, dctRcvd, testName, reqType):
    # Skip if performance enabled
    if not diameterFileDebugFlag: return
    
    filePrefix = 'ECT_diameter_'
    if MsccFlag:
        outputFile = filePrefix + testName + '_mscc.txt'
    else:
        outputFile = filePrefix + testName + '.txt'


    # add this file to the list of files to validate. check if already there from prev diam req
    allResultFilesList =  path + '/' + COMMON.resultsDir + '/allMdcFilesList'
    cmd = 'grep ECT_diameter ' + allResultFilesList
    grepRes = QAUTILS.runCmd(cmd+' >/dev/null 2>&1')
#    print grepRes
    logger.printRes(path, 'somelog', 'a' + str(grepRes))
    #sys.exit(1)
    #return
    if grepRes == '':
        #QAUTILS.runCmd('rm ' + path + '/' + COMMON.resultsDir + '/ECT_diameter*')
        fp = open(allResultFilesList,'a')
        fp.write(path + '/' + COMMON.resultsDir + '/' + outputFile + '\n')
        fp.close()

    msg = 'expected eventPass =' + str(reqType) + '\n'
    msg=msg + 'SENT********* '
    logger.printRes(path, outputFile, msg)
    logger.printRes(path, outputFile, dctSent)
    
    msg='RCVD********* '
    logger.printRes(path, outputFile, msg)
    logger.printRes(path, outputFile, dctRcvd)
    logger.printRes(path, outputFile, '================= DONE ======================\n')


#======================================================
#goes through all the lines in a diameter packet and removes fields that change dynamically 
#remove the field "len" for excluded AVPs also.
def getDiameterDct(path, diamObj, eventPass = False, stripList=None):
    global MsccFlag
    strippedDiamPacket = ''
    tmpDct = {}
    diamArr = diamObj.split('\n')
    for line in diamArr: #diamp.readlines():
        #skip the time field in the pkt
        line = re.sub('len=\d+,', '', line)
        if re.search('Multiple-Services-Credit-Control', line):
            MsccFlag = True
            QAUTILS.msccFlag = True
        if re.search('Subscription-Id-Data\(444\)', line):
            line = re.sub('value=.*', '', line)
            line = re.sub('len=\d+,', '', line)
        if re.search('Event-Timestamp', line):
            line = re.sub('value=.*', '', line)
        if re.search('Start-Time', line):
            line = re.sub('value=.*', '', line)
            line = re.sub('len=\d+,', '', line)
        if re.search('User-Name', line):
            line = re.sub('value=.*', '', line)
            line = re.sub('len=\d+,', '', line)
        if re.search('Session-Id', line):
            line = re.sub('value=.*', '', line)
            line = re.sub('len=\d+,', '', line)
        if re.search('Error-Message', line):
            line = re.split(":", line)[1] #+ '_checkERROR!!'
        if stripList:
            for stripItem in stripList:
                if re.search(stripItem, line):
                    line = re.sub('value=.*', '', line)

        strippedDiamPacket = strippedDiamPacket + line + '\n'
        #skip any line that does not have a field named value
        #if not re.search('value', line):
        #    continue
        if re.search('AVP',line):
           line = line.strip('\n')
           line = re.sub('.*AVP: ', '', line)
           tmp = line.split(',')
           tmpDct[tmp[0]] = tmp[-1]
    return (tmpDct, strippedDiamPacket)

def getRawDiameterDct(path, diamObj):
    global MsccFlag
    grouped = {}
    listField1 = []
    msccCounter = 0
    PolicyCounterStatusReportCounter = 0
    pcidCounter = 0
    subIdCounter = 0
    eventTriggerCounter = 0
    specificActionCounter = 0
    currentField = '' 
    diameterDct = {}
    firstField = 0
    lastField = 0
    ruleRemoveCounter = 0
    ruleAddCounter = 0
    diamArr = diamObj.split('\n')

    #print 'Received diameter array: ' + str(diamArr)
    for line in diamArr:
        # Skip until we get to the header line
        if not re.search('Diameter Hdr', line): continue

        # Break this line into fields
        hdrLine = line.split(',')

        # Process each field
        for fields in hdrLine:
                # If the field contains the Diameter word, then need to skinny it down
                if re.search('Diameter Hdr', fields): fields = fields.split(':')[1].strip()

                # Get the command and value (separated by an '=' character)
                command = fields.split('=')[0].strip()
                value = fields.split('=')[1].strip()

                # Add to the dictionary to be returned
                diameterDct[command] = value

        # Done processing the header line
        break

    for line in diamArr:
        if re.search('Diameter Hdr', line): continue
        tmpLine = line.replace(' ','X')
        field1 = tmpLine.split(':')[0]
        listField1.append(field1)

    lineNumber = 0

    # Debug output
#    print 'listField1 = ' + str(listField1)
    
    #print 'Received RAW Diameter array: ' + str(diamArr)
    
    for line in diamArr:
        if re.search('Diameter Hdr', line): continue  #skip first line
#       print 'line: ' + line
        currentField = listField1[lineNumber]
        lineNumber += 1
        
        line = line.strip('\n')
        line = line.strip(',')
        line = re.sub('.*AVP: ', '', line)
        tmp = line.split(',')
        currentFieldLen = len(currentField)

        #duplicated AVP of Event-Trigger for gx
        if tmp[0] == 'Event-Trigger(1006)':  
            tmp[0] = 'Event-Trigger' + str(eventTriggerCounter)
            eventTriggerCounter += 1

        #duplicated AVP of Specific-Action for Rx
        if tmp[0] == 'Specific-Action(513)':
            tmp[0] = 'Specific-Action' + str(specificActionCounter)
            specificActionCounter += 1

        if re.search('Grouped', line):  #if this AVP is Grouped
            if firstField == 0:
                firstField = currentFieldLen
            elif currentFieldLen == firstField:
#               print 'Leaving subgroup'
                grouped={} #we are no longer part of this subgroup

            else:
                lastField = currentFieldLen

            # Remap and count fields that could be duplicates
            if tmp[0] == 'Multiple-Services-Credit-Control(456)':  #change this to a shorter name
                tmp[0] = 'Mscc' + str(msccCounter) #keep track of how many MSCC pkts we get
                msccCounter += 1
            elif tmp[0] == 'Policy-Counter-Status-Report(2903)':  #change this to a shorter name
                tmp[0] = 'Pcsr' + str(PolicyCounterStatusReportCounter) #keep track of how many MSCC pkts we get
                PolicyCounterStatusReportCounter += 1
            elif tmp[0].startswith('Policy-Counter-Identifier'):  #change this to a shorter name
                tmp[0] = 'Pcid' + str(pcidCounter) #keep track of how many MSCC pkts we get
                pcidCounter += 1
            elif tmp[0].startswith('Subscription-Id'):  #change this to a shorter name
                tmp[0] = 'Subscription-Id' + str(subIdCounter) #keep track of how many MSCC pkts we get
                subIdCounter += 1
            elif tmp[0].startswith('Charging-Rule-Remove(1002)'):  #change this to a shorter name
                tmp[0] = 'Charging-Rule-Remove' + str(ruleRemoveCounter) #keep track of how many MSCC pkts we get
                ruleRemoveCounter += 1
            elif tmp[0].startswith('Charging-Rule-Install(1001)'):  #change this to a shorter name
                tmp[0] = 'Charging-Rule-Install' + str(ruleAddCounter) #keep track of how many MSCC pkts we get
                ruleAddCounter += 1

            tmp[0] = re.sub('\(\d+\)','', tmp[0])
            grouped[currentFieldLen] = tmp[0]  #create a dct with current group levels
#           print 'Created currentFieldLen ' + str(currentFieldLen) + ': ' + str(grouped[currentFieldLen])
            continue

        avpString = ''
        levelOfCurrentAvp = len(currentField)
        if levelOfCurrentAvp <= firstField:  #done with this subgroup
#           print 'Done with sub group from l2 check'
            grouped = {}
            firstField = 0
            lastField = 0

        elif levelOfCurrentAvp <= lastField:   #some subgroups are done, remove them
            for avpLevel in list(grouped.keys()):
                if levelOfCurrentAvp <= avpLevel:
                    del grouped[avpLevel]
                else:
                    avpString = grouped[avpLevel] + '->' + avpString
#                   print 'Changed avpString in first elif: ' + avpString
            allKeys = sorted(grouped.keys())
            lastField = allKeys[-1]

        elif levelOfCurrentAvp > lastField:   #build the AVP from its location going up
            for avpLevel in reversed(sorted(grouped.keys())):
#               print 'Checking avpLevel ' + str(avpLevel)
                if levelOfCurrentAvp > avpLevel:
                    avpString = grouped[avpLevel] + '->' + avpString
#                   print 'Changed avpString in second elif: ' + avpString

        tmp[0] = re.sub('\(\d+\)','', tmp[0]) #remove AVP codes (258) for elevelOfCurrentAvp
        tmp[0] = avpString + tmp[0]

        diameterDct[tmp[0]] = re.sub('value=', '', tmp[-1].strip())
#       print 'saving dictionary entry ' + tmp[0] + ' = ' + str(diameterDct[tmp[0]])

    #for val in tmpDct:
    #.   print val + '=>' +  tmpDct[val]
    return (diameterDct)

def msccStoreUnits(msccList, direction, amount, serviceId, baseString, msccBaseString, reportingReason=None, currencyFlag=False, exponent=0, currencyCode=None):
    # Get quantity selector (used in a slightly hacky way...)
    quantitySelector = getQuantitySelector(serviceId, mscc = True)
    
    # Loop through each of the entries
    for count in range(len(amount)):
        actualString = baseString + '$' + str(count)
        #actualString = baseString + '$5'
        
        # Get the values
        item = amount[count]
        itemAmount = str(item[0])
        itemTariff = item[1]
        
        # Skip if the amount is zero or not defined.
#       print 'msccStoreUnits: itemAmount = ' + itemAmount
        if (not itemAmount) or int(itemAmount) == 0: continue
        
        # Add in the data
        if currencyFlag:
                # Want this in CC-Money
                msccList.append(msccBaseString + '|' + actualString + '|' + 'CC-Money|Unit-Value|Value-Digits:' + itemAmount)
                msccList.append(msccBaseString + '|' + actualString + '|' + 'CC-Money|Unit-Value|Exponent:' + str(exponent))
                
                # Store currency code if defined
                if currencyCode: msccList.append(msccBaseString + '|' + actualString + '|' + 'CC-Money|Currency-Code:'+str(currencyCode))
        elif 'Data' in quantitySelector:
            # Check where we should put these
            if (direction):
                # May put in input, Output, or total octets
                if (direction.lower() == 'in'):
                    msccList.append(msccBaseString + '|' + actualString + '|' + 'CC-Input-Octets:' + itemAmount)
                elif (direction.lower() == 'out'):
                    msccList.append(msccBaseString + '|' + actualString + '|' + 'CC-Output-Octets:' + itemAmount)
                elif (direction.lower() == 'in_out'):
                    msccList.append(msccBaseString + '|' + actualString + '|' + 'CC-Input-Octets:' + str(old_div(int(itemAmount), 2)))
                    msccList.append(msccBaseString + '|' + actualString + '|' + 'CC-Output-Octets:' + str(int(itemAmount) - (old_div(int(itemAmount), 2))))
                    msccList.append(msccBaseString + '|' + actualString + '|' + 'CC-Total-Octets:' + itemAmount)
                else:
                    msccList.append(msccBaseString + '|' + actualString + '|' + 'CC-Total-Octets:' + itemAmount)
            else:
                msccList.append(msccBaseString + '|' + actualString + '|' + 'CC-Total-Octets:' + itemAmount)
        elif 'Duration' in quantitySelector:
            msccList.append(msccBaseString + '|' + actualString + '|' + 'CC-Time:' + itemAmount)
        else:
            msccList.append(msccBaseString + '|' + actualString + '|' + 'CC-Service-Specific-Units:' + itemAmount)

        # Add tariff change AVP if it was entered
        if itemTariff is not None:
            print('Tariff-Change-Usage = ' + str(itemTariff))
            msccList.append(msccBaseString + '|' + actualString + '|' + 'Tariff-Change-Usage:' + str(itemTariff))
        
        # add reporting reason if input
        if reportingReason: msccList.append(msccBaseString + '|' + actualString + '|' + 'Reporting-Reason:' + str(reportingReason))

    # Return mscc list
    return msccList

def getMsccGroupedAvp(extraAVP, requestType='initial', reqAmount=0, usedAmount=0, serviceId='data', usedDirection='total', requestDirection='total', ratingGroup=None, ReportingReason=None, incServiceId=True, msccCount=0, currencyFlag={'req':False, 'used':False}, exponent={'req':0, 'used':0}, currencyCode=None, triggerType=None, msccServiceId=None, refundInformation = None, usedUnitRatType=None):
#, reqCount=0, usedCount=0):
                 
    # Old code used integers for the direction value.  Change them here.
    usedDirection = str(usedDirection)
    requestDirection = str(requestDirection)
    #if not usedDirection.isdigit():    usedDirection = 'total'
    #if not requestDirection.isdigit(): requestDirection = 'total'

    # Initialize MSCC structures
    msccList = []
    
    # Strings to make life easier.  Support multiple context in a single message
    msccBaseString = 'Multiple-Services-Credit-Control'
    if msccCount: msccBaseString += '$' + str(msccCount)
    
    # If requested or used amunts are not a list, then change to a list
    if type(reqAmount) != type(list()): 
        # Convert to a list
        regSave = reqAmount
        reqAmount = []
        reqAmount.append([str(regSave), None])
    
    if type(usedAmount) != type(list()): 
        # Convert to a list
        usedSave = usedAmount
        usedAmount = []
        usedAmount.append([str(usedSave), None])
    
#    print 'requested amount = ' + str(reqAmount)
#    print 'used amount = ' + str(usedAmount)
#    print 'requestType = ' + requestType
    
    # Add requested units if not term or if flag set to always include
    if requestType not in ['term'] or int(reqAmount[0][0]) == '-1':
        # If amount is -1, then set to 0.  This is a setting to signal to include an empty RSU in the MSCC 
        if reqAmount[0][0] == '-1': reqAmount[0][0] = '0'
        
        #print 'Storing RSU'
        msccList = msccStoreUnits(msccList, requestDirection, reqAmount, serviceId, 'Requested-Service-Unit', msccBaseString, currencyFlag=currencyFlag['req'], exponent=exponent['req'], currencyCode=currencyCode)

    # Add used units if not initial or if flag set to always include
    if requestType not in ['initial'] or int(usedAmount[0][0]) == '-1':
        # If amount is -1, then set to 0.  This is a setting to signal to include an empty USU in the MSCC 
        if int(usedAmount[0][0]) == '-1': usedAmount[0][0] = '0'
        
        #print 'Storing USU'
        msccList = msccStoreUnits(msccList, usedDirection, usedAmount, serviceId, 'Used-Service-Unit', msccBaseString, reportingReason=ReportingReason, currencyFlag=currencyFlag['used'], exponent=exponent['used'], currencyCode=currencyCode)
        
    # Add RAT type if present
    if usedUnitRatType and str(usedUnitRatType) != '0':
        # Want this to be an even number of digits
        usedUnitRatType = str(usedUnitRatType)
        if len(usedUnitRatType) % 2: usedUnitRatType = '0' + usedUnitRatType
        msccList.append(msccBaseString + '|' + '3GPP-RAT-Type:' + usedUnitRatType)
    
    # Add a rating group if one entered
    if (ratingGroup):
#           print 'Rating-Group = ' + str(ratingGroup)
            msccList.append(msccBaseString + '|' + 'Rating-Group:' + str(ratingGroup))

    # Add reporting reason if it was entered
    if (ReportingReason):
#           print 'Reporting-Reason = ' + str(ReportingReason)
            msccList.append(msccBaseString + '|' + 'Reporting-Reason:' + ReportingReason)

    # Add refund information if it was entered
    if (refundInformation):
#           print 'Refund-Information = ' + str(refundInformation)
            msccList.append(msccBaseString + '|' + 'Refund-Information:' + refundInformation)

    # Set service ID value for internal MSCC structure if we're supposed to include this
    if incServiceId:
        # May want to pass in a real service ID, so allow that through unchanged
        if msccServiceId: _id = int(msccServiceId)
        elif serviceId in cd.serviceIdDefs: _id = getServiceId(serviceId)
        else: _id = 100
    
        # Add service ID
        msccList.append(msccBaseString + '|' + 'Service-Identifier:' + str(_id))
    
    # See if triggerType defined
    if triggerType:
        for i in range(len(triggerType)):
                msccList.append(msccBaseString + '|' + 'Trigger|Trigger-Type$' + str(i) + ':' + str(triggerType[i]))
    
    # Always want to remove default MSCC structure
    if not 'omit' in extraAVP:  extraAVP['omit'] = []
    extraAVP['omit'].append(msccBaseString)
    
    # If we did anything, then add to extra list
    if len(msccList):
        if not 'add' in extraAVP:  extraAVP['add'] = []
        extraAVP['add'].extend(msccList)

    # Return updated extraAVP
    return extraAVP
      
# Function to send out a pre-packaged diameter message
def packageSendReceiveDecodeDiameterMessage(path, diamPacketDct, extraAVP, eventPass=True, msgId=272, appId=4, hopByHopId=1001, endToEndId=2001, msccAvp=None, diamConnection=None, sendOnlyFlag=False, answerFlag=False, duplicateFlag=False):
    logger =  LOGGER.clErrors(path)
    
    # Debug output
    #print 'packageSendReceiveDecodeDiameterMessage: extraAVP = ' + str(extraAVP)
    
    # Minor hack.  If extraAVP has a "debug" sntry set to true, then we want to print diameter messages
    debugFlag = False
    if 'add' in extraAVP:
        for i,entry in enumerate(extraAVP['add']):
            try:
                # No all entries are single items, so put in try/except
                if entry.lower() == 'debug':
                        debugFlag = True
                        del extraAVP['add'][i]
                        break
            except: pass
        
    # Set proxy flag logic
    if 'CmdFlagProxiable' in extraAVP:
        CmdFlagProxiable = True
        del extraAVP['CmdFlagProxiable']
    else: CmdFlagProxiable = False
    
    # Setup basic diameer packet
    tree = None
    tree = PKTBASE.diamPacket(CmdFlagProxiable, msgId=msgId, hopByHopId=hopByHopId, endToEndId=endToEndId, appId=appId, answerFlag=answerFlag, CmdFlagReTransmit=duplicateFlag)

    #check if we have additional custom add/omit lists
    addListAvps = []
    omitListAvps = []
    extraAVP = checkAdditionalAvps(extraAVP)

    # Check for omits
    if 'omit' in extraAVP:
        omitListAvps = extraAVP['omit']
        if omitListAvps != [] :
            omitListAvps = adjustList(omitListAvps, msccAvp)
            diamPacketDct = tree.removeAvp(omitListAvps, diamPacketDct)
        del extraAVP['omit']

    iter = 1  #needed to normalize duplicate AVPS
    # Check for additions:
    if 'add' in extraAVP:
        addListAvps = extraAVP['add']

        tmpList = [x for x in addListAvps if type(x) == type([])]
        tmpList2 = [x for x in addListAvps if type(x) != type([])]
#       print 'packageSendReceiveDecodeDiameterMessage: tmpList = ' + str(tmpList) + ', tmpList2 = ' + str(tmpList2)
        for x in tmpList:
            (tmpDct, iter) = tree.buildCustomNode(x, iter) #normalize the keys
            
            # Minor hack: logic doesn't properly handle lists within lists.  
            # Note that this only addresses lists at a second level.  
            # It also doesn't work properly if there are multiple MSCC groupings already
            # (as then we'd need to associate which MSCC group the data belongs to).
            # Process each add list entry
            for i in range(len(tmpDct)):
             # Check for every 2nd level exception
             for entry in embeddedLists:
                # Separate into components
                (outerList, innerList) = entry
                
                # See if entry starts with outerList string and contains innerList string
                if tmpDct[i].startswith(outerList) and tmpDct[i].count(innerList):
                        # Remove the iteration value from the outer list item.
                        tmpDct[i] = tmpDct[i][:len(outerList)] + tmpDct[i][len(outerList)+2:]
                
                # Also allow for sip: string
                if tmpDct[i].count('sip$1'): tmpDct[i] = tmpDct[i].replace('sip$1','sip')
                
#           print 'tmpDct = ' + str(tmpDct)
            
            diamPacketDct = tree.addAvps(tmpDct, diamPacketDct)
            iter += 1
        diamPacketDct = tree.addAvps(tmpList2, diamPacketDct)
        del extraAVP['add']
    # Debug output
    #print diamPacketDct

    tree.createTree(diamPacketDct)
    
    # Build the Diameter packet
    diamPacket = tree.createDiamTree()
    # Debug output
    #print "="*50
    #print diamPacket
    
    # Output if debug flag set
    if debugFlag: print('\nDiameter sent message: ' + str(diamPacket) + '\n')

    # Get connection object if not passed in
    if not diamConnection: diamConnection = QAUTILS.getDiamConnection()
    
    # If sending only, then do that here
    if sendOnlyFlag:
        # Send packet
        diamConnection.sendOnly(diamPacket)
        
        # Log what was sent 
        if diameterFileDebugFlag: logger.printRes(path, 'diameter_sent_pkts.txt', str(diamPacket))
        
        # Exit from here (nothing received back, so nothing to process)
        return None, extraAVP
    
    # Send packet; get response packet
    diamResp = diamConnection.send(diamPacket)
    
    # Log what was sent and received
    if diameterFileDebugFlag: 
        logger.printRes(path, 'diameter_recv_pkts.txt', str(diamResp))
        logger.printRes(path, 'diameter_sent_pkts.txt', str(diamPacket))
    
    # Output if debug flag set
    if debugFlag: print('\nDiameter recv message: ' + str(diamResp) + '\n')
    
    # Do some checking (find out if eventPass matches what we received back)
    checkDiamPkts(path, str(diamPacket), diamResp, eventPass, stripList=[])
    
    # Decode packet
    dctRcvd = getRawDiameterDct(path, str(diamResp))
    
    # Keep reading until we get the command type we're expecting
    while True:
        # If dictionary is empty then we timed out 
        if not dctRcvd:
                logger.printRes(path, 'diameter_recv_pkts.txt', 'ERROR: packageSendReceiveDecodeDiameterMessage: Received  Nothing back')
                sys.exit('ERROR: Received nothing back')
        
        # KEF: add current time to the dictionary
        dctRcvd['currentTime'] = MDCTIME.getTime(usec=True)
        #print 'Current time packet received: ' + dctRcvd['currentTime']

        # If they're equal, then break
        if dctRcvd['cmd'] == str(msgId): break

        # Can't silently drop these, as the diameter gateway expects responses (and closes the socket after 4 non-responses)
        if dctRcvd['cmd'] == '258':
                # *** KEF ***
                logger.printRes(path, 'diameter_recv_pkts.txt', 'ERROR: packageSendReceiveDecodeDiameterMessage: Received RAR when not expecting it')
                sys.exit('ERROR: Received RAR when not expecting it')
                # Process RAR
                print('Sending back RAA for unexpected RAR')
                create_diameter_pkt_base.sendReauthAnswer(dctRcvd, diamConnection = diamConnection)
        elif dctRcvd['cmd'] == '280':
                # Send Watchdog answer
                print('Sending back DWA for unexpected DWR')
                create_diameter_pkt_base.sendDeviceWatchdogAnswer(dctRcvd, diamConnection = diamConnection)
        else:
                # Print something so we know we're dropping a packet
                print('Expecting Diameter message command ' + str(msgId) + ' but received message command ' + dctRcvd['cmd'])
                pprint.pprint(dctRcvd)
                
                # *** KEF ***
                logger.printRes(path, 'diameter_recv_pkts.txt', 'ERROR: packageSendReceiveDecodeDiameterMessage: Received unexpected message')
                sys.exit('ERROR: Received unexpected Diameter message')
                # Need to figure out what action to take (e.g send CEA, SNA, etc.)
                print('No action taken on unexpected message received')

        # Go get the next packet
        (dctRcvd, diamResp) = receiveDiameterPacket(path, diamConnection, msgId, timeout=5)

    # Debug output
    #qa_utils.printDct(dctRcvd)
    
    # CSV copy of packet
    try:
        import csv_CmdMisc as CMDMISC
        CMDMISC.SavedData = copy.deepcopy(dctRcvd)
    except:
        pass
    
    # Return data
    return dctRcvd, extraAVP

# Function to receive a diameter packet
def receiveDiameterPacket(path=os.getcwd(), diamConnection=None, msgId=None, timeout=0, extraAVP = {}):
    #logger = LOGGER.clErrors(path)

    # Minor hack.  If extraAVP has a "debug" sntry set to true, then we want to print diameter messages
    debugFlag = False
    if 'add' in extraAVP:
        for i,entry in enumerate(extraAVP['add']):
            try:
                # No all entries are single items, so put in try/except
                if entry.lower() == 'debug':
                        debugFlag = True
                        del extraAVP['add'][i]
                        break
            except: pass
        
    # Get connection object if not passed in
    if not diamConnection: diamConnection = QAUTILS.getDiamConnection()
    
    # See if we're going to adjust the socket timeout
    if int(timeout) > 0:
        # Get the current timeout
        currentTimeout = diamConnection.socketObj.gettimeout()
    
        # Set socket timeout
        diamConnection.socketObj.settimeout(int(timeout))

    # Use try/except to address timeout
    try:
        # Receive packet
        diamResp = diamConnection.recvOnly()
    except IOError:
        # Timeout
        print('WARNING: Received a socket timeout from receiveDiameterPacket().  Waited ' + str(timeout) + ' seconds')
        diamResp = None
    except:
        # Some other critical error.  Would have exited without this, so exit here in a controlled way.
        sys.exit("ERROR: socket exception in receiveDiameterPacket().  Exiting test.")
    finally:
        # Restore socket timeout if it was set above
        if int(timeout) > 0: diamConnection.socketObj.settimeout(currentTimeout)
        
    # See if timeout failure
    if not diamResp: 
        print('\n\nWARNING: receiveDiameterPacket() returned with an error - timeout value set to ' + str(timeout) + '\n\n')
        return None, None
    
    # Log what was sent and received
    if diameterFileDebugFlag: logger.printRes(path, 'diameter_recv_pkts.txt', str(diamResp))

    # Decode packet
    dctRcvd = getRawDiameterDct(path, str(diamResp))

    # Keep reading until we get the command type we're expecting
    while msgId:
        # If they're equal, then break
        if dctRcvd['cmd'] == str(msgId): break

        # Can't silently drop these, as the diameter gateway expects responses (and closes the socket after 4 non-responses)
        if dctRcvd['cmd'] == '258':
                # *** KEF ***
                sys.exit('ERROR: Received RAR when not expecting it')
                # Process RAR
                print('Sending back RAA for unexpected RAR')
                create_diameter_pkt_base.sendReauthAnswer(dctRcvd, diamConnection = diamConnection)
        elif dctRcvd['cmd'] == '280':
                # Send Watchdog answer
                print('Sending back DWA for unexpected DWR')
                create_diameter_pkt_base.sendDeviceWatchdogAnswer(dctRcvd, diamConnection = diamConnection)
        else:
                # Print something so we know we're dropping a packet
                print('Expecting Diameter message command ' + str(msgId) + ' but received message command ' + dctRcvd['cmd'])
                pprint.pprint(dctRcvd)
                
                # *** KEF ***
                sys.exit('ERROR: Received unexpected Diameter message')
                # Need to figure out what action to take (e.g send CEA, SNA, etc.)
                print('No action taken on unexpected message received')

        # Go get the next packet
        (dctRcvd, diamResp) = receiveDiameterPacket(path, diamConnection, msgId, timeout, extraAVP)
    
    # Output if debug flag set
    if debugFlag: print('\nDiameter recv message: ' + str(diamResp) + '\n')
    
    # Debug output
    #QAUTILS.printDct(dctRcvd)

    # CSV copy of packet
    try:
        import csv_CmdMisc as CMDMISC
        CMDMISC.SavedData = copy.deepcopy(dctRcvd)
    except:
        pass
    
    # Return data
    return dctRcvd, diamResp

# Funtion to check return code of Diameter packet
def checkDiameterResultCodes(diamDct, index = 0):

    # Assume success returned
    diamResult = 0
    
    # Debug output
    #print 'Diameter response dictionary: ' 
    #print str(diamDct)
    
    # Get the result code string.
    # Need to first check outer layer.  Can be Result-Code or Experimental-Result->Experimental-Result-Code.
    outerResultString = 'Result-Code'
    expermentalResultString = 'Experimental-Result->Experimental-Result-Code'
    msccResultString = 'Mscc' + str(index) + '->Result-Code'
    resultSuccess = '2001'
    # Check diameter message for error code
    if outerResultString in diamDct:
        if diamDct[outerResultString].strip() != resultSuccess:
                # Got a failure return code
                diamResult = 1
        # Check internal MSCC results if defined
        elif msccResultString in diamDct:
                # Check if the MSCC result code says failure
                if diamDct[msccResultString].strip() != resultSuccess:
                        # Got a failure return code.  Minimally don't update tracking data.
                        diamResult = 1
    elif expermentalResultString in diamDct:
        # Check experimental result code
        if diamDct[expermentalResultString].strip() != resultSuccess:
                # Got a failure return code
                diamResult = 1
    else:
        # No result code was returned
        diamResult = 2

        # See what we got
        print('WARNING: received unexpected message - no result code returned.')
        pprint.pprint(diamDct)

    # Return result
    return diamResult

# Act on result codes
def exitOnFailureDiameterResultCodes(diamResult, eventPass=True, grantedAmount=1, fuiFlag=False, continuePastError=False, diamDct=None):
         errorFlag = False
         
         # If no result code came back, then this is a problem
         if diamResult == 2:
                # For now, error out of here
                sys.exit('Exiting due to unexpected message received')

         # Some PCEFs don't allow error return codes when out of assets.  They use FUI to identify this.
         # For the test framework, nothing granted and FUI means error.
         if (not grantedAmount) and fuiFlag:
                # This is an error 
                diamResult = 1
         
         # If error (non-zero result) and not expecting one, then this is a failure
         if diamResult and eventPass:
                print('ERROR:  Received a failure result code (or FUI with nothing granted) when not expecting a failure.')
                if not continuePastError:
                        print('Failing command due to unexpected response code')
                        if diamDct: pprint.pprint(diamDct)
                        
                        sys.exit('Exiting due to error encountered')
                
                print('Continuing as continuePastError = ' + str(continuePastError))
                errorFlag = True
         
         # If success (zero result) and expecting failure, then this is a failure
         if (not diamResult) and (not eventPass):
                print('ERROR:  Received a success result code but expecting a failure.')
                if not continuePastError:
                        print('Failing command due to unexpected response code')
                        if diamDct: pprint.pprint(diamDct)
                        
                        sys.exit('Exiting due to error encountered')
                
                print('Continuing as continuePastError = ' + str(continuePastError))
                errorFlag = True
         
         return errorFlag
        
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

