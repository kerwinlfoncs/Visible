#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:36:21
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:36:21
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:36:21
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

from __future__ import print_function
# from builtins import str
# from builtins import str
import sys, copy, pprint
import csvMain as CSV
import csv_data as DATA

#==========================================================
def customURLProcessDatafile(lclDCT, options, lclStartTime):
        # For now, only dataFile is the key item
        if not lclDCT['dataFile']: return
        
        # Get key parameters into local variables (for ease of reading)
        # For this command dataFile can be in list format
        dataFile = lclDCT['dataFile'].split('@')
        
        print('In customURLProcessDatafile' + ', dataFile(s) = ' + str(dataFile))
        
        # Reset local object structure
        objInfo = {}
                
        # Process each data file
        for files in dataFile:
                #print 'Started file: ' + files
                
                # Read into structure
                with open(files) as f:
                        data = f.readlines()
                idx = 0
                
                # Get first non-blank line
                while (idx < len(data)):
                        line = data[idx].strip()
                        idx += 1
                        if line == '' or line.startswith('#'): continue
                        
                        #print 'Read line: ' + line
                        
                        # At this point there better be a leading "{"
                        if not line.startswith('{'): sys.exit('ERROR: need to start something wih a "{"')
                        
                        # What is started is the second item
                        startedItem = line.split(' ')[-1].strip()
                        #print 'Starting: ' + startedItem
                        idx = newItem(lclDCT, options, lclStartTime, idx, data, startedItem, objInfo)
                        #print 'Ending: ' + startedItem
                        
                        # If this is a new major item, then add as a new element in the array
                        if startedItem.lower() in ['device', 'subscriber', 'group', 'offer']: 
                                cmd = 'DATA.Cust' + startedItem.lower().capitalize() + "['elements'].append(copy.deepcopy(objInfo))"
                                #print cmd
                                exec(cmd)
                        elif startedItem.lower().count('common'): 
                                # Put into object common area
                                cmd = 'DATA.Cust' + startedItem[:-len('common')].lower().capitalize() + "['common'] = copy.deepcopy(objInfo)"
                                #print cmd
                                exec(cmd)
                        
                        # Reset local object structure
                        objInfo = {}
                
                #print 'Ended file: ' + files
                
        return None,None,None

#==========================================================
def newItem(lclDCT, options, lclStartTime, idx, data, startedItem, objInfo):
        # Need ID parameter list
        idParameters = [x[0] for x in DATA.idParameter]
        #print idParameters
        
        # Read until we find the close of this object, or we find a new open
        # Get first non-blank line
        closeFlag = False
        while (idx < len(data)):
                line = data[idx].strip()
                idx += 1
                if line == '' or line.startswith('#'): continue
                
                #print 'Read line: ' + line
                        
                # If we found the end, then exit
                if line.startswith('}'):
                        closeFlag = True
                        break
                
                # If opening, then iterate
                if line.startswith('{'):
                        # What is started is the second item
                        startedItem = line.split(' ')[-1].strip()
                        #print 'Starting: ' + startedItem
                        if startedItem not in objInfo: objInfo[startedItem] = []
                        addlData = {}
                        idx = newItem(lclDCT, options, lclStartTime, idx, data, startedItem, addlData)
                        objInfo[startedItem].append(copy.deepcopy(addlData))
                        #print 'Ending: ' + startedItem
                
                else:
                        # Record parameter/value pair
                        line = line.split(':')
                        parameter = line[0].strip()
                        value     = line[1].strip()
                        
                        # If list character in the value, then split on it
                        if value.count(DATA.listChar): value = value.split(DATA.listChar)
                        
                        #print 'Original ' + parameter + ' value: ' + str(value)
                        # Need to manipulate this data.
                        # Always use a fresh dictionary so we only look at this one field.
                        #_lclDCT = copy.deepcopy(lclDCT)
                        _lclDCT = {}
                        # Setup the basics
                        if lclDCT['msisdn']:    _lclDCT['msisdnEntered'] = True
                        else:                   _lclDCT['msisdnEntered'] = False
                        if lclDCT['imsi']:      _lclDCT['imsiEntered'] = True
                        else:                   _lclDCT['imsiEntered'] = False
                        
                        # Add the one parameter to translate
                        _lclDCT[parameter] = str(value)
                        CSV.updateInputParameters(_lclDCT, lclStartTime, options)
                        lclDCT[parameter] = _lclDCT[parameter]
                        
                        '''
                        # Make absolute if an ID parameter and an integer returned
                        if parameter in idParameters and _lclDCT[parameter].isdigit():
                                lclDCT[parameter] = 'a' + _lclDCT[parameter]
                        else:   lclDCT[parameter] = _lclDCT[parameter]
                        '''
                        #print 'Updated ' + parameter + ' value: ' + str(lclDCT[parameter])
                        value = line[1] = lclDCT[parameter]
                        
                        # Store in object info
                        objInfo[parameter] = value
                
                # Rebuild the line
                data[idx-1] = ':'.join(line)
        
        # Better be ending on a closed flag...
        if not closeFlag:
                print('ERROR: newItem ending on an open item')
                pprint.pprint(data)
                sys.exit('Exiting')
        
        # Return data 
        return idx
        
