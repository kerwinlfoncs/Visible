#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:43
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:23
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:05
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


# from builtins import str
# from builtins import str
import os, pprint, sys, time, re
import data_container as MDC
# Check if the data_container_defs.py needs to be re-created
import data_container_defs as MDCDEFS
import diameter as DIAM
import commonDefs as cd
import diameter_utils as DIAMUTILS
import qa_utils
import log_errors as LOGGER
import diameter_utils_base as PKTBASE
import custSpecific as CUST
import create_diameter_CER_pkt

#
# This program will create Diameter packets and send them to the
# Diameter Gateway.

####################################################################
# Create  AAR Rx Request
def createAARequestRx(path,reqDct, diamConnection, eventPass, extraAVP = {}, sendOnlyFlag=False,SkipCERFlag=False):
    logger =  LOGGER.clErrors(path)
    diamPacket = None
    appId = 16777236 # Rx appId
    msgId = 265      # Rx:AA msg id
    
    # Exhange CER/CEA if needed
    if not SkipCERFlag: cer  = create_diameter_CER_pkt.main(diamConnection, reqDct, extraAVP)

    # Create the input data
    # If session ID is an integer then add prefix, else use what's passed in.
    if str(reqDct['sessionId']).isdigit(): fullSessionId= cd.RxSessionIdPrefix + str(reqDct['sessionId'])
    else: fullSessionId =  str(reqDct['sessionId'])
    
    diamPacketDct = {}
    diamPacketDct['Session-Id'] = fullSessionId
    diamPacketDct['Origin-Host'] = reqDct['Origin-Host']
    diamPacketDct['Origin-Realm'] = reqDct['Origin-Realm']
    diamPacketDct['Destination-Realm'] = 'destrealm.net'
    diamPacketDct['Destination-Host'] =  reqDct['Destination-Host'] 
    diamPacketDct['Origin-State-Id'] = '1234567890' 
    diamPacketDct['Auth-Application-Id'] = '4'
    # What to put in the User name depends on which value is submitted.  IMSI has priority over MSISDN.
    subscList = None
    if 'Subscription-Id-Type-IMSI' in reqDct:
        subscId1=['Subscription-Id|Subscription-Id-Type:1',
                   'Subscription-Id|Subscription-Id-Data:' +
                    str(reqDct['Subscription-Id-Type-IMSI'])]

        if 'add' in extraAVP:  extraAVP['add'].append(subscId1)
        else: extraAVP['add'] = subscId1

    if 'Subscription-Id-Type-MSISDN' in reqDct:
        subscId2=['Subscription-Id|Subscription-Id-Type:0',
                  'Subscription-Id|Subscription-Id-Data:' +
                    str(reqDct['Subscription-Id-Type-MSISDN'])]

        if 'add' in extraAVP:  extraAVP['add'].append(subscId2)
        else: extraAVP['add'] = subscId2
        
        # Why add twice??
        '''
        if extraAVP.has_key('add'):  extraAVP['add'].append(subscId2)
        else: extraAVP['add'] = subscId2
        '''
        
    #added for Non-Mobile device , mtx-14174, customer can set accessId and loginId from any of
    # these 3 diameter avp . SIP_URI, NAI and Private
    # Build subscription ID data.  May have either LoginId/AccessId, or both.
    # for testing reqDct['Subscription-Id-Type-SIP-URI']= 2
    if 'Subscription-Id-Type-SIP-URI' in reqDct:
               subscId3=['Subscription-Id|Subscription-Id-Type:2',
                       'Subscription-Id|Subscription-Id-Data:' +
                       str(reqDct['Subscription-Id-Type-SIP-URI'])]
               if 'add' in extraAVP:  extraAVP['add'].append(subscId3)
               else: extraAVP['add'] = subscId3


    if 'Subscription-Id-Type-NAI' in reqDct:
               subscId4=['Subscription-Id|Subscription-Id-Type:3',
                   'Subscription-Id|Subscription-Id-Data:' +
                    str(reqDct['Subscription-Id-Type-NAI'])]
               if 'add' in extraAVP:  extraAVP['add'].append(subscId4)
               else: extraAVP['add'] = subscId4

    if reqDct['requestType'] == 'initial':
           diamPacketDct['Rx-Request-Type'] = '0'
    elif reqDct['requestType'] == 'interim':
           diamPacketDct['Rx-Request-Type'] = '1'
    else: diamPacketDct['Termination-Cause'] = '1' 
     # Package and send the diameter packet
    (dctRcvd, extraAVP) = DIAMUTILS.packageSendReceiveDecodeDiameterMessage(path, diamPacketDct, extraAVP, eventPass=eventPass, msgId=msgId, appId=appId, diamConnection=diamConnection,sendOnlyFlag=sendOnlyFlag)

    # Add output if verbose says to
    try:
        if reqDct['verbose'] in ['full', 'high']: pprint.pprint(dctRcvd)
    except:
        pass

    # Return post-processed received dictionary
    return dctRcvd
    

####################################################################
# Create  Rx:RA answer Request
def sendReauthAnswerRx(dctRcvd = {}, path = os.getcwd(), eventPass=True, extraAVP = {}, msccAvp=None, diamConnection=None, nonSuccessResultCode='5002'):    

    appId = 16777236 # Rx appId
    msgId = 258      # Rx:RA msg id   
     # Clear dictionary
    diamPacketDct = {}

     # Use data from the input packet, if it's there, else default the data
    if 'Destination-Host' in dctRcvd:
       # Copy from input packet
       diamPacketDct['Origin-Host'] = dctRcvd['Destination-Host'].strip()

       # Remove from extraAVP if present
       if 'Origin-Host' in extraAVP: del extraAVP['Origin-Host']
    else: diamPacketDct['Origin-Host'] = 'orighost.net'

    if 'Destination-Realm' in dctRcvd:
        # Copy from input packet
        diamPacketDct['Origin-Realm'] = dctRcvd['Destination-Realm'].strip()

    if 'Origin-Realm' in extraAVP: del extraAVP['Origin-Realm']
    else: diamPacketDct['Origin-Realm'] = 'origrealm.net'

    if 'Origin-State-Id' in dctRcvd: diamPacketDct['Origin-State-Id'] = dctRcvd['Origin-State-Id'].strip()
    else: diamPacketDct['Origin-State-Id'] = '333'


    if 'Session-Id' in dctRcvd: diamPacketDct['Session-Id'] = dctRcvd['Session-Id'].strip()
    else: diamPacketDct['Session-Id'] = cd.RxSessionIdPrefix + '998023766' 

    if 'Auth-Application-Id' in dctRcvd: appId = int(dctRcvd['Auth-Application-Id'].strip())
    else: appId = 16777236 


    # What to send for the result depends on eventPass setting
    if int(eventPass): diamPacketDct['Result-Code'] = '2002'
    else:
        print('EventPass = '+ str(eventPass))
        diamPacketDct['Result-Code'] = nonSuccessResultCode

    # Package and send the diameter packet.  Set sendOnlyFlag parameter so we don't expect to receive anything.  Set answer flag as this is an answer message.
    (dctRcvd, extraAVP) = DIAMUTILS.packageSendReceiveDecodeDiameterMessage(path, diamPacketDct, extraAVP, eventPass=True, msgId=msgId, appId=appId, msccAvp=msccAvp, diamConnection=diamConnection, sendOnlyFlag=True, answerFlag=True)

     # Add output if verbose says to
    try:
        if reqDct['verbose'] in ['full', 'high']: pprint.pprint(dctRcvd)
    except:
        pass

    # Return
    return

############################################################################
# Create Rx:ST Request
def createSessionTermRequestRx(path,reqDct, diamConnection, eventPass, extraAVP = {}, SkipCERFlag=False):
    logger =  LOGGER.clErrors(path)
    tree = None
    diamPacket = None
    appId = 16777236 
    msgId = 275 #Rx:ST 

    #send a CER first
    if not SkipCERFlag: cer  = create_diameter_CER_pkt.main(diamConnection, reqDct, extraAVP) 
   
    diamPacketDct = {}
    diamPacketDct['Origin-Host'] = reqDct['Origin-Host']
    diamPacketDct['Origin-Realm'] = reqDct['Origin-Realm']
    fullSessionId = cd.RxSessionIdPrefix + str(reqDct['sessionId'])
    diamPacketDct['Session-Id'] = fullSessionId
    diamPacketDct['Destination-Host'] = reqDct['Destination-Host']
    diamPacketDct['Destination-Realm'] = 'destrealm.net'
    diamPacketDct['Origin-State-Id'] = '1234567890'
    diamPacketDct['Auth-Application-Id'] = '4'
    diamPacketDct['Termination-Cause'] = '1'

    # Package and send the diameter packet
    (dctRcvd, extraAVP) = DIAMUTILS.packageSendReceiveDecodeDiameterMessage(path, diamPacketDct, extraAVP, eventPass=eventPass, msgId=msgId, appId=appId, diamConnection=diamConnection)

    # Add output if verbose says to
    try:
        if reqDct['verbose'] in ['full', 'high']: pprint.pprint(dctRcvd)
    except:
        pass

    # Return post-processed received dictionary
    return dctRcvd

############################################################################
# Create Abort Session Answer Rx session
def sendAbortSessionAnswerRx(dctRcvd = {}, path = os.getcwd(), eventPass=True, extraAVP = {}, msccAvp=None, diamConnection=None, nonSuccessResultCode='5002'):

    print('Sending ASA message: ' + str(dctRcvd))

    appId = 16777236
    msgId = 274
    # Clear dictionary
    diamPacketDct = {}

    # Use data from the input packet, if it's there, else default the data
    if 'Destination-Host' in dctRcvd:
         # Copy from input packet
         diamPacketDct['Origin-Host'] = dctRcvd['Destination-Host'].strip()

         # Remove from extraAVP if present
         if 'Origin-Host' in extraAVP: del extraAVP['Origin-Host'] 
    else: diamPacketDct['Origin-Host'] = 'orighost.net'

    if 'Destination-Realm' in dctRcvd:
          # Copy from input packet
          diamPacketDct['Origin-Realm'] = dctRcvd['Destination-Realm'].strip()

          # Remove from extraAVP if present
          if 'Origin-Realm' in extraAVP: del extraAVP['Origin-Realm']
    else: diamPacketDct['Origin-Realm'] = 'origrealm.net'

    if 'Origin-State-Id' in dctRcvd: diamPacketDct['Origin-State-Id'] = dctRcvd['Origin-State-Id'].strip()
    else: diamPacketDct['Origin-State-Id'] = '333'

    if 'Session-Id' in dctRcvd: diamPacketDct['Session-Id'] = dctRcvd['Session-Id'].strip()
    else: diamPacketDct['Session-Id'] = cd.RxSessionIdPrefix + '998023766'  

    if int(eventPass): diamPacketDct['Result-Code'] = '2001'
    else:         diamPacketDct['Result-Code'] = nonSuccessResultCode

    # Package and send the diameter packet.  Set sendOnlyFlag parameter so we don't expect to receive anything.  Set answer flag as this is an answer message.
    (dctRcvd, extraAVP) = DIAMUTILS.packageSendReceiveDecodeDiameterMessage(path, diamPacketDct, extraAVP, eventPass=True, msgId=msgId , appId=appId, msccAvp=msccAvp, diamConnection=diamConnection, sendOnlyFlag=True, answerFlag=True)

     # Add output if verbose says to
    try:
        if reqDct['verbose'] in ['full', 'high']: pprint.pprint(dctRcvd)
    except:
        pass

    # Return
    return
 
####################################################################
# Create STR Request
def createSessionTermRequest(path,reqDct, diamConnection, eventPass, extraAVP = {}, SkipCERFlag=False):
    logger =  LOGGER.clErrors(path)
    tree = None
    diamPacket = None
    appId = 0
    msgId = 275

    #send a CER first
    if not SkipCERFlag: cer  = create_diameter_CER_pkt.main(diamConnection, reqDct, extraAVP) 
    #createCapabilityExchangeRequest(eventPass=eventPass, extraAVP = extraAVP, diamConnection= diamConnection)

    # Create the input data
    fullSessionId= cd.GySessionIdPrefix + str(reqDct['sessionId'])
    diamPacketDct = {}
    diamPacketDct['Session-Id'] = fullSessionId
    diamPacketDct['Origin-Host'] = reqDct['Origin-Host']
    diamPacketDct['Origin-Realm'] = reqDct['Origin-Realm']
    diamPacketDct['Destination-Realm'] = 'destrealm.net'
    diamPacketDct['Auth-Application-Id'] = 4
    diamPacketDct['Termination-Cause'] = '1'

    # Package and send the diameter packet
    (dctRcvd, extraAVP) = DIAMUTILS.packageSendReceiveDecodeDiameterMessage(path, diamPacketDct, extraAVP, eventPass=eventPass, msgId=msgId, appId=appId, diamConnection=diamConnection)

    # Add output if verbose says to
    try:
        if reqDct['verbose'] in ['full', 'high']: pprint.pprint(dctRcvd)
    except:
        pass
    
    # Return post-processed received dictionary
    return dctRcvd

####################################################################
# Create  CCR Gx Request
def createCreditControlRequestGx(path,reqDct, diamConnection, eventPass, extraAVP = {}, SkipCERFlag=False):
    logger =  LOGGER.clErrors(path)
    diamPacket = None
    appId = 16777238 # Gx appId
    msgId = 272      # CCR message
    omitListAvps = []
    if 'omit' in extraAVP:
      omitListAvps = extraAVP['omit']

    #send a CER first
    if not SkipCERFlag: cer  = create_diameter_CER_pkt.main(diamConnection, reqDct, extraAVP) 

    # Create the input data
    fullSessionId= cd.GxSessionIdPrefix + str(reqDct['sessionId'])
    diamPacketDct = {}
    diamPacketDct['Session-Id'] = fullSessionId
    diamPacketDct['Origin-Host'] = reqDct['Origin-Host']
    diamPacketDct['Origin-Realm'] = reqDct['Origin-Realm']
    diamPacketDct['Destination-Realm'] = 'destrealm.net'
    diamPacketDct['Auth-Application-Id'] = DIAM.GxAppId 
    diamPacketDct['Origin-State-Id'] = '1234567890'
    diamPacketDct['Destination-Host'] =  reqDct['Destination-Host']
    #diamPacketDct['Event-Timestamp'] = reqDct['eventTime']
    
    # KEF: What is this if statement???? Skip for now.
    # check if not a STR send
    #if reqDct['requestType'] == 'term':
    if msgId != 272:
      if 'reqNum' not in reqDct : 
        # a STR send
        msgId = 275 # STR
        appId = DIAM.CommonAppId # which is 0
        diamPacketDct['Auth-Application-Id'] = '4' 
        diamPacketDct['Termination-Cause'] = '1'
 
    else:
        reqtype = DIAMUTILS.getRequestType (reqDct['requestType'])
        diamPacketDct['CC-Request-Type'] = reqtype
        diamPacketDct['CC-Request-Number'] = reqDct['reqNum']
        diamPacketDct['Event-Timestamp'] = reqDct['eventTime']

        #Use-Name is not needed for Gx CC request
        # What to put in the User name depends on which value is submitted.  IMSI has priority over MSISDN.
        #if reqDct.has_key('Subscription-Id-Type-IMSI'):
        #  diamPacketDct['User-Name'] =  str(reqDct['Subscription-Id-Type-IMSI'])
        #if reqDct.has_key('Subscription-Id-Type-MSISDN'):
        #  diamPacketDct['User-Name'] = str(reqDct['Subscription-Id-Type-MSISDN'])
        # Build subscription ID data.  May have either IMSI/MSISDN, or both.
        subscList = None
        # for testing reqDct['Subscription-Id-Type-MSISDN']= 1
        if 'Subscription-Id' not in omitListAvps:
          if 'Subscription-Id-Type-IMSI' in reqDct:
                 subscId1=['Subscription-Id|Subscription-Id-Type:1',
                        'Subscription-Id|Subscription-Id-Data:' +
                    str(reqDct['Subscription-Id-Type-IMSI'])]

                 if 'add' in extraAVP:  extraAVP['add'].append(subscId1)
                 else: extraAVP['add'] = subscId1

          if 'Subscription-Id-Type-MSISDN' in reqDct:
                subscId2=['Subscription-Id|Subscription-Id-Type:0',
                          'Subscription-Id|Subscription-Id-Data:' +
                    str(reqDct['Subscription-Id-Type-MSISDN'])]

                if 'add' in extraAVP:  extraAVP['add'].append(subscId2)
                else: extraAVP['add'] = subscId2

          #added for Non-Mobile device , mtx-14174, customer can set accessId and loginId from any of
          # these 3 diameter avp . SIP_URI, NAI and Private
          # Build subscription ID data.  May have either LoginId/AccessId, or both.
          # for testing reqDct['Subscription-Id-Type-SIP-URI']= 2
          if 'Subscription-Id-Type-SIP-URI' in reqDct:
               subscId3=['Subscription-Id|Subscription-Id-Type:2',
                       'Subscription-Id|Subscription-Id-Data:' +
                       str(reqDct['Subscription-Id-Type-SIP-URI'])]
               if 'add' in extraAVP:  extraAVP['add'].append(subscId3)
               else: extraAVP['add'] = subscId3


          if 'Subscription-Id-Type-NAI' in reqDct:
               subscId4=['Subscription-Id|Subscription-Id-Type:3',
                   'Subscription-Id|Subscription-Id-Data:' +
                    str(reqDct['Subscription-Id-Type-NAI'])]
               if 'add' in extraAVP:  extraAVP['add'].append(subscId4)
               else: extraAVP['add'] = subscId4

        #SGSN-Address is not a known AVP for Gx CC request
        #diamPacketDct['SGSN-Address'] = reqDct['SGSN-Address']
        msgId = 272

    
    # Package and send the diameter packet
    (dctRcvd, extraAVP) = DIAMUTILS.packageSendReceiveDecodeDiameterMessage(path, diamPacketDct, extraAVP, eventPass=eventPass, msgId=msgId, appId=appId, diamConnection=diamConnection)

    # Add output if verbose says to
    try:
        if reqDct['verbose'] in ['full', 'high']: pprint.pprint(dctRcvd)
    except:
        pass
    
    # Return post-processed received dictionary
    return dctRcvd



############################################################################
# Create Spend Limit Request
def createSpendLimitOrSpendTermRequest(path,reqDct, diamConnection, eventPass, extraAVP = {}, SkipCERFlag=False):
    logger =  LOGGER.clErrors(path)
    tree = None
    diamPacket = None

    #send a CER first
    if not SkipCERFlag: cer  = create_diameter_CER_pkt.main(diamConnection, reqDct, extraAVP) #createCapabilityExchangeRequest(eventPass=eventPass, extraAVP = extraAVP, diamConnection= diamConnection)

    # Create the input data

    diamPacketDct = {}
    diamPacketDct['Origin-Host'] = reqDct['Origin-Host']
    diamPacketDct['Origin-Realm'] = reqDct['Origin-Realm']
    fullSessionId = cd.SySessionIdPrefix + str(reqDct['sessionId'])
    diamPacketDct['Session-Id'] = fullSessionId
    diamPacketDct['Destination-Host'] = reqDct['Destination-Host']
    diamPacketDct['Destination-Realm'] = 'destrealm.net'
    diamPacketDct['Origin-State-Id'] = '1234567890'
    diamPacketDct['Event-Timestamp'] = reqDct['eventTime']
    diamPacketDct['Auth-Application-Id'] = '4'

    # Non-standard AVP (helps our system work better)
##    diamPacketDct['Event-Timestamp'] = reqDct['eventTime']
    
    # Set request type specific AVPs
    if reqDct['requestType'] == 'initial': 
        diamPacketDct['SL-Request-Type'] = '0'
    elif reqDct['requestType'] == 'interim': 
        diamPacketDct['SL-Request-Type'] = '1'
    else: diamPacketDct['Termination-Cause'] = '1'
    
    # Additional non-term AVPs
    if reqDct['requestType'] != 'term': 
            # Build subscription ID data.  May have either IMSI/MSISDN, or both.
            subscList = None
            # See if an IMSI was passed in
            if 'Subscription-Id-Type-IMSI' in reqDct:
                subscId1=['Subscription-Id|Subscription-Id-Type:1', 
                           'Subscription-Id|Subscription-Id-Data:' +  
                            str(reqDct['Subscription-Id-Type-IMSI'])]

                # Create/add-to extraAVP entry
                if 'add' in extraAVP:  extraAVP['add'].append(subscId1)
                else: extraAVP['add'] = subscId1

            # See if an MSISDN was passed in
            if 'Subscription-Id-Type-MSISDN' in reqDct:
                subscId2=['Subscription-Id|Subscription-Id-Type:0', 
                          'Subscription-Id|Subscription-Id-Data:' +
                            str(reqDct['Subscription-Id-Type-MSISDN'])]

                # Create/add-to extraAVP entry
                if 'add' in extraAVP:  extraAVP['add'].append(subscId2)
                else: extraAVP['add'] = subscId2

            #added for Non-Mobile device , mtx-14174, customer can set accessId and loginId from any of
            # these 3 diameter avp . SIP_URI, NAI and Private
            # Build subscription ID data.  May have either LoginId/AccessId, or both.
            # for testing reqDct['Subscription-Id-Type-SIP-URI']= 2
            if 'Subscription-Id-Type-SIP-URI' in reqDct:
                subscId3=['Subscription-Id|Subscription-Id-Type:2',
                      'Subscription-Id|Subscription-Id-Data:' +
                       str(reqDct['Subscription-Id-Type-SIP-URI'])]
                if 'add' in extraAVP:  extraAVP['add'].append(subscId3)
                else: extraAVP['add'] = subscId3


            if 'Subscription-Id-Type-NAI' in reqDct:
                subscId4=['Subscription-Id|Subscription-Id-Type:3',
                   'Subscription-Id|Subscription-Id-Data:' +
                    str(reqDct['Subscription-Id-Type-NAI'])]
                if 'add' in extraAVP:  extraAVP['add'].append(subscId4)
                else: extraAVP['add'] = subscId4
 
         
    # Define message IDs
    if reqDct['requestType'] != 'term': 
        # SLR message.
        # Different vendors map diameter AVPs differently
        if hasattr(CUST, "diameterMessageIds"):
                if 'SLR' in CUST.diameterMessageIds:
                        appId = CUST.diameterMessageIds['SLR'][0]
                        msgId = CUST.diameterMessageIds['SLR'][1]
                else:
                        # use 3GPP defaults
                        appId = 16777302
                        msgId = 8388635
        else:
                # use 3GPP defaults
                appId = 16777302
                msgId = 8388635
    else:
        # STR message.
        # Different vendors map diameter AVPs differently
        if hasattr(CUST, "diameterMessageIds"):
                if 'STR' in CUST.diameterMessageIds:
                        appId = CUST.diameterMessageIds['STR'][0]
                        msgId = CUST.diameterMessageIds['STR'][1]
                else:
                        # use 3GPP defaults
                        appId = 16777302
                        msgId = 275
        else:
                # use 3GPP defaults
                appId = 16777302
                msgId = 275
    
    # Package and send the diameter packet
    (dctRcvd, extraAVP) = DIAMUTILS.packageSendReceiveDecodeDiameterMessage(path, diamPacketDct, extraAVP, eventPass=eventPass, msgId=msgId, appId=appId, diamConnection=diamConnection)
    
    # Add output if verbose says to
    try:
        if reqDct['verbose'] in ['full', 'high']: pprint.pprint(dctRcvd)
    except:
        pass
    
    # Return post-processed received dictionary
    return dctRcvd

############################################################################
# Create Subscribe Notifications Request
def createSubscribeNotificationRequest(path,reqDct, diamConnection, eventPass, extraAVP = {}, SkipCERFlag=False):
    logger =  LOGGER.clErrors(path)
    tree = None
    diamPacket = None

    #send a CER first
    if not SkipCERFlag: cer  = create_diameter_CER_pkt.main(diamConnection, reqDct, extraAVP) #createCapabilityExchangeRequest(eventPass=eventPass, extraAVP = extraAVP, diamConnection= diamConnection)

    # Create the input data
    diamPacketDct = {}
    
    # Fixed values (always passed in or hard-coded)
    diamPacketDct['Origin-Host'] = reqDct['Origin-Host']
    diamPacketDct['Origin-Realm'] = reqDct['Origin-Realm']
    diamPacketDct['Session-Id'] = cd.ShSessionIdPrefix + str(reqDct['sessionId'])
    diamPacketDct['Destination-Host'] = reqDct['Destination-Host']
    diamPacketDct['Destination-Realm'] = 'destrealm.net'
    diamPacketDct['Event-Timestamp'] = reqDct['eventTime']
    diamPacketDct['Vendor-Specific-Application-Id|Auth-Application-Id'] = '16777217'
    diamPacketDct['Vendor-Specific-Application-Id|Vendor-Id'] = '10415'
    diamPacketDct['User-Name'] = '1232'
    
    # Optional items
    # MSISDN is OctetString, so convert value to hex
    try:        diamPacketDct['User-Identity|MSISDN'] = DIAM.convertStringToHexStr(reqDct['Subscription-Id-Type-MSISDN'])
    except:     pass
    try:        diamPacketDct['User-Identity|Public-Identity'] = reqDct['Subscription-Id-Type-IMSI']
    except:     pass
    
    # These fields should always be sent, so default them if nothing passed in
    try:        diamPacketDct['Expiry-Time'] = extraAVP['Expiry-Time']
    except:     diamPacketDct['Expiry-Time'] = str(int(reqDct['eventTime']) + 300)
    try:        diamPacketDct['One-Time-Notification'] = extraAVP['One-Time-Notification']
    except:     diamPacketDct['One-Time-Notification'] = '0'

    # Following AVPs are ignored in 5080
 #   diamPacketDct['Service-Indication'] = 
    diamPacketDct['Auth-Session-State'] = '1'
    diamPacketDct['Subs-Req-Type'] = '0'
    diamPacketDct['Data-Reference'] = '0'

#    print diamPacketDct

    # Package and send the diameter packet
    (dctRcvd, extraAVP) = DIAMUTILS.packageSendReceiveDecodeDiameterMessage(path, diamPacketDct, extraAVP, eventPass=eventPass, msgId=308, appId=16777217, diamConnection=diamConnection)

#    print dctRcvd
#    pprint.pprint(dctRcvd)
    # Add output if verbose says to
    try:
        if reqDct['verbose'] in ['full', 'high']: pprint.pprint(dctRcvd)
    except:     pass

    # Return post-processed received dictionary
    return dctRcvd

############################################################################
# Create Push Notification Answer
def sendPushNotificationAnswer(diamConnection, dctRcvd={}, path = os.getcwd(), eventPass=True, extraAVP = {}, nonSuccessResultCode='5002'):

    diamPacketDct = {}


    if 'Destination-Host' in dctRcvd:
        # Copy from input packet
        diamPacketDct['Origin-Host'] = dctRcvd['Destination-Host'].strip()

        # Remove from extraAVP if present
        if 'Origin-Host' in extraAVP: del extraAVP['Origin-Host']
    else: diamPacketDct['Origin-Host'] = 'orighost.net'

    if 'Destination-Realm' in dctRcvd:
        # Copy from input packet
        diamPacketDct['Origin-Realm'] = dctRcvd['Destination-Realm'].strip()

        # Remove from extraAVP if present
        if 'Origin-Realm' in extraAVP: del extraAVP['Origin-Realm']
    else: diamPacketDct['Origin-Realm'] = 'origrealm.net'
    if 'Session-Id' in dctRcvd: 
        diamPacketDct['Session-Id'] = dctRcvd['Session-Id'].strip()
    else:
        diamPacketDct['Session-Id'] = cd.ShSessionIdPrefix + '12345'

    diamPacketDct['Vendor-Specific-Application-Id|Vendor-Id'] = '10415'

    # Following AVPs are ignored in 5080
    diamPacketDct['Auth-Session-State'] = '16777217'

    if int(eventPass): 
        diamPacketDct['Result-Code'] = '2002'
    else:
        print('EventPass = '+ str(eventPass))
        diamPacketDct['Result-Code'] = nonSuccessResultCode


#    print diamPacketDct

    # Package and send the diameter packet
    (dctRcvd, extraAVP) = DIAMUTILS.packageSendReceiveDecodeDiameterMessage(path, diamPacketDct, extraAVP, eventPass=eventPass, msgId=309, appId=16777217, diamConnection=diamConnection, sendOnlyFlag=True, answerFlag=True)


############################################################################
# Create Credit Control Request
def createCreditControlRequest(path,reqDct, diamConnection, eventPass, extraAVP = {}, SkipCERFlag=False, sendOnlyFlag=False, duplicateFlag = False):
    logger =  LOGGER.clErrors(path)
    tree = None
    msccPkt = False
    diamPacket = None
    if 'MSCC' in extraAVP:
        msccPkt = True

    #send a CER first
    if not SkipCERFlag: cer  = create_diameter_CER_pkt.main(diamConnection, reqDct, extraAVP) #createCapabilityExchangeRequest(eventPass=eventPass, extraAVP = extraAVP, diamConnection= diamConnection)

    # Create the input data
    fullSessionId= cd.GySessionIdPrefix + str(reqDct['sessionId'])
    diamPacketDct = {}
    diamPacketDct['Session-Id'] = fullSessionId
    diamPacketDct['Origin-Host'] = reqDct['Origin-Host']
    diamPacketDct['Origin-Realm'] = reqDct['Origin-Realm']
    diamPacketDct['Destination-Realm'] = 'destrealm.net'
    diamPacketDct['Auth-Application-Id'] = '4'
    diamPacketDct['Service-Context-Id'] = reqDct['Service-Context-Id']
    diamPacketDct['Service-Identifier'] = reqDct['serviceIdName']

    reqtype = DIAMUTILS.getRequestType (reqDct['requestType'])
    diamPacketDct['CC-Request-Type'] = reqtype
    diamPacketDct['CC-Request-Number'] = reqDct['reqNum']

    diamPacketDct['Event-Timestamp'] = reqDct['eventTime']
    diamPacketDct['Destination-Host'] =  reqDct['Destination-Host']

    # What to put in the User name depends on which value is submitted.  IMSI has priority over MSISDN.
    if 'Subscription-Id-Type-IMSI' in reqDct:
         diamPacketDct['User-Name'] =  str(reqDct['Subscription-Id-Type-IMSI'])
    if 'Subscription-Id-Type-MSISDN' in reqDct:
         diamPacketDct['User-Name'] = str(reqDct['Subscription-Id-Type-MSISDN'])

    if 'Subscription-Id-Type-SIP' in reqDct:
         diamPacketDct['User-Name'] = reqDct['Subscription-Id-Type-SIP']
       
    if 'Subscription-Id-Type-NAI' in reqDct:
         diamPacketDct['User-Name'] = reqDct['Subscription-Id-Type-NAI'] 
    # PATRICIA: add Diameter logic here
    #if 'loginId' in reqDct: 
    #if 'accessId' in reqDct: 
    
    # Build subscription ID data.  May have either IMSI/MSISDN, or both.
    subscList = None
    # for testing reqDct['Subscription-Id-Type-MSISDN']= 1
    if 'Subscription-Id-Type-IMSI' in reqDct:
        subscId1=['Subscription-Id|Subscription-Id-Type:1', 
                   'Subscription-Id|Subscription-Id-Data:' +  
                    str(reqDct['Subscription-Id-Type-IMSI'])]

        if 'add' in extraAVP:  extraAVP['add'].append(subscId1)
        else: extraAVP['add'] = subscId1

    if 'Subscription-Id-Type-MSISDN' in reqDct:
        subscId2=['Subscription-Id|Subscription-Id-Type:0', 
                  'Subscription-Id|Subscription-Id-Data:' +
                    str(reqDct['Subscription-Id-Type-MSISDN'])]

        if 'add' in extraAVP:  extraAVP['add'].append(subscId2)
        else: extraAVP['add'] = subscId2

    #added for Non-Mobile device , mtx-14174, customer can set accessId and loginId from any of
    # these 3 diameter avp . SIP_URI, NAI and Private
    # Build subscription ID data.  May have either LoginId/AccessId, or both.
    # for testing reqDct['Subscription-Id-Type-SIP-URI']= 2
    if 'Subscription-Id-Type-SIP-URI' in reqDct:
        subscId3=['Subscription-Id|Subscription-Id-Type:2',
                   'Subscription-Id|Subscription-Id-Data:' +
                    str(reqDct['Subscription-Id-Type-SIP-URI'])]
        if 'add' in extraAVP:  extraAVP['add'].append(subscId3)
        else: extraAVP['add'] = subscId3

    #if reqDct.has_key('Subscription-Id-Type-PRIVATE'):
    #    subscId3=['Subscription-Id|Subscription-Id-Type:4',
    #               'Subscription-Id|Subscription-Id-Data:' +
    #                reqDct['Subscription-Id-Type-PRIVATE']]
    #    if extraAVP.has_key('add'):  extraAVP['add'].append(subscId3)
    #    else: extraAVP['add'] = subscId3

    if 'Subscription-Id-Type-NAI' in reqDct:
        subscId4=['Subscription-Id|Subscription-Id-Type:3',
                   'Subscription-Id|Subscription-Id-Data:' +
                    str(reqDct['Subscription-Id-Type-NAI'])]
        if 'add' in extraAVP:  extraAVP['add'].append(subscId4)
        else: extraAVP['add'] = subscId4

         
    #print reqDct
    #print  extraAVP['add']
    #sys.exit(1)
    #diamPacketDct['SGSN-Address'] = reqDct['SGSN-Address']
        
    ## get the Quantity selector  - returns totalData or actualDuration, etc..
    ## these values are defined in commonDefs.py
    msccAvp = None

    if msccPkt:
        msccAvp = 'Multiple-Services-Credit-Control'  #needed for later checking quatity selectors
        diamPacketDct["Multiple-Services-Indicator"] ='1'
        diamPacketDct["Multiple-Services-Credit-Control"] ='Grouped'
        diamPacketDct['Multiple-Services-Credit-Control|Rating-Group'] = reqDct['Service-Context-Id']

    quantitySelector = DIAMUTILS.getQuantitySelector(reqDct['serviceId'], msccAvp)

    ############################################################
    amountReq =  int(reqDct['reqamount'])
    amountUsed =  int(reqDct['usedamount'])
    moneyExponent = reqDct['exponent']
    currencyCode = reqDct['currencyCode']
    if moneyExponent: moneyExponent = int(moneyExponent)
    
    if (reqDct['requestType'] == 'initial'):
        diamPacketDct = DIAMUTILS.getAvpRequestedOrUsedServiceUnit(diamPacketDct, quantitySelector, amountReq, 'Requested-Service-Unit', msccAvp, moneyExponent, currencyCode)

    elif (reqDct['requestType'] == 'interim'):
        diamPacketDct = DIAMUTILS.getAvpRequestedOrUsedServiceUnit(diamPacketDct, quantitySelector, amountReq, 'Requested-Service-Unit', msccAvp, moneyExponent, currencyCode)
        diamPacketDct = DIAMUTILS.getAvpRequestedOrUsedServiceUnit(diamPacketDct, quantitySelector, amountUsed, 'Used-Service-Unit', msccAvp, moneyExponent, currencyCode)

    elif (reqDct['requestType'] == 'term'):
         diamPacketDct = DIAMUTILS.getAvpRequestedOrUsedServiceUnit(diamPacketDct, quantitySelector, amountUsed, 'Used-Service-Unit', msccAvp, moneyExponent, currencyCode)
    elif (reqDct['requestType'] == 'event'):
        #print 'Event processing:  amountUsed = ' + str(amountUsed) + ', moneyExponent = ' + str(moneyExponent)
        #diamPacketDct = DIAMUTILS.getAvpRequestedOrUsedServiceUnit(diamPacketDct, quantitySelector, amountUsed, 'Used-Service-Unit', msccAvp, moneyExponent, currencyCode)
        #print 'Packaging RSU with amount ' + str(amountReq)
        diamPacketDct = DIAMUTILS.getAvpRequestedOrUsedServiceUnit(diamPacketDct, quantitySelector, amountReq, 'Requested-Service-Unit', msccAvp, moneyExponent, currencyCode)

    psReqDctList = ['Start-Time', 'Called-Station-Id', '3GPP-MS-TimeZone']
    diamPacketDct['Service-Information|PS-Information|Start-Time'] = reqDct['Start-Time']
    diamPacketDct['Service-Information|PS-Information|Called-Station-Id']=reqDct['Called-Station-Id']
    diamPacketDct['Service-Information|PS-Information|3GPP-MS-TimeZone']=reqDct['3GPP-MS-TimeZone']
    
    # See if we're going to override defaults
    if 'appId' in extraAVP: appId = int(extraAVP['appId'])
    else:                         appId = 4
    
    if 'msgId' in extraAVP: msgId = int(extraAVP['msgId'])
    else:                         msgId = 272
    
    if 'hopByHopId' in extraAVP:        hopByHopId = int(extraAVP['hopByHopId'])
    else:                               hopByHopId=1001
    
    if 'endToEndId' in extraAVP:        endToEndId = int(extraAVP['endToEndId'])
    else:                               endToEndId=2001
    
    # Last chance customer-specific processing on CCR messages
    # Not all customer specific code has this function, so add within a "try" section.
    try:
        CUST.lastChanceCustSpecificCcrMods(diamPacketDct, extraAVP)
    except:
        kef = 1
    
    # Package and send the diameter packet
    (dctRcvd, extraAVP) = DIAMUTILS.packageSendReceiveDecodeDiameterMessage(path, diamPacketDct, extraAVP, eventPass=eventPass, msgId=msgId, appId=appId, msccAvp=msccAvp, diamConnection=diamConnection, hopByHopId=hopByHopId, endToEndId=endToEndId, sendOnlyFlag=sendOnlyFlag, duplicateFlag=duplicateFlag)
    
    # Add output if verbose says to
    try:
        if reqDct['verbose'] in ['full', 'high']: pprint.pprint(dctRcvd)
    except:
        pass
    
    # Return post-processed received dictionary
    return dctRcvd

############################################################################
# Create Device Watchdog Request
def createDeviceWatchdogRequest(dctRcvd = {}, path = os.getcwd(), eventPass=True, extraAVP = {}, msccAvp=None, diamConnection=None):

    # Clear dictionary
    diamPacketDct = {}
    
    # This message has basically hard-coded AVPs...
    diamPacketDct['Origin-Host'] = 'orighost.net'
    diamPacketDct['Origin-Realm'] = 'origrealm.net'

    # One echoed AVP
    if 'Origin-State-Id' in dctRcvd: diamPacketDct['Origin-State-Id'] = dctRcvd['Origin-State-Id']
    else: diamPacketDct['Origin-State-Id'] = '100'
    
    # Package and send the diameter packet
    (dctRcvd, extraAVP) = DIAMUTILS.packageSendReceiveDecodeDiameterMessage(path, diamPacketDct, extraAVP, eventPass=eventPass, msgId=280, appId=0, msccAvp=msccAvp, diamConnection=diamConnection)
    
    # Add output if verbose says to
    try:
        if reqDct['verbose'] in ['full', 'high']: pprint.pprint(dctRcvd)
    except:
        pass
    
    # Debug output
    #print 'Diameter Watchdog Request (DWR) message fields: ' + str(dctRcvd)
    
    # Return post-processed received dictionary
    return dctRcvd

############################################################################
# Create Device Watchdog Answer
def sendDeviceWatchdogAnswer(dctRcvd = {}, path = os.getcwd(), eventPass=True, extraAVP = {}, msccAvp=None, diamConnection=None):

    # Clear dictionary
    diamPacketDct = {}
    
    # This message has basically hard-coded AVPs...
    diamPacketDct['Origin-Host'] = 'orighost.net'
    diamPacketDct['Origin-Realm'] = 'origrealm.net'

    # One echoed AVP
    if 'Origin-State-Id' in dctRcvd: diamPacketDct['Origin-State-Id'] = dctRcvd['Origin-State-Id'].strip()
    else: diamPacketDct['Origin-State-Id'] = '100'
    
    # Some customer remap the appId value of this message...
    if 'Auth-Application-Id' in dctRcvd: appId = int(dctRcvd['Auth-Application-Id'].strip())
    else: appId = 0
    
    # What to return as a result depends on eventPass
    if int(eventPass): diamPacketDct['Result-Code'] = '2001'
    else:         diamPacketDct['Result-Code'] = '5002'

    # Package and send the diameter packet
    (dctRcvd, extraAVP) = DIAMUTILS.packageSendReceiveDecodeDiameterMessage(path, diamPacketDct, extraAVP, eventPass=True, msgId=280, appId=appId, msccAvp=msccAvp, diamConnection=diamConnection, sendOnlyFlag=True, answerFlag=True)
    
    # Add output if verbose says to
    try:
        if reqDct['verbose'] in ['full', 'high']: pprint.pprint(dctRcvd)
    except:
        pass
    
    # Return post-processed received dictionary
    return 

############################################################################
# Create Capability Exchange message
def createCapabilityExchangeRequest(path = os.getcwd(), eventPass=True, extraAVP = {}, msccAvp=None, diamConnection=None):

    # Clear dictionary
    diamPacketDct = {}

    # This message has basically hard-coded AVPs...
    diamPacketDct['Origin-Host'] = 'orighost.net'
    diamPacketDct['Origin-Realm'] = 'origrealm.net'
    diamPacketDct['Origin-State-Id'] = '100'
    diamPacketDct['Vendor-Id'] = '35838'
    diamPacketDct['Host-IP-Address'] = '1.2.3.4'
    diamPacketDct['Product-Name'] = 'OCS'
    diamPacketDct['Supported-Vendor-Id'] = '100'
    diamPacketDct['Supported-Vendor-Id$1'] = '101'
    diamPacketDct['Supported-Vendor-Id$2'] = '102'
    diamPacketDct['Auth-Application-Id'] = '4'
    diamPacketDct['Firmware-Revision'] = '331320045'
    diamPacketDct['Inband-Security-Id'] = '0'
    
    # Force error if not expecting to pass
    if not eventPass:
        print('*** Adding additional vendor ID to VSA because failure is desired ***')
                
        # Add the default grouped AVP data
        diamPacketDct['Vendor-Specific-Application-Id|Auth-Application-Id'] = '4'
        diamPacketDct['Vendor-Specific-Application-Id|Vendor-Id'] = '10415'
        
        # Add a second one via extraAVP (create if needed)
        if not extraAVP: extraAVP = {}
        if 'add' not in extraAVP: extraAVP['add'] = []
        extraAVP['add'].append('Vendor-Specific-Application-Id|Vendor-Id$2:11610')

    # Package and send the diameter packet
    (dctRcvd, extraAVP) = DIAMUTILS.packageSendReceiveDecodeDiameterMessage(path, diamPacketDct, extraAVP, eventPass=eventPass, msgId=257, appId=0, msccAvp=msccAvp, diamConnection=diamConnection)

    # Add output if verbose says to
    try:
        if reqDct['verbose'] in ['full', 'high']: pprint.pprint(dctRcvd)
    except:
        pass
    
    # Debug output
    #print 'Diameter Capability Exchange Answer (CEA) message fields: ' + str(dctRcvd)

    # Return post-processed received dictionary
    return dctRcvd

############################################################################
# Create Disconnect Peer request
def createDisconnectPeerRequest(path = os.getcwd(), eventPass=True, extraAVP = {}, msccAvp=None, diamConnection=None):

    # Clear dictionary
    diamPacketDct = {}
    
    # This message has basically hard-coded AVPs...
    diamPacketDct['Origin-Host'] = 'orighost.net'
    diamPacketDct['Origin-Realm'] = 'origrealm.net'
    diamPacketDct['Disconnect-Cause'] = '2'

    # Package and send the diameter packet
    (dctRcvd, extraAVP) = DIAMUTILS.packageSendReceiveDecodeDiameterMessage(path, diamPacketDct, extraAVP, eventPass=eventPass, msgId=282, appId=0, msccAvp=msccAvp, diamConnection=diamConnection)
    
    # Add output if verbose says to
    try:
        if reqDct['verbose'] in ['full', 'high']: pprint.pprint(dctRcvd)
    except:
        pass
    
    # Debug output
    #print 'Diameter Disconnect Peer Answer (DPA) message fields: ' + str(dctRcvd)
    
    # Return post-processed received dictionary
    return dctRcvd

############################################################################
# Create Re-Auth Answer
def sendReauthAnswer(dctRcvd = {}, path = os.getcwd(), eventPass=True, extraAVP = {}, msccAvp=None, diamConnection=None, nonSuccessResultCode='5002'):

    #print 'Sending RAA message: ' + str(dctRcvd)
    
    # Clear dictionary
    diamPacketDct = {}
    
    # Use data from the input packet, if it's there, else default the data
    if 'Destination-Host' in dctRcvd: 
                # Copy from input packet 
                diamPacketDct['Origin-Host'] = dctRcvd['Destination-Host'].strip()
                
                # Remove from extraAVP if present
                if 'Origin-Host' in extraAVP: del extraAVP['Origin-Host']
    else: diamPacketDct['Origin-Host'] = 'orighost.net'

    if 'Destination-Realm' in dctRcvd:
                # Copy from input packet 
                diamPacketDct['Origin-Realm'] = dctRcvd['Destination-Realm'].strip()
                
                # Remove from extraAVP if present
                if 'Origin-Realm' in extraAVP: del extraAVP['Origin-Realm']
    else: diamPacketDct['Origin-Realm'] = 'origrealm.net'

    if 'User-Name' in dctRcvd: diamPacketDct['User-Name'] = dctRcvd['User-Name'].strip()
    #else: diamPacketDct['User-Name'] = '16307796141' #In Gx CC request, no User-Name needed in RAA
    
    if 'Rating-Group' in dctRcvd: diamPacketDct['Rating-Group'] = dctRcvd['Rating-Group'].strip()

    #add service-Identifier in RAA , start from 4700, ocs engine looking for this in RAA 
    if 'Service-Identifier' in dctRcvd: diamPacketDct['Service-Identifier'] = dctRcvd['Service-Identifier'].strip()

    if 'Origin-State-Id' in dctRcvd: diamPacketDct['Origin-State-Id'] = dctRcvd['Origin-State-Id'].strip()
    else: diamPacketDct['Origin-State-Id'] = '333'
   
    if 'MtxTrafficRouteData' in dctRcvd: diamPacketDct['MtxTrafficRouteData'] = dctRcvd['MtxTrafficRouteData'].strip()  

    if 'Session-Id' in dctRcvd: diamPacketDct['Session-Id'] = dctRcvd['Session-Id'].strip()
    else: diamPacketDct['Session-Id'] = cd.GySessionIdPrefix + '998023766'
    
    # Some customer remap the appId value of this message...
    if 'Auth-Application-Id' in dctRcvd: 
        appId = int(dctRcvd['Auth-Application-Id'].strip())
    elif 'appId' in dctRcvd: #Gx RAR return appId instead of Auth-Application-Id
        appId = int(dctRcvd['appId'].strip())
    else: appId = 4
    
    # What to send for the result depends on eventPass setting
    if int(eventPass): diamPacketDct['Result-Code'] = '2002'
    else:
        print('EventPass = '+ str(eventPass))
        diamPacketDct['Result-Code'] = nonSuccessResultCode

    # Package and send the diameter packet.  Set sendOnlyFlag parameter so we don't expect to receive anything.  Set answer flag as this is an answer message.
    (dctRcvd, extraAVP) = DIAMUTILS.packageSendReceiveDecodeDiameterMessage(path, diamPacketDct, extraAVP, eventPass=True, msgId=258, appId=appId, msccAvp=msccAvp, diamConnection=diamConnection, sendOnlyFlag=True, answerFlag=True)
    
    # Add output if verbose says to
    try:
        if reqDct['verbose'] in ['full', 'high']: pprint.pprint(dctRcvd)
    except:
        pass
    
    # Return
    return 

############################################################################
# Create Spend Notification Answer
def sendSpendNotificationAnswer(dctRcvd = {}, path = os.getcwd(), eventPass=True, extraAVP = {}, msccAvp=None, diamConnection=None, nonSuccessResultCode='5002'):

    #print 'Sending SNA message: ' + str(dctRcvd)
    
    # Clear dictionary
    diamPacketDct = {}
    
    # Use data from the input packet, if it's there, else default the data
    if 'Destination-Host' in dctRcvd:
                # Copy from input packet 
                diamPacketDct['Origin-Host'] = dctRcvd['Destination-Host'].strip()
                
                # Remove from extraAVP if present
                if 'Origin-Host' in extraAVP: del extraAVP['Origin-Host']
    else: diamPacketDct['Origin-Host'] = 'orighost.net'

    if 'Destination-Realm' in dctRcvd:
                # Copy from input packet 
                diamPacketDct['Origin-Realm'] = dctRcvd['Destination-Realm'].strip()
                
                # Remove from extraAVP if present
                if 'Origin-Realm' in extraAVP: del extraAVP['Origin-Realm']
    else: diamPacketDct['Origin-Realm'] = 'origrealm.net'

    if 'Origin-State-Id' in dctRcvd: diamPacketDct['Origin-State-Id'] = dctRcvd['Origin-State-Id'].strip()
    else: diamPacketDct['Origin-State-Id'] = '333'
   
    if 'MtxTrafficRouteData' in dctRcvd: diamPacketDct['MtxTrafficRouteData'] = dctRcvd['MtxTrafficRouteData'].strip()
   
    if 'Session-Id' in dctRcvd: diamPacketDct['Session-Id'] = dctRcvd['Session-Id'].strip()
    else: diamPacketDct['Session-Id'] = cd.GySessionIdPrefix + '998023766'
    
    # Some customer remap the appId and/or command value of this message...
    if 'Auth-Application-Id' in dctRcvd: 
        # Assume if we get one we get both, since they're both part of the header...
        appId = int(dctRcvd['Auth-Application-Id'].strip())
        msgId = int(dctRcvd['cmd'].strip())
    else:
        # Different vendors map diameter AVPs differently
        if hasattr(CUST, "diameterMessageIds"):
                if 'SNA' in CUST.diameterMessageIds:
                        appId = CUST.diameterMessageIds['SNA'][0]
                        msgId = CUST.diameterMessageIds['SNA'][1]
                else:
                        # use 3GPP defaults
                        appId = 16777302
                        msgId = 8388636
        else:
                # use 3GPP defaults
                appId = 16777302
                msgId = 8388636
    
    # What to send for the result depends on eventPass setting
    if int(eventPass): diamPacketDct['Result-Code'] = '2001'
    else:         diamPacketDct['Result-Code'] = nonSuccessResultCode

    # Package and send the diameter packet.  Set sendOnlyFlag parameter so we don't expect to receive anything.  Set answer flag as this is an answer message.
    (dctRcvd, extraAVP) = DIAMUTILS.packageSendReceiveDecodeDiameterMessage(path, diamPacketDct, extraAVP, eventPass=True, msgId=msgId , appId=appId, msccAvp=msccAvp, diamConnection=diamConnection, sendOnlyFlag=True, answerFlag=True)
    
    # Add output if verbose says to
    try:
        if reqDct['verbose'] in ['full', 'high']: pprint.pprint(dctRcvd)
    except:
        pass
    
    # Return
    return 


############################################################################
# Create Abort Session request
def createAbortSessionRequest(sesionId, path = os.getcwd(), eventPass=True, extraAVP = {}, msccAvp=None, diamConnection=None):

    # Clear dictionary
    diamPacketDct = {}
    
    # This message has basically hard-coded AVPs...
    diamPacketDct['Session-Id'] = sesionId
    diamPacketDct['Origin-Host'] = 'orighost.net'
    diamPacketDct['Origin-Realm'] = 'origrealm.net'
    diamPacketDct['Destination-Realm'] = 'destrealm.net'
    diamPacketDct['Destination-Host'] = 'desthost.net'
    diamPacketDct['Auth-Application-Id'] = '4'

    # Package and send the diameter packet
    (dctRcvd, extraAVP) = DIAMUTILS.packageSendReceiveDecodeDiameterMessage(path, diamPacketDct, extraAVP, eventPass=eventPass, msgId='274', appId=0, msccAvp=msccAvp, diamConnection=diamConnection)
    
    # Add output if verbose says to
    try:
        if reqDct['verbose'] in ['full', 'high']: pprint.pprint(dctRcvd)
    except:
        pass
    
    # Debug output
    #print 'Diameter Disconnect Peer Answer (DPA) message fields: ' + str(dctRcvd)
    
    # Return post-processed received dictionary
    return dctRcvd

############################################################################
# Create Abort Session Answer
def sendAbortSessionAnswer(dctRcvd = {}, path = os.getcwd(), eventPass=True, extraAVP = {}, msccAvp=None, diamConnection=None, nonSuccessResultCode='5002'):

    print('Sending ASA message: ' + str(dctRcvd))

    # Clear dictionary
    diamPacketDct = {}

    # Use data from the input packet, if it's there, else default the data
    if 'Destination-Host' in dctRcvd:
                # Copy from input packet
                diamPacketDct['Origin-Host'] = dctRcvd['Destination-Host'].strip()

                # Remove from extraAVP if present
                if 'Origin-Host' in extraAVP: del extraAVP['Origin-Host']
    else: diamPacketDct['Origin-Host'] = 'orighost.net'

    if 'Destination-Realm' in dctRcvd:
                # Copy from input packet
                diamPacketDct['Origin-Realm'] = dctRcvd['Destination-Realm'].strip()

                # Remove from extraAVP if present
                if 'Origin-Realm' in extraAVP: del extraAVP['Origin-Realm']
    else: diamPacketDct['Origin-Realm'] = 'origrealm.net'

    if 'Origin-State-Id' in dctRcvd: diamPacketDct['Origin-State-Id'] = dctRcvd['Origin-State-Id'].strip()
    else: diamPacketDct['Origin-State-Id'] = '333'

    if 'Session-Id' in dctRcvd: diamPacketDct['Session-Id'] = dctRcvd['Session-Id'].strip()
    else: diamPacketDct['Session-Id'] = cd.GySessionIdPrefix + '998023766'


    # Some customer remap the appId value of this message...
    if 'Auth-Application-Id' in dctRcvd: appId = int(dctRcvd['Auth-Application-Id'].strip())
    else: appId = 0

    # What to send for the result depends on eventPass setting
    if int(eventPass): diamPacketDct['Result-Code'] = '2001'
    else:         diamPacketDct['Result-Code'] = nonSuccessResultCode

    # Package and send the diameter packet.  Set sendOnlyFlag parameter so we don't expect to receive anything.  Set answer flag as this is an answer message.
    (dctRcvd, extraAVP) = DIAMUTILS.packageSendReceiveDecodeDiameterMessage(path, diamPacketDct, extraAVP, eventPass=True, msgId=274 , appId=appId, msccAvp=msccAvp, diamConnection=diamConnection, sendOnlyFlag=True, answerFlag=True)

    # Add output if verbose says to
    try:
        if reqDct['verbose'] in ['full', 'high']: pprint.pprint(dctRcvd)
    except:
        pass
    
    # Return
    return

############################################################################
def main():
    print('in main()')

if __name__ == '__main__':
    main()

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

