#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:41:22
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:40
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:22
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


import os,sys
import optparse
import pretty_print as PRINT
import qa_utils as QAUTILS
import QA_subscriber_management_restv3 as RESTV3
import data_container_defs as MDCDEFS
import subscriber_mgmt_v3 as SUBMAN

restInst = None

def main():
    global restInst

    parser = optparse.OptionParser()
    parser.add_option("-s", "--subscid", action='store', type='int', default=0)
    parser.add_option("-x", "--externalid", action='store', type='string', default=None)
    parser.add_option("-i", "--imsi", action='store', type='string', default=None)
    parser.add_option("-o", "--soid", action='store', type='string', default=None)
    parser.add_option("-w", "--doid", action='store', type='string', default=None)
    parser.add_option("-c", "--goid", action='store', type='string', default=None)
    parser.add_option("-a", "--daccess", action='store', type='string', default=None)
    parser.add_option("-b", "--dexternal", action='store', type='string', default=None)
    parser.add_option("-g", "--groupid", action='store', type='int', default=0)
    parser.add_option("-l", "--level", action='store', type='int', default=1)
    parser.add_option("-t", "--time", action='store', type='string', default=None)
    parser.add_option("-m", "--mdcgw", default="1", help="update by mdc gw")
    parser.add_option("-r", "--restgw", default=None, help="update by REST")
    parser.add_option("-d", "--deviceType", action='store', type='int', default=None)
    parser.add_option("-y", "--status", action='store', type='int', default=None)
    parser.add_option("-v", "--values", action='store', type='string', default=None, help="a comma separated name=value pair list. Ex: firstName=Joe,billingCycle=4011")
    parser.add_option("--nx", dest="newExternalId",action='store', type='string', default=None)
    parser.add_option("--na", dest="newAccessNum",action='store', type='string', default=None)
    parser.add_option("--ol", dest="offerList",action='store', type='string', default=None)
    parser.add_option("--os", dest="offerStartTime",action='store', type='string', default=None)
    parser.add_option("--oe", dest="offerEndTime",action='store', type='string', default=None)
    parser.add_option("--sq", dest="subscQueryType",action='store', type='string', default=None)
    parser.add_option("--sqv", dest="subQueryValue",action='store', type='string', default=None)
    parser.add_option("--dq", dest="devQueryType",action='store', type='string', default=None)
    parser.add_option("--dqv", dest="devQueryValue",action='store', type='string', default=None)
    parser.add_option("--sgq", dest="subGrpQueryType",action='store', type='string', default=None)
    parser.add_option("--mbr", dest="grpMembers",action='store', type='string', default=None)
    (options, args) = parser.parse_args()

    # Get client to perform query
    gatewaysConfig = QAUTILS.getDiameterRestConfig()
    if options.restgw:
        RESTV3.setVersion('REST')
    else:
        RESTV3.setVersion('MDC')
        RESTV3.mtxflags = 1
    QAUTILS.gatewaysConfig = gatewaysConfig
    restInst = QAUTILS.getSubscInterface()

    if options.imsi:
        updateDeviceData(options.imsi, 'Imsi', options.newAccessNum, options.newExternalId, options.deviceType, options.status, options.level, options.time, options.restgw, options.externalid, options.offerList, options.offerStartTime, options.offerEndTime, options.subscQueryType, options.subQueryValue)
    elif options.doid:
        updateDeviceData(options.doid, 'ObjectId', options.newAccessNum, options.newExternalId, options.deviceType, options.status, options.level, options.time, options.restgw, options.externalid, options.offerList, options.offerStartTime, options.offerEndTime, options.subscQueryType, options.subQueryValue)
    elif options.daccess:
        updateDeviceData(options.daccess, 'AccessNumber', options.newAccessNum, options.newExternalId, options.deviceType, options.status, options.level, options.time, options.restgw, options.externalid, options.offerList, options.offerStartTime, options.offerEndTime, options.subscQueryType, options.subQueryValue)
    elif options.dexternal:
        updateDeviceData(options.dexternal, 'ExternalId', options.newAccessNum, options.newExternalId, options.deviceType, options.status, options.level, options.time, options.restgw, options.externalid, options.offerList, options.offerStartTime, options.offerEndTime, options.subscQueryType, options.subQueryValue)

    elif options.soid:
        updateSubscriberData(options.soid, 'ObjectId', options.values, options.newExternalId, options.status, options.level, options.time, options.restgw, options.offerList, options.offerStartTime, options.offerEndTime, options.devQueryType, options.devQueryValue)
    elif options.subscid:
        updateSubscriberData(options.subscid, 'PhoneNumber', options.values, options.newExternalId, options.status, options.level, options.time, options.restgw, options.offerList, options.offerStartTime, options.offerEndTime,  options.devQueryType, options.devQueryValue)
    elif options.externalid:
        updateSubscriberData(options.externalid, 'ExternalId', options.values, options.newExternalId, options.status, options.level, options.time, options.restgw, options.offerList, options.offerStartTime, options.offerEndTime, options.devQueryType, options.devQueryValue)

    elif options.groupid:
        updateGroupData(options.groupid, 'ExternalId', options.values, options.newExternalId, options.status, options.level, options.time, options.restgw, options.offerList, options.offerStartTime, options.offerEndTime, options.subGrpQueryType, options.subscQueryType, options.grpMembers)
    elif options.goid:
        updateGroupData(options.goid, 'ObjectId', options.values, options.newExternalId, options.status, options.level, options.time, options.restgw, options.offerList, options.offerStartTime, options.offerEndTime, options.subGrpQueryType, options.subscQueryType, options.grpMembers)
    else:
        print('nothing has been updated!!!!!!!!!!!')
		 
def updateGroupData(queryValue, queryType, newValues, newExternalId, status, level, time, rest, offerList, offerStartTime, offerEndTime, subGrpQueryType, subscQueryType, grpMembers):
    print("updating group with ", queryType, "=", queryValue)

    gName = None
    tier = None
    administrator_id=None
    notificationPreference=None
    timeZone=None
    billingCycle=None
    attr=None
    billCycleMdc=None

    if newValues is not None:
        uParames = newValues.split(',')
        if len(uParames) < 1:
            print("missing new values.")
            print("the new values should be a string with name=value pairs separated by ','")
            return -1
        else :
            for pair in uParames :
                name=pair.split('=')[0]
                val=pair.split('=')[1]
                if name.lower() == 'name' :
                    gName = val
                if name.lower() == 'tier' :
                    tier = val
                elif name.lower() == 'timezone' :
                    timeZone = val
                if name.lower() == 'administrator_id' :
                    administrator_id = val
                elif name.lower() == 'billingcycle' :
                    vals = val.split('/')
                    if len(vals) > 1 :
                        tId = vals[0]
                        offset = vals[1]
                    else :
                        tId = vals[0]
                        offset = None
                    # create billCycle MDC
                    billCycleMdc = SUBMAN.newBillingCycleData(tId, offset)

    retCode = RESTV3.modifyGroup(restInst, queryValue, groupQueryType=queryType, now=time, externalId=newExternalId,
                                  name=gName, tier=tier, administrator_id=administrator_id, timeZone=timeZone, 
                                  status = status, billingCycle=billCycleMdc)

    if offerList is not None :
        ol = offerList.split(',')
        print("subscribe to offer: ",ol) 
        result = RESTV3.groupSubscribeToOffer(restInst, queryValue, ol, offerStartTime, offerEndTime, queryType=queryType, now=time)
        print(result)

    if grpMembers is not None :
        gm = grpMembers.split(',')
        if subscQueryType is not None and subGrpQueryType is not None :
            print("too many parames.  Cannot add subscribers and subgroups at the same time.")
        elif subscQueryType is not None :
            result = RESTV3.addGroupMembership(restInst, queryValue, groupQueryType=queryType, now=time, 
                                     subscribers=gm, subQueryType=subscQueryType)
        elif subGrpQueryType is not None :
            result = RESTV3.addGroupMembership(restInst, queryValue, groupQueryType=queryType, now=time, 
                                     subGroups=gm,subGroupQueryType=subGroupQueryType)
        else :
            print("missing member query type.")

    print(retCode)

def updateSubscriberData(queryValue, queryType, newValues, newExternalId, status, level, time, rest, offerList, offerStartTime, offerEndTime, devQueryType, devQueryValue):
    print("updating subscriber with ", queryType, "=", queryValue)

    firstName = None
    lastName = None
    contactEmail=None
    contactPhoneNumber=None
    notificationPreference=None
    timeZone=None
    billingCycle=None
    attr=None
    language=None
    billCycleMdc=None

    if newValues is not None:
        uParames = newValues.split(',')
        if len(uParames) < 1:
            print("missing new values.")
            print("the new values should be a string with name=value pairs separated by ','") 
            return -1
        else :
            for pair in uParames :
                name=pair.split('=')[0]
                val=pair.split('=')[1]
                if name.lower() == 'firstname' :
                    firstName = val
                if name.lower() == 'lastname' :
                    lastName = val
                elif name.lower() == 'timezone' :
                    timeZone = val     
                if name.lower() == 'contactemail' :
                    contactEmail = val
                if name.lower() == 'contactphonenumber' :
                    contactPhoneNumber = val
                elif name.lower() == 'billingcycle' :
                    vals = val.split('/')
                    if len(vals) > 1 :
                        tId = vals[0]
                        offset = vals[1]
                    else :
                        tId = vals[0]
                        offset = None
                    # create billCycle MDC
                    billCycleMdc = SUBMAN.newBillingCycleData(tId, offset)
                elif name.lower() == 'language' :
                    language = val     

    retCode = RESTV3.modifySubscriber(restInst, queryValue, queryType, now=time, externalId=newExternalId, 
                                        firstName=firstName, lastName=lastName, contactEmail=contactEmail, 
                                       contactPhoneNumber=contactPhoneNumber, timeZone=timeZone, billingCycle=billCycleMdc, 
                                       language=language, status=status)

    if offerList is not None :
        ol = offerList.split(',')
        print("subscribe to offer: ", ol)
        result = RESTV3.subscribeToOffer(restInst, queryValue, ol, offerStartTime, offerEndTime, queryType=queryType, now=time)
        print(result)

    if devQueryType is not None :
        result = RESTV3.addDeviceToSubscriber(restInst, queryValue,subQueryType=queryType, deviceId=devQueryValue, 
                                   devQueryType=devQueryType, now=time, isCreateDevice=False)

    print(retCode)

def updateDeviceData(queryValue, queryType, newAccessNum, newExternalId, newDeviceType, status, level, time, rest, externalid, offerList, offerStartTime, offerEndTime, subscQueryType, subQueryValue):
    print("updating device with ", queryType, "=", queryValue)
    if newDeviceType == 0 :
        newDeviceType = None
    attr=None;        
    retCode = RESTV3.modifyDevice(restInst, queryValue, queryType, attr=attr, deviceType=newDeviceType, externalId=newExternalId, status=status,  now=time)
    #retCode = restInst.deviceModify(queryType, queryValue, attr=attr, deviceType=newDeviceType, externalId=newExternalId, now=time)

    if offerList is not None :
        ol = offerList.split(',')
        print("subscribe to offer: ", ol)
        result = RESTV3.devicePurchaseOffer(restInst, queryValue, ol, offerStartTime, offerEndTime, queryType=queryType, now=time)
        print(result)

    if subscQueryType is not None :
        result = RESTV3.addDeviceToSubscriber(restInst, subQueryValue, subQueryType=subscQueryType, 
                        deviceId=queryValue, devQueryType=queryType, now=time, isCreateDevice=False)

    print(retCode)

if __name__ == '__main__':
   main()
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

