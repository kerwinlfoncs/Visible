# Script to manage execution of a test suite per customer.  Also optionally manage test environment and testing type

# Define usage string
_usage="usage: go_restart_p2.sh <customer> <test suite>" 

# Keep track of where we started
_pwd=`pwd`
echo "$_pwd"
# Set variables, as this passed get.sh so they're good to go!
# May need to use defaults if nothing passed in
if [ "$1" != "" ]
then
	_cust="$1"
else
	_cust="QA"
fi

#check the notification framework
#checkNotificationSetup.py -H $CatalogBuilderHost 

# Get test suite name from argument
_testSuite="$2"
_gateway="$3"
if [ "$4" != "" ]
then
    _sba="$4"
fi

# Check if customer directory exists
if [ ! -d "$QADIR/$_cust/Configuration" ]
then
	echo "ERROR:  directory $QADIR/$_cust/Configuration does not exist."
	exit 1
fi

# Go to customer specific directory
cd $QADIR/$_cust/Configuration

if [[ $_testSuite = ccf* ]] ; then
    echo "setting up a CCF run for /home/mtx/workspace/trunk/MTXQA/QA/Configuration/dataFile "
    #cp dataFile.CCF dataFile
    source dataFile.CCF
elif [[ $_testSuite = cch_tax* ]] ; then
    echo "setting up a CCH Tax run for /home/mtx/workspace/trunk/MTXQA/QA/Configuration/dataFile "
    source dataFile.cchtax

else
    echo "setting up a DIAM run for /home/mtx/workspace/trunk/MTXQA/QA/Configuration/dataFile "
    #cp dataFile.QA dataFile
    source dataFile.QA
    
fi


# Retrieve customer-specific data (if it exists)
#if [ -f dataFile ]
#then
#	source dataFile
#fi

# Go back to whence we came from!
cd $_pwd >/dev/null

# Set price file
retrieved_file=mtx_pricing_${pricingdomain}.xml

# Now need to get the IP address of the machine I'm running on, change the last nibble to 224, 
# then update the multi-cast address in create_config.info, and finally run create_config.py
sh set_multicast.sh

# Return to original directory
cd $_pwd >/dev/null

# configure engine
configure_engine.py


# clean shared dir
if [ "A$MTX_SHARED_DIR" != "A" ]; then
    run_cmd_on_engine.py 1 "rm -rf $MTX_SHARED_DIR/*"
else
   echo "env MTX_SHARED_DIR = $MTX_SHARED_DIR ..... is not set!"
   exit
fi

#if [ "$_testSuite" != "5g_base" ] && [ "$_testSuite" != "5g_vtime" ]; then
# Restart blade
restart_server
#fi


# Wait for the engine to be ready
echo "Wait for engine to be ready"
waitForEngineReady.py

if [ "$_testSuite" = "5g_base" ] || [ "$_testSuite" = "5g_vtime" ]
then
    ssh $_sba "/home/mtx/workspace/trunk/MTXQA/QA/Tests_5g/mtx_tests_sba/mtx_test_docker_scripts/docker_stop_allimages"
    ssh $_sba "nohup /home/mtx/workspace/trunk/MTXQA/QA/Tests_5g/mtx_tests_sba/mtx_test_docker_scripts/gosba.py -p" &
fi

# load cch data
if [[ $_testSuite = cch_tax* ]] ; then
    echo "going to load cch tax data file "
    load_tax.py -f $QADIR/QA/Configuration/cch_tax/mtx_tax_compiled.zip -v;
fi

# Get pricing from the admin workspace
echo "Retrieving domain $retrieved_file from host $CatalogBuilderHost:$CatalogBuilderPort using username $CatalogUserName and password $CatalogPassword in $pricingdomain"
$MTX_BIN_DIR/get_pricing.py $retrieved_file http://$CatalogBuilderHost:$CatalogBuilderPort/matrixx/data/admin/compile  $CatalogUserName $CatalogPassword $pricingdomain > _tmp

#### added for blade env we need to have the pricing file in /tmp/PRICING on load04 and blade1 of a processing cluster
# Only try to create if the directory doesn't exist (avoid error message)
if [ ! -d /tmp/PRICING ]
then
	mkdir /tmp/PRICING
fi
cp $retrieved_file /tmp/PRICING

# Load pricing
echo "Loading retrieved pricing data"
QA_load_pricing.py -f $retrieved_file >> _tmp

# Check if we succeeded
_x=`grep SUCCEEDED _tmp | wc -l`
if [ $_x -eq 0 ]
then
        # Failed
        echo "Loading of domain $pricingdomain failed.  Last 10 lines of debug log are:"
        tail -10 $MTX_LOG_DIR/mtx_debug.log
        echo -e "\n\n"
        echo "Last 10 lines of price loader log file `pwd`/price_loader_1_stderr.log are:"
        tail -10 price_loader_1_stderr.log
        echo -e "Exiting\n\n"
	exit 1
fi

# Remove temp file
rm _tmp

# Go to the main test driver directory
if [ "$_testSuite" = "5g_base" ] || [ "$_testSuite" = "5g_vtime" ]
then
    cd $QADIR/$_cust/Tests_5g/main_tests_driver
else
    cd $QADIR/$_cust/Tests/main_tests_driver 
fi

# Reset where we want to go back to
_pwd=`pwd`

# Prepare directory
echo "Prepare `pwd`/$_cust directory"
_resDir=_results
# create archive directories
if [ ! -d archieved_results ]
then
	echo "Creating archive directory"
	mkdir archieved_results
        mkdir archieved_results/$_testSuite$_resDir >/dev/null
elif [ ! -d archieved_results/$_testSuite$_resDir ]
then 
        echo "Creating archieved_results/$_testSuite$_resDir directory"
        mkdir archieved_results/$_testSuite$_resDir
fi

# Should need to create customer directory...
if [ ! -d $_cust ]
then
	echo "Creating $_cust directory"
	mkdir $_cust
        mkdir $_cust/$_testSuite$_resDir >/dev/null
elif [ ! -d $_cust/$_testSuite$_resDir ]
then 
        echo "Creating $_cust/$_testSuite$_resDir directory"
        mkdir $_cust/$_testSuite$_resDir
else
	# Clean up customer directory
	echo "archieve old test results"
	mv $_cust/$_testSuite$_resDir/* archieved_results/$_testSuite$_resDir 
fi

# Return to parent directory
cd $_pwd >/dev/null

# Create list of tests to run.  Use the customer specific getlist.sh script
echo "Getting test list for suite $_testSuite"
sh getlist.sh $_testSuite 
_testCount=`wc -l allTestsList | cut -f1 -d" "`
echo "Will execute $_testCount tests"
# For now, copy the test list file to the parent directory.  Need to fix so it can run locally...
#cp allTestsList ..

# Remove results files from all over the place...
find .. -name Summary*.txt|xargs rm >/dev/null 2>&1
find .. | grep results | grep -v main_tests_driver | grep -v svn | xargs rm >/dev/null 2>&1

# Finally!  Run the suite of tests
echo "Start test execution"
./startall.py -k 1 -y $_gateway > _out 2>&1

# Copy results to child directory (so not overwritten by next child run)
echo "Moving run results to $_cust directory"
mv _out $_cust/$_testSuite$_resDir
mv results/* $_cust/$_testSuite$_resDir
rm allTestsList

# Grep notificaiton error logs
echo "======== Getting notification error logs ==========="
echo "======== notification server : " $CatalogBuilderHost
#getNotificationErrorLog.py -H $CatalogBuilderHost -f $_cust/$_testSuite$_resDir

# send email to notify regression run is completed
#mail -s "regression run is completed" xxx.yyyy@matrixx.com  < /dev/null

# All done!
echo "All Done!!"

