#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:38
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:18
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:01
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
import os
import optparse
import re
import shutil
import sys
import time
import subprocess

confDir = None

def main():
    global confDir

    binDir = os.path.abspath(os.path.expandvars(os.getenv('MTX_BIN_DIR', '.')))
    confDir = os.path.abspath(os.path.expandvars(os.getenv('MTX_CONF_DIR', '.')))
    args = sys.argv[1:]
    argStr = ''
    priceFileName = 'mtx_pricing.xml'
    revert = False
    if args is not []:
        for arg in range(len(args)):
            argStr += ' ' + args[arg]
            if args[arg] == '-f':
                priceFileName = args[arg + 1]
            if args[arg] == '--revert' or args[arg] == '-r':
                revert = True
    cmd = 'python3 ' + binDir + '/load_pricing.py' + argStr
    subprocess.call(cmd, shell=True)

    newPricingXmlAbsFileName = os.path.abspath(priceFileName)

    if not revert:
        if (not os.path.exists(newPricingXmlAbsFileName)):
            print('************************************************')
            print('ERROR: The specified pricing file (' + newPricingXmlAbsFileName + ') does not exist.')
            print('current dir - ' + os.path.abspath('.'))
            print('************************************************')
            sys.exit(1)

        # build up event type tree for later hierarchy traversing in outputting events
        createEventTypeTree(newPricingXmlAbsFileName)

        # parse config file and save system time zone
        confDir = os.path.abspath(os.path.expandvars(os.getenv('MTX_CONF_DIR', '.')))
        configFileName = confDir + '/mtx_config.xml'
        if (os.path.exists(configFileName)):
            saveTimeZone(configFileName)
        else:
            print('Failure saving system time zone!')
            os.putenv("TZ", 'ETC/Utc')

    sys.exit(0)

def createEventTypeTree(priceFileName):
    global confDir

    eventTypeStartPattern = re.compile(r'.*<event_types>.*')
    eventTypeEndPattern = re.compile(r'.*</event_types>.*')
    try:
        priceFile = open(priceFileName, 'r')
        eventTypeList = []
        hit = False 
        while 1:
            line = priceFile.readline()
            if not line:
                break
            if eventTypeStartPattern.match(line):
                hit = True
            if hit:
                eventTypeList.append(line)
            if eventTypeEndPattern.match(line):
                break

        priceFile.close()
        eventTypeStr = "".join([x for x in eventTypeList])
        eventTypeFile = open(confDir + '/eventTypes', 'w')
        eventTypeFile.write(eventTypeStr)
        eventTypeFile.close()

    except IOError:
        eventTypeFile = open(confDir + '/eventTypes', 'w')
        eventDct = {'1':('usage', None), '2':('recurring', None), '3':('first usage', None),\
            '4':('purchase', None), '5':('cancel', None), '6':('balance adjust', None), '7':('balance topup', None),\
            '8':('notification', None)}
        eventTypeFile.write(str(eventDct))
        eventTypeFile.close()

def saveTimeZone(configFileName):
    systemTimeZonePattern = re.compile(r'.*<system_time_zone_id>.*')
    try:
        configFile = open(configFileName, 'r')
        while 1:
            line = configFile.readline()
            if not line:
                break
            if systemTimeZonePattern.match(line):
                removeTagPattern = re.compile(r'<.*?>')
                timeZone = removeTagPattern.sub('', line)
                stripSpacesPattern = re.compile(r'\s+')
                timeZone = stripSpacesPattern.sub('', timeZone)
                qaDir = os.getenv("QADIR")
                timeZoneFileName = qaDir + '/Common/timeZone'
                cmd = 'echo "' + timeZone + '" > ' + timeZoneFileName
                subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
                break

        configFile.close()

    except IOError:
        cmd = 'echo "ETC/Utc" > timeZoneFileName'
        subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)

if __name__ == '__main__':
    main()
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
