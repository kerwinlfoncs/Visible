## before you start make sure you have the F5's IP for  VS of P1 or P2 IP
#HP1 F5 has 2 : 10.10.115.216 
#There are two VS  on lb01

#    .  P1: 10.10.115.216 (three processing blades: bld01,02, 03)
#    .  P2: 10.10.115.217 (three processing blades: bld04,05, 06)


sudo yum -y install tomcat

sudo /etc/init.d/tomcat6 start
sudo chkconfig tomcat6 on
#Install the Proxy Server

#edit /etc/sysconfig/tomcat
# Where your java installation lives
#JAVA_HOME="/usr/lib/jvm/java"
#JAVA_OPTS="-Drsgateway.engine.address=localhost -Drsgateway.engine.port=4070 -DMTX_LOG_DIR=/var/log/tomcat




#) Properties file should be written to /var/run/mtx
#/var/run/mtx/gateway_proxy.properties

#Start the proxy server  FIRST!!!!!!!!!!!
#	/opt/mtx/bin/gateway_proxy.sh
# Test using test_rest_interactive.py
#) Log file and notification log file written to /var/log/mtx

#Restart tomcat6
#curl -s http://localhost:8080/rsgateway/data/v3/subscriber/query/ExternalId/1
#
#war file in /var/lib/tomcat/webapp
#proxy status
gateway_proxy.sh status

