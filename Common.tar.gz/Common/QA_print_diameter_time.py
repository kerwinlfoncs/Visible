#!/usr/bin/python3
#=============================================================================
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:41:21
#
# Copyright 2010,2011,2012, Matrixx Software, Inc. All rights reserved.
#
#-----------------------------------------------------------------------------
#
# @file
# @date       $Date: 2012-01-07 20:58:52 -0800 (Sat, 07 Jan 2012) $
#
# $Id: print_diameter_time.py 5791 2012-01-08 04:58:52Z $
#
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:37:02
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:19
#
#=============================================================================
#

# from builtins import str
# from builtins import str
import common_functions as common_functions
import diameter as DIAM
import time
import optparse

################################################################################


def getTimeLoop():
    while True:
        myQuestion = \
            'What time value(s) (yyyy-mm-ddThh:mm:ss) do you want to convert?'
        timeInput = str(common_functions.getAnswer(myQuestion))
        getTimeField(timeInput)
        common_functions.removeQuestion(myQuestion)
    return

def getTimeField(timeInput):
        # Convert the time into the correct time value.
        values = timeInput.split(',')
        isValid = False
        for value in values:
            value = value.strip()
            parts = value.split('T')
            # First part is the date
            dateParts = parts[0].split('-')
            if (len(dateParts) != 3):
                print('Error: expecting a date: 3 numbers separated by ' + \
                    '-. Found ' + parts[0] + ' in ' +  value + ' - Try again.')
                isValid = False
                break
            yearVal = int(dateParts[0].strip())
            monthVal = int(dateParts[1].strip())
            dayVal = int(dateParts[2].strip())
            if ((yearVal < 1900) or (yearVal > 2036)):
                print('Error: year value range is 1900 to 2036. Found ' + \
                    str(yearVal) + ' in ' +  value + ' - Try again.')
                isValid = False
                break
            if ((monthVal < 1) or (monthVal > 12)):
                print('Error: month value range is 1 to 12. Found ' + \
                    str(monthVal) + ' in ' +  value + ' - Try again.')
                isValid = False
                break
            if ((dayVal < 1) or (dayVal > 31)):
                print('Error: day value range is 1 to 31. Found ' + \
                    str(dayVal) + ' in ' +  value + ' - Try again.')
                isValid = False
                break
            # The second part is the time
            timeParts = ['0', '0', '0']
            if (len(parts) == 2):
                timeParts = parts[1].split(':')
            if (len(timeParts) != 3):
                print('Error: expecting a time: 3 numbers separated by ' + \
                    ':. Found ' + parts[1] + ' in ' +  value + ' - Try again.')
                isValid = False
                break
            hourVal = int(timeParts[0].strip())
            minuteVal = int(timeParts[1].strip())
            secondVal = int(timeParts[2].split('.')[0])
            print("timeParts=",timeParts, " minuteVal=", minuteVal)
            if ((hourVal < 0) or (hourVal > 23)):
                print('Error: hour value range is 0 to 23. Found ' + \
                    str(hourVal) + ' in ' +  value + ' - Try again.')
                isValid = False
                break
            if ((minuteVal < 0) or (minuteVal > 59)):
                print('Error: minute value range is 0 to 59. Found ' + \
                    str(minuteVal) + ' in ' +  value + ' - Try again.')
                isValid = False
                break
            if ((secondVal < 0) or (secondVal > 59)):
                print('Error: second value range is 0 to 59. Found ' + \
                    str(secondVal) + ' in ' +  value + ' - Try again.')
                isValid = False
                break
            secondsSinceEpoch = int(time.mktime((yearVal, monthVal, dayVal,
                hourVal, minuteVal, secondVal, 0, 1, 0)))
            # NOTE: we need to take into account the timezone.
            # Make this a UTC time by adjusting for the timezone
            # TODO What about DST? I think we always want it set to 0 in the
            # mktime call above.
            secondsSinceEpoch -= time.timezone
            diameterTime = DIAM.convertUnixTimeToDiameterTime(secondsSinceEpoch)
            # Now print this
            print('  ' + str(value) + ' --> ' + str(diameterTime))
            return str(diameterTime)

################################################################################

def main():
    parser = optparse.OptionParser()
    parser.add_option("-t","--timeC", action = "store", default = None, type = "string", help = "input the time as ex:2012-02-01T12:30:33")
    (options, args) = parser.parse_args()
    if options.timeC:
        print("Converting Time ==>", options.timeC)
        getTimeField(options.timeC)
    else:
        getTimeLoop()

################################################################################

if __name__ == '__main__':
    main()

