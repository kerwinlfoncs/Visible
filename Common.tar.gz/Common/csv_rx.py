#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:36:17
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:36:17
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:36:16
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
import copy, time, sys, socket, parser, pprint, re, random, string, os, pytz, itertools , decimal
import csv_prim as PRIM

#==========================================================
# Define RX list of parameters
rxDescriptionParams = []
rxDescriptionParams.append(('mediaComponentId','Media-Component-Number'))
rxDescriptionParams.append(('afApplicationId','AF-Application-Identifier'))
rxDescriptionParams.append(('mediaType','Media-Type'))
rxDescriptionParams.append(('maxRequestedBitrateUpload','Max-Requested-Bandwidth-UL'))
rxDescriptionParams.append(('maxRequestedBitrateDownload','Max-Requested-Bandwidth-DL'))
rxDescriptionParams.append(('maxSupportedBitrateUpload','Max-Supported-Bandwidth-UL'))
rxDescriptionParams.append(('maxSupportedBitrateDownload','Max-Supported-Bandwidth-DL'))
rxDescriptionParams.append(('minDesiredBitrateUpload','Min-Desired-Bandwidth-UL'))
rxDescriptionParams.append(('minDesiredBitrateDownload','Min-Desired-Bandwidth-DL'))
rxDescriptionParams.append(('minRequestedBitrateUpload','Min-Requested-Bandwidth-UL'))
rxDescriptionParams.append(('minRequestedBitrateDownload','Min-Requested-Bandwidth-DL'))
rxDescriptionParams.append(('extendedMaxRequestedBitrateUpload','Extended-Max-Requested-BW-UL'))
rxDescriptionParams.append(('extendedMaxRequestedBitrateDownload','Extended-Max-Requested-BW-DL'))
rxDescriptionParams.append(('extendedMaxSupportedBitrateUpload','Extended-Max-Supported-BW-UL'))
rxDescriptionParams.append(('extendedMaxSupportedBitrateDownload','Extended-Max-Supported-BW-DL'))
rxDescriptionParams.append(('extendedMinDesiredBitrateUpload','Extended-Min-Desired-BW-UL'))
rxDescriptionParams.append(('extendedMinDesiredBitrateDownload','Extended-Min-Desired-BW-DL'))
rxDescriptionParams.append(('extendedMinRequestedBitrateUpload','Extended-Min-Requested-BW-UL'))
rxDescriptionParams.append(('extendedMinRequestedBitrateDownload','Extended-Min-Requested-BW-DL'))
rxDescriptionParams.append(('flowStatus','Flow-Status'))
rxDescriptionParams.append(('prioritySharingFlag','Priority-Sharing-Indicator'))
rxDescriptionParams.append(('preemptionCapability','Pre-emption-Capability'))
rxDescriptionParams.append(('preemptionVulnerability','Pre-emption-Vulnerability'))
rxDescriptionParams.append(('rtcpSenderBitrate','RS-Bandwidth'))
rxDescriptionParams.append(('rtcpReceiverBitrate','RR-Bandwidth'))
rxDescriptionParams.append(('codecDataList','Codec-Data'))
rxDescriptionParams.append(('sharingKeyDownload','Sharing-Key-DL'))
rxDescriptionParams.append(('sharingKeyUpload','Sharing-Key-UL'))
rxDescriptionParams.append(('contentVersion','Content-Version'))

rxSubComponentParams = []
rxSubComponentParams.append(('scFlowId','Flow-Number'))
rxSubComponentParams.append(('scFlowDescriptionList','Flow-Description'))
rxSubComponentParams.append(('scFlowStatus','Flow-Status'))
rxSubComponentParams.append(('scFlowUsage','Flow-Usage'))
rxSubComponentParams.append(('scMaxRequestedBitrateUpload','Max-Requested-Bandwidth-UL'))
rxSubComponentParams.append(('scMaxRequestedBitrateDownload','Max-Requested-Bandwidth-DL'))
rxSubComponentParams.append(('scExtendedMaxRequestedBitrateUpload','Extended-Max-Requested-BW-UL'))
rxSubComponentParams.append(('scExtendedMaxRequestedBitrateDownload','Extended-Max-Requested-BW-DL'))
rxSubComponentParams.append(('scAfSignallingProtocol','AF-Signalling-Protocol'))
rxSubComponentParams.append(('scTosTrafficClass','ToS-Traffic-Class'))

# Define data to hold array of RX information
rxMedia = []

def buildRxMediaData(lclDCT):
        global rxMedia
        
        interface='rx'
        service='data'
        avp = 'Media-Component-Description$' + str(len(rxMedia))
        listAVPData = {}
        listAVPData[interface] = {}
        listAVPData[interface][service] = {}
        listAVPData[interface][service][avp] = {}
        listAVPData[interface][service][avp]['topLevel'] = {}
        listAVPData[interface][service][avp]['message'] = 'initial|interim'
        listAVPData[interface][service][avp]['AVP'] = []
        
        # Add elements to the AVP list
        for entry in rxDescriptionParams:
                # Separate entry
                parameter = entry[0]
                lclAvp = entry[1]
                
                # If parameter is None, then skip
                if str(lclDCT[parameter]).lower() == 'none': continue
                
                # Add entry
                listAVPData[interface][service][avp]['topLevel'][lclAvp] = lclDCT[parameter]
        
        # Now build media Sub-component data.
        # Walk sub-component list to see if anything defined.
        listElements = {}
        for i in range(len(lclDCT['scFlowUsage'])):
                # Process each AVP
                for entry in rxSubComponentParams:
                        # Separate entry
                        parameter = entry[0]
                        lclAvp = entry[1]
                        
                        # If parameter is None, then skip
                        if not lclDCT[parameter]: continue
                        
                        # If length of this parameter is not the same as the key parameter, or the list entry is empty, then also skip
                        if len(lclDCT[parameter]) <= i or str(lclDCT[parameter][i]).lower() == 'none': continue
                        
                        # Add element
                        listElements['Media-Sub-Component$' + str(i) + '|' + lclAvp] = str(lclDCT[parameter][i])
                
                # Add if anything added
                if len(listElements):
                        listAVPData[interface][service][avp]['AVP'].append(copy.deepcopy(listElements))
                        listElements = {}
        
        # Add to RX global data
        rxMedia.append(copy.deepcopy(listAVPData))
        
# Add RX data to extraAVP               
def addRxMediaData(extraAVP, lclDCT, options=None):
        global rxMedia
        
        interface='rx'
        service='data'
        
        # Now add these to the overall list to process
        for i in range(len(rxMedia)): PRIM.addListAVPs(rxMedia[i], extraAVP, lclDCT, service, options, interface)
        
        # Clear RX global data
        rxMedia = []
