
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:49
#
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:28
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:08
import smtpd, sys
import asyncore

class CustomSMTPServer(smtpd.SMTPServer):
    
    def process_message(self, peer, mailfrom, rcpttos, data):
        print('Receiving message from:', peer)
        print('Message addressed from:', mailfrom)
        print('Message addressed to  :', rcpttos)
        print('Message length        :', len(data))
        print('Message               :', data)
        return

host='127.0.0.1'
port=1025

print('Listening on host=', host, ', port=', port)

server = CustomSMTPServer((host, port), None)

asyncore.loop()

