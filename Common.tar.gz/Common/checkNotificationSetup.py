#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:37
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:17
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:00
#===============================================================================
#
# Copyright 2011-2017, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


import optparse
import os, sys
import qa_utils as QAUTILS
import fcntl
import get_config as CONFIG

#==========================================================

def main():
    # Process input args
    (options, args) = CONFIG.initializeTest()
    if not len(sys.argv) > 1 :
        print(options)
        exit()

    host = options.notificationHost
    print("Checking notification setup on " + host)

    activemq = QAUTILS.runCmd('ssh ' + host + ' "ps -ef | grep activemq | grep -v grep | wc -l"')
    if activemq != "1" :
       print("WARNING === activeMQ is not running !!!!!")

    notifier = QAUTILS.runCmd('ssh ' + host + ' "ps -ef | grep notifier | grep -v grep | wc -l"')
    if notifier != "1" :
       print("WARNING === The notifier is not running !!!!!")

    if activemq == "1" and notifier == "1" :
       print("========= All notification components are running OK ==============")
       QAUTILS.runCmd('ssh ' + host + ' "echo > /var/log/mtx/mtx_notifier.log"')
 
if __name__ == '__main__':
    main()

#===============================================================================
#
# Copyright 2011-2017, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
