# Make sure the python path includes the current directory
export PYTHONPATH=.:$PYTHONPATH

# Invoke the command, passing through all inputs
./GatherDiamFromLogs.py $@

