#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:35:49
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:35:48
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:35:48
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
# from builtins import str
# from builtins import str
import sys
import QA_subscriber_management_restv3 as REST_UTIL
import csv_qa as CSVQA
import csv_data as DATA
import csv_prim as PRIM

#==========================================================
def CmdPrice_pricingqueryrole(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.pricingQueryRole(RESTInst, lclDCT['externalId'], routingType=lclDCT['routingType'], routingValue=lclDCT['routingValue'], eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingqueryrolelist(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.pricingQueryRoleList(RESTInst, routingType=lclDCT['routingType'], routingValue=lclDCT['routingValue'], eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingquerycontract(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.pricingQueryContract(RESTInst, lclDCT['elementId'], routingType=lclDCT['routingType'], routingValue=lclDCT['routingValue'], eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingqueryeventtype(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.pricingQueryEventType(RESTInst, queryValue=lclDCT['elementId'], eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingqueryeventtypelist(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.pricingQueryEventTypeList(RESTInst, eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingqueryratetag(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.pricingQueryRateTag(RESTInst, queryValue=lclDCT['elementId'], eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingqueryratetaglist(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.pricingQueryRateTagList(RESTInst, eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingquerycatalogitem(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        if not lclDCT['useCache']:        retCode = REST_UTIL.pricingQueryCatalogItem(RESTInst, queryValue=lclDCT['offerId'][0], queryType=lclDCT['offerQueryType'], eventPass=lclDCT['eventPass'])
        else:                   retCode = REST_UTIL.pricingCacheQueryCatalogItem(RESTInst, queryValue=lclDCT['offerId'][0], queryType=lclDCT['offerQueryType'], eventPass=lclDCT['eventPass'])
        
        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingquerycatalogitemlist(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        if not lclDCT['useCache']:        retCode = REST_UTIL.pricingQueryCatalogItemList(RESTInst, eventPass=lclDCT['eventPass'])
        else:                   retCode = REST_UTIL.pricingCacheQueryCatalogItemList(RESTInst, eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingquerystatus(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.pricingQueryStatus(RESTInst, eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingqueryofferlist(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.pricingQueryOfferList(RESTInst, eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])

        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingqueryoffer(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # ** Now work on offers.  Can have two parameters to specify this.  Can buy by all offers, external ID, or catalog ID.  Can by legacy product ID or current catalog ID.
        # ** More difficult than it should be...
        (catalogItemId,offerId) = PRIM.processOffers(lclDCT['offerId'], lclDCT['subOfferId'], lclDCT['offerIsExternal'], lclDCT['offerIsCatalog'], lclDCT['allOffers'])
        
        # If no offers specified, then this is an error
        if not offerId: sys.exit('ERROR: issued subscriber purchase offer command but did not specify any offers (offerId or subOfferId parameters)')
        
        # Execute primitive
        retCode = REST_UTIL.pricingQueryOffer(RESTInst, offerId[0], version=lclDCT['elementId'], queryType=lclDCT['offerQueryType'], eventPass=lclDCT['eventPass'], useCache=lclDCT['useCache'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])

        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingquerybalancelist(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.pricingQueryBalanceList(RESTInst, eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])

        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingquerybalanceclasslist(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.pricingQueryBalanceClassList(RESTInst, eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])

        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingquerybalanceclass(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.pricingQueryBalanceClass(RESTInst, queryValue=lclDCT['balanceClassId'], eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])

        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingquerybalance(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.pricingQueryBalance(RESTInst, lclDCT['balanceId'], lclDCT['balanceQueryType'], eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])

        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingquerylifecycle(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Here's a case where we don't want to translate the value...  So translate back
        for key in list(DATA.objectTypeMapping.keys()):
                if DATA.objectTypeMapping[key] == lclDCT['objectType']:
                        objectType = key
                        break
        else: sys.exit('ERROR: CmdPrice_pricingquerylifecycle objectType value of ' + str(lclDCT['objectType']) + ' not valid.  Must be in ' + str(DATA.objectTypeMapping))
        
        # Execute primitive
        retCode = REST_UTIL.pricingQueryLifecycle(RESTInst, objectType, eventPass=lclDCT['eventPass'], useCache=lclDCT['useCache'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])

        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingqueryservicetype(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Hard-code service IDs from serviceId name.  Really should make this custom config...
        # Should translate all files from admin/ServiceTypes pricing directory...
        if lclDCT['serviceId'].lower() == 'data': lclId = 2
        elif  lclDCT['serviceId'].lower() == 'voice': lclId = 3
        elif  lclDCT['serviceId'].lower() == 'text': lclId = 4
        elif  lclDCT['serviceId'].lower() == 'mms': lclId = 5
        else: lclId = lclDCT['serviceId']
        
        # Execute primitive
        retCode = REST_UTIL.pricingQueryServiceType(RESTInst, queryValue=lclId, eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])

        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingqueryservicetypelist(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.pricingQueryServiceTypeList(RESTInst, eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])

        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingquerybillingcyclelist(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.pricingQueryBillingCycleList(RESTInst, eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])

        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingquerybillingcycle(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.pricingQueryBillingCycle(RESTInst, queryValue=lclDCT['profileId'], eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])

        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingqueryservicecontext(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.pricingQueryServiceContext(RESTInst, serviceQueryValue=lclId, contextQueryValue=lclDCT['contextValue'], eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])

        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingquerybalancethresholdlist(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.pricingQueryBalanceThresholdList(RESTInst, queryValue=lclDCT['balanceId'], eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])

        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingquerycontractpaymentschedule(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.pricingQueryContractPaymentSchedule(RESTInst, lclDCT['externalId'], routingType=lclDCT['routingType'], routingValue=lclDCT['routingValue'], eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingquerycontractpaymentschedulelist(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.pricingQueryContractPaymentScheduleList(RESTInst, routingType=lclDCT['routingType'], routingValue=lclDCT['routingValue'], eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingquerytenant(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.pricingQueryTenant(RESTInst, lclDCT['externalId'], routingType=lclDCT['routingType'], routingValue=lclDCT['routingValue'], eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdPrice_pricingquerytenantlist(lclDCT, options, RESTInst=None):
        # *** lclDCT[] has all the values.

        # Execute primitive
        retCode = REST_UTIL.pricingQueryTenantList(RESTInst, routingType=lclDCT['routingType'], routingValue=lclDCT['routingValue'], eventPass=lclDCT['eventPass'])

        # Write to where the caller wanted it to go
        CSVQA.processDataToOutput(retCode, lclDCT['outputFileName'])
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
