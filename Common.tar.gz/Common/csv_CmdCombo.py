#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:35:26
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:35:26
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:35:25
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
from __future__ import print_function
# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
import sys, time
import QA_subscriber_management_restv3 as REST_UTIL
import qa_utils as QAUTILS
import csv_track as TRACK
import csv_data as DATA
import csv_prim as PRIM
import csv_CmdSub as CMDSUB
import csv_CmdGroup as CMDGROUP
import restV3 as RESTV3

# Define command failed
cmdFailed = '-1'

#==========================================================
def CmdCombo_waitforgroupbalancevalue(lclDCT, options, RESTInst):
        return CmdCombo_waitforbalancevalue(lclDCT, options, RESTInst)
        
#==========================================================
def CmdCombo_waitforsubscriberbalancevalue(lclDCT, options, RESTInst):
        return CmdCombo_waitforbalancevalue(lclDCT, options, RESTInst)
        
#==========================================================
def CmdCombo_waitforbalancevalue(lclDCT, options, RESTInst):
        # *** lclDCT[] has all the values.

        # Subscriber should exist
        if 'Subscriber' in lclDCT['ACTION'] and lclDCT['externalId'] not in TRACK.subscriberTracking and not lclDCT['noChecks']:
                print('ERROR: subscriber with ID "' + lclDCT['externalId'] + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Group should exist
        if 'Group' in lclDCT['ACTION'] and lclDCT['groupId'] not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: group with ID "' + lclDCT['groupId'] + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Make sure the balance ID was passed in
        if not lclDCT['balanceId']:
                print('ERROR: parameter "balanceId" is required for this command.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # timeToWaitInterval is the number of loops.
        # Get the delay time and the number of times to wait.
        intervals = int(float(lclDCT['timeToWait']) / float(lclDCT['timeToWaitInterval']))
        
        # save key data
        action = lclDCT['ACTION']
        
        # Loop
        found = False
        for i in range(intervals):
                # Invoke function to check value.  Don't exit on failure, as we're looping here
                if 'Subscriber' in lclDCT['ACTION']:
                        lclDCT['ACTION'] = 'validateSubscriberBalanceValue'
                        (queryType, queryValue) = CmdCombo_validatesubscriberbalancevalue(lclDCT, options, RESTInst, exitOnFail = False)
                else:
                        lclDCT['ACTION'] = 'validateGroupBalanceValue'
                        (queryType, queryValue) = CmdCombo_validategroupbalancevalue(lclDCT, options, RESTInst, exitOnFail = False)
                
                # If nothing returned, then we didn't match the balance value
                if queryType == cmdFailed and queryValue == cmdFailed:
                        # Sleep
                        print('Sleeping for the ' + str(i+1) + ' time out of ' + str(intervals) + ' for the balance value to match.')
                        time.sleep(float(lclDCT['timeToWaitInterval']))
                else:
                        found = True
                        break
                
        # Restore action
        lclDCT['ACTION'] = action
        
        # See if we matched
        if found: print('Balance match found')
        else:     print('Balance match NOT found')
        
        # See if we didn't break early
        if not found:
                # Exit on unexpected failure
                if lclDCT['eventPass']:   sys.exit('Command failed when success expected.  Error on command: ' + lclDCT['ACTION'])
                else:   print('Command failed when failure expected (so successful).')
        elif not lclDCT['eventPass']:     sys.exit('Command succeeded when failure expected.  Error on command: ' + lclDCT['ACTION'])
        
        # If here, then we passed!
        return (queryType, queryValue)
        
#==========================================================
def CmdCombo_validategroupbalancevalue(lclDCT, options, RESTInst, exitOnFail = True):
        return CmdCombo_validatebalancevalue(lclDCT, options, RESTInst, exitOnFail = True)
        
#==========================================================
def CmdCombo_validatesubscriberbalancevalue(lclDCT, options, RESTInst, exitOnFail = True):
        return CmdCombo_validatebalancevalue(lclDCT, options, RESTInst, exitOnFail = True)
        
#==========================================================
def CmdCombo_validatebalancevalue(lclDCT, options, RESTInst, exitOnFail = True):
        # *** lclDCT[] has all the values.

        # Subscriber should exist
        if 'Subscriber' in lclDCT['ACTION'] and lclDCT['externalId'] not in TRACK.subscriberTracking and not lclDCT['noChecks']:
                print('ERROR: subscriber with ID "' + lclDCT['externalId'] + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Group should exist
        if 'Group' in lclDCT['ACTION'] and lclDCT['groupId'] not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: group with ID "' + lclDCT['groupId'] + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Make sure the balance ID was passed in
        if not lclDCT['balanceId']:
                print('ERROR: parameter "balanceId" is required for this command.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
        
        # Set per-object values
        if 'Subscriber' in lclDCT['ACTION']:
                cmd = 'subscriber'
                value = lclDCT['externalId']
                queryType = lclDCT['subQueryType']
        else:
                cmd = 'group'
                value = lclDCT['groupId']
                queryType = lclDCT['groupQueryType']

        # Get the balance in question
        balance = PRIM.getBalanceData(cmd, value, lclDCT['balanceId'], lclDCT['resourceId'], lclDCT['lclStartTime'], lclDCT['ACTION'], lclDCT['subQueryType'])
        
        # May be a formula here...  Need to ensure precision holds for the balance (error if not).
        amount = str(PRIM.processAmountFormula('subscriber', value, lclDCT['amount'], lclDCT['lclStartTime'], lclDCT['ACTION'], precisionFlag = True, balanceId = lclDCT['balanceId'], queryType=queryType))
        
        # If they want to compare to the credit limit, then retrieve that
        if str(amount).lower() == 'cl': amount = balance['CreditLimit']

        # Make sure we handle "infinity" as a credit limit...
        if str(amount).lower() == 'infinity': amount = '9999999999999'

        # Assume false (bad karma...)
        result = False
        
        # Change list to single value
        operation = lclDCT['operation'][0]
        
        # Check each operation to see if true
        if   operation.lower() == 'equal'         and float(balance['Amount']) == float(amount): result = True
        elif operation.lower() == 'notequal'      and float(balance['Amount']) != float(amount): result = True
        elif operation.lower() == 'greaterthan'   and float(balance['Amount']) >  float(amount): result = True
        elif operation.lower() == 'greaterequal'  and float(balance['Amount']) >= float(amount): result = True
        elif operation.lower() == 'lessthan'      and float(balance['Amount']) <  float(amount): result = True
        elif operation.lower() == 'lessequal'     and float(balance['Amount']) <= float(amount): result = True
        
        # Debug output
        '''
        print 'Name: ' + balance['Name']
        print 'Balance Amount: ' + str(float(balance['Amount']))
        print 'Operation: ' + operation
        print 'amount: ' + str(float(amount))
        print 'result: ' + str(result)
        '''
        print('Result of balance ' + balance['Name'] + ': ' + str(float(balance['Amount']))+ ' ' +  operation + ' ' + str(float(amount)) + ': ' + str(result))
        # if the result doesn't match the expected result, then we have an issue
        if result != lclDCT['eventPass']:
                # This is not always the primary command.  Sometimes used as a helper.
                if exitOnFail:
                        # Primary command
                        print('ERROR: comparison failed expected results.')
                        
                        # If not suposed to continue past errors, then exit
                        if not lclDCT['continuePastError']: sys.exit('Error on command: ' + lclDCT['ACTION'])
                        else:  print('Continuing past error as per local variable continuePastError set to True')
                else:
                        # Helper command.  Return all cmdFailed to signal caller that we didn't pass the request.
                        return (cmdFailed, cmdFailed)
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdCombo_setgroupbalancevalue(lclDCT, options, RESTInst):
        return CmdCombo_setbalancevalue(lclDCT, options, RESTInst)

#==========================================================
def CmdCombo_setsubscriberbalancevalue(lclDCT, options, RESTInst):
        return CmdCombo_setbalancevalue(lclDCT, options, RESTInst)

#==========================================================
def CmdCombo_setbalancevalue(lclDCT, options, RESTInst):
        # *** lclDCT[] has all the values.

        # Subscriber should exist
        if 'Subscriber' in lclDCT['ACTION'] and lclDCT['externalId'] not in TRACK.subscriberTracking and not lclDCT['noChecks']:
                print('ERROR: subscriber with ID "' + lclDCT['externalId'] + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Group should exist
        if 'Group' in lclDCT['ACTION'] and lclDCT['groupId'] not in TRACK.groupTracking and not lclDCT['noChecks']:
                print('ERROR: group with ID "' + lclDCT['groupId'] + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        # Make sure the balance ID was passed in
        if not lclDCT['balanceId']:
                print('ERROR: parameter "balanceId" is required for this command.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])

        if 'Subscriber' in lclDCT['ACTION']:
                cmd = 'subscriber'
                value = lclDCT['externalId']
                queryType = lclDCT['subQueryType']
        else:
                cmd = 'group'
                value = lclDCT['groupId']
                queryType = lclDCT['groupQueryType']

        # Get the balance in question
        if 'Subscriber' in lclDCT['ACTION']:    balance = PRIM.getBalanceData(cmd, value, lclDCT['balanceId'], lclDCT['resourceId'], lclDCT['lclStartTime'], lclDCT['ACTION'], lclDCT['subQueryType'])
        else:                                   balance = PRIM.getBalanceData(cmd, value, lclDCT['balanceId'], lclDCT['resourceId'], lclDCT['lclStartTime'], lclDCT['ACTION'], lclDCT['groupQueryType'])
        
        # May be a formula here...  Need to ensure precision holds for the balance (error if not).
        amount = str(PRIM.processAmountFormula('subscriber', value, lclDCT['amount'], lclDCT['lclStartTime'], lclDCT['ACTION'], precisionFlag = True, balanceId = lclDCT['balanceId'], queryType=queryType))
        
        # Get amount to adjust by
        deltaAmount = float(balance['Amount']) - float(amount)
        
        # Set adjust type
        if deltaAmount >= 0: lclDCT['adjustType'] = DATA.adjustTypeMapping['credit']
        else:                lclDCT['adjustType'] = DATA.adjustTypeMapping['debit']
        
        # Put amount into the local dictionary
        lclDCT['amount'] = str(abs(deltaAmount))
        
        # Invoke API to adjust the balance
        if 'Subscriber' in lclDCT['ACTION']:    (queryType, queryValue) = CMDSUB.CmdSub_subscriberadjustbalance(lclDCT, options, RESTInst, '0')
        else:                                   (queryType, queryValue) = CMDGROUP.CmdGroup_groupadjustbalance(lclDCT, options, RESTInst, '0')
        
        # Restore the dictionary data
        lclDCT['amount'] = amount
        
        # Use returned values for query data (so nothing to store here)
        return (queryType, queryValue)
        
