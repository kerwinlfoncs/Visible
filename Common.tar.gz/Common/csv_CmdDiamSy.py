#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:35:35
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:35:35
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:35:34
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
from __future__ import print_function
# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
import copy, os, sys, pprint
import diameter_utils
import create_diameter_pkt_base
import csv_track as TRACK
import custSpecific as CUST
import csv_data as DATA
import csv_prim as PRIM
import csv_5G as FIVEG

# Define globals
lastSnrDct = {}

# =========================================================================================
# ===========================  Diameter Sy commands ==== ==================================
# =========================================================================================

#==========================================================
def retrieveAndValidateSyPolicyData(diamDct, lclDCT, printFlag = False):
        #pprint.pprint(diamDct)
        
        # Grab policy data from the SLA
        policyData = []
        idx = 0
        while True:
                # See if the policy value was input
                pcidString = 'Pcsr' + str(idx)
                activeRuleStringStatus = pcidString + '->Policy-Counter-Status'
                activeRuleStringId     = pcidString + '->Policy-Counter-Identifier'
                pendingRuleTime        = pcidString + '->Pending-Policy-Counter-Information->Pending-Policy-Counter-Change-Time'
                pendingRuleStatus      = pcidString + '->Pending-Policy-Counter-Information->Policy-Counter-Status'

                # Check for active entry
                if activeRuleStringStatus in diamDct:
                        # Store in the array

                        # Check if any pending data
                        if pendingRuleTime in diamDct:
                                # Store in the array
                                policyData.append([diamDct[activeRuleStringStatus], diamDct[activeRuleStringId], diamDct[pendingRuleTime].split('(')[1].split(')')[0], diamDct[pendingRuleStatus]])
                        else:
                                policyData.append([diamDct[activeRuleStringStatus], diamDct[activeRuleStringId], None, None])

                        # bump index (how TF stores list items in returned messages)
                        idx += 1
                else:
                        # No more of these
                        break

        # If printing and anything to print, then output
        if printFlag and len(policyData):
                print('Sy Rules: ')
                ruleArray = [L[1] for L in policyData]
                nameLength = len(max(ruleArray, key=len))
                valueArray = [L[0] for L in policyData]
                valueLength = len(max(valueArray, key=len))
                outFormat = '%-' + str(nameLength) + 's: %-' + str(valueLength) + 's %s\n'
                outFormat2 = '       %s: %s %s\n'
                for entry in policyData:
                        (status,rule,pendingTime,pendingStatus) = entry
                        if pendingTime:
                                sys.stdout.write(outFormat  % (rule,status,'(Active)'))
                                sys.stdout.write(outFormat2 % (pendingTime,pendingStatus,'(Pending)'))
                        else:
                                sys.stdout.write(outFormat  % (rule,status,''))

        # Validate response if input specified.
        if lclDCT['policyStatus']:
                # Validate
                retVal = validateSyMessage(diamDct, 'None', lclDCT)
                
                # Check response
                if not retVal: sys.exit('Failed Sy validation.  Exiting')
                '''
                for param in DATA.parameterSyValidate:
                        cmd = 'if lclDCT[param]: _a = validateSyMessage(diamDct, param, lclDCT) \n'
                        cmd += 'else: _a = True'
                        exec(cmd)
                        retVal = locals()['_a']
                        
                        # Check response
                        if not retVal: sys.exit('Failed Sy validation.  Exiting')
                '''
        else: print('\n')
        
        return policyData

#==========================================================
def validateSyMessage(diamDct, field, lclDCT):
#       print 'Validating Sy message.  Field = ' + field
        foundCount = 0
        
        # Get policy info to validate
        policyIdentifier = lclDCT['policyIdentifier']
        policyStatus = lclDCT['policyStatus']
        policyPartial = lclDCT['policyPartial']
        
        # Check if we should evaluate policy
        evaluatePolicy = PRIM.policyValidationInputChecks(lclDCT)
        
        # Evaluate if we should
        if evaluatePolicy:
                # Walk the list of returned policy.  These are not in an array; they're individual fields.  Max at 20 for now.
                for i in range(50):
                        pcidString = 'Pcsr' + str(i)

                        # Build dictionary key
                        nameKey = pcidString + '->Policy-Counter-Identifier'
                        
                        # If key not present, then break out (as keys will be sequential)
                        if nameKey not in diamDct: break
                        
                        # If here, then we found the key.  Get the name
                        policyName = diamDct[nameKey]
                        
                        # Get the value
                        valueKey = pcidString + '->Policy-Counter-Status'
                        policyValue = diamDct[valueKey]
                        
                        # A counter may have a pending status
                        pendingRuleTime        = pcidString + '->Pending-Policy-Counter-Information->Pending-Policy-Counter-Change-Time'
                        pendingRuleStatus      = pcidString + '->Pending-Policy-Counter-Information->Policy-Counter-Status'

                        # Compare this against the input data.  First need to make sure we have this name in the validation item
                        try:
                                index = policyIdentifier.index(policyName)
                        except:
                                # Policy not specified in TF command.  How to react depends on policyPartial value
                                if policyPartial:
                                        #print 'NOTE: Sy returned policy "' + policyName + '" not in command line policy identifiers, but policyPartial set so continuing'
                                        continue
                                else:
                                        print('ERROR: Sy returned policy "' + policyName + '" not in command line policy identifiers (' + str(policyIdentifier) + ')')
                                        return False
                        
                        # Cover input errors, where the length of the status != length of the identifers
                        if len(policyStatus) <= index:
                                print('ERROR:  length of command line policyStatus is ' + str(len(policyStatus)) + ' while the length of the policyIdentifier is ' + str(len(policyIdentifier)))
                                return False
                        
                        # See if the values match.
                        # Can validate pending time/status and/or the counter itself.
                        for pStatus in policyStatus[index].split('|'):
                         if   pStatus.startswith('Pending-Time'):
                                # Make sure pending data is present
                                try:
                                        valueToCheck = diamDct[pendingRuleTime]
                                        status = pStatus.split(':')[1]
                                except:
                                        print('ERROR: Test requesting to validate policy counter"' + policyIdentifier[index] + '" pending time, but that\'s not present')
                                        return False
                         elif pStatus.startswith('Pending-Status'):
                                # Make sure pending data is present
                                try:
                                        valueToCheck = diamDct[pendingRuleStatus]
                                        status = pStatus.split(':')[1]
                                except:
                                        print('ERROR: Test requesting to validate policy counter"' + policyIdentifier[index] + '" pending status, but that\'s not present')
                                        return False
                         else:
                                valueToCheck = policyValue
                                status = pStatus
                         if status != valueToCheck:
                                print('ERROR:  policy "' + policyName + '" command line value "' + str(status) + '" doesn\'t match returned value of "' + str(valueToCheck) + '"')
                                return False
                        
                         # Report success
                         if   pStatus.startswith('Pending'): print('Validated Sy policy ' + policyName + ' (' + pStatus.split(':')[0] + ') = ' + valueToCheck)
                         else:                               print('Validated Sy policy ' + policyName + ' = ' + valueToCheck)
                        
                        # Increment found count - only once per identifier
                        foundCount += 1
                
                # If here, then everything matched.  Want to make sure everything that was expected was returned.
                # NOTE: a value of 99999 means the counter won't be returned.  Thus we shouldn't have found it.
                if foundCount != (len(policyIdentifier) - lclDCT['policyStatus'].count('99999')):
                        print('ERROR: ' + str(len(policyIdentifier)) + ' policy status expected, but only ' + str(foundCount) + ' returned.')
                        print('Command line Sy policy identifiers: ' + str(policyIdentifier))
                        print('Command line Sy policy status:      ' + str(policyStatus))
                        print('Returned Dictionary: ')
                        pprint.pprint(diamDct)
                        return False
                
        # If here, then all went well
        return True
        
#==========================================================
def CmdDiam_diameterreceivespendnotificationrequest(lclDCT, options, diamConnection, extraAVP={}):
        global lastSnrDct
        
        # If 5G Sy then handle totally different
        if lclDCT['interface'].lower() == '5gsy':
                FIVEG.FiveGReceiveNotify(lclDCT, options, diamConnection, extraAVP)
                return (None, None)
        
        # *** lclDCT[] has all the values.
        '''
        '''
        eventPass = lclDCT['eventPass']
        nonSuccessResultCode = lclDCT['nonSuccessResultCode']

        # Always Sy for this command
        diamConnection = TRACK.diamConnectionSy

        # Get message ID.  May be customized or default
        if hasattr(CUST, "diameterMessageIds") and 'SNR' in CUST.diameterMessageIds: msgId = CUST.diameterMessageIds['SNR'][1]
        else: msgId = DATA.DiameterMessageIds['SySNR'] 

        # Receive message
        (diamDct, diamResp) = diameter_utils.receiveDiameterPacket(diamConnection=diamConnection, msgId = msgId, timeout=lclDCT['timeToWait'], extraAVP=extraAVP)
        
        # Check response
        if (not diamResp and eventPass) or (diamResp and not eventPass):
                if eventPass: sys.exit('CmdDiam_diameterreceivespendnotificationrequest() received a unexpected failure from diameter_utils.receiveDiameterPacket()')
                else:         sys.exit('CmdDiam_diameterreceivespendnotificationrequest() received a unexpected success from diameter_utils.receiveDiameterPacket()')
        
        # Nothing to query in this scenario
        queryType = queryValue = None
        
        # If failure expected, then return here
        if not eventPass: return (queryType, queryValue)
        
        # Debug output
        #print 'Received SNR.  Packet contents: ' + str(diamDct)
        
        # Validate response if input specified.
        '''
        for param in DATA.parameterSyValidate:
                cmd = 'if ' + param + ': _a = validateSyMessage(diamDct, param, lclDCT) \n'
                cmd += 'else: _a = True'
                exec(cmd)
                retVal = locals()['_a']
                
                # Check response
                if not retVal: sys.exit('Failed Sy validation.  Exiting')
        '''
        
        # Output policy data
        policyData = retrieveAndValidateSyPolicyData(diamDct, lclDCT, printFlag=True)
        
        # Reply if we're supposed to
        if not lclDCT['noReply']:
                print('Sending SNA')

                # Turn around a SNA
                if nonSuccessResultCode:
                        create_diameter_pkt_base.sendSpendNotificationAnswer(diamDct, diamConnection = diamConnection, eventPass=False, extraAVP=extraAVP, nonSuccessResultCode=nonSuccessResultCode)
                else:   create_diameter_pkt_base.sendSpendNotificationAnswer(diamDct, diamConnection = diamConnection, eventPass=eventPass, extraAVP=extraAVP)

        else:
                # Save last message (so answer can use it if response is delayed)
                 lastSnrDct = copy.deepcopy(diamDct)

        return (queryType, queryValue)
        
#==========================================================
def CmdDiam_diametersendspendnotificationanswer(lclDCT, options, diamConnection, extraAVP={}):
        global lastSnrDct
        
        # *** lclDCT[] has all the values.
        '''
        '''
        eventPass = lclDCT['eventPass']
        nonSuccessResultCode = lclDCT['nonSuccessResultCode']

        # Always Sy for this command
        diamConnection = TRACK.diamConnectionSy

        # Send SNR.  Use last saved SNR dictionary (command needs data from previous SNR command)
        if nonSuccessResultCode:
                create_diameter_pkt_base.sendSpendNotificationAnswer(lastSnrDct, diamConnection = diamConnection, eventPass=False, extraAVP=extraAVP, nonSuccessResultCode=nonSuccessResultCode)
        else:   create_diameter_pkt_base.sendSpendNotificationAnswer(lastSnrDct, diamConnection = diamConnection, eventPass=eventPass, extraAVP=extraAVP)
        
        # Clear global
        lastSnrDct = {}
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)

