#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:36:20
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:36:20
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:36:18
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
# NOTE:  Please do not import any additional QA test-specific files here.  This file is used
#        as part of the debug log analysis script and needs to run stand-alone
#        (i.e. only using Python libraries).  The files already imported have been setup to
#        work in this mode.

from __future__ import print_function
from __future__ import division
# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
from past.utils import old_div
import os, sys, copy, pprint
import csv_id as CSVID
import csv_qa as CSVQA
import diameter_utils as DIAMU
import common_mdc as COMMON
import QA_subscriber_management_restv3 as REST_UTIL

# Define and setup various ID mappings (so we know what's assigned to what)
groupTracking = {}
groupTracking['groupId'] = []   # List of groups that are defined
groupTracking['mark'] = []      # List of marks
subscriberTracking = {}
subscriberTracking['externalId'] = []   # List of subscribers that are defined
subscriberTracking['mark'] = [] # List of marks
deviceTracking = {}
deviceTracking['deviceId'] = [] # List of devices that are defined
deviceTracking['mark'] = []     # List of marks
accessNumberTracking = {}
accessNumberTracking['accessNumbers'] = [] # List of accessNumbers that are defined
sessionTracking = {}
sessionTracking['sessions'] = []
userTracking = {}
userTracking['userId'] = []     # List of subscribers that are defined
userTracking['mark'] = []       # List of marks

# Diameter connection global data
diamConnection = None
diamConnectionGx = None
diamConnectionGy = None
diamConnectionSy = None
diamConnectionSh = None
diamConnectionRx = None
diamConnection5G = None
diamConnectionGxDict = {}
diamConnectionGyDict = {}
diamConnectionSyDict = {}
diamConnectionShDict = {}
diamConnectionRxDict = {}
diamConnection5GDict = {}
noCheckFlag = False

# Define for saved time
saveTime = {}

# Commpn output strings
headingString  = '\n\n**************  Start of Output *******************\n'
trailingString = '\n\n**************  End of Output   *******************\n'

#==========================================================
def setupTrackingData():
        global groupTracking, subscriberTracking, deviceTracking, accessNumberTracking, sessionTracking, subscriberTracking, userTracking
        
        # Define and setup various ID mappings (so we know what's assigned to what)
        groupTracking = {}
        groupTracking['groupId'] = []   # List of groups that are defined
        groupTracking['mark'] = []      # List of marks
        subscriberTracking = {}
        subscriberTracking['externalId'] = []   # List of subscribers that are defined
        subscriberTracking['mark'] = [] # List of marks
        deviceTracking = {}
        deviceTracking['deviceId'] = [] # List of devices that are defined
        deviceTracking['mark'] = []     # List of marks
        accessNumberTracking = {}
        accessNumberTracking['accessNumbers'] = [] # List of accessNumbers that are defined
        sessionTracking = {}
        sessionTracking['sessions'] = []
        subscriberTracking = {}
        subscriberTracking['externalId'] = []   # List of subscribers that are defined
        subscriberTracking['mark'] = [] # List of marks
        userTracking = {}
        userTracking['userId'] = []     # List of subscribers that are defined
        userTracking['mark'] = []       # List of marks
        
#==========================================================
def findObjectMark(options, specialString):
        # Process each possible prefix separately
        # Group mark entered
        if specialString[0].lower().startswith('group'):
                # Get the group ID
                lclGroupId = CSVID.getAbsoluteIdValue(options, 'groupId', specialString[1], True)[0]

                # See if a subscriber index was also input
                field = 2
                if len(specialString) > field:  index = int(specialString[field])
                else:                           index = 0

                # Set the device
                if len(groupTracking[lclGroupId]['externalId']) > index:
                        lclSubId = groupTracking[lclGroupId]['externalId'][index]
                else:
                        print('WARNING: group ' + str(lclGroupId) + ' doesn\'t have ' + str(index) + ' subscriber defined.  Using index 0.')
                        lclSubId = groupTracking[lclGroupId]['externalId'][0]

                # See if a device index was also input
                field = 3
                if len(specialString) > field:  index = int(specialString[field])
                else:                           index = 0

                # Set the device
                if len(subscriberTracking[lclSubId]['deviceId']) > index:
                        lclDeviceId = subscriberTracking[lclSubId]['deviceId'][index]
                else:
                        print('WARNING: subscriber ' + str(lclSubId) + ' doesn\'t have ' + str(index) + ' device defined.  Using index 0.')
                        lclDeviceId = subscriberTracking[lclSubId]['deviceId'][0]

                # See if a MSISDN index was also input
                field = 4
                if len(specialString) > field:  index = int(specialString[field])
                else:                           index = 0
                # Set the access number
                if len(deviceTracking[lclDeviceId]['accessNumbers']) > index:
                        retData = deviceTracking[lclDeviceId]['accessNumbers'][index]
                else:
                        print('WARNING: device ' + str(lclDeviceId) + ' doesn\'t have ' + str(index) + ' MSISDN defined.  Using index 0.')
                        retData = deviceTracking[lclDeviceId]['accessNumbers'][0]

                print('Data changed to match ' + specialString[0] + ' mark "' + specialString[1] + '".  Set ' + specialString[0] + ' ' +  str(lclGroupId) + ', subscriber ' + str(lclSubId) + ', device ' + str(lclDeviceId) + ', access number ' + str(retData))

        # Subscriber mark entered
        if specialString[0].lower().startswith('subscriber'):
                # Get the subscriber ID
                lclSubId = CSVID.getAbsoluteIdValue(options, 'externalId', specialString[1], True)[0]

                # See if a device index was also input
                field = 2
                if len(specialString) > field:  index = int(specialString[field])
                else:                           index = 0

                # Set the device
                if len(subscriberTracking[lclSubId]['deviceId']) > index:
                        lclDeviceId = subscriberTracking[lclSubId]['deviceId'][index]
                else:
                        print('WARNING: subscriber ' + str(lclSubId) + ' doesn\'t have ' + str(index) + ' device defined.  Using index 0.')
                        lclDeviceId = subscriberTracking[lclSubId]['deviceId'][0]

                # See if a MSISDN index was also input
                field = 3
                if len(specialString) > field:  index = int(specialString[field])
                else:                           index = 0

                # Set the access number
                if len(deviceTracking[lclDeviceId]['accessNumbers']) > index:
                        retData = deviceTracking[lclDeviceId]['accessNumbers'][index]
                else:
                        print('WARNING: device ' + str(lclDeviceId) + ' doesn\'t have ' + str(index) + ' MSISDN defined.  Using index 0.')
                        retData = deviceTracking[lclDeviceId]['accessNumbers'][0]

                print('Data changed to match ' + specialString[0] + ' mark "' + specialString[1] + '".  Set ' + specialString[0] + ' ' +  str(lclSubId) + ', device ' + str(lclDeviceId) + ', access number ' + str(retData))

        
        # Device mark entered
        if specialString[0].lower().startswith('device'):
                # Get the device ID
                lclDeviceId = CSVID.getAbsoluteIdValue(options, 'deviceId', specialString[1], True)[0]

                # See if a MSISDN index was also input
                field = 2
                if len(specialString) > field:  index = int(specialString[field])
                else:                           index = 0

                # Set the access number
                if len(deviceTracking[lclDeviceId]['accessNumbers']) > index:
                        retData = deviceTracking[lclDeviceId]['accessNumbers'][index]
                else:
                        print('WARNING: device ' + str(lclDeviceId) + ' doesn\'t have ' + str(index) + ' MSISDN defined.  Using index 0.')
                        retData = deviceTracking[lclDeviceId]['accessNumbers'][0]

                print('Data changed to match ' + specialString[0] + ' mark "' + specialString[1] + '".  Set ' + specialString[0] + ' ' +  str(lclDeviceId) + ', access number ' + str(retData))

        return retData

#==========================================================
def showDeviceTrackingData(devList, scope = 'local', verbose = 'none', outputFileName = None):
   # If no checks are on, then can;t do anything here
   if noCheckFlag:
        print('NOTE:  noChecks flag is on.  No tracking is enabled.')
        return

   #print 'showDeviceTrackingData: scope/verbose = ' + scope + '/' + verbose
   # Go through all devices in the list
   for deviceId in devList:
        # Output data
        _str= 'Device ID: ' + deviceId + \
                ', Parent Subscriber = ' + deviceTracking[deviceId]['externalId'] + \
                ', number of marks = ' + str(len(deviceTracking[deviceId]['mark'])) + \
                ', number of access numbers: ' + str(len(deviceTracking[deviceId]['accessNumbers'])) + \
                ', number offers: ' + str(len(deviceTracking[deviceId]['offerId'])) + \
                ', number active sessions: ' + str(len(deviceTracking[deviceId]['sessions']))
        CSVQA.processDataToOutput(_str, outputFileName)
        _str= 'marks: ' + str(deviceTracking[deviceId]['mark']) + \
                '\nAccess Numbers: ' + str(deviceTracking[deviceId]['accessNumbers']) + \
                '\nOffers: ' + str(deviceTracking[deviceId]['offerId']) + \
                '\nSessions: ' + str(deviceTracking[deviceId]['sessions']) + \
                '\n'
        CSVQA.processDataToOutput(_str, outputFileName)
         
        # If verbose is high, then show all sessions
        if verbose == 'high' and len(deviceTracking[deviceId]['sessions']):
            for subSession in deviceTracking[deviceId]['sessions']:
                # Log session data
                CSVQA.processDataToOutput(str(sessionTracking[subSession]) + '\n', outputFileName)

#==========================================================
def showSubscriptionTrackingData(subList, scope = 'local', verbose = 'none', outputFileName = None):
   # If no checks are on, then can;t do anything here
   if noCheckFlag:
        print('NOTE:  noChecks flag is on.  No tracking is enabled.')
        return

   #print 'showSubscriptionTrackingData: scope/verbose = ' + scope + '/' + verbose
   pprint.pprint(subscriberTracking)
   
   # Go through all subs in the list
   for externalId in subList:
         # Output data
         _str= 'Subscriber ID: ' + externalId + \
                ', number of marks = ' + str(len(subscriberTracking[externalId]['mark'])) + \
                ', number of devices: ' + str(len(subscriberTracking[externalId]['deviceId'])) + \
                ', number of parent groups: ' + str(len(subscriberTracking[externalId]['parentGroupId'])) + \
                ', number offers: ' + str(len(subscriberTracking[externalId]['offerId'])) + \
                ', number active sessions: ' + str(len(subscriberTracking[externalId]['sessions']))
         CSVQA.processDataToOutput(_str, outputFileName)
         _str = 'marks: ' + str(subscriberTracking[externalId]['mark']) + \
                '\nDevices: ' + str(subscriberTracking[externalId]['deviceId']) + \
                '\nParent Groups: ' + str(subscriberTracking[externalId]['parentGroupId']) + \
                '\nOffers: ' + str(subscriberTracking[externalId]['offerId']) + \
                '\nSessions: ' + str(subscriberTracking[externalId]['sessions']) + \
                '\n'
         CSVQA.processDataToOutput(_str, outputFileName)
        
         # Output device data if any exist and we're in a verbose mode
         if subscriberTracking[externalId]['deviceId'] and verbose != 'none':
                showDeviceTrackingData(subscriberTracking[externalId]['deviceId'], scope = scope, verbose = verbose, outputFileName = outputFileName)
         
#==========================================================
def showSubscriberTrackingData(subList, scope = 'local', verbose = 'none', outputFileName = None):
   # If no checks are on, then can;t do anything here
   if noCheckFlag:
        print('NOTE:  noChecks flag is on.  No tracking is enabled.')
        return

   #print 'showSubscriberTrackingData: scope/verbose = ' + scope + '/' + verbose
   # Go through all subs in the list
   for externalId in subList:
         # Output data
         _str= 'Subscriber ID: ' + externalId + \
                ', number of marks = ' + str(len(subscriberTracking[externalId]['mark'])) + \
                ', number of devices: ' + str(len(subscriberTracking[externalId]['deviceId'])) + \
                ', number of parent groups: ' + str(len(subscriberTracking[externalId]['parentGroupId'])) + \
                ', number offers: ' + str(len(subscriberTracking[externalId]['offerId'])) + \
                ', number active sessions: ' + str(len(subscriberTracking[externalId]['sessions']))
         CSVQA.processDataToOutput(_str, outputFileName)
         _str = 'marks: ' + str(subscriberTracking[externalId]['mark']) + \
                '\nDevices: ' + str(subscriberTracking[externalId]['deviceId']) + \
                '\nParent Groups: ' + str(subscriberTracking[externalId]['parentGroupId']) + \
                '\nOffers: ' + str(subscriberTracking[externalId]['offerId']) + \
                '\nSessions: ' + str(subscriberTracking[externalId]['sessions']) + \
                '\n'
         CSVQA.processDataToOutput(_str, outputFileName)
        
         # Output device data if any exist and we're in a verbose mode
         if subscriberTracking[externalId]['deviceId'] and verbose != 'none':
                showDeviceTrackingData(subscriberTracking[externalId]['deviceId'], scope = scope, verbose = verbose, outputFileName = outputFileName)
         
#==========================================================
def showGroupTrackingData(groupList, level, scope = 'local', verbose = 'none', outputFileName = None):
        # If no checks are on, then can;t do anything here
        if noCheckFlag:
                print('NOTE:  noChecks flag is on.  No tracking is enabled.')
                return

        nextLevelList = []
        #print 'showGroupTrackingData: scope/verbose = ' + scope + '/' + verbose
        # Output level data
        _str = '\nLevel: ' + str(level) + '\n'
        CSVQA.processDataToOutput(_str, outputFileName)
        
        # Go through all groups in the list
        for groupId in groupList:
         # Output data
         _str = 'Group ID: ' + groupId + \
                ', number of marks = ' + str(len(groupTracking[groupId]['mark'])) + \
                ', number of subs: ' + str(len(groupTracking[groupId]['externalId'])) + \
                ', number of sub-groups: ' + str(len(groupTracking[groupId]['groupId'])) + \
                ', number of parent groups: ' + str(len(groupTracking[groupId]['parentGroupId'])) + \
                ', number offers: ' + str(len(groupTracking[groupId]['offerId']))
         CSVQA.processDataToOutput(_str, outputFileName)
         _str = 'marks: ' + str(groupTracking[groupId]['mark']) + \
                '\nSubs: ' + str(groupTracking[groupId]['externalId']) + \
                '\nSub-Groups: ' + str(groupTracking[groupId]['groupId']) + \
                '\nParent Groups: ' + str(groupTracking[groupId]['parentGroupId']) + \
                '\nOffers: ' + str(groupTracking[groupId]['offerId']) + '\n'
         CSVQA.processDataToOutput(_str, outputFileName)
        
         # Output sub data if any exist and we're in a verbose mode
         if groupTracking[groupId]['externalId'] and verbose != 'none':
                showSubscriberTrackingData(groupTracking[groupId]['externalId'], scope = scope, verbose = verbose, outputFileName = outputFileName)
         
         # Build next level list in case we need it
         if groupTracking[groupId]['groupId']:
                nextLevelList.extend(groupTracking[groupId]['groupId'])
        
        # If we're not in local scope, then we want to iterate through the next layer
        if scope != 'local' and nextLevelList:
                # Bump level
                level = str(int(level) + 1)
                showGroupTrackingData(nextLevelList, level, scope = scope, verbose = verbose, outputFileName = outputFileName)
        
#==========================================================
def retrieveTrackingData(action, groupId = None, externalId = None, deviceId = None, accessNumbers = None, offerId = None, scope = 'local', mark = None):
        idToReturn = []
        
        # If no checks are on, then can;t do anything here
        if noCheckFlag:
                print('NOTE:  noChecks flag is on.  No tracking is enabled.')
                return idToReturn

        # If mark passed in, then may need to change external ID or group ID
        if mark:
                # If the action contains the work "Group", then use group mark, else use subscriber mark
                if "Group" in action and groupId and mark in groupTracking: groupId =  groupTracking[mark]
                elif "Group" not in action and externalId and mark in subscriberTracking: externalId = subscriberTracking[mark]
                
        objectList = []
        objectList2 = []
        if action == 'queryGroup':
           objectList = groupTracking['groupId']
        elif action.count('EverySubEvent') or \
           action.count('EverySubInGroupEvent') or \
           action == 'querySubscriber' or \
           action == 'queryEverySubEvent' or \
           action == 'queryEverySubInGroupEvent'        : 
           # Get the list of subs based on the action
           if action.count('EverySubEvent') or action == 'queryEverySubEvent':
                objectList = copy.deepcopy(subscriberTracking['externalId'])
           elif action == 'querySubscriber':
                objectList.append(externalId)
           elif (action.count('EverySubInGroupEvent') or action == 'queryEverySubInGroupEvent') and scope == 'local':
                objectList = copy.deepcopy(groupTracking[groupId]['externalId'])
           else:
                # Query every sub in all groups below the input one (as well as the input one).
                objectList = copy.deepcopy(groupTracking[groupId]['externalId'])
                for group in groupTracking[groupId]['groupId']:
                        objectList.extend(retrieveTrackingData('queryEverySubInGroupEvent', groupId=group, scope=scope))
           
           # The rest of the function translats subscriber IDs to device IDs.  If here and this is a query event, then return the subscriber list.
           if action.startswith('query'):
                # Return subscriber list
                return objectList

           # Want to send to one device per sub
           for subscriber in objectList:
                # Make sure the sub has a device...
                if len(subscriberTracking[subscriber]['deviceId']):
                        idToReturn.append(subscriberTracking[subscriber]['deviceId'][0])
           print('List of devices for action ' + action + ' : ' + str(idToReturn))
                
        elif action.count('EveryDeviceEvent') or \
             action.count('EveryDeviceInSubEvent') or \
             action.count('EveryDeviceInGroupEvent'): 
           # Get the list of subs based on the action
           if action.count('EveryDeviceEvent'):
                objectList = copy.deepcopy(subscriberTracking['externalId'])
           elif action.count('EveryDeviceInSubEvent'):
                objectList.append(externalId)
           elif action.count('EveryDeviceInGroupEvent') and scope == 'local':
                objectList = copy.deepcopy(groupTracking[groupId]['externalId'])
           else:
                # Query every sub in all groups below the input one (as well as the input one).
                objectList = copy.deepcopy(groupTracking[groupId]['externalId'])
                for group in groupTracking[groupId]['groupId']:
                        objectList.extend(retrieveTrackingData('queryEverySubInGroupEvent', groupId=group, scope=scope))
                
           for subscriber in objectList:
                # Make sure the sub has a device...
                if len(subscriberTracking[subscriber]['deviceId']):
                        for device in subscriberTracking[subscriber]['deviceId']:
                                idToReturn.append(device)
           print('List of devices for action ' + action + ' : ' + str(idToReturn))

        elif action.count('EveryAccessNumberEvent') or \
             action.count('EveryAccessNumberInSubEvent') or \
             action.count('EveryAccessNumberInGroupEvent'): 
           # Get the list of subs based on the action
           if action.count('EveryAccessNumberEvent'):
                objectList = copy.deepcopy(subscriberTracking['externalId'])
           elif action.count('EveryAccessNumberInSubEvent'):
                objectList.append(externalId)
           elif action.count('EveryAccessNumberInGroupEvent') and scope == 'local':
                objectList = copy.deepcopy(groupTracking[groupId]['externalId'])
           else:
                # Query every sub in all groups below the input one (as well as the input one).
                objectList = copy.deepcopy(groupTracking[groupId]['externalId'])
                for group in groupTracking[groupId]['groupId']:
                        objectList.extend(retrieveTrackingData('queryEverySubInGroupEvent', groupId=group, scope=scope))

           for subscriber in objectList:
                # Make sure the sub has a device...
                if len(subscriberTracking[subscriber]['deviceId']):
                        for device in subscriberTracking[subscriber]['deviceId']:
                                # Make sure device has an access numbers
                                if len(deviceTracking[device]['accessNumbers']):
                                        for aN in deviceTracking[device]['accessNumbers']:
                                                # Add to the list
                                                idToReturn.append(aN)
           print('List of devices for action ' + action + ' : ' + str(idToReturn))
                
        return idToReturn
#==========================================================
def updateTrackingData(action, groupId = None, subGroupId = None, externalId = None, deviceId = None, accessNumbers = None, offerId = None, mark = None, resourceId = None, taskId = None, modId = None, userId=None, RESTInst=None):
        # If no checks are on, then can't do anything here.  
        # In order to support mid-test removes we need to allow deltee to go through here.
        if noCheckFlag and not action.startswith('delete'):
                print('NOTE: noChecks flag is on and not a delete command.  No tracking is enabled.')
                return
        
        # ** Never really implemented resource ID, so clear it internally
        resourceId = None
        
        #print 'action = ' + action + ', access numbers = ' + str(accessNumbers)
        
        if action == 'createUser': 
         # Two possible IDs for this object
         if userId:
                idx = 'userId'
                valToUse = userId
                queryType='UserId'
         else:
                idx = 'userExternalId'
                valToUse = externalId
                queryType='ExternalId'
        
         # Track this user and create a holding place for future items
         userTracking[idx].append(valToUse)
         userTracking[valToUse] = {}
         userTracking[valToUse]['id'] = userId
         userTracking[valToUse]['mark'] = []
         userTracking[valToUse]['userExternalId'] = externalId
         
         # May need to switch ID to external ID
         if valToUse.isdigit() and RESTInst:
                oid = REST_UTIL.getUserOID(RESTInst,queryValue=valToUse, queryType=queryType)
                userTracking[oid] = {}
                userTracking[oid]['oid_to_externalId'] = externalId
                userTracking[oid]['oid_to_userId'] = userId
                
         #print 'Tracking user data for ' + valToUse
        
         # Track mark if provided
         if mark:
                userTracking[mark] = valToUse
                userTracking[valToUse]['mark'].append(mark)
                #print 'Storing user mark = "' + mark + '" = ' + valToUse
        
        elif action in ['createSubscription', 'createSubscriber']: 
         valToUse = externalId
         # Track this user and create a holding place for future items
         subscriberTracking['externalId'].append(valToUse)
         subscriberTracking[valToUse] = {}
         subscriberTracking[valToUse]['id'] = valToUse
         subscriberTracking[valToUse]['parentGroupId'] = []
         subscriberTracking[valToUse]['deviceId'] = []
         subscriberTracking[valToUse]['offerId'] = []
         subscriberTracking[valToUse]['mark'] = []
         subscriberTracking[valToUse]['sessions'] = []
         subscriberTracking[valToUse]['timeFirstSession'] = 0
         subscriberTracking[valToUse]['TotalGranted'] = 0
         subscriberTracking[valToUse]['TotalUsed'] = 0
         subscriberTracking[valToUse]['dataPoints'] = {}
         subscriberTracking[valToUse]['userId'] = userId
         
         # May need to switch ID to external ID
         if valToUse.isdigit() and RESTInst:
                oid = REST_UTIL.getSubscriptionOID(RESTInst,queryValue=valToUse)
                subscriberTracking[oid] = {}
                subscriberTracking[oid]['oid_to_externalId'] = valToUse
                
         print('Tracking subscription data for ' + valToUse)
        
         # Allow for up to 3600 seconds of data
         subscriberTracking[valToUse]['aqmData'] = []
        
         # Track mark if provided
         if mark:
                subscriberTracking[mark] = valToUse
                subscriberTracking[valToUse]['mark'].append(mark)
                #print 'Storing subscription mark = "' + mark + '" = ' + valToUse
        
        elif action == 'addSubscription': 
         # Two possible IDs for this object
         if userId:
                idx = 'userId'
                valToUse = userId
         else:
                idx = 'userExternalId'
                valToUse = externalId
        
         if 'subscriptions' not in userTracking[valToUse]: userTracking[valToUse]['subscriptions'] = []
         userTracking[valToUse]['subscriptions'].append(externalId)
        
        elif action == 'removeSubscriptionFromUser': 
         valToUse = userId
         try: userTracking[valToUse]['subscriptions'].remove(externalId)
         except: pass
                
        elif action in ['deleteSubscription', 'deleteSubscriber']: 
                valToUse = externalId
                
                if valToUse in subscriberTracking:
                        # See if this was an OID
                        try: valToUse = subscriberTracking[valToUse]['oid_to_externalId']
                        except: pass
                        
                        # Remove the item
                        subscriberTracking['externalId'].remove(valToUse)
                        for item in subscriberTracking[valToUse]['mark']: del subscriberTracking[item]
                        del subscriberTracking[valToUse]
                        #print 'Deleted subscription ' + str(valToUse)
         
        elif action == 'deleteUser': 
                # Two possible IDs for this object
                if userId:
                        idx = 'userId'
                        valToUse = userId
                else:
                        idx = 'userExternalId'
                        valToUse = externalId
                
                if valToUse in userTracking:
                        save_valToUse = valToUse
                        # See if this was an OID
                        try:
                             valToUse = userTracking[valToUse]['oid_to_externalId']
                             
                             # Remove the item
                             userTracking['userId'].remove(valToUse)
                             for item in userTracking[valToUse]['mark']: del userTracking[item]
                             del userTracking[valToUse]
                             #print 'Deleted user ' + str(valToUse)
                        except: del userTracking[save_valToUse]

        elif action in ['modifyUser']: 
                # Skip
                kef=1
        
        elif action == 'deleteGroup': 
                valToUse = groupId
                
                if valToUse in groupTracking:
                        # See if this was an OID
                        try: valToUse = groupTracking[valToUse]['oid_to_externalId']
                        except: pass
                        
                        # Remove the item
                        groupTracking['groupId'].remove(valToUse)
                        for item in groupTracking[valToUse]['mark']: del groupTracking[item]
                        del groupTracking[valToUse]
                        #print 'Deleted group ' + str(valToUse)
        
        elif action == 'createGroup': 
         valToUse = groupId
         
         # Track this group and create a holding place for future items
         groupTracking['groupId'].append(valToUse)
         groupTracking[valToUse] = {}
         groupTracking[valToUse]['id'] = valToUse
         groupTracking[valToUse]['externalId'] = []
         groupTracking[valToUse]['taskId'] = None
         groupTracking[valToUse]['valToUse'] = []
         groupTracking[valToUse]['parentGroupId'] = []
         groupTracking[valToUse]['groupId'] = []
         groupTracking[valToUse]['offerId'] = []
         groupTracking[valToUse]['mark'] = []
         groupTracking[valToUse]['sessions'] = []
         groupTracking[valToUse]['timeFirstSession'] = 0
         groupTracking[valToUse]['TotalGranted'] = 0
         groupTracking[valToUse]['TotalUsed'] = 0
         groupTracking[valToUse]['dataPoints'] = {}
         
         # May need to switch ID to external ID
         if valToUse.isdigit() and RESTInst:
                oid = REST_UTIL.getGroupOID(RESTInst,queryValue=valToUse)
                groupTracking[oid] = {}
                groupTracking[oid]['oid_to_externalId'] = valToUse
                
         #print 'Tracking group data for ' + valToUse
        
         # Track mark if provided
         if mark:
                groupTracking[mark] = valToUse
                groupTracking[valToUse]['mark'].append(mark)
                #print 'Storing group mark = "' + mark + '" = ' + valToUse
        
        elif action == 'modifyGroup':
         valToUse = groupId
         
         # Action to take iff modifying the external ID
         if modId:
                # Want to move the old external ID to the new one
                groupTracking[modId] = copy.deepcopy(groupTracking[valToUse])

                # Remove old entry in groupTracking['groupId']
                groupTracking['groupId'].remove(valToUse)
                
                # Add new entry
                groupTracking['groupId'].append(modId)
                
                # Delete old group ID
                del groupTracking[valToUse]
                 
                # Update subscriber data.
                # May not have subscription external IDs here, so check all of them.
                for subscriber in groupTracking[modId]['externalId']:
                        subscriberTracking[subscriber]['parentGroupId'].remove(valToUse)
                        subscriberTracking[subscriber]['parentGroupId'].append(modId)
                
                # ** MISSING: Need to update parent groups so they track this new ID
                # ** MISSING: Need to update child  groups so they track this new ID
                
         # Add new entry
         groupTracking['groupId'].append(modId)
         
        elif action == 'addSubscriberToGroup': 
         # Assume subscriber has been created
         groupTracking[groupId]['externalId'].append(externalId)
         
         # May be a subscriber or a subscription
         try:
                subscriberTracking[externalId]['parentGroupId'].append(groupId) 
                #print 'Adding subscriber ' + externalId + ' to group ' + groupId
         except:
                subscriberTracking[externalId]['parentGroupId'].append(groupId) 
                #print 'Adding subscription ' + externalId + ' to group ' + groupId
                
        elif action == 'removeSubscriberFromGroup': 
         # Assume subscriber has been created
         groupTracking[groupId]['externalId'].remove(externalId)
         # May be a subscriber or a subscription
         try:
                subscriberTracking[externalId]['parentGroupId'].remove(groupId) 
                #print 'Remove subscriber ' + externalId + ' from group ' + groupId
         except:
                subscriberTracking[externalId]['parentGroupId'].remove(groupId) 
                #print 'Removing subscription ' + externalId + ' from group ' + groupId

        elif action == 'addSubGroupToGroup': 
         # Assume groups have been created
         groupTracking[groupId]['groupId'].append(subGroupId)
         groupTracking[subGroupId]['parentGroupId'].append(groupId) 
         #print 'Adding subgroup ' + subGroupId + ' to group ' + groupId

        elif action == 'removeSubGroupFromGroup': 
         # Assume groups have been created
         groupTracking[groupId]['groupId'].remove(subGroupId)
         groupTracking[subGroupId]['parentGroupId'].remove(groupId) 
         #print 'Adding subgroup ' + subGroupId + ' to group ' + groupId

        elif action == 'groupSubscribeToOffer':
          # track this
          if taskId:    groupTracking[groupId]['taskId'] = taskId
          else:         groupTracking[groupId]['offerId'].extend(offerId)
         
        elif action in ['groupUnsubscribeFromOffer', 'groupCancelOffer']:
          # track this
          if taskId:    groupTracking[groupId]['taskId'] = None
          elif resourceId:
                # Remember that resource IDs start at 1 and array indices start at 0...
                for idx in range(len(resourceId)):
                        if len(groupTracking[groupId]['offerId']) >= int(resourceId[idx]):
                                groupTracking[groupId]['offerId'][int(resourceId[idx])-1] = 'Deleted'
         
        elif action in ['modifySubscriber', 'modifySubscription']:
         # Action to take iff modifying the external ID
         if modId:
                # Need to udpate every group the sub is part of
                for group in subscriberTracking[externalId]['parentGroupId']:
                        groupTracking[group]['externalId'].remove(externalId)
                        groupTracking[group]['externalId'].append(modId)
                
                # Want to move the old external ID to the new one
                subscriberTracking[modId] = copy.deepcopy(subscriberTracking[externalId])

                # Remove old entry in subscriberTracking['externalId']
                subscriberTracking['externalId'].remove(externalId)

                # Add new entry
                subscriberTracking['externalId'].append(modId)
                
                # Update device to  point to updated external Id
                for device in subscriberTracking[modId]['deviceId']:
                        deviceTracking[device]['externalId'] = modId
         
                # Delete subscriberTracking[externalId]
                del subscriberTracking[externalId]
                 
        elif action in ['addSubscriber', 'createSubscriberAndDevice']:
         print('Adding external ID ' + externalId + ' to subscriberTracking')
         # Create this device
         updateTrackingData('createSubscriber', externalId = externalId, mark = mark, userId=userId, RESTInst=RESTInst)
                        
         # Track offers if any were defined
         if offerId:
                updateTrackingData('subscribeToOffer', externalId = externalId, offerId = offerId)
         
         # If a device was assigned here, then need to track it as well
         if deviceId != '0' and deviceId != None:
                updateTrackingData('addDeviceToSubscriber', externalId = externalId, deviceId = deviceId, accessNumbers = accessNumbers, mark = mark, RESTInst=RESTInst)
                
        elif action.lower() == 'subscribetooffer':
          # track this
          if taskId:    subscriberTracking[externalId]['taskId'] = taskId
          else:
                # Loop through offers
                subscriberTracking[externalId]['offerId'].extend(offerId)
         
        elif action.lower() == 'unsubscribefromoffer':
          # track this
          if taskId:    subscriberTracking[externalId]['taskId'] = None
          elif resourceId:
                # Remember that resource IDs start at 1 and array indices start at 0...
                for idx in range(len(resourceId)):
                        if len(subscriberTracking[externalId]['offerId']) >= int(resourceId[idx]):
                                subscriberTracking[externalId]['offerId'][int(resourceId[idx])-1] = 'Deleted'

        elif action.startswith('createDevice'):
         valToUse = deviceId
         
         # Track this
         deviceTracking['deviceId'].append(valToUse)
         deviceTracking[valToUse] = {}
         deviceTracking[valToUse]['accessNumbers'] = []
         deviceTracking[valToUse]['mark'] = []
         deviceTracking[valToUse]['offerId'] = []
         deviceTracking[valToUse]['sessions'] = []
         deviceTracking[valToUse]['externalId'] = None
                
         # May need to switch ID to external ID
         if valToUse.isdigit() and RESTInst:
                oid = REST_UTIL.getDeviceOID(RESTInst,queryValue=valToUse)
                deviceTracking[oid] = {}
                deviceTracking[oid]['oid_to_externalId'] = valToUse
                
         # Track mark if provided
         if mark:
                deviceTracking[mark] = valToUse
                deviceTracking[valToUse]['mark'].append(mark)
                #print 'Storing device mark = "' + mark + '" = ' + valToUse
        
         # Modify this device to update all other fields
         updateTrackingData('modifyDevice', deviceId = valToUse, accessNumbers = accessNumbers)
                
        elif action == 'deleteDevice':
                valToUse = deviceId
                
                if valToUse in deviceTracking:
                        # Swith OID to external ID if input is OID
                        try: valToUse = deviceTracking[valToUse]['oid_to_externalId']
                        except: pass
                        
                        # Clean up access number tracking data
                        for aN in deviceTracking[valToUse]['accessNumbers']:
                                # Remove access number
                                accessNumberTracking['accessNumbers'].remove(aN)
                        
                        # Delete the access number entry
                        del accessNumberTracking[aN]
                        
                        # Un-track this
                        deviceTracking['deviceId'].remove(valToUse)
                        for item in deviceTracking[valToUse]['mark']: del deviceTracking[item]
                        del deviceTracking[valToUse]
        
        elif action == 'modifyDevice':
         # May have changed IMSI.  Need to copy/delete structure in this case
         if modId:
                # Copy to new ID
                deviceTracking[modId] = copy.deepcopy(deviceTracking[deviceId])
                
                # Remove old ID
                del(deviceTracking[deviceId])
                
                # Update device tracking array
                deviceTracking['deviceId'].remove(deviceId)
                deviceTracking['deviceId'].append(modId)
                
                # Update marks
                for mark in deviceTracking[modId]['mark']: deviceTracking[mark] = modId
                
                # Update access numbers
                for aN in deviceTracking[modId]['accessNumbers']: accessNumberTracking[aN]['deviceId'] = modId
                
                # Update subscriber pointing to this device.
                # Device may not be associated with a subscriber...
                try:
                        ext = deviceTracking[modId]['externalId']
                        subscriberTracking[ext]['deviceId'].remove(deviceId)
                        subscriberTracking[ext]['deviceId'].append(modId)
                except: pass
                
         # Update if defined
         if accessNumbers:
                # Clean up access number tracking data
                for aN in deviceTracking[deviceId]['accessNumbers']:
                        accessNumberTracking['accessNumbers'].remove(aN)
                        accessNumberTracking[aN] = {}
                        
                # Clean the device of access numbers
                deviceTracking[deviceId]['accessNumbers'] = []
                
                # May be a list or a single entity
                accessNumToUse = []
                if type(accessNumbers) == type(list()):
                        accessNumToUse = accessNumbers
                else:
                        accessNumToUse.append(accessNumbers)
                
                for aN in accessNumToUse:
                        deviceTracking[deviceId]['accessNumbers'].append(aN)
                        accessNumberTracking['accessNumbers'].append(aN)
                        accessNumberTracking[aN] = {}
                        accessNumberTracking[aN]['deviceId'] = deviceId
                        accessNumberTracking[aN]['sessions'] = []
                                
                        #print 'Adding access number ' + aN + ' to device ' + deviceId
         
        elif action in ['removeDeviceFromSubscriber', 'removeDeviceFromSubscription']:
         deviceTracking[deviceId]['externalId'] = None
         if action.count('Subscriber'): subscriberTracking[externalId]['deviceId'].remove(deviceId) 
         else:                          subscriberTracking[externalId]['deviceId'].remove(deviceId) 
        
        elif action in ['addDeviceToSubscriber', 'addDeviceToSubscription']:
         # Device may already be created.  Check first
         if not deviceTracking['deviceId'].count(deviceId):
                # Change mark to be device specific if one was input
                newMark = mark
                if newMark:
                        # Want mark from this call to reflect the device number within the subscriber
                        if action.count('Subscriber'):  _ext = '_D' + str(len(subscriberTracking[externalId]['deviceId']))
                        else:                           _ext = '_D' + str(len(subscriberTracking[externalId]['deviceId']))
                        newMark = mark+_ext
                        
                # Create this device
                updateTrackingData('createDevice', deviceId = deviceId, accessNumbers = accessNumbers, mark = newMark, RESTInst=RESTInst)
                
         # This makes the association between the device and subscriber/subscription, so track that 
         deviceTracking[deviceId]['externalId'] = externalId
         if action.count('Subscriber'): subscriberTracking[externalId]['deviceId'].append(deviceId) 
         else:                          subscriberTracking[externalId]['deviceId'].append(deviceId)
         #print 'Adding device ' + deviceId + ' to subscriber ' + externalId
                
        elif action in  ['devicePurchaseOffer', 'deviceSubscribeToOffer']:
                # Store this
                deviceTracking[deviceId]['offerId'].extend(offerId)
        
        elif action in ['deviceCancelOffer', 'deviceUnsubscribeFromOffer']:
          if resourceId:
                # track this
                for idx in range(len(resourceId)):
                        if len(deviceTracking[deviceId]['offerId']) >= int(resourceId[idx]):
                                deviceTracking[deviceId]['offerId'][int(resourceId[idx])-1] = 'Deleted'
        
        else:
                # Unexpected action
                print('WARNING: updateTrackingData() received action "' + action + '" and does not have code to process this')
        
        return 

#==========================================================
def checkIfSessionTracked(sessionId, ratingGroup):
        # Get sub-session ID
        subSession = str(sessionId) + '_' + str(ratingGroup)
        
        # See if the session exists
        if subSession in sessionTracking: return True
        else: return False
        
#==========================================================
def updateSubAndGroupSessionData(externalId, eventDelta, grantedAmount, usedAmount, reqAmount):
#       print 'Updating subsciber ID = ' + externalId + ' with event delta = ' + str(eventDelta)
        subscriberTracking[externalId]['TotalGranted'] += int(grantedAmount)
        subscriberTracking[externalId]['TotalUsed'] += int(usedAmount)
                
        # Need to make sure to handle multiple points at the same time
        if str(eventDelta) not in subscriberTracking[externalId]['dataPoints']:
                # Create entry
                subscriberTracking[externalId]['dataPoints'][str(eventDelta)] = ((1, int(usedAmount), int(reqAmount), int(grantedAmount), subscriberTracking[externalId]['TotalGranted'], subscriberTracking[externalId]['TotalUsed'], eventDelta))
        else:
                # Need to add to existing entry for this time offset.
                # Can't seem to update the tuple by referencing the fields within the tuple...
                # So create a new, updated tuple and reset the field.
                count           = subscriberTracking[externalId]['dataPoints'][str(eventDelta)][0] + 1
                usedAmount      = subscriberTracking[externalId]['dataPoints'][str(eventDelta)][1] + int(usedAmount)
                reqAmount       = subscriberTracking[externalId]['dataPoints'][str(eventDelta)][2] + int(reqAmount)
                grantedAmount   = subscriberTracking[externalId]['dataPoints'][str(eventDelta)][3] + int(grantedAmount)
                eventDelta      = subscriberTracking[externalId]['dataPoints'][str(eventDelta)][6]
                subscriberTracking[externalId]['dataPoints'][str(eventDelta)] = ((1, int(usedAmount), int(reqAmount), int(grantedAmount), subscriberTracking[externalId]['TotalGranted'], subscriberTracking[externalId]['TotalUsed'], eventDelta))

        # Add parent if defined
        if externalId and len(subscriberTracking[externalId]['parentGroupId']) > 0: groupId = subscriberTracking[externalId]['parentGroupId'][0]
        else: groupId = None
        
        # Update all parent groups in the hierarchy
        while groupId:
#               print 'Updating group ID = ' + groupId + ' with event delta = ' + str(eventDelta)
                # Update total values here
                groupTracking[groupId]['TotalGranted'] += int(grantedAmount)
                groupTracking[groupId]['TotalUsed'] += int(usedAmount)
                
                # Need to make sure to handle multiple points at the same time
                if str(eventDelta) not in groupTracking[groupId]['dataPoints']:
                        # Create entry
                        groupTracking[groupId]['dataPoints'][str(eventDelta)] = ((1, int(usedAmount), int(reqAmount), int(grantedAmount), groupTracking[groupId]['TotalGranted'], groupTracking[groupId]['TotalUsed'], eventDelta))
                else:
                        # Need to add to existing entry for this time offset.
                        # Can't seem to update the tuple by referencing the fields within the tuple...
                        # So create a new, updated tuple and reset the field.
                        count           = groupTracking[groupId]['dataPoints'][str(eventDelta)][0] + 1
                        usedAmount      = groupTracking[groupId]['dataPoints'][str(eventDelta)][1] + int(usedAmount)
                        reqAmount       = groupTracking[groupId]['dataPoints'][str(eventDelta)][2] + int(reqAmount)
                        grantedAmount   = groupTracking[groupId]['dataPoints'][str(eventDelta)][3] + int(grantedAmount)
                        eventDelta      = groupTracking[groupId]['dataPoints'][str(eventDelta)][6]
                        groupTracking[groupId]['dataPoints'][str(eventDelta)] = ((1, int(usedAmount), int(reqAmount), int(grantedAmount), groupTracking[groupId]['TotalGranted'], groupTracking[groupId]['TotalUsed'], eventDelta))
                        
                # Get next parent ID in the hierarchy
                if len(groupTracking[groupId]['parentGroupId']) > 0: groupId = groupTracking[groupId]['parentGroupId'][0]
                else: groupId = None
        return

#==========================================================
def updateSessionTrackingData(deviceId=0, accessNumber=0, requestType='init', sessionId=0, ratingGroup=0, time=0, reqAmount=0, usedAmount=0, grantedAmount=0, mark=None, interface='gy', vqt=0, validityTime=0, timeBuffer=0.0, usedVelocity=0.0, grantedVelocity=0.0, eventDelta=1, aqmFunction='0', totalToUse=0, index=0, SkipFlag=False, sessionOffset=0, verbose='normal', diamDebug=True):
   # If no checks are on, then can;t do anything here
#   if noCheckFlag:
#       print 'NOTE:  noChecks flag is on.  No tracking is enabled.'
#       return
   
   if diamDebug:  
    print('updateSessionTrackingData: device/access = ' + str(deviceId) + '/' + str(accessNumber) + ', sessionId/ratingGroup = ' + str(sessionId) + '/' + str(ratingGroup))
   
   # Assume no creation/deletion required
   deleteFlag = False
   createFlag = False
        
   # Init locals
   externalId = None
   
   # Get sub-session ID
   subSession = str(sessionId) + '_' + str(ratingGroup)
        
   # Sanity check:  if not an initial and the session does not exist, then need to exit right away.
   # Covers case where tool is invoked in the middle of a session
#   if requestType == 'interim' and subSession not in sessionTracking:
#       print 'WARNING:  no session exists for session ' + subSession + ' and this is an interim message.  Not tracking this.
#       return
   
   # Check if a device was passed in (prioriy over access number).
   # Could also have a login ID which (we hope...) is non-numeric.
   try:
        if int(deviceId) > -1:  useDeviceID = True
        else:                   useDeviceID = False
   except:                      useDeviceID = True
        
   # Special code for tracking when noChecks are enabled
   if noCheckFlag:
        if requestType == 'initial': createFlag = True
        elif requestType == 'interim' and subSession not in sessionTracking['sessions']: createFlag = True
        elif requestType == 'term':
                deleteFlag = True
                if subSession not in sessionTracking['sessions']: createFlag = True
   
   elif useDeviceID:
        # Chck if an init 
        if requestType == 'initial':
                # Make sure the session ID doesn't already exist.
                if deviceTracking[deviceId]['sessions'].count(subSession):
                        print('WARNING:  Device ' + deviceId + ' already has an active session_RG combination of ' + subSession)
                        #sys.exit('Done')
                else:
                        # Set create flag to true
                        createFlag = True
        
        elif requestType == 'interim':
                # Sub-sessions can come in as part of interim messages.
                if not deviceTracking[deviceId]['sessions'].count(subSession):
                        print('Adding sub session ' + subSession + ' as part of interim message')
                        # Set create flag to true
                        createFlag = True
                        
        # If a term and session doesn't exist, then create one
        elif requestType == 'term':
                # Set delete flag to true
                deleteFlag = True
                
                # See if we need to create this first (for logging purposes)
                if not deviceTracking[deviceId]['sessions'].count(subSession):
                        # Set create flag to true
                        createFlag = True
                
        # Check if we need to create
        if createFlag:
                # Add to the list of sessions
                deviceTracking[deviceId]['sessions'].append(subSession)
                externalId = deviceTracking[deviceId]['externalId']
                if REST_UTIL.subUrl == 'subscriber':
                        subscriberTracking[externalId]['sessions'].append(subSession)
                else:   subscriberTracking[externalId]['sessions'].append(subSession)
                if REST_UTIL.subUrl == 'subscriber':
                 if len(subscriberTracking[externalId]['parentGroupId']) > 0: 
                        groupId = subscriberTracking[externalId]['parentGroupId'][0]
                        groupTracking[groupId]['sessions'].append(subSession)
                else:
                 if len(subscriberTracking[externalId]['parentGroupId']) > 0: 
                        groupId = subscriberTracking[externalId]['parentGroupId'][0]
                        groupTracking[groupId]['sessions'].append(subSession)
                #print 'Adding session ' + subSession + ' to device ' + deviceId
        
        # Check if need to delete
        if deleteFlag:
                # Remove data
                deviceTracking[deviceId]['sessions'].remove(subSession)
                externalId = deviceTracking[deviceId]['externalId']
                if REST_UTIL.subUrl == 'subscriber':
                        subscriberTracking[externalId]['sessions'].remove(subSession)
                else:   subscriberTracking[externalId]['sessions'].remove(subSession)
                if REST_UTIL.subUrl == 'subscriber':
                 if len(subscriberTracking[externalId]['parentGroupId']) > 0: 
                        groupId = subscriberTracking[externalId]['parentGroupId'][0]
                        groupTracking[groupId]['sessions'].remove(subSession)
                else:
                 if len(subscriberTracking[externalId]['parentGroupId']) > 0: 
                        groupId = subscriberTracking[externalId]['parentGroupId'][0]
                        groupTracking[groupId]['sessions'].remove(subSession)
                #print 'Removing session ' + subSession + ' from device ' + deviceId
        
        # Want external ID for all scenarios (missing interim in the above)
        externalId = deviceTracking[deviceId]['externalId']
        
   # Check if a access number was passed in
   elif int(accessNumber) > -1:
        if requestType == 'initial':
                # Make sure the session ID doesn't already exist.
                if accessNumberTracking[accessNumber]['sessions'].count(subSession):
                        print('WARNING:  Access Number ' + accessNumber + ' already has an active session_RG combination of ' + subSession)
                        #sys.exit('Done')
                else:
                        # Set create flag to true
                        createFlag = True
        
        elif requestType == 'interim':
                # Sub-sessions can come in as part of interim messages.
                if not accessNumberTracking[accessNumber]['sessions'].count(subSession):
                        print('Adding sub session ' + subSession + ' as part of interim message')
                        # Set create flag to true
                        createFlag = True
                        
        # If a term and session doesn't exist, then create one
        elif requestType == 'term':
                # Set delete flag to true
                deleteFlag = True
                
                # See if we need to create this first (for logging purposes)
                if not accessNumberTracking[accessNumber]['sessions'].count(subSession):
                        # Set create flag to true
                        createFlag = True
                
        # Check if we need to create
        if createFlag:
                # Add to the list of sessions
                accessNumberTracking[accessNumber]['sessions'].append(subSession)
                deviceId = accessNumberTracking[accessNumber]['deviceId']
                externalId = deviceTracking[deviceId]['externalId']
                if REST_UTIL.subUrl == 'subscriber':
                        subscriberTracking[externalId]['sessions'].append(subSession)
                else:   subscriberTracking[externalId]['sessions'].append(subSession)
#               print 'Adding session ' + subSession + ' to accessNumber ' + accessNumber
        
        # Check if need to delete
        if deleteFlag:
                # Remove data
                accessNumberTracking[accessNumber]['sessions'].remove(subSession)
                deviceId = accessNumberTracking[accessNumber]['deviceId']
                externalId = deviceTracking[deviceId]['externalId']
                if REST_UTIL.subUrl == 'subscriber':
                        subscriberTracking[externalId]['sessions'].remove(subSession)
                else:   subscriberTracking[externalId]['sessions'].remove(subSession)
   
        # Want external ID for all scenarios (missing interim in the above)
        deviceId = accessNumberTracking[accessNumber]['deviceId']
        externalId = deviceTracking[deviceId]['externalId']
        
   #### Now process session data itself (independent of access number, device, or subscriber data)
   # Check if we need to create
   if createFlag:
        # Create session data
        sessionTracking['sessions'].append(subSession)
        sessionTracking[subSession] = {}
        sessionTracking[subSession]['sessionId'] = sessionId
        sessionTracking[subSession]['id'] = subSession
        sessionTracking[subSession]['externalId'] = externalId
        sessionTracking[subSession]['deviceId'] = deviceId
        sessionTracking[subSession]['accessNumber'] = accessNumber
        sessionTracking[subSession]['startTime'] = time
        sessionTracking[subSession]['eventTime'] = time
        sessionTracking[subSession]['endTime'] = None
        sessionTracking[subSession]['eventCount'] = 0
        sessionTracking[subSession]['events'] = []
        sessionTracking[subSession]['sessionOffset'] = sessionOffset
        sessionTracking[subSession]['interface'] = interface.lower()
        sessionTracking[subSession]['interface'] = interface.lower()
        sessionTracking[subSession]['lookAheadVelocity'] = None
        
        # Fields differ between interfaces
        if interface.lower() in ['gy', '5g']:
                sessionTracking[subSession]['TotalUsed'] = 0
                sessionTracking[subSession]['TotalRequested'] = 0
                sessionTracking[subSession]['TotalGranted'] = 0
                sessionTracking[subSession]['currentReservation'] = 0
                sessionTracking[subSession]['lastGrant'] = 0
                sessionTracking[subSession]['vqt'] = 0
                sessionTracking[subSession]['validityTime'] = None
                sessionTracking[subSession]['timeBuffer'] = 0.0
        
        # If mark passed in, then check for an existing mark
        if mark:
                if mark in sessionTracking: print('WARNING:  duplicate session mark specified (' + mark + ').  Ignoring duplicate.')
                else:
                        # Store mark data
                        sessionTracking[mark] = subSession
                        sessionTracking[subSession]['mark'] = mark
                        
#       print 'Adding session ' + subSession + ' data'
                
   # Update session data if key exists (cover case where tool invoked with just an event to an existing session)
   if subSession in sessionTracking:
        # Debug data
#       print 'Updating session ' + subSession + ' data'
        sessionTracking[subSession]['eventCount'] += 1
        if interface.lower() in ['gy', '5g']:
#               print 'Updating device ID = ' + sessionTracking[subSession]['deviceId'] + ' with event delta = ' + str(eventDelta)
                
                # Current reservation is always less the last grant and more the current granted amount
                sessionTracking[subSession]['currentReservation'] -= int(sessionTracking[subSession]['lastGrant'])
                sessionTracking[subSession]['currentReservation'] += int(grantedAmount)
                
                sessionTracking[subSession]['lastGrant'] = grantedAmount
                sessionTracking[subSession]['TotalUsed'] += int(usedAmount)
                sessionTracking[subSession]['TotalRequested'] += int(reqAmount)
                sessionTracking[subSession]['TotalGranted'] += int(grantedAmount)
                sessionTracking[subSession]['timeBuffer'] = timeBuffer
                sessionTracking[subSession]['eventTime'] = time
                sessionTracking[subSession]['totalToUse'] = totalToUse
                sessionTracking[subSession]['index'] = index
                sessionTracking[subSession]['SkipFlag'] = SkipFlag
                sessionTracking[subSession]['aqmFunction'] = aqmFunction
                sessionTracking[subSession]['events'].append((int(usedAmount), int(reqAmount), int(grantedAmount), float(usedVelocity), float(grantedVelocity), int(eventDelta), int(sessionTracking[subSession]['TotalUsed']), int(sessionTracking[subSession]['TotalGranted']), int(validityTime)))
                sessionTracking[subSession]['vqt'] = vqt
                sessionTracking[subSession]['validityTime'] = validityTime
                
                # If AQM is in effect, then update subscriber and group session data.  Otherwise don't bother (as the data is only relevent for AQM sessions).
                if aqmFunction != '0': updateSubAndGroupSessionData(externalId, eventDelta, grantedAmount, usedAmount, reqAmount)

        else:
                # Need to add Sy data here.  Policy values put into the reqAmount parameter.
                # Not all calls do this yet...
                if type(reqAmount) is list: sessionTracking[subSession]['events'].extend(reqAmount)
                else: sessionTracking[subSession]['events'].append('None')

   else:
        # really shouldn't be here...
        print('WARNING:  received a session ' + requestType + ' message for deviceId/accessNumber ' + str(deviceId) + '/' + str(accessNumber) + ' but did not have anyhing recorded for it...')
        
   # Check if need to delete
   if deleteFlag:
        # Update end time
        sessionTracking[subSession]['endTime'] = time
                
        # Log session data
        if verbose.lower() not in ['low', 'none'] or str(aqmFunction) != '0': sessionLogData(subSession, sessionTracking[subSession], aqmFunction=aqmFunction)
                
        # Remove mark if defined
        if 'mark' in sessionTracking[subSession]: del sessionTracking[sessionTracking[subSession]['mark']]
                
        # Remove session data
        sessionTracking['sessions'].remove(subSession)
        del sessionTracking[subSession]
   
   return 

#==========================================================
def sessionGetLastAmounts(sessionId, ratingGroup):
   lastGrant = sessionGetValue(sessionId, ratingGroup, 'lastGrant')
   vqt = sessionGetValue(sessionId, ratingGroup, 'vqt')
   validityTime = sessionGetValue(sessionId, ratingGroup, 'validityTime')
   
   # Debug output
#   print 'Returning granted/vqt/validityTime amount for session ' + sessionId + ' = ' + str(lastGrant) + '/' + str(vqt) + '/' + str(validityTime)
   
   return (lastGrant, vqt, validityTime)

#==========================================================
def sessionGetSessionStartTime(sessionId, ratingGroup):
   return  sessionGetValue(sessionId, ratingGroup, 'startTime')

#==========================================================
def sessionSetValue(sessionId, ratingGroup, parameter, value):
   # If no checks are on, then can;t do anything here
#  if noCheckFlag:
#       print 'NOTE:  noChecks flag is on.  No tracking is enabled.'
#       return 0

   # Get sub-session ID
   subSession = str(sessionId) + '_' + str(ratingGroup)
        
   # Make sure the session exists. This API can be used to create new session entries as needed.
   if subSession in sessionTracking: sessionTracking[subSession][parameter] = value

#==========================================================
def sessionGetValue(sessionId, ratingGroup, parameter):
   # If no checks are on, then can;t do anything here
#   if noCheckFlag:
#       print 'NOTE:  noChecks flag is on.  No tracking is enabled.'
#       return 0

   # Get sub-session ID
   subSession = str(sessionId) + '_' + str(ratingGroup)
        
   # Make sure the entry exists (user may invoke tool in the middle of a session)
   if subSession in sessionTracking and parameter in sessionTracking[subSession]:
        retVal = sessionTracking[subSession][parameter]
   else:
        retVal = 0
   
   return retVal

#==========================================================
def sessionLogData(subSession, sessionData, outputFileName = None, aqmFunction='0'):
   # Skip if performance enabled and AQM disabled
   if not DIAMU.diameterFileDebugFlag and aqmFunction == '0': return
    
   # Separate out session ID and rating group from subSession value
   sessionId = subSession.split('_')[0]
   ratingGroup = subSession.split('_')[1]
        
   # Get data
   externalId = sessionTracking[subSession]['externalId']
   deviceId = str(sessionGetValue(sessionId, ratingGroup, 'deviceId'))
   interface = sessionTracking[subSession]['interface']
        
   # Common output
   print('\nSession Termination Data:')
   print('Session Type:  ' + interface.capitalize())
   print('Session ID/RG: ' + str(sessionId) + '/' + str(ratingGroup))
   print('Sub/Device ID: ' + str(externalId) + '/' + str(deviceId))
   if externalId in subscriberTracking and len(subscriberTracking[externalId]['parentGroupId']) > 0: 
        print('Parent Ext ID: ' + str(subscriberTracking[externalId]['parentGroupId'][0]))
   print('Start time:    ' + str(sessionGetValue(sessionId, ratingGroup, 'startTime')))
   print('End time:      ' + str(sessionGetValue(sessionId, ratingGroup, 'endTime')))
   
   # If not Gy or 5G, then exit now
   if interface.lower() not in ['gy', '5g']:
        # Good output
        print('# Events:      ' + str(sessionGetValue(sessionId, ratingGroup, 'eventCount')) + '\n')
        
        # Exit
        return
   
   # Resume Gy output
   print('Total R/G/U:   ' + str(sessionGetValue(sessionId, ratingGroup, 'TotalRequested')) + '/' \
                           + str(sessionGetValue(sessionId, ratingGroup, 'TotalGranted'))   + '/' \
                           + str(sessionGetValue(sessionId, ratingGroup, 'TotalUsed')))
   print('# Events:      ' + str(sessionGetValue(sessionId, ratingGroup, 'eventCount')))
      
   # If less than 50 events, then output each one
   eventCount = int(sessionGetValue(sessionId, ratingGroup, 'eventCount'))
   if eventCount < 50:
        print('usedAmount,reqAmount,grantedAmount,usedVelocity,grantedVelocity,eventDelta,TotalUsed,TotalGranted,validityTime')
        for i in range(eventCount): print(str(sessionTracking[subSession]['events'][i]))
   
   # So the output looks nice...
   print('\n')
        
   # If AQM, then additional output
   if aqmFunction != '0':
        # Debug output
#       print 'Processing externalId: ' + externalId + ', session ' + sessionId
                
        # Open file for writing
        fileName = '' + COMMON.resultsDir + '/D' + deviceId + '_' + sessionId
        f = open(fileName, 'w')
                
        # Echo in header line
        f.write("Time (sec), Used Bytes, Granted Bytes, Time (sec), Used Bps, Granted Bps, Time (sec), Total Used, Total Granted\n")
                
        # Process each point
#       totalGrantedInSession    = str(sessionTracking[subSession]['TotalGranted'])
        for i in range(len(sessionTracking[subSession]['events'])):
                used            = str(sessionTracking[subSession]['events'][i][0])
                granted         = str(sessionTracking[subSession]['events'][i][2])
                usedVelocity    = str(sessionTracking[subSession]['events'][i][3])
                grantedVelocity = str(sessionTracking[subSession]['events'][i][4])
                eventDelta      = str(sessionTracking[subSession]['events'][i][5] + int(sessionTracking[subSession]['sessionOffset']))
                totalUsed       = str(sessionTracking[subSession]['events'][i][6])
                totalGranted    = str(sessionTracking[subSession]['events'][i][7])
                f.write(eventDelta + ',' +      \
                        used + ',' +            \
                        granted + ',' +         \
                        eventDelta + ',' +      \
                        usedVelocity + ',' +    \
                        grantedVelocity + ',' + \
                        eventDelta + ',' +      \
                        totalUsed + ',' +       \
                        totalGranted +          \
                        '\n')
                
        # Close the file
        f.close()

   return 

#==========================================================
def aqmSubscriberLogData(aqmFunction='0'):
        # Skip if performance enabled and AQM disabled
        if not DIAMU.diameterFileDebugFlag and aqmFunction == '0': return
        
        # Loop through each group that was impacted
        for sub in range(len(subscriberTracking['externalId'])):
                externalId = subscriberTracking['externalId'][sub]
                
                # Open file for writing
                fileName = '' + COMMON.resultsDir + '/S' + externalId
                f = open(fileName, 'w')
                
                # Echo in header line
                f.write("Time (sec), Used Bytes, Granted Bytes, Time (sec), Used Bps, Granted Bps, Time (sec), Total Used, Total Granted\n")
                
                # Dumb approach (since I'm struggling getting dictionary entries...)
                for i in range(3600):
                        # Stored event fields are:
                        # ((count, int(usedAmount), int(reqAmount), int(grantedAmount), subscriberTracking[externalId]['TotalGranted'], subscriberTracking[externalId]['TotalUsed'], time))
                        # See if the event exists
                        if str(i) in subscriberTracking[externalId]['dataPoints']:
                                used            = int(subscriberTracking[externalId]['dataPoints'][str(i)][1])
                                granted         = int(subscriberTracking[externalId]['dataPoints'][str(i)][3])
                                totalGranted    = int(subscriberTracking[externalId]['dataPoints'][str(i)][4])
                                totalUsed       = int(subscriberTracking[externalId]['dataPoints'][str(i)][5])
                                eventDelta      = int(subscriberTracking[externalId]['dataPoints'][str(i)][6])
                                
                                # Velocity is delta used / delta time.
                                # If first point, then no velocity.
                                if i == 0: usedVelocity = 0.0
                                else: usedVelocity = float(old_div(totalUsed, eventDelta))
#                                       # Get previous used and time
#                                       prevTotalUsed = int(subscriberTracking[externalId]['dataPoints'][str(prevEventTime)][5])
#                                       usedVelocity = float((totalUsed - prevTotalUsed) / (eventDelta - prevEventTime))
                                
                                # Calculating granted velocity requires QVT, which is not stored (and would get quite complicated).  
                                grantedVelocity = 0.0
                                
                                # Write data to the file
                                f.write(str(eventDelta) + ',' +         \
                                        str(used) + ',' +               \
                                        str(granted) + ',' +            \
                                        str(eventDelta) + ',' +         \
                                        str(usedVelocity) + ',' +       \
                                        str(grantedVelocity) + ',' +    \
                                        str(eventDelta) + ',' +         \
                                        str(totalUsed) + ',' +          \
                                        str(totalGranted) +             \
                                        '\n')
                
                                # Save previous event ID
                                prevEventTime = eventDelta
                
                # Close the file
                f.close()
                
#==========================================================
def aqmGroupLogData(aqmFunction='0'):
        # Skip if performance enabled and AQM disabled
        if not DIAMU.diameterFileDebugFlag and aqmFunction == '0': return
        
        # Loop through each group that was impacted
        for group in range(len(groupTracking['groupId'])):
                groupId = groupTracking['groupId'][group]
                
                # Open file for writing
                fileName = '' + COMMON.resultsDir + '/G' + groupId
                f = open(fileName, 'w')
                
                # Echo in header line
                f.write("Time (sec), Used Bytes, Granted Bytes, Time (sec), Used Bps, Granted Bps, Time (sec), Total Used, Total Granted\n")
                
                # Dumb approach (since I'm struggling getting dictionary entries...)
                for i in range(3600):
                        # Stored event fields are:
                        # ((count, int(usedAmount), int(reqAmount), int(grantedAmount), subscriberTracking[externalId]['TotalGranted'], subscriberTracking[externalId]['TotalUsed'], time))
                        # See if the event exists
                        if str(i) in groupTracking[groupId]['dataPoints']:
                                used            = int(groupTracking[groupId]['dataPoints'][str(i)][1])
                                granted         = int(groupTracking[groupId]['dataPoints'][str(i)][3])
                                totalGranted    = int(groupTracking[groupId]['dataPoints'][str(i)][4])
                                totalUsed       = int(groupTracking[groupId]['dataPoints'][str(i)][5])
                                eventDelta      = int(groupTracking[groupId]['dataPoints'][str(i)][6])
                                
                                # Velocity is delta used / delta time.  Unfortunately with random points the delta can be large with 1 sec time.
                                # Keep it simple and only support the instantaneous used velocity.
                                # If first point, then no velocity.
                                if i == 0: usedVelocity = 0.0
                                else: usedVelocity = float(old_div(totalUsed, eventDelta))
                                        # Get previous used and time
#                                       prevTotalUsed = int(groupTracking[groupId]['dataPoints'][str(prevEventTime)][5])
#                                       usedVelocity = float((totalUsed - prevTotalUsed) / (eventDelta - prevEventTime))
                                
                                # Calculating granted velocity requires QVT, which is not stored (and would get quite complicated).  
                                grantedVelocity = 0.0
                                
                                # Write data to the file
                                f.write(str(eventDelta) + ',' +         \
                                        str(used) + ',' +               \
                                        str(granted) + ',' +            \
                                        str(eventDelta) + ',' +         \
                                        str(usedVelocity) + ',' +       \
                                        str(grantedVelocity) + ',' +    \
                                        str(eventDelta) + ',' +         \
                                        str(totalUsed) + ',' +          \
                                        str(totalGranted) +             \
                                        '\n')
                                
                                # Save previous event ID
#                               prevEventTime = eventDelta
                
                # Close the file
                f.close()
                
#==========================================================

def main():
    x = 1


if __name__ == '__main__':
    main()

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

