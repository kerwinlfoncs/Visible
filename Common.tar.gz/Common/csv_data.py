#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:39:55
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:39:55
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:39:54
# -*- coding: utf-8 -*-

#===============================================================================
#
# Copyright 2010,2011,2012,2013,2014,2015,2016 Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

#  Really shouldn't import anything here...
import os

# Can't import primitives as QA code pulls this in and they don't use any Tools
#from primitives import primData as PRIMDATA

# Define for running notification consume command, using matrixx.all topic
# ** Need to figure out what to read if using queues
CONSUME="java -jar /opt/mtx/bin/mtx_notification_client.jar -address:tcp://notgw:61616 matrixx.all > _notifications"

# *** URL for Diameter AVP encoding: https://www.iana.org/assignments/address-family-numbers/address-family-numbers.xhtml.
# *** Set these values and a "|" with the hex encoded actual value and this gets to the engine properly.

# Define globals
global DiameterHostName
global MyHostName
global servicesConfig
global overrideURL
global overrideOperations
overrideURL = None
overrideOperations = None
TFVariables = []

# *** Multi-Request data ***
# Define structure for multi-request building
V3Builder = None

# Define array for multi-requests
mrCommands = []
mrEnabled = False

# MR command index (so we can map from a multi request index back to external IDs for object tracking)
mrIndex = 0

# Arrays to manage objects referenced by multi-request index
mrIndexObjectExternalId = []

# *** End of MR data

# Define flag for always doing a diff
diffEnableFlag = False

# Define time last command started.  Used for event processing (to capture the last command only)
timeOfLastCommand = ''

# Data for contstant values.
# Initialize testFlag (used sparingly when w eneed to skip over stuff).
constantValue = {}
constantValue['testFlag'] = 'False'


# Define custom URL action data structures
CustDevice = {}
CustSubscriber = {}
CustGroup = {}
CustOffer = {}

CustDevice['elements'] = []
CustSubscriber['elements'] = []
CustGroup['elements'] = []
CustOffer['elements'] = []

# Define dictionaries for rate tags
rateTagId = {}
rateTagExtId = {}

# Flag indicating we should automatically update marks
MessWithMarks = True

# Place holder for release varaible
release = None

# Holds list of products.  Start with default list
productList = ['data', 'voice', 'text', 'mms', 'sms', 'video']

# ********************** MEF Processing data **********************************
# Flag indicating if the previous command did MEF processing (so we don't wait unnecessarily).  Assume True so first command doesn't wait.
previousCommandMefDataProcessed = True

# Get MEF file directory
mefDir = os.path.expandvars(os.getenv('MTX_SHARED_DIR', '/shared')) + '/event_files'

# The following gets the time stamp of the oldest file
# NOTE: Sometimes see a pipe error.  Should be OK here as we want the result of the head command.  
# 
# From the web:
# When head finishes after handling the first line, it exits, closing the other end of the pipe. 
# sort may still be trying to write more, and writing to a closed pipe or socket returns the EPIPE error. 
# But it also raises the SIGPIPE signal, killing the process, unless the signal is ignored or handled. 
# With the signal ignored, sort sees the error, complains, and exits. But if the signal is not ignored, it just dies, without leaving an error message.
mefFileCmdLatest = 'ls -lt --full-time ' + mefDir + '/*gz | sort -r | head -1'

# The following gets the time and file name of all files
mefFileCmd = 'ls -lt --full-time ' + mefDir + '/*gz | sort -r '

# Array of MEF files already processed.  Filled in as a test proceeds.
mefFilesProcessedTime = None

# Flag indicating if we're running locally (as some features require running local).  Assume True.
runningLocal = True

# Define adjustment percentage, above, below characters
adjustPercentChar = '%'
adjustAboveChar = 'a'
adjustBelowChar = 'p'

# Define different currency symbols and country names
# *** NOT WORKING (yet) for non-ascii currencies.  Can't figure out how to check for unicode in a string and then strip off (leaving ascii digits).
# File MTXQA/Common/csv_CmdDiamGy.py, function currencyProcess() tries to do this and the line "if amount.startswith(currencySymbol)" generates an error...
# For now stick with using ascii currencies.
localCurrency = {}
localCurrency['USD'] = '$'
localCurrency['AUS'] = '$'
localCurrency['NZD'] = '$'
localCurrency['GBP'] = '$'
localCurrency['EUR'] = '$'

# Currencies with strings (just different - code doesn't care)
localCurrency['SEK'] = 'Kr'
localCurrency['CHF'] = 'CHF'
localCurrency['OMR'] = 'OMR'

# Default local currency to be USD.  Custom code can change this
localCurrencyToUse = 'USD'

######### Start common input parameter specifications ##################

# The following define all the command line parameters and data file parameters that are used as inputs to each file command or to the command invocation itself.
# * The first parameter is the name of the parameter.  
# * Parameters two through 5 are standard Python input arguments (action, type, default, help string).
# * A 6th parameter, if not None, defines the parameter to use in place of this (in case duplicate names are used across structures)
# * A 7th parameter identifies the structure hierarchy that a field is part of (STILL in development).
# 
# Default input argument lines will be generated and executed for each of these.  Keeps it to one spot where config is required.
# Note:  some of these are primary parameters, so their input args are defined in qa_utils.py.  Set the second param to None to avoid generating another input args line.
# Binary parameters appear to not have a type value.  Set that field to None for binary params.
parameters=[]
# All Payment items together
parameters.append(('payNow', 'store_true', None, False))
parameters.append(('paymentId', 'store', 'string', None))
parameters.append(('paymentType', 'store', 'string', 'CREDIT'))
parameters.append(('paymentToken', 'store', 'string', None))
parameters.append(('paymentAttr', 'store', 'string', None))
parameters.append(('isDefault', 'store_true', None, False))
parameters.append(('isSysDefault', 'store_true', None, False))

# All offer purchase items together
parameters.append(('nonce', 'store', 'string', None))
parameters.append(('offerStatus', 'store', 'string', None))
parameters.append(('cmdCount', 'store', 'string', None))
parameters.append(('chargeMethod', 'store', 'string', None))
parameters.append(('chargeMethodAttr', 'store', 'string', None))
parameters.append(('paymentMethodResourceId', 'store', 'string', None))
parameters.append(('paymentGatewayUserId', 'store', 'int', 0))
parameters.append(('paymentGatewayId', 'store', 'string', None))
parameters.append(('paymentGatewayOneTimeToken', 'store', 'string', None))
parameters.append(('purchaseInfo', 'store_true', None, False))
parameters.append(('contractCancelMode', 'store', 'string', None))
parameters.append(('debtCancellationMode', 'store', 'string', None))
parameters.append(('cycleOwnerType', 'store', 'string', None))
parameters.append(('immediateChange', 'store_true', None, False))
parameters.append(('offerCycleOffset', 'store', 'string', None))
parameters.append(('offerCycleType', 'store', 'string', None))
parameters.append(('offerCycleResourceId', 'store', 'string', None))
parameters.append(('offerCycleStartTime', 'store', 'string', None))
parameters.append(('offerCycleEndTime', 'store', 'string', None))
parameters.append(('preActiveState', 'store_true', None, False))
parameters.append(('activationExpirationTime', 'store', 'string', None))
parameters.append(('activationExpirationRelativeOffsetUnit', 'store', 'string', None))
parameters.append(('activationExpirationRelativeOffset', 'store', 'string', None))
parameters.append(('endTimeRelativeOffsetUnit', 'store', 'string', None))
parameters.append(('endTimeRelativeOffset', 'store', 'string', None))
parameters.append(('offerCycleAlignmentDisabled', 'store_true', None, False))
parameters.append(('autoActivationRelativeOffsetUnit', 'store', 'string', None))
parameters.append(('autoActivationRelativeOffset', 'store', 'string', None))
parameters.append(('autoActivationTime', 'store', 'string', None))
parameters.append(('autoActivationCycleResourceId', 'store', 'string', None))
parameters.append(('isRecurringFailureAllowed', 'store_true', None, False))
parameters.append(('paymentDueDate', 'store', 'string', None))
parameters.append(('contractPeriod', 'store', 'string', None))
parameters.append(('contractInterval', 'store', 'string', None))
parameters.append(('commitmentPeriod', 'store', 'string', None))
parameters.append(('commitmentPeriodInterval', 'store', 'string', None))
parameters.append(('isOpenContract', 'store', 'string', None))
parameters.append(('etcScheduleRangeArray', 'store', 'string', None))
parameters.append(('etcScheduleRangeUnit', 'store', 'string', None))
parameters.append(('paymentScheduleRangeArray', 'store', 'string', None))
parameters.append(('paymentScheduleAmountArray', 'store', 'string', None))
parameters.append(('paymentScheduleLastAmount', 'store', 'string', None))
parameters.append(('delayCharge', 'store', 'string', None))

# Common api event data parameter
parameters.append(('apiEventData', 'store', 'string', None))

# Recharge parameters
parameters.append(('rechargeTime', 'store', 'string', None))
parameters.append(('periodType', 'store', 'string', None))
parameters.append(('periodCoefficient', 'store', 'string', None))

# Threshold parameters
parameters.append(('rechargeAmount', 'store', 'string', None))
parameters.append(('removeThresholdOnly', 'store_true', None, False))
parameters.append(('removeRechargeDataOnly', 'store_true', None, False))

# Multiple object flag
parameters.append(('everySubInGroup', 'store_true', None, False))
parameters.append(('everyDevInGroup', 'store_true', None, False))

# Parameters to skip including MSISDN or IMSI in a usage request
parameters.append(('skipMsisdn', 'store_true', None, False))
parameters.append(('skipImsi', 'store_true', None, False))

# Generic parameters
parameters.append(('accessType', 'store', 'string', None))
parameters.append(('accessNetwork', 'store', 'string', None))
parameters.append(('accessNumbersPrefix', 'store', 'string', None))
parameters.append(('adjustType', 'store', 'string', '1'))
parameters.append(('allAdmins', 'store_true', None, False))
parameters.append(('allDevices', 'store_true', None, False))
parameters.append(('allOffers', 'store_true', None, False))
parameters.append(('amount', 'store', 'string', '0'))
parameters.append(('applyDefaultFilter', 'store_true', None, False))
parameters.append(('aqmFunction', 'store', 'string', '0'))
parameters.append(('aqmRealTimeFlag', 'store_true', None, False))
parameters.append(('aqmMaxVelocity', 'store', 'string', '0'))
parameters.append(('areaCode', 'store', 'string', None))
parameters.append(('background', 'store_true', None, False))
parameters.append(('balanceClassId', 'store', 'string', None))
parameters.append(('balanceStartTime', 'store', 'string', None))
parameters.append(('balanceEndTime', 'store', 'string', None))
parameters.append(('balanceEndTimeExtensionOffset', 'store', 'string', None))
parameters.append(('balanceEndTimeExtensionOffsetUnit', 'store', 'string', None))
parameters.append(('balanceId', 'store', 'string', None))
parameters.append(('balanceIntervalId', 'store', 'string', None))
parameters.append(('balanceQueryType', 'store', 'string', 'BalanceId'))
parameters.append(('billingCycleDisabled', 'store_true', None, None))
parameters.append(('blade', 'store', 'string', None))
parameters.append(('bladeRelative', 'store', 'string', 'lowest'))
parameters.append(('callDirection', 'store', 'string', 'mo'))
parameters.append(('calledStation', 'store', 'string', None))
parameters.append(('calledStationTon', 'store', 'string', '1'))
parameters.append(('calledStationPrefix', 'store', 'string', None))
parameters.append(('calledStationSuffix', 'store', 'string', None))
parameters.append(('callingStation', 'store', 'string', None))
parameters.append(('catalogExternalId', 'store', 'string', '0'))
parameters.append(('catalogQueryType', 'store', 'string', 'ExternalId'))
parameters.append(('cbId', 'store', 'int', 0))
parameters.append(('cellId', 'store', 'string', None))
parameters.append(('cluster', 'store', 'string', '1'))
parameters.append(('cmd', 'store', 'string', None))
parameters.append(('cmdOptions', 'store', 'string', None))
parameters.append(('componentMeterId', 'store', 'int', None))
parameters.append(('contactEmail', 'store', 'string', None))
parameters.append(('contactPhoneNumber', 'store', 'string', None))
parameters.append(('contextValue', 'store', 'string', None))
parameters.append(('continuePastError', 'store_true', None, False))
parameters.append(('command', 'store', 'string', None))
parameters.append(('checkpointInfo', 'store', 'string', None))
parameters.append(('createOnDemand', 'store_false', None, True))
parameters.append(('createMsccFlag', 'store_true', None, False))
parameters.append(('creditFloorPolicy', 'store', 'string', None))
parameters.append(('creditLimitPolicy', 'store', 'string', None))
parameters.append(('currencyCode', 'store', 'string', None))
parameters.append(('customer', 'store', 'string', None))
parameters.append(('customDevName', 'store', 'string', ''))
parameters.append(('customGroupName', 'store', 'string', ''))
parameters.append(('customInfo', 'store', 'string', None))
parameters.append(('customLoginName', 'store', 'string', ''))
parameters.append(('customOfferName', 'store', 'string', ''))
parameters.append(('customSubName', 'store', 'string', ''))
parameters.append(('customUserName', 'store', 'string', ''))
parameters.append(('customURL', 'store', 'string', None))
parameters.append(('customApiEventDataName', 'store', 'string', ''))
parameters.append(('dataFile', 'store', 'string', None))
parameters.append(('dateOffset', 'store', 'string', None))
parameters.append(('default1', 'store', 'string', 'deafultIncludeFile1'))
parameters.append(('default2', 'store', 'string', 'defaultIncludeFile2'))
parameters.append(('default3', 'store', 'string', 'defaultIncludeFile3'))
parameters.append(('default4', 'store', 'string', 'defaultIncludeFile4'))
parameters.append(('default5', 'store', 'string', 'defaultIncludeFile5'))
parameters.append(('defaultParam1', 'store', 'string', None))
parameters.append(('defaultParam2', 'store', 'string', None))
parameters.append(('defaultParam3', 'store', 'string', None))
parameters.append(('defaultParam4', 'store', 'string', None))
parameters.append(('defaultParam5', 'store', 'string', None))
parameters.append(('deleteDevices', 'store_true', None, False))
parameters.append(('deleteSessions', 'store_true', None, False))
parameters.append(('devAddress', 'store', 'string', None))
parameters.append(('devFile', 'store', 'string', None))
parameters.append(('deviceId', 'store', 'string', None))
parameters.append(('deviceTypeName', None))
parameters.append(('devExternalId', 'store', 'string', None))
parameters.append(('devOfferId', 'store', 'string', None))
parameters.append(('devQueryType', 'store', 'string', 'PhoneNumber'))
parameters.append(('devStatus', 'store', 'string', None))
parameters.append(('diamDebug', 'store_true', None, False))
parameters.append(('diameterCommand', 'store', 'string', 'gy'))
parameters.append(('interface', 'store', 'string', None))
parameters.append(('diameterDestinationIpAddressGx', 'store', 'string', None))
parameters.append(('diameterDestinationIpAddressGy', 'store', 'string', None))
parameters.append(('diameterDestinationIpAddressSy', 'store', 'string', None))
parameters.append(('diameterDestinationIpAddressSh', 'store', 'string', None))
parameters.append(('diameterDestinationIpAddressRx', 'store', 'string', None))
parameters.append(('diffOnly', 'store_true', None, False))
parameters.append(('duplicateFlag', 'store_true', None, False))
parameters.append(('elementId', 'store', 'string', None))
parameters.append(('eligibilityCheck', 'store_true', None, None))
parameters.append(('encodeType', 'store', 'string', 'cgi'))
parameters.append(('engine', 'store', 'string', None))
parameters.append(('engineStatus', 'store', 'string', 'active'))
parameters.append(('engineRelative', 'store', 'string', None))
parameters.append(('eventMoney', 'store', 'string', None))
parameters.append(('eventStringToCheckFor', 'store', 'string', None))
parameters.append(('eventTimeLowerBound', 'store', 'string', None))
parameters.append(('eventTimeUpperBound', 'store', 'string', None))
parameters.append(('eventTypeStringArray', 'store', 'string', None))
parameters.append(('eventPass', 'store_false', None, True))
parameters.append(('eventProcessing', 'store', 'string', None))
parameters.append(('eventTrigger', 'store', 'string', None))
parameters.append(('executeMode', 'store', 'string', None))
parameters.append(('expiryTime', 'store', 'string', '1'))
parameters.append(('failCode', 'store', 'int', 0))
parameters.append(('fee', 'store', 'int', None))
parameters.append(('filterCmd', 'store', 'string', None))
parameters.append(('blockDefaultFilter', 'store_true', None, False))
parameters.append(('filter', 'store', 'string', None))
parameters.append(('filterName', 'store', 'string', None))
parameters.append(('firstName', 'store', 'string', None))
parameters.append(('fqdn', 'store', 'string', None))
parameters.append(('futureTime', 'store', 'string', None))
parameters.append(('glCenter', 'store', 'string', None))
parameters.append(('groupAddDefaultAdmin', 'store_true', None, False))
parameters.append(('groupFile', 'store', 'string', None))
parameters.append(('groupId', 'store', 'string', '0'))
parameters.append(('groupNotificationPreference', 'store', 'string', None))
parameters.append(('groupOfferId', 'store', 'string', None))
parameters.append(('groupQueryType', 'store', 'string', 'ExternalId'))
parameters.append(('groupReAuthPreference', 'store', 'string', None))
parameters.append(('groupStatus', 'store', 'string', None))
parameters.append(('groupTimeZone', 'store', 'string', None))
parameters.append(('hideExpired', 'store_true', None, False))
parameters.append(('hideHidden', 'store_true', None, False))
parameters.append(('hideTemplateData', 'store_true', None, False))
parameters.append(('hideCustomData', 'store_true', None, False))
parameters.append(('hideOfferData', 'store_true', None, False))
parameters.append(('hierarchy', 'store', 'string', None))
parameters.append(('httpLevel', 'store', 'int', 1))
parameters.append(('httpAuthUsername', 'store', 'string', None))
parameters.append(('httpAuthPassword', 'store', 'string', None))
parameters.append(('imei', 'store', 'string', '0'))
parameters.append(('ipv6Flag', 'store_true', None, False))
parameters.append(('info', 'store', 'string', "test_info"))
parameters.append(('isCurrent', 'store_true', None, False))
parameters.append(('isPayoff', 'store_true', None, False))
parameters.append(('isTargetResource', 'store_true', None, False))
parameters.append(('isTemporaryCreditLimit', 'store_true', None, False))
parameters.append(('useNewDataModel', 'store_true', None, False))
parameters.append(('useTargetResource', 'store_true', None, False))
parameters.append(('keepChildren', 'store_true', None, False))
parameters.append(('language', 'store', 'string', None))
parameters.append(('lastActivityUpdateTime', 'store', 'string', None))
parameters.append(('lastName', 'store', 'string', None))
parameters.append(('level', 'store', 'int', '0'))
#parameters.append(('limitedDevices', 'store_true', None, False))
parameters.append(('LoginId', 'store', 'string', None))
parameters.append(('mark', 'store', 'string', ''))
parameters.append(('markPrefix', 'store', 'string', None))
parameters.append(('maxCommands', 'store', 'int', 0))
parameters.append(('maxToUse', 'store', 'string', '-1'))
parameters.append(('mefProcessingData', 'store', 'string', None))
parameters.append(('membershipType', 'store', 'string', None))
parameters.append(('merchantId', 'store', 'string', None))
parameters.append(('subExternalIdPrefix', 'store', 'string', None))
parameters.append(('devExternalIdPrefix', 'store', 'string', None))
parameters.append(('groupExternalIdPrefix', 'store', 'string', None))
parameters.append(('mmsAddressType', 'store', 'string', '1'))
parameters.append(('modBalanceId', 'store', 'string', None))
parameters.append(('modExternalId', 'store', 'string', None))
parameters.append(('modSubQueryType', 'store', 'string', 'ExternalId'))
parameters.append(('modGroupId', 'store', 'string', None))
parameters.append(('modGroupQueryType', 'store', 'string', 'ExternalId'))
parameters.append(('modLoginId', 'store', 'string', None))
parameters.append(('modResourceId', 'store', 'int', 0))
parameters.append(('msccServiceId', 'store', 'int', 0))
parameters.append(('mrIndex', 'store', 'int', 0))
parameters.append(('mtxUli', 'store', 'string', ''))
parameters.append(('multiMsccData', 'store', 'string', None))
#parameters.append(('msccPooledFlag', 'store_true', None, False))
parameters.append(('name', 'store', 'string', None))
parameters.append(('newImsi', 'store', 'string', None))
parameters.append(('nodeFunctionality', 'store', 'string', None))
parameters.append(('noChecks', 'store_true', None, False))
parameters.append(('noMgmt', 'store_true', None, False))
parameters.append(('noMscc', 'store_true', None, False))
parameters.append(('noPause', 'store_true', None, False))
parameters.append(('noPayload', 'store_true', None, False))
parameters.append(('noPin', 'store_true', None, False))
parameters.append(('noResults', 'store_true', None, False))
parameters.append(('noa', 'store', 'string', 'international'))
parameters.append(('nonSuccessResultCode', 'store', 'string', None))
parameters.append(('normalizers', 'store', 'string', None))
parameters.append(('notificationPreference', 'store', 'string', 'both'))
parameters.append(('notificationCheck', 'store', 'string', None))
parameters.append(('notificationTypeStringArray', 'store', 'string', None))
parameters.append(('objectType', 'store', 'string', 'Subscriber'))
parameters.append(('off', 'store', 'string', None))
parameters.append(('offerEndTime', 'store', 'string', None))
parameters.append(('offerFile', 'store', 'string', None))
parameters.append(('offerId', 'store', 'string', None))
parameters.append(('offerBundle', 'store', 'string', None))
parameters.append(('offerGrant', 'store', 'string', None))
parameters.append(('offerCharge', 'store', 'string', None))
parameters.append(('offerEndTimeExtensionOffset', 'store', 'string', None))
parameters.append(('offerEndTimeExtensionOffsetUnit', 'store', 'string', None))
parameters.append(('offerValidityUnit', 'store', 'string', None))
parameters.append(('offerValidityAmount', 'store', 'string', None))
parameters.append(('offerIsCatalog', 'store_true', None, False))
parameters.append(('offerIsExternal', 'store_true', None, True))
parameters.append(('offerQueryType', 'store', 'string', 'OfferId'))
parameters.append(('offerStartTime', 'store', 'string', None))
parameters.append(('omit', 'store', 'string', None))
parameters.append(('on', 'store', 'string', None))
parameters.append(('operators', 'store', 'string', None))
parameters.append(('operation', 'store', 'string', 'equal'))
parameters.append(('originHostGx', 'store', 'string', 'CsvFrameWork-Gx'))
parameters.append(('originHostGy', 'store', 'string', 'CsvFrameWork-Gy'))
parameters.append(('originHostSy', 'store', 'string', 'CsvFrameWork-Sy'))
parameters.append(('originHostSh', 'store', 'string', 'CsvFrameWork-Sh'))
parameters.append(('originHostRx', 'store', 'string', 'CsvFrameWork-Rx'))
parameters.append(('originRealmGx', 'store', 'string', 'matrixxsw.com'))
parameters.append(('originRealmGy', 'store', 'string', 'matrixxsw.com'))
parameters.append(('originRealmSy', 'store', 'string', 'matrixxsw.com'))
parameters.append(('originRealmSh', 'store', 'string', 'matrixxsw.com'))
parameters.append(('originRealmRx', 'store', 'string', 'matrixxsw.com'))
parameters.append(('overrideURL', 'store', 'string', None))
parameters.append(('outputFileName', 'store', 'string', 'none'))
parameters.append(('outputString', 'store', 'string', ''))
parameters.append(('normParameters', 'store', 'string', None))
parameters.append(('paramName', 'store', 'string', ''))
parameters.append(('paramValue', 'store', 'string', ''))
parameters.append(('parentService', 'store', 'string', None))
parameters.append(('password', 'store', 'string', None))
parameters.append(('pauseFlag', 'store', 'string', ''))
parameters.append(('percentage', 'store_true', None, False))
parameters.append(('policyIdentifier', 'store', 'string', None))
parameters.append(('policyPartial', 'store_true', None, False))
parameters.append(('policyStatus', 'store', 'string', None))
parameters.append(('pricingInfo', 'store', 'string', None))
parameters.append(('printFlag', 'store_false', None, True))
parameters.append(('processAssociatedEvents', 'store_true', None, False))
parameters.append(('processSecondaryEvents', 'store_true', None, False))
parameters.append(('processToKill', 'store', 'string', None))
parameters.append(('profileId', 'store', 'string', ''))
parameters.append(('privateKey', 'store', 'string', None))
parameters.append(('precision', 'store', 'string', None))
parameters.append(('grantProrationType', 'store', 'string', None))
parameters.append(('chargeProrationType', 'store', 'string', None))
parameters.append(('cancelType', 'store', 'string', None))
parameters.append(('cancelInfo', 'store_true', None, False))
parameters.append(('publicKey', 'store', 'string', None))
parameters.append(('query', 'store', 'string', None))
parameters.append(('queryCursor', 'store', 'string', None))
parameters.append(('querySize', 'store', 'string', '150'))
parameters.append(('randomValue', 'store', 'string', None))
parameters.append(('ratType', 'store', 'string', None))
parameters.append(('ratingGroup', 'store', 'string', None))
parameters.append(('ratingGroupRequiredForSession', 'store_true', None, False))
parameters.append(('reason', 'store', 'string', 'test_reason'))
parameters.append(('recurringStart', 'store', 'string', None))
parameters.append(('recurringStop', 'store', 'string', None))
parameters.append(('referralExternalId', 'store', 'string', None))
parameters.append(('refundInformation', 'store', 'string', None))
parameters.append(('refundOverride', 'store', 'string', None))
parameters.append(('refundSessionId', 'store', 'int', 0))
parameters.append(('remainingRolloverCounter', 'store', 'string', None))
parameters.append(('repeat', 'store', 'int', 1))
parameters.append(('noReply', 'store_true', None, False))
parameters.append(('reportingReason', 'store', 'string', None))
parameters.append(('requestAction', 'store', 'string', 'debit'))
parameters.append(('requestType', 'store', 'string', 'term'))
parameters.append(('requestDirection', 'store', 'string', ''))
parameters.append(('reqAmount', 'store', 'string', '0'))
parameters.append(('requestNumber', 'store', 'string', None))
parameters.append(('reqData', 'store', 'string', None))
parameters.append(('reqTime', 'store', 'string', None))
parameters.append(('resourceId', 'store', 'int', 0))
parameters.append(('rolesPricingIds', 'store', 'string', None))
parameters.append(('rolesExternalIds', 'store', 'string', None))
parameters.append(('rmvFlag', 'store_true', None, False))
parameters.append(('routingType', 'store', 'string', 'RTID'))
parameters.append(('routingValue', 'store', 'string', None))
parameters.append(('rpmInfo', 'store', 'string', None))
parameters.append(('rulebase', 'store', 'string', '0'))
parameters.append(('saveData', 'store', 'string', None))
parameters.append(('saveDataIgnore', 'store_true', None, False))
parameters.append(('saveEvents', 'store_true', None, False))
parameters.append(('saveEventsSubstring', 'store', 'string', None))
parameters.append(('saveOutputFileName', 'store', 'string', None))
parameters.append(('saveNotifications', 'store_true', None, False))
parameters.append(('saveNotificationsSubstring', 'store', 'string', None))
parameters.append(('saveResults', 'store_true', None, False))
parameters.append(('scope', 'store', 'string', 'local'))
parameters.append(('sendOnlyFlag', 'store_true', None, False))
parameters.append(('separateAccessNumbers', 'store_true', None, False))
parameters.append(('sessionType', 'store', 'string', 'Gy'))
parameters.append(('showGl', 'store_true', None, False))
parameters.append(('skipStepResults', 'store_true', None, False))
parameters.append(('skipFriendlyNames', 'store_true', None, False))
parameters.append(('smsAddressType', 'store', 'string', '1'))
parameters.append(('smsMessageType', 'store', 'string', '0'))
parameters.append(('snmpMIBs', 'store', 'string', None))
parameters.append(('snmpCheck', 'store', 'string', None))
parameters.append(('sourceIsEventInitiator', 'store_true', None, False))
parameters.append(('ssl', 'store_true', None, False))
parameters.append(('startDelay', 'store', 'string', '0'))
parameters.append(('startTime', 'store', 'string', None))
parameters.append(('stopCountingSteps', 'store_true', None, False))
parameters.append(('subFile', 'store', 'string', None))
parameters.append(('subGroupId', 'store', 'string', ''))
parameters.append(('subMark', 'store', 'string', ''))
parameters.append(('subOfferId', 'store', 'string', None))
parameters.append(('subQueryType', 'store', 'string', 'ExternalId'))
parameters.append(('subStatus', 'store', 'string', None))
parameters.append(('subTimeZone', 'store', 'string', None))
parameters.append(('tariffChangeUsage', 'store', 'string', ''))
parameters.append(('testNameExtension', 'store', 'string', ''))
parameters.append(('template', 'store', 'string', None))
parameters.append(('tetherFlag', 'store_true', None, False))
parameters.append(('TgppSgsnMccMnc', 'store', 'string', None))
parameters.append(('thresholdId', 'store', 'int', '0'))
parameters.append(('taxCertificate', 'store', 'string', None))
parameters.append(('taxLocation', 'store', 'string', None))
parameters.append(('taxStatus', 'store', 'string', None))
parameters.append(('tier', 'store', 'string', None))
parameters.append(('timeZone', 'store', 'string', None))
parameters.append(('timeToWait', 'store', 'string', '5'))
parameters.append(('timeToWaitInterval', 'store', 'string', '1'))
parameters.append(('topupType', 'store', 'string', 'VOUCHER'))
parameters.append(('totalToUse', 'store', 'string', '-1'))
parameters.append(('trace', 'store_true', None, False))
parameters.append(('triggerType', 'store', 'string', None))
parameters.append(('uli', 'store', 'string', None))
parameters.append(('ulixtra1', 'store', 'string', '1234'))
parameters.append(('ulixtra2', 'store', 'string', '5678'))
parameters.append(('uliOnlyOnFirstMessage', 'store_true', None, False))
parameters.append(('useCache', 'store_true', None, False))
parameters.append(('usedAmount', 'store', 'string', '-1'))
parameters.append(('usedDirection', 'store', 'string', ''))
parameters.append(('usedFlag', 'store', 'string', ''))
parameters.append(('usedData', 'store', 'string', None))
parameters.append(('usedTime', 'store', 'string', None))
parameters.append(('useGxInterface', 'store_true', None, False))
parameters.append(('useGyInterface', 'store_true', None, False))
parameters.append(('useSyInterface', 'store_true', None, False))
parameters.append(('userExternalId', 'store', 'string', None))
parameters.append(('userId', 'store', 'string', '0'))
parameters.append(('userQueryType', 'store', 'string', 'UserId'))
parameters.append(('userStatus', 'store', 'string', None))
parameters.append(('userTimeZone', 'store', 'string', None))
parameters.append(('useUser', 'store_true', None, False))
parameters.append(('validate', 'store_true', None, False))
parameters.append(('verbose', 'store', 'string', 'normal'))
parameters.append(('viewDiam', 'store', 'string', None))
parameters.append(('viewEvents', 'store', 'string', None))
parameters.append(('virtualCreditLimitIsPercent', 'store_true', None, False))
parameters.append(('voucher', 'store', 'string', ''))
parameters.append(('zoneIpAddress', 'store', 'string', None))
parameters.append(('searchInMemoryDatabase', 'store_true', None, False))
parameters.append(('addlIncludeParameters', 'store', 'string', None))

# Add stuff here that can be used for negative testing.
# Diameter negative testing
parameters.append(('CmdFlagProxiable', 'store', 'string', None))
parameters.append(('appId', 'store', 'string', None))
parameters.append(('msgId', 'store', 'string', None))
parameters.append(('endToEndId', 'store', 'string', None))
parameters.append(('hopByHopId', 'store', 'string', None))

# Should be removed fron the code, but still referenced...
parameters.append(('mergeSubIds', 'store_true', None, False))

# Flag indicating if usage is for a subscriber or a subscription.
# TF needs this internally and for now author is not sure how to do this since the device query returns "Subscriber" always...
parameters.append(('subscriptionCommand', 'store_true', None, False))

#5G Parameters
parameters.append(('dataNetworkName', 'store', 'string', None))
parameters.append(('sliceServiceType', 'store', 'int', '0'))
parameters.append(('sliceDifferentiator', 'store', 'string', None))
parameters.append(('usedUnit5QI', 'store', 'int', '0'))
parameters.append(('qosId', 'store', 'int', '0'))
parameters.append(('usedUnitRatType', 'store', 'int', None))
parameters.append(('offline', 'store', 'string', None))
parameters.append(('location', 'store', 'string', None))
parameters.append(('FiveGtriggerCategory', 'store', 'string', None))
parameters.append(('FiveGtriggerType', 'store', 'string', None))
parameters.append(('mscAdress', 'store', 'string', None))
parameters.append(('portStart', 'store', 'int', 8000))
parameters.append(('portStop', 'store', 'int', 8009))
parameters.append(('qos', 'store', 'int', '0'))

# Add Rx media description fields
parameters.append(('mediaComponentId', 'store', 'string', None))
parameters.append(('afApplicationId', 'store', 'string', None))
parameters.append(('mediaType', 'store', 'string', None))
parameters.append(('maxRequestedBitrateUpload', 'store', 'string', None))
parameters.append(('maxRequestedBitrateDownload', 'store', 'string', None))
parameters.append(('maxSupportedBitrateUpload', 'store', 'string', None))
parameters.append(('maxSupportedBitrateDownload', 'store', 'string', None))
parameters.append(('minDesiredBitrateUpload', 'store', 'string', None))
parameters.append(('minDesiredBitrateDownload', 'store', 'string', None))
parameters.append(('minRequestedBitrateUpload', 'store', 'string', None))
parameters.append(('minRequestedBitrateDownload', 'store', 'string', None))
parameters.append(('extendedMaxRequestedBitrateUpload', 'store', 'string', None))
parameters.append(('extendedMaxRequestedBitrateDownload', 'store', 'string', None))
parameters.append(('extendedMaxSupportedBitrateUpload', 'store', 'string', None))
parameters.append(('extendedMaxSupportedBitrateDownload', 'store', 'string', None))
parameters.append(('extendedMinDesiredBitrateUpload', 'store', 'string', None))
parameters.append(('extendedMinDesiredBitrateDownload', 'store', 'string', None))
parameters.append(('extendedMinRequestedBitrateUpload', 'store', 'string', None))
parameters.append(('extendedMinRequestedBitrateDownload', 'store', 'string', None))
parameters.append(('flowStatus', 'store', 'string', None))
parameters.append(('prioritySharingFlag', 'store', 'string', None))
parameters.append(('preemptionCapability', 'store', 'string', None))
parameters.append(('preemptionVulnerability', 'store', 'string', None))
parameters.append(('rtcpSenderBitrate', 'store', 'string', None))
parameters.append(('rtcpReceiverBitrate', 'store', 'string', None))
parameters.append(('codecDataList', 'store', 'string', None))
parameters.append(('sharingKeyDownload', 'store', 'string', None))
parameters.append(('sharingKeyUpload', 'store', 'string', None))
parameters.append(('contentVersion', 'store', 'string', None))

# Add Rx media sub-component fields
parameters.append(('scFlowId', 'store', 'string', None))
parameters.append(('scFlowDescriptionList', 'store', 'string', None))
parameters.append(('scFlowStatus', 'store', 'string', None))
parameters.append(('scFlowUsage', 'store', 'string', None))
parameters.append(('scMaxRequestedBitrateUpload', 'store', 'string', None))
parameters.append(('scMaxRequestedBitrateDownload', 'store', 'string', None))
parameters.append(('scExtendedMaxRequestedBitrateUpload', 'store', 'string', None))
parameters.append(('scExtendedMaxRequestedBitrateDownload', 'store', 'string', None))
parameters.append(('scAfSignallingProtocol', 'store', 'string', None))
parameters.append(('scTosTrafficClass', 'store', 'string', None))

# Add US Tax fields
parameters.append(('npa', 'store', 'string', None))
parameters.append(('nxx', 'store', 'string', None))
parameters.append(('plus4', 'store', 'string', None))
parameters.append(('geoCode', 'store', 'string', None))
parameters.append(('postalCode', 'store', 'string', None))
parameters.append(('streetAddr', 'store', 'string', None))
parameters.append(('extendedAddr', 'store', 'string', None))
parameters.append(('locality', 'store', 'string', None))
parameters.append(('region', 'store', 'string', None))
parameters.append(('extendedPostalCode', 'store', 'string', None))
parameters.append(('countryCode', 'store', 'string', None))
parameters.append(('tenantId', 'store', 'string', None))
parameters.append(('exemptionCodeList', 'store', 'string', None))
parameters.append(('customerType', 'store', 'string', None))

# Here are the reporting reason values (Diameter standards)
FINAL = '2'
FORCED_REAUTHORISATION = '7'
OTHER_QUOTA_TYPE = '5'
POOL_EXHAUSTED = '8'
QHT = '1'
QUOTA_EXHAUSTED = '3'
RATING_CONDITION_CHANGE = '6'
THRESHOLD = '0'
VALIDITY_TIME = '4'

# The following are the command line variables used to manage custom items
# Entry is:  old AVP location (group|group|...|avp), parameter, new AVP location (same format as old)
customSubscriberParameters = []
customDeviceParameters = []
customGroupParameters = []
customOfferParameters = []
customUserParameters = []
customLoginParameters = []
custom5GRequestParameters = []
customApiEventDataParameters = []

######### Done with input parameter specifications ##################

# Define parameters that can utlize "next", "last", etc.
# The second parameter identifies whether the object can be referenced by a mark. 
idParameter = []
idParameter.append(('catalogExternalId', True))
idParameter.append(('userExternalId', True))
idParameter.append(('externalId', True))
idParameter.append(('devExternalId', True))
idParameter.append(('userId', True))
idParameter.append(('referralExternalId', True))
idParameter.append(('modExternalId', True))
idParameter.append(('groupId', True))
idParameter.append(('modGroupId', True))
idParameter.append(('subGroupId', True))
idParameter.append(('refundSessionId', False))
idParameter.append(('sessionId', False))
idParameter.append(('deviceId', True))
idParameter.append(('accessNumbers', False))
idParameter.append(('imei', False))
idParameter.append(('imsi', False))
idParameter.append(('newImsi', False))
idParameter.append(('msisdn', False))
idParameter.append(('paymentGatewayUserId', False))
idParameter.append(('mscAdress', True))
# Define parameters that can be translated from strings to integers (for ease of test writing)
# Second parameter identifies a common mapping to use.  If set to None or missing, then use mapping associated with the parameter name.
# Third parameter is whether to exit on failure to find a match.  Default is True.
parameterTranslate = []

# Want to auto-map all store_true and store_false parameters to the TrueFalse translation.  Avoid having to remember to do this each time a parameter is added.
# NOTE: this is now done from RunCsvFile, since we need to pull in parameters from other systems (e.g. CCF).

parameterTranslate.append(('offerId',      None,      False))
parameterTranslate.append(('groupStatus', None))
parameterTranslate.append(('subStatus', None))
parameterTranslate.append(('devStatus', None))
parameterTranslate.append(('userStatus', None))
parameterTranslate.append(('notificationPreference', None))
parameterTranslate.append(('noa', None))
parameterTranslate.append(('groupNotificationPreference', None))
parameterTranslate.append(('adjustType', None))
parameterTranslate.append(('creditFloorPolicy', None))
parameterTranslate.append(('creditLimitPolicy', None))
parameterTranslate.append(('objectType', None))
parameterTranslate.append(('profileId', None))
parameterTranslate.append(('reportingReason', None))
parameterTranslate.append(('eventTrigger', None))
parameterTranslate.append(('membershipType', None))
parameterTranslate.append(('tariffChangeUsage', None))
parameterTranslate.append(('balanceEndTimeExtensionOffsetUnit', None))
parameterTranslate.append(('offerEndTimeExtensionOffsetUnit', 'balanceEndTimeExtensionOffsetUnit'))
parameterTranslate.append(('endTimeExtensionOffsetUnit', 'balanceEndTimeExtensionOffsetUnit'))
parameterTranslate.append(('encodeType', None))
parameterTranslate.append(('subOfferId',   'offerId', False))
parameterTranslate.append(('groupOfferId', 'offerId', False))
parameterTranslate.append(('devOfferId',   'offerId', False))
parameterTranslate.append(('offerCycleResourceId',   'offerId', False))
parameterTranslate.append(('autoActivationCycleResourceId',   'offerId', False))
parameterTranslate.append(('policyIdentifier', None, False))
parameterTranslate.append(('policyStatus', None, False))
parameterTranslate.append(('triggerType',      None))
parameterTranslate.append(('requestAction', None))
parameterTranslate.append(('sessionType', None))
parameterTranslate.append(('ratType', None, False))
parameterTranslate.append(('groupReAuthPreference', None))
parameterTranslate.append(('balanceId', None))
parameterTranslate.append(('balanceClassId', None))
parameterTranslate.append(('modBalanceId', None))
parameterTranslate.append(('omit', None, False))
parameterTranslate.append(('startTime', None, False))
parameterTranslate.append(('calledStation', None, False))
parameterTranslate.append(('smsAddressType', None, False))
parameterTranslate.append(('smsMessageType', None, False))
parameterTranslate.append(('executeMode', None))
parameterTranslate.append(('eventTypeStringArray', None, False))
parameterTranslate.append(('notificationTypeStringArray', None, False))
parameterTranslate.append(('mmsAddressType', 'smsAddressType', False))
parameterTranslate.append(('offerCycleOffset', None, False))
parameterTranslate.append(('offerCycleType', None, False))
parameterTranslate.append(('periodType', None, False))
parameterTranslate.append(('cycleOwnerType', None, False))
parameterTranslate.append(('offerStatus', None, False))
parameterTranslate.append(('paymentGatewayId', None))
parameterTranslate.append(('autoActivationRelativeOffsetUnit', None))
parameterTranslate.append(('activationExpirationRelativeOffsetUnit', 'autoActivationRelativeOffsetUnit'))
parameterTranslate.append(('endTimeRelativeOffsetUnit', 'autoActivationRelativeOffsetUnit'))
parameterTranslate.append(('subQueryType',      None,      False))
parameterTranslate.append(('devQueryType',      None,      False))
parameterTranslate.append(('cancelType',      None))
parameterTranslate.append(('grantProrationType',      None))
parameterTranslate.append(('chargeProrationType', 'grantProrationType'))
parameterTranslate.append(('contractCancelMode', None))
parameterTranslate.append(('debtCancellationMode', 'contractCancelMode'))
parameterTranslate.append(('routingType',      None,      False))
parameterTranslate.append(('rolesPricingIds',      None,      False))

# Special translations for reqAmount to either skip or put empty (5G only).  Set last param to false so we allow normal values through (and get unit translated).
parameterTranslate.append(('reqAmount', None, False))

# Define parameters that we need to turn into lists before executing commands
listParameters = []
listParameters.append('exemptionCodeList')
listParameters.append('offerId')
listParameters.append('offerCharge')
listParameters.append('offerGrant')
listParameters.append('offerValidityAmount')
listParameters.append('offerValidityUnit')
listParameters.append('subOfferId')
listParameters.append('groupOfferId')
listParameters.append('devOfferId')
listParameters.append('hierarchy')
listParameters.append('members')
listParameters.append('reqAmount')
listParameters.append('usedAmount')
listParameters.append('multiMsccData')
listParameters.append('totalToUse')
listParameters.append('aqmFunction')
listParameters.append('startDelay')
listParameters.append('normalizers')
listParameters.append('normParameters')
listParameters.append('policyIdentifier')
listParameters.append('policyStatus')
listParameters.append('triggerType')
listParameters.append('eventTrigger')
listParameters.append('omit')
listParameters.append('tier')
listParameters.append('filterCmd')
listParameters.append('eventTypeStringArray')
listParameters.append('notificationTypeStringArray')
listParameters.append('notificationCheck')
listParameters.append('snmpMIBs')
listParameters.append('saveData')
listParameters.append('operation')
listParameters.append('operators')
listParameters.append('rolesPricingIds')
listParameters.append('rolesExternalIds')
listParameters.append('FiveGtriggerCategory')
listParameters.append('FiveGtriggerType')
listParameters.append('addlIncludeParameters')
#listParameters.append('isTargetResource')
#listParameters.append('useTargetResource')
listParameters.append('saveEventsSubstring')
listParameters.append('saveNotificationsSubstring')
listParameters.append('etcScheduleRangeArray')
listParameters.append('paymentScheduleRangeArray')
listParameters.append('paymentScheduleAmountArray')
# Add Rx media sub-componet items
listParameters.append('scFlowId')
listParameters.append('scFlowDescriptionList')
listParameters.append('scFlowStatus')
listParameters.append('scFlowUsage')
listParameters.append('scMaxRequestedBitrateUpload')
listParameters.append('scMaxRequestedBitrateDownload')
listParameters.append('scExtendedMaxRequestedBitrateUpload')
listParameters.append('scExtendedMaxRequestedBitrateDownload')
listParameters.append('scAfSignallingProtocol')
listParameters.append('scTosTrafficClass')

# Define all the time parameters (special processing done on them)
timeParameters = []
timeParameters.append('rechargeTime')
timeParameters.append('offerStartTime')
timeParameters.append('offerEndTime')
timeParameters.append('balanceStartTime')
timeParameters.append('balanceEndTime')
timeParameters.append('startTime')
#timeParameters.append('timeToWait')
#timeParameters.append('timeToWaitInterval')
timeParameters.append('futureTime')
timeParameters.append('lastActivityUpdateTime')
timeParameters.append('eventTimeLowerBound')
timeParameters.append('eventTimeUpperBound')
timeParameters.append('offerCycleOffset')
timeParameters.append('expiryTime')
timeParameters.append('autoActivationTime')
timeParameters.append('activationExpirationTime')
timeParameters.append('offerCycleStartTime')
timeParameters.append('paymentDueDate')
timeParameters.append('offerCycleEndTime')

# Define all the parameters that support units on their input (e.g. "1 MB" or "2.5 min")
unitParameters = []
unitParameters.append('reqTime')
unitParameters.append('usedTime')
unitParameters.append('reqData')
unitParameters.append('usedData')
unitParameters.append('reqAmount')
unitParameters.append('usedAmount')
unitParameters.append('amount')
unitParameters.append('aqmMaxVelocity')
unitParameters.append('totalToUse')
unitParameters.append('maxToUse')
unitParameters.append('recurringStart')
unitParameters.append('recurringStop')
unitParameters.append('startDelay')
unitParameters.append('offerGrant')
unitParameters.append('timeToWait')

# Set key AVPs and corresponding input parameters
# Entry is:  old AVP location (group|group|...|avp), parameter, new AVP location (same format as old), optional gx/gy/sy indication.  Gy is default.
keyAVPs = []
#keyAVPs.append(['Event-Report-Indication|RAT-Type',            'ratType',              'Event-Report-Indication|RAT-Type',     'gx'])
#keyAVPs.append(['Event-Trigger',                               'eventTrigger',         'Event-Trigger',                        'gx'])

# Define parameters that are not passed along as extra params in include command processing
notIncludeParameters = []
notIncludeParameters.append('include')
notIncludeParameters.append('dataFile')
notIncludeParameters.append('repeat')
notIncludeParameters.append('normalizers')
notIncludeParameters.append('normParameters')
notIncludeParameters.append('filterCmd')

# Define parameters that are passed along as extra params in include command processing to every line
alwaysIncludeParameters = []
alwaysIncludeParameters.append('ApplicationRGList')
alwaysIncludeParameters.append('externalId')
alwaysIncludeParameters.append('deviceId')
alwaysIncludeParameters.append('accessNumbers')
alwaysIncludeParameters.append('separateAccessNumbers')
alwaysIncludeParameters.append('groupId')
alwaysIncludeParameters.append('markPrefix')
alwaysIncludeParameters.append('noChecks')
alwaysIncludeParameters.append('devExternalId')
alwaysIncludeParameters.append('userExternalId')
alwaysIncludeParameters.append('skipStepResults')
alwaysIncludeParameters.append('mscAddress')

# Define parameters that can be modified for subs, groups, devices AND are in the command line (versus in the <Attr> parameter)
groupModifyList = []
groupModifyList.append(('name'))
groupModifyList.append(('tier'))
groupModifyList.append(('profileId'))
groupModifyList.append(('taxCertificate'))
groupModifyList.append(('taxLocation'))
groupModifyList.append(('taxStatus'))
groupModifyList.append(('groupStatus'))
groupModifyList.append(('timeZone'))
groupModifyList.append(('groupTimeZone'))
groupModifyList.append(('groupNotificationPreference'))

subscriberModifyList = []
subscriberModifyList.append(('firstName'))
subscriberModifyList.append(('lastName'))
subscriberModifyList.append(('contactPhoneNumber'))
subscriberModifyList.append(('contactEmail'))
subscriberModifyList.append(('notificationPreference'))
subscriberModifyList.append(('timeZone'))
subscriberModifyList.append(('subTimeZone'))
subscriberModifyList.append(('subStatus'))
subscriberModifyList.append(('taxCertificate'))
subscriberModifyList.append(('taxLocation'))
subscriberModifyList.append(('taxStatus'))
subscriberModifyList.append(('language'))
subscriberModifyList.append(('profileId'))

deviceModifyList = []
deviceModifyList.append(('deviceType'))
deviceModifyList.append(('accessNumbers'))
deviceModifyList.append(('devStatus'))
deviceModifyList.append(('devExternalId'))

userModifyList = []
userModifyList.append(('userStatus'))
userModifyList.append(('firstName'))
userModifyList.append(('lastName'))
userModifyList.append(('contactPhoneNumber'))
userModifyList.append(('contactEmail'))
userModifyList.append(('notificationPreference'))
userModifyList.append(('externalId'))
userModifyList.append(('userTimeZone'))
userModifyList.append(('userExternalId'))

loginModifyList = []
loginModifyList.append(('login'))
loginModifyList.append(('accessNumbers'))

offerModifyList = []

# Lists of Sy, Sh, and Gy parameters to be validated
parameterGyValidate = []
parameterShValidate = []
parameterSyValidate = []
#parameterSyValidate.append('policyIdentifier')

# Define special characters
paramSepChar = ';'
timeSepChar = ','
assignmentChar = '='
commentChar = ['#', ';']
useDefaultChar = 'x'
listChar = '@'
fileChar = '_'
msccParamNameChar = '='

# Define string and character for input file specification
inputFileString = '--inputFile'
inputFileSepChar = ','

# Place holder for diameter AVPs (so people know it'll be here)
DiameterAVPs = {}

#==========================================================
# *** Parameter Mappings ***
#==========================================================

# Allow for special 5G-only names to control what's sent (or not) in the Charging Data Request message
reqAmountMapping = {}
reqAmountMapping['empty'] = 999999
reqAmountMapping['missing'] = 999998

# Allow for user friendly names for routingType
routingTypeMapping = {}
routingTypeMapping['route'] = 'RTID'
routingTypeMapping['objectid'] = 'OBID'
routingTypeMapping['externalid'] = 'EXID'
routingTypeMapping['imsi'] = 'IMSI'
routingTypeMapping['accessnumber'] = 'ACNM'
routingTypeMapping['msisdn'] = 'ACNM'
routingTypeMapping['login'] = 'LOGN'
routingTypeMapping['access'] = 'ACID'
routingTypeMapping['session'] = 'SESS'

# Following entries are for the ActivationExpirationRelativeOffsetUnit unit value
autoActivationRelativeOffsetUnitMapping = {}
autoActivationRelativeOffsetUnitMapping['hour'] = '1'
autoActivationRelativeOffsetUnitMapping['day'] = '2'
autoActivationRelativeOffsetUnitMapping['week'] = '3'
autoActivationRelativeOffsetUnitMapping['month'] = '4'
autoActivationRelativeOffsetUnitMapping['year'] = '5'
autoActivationRelativeOffsetUnitMapping['billingCycleInclusive'] = '6'
autoActivationRelativeOffsetUnitMapping['billingCycleExclusive'] = '7'
autoActivationRelativeOffsetUnitMapping['minute'] = '8'

# Dummy define as lots of carriers have special numbers to add here
global calledStationMapping
calledStationMapping = {}
calledStationMapping['ccfEmpty'] = '99999'

# contractCancelMode
global contractCancelModeMapping
contractCancelModeMapping = {}
contractCancelModeMapping['pay_all'] = '1'
contractCancelModeMapping['pay_and_write_off'] = '2'
contractCancelModeMapping['write_off_all'] = '3'
contractCancelModeMapping['pay_none'] = '4'

# Payment gateways
global paymentGatewayIdMapping
paymentGatewayIdMapping = {}
# Get from primitives data, which is reversed
# ** Can't get from primitives.  QA doesn;t run with primitives and this file gets pulled into QA code.
paymentGatewayIdMapping['braintree'] = '0'
paymentGatewayIdMapping['recharge'] = '2'
paymentGatewayIdMapping['cybersource'] = '3'
paymentGatewayIdMapping['foomasterpass'] = '4'
paymentGatewayIdMapping['payfort'] = '5'
paymentGatewayIdMapping['romcard'] = '6'
paymentGatewayIdMapping['other'] = '10'

#for key in PRIMDATA.paymentGatewayIdMapping: paymentGatewayIdMapping[PRIMDATA.paymentGatewayIdMapping[key]] = key

# Define mappings for device query types.  Only a few are mapped (friendly names).
global devQueryTypeMapping
devQueryTypeMapping = {}
devQueryTypeMapping['msisdn'] = 'AccessNumber'

# Define mappings for sub query types.  Only a few are mapped (friendly names).
global subQueryTypeMapping
subQueryTypeMapping = {}
subQueryTypeMapping['msisdn'] = 'AccessNumber'
subQueryTypeMapping['imsi'] = 'PhoneNumber'

# Define mappings for noa
global noaMapping
noaMapping = {}
noaMapping['subscriber'] = '1'
noaMapping['unknown'] = '2'
noaMapping['national'] = '3'
noaMapping['intl'] = noaMapping['international'] = '4'

# Define mappings for executeMode
executeModeMapping = {}
executeModeMapping['normal'] = 0
executeModeMapping['dryrun'] = 1
executeModeMapping['advice'] = 2

# Define mappings for smsMessageType
smsMessageTypeMapping = {}
smsMessageTypeMapping['event'] = smsMessageTypeMapping['submit'] = '0'
smsMessageTypeMapping['dr'] = smsMessageTypeMapping['deliveryreport'] = '1'

# Define mappings for smsAddressType
smsAddressTypeMapping = {}
smsAddressTypeMapping['msisdn']         = '1'
smsAddressTypeMapping['shortcode']      = '4'

# Event type strings.  These map to the event type a.b.c nomenclature.
# These are now read via a pricing query.
eventTypeStringArrayMapping = {}

# ** The following are when used for filtering notifications via event store calls.  Really shouldn't use the same parameter for this...
notificationTypeStringArrayMapping = {}
notificationTypeStringArrayMapping['before_subscriber_status'] = '1'
notificationTypeStringArrayMapping['before_group_status'] = '2'
notificationTypeStringArrayMapping['before_device_status'] = '3'
notificationTypeStringArrayMapping['subscriber_status'] = '4'
notificationTypeStringArrayMapping['group_status'] = '5'
notificationTypeStringArrayMapping['device_status'] = '6'
notificationTypeStringArrayMapping['before_subscriber_balance_expiration'] = '10'
notificationTypeStringArrayMapping['before_group_balance_expiration'] = '11'
notificationTypeStringArrayMapping['subscriber_balance_expiration'] = '12'
notificationTypeStringArrayMapping['group_balance_expiration'] = '13'
notificationTypeStringArrayMapping['after_subscriber_balance_expiration'] = '14'
notificationTypeStringArrayMapping['after_group_balance_expiration'] = '15'
notificationTypeStringArrayMapping['subscriber_balance_create'] = '16'
notificationTypeStringArrayMapping['group_balance_create'] = '17'
notificationTypeStringArrayMapping['subscriber_balance_threshold'] = '18'
notificationTypeStringArrayMapping['group_balance_threshold'] = '19'
notificationTypeStringArrayMapping['subscriber_offer_purchase'] = '20'
notificationTypeStringArrayMapping['group_offer_purchase'] = '21'
notificationTypeStringArrayMapping['device_offer_purchase'] = '22'
notificationTypeStringArrayMapping['subscriber_offer_cancel'] = '23'
notificationTypeStringArrayMapping['group_offer_cancel'] = '24'
notificationTypeStringArrayMapping['device_offer_cancel'] = '25'
notificationTypeStringArrayMapping['before_subscriber_offer_expiration'] = '26'
notificationTypeStringArrayMapping['before_group_offer_expiration'] = '27'
notificationTypeStringArrayMapping['before_device_offer_expiration'] = '28'
notificationTypeStringArrayMapping['subscriber_offer_expiration'] = '29'
notificationTypeStringArrayMapping['group_offer_expiration'] = '30'
notificationTypeStringArrayMapping['device_offer_expiration'] = '31'
notificationTypeStringArrayMapping['after_subscriber_offer_expiration'] = '32'
notificationTypeStringArrayMapping['after_group_offer_expiration'] = '33'
notificationTypeStringArrayMapping['after_device_offer_expiration'] = '34'
notificationTypeStringArrayMapping['subscriber_bundle_purchase'] = '35'
notificationTypeStringArrayMapping['group_bundle_purchase'] = '36'
notificationTypeStringArrayMapping['device_bundle_purchase'] = '37'
notificationTypeStringArrayMapping['subscriber_bundle_cancel'] = '38'
notificationTypeStringArrayMapping['group_bundle_cancel'] = '39'
notificationTypeStringArrayMapping['device_bundle_cancel'] = '40'
notificationTypeStringArrayMapping['before_subscriber_bundle_expiration'] = '41'
notificationTypeStringArrayMapping['before_group_bundle_expiration'] = '42'
notificationTypeStringArrayMapping['before_device_bundle_expiration'] = '43'
notificationTypeStringArrayMapping['subscriber_bundle_expiration'] = '44'
notificationTypeStringArrayMapping['group_bundle_expiration'] = '45'
notificationTypeStringArrayMapping['device_bundle_expiration'] = '46'
notificationTypeStringArrayMapping['after_subscriber_bundle_expiration'] = '47'
notificationTypeStringArrayMapping['after_group_bundle_expiration'] = '48'
notificationTypeStringArrayMapping['after_device_bundle_expiration'] = '49'
notificationTypeStringArrayMapping['subscriber_last_unit'] = '50'
notificationTypeStringArrayMapping['group_last_unit'] = '51'
notificationTypeStringArrayMapping['subscriber_recurring_charge'] = '52'
notificationTypeStringArrayMapping['group_recurring_charge'] = '53'
notificationTypeStringArrayMapping['subscriber_auto_renew'] = '54'
notificationTypeStringArrayMapping['group_auto_renew'] = '55'
notificationTypeStringArrayMapping['subscriber_session_context_end'] = '56'
notificationTypeStringArrayMapping['subscriber_first_usage_charge'] = '58'
notificationTypeStringArrayMapping['group_first_usage_charge'] = '59'
notificationTypeStringArrayMapping['subscriber_recurring_failure'] = '60'
notificationTypeStringArrayMapping['group_recurring_failure'] = '61'
notificationTypeStringArrayMapping['subscriber_event_charge'] = '62'
notificationTypeStringArrayMapping['device_policy_change'] = '63'
notificationTypeStringArrayMapping['subscriber_payment'] = '64'
notificationTypeStringArrayMapping['group_payment'] = '65'
notificationTypeStringArrayMapping['subscriber_recharge'] = '66'
notificationTypeStringArrayMapping['group_recharge'] = '67'
notificationTypeStringArrayMapping['subscriber_payment_settlement'] = '68'
notificationTypeStringArrayMapping['group_payment_settlement'] = '69'
notificationTypeStringArrayMapping['subscriber_recurring'] = '70'
notificationTypeStringArrayMapping['group_recurring'] = '71'
notificationTypeStringArrayMapping['ussd_query'] = '72'
notificationTypeStringArrayMapping['device_recurring_charge'] = '73'
notificationTypeStringArrayMapping['device_recurring_failure'] = '74'
notificationTypeStringArrayMapping['device_recurring'] = '75'
notificationTypeStringArrayMapping['subscriber_refund'] = '76'
notificationTypeStringArrayMapping['group_refund'] = '77'
notificationTypeStringArrayMapping['subscriber_scheduled_recharge'] = '78'
notificationTypeStringArrayMapping['group_scheduled_recharge'] = '79'
notificationTypeStringArrayMapping['subscriber_recharge_failure'] = '80'
notificationTypeStringArrayMapping['group_recharge_failure'] = '81'
notificationTypeStringArrayMapping['subscriber_recurring_recharge'] = '82'
notificationTypeStringArrayMapping['group_recurring_recharge'] = '83'
notificationTypeStringArrayMapping['subscriber_offer_transition_to_recoverable'] = '84'
notificationTypeStringArrayMapping['group_offer_transition_to_recoverable'] = '85'
notificationTypeStringArrayMapping['device_offer_transition_to_recoverable'] = '86'
notificationTypeStringArrayMapping['subscriber_bundle_transition_to_recoverable'] = '87'
notificationTypeStringArrayMapping['group_bundle_transition_to_recoverable'] = '88'
notificationTypeStringArrayMapping['device_bundle_transition_to_recoverable'] = '89'
notificationTypeStringArrayMapping['subscriber_offer_transition_to_inactive'] = '90'
notificationTypeStringArrayMapping['group_offer_transition_to_inactive'] = '91'
notificationTypeStringArrayMapping['device_offer_transition_to_inactive'] = '92'
notificationTypeStringArrayMapping['subscriber_bundle_transition_to_inactive'] = '93'
notificationTypeStringArrayMapping['group_bundle_transition_to_inactive'] = '94'
notificationTypeStringArrayMapping['device_bundle_transition_to_inactive'] = '95'
notificationTypeStringArrayMapping['subscriber_contract_late_charge'] = '96'
notificationTypeStringArrayMapping['group_contract_late_charge'] = '97'
notificationTypeStringArrayMapping['subscriber_contract_debt_payment'] = '98'
notificationTypeStringArrayMapping['device_contract_debt_payment'] = '99'
notificationTypeStringArrayMapping['group_contract_debt_payment'] = '100'
notificationTypeStringArrayMapping['device_contract_late_charge'] = '101'
notificationTypeStringArrayMapping['subscriber_missed_contract_charge'] = '102'
notificationTypeStringArrayMapping['device_missed_contract_charge'] = '103'
notificationTypeStringArrayMapping['group_missed_contract_charge'] = '104'
notificationTypeStringArrayMapping['subscriber_offer_modify'] = '105'
notificationTypeStringArrayMapping['group_offer_modify'] = '106'
notificationTypeStringArrayMapping['device_offer_modify'] = '107'
notificationTypeStringArrayMapping['subscriber_bundle_modify'] = '108'
notificationTypeStringArrayMapping['group_bundle_modify'] = '109'
notificationTypeStringArrayMapping['device_bundle_modify'] = '110'
notificationTypeStringArrayMapping['before_user_status'] = '111'
notificationTypeStringArrayMapping['user_status'] = '112'
notificationTypeStringArrayMapping['subscriber_cycle_arrears_recurring_charge'] = '113'
notificationTypeStringArrayMapping['group_cycle_arrears_recurring_charge'] = '114'
notificationTypeStringArrayMapping['subscription_modify'] = '115'
notificationTypeStringArrayMapping['group_modify'] = '116'
notificationTypeStringArrayMapping['device_modify'] = '117'
notificationTypeStringArrayMapping['user_modify'] = '118'
notificationTypeStringArrayMapping['subscriber_balance_expiry_recharge'] = '119'
notificationTypeStringArrayMapping['group_balance_expiry_recharge'] = '120'
notificationTypeStringArrayMapping['subscriber_cycle_arrears_recurring'] = '121'
notificationTypeStringArrayMapping['group_cycle_arrears_recurring'] = '122'
notificationTypeStringArrayMapping['menu'] = '123'
notificationTypeStringArrayMapping['subscriber_payment_method_update_request'] = '127'
notificationTypeStringArrayMapping['group_payment_method_update_request'] = '128'
notificationTypeStringArrayMapping['subscriber_debt_payment'] = '129'
notificationTypeStringArrayMapping['group_debt_payment'] = '130'
notificationTypeStringArrayMapping['subscriber_purchased_item_status_change'] = '131'
notificationTypeStringArrayMapping['group_purchased_item_status_change'] = '132'
notificationTypeStringArrayMapping['device_purchased_item_status_change'] = '133'
notificationTypeStringArrayMapping['before_subscriber_purchased_item_status_change'] = '134'
notificationTypeStringArrayMapping['before_group_purchased_item_status_change'] = '135'
notificationTypeStringArrayMapping['before_device_purchased_item_status_change'] = '136'
notificationTypeStringArrayMapping['subscriber_add_group_membership'] = '137'
notificationTypeStringArrayMapping['group_add_group_membership'] = '138'
notificationTypeStringArrayMapping['subscriber_remove_group_membership'] = '139'
notificationTypeStringArrayMapping['group_remove_group_membership'] = '140'

# Define mappings for ratType
ratTypeMapping = {}
ratTypeMapping['wlan']  = '0'
ratTypeMapping['unknown'] = '2'
ratTypeMapping['utran'] = '1000'
ratTypeMapping['geran'] = '1001'
ratTypeMapping['gan']   = '1002'
ratTypeMapping['hspa']  = '1003'
ratTypeMapping['eutran'] = '1004'
ratTypeMapping['cdma1X'] = '2000'
ratTypeMapping['hrpd']  = '2001'
ratTypeMapping['umb']   = '2002'
ratTypeMapping['ehrpd'] = '2003'
ratTypeMapping['5g']    = 'NR'
ratTypeMapping['4g']    = 'EUTRA'

# Define mappings for eventTrigger
# https://docs.oracle.com/cd/E39414_01/doc.61/e29455/sbpms_appena_reference.htm
eventTriggerMapping = {}
eventTriggerMapping['sgsn_change'] = '0'
eventTriggerMapping['qos_change'] = '1'
eventTriggerMapping['rat_change'] = '2'
eventTriggerMapping['tft_change'] = '3'
eventTriggerMapping['plmn_change'] = '4'
eventTriggerMapping['loss_of_bearer'] = '5'
eventTriggerMapping['recovery_of_bearer'] = '6'
eventTriggerMapping['ipcan_change'] = '7'
eventTriggerMapping['malfunction'] = '8'
eventTriggerMapping['resource_limits'] = '9'
eventTriggerMapping['max_bearers'] = '10'
eventTriggerMapping['qos_change_exceeding_auth'] = '11'
eventTriggerMapping['rai_change'] = '12'
eventTriggerMapping['uli_change'] = '13'
eventTriggerMapping['no_event'] = '14'
eventTriggerMapping['out_of_credit'] = '15'
eventTriggerMapping['reallocation_of_credit'] = '16'
eventTriggerMapping['revalidation_timeout'] = '17'
eventTriggerMapping['ue_timezone_change'] = '25'
eventTriggerMapping['app_start'] = '39'
eventTriggerMapping['app_stop'] = '40'

# Define trigger type mappings
triggerTypeMapping = {}
triggerTypeMapping['sgsn'] = '1'
triggerTypeMapping['qos'] = '2'
triggerTypeMapping['location'] = '3'
triggerTypeMapping['rat'] = '4'
triggerTypeMapping['timezone'] = '5'
triggerTypeMapping['mcc'] = '30'
triggerTypeMapping['mnc'] = '31'
triggerTypeMapping['rac'] = '32'
triggerTypeMapping['lac'] = '33'
triggerTypeMapping['tac'] = '35'
triggerTypeMapping['serving_node'] = '61'

# Define mappings for AQM function fields
aqmFunctionMapping = {}
aqmFunctionMapping['sin'] = 'sin'
aqmFunctionMapping['cos'] = 'cos'

# Define mappings for objectType fields
objectTypeMapping = {}
objectTypeMapping['device'] = '1'
objectTypeMapping['subscriber'] = '2'
objectTypeMapping['group'] = '3'

# Overload objectType for startDiff identification
objectTypeMapping['all'] = 'all'

# Define mappings for groupReAuthPreference fields
groupReAuthPreferenceMapping = {}
groupReAuthPreferenceMapping['disable'] = '0'
groupReAuthPreferenceMapping['purchase'] = '1'
groupReAuthPreferenceMapping['cancel'] = '2'
groupReAuthPreferenceMapping['both'] = '3'
groupReAuthPreferenceMapping['status'] = '4'
groupReAuthPreferenceMapping['purchase_and_status'] = '5'
groupReAuthPreferenceMapping['cancel_and_status'] = '6'
groupReAuthPreferenceMapping['purchase_and_cancel_and_status'] = '7'

# Define mappings for group notification preference
groupNotificationPreferenceMapping = {}
groupNotificationPreferenceMapping['admin'] = '1'
groupNotificationPreferenceMapping['member'] = '2'

# Define mappings for notification preference
notificationPreferenceMapping = {}
notificationPreferenceMapping['disable'] = '0'
notificationPreferenceMapping['email'] = '1'
notificationPreferenceMapping['text'] = '2'
notificationPreferenceMapping['both'] = '3'
notificationPreferenceMapping['ussd'] = '4'
# Custom values
notificationPreferenceMapping['inapp'] = '65536'

# Define mappings for creditFloorPolicy 
creditFloorPolicyMapping = {}
creditFloorPolicyMapping['None'] = '1'
creditFloorPolicyMapping['transfer'] = '2'
creditFloorPolicyMapping['source'] = '3'

# Define mappings for creditLimitPolicy 
creditLimitPolicyMapping = {}
creditLimitPolicyMapping['allow'] = creditLimitPolicyMapping['ignore'] = '1'
creditLimitPolicyMapping['block'] = creditLimitPolicyMapping['reject'] = '2'

# Define mappings for adjustType 
adjustTypeMapping = {}
adjustTypeMapping['credit'] = '1'
adjustTypeMapping['debit'] = '2'
adjustTypeMapping['meter'] = '3'
adjustTypeMapping['reset'] = '3'

# Define mappings for bill cycle
profileIdMapping = {}
profileIdMapping['firstofmonth'] = '4011'
profileIdMapping['currentdaymonth'] = '4012'

# Define mappings for reportingReason 
reportingReasonMapping = {}
reportingReasonMapping['threshold'] = '0'
reportingReasonMapping['qht'] = '1'
reportingReasonMapping['final'] = '2'
reportingReasonMapping['quota'] = '3'
reportingReasonMapping['time'] = '4'
reportingReasonMapping['other'] = '5'
reportingReasonMapping['condition'] = '6'
reportingReasonMapping['forced'] = '7'
reportingReasonMapping['pool'] = '8'

# Define mappings for tariff time change
tariffChangeUsageMapping = {}
tariffChangeUsageMapping['before'] = '0'
tariffChangeUsageMapping['after'] = '1'
tariffChangeUsageMapping['unknown'] = '2'
tariffChangeUsageMapping['both'] = '3'

# Define mappings for TrueFalse entries
TrueFalseMapping = {}
'''
# WHat I originally did...
TrueFalseMapping['0'] = '0'
TrueFalseMapping['false'] = '0'
TrueFalseMapping['fail'] = '0'
TrueFalseMapping['False'] = '0'
TrueFalseMapping['off'] = '0'
TrueFalseMapping['no'] = '0'
TrueFalseMapping['1'] = '1'
TrueFalseMapping['true'] = '1'
TrueFalseMapping['True'] = '1'
TrueFalseMapping['pass'] = '1'
TrueFalseMapping['on'] = '1'
TrueFalseMapping['yes'] = '1'
TrueFalseMapping['source'] = '1'
TrueFalseMapping['target'] = '0'
'''
# What I recently done...
TrueFalseMapping['false'] = False
TrueFalseMapping['fail'] = False
TrueFalseMapping['off'] = False
TrueFalseMapping['no'] = False
TrueFalseMapping['0'] = False
TrueFalseMapping[0] = False
TrueFalseMapping['true'] = True
TrueFalseMapping['pass'] = True
TrueFalseMapping['on'] = True
TrueFalseMapping['yes'] = True
TrueFalseMapping['1'] = True
TrueFalseMapping[1] = True
TrueFalseMapping['source'] = True
TrueFalseMapping['target'] = False

# Define mappings for membershipType
membershipTypeMapping = {}

# Following entries are when querying a group
membershipTypeMapping['subscribers'] = '1'
membershipTypeMapping['subgroups'] = '2'
membershipTypeMapping['administrators'] = '3'

# Following entries are when querying a subscriber
membershipTypeMapping['groups'] = '1'
membershipTypeMapping['administers'] = '2'

# Following entries are for the balance adjustment end date unit value
balanceEndTimeExtensionOffsetUnitMapping = {}
balanceEndTimeExtensionOffsetUnitMapping['hour'] = '1'
balanceEndTimeExtensionOffsetUnitMapping['day'] = '2'
balanceEndTimeExtensionOffsetUnitMapping['week'] = '3'
balanceEndTimeExtensionOffsetUnitMapping['month'] = '4'
balanceEndTimeExtensionOffsetUnitMapping['year'] = '5'
balanceEndTimeExtensionOffsetUnitMapping['minute'] = '6'

# Define mappings for encodeType fields
encodeTypeMapping = {}
encodeTypeMapping['cgi'] = '00'
encodeTypeMapping['sai'] = '01'
encodeTypeMapping['rai'] = '02'
encodeTypeMapping['tai']  = '80'
encodeTypeMapping['ecgi'] = '81'
encodeTypeMapping['taiandecgi'] = '82'

# Define mappings for requestAction 
requestActionMapping = {}
requestActionMapping['debit'] = '0'
requestActionMapping['refund'] = '1'
requestActionMapping['check'] = requestActionMapping['afford'] = '2'
requestActionMapping['price'] = requestActionMapping['adviceofcharge'] = requestActionMapping['aoc'] = '3'

# Define mappings for SessionType 
sessionTypeMapping = {}
sessionTypeMapping['gy'] = '1'
sessionTypeMapping['sy'] = '2'
sessionTypeMapping['gx'] = '3'

# Define mapping for cycle data
cancelTypeMapping = {}
cancelTypeMapping['immediate'] = '1'
cancelTypeMapping['billing_cycle'] = '2'
cancelTypeMapping['balance_cycle'] = '3'
cancelTypeMapping['purchased_item_cycle'] = '4'

# Define mapping for grantProrationType data
grantProrationTypeMapping = {}
grantProrationTypeMapping['none'] = '0'
grantProrationTypeMapping['full_amount'] = '1'
grantProrationTypeMapping['no_amount'] = '2'
grantProrationTypeMapping['scaled'] = '3'
grantProrationTypeMapping['consumption_based'] = '4'
grantProrationTypeMapping['forfeiture_based'] = '5'

# Define mapping for cycle data
periodTypeMapping = {}
periodTypeMapping['week'] = '1'
periodTypeMapping['month'] = '2'
periodTypeMapping['year'] = '3'

offerCycleOffsetMapping = {}
offerCycleOffsetMapping["sunday"] = '1'
offerCycleOffsetMapping["monday"] = '2'
offerCycleOffsetMapping["tuesday"] = '3'
offerCycleOffsetMapping["wednesday"] = '4'
offerCycleOffsetMapping["thursday"] = '5'
offerCycleOffsetMapping["friday"] = '6'
offerCycleOffsetMapping["saturday"] = '7'

offerCycleTypeMapping = {}
offerCycleTypeMapping['billing_cycle'] = '1'
offerCycleTypeMapping['purchase_time'] = '2'
offerCycleTypeMapping['balance_cycle'] = '3'
offerCycleTypeMapping['offer_cycle'] = '4'
offerCycleTypeMapping['fixed_offset'] = '5'
offerCycleTypeMapping['current_time'] = '6'

cycleOwnerTypeMapping = {}
cycleOwnerTypeMapping['dev'] = '1'
cycleOwnerTypeMapping['sub'] = '2'
cycleOwnerTypeMapping['grp'] = '3'

offerStatusMapping = {}
offerStatusMapping['active'] = '1'

# *** Define data structures that are populated by the csv_prim.py function getCustomMappings().  
# *** This is data read from the engine and/or CB when the TF starts.

# Balance data - name to ID
balanceIdMapping = {}
balanceClassIdMapping = {}
modBalanceIdMapping = {}

# Balance data - ID to name 
balanceNameMapping = {}
balanceClassNameMapping = {}

# Offer data
offerIdMapping = {}

# Extra data used if a test wants to use Catalog Item IDs instead of external IDs.
offerExtIdToId = {}

# Status life cycle mapping
subStatusMapping = {}
devStatusMapping = {}
groupStatusMapping = {}
userStatusMapping = {}

# *** End of data populated by getCustomMappings() ***

# *** Define data structures referenced by code that's decoding returned data (versus input data as the above)
QuantityTypeMapping = {}
QuantityTypeMapping['1'] = 'Actual duration'
QuantityTypeMapping['2'] = 'Active duration'
QuantityTypeMapping['3'] = 'Monetary'
QuantityTypeMapping['4'] = 'Total data'
QuantityTypeMapping['5'] = 'In data'
QuantityTypeMapping['6'] = 'Out data'
QuantityTypeMapping['7'] = 'Service specific'

QuantityUnitMapping = {}
QuantityUnitMapping['0'] = 'none'
QuantityUnitMapping['100'] = 'seconds'
QuantityUnitMapping['101'] = 'minutes'
QuantityUnitMapping['102'] = 'hours'
QuantityUnitMapping['103'] = 'days'
QuantityUnitMapping['104'] = 'weeks'
QuantityUnitMapping['200'] = 'bytes'
QuantityUnitMapping['201'] = 'kbytes'
QuantityUnitMapping['202'] = 'mbytes'
QuantityUnitMapping['203'] = 'gbytes'

# *** End of data structures referenced by code that's decoding returned data (versus input data as the above)

# Global variables that store the highest assigned ID for subs, devices, and access numbers
maxAssignedIds = {}
maxAssignedIdsSave = {}

# Define last referenced array
lastRefIds = {}

# Define Diameter message IDs
DiameterMessageIds = {}
DiameterMessageIds['GyRAR'] = '258'
DiameterMessageIds['WDR']   = '280'
DiameterMessageIds['GyASR']  = '280'
DiameterMessageIds['SySNR']  = '8388636'
DiameterMessageIds['ShPNR']  = '309'
DiameterMessageIds['GyASR'] = '274'
DiameterMessageIds['RxAAR'] = '265'

#==========================================================
def main():
    x = 1


if __name__ == '__main__':
    main()

#===============================================================================
#
# Copyright 2010,2011,2012,2013,2014,2015,2016 Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


