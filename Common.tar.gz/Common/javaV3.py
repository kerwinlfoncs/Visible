#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:41:08
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:51
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:18
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


# from builtins import str
# from builtins import str
import os,sys
import data_container_defs as MDCDEFS
import QA_subscriber_management_rest_helper as RESTHELPER
import subscriber_mgmt_v3 as REST
import common_mdc as COMMON
import time
from xml.etree import ElementTree
#import javaV3_helper
import qa_utils

#====================================================================
def failed(eventPass = True):
    if eventPass:
        return False
    else:
        return True

#====================================================================
def passed(eventPass = True):
    if eventPass:
        return True
    else:
        return False

def readConfigFile():
    gatewaysConfig = qa_utils.getDiameterRestConfig()
    hostName=gatewaysConfig.get('DATACONTAINER', 'hostName'),
    hostPort=gatewaysConfig.get('DATACONTAINER', 'hostPort')
    print(str(hostName[0]), hostPort)
    return(str(hostName[0]), hostPort)

#====================================================================
def createSubscriber(V3inst=None, externalId=None, now=None, payload=None, 
                     billingCycle=None, eventPass=True, firstName=None, 
                     lastName=None, contactEmail=None, contactPhoneNumber=None, 
                     notificationPreference=None, timeZone=None, attr=None, 
                     sharedWalletQuery=None, status=None, vatClass=None, 
                     vatCertificate=None, language=None, doNotExecute=False):

    userDct = {}
    allDct = []
    userDct["ExternalId"] = externalId
    userDct["Status"] = status
    userDct["FirstName"] = firstName 
    userDct["LastName"] =  lastName
    userDct["ContactEmail"] = contactEmail
    userDct["ContactPhoneNumber"] =   contactPhoneNumber
    userDct["NotificationPreference"] = notificationPreference
    userDct["TimeZone"] = timeZone
    userDct["SharedWalletQuery"] = sharedWalletQuery
    userDct["VatClass"] =  vatClass
    userDct["VatCertificate"] = vatCertificate
    userDct["Language"] = language
    (hostName, hostPort) = readConfigFile()
    userDct["hostName"] = hostName
    userDct["hostPort"] = hostPort

    #java code has a problem converting None to BigNumber TODO fix
    userDctNoEmptyString = {}
    userDctNoEmptyString = dict((k,v) for (k,v) in list(userDct.items()) if v is not None)
    userDct = appendQuotesToStringsforDct(userDctNoEmptyString)

    #billingDct =  createSubscriberBillingProfile(V3inst, subscriberId = externalId, 
    #              profileId=4011,
    #              startTime=None, dateOffset=0,
    #              queryType="ExternalId", eventPass=True, now=None)
    if billingCycle != None:
        userDct.update(billingCycle)

    #add Attr for exteneded object  TODO : make it optional sample code
    #attrTmp["\"containerName\""] = "\"DemoSubscriberObjectExtension\""
    #attrTmp["\"Field1\""] = "39999"
    #attrTmp.update(userDct)
    #print allDct
    allList = []
    if (attr != None):
        #need some extra quotes here
        allList.append(appendQuotesToStringsforDct(attr))

    allList.append(userDct)
    print(allList)
    if (doNotExecute):
        return allList
    cmd = "jython /home/mtx/workspace/trunk/MTXQA/Common/javaV3_helper.py addSubscriber " +  str(allList)
    os.system(cmd)

#====================================================================
def appendQuotesToStringsforDct (attr):
    newAttr = {}
    for field in list(attr.keys()):
        newField =  '\"' + str(field) +  '\"'
        if type(attr[field]) == type('a'):
            newVal =  '\"' + str(attr[field])  +  '\"'
        else:
            newVal =  str(attr[field])
        newAttr[newField] = newVal
    return newAttr

#====================================================================
def addSubscriberMultiRequest(V3inst, externalId = None, deviceId = None, 
        deviceType = 1, offerId = 0,
        offerStartTime = None, offerEndTime = None, serviceId = None, payload = None, 
        subAttr = None, billingCycle = None, eventPass=True, firstName=None, 
        lastName=None, contactEmail=None, contactPhoneNumber=None,
        notificationPreference=1, timeZone=None, sharedWalletQuery=None, 
        now=None, devAttr=None, accessNumbers=None,
        subStatus=None, devStatus=None, vatClass=None, vatCertificate=None, 
        language=None, offerIsExternal=False, addDevice=True, imsi=0):
   
    if imsi == 0:
        imsi = externalId

    allLists = []
    subscList = createSubscriber (V3inst, externalId, now, payload, billingCycle, eventPass, firstName,
             lastName, contactEmail, contactPhoneNumber, notificationPreference, timeZone, subAttr,
             sharedWalletQuery, subStatus, vatClass, vatCertificate, language, doNotExecute=True)

    #TODO : add dev externalId if need to
    devExternalId = str(int(externalId) + 1 )
    devList = createDevice(V3inst, imsi, devExternalId, 
        deviceType=deviceType, attr=devAttr,
        accessNumbers=accessNumbers, now=now, eventPass=eventPass,
        status=devStatus, mobile=True, doNotExecute=True) 

    #TODO: workaround . most tests do now supply imsi and device externalId
    offerList = subscribeToOffer(V3inst, imsi, offerId, offerStartTime, offerEndTime, eventPass,
         now = now, offerIsExternal = offerIsExternal, doNotExecute=True)

    allLists.append(subscList)
    allLists.append(devList)
    allLists.append(offerList)
    cmd = "jython /home/mtx/workspace/trunk/MTXQA/Common/javaV3_helper.py multiReqCreateSubscriberAndDevice " + str(allLists)
    #print cmd
    ret = os.system(cmd)
    
    
#====================================================================
#====================================================================
def addSubscriber(V3inst, externalId = None, deviceId = None, deviceType = 1, offerId = 0,
        offerStartTime = None, offerEndTime = None, serviceId = None, payload = None, 
        subAttr = None, billingCycle = None, eventPass=True, firstName=None, 
        lastName=None, contactEmail=None, contactPhoneNumber=None,
        notificationPreference=1, timeZone=None, sharedWalletQuery=None, 
        now=None, devAttr=None, accessNumbers=None,
        subStatus=None, devStatus=None, vatClass=None, vatCertificate=None, 
        language=None, offerIsExternal=False, addDevice=True, imsi=0):
#====================================================================
    if externalId == None:
        sys.exit(" externalId is None!")

    
    createSubscriber (V3inst, externalId, now, payload, billingCycle, eventPass, firstName,
             lastName, contactEmail, contactPhoneNumber, notificationPreference, timeZone, subAttr,
             sharedWalletQuery, subStatus, vatClass, vatCertificate, language)

    #TODO: workaround . most tests do not supply imsi and device externalId
    if imsi == 0:
        imsi = str(int(externalId)) 
    
    devExternalId = str(int(externalId) + 1 )

    createDevice(V3inst, imsi, devExternalId, deviceType, attr=devAttr, 
        accessNumbers=accessNumbers, now=now, eventPass=eventPass, 
        status=devStatus, mobile=True)

    deviceId = devExternalId
    addDeviceToSubscriber(V3inst, externalId, deviceId, deviceType, subQueryType="ExternalId",
        devQueryType="PhoneNumber", eventPass=True, attr=None, accessNumbers=None, 
        status=None, now=None, imsi=imsi)

    #TODO: workaround . most tests do now supply imsi and device externalId
    subscribeToOffer(V3inst, imsi, offerId, offerStartTime, offerEndTime, eventPass,
         now = now, offerIsExternal = offerIsExternal)
    return (0,0)


    #TODO : add code to validate

#====================================================
def subscribeToOffer(V3inst, externalId, offerId, offerStartTime=None, offerEndTime=None, eventPass=True,
        queryType="ExternalId", now=None, offerIsExternal=False, doNotExecute = False):
#====================================================================
    if now is None:
        now = offerStartTime

    # Input may be  alist of may be a single item.  If list, then want to purchase all in one command.
    offerList = []
    offerCount = 0
    offerStartTime = '\"' + str(offerStartTime) + '\"'
    offerEndTime = '\"' + str(offerEndTime) + '\"'

    if type(offerId) is list:
        for offer in offerId:
            offer = '\"' + str(offer) + '\"'
            # Conditionally select product offer by ExternalId or ProductOfferId
            if offerIsExternal:
                offerList.append({"\"ExternalId\"":offer, "\"StartTime\"":offerStartTime, "\"EndTime\"":offerEndTime})
            else:
                offerList.append({"\"ProductOfferId\"":offer, "\"StartTime\"":offerStartTime, "\"EndTime\"":offerEndTime})
    else:
        # Single offer input.  Append the one item
        # Conditionally select product offer by ExternalId or ProductOfferId
        if offerIsExternal:
            offerId = '\"' + str(offerId) + '\"'
            offerList.append({"\"ExternalId\"":offerId, "\"StartTime\"":offerStartTime, "\"EndTime\"":offerEndTime})
        else:
    	    offerList = [{"\"ProductOfferId\"":offerId, "\"StartTime\"":offerStartTime, "\"EndTime\"":offerEndTime}]

    #append this temporarily. remove after reading it from javaV3_helper.py
    tmpVal = {}
    tmpVal["\"Imsi\""] = '\"' + externalId + '\"'
    offerList.append(tmpVal)

    #sending this : 
    #[{"EndTime":"2013-12-05T11:52:29Z","ProductOfferId":9,"StartTime":"2012-12-05T11:52:28Z"},{"Imsi":"558"}]

    if (doNotExecute): return(offerList)

    cmd = "jython /home/mtx/workspace/trunk/MTXQA/Common/javaV3_helper.py deviceImsiPurchaseOffer " + str(offerList)
    #print cmd
    ret = os.system(cmd)
    # Call official API
    
#=============================================================
def unsubscribeFromOffer(V3inst, subscriberId, resourceId=0, endTime=None, eventPass=True,
        queryType="ExternalId"):
    resourceList = []
    
    # Build list of resurces.  Allow for error testing (so passeding in nothing will not set any items in the list)
    if type(resourceId) is list:
        for resource in resourceId:
            resourceList.append(resource)
    elif resourceId != 0:
        resourceList.append(resourceId)

    responseMdc = V3inst.subscriberCancelOffer(queryType=queryType, queryValue=subscriberId,
        resourceIdList=resourceList, now=endTime)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="unsubscribeFromOffer", status=retCode, msg=retText, shouldPass=eventPass)
    
    return COMMON.debugSuccess(method="unsubscribeFromOffer", shouldPass=eventPass)

#=============================================================
def addSubscriberThreshold(V3inst, queryValue, thresholdId, resourceId, threshName,
                          val, notify, eventPass=True,
                          now=None, queryType="ExternalId"): 
    if notify:
        thresholdNotification = 1
    else:
        thresholdNotification = 0

    if resourceId is None:
        walletMdc = V3inst.subscriberQueryWallet(queryType=queryType, queryValue=queryValue, now=now)
        resourceId = COMMON.getResourceId(walletMdc, thresholdId)
        if resourceId is None:
            return COMMON.debugFailure(method="addSubscriberThreshold", status=1, msg="ThresholdId not found")

    responseMdc = V3inst.subscriberAddThreshold(queryType=queryType, queryValue=queryValue, thresholdId=thresholdId,
        resourceId=resourceId, thresholdAmount=val, thresholdName=threshName,
        thresholdNotification=thresholdNotification, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="addSubscriberThreshold", status=retCode, msg=retText, shouldPass=eventPass)
    
    return COMMON.debugSuccess(method="addSubscriberThreshold", shouldPass=eventPass)

#=============================================================
def removeSubscriberThreshold(V3inst, subscriberId, indexId, thresholdId, queryType="ExternalId", eventPass=True,
        now=None):
    responseMdc = V3inst.subscriberRemoveThreshold(queryType=queryType, queryValue=subscriberId, resourceId=indexId,
        thresholdId=thresholdId, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="removeSubscriberThreshold", status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method="removeSubscriberThreshold", shouldPass=eventPass)
    
#=============================================================
def addSubscriberBalance(V3inst, subscriberId, balanceList, now=None, queryType="ExternalId", eventPass=True):
    responseMdc = V3inst.subscriberAddBalance(queryType=queryType, queryValue=subscriberId, balanceList=balanceList,
        now=now)
    
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="addSubscriberBalance", status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method="addSubscriberBalance", shouldPass=eventPass)

#========================================================
#TODO why do we need externalId
def createSubscriberBillingProfile(V3inst, subscriberId, profileId=4011, 
                   startTime=None, dateOffset=0,
                   queryType="ExternalId", eventPass=True, now=None):

    userDct= {}
    userDct["\"BillingCycleId\""] =  profileId
    userDct["\"SubscriberId\""] = '\"' + subscriberId +  '\"'
    if ( startTime != None):
        userDct["\"StartTime\""] = '\"' + startTime  +  '\"'
    userDct["\"dateOffset\""] = dateOffset
    return userDct

#TODO add
#    responseMdc = V3inst.subscriberModify(queryType=queryType, queryValue=subscriberId,
#        billingCycle=billCycleMdc, now=now)


#========================================================
def createGroupBillingProfile(V3inst, groupId, profileId, startTime=None, dateOffset=0,
        queryType="ExternalId", eventPass=True, now=None):
    billCycleMdc = createBillingCycleData(templateId=profileId, dateOffset=dateOffset, startTime=startTime)
    responseMdc = V3inst.groupModify(queryType=queryType, queryValue=groupId, billingCycle=billCycleMdc, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="addGroupBillingProfile", status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method="addGroupBillingProfile", shouldPass=eventPass)

#========================================================
def modifySubscriber(V3inst, queryValue, payload=None, eventPass=True, queryType="ExternalId", now=None,
        firstName=None, lastName=None, contactEmail=None, contactPhoneNumber=None, notificationPreference=None,
        timeZone=None, attr=None, billingCycle=None, status=None, vatClass=None, vatCertificate=None, language=None,
        externalId=None):
    if payload:
        firstName = payload["firstName"] 
        lastName = payload["lastName"]
        contactEmail = payload["contactEmail"]
        contactPhoneNumber = payload["contactPhoneNumber"]
        timeZone = payload["timeZone"]
        attr = payload["attr"]
        notificationPreference = payload["notificationPreference"]

    # Issue subscriber modify command
    responseMdc = V3inst.subscriberModify(queryType=queryType, queryValue=queryValue, now=now,
        firstName=firstName, lastName=lastName, contactEmail=contactEmail, contactPhoneNumber=contactPhoneNumber,
        notificationPreference=notificationPreference, timeZone=timeZone, attr=attr, billingCycle=billingCycle,
        status=status, vatClass=vatClass, vatCertificate=vatCertificate, language=language, externalId=externalId)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="modifySubscriber", status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method="modifySubscriber", shouldPass=eventPass)

#=============================================================
def querySubscriber(V3inst, queryValue, queryType="ExternalId", eventPass=True, now=None):
    responseMdc = V3inst.subscriberQuery(queryType=queryType, queryValue=queryValue, now=now)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="querySubscriber", status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method="querySubscriber", shouldPass=eventPass):
        return responseMdc

#=============================================================
def querySubscriberWallet(V3inst, queryValue, queryType="ExternalId", now=None, eventPass=True):
    searchDct = {}
    searchDct[queryType] = queryValue
    print(searchDct)
    sendDct = appendQuotesToStringsforDct(searchDct)
    dctList = []
    dctList.append(sendDct)
    
    cmd = "jython /home/mtx/workspace/trunk/MTXQA/Common/javaV3_helper.py  subscriberQueryWallet " + str(dctList)
    os.system(cmd)

#=============================================================
def createDevice(V3inst, imsi, externalId=None, deviceType=None, attr=None, 
        accessNumbers=None, now=None, eventPass=True, status=None, mobile=True, doNotExecute=False):

    if accessNumbers is not None and type(accessNumbers) is not list:
        accessNumbers = [accessNumbers]

    if imsi == 0:
        imsi=externalId

    deviceDctList = []
    deviceDct = {}
    if deviceType != None:
        deviceDct["\"DeviceType\""] = deviceType

    if (status != None) :
        deviceDct["\"Status\""] = str(status)

    deviceDct["\"ExternalId\""] = '\"' + str(externalId) + '\"'
    deviceDct["\"Imsi\""] = imsi

    #assuming we get a list of access numbers
    #example : L = [234,5678]
    #convert it to a string
    if (accessNumbers != None):
        accessNumberString='&'.join(str(x) for x in accessNumbers)
        deviceDct["\"AccessNumberArray\""]= '\"' + accessNumberString + '\"' 

    #deviceExtention = {}
    #sample
    #deviceExtention["\"containerName\""] = "\"DemoDeviceObjectExtension\""
    #deviceExtention["\"manufacturer\""] = "\"Johny\""
    #deviceExtention["\"model\""] = "\"1999\""
    #deviceExtention["\"usim\""] = "\"ABCDEF\""

    deviceDctList.append(deviceDct)
    if (attr != None):
        #need some extra quotes here
        deviceDctList.append(appendQuotesToStringsforDct(attr))

    if (doNotExecute): return deviceDctList
    if (mobile):
        cmd = "jython /home/mtx/workspace/trunk/MTXQA/Common/javaV3_helper.py  createDeviceMobile " + str(deviceDctList)
        os.system(cmd)

    
#=============================================================
def deleteDevice(V3inst, queryValue, queryType="Imsi", now=None, eventPass=True):
    deleteDeviceDct = {}
    deleteDeviceDct[queryType] = queryValue
    deleteDeviceLst = []
    deleteDeviceLst.append(appendQuotesToStringsforDct(deleteDeviceDct))

    cmd = "jython /home/mtx/workspace/trunk/MTXQA/Common/javaV3_helper.py deleteDevice " +  str(deleteDeviceLst)
    os.system(cmd)

#=============================================================
def modifyDevice(V3inst, queryValue, queryType='PhoneNumber', deviceType=None, 
                attr=None, now=None, eventPass=True,
                status=None, accessNumbers=None, externalId=None):

    if (accessNumbers != None):
        accessNumberString='&'.join(str(x) for x in accessNumbers)
        deviceDct["\"AccessNumberArray\""]= '\"' + accessNumberString + '\"'

    modifyDeviceDct = {}
    modifyDeviceDct["queryType"] = queryType
    modifyDeviceDct["queryValue"] = queryValue
    modifyDeviceDct["DeviceType"] = deviceType
    modifyDeviceDct["Status"] = status
    modifyDeviceDct["ExternalId"] = externalId

    if (accessNumbers != None):
        accessNumberString='&'.join(str(x) for x in accessNumbers)
        modifyDeviceDct["\"AccessNumberArray\""]= '\"' + accessNumberString + '\"'

    modifyDeviceLst = []
    modifyDeviceLst.append(appendQuotesToStringsforDct(modifyDeviceDct))

    
    if (attr != None):
        #need some extra quotes here
        modifyDeviceLst.append(appendQuotesToStringsforDct(attr))

    cmd = "jython /home/mtx/workspace/trunk/MTXQA/Common/javaV3_helper.py deviceModify " +  str(modifyDeviceLst)
    os.system(cmd)

#=============================================================
def queryDevice(V3inst, queryValue, queryType="Imsi", now=None, eventPass=True):
    queryDeviceDct = {}
    queryDeviceDct[queryType] = queryValue
    queryDeviceLst = []
    queryDeviceLst.append(appendQuotesToStringsforDct(queryDeviceDct))
    cmd = "jython /home/mtx/workspace/trunk/MTXQA/Common/javaV3_helper.py deviceQuery " +  str(queryDeviceLst)
    os.system(cmd)

#=============================================================
def addDeviceToSubscriber(V3inst, externalId, deviceId=None, deviceType=1, subQueryType="ExternalId",
        devQueryType="PhoneNumber", eventPass=True, attr=None, accessNumbers=None, status=None, now=None, imsi=0):
    #TODO :  temp  
    imsi = externalId

    subAddDevDct = {}
    subAddDevDct["\"ExternalId\""] = '\"' + str(externalId) + '\"'
    subAddDevDct["\"Imsi\""] =  '\"' + str(imsi)  + '\"'
    allList = []
    allList.append(subAddDevDct)

    cmd = "jython /home/mtx/workspace/trunk/MTXQA/Common/javaV3_helper.py subscriberAddDevice " +  str(allList)
    os.system(cmd)
    

#=============================================================
def removeDeviceFromSubscriber(V3inst, subscriberId, deviceId, subQueryType, devQueryType, eventPass, now):
    responseMdc = V3inst.subscriberRemoveDevice(subQueryType=subQueryType, subQueryValue=subscriberId,
        devQueryType=devQueryType, devQueryValue=deviceId, now=now)
    
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="removeDeviceFromSubscriber", status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method="removeDeviceFromSubscriber", shouldPass=eventPass)

#=============================================================
def devicePurchaseOffer(V3inst, queryValue, offerId, offerStartTime=None, offerEndTime=None, queryType="PhoneNumber",
        eventPass=True, now=None, offerIsExternal=False):
    if now is None:
        now = offerStartTime

    # Input may be  alist of may be a single item.  If list, then want to purchase all in one command.
    offerList = []
    if type(offerId) is list:
        for offer in offerId:
            if offerIsExternal:
                offerList.append({"ExternalId":offer, "StartTime":offerStartTime, "EndTime":offerEndTime})
            else:
                offerList.append({"ProductOfferId":offer, "StartTime":offerStartTime, "EndTime":offerEndTime})
    else:
        # Single offer input.
        if offerIsExternal:
            offerList.append({"ExternalId":offerId, "StartTime":offerStartTime, "EndTime":offerEndTime})
        else:
    	    offerList = [{"ProductOfferId":offerId, "StartTime":offerStartTime, "EndTime":offerEndTime}]

    # Call official API
    responseMdc = V3inst.devicePurchaseOffer(queryType=queryType, queryValue=queryValue, offerList=offerList, now=now)

    createResourceIds = responseMdc.getUsingKey(MDCDEFS.kMtxResponseAddResourceIdArrayFldKey)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return (COMMON.debugFailure(method="devicePurchaseOffer", status=retCode, msg=retText, shouldPass=eventPass),
            createResourceIds)

    return (COMMON.debugSuccess(method="devicePurchaseOffer", shouldPass=eventPass), createResourceIds)

#=============================================================
def deviceCancelOffer(V3inst, queryValue, resourceId=0, endTime=None, queryType="PhoneNumber",
        eventPass=True):
    resourceList = []
    
    # Build list of resurces
    if type(resourceId) is list:
        for resource in resourceId:
            resourceList.append(resource)
    elif resourceId != 0:
        resourceList.append(resourceId)

    responseMdc = V3inst.deviceCancelOffer(queryType=queryType, queryValue=queryValue, resourceIdList=resourceList,
        now=endTime)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="deviceCancelOffer", status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method="deviceCancelOffer", shouldPass=eventPass)

#=============================================================
def createGroup(V3inst, groupId=None, name=None, tier=None, administrator_id=0, eventPass=True, attr=None, now=None,
        billingCycle=None, queryType="ExternalId", vatClass=None, vatCertificate=None, timeZone=None):
    adminArray = []
    if administrator_id != 0 and type(administrator_id) is list:
        for admin in administrator_id:
            adminArray.append(REST.newSubscriberSearch(subscriberSearchName=queryType, subscriberSearchId=admin))
    elif administrator_id != 0:
        adminArray = [REST.newSubscriberSearch(subscriberSearchName=queryType, subscriberSearchId=administrator_id)]

    responseMdc = V3inst.groupCreate(externalId=groupId, groupName=name, adminSearchArray=adminArray, attr=attr,
        tier=tier, billingCycle=billingCycle, now=now, vatClass=vatClass, vatCertificate=vatCertificate,
        timeZone=timeZone)

    oid = responseMdc.getUsingKey(MDCDEFS.kMtxResponseCreateObjectIdFldKey)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return (COMMON.debugFailure(method="createGroup", status=retCode, msg=retText, shouldPass=eventPass), oid)

    return (COMMON.debugSuccess(method="createGroup", shouldPass=eventPass), oid)

#=============================================================
def modifyGroup(V3inst, groupId, name=None, tier=None, administrator_id=0, billingCycle=None, attr=None,
        subQueryType="ExternalId", groupQueryType="ExternalId", now=None, eventPass=True, vatClass=None,
        vatCertificate=None, externalId=None, timeZone=None):
    adminArray = []
    if administrator_id != 0 and type(administrator_id) is list:
        for admin in administrator_id:
            adminArray.append(REST.newSubscriberSearch(subscriberSearchName=subQueryType, subscriberSearchId=admin))
    elif administrator_id != 0:
        adminArray = [REST.newSubscriberSearch(subscriberSearchName=subQueryType, subscriberSearchId=administrator_id)]

    if adminArray != []:
        V3inst.groupAddMembership(queryType=groupQueryType, queryValue=groupId, adminSearchArray=adminArray, now=now)

    responseMdc = V3inst.groupModify(queryType=groupQueryType, queryValue=groupId, groupName=name,
        attr=attr, tier=tier, billingCycle=billingCycle, now=now, vatClass=vatClass, vatCertificate=vatCertificate,
        externalId=externalId, timeZone=timeZone)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="modifyGroup", status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method="modifyGroup", shouldPass=eventPass)

#=============================================================
def addSubscriberToGroup(V3inst, groupId, subscriberId, subQueryType="ExternalId", groupQueryType="ExternalId",
        eventPass=True, now=None):
    subList = []
    if type(subscriberId) is list:
        for sub in subscriberId:
            subList.append(REST.newSubscriberSearch(subscriberSearchName=subQueryType, subscriberSearchId=sub))
    else:
        subList.append(REST.newSubscriberSearch(subscriberSearchName=subQueryType, subscriberSearchId=subscriberId))

    responseMdc=V3inst.groupAddMembership(queryType=groupQueryType, queryValue=groupId, subscriberSearchArray=subList,
        now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="addSubscriberToGroup", status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method="addSubscriberToGroup", shouldPass=eventPass)

#=============================================================
def addGroupMembership(V3inst, groupId, subscribers=None, subGroups=None, subQueryType="ExternalId",
        subGroupQueryType="ExternalId", groupQueryType="ExternalId", eventPass=True, now=None,
        admins=None, adminQueryType="ExternalId"):
    subList = []
    if type(subscribers) is list:
        for sub in subscribers:
            subList.append(REST.newSubscriberSearch(subscriberSearchName=subQueryType, subscriberSearchId=sub))
    elif subscribers:
        subList.append(REST.newSubscriberSearch(subscriberSearchName=subQueryType, subscriberSearchId=subscribers))

    groupList = []
    if type(subGroups) is list:
        for group in subGroups:
            groupList.append(REST.newGroupSearch(groupSearchName=subGroupQueryType, groupSearchId=group))
    elif subGroups:
        groupList.append(REST.newGroupSearch(groupSearchName=subGroupQueryType, groupSearchId=subGroups))

    adminList = []
    if type(admins) is list:
        for admin in admins:
            adminList.append(REST.newSubscriberSearch(subscriberSearchName=adminQueryType, subscriberSearchId=admin))
    elif admins:
        adminList.append(REST.newSubscriberSearch(subscriberSearchName=adminQueryType, subscriberSearchId=admins))

    responseMdc=V3inst.groupAddMembership(queryType=groupQueryType, queryValue=groupId, subscriberSearchArray=subList,
        subGroupSearchArray=groupList, adminSearchArray=adminList, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="addGroupMembership", status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method="addGroupMembership", shouldPass=eventPass)

#=============================================================
def removeGroupMembership(V3inst, groupId, subscribers=None, subGroups=None, subQueryType="ExternalId",
        subGroupQueryType="ExternalId", groupQueryType="ExternalId", eventPass=True, now=None,
        admins=None, adminQueryType="ExternalId"):
    subList = []
    if type(subscribers) is list:
        for sub in subscribers:
            subList.append(REST.newSubscriberSearch(subscriberSearchName=subQueryType, subscriberSearchId=sub))
    elif subscribers:
        subList.append(REST.newSubscriberSearch(subscriberSearchName=subQueryType, subscriberSearchId=subscribers))

    groupList = []
    if type(subGroups) is list:
        for group in subGroups:
            groupList.append(REST.newGroupSearch(groupSearchName=subQueryType, groupSearchId=group))
    elif subGroups:
        groupList.append(REST.newGroupSearch(groupSearchName=subQueryType, groupSearchId=subGroups))

    adminList = []
    if type(admins) is list:
        for admin in admins:
            adminList.append(REST.newSubscriberSearch(subscriberSearchName=adminQueryType, subscriberSearchId=admin))
    elif admins:
        adminList.append(REST.newSubscriberSearch(subscriberSearchName=adminQueryType, subscriberSearchId=admins))

    responseMdc=V3inst.groupRemoveMembership(queryType=groupQueryType, queryValue=groupId,
        subscriberSearchArray=subList, subGroupSearchArray=groupList, adminSearchArray=adminList, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="removeGroupMembership", status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method="removeGroupMembership", shouldPass=eventPass)

#=============================================================
def removeSubscriberFromGroup(V3inst, groupId, subscriberId, subQueryType="ExternalId", groupQueryType="ExternalId",
        eventPass=True, now=None):
    subList = []
    if type(subscriberId) is list:
        for sub in subscriberId:
            subList.append(REST.newSubscriberSearch(subscriberSearchName=subQueryType, subscriberSearchId=sub))
    else:
        subList.append(REST.newSubscriberSearch(subscriberSearchName=subQueryType, subscriberSearchId=subscriberId))

    responseMdc = V3inst.groupRemoveMembership(queryType=groupQueryType, queryValue=groupId,
        subscriberSearchArray=subList, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="removeSubscriberFromGroup", status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method="removeSubscriberFromGroup", shouldPass=eventPass)

#=============================================================
def addSubGroupToGroup(V3inst, groupId, subGroupId, subQueryType="ExternalId", groupQueryType="ExternalId",
        now=None, eventPass=True):
    groupList = []
    if type(subGroupId) is list:
        for group in subGroupId:
            groupList.append(REST.newGroupSearch(groupSearchName=subQueryType, groupSearchId=group))
    else:
        groupList.append(REST.newGroupSearch(groupSearchName=subQueryType, groupSearchId=subGroupId))

    responseMdc=V3inst.groupAddMembership(queryType=groupQueryType, queryValue=groupId, subGroupSearchArray=groupList,
        now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="addSubGroupToGroup", status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method="addSubGroupToGroup", shouldPass=eventPass)

#=============================================================
def removeSubGroupFromGroup(V3inst, groupId, subGroupId, subQueryType="ExternalId", groupQueryType="ExternalId",
        eventPass=True, now=None):
    groupList = []
    if type(subGroupId) is list:
        for group in subGroupId:
            groupList.append(REST.newGroupSearch(groupSearchName=subQueryType, groupSearchId=group))
    else:
        groupList.append(REST.newGroupSearch(groupSearchName=subQueryType, groupSearchId=subGroupId))

    responseMdc = V3inst.groupRemoveMembership(queryType=groupQueryType, queryValue=groupId,
        subGroupSearchArray=groupList, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="removeSubGroupFromGroup", status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method="removeSubGroupFromGroup", shouldPass=eventPass)

#=============================================================
def groupSubscribeToOffer(V3inst, groupId, offerId, offerStartTime=None, offerEndTime=None, eventPass=True,
        queryType="ExternalId", now=None, offerIsExternal=False):
    if now is None:
        now = offerStartTime

    offerList = []
    if type(offerId) is list:
        for offer in offerId:
            # Conditionally select product offer by ExternalId or ProductOfferId
            if offerIsExternal:
                offerList.append({"ExternalId":offer, "StartTime":offerStartTime, "EndTime":offerEndTime})
            else:
                offerList.append({"ProductOfferId":offer, "StartTime":offerStartTime, "EndTime":offerEndTime})
    else:
        # Conditionally select product offer by ExternalId or ProductOfferId
        if offerIsExternal:
            offerList.append({"ExternalId":offerId, "StartTime":offerStartTime, "EndTime":offerEndTime})
        else:
            offerList.append({"ProductOfferId":offerId, "StartTime":offerStartTime, "EndTime":offerEndTime})

    responseMdc = V3inst.groupPurchaseOffer(queryType=queryType, queryValue=groupId, offerList=offerList,
        now=now)

    createResourceIds = responseMdc.getUsingKey(MDCDEFS.kMtxResponseAddResourceIdArrayFldKey)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return (COMMON.debugFailure(method="groupSubscribeToOffer", status=retCode, msg=retText, shouldPass=eventPass),
            createResourceIds)

    return (COMMON.debugSuccess(method="groupSubscribeToOffer", shouldPass=eventPass), createResourceIds)

#=============================================================
def groupUnsubscribeFromOffer(V3inst, groupId, resourceIds, now=None, eventPass=True, queryType="ExternalId"):
    if type(resourceIds) is not list:
        resourceIds = [resourceIds]

    responseMdc = V3inst.groupCancelOffer(queryType=queryType, queryValue=groupId, resourceIdList=resourceIds,
        now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="groupUnsubscribeFromOffer", status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method="groupUnsubscribeFromOffer", shouldPass=eventPass)

#========================================================
def addGroupThreshold(V3inst, groupId, thresholdId, resourceId=None, threshName=None, val=0, notify=None,
        eventPass=True, now=None, queryType="ExternalId"):
    if notify:
        thresholdNotification = 1
    else:
        thresholdNotification = 0

    # Use helper to look for resourceId based on thresholdId if not passed in
    if resourceId is None:
        walletMdc = V3inst.groupQueryWallet(queryType=queryType, queryValue=groupId, now=now)
        resourceId = COMMON.getResourceId(walletMdc, thresholdId)
        if resourceId is None:
            return COMMON.debugFailure(method="addGroupThreshold", status=1, msg="ThresholdId not found")

    responseMdc = V3inst.groupAddThreshold(queryType=queryType, queryValue=groupId, thresholdId=thresholdId,
        resourceId=resourceId, thresholdAmount=val, thresholdName=threshName,
        thresholdNotification=thresholdNotification, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="addGroupThreshold", status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method="addGroupThreshold", shouldPass=eventPass)

#========================================================
def removeGroupThreshold(V3inst, groupId, resourceId, thresholdId, now=None, queryType="ExternalId", eventPass=True):
    responseMdc = V3inst.groupRemoveThreshold(queryType=queryType, queryValue=groupId, resourceId=resourceId,
        thresholdId=thresholdId, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="removeGroupThreshold", status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method="removeGroupThreshold", shouldPass=eventPass)

#=============================================================
def queryGroup(V3inst, queryValue, queryType="ExternalId", now=None, eventPass=True):
    responseMdc = V3inst.groupQuery(queryType=queryType, queryValue=queryValue, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="queryGroup", status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method="queryGroup", shouldPass=eventPass):
        return responseMdc

#=============================================================
def queryGroupWallet(V3inst, queryValue, queryType="ExternalId", now=None, eventPass=True):
    responseMdc = V3inst.groupQueryWallet(queryType=queryType, queryValue=queryValue, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="queryGroupWallet", status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method="queryGroupWallet", shouldPass=eventPass):
        return responseMdc

#=============================================================
def createBillingCycleData(templateId, dateOffset=None, startTime=None):
    billCycleMdc = REST.newBillingCycleData(templateId=templateId, dateOffset=dateOffset, startTime=startTime)

    if not billCycleMdc:
        return False
    print(billCycleMdc)

    return billCycleMdc

#=============================================================
def subscriberAdjustBalance(V3inst=None, queryValue=None, balanceResourceId=None, adjustType=None, amount=None,
        reason=None, queryType="PhoneNumber", info=None, now=None, eventPass=True):
    responseMdc = V3inst.subscriberAdjustBalance(queryType=queryType, queryValue=queryValue,
        balanceResourceId=balanceResourceId, adjustType=adjustType, amount=amount, reason=reason, info=info, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="subscriberAdjustBalance", status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method="subscriberAdjustBalance", shouldPass=eventPass)

#=============================================================
def subscriberTopupBalance(V3inst=None, queryValue=None, balanceResourceId=None, amount=None, voucher=None,
        queryType="PhoneNumber", now=None, eventPass=True):
    responseMdc = V3inst.subscriberTopupBalance(queryType=queryType, queryValue=queryValue,
        balanceResourceId=balanceResourceId, amount=amount, voucher=voucher, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="subscriberTopupBalance", status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method="subscriberTopupBalance", shouldPass=eventPass)

#=============================================================
def groupAdjustBalance(V3inst=None, queryValue=None, balanceResourceId=None, adjustType=None, amount=None,
        reason=None, queryType="PhoneNumber", info=None, now=None, eventPass=True):
    responseMdc = V3inst.groupAdjustBalance(queryType=queryType, queryValue=queryValue,
        balanceResourceId=balanceResourceId, adjustType=adjustType, amount=amount, reason=reason, info=info, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="groupAdjustBalance", status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method="groupAdjustBalance", shouldPass=eventPass)

#=============================================================
def groupTopupBalance(V3inst=None, queryValue=None, balanceResourceId=None, amount=None, voucher=None,
        queryType="PhoneNumber", now=None, eventPass=True):
    responseMdc = V3inst.groupTopupBalance(queryType=queryType, queryValue=queryValue,
        balanceResourceId=balanceResourceId, amount=amount, voucher=voucher, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="groupTopupBalance", status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method="groupTopupBalance", shouldPass=eventPass)

#=============================================================
def pricingQueryStatus(V3inst, now=None, eventPass=True):
    responseMdc = V3inst.pricingQueryStatus(now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="pricingQueryStatus", status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method="pricingQueryStatus", shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryOffer(V3inst, offerId, queryType="OfferId", now=None, eventPass=True):
    responseMdc = V3inst.pricingQueryOffer(queryValue=offerId, queryType=queryType, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="pricingQueryOffer", status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method="pricingQueryOffer", shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryOfferList(V3inst, now=None, eventPass=True):
    responseMdc = V3inst.pricingQueryOfferList(now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="pricingQueryOfferList", status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method="pricingQueryOfferList", shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryBalance(V3inst, balanceId, queryType="BalanceId", now=None, eventPass=True):
    responseMdc = V3inst.pricingQueryBalance(queryValue=balanceId, queryType=queryType, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="pricingQueryBalance", status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method="pricingQueryBalance", shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryBalanceList(V3inst, now=None, eventPass=True):
    responseMdc = V3inst.pricingQueryBalanceList(now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method="pricingQueryBalanceList", status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method="pricingQueryBalanceList", shouldPass=eventPass):
        return responseMdc


#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

