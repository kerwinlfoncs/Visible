#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:44
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:24
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:06
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


# from builtins import str
# from builtins import str
import data_container as MDC
# Check if the data_container_defs.py needs to be re-created
import data_container_defs as MDCDEFS
import diameter as DIAM
import os
import sys
import time
import commonDefs as cd
import diameter_utils as DIAMUTILS
import qa_utils
import log_errors as LOGGER

# Define a debug flag that can disable writing dat ato files (for speed)
diameterFileDebugFlag = True

#
# This program will create Diameter packets and send them to the
# Diameter Gateway.
####################################################################
    ############################################################################
    # Main processing starts here
def main2(path,reqDct, diamConnection, eventPass, extraAVP = {}, msccAvpListToAppend = [], stripList=None):
    logger =  LOGGER.clErrors(path)
    #doNotOmitFlag = True
    #if 'omit' in extraAVP: doNotOmitFlag = False

    #finalRetCode = 0
    #fileNameList = []
    mscc = False
    if 'MSCC' in extraAVP:
        mscc = True

    # Create the input data
    fullSessionId='.;1;' + str(reqDct['sessionId'])
    if 'CmdFlagProxiable' in extraAVP:
        diamPacket = DIAM.createPacket(4, 272 + DIAM.CmdFlagRequest + DIAM.CmdFlagProxiable, 1001, 2001)
        del extraAVP['CmdFlagProxiable']
    else:
        diamPacket = DIAM.createPacket(4, 272 + DIAM.CmdFlagRequest, 1001, 2001)
    diamPacket = DIAMUTILS.checkOmitAvp(extraAVP, 'Session-Id', fullSessionId, diamPacket)
    diamPacket = DIAMUTILS.checkOmitAvp(extraAVP, 'Origin-Host', reqDct['Origin-Host'], diamPacket)
    diamPacket = DIAMUTILS.checkOmitAvp(extraAVP, 'Origin-Realm', 'origrealm.net', diamPacket)
    diamPacket = DIAMUTILS.checkOmitAvp(extraAVP, 'Destination-Realm', 'destrealm.net', diamPacket)
    diamPacket = DIAMUTILS.checkOmitAvp(extraAVP, 'Auth-Application-Id', '4', diamPacket)

#    serviceIdContext = DIAMUTILS.getServiceIdContext(reqDct['serviceId'])
    diamPacket = DIAMUTILS.checkOmitAvp(extraAVP, 'Service-Context-Id',  reqDct['Service-Context-Id'], diamPacket)
    
    # check if there is anything to be omitted.  then check if this AVP in the list
#    serviceId = DIAMUTILS.getServiceId(reqDct['serviceId'])
    diamPacket = DIAMUTILS.checkOmitAvp(extraAVP, 'Service-Identifier', reqDct['serviceIdName'], diamPacket)
        
    #get reqType
    reqtype = DIAMUTILS.getRequestType (reqDct['requestType'])
#    print reqtype
    diamPacket = DIAMUTILS.checkOmitAvp(extraAVP, 'Event-Timestamp', reqDct['eventTime'], diamPacket)  
    diamPacket = DIAMUTILS.checkOmitAvp(extraAVP, 'CC-Request-Type', reqtype, diamPacket) 
    diamPacket = DIAMUTILS.checkOmitAvp(extraAVP, 'CC-Request-Number', reqDct['reqNum'], diamPacket) 
    diamPacket = DIAMUTILS.checkOmitAvp(extraAVP, 'Destination-Host', reqDct['Destination-Host'], diamPacket)
    
    # What to put in the User name depends on which value is submitted.  IMSI has priority over MSISDN.
    if 'Subscription-Id-Type-IMSI' in reqDct:
        diamPacket = DIAMUTILS.checkOmitAvp(extraAVP, 'User-Name', str(reqDct['Subscription-Id-Type-IMSI']), diamPacket)
    else:
        diamPacket = DIAMUTILS.checkOmitAvp(extraAVP, 'User-Name', str(reqDct['Subscription-Id-Type-MSISDN']), diamPacket)
    
    # Build subscription ID data.  May have either IMSI/MSISDN, or both.
    key = 'Subscription-Id-Type-IMSI'
    if key in reqDct:
        avpList = []
        dataTypeAVP = DIAM.Avp('Subscription-Id-Type', '1')
        dataAVP = DIAM.Avp('Subscription-Id-Data', str(reqDct[key]))
        avpList.append(dataTypeAVP)
        avpList.append(dataAVP)
    
        # Now add whatever was just included to the top Subscription-Id group AVP
        diamPacket = DIAMUTILS.checkOmitAvp(extraAVP,'Subscription-Id', avpList, diamPacket)

    key = 'Subscription-Id-Type-MSISDN'
    if key in reqDct:
        avpList = []
        dataTypeAVP = DIAM.Avp('Subscription-Id-Type', '0')
        dataAVP = DIAM.Avp('Subscription-Id-Data', str(reqDct[key]))
        avpList.append(dataTypeAVP)
        avpList.append(dataAVP)
        
        # Now add whatever was just included to the top Subscription-Id group AVP
        diamPacket = DIAMUTILS.checkOmitAvp(extraAVP,'Subscription-Id', avpList, diamPacket)

    #SubscriptionIdAvp = DIAM.Avp('Subscription-Id', avpList)
    #diamPacket.appendAvpObj(SubscriptionIdAvp)
   
    diamPacket = DIAMUTILS.checkOmitAvp(extraAVP, 'SGSN-Address', reqDct['SGSN-Address'], diamPacket)
        
    ## get the Quantity selector  - returns totalData or actualDuration, etc..
    ## these values are defined in commonDefs.py
    quantitySelector = DIAMUTILS.getQuantitySelector(reqDct['serviceId'], mscc)

    ## Process Requested Units
    avpList = []
    avpList = DIAMUTILS.getAvpRequestedOrUsedServiceUnit(DIAM, quantitySelector, int(reqDct['reqamount']), extraAVP)
    avpListRequestedServiceUnit = avpList

    ## Process Used Units
    avpList = []
    avpList = DIAMUTILS.getAvpRequestedOrUsedServiceUnit(DIAM, quantitySelector, int(reqDct['usedamount']), extraAVP)
    avpListUsedServiceUnit = avpList
    ServiceUnitAvp = None

    ############################################################
    if 'MSCC' not in extraAVP:
        if (reqDct['requestType'] == 'initial'):
           diamPacket = DIAMUTILS.checkOmitAvp(extraAVP, 'Requested-Service-Unit', avpListRequestedServiceUnit, diamPacket)

        if (reqDct['requestType'] == 'interim'):
           diamPacket = DIAMUTILS.checkOmitAvp(extraAVP, 'Requested-Service-Unit', avpListRequestedServiceUnit, diamPacket)
           diamPacket = DIAMUTILS.checkOmitAvp(extraAVP, 'Used-Service-Unit', avpListUsedServiceUnit, diamPacket)

        elif (reqDct['requestType'] == 'term'):
           #print 'Processing unsed units'
           diamPacket = DIAMUTILS.checkOmitAvp(extraAVP, 'Used-Service-Unit', avpListUsedServiceUnit, diamPacket)

        elif (reqDct['requestType'] == 'event'):
           diamPacket = DIAMUTILS.checkOmitAvp(extraAVP, 'Used-Service-Unit', avpListUsedServiceUnit, diamPacket)

    else:
##        print len(msccAvpListToAppend)
        # Add outer level indication packet here.  May have a blank AVP list...
        diamPacket = DIAMUTILS.checkOmitAvp(extraAVP, "Multiple-Services-Indicator",'1', diamPacket)
        diamPacket = DIAMUTILS.checkOmitAvp(extraAVP,"Multiple-Services-Credit-Control", msccAvpListToAppend, diamPacket,funcToCall="createDiamMsccPkt")

    ## Build PS-Information grouped AVP ##
    # Two types of data for this group:  (1) items in reqDCT, (2) items in extraAVP
    # Process each one independently, grabbing the data from the right source
    avpList = []

    psReqDctList = ['Start-Time', 'Called-Station-Id', '3GPP-MS-TimeZone']
    for _key in psReqDctList:
     if 'omit' in extraAVP:
        if _key not in extraAVP['omit']:
            _avp = DIAM.Avp(_key, reqDct[_key])
            avpList.append(_avp)
     else:
        _avp = DIAM.Avp(_key, reqDct[_key])
        avpList.append(_avp)

    psExtraList = ['3GPP-Charging-Id', 'PDN-Connection-ID', 'Node-Id', '3GPP-PDP-Type', 'PDP-Address', 'Dynamic-Address-Flag', 'QoS-Information', 'SGSN-Address', 'GGSN-Address', 'CG-Address', 'Serving-Node-Type', 'SGW-Change', '3GPP-IMSI-MCC-MNC', '3GPP-GGSN-MCC-MNC', '3GPP-NSAPI', '3GPP-Session-Stop-Indicator', '3GPP-Selection-Mode', '3GPP-Charging-Characteristics ', '3GPP-SGSN-MCC-MNC', 'Charging-Rule-Base-Name', '3GPP-User-Location-Info', '3GPP2-BSID', '3GPP-RAT-Type', 'PS-Furnish-Charging-Information', 'PDP-Context-Type', 'Offline-Charging', 'Traffic-Data-Volumes', 'Service-Data-Container', 'User-Equipment-Info', 'Terminal-Information', 'Stop-Time', 'Change-Condition', 'Diagnostics']
    for _key in psExtraList:
     # Assume we're not going to load or delete this AVP
     load=False
     delete=False

     # Check if we've defined this AVP
     if _key in extraAVP:
        # Now assume we are going to load this
        load=True

        # Will now unconditionally delete (regardless of load status)
        delete=True

        # See if this key is in the omit list
        if 'omit' in extraAVP:
          if _key in extraAVP['omit']:
            # Bummer...  Don't load it.
            load=False

     # If load is true, then load it!
     if load:
       _avp = DIAM.Avp(_key, extraAVP[_key])
       avpList.append(_avp)

     # If delete is true then remove key item
     if delete:
       del extraAVP[_key]

    # PS-Information are the AVPs that were not omitted from above
    PSInformationAvp = DIAM.Avp('PS-Information', avpList)

    # See if we really should include the PS-Information grouped AVP.
    # Could optimize and put this omit check at the beginning of the PS-Information
    # section, but easier to understand here...
    avpList = []
    _key='PS-Information'
    if 'omit' in extraAVP:
        if _key not in extraAVP['omit']:
            avpList.append(PSInformationAvp)
    else:
        avpList.append(PSInformationAvp)

    # Finally wrap the PS-Information into the Service-Information grouped AVP
    diamPacket = DIAMUTILS.checkOmitAvp(extraAVP, 'Service-Information', avpList, diamPacket)
    #ServiceInformationAvp = DIAM.Avp('Service-Information', avpList)
    #diamPacket.appendAvpObj(ServiceInformationAvp)

    # Cleanup AVPs we really dont want added randomly to the diam pkt
    extraAVP = DIAMUTILS.cleanupUsedReqAvpAmounts(extraAVP)

    #override regardless of diam specification (fault tests)
    if 'override' in extraAVP:
        print(extraAVP['override'])
        for ((avp, val)) in extraAVP['override']:
            diamPacket = DIAMUTILS.checkOmitAvp(extraAVP, avp, val, diamPacket)
        del extraAVP['override']

    if extraAVP != None:
        for AVP in extraAVP:
            if AVP == 'MSCC' : continue
            if AVP == 'MsccManual' : continue
            if AVP == 'omit' : continue
            diamPacket = DIAMUTILS.checkOmitAvp(extraAVP, AVP, extraAVP[AVP], diamPacket)

    filename = 'diameter_send' 
    if diameterFileDebugFlag: logger.printRes(path, 'diameter_sent_pkts.txt', str(diamPacket), overwrite = False)
    diamResp = diamConnection.send(diamPacket)
    if diameterFileDebugFlag: logger.printRes(path, 'diameter_recv_pkts.txt', str(diamResp))
    #DIAMUTILS.checkDiamPkts(path, 'diameter_sent_pkts.txt', 'diameter_recv_pkts.txt', eventPass)
    DIAMUTILS.checkDiamPkts(path, str(diamPacket), diamResp, eventPass, stripList)
    dctRcvd = DIAMUTILS.getRawDiameterDct(path, str(diamResp))
    #qa_utils.printDct(dctRcvd)
    return dctRcvd

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

