#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:36:15
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:36:15
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:36:15
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

from __future__ import print_function
# from builtins import str
# from builtins import str
import os, sys, socket, copy, pprint
import collections
#try:
import custSpecific as CUST
#except ImportError:
#   os.system(' echo \"\" > custSpecific.py ')

import csv_data as DATA

#==========================================================
def processDataToOutput(data, fileName):
         # See where to output the returned data
         if not fileName or fileName.lower() in ['stdout', 'none']:
                # Send to standard Out
                print(str(data))
         else:
                # Write to a file
                # Open data file
                try:
                 dataFile = open(fileName.lstrip(), 'w')
                except IOError as e:
                 print('I/O error({0}) on opening of file "' + fileName + '". Error details: {1}'.format(e.errno, e.strerror))
                 sys.exit('Done')

                # Write the input data.
                # Append newline, as writing to file doesn't do this (and print does)
                dataFile.write(str(data)+'\n')

                # Close the file
                dataFile.close()

#==========================================================
def convertToolListToPythonList(inList):
#       print 'Input data: ' +  str(inList)
        # Simple to return this as a list.
        # May also receive a list of lists, so want to address that here.
        if not type(inList) == type(list()): retList = str(inList).split(DATA.listChar)
        else:
         # Go through each list item and if it's a list of lists then separate out
         retList = []
         for entry in inList: retList.extend(str(entry).split(DATA.listChar))
#        retList = inList

#       print 'Ouput data: ' +  str(retList)
        return retList

#==========================================================
def addCsvInputArgs(parser):
        # Create list of parameters that can be input.
        # Start with main list.
        fullList = []
        fullList.extend(DATA.parameters)
        
        # ** TEST duplicate detection
        #DATA.customGroupParameters.append(('balanceId', 'store', 'string', None))
        
        # Need to do duplicate checking.  Remove any duplicates.  Not a Pythonic way I could find...
        for item in [   "customSubscriberParameters",
                        "customDeviceParameters",
                        "customGroupParameters",
                        "customOfferParameters",
                        "customUserParameters",
                        "customLoginParameters",
                        "customApiEventDataParameters",
                        "custom5GRequestParameters"
                    ]:
                # See if defined (after earlier merging custom params with base)
                if hasattr(DATA, item):
                        # Build latest list of parameters.  There is still an issue if the same list has duplicates, but that's a low runner...
                        # Would need to re-run this command each time fullList.append((entry)) is run below (and move this line outside the for loop).
                        paramList = [x[0] for x in fullList]
                        
                        # Get items from the list
                        if   item == "customSubscriberParameters":      listPtr = DATA.customSubscriberParameters
                        elif item == "customDeviceParameters":          listPtr = DATA.customDeviceParameters
                        elif item == "customGroupParameters":           listPtr = DATA.customGroupParameters
                        elif item == "customOfferParameters":           listPtr = DATA.customOfferParameters
                        elif item == "customUserParameters":            listPtr = DATA.customUserParameters
                        elif item == "customLoginParameters":           listPtr = DATA.customLoginParameters
                        elif item == "customApiEventDataParameters":    listPtr = DATA.customApiEventDataParameters
                        elif item == "custom5GRequestParameters":       listPtr = DATA.custom5GRequestParameters
                        
                        # Walk this list and see if in the current parameter list
                        for entry in listPtr:
                                if entry[0] in paramList:       print('WARNING: duplicate parameter "' + str(entry[0]) + '" found')
                                else:                           fullList.append((entry))
        
#       print 'fullList: ' + str(fullList)
        
        # Process each parameter
        for lclVarTuple in fullList:
         # Call common funciton (reusable)
         # Separate out tuple components
         parmName = lclVarTuple[0]
         parmAction = lclVarTuple[1]

         # If the action is None, then this parameter is already defined in the base options data (qa_utils.py).  Skip.
         if parmAction == None:
                continue

         # Get rest of the tuple
         parmType = lclVarTuple[2]
         parmDefault = lclVarTuple[3]

         # Build the command line so it can be run through eval
         cmd = 'parser.add_option("", "--' + parmName + '", action=\'' + parmAction + '\', help="' + parmName + '"'

         # Add in type if value is not set to none
         if parmType != None:
                cmd += ', type=\'' + parmType + '\''

         # Default string depends on int vs string vs true/false
         if parmDefault == None:
                cmd += ', default=None)'
         elif parmAction.startswith('store_') and (parmDefault == True or str(parmDefault).lower() == 'true'):
                cmd += ', default=True)'
         elif parmAction.startswith('store_') and (parmDefault == False or str(parmDefault).lower() == 'false'):
                cmd += ', default=False)'
         elif parmType == 'string':
                cmd += ', default=\'' + parmDefault + '\')'
         elif parmType == 'int':
                cmd += ', default=' + str(parmDefault) + ')'
         else:
                cmd += ', default=' + str(parmDefault) + ')'

         #print('executing command: ' + cmd)
         exec(cmd)

        return parser

#==========================================================
def appendContentsOfCommandLineInputFiles(args):
        # Define list to track input files (so we don;t go into a recursive loop)
        FileProcessed = {}

        # Process until no more files in an input argument
        while DATA.inputFileString in args:
                # Get file parameter index
                index = args.index(DATA.inputFileString)

                # Get file name value.  Could be a comma separated list...
                fileNames = args[index+1]

                # Now want to remove the input file parameter from the args list, along with the file name, and then insert these args at that location
                args.pop(index)
                args.pop(index)

                # Convert argument to a list
                filesToProcess = fileNames.split(DATA.inputFileSepChar)

                for fileName in filesToProcess:
                 # Expand the name in case any ENV variables are there
                 fileName = os.path.expandvars(fileName)

                 # Check if we've processed this already
                 if fileName in FileProcessed:
                        print('ERROR:  input files are circular.  Files encountered are: ' + str(FileProcessed) + '. Trying to import file "' + fileName + '" a second time.')
                        sys.exit(1)

                 print('Processing command line parameter file ' + fileName)

                 # Add entry for this file
                 FileProcessed[fileName] = '1'

                 # Clear local args list for this file
                 lclArgs = []

                 # Open the file for reading
                 try:
                  f = open(fileName, 'r')
                 except IOError as e:
                  print('I/O error({0}) on opening of file "' + fileName + '". Error details: {1}'.format(e.errno, e.strerror))
                  sys.exit('Done')

                 for line in f:
                        # If a blank line before strip, then it's EOF
                        if not line:
                                break

                        # Remove leading/trailing white space (including the newline char - very annoying!)
                        line = line.rstrip()
                        line = line.lstrip()

                        # If a blank line after a strip, then skip (treat as a comment)
                        if not line:
                                continue

                        # If this starts with a comment character, then it's a comment line and we want to skip it
                        if line[0] in DATA.commentChar:
                                continue

                        # Finaly!  We are at a line to include.   Make sure to split the line as the command and the value are treated as two parameters in Python.
                        # Only split to the first white space, as offers can have white space in their name (this bug took over an hour to figure out!!)
                        # [This will work with the case where there is no white space as well (e.g. -ffile), but we're not doing that here...]
                        lclArgs = line.split(None,1)

                        # Now insert the parameter and argument starting from where the inputfile parameter was present (so we retain order if that ever matters)
                        # Some parameters are binary and thus may not have a value associated with them.
                        args.insert(index, lclArgs[0])
                        index += 1
                        if len(lclArgs) > 1:
                                args.insert(index, lclArgs[1])
                                index += 1

                        #print 'Inserted "' + str(lclArgs) + '" to the args list.  New args list is: "' + str(args)

                # Close the file
                f.close()

         #print 'Final args list is: "' + str(args)

        # Return final args list
        return args

#==========================================================
def main():
    x = 1


if __name__ == '__main__':
    main()

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

