#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:21
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:03
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:34:50
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================



# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
import os,sys, pprint
import data_container_defs as MDCDEFS
import qa_mdc_defs as QA_MDCDEFS
import QA_subscriber_management_rest_helper as RESTHELPER
import QA_subscriber_management_restv3 as RESTV3
import subscriber_mgmt_v3 as REST
import common_mdc as COMMON
import time
from xml.etree import ElementTree
import log_errors as mylogger
logger = mylogger.clErrors(os.getcwd())
import qa_utils as QAUTILS
import timeToMDCtime as MDCTIME
import data_container
import commonDefs as cd

#====================================================================
def getOID(responseMdc, key):
        # There's always an OID created if successful
        oid = responseMdc.getUsingKey(key)
        
        # Change colon to dash (for consistency with REST/JSON queries)
        oid = oid.replace(':', '-')
        
        #print 'getOID: oid = ' + str(oid)
        return oid

#=============================================================
def getSubscriptionOID(V3inst=0, queryValue=None, queryType='ExternalId', now=None):
        return getSubscriberOID(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)

#=============================================================
def getSubscriberOID(V3inst=0, queryValue=None, queryType='ExternalId', now=None):
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=None)
        if queryResponse: return getOID(queryResponse, MDCDEFS.kMtxResponseSubscriberObjectIdFldKey)
        else:             return None

#=============================================================
def getGroupOID(V3inst=0, queryValue=None, queryType='ExternalId', now=None):
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=None)
        if queryResponse: return getOID(queryResponse, MDCDEFS.kMtxResponseGroupObjectIdFldKey)
        else:             return None

#=============================================================
def getDeviceOID(V3inst=0, queryValue=None, queryType='ExternalId', now=None):
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=None)
        if queryResponse: return getOID(queryResponse, MDCDEFS.kMtxResponseDeviceObjectIdFldKey)
        else:             return None

#=============================================================
def getUserOID(V3inst=0, queryValue=None, queryType='ExternalId', now=None):
        queryResponse = queryUser(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=None)
        if queryResponse: return getOID(queryResponse, MDCDEFS.kMtxResponseUserObjectIdFldKey)
        else:             return None

#====================================================================
def failed(eventPass = True):
    if eventPass:
        return False
    else:
        return True

#====================================================================
def passed(eventPass = True):
    if eventPass:
        return True
    else:
        return False

#====================================================================
def getRoles(rolesPricingIds=None, rolesExternalIds=None):
    roles = []
    if rolesPricingIds:
        if type(rolesPricingIds) is list:
            for pricingId in rolesPricingIds:
                roles.append({'PricingId': pricingId})
        else: roles.append({'PricingId': rolesPricingIds})
    if rolesExternalIds:
        if type(rolesExternalIds) is list:
            for externalId in rolesExternalIds:
                roles.append({'ExternalId': externalId})
        else: roles.append({'ExternalId': rolesExternalIds})
    #print roles
    return roles

#====================================================================
def importSubscriberBalanceValue(V3inst=None, queryType='ExternalId', externalId=None, resourceId=None,
           amount=None, startTime=None, createOnDemand=None, now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()
    # Get to the point!
    responseMdc = V3inst.subscriberImportBalanceValue(queryType=queryType, queryValue=externalId, balanceResourceId=resourceId,
            amount=amount, startTime=startTime, createOnDemand=createOnDemand, now=now)

    # There's always an OID created if successful
##    oid = responseMdc.getUsingKey(MDCDEFS.kMtxResponseCreateObjectIdFldKey)
    oid = 'None Returned'

    #print 'oid from createSubscriber = ' + str(oid)

    # See if we failed or passed
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return (COMMON.debugFailure(method='importSubscriberBalanceValue', status=retCode, msg=retText, shouldPass=eventPass), oid)

    return (COMMON.debugSuccess(method='importSubscriberBalanceValue', shouldPass=eventPass), oid)

#=================================================================
def deleteUserSubscription(V3inst, queryValue=None, queryType='ExternalId', subQueryValue=None, subQueryType='ExternalId',
        now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True, apiEventData=None, multiRequestBuild=None):

    # remove subscription
    retCode = userRemoveSubscription(V3inst, userQueryValue=queryValue, userQueryType=queryType, subQueryValue=subQueryValue, subQueryType=subQueryType, eventPass=eventPass, now=now)

    retCode = deleteSubscription(V3inst, queryValue=subQueryValue, queryType=subQueryType, now=now, eventPass=eventPass)

    return retCode

#=================================================================
def createUserSubscription(V3inst=0, queryValue=None, queryType=None,
    # Subscription
    subExternalId=None, subStatus=None, timeZone=None, billingCycle=None, dateOffset=None,
    taxStatus=None, taxCertificate=None, taxLocation=None, glCenter=None, name=None, subAttr=None,
    subApiEventData=None, 
    #US Tax
    customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
    # Role
    rolesExternalIds=None, rolesPricingIds=None,
    #
    now=None, apiEventData=None, routingType=None, routingValue=None, executeMode=None, eventPass=True):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    #check if we passed a string for billingCycle and convert it to a billing cycle template
    if billingCycle:
        if type(billingCycle) is not data_container.DataContainer:
            billingCycle = createBillingCycleData(int(billingCycle), startTime=now, dateOffset=dateOffset)

    # Subscription
    (sRetCode, sOid) = createSubscription(V3inst, externalId=subExternalId, status=subStatus, timeZone=timeZone,
                              billingCycle=billingCycle, dateOffset=dateOffset, taxStatus=taxStatus,
                              taxCertificate=taxCertificate, taxLocation=taxLocation, glCenter=glCenter, name=name, attr=subAttr,
                              now=now, routingType=routingType, routingValue=routingValue, executeMode=executeMode,
                              customerType=customerType, serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId, 
                              exemptionCodeList=exemptionCodeList,
                              apiEventData=subApiEventData, eventPass=eventPass)

    # userAddSubscription
    retCode = userAddSubscription(V3inst, userQueryValue=queryValue, userQueryType=queryType, 
                  subQueryValue=sOid, subQueryType='ObjectId', rolesExternalIds=rolesExternalIds, rolesPricingIds=rolesPricingIds,
                  now=now, routingType=routingType, routingValue=routingValue, executeMode=executeMode, eventPass=eventPass,
                  apiEventData=apiEventData)

    return (passed(eventPass), sOid)

#=============================================================r===
def createSubscriberAndDevice(V3inst=0, externalId=None, queryValue=None, queryType=None,
        # User
        userId=None, userExternalId=None, firstName=None, lastName=None, contactEmail=None, contactPhoneNumber=None,
        contactPushTokenList=None, notificationPreference=None, language=None, userAttr=None,  userStatus=None,
        userApiEventData=None,
        # Subscriber
        subStatus=None, timeZone=None, billingCycle=None, dateOffset=None, subAttr=None, taxStatus=None, taxCertificate=None,
        taxLocation=None, glCenter=None, payload=None, subApiEventData=None,
        # Role
        rolesExternalIds=None, rolesPricingIds=None,
        # Device
        deviceId=None, deviceType=1, devAttr=None, accessNumbers=None, devStatus=None, deviceExternalId=None, devApiEventData=None,
        # PaymentMethod
        paymentGatewayId=None, paymentGatewayUserId=None, paymentGatewayOneTimeToken=None, paymentAttr=None, paymentName=None,
        paymentType=None, paymentIsDefault=None, paymentIsSysDefault=None, paymentApiEventData=None, 
        # Recharge Schedule
        firstRechargeTime=None, rechargePeriodType=None, rechargePeriodCoef=None, rechargeCycleTimeOfDay=None, rechargeCycleOffset=None,
        rechargeAmount=None, rechargeEndTimeExtensionOffsetUnit=None, rechargeEndTimeExtensionOffset=None, scheduledRechargeNotificationProfileId=None,
        rechargeApiEventData=None,
        # Offer
        chargeMethod=None, offerId=0, catalogItemId=None, offerStartTime=None, offerEndTime=None, offerIsExternal=None,
        offerAttr=None, endTimeRelativeOffset=None, endTimeRelativeOffsetUnit=None, downPayment=None,
        isTargetResource=None, useTargetResource=None, isRecurringFailureAllowed=None, parameterList=None, offerStatusValue=None,
        paymentDueDate=None, chargePurchaseProrationType=None, grantPurchaseProrationType=None, reason=None, info=None, offerApiEventData=None,
        offerLifecycleProfileId=None,
        # Offer Activation
        preActiveState=None, activationExpirationTime=None, activationExpirationRelativeOffsetUnit=None, activationExpirationRelativeOffset=None,
        autoActivationCycleResourceId=None, autoActivationTime=None, autoActivationRelativeOffsetUnit=None, autoActivationRelativeOffset=None,
        isPendingActivationAllowed=None,
        # Offer Cycle
        offerCycleType=None, offerCycleOffset=None, offerCycleResourceId=None, offerCycleStartTime=None,
        #
        apiEventData=None, now=None, eventPass=True, routingType=None, routingValue=None, purchaseInfo=False, executeMode=None,
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        multiRequestBuild=None, eligibilityCheck=True, geoData=None):

    if now is None:
        now=offerStartTime

    #check if we passed a string for billingCycle and convert it to a billing cycle template
    if billingCycle:
        if type(billingCycle) is not data_container.DataContainer:
            billingCycle = createBillingCycleData(int(billingCycle), startTime=now, dateOffset=dateOffset)

    if type(contactPushTokenList) is list:
          contactPushTokenList1=[]
          contactPushTokenList1 = contactPushTokenList
    else:
          contactPushTokenList1 = None

    # If we have a userExternalId, we create User, Subscription and Roles
    if userId or userExternalId:
        # User
        (uRetCode, uOid) = createUser(V3inst, userId=userId, externalId=userExternalId, firstName=firstName,
                              lastName=lastName, contactEmail=contactEmail, contactPhoneNumber=contactPhoneNumber,
                              contactPushTokenList=contactPushTokenList, notificationPreference=notificationPreference,
                              language=language, attr=userAttr, status=userStatus, tenantId=tenantId, apiEventData=userApiEventData,
                              now=now, routingType=routingType, routingValue=routingValue, executeMode=executeMode,
                              eventPass=eventPass)
        # Subscription
        (sRetCode, sOid) = createSubscription(V3inst, externalId=externalId, status=subStatus, timeZone=timeZone,
                              billingCycle=billingCycle, dateOffset=dateOffset, taxStatus=taxStatus,
                              taxCertificate=taxCertificate, taxLocation=taxLocation, glCenter=glCenter, attr=subAttr,
                              customerType=customerType, serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId, 
                              exemptionCodeList=exemptionCodeList, apiEventData=subApiEventData,
                              now=now, routingType=routingType, routingValue=routingValue, executeMode=executeMode,
                              eventPass=eventPass)
        oid=sOid

        # userAddSubscription
        retCode = userAddSubscription(V3inst, userQueryValue=uOid, subQueryValue=sOid,
                  rolesExternalIds=rolesExternalIds, rolesPricingIds=rolesPricingIds,
                  now=now, routingType=routingType, routingValue=routingValue, executeMode=executeMode, eventPass=eventPass)

    # Use the subUrl to see if we want just a Subscription
    elif RESTV3.subUrl == 'subscription' and not queryValue:
        (sRetCode, oid) = createSubscription(V3inst, externalId=externalId, status=subStatus, timeZone=timeZone,
                              billingCycle=billingCycle, dateOffset=dateOffset, taxStatus=taxStatus,
                              taxCertificate=taxCertificate, taxLocation=taxLocation, glCenter=glCenter, attr=subAttr,
                              customerType=customerType, serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId, 
                              exemptionCodeList=exemptionCodeList, apiEventData=subApiEventData,
                              now=now, routingType=routingType, routingValue=routingValue, executeMode=executeMode,
                              eventPass=eventPass)

    # If not then just create a Subscriber
    elif not queryValue:
        (retValue, oid) = createSubscriber(V3inst = V3inst, externalId = externalId, now = now,
        payload = payload, billingCycle = billingCycle, eventPass = eventPass, firstName = firstName,
        lastName = lastName, contactEmail = contactEmail, contactPhoneNumber = contactPhoneNumber,
        contactPushTokenList=contactPushTokenList1,
        notificationPreference = notificationPreference, timeZone = timeZone,
        attr = subAttr, status = subStatus, taxStatus=taxStatus, taxCertificate=taxCertificate,
        taxLocation=taxLocation, language = language, dupAttr=True, glCenter=glCenter, apiEventData=subApiEventData,
        customerType=customerType, serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId, exemptionCodeList=exemptionCodeList,
        routingType=routingType, routingValue=routingValue)

    # We already have a Subscriber
    elif queryType == 'ObjectId':
        oid=queryValue
    else:
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        oid = queryResponse.getUsingKey(MDCDEFS.kMtxResponseSubscriberObjectIdFldKey)
        queryType='ObjectId'

    # create a new device if a deviceId is provided
    if deviceId is not None:
        # Add device to the subscriber if one was specified.
        (retCode, deviceOid) = addDeviceToSubscriber(V3inst, oid, deviceId, deviceType, deviceExternalId=deviceExternalId, accessNumbers = accessNumbers,
            subQueryType = 'ObjectId', devQueryType = 'PhoneNumber', eventPass = eventPass, attr=devAttr, tenantId=tenantId, apiEventData=devApiEventData,
            status=devStatus, now=now, noTouch=False, devOid=None, routingType=routingType, routingValue=routingValue)
        if not retCode:
            return (failed(eventPass), oid)

    # Add Payment Method
    if paymentGatewayId is not None and paymentGatewayOneTimeToken is not None:
        retCode = subscriberAddPaymentMethod(V3inst, queryValue=externalId, paymentGatewayUserId=paymentGatewayId,
                          paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, paymentGatewayId=paymentGatewayId,
                          paymentType=paymentType, name=paymentName, isDefault=paymentIsDefault, isSysDefault=paymentIsSysDefault,
                          paymentAttr=paymentAttr, now=now, eventPass=eventPass)
        if not retCode:
            return (failed(eventPass), oid)

    if offerId != 0 or catalogItemId:
        if not subscribeToOffer(V3inst = V3inst, externalId = oid, offerId = offerId, catalogItemId=catalogItemId,
                offerStartTime = offerStartTime, offerEndTime = offerEndTime, eventPass = eventPass,
                queryType = 'ObjectId', now=now, offerIsExternal=offerIsExternal, attr=offerAttr,
                chargeMethod=chargeMethod, paymentGatewayId=paymentGatewayId,
                paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, preActiveState=preActiveState,
                paymentGatewayUserId=paymentGatewayUserId, autoActivationTime=autoActivationTime,
                autoActivationRelativeOffsetUnit=autoActivationRelativeOffsetUnit, autoActivationRelativeOffset=autoActivationRelativeOffset,
                autoActivationCycleResourceId=autoActivationCycleResourceId, activationExpirationTime=activationExpirationTime,
                activationExpirationRelativeOffsetUnit=activationExpirationRelativeOffsetUnit,
                activationExpirationRelativeOffset=activationExpirationRelativeOffset, endTimeRelativeOffset=endTimeRelativeOffset,
                endTimeRelativeOffsetUnit=endTimeRelativeOffsetUnit,
                offerCycleType=offerCycleType, offerCycleOffset=offerCycleOffset, offerCycleStartTime=offerCycleStartTime,
                downPayment=downPayment, isTargetResource=isTargetResource, useTargetResource=useTargetResource,
                isRecurringFailureAllowed=isRecurringFailureAllowed, chargePurchaseProrationType=chargePurchaseProrationType,
                grantPurchaseProrationType=grantPurchaseProrationType, reason=reason, info=info, eligibilityCheck=eligibilityCheck,
                isPendingActivationAllowed=isPendingActivationAllowed, offerLifecycleProfileId=offerLifecycleProfileId,
                routingType=routingType, routingValue=routingValue,
                paymentDueDate=paymentDueDate, apiEventData=offerApiEventData, parameterList=parameterList, offerStatusValue=offerStatusValue, geoData=geoData):
            return (failed(eventPass), oid)

    # Add a Recharge Schedule
    if rechargePeriodType is not None and rechargeAmount is not None:
        retCode = subscriberAddRechargeSchedule(V3inst, queryValue=externalId, amount=rechargeAmount, periodType=rechargePeriodType,
                          firstRechargeTime=firstRechargeTime, periodCoef=rechargePeriodCoef, cycleTimeOfDay=rechargeCycleTimeOfDay,
                          cycleOffset=rechargeCycleOffset, endTimeExtensionOffsetUnit=rechargeEndTimeExtensionOffsetUnit,
                          endTimeExtensionOffset=rechargeEndTimeExtensionOffset,
                          scheduledRechargeNotificationProfileId=scheduledRechargeNotificationProfileId,
                          eventPass=eventPass, now=now)
        if not retCode:
            return (failed(eventPass), oid)

    return (passed(eventPass), oid)

#====================================================================
def createUserAndSubscription(V3inst,
        # User
        userId=None, userExternalId=None, firstName=None, lastName=None,
        contactEmail=None, contactPhoneNumber=None, contactPushTokenList=None, notificationPreference=None,
        language=None, userAttr=None,  userStatus=None, userApiEventData=None,
        # Subscription
        subExternalId=None, subStatus=None, timeZone=None, billingCycle=None, dateOffset=None,
        taxStatus=None, taxCertificate=None, taxLocation=None, glCenter=None, name=None, subAttr=None,
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None, 
        subApiEventData=None,
        # Role
        rolesExternalIds=None, rolesPricingIds=None,
        #
        now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True):

        # User
        (uRetCode, uOid) = createUser(V3inst, userId=userId, externalId=userExternalId, firstName=firstName,
                              lastName=lastName, contactEmail=contactEmail, contactPhoneNumber=contactPhoneNumber,
                              contactPushTokenList=contactPushTokenList, notificationPreference=notificationPreference,
                              language=language, attr=userAttr, status=userStatus,  tenantId=tenantId, apiEventData=userApiEventData,
                              now=now, routingType=routingType, routingValue=routingValue, executeMode=executeMode, 
                              eventPass=eventPass)
        # Subscription
        (sRetCode, sOid) = createSubscription(V3inst, externalId=subExternalId, status=subStatus, timeZone=timeZone,
                              billingCycle=billingCycle, dateOffset=dateOffset, taxStatus=taxStatus,
                              taxCertificate=taxCertificate, taxLocation=taxLocation, glCenter=glCenter, name=name, attr=subAttr,
                              customerType=customerType, serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId, 
                              exemptionCodeList=exemptionCodeList,
                              apiEventData=subApiEventData, now=now, routingType=routingType, routingValue=routingValue, 
                              executeMode=executeMode, eventPass=eventPass)

        # userAddSubscription
        retCode = userAddSubscription(V3inst, userQueryValue=uOid, subQueryValue=sOid, 
                  rolesExternalIds=rolesExternalIds, rolesPricingIds=rolesPricingIds,
                  now=now, routingType=routingType, routingValue=routingValue, executeMode=executeMode, eventPass=eventPass)

        # For nor just assume it passes
        return (COMMON.debugSuccess(method='createUserAndSubscription', shouldPass=eventPass), uOid, sOid)

#====================================================================
def createSubscription(V3inst, externalId=None, status=None, timeZone=None, billingCycle=None, dateOffset=None,
        attr=None, taxStatus=None, taxCertificate=None, taxLocation=None, glCenter=None, name=None, apiEventData=None, 
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    fname = sys._getframe().f_code.co_name

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    #check if we passed a string for billingCycle and convert it to a billing cycle template
    if billingCycle:
        if type(billingCycle) is not data_container.DataContainer:
            billingCycle = createBillingCycleData(int(billingCycle), startTime=now, dateOffset=dateOffset)

    apiName = 'subscriptionCreate'
    paramString = 'now=now, externalId=externalId, status=status, timeZone=timeZone, billingCycle=billingCycle, \
                   attr=attr, taxStatus=taxStatus, taxCertificate=taxCertificate, taxLocation=taxLocation, glCenter=glCenter, \
                   name=name'

    # Build the command of additional parameters.
    for item in ['apiEventData','customerType','serviceAddress','npa','nxx','tenantId','exemptionCodeList']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    # If a multi request then return the payload
    if multiRequestBuild:       return responseMdc

    # There's always an OID created if successful
    oid = responseMdc.getUsingKey(MDCDEFS.kMtxResponseCreateObjectIdFldKey)

    print('oid from createSubscription = ' + str(oid))

    # See if we failed or passed
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return (COMMON.debugFailure(method=fname, status=retCode, msg=retText, shouldPass=eventPass), oid)

    return (COMMON.debugSuccess(method=fname, shouldPass=eventPass), oid)

#=============================================================
def querySubscription(V3inst, queryValue, queryType='ExternalId', eventPass=True, querySize=None, now=None, routingType=None, routingValue=None, useResponseSubscriptionTransformer=False, multiRequestBuild=None):

    #print "querySub:===== ", now
    responseMdc = V3inst.subscriptionQuery(queryType=queryType, queryValue=queryValue, querySize=querySize, now=now)
    # mdc not support useResponseSubscriptionTransformer

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='querySubscription', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='querySubscription', shouldPass=eventPass):
        return responseMdc

#====================================================================
def modifySubscription(V3inst, queryValue=None, queryType='ExternalId', externalId=None, status=None, timeZone=None,
        name=None, billingCycle=None, dateOffset=None, immediateChange=None, billingCycleDisabled=None,
        attr=None, taxStatus=None, taxCertificate=None, taxLocation=None, glCenter=None, lastActivityUpdateTime=None,
        currentPaymentTokenResourceId=None, sysPaymentTokenResourceId=None,
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        apiEventData=None, routingType=None, routingValue=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    # Get function name
    fname = sys._getframe().f_code.co_name

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    #check if we passed a string for billingCycle and convert it to a billing cycle template
    if billingCycle:
        if type(billingCycle) is not data_container.DataContainer:
            billingCycle = createBillingCycleData(int(billingCycle), startTime=now, dateOffset=dateOffset, immediateChange=immediateChange)

    apiName = 'subscriptionModify'
    paramString = 'now=now, queryValue=queryValue, queryType=queryType, externalId=externalId, status=status, timeZone=timeZone, \
                   name=name, billingCycle=billingCycle, billingCycleDisabled=billingCycleDisabled, \
                   attr=attr, taxStatus=taxStatus, taxCertificate=taxCertificate, taxLocation=taxLocation, glCenter=glCenter, \
                   lastActivityUpdateTime=lastActivityUpdateTime, currentPaymentTokenResourceId=currentPaymentTokenResourceId, \
                   sysPaymentTokenResourceId=sysPaymentTokenResourceId'

    # Build the command of additional parameters.
    for item in ['apiEventData','customerType','serviceAddress','npa','nxx','tenantId','exemptionCodeList']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)
    
    # If a multi request then return the payload
    if multiRequestBuild:       return responseMdc

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method=fname, status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method=fname, shouldPass=eventPass)

#====================================================================
def deleteSubscription(V3inst, queryValue=None, queryType='ExternalId', deleteSession=False, deleteDevices=False,
        now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True,
        apiEventData=None, multiRequestBuild=None):


    # Get function name
    fname = sys._getframe().f_code.co_name

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    apiName = 'subscriptionDelete'
    paramString = 'queryType=queryType, queryValue=queryValue, now=now, deleteDevices=deleteDevices, deleteSession=deleteSession'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)
    
    # If a multi request then return the payload
    if multiRequestBuild:       return responseMdc

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='deleteSubscription', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='deleteSubscription', shouldPass=eventPass):
        return responseMdc

#====================================================================
def createUser(V3inst, userId=None, externalId=None, firstName=None, lastName=None,
        contactEmail=None, contactPhoneNumber=None, contactPushTokenList=None, notificationPreference=None,
        language=None, attr=None,  status=None, now=None, routingType=None, routingValue=None, executeMode=None,
        tenantId=None, apiEventData=None, eventPass=True, multiRequestBuild=None, timeZone=None):

    # Get function name
    fname = sys._getframe().f_code.co_name

    if type(contactPushTokenList) is list:
          contactPushTokenList1=[]
          contactPushTokenList1 = contactPushTokenList
    else:
          contactPushTokenList1 = None

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'userId=userId, externalId=externalId, firstName=firstName, lastName=lastName, \
                   contactEmail=contactEmail, contactPhoneNumber=contactPhoneNumber, contactPushTokenList=contactPushTokenList1, \
                   notificationPreference=notificationPreference, language=language, attr=attr, now=now'

    # Build the command of additional parameters.
    for item in ['status', 'timeZone', 'tenantId', 'apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    apiName = 'userCreate'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print(apiName + ': cmd = ' + cmd)
    responseMdc = eval(cmd)
    
    # If a multi request then return the payload
    if multiRequestBuild:       return responseMdc

    # There's always an OID created if successful
    oid = responseMdc.getUsingKey(MDCDEFS.kMtxResponseCreateObjectIdFldKey)

    #print('oid from createUser = ' + str(oid))

    # See if we failed or passed
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return (COMMON.debugFailure(method=fname, status=retCode, msg=retText, shouldPass=eventPass), oid)

    return (COMMON.debugSuccess(method=fname, shouldPass=eventPass), oid)

#=============================================================
def queryUser(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None, routingType=None, routingValue=None, multiRequestBuild=None):

    apiName = 'userQuery'

    paramString = 'queryValue=queryValue, queryType=queryType, now=now'

    if multiRequestBuild:
        cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:
        cmd = 'V3inst.' + apiName + '(' + paramString+ ')'
    #print apiName + ': cmd =' + cmd
    responseMdc = eval(cmd)

    # If a multi request then return the payload
    if multiRequestBuild:       return responseMdc

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='queryUser', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='queryUser', shouldPass=eventPass):
        return responseMdc

#====================================================================
def modifyUserAndAuthData(V3inst, queryValue=None, queryType='ExternalId', userId=None, externalId=None, firstName=None, lastName=None,
        contactEmail=None, contactPhoneNumber=None, contactPushTokenList=None, notificationPreference=None,
        language=None, attr=None, status=None, loginId=None, password=None, tenantId=None,
        userApiEventData=None, authApiEventData=None, apiEventData=None, lastActivityUpdateTime=None, 
        routingType=None, routingValue=None, now=None, executeMode=None, eventPass=True, multiRequestBuild=None):


    modifyUser(V3inst=V3inst, queryValue=queryValue, queryType=queryType, userId=userId, externalId=externalId,
        firstName=firstName, lastName=lastName, contactEmail=contactEmail, contactPhoneNumber=contactPhoneNumber,
        contactPushTokenList=contactPushTokenList, notificationPreference=notificationPreference,
        language=language, attr=attr, status=status, routingType=routingType, routingValue=routingValue, now=now,
        lastActivityUpdateTime=lastActivityUpdateTime, tenantId=tenantId, executeMode=executeMode, eventPass=eventPass, apiEventData=userApiEventData,
        multiRequestBuild=multiRequestBuild)

    userModifyAuthData(V3inst=V3inst, queryValue=queryValue, queryType=queryType, loginId=loginId, password=password,
        now=now, routingType=routingType, routingValue=routingValue, executeMode=executeMode, eventPass=eventPass,
        apiEventData=authApiEventData, multiRequestBuild=multiRequestBuild)

#====================================================================
def modifyUser(V3inst, queryValue=None, queryType='ExternalId', userId=None, externalId=None, firstName=None, lastName=None,
        contactEmail=None, contactPhoneNumber=None, contactPushTokenList=None, notificationPreference=None,
        language=None, attr=None, status=None, routingType=None, routingValue=None, tenantId=None, now=None, executeMode=None, eventPass=True,
        lastActivityUpdateTime=None, apiEventData=None, multiRequestBuild=None):

    # Get function name
    fname = sys._getframe().f_code.co_name

    if type(contactPushTokenList) is list:
          contactPushTokenList1=[]
          contactPushTokenList1 = contactPushTokenList
    else:
          contactPushTokenList1 = None

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    apiName = 'userModify'
    paramString = 'queryValue=queryValue, queryType=queryType, userId=userId, externalId=externalId, firstName=firstName, lastName=lastName, \
                   contactEmail=contactEmail, contactPhoneNumber=contactPhoneNumber, contactPushTokenList=contactPushTokenList1, \
                   notificationPreference=notificationPreference, language=language, attr=attr, now=now'

    # Build the command of additional parameters.
    for item in ['status', 'apiEventData', 'tenantId', 'lastActivityUpdateTime']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)
    
    # If a multi request then return the payload
    if multiRequestBuild:       return responseMdc

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method=fname, status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method=fname, shouldPass=eventPass)

#====================================================================
def deleteUser(V3inst, queryValue=None, queryType='ExternalId', userId=None,
        now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True,
        deleteSubscription=None, deleteDevices=None, deleteSession=None,
        removeExplicitMembership=False, apiEventData=None, multiRequestBuild=None):

    # Get function name
    fname = sys._getframe().f_code.co_name

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    apiName = 'userDelete'
    paramString = 'queryValue=queryValue, queryType=queryType, \
                   deleteSubscription=deleteSubscription, deleteDevices=deleteDevices, deleteSession=deleteSession, removeExplicitMembership=removeExplicitMembership'

    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)
    
    # If a multi request then return the payload
    if multiRequestBuild:       return responseMdc

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='deleteUser', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='deleteUser', shouldPass=eventPass):
        return responseMdc

#====================================================================
def userModifyAuthData(V3inst, queryValue=None, queryType='ExternalId', loginId=None, password=None, now=None,
        routingType=None, routingValue=None, executeMode=None, eventPass=True, isService=False,
        apiEventData=None, multiRequestBuild=None):

    # Get function name
    fname = sys._getframe().f_code.co_name

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    apiName = 'userModifyAuthData'
    paramString = 'now=now, queryValue=queryValue, queryType=queryType, loginId=loginId, password=password'

    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    print( apiName + ': cmd = ' + cmd)
    responseMdc = eval(cmd)
    
    # If a multi request then return the payload
    if multiRequestBuild:       return responseMdc

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method=fname, status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method=fname, shouldPass=eventPass)

#====================================================================
def userQueryAuthData(V3inst, queryValue=None, queryType='ExternalId', now=None,
        routingType=None, routingValue=None, executeMode=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    fname = sys._getframe().f_code.co_name

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.userQueryAuthData(now=now, queryValue=queryValue, queryType=queryType)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method=fname, status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method=fname, shouldPass=eventPass):
        return responseMdc

#====================================================================
def userAddGroup(V3inst, userQueryValue=None, userQueryType='ObjectId', grpQueryValue=None, grpQueryType='ObjectId',
        rolesPricingIds=None, rolesExternalIds=None, now=None, routingType=None, routingValue=None, executeMode=None,
        eventPass=True, apiEventData=None, multiRequestBuild=None):

    # Get function name
    fname = sys._getframe().f_code.co_name

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    roles=None
    if rolesPricingIds or rolesExternalIds:
        roles = getRoles(rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds)

    apiName = 'userAddGroup'
    paramString = 'userQueryValue=userQueryValue, userQueryType=userQueryType, \
                   grpQueryValue=grpQueryValue, grpQueryType=grpQueryType, now=now'

    for item in ['roles', 'apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    # If a multi request then return the payload
    if multiRequestBuild:       return responseMdc

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method=fname, status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method=fname, shouldPass=eventPass)

#====================================================================
def userModifyGroup(V3inst, userQueryValue=None, userQueryType='ObjectId', grpQueryValue=None, grpQueryType='ObjectId',
        rolesPricingIds=None, rolesExternalIds=None, now=None, routingType=None, routingValue=None, executeMode=None,
        eventPass=True, removeExplicitMembership=False, apiEventData=None, multiRequestBuild=None):

    # Get function name
    fname = sys._getframe().f_code.co_name

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    roles=None
    if rolesPricingIds or rolesExternalIds:
        roles = getRoles(rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds)

    apiName = 'userModifyGroup'
    paramString = 'userQueryValue=userQueryValue, userQueryType=userQueryType, \
                   grpQueryValue=grpQueryValue, grpQueryType=grpQueryType, removeExplicitMembership=removeExplicitMembership, now=now'

    for item in ['roles', 'apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    # If a multi request then return the payload
    if multiRequestBuild:       return responseMdc

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method=fname, status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method=fname, shouldPass=eventPass)

#====================================================================
def userRemoveGroup(V3inst, userQueryValue=None, userQueryType='ObjectId', grpQueryValue=None, grpQueryType='ObjectId',
        now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True, apiEventData=None, multiRequestBuild=None, removeExplicitMembership=False):

    # Get function name
    fname = sys._getframe().f_code.co_name

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    apiName = 'userRemoveGroup'
    paramString = 'userQueryValue=userQueryValue, userQueryType=userQueryType, \
                   grpQueryValue=grpQueryValue, grpQueryType=grpQueryType, removeExplicitMembership=removeExplicitMembership, now=now'

    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)
    
    # If a multi request then return the payload
    if multiRequestBuild:       return responseMdc

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method=fname, status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method=fname, shouldPass=eventPass)

#====================================================================
def userAddSubscription(V3inst, userQueryValue=None, userQueryType='ObjectId', subQueryValue=None, subQueryType='ObjectId',
        rolesPricingIds=None, rolesExternalIds=None, now=None, routingType=None, routingValue=None, executeMode=None,
        eventPass=True, apiEventData=None, multiRequestBuild=None):

    # Get function name
    fname = sys._getframe().f_code.co_name

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()
 
    roles = getRoles(rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds)

    apiName = 'userAddSubscription'
    paramString = 'userQueryValue=userQueryValue, userQueryType=userQueryType, \
                   subQueryValue=subQueryValue, subQueryType=subQueryType, now=now'
    if roles:
      for item in ['roles']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    # If a multi request then return the payload
    if multiRequestBuild:       return responseMdc

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method=fname, status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method=fname, shouldPass=eventPass)

#====================================================================
def userModifySubscription(V3inst, userQueryValue=None, userQueryType='ObjectId', subQueryValue=None, subQueryType='ObjectId',
        rolesPricingIds=None, rolesExternalIds=None, now=None, routingType=None, routingValue=None, executeMode=None,
        eventPass=True, apiEventData=None, multiRequestBuild=None, removeExplicitMembership=False):

    # Get function name
    fname = sys._getframe().f_code.co_name

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    roles = getRoles(rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds)

    apiName = 'userModifySubscription'
    paramString = 'userQueryValue=userQueryValue, userQueryType=userQueryType, \
                   subQueryValue=subQueryValue, subQueryType=subQueryType, removeExplicitMembership=removeExplicitMembership, now=now'

    for item in ['roles']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    # If a multi request then return the payload
    if multiRequestBuild:       return responseMdc

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method=fname, status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method=fname, shouldPass=eventPass)

#====================================================================
def userRemoveSubscription(V3inst, userQueryValue=None, userQueryType='ObjectId', subQueryValue=None, subQueryType='ObjectId',
        now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True, removeExplicitMembership=False, apiEventData=None, multiRequestBuild=None):

    # Get function name
    fname = sys._getframe().f_code.co_name

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    apiName = 'userRemoveSubscription'
    paramString = 'userQueryValue=userQueryValue, userQueryType=userQueryType, \
                   subQueryValue=subQueryValue, subQueryType=subQueryType, removeExplicitMembership=removeExplicitMembership, now=now'

    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)
    
    # If a multi request then return the payload
    if multiRequestBuild:       return responseMdc

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method=fname, status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method=fname, shouldPass=eventPass)

#=============================================================
def queryUserEvent(V3inst, queryValue, queryType='ExternalId', querySize=None, queryCursor=None,
    eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypeStringArray=None,  now=None, eventPass=True):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Ensure array is in fact an array
    if eventTypeStringArray:
        if type(eventTypeStringArray) is list:  eventTypeStringArray = [str(i) for i in eventTypeStringArray]
        else:                                   eventTypeStringArray = [str(eventTypeStringArray)]

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, now=now,\
                   querySize=querySize, queryCursor=queryCursor,\
                   eventTimeLowerBound=eventTimeLowerBound, eventTimeUpperBound=eventTimeUpperBound, \
                   eventTypeStringArray=eventTypeStringArray'

    # Execute the call
    cmd = 'V3inst.userQueryEvent(' + paramString + ')'
    #print 'userQueryEvent: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return (COMMON.debugFailure(method='queryUserEvent', status=retCode, msg=retText, shouldPass=eventPass), 0)

    if COMMON.debugSuccess(method='queryUserEvent', shouldPass=eventPass):
        cursor = responseMdc.getUsingKey(MDCDEFS.kMtxResponseEventInfoQueryCursorFldKey)
        return (responseMdc, cursor)

#====================================================================
def groupAddUser(V3inst, userQueryValue=None, userQueryType='ObjectId', grpQueryValue=None, grpQueryType='ObjectId',
        rolesPricingIds=None, rolesExternalIds=None, now=None, routingType=None, routingValue=None, executeMode=None,
        eventPass=True, apiEventData=None, multiRequestBuild=None):

    # Get function name
    fname = sys._getframe().f_code.co_name

    roles=None
    if rolesPricingIds or rolesExternalIds:
        roles = getRoles(rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds)

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    apiName = 'groupAddUser'
    paramString = 'userQueryValue=userQueryValue, userQueryType=userQueryType, \
                   grpQueryValue=grpQueryValue, grpQueryType=grpQueryType, now=now'

    for item in ['roles']:
       # cmd = 'if ' + item + ' != None: paramString += \', ' + item + '=' + item + '\''
        if item !=None:
            paramString += ', ' + item + '=' + item 
        #exec(cmd)

    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    # If a multi request then return the payload
    if multiRequestBuild:       return responseMdc

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method=fname, status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method=fname, shouldPass=eventPass)

#====================================================================
def groupModifyUser(V3inst, userQueryValue=None, userQueryType='ObjectId', grpQueryValue=None, grpQueryType='ObjectId',
        rolesPricingIds=None, rolesExternalIds=None, now=None, routingType=None, routingValue=None, executeMode=None,
        eventPass=True, removeExplicitMembership=False, apiEventData=None, multiRequestBuild=None):

    # Get function name
    fname = sys._getframe().f_code.co_name

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    roles=None
    if rolesPricingIds or rolesExternalIds:
        roles = getRoles(rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds)

    apiName = 'groupModifyUser'
    paramString = 'userQueryValue=userQueryValue, userQueryType=userQueryType, \
                   grpQueryValue=grpQueryValue, grpQueryType=grpQueryType, now=now, removeExplicitMembership=removeExplicitMembership'

    for item in ['roles']:
       # cmd = 'if ' + item + ' != None: paramString += \', ' + item + '=' + item + '\''
        if item !=None:
            paramString += ', '  + item + '=' + item
        #exec(cmd)

    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    # If a multi request then return the payload
    if multiRequestBuild:       return responseMdc

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method=fname, status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method=fname, shouldPass=eventPass)

#====================================================================
def groupRemoveUser(V3inst, userQueryValue=None, userQueryType='ObjectId', grpQueryValue=None, grpQueryType='ObjectId',
        now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True,
        removeExplicitMembership=False, apiEventData=None, multiRequestBuild=None):

    # Get function name
    fname = sys._getframe().f_code.co_name

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    apiName = 'groupRemoveUser'
    paramString = 'userQueryValue=userQueryValue, userQueryType=userQueryType, \
                   grpQueryValue=grpQueryValue, grpQueryType=grpQueryType, removeExplicitMembership=False, now=now'

    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)
    
    # If a multi request then return the payload
    if multiRequestBuild:       return responseMdc

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method=fname, status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method=fname, shouldPass=eventPass)

#====================================================================
def queryGroupUsers(V3inst, queryValue=None, queryType='ObjectId', returnExternalId=None, querySize=None, queryCursor=None,
        routingType=None, routingValue=None, eventPass=True, now=None, apiEventData=None, multiRequestBuild=None):

    # Get function name
    fname = sys._getframe().f_code.co_name

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryValue=queryValue, queryType=queryType, returnExternalId=returnExternalId, \
                   querySize=querySize, queryCursor=queryCursor, now=now, membershipType=4'

    # Execute the call
    apiName = 'groupQueryMembership'
    cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return (COMMON.debugFailure(method=apiName, status=retCode, msg=retText, shouldPass=eventPass), 0)

    if COMMON.debugSuccess(method=apiName, shouldPass=eventPass):
        cursor = responseMdc.getUsingKey(MDCDEFS.kMtxResponseMemberResultSetQueryCursorFldKey)
        return (responseMdc, cursor)

#====================================================================
def queryUserGroups(V3inst, queryValue=None, queryType='ObjectId', returnExternalId=None, querySize=None, queryCursor=None,
        routingType=None, routingValue=None, eventPass=True, now=None, multiRequestBuild=None):

    # Get function name
    fname = sys._getframe().f_code.co_name

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryValue=queryValue, queryType=queryType, returnExternalId=returnExternalId, \
                   querySize=querySize, queryCursor=queryCursor, now=now, membershipType=2'

    # Execute the call
    apiName = 'userQueryMembership'
    cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return (COMMON.debugFailure(method=apiName, status=retCode, msg=retText, shouldPass=eventPass), 0)

    if COMMON.debugSuccess(method=apiName, shouldPass=eventPass):
        cursor = responseMdc.getUsingKey(MDCDEFS.kMtxResponseMemberResultSetQueryCursorFldKey)
        return (responseMdc, cursor)

#====================================================================
def queryUserSubscriptions(V3inst, queryValue=None, queryType='ObjectId', returnExternalId=None, querySize=None, queryCursor=None,
        routingType=None, routingValue=None, eventPass=True, now=None, multiRequestBuild=None):

    # Get function name
    fname = sys._getframe().f_code.co_name

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryValue=queryValue, queryType=queryType, returnExternalId=returnExternalId, \
                   querySize=querySize, queryCursor=queryCursor, now=now, membershipType=1'

    # Execute the call
    apiName = 'userQueryMembership'
    cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return (COMMON.debugFailure(method=apiName, status=retCode, msg=retText, shouldPass=eventPass), 0)

    if COMMON.debugSuccess(method=apiName, shouldPass=eventPass):
        cursor = responseMdc.getUsingKey(MDCDEFS.kMtxResponseMemberResultSetQueryCursorFldKey)
        return (responseMdc, cursor)

#====================================================================
def querySubscriberUsers(V3inst, queryValue=None, queryType='ObjectId', returnExternalId=None, querySize=None, queryCursor=None,
        routingType=None, routingValue=None, eventPass=True, now=None, multiRequestBuild=None):

    # Get function name
    fname = sys._getframe().f_code.co_name

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryValue=queryValue, queryType=queryType, returnExternalId=returnExternalId, \
                   querySize=querySize, queryCursor=queryCursor, membershipType=3'

    # Execute the call
    apiName = 'subscriberQueryMembership'
    cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return (COMMON.debugFailure(method=apiName, status=retCode, msg=retText, shouldPass=eventPass), 0)

    if COMMON.debugSuccess(method=apiName, shouldPass=eventPass):
        cursor = responseMdc.getUsingKey(MDCDEFS.kMtxResponseMemberResultSetQueryCursorFldKey)
        return (responseMdc, cursor)

#====================================================================
def createSubscriber(V3inst=None, externalId=None, now=None, payload=None, billingCycle=None, eventPass=True, 
        firstName=None, lastName=None, contactEmail=None, contactPhoneNumber=None, notificationPreference=None, contactPushTokenList=None,
        timeZone=None, attr=None, status=None, taxStatus=None, taxCertificate=None, taxLocation=None, apiEventData=None, 
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        language=None, dupAttr=True, dateOffset=None, glCenter=None, name=None, routingType=None, routingValue=None, executeMode=None, multiRequestBuild=None, apiEventSecurityInfo=None):

    # Get function name
    fname = sys._getframe().f_code.co_name
    
    # Allow function to be called directoy from the command line
    if V3inst == None: V3inst = QAUTILS.getSubscInterfaceMDC()

    #if notificaiton preference defined in ~common/config.ini is not None, 
    #override the default notficationPreference None value
    #subPrefConfig = QAUTILS.gatewaysConfig.get('NOTIFICATIONPREFERENCE','suscriberPreference') 
    #print subPrefConfig
    #if subPrefConfig and notificationPreference is None:
    #    notificationPreference = subPrefConfig
    #    print notificationPreference
    
    if payload:
        firstName = payload['firstName'] 
        lastName = payload['lastName']
        contactEmail = payload['contactEmail']
        contactPhoneNumber = payload['contactPhoneNumber']
        timeZone = payload['timeZone']
        attr = payload['attr']
        notificationPreference = payload['notificationPreference']

    #check if we passed a string for billingCycle and convert it to a billing cycle template
    if billingCycle:
        if type(billingCycle) is not data_container.DataContainer:
            billingCycle = createBillingCycleData(int(billingCycle), startTime=now, dateOffset=dateOffset)

    # Define baseline parameters - good from day 1
    paramString = 'now=now, externalId=externalId, firstName=firstName, lastName=lastName, contactEmail=contactEmail,           \
                contactPhoneNumber=contactPhoneNumber, notificationPreference=notificationPreference, timeZone=timeZone,        \
                billingCycle=billingCycle, attr=attr,  status=status, taxStatus=taxStatus, taxCertificate=taxCertificate,       \
                taxLocation=taxLocation,language=language'
    
    # Build the command of additional parameters.
    for item in ['glCenter', 'routingType', 'routingValue','contactPushTokenList', 'name', 'apiEventData','customerType','serviceAddress','npa','nxx','tenantId','exemptionCodeList', 'apiEventSecurityInfo']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item
    
    # Execute the call
    apiName = 'subscriberCreate'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)
    
    # If a multi request then return the payload
    if multiRequestBuild:       return responseMdc
    
    # There's always an OID created if successful
    oid = responseMdc.getUsingKey(MDCDEFS.kMtxResponseCreateObjectIdFldKey)

    #print 'oid from createSubscriber = ' + str(oid)

    # See if we failed or passed
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return (COMMON.debugFailure(method=fname, status=retCode, msg=retText, shouldPass=eventPass), oid)

    return (COMMON.debugSuccess(method=fname, shouldPass=eventPass), oid)

#====================================================================
def addSubscriber(V3inst, externalId = None, deviceId = None, deviceType = 1, offerId = 0, catalogItemId=None,
        offerStartTime = None, offerEndTime = None, serviceId = None, payload = None, subAttr = None,
        billingCycle = None, eventPass=True, firstName=None, lastName=None, contactEmail=None, contactPhoneNumber=None,  contactPushTokenList=None,
        notificationPreference=None, timeZone=None,  now=None, devAttr=None, accessNumbers=None,
        subStatus=None, devStatus=None, taxStatus=None, taxCertificate=None, taxLocation=None, language=None, 
        chargeMethod=None, paymentMethodResourceId=None, paymentGatewayId=None, paymentGatewayOneTimeToken=None, offerIsExternal=False,
        paymentGatewayUserId=None, deferredSettlement=None, deferredSettlementTimeout=None, deferredSettlementTimeoutAction=None,
        offerAttr=None, dupAttr=True, dateOffset=None, glCenter=None, name=None, noTouch=False, devOid=None, devQueryType = 'PhoneNumber',
        routingType=None, routingValue=None, preActiveState=None, autoActivationTime=None, autoActivationRelativeOffsetUnit=None,
        autoActivationRelativeOffset=None, autoActivationCycleResourceId=None, activationExpirationTime=None,
        activationExpirationRelativeOffsetUnit=None, activationExpirationRelativeOffset=None, endTimeRelativeOffset=None,
        endTimeRelativeOffsetUnit=None, offerCycleType=None, offerCycleOffset=None, offerCycleStartTime=None, isRecurringFailureAllowed=None,
        subApiEventData=None, devApiEventData=None, offerApiEventData=None, parameterList=None, offerStatusValue=None,
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        isPendingActivationAllowed=None, offerLifecycleProfileId=None,
        paymentDueDate=None, chargePurchaseProrationType=None, grantPurchaseProrationType=None, reason=None, info=None, eligibilityCheck=True, geoData=None):

    time.sleep(0.006)
    #RESTHELPER.saveResultsIntoMainDriver(externalId, deviceId)

    if now is None:
        now=offerStartTime

    #check if we passed a string for billingCycle and convert it to a billing cycle template
    if billingCycle:
        if type(billingCycle) is not data_container.DataContainer:
            billingCycle = createBillingCycleData(int(billingCycle), startTime=now,dateOffset=dateOffset)

    if type(contactPushTokenList) is list:
          contactPushTokenList1=[]
          contactPushTokenList1 = contactPushTokenList         
    else:
          contactPushTokenList1 = None
    
    # Issue subscriber create command.  Validate response
    (retValue, oid) = createSubscriber(V3inst = V3inst, externalId = externalId, now = now,
        payload = payload, billingCycle = billingCycle, eventPass = eventPass, firstName = firstName,
        lastName = lastName, contactEmail = contactEmail, contactPhoneNumber = contactPhoneNumber,
         contactPushTokenList=contactPushTokenList1,
        notificationPreference = notificationPreference, timeZone = timeZone, 
        attr = subAttr, apiEventData=subApiEventData, status = subStatus, taxStatus=taxStatus, taxCertificate=taxCertificate, 
        customerType=customerType, serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId, exemptionCodeList=exemptionCodeList,
        taxLocation=taxLocation, language = language, dupAttr=True, glCenter=glCenter, name=name, routingType=routingType, routingValue=routingValue) 

    # create a new device if a deviceId is provided
    if deviceId is not None:
        # Add device to the subscriber if one was specified.
        (retCode, deviceOid) = addDeviceToSubscriber(V3inst, oid, deviceId, deviceType, accessNumbers = accessNumbers, tenantId=tenantId,
            subQueryType = 'ObjectId', devQueryType = devQueryType, eventPass = eventPass, attr=devAttr, apiEventData=devApiEventData,
            status=devStatus, now=now, noTouch=noTouch, devOid=devOid, routingType=routingType, routingValue=routingValue)
        if not retCode:
            return (failed(eventPass), oid)

    if offerId != 0 or catalogItemId:
        if not subscribeToOffer(V3inst = V3inst, externalId = oid, offerId = offerId, catalogItemId=catalogItemId,
                offerStartTime = offerStartTime, offerEndTime = offerEndTime, eventPass = eventPass,
                queryType = 'ObjectId', now=now, offerIsExternal=offerIsExternal, attr=offerAttr,
                chargeMethod=chargeMethod, paymentMethodResourceId=paymentMethodResourceId, paymentGatewayId=paymentGatewayId,
                paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, preActiveState=preActiveState,
                paymentGatewayUserId=paymentGatewayUserId, apiEventData=offerApiEventData,
                deferredSettlement=deferredSettlement, deferredSettlementTimeout=deferredSettlementTimeout,
                deferredSettlementTimeoutAction=deferredSettlementTimeoutAction, autoActivationTime=autoActivationTime,
                autoActivationRelativeOffsetUnit=autoActivationRelativeOffsetUnit, autoActivationRelativeOffset=autoActivationRelativeOffset,
                autoActivationCycleResourceId=autoActivationCycleResourceId, activationExpirationTime=activationExpirationTime,
                activationExpirationRelativeOffsetUnit=activationExpirationRelativeOffsetUnit,
                activationExpirationRelativeOffset=activationExpirationRelativeOffset, endTimeRelativeOffset=endTimeRelativeOffset,
                endTimeRelativeOffsetUnit=endTimeRelativeOffsetUnit, parameterList=parameterList, offerStatusValue=offerStatusValue,
                offerCycleType=offerCycleType, offerCycleOffset=offerCycleOffset, offerCycleStartTime=offerCycleStartTime,
                isRecurringFailureAllowed=isRecurringFailureAllowed, chargePurchaseProrationType=chargePurchaseProrationType,
                isPendingActivationAllowed=isPendingActivationAllowed, offerLifecycleProfileId=offerLifecycleProfileId,
                routingType=routingType, routingValue=routingValue, paymentDueDate=paymentDueDate, grantPurchaseProrationType=grantPurchaseProrationType,
                reason=reason, info=info, eligibilityCheck=eligibilityCheck, geoData=geoData):
            return (failed(eventPass), oid)

    return (passed(eventPass), oid)

#====================================================
#note externalId should be queryValue.
def subscribeToOffer(V3inst, externalId=None, offerId=None, catalogItemId=None, offerStartTime=None,
        offerEndTime=None, eventPass=True, queryType='ExternalId', now=None, offerIsExternal=False,
        offerId2=None, attr=None, dupAttr=True, future=False, purchaseInfo=False, executeMode=None, 
        chargeMethod=None, paymentMethodResourceId=None, paymentGatewayId=None, paymentGatewayOneTimeToken=None,
        paymentDueDate=None, deferredSettlement=None, deferredSettlementTimeout=None, deferredSettlementTimeoutAction=None,
        paymentGatewayUserId=None, offerCycleType=None, offerCycleResourceId=None, offerCycleOffset=None, offerCycleStartTime=None, 
        preActiveState=None, autoActivationTime=None, autoActivationRelativeOffsetUnit=None, autoActivationRelativeOffset=None,
        autoActivationCycleResourceId=None, activationExpirationTime=None, activationExpirationRelativeOffsetUnit=None,
        activationExpirationRelativeOffset=None, endTimeRelativeOffsetUnit=None, endTimeRelativeOffset=None,
        downPayment=None, chargeMethodAttr=None, isTargetResource=None, useTargetResource=None, offerStatusValue=None,
        isRecurringFailureAllowed=None, chargePurchaseProrationType=None, grantPurchaseProrationType=None, reason=None, info=None, eligibilityCheck=True,
        contractPeriod=None, contractInterval=None, commitmentPeriod=None, commitmentPeriodInterval=None, isOpenContract=None,
        isPendingActivationAllowed=None, offerLifecycleProfileId=None,
        routingType=None, routingValue=None, parameterList=None, apiEventData=None, multiRequestBuild=None, etcScheduleRangeArray=None,
        etcScheduleRangeUnit=None, paymentScheduleRangeArray=None, paymentScheduleAmountArray=None, paymentScheduleLastAmount=None, delayCharge=None, geoData=None, endAfterCycleCount=None, noEndTime=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    if now is None:
        now = offerStartTime

    if parameterList is None:
        parameterList = []

    offerList = []
    if catalogItemId:
        offerId=catalogItemId

    offerList = prepOfferAttr(offerId, offerIsExternal=offerIsExternal, offerStartTime=offerStartTime, 
                          offerEndTime=offerEndTime, attr=attr, offerList=offerList, offerId2=offerId2, dupAttr=dupAttr,
                          catalogItemId=catalogItemId, offerCycleType=offerCycleType, offerCycleResourceId=offerCycleResourceId,
                          offerCycleOffset=offerCycleOffset, offerCycleStartTime=offerCycleStartTime, preActiveState=preActiveState,
                          autoActivationTime=autoActivationTime, autoActivationRelativeOffsetUnit=autoActivationRelativeOffsetUnit,
                          autoActivationRelativeOffset=autoActivationRelativeOffset, autoActivationCycleResourceId=autoActivationCycleResourceId,
                          activationExpirationTime=activationExpirationTime,activationExpirationRelativeOffsetUnit=activationExpirationRelativeOffsetUnit,
                          activationExpirationRelativeOffset=activationExpirationRelativeOffset, endTimeRelativeOffsetUnit=endTimeRelativeOffsetUnit,
                          endTimeRelativeOffset=endTimeRelativeOffset, downPayment=downPayment, isRecurringFailureAllowed=isRecurringFailureAllowed,
                          isTargetResource=isTargetResource, useTargetResource=useTargetResource, chargePurchaseProrationType=chargePurchaseProrationType,
                          grantPurchaseProrationType=grantPurchaseProrationType, reason=reason, info=info, offerStatusValue=offerStatusValue,
                          parameterList=parameterList, etcScheduleRangeArray=etcScheduleRangeArray, etcScheduleRangeUnit=etcScheduleRangeUnit,
                          paymentDueDate=paymentDueDate, paymentScheduleRangeArray=paymentScheduleRangeArray,
                          isPendingActivationAllowed=isPendingActivationAllowed, offerLifecycleProfileId=offerLifecycleProfileId,
                          paymentScheduleAmountArray=paymentScheduleAmountArray, paymentScheduleLastAmount=paymentScheduleLastAmount, delayCharge=delayCharge, geoData=geoData, endAfterCycleCount=endAfterCycleCount, noEndTime=noEndTime)

    #print( "offerListofferList=", offerList)

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=externalId,offerList=offerList,now=now'

    # Build the command of additional parameters.
    nonce=paymentGatewayOneTimeToken
    for item in ['chargeMethod', 'paymentMethodResourceId', 'paymentGatewayId', 'nonce', 'chargeMethodAttr', \
                 'deferredSettlement', 'deferredSettlementTimeout', 'deferredSettlementTimeoutAction', \
                 'paymentGatewayUserId', 'eligibilityCheck', 'apiEventData','geoData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    apiName = 'subscriberPurchaseOffer'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.'            + apiName + '(' + paramString + ')'
    #print(apiName + ': cmd = ' + cmd)
    responseMdc = eval(cmd)
    #print 'responseMdc = ' + str(responseMdc)
    
    # If a multi request then return the payload
    if multiRequestBuild:       return 0,responseMdc
    
    #print "response:", responseMdc
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        if purchaseInfo :
          return (COMMON.debugFailure(method='subscribeToOffer', status=retCode, msg=retText, shouldPass=eventPass), responseMdc)
        else:
          return(COMMON.debugFailure(method='subscribeToOffer', status=retCode, msg=retText, shouldPass=eventPass), None)
        #return(COMMON.debugFailure(method='subscribeToOffer', status=retCode, msg=retText, shouldPass=eventPass), None)

    # Get the array of created resources from the response.
    createResourceIds = responseMdc.getUsingKey(MDCDEFS.kMtxResponseAddResourceIdArrayFldKey)

    #return all purchase information if purchseInfo is true
    if purchaseInfo :
       return (COMMON.debugSuccess(method='subscribeToOffer', shouldPass=eventPass), responseMdc)
    else:
       return (COMMON.debugSuccess(method='subscribeToOffer', shouldPass=eventPass), createResourceIds)



#============================================================
# params are offerId is either offer id or externatId.  offerId2 is when we want to use both 
#the offerId and externalId.
#dupAttr is set when we want to purchase manyoffers and all have the same attr
#============================================================
def prepOfferAttr(offerId, offerIsExternal=False, offerStartTime=None, offerEndTime=None, 
                 attr=None, offerList=[], offerId2=None, dupAttr=True, catalogItemId=None, offerCycleType=None, offerCycleResourceId=None,
                 offerCycleOffset=None, offerCycleStartTime=None, preActiveState=None, autoActivationTime=None, autoActivationRelativeOffsetUnit=None,
                 autoActivationRelativeOffset=None, autoActivationCycleResourceId=None,
                 activationExpirationTime=None, activationExpirationRelativeOffsetUnit=None,
                 activationExpirationRelativeOffset=None, endTimeRelativeOffset=None, endTimeRelativeOffsetUnit=None, downPayment=None,
                 isRecurringFailureAllowed=None, isTargetResource=None, useTargetResource=None,
                 chargePurchaseProrationType=None, grantPurchaseProrationType=None, reason=None, info=None, offerStatusValue=None,
                 contractPeriod=None, contractInterval=None, commitmentPeriod=None, commitmentPeriodInterval=None, isOpenContract=None,
                 etcScheduleRangeArray=None, parameterList=None, etcScheduleRangeUnit=None, paymentDueDate=None, paymentScheduleRangeArray=None,
                 paymentScheduleAmountArray=None, paymentScheduleLastAmount=None, delayCharge=None, geoData=None,
                 isPendingActivationAllowed=None, offerLifecycleProfileId=None, endAfterCycleCount=None, noEndTime=None):
    
    i = 0
    #Check if off is not a list and convert it to a list
    if type(offerId) is not list:
        offerL = [offerId]
    else:
        offerL = offerId

    #check if we have attr or need to duplicate one
    attrArr = attr
    if attr: 
        if type(attr) is not list and dupAttr:  #dont dup in case we forgot to unset dupAttr
            attrArr = []
            while i < len(offerL):
                attrArr.append(attr)
                i += 1

        
    if catalogItemId:
        purchaseType = 'CatalogItemId'
    else:
        purchaseType = 'ProductOfferId'

    # Set offer cycle type to be offer if useTargetResource is set
    if useTargetResource in ['1', True]: offerCycleType='4'

    i = 0
    #Create offer list
    attVal = attrArr
    for offer in offerL:
        if type(attrArr) is list:
            if i >= len(attrArr):  attVal = None  #maybe we did not input all Attr for all offers
            else : attVal = attrArr[i]

        if offerIsExternal and offerId2!= None:
            offerList.append({purchaseType:offerId2, 'ExternalId':offer, 'StartTime':offerStartTime,'EndTime':offerEndTime, 'Attr':attVal,
                               'CycleType':offerCycleType, 'CycleResourceId':offerCycleResourceId, 'CycleOffset':offerCycleOffset,
                               'CycleStartTime':offerCycleStartTime, 'PreActiveState':preActiveState, 'AutoActivationTime':autoActivationTime,
                               'AutoActivationRelativeOffsetUnit':autoActivationRelativeOffsetUnit, 'AutoActivationRelativeOffset':autoActivationRelativeOffset,
                               'AutoActivationCycleResourceId':autoActivationCycleResourceId, 'ActivationExpirationTime':activationExpirationTime,
                               'ActivationExpirationRelativeOffsetUnit':activationExpirationRelativeOffsetUnit, 'ActivationExpirationRelativeOffset':activationExpirationRelativeOffset,
                               'EndTimeRelativeOffset':endTimeRelativeOffset, 'EndTimeRelativeOffsetUnit':endTimeRelativeOffsetUnit, 'DownPayment':downPayment,
                               'ParameterList':parameterList, 'OfferStatusValue':offerStatusValue,
                               'IsPendingActivationAllowed':isPendingActivationAllowed, 'OfferLifecycleProfileId':offerLifecycleProfileId,
                               'IsRecurringFailureAllowed':isRecurringFailureAllowed, 'IsTargetResource':isTargetResource, 'UseTargetResource':useTargetResource})
                               
        elif offerIsExternal:
            offerList.append({'ExternalId':offer, 'StartTime':offerStartTime, 'EndTime':offerEndTime, 'Attr':attVal,
                               'CycleType':offerCycleType, 'CycleResourceId':offerCycleResourceId, 'CycleOffset':offerCycleOffset,
                               'CycleStartTime':offerCycleStartTime, 'PreActiveState':preActiveState, 'AutoActivationTime':autoActivationTime,
                               'AutoActivationRelativeOffsetUnit':autoActivationRelativeOffsetUnit, 'AutoActivationRelativeOffset':autoActivationRelativeOffset,
                               'AutoActivationCycleResourceId':autoActivationCycleResourceId, 'ActivationExpirationTime':activationExpirationTime,
                               'ActivationExpirationRelativeOffsetUnit':activationExpirationRelativeOffsetUnit, 'ActivationExpirationRelativeOffset':activationExpirationRelativeOffset,
                               'EndTimeRelativeOffset':endTimeRelativeOffset, 'EndTimeRelativeOffsetUnit':endTimeRelativeOffsetUnit, 'DownPayment':downPayment,
                               'ParameterList':parameterList, 'OfferStatusValue':offerStatusValue,
                               'IsPendingActivationAllowed':isPendingActivationAllowed, 'OfferLifecycleProfileId':offerLifecycleProfileId,
                               'IsRecurringFailureAllowed':isRecurringFailureAllowed, 'IsTargetResource':isTargetResource, 'UseTargetResource':useTargetResource})
        else:
            offerList.append({purchaseType:offer, 'StartTime':offerStartTime, 'EndTime':offerEndTime, 'Attr':attVal,
                               'CycleType':offerCycleType, 'CycleResourceId':offerCycleResourceId, 'CycleOffset':offerCycleOffset,
                               'CycleStartTime':offerCycleStartTime, 'PreActiveState':preActiveState, 'AutoActivationTime':autoActivationTime,
                               'AutoActivationRelativeOffsetUnit':autoActivationRelativeOffsetUnit, 'AutoActivationRelativeOffset':autoActivationRelativeOffset,
                               'AutoActivationCycleResourceId':autoActivationCycleResourceId, 'ActivationExpirationTime':activationExpirationTime,
                               'ActivationExpirationRelativeOffsetUnit':activationExpirationRelativeOffsetUnit, 'ActivationExpirationRelativeOffset':activationExpirationRelativeOffset,
                               'EndTimeRelativeOffset':endTimeRelativeOffset, 'EndTimeRelativeOffsetUnit':endTimeRelativeOffsetUnit, 'DownPayment':downPayment,
                               'IsPendingActivationAllowed':isPendingActivationAllowed, 'OfferLifecycleProfileId':offerLifecycleProfileId,
                               'ParameterList':parameterList, 'OfferStatusValue':offerStatusValue,
                               'IsRecurringFailureAllowed':isRecurringFailureAllowed, 'IsTargetResource':isTargetResource, 'UseTargetResource':useTargetResource, 'EndAfterCycleCount':endAfterCycleCount, 'NoEndTime': noEndTime})

        if etcScheduleRangeUnit or etcScheduleRangeArray or paymentScheduleRangeArray or paymentScheduleAmountArray or paymentScheduleLastAmount or delayCharge or contractPeriod or contractInterval or commitmentPeriod or commitmentPeriodInterval or isOpenContract:
            ContractParameterOverrideData = {'EtcScheduleRangeUnit':etcScheduleRangeUnit, 'EtcScheduleRangeArray':etcScheduleRangeArray, 'PaymentScheduleRangeArray':paymentScheduleRangeArray, 'PaymentScheduleAmountArray':paymentScheduleAmountArray, 'PaymentScheduleLastAmount':paymentScheduleLastAmount, 'DelayCharge':delayCharge, 'ContractPeriod':contractPeriod, 'ContractInterval':contractInterval, 'CommitmentPeriod':commitmentPeriod, 'CommitmentPeriodInterval':commitmentPeriodInterval, 'IsOpenContract':isOpenContract}
            #print ContractParameterOverrideData
            offerList[i].update({'ContractParameterOverrideData':ContractParameterOverrideData})

        if type(chargePurchaseProrationType) is list:
            offerList[i].update({'ChargePurchaseProrationType':chargePurchaseProrationType[i], 'GrantPurchaseProrationType':grantPurchaseProrationType[i], 'Reason':reason[i], 'Info':info[i]})
        else:
            offerList[i].update({'ChargePurchaseProrationType':chargePurchaseProrationType, 'GrantPurchaseProrationType':grantPurchaseProrationType, 'Reason':reason, 'Info':info})
 
        if type(paymentDueDate) is list:
            offerList[i].update({'PaymentDueDate':paymentDueDate[i]})
        else:
            offerList[i].update({'PaymentDueDate':paymentDueDate})

        
        i += 1

    return offerList

#=========================================================================================================
def unsubscribeFromOffer(V3inst, subscriberId, resourceId=0, endTime=None, eventPass=True,
        queryType='ExternalId', cancelInfo=False, executeMode=None, eligibilityCheck=True, apiEventData=None, multiRequestBuild=None):
    resourceList = []
    
    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

     
    # Build list of resurces.  Allow for error testing (so passeding in nothing will not set any items in the list)
    if type(resourceId) is list:
        for resource in resourceId:
            resourceList.append(resource)
    elif resourceId != 0:
        resourceList.append(resourceId)

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=subscriberId,resourceIdList=resourceList, now=endTime'

    # Build the command of additional parameters.
    for item in ['eligibilityCheck']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    apiName = 'subscriberCancelOffer'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.'            + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)
    #print 'responseMdc = ' + str(responseMdc)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        if cancelInfo :
          return (COMMON.debugFailure(method='unsubscribeFromOffer',status=retCode, msg=retText, shouldPass=eventPass), responseMdc)
        else:
          return COMMON.debugFailure(method='unsubscribeFromOffer', status=retCode, msg=retText, shouldPass=eventPass)

    if cancelInfo :
        return (COMMON.debugSuccess(method='unsubscribeFromOffer', shouldPass=eventPass), responseMdc)
    else:
        return COMMON.debugSuccess(method='unsubscribeFromOffer', shouldPass=eventPass)

#=============================================================
def subscriberCancelOffer(V3inst, queryValue, resourceId=0, cancelType=None, grantCancelProrationType=None, chargeCancelProrationType=None,
        reason=None, info=None, cancelOfferDataList='', now=None, queryType='ExternalId', cancelInfo=False, eventPass=True, executeMode=None,
        apiEventData=None, contractCancelMode=None, debtCancellationMode=None, multiRequestBuild=None, isWaiveEarlyTerminationCharge=None, eligibilityCheck=True):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    if type(resourceId) is not list:
        resourceId = [resourceId]

    if cancelOfferDataList:
        resourceIdList=None
    elif cancelType or grantCancelProrationType or chargeCancelProrationType or reason or info or contractCancelMode or debtCancellationMode:
        cancelOfferDataList = []
        resourceIdList=None
        for id in resourceId:
            cancelOfferData = {"ResourceId": id, "CancelType": cancelType, "GrantCancelProrationType": grantCancelProrationType, 
                                  "ChargeCancelProrationType": chargeCancelProrationType, "Reason": reason, "Info": info, "ContractCancelMode": contractCancelMode, "DebtCancellationMode": debtCancellationMode, "IsWaiveEarlyTerminationCharge": isWaiveEarlyTerminationCharge}
            cancelOfferDataList.append(cancelOfferData)
            #print cancelOfferDataList
    else:
        resourceIdList=resourceId
        cancelOfferDataList=None


    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue,resourceIdList=resourceIdList, now=now'

    # Build the command of additional parameters.
    for item in ['cancelOfferDataList', 'eligibilityCheck', 'apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    apiName = 'subscriberCancelOffer'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.'            + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)
    #print 'responseMdc = ' + str(responseMdc)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        if cancelInfo :
          return (COMMON.debugFailure(method='subscriberCancelOffer',status=retCode, msg=retText, shouldPass=eventPass), responseMdc)
        else:
          return COMMON.debugFailure(method='subscriberCancelOffer', status=retCode, msg=retText, shouldPass=eventPass)


    if cancelInfo :
        return (COMMON.debugSuccess(method='subscriberCancelOffer', shouldPass=eventPass), responseMdc)
    else:
        return COMMON.debugSuccess(method='subscriberCancelOffer', shouldPass=eventPass)

#=============================================================
def addSubscriberThreshold(V3inst, queryValue, thresholdId, resourceId, threshName, val, notify, eventPass=True,
        now=None, queryType='ExternalId', recurringStart = None, recurringStop = None, virtualCreditLimitIsPercent=0,
        rechargeAmount=None, rechargePaymentMethodResourceId=None, isTemporaryCreditLimit=None,
        apiEventData=None, multiRequestBuild=None):

    # Get function name
    fname = sys._getframe().f_code.co_name
    
    # Allow function to be called directoy from the command line
    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    if notify:
        thresholdNotification = 1
    else:
        thresholdNotification = 0

    if resourceId is None:
        walletMdc = V3inst.subscriberQueryWallet(queryType=queryType, queryValue=queryValue, now=now)
        resourceId = COMMON.getResourceId(walletMdc, thresholdId)
        if resourceId is None:
            return COMMON.debugFailure(method='addSubscriberThreshold', status=1, msg='ThresholdId not found')

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, thresholdId=thresholdId, \
                resourceId=resourceId, thresholdAmount=val, thresholdName=threshName,   \
                thresholdNotification=thresholdNotification, now=now, recurringStart = recurringStart, recurringStop = recurringStop'
        
    # Build the command of additional parameters.
    for item in ['virtualCreditLimitIsPercent', 'rechargeAmount', 'rechargePaymentMethodResourceId', 'isTemporaryCreditLimit']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item
    
    # Execute the call
    cmd = 'V3inst.subscriberAddThreshold(' + paramString + ')'
    #print 'subscriberAddThreshold: cmd = ' + cmd
    responseMdc = eval(cmd)
    
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method=fname, status=retCode, msg=retText, shouldPass=eventPass)
    
    return COMMON.debugSuccess(method=fname, shouldPass=eventPass)

#=============================================================
def removeSubscriberThreshold(V3inst, subscriberId, indexId, thresholdId, queryType='ExternalId', eventPass=True,
        now=None, removeThresholdOnly=None, removeRechargeDataOnly=None, isTemporaryCreditLimit=None,
        apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=subscriberId, thresholdId=thresholdId, \
                resourceId=indexId, now=now'

    # Build the command of additional parameters.
    for item in ['removeThresholdOnly', 'removeRechargeDataOnly', 'isTemporaryCreditLimit']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.subscriberRemoveThreshold(' + paramString + ')'
    #print 'groupAddThreshold: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='removeSubscriberThreshold', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='removeSubscriberThreshold', shouldPass=eventPass)

#=============================================================
def querySubscriberThresholdRechargeDefn(V3inst, queryValue, queryType='ExternalId', balanceResourceId=None, now=None, eventPass=True, multiRequestBuild=None):

    responseMdc = V3inst.subscriberQueryThresholdRechargeDefn(queryType=queryType, queryValue=queryValue, balanceResourceId=balanceResourceId,
        now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='querySubscriberThresholdRechargeDefn', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='querySubscriberThresholdRechargeDefn', shouldPass=eventPass):
        return responseMdc

#=============================================================
def addSubscriberBalance(V3inst, subscriberId, balanceList, now=None, queryType='ExternalId', eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.subscriberAddBalance(queryType=queryType, queryValue=subscriberId, balanceList=balanceList,
        now=now)
    
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='addSubscriberBalance', status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method='addSubscriberBalance', shouldPass=eventPass)

#========================================================
def createSubscriberBillingProfile(V3inst, subscriberId, profileId, startTime=None, dateOffset=None,
        queryType='ExternalId', eventPass=True, now=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    billCycleMdc = createBillingCycleData(templateId=profileId, dateOffset=dateOffset, startTime=startTime)

    responseMdc = V3inst.subscriberModify(queryType=queryType, queryValue=subscriberId,
        billingCycle=billCycleMdc, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='addSubscriberBillingProfile', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='addSubscriberBillingProfile', shouldPass=eventPass)

#========================================================
def createGroupBillingProfile(V3inst, groupId, profileId, startTime=None, dateOffset=0,
        queryType='ExternalId', eventPass=True, now=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    billCycleMdc = createBillingCycleData(templateId=profileId, dateOffset=dateOffset, startTime=startTime)
    responseMdc = V3inst.groupModify(queryType=queryType, queryValue=groupId, billingCycle=billCycleMdc, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='addGroupBillingProfile', status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method='addGroupBillingProfile', shouldPass=eventPass)

#========================================================
def getGatewayAuthorizationToken(V3inst, paymentGatewayUserId=None, paymentGatewayId=0, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.sysCreateClientToken(paymentGatewayUserId=paymentGatewayUserId,
        paymentGatewayId=paymentGatewayId)

    if not REST.checkResultSuccess(responseMdc):
         (retCode, retText) = REST.getResultStatus(responseMdc)
         return COMMON.debugFailure(method='getGatewayAuthorizationToken', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='getGatewayAuthorizationToken', shouldPass=eventPass):
         return responseMdc

#========================================================
def subscriberCreatePaymentOneTimeToken(V3inst, queryValue, queryType='ExternalId', paymentMethodResourceId=None, paymentAttr=None,
        eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.subscriberCreatePaymentOneTimeToken(queryValue=queryValue, queryType=queryType,
        paymentMethodResourceId=paymentMethodResourceId, paymentAttr=paymentAttr)

    if not REST.checkResultSuccess(responseMdc):
         (retCode, retText) = REST.getResultStatus(responseMdc)
         return COMMON.debugFailure(method='subscriberCreatePaymentOneTimeToken', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='subscriberCreatePaymentOneTimeToken', shouldPass=eventPass):
         return responseMdc

#Requires Braintree
#========================================================
def subscriberAddPaymentMethod(V3inst, queryValue, paymentGatewayUserId=None, paymentGatewayOneTimeToken=None, paymentGatewayId=0,
        paymentType=None, name=None, isDefault=True, isSysDefault=None, queryType='ExternalId', paymentAttr=None, now=None, eventPass=True, 
        executeMode=None, apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, paymentGatewayUserId=paymentGatewayUserId, \
                   nonce=paymentGatewayOneTimeToken, paymentGatewayId=paymentGatewayId, paymentType=paymentType, \
                   name=name, isDefault=isDefault, now=now, paymentAttr=paymentAttr'

    for item in ['isSysDefault']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.subscriberAddPaymentMethod(' + paramString + ')'
    #print 'isubscriberAddPaymentMethod: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberAddPaymentMethod', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='subscriberAddPaymentMethod', shouldPass=eventPass)

#========================================================
def subscriberModifyPaymentMethod(V3inst, queryValue, resourceId=None, paymentGatewayUserId=None, paymentType=None, name=None,
        isDefault=None, isSysDefault=None, paymentGatewayOneTimeToken=None, queryType='ExternalId', paymentAttr=None, now=None,
        eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, resourceId=resourceId, paymentGatewayUserId=paymentGatewayUserId, \
                   paymentType=paymentType, name=name, isDefault=isDefault, paymentAttr=paymentAttr, now=now' 

    for item in ['isSysDefault', 'paymentGatewayOneTimeToken']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.subscriberModifyPaymentMethod(' + paramString + ')'
    #print 'subscriberModifyPaymentMethod: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberModifyPaymentMethod', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='subscriberModifyPaymentMethod', shouldPass=eventPass)

#========================================================
def subscriberValidatePaymentMethod(V3inst, queryValue, queryType='ExternalId', resourceId=None, postalCode=None,
        now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.subscriberValidatePaymentMethod(queryValue=queryValue, queryType=queryType,
        resourceId=resourceId, postalCode=postalCode)

    if not REST.checkResultSuccess(responseMdc):
         (retCode, retText) = REST.getResultStatus(responseMdc)
         return COMMON.debugFailure(method='subscriberValidatePaymentMethod', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='subscriberValidatePaymentMethod', shouldPass=eventPass):
         return responseMdc

#========================================================
def subscriberQueryPaymentMethod(V3inst, queryValue, paymentGatewayId=None, returnDefault=None, queryType='ObjectId', now=None,
        returnSysDefault=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()
    
    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, paymentGatewayId=paymentGatewayId, returnDefault=returnDefault, \
                   now=now'

    for item in ['returnSysDefault']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.subscriberQueryPaymentMethod(' + paramString + ')'
    #print 'subscriberQueryPaymentMethod: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
         (retCode, retText) = REST.getResultStatus(responseMdc)
         return COMMON.debugFailure(method='subscriberQueryPaymentMethod', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='subscriberQueryPaymentMethod', shouldPass=eventPass):
         return responseMdc

#========================================================
def subscriberRemovePaymentMethod(V3inst, queryValue, resourceId=None, queryType='ObjectId', now=None, eventPass=True,
        apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.subscriberRemovePaymentMethod(queryType=queryType, queryValue=queryValue, resourceId=resourceId,
        now=None)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberRemovePaymentMethod', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='subscriberRemovePaymentMethod', shouldPass=eventPass)

#========================================================
def groupCreatePaymentOneTimeToken(V3inst, queryValue, queryType='ExternalId', paymentMethodResourceId=None, paymentAttr=None,
        eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.groupCreatePaymentOneTimeToken(queryValue=queryValue, queryType=queryType,
        paymentMethodResourceId=paymentMethodResourceId, paymentAttr=paymentAttr)

    if not REST.checkResultSuccess(responseMdc):
         (retCode, retText) = REST.getResultStatus(responseMdc)
         return COMMON.debugFailure(method='groupCreatePaymentOneTimeToken', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='groupCreatePaymentOneTimeToken', shouldPass=eventPass):
         return responseMdc

#Requires Braintree
#========================================================
def groupAddPaymentMethod(V3inst, queryValue, paymentGatewayUserId=None, paymentGatewayOneTimeToken=None, paymentGatewayId=0,
        paymentType=None, name=None, isDefault=True, isSysDefault=None, queryType='ExternalId', paymentAttr=None, now=None,
        eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, paymentGatewayUserId=paymentGatewayUserId, \
                   nonce=paymentGatewayOneTimeToken, paymentGatewayId=paymentGatewayId, paymentType=paymentType, \
                   name=name, isDefault=isDefault, now=now, paymentAttr=paymentAttr'

    for item in ['isSysDefault']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.groupAddPaymentMethod(' + paramString + ')'
    #print 'groupAddPaymentMethod: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupAddPaymentMethod', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='groupAddPaymentMethod', shouldPass=eventPass)

#========================================================
def groupModifyPaymentMethod(V3inst, queryValue, resourceId=None, paymentGatewayUserId=None, paymentType=None, name=None,
        isDefault=None, isSysDefault=None, queryType='ExternalId', paymentAttr=None, paymentGatewayOneTimeToken=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, resourceId=resourceId, paymentGatewayUserId=paymentGatewayUserId, \
                   paymentType=paymentType, name=name, isDefault=isDefault, paymentAttr=paymentAttr, now=now'

    for item in ['isSysDefault', 'paymentGatewayOneTimeToken']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.groupModifyPaymentMethod(' + paramString + ')'
    #print 'groupModifyPaymentMethod: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupModifyPaymentMethod', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='groupModifyPaymentMethod', shouldPass=eventPass)

#========================================================
def groupValidatePaymentMethod(V3inst, queryValue, queryType='ExternalId', resourceId=None, postalCode=None,
        now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.groupValidatePaymentMethod(queryValue=queryValue, queryType=queryType,
        resourceId=resourceId, postalCode=postalCode)

    if not REST.checkResultSuccess(responseMdc):
         (retCode, retText) = REST.getResultStatus(responseMdc)
         return COMMON.debugFailure(method='groupValidatePaymentMethod', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='groupValidatePaymentMethod', shouldPass=eventPass):
         return responseMdc

#========================================================
def groupQueryPaymentMethod(V3inst, queryValue, paymentGatewayId=None, returnDefault=None, returnSysDefault=None, queryType='ObjectId', now=None,

        eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, paymentGatewayId=paymentGatewayId, returnDefault=returnDefault, \
                   now=now'

    for item in ['returnSysDefault']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.groupQueryPaymentMethod(' + paramString + ')'
    #print 'groupQueryPaymentMethod: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
         (retCode, retText) = REST.getResultStatus(responseMdc)
         return COMMON.debugFailure(method='groupQueryPaymentMethod', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='groupQueryPaymentMethod', shouldPass=eventPass):
         return responseMdc

#========================================================
def groupRemovePaymentMethod(V3inst, queryValue, resourceId=None, queryType='ObjectId', now=None, eventPass=True,
        apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.groupRemovePaymentMethod(queryType=queryType, queryValue=queryValue, resourceId=resourceId,
        now=None)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupRemovePaymentMethod', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='groupRemovePaymentMethod', shouldPass=eventPass)

#========================================================
def subscriberPayment(V3inst, queryValue, amount, payNow=None, queryType='ExternalId', paymentMethodResourceId=None,
        paymentGatewayId=None, paymentGatewayOneTimeToken=None, info=None, reason=None, chargeMethodAttr=None,
        paymentGatewayUserId=None, apiEventData=None, now=None, executeMode=None, eventPass=True, multiRequestBuild=None):

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, amount=amount, payNow=payNow, now=now'
    # Build the command of additional parameters.
    nonce=paymentGatewayOneTimeToken
    for item in ['paymentMethodResourceId', 'paymentGatewayId', 'nonce', 'chargeMethodAttr', 'info', 'reason', \
                 'paymentGatewayUserId', 'apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.subscriberPayment(' + paramString + ')'
    #print 'subscriberPayment: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
         (retCode, retText) = REST.getResultStatus(responseMdc)
         return COMMON.debugFailure(method='subscriberPayment', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='subscriberPayment', shouldPass=eventPass):
         return responseMdc

#========================================================
def groupPayment(V3inst, queryValue, amount, payNow=None, queryType='ExternalId', paymentMethodResourceId=None,
        paymentGatewayId=None, paymentGatewayOneTimeToken=None, info=None, reason=None, chargeMethodAttr=None,
        paymentGatewayUserId=None, apiEventData=None, now=None, executeMode=None, eventPass=True, multiRequestBuild=None):

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, amount=amount, payNow=payNow, now=now'
    # Build the command of additional parameters.
    nonce=paymentGatewayOneTimeToken
    for item in ['paymentMethodResourceId', 'paymentGatewayId', 'nonce', 'chargeMethodAttr', 'info', 'reason', \
                 'paymentGatewayUserId', 'apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.groupPayment(' + paramString + ')'
    #print 'groupPayment: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
         (retCode, retText) = REST.getResultStatus(responseMdc)
         return COMMON.debugFailure(method='groupPayment', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='groupPayment', shouldPass=eventPass):
         return responseMdc

#========================================================
def subscriberSettlePayment(V3inst, queryValue, queryType='ExternalId', resourceId=None, eventPass=True, now=None,
        apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.subscriberSettlePayment(queryType=queryType, queryValue=queryValue, resourceId=resourceId, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberSettlePayment', status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method='subscriberSettlePayment', shouldPass=eventPass)

#========================================================
def groupSettlePayment(V3inst, queryValue, queryType='ExternalId', resourceId=None, eventPass=True, now=None,
        apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.groupSettlePayment(queryType=queryType, queryValue=queryValue, resourceId=resourceId, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupSettlePayment', status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method='groupSettlePayment', shouldPass=eventPass)

#python -c 'import mdcV3;mdcV3.modifySubscriber(None,queryValue='5550009368',firstName="lia")'
# python -c 'import mdcV3;mdcV3.modifySubscriber(None,queryValue='5550009368',billingCycle=4012, dateOffset=10)'
def modifySubscriber(V3inst, queryValue, payload=None, eventPass=True, queryType='ExternalId', now=None,
        firstName=None, lastName=None, contactEmail=None, contactPhoneNumber=None, contactPushTokenList=None, notificationPreference=None,
        timeZone=None, attr=None, billingCycle=None, status=None, taxStatus=None, taxCertificate=None, taxLocation=None, language=None,
        externalId=None, dateOffset=None, glCenter=None, name=None, paymentGatewayUserId=None, currentPaymentTokenResourceId=None,
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        apiEventData=None, lastActivityUpdateTime=None, billingCycleDisabled=None, multiRequestBuild=None):

    # Get function name
    fname = sys._getframe().f_code.co_name
    
    # Allow function to be called directoy from the command line
    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    #if notificaiton preference defined in ~common/config.ini is not None,
    #override the default notficationPreference None value
    #subPrefConfig = QAUTILS.gatewaysConfig.get('NOTIFICATIONPREFERENCE','suscriberPreference')
    #print subPrefConfig
    #if subPrefConfig and notificationPreference is None:
    #   notificationPreference = subPrefConfig

    if payload:
        firstName = payload['firstName'] 
        lastName = payload['lastName']
        contactEmail = payload['contactEmail']
        contactPhoneNumber = payload['contactPhoneNumber']
        timeZone = payload['timeZone']
        attr = payload['attr']
        notificationPreference = payload['notificationPreference']

    #check if we passed a string for billingCycle and convert it to a billing cycle template
    if billingCycle:
        if type(billingCycle) is not data_container.DataContainer:
            billingCycle = createBillingCycleData(int(billingCycle), startTime=now, dateOffset=dateOffset)

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, now=now, \
                firstName=firstName, lastName=lastName, contactEmail=contactEmail, contactPhoneNumber=contactPhoneNumber,       \
                notificationPreference=notificationPreference, timeZone=timeZone, attr=attr, billingCycle=billingCycle,         \
                status=status, taxStatus=taxStatus, taxCertificate=taxCertificate, taxLocation=taxLocation, language=language, externalId=externalId'
        
    # Build the command of additional parameters.
    for item in ['glCenter', 'paymentGatewayUserId', 'currentPaymentTokenResourceId', 'lastActivityUpdateTime', \
                 'billingCycleDisabled','contactPushTokenList', 'name', 'apiEventData','customerType','serviceAddress','npa','nxx','tenantId','exemptionCodeList']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item
 
    # Execute the call
    cmd = 'V3inst.subscriberModify(' + paramString + ')'
    #print 'subscriberModify: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method=fname, status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method=fname, shouldPass=eventPass)

#=============================================================
def querySubscriber(V3inst, queryValue, queryType='ExternalId', eventPass=True, querySize=None, now=None, multiRequestBuild=None):

    #print "querySub:===== ", now
    responseMdc = V3inst.subscriberQuery(queryType=queryType, queryValue=queryValue, querySize=querySize, now=now)
    
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='querySubscriber', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='querySubscriber', shouldPass=eventPass):
        return responseMdc

#=============================================================
def querySubscriberCursor(V3inst, queryValue, queryType='ExternalId', eventPass=True, querySize=None, now=None, multiRequestBuild=None):

    responseMdc = V3inst.subscriberQuery(queryType=queryType, queryValue=queryValue, querySize=querySize, now=now)
    
    cursorDict = {}
    
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return (COMMON.debugFailure(method='querySubscriber', status=retCode, msg=retText, shouldPass=eventPass), cursorDict)

    # See if we got the expected response
    if COMMON.debugSuccess(method='querySubscriber', shouldPass=eventPass):
        # Get each cursor value
        for cursor in ['AdminGroupCursor', 'ParentGroupCursor']:
                try:
                        cmd="cursorDict['" + cursor + "'] = str(responseMdc.getUsingKey(MDCDEFS.kMtxResponseSubscriber" + cursor + "FldKey))"
                        exec(compile(cmd, '<string>', 'exec'))
                except:
                        cmd="cursorDict['" + cursor + "'] = '0'"
                        exec(compile(cmd, '<string>', 'exec'))
        
        #print 'querySubscriberCursor, dictionary = ' + str(cursorDict)
        
        return (responseMdc, cursorDict)

#=============================================================
def subscriberModifyOffer(V3inst, queryValue, queryType='ExternalId', resourceId=None, startTime=None, endTime=None, eventPass=True, attr=None,
    now=None, executeMode=None, cycleType=None, cycleResourceId=None, cycleOffset=None, cycleAlignmentDisabled=None, cycleStartTime=None, cycleEndTime=None, 
    apiEventData=None, immediateChange=None, isRecurringFailureAllowed=None, status=None, offerStatusValue=None, modifyInfo=False, parameterList=None, multiRequestBuild=None, endTimeExtensionOffset=None, endTimeExtensionOffsetUnit=None, endAfterCycleCount=None, noEndTime=None):
    
    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, resourceId=resourceId, \
                   startTime=startTime, endTime=endTime, attr=attr, now=now'

    # Build the command of additional parameters.
    for item in ['cycleType', 'cycleResourceId', 'cycleOffset', 'cycleAlignmentDisabled', 'cycleStartTime', 'cycleEndTime', \
                 'apiEventData', 'immediateChange', 'isRecurringFailureAllowed', 'status', 'offerStatusValue', 'parameterList', 'endTimeExtensionOffset', 'endTimeExtensionOffsetUnit', 'endAfterCycleCount', 'noEndTime']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.subscriberModifyOffer(' + paramString + ')'
    #print 'subscriberModifyOffer: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberModifyOffer', status=retCode, msg=retText, shouldPass=eventPass)

    if modifyInfo:
        return (COMMON.debugSuccess(method='subscriberModifyOffer', shouldPass=eventPass), responseMdc)
    elif COMMON.debugSuccess(method='subscriberModifyOffer', shouldPass=eventPass):
        return responseMdc

# Subscriber Modify Status
#========================================================
def subscriberModifyStatus(V3inst, queryValue=None, statusTransitionTime=None, statusValue=None, queryType='ExternalId', now=None,
                           apiEventData=None, executeMode=None, routingValue=None, routingType=None, multiRequestBuild=None, eventPass=True):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, statusTransitionTime=statusTransitionTime, \
                   statusValue=statusValue, now=now, apiEventData=apiEventData'

    # Execute the call
    cmd = 'V3inst.subscriberModifyStatus(' + paramString + ')'
    #print 'subscriberModifyStatus: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberModifyStatus', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='subscriberModifyStatus', shouldPass=eventPass)

# Subscriber Remove Scheduled Status Change
#=============================================================
def subscriberRemoveScheduledStatusChange(V3inst, queryValue=None, queryType='ExternalId', eventPass=True, now=None,
                               routingType=None, routingValue=None, apiEventData=None, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryValue=queryValue, queryType=queryType, now=now, apiEventData=apiEventData'

    # Execute the call
    apiName = 'subscriberRemoveScheduledStatusChange'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberRemoveScheduledStatusChange', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='subscriberRemoveScheduledStatusChange', shouldPass=eventPass)

# Subscriber Suspend Offer
#=============================================================
def subscriberSuspendOffer(V3inst, queryValue=None, resourceId=None, scheduledSuspendTime=None, queryType='ExternalId', now=None,
                   isPauseMode=None, autoResumeRelativeOffset=None, autoResumeRelativeOffsetUnit=None, autoResumeTime=None,
                   grantSuspendProrationType=None, chargeSuspendProrationType=None,
                   grantResumeProrationType=None, chargeResumeProrationType=None,
                   apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, resourceId=resourceId, \
                   isPauseMode=isPauseMode, scheduledSuspendTime=scheduledSuspendTime, \
                   autoResumeRelativeOffset=autoResumeRelativeOffset, autoResumeRelativeOffsetUnit=autoResumeRelativeOffsetUnit, \
                   autoResumeTime=autoResumeTime, grantSuspendProrationType=grantSuspendProrationType, chargeSuspendProrationType=chargeSuspendProrationType, \
                   grantResumeProrationType=grantResumeProrationType, chargeResumeProrationType=chargeResumeProrationType, \
                   now=now, apiEventData=apiEventData'

    # Execute the call
    cmd = 'V3inst.subscriberSuspendOffer(' + paramString + ')'
    #print 'subscriberSuspendOffer: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberSuspendOffer', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='subscriberSuspendOffer', shouldPass=eventPass)

# Subscriber Resume Offer
#=============================================================
def subscriberResumeOffer(V3inst, queryValue=None, resourceId=None, scheduledResumeTime=None, queryType='ExternalId', now=None,
                           resumeRelativeOffset=None, resumeRelativeOffsetUnit=None, grantResumeProrationType=None,
                           chargeResumeProrationType=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, resourceId=resourceId, \
                   scheduledResumeTime=scheduledResumeTime, \
                   resumeRelativeOffset=resumeRelativeOffset, resumeRelativeOffsetUnit=resumeRelativeOffsetUnit, \
                   grantResumeProrationType=grantResumeProrationType, chargeResumeProrationType=chargeResumeProrationType, \
                   now=now, apiEventData=apiEventData'

    # Execute the call
    cmd = 'V3inst.subscriberResumeOffer(' + paramString + ')'
    #print 'subscriberResumeOffer: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberResumeOffer', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='subscriberResumeOffer', shouldPass=eventPass)


# Subscriber Remove Scheduled Offer Status Change
#=============================================================
def subscriberRemoveScheduledOfferStatusChange(V3inst, queryValue=None, queryType='ExternalId', resourceId=None,
                               eventPass=True, routingType=None, routingValue=None, now=None, apiEventData=None, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryValue=queryValue, queryType=queryType, resourceId=resourceId, now=now, apiEventData=apiEventData'

    # Execute the call
    apiName = 'subscriberRemoveScheduledOfferStatusChange'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberRemoveScheduledOfferStatusChange', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='subscriberRemoveScheduledOfferStatusChange', shouldPass=eventPass)

#=============================================================
def subscriberActivateOffer(V3inst, queryValue, queryType, resourceId=None, now=None, executeMode=None,
        apiEventData=None, routingType=None, routingValue=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc=V3inst.subscriberActivateOffer(queryType=queryType, queryValue=queryValue, resourceId=resourceId, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberActivateOffer', status=retCode, msg=retText, shouldPass=eventPass)

        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberActivateOffer', status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method='subscriberActivateOffer', shouldPass=eventPass)

#=============================================================
def groupModifyOffer(V3inst, queryType, queryValue, resourceId=None, startTime=None, endTime=None, eventPass=True,
    attr=None, now=None, executeMode=None, cycleType=None, cycleResourceId=None, cycleOffset=None, cycleAlignmentDisabled=None, cycleStartTime=None, cycleEndTime=None, apiEventData=None, immediateChange=None, isRecurringFailureAllowed=None, status=None, offerStatusValue=None, modifyInfo=False, parameterList=None, multiRequestBuild=None, endTimeExtensionOffset=None, endTimeExtensionOffsetUnit=None, endAfterCycleCount=None, noEndTime=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, resourceId=resourceId, \
                   startTime=startTime, endTime=endTime, attr=attr, now=now'

    # Build the command of additional parameters.
    for item in ['cycleType', 'cycleResourceId', 'cycleOffset', 'cycleAlignmentDisabled', 'cycleStartTime', 'cycleEndTime',\
                 'apiEventData', 'immediateChange', 'isRecurringFailureAllowed', 'status', 'offerStatusValue', 'parameterList', 'endTimeExtensionOffset', 'endTimeExtensionOffsetUnit', 'endAfterCycleCount', 'noEndTime']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.groupModifyOffer(' + paramString + ')'
    #print 'groupModifyOffer: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupModifyOffer', status=retCode, msg=retText, shouldPass=eventPass)

    if modifyInfo:
        return (COMMON.debugSuccess(method='groupModifyOffer', shouldPass=eventPass), responseMdc)
    if COMMON.debugSuccess(method='groupModifyOffer', shouldPass=eventPass):
        return responseMdc

# Group Modify Status
#========================================================
def groupModifyStatus(V3inst, queryValue=None, statusTransitionTime=None, statusValue=None, queryType='ExternalId', now=None,
                           apiEventData=None, executeMode=None, routingValue=None, routingType=None, multiRequestBuild=None, eventPass=True):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, statusTransitionTime=statusTransitionTime, \
                   statusValue=statusValue, now=now, apiEventData=apiEventData'

    # Execute the call
    cmd = 'V3inst.groupModifyStatus(' + paramString + ')'
    #print 'groupModifyStatus: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupModifyStatus', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='groupModifyStatus', shouldPass=eventPass)

# Group Remove Scheduled Status Change
#=============================================================
def groupRemoveScheduledStatusChange(V3inst, queryValue=None, queryType='ExternalId', eventPass=True, now=None,
                               routingType=None, routingValue=None, apiEventData=None, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryValue=queryValue, queryType=queryType, now=now, apiEventData=apiEventData'

    # Execute the call
    apiName = 'groupRemoveScheduledStatusChange'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupRemoveScheduledStatusChange', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='groupRemoveScheduledStatusChange', shouldPass=eventPass)

# Group Suspend Offer
#=============================================================
def groupSuspendOffer(V3inst, queryValue=None, resourceId=None, scheduledSuspendTime=None, queryType='ExternalId', now=None,
                   isPauseMode=None, autoResumeRelativeOffset=None, autoResumeRelativeOffsetUnit=None, autoResumeTime=None,
                   grantSuspendProrationType=None, chargeSuspendProrationType=None,
                   grantResumeProrationType=None, chargeResumeProrationType=None,
                   apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, resourceId=resourceId, \
                   isPauseMode=isPauseMode, scheduledSuspendTime=scheduledSuspendTime, \
                   autoResumeRelativeOffset=autoResumeRelativeOffset, autoResumeRelativeOffsetUnit=autoResumeRelativeOffsetUnit, \
                   autoResumeTime=autoResumeTime, grantSuspendProrationType=grantSuspendProrationType, chargeSuspendProrationType=chargeSuspendProrationType, \
                   grantResumeProrationType=grantResumeProrationType, chargeResumeProrationType=chargeResumeProrationType, \
                   now=now, apiEventData=apiEventData'

    # Execute the call
    cmd = 'V3inst.groupSuspendOffer(' + paramString + ')'
    #print 'groupSuspendOffer: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupSuspendOffer', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='groupSuspendOffer', shouldPass=eventPass)

# Group Resume Offer
#=============================================================
def groupResumeOffer(V3inst, queryValue=None, resourceId=None, scheduledResumeTime=None, queryType='ExternalId', now=None,
                           resumeRelativeOffset=None, resumeRelativeOffsetUnit=None, grantResumeProrationType=None,
                           chargeResumeProrationType=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, resourceId=resourceId, \
                   scheduledResumeTime=scheduledResumeTime, \
                   resumeRelativeOffset=resumeRelativeOffset, resumeRelativeOffsetUnit=resumeRelativeOffsetUnit, \
                   grantResumeProrationType=grantResumeProrationType, chargeResumeProrationType=chargeResumeProrationType, \
                   now=now, apiEventData=apiEventData'

    # Execute the call
    cmd = 'V3inst.groupResumeOffer(' + paramString + ')'
    #print 'groupResumeOffer: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupResumeOffer', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='groupResumeOffer', shouldPass=eventPass)


# Group Remove Scheduled Offer Status Change
#=============================================================
def groupRemoveScheduledOfferStatusChange(V3inst, queryValue=None, queryType='ExternalId', resourceId=None,
                               eventPass=True, routingType=None, routingValue=None, now=None, apiEventData=None, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryValue=queryValue, queryType=queryType, resourceId=resourceId, now=now, apiEventData=apiEventData'

    # Execute the call
    apiName = 'groupRemoveScheduledOfferStatusChange'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupRemoveScheduledOfferStatusChange', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='groupRemoveScheduledOfferStatusChange', shouldPass=eventPass)

#=============================================================
def groupActivateOffer(V3inst, queryValue, queryType, resourceId=None, now=None, executeMode=None,
       apiEventData=None, routingType=None, routingValue=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc=V3inst.groupActivateOffer(queryType=queryType, queryValue=queryValue, resourceId=resourceId, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupActivateOffer', status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method='groupActivateOffer', shouldPass=eventPass)

#=============================================================
def deviceModifyOffer(V3inst, queryType, queryValue, resourceId=None, startTime=None, endTime=None, eventPass=True, attr=None, 
     now=None, executeMode=None, cycleType=None, cycleOwnerType=None, cycleResourceId=None, cycleOffset=None, cycleAlignmentDisabled=None, cycleStartTime=None, cycleEndTime=None, 
     apiEventData=None, immediateChange=None, isRecurringFailureAllowed=None, status=None, offerStatusValue=None, modifyInfo=False, parameterList=None, multiRequestBuild=None, endTimeExtensionOffset=None, endTimeExtensionOffsetUnit=None, endAfterCycleCount=None, noEndTime=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, resourceId=resourceId, \
                   startTime=startTime, endTime=endTime, attr=attr, now=now'

    # Build the command of additional parameters.
    for item in ['cycleType', 'cycleResourceId', 'cycleOffset', 'cycleOwnerType', 'cycleAlignmentDisabled', 'cycleStartTime','cycleEndTime', 
                 'apiEventData', 'immediateChange', 'isRecurringFailureAllowed', 'status', 'offerStatusValue', 'parameterList', 'endTimeExtensionOffset', 'endTimeExtensionOffsetUnit', 'endAfterCycleCount', 'noEndTime']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.deviceModifyOffer(' + paramString + ')'
    #print ('deviceModifyOffer: cmd = ' + cmd)
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='deviceModifyOffer', status=retCode, msg=retText, shouldPass=eventPass)

    if modifyInfo:
        return (COMMON.debugSuccess(method='deviceModifyOffer', shouldPass=eventPass), responseMdc)
    elif COMMON.debugSuccess(method='deviceModifyOffer', shouldPass=eventPass):
        return responseMdc

# Device Modify Status
#========================================================
def deviceModifyStatus(V3inst, queryValue=None, statusTransitionTime=None, statusValue=None, queryType='PhoneNumber', now=None,
                           apiEventData=None, executeMode=None, routingValue=None, routingType=None, multiRequestBuild=None, eventPass=True):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, statusTransitionTime=statusTransitionTime, \
                   statusValue=statusValue, now=now, apiEventData=apiEventData'

    # Execute the call
    cmd = 'V3inst.deviceModifyStatus(' + paramString + ')'
    #print 'deviceModifyStatus: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='deviceModifyStatus', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='deviceModifyStatus', shouldPass=eventPass)

# Device Remove Scheduled Status Change
#=============================================================
def deviceRemoveScheduledStatusChange(V3inst, queryValue=None, queryType='PhoneNumber', eventPass=True, now=None,
                               routingType=None, routingValue=None, apiEventData=None, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryValue=queryValue, queryType=queryType, now=now, apiEventData=apiEventData'

    # Execute the call
    apiName = 'deviceRemoveScheduledStatusChange'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='deviceRemoveScheduledStatusChange', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='deviceRemoveScheduledStatusChange', shouldPass=eventPass)

# Device Suspend Offer
#=============================================================
def deviceSuspendOffer(V3inst, queryValue=None, resourceId=None, scheduledSuspendTime=None, queryType='PhoneNumber', now=None,
                   isPauseMode=None, autoResumeRelativeOffset=None, autoResumeRelativeOffsetUnit=None, autoResumeTime=None,
                   grantSuspendProrationType=None, chargeSuspendProrationType=None,
                   grantResumeProrationType=None, chargeResumeProrationType=None,
                   apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, resourceId=resourceId, \
                   isPauseMode=isPauseMode, scheduledSuspendTime=scheduledSuspendTime, \
                   autoResumeRelativeOffset=autoResumeRelativeOffset, autoResumeRelativeOffsetUnit=autoResumeRelativeOffsetUnit, \
                   autoResumeTime=autoResumeTime, grantSuspendProrationType=grantSuspendProrationType, chargeSuspendProrationType=chargeSuspendProrationType, \
                   grantResumeProrationType=grantResumeProrationType, chargeResumeProrationType=chargeResumeProrationType, \
                   now=now, apiEventData=apiEventData'

    # Execute the call
    cmd = 'V3inst.deviceSuspendOffer(' + paramString + ')'
    #print 'deviceSuspendOffer: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='deviceSuspendOffer', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='deviceSuspendOffer', shouldPass=eventPass)

# Device Resume Offer
#=============================================================
def deviceResumeOffer(V3inst, queryValue=None, resourceId=None, scheduledResumeTime=None, queryType='PhoneNumber', now=None,
                           resumeRelativeOffset=None, resumeRelativeOffsetUnit=None, grantResumeProrationType=None,
                           chargeResumeProrationType=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, resourceId=resourceId, \
                   scheduledResumeTime=scheduledResumeTime, \
                   resumeRelativeOffset=resumeRelativeOffset, resumeRelativeOffsetUnit=resumeRelativeOffsetUnit, \
                   grantResumeProrationType=grantResumeProrationType, chargeResumeProrationType=chargeResumeProrationType, \
                   now=now, apiEventData=apiEventData'

    # Execute the call
    cmd = 'V3inst.deviceResumeOffer(' + paramString + ')'
    #print 'deviceResumeOffer: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='deviceResumeOffer', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='deviceResumeOffer', shouldPass=eventPass)


# Device Remove Scheduled Offer Status Change
#=============================================================
def deviceRemoveScheduledOfferStatusChange(V3inst, queryValue=None, queryType='PhoneNumber', resourceId=None,
                               eventPass=True, routingType=None, routingValue=None, now=None, apiEventData=None, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryValue=queryValue, queryType=queryType, resourceId=resourceId, now=now, apiEventData=apiEventData'

    # Execute the call
    apiName = 'deviceRemoveScheduledOfferStatusChange'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='deviceRemoveScheduledOfferStatusChange', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='deviceRemoveScheduledOfferStatusChange', shouldPass=eventPass)

#=============================================================
def deviceActivateOffer(V3inst, queryValue, queryType, resourceId=None, now=None, executeMode=None,
       apiEventData=None, routingType=None, routingValue=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc=V3inst.deviceActivateOffer(queryType=queryType, queryValue=queryValue, resourceId=resourceId, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='deviceActivateOffer', status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method='deviceActivateOffer', shouldPass=eventPass)

#=============================================================
def querySubscriberWallet(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True, multiRequestBuild=None):

    responseMdc = V3inst.subscriberQueryWallet(queryType=queryType, queryValue=queryValue, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='querySubscriberWallet', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='querySubscriberWallet', shouldPass=eventPass):
        return responseMdc

#=============================================================
def subscriberCheckPurchasedItemCycleAlignment(V3inst, queryValue, queryType='ExternalId', offerExternalId=None, catalogId=None, offerId=None, offerResourceId=None, now=None, eventPass=True, multiRequestBuild=None):
    if offerExternalId:
        offerRequest = {'ExternalId':offerExternalId}
    elif offerId:
        offerRequest = {'ProductOfferId':offerId}
    elif catalogId:
        offerRequest = {'CatalogItemId':catalogId}
    else: offerRequest=None    
    print(offerRequest)
    
    responseMdc = V3inst.subscriberCheckPurchasedItemCycleAlignment(queryType=queryType, queryValue=queryValue, offerResourceId=offerResourceId, offerRequest=offerRequest, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberCheckPurchasedItemCycleAlignment', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='subscriberCheckPurchasedItemCycleAlignment', shouldPass=eventPass):
        return responseMdc

#=============================================================
def groupCheckPurchasedItemCycleAlignment(V3inst, queryValue, queryType='ExternalId', offerExternalId=None, catalogId=None, offerId=None, offerResourceId=None, now=None, eventPass=True, multiRequestBuild=None):

    if offerExternalId:
        offerRequest = {'ExternalId':offerExternalId}
    elif offerId:
        offerRequest = {'ProductOfferId':offerId}
    elif catalogId:
        offerRequest = {'CatalogItemId':catalogId}
    else: offerRequest=None

    responseMdc = V3inst.groupCheckPurchasedItemCycleAlignment(queryType=queryType, queryValue=queryValue,  offerResourceId=offerResourceId, offerRequest=offerRequest, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupCheckPurchasedItemCycleAlignment', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='groupCheckPurchasedItemCycleAlignment', shouldPass=eventPass):
        return responseMdc

#=============================================================
def deviceCheckPurchasedItemCycleAlignment(V3inst, queryValue, queryType='ExternalId', offerExternalId=None, catalogId=None, offerId=None, offerResourceId=None, now=None, eventPass=True, multiRequestBuild=None):

    if offerExternalId:
        offerRequest = {'ExternalId':offerExternalId}
    elif offerId:
        offerRequest = {'ProductOfferId':offerId}
    elif catalogId:
        offerRequest = {'CatalogItemId':catalogId}
    else: offerRequest=None    

    responseMdc = V3inst.deviceCheckPurchasedItemCycleAlignment(queryType=queryType, queryValue=queryValue, offerResourceId=offerResourceId, offerRequest=offerRequest, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='deviceCheckPurchasedItemCycleAlignment', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='deviceCheckPurchasedItemCycleAlignment', shouldPass=eventPass):
        return responseMdc

#api for large group
#=============================================================
def querySubscriberMembership(V3inst,queryValue, membershipType=None, queryType='ExternalId',
            queryCursor=None, querySize=None, now=None, eventPass=True, multiRequestBuild=None): 

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.subscriberQueryMembership(queryType=queryType, queryValue=queryValue, membershipType=membershipType,
            queryCursor=queryCursor, querySize=querySize, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return (COMMON.debugFailure(method='querySubscriberMembership', status=retCode, msg=retText, shouldPass=eventPass), None)

    if COMMON.debugSuccess(method='querySubscriberMembership', shouldPass=eventPass):
        # Need to get queryCursor value
        queryCursor = responseMdc.getUsingKey(MDCDEFS.kMtxResponseMemberResultSetQueryCursorFldKey)
        
        # Return full MDC and queryCursor value
        return (responseMdc, str(queryCursor))

#api for large group
#=============================================================
def queryGroupMembership(V3inst,queryValue, membershipType=None,queryType='ExternalId',
            queryCursor=None, querySize=None, now=None, eventPass=True, returnExternalId=False, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()
   
    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, membershipType=membershipType, \
                   queryCursor=queryCursor, querySize=querySize, now=now'
        
    # Build the command of additional parameters.
    for item in ['returnExternalId']:
           # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item
 
    # Execute the call
    cmd = 'V3inst.groupQueryMembership(' + paramString + ')'
    #print 'groupQueryMembership: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return (COMMON.debugFailure(method='queryGroupMembership', status=retCode, msg=retText, shouldPass=eventPass), None)

    if COMMON.debugSuccess(method='queryGroupMembership', shouldPass=eventPass):
        # Need to get queryCursor value
        queryCursor = responseMdc.getUsingKey(MDCDEFS.kMtxResponseMemberResultSetQueryCursorFldKey)
        
        # Return full MDC and queryCursor value
        return (responseMdc, str(queryCursor))

#=============================================================
def createDevice(V3inst, imsi, externalId=None, deviceType=None, attr=None, accessNumbers=None, apiEventData=None, now=None,
        eventPass=True, status=None, mobile=None, tenantId=None, routingType=None, routingValue=None, executeMode=None, multiRequestBuild=None, apiEventSecurityInfo=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    if accessNumbers is not None and type(accessNumbers) is not list:
        accessNumbers = [accessNumbers]

    # Define baseline parameters - good from day 1
    paramString = 'imsi = imsi, externalId = externalId, deviceType = deviceType, \
                attr = attr, accessNumbers = accessNumbers, now = now, status = status'
        
    # Build the command of additional parameters.
    for item in ['routingType', 'routingValue', 'tenantId', 'apiEventData', 'apiEventSecurityInfo']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item
    
    # Execute the call
    apiName = 'deviceCreateMobile'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)
    
    # If a multi request then return the payload
    if multiRequestBuild:       return responseMdc
    
    oid = responseMdc.getUsingKey(MDCDEFS.kMtxResponseCreateObjectIdFldKey)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return (COMMON.debugFailure(method='createDevice', status=retCode, msg=retText, shouldPass=eventPass), oid)

    return (COMMON.debugSuccess(method='createDevice', shouldPass=eventPass), oid)

#=============================================================
def subscriberCreateDevice(V3inst, queryValue=None, queryType='ExternalId', deviceId=None, externalId=None, deviceType=None, attr=None,
        now=None, accessNumbers=None,eventPass=True, status=None, mobile=None, routingType=None, routingValue=None, executeMode=None,
        tenantId=None, apiEventData=None, returnTemplate=False, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    (retCode, deviceOid) = addDeviceToSubscriber(V3inst, queryValue, deviceId=deviceId, deviceType=deviceType, subQueryType=queryType,
        eventPass=True, attr=attr, accessNumbers=accessNumbers, status=status, now=now, apiEventData=apiEventData,
        tenantId=tenantId, isCreateDevice=True, noTouch=False, routingType=routingType, routingValue=routingValue, multiRequestBuild=multiRequestBuild)

#=============================================================
def createDeviceLogin(V3inst, loginId, externalId=None, deviceType=None, attr=None, accessIds=None, now=None,
        tenantId=None, apiEventData=None, eventPass=True, status=None, routingType=None, routingValue=None, multiRequestBuild=None, apiEventSecurityInfo=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    if accessIds is not None and type(accessIds) is not list:
        accessIds = [accessIds]

    # Define baseline parameters - good from day 1
    paramString = 'loginId=loginId, externalId = externalId, deviceType = deviceType, \
                attr = attr, accessIds = accessIds, now = now, status = status'
        
    # Build the command of additional parameters.
    for item in ['routingType', 'routingValue', 'tenantId', 'apiEventData', 'apiEventSecurityInfo']:
           # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item
 
    # Execute the call
    apiName = 'deviceCreateLogin'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)
    
    # If a multi request then return the payload
    if multiRequestBuild:       return responseMdc
    
    oid = responseMdc.getUsingKey(MDCDEFS.kMtxResponseCreateObjectIdFldKey)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return (COMMON.debugFailure(method='createDeviceLogin', status=retCode, msg=retText, shouldPass=eventPass), oid)

    return (COMMON.debugSuccess(method='createDeviceLogin', shouldPass=eventPass), oid)


#=============================================================
def subscriberDeleteDevice(V3inst, queryValue=None, queryType='ObjectId', devQueryValue=None, devQueryType='Imsi', now=None, apiEventData=None, eventPass=True, multiRequestBuild=None):
    deleteDevice(V3inst, devQueryValue, queryType=devQueryType, now=now, apiEventData=apiEventData, eventPass=eventPass, multiRequestBuild=multiRequestBuild)

#=============================================================
def deleteDevice(V3inst, queryValue, queryType='Imsi', deleteSession=False, now=None, eventPass=True, apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, now=now'
    
    # Build the command of additional parameters.
    for item in ['deleteSession', 'apiEventData']: 
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item
 
    # Execute the call
    cmd = 'V3inst.deviceDelete(' + paramString + ')'
    #print 'deviceDelete: cmd = ' + cmd
    responseMdc = eval(cmd)

    testName = os.getcwd().split('/')[-1]
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='deleteDevice', status=retCode, msg=retText, shouldPass=eventPass)
    return COMMON.debugSuccess(method='deleteDevice', shouldPass=eventPass)

#=============================================================
def addDeviceToSubscriber(V3inst, externalId, deviceId=None, deviceType=1, subQueryType='ExternalId', deviceExternalId=None,
        devQueryType='PhoneNumber', eventPass=True, attr=None, accessNumbers=None, status=None, apiEventData=None, now=None, 
        tenantId=None, isCreateDevice=True, noTouch=False, devOid=None, routingType=None, routingValue=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # For negative tests that do not want to create device.
    if deviceId and not isCreateDevice :
        # Define static string
        paramString = 'subQueryType=subQueryType, subQueryValue=externalId, devQueryType=devQueryType, devQueryValue=deviceId, now=now'

        # Build the command of additional parameters.
        '''
        for item in ['routingType', 'routingValue', 'tenantId', 'apiEventData']:
        # Command pulls in non-None parameters into paramString
         cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
         #print('cmd =', cmd)
         exec(cmd)
         item = locals()['_a']
         if item != None: paramString += item
        '''

        # Execute the call
        apiName = 'subscriberAddDevice'
        if multiRequestBuild:   cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
        else:                   cmd = 'V3inst.' + apiName + '(' + paramString + ')'

        responseMdc = eval(cmd)
        
        # If a multi request then return the payload
        if multiRequestBuild:   return responseMdc
    
        if not REST.checkResultSuccess(responseMdc):
            (retCode, retText) = REST.getResultStatus(responseMdc)
            return (COMMON.debugFailure(method='addDeviceToSubscriber', status=retCode, msg=retText, shouldPass=eventPass),
            None)
        else :
            return COMMON.debugSuccess(method='addDeviceToSubscriber', shouldPass=eventPass)
 
    existed = False
    
    # Only want to add if multi-request in play
    if multiRequestBuild: pass
    elif deviceId:
        if noTouch:
            #if using the noTouch option, device must not exist OR device oid must be passed in
            if devOid:
                oid = devOid
                existed = True
            else:
                pass        
        # Check if the device already exists
        elif queryDevice(V3inst=V3inst, queryType=devQueryType, queryValue=deviceId, eventPass=None, now=now):
            responseMdc = V3inst.deviceQuery(queryType=devQueryType, queryValue=deviceId, now=now)
            existed = True
        if not existed:
                # Device does not exist.

            # If device ID passed in, go ahead and create device.
            if deviceId is not None and devQueryType == 'PhoneNumber' : #and eventPass:
                if apiEventData:
                    (retCode, oid) = createDevice(V3inst, imsi=deviceId, deviceType=deviceType, externalId=deviceExternalId, apiEventData=apiEventData,
                        attr=attr, accessNumbers=accessNumbers, status=status, tenantId=tenantId, now=now, routingType=routingType, routingValue=routingValue)
                else:
                    (retCode, oid) = createDevice(V3inst, imsi=deviceId, deviceType=deviceType, externalId=deviceExternalId,
                        attr=attr, accessNumbers=accessNumbers, status=status, tenantId=tenantId, now=now, routingType=routingType, routingValue=routingValue)
                if not retCode:
                    return (COMMON.debugFailure(method='addDeviceToSubscriber', status=21,
                        msg='could not create device with id ' + str(deviceId), shouldPass=eventPass), None)
            elif deviceId is not None and devQueryType == 'LoginId' : #and eventPass:
                if apiEventData:
                    (retCode, oid) = createDeviceLogin(V3inst, loginId=deviceId, deviceType=deviceType, externalId=deviceExternalId, apiEventData=ApiEventData,
                        attr=attr, accessIds=accessNumbers, status=status, now=now, tenantId=tenantId, routingType=routingType, routingValue=routingValue)
                else:
                    (retCode, oid) = createDeviceLogin(V3inst, loginId=deviceId, deviceType=deviceType, externalId=deviceExternalId,
                        attr=attr, accessIds=accessNumbers, status=status, tenantId=tenantId, now=now, routingType=routingType, routingValue=routingValue)
                if not retCode:
                    return (COMMON.debugFailure(method='addDeviceToSubscriber', status=21,
                        msg='could not create device with id ' + str(deviceId), shouldPass=eventPass), None)
           
            # Continue on for negative testing
            elif  not eventPass:
                oid = None

    else:
        return (COMMON.debugFailure(method='addDeviceToSubscriber', status=20, msg='no device id passed in',
            shouldPass=True), None)
   
    # Only want to add if multi-request in play
    if multiRequestBuild: pass
    elif noTouch:
        #if using the noTouch option, assume device has no owner and don't query for response MDC 
        pass
    elif existed:
        if REST.checkResultSuccess(responseMdc):
            oid = responseMdc.getUsingKey(MDCDEFS.kMtxResponseDeviceObjectIdFldKey)
    else:
        responseMdc = V3inst.deviceQuery(queryType='ObjectId', queryValue=oid, now=now)
    
    # Only want to add if multi-request in play
    if multiRequestBuild: pass
    elif noTouch:
        pass
    # Check if device already has an owner (devices can only belong to one subscriber)
    elif responseMdc.isPresent(MDCDEFS.kMtxResponseDeviceSubscriberIdFldKey) and eventPass == True:
        msg = 'Device already has an owner'
        return (COMMON.debugFailure(method='addDeviceToSubscriber', status=23, msg=msg, shouldPass=eventPass),
            oid)

    # Device exists; add the device to the subscriber
    # Define static string
    paramString = 'subQueryType=subQueryType, subQueryValue=externalId, devQueryType=devQueryType, devQueryValue=deviceId, now=now'

    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item
 
    # Execute the call
    apiName = 'subscriberAddDevice'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)
    
    # If a multi request then return the payload
    if multiRequestBuild:       return responseMdc
    
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return (COMMON.debugFailure(method='addDeviceToSubscriber', status=retCode, msg=retText, shouldPass=eventPass),
            oid)

    return (COMMON.debugSuccess(method='addDeviceToSubscriber', shouldPass=eventPass), oid)

#=============================================================
def removeDeviceFromSubscriber(V3inst, subscriberId, deviceId, subQueryType, devQueryType, deleteSession, eventPass, now,
                               apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'subQueryType=subQueryType, subQueryValue=subscriberId,deleteSession=deleteSession, \
                   devQueryType=devQueryType, devQueryValue=deviceId, now=now'
    
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    apiName = 'subscriberRemoveDevice'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='removeDeviceFromSubscriber', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='removeDeviceFromSubscriber', shouldPass=eventPass)

#=============================================================
def modifyDevice(V3inst, queryValue, queryType='PhoneNumber', deviceType=None, attr=None, now=None, eventPass=True,
        status=None, accessNumbers=None, language=None, externalId=None, lastActivityUpdateTime=None, imsi=None,
        loginId=None, tenantId=None, apiEventData=None, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    if accessNumbers is not None and type(accessNumbers) is not list:
        accessNumbers = [accessNumbers]

    if attr is None and accessNumbers is not None:
        try:
            if queryType=='LoginId' or queryType=='AccessId':
               attr = MDCDEFS.kMtxLoginDeviceExtensionMdcDesc.create()

            else:
               attr = MDCDEFS.kMtxMobileDeviceExtensionMdcDesc.create()

        except:
            return COMMON.debugFailure(method='modifyDevice', status=9, msg='Error setting access numbers in attr',
                shouldPass=eventPass)
            
    if accessNumbers is not None:
        try:
            if queryType=='LoginId' or  queryType=='AccessId':
               attr.setUsingKey(MDCDEFS.kMtxLoginDeviceExtensionAccessIdArrayFldKey, accessNumbers)
               print('in LoginId')
            else:
                attr.setUsingKey(MDCDEFS.kMtxMobileDeviceExtensionAccessNumberArrayFldKey, accessNumbers)

        except:
            return COMMON.debugFailure(method='modifyDevice', status=9, msg='Error setting access numbers in attr',
                shouldPass=eventPass)

    #modify imsi/loginId can be only done outside of attr
    #To modify non-imsi attr, we need to remove Imsi/LoginId.
    if attr is not None:
        #print attr
        # Not all customers have a Demoxxx custom container defined...
        try:
         if attr.descObj.containerKey == MDCDEFS.kDemoLoginDeviceObjectExtensionMdcDesc.containerKey :
            attr.setUsingKey(MDCDEFS.kMtxLoginDeviceExtensionLoginIdFldKey, None)
        except: pass
        try:
         if attr.descObj.containerKey == MDCDEFS.kDemoDeviceObjectExtensionMdcDesc.containerKey :
            attr.setUsingKey(MDCDEFS.kMtxMobileDeviceExtensionImsiFldKey, None)
        except: pass
        #print attr
       
    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, deviceType=deviceType, \
                attr=attr, now=now, status=status, externalId=externalId'
        
    # Build the command of additional parameters.
    for item in ['lastActivityUpdateTime', 'imsi', 'loginId', 'tenantId', 'apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item
 
    # Execute the call
    cmd = 'V3inst.deviceModify(' + paramString + ')'
    #print 'deviceModify: cmd = ' + cmd
    #print 'attr: ' + str(attr)
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='modifyDevice', status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method='modifyDevice', shouldPass=eventPass)

#====================================================
def devicePurchaseOffer(V3inst, queryValue, offerId=None, catalogItemId=None, offerStartTime=None,
        offerEndTime=None, queryType='PhoneNumber', eventPass=True, now=None, offerIsExternal=False,
        attr=None, chargeMethod=None, paymentMethodResourceId=None, paymentGatewayId=None, paymentGatewayOneTimeToken=None,
        paymentGatewayUserId=None, etcScheduleRangeArray=None, etcScheduleRangeUnit=None, paymentScheduleRangeArray=None, paymentScheduleAmountArray=None, paymentScheduleLastAmount=None, delayCharge=None, chargeMethodAttr=None,
        purchaseInfo=False, executeMode=None, offerCycleType=None, offerCycleResourceId=None, offerCycleOffset=None, cycleOwnerType=None, offerCycleStartTime=None,
        preActiveState=None, autoActivationTime=None, autoActivationRelativeOffsetUnit=None, autoActivationRelativeOffset=None, autoActivationCycleResourceId=None,
        activationExpirationTime=None, activationExpirationRelativeOffsetUnit=None, activationExpirationRelativeOffset=None, endTimeRelativeOffsetUnit=None,
        endTimeRelativeOffset=None, downPayment=None, multiRequestBuild=None, isRecurringFailureAllowed=None, isTargetResource=None, useTargetResource=None,
        paymentDueDate=None, deferredSettlement=None, deferredSettlementTimeout=None, deferredSettlementTimeoutAction=None, apiEventData=None, offerStatusValue=None,
        chargePurchaseProrationType=None, grantPurchaseProrationType=None, reason=None, info=None, parameterList=None, contractPeriod=None, contractInterval=None,
        isPendingActivationAllowed=None, offerLifecycleProfileId=None,
        routingType=None, routingValue=None, commitmentPeriod=None, commitmentPeriodInterval=None, isOpenContract=None, eligibilityCheck=True, geoData=None, endAfterCycleCount=None, noEndTime=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    if now is None:
        now = offerStartTime

    if parameterList is None:
        parameterList = []

    # Input may be  alist of may be a single item.  If list, then want to purchase all in one command.
    offerList = []

    if catalogItemId:
        offerId=catalogItemId
        purchaseType = 'CatalogItemId'
    else:
        purchaseType = 'ProductOfferId'


    ContractParameterOverrideData = {}
    if etcScheduleRangeArray or etcScheduleRangeUnit or paymentScheduleRangeArray or paymentScheduleAmountArray or paymentScheduleLastAmount or delayCharge:
        ContractParameterOverrideData = {"EtcScheduleRangeArray": etcScheduleRangeArray, "EtcScheduleRangeUnit": etcScheduleRangeUnit, 'PaymentScheduleRangeArray':paymentScheduleRangeArray, 'PaymentScheduleAmountArray':paymentScheduleAmountArray, 'PaymentScheduleLastAmount':paymentScheduleLastAmount, 'DelayCharge':delayCharge }

    if type(offerId) is list:
        for offer in offerId:
            if offerIsExternal:
                offerList.append({'ExternalId':offer, 'StartTime':offerStartTime, 'EndTime':offerEndTime, 'Attr':attr, 'CycleType':offerCycleType,
                                  'CycleResourceId':offerCycleResourceId, 'CycleOffset':offerCycleOffset, 'CycleOwnerType':cycleOwnerType,
                                  'CycleStartTime':offerCycleStartTime, 'PreActiveState':preActiveState, 'AutoActivationTime':autoActivationTime,
                                  'AutoActivationRelativeOffsetUnit':autoActivationRelativeOffsetUnit, 'AutoActivationRelativeOffset':autoActivationRelativeOffset,
                                  'AutoActivationCycleResourceId':autoActivationCycleResourceId, 'ActivationExpirationTime':activationExpirationTime,
                                  'ActivationExpirationRelativeOffsetUnit':activationExpirationRelativeOffsetUnit, 'ActivationExpirationRelativeOffset':activationExpirationRelativeOffset,
                                  'endTimeRelativeOffset':endTimeRelativeOffset, 'endTimeRelativeOffsetUnit':endTimeRelativeOffsetUnit, 'DownPayment':downPayment,
                                  'PaymentDueDate':paymentDueDate, 'IsRecurringFailureAllowed':isRecurringFailureAllowed, 'ChargePurchaseProrationType':chargePurchaseProrationType,
                                  'GrantPurchaseProrationType':grantPurchaseProrationType, 'Reason':reason, 'Info': info, 'OfferStatusValue':offerStatusValue,
                                  'IsPendingActivationAllowed':isPendingActivationAllowed, 'OfferLifecycleProfileId':offerLifecycleProfileId,
                                  'ParameterList':parameterList, 'ContractParameterOverrideData':ContractParameterOverrideData, 'EndAfterCycleCount':endAfterCycleCount, 'NoEndTime':noEndTime})
            else:
                offerList.append({purchaseType:offer, 'StartTime':offerStartTime, 'EndTime':offerEndTime, 'Attr':attr, 'CycleType':offerCycleType,
                                  'CycleResourceId':offerCycleResourceId, 'CycleOffset':offerCycleOffset, 'CycleOwnerType':cycleOwnerType,
                                  'CycleStartTime':offerCycleStartTime, 'PreActiveState':preActiveState, 'AutoActivationTime':autoActivationTime,
                                  'AutoActivationRelativeOffsetUnit':autoActivationRelativeOffsetUnit, 'AutoActivationRelativeOffset':autoActivationRelativeOffset,
                                  'AutoActivationCycleResourceId':autoActivationCycleResourceId, 'ActivationExpirationTime':activationExpirationTime,
                                  'ActivationExpirationRelativeOffsetUnit':activationExpirationRelativeOffsetUnit, 'ActivationExpirationRelativeOffset':activationExpirationRelativeOffset,
                                  'endTimeRelativeOffset':endTimeRelativeOffset, 'endTimeRelativeOffsetUnit':endTimeRelativeOffsetUnit, 'DownPayment':downPayment,
                                  'PaymentDueDate':paymentDueDate, 'IsRecurringFailureAllowed':isRecurringFailureAllowed, 'IsTargetResource':isTargetResource, 'UseTargetResource':useTargetResource,
                                  'ChargePurchaseProrationType':chargePurchaseProrationType, 'GrantPurchaseProrationType':grantPurchaseProrationType,
                                  'IsPendingActivationAllowed':isPendingActivationAllowed, 'OfferLifecycleProfileId':offerLifecycleProfileId,
                                  'Reason':reason, 'Info': info, 'OfferStatusValue':offerStatusValue, 'ParameterList':parameterList,'ContractParameterOverrideData':ContractParameterOverrideData, 'EndAfterCycleCount':endAfterCycleCount, 'NoEndTime':noEndTime})
    else:
        # Single offer input.
        if offerIsExternal:
            offerList.append({'ExternalId':offerId, 'StartTime':offerStartTime, 'EndTime':offerEndTime, 'Attr':attr, 'CycleType':offerCycleType,
                              'CycleResourceId':offerCycleResourceId, 'CycleOffset':offerCycleOffset, 'CycleOwnerType':cycleOwnerType,
                              'CycleStartTime':offerCycleStartTime, 'PreActiveState':preActiveState, 'AutoActivationTime':autoActivationTime,
                              'AutoActivationRelativeOffsetUnit':autoActivationRelativeOffsetUnit, 'AutoActivationRelativeOffset':autoActivationRelativeOffset,
                              'AutoActivationCycleResourceId':autoActivationCycleResourceId, 'ActivationExpirationTime':activationExpirationTime,
                              'ActivationExpirationRelativeOffsetUnit':activationExpirationRelativeOffsetUnit, 'ActivationExpirationRelativeOffset':activationExpirationRelativeOffset,
                              'endTimeRelativeOffset':endTimeRelativeOffset, 'endTimeRelativeOffsetUnit':endTimeRelativeOffsetUnit, 'DownPayment':downPayment,
                              'PaymentDueDate':paymentDueDate, 'IsRecurringFailureAllowed':isRecurringFailureAllowed, 'IsTargetResource':isTargetResource, 'UseTargetResource':useTargetResource,
                              'ChargePurchaseProrationType':chargePurchaseProrationType, 'GrantPurchaseProrationType':grantPurchaseProrationType,
                              'IsPendingActivationAllowed':isPendingActivationAllowed, 'OfferLifecycleProfileId':offerLifecycleProfileId,
                              'Reason':reason, 'Info': info, 'OfferStatusValue':offerStatusValue, 'ParameterList':parameterList, 'ContractParameterOverrideData':ContractParameterOverrideData, 'EndAfterCycleCount':endAfterCycleCount, 'NoEndTime':noEndTime})
        else:
            offerList = [{purchaseType:offerId, 'StartTime':offerStartTime, 'EndTime':offerEndTime, 'Attr':attr, 'CycleType':offerCycleType,
                          'CycleResourceId':offerCycleResourceId, 'CycleOffset':offerCycleOffset, 'CycleOwnerType':cycleOwnerType,
                          'CycleStartTime':offerCycleStartTime, 'PreActiveState':preActiveState, 'AutoActivationTime':autoActivationTime,
                          'AutoActivationRelativeOffsetUnit':autoActivationRelativeOffsetUnit, 'AutoActivationRelativeOffset':autoActivationRelativeOffset,
                          'AutoActivationCycleResourceId':autoActivationCycleResourceId, 'ActivationExpirationTime':activationExpirationTime,
                          'ActivationExpirationRelativeOffsetUnit':activationExpirationRelativeOffsetUnit, 'ActivationExpirationRelativeOffset':activationExpirationRelativeOffset,
                          'endTimeRelativeOffset':endTimeRelativeOffset, 'endTimeRelativeOffsetUnit':endTimeRelativeOffsetUnit, 'DownPayment':downPayment,
                          'PaymentDueDate':paymentDueDate, 'IsRecurringFailureAllowed':isRecurringFailureAllowed, 'IsTargetResource':isTargetResource, 'UseTargetResource':useTargetResource,
                          'ChargePurchaseProrationType':chargePurchaseProrationType, 'GrantPurchaseProrationType':grantPurchaseProrationType,
                          'IsPendingActivationAllowed':isPendingActivationAllowed, 'OfferLifecycleProfileId':offerLifecycleProfileId,
                          'Reason':reason, 'Info': info, 'OfferStatusValue':offerStatusValue, 'ParameterList':parameterList, 'ContractParameterOverrideData':ContractParameterOverrideData, 'endAfterCycleCount':endAfterCycleCount, 'noEndTime':noEndTime}]

    print("------ ", queryValue, queryType)
    #print offerList
    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, offerList=offerList, now=now'
    # Build the command of additional parameters.
    nonce=paymentGatewayOneTimeToken
    for item in ['chargeMethod', 'paymentMethodResourceId', 'paymentGatewayId', 'nonce', 'chargeMethodAttr', \
                 'paymentGatewayUserId', 'eligibilityCheck', 'deferredSettlement', 'deferredSettlementTimeout', 'deferredSettlementTimeoutAction', \
                 'apiEventData','geoData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.devicePurchaseOffer(' + paramString + ')'
    #print 'devicePurchaseOffer: cmd = ' + cmd
    responseMdc = eval(cmd)

    createResourceIds = responseMdc.getUsingKey(MDCDEFS.kMtxResponseAddResourceIdArrayFldKey)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        if purchaseInfo :
          return (COMMON.debugFailure(method='devicePurchaseOffer', status=retCode, msg=retText, shouldPass=eventPass), responseMdc)
        else:
          return(COMMON.debugFailure(method='devicePurchaseOffer', status=retCode, msg=retText, shouldPass=eventPass), createResourceIds )

    if purchaseInfo:
       return (COMMON.debugSuccess(method='devicePurchaseOffer', shouldPass=eventPass), responseMdc)
    else:
       return (COMMON.debugSuccess(method='devicePurchaseOffer', shouldPass=eventPass), createResourceIds)

#=============================================================
def deviceCancelOffer(V3inst, queryValue, resourceId=0, endTime=None, queryType='PhoneNumber',
        eventPass=True, now=None, cancelInfo=False, executeMode=None, apiEventData=None, multiRequestBuild=None, eligibilityCheck=True):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()
 
    resourceList = []
    
    # Build list of resurces
    if type(resourceId) is list:
            resourceList = resourceId
    elif resourceId != 0:
        resourceList.append(resourceId)
    else:
        sys.exit('deviceCancelOffer: no resourceId was provided')

    if endTime != None:   #if we pass endTime , we will use it instead. for backwards compatibility
        now = endTime

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, resourceIdList=resourceList, now=now'

    # Build the command of additional parameters.
    for item in ['eligibilityCheck', 'apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    apiName = 'deviceCancelOffer'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.'            + apiName + '(' + paramString + ')'

    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)
    #print 'responseMdc = ' + str(responseMdc)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        if  cancelInfo :
            return (COMMON.debugFailure(method='deviceCancelOffer', status=retCode, msg=retText,
            shouldPass=eventPass), responseMdc)
        else:
            return COMMON.debugFailure(method='deviceCancelOffer', status=retCode, msg=retText,
            shouldPass=eventPass)

    if cancelInfo :
        return (COMMON.debugSuccess(method='deviceCancelOffer', shouldPass=eventPass), responseMdc)
    else:
        return COMMON.debugSuccess(method='deviceCancelOffer', shouldPass=eventPass)

#=============================================================
def deviceCancelOfferExt(V3inst, queryValue, resourceId=0, cancelType=None, grantCancelProrationType=None, chargeCancelProrationType=None,
        reason=None, info=None, cancelOfferDataList='', now=None, queryType='PhoneNumber', cancelInfo=False, eventPass=True, executeMode=None,
        apiEventData=None, contractCancelMode=None, debtCancellationMode=None, multiRequestBuild=None, isWaiveEarlyTerminationCharge=None, eligibilityCheck=True):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    if type(resourceId) is not list:
        resourceId = [resourceId]

    if cancelOfferDataList:
        resourceIdList=None
    elif cancelType or grantCancelProrationType or chargeCancelProrationType or reason or info or contractCancelMode or debtCancellationMode:
        cancelOfferDataList = []
        resourceIdList=None
        for id in resourceId:
            cancelOfferData = {"ResourceId": id, "CancelType": cancelType, "GrantCancelProrationType": grantCancelProrationType,
                                  "ChargeCancelProrationType": chargeCancelProrationType, "Reason": reason, "Info": info, "ContractCancelMode":contractCancelMode, "DebtCancellationMode": debtCancellationMode, "IsWaiveEarlyTerminationCharge": isWaiveEarlyTerminationCharge}
            cancelOfferDataList.append(cancelOfferData)
    else:
        resourceIdList=resourceId
        cancelOfferDataList=None

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, resourceIdList=resourceIdList, now=now'

    # Build the command of additional parameters.
    for item in ['cancelOfferDataList', 'eligibilityCheck', 'apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    apiName = 'deviceCancelOffer'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.'            + apiName + '(' + paramString + ')'

    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)
    #print 'responseMdc = ' + str(responseMdc)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        if cancelInfo :
            return (COMMON.debugFailure(method='deviceCancelOffer', status=retCode, msg=retText, shouldPass=eventPass), responseMdc)
        else:
            return COMMON.debugFailure(method='deviceCancelOffer', status=retCode, msg=retText, shouldPass=eventPass)

    if cancelInfo :
        return (COMMON.debugSuccess(method='deviceCancelOffer', shouldPass=eventPass), responseMdc)
    else:
        return COMMON.debugSuccess(method='deviceCancelOffer', shouldPass=eventPass)
#=============================================================
def queryDevice(V3inst, queryValue, queryType='PhoneNumber', now=None, eventPass=True, multiRequestBuild=None):
    # Query the device.
    responseMdc = V3inst.deviceQuery(queryType=queryType, queryValue=queryValue, now=now)
    if not REST.checkResultSuccess(responseMdc):
        # Used for determining if device already exists for addDeviceToSubscriber wrapper
        if eventPass is None:
            return None
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='queryDevice', status=retCode, msg=retText, shouldPass=eventPass)

    if eventPass is None:
        return responseMdc
    if COMMON.debugSuccess(method='queryDevice', shouldPass=eventPass):
        return responseMdc

#=============================================================
def createGroup(V3inst, groupId=None, name=None, tier=None, administrator_id=0, eventPass=True, attr=None, now=None, status=None,
        billingCycle=None, queryType='ExternalId', taxStatus=None, taxCertificate=None, taxLocation=None, timeZone=None,
        notificationPreference = None, dateOffset=None, groupReAuthPreference=None, glCenter=None, apiEventData=None,
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None,
        exemptionCodeList=None, routingType=None, routingValue=None, executeMode=None, multiRequestBuild=None, apiEventSecurityInfo=None):

    # Get function name
    fname = sys._getframe().f_code.co_name
    
    # Allow function to be called directoy from the command line
    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    adminArray = []
    if administrator_id != 0 and type(administrator_id) is list:
        for admin in administrator_id:
            adminArray.append(REST.newSubscriberSearch(subscriberSearchName=queryType, subscriberSearchId=admin))
    elif administrator_id != 0:
        adminArray = [REST.newSubscriberSearch(subscriberSearchName=queryType, subscriberSearchId=administrator_id)]

    #check if we passed a string for billingCycle and convert it to a billing cycle template
    if billingCycle:
        if type(billingCycle) is not data_container.DataContainer:
            billingCycle = createBillingCycleData(int(billingCycle), dateOffset=dateOffset, startTime=now)

    # Define baseline parameters - good from day 1
    paramString = 'externalId=groupId, groupName=name, adminSearchArray=adminArray, attr=attr, status=status,   \
                tier=tier, billingCycle=billingCycle, now=now, taxStatus=taxStatus, taxCertificate=taxCertificate, taxLocation=taxLocation,     \
                timeZone=timeZone, notificationPreference=notificationPreference'
        
    # Build the command of additional parameters.
    for item in ['groupReAuthPreference', 'glCenter', 'routingType', 'routingValue', 'apiEventData','customerType','serviceAddress','npa','nxx'  \
                 ,'tenantId','exemptionCodeList', 'apiEventSecurityInfo']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item
 
    # Execute the call
    apiName = 'groupCreate'
    if multiRequestBuild:
        cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:
        cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print 'groupCreate: cmd = ' + cmd
    responseMdc = eval(cmd)
    
    # If a multi request then return the payload
    if multiRequestBuild:       return responseMdc

    oid = responseMdc.getUsingKey(MDCDEFS.kMtxResponseCreateObjectIdFldKey)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return (COMMON.debugFailure(method=fname, status=retCode, msg=retText, shouldPass=eventPass), oid)

    return (COMMON.debugSuccess(method=fname, shouldPass=eventPass), oid)

#=============================================================
def modifyGroup(V3inst, groupId, name=None, tier=None, administrator_id=0, billingCycle=None, attr=None, status=None,
        subQueryType='ExternalId', groupQueryType='ExternalId', now=None, eventPass=True, notificationPreference = None,
        taxStatus=None, taxCertificate=None, taxLocation=None, externalId=None, timeZone=None, groupReAuthPreference=None,
        dateOffset=None, glCenter=None, paymentGatewayUserId=None, currentPaymentTokenResourceId=None,
        apiEventData=None, lastActivityUpdateTime=None, executeMode=None, billingCycleDisabled=None, multiRequestBuild=None,
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        maxUserCount=None, maxSubscriberCount=None):

    # Get function name
    fname = sys._getframe().f_code.co_name
    
    # Allow function to be called directoy from the command line
    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    adminArray = []
    if administrator_id != 0 and type(administrator_id) is list:
        for admin in administrator_id:
            adminArray.append(REST.newSubscriberSearch(subscriberSearchName=subQueryType, subscriberSearchId=admin))
    elif administrator_id != 0:
        adminArray = [REST.newSubscriberSearch(subscriberSearchName=subQueryType, subscriberSearchId=administrator_id)]

    if adminArray != []:
        V3inst.groupAddMembership(queryType=groupQueryType, queryValue=groupId, adminSearchArray=adminArray, now=now )

    #check if we passed a string for billingCycle and convert it to a billing cycle template
    if billingCycle:
        if type(billingCycle) is not data_container.DataContainer:
            billingCycle = createBillingCycleData(int(billingCycle), startTime=now, dateOffset=dateOffset)

    # Define baseline parameters - good from day 1
    paramString = 'queryType=groupQueryType, queryValue=groupId, groupName=name, status=status, \
                attr=attr, tier=tier, billingCycle=billingCycle, now=now, taxStatus=taxStatus, taxCertificate=taxCertificate, taxLocation=taxLocation, \
                notificationPreference = notificationPreference, externalId=externalId, timeZone=timeZone, groupReAuthPreference=groupReAuthPreference'
        
    # Build the command of additional parameters.
    for item in ['glCenter', 'paymentGatewayUserId', 'currentPaymentTokenResourceId', 'lastActivityUpdateTime', \
                 'billingCycleDisabled', 'apiEventData', 'maxUserCount', 'maxSubscriberCount','customerType','serviceAddress','npa','nxx','tenantId','exemptionCodeList']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item
 
    # Execute the call
    cmd = 'V3inst.groupModify(' + paramString + ')'
    #print 'groupModify: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method=fname, status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method=fname, shouldPass=eventPass)

#=============================================================
def addAdminToGroup(V3inst, groupId, subscriberId, subQueryType='ExternalId', groupQueryType='ExternalId',
        eventPass=True, now=None, executeMode=None, apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    subList = []
    if type(subscriberId) is list:
        for sub in subscriberId:
            subList.append(REST.newSubscriberSearch(subscriberSearchName=subQueryType, subscriberSearchId=sub))
    else:
        subList.append(REST.newSubscriberSearch(subscriberSearchName=subQueryType, subscriberSearchId=subscriberId))

    responseMdc=V3inst.groupAddMembership(queryType=groupQueryType, queryValue=groupId, adminSearchArray=subList,
        now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='addAdminToGroup', status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method='addAdminToGroup', shouldPass=eventPass)

#=============================================================
def removeAdminFromGroup(V3inst, groupId, admins, adminQueryType='ExternalId', groupQueryType='ExternalId',
        eventPass=True, now=None, executeMode=None, apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    subList = []
    if type(admins) is list:
        for admin in admins:
            subList.append(REST.newSubscriberSearch(subscriberSearchName=adminQueryType, subscriberSearchId=admin))
    else:
        subList.append(REST.newSubscriberSearch(subscriberSearchName=adminQueryType, subscriberSearchId=admins))


    paramString='queryType=groupQueryType, queryValue=groupId, adminSearchArray=subList, now=now'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    apiName = 'groupRemoveMembership'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='removeAdminFromGroup', status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method='removeAdminFromGroup', shouldPass=eventPass)

#=============================================================
def addSubscriberToGroup(V3inst, groupId, subscriberId, subQueryType='ExternalId', groupQueryType='ExternalId',
        apiEventData=None, eventPass=True, now=None, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    subList = []
    if type(subscriberId) is list:
        for sub in subscriberId:
            subList.append(REST.newSubscriberSearch(subscriberSearchName=subQueryType, subscriberSearchId=sub))
    else:
        subList.append(REST.newSubscriberSearch(subscriberSearchName=subQueryType, subscriberSearchId=subscriberId))

    # Define baseline parameters - good from day 1
    paramString = 'queryType=groupQueryType, queryValue=groupId, subscriberSearchArray=subList, now=now'
    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.groupAddMembership(' + paramString + ')'
    #print 'groupAddMembership: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='addSubscriberToGroup', status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method='addSubscriberToGroup', shouldPass=eventPass)

#=============================================================
def addGroupMembership(V3inst, groupId, subscribers=None, subGroups=None, subQueryType='ExternalId',
        subGroupQueryType='ExternalId', groupQueryType='ExternalId', eventPass=True, now=None,
        admins=None, adminQueryType='ExternalId', apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    subList = []
    if type(subscribers) is list:
        for sub in subscribers:
            subList.append(REST.newSubscriberSearch(subscriberSearchName=subQueryType, subscriberSearchId=sub))
    elif subscribers:
        subList.append(REST.newSubscriberSearch(subscriberSearchName=subQueryType, subscriberSearchId=subscribers))

    groupList = []
    if type(subGroups) is list:
        for group in subGroups:
            groupList.append(REST.newGroupSearch(groupSearchName=subGroupQueryType, groupSearchId=group))
    elif subGroups:
        groupList.append(REST.newGroupSearch(groupSearchName=subGroupQueryType, groupSearchId=subGroups))

    adminList = []
    if type(admins) is list:
        for admin in admins:
            adminList.append(REST.newSubscriberSearch(subscriberSearchName=adminQueryType, subscriberSearchId=admin))
    elif admins:
        adminList.append(REST.newSubscriberSearch(subscriberSearchName=adminQueryType, subscriberSearchId=admins))


    paramString='queryType=groupQueryType, queryValue=groupId, subscriberSearchArray=subList, \
        subGroupSearchArray=groupList, adminSearchArray=adminList, now=now'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    apiName = 'groupAddMembership'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='addGroupMembership', status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method='addGroupMembership', shouldPass=eventPass)

#=============================================================
def removeGroupMembership(V3inst, groupId, subscribers=None, subGroups=None, subQueryType='ExternalId',
        subGroupQueryType='ExternalId', groupQueryType='ExternalId', eventPass=True, now=None,
        admins=None, adminQueryType='ExternalId', apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    subList = []
    if type(subscribers) is list:
        for sub in subscribers:
            subList.append(REST.newSubscriberSearch(subscriberSearchName=subQueryType, subscriberSearchId=sub))
    elif subscribers:
        subList.append(REST.newSubscriberSearch(subscriberSearchName=subQueryType, subscriberSearchId=subscribers))

    groupList = []
    if type(subGroups) is list:
        for group in subGroups:
            groupList.append(REST.newGroupSearch(groupSearchName=subQueryType, groupSearchId=group))
    elif subGroups:
        groupList.append(REST.newGroupSearch(groupSearchName=subQueryType, groupSearchId=subGroups))

    adminList = []
    if type(admins) is list:
        for admin in admins:
            adminList.append(REST.newSubscriberSearch(subscriberSearchName=adminQueryType, subscriberSearchId=admin))
    elif admins:
        adminList.append(REST.newSubscriberSearch(subscriberSearchName=adminQueryType, subscriberSearchId=admins))


    paramString='queryType=groupQueryType, queryValue=groupId, \
        subscriberSearchArray=subList, subGroupSearchArray=groupList, adminSearchArray=adminList, now=now'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    apiName = 'groupRemoveMembership'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='removeGroupMembership', status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method='removeGroupMembership', shouldPass=eventPass)

#=============================================================
def removeSubscriberFromGroup(V3inst, groupId, subscriberId, subQueryType='ExternalId', groupQueryType='ExternalId',
        apiEventData=None, eventPass=True, now=None, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    subList = []
    if type(subscriberId) is list:
        for sub in subscriberId:
            subList.append(REST.newSubscriberSearch(subscriberSearchName=subQueryType, subscriberSearchId=sub))
    else:
        subList.append(REST.newSubscriberSearch(subscriberSearchName=subQueryType, subscriberSearchId=subscriberId))

    paramString = 'queryType=groupQueryType, queryValue=groupId, subscriberSearchArray=subList, now=now'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.groupRemoveMembership(' + paramString + ')'
    #print 'groupRemoveMembership: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='removeSubscriberFromGroup', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='removeSubscriberFromGroup', shouldPass=eventPass)

#=============================================================
def addSubGroupToGroup(V3inst, groupId, subGroupId, subQueryType='ExternalId', groupQueryType='ExternalId',
        apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    groupList = []
    if type(subGroupId) is list:
        for group in subGroupId:
            groupList.append(REST.newGroupSearch(groupSearchName=subQueryType, groupSearchId=group))
    else:
        groupList.append(REST.newGroupSearch(groupSearchName=subQueryType, groupSearchId=subGroupId))

    paramString = 'queryType=groupQueryType, queryValue=groupId, subGroupSearchArray=groupList, now=now'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.groupAddMembership(' + paramString + ')'
    #print 'groupAddMembership: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='addSubGroupToGroup', status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method='addSubGroupToGroup', shouldPass=eventPass)

#=============================================================
def removeSubGroupFromGroup(V3inst, groupId, subGroupId, subQueryType='ExternalId', groupQueryType='ExternalId',
        apiEventData=None, eventPass=True, now=None, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    groupList = []
    if type(subGroupId) is list:
        for group in subGroupId:
            groupList.append(REST.newGroupSearch(groupSearchName=subQueryType, groupSearchId=group))
    else:
        groupList.append(REST.newGroupSearch(groupSearchName=subQueryType, groupSearchId=subGroupId))


    paramString = 'queryType=groupQueryType, queryValue=groupId, subGroupSearchArray=groupList, now=now'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.groupRemoveMembership(' + paramString + ')'
    #print 'groupRemoveMembership: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='removeSubGroupFromGroup', status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method='removeSubGroupFromGroup', shouldPass=eventPass)

#=============================================================
def groupSubscribeToOffer(V3inst, groupId, offerId, catalogItemId=None, offerStartTime=None, offerEndTime=None,
        eventPass=True, queryType='ExternalId', now=None, offerIsExternal=False, attr=None, dupAttr=True,
        chargeMethod=None, paymentMethodResourceId=None, paymentGatewayId=None, paymentGatewayOneTimeToken=None,
        chargeMethodAttr=None, paymentGatewayUserId=None, paymentDueDate=None, etcScheduleRangeArray=None, etcScheduleRangeUnit=None,
        paymentScheduleRangeArray=None, paymentScheduleAmountArray=None, paymentScheduleLastAmount=None, delayCharge=None, deferredSettlement=None,
        deferredSettlementTimeout=None, deferredSettlementTimeoutAction=None,
        purchaseInfo=False, executeMode=None, offerCycleType=None, offerCycleResourceId=None, offerCycleOffset=None, offerCycleStartTime=None,
        preActiveState=None, autoActivationTime=None, autoActivationRelativeOffsetUnit=None, autoActivationRelativeOffset=None,
        autoActivationCycleResourceId=None, activationExpirationTime=None, activationExpirationRelativeOffsetUnit=None,
        activationExpirationRelativeOffset=None, endTimeRelativeOffsetUnit=None, endTimeRelativeOffset=None, downPayment=None,
        isRecurringFailureAllowed=None, isTargetResource=None, useTargetResource = None, apiEventData=None, offerStatusValue=None, parameterList=None,
        contractPeriod=None, contractInterval=None, commitmentPeriod=None, commitmentPeriodInterval=None, isOpenContract=False,
        isPendingActivationAllowed=None, offerLifecycleProfileId=None,
        routingType=None, routingValue=None, chargePurchaseProrationType=None, grantPurchaseProrationType=None, reason=None, info=None, multiRequestBuild=None, eligibilityCheck=True, geoData=None, endAfterCycleCount=None, noEndTime=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    if now is None:
        now = offerStartTime

    if catalogItemId:
        offerId = catalogItemId

    if parameterList is None:
        parameterList = []

    offerList = []
    offerList = prepOfferAttr(offerId, offerIsExternal=offerIsExternal, offerStartTime=offerStartTime, offerEndTime=offerEndTime, paymentDueDate=paymentDueDate,
                          attr=attr, offerList=offerList, dupAttr=dupAttr, catalogItemId=catalogItemId, offerCycleType=offerCycleType,
                          offerCycleResourceId=offerCycleResourceId, offerCycleOffset=offerCycleOffset, offerCycleStartTime=offerCycleStartTime,
                          preActiveState=preActiveState, autoActivationTime=autoActivationTime, autoActivationRelativeOffsetUnit=autoActivationRelativeOffsetUnit,
                          autoActivationRelativeOffset=autoActivationRelativeOffset, autoActivationCycleResourceId=autoActivationCycleResourceId,
                          activationExpirationTime=activationExpirationTime, activationExpirationRelativeOffsetUnit=activationExpirationRelativeOffsetUnit,
                          activationExpirationRelativeOffset=activationExpirationRelativeOffset, endTimeRelativeOffsetUnit=endTimeRelativeOffsetUnit,
                          endTimeRelativeOffset=endTimeRelativeOffset, downPayment=downPayment, isRecurringFailureAllowed=isRecurringFailureAllowed,
                          isTargetResource=isTargetResource, useTargetResource=useTargetResource, chargePurchaseProrationType=chargePurchaseProrationType,
                          grantPurchaseProrationType=grantPurchaseProrationType, reason=reason, info=info, offerStatusValue=offerStatusValue, parameterList=parameterList,
                          isPendingActivationAllowed=isPendingActivationAllowed, offerLifecycleProfileId=offerLifecycleProfileId,
                          etcScheduleRangeArray=etcScheduleRangeArray, etcScheduleRangeUnit=etcScheduleRangeUnit, paymentScheduleRangeArray=paymentScheduleRangeArray,
                          paymentScheduleAmountArray=paymentScheduleAmountArray, paymentScheduleLastAmount=paymentScheduleLastAmount, delayCharge=delayCharge, geoData=geoData,
                          endAfterCycleCount=endAfterCycleCount, noEndTime=noEndTime)

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=groupId, offerList=offerList, now=now'
    # Build the command of additional parameters.
    nonce=paymentGatewayOneTimeToken
    for item in ['chargeMethod', 'paymentMethodResourceId', 'paymentGatewayId', 'nonce', 'chargeMethodAttr', \
                 'deferredSettlement', 'deferredSettlementTimeout', 'deferredSettlementTimeoutAction', \
                 'paymentGatewayUserId', 'eligibilityCheck', 'apiEventData','geoData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.groupPurchaseOffer(' + paramString + ')'
    #print 'groupPurchaseOffer: cmd = ' + cmd
    responseMdc = eval(cmd)

    createResourceIds = responseMdc.getUsingKey(MDCDEFS.kMtxResponseAddResourceIdArrayFldKey)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        if purchaseInfo:
           return (COMMON.debugFailure(method='groupSubscribeToOffer', status=retCode, msg=retText, shouldPass=eventPass), responseMdc)
        else:
           return (COMMON.debugFailure(method='groupSubscribeToOffer', status=retCode, msg=retText, shouldPass=eventPass),
            createResourceIds)

    if purchaseInfo:
       return (COMMON.debugSuccess(method='groupSubscribeToOffer', shouldPass=eventPass), responseMdc)
    else:
       return (COMMON.debugSuccess(method='groupSubscribeToOffer', shouldPass=eventPass), createResourceIds)

#==========================================================================================================
#add getSubscInterfaceMDC() interface to allow api to run from cmd line 
#e.g , to cancel offer of group via api : groupUnsubscribeFromOffer(None,107139,1),specify  V3inst to None 
#                                         to call the getSubscInterfaceMDC()
#command to run from command line : python -c 'import mdcV3;mdcV3.groupUnsubscribeFromOffer(None,107139,1)'
def groupUnsubscribeFromOffer(V3inst, groupId, resourceIds, now=None, eventPass=True, queryType='ExternalId',
        cancelInfo=False, executeMode=None, multiRequestBuild=None, apiEventData=None, eligibilityCheck=True):
    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    if type(resourceIds) is not list:
        resourceIds = [resourceIds]

    #responseMdc = V3inst.groupCancelOffer(queryType=queryType, queryValue=groupId, resourceIdList=resourceIds,
    #    now=now, eligibilityCheck=eligibilityCheck)

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=groupId,resourceIdList=resourceIds, now=now'

    # Build the command of additional parameters.
    for item in ['eligibilityCheck', 'apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    apiName = 'groupCancelOffer'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.'            + apiName + '(' + paramString + ')'

    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        if cancelInfo:
            return (COMMON.debugFailure(method='groupUnsubscribeFromOffer', status=retCode, msg=retText,
            shouldPass=eventPass), responseMdc)
        else:
            return COMMON.debugFailure(method='groupUnsubscribeFromOffer', status=retCode, msg=retText,
            shouldPass=eventPass)

    if cancelInfo:
        return (COMMON.debugSuccess(method='groupUnsubscribeFromOffer', shouldPass=eventPass), responseMdc)
    else:
        return COMMON.debugSuccess(method='groupUnsubscribeFromOffer', shouldPass=eventPass)

#========================================================
def groupCancelOffer(V3inst, queryValue, resourceId=0, cancelType=None, grantCancelProrationType=None, chargeCancelProrationType=None,
        reason=None, info=None, cancelOfferDataList='', now=None, queryType='ExternalId', cancelInfo=False, eventPass=True, apiEventData=None,
        executeMode=None, contractCancelMode=None, debtCancellationMode=None, multiRequestBuild=None, isWaiveEarlyTerminationCharge=None, eligibilityCheck=True):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    if type(resourceId) is not list:
        resourceId = [resourceId]

    if cancelOfferDataList:
        resourceIdList=None
    elif cancelType or grantCancelProrationType or chargeCancelProrationType or reason or info or contractCancelMode or debtCancellationMode:
        cancelOfferDataList = []
        resourceIdList=None
        for id in resourceId:
            cancelOfferData = {"ResourceId": id, "CancelType": cancelType, "GrantCancelProrationType": grantCancelProrationType,
                                  "ChargeCancelProrationType": chargeCancelProrationType, "Reason": reason, "Info": info, "ContractCancelMode": contractCancelMode, "DebtCancellationMode": debtCancellationMode, "IsWaiveEarlyTerminationCharge": isWaiveEarlyTerminationCharge}
            cancelOfferDataList.append(cancelOfferData)
    else:
        resourceIdList=resourceId
        cancelOfferDataList=None

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue,resourceIdList=resourceIdList, now=now'

    # Build the command of additional parameters.
    for item in ['cancelOfferDataList', 'eligibilityCheck', 'apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    apiName = 'groupCancelOffer'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.'            + apiName + '(' + paramString + ')'

    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        if cancelInfo :
            return (COMMON.debugFailure(method='groupCancelOffer', status=retCode, msg=retText, shouldPass=eventPass), responseMdc)
        else:
            return COMMON.debugFailure(method='groupCancelOffer', status=retCode, msg=retText, shouldPass=eventPass)

    if cancelInfo :
        return (COMMON.debugSuccess(method='groupCancelOffer', shouldPass=eventPass), responseMdc)
    else:
        return COMMON.debugSuccess(method='groupCancelOffer', shouldPass=eventPass)

#========================================================
def addGroupThreshold(V3inst, groupId, thresholdId, resourceId=None, threshName=None, val=0, notify=None,
        eventPass=True, now=None, queryType='ExternalId', recurringStart = None, recurringStop = None, virtualCreditLimitIsPercent=0,
        rechargeAmount=None, rechargePaymentMethodResourceId=None, executeMode=None, isTemporaryCreditLimit=None, 
        apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    if notify:
        thresholdNotification = 1
    else:
        thresholdNotification = 0

    # Use helper to look for resourceId based on thresholdId if not passed in
    if resourceId is None:
        walletMdc = V3inst.groupQueryWallet(queryType=queryType, queryValue=groupId, now=now)
        resourceId = COMMON.getResourceId(walletMdc, thresholdId)
        if resourceId is None:
            return COMMON.debugFailure(method='addGroupThreshold', status=1, msg='ThresholdId not found')

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=groupId, thresholdId=thresholdId, \
                resourceId=resourceId, thresholdAmount=val, thresholdName=threshName,   \
                thresholdNotification=thresholdNotification, now=now, recurringStart = recurringStart, recurringStop = recurringStop'
        
    # Build the command of additional parameters.
    for item in ['virtualCreditLimitIsPercent', 'rechargeAmount', 'rechargePaymentMethodResourceId', 'isTemporaryCreditLimit', 'apiEventData']:
           # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item
 
    # Execute the call
    cmd = 'V3inst.groupAddThreshold(' + paramString + ')'
    #print 'groupAddThreshold: cmd = ' + cmd
    responseMdc = eval(cmd)
    
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='addGroupThreshold', status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method='addGroupThreshold', shouldPass=eventPass)

#========================================================
def removeGroupThreshold(V3inst, groupId, resourceId, thresholdId, now=None, queryType='ExternalId',
    removeThresholdOnly=None, removeRechargeDataOnly=None, eventPass=True, isTemporaryCreditLimit=None, 
    apiEventData=None, multiRequestBuild=None):

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=groupId, thresholdId=thresholdId, \
                resourceId=resourceId, now=now'

    # Build the command of additional parameters.
    for item in ['removeThresholdOnly', 'removeRechargeDataOnly', 'isTemporaryCreditLimit', 'apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.groupRemoveThreshold(' + paramString + ')'
    #print 'groupAddThreshold: cmd = ' + cmd
    responseMdc = eval(cmd)

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='removeGroupThreshold', status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method='removeGroupThreshold', shouldPass=eventPass)

#=============================================================
def queryGroupThresholdRechargeDefn(V3inst, queryValue, queryType='ExternalId', balanceResourceId=None, now=None, eventPass=True, multiRequestBuild=None):

    responseMdc = V3inst.groupQueryThresholdRechargeDefn(queryType=queryType, queryValue=queryValue, balanceResourceId=balanceResourceId,
        now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='queryGroupThresholdRechargeDefn', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='queryGroupThresholdRechargeDefn', shouldPass=eventPass):
        return responseMdc

#=============================================================
def queryGroup(V3inst, queryValue, queryType='ExternalId', querySize=None,now=None, eventPass=True, multiRequestBuild=None):
    responseMdc = V3inst.groupQuery(queryType=queryType, queryValue=queryValue,querySize=querySize, now=now)
 
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='queryGroup', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='queryGroup', shouldPass=eventPass):
        return responseMdc

#=============================================================
def queryGroupCursor(V3inst, queryValue, queryType='ExternalId', querySize=None,now=None, eventPass=True, multiRequestBuild=None):
    responseMdc = V3inst.groupQuery(queryType=queryType, queryValue=queryValue,querySize=querySize, now=now)
    #print( 'queryGroupCursor, responseMdc = ' + str(responseMdc))

    cursorDict = {}
    
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return (COMMON.debugFailure(method='queryGroupCursor', status=retCode, msg=retText, shouldPass=eventPass), cursorDict)

    if COMMON.debugSuccess(method='queryGroupCursor', shouldPass=eventPass):
        # Get each cursor value
        for cursor in ['AdminCursor', 'SubscriberMemberCursor', 'GroupMemberCursor']:
                try:
                        cmd="cursorDict['" + cursor + "'] = responseMdc.getUsingKey(MDCDEFS.kMtxResponseGroup" + cursor + "FldKey)"
                        exec(compile(cmd, '<string>', 'exec'))
                except:
                        cmd="cursorDict['" + cursor + "'] = '0'"
                        exec(compile(cmd, '<string>', 'exec'))
        
        #print 'queryGroupCursor, dictionary = ' + str(cursorDict)
        
        # Return full MDC and queryCursor value
        return (responseMdc, cursorDict)

#=============================================================
def queryGroupWallet(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True, multiRequestBuild=None):
    responseMdc = V3inst.groupQueryWallet(queryType=queryType, queryValue=queryValue, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='queryGroupWallet', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='queryGroupWallet', shouldPass=eventPass):
        return responseMdc

#=============================================================
def createBillingCycleData(templateId, dateOffset=None, startTime=None, immediateChange=None):
    # Define baseline parameters - good from day 1
    paramString = 'templateId=templateId, dateOffset=dateOffset'

    # Build the command of additional parameters.
    for item in ['immediateChange']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'REST.newBillingCycleData(' + paramString + ')'
    #print 'createBillingCycleData: cmd = ' + cmd
    billCycleMdc = eval(cmd)

    if not billCycleMdc:
        return False

    return billCycleMdc

#=============================================================
def subscriberAdjustBalance(V3inst=None, queryValue=None, balanceResourceId=None, componentMeterId=None, adjustType=None, amount=None,
        reason=None, queryType='PhoneNumber', info=None, endTime=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
        now=None, creditLimitPolicy=None, startTime=None, apiEventData=None, eventPass=True, multiRequestBuild=None, executeMode=None):
    
    # Get function name
    fname = sys._getframe().f_code.co_name
    
    # Allow function to be called directoy from the command line
    if V3inst == None: V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, balanceResourceId=balanceResourceId, adjustType=adjustType,      \
                amount=amount, reason=reason '
    
    # Build additional parameters
    for item in ['info', 'endTime', 'endTimeExtensionOffsetUnit', 'endTimeExtensionOffset', 'now', 'creditLimitPolicy',
                     'componentMeterId', 'startTime', 'apiEventData']:
                # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item
    
    # Execute the call
    cmd = 'V3inst.subscriberAdjustBalance(' + paramString + ')'
    #print('subscriberAdjustBalance ',cmd)
    responseMdc = eval(cmd)
    
    # Check the response
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method=fname, status=retCode, msg=retText, shouldPass=eventPass), responseMdc

    return COMMON.debugSuccess(method=fname, shouldPass=eventPass)

#=============================================================
def subscriberTransferBalance(V3inst=None, queryValue=None, queryType='PhoneNumber', balanceResourceId=None, amount=None, amountIsPct=False,
        targetSubscriberSearchData=None, targetGroupSearchData=None, targetQueryType='PhoneNumber', targetBalanceResourceId=None,
        sourceIsEventInitiator=None, creditFloorPolicy=None, reason=None, info=None, apiEventData=None,
        now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    if (targetSubscriberSearchData and targetQueryType != 'ObjectId'):
        targetSubscriberSearchData = REST.newSubscriberSearch(subscriberSearchName=targetQueryType, subscriberSearchId=targetSubscriberSearchData)

    if (targetGroupSearchData and targetQueryType != 'ObjectId'):
        targetGroupSearchData = REST.newGroupSearch(groupSearchName=targetQueryType, groupSearchId=targetGroupSearchData)

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, balanceResourceId=balanceResourceId, amount=amount, \
                   amountIsPct=amountIsPct, targetSubscriberSearchData=targetSubscriberSearchData, targetGroupSearchData=targetGroupSearchData, \
                   targetBalanceResourceId=targetBalanceResourceId, sourceIsEventInitiator=sourceIsEventInitiator, creditFloorPolicy=creditFloorPolicy, \
                   reason=reason, info=info, now=now'

    # Build additional parameters
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.subscriberTransferBalance(' + paramString + ')'
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberTransferBalance', status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method='subscriberTransferBalance', shouldPass=eventPass)

#=============================================================
def subscriberAdjustRolloverBalance(V3inst=None, queryValue=None, reason=None, balanceResourceId=None,
           queryType='PhoneNumber', balanceIntervalId=None, adjustType=None, amount=None, info=None, remainingRolloverCounter=None,
           apiEventData=None, now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryType=queryType, queryValue=queryValue, reason=reason, \
                   balanceResourceId=balanceResourceId, balanceIntervalId=balanceIntervalId, adjustType=adjustType, amount=amount, info=info, \
                   remainingRolloverCounter=remainingRolloverCounter, now=now'

    # Build additional parameters
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.subscriberAdjustRolloverBalance(' + paramString + ')'
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberAdjustRolloverBalance', status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method='subscriberAdjustRolloverBalance', shouldPass=eventPass)

#=============================================================
def subscriberTopupBalance(V3inst=None, queryValue=None, balanceResourceId=None, amount=None, voucher=None,
        queryType='PhoneNumber', endTime=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
        apiEventData=None, now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryType=queryType, queryValue=queryValue, \
                   balanceResourceId=balanceResourceId, amount=amount, voucher=voucher, endTime=endTime, \
                   endTimeExtensionOffsetUnit=endTimeExtensionOffsetUnit, endTimeExtensionOffset=endTimeExtensionOffset, now=now'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.subscriberTopupBalance(' + paramString + ')'
    #print 'subscriberTopupBalance: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberTopupBalance', status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method='subscriberTopupBalance', shouldPass=eventPass)

#=============================================================
def subscriberRecharge(V3inst=None, queryValue=None, amount=None, balanceResourceId=None, payNow=None,
        queryType='PhoneNumber', endTime=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
        paymentMethodResourceId=None, paymentGatewayId=None, paymentGatewayOneTimeToken=None, info=None, reason=None,
        chargeMethodAttr=None, paymentGatewayUserId=None, rechargeAttr=None, 
        apiEventData=None, now=None, eventPass=True, executeMode=None, payload=True, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, amount=amount'

    # Build the command of additional parameters.
    nonce=paymentGatewayOneTimeToken
    if payload:
      for item in ['endTime', 'endTimeExtensionOffsetUnit', 'endTimeExtensionOffset', 'chargeMethodAttr', \
                     'paymentMethodResourceId', 'paymentGatewayId', 'nonce', 'info', 'reason', 'balanceResourceId',  \
                     'payNow', 'now', 'paymentGatewayUserId', 'rechargeAttr', 'apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.subscriberRecharge(' + paramString + ')'
    #print 'subscriberRecharge: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberRecharge', status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method='subscriberRecharge', shouldPass=eventPass)

#=============================================================
def subscriberAddRechargeSchedule(V3inst=None, queryValue=None, firstRechargeTime=None, queryType='ExternalId',
        periodType=None, periodCoef=None, cycleTimeOfDay=None, cycleOffset=None,
        amount=None, paymentMethodResourceId=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
        scheduledRechargeNotificationProfileId=None, now=None, eventPass=True, executeMode=None,
        apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    cycleDefn = REST.newRechargeCycleData(periodType=periodType, periodCoef=periodCoef, cycleTimeOfDay=cycleTimeOfDay,
       cycleOffset=cycleOffset)

    paramString = 'queryType=queryType, queryValue=queryValue, firstRechargeTime=firstRechargeTime, cycleDefn = cycleDefn,  \
        amount=amount, paymentMethodResourceId=paymentMethodResourceId, endTimeExtensionOffsetUnit=endTimeExtensionOffsetUnit, \
        endTimeExtensionOffset=endTimeExtensionOffset, scheduledRechargeNotificationProfileId=scheduledRechargeNotificationProfileId'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    apiName = 'subscriberAddRechargeSchedule'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberAddRechargeSchedule', status=retCode, msg=retText, shouldPass=eventPass)

    return (COMMON.debugSuccess(method='subscriberAddRechargeSchedule', shouldPass=eventPass), responseMdc)

#=============================================================
def subscriberModifyRechargeSchedule(V3inst=None, queryValue=None, nextRechargeTime=None, queryType='ExternalId',
        periodType=None, periodCoef=None, cycleTimeOfDay=None, cycleOffset=None,
        amount=None, paymentMethodResourceId=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
        scheduledRechargeNotificationProfileId=None, now=None, eventPass=True, executeMode=None, 
        apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    if periodType or periodCoef or cycleTimeOfDay or cycleOffset:
       cycleDefn = REST.newRechargeCycleData(periodType=periodType, periodCoef=periodCoef, cycleTimeOfDay=cycleTimeOfDay,
       cycleOffset=cycleOffset)
    else:
        cycleDefn = None

    paramString = 'queryType=queryType, queryValue=queryValue, nextRechargeTime=nextRechargeTime, cycleDefn = cycleDefn,  \
        amount=amount, paymentMethodResourceId=paymentMethodResourceId, endTimeExtensionOffsetUnit=endTimeExtensionOffsetUnit, \
        endTimeExtensionOffset=endTimeExtensionOffset, scheduledRechargeNotificationProfileId=scheduledRechargeNotificationProfileId'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    apiName = 'subscriberModifyRechargeSchedule'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberModifyRechargeSchedule', status=retCode, msg=retText, shouldPass=eventPass)

    return (COMMON.debugSuccess(method='subscriberModifyRechargeSchedule', shouldPass=eventPass), responseMdc)

#=============================================================
def subscriberRemoveRechargeSchedule(V3inst=None, queryValue=None, queryType='ExternalId', now=None, eventPass=True, executeMode=None,
        apiEventData=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    paramString = 'queryType=queryType, queryValue=queryValue, now=now'
    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    apiName = 'subscriberRemoveRechargeSchedule'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberRemoveRechargeSchedule', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='subscriberRemoveRechargeSchedule', shouldPass=eventPass)

#=============================================================
def subscriberQueryRechargeSchedule(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.subscriberQueryRechargeSchedule(queryType=queryType, queryValue=queryValue, now=now)

    if not REST.checkResultSuccess(responseMdc):
         (retCode, retText) = REST.getResultStatus(responseMdc)
         return COMMON.debugFailure(method='subscriberQueryRechargeSchedule', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='subscriberQueryRechargeSchedule', shouldPass=eventPass):
         return responseMdc

#=============================================================
def subscriberQueryRecurringRecharge(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.subscriberQueryRecurringRecharge(queryType=queryType, queryValue=queryValue, now=now)

    if not REST.checkResultSuccess(responseMdc):
         (retCode, retText) = REST.getResultStatus(responseMdc)
         return COMMON.debugFailure(method='subscriberQueryRecurringRecharge', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='subscriberQueryRecurringRecharge', shouldPass=eventPass):
         return responseMdc

#=============================================================
def subscriberAddBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId', balanceResourceId=None,
        durationBeforeExpiryInMinutes=None, notificationProfileId=None, paymentMethodResourceId=None, rechargeAmount=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.subscriberAddBalanceExpiryRechargeDefn(queryType=queryType, queryValue=queryValue,
        balanceResourceId=balanceResourceId, durationBeforeExpiryInMinutes=durationBeforeExpiryInMinutes, notificationProfileId=notificationProfileId,
        paymentMethodResourceId=paymentMethodResourceId, rechargeAmount=rechargeAmount, now=now)

    if not REST.checkResultSuccess(responseMdc):
         (retCode, retText) = REST.getResultStatus(responseMdc)
         return COMMON.debugFailure(method='subscriberAddBalanceExpiryRechargeDefn', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='subscriberAddBalanceExpiryRechargeDefn', shouldPass=eventPass):
         return responseMdc

#=============================================================
def subscriberModifyBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId', balanceResourceId=None,
        durationBeforeExpiryInMinutes=None, notificationProfileId=None, paymentMethodResourceId=None, rechargeAmount=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryType=queryType, queryValue=queryValue, \
        balanceResourceId=balanceResourceId, durationBeforeExpiryInMinutes=durationBeforeExpiryInMinutes, notificationProfileId=notificationProfileId, \
        paymentMethodResourceId=paymentMethodResourceId, rechargeAmount=rechargeAmount, now=now'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    apiName = 'subscriberModifyBalanceExpiryRechargeDefn'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)
    if not REST.checkResultSuccess(responseMdc):
         (retCode, retText) = REST.getResultStatus(responseMdc)
         return COMMON.debugFailure(method='subscriberModifyBalanceExpiryRechargeDefn', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='subscriberModifyBalanceExpiryRechargeDefn', shouldPass=eventPass):
         return responseMdc

#=============================================================
def subscriberRemoveBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId', balanceResourceId=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryType=queryType, queryValue=queryValue, balanceResourceId=balanceResourceId, now=now'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    apiName = 'subscriberRemoveBalanceExpiryRechargeDefn'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
         (retCode, retText) = REST.getResultStatus(responseMdc)
         return COMMON.debugFailure(method='subscriberRemoveBalanceExpiryRechargeDefn', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='subscriberDeleteBalanceExpiryRechargeDefn', shouldPass=eventPass):
         return responseMdc

#=============================================================
def subscriberQueryBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId',
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.subscriberQueryBalanceExpiryRechargeDefn(queryType=queryType, queryValue=queryValue, now=now)

    if not REST.checkResultSuccess(responseMdc):
         (retCode, retText) = REST.getResultStatus(responseMdc)
         return COMMON.debugFailure(method='subscriberQueryBalanceExpiryRechargeDefn', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='subscriberQueryBalanceExpiryRechargeDefn', shouldPass=eventPass):
         return responseMdc

#=============================================================
def subscriberRefundPayment(V3inst=None, queryValue=None, queryType='PhoneNumber', resourceId=None, balanceResourceId=None,
        amount=None, reason=None, info=None, apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, amount=amount, resourceId=resourceId, \
                   reason=reason, now=now'

    for item in ['info', 'balanceResourceId', 'apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.subscriberRefundPayment(' + paramString + ')'
    #print 'subscriberRefundPayment: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberRefundPayment', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='subscriberRefundPayment', shouldPass=eventPass):
        return responseMdc

#=============================================================
def subscriberQueryPaymentHistory(V3inst=None, queryValue=None, queryType='PhoneNumber', now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.subscriberQueryPaymentHistory(queryType=queryType, queryValue=queryValue)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberQueryPaymentHistory', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='subscriberQueryPaymentHistory', shouldPass=eventPass):
        return responseMdc

#=============================================================
def subscriberModifyExternalPayment(V3inst=None, queryValue=None, queryType='ExternalId', 
        amount=None, resourceId=None, info=None, reason=None, opType=None,
        apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.subscriberModifyExternalPayment(queryType=queryType, queryValue=queryValue,
                            amount=amount, resourceId=resourceId, info=info, reason=reason, opType=opType,
                            apiEventData=apiEventData, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberModifyExternalPayment', status=retCode, msg=retText, shouldPass=eventPass)

#=============================================================
def subscriberQueryExternalPayment(V3inst=None, queryValue=None, queryType='ExternalId', now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.subscriberQueryExternalPayment(queryType=queryType, queryValue=queryValue)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberQueryExternalPayment', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='subscriberQueryExternalPayment', shouldPass=eventPass):
        return responseMdc

# Estimate the Subscribers Recurring Charge
#=============================================================
def subscriberEstimateRecurringCharge(V3inst, queryValue=None, queryType='ObjectId', now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.subscriberEstimateRecurringCharge(queryType=queryType, queryValue=queryValue, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberEstimateRecurringCharge', status=retCode, msg=retText, shouldPass=eventPass)

    return (COMMON.debugSuccess(method='subscriberEstimateRecurringCharge', shouldPass=eventPass), responseMdc)

#=============================================================
def groupAdjustBalance(V3inst=None, queryValue=None, balanceResourceId=None, componentMeterId=None, adjustType=None, amount=None,
        reason=None, queryType='PhoneNumber', info=None, endTime=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
        now=None, creditLimitPolicy=None, apiEventData=None, startTime=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    # Get function name
    fname = sys._getframe().f_code.co_name
    
    # Allow function to be called directoy from the command line
    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, balanceResourceId=balanceResourceId, adjustType=adjustType, amount=amount, reason=reason '
    
    # Build the command of additional parameters.
    for item in ['info', 'endTime', 'endTimeExtensionOffsetUnit', 'endTimeExtensionOffset', 'now', 'creditLimitPolicy',  \
                 'componentMeterId', 'startTime', 'apiEventData']:
           # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item
 
    # Execute the call
    cmd = 'V3inst.groupAdjustBalance(' + paramString + ')'
    #print 'groupAdjustBalance: cmd = ' + cmd
    responseMdc = eval(cmd)
    
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method=fname, status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method=fname, shouldPass=eventPass)

#=============================================================
def groupTransferBalance(V3inst=None, queryValue=None, queryType='PhoneNumber', balanceResourceId=None, amount=None, amountIsPct=False,
        targetSubscriberSearchData=None, targetGroupSearchData=None, targetQueryType='PhoneNumber', targetBalanceResourceId=None,
        sourceIsEventInitiator=None, creditFloorPolicy=None, reason=None, info=None,
        apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    if (targetSubscriberSearchData and targetQueryType != 'ObjectId'):
        targetSubscriberSearchData = REST.newSubscriberSearch(subscriberSearchName=targetQueryType, subscriberSearchId=targetSubscriberSearchData)

    if (targetGroupSearchData and targetQueryType != 'ObjectId'):
        targetGroupSearchData = REST.newGroupSearch(groupSearchName=targetQueryType, groupSearchId=targetGroupSearchData)

    paramString = 'queryType=queryType, queryValue=queryValue, balanceResourceId=balanceResourceId, amount=amount, \
                   amountIsPct=amountIsPct, targetSubscriberSearchData=targetSubscriberSearchData, targetGroupSearchData=targetGroupSearchData, \
                   targetBalanceResourceId=targetBalanceResourceId, sourceIsEventInitiator=sourceIsEventInitiator, creditFloorPolicy=creditFloorPolicy, \
                   reason=reason, info=info, now=now'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.groupTransferBalance(' + paramString + ')'
    #print 'groupTransferBalance: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupTransferBalance', status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method='groupTransferBalance', shouldPass=eventPass)

#=============================================================
def groupTopupBalance(V3inst=None, queryValue=None, balanceResourceId=None, amount=None, voucher=None,
        queryType='PhoneNumber', endTime=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
        apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryType=queryType, queryValue=queryValue, balanceResourceId=balanceResourceId, amount=amount, \
                   voucher=voucher, endTime=endTime, endTimeExtensionOffsetUnit=endTimeExtensionOffsetUnit,        \
                   endTimeExtensionOffset=endTimeExtensionOffset, now=now'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.groupTopupBalance(' + paramString + ')'
    #print 'groupTopupBalance: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupTopupBalance', status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method='groupTopupBalance', shouldPass=eventPass)

#=============================================================
def groupRecharge(V3inst=None, queryValue=None, amount=None, balanceResourceId=None, payNow=None, queryType='ExternalId',
        endTime=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None, paymentMethodResourceId=None, 
        paymentGatewayId=None, paymentGatewayOneTimeToken=None, info=None, reason=None, chargeMethodAttr=None, 
        paymentGatewayUserId=None, rechargeAttr=None,
        apiEventData=None, now=None, eventPass=True, executeMode=None, payload=True, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, amount=amount'

    # Build the command of additional parameters.
    nonce=paymentGatewayOneTimeToken
    if payload:
      for item in ['endTime', 'endTimeExtensionOffsetUnit', 'endTimeExtensionOffset', 'chargeMethodAttr', \
                     'paymentMethodResourceId', 'paymentGatewayId', 'nonce', 'info', 'reason', 'balanceResourceId', \
                     'payNow', 'now', 'paymentGatewayUserId', 'rechargeAttr', 'apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.groupRecharge(' + paramString + ')'
    #print 'groupRecharge: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupRecharge', status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method='groupRecharge', shouldPass=eventPass)

#=============================================================
def groupAddRechargeSchedule(V3inst=None, queryValue=None, firstRechargeTime=None, queryType='ExternalId',
        periodType=None, periodCoef=None, cycleTimeOfDay=None, cycleOffset=None,
        amount=None, paymentMethodResourceId=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
        scheduledRechargeNotificationProfileId=None, now=None, eventPass=True, executeMode=None,
        apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    cycleDefn = REST.newRechargeCycleData(periodType=periodType, periodCoef=periodCoef, cycleTimeOfDay=cycleTimeOfDay,
       cycleOffset=cycleOffset)

    paramString = 'queryType=queryType, queryValue=queryValue, firstRechargeTime=firstRechargeTime, cycleDefn = cycleDefn, \
        amount=amount, paymentMethodResourceId=paymentMethodResourceId, endTimeExtensionOffsetUnit=endTimeExtensionOffsetUnit, \
        endTimeExtensionOffset=endTimeExtensionOffset, scheduledRechargeNotificationProfileId=scheduledRechargeNotificationProfileId'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    apiName = 'groupAddRechargeSchedule'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupAddRechargeSchedule', status=retCode, msg=retText, shouldPass=eventPass)

    return (COMMON.debugSuccess(method='groupAddRechargeSchedule', shouldPass=eventPass), responseMdc)

#=============================================================
def groupModifyRechargeSchedule(V3inst=None, queryValue=None, nextRechargeTime=None, queryType='ExternalId',
        periodType=None, periodCoef=None, cycleTimeOfDay=None, cycleOffset=None,
        amount=None, paymentMethodResourceId=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
        scheduledRechargeNotificationProfileId=None, now=None, eventPass=True, executeMode=None,
        apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    if periodType or periodCoef or cycleTimeOfDay or cycleOffset:
       cycleDefn = REST.newRechargeCycleData(periodType=periodType, periodCoef=periodCoef, cycleTimeOfDay=cycleTimeOfDay,
       cycleOffset=cycleOffset)
    else:
        cycleDefn = None

    paramString = 'queryType=queryType, queryValue=queryValue, nextRechargeTime=nextRechargeTime, cycleDefn = cycleDefn, \
        amount=amount, paymentMethodResourceId=paymentMethodResourceId, endTimeExtensionOffsetUnit=endTimeExtensionOffsetUnit, \
        endTimeExtensionOffset=endTimeExtensionOffset, scheduledRechargeNotificationProfileId=scheduledRechargeNotificationProfileId'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    apiName = 'groupModifyRechargeSchedule'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupModifyRechargeSchedule', status=retCode, msg=retText, shouldPass=eventPass)

    return (COMMON.debugSuccess(method='groupModifyRechargeSchedule', shouldPass=eventPass), responseMdc)

#=============================================================
def groupRemoveRechargeSchedule(V3inst=None, queryValue=None, queryType='ExternalId', now=None, eventPass=True, executeMode=None,
        apiEventData=None, multiRequestBuild=None):

    global restVersion
    if now is not None:
        now = MDCTIME.convertTime(now, restVersion=restVersion)

    paramString = 'queryType=queryType, queryValue=queryValue, now=now'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    apiName = 'groupRemoveRechargeSchedule'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupRemoveRechargeSchedule', status=retCode, msg=retText,
            shouldPass=eventPass)

    return COMMON.debugSuccess(method='groupRemoveRechargeSchedule', shouldPass=eventPass)


#=============================================================
def groupQueryRechargeSchedule(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.groupQueryRechargeSchedule(queryType=queryType, queryValue=queryValue, now=now)

    if not REST.checkResultSuccess(responseMdc):
         (retCode, retText) = REST.getResultStatus(responseMdc)
         return COMMON.debugFailure(method='groupQueryRechargeSchedule', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='groupQueryRechargeSchedule', shouldPass=eventPass):
         return responseMdc

#=============================================================
def groupQueryRecurringRecharge(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.groupQueryRecurringRecharge(queryType=queryType, queryValue=queryValue, now=now)

    if not REST.checkResultSuccess(responseMdc):
         (retCode, retText) = REST.getResultStatus(responseMdc)
         return COMMON.debugFailure(method='groupQueryRecurringRecharge', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='groupQueryRecurringRecharge', shouldPass=eventPass):
         return responseMdc

#=============================================================
def groupAddBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId', balanceResourceId=None,
        durationBeforeExpiryInMinutes=None, notificationProfileId=None, paymentMethodResourceId=None, rechargeAmount=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None, apiEventSecurityInfo=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryType=queryType, queryValue=queryValue, \
        balanceResourceId=balanceResourceId, durationBeforeExpiryInMinutes=durationBeforeExpiryInMinutes, notificationProfileId=notificationProfileId, \
        paymentMethodResourceId=paymentMethodResourceId, rechargeAmount=rechargeAmount, now=now'

    # Build the command of additional parameters.
    for item in ['apiEventData', 'apiEventSecurityInfo']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    apiName = 'groupAddBalanceExpiryRechargeDefn'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)
    if not REST.checkResultSuccess(responseMdc):
         (retCode, retText) = REST.getResultStatus(responseMdc)
         return COMMON.debugFailure(method='groupAddBalanceExpiryRechargeDefn', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='groupAddBalanceExpiryRechargeDefn', shouldPass=eventPass):
         return responseMdc

#=============================================================
def groupModifyBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId', balanceResourceId=None,
        durationBeforeExpiryInMinutes=None, notificationProfileId=None, paymentMethodResourceId=None, rechargeAmount=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryType=queryType, queryValue=queryValue, \
        balanceResourceId=balanceResourceId, durationBeforeExpiryInMinutes=durationBeforeExpiryInMinutes, notificationProfileId=notificationProfileId, \
        paymentMethodResourceId=paymentMethodResourceId, rechargeAmount=rechargeAmount, now=now'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    apiName = 'groupModifyBalanceExpiryRechargeDefn'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
         (retCode, retText) = REST.getResultStatus(responseMdc)
         return COMMON.debugFailure(method='groupModifyBalanceExpiryRechargeDefn', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='groupModifyBalanceExpiryRechargeDefn', shouldPass=eventPass):
         return responseMdc

#=============================================================
def groupRemoveBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId', balanceResourceId=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryType=queryType, queryValue=queryValue, balanceResourceId=balanceResourceId, now=now'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    apiName = 'groupRemoveBalanceExpiryRechargeDefn'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
         (retCode, retText) = REST.getResultStatus(responseMdc)
         return COMMON.debugFailure(method='groupRemoveBalanceExpiryRechargeDefn', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='groupDeleteBalanceExpiryRechargeDefn', shouldPass=eventPass):
         return responseMdc

#=============================================================
def groupQueryBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId',
        now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.groupQueryBalanceExpiryRechargeDefn(queryType=queryType, queryValue=queryValue, now=now)

    if not REST.checkResultSuccess(responseMdc):
         (retCode, retText) = REST.getResultStatus(responseMdc)
         return COMMON.debugFailure(method='groupQueryBalanceExpiryRechargeDefn', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='groupQueryBalanceExpiryRechargeDefn', shouldPass=eventPass):
         return responseMdc

#=============================================================
def sysQueryConfigRecurringRecharge(V3inst, eventPass=True, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.sysQueryConfigRecurringRecharge()

    if not REST.checkResultSuccess(responseMdc):
         (retCode, retText) = REST.getResultStatus(responseMdc)
         return COMMON.debugFailure(method='sysQueryConfigRecurringRecharge', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='sysQueryConfigRecurringRecharge', shouldPass=eventPass):
         return responseMdc

#=============================================================
def groupRefundPayment(V3inst=None, queryValue=None, queryType='ExternalId', resourceId=None, balanceResourceId=None,
       amount=None, reason=None, info=None, apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
 

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, amount=amount, resourceId=resourceId, \
                   reason=reason, now=now'

    for item in ['info', 'balanceResourceId', 'apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.groupRefundPayment(' + paramString + ')'
    #print 'groupRefundPayment: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupRefundPayment', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='groupRefundPayment', shouldPass=eventPass):
        return responseMdc

#=============================================================
def groupQueryPaymentHistory(V3inst=None, queryValue=None, queryType='ExternalId', now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.groupQueryPaymentHistory(queryType=queryType, queryValue=queryValue)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupQueryPaymentHistory', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='groupQueryPaymentHistory', shouldPass=eventPass):
        return responseMdc

#=============================================================
def groupModifyExternalPayment(V3inst=None, queryValue=None, queryType='ExternalId',
        amount=None, resourceId=None, info=None, reason=None, opType=None,
        apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.groupModifyExternalPayment(queryType=queryType, queryValue=queryValue,
                            amount=amount, resourceId=resourceId, info=info, reason=reason, opType=opType,
                            apiEventData=apiEventData, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupModifyExternalPayment', status=retCode, msg=retText, shouldPass=eventPass)

#=============================================================
def groupQueryExternalPayment(V3inst=None, queryValue=None, queryType='ExternalId', now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.groupQueryExternalPayment(queryType=queryType, queryValue=queryValue)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupQueryExternalPayment', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='groupQueryExternalPayment', shouldPass=eventPass):
        return responseMdc

# Estimate the Groups Recurring Charge
#=============================================================
def groupEstimateRecurringCharge(V3inst, queryValue=None, queryType='ObjectId', now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.groupEstimateRecurringCharge(queryType=queryType, queryValue=queryValue, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupEstimateRecurringCharge', status=retCode, msg=retText, shouldPass=eventPass)

    return (COMMON.debugSuccess(method='groupEstimateRecurringCharge', shouldPass=eventPass), responseMdc)

#=============================================================
def groupAdjustRolloverBalance(V3inst=None, queryValue=None, reason=None, balanceResourceId=None,
           queryType='ExternalId', balanceIntervalId=None, adjustType=None, amount=None, info=None, remainingRolloverCounter=None,
           apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryType=queryType, queryValue=queryValue, reason=reason, \
                   balanceResourceId=balanceResourceId, balanceIntervalId=balanceIntervalId, adjustType=adjustType, amount=amount, info=info, \
                   remainingRolloverCounter=remainingRolloverCounter, now=now'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.groupAdjustRolloverBalance(' + paramString + ')'
    #print 'groupAdjustRolloverBalance: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupAdjustRolloverBalance', status=retCode, msg=retText, shouldPass=eventPass)

    return COMMON.debugSuccess(method='groupAdjustRolloverBalance', shouldPass=eventPass)

#=============================================================
def deleteGroup(V3inst, queryValue=None, queryType='ExternalId', now=None, eventPass=True, 
        apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryType=queryType, queryValue=queryValue, now=now'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
       # cmd = 'if ' + item + ' != None: paramString += \', ' + item + '=' + item + '\''
        if item !=None:
           paramString += ', ' + item + '=' + item
        #exec(cmd)

    # Execute the call
    apiName = 'groupDelete'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.' + apiName + '(' + paramString + ')'
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='deleteGroup', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='deleteGroup', shouldPass=eventPass):
        return responseMdc

#=============================================================
def deleteSubscriber(V3inst, queryValue=None, queryType='ExternalId', now=None, eventPass=True,
    deleteDevices=False, deleteSession=False, apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()
    
    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, now=now, deleteDevices=deleteDevices'
    
    # Build the command of additional parameters.
    for item in ['deleteSession', 'apiEventData']: 
           # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item
 
    # Execute the call
    cmd = 'V3inst.subscriberDelete(' + paramString + ')'
    #print 'subscriberDelete: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='deleteSubscriber', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='deleteSubscriber', shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryStatus(V3inst, now=None, eventPass=True, multiRequestBuild=None):
    
    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.pricingQueryStatus(now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryStatus', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryStatus', shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryOffer(V3inst, offerId, queryType='OfferId', version=None, now=None, eventPass=True, useCache=False, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.pricingQueryOffer(queryValue=offerId, queryType=queryType, version=version, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryOffer', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryOffer', shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryOfferList(V3inst, now=None, eventPass=True, globalList=False, multiRequestBuild=None):

    if V3inst == None:
       V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.pricingQueryOfferList(now,globalList=globalList)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryOfferList', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryOfferList', shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryBalance(V3inst, balanceId, queryType='BalanceId', now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.pricingQueryBalance(queryValue=balanceId, queryType=queryType, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryBalance', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryBalance', shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryBalanceList(V3inst, now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.pricingQueryBalanceList(now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryBalanceList', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryBalanceList', shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryLifecycle(V3inst, objectType, lifecycleProfileId=None, now=None, eventPass=True, useCache=False, multiRequestBuild=None):
    print('Life Cycle MDC - object type = ' + str(objectType))
    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.pricingQueryLifecycle(objectType, lifecycleProfileId=lifecycleProfileId, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryStatus', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryStatus', shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryServiceType(V3inst, queryType='ServiceTypeId', queryValue=None, now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.pricingQueryServiceType(queryType=queryType,queryValue=queryValue, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryServiceType', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryServiceType', shouldPass=eventPass):
        return responseMdc


#=============================================================
def pricingQueryServiceTypeList(V3inst, now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.pricingQueryServiceTypeList(now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryServiceTypeList', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryServiceTypeList', shouldPass=eventPass):
        return responseMdc


#=============================================================
def pricingQueryServiceContext(V3inst, serviceQueryType='ServiceTypeId', serviceQueryValue=None, contextQueryType='ContextId', contextQueryValue=None, now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.pricingQueryServiceContext(serviceQueryType=serviceQueryType, serviceQueryValue=serviceQueryValue, contextQueryType=contextQueryType,
                                           contextQueryValue=contextQueryValue, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryServiceContext', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryServiceContext', shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryBalanceClass(V3inst, queryType='BalanceClassId', queryValue=None, now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.pricingQueryBalanceClass(queryValue=queryValue,  queryType=queryType, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryBalanceClass', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryBalanceClass', shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryBalanceClassList(V3inst, now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.pricingQueryBalanceClassList(now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryBalanceClassList', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryBalanceClassList', shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryBalanceThresholdList(V3inst, queryType='BalanceId', queryValue=None, now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.pricingQueryBalanceThresholdList(queryValue=queryValue,  queryType=queryType, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryBalanceThresholdList', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryBalanceThresholdList', shouldPass=eventPass):
        return responseMdc


#=============================================================
def pricingQueryBillingCycle(V3inst, queryType='BillingCycleId', queryValue=None, now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.pricingQueryBillingCycle(queryValue=queryValue,  queryType=queryType, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryBillingCycle', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryBillingCycle', shouldPass=eventPass):
        return responseMdc


#=============================================================
def pricingQueryBillingCycleList(V3inst, now=None, eventPass=True, multiRequestBuild=None):
    
    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.pricingQueryBillingCycleList(now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryBillingCycleList', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryBillingCycleList', shouldPass=eventPass):
        return responseMdc

#=============================================================
def subscriberQueryCatalog(V3inst, queryValue=None, queryType=None, catalogQueryValue=None, catalogQueryType=None, now=None, eventPass=True, eligibilityFilter=True, filterName=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, catalogQueryType=catalogQueryType, catalogQueryValue=catalogQueryValue, now=now, eligibilityFilter=eligibilityFilter'

    # Build the command of additional parameters if any other new parameters added later
    """
    for item in [' '] :
        cmd = 'if ' + item + ' != None: paramString += \', ' + item + '=' + item + '\''
        exec(cmd)
    """
    # Execute the call
    apiName = 'subscriberQueryCatalog'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.'            + apiName + '(' + paramString + ')'

    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    #print responseMdc
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberQueryCatalog', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='subscriberQueryCatalog', shouldPass=eventPass):
        return responseMdc

#=============================================================
def deviceQueryCatalog(V3inst, queryValue=None, queryType=None, catalogQueryValue=None, catalogQueryType=None, now=None, eventPass=True, eligibilityFilter=True, filterName=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, catalogQueryType=catalogQueryType, catalogQueryValue=catalogQueryValue, now=now, eligibilityFilter=eligibilityFilter'

    # Build the command of additional parameters if any other new parameters added later
    """
    for item in [' '] :
        cmd = 'if ' + item + ' != None: paramString += \', ' + item + '=' + item + '\''
        exec(cmd)
    """
    # Execute the call
    apiName = 'deviceQueryCatalog'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.'            + apiName + '(' + paramString + ')'

    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    #print responseMdc
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='deviceQueryCatalog', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='deviceQueryCatalog', shouldPass=eventPass):
        return responseMdc

#=============================================================
def groupQueryCatalog(V3inst, queryValue=None, queryType=None, catalogQueryValue=None, catalogQueryType=None, now=None, eventPass=True, eligibilityFilter=True, filterName=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, catalogQueryType=catalogQueryType, catalogQueryValue=catalogQueryValue, now=now, eligibilityFilter=eligibilityFilter'

    # Build the command of additional parameters if any other new parameters added later
    """
    for item in [' '] :
        cmd = 'if ' + item + ' != None: paramString += \', ' + item + '=' + item + '\''
        exec(cmd)
    """
    # Execute the call
    apiName = 'groupQueryCatalog'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.'            + apiName + '(' + paramString + ')'

    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    #print responseMdc
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupQueryCatalog', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='groupQueryCatalog', shouldPass=eventPass):
        return responseMdc


#=============================================================
def subscriberQueryOneTimeOffer(V3inst, queryValue=None, queryType=None, now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, now=now'

    # Build the command of additional parameters if any other new parameters added later
    """
    for item in [' '] :
        cmd = 'if ' + item + ' != None: paramString += \', ' + item + '=' + item + '\''
        exec(cmd)
    """
    # Execute the call
    apiName = 'subscriberQueryOneTimeOffer'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.'            + apiName + '(' + paramString + ')'

    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    #print responseMdc
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberQueryOneTimeOffer', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='subscriberQueryOneTimeOffer', shouldPass=eventPass):
        return responseMdc

#=============================================================
def deviceQueryOneTimeOffer(V3inst, queryValue=None, queryType=None, now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, now=now'

    # Build the command of additional parameters if any other new parameters added later
    """
    for item in [' '] :
        cmd = 'if ' + item + ' != None: paramString += \', ' + item + '=' + item + '\''
        exec(cmd)
    """
    # Execute the call
    apiName = 'deviceQueryOneTimeOffer'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.'            + apiName + '(' + paramString + ')'

    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    #print responseMdc
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='deviceQueryOneTimeOffer', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='deviceQueryOneTimeOffer', shouldPass=eventPass):
        return responseMdc

#=============================================================
def groupQueryOneTimeOffer(V3inst, queryValue=None, queryType=None, now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, now=now'

    # Build the command of additional parameters if any other new parameters added later
    """
    for item in [' '] :
        cmd = 'if ' + item + ' != None: paramString += \', ' + item + '=' + item + '\''
        exec(cmd)
    """
    # Execute the call
    apiName = 'groupQueryOneTimeOffer'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.'            + apiName + '(' + paramString + ')'

    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    #print responseMdc
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupQueryOneTimeOffer', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='groupQueryOneTimeOffer', shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryCatalogItemList(V3inst, now=None, routingType=None, routingValue=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'routingValue=routingValue, routingType=routingType, now=now'

    # Build the command of additional parameters if any other new parameters added later
    """
    for item in [] :
        cmd = 'if ' + item + ' != None: paramString += \', ' + item + '=' + item + '\''
        exec(cmd)
    """
    # Execute the call
    apiName = 'pricingQueryCatalogItemList'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.'            + apiName + '(' + paramString + ')'
  
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)
    #print 'responseMdc = ' + str(responseMdc)


    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryCatalogItemList', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryCatalogItemList', shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryCatalogItem(V3inst, queryType=None, queryValue=None, now=None,
                            routingType=None, routingValue=None, eventPass=True, multiRequestBuild=None, catalogItemTime=None):

    if queryType != 'ExternalId':
        queryType = 'CatalogItemId'

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, routingValue=routingValue, routingType=routingType, now=now'

    # Build the command of additional parameters if any other new parameters added later
    for item in ['catalogItemTime'] :
            # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    apiName = 'pricingQueryCatalogItem'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.'            + apiName + '(' + paramString + ')'
  
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    #print responseMdc
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryCatalogItem', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryCatalogItem', shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryEventTypeList(V3inst, now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.pricingQueryEventTypeList(now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryEventTypeList', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryEventTypeList', shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryEventType(V3inst, queryType='EventTypeId', queryValue=None, now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.pricingQueryEventType(queryType=queryType, queryValue=queryValue, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryEventType', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryEventType', shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryRateTagList(V3inst, now=None, routingType=None, routingValue=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.pricingQueryRateTagList(now=now, routingType=routingType, routingValue=routingValue)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryRateTagList', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryRateTagList', shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryRateTag(V3inst, queryType='RateTagId', queryValue=None, now=None,
                            routingType=None, routingValue=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.pricingQueryRateTag(queryType=queryType, queryValue=queryValue, now=now,
                            routingType=routingType, routingValue=routingValue)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQuerRateTagId', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryRateTagId', shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryRoleList(V3inst, now=None, routingType=None, routingValue=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.pricingQueryRoleList(now=now, routingType=routingType, routingValue=routingValue)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryRoleList', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryRoleList', shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryRole(V3inst, queryType='ExternalId', queryValue=None, now=None,
                            routingType=None, routingValue=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.pricingQueryRole(queryType=queryType, queryValue=queryValue, now=now,
                            routingType=routingType, routingValue=routingValue)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQuerRole', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryRole', shouldPass=eventPass):
        return responseMdc

#------------------------------------------------------------
def findBalanceBy(balances, resourceId):
    for balance in balances:
        ResourceId = balance.getUsingKey(MDCDEFS.kMtxBalanceInfoResourceIdFldKey)
        if resourceId == balResourceId:
            return balance
    return None
#=============================================================
def findOffersResourceId(offerList):
    resourceIdList = []
    for offer in offerList:
        resourceId = offer.getUsingKey(MDCDEFS.kMtxPurchasedOfferResourceIdFldKey)
        resourceIdList.append(resourceId)
    return resourceIdList
#=============================================================
# This call returns the task ID of the scheduled task
def subscriberPurchaseOfferInFuture(V3inst, queryValue, offerId=None, purchaseStartTime=None,
                      offerStartTime=None, offerEndTime=None, eventPass=True, queryType='ExternalId', now=None, 
                      offerIsExternal=False, offerId2=None, attr=None,  skipVtime=False, dupAttr=True,
                      catalogItemId=None, multiRequestBuild=None):
    
    # Setup vtime local parameters
    if not skipVtime:
        vtimePrePurchase = MDCTIME.getTime(-1, 'day', purchaseStartTime)  #it doesn 't matter how far back - as long as it is earlier
        vtimePostPurchase = MDCTIME.getTime(1, 'day', purchaseStartTime)  #it doesn 't matter how far forward - as long as it is later
    else:
        # Clear vtime locals
        vtimePostPurchase = None
        vtimePrePurchase = None

    # Get MDC instance that doesn;t have a connection (so data won;t be sent)
    V3builder = QAUTILS.getSubscInterface(mode = 'BuildRequest')

    # Build the offer list
    if catalogItemId:
        offerId=catalogItemId

    offerList = []
    offerList = prepOfferAttr(offerId, offerIsExternal=offerIsExternal, offerStartTime=offerStartTime, 
                          offerEndTime=offerEndTime, attr=attr, offerList=offerList, offerId2=offerId2,
                          dupAttr=dupAttr, catalogItemId=catalogItemId)

    # Build the message
    purchaseMdc = V3builder.subscriberPurchaseOffer(queryType = queryType, queryValue = queryValue,
                            offerList = offerList,now=now)

    # Debug output
    #print 'purchaseMdc ', str(purchaseMdc)
    
    # Play with time if vtime parameter says to 
    if not skipVtime:
        MDCTIME.spoofTime(startTime=vtimePrePurchase, sleep=5)
    
        # Debug output
        #print 'vtimePrePurchase ',vtimePrePurchase
        #print 'purchaseStartTime ',purchaseStartTime
    
    # Schedule the task
    responseMdc = V3inst.taskCreate(taskTime=purchaseStartTime, taskRequest=purchaseMdc)

    #get task objectId
    # Debug output
    taskOid =  responseMdc.getUsingKey(MDCDEFS.kMtxResponseCreateObjectIdFldKey)    
    #print 'taskOid=',taskOid
    # Play with time if vtime parameter says to 
    if not skipVtime:
        MDCTIME.spoofTime(startTime=vtimePostPurchase, sleep =7)  #now task should have executed
        MDCTIME.clearSpoofTime()  #reset engine time

    ###  Should get the object ID of the scheduled task.  That's key to the response.

    # Return call task object Id
    return taskOid  

#=============================================================
# delete the task of future purchase offer
def subscriberCancelOfferInFuture(V3inst, cancelStartTime, queryType = 'ObjectId', queryValue = 0, resourceIdList = [], skipVtime = False, eventPass = True, multiRequestBuild=None):

    # Query type must be ObjectId
#    if queryType != 'ObjectId': sys.exit('subscriberCancelOfferInFuture: queryType must be "ObjectId"')
    
    # Cancel the scheduled task
    responseMdc = V3inst.taskDelete(queryValue = queryValue,  queryType = 'ObjectId', now=cancelStartTime)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberCancelOfferInFuture', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='subscriberCancelOfferInFuture', shouldPass=eventPass):
        return responseMdc

#=============================================================
#this call returns the last timsestamp that touched this subscriber
#TODO: add validation

def groupPurchaseOfferInFuture(V3inst, queryValue, offerId=None, purchaseStartTime=None, offerStartTime=None, 
              offerEndTime=None, eventPass=True, queryType='ExternalId', now=None, 
              offerIsExternal=False, skipVtime=False, attr=None, dupAttr=True, catalogItemId=None, multiRequestBuild=None):

    vtimePostPurchase = None

    if catalogItemId:
        offerId=catalogItemId

    offerList = []
    offerList = prepOfferAttr(offerId, offerIsExternal=offerIsExternal, offerStartTime=offerStartTime,
                          offerEndTime=offerEndTime, attr=attr, offerList=offerList, dupAttr=dupAttr,
                          catalogItemId=catalogItemId)
      
    if not skipVtime:
        vtimePrePurchase = MDCTIME.getTime(-1, 'day', purchaseStartTime)  #it doesn 't matter how far back - as long as it is earlier
        vtimePostPurchase = MDCTIME.getTime(1, 'day', purchaseStartTime)  #it doesn 't matter how far back - as long as it is earlier
    V3builder = QAUTILS.getSubscInterface(mode = 'BuildRequest')
    # Schedule a offer purchase for the subscriber.
    purchaseMdc = V3builder.groupPurchaseOffer(queryType = queryType, queryValue = queryValue,
                            offerList = offerList)
    if not skipVtime:
        MDCTIME.spoofTime(startTime=vtimePrePurchase, sleep=5)
    responseMdc = V3inst.taskCreate(taskTime=purchaseStartTime, taskRequest=purchaseMdc)

    #get task Object ID
    taskOid =  responseMdc.getUsingKey(MDCDEFS.kMtxResponseCreateObjectIdFldKey)
    #print 'taskOid=',taskOid
    if not skipVtime:
        MDCTIME.spoofTime(startTime=vtimePostPurchase, sleep = 5)  #now task should have executed
        MDCTIME.clearSpoofTime()  #reset engine time

    return taskOid  

#=============================================================
#this call delete the task for purchasing future offer
def groupCancelOfferInFuture(V3inst, cancelStartTime, queryType = 'ObjectId', queryValue = 0, resourceIdList = [], skipVtime = False, eventPass = True, multiRequestBuild=None):
    
    # Query type must be ObjectId
    if queryType != 'ObjectId': sys.exit('groupCancelOfferInFuture: queryType must be "ObjectId"')
    
    # Cancel the scheduled task
    responseMdc = V3inst.taskDelete(queryValue = queryValue,  queryType = queryType, now=cancelStartTime)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupCancelOfferInFuture', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='groupCancelOfferInFuture', shouldPass=eventPass):
        return responseMdc
  
#=============================================================
#this call send multiple requests in one REST call
#
def multiRequest(V3inst, requests, now=None, eventPass=True, routingType=None, routingValue=None):
    responseMdc = V3inst.multiRequest(requests, now, routingType, routingValue)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='multiRequest', status=retCode, msg=retText, shouldPass=eventPass)
    return COMMON.debugSuccess(method='multiRequest', shouldPass=eventPass)

#=============================================================
# this call sends multiple requests in one REST call and returns the response MDC (if success)
#
def multiRequestSaveResponse(V3inst, requests, now=None, eventPass=True, routingType=None, routingValue=None):
    responseMdc = V3inst.multiRequest(requests, now, routingType, routingValue)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return (COMMON.debugFailure(method='multiRequest', status=retCode, msg=retText, shouldPass=eventPass), responseMdc)
    return (COMMON.debugSuccess(method='multiRequest', shouldPass=eventPass), responseMdc)

#=============================================================
def querySubscriberEvent(V3inst, queryValue, queryType='ExternalId', deviceQueryType=None, deviceQueryValue=None,
    querySize=None, queryCursor=None, eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypeStringArray=None,  now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Ensure array is in fact an array
    if eventTypeStringArray:
        if type(eventTypeStringArray) is list:  eventTypeStringArray = [str(i) for i in eventTypeStringArray]
        else:                                   eventTypeStringArray = [str(eventTypeStringArray)]

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, now=now,\
                   deviceQueryType=deviceQueryType, querySize=querySize, queryCursor=queryCursor,\
                   deviceQueryValue=deviceQueryValue'

    # Build the command of additional parameters.
    for item in ['eventTimeLowerBound', 'eventTimeUpperBound', 'eventTypeStringArray']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.subscriberQueryEvent(' + paramString + ')'
    #print 'subscriberQueryEvent: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return (COMMON.debugFailure(method='querySubscriberEvent', status=retCode, msg=retText, shouldPass=eventPass), 0)

    if COMMON.debugSuccess(method='querySubscriberEvent', shouldPass=eventPass):
        cursor = responseMdc.getUsingKey(MDCDEFS.kMtxResponseEventInfoQueryCursorFldKey)
        return (responseMdc, cursor)

#=============================================================
def queryGroupEvent(V3inst, queryValue, queryType='ExternalId', querySize=None, queryCursor=None,
    eventTimeLowerBound=None, eventTimeUpperBound=None, now=None, eventTypeStringArray=None, eventPass=True, multiRequestBuild=None):
    
    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Ensure array is in fact an array
    if eventTypeStringArray:
        if type(eventTypeStringArray) is list:  eventTypeStringArray = [str(i) for i in eventTypeStringArray]
        else:                                   eventTypeStringArray = [str(eventTypeStringArray)]

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, querySize=querySize, queryCursor=queryCursor, now=now'
        
    # Build the command of additional parameters.
    for item in ['eventTimeLowerBound', 'eventTimeUpperBound', 'eventTypeStringArray' ]:
           # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item
 
    # Execute the call
    cmd = 'V3inst.groupQueryEvent(' + paramString + ')'
    #print 'groupQueryEvent: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return (COMMON.debugFailure(method='queryGroupEvent', status=retCode, msg=retText, shouldPass=eventPass), 0)

    if COMMON.debugSuccess(method='queryGroupEvent', shouldPass=eventPass):
        cursor = responseMdc.getUsingKey(MDCDEFS.kMtxResponseEventInfoQueryCursorFldKey)
        return (responseMdc, cursor)

#=============================================================
def queryDeviceAggregation(V3inst, queryValue, queryType='PhoneNumber', now=None, eventPass=True, multiRequestBuild=None):
    # Query the device.

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.deviceQueryAggregation(queryType=queryType, queryValue=queryValue, now=now)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='queryDeviceAggregation', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='queryDeviceAggregation', shouldPass=eventPass):
        #cursor = responseMdc.getUsingKey(MDCDEFS.kMtxResponseEventInfoQueryCursorFldKey)
        return responseMdc

#=============================================================
def querySubscriberAggregation(V3inst, queryValue, queryType='PhoneNumber', now=None, eventPass=True, multiRequestBuild=None):
    # Query the device.

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.subscriberQueryAggregation(queryType=queryType, queryValue=queryValue, now=now)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='querySubscriberAggregation', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='querySubscriberAggregation', shouldPass=eventPass):
        #cursor = responseMdc.getUsingKey(MDCDEFS.kMtxResponseEventInfoQueryCursorFldKey)
        return responseMdc


#=============================================================
def eventQuery(V3inst, queryValue, queryType='EventId', now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.eventQuery(queryType=queryType, queryValue=queryValue, now=now)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='queryEvent', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='queryEvent', shouldPass=eventPass):
        #cursor = responseMdc.getUsingKey(MDCDEFS.kMtxResponseEventInfoQueryCursorFldKey)
        return responseMdc


#=============================================================
def addSubscriberBatch(V3inst, batchSize, subExternalIdStartIndex, devExternalIdStartIndex, subscriberIdStartIndex, deviceIdStartIndex, deviceType, offerId, startTime=None, endTime=None, now = None, dateOffset=None, multiRequestBuild=None):
    V3builder = QAUTILS.getSubscInterface(mode = 'BuildRequest')
       
    requests = []
    offerList = []
    offerList.append({'ProductOfferId':offerId, 'StartTime':startTime, 'EndTime':None})
    for i in range (0,batchSize):
    
        deviceId = str(int(deviceIdStartIndex)+i)
        devExternalId = str(int(devExternalIdStartIndex)+i)
        subExternalId = str(int(subExternalIdStartIndex)+i)
        subscriberId =  str(int(subscriberIdStartIndex)+i)
        
        createSubscMdc = V3builder.subscriberCreate(externalId = subExternalId)
        
        deviceCreateMdc =  V3builder.deviceCreateMobile(externalId = devExternalId, imsi = deviceId, deviceType=deviceType)

        subscAddDeviceMdc = V3builder.subscriberAddDevice(
                       subQueryType = 'MultiRequestIndex', subQueryValue = i*4,
                       devQueryType = 'MultiRequestIndex', devQueryValue = (i*4)+1,
                       now = now)

        subscPurchaseOfferMdc = V3builder.subscriberPurchaseOffer(
                       queryType = 'MultiRequestIndex', queryValue = i*4,
                       offerList = offerList, now = now)

        requests = requests + [createSubscMdc, deviceCreateMdc, subscAddDeviceMdc, subscPurchaseOfferMdc]
    multiRequest(V3inst, requests = requests, now = now)

    
#=============================================================
def modifySubscriberBatch(V3inst, batchSize, queryValueStartIndex, eventPass=True, queryType='ExternalId', now=None,
        firstName=None, lastName=None, contactEmail=None, contactPhoneNumberStartIndex=None, notificationPreference=None,
        timeZone=None, attr=None, billingCycle=None, status=None, taxStatus=None, taxCertificate=None, taxLocation=None, language=None,
        externalIdStartIndex=None, dateOffset=None, multiRequestBuild=None, glCenter=None, billingCycleDisabled=None):
    V3builder = QAUTILS.getSubscInterface(mode = 'BuildRequest')

    requests = []
    for i in range (0,batchSize):
        if contactPhoneNumberStartIndex:
            contactPhoneNumber = str(int(contactPhoneNumberStartIndex)+i)
        else:
            contactPhoneNumber = None
        if externalIdStartIndex:
            externalId = str(int(externalIdStartIndex)+i)
        else:
            externalId = None

        #check if we passed a string for billingCycle and convert it to a billing cycle template
        if billingCycle:
            if type(billingCycle) is not data_container.DataContainer:
                billingCycle = createBillingCycleData(int(billingCycle), startTime=now, dateOffset=dateOffset)

        subscModifyMdc = V3builder.subscriberModify(queryType = queryType, queryValue = str(int(queryValueStartIndex)+i), now=now,
            firstName=firstName, lastName=lastName, contactEmail=contactEmail, contactPhoneNumber=contactPhoneNumber,
            notificationPreference=notificationPreference, timeZone=timeZone, attr=attr, billingCycle=billingCycle,
            status=status, taxStatus=taxStatus, taxCertificate=taxCertificate, taxLocation=taxLocation, language=language, externalId=externalId, glCenter=glCenter, billingCycleDisabled=billingCycleDisabled)
        requests = requests + [subscModifyMdc]
    
    multiRequest(V3inst, requests = requests, now = now)

#=============================================================
def querySubscriberBatch(V3inst, batchSize, queryValueStartIndex, queryType='ExternalId', querySize=None, eventPass=True, now=None, multiRequestBuild=None):
    V3builder = QAUTILS.getSubscInterface(mode = 'BuildRequest')
    requests = []

    for i in range (0,batchSize):
        subscQueryMdc = V3builder.subscriberQuery(queryType = queryType, queryValue = str(int(queryValueStartIndex)+i))
        requests = requests + [subscQueryMdc]

    multiResult = multiRequestSaveResponse(V3inst, requests = requests, now = now)
    return  QA_MDCDEFS.getMultiRequestResponseList(multiResult[1])

#=============================================================
def deleteSubscriberBatch(V3inst, queryValue, queryType='ExternalId', deleteDevices=False, eventPass=True, now=None, multiRequestBuild=None):

    if type(queryValue) == str :
        ids = queryValue.split(',')
    else :
        ids = queryValue

    if V3inst == None:
        V3builder = QAUTILS.getSubscInterfaceMDC(mode = 'BuildRequest')

    requests = []

    for i in ids:
        deleteSubMdc = V3builder.subscriberDelete(queryType = queryType, queryValue = i)
        requests.append(deleteSubMdc)

    if V3inst == None:
        restInst = QAUTILS.getSubscInterfaceMDC()
    multiResult = multiRequestSaveResponse(restInst, requests = requests, now = now)
    
    if V3inst == None:
        return multiResult[1].getUsingKey(MDCDEFS.kMtxResponseMultiResponseListFldKey)
    else: 
        return  QA_MDCDEFS.getMultiRequestResponseList(multiResult[1])

#=============================================================
def queryDeviceSession(V3inst, queryValue, queryType='Imsi', now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.deviceQuerySession(queryType=queryType, queryValue=queryValue, now=now)
    #print responseMdc 
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='queryDeviceSession', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='queryDeviceSession', shouldPass=eventPass):
        #print 'Returning data from queryDeviceSession'
        return responseMdc

#=============================================================
def validateDeviceSession(V3inst, queryValue, queryType='Imsi', sessionId=None, sessionType=None, now=None, eventPass=True, multiRequestBuild=None):
    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()
    
    # If session ID is just integers, then it needs the framework prefix
    if sessionId and sessionId.isdigit():
        # Need proper session prefix.  Usually nothing specified or Gy, so check that first.  Gy also a catch-all for invalid values.
        if not sessionType or sessionType == '1': sessionId = cd.GySessionIdPrefix + sessionId
        elif sessionType == '2':                  sessionId = cd.SySessionIdPrefix + sessionId
        elif sessionType == '3':                  sessionId = cd.GxSessionIdPrefix + sessionId
        elif sessionType == '4':                  sessionId = cd.RxSessionIdPrefix + sessionId
        else:
                print('WARNNING:  validateDeviceSession() invalid value passed in for sessionType: ' + str(sessionType) + '.  Defaulting to Gy.')
                sessionId = cd.GySessionIdPrefix + sessionId
    
    #print "=============: ", queryValue, sessionId, sessionType
    responseMdc = V3inst.deviceValidateSession(queryType=queryType, queryValue=queryValue, sessionId=sessionId, sessionType=sessionType, now=now)
    #print responseMdc 
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='validateDeviceSession', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='validateDeviceSession', shouldPass=eventPass):
        #print 'Returning data from validateDeviceSession'
        return responseMdc


#=============================================================
def deviceEvaluateSyPolicy(V3inst, queryValue ,queryType='Imsi',  now=None, eventPass=True, multiRequestBuild=None):
    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.deviceEvaluateSyPolicy(queryValue=queryValue,queryType=queryType, now=now)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='deviceEvaluateSyPolicy', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='deviceEvaluateSyPolicy', shouldPass=eventPass):
        return responseMdc

#=============================================================
def deviceEndAggregation(V3inst, queryValue, queryType, now=None, eventPass=True, multiRequestBuild=None):
    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.deviceEndAggregation(queryType=queryType, queryValue=queryValue, now=now)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='deviceEndAggregation', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='deviceEndAggregation', shouldPass=eventPass):
        return responseMdc


#=============================================================
def queryDeviceEvent(V3inst, queryValue, queryType='Imsi', queryCursor=None, querySize=None,
    eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypeStringArray=None, now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Ensure array is in fact an array
    if eventTypeStringArray:
        if type(eventTypeStringArray) is list:  eventTypeStringArray = [str(i) for i in eventTypeStringArray]
        else:                                   eventTypeStringArray = [str(eventTypeStringArray)]

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, querySize=querySize, queryCursor=queryCursor, now=now'
        
    # Build the command of additional parameters.
    for item in ['eventTimeLowerBound', 'eventTimeUpperBound', 'eventTypeStringArray' ]:
           # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item
 
    # Execute the call
    cmd = 'V3inst.deviceQueryEvent(' + paramString + ')'
    #print 'deviceQueryEvent: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return (COMMON.debugFailure(method='queryDeviceEvent', status=retCode, msg=retText, shouldPass=eventPass), 0)

    if COMMON.debugSuccess(method='queryDeviceEvent', shouldPass=eventPass):
        cursor = responseMdc.getUsingKey(MDCDEFS.kMtxResponseEventInfoQueryCursorFldKey)
        return (responseMdc, cursor)

#=============================================================
def deleteDeviceSession(V3inst, queryValue, queryType='Imsi', sessionIdList=None, sessionType=None, now=None, eventPass=True, multiRequestBuild=None):
    if V3inst == None: V3inst = QAUTILS.getSubscInterfaceMDC()
    
    # May need processing if parameter is defined
    if sessionIdList:
     # See if not a list
     if not type(sessionIdList) is list: sessionIdList = [sessionIdList]
    
     # If session ID is just integers, then it needs the framework prefix
     for i,sessionId in enumerate(sessionIdList):
      if sessionId and sessionId.isdigit():
        # Need proper session prefix.  Usually nothing specified or Gy, so check that first.  Gy also a catch-all for invalid values.
        if not sessionType or sessionType == '1': sessionId = cd.GySessionIdPrefix + sessionId
        elif sessionType == '2':                  sessionId = cd.SySessionIdPrefix + sessionId
        elif sessionType == '3':                  sessionId = cd.GxSessionIdPrefix + sessionId
        elif sessionType == '4':                  sessionId = cd.RxSessionIdPrefix + sessionId
        else:
                print('WARNNING:  deleteDeviceSession() invalid value passed in for sessionType: ' + str(sessionType) + '.  Defaulting to Gy.')
                sessionId = cd.GySessionIdPrefix + sessionId
    
        # Update list item    
        sessionIdList[i] = sessionId
    
    #print "=============: ", queryValue, sessionId, sessionType
    responseMdc = V3inst.deviceDeleteSession(queryType=queryType, queryValue=queryValue, sessionIdList=sessionIdList, sessionType=sessionType, now=now)
    #print responseMdc 
    
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='deleteDeviceSession', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='deleteDeviceSession', shouldPass=eventPass):
        #print 'Returning data from deleteDeviceSession'
        return responseMdc

#=============================================================
def queryNotificationProfile(V3inst, queryValue, queryType='NotificationProfileId', eventPass=True, multiRequestBuild=None):
    if V3inst == None: V3inst = QAUTILS.getSubscInterfaceMDC()

    #print "=============: ", queryValue, queryType, sessionType
    responseMdc = V3inst.notificationProfileQuery(queryType=queryType, queryValue=queryValue)
    #print responseMdc

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='queryNotificationProfile', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='queryNotificationProfile', shouldPass=eventPass):
        #print 'Returning data from deleteSubscriberSession'
        return responseMdc

#=============================================================
def subscriberRehome(V3inst, queryValue, queryType='ObjectId', routingType='RouteId', routingValue=2, eventPass=True,
        apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()
    
    routingType = getRoutingType(routingType)

    # Really shouldn't call this API with eventPass = False, as this is a multi-call API and we didn;t code failure handling at the start to manage this (bad code design by us...)
    if not eventPass:  sys.exit('ERROR: can\'t call subscriberRehome() with eventPass=False')
    
    # Prepare
    (responseMdc, rehomeCtxList, rehomeDataList, sourceDomainId) = subscriberRehomePrepare(V3inst, queryValue, queryType=queryType, eventPass=eventPass)
    #print 'rehomeCtxList = ' + str(rehomeCtxList) + ', rehomeDataList = ' + str(rehomeDataList)
    
    # Rehome
    databaseRehome(V3inst, rehomeCtxList, rehomeDataList, routingType=routingType, routingValue=routingValue, eventPass=eventPass)
    
    # Commit
    databaseRehomeCommit(V3inst, rehomeCtxList, routingType=routingType, routingValue=sourceDomainId, eventPass=eventPass)

    # Always return success at this point
    return True
   
#=============================================================
def userRehome(V3inst, queryValue, queryType='ObjectId', routingType='RouteId', routingValue=2, eventPass=True, 
        apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    routingType = getRoutingType(routingType)

    # Really shouldn't call this API with eventPass = False, as this is a multi-call API and we didn;t code failure handling at the start to manage this (bad code design by us...)
    if not eventPass:  sys.exit('ERROR: can\'t call userRehome() with eventPass=False')

    # Prepare
    (responseMdc, rehomeCtxList, rehomeDataList, sourceDomainId) = userRehomePrepare(V3inst, queryValue, queryType=queryType, eventPass=eventPass)
    #print 'rehomeCtxList = ' + str(rehomeCtxList) + ', rehomeDataList = ' + str(rehomeDataList)

    # Rehome
    databaseRehome(V3inst, rehomeCtxList, rehomeDataList, routingType=routingType, routingValue=routingValue, eventPass=eventPass)

    # Commit
    databaseRehomeCommit(V3inst, rehomeCtxList, routingType=routingType, routingValue=sourceDomainId, eventPass=eventPass)

    # Always return success at this point
    return True

#=============================================================
def deviceRehome(V3inst, queryValue, queryType='ObjectId', routingType='RouteId', routingValue=2, eventPass=True, 
        apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    routingType = getRoutingType(routingType)

    # Really shouldn't call this API with eventPass = False, as this is a multi-call API and we didn;t code failure handling at the start to manage this (bad code design by us...)
    if not eventPass:  sys.exit('ERROR: can\'t call deviceRehome() with eventPass=False')

    # Prepare
    (responseMdc, rehomeCtxList, rehomeDataList, sourceDomainId) = deviceRehomePrepare(V3inst, queryValue, queryType=queryType, eventPass=eventPass)
    #print 'rehomeCtxList = ' + str(rehomeCtxList) + ', rehomeDataList = ' + str(rehomeDataList)

    # Rehome
    databaseRehome(V3inst, rehomeCtxList, rehomeDataList, routingType=routingType, routingValue=routingValue, eventPass=eventPass)

    # Commit
    databaseRehomeCommit(V3inst, rehomeCtxList, routingType=routingType, routingValue=sourceDomainId, eventPass=eventPass)

    # Always return success at this point
    return True

#=============================================================
def groupRehome(V3inst, queryValue, queryType='ObjectId', routingType='RouteId', routingValue=2, eventPass=True, 
        apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    routingType = getRoutingType(routingType)

    # Really shouldn't call this API with eventPass = False, as this is a multi-call API and we didn;t code failure handling at the start to manage this (bad code design by us...)
    if not eventPass:  sys.exit('ERROR: can\'t call groupRehome() with eventPass=False')

    # Prepare
    (responseMdc, rehomeCtxList, rehomeDataList, sourceDomainId) = groupRehomePrepare(V3inst, queryValue, queryType=queryType, eventPass=eventPass)
    #print 'rehomeCtxList = ' + str(rehomeCtxList) + ', rehomeDataList = ' + str(rehomeDataList)

    # Rehome
    databaseRehome(V3inst, rehomeCtxList, rehomeDataList, routingType=routingType, routingValue=routingValue, eventPass=eventPass)

    # Commit
    databaseRehomeCommit(V3inst, rehomeCtxList, routingType=routingType, routingValue=sourceDomainId, eventPass=eventPass)

    # Always return success at this point
    return True
 
#=============================================================
# Get abbreviated routing type code based on user-friendly routing type argument
def getRoutingType(routingType):
    if routingType == 'RouteId':
        return 'RTID'
    elif routingType == 'ObjectId':
        return 'OBID'
    elif routingType == 'ExternalId':
        return 'EXID'
    elif routingType == 'Imsi':
        return 'IMSI'
    elif routingType == 'AccessNumber':
        return 'ACNM'
    elif routingType == 'LoginId':
        return 'LOGN'
    elif routingType == 'AccessId':
        return 'ACID'
    else:
        raise RuntimeError('ERROR: unknown routingType: %s' % routingType)

#=============================================================
# Prepare the rehoming of the subscriber
def subscriberRehomePrepare(V3inst, queryValue, queryType='ObjectId', eventPass='True', multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.subscriberRehomePrepare(queryType, queryValue)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberRehomePrepare', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='subscriberRehomePrepare', shouldPass=eventPass):
        rehomeCtxList = responseMdc.getUsingKey(MDCDEFS.kMtxResponseRehomeRehomeContextListFldKey)
        rehomeDataList = responseMdc.getUsingKey(MDCDEFS.kMtxResponseRehomeRehomeDataListFldKey)
        sourceDomainId = responseMdc.getUsingKey(MDCDEFS.kMtxResponseRouteIdFldKey)
        return (responseMdc, rehomeCtxList, rehomeDataList, sourceDomainId)

#=============================================================
# Prepare the rehoming of the user
def userRehomePrepare(V3inst, queryValue, queryType='ObjectId', eventPass='True', multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.userRehomePrepare(queryType, queryValue)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='userRehomePrepare', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='userRehomePrepare', shouldPass=eventPass):
        rehomeCtxList = responseMdc.getUsingKey(MDCDEFS.kMtxResponseRehomeRehomeContextListFldKey)
        rehomeDataList = responseMdc.getUsingKey(MDCDEFS.kMtxResponseRehomeRehomeDataListFldKey)
        sourceDomainId = responseMdc.getUsingKey(MDCDEFS.kMtxResponseRouteIdFldKey)
        return (responseMdc, rehomeCtxList, rehomeDataList, sourceDomainId)

#=============================================================
def deviceRehomePrepare(V3inst, queryValue, queryType='ObjectId', eventPass='True', multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.deviceRehomePrepare(queryType, queryValue)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='deviceRehomePrepare', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='deviceRehomePrepare', shouldPass=eventPass):
        rehomeCtxList = responseMdc.getUsingKey(MDCDEFS.kMtxResponseRehomeRehomeContextListFldKey)
        rehomeDataList = responseMdc.getUsingKey(MDCDEFS.kMtxResponseRehomeRehomeDataListFldKey)
        sourceDomainId = responseMdc.getUsingKey(MDCDEFS.kMtxResponseRouteIdFldKey)
        return (responseMdc, rehomeCtxList, rehomeDataList, sourceDomainId)

#=============================================================
def groupRehomePrepare(V3inst, queryValue, queryType='ObjectId', eventPass='True', multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.groupRehomePrepare(queryType, queryValue)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupRehomePrepare', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='groupRehomePrepare', shouldPass=eventPass):
        rehomeCtxList = responseMdc.getUsingKey(MDCDEFS.kMtxResponseRehomeRehomeContextListFldKey)
        rehomeDataList = responseMdc.getUsingKey(MDCDEFS.kMtxResponseRehomeRehomeDataListFldKey)
        sourceDomainId = responseMdc.getUsingKey(MDCDEFS.kMtxResponseRouteIdFldKey)
        return (responseMdc, rehomeCtxList, rehomeDataList, sourceDomainId)

#=============================================================
# Attempt to rehome the subscriber
def databaseRehome(V3inst, rehomeCtxList, rehomeDataList, routingType='RTID', routingValue=2, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc =  V3inst.databaseRehome(rehomeCtxList, rehomeDataList, routingType, routingValue)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='databaseRehome', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='databaseRehome', shouldPass=eventPass):
        return responseMdc

#=============================================================
# Commit subscriber rehoming
def databaseRehomeCommit(V3inst, rehomeCtxList, routingType='RTID', routingValue=2, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc =  V3inst.databaseRehomeCommit(rehomeCtxList, routingType, routingValue)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='databaseRehomeCommit', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='databaseRehomeCommit', shouldPass=eventPass):
        return responseMdc

#=============================================================
# Rollback the rehoming
def databaseRehomeRollback(V3inst, rehomeCtxList, routingType='RTID', routingValue=2, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc =  V3inst.databaseRehomeRollback(rehomeCtxList, routingType, routingValue)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='databaseRehomeRollback', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='databaseRehomeRollback', shouldPass=eventPass):
        return responseMdc

#=============================================================
# This call returns the task ID of the scheduled task
def devicePurchaseOfferInFuture(V3inst, queryValue, offerId=None, purchaseStartTime=None, offerStartTime=None, 
                      offerEndTime=None, eventPass=True, queryType='ExternalId', now=None, 
                      offerIsExternal=False, offerId2=None, attr=None,  skipVtime=False, dupAttr=True,
                      catalogItemId=None, multiRequestBuild=None, geoData=None):
    
    # Setup vtime local parameters
    if not skipVtime:
        vtimePrePurchase = MDCTIME.getTime(-1, 'day', purchaseStartTime)  #it doesn 't matter how far back - as long as it is earlier
        vtimePostPurchase = MDCTIME.getTime(1, 'day', purchaseStartTime)  #it doesn 't matter how far forward - as long as it is later
    else:
        # Clear vtime locals
        vtimePostPurchase = None
        vtimePrePurchase = None

    # Get MDC instance that doesn;t have a connection (so data won;t be sent)
    V3builder = QAUTILS.getSubscInterface(mode = 'BuildRequest')

    # Build the offer list
    if catalogItemId:
        offerId=catalogItemId

    offerList = []
    offerList = prepOfferAttr(offerId, offerIsExternal=offerIsExternal, offerStartTime=offerStartTime, 
                          offerEndTime=offerEndTime, attr=attr, offerList=offerList, offerId2=offerId2, dupAttr=dupAttr,
                          catalogItemId=catalogItemId)

    # Build the message
    purchaseMdc = V3builder.devicePurchaseOffer(queryType = queryType, queryValue = queryValue,
                            offerList = offerList,now=now)

    # Debug output
    #print 'purchaseMdc ', str(purchaseMdc)
    
    # Play with time if vtime parameter says to 
    if not skipVtime:
        MDCTIME.spoofTime(startTime=vtimePrePurchase, sleep=5)
    
        # Debug output
        #print 'vtimePrePurchase ',vtimePrePurchase
        #print 'purchaseStartTime ',purchaseStartTime
    
    # Schedule the task
    responseMdc = V3inst.taskCreate(taskTime=purchaseStartTime, taskRequest=purchaseMdc)

    #get task objectId
    # Debug output
    taskOid =  responseMdc.getUsingKey(MDCDEFS.kMtxResponseCreateObjectIdFldKey)    
    #print 'taskOid=',taskOid
    # Play with time if vtime parameter says to 
    if not skipVtime:
        MDCTIME.spoofTime(startTime=vtimePostPurchase, sleep =7)  #now task should have executed
        MDCTIME.clearSpoofTime()  #reset engine time

    ###  Should get the object ID of the scheduled task.  That's key to the response.

    # Return call task object Id
    return taskOid  

#=============================================================
# delete the task of future purchase offer
def deviceCancelOfferInFuture(V3inst, cancelStartTime, queryType = 'ObjectId', queryValue = 0, resourceIdList = [], skipVtime = False, eventPass = True, multiRequestBuild=None):

    # Query type must be ObjectId
    if queryType != 'ObjectId': sys.exit('deviceCancelOfferInFuture: queryType must be "ObjectId"')
    
    # Cancel the scheduled task
    responseMdc = V3inst.taskDelete(queryValue = queryValue,  queryType = queryType, now=cancelStartTime)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='deviceCancelOfferInFuture', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='deviceCancelOfferInFuture', shouldPass=eventPass):
        return responseMdc

#=============================================================
def querySubscriberEventstore(V3inst, queryValue, queryType='ExternalId', resultSize=None, deviceQueryType=None, deviceQueryValue=None,
    eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypes=None, notificationTypes=None, notification=False, searchInMemoryDatabase=None, applyDefaultFilter=True,
    routingType=None, routingValue=None, now=None, eventPass=True, multiRequestBuild=None, formatTime=None):
        # Not suported via MDC
        print('WARNING: event store logic not supported via MDC calling.  Use REST/JSON calls.  Invoking event query.')
        
        # Invoke event API
        (response, cursor) = querySubscriberEvent(V3inst, queryValue, queryType=queryType, querySize=resultSize, queryCursor=None,
                eventTimeLowerBound=eventTimeLowerBound, eventTimeUpperBound=eventTimeUpperBound, now=now, eventTypeStringArray=eventTypes, eventPass=eventPass)
        
        return response
        
#=============================================================
def queryDeviceEventstore(V3inst, queryValue, queryType='ExternalId', resultSize=None,
    eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypes=None, notificationTypes=None, notification=False,
    now=None, eventPass=True, multiRequestBuild=None):
        # Not suported via MDC
        print('WARNING: event store logic not supported via MDC calling.  Use REST/JSON calls.  Invoking event query.')
        
        # Invoke event API
        (response, cursor) = queryDeviceEvent(V3inst, queryValue, queryType=queryType, querySize=resultSize, queryCursor=None,
                eventTimeLowerBound=eventTimeLowerBound, eventTimeUpperBound=eventTimeUpperBound, now=now, eventTypeStringArray=eventTypes, eventPass=eventPass)
        
        return response
        
        
#=============================Y================================
def queryGroupEventstore(V3inst, queryValue, queryType='ExternalId', resultSize=None,
    eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypes=None, notificationTypes=None, notification=False, applyDefaultFilter=True,
    routingType=None, routingValue=None, now=None, eventPass=True, multiRequestBuild=None):
        # Not suported via MDC
        print('WARNING: event store logic not supported via MDC calling.  Use REST/JSON calls.  Invoking event query.')
        
        # Invoke event API
        (response, cursor) = queryGroupEvent(V3inst, queryValue, queryType=queryType, querySize=resultSize, queryCursor=None,
                eventTimeLowerBound=eventTimeLowerBound, eventTimeUpperBound=eventTimeUpperBound, now=now, eventTypeStringArray=eventTypes, eventPass=eventPass)
        
        return response


#=============================================================
def queryUserEventstore(V3inst, queryValue, queryType='ExternalId', resultSize=None, 
    eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypes=None, notificationTypes=None, notification=False, applyDefaultFilter=True,
    routingType=None, routingValue=None, now=None, eventPass=True, multiRequestBuild=None):
        # Not suported via MDC
        print('WARNING: event store logic not supported via MDC calling.  Use REST/JSON calls.  Invoking event query.')

        # Invoke event API
        (response, cursor) = queryUserEvent(V3inst, queryValue, queryType=queryType, querySize=resultSize, queryCursor=None,
          eventTimeLowerBound=eventTimeLowerBound, eventTimeUpperBound=eventTimeUpperBound, now=now, eventTypeStringArray=eventTypes, eventPass=eventPass)

        return response

        
#=============================Y================================
def querySubDomains(V3inst, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    response = V3inst.sysQueryDomain()

    return response

#=============================================================
def subscriberMakeFinanceContractPrincipalPayment(V3inst, queryValue, offerResourceId, queryType = 'ExternalId',
    isPayoff=True, extraPrincipalAmount=None, paymentMethodResourceId=None, chargeMethod=None,
    paymentGatewayId=None, nonce=None, chargeMethodAttr=None, reason=None, info=None,
    apiEventData=None, now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryValue=queryValue, offerResourceId=offerResourceId, queryType=queryType, \
                  isPayoff=isPayoff, extraPrincipalAmount=extraPrincipalAmount, paymentMethodResourceId=paymentMethodResourceId, chargeMethod=chargeMethod,\
                  paymentGatewayId=paymentGatewayId, nonce=nonce, chargeMethodAttr=chargeMethodAttr, reason=reason, info=info, now=now'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.subscriberMakeFinanceContractPrincipalPayment(' + paramString + ')'
    #print 'subscriberMakeFinanceContractPrincipalPayment: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberMakeFinanceContractPrincipalPayment', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='subscriberMakeFinanceContractPrincipalPayment', shouldPass=eventPass):
        return responseMdc

#=============================================================
def groupMakeFinanceContractPrincipalPayment(V3inst, queryValue, offerResourceId, queryType = 'ExternalId',
    isPayoff=True, extraPrincipalAmount=None, paymentMethodResourceId=None, chargeMethod=None,
    paymentGatewayId=None, nonce=None, chargeMethodAttr=None, reason=None, info=None,
    apiEventData=None, now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryValue=queryValue, offerResourceId=offerResourceId, queryType=queryType, \
                  isPayoff=isPayoff, extraPrincipalAmount=extraPrincipalAmount, paymentMethodResourceId=paymentMethodResourceId, chargeMethod=chargeMethod, \
                  paymentGatewayId=paymentGatewayId, nonce=nonce, chargeMethodAttr=chargeMethodAttr, reason=reason, info=info, now=now'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.groupMakeFinanceContractPrincipalPayment(' + paramString + ')'
    #print 'groupMakeFinanceContractPrincipalPayment: cmd = ' + cmd
    responseMdc = eval(cmd)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupMakeFinanceContractPrincipalPayment', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='groupMakeFinanceContractPrincipalPayment', shouldPass=eventPass):
        return responseMdc

#=============================================================
def subscriberContractDebtPayment(V3inst, queryValue, offerResourceId,
    amount, queryType = 'ExternalId', paymentMethodResourceId=None, chargeMethod=None, paymentGatewayId=None,
    nonce=None, chargeMethodAttr=None, reason=None, info=None,
    apiEventData=None, now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryValue=queryValue, offerResourceId=offerResourceId, \
                  amount=amount, queryType=queryType, paymentMethodResourceId=paymentMethodResourceId, chargeMethod=chargeMethod, \
                  paymentGatewayId=paymentGatewayId, nonce=nonce, chargeMethodAttr=chargeMethodAttr, reason=reason, info=info, now=now'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.subscriberContractDebtPayment(' + paramString + ')'
    #print 'subscriberContractDebtPayment: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberContractDebtPayment', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='subscriberContractDebtPayment', shouldPass=eventPass):
        return responseMdc

#=============================================================
def deviceContractDebtPayment(V3inst, queryValue, offerResourceId,
    amount, queryType = 'PhoneNumber', paymentMethodResourceId=None, chargeMethod=None, paymentGatewayId=None,
    nonce=None, chargeMethodAttr=None, reason=None, info=None,
    apiEventData=None, now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryValue=queryValue, offerResourceId=offerResourceId, \
                  amount=amount, queryType=queryType, paymentMethodResourceId=paymentMethodResourceId, chargeMethod=chargeMethod, \
                  paymentGatewayId=paymentGatewayId, nonce=nonce, chargeMethodAttr=chargeMethodAttr, reason=reason, info=info, now=now'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.deviceContractDebtPayment(' + paramString + ')'
    #print 'deviceContractDebtPayment: cmd = ' + cmd

    responseMdc = eval(cmd)
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='deviceContractDebtPayment', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='deviceContractDebtPayment', shouldPass=eventPass):
        return responseMdc

#=============================================================
def groupContractDebtPayment(V3inst, queryValue, offerResourceId,
    amount, queryType = 'ExternalId', paymentMethodResourceId=None, chargeMethod=None, paymentGatewayId=None,
    nonce=None, chargeMethodAttr=None, reason=None, info=None, now=None, eventPass=True, apiEventData=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryValue=queryValue, offerResourceId=offerResourceId, \
                  amount=amount, queryType=queryType, paymentMethodResourceId=paymentMethodResourceId, chargeMethod=chargeMethod, \
                  paymentGatewayId=paymentGatewayId, nonce=nonce, chargeMethodAttr=chargeMethodAttr, reason=reason, info=info, now=now'

    # Build the command of additional parameters.
    for item in ['apiEventData']:
        # Command pulls in non-None parameters into paramString
        cmd = '_a = \', ' + item + '=' + item + '\' if ' + item + ' != None else None'
        #print('cmd =', cmd)
        exec(cmd)
        item = locals()['_a']
        if item != None: paramString += item

    # Execute the call
    cmd = 'V3inst.groupContractDebtPayment(' + paramString + ')'
    #print 'groupContractDebtPayment: cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupContractDebtPayment', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='groupContractDebtPayment', shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryContractList(V3inst, routingType=None, routingValue=None, now=None, eventPass=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.pricingQueryContractList(routingType=routingType, routingValue=routingValue, now=now)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryContractList', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryContractList', shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryContract(V3inst, queryValue, queryType='ContractId', routingType=None, routingValue=None, now=None, eventPass = True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    responseMdc = V3inst.pricingQueryContract(queryValue=queryValue, queryType=queryType, routingType=routingType,
                  routingValue=routingValue, now=now)

    if COMMON.debugSuccess(method='pricingQueryContract', shouldPass=eventPass):
        return responseMdc


#=============================================================
def subscriberQueryCatalogItemList(V3inst, queryValue=None, queryType=None, now=None, eventPass=True,
                             eligibilityFilter=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, now=now, eligibilityFilter=eligibilityFilter'

    # Build the command of additional parameters if any other new parameters added later
    """
    for item in [' '] :
        cmd = 'if ' + item + ' != None: paramString += \', ' + item + '=' + item + '\''
        exec(cmd)
    """
    # Execute the call
    apiName = 'subscriberQueryCatalogItemList'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.'            + apiName + '(' + paramString + ')'
  
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    #print responseMdc
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='subscriberQueryCatalogItemList', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='subscriberQueryCatalogItemList', shouldPass=eventPass):
        return responseMdc

#=============================================================
def deviceQueryCatalogItemList(V3inst, queryValue=None, queryType=None, now=None, eventPass=True, eligibilityFilter=True,  multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, now=now, eligibilityFilter=eligibilityFilter'

    # Build the command of additional parameters if any other new parameters added later
    """
    for item in [' '] :
        cmd = 'if ' + item + ' != None: paramString += \', ' + item + '=' + item + '\''
        exec(cmd)
    """
    # Execute the call
    apiName = 'deviceQueryCatalogItemList'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.'            + apiName + '(' + paramString + ')'
  
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='deviceQueryCatalogItemList', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='deviceQueryCatalogItemList', shouldPass=eventPass):
        return responseMdc

#=============================================================
def groupQueryCatalogItemList(V3inst, queryValue=None, queryType=None, now=None, eventPass=True, eligibilityFilter=True, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, now=now, eligibilityFilter=eligibilityFilter'

    # Build the command of additional parameters if any other new parameters added later
    """
    for item in [' '] :
        cmd = 'if ' + item + ' != None: paramString += \', ' + item + '=' + item + '\''
        exec(cmd)
    """
    # Execute the call
    apiName = 'groupQueryCatalogItemList'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.'            + apiName + '(' + paramString + ')'
  
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='groupQueryCatalogItemList', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='groupQueryCatalogItemList', shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryCatalogList(V3inst, eventPass=True, now=None, routingType=None, routingValue=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'routingValue=routingValue, routingType=routingType, now=now'

    # Build the command of additional parameters if any other new parameters added later
    """
    for item in [''] :
        cmd = 'if ' + item + ' != None: paramString += \', ' + item + '=' + item + '\''
        exec(cmd)
    """
    # Execute the call
    apiName = 'pricingQueryCatalogList'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.'            + apiName + '(' + paramString + ')'
  
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    #print responseMdc.printXml()
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryCatalogList', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryCatalogList', shouldPass=eventPass):
        return responseMdc


#=============================================================
def pricingQueryCatalog(V3inst, queryValue=None, queryType='CatalogId', eventPass=True, now=None, routingType=None, routingValue=None, multiRequestBuild=None):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, routingValue=routingValue, routingType=routingType, now=now'

    # Build the command of additional parameters if any other new parameters added later
    """
    for item in [' '] :
        cmd = 'if ' + item + ' != None: paramString += \', ' + item + '=' + item + '\''
        exec(cmd)
    """
    # Execute the call
    apiName = 'pricingQueryCatalog'
    if multiRequestBuild:       cmd = 'multiRequestBuild.' + apiName + '(' + paramString + ')'
    else:                       cmd = 'V3inst.'            + apiName + '(' + paramString + ')'
  
    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    #print responseMdc.printXml()
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryCatalog', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryCatalog', shouldPass=eventPass):
        return responseMdc


#=============================================================
def queryPricingStatus(V3inst, now=None, routingType=None, routingValue=None, eventPass=True):

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'routingValue=routingValue, routingType=routingType, now=now'

    # Build the command of additional parameters if any other new parameters added later
    """
    for item in [' '] :
        cmd = 'if ' + item + ' != None: paramString += \', ' + item + '=' + item + '\''
        exec(cmd)
    """
    # Execute the call
    apiName = 'pricingQueryStatus'
    cmd = 'V3inst.' + apiName + '(' + paramString + ')'

    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    print(responseMdc.printXml())
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryStatus', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryStatus', shouldPass=eventPass):
        return responseMdc


#=============================================================
def pricingQueryContractPaymentScheduleList(V3inst, eventPass=True, now=None, routingType=None, routingValue=None, multiRequestBuild=None):
    global restVersion

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'routingValue=routingValue, routingType=routingType, now=now'

    # Build the command of additional parameters if any other new parameters added later
    """
    for item in [' '] :
        cmd = 'if ' + item + ' != None: paramString += \', ' + item + '=' + item + '\''
        exec(cmd)
    """
    # Execute the call
    apiName = 'pricingQueryContractPaymentScheduleList'
    cmd = 'V3inst.' + apiName + '(' + paramString + ')'

    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    print(responseMdc.printXml())
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryContractPaymentScheduleList', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryContractPaymentScheduleList', shouldPass=eventPass):
        return responseMdc


#=============================================================
def pricingQueryContractPaymentSchedule(V3inst, queryValue=None, queryType='ContractPaymentScheduleId', eventPass=True, now=None, routingType=None, routingValue=None, multiRequestBuild=None):
    global restVersion

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'queryType=queryType, queryValue=queryValue, routingValue=routingValue, routingType=routingType, now=now'

    # Build the command of additional parameters if any other new parameters added later
    """
    for item in [' '] :
        cmd = 'if ' + item + ' != None: paramString += \', ' + item + '=' + item + '\''
        exec(cmd)
    """
    # Execute the call
    apiName = 'pricingQueryContractPaymentSchedule'
    cmd = 'V3inst.' + apiName + '(' + paramString + ')'

    #print apiName + ': cmd = ' + cmd
    responseMdc = eval(cmd)

    print(responseMdc.printXml())
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryContractPaymentSchedule', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryContractPaymentSchedule', shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryTenantList(V3inst,  now=None, routingType=None, routingValue=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Execute the call
    apiName = 'pricingQueryTenantList'
    cmd = 'V3inst.' + apiName + '()'

    #print (apiName + ': cmd = ' + cmd)
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryTenantList', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryTenantList', shouldPass=eventPass):
        return responseMdc

#=============================================================
def pricingQueryTenant(V3inst,  queryType='TenantId', queryValue=None, now=None, routingType=None, routingValue=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'queryType, queryValue, routingValue=routingValue, routingType=routingType, now=now'

    # Execute the call
    apiName = 'pricingQueryTenant'
    cmd = 'V3inst.' + apiName + '(' + paramString + ')'

    #print (apiName + ': cmd = ' + cmd)
    responseMdc = eval(cmd)

    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='pricingQueryTenant', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='pricingQueryTenant', shouldPass=eventPass):
        return responseMdc

#=============================================================
def taxQueryProductGroupList(V3inst,  now=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Execute the call
    apiName = 'taxQueryProductGroupList'
    cmd = 'V3inst.' + apiName + '()'

    print (apiName + ': cmd = ' + cmd)
    responseMdc = eval(cmd)

    print(responseMdc.printXml())
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='taxQueryProductGroupList', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='taxQueryProductGroupList', shouldPass=eventPass):
        return responseMdc

#=============================================================
def taxQueryProductItemList(V3inst,  productGroup=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    paramString = 'productGroup=productGroup'
    # Execute the call
    apiName = 'taxQueryProductItemList'
    cmd = 'V3inst.' + apiName + '(' + paramString + ')'

    print (apiName + ': cmd = ' + cmd)
    responseMdc = eval(cmd)

    print(responseMdc.printXml())
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='taxQueryProductItemList', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='taxQueryProductItemList', shouldPass=eventPass):
        return responseMdc

#=============================================================
def taxQueryCustomerTypeList(V3inst,  now=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Execute the call
    apiName = 'taxQueryCustomerTypeList'
    cmd = 'V3inst.' + apiName + '()'

    print (apiName + ': cmd = ' + cmd)
    responseMdc = eval(cmd)

    print(responseMdc.printXml())
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='taxQueryCustomerTypeList', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='taxQueryCustomerTypeList', shouldPass=eventPass):
        return responseMdc

#=============================================================
def taxQueryExemptionCodeList(V3inst,  now=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Execute the call
    apiName = 'taxQueryExemptionCodeList'
    cmd = 'V3inst.' + apiName + '()'

    print (apiName + ': cmd = ' + cmd)
    responseMdc = eval(cmd)

    print(responseMdc.printXml())
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='taxQueryExemptionCodeList', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='taxQueryExemptionCodeList', shouldPass=eventPass):
        return responseMdc

#=============================================================
def taxQueryStatus(V3inst,  now=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Execute the call
    apiName = 'taxQueryStatus'
    cmd = 'V3inst.' + apiName + '()'

    print (apiName + ': cmd = ' + cmd)
    responseMdc = eval(cmd)

    print(responseMdc.printXml())
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='taxQueryStatus', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='taxQueryStatus', shouldPass=eventPass):
        return responseMdc

#=============================================================
def taxQueryGeoCode(V3inst,  postalCode=None, plus4=None, npa=None, nxx=None, timeZone=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    # Define baseline parameters - good from day 1
    paramString = 'postalCode=postalCode, plus4=plus4, npa=npa, nxx=nxx, timeZone=timeZone, now=now'

    # Build the command of additional parameters if any other new parameters added later
    """
    for item in [' '] :
        cmd = 'if ' + item + ' != None: paramString += \', ' + item + '=' + item + '\''
        exec(cmd)
    """

    # Execute the call
    apiName = 'taxQueryGeoCode'
    cmd = 'V3inst.' + apiName + '(' + paramString + ')'

    print (apiName + ': cmd = ' + cmd)
    responseMdc = eval(cmd)

    print(responseMdc.printXml())
    if not REST.checkResultSuccess(responseMdc):
        (retCode, retText) = REST.getResultStatus(responseMdc)
        return COMMON.debugFailure(method='taxQueryGeoCode', status=retCode, msg=retText, shouldPass=eventPass)

    if COMMON.debugSuccess(method='taxQueryGeoCode', shouldPass=eventPass):
        return responseMdc


#=============================================================
def createServiceAddressData(streetAddr=None, extendedAddr=None, locality=None, region=None, postalCode=None, extendedPostalCode=None, countryCode=None):


    paramString = 'streetAddr=streetAddr, extendedAddr=extendedAddr, locality=locality, region=region, postalCode=postalCode, extendedPostalCode=extendedPostalCode, countryCode=countryCode'

    # Execute the call
    apiName ='newServiceAddressData'
    cmd = 'REST.' + apiName + '(' + paramString + ')'
    print ('createServiceAddressData: cmd = ' + cmd)
    serviceAddressMdc = eval(cmd)

    if not serviceAddressMdc:
        return False

    return serviceAddressMdc


#=============================================================
def createGeoData(geoCode=None, postalCode=None, plus4=None, npa=None, nxx=None):

    paramString = 'geoCode=geoCode, postalCode=postalCode, plus4=plus4, npa=npa, nxx=nxx'

    
    # Execute the call
    apiName ='newGeoData'
    cmd = 'REST.' + apiName + '(' + paramString + ')'
    print ('geodataMdc: cmd = ' + cmd)
    geodataMdc = eval(cmd)

    if not geodataMdc:
        return False

    return geodataMdc 
 
 
#==========================================================================================================
#add getSubscInterfaceMDC() interface to allow api to run from cmd line
#example 1: to cancel offer of group via api : groupUnsubscribeFromOffer(None,107139,1),specify  V3inst to None
#                                         to call the getSubscInterfaceMDC()
#command to run from command line : python -c 'import mdcV3;mdcV3.groupUnsubscribeFromOffer(None,107139,1)'
#command to run from command line : python -c 'import mdcV3;mdcV3.unsubscribeFromOffer(None,123,1)'
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

