#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:41:20
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:37:01
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:19
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


# from builtins import str
# from builtins import str
import optparse
import os, sys
import fcntl

# Linux file separator character
global pathSepChar
pathSepChar = '/'
    
# Root directory for configuration files
global basePath
basePath = os.path.expandvars('$QADIR/')
    
# Script input separator (e.g. --engine QA.hp1)
global inputSepChar
inputSepChar = '.'

# Default customer
defaultCustomer = 'QA'
    
#===============================================================================
def initializeTest():
        # Define usage string (output if --help is input)
        usage = '''%prog <optional parameters>

Parameter values are formatted as "a.b.c.d".
"a" can be the customer or a directory under the parameter type.
If the app parameter specifies a directory, then that becomes the default directory.  Otherwise the tool's default customer is used.
The default directory will be used for all optional parameters unless that parameter provides a customer value in the "a" position.
'''
        
        # Define options
        parser = optparse.OptionParser(usage=usage)
        parser.add_option("-a", "--app", action='store', type='string', default='', help='application identifiers (e.g. QA)')
        parser.add_option("-e", "--engine", action='store', type='string', default='', help='engine identifiers (e.g. QA.hp1)')
        parser.add_option("-t", "--testing", action='store', type='string', default='func', help='testing identifiers (e.g. QA.func)')
        parser.add_option("-s", "--site", action='store', type='string', default='vm', help='site identifiers (e.g. QA)')
        parser.add_option("-f", "--file", action='store', type='string', default='', help='file name')
        parser.add_option("-o", "--override", action='store', type='string', default='', help='override identifiers (e.g. QA.local)')
        parser.add_option("-u", "--selectiveUpdate", action='store', type='string', default='', help='selective update identifiers (e.g. QA)')
        parser.add_option("-n", "--testSuiteName", action='store', type='string', default='', help='QA test suite identifier (e.g. vtime)')
        parser.add_option("", "--skipMultiCast", action='store_true', type=None, default=False, help='Skip multi-cast updates when creating the config')
        parser.add_option("-H", "--notificationHost", action='store', type='string', default='', help='the host ip that runs activeMQ_connector, notifier')
        parser.add_option("--notify", action='store', type='string', default='',help="email address you wish to notify when tests finish")

        # Process command line params
        (options, args) = parser.parse_args()

        # Return input structure
        return(options, args)

#===============================================================================
def getPath(customer, item, dirString):
    # Check for item directory.  Tricky for this, as the item may include the customer or may want to use the default customer.
    # Try both, with the input alone tried first (in case it has the customer specified).

    # If nothing input for the item, then use customer
    if not item: item = customer
    
    # Get first part of the input item parameter
    itemFirstPart = item.partition(inputSepChar)[0]

    # Grab everything except the first part, with input separators replaced with path separators
    inputPath = item.partition(inputSepChar)[2].replace(inputSepChar, pathSepChar)
    
    # Add leading/trailing path separators to input string (for directory checks)
    dirStringPath = pathSepChar + dirString + pathSepChar

    # Setup path checked list
    pathList = []

    # Check #1: does the item specify everything (customer + underlying directories)
    _path = basePath + itemFirstPart + '/Configuration' + dirStringPath + inputPath
        
    # Add to tried directories
    pathList.append(_path)
    
    # See if the directory exists
    if os.path.isdir(pathList[0]): PathToUse = pathList[0]
    else:
        # OK, that didn't work.
        # Check #2: try is using the customer and adding the engine list as part of the underlying path
        _path = basePath + customer + '/Configuration' + dirStringPath + itemFirstPart + pathSepChar + inputPath
        
        # Add to tried directories
        pathList.append(_path)
        
        # See if the directory exists
        if os.path.isdir(pathList[1]): PathToUse = pathList[1]
        else:
                # This also didn't work.  Fail the request
                print('ERROR: ' + dirString + ' path of "' + str(pathList) + '" does not exist.  Aborting.')
                sys.exit(1)

    # Remove any/all trailing directory characters, as the commands invoked don't want any of these trailing
    return PathToUse.rstrip(pathSepChar)

#==========================================================

def processInput(options, defCustomer):
    # Get customer.  If nothing input, then use environment variable, else use default customer
    if not options.app:
        # Default customer already guaranteed to be the desired value
        customer = defCustomer
    else:
        # Use what was input
        customer = options.app.split(inputSepChar)[0]
    
    # Get customer path
    customerPath = basePath + customer + pathSepChar

    # Very simple first check.  If first item in the app list is NOT a directory in the
    # base dir, then assume default customer
    if not os.path.isdir(customerPath):
        # 
        # Assume default customer (only chance this has of working...)
        print('NOTE:  directory "' + customerPath + '" does not exist.  Assuming default customer ' + defCustomer)
    
        # Reset customer and customer path
        customer = defCustomer
        customerPath = basePath + customer + pathSepChar

    ###### Get paths ######
    appPathToUse    = getPath(customer, options.app, 'app')
    enginePathToUse = getPath(customer, options.engine, 'config_engine')
    sitePathToUse   = getPath(customer, options.site, 'config_site')
    testPathToUse   = getPath(customer, options.testing, 'Testing')
    overridePathToUse   = getPath(customer, options.override, 'override')
    selUpdPathToUse     = getPath(customer, options.selectiveUpdate, 'selective_updates')

    # Print what we have for paths
    print('Customer is ' + customer)
    print('Paths are:\n'+ appPathToUse + '\n' + enginePathToUse + '\n' + sitePathToUse + '\n' + testPathToUse + '\n' + selUpdPathToUse + '\n' + overridePathToUse)

    # Execute create_config command
    cmd =  'create_config.py'
    cmd += ' -i ' + enginePathToUse 
    cmd += ' -i ' + sitePathToUse
    cmd += ' -i ' + appPathToUse
    cmd += ' -i ' + selUpdPathToUse
    cmd += ' -i ' + testPathToUse
    cmd += ' -i ' + overridePathToUse
    cmd += ' --use_default_values'
    print('\n\nCommand is: ' + cmd)
    os.system(cmd)

    # Execute command to update multi-cast address
    if not options.skipMultiCast:
        cmd = 'sh set_multicast.sh ' + customer + ' ' + options.testSuiteName
        print('\n\nCommand is: ' + cmd)
        os.system(cmd)

    # All Done!
    return customer
    
#==========================================================

def main():
    # Overwrite default customer if environment variable is set
    if os.path.expandvars('$customer'): 
        defCustomer = os.path.expandvars('$customer')
    else:
        defCustomer = defaultCustomer
    
    # Process input args
    (options, args) = initializeTest()
    
    # Process the inputs
    processInput(options, defCustomer)

if __name__ == '__main__':
    main()

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
