#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:35:36
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:35:36
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:35:35
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
from __future__ import print_function
import sys, time, string
import qa_utils as QAUTILS

#==========================================================
def CmdGl_cleargldata(lclDCT, options, line):
        # *** lclDCT[] has all the values.
        
        # Need to clear multiple DBs.  First get the DBs
        command = 'mongo mongo/MtxEventDatabase < /home/mtx/workspace/trunk/MTXQA/Tools/GL/showDBs | egrep "^EventCollection"'
        dataBases = QAUTILS.runCmd(command).split('\n')
        
        # Save main file
        command = 'cp /home/mtx/workspace/trunk/MTXQA/Tools/GL/clearMongo __x'
        QAUTILS.runCmd(command)
        
        # Append to the main file a clearing of all DBs
        for db in dataBases:
                command = 'echo "db.' + db + '.remove({})" >> __x'
                QAUTILS.runCmd(command)
         
        # Setup command to clear Mongo DB
        command='mongo mongo/MtxEventDatabase < __x'
        
        #print 'command to run: ' + command
        print('G/L Clear result: ' + QAUTILS.runCmd(command))

        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)

#==========================================================
def CmdGl_getgldata(lclDCT, options, line):
        # *** lclDCT[] has all the values.

        # Command to get GL posting data
        command='getGlData ' + lclDCT['lclStartTime'][0:10]
        
        #print 'command to run: ' + command
        print('G/L Get result: ' + QAUTILS.runCmd(command))

        # Nothing to query in this scenario
        queryType = queryValue = None
        
        return (queryType, queryValue)

