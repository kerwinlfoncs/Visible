#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Wed 2021-08-25T10:08:04
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-06-25T20:04:45
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-06-25T20:04:37

# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
import requests

#import auth, sys, json
import sys, json, os, copy, pprint
import collections
import timeToMDCtime as MDCTIME
import qa_utils as QAUTILS
from collections import OrderedDict
from datetime import datetime as dt
import diameter_utils as DIAMUTILS

# Might need to read IP address
from netifaces import AF_INET, AF_INET6, AF_LINK, AF_PACKET, AF_BRIDGE
import netifaces as ni

try:
   import custSpecific as CUST
except ImportError:
   os.system(' echo > custSpecific.py ')
   import custSpecific as CUST

invocationSequenceNumber = int(dt.utcnow().strftime("%s"))
filePath = os.getcwd()
moduleCwd = os.path.dirname(__file__)

generalDct={}
sessionTimeKeeper = {}

# Define port that can override configured value
sbaPort = 0
sbaIp = 0
notifyUri = ''

#-----------------------------------------------------------

nfGlobal={ 
   "nfConsumerIdentification": {
    "nFIPv4Address": "127.0.0.1",
    "nFIPv6Address": "127.0.0.1",
    "nFName": "07590aac-e824-47b7-b36a-fb37e223c57f",
    "nodeFunctionality": "SMF"
  }
}

#-----------------------------------------------------------
def getPduSessionData( deviceId=1, sessionId=0, serviceType='data', requestType='init', extraAVP=[], accessNumber=0):
    filePath = os.getcwd()
    moduleCwd = os.path.dirname(__file__)

    # Get template for this container
    with open(moduleCwd + "/input/_pDUSessionChargingInformation.json") as json_file:
        dataPduSession = json.load(json_file)
        if int(accessNumber):  dataPduSession["pDUSessionChargingInformation"]["userInformation"]["servedGPSI"] = "msisdn-" + str(accessNumber)
        else:                  dataPduSession["pDUSessionChargingInformation"]["userInformation"]["servedGPSI"] = "imsi-"   + str(deviceId)
        dataPduSession["pDUSessionChargingInformation"]["pduSessionInformation"]["pduSessionID"]=12
        
        # Extra AVPs may have data to add
        try:
                checkExtraAVP("pDUSessionChargingInformation", extraAVP, dataPduSession)
                del extraAVP["pDUSessionChargingInformation"]
        except: pass
        
        # Check deletions
        '''
        if 'omit' in extraAVP:
         for entry in extraAVP['omit']:
                # Split into pieces.  No value in deletions.
                indices = entry.split(':')[0].split('|')
                
                # See if a PDU entry
                if indices[0] == "pDUSessionChargingInformation":
                        # Walk the entry to build the array hierarchy
                        arrayString = ''
                        for item in indices: arrayString = arrayString + '["' + item + '"]'
                        
                        # Build the command
                        cmd = 'del dataPduSession' + arrayString 
                        #print 'getPduSessionData: cmd = ' + cmd
                        exec(cmd)
                        
                        # Remove entry from extraAVP
                        #del extraAVP['omit'][entry]
                
        '''
    return(dataPduSession)

#-----------------------------------------------------------
def checkExtraAVP(checkStr, extraAVP, retDCT, sectionsToRemove = None):
        # Check additions
        if 'add' not in extraAVP: return retDCT
        
        for entry in extraAVP['add']:
                # Split into pieces.  Remove value and then split entries
                indices = entry.split(':')[0].split('|')
                
                # Sometimes the entry is a flag with no value.  Skip if so.
                try:    value = entry.split(':')[1:]
                except: continue
                
                # Not sure what happens if you join a list of 1 item...
                if   not len(value): continue
                elif len(value) > 1: value = ':'.join(value)
                else:              value = value[0]
                
                # Hack: if string starts with _INT_, then it's an integer or float and needs the double quotes removed
                prefix = '_INT_'
                if str(value).startswith(prefix):
                        value = value[len(prefix):]
                        
                        # Now set as INT or float
                        if value.isdigit(): 
                                #print 'Value to make an INT: ' + str(value)
                                value = int(value)
                        else:
                                #print 'Value to make an FLOAT: ' + str(value)
                                value = float(value)
                        
                # See if at top level
                #print 'Looking at entry ' + str(entry) + ', checkStr = ' + str(checkStr)
                if not checkStr:
                        #print 'Looking at key ' + str(indices[0])
                        # Get the item to process
                        item = indices[0]
                        
                        # If it starts with a double quote, then remove from item name
                        if item.startswith('"'): item = item[1:-1]
                        
                        # Skip non-5G items
                        if not item.startswith('5G_'): continue
                        
                        # Make sure only one field specified
                        if len(indices) > 1:
                                print('ERROR: extraAVP add entry ' + str(entry) + ' has more than a single field populated.')
                                sys.exit('Exiting Early')
                        
                        # Remove prefix from field name
                        fieldName = item[3:]
                        
                        # Set the top-level field
                        #print 'Adding top-level key ' + fieldName + ' with value ' + str(value)
                        if   str(value).lower() == 'true': value = True
                        elif str(value).lower() == 'false': value = False
                        retDCT[fieldName] = value
                        
                # See if a match.  Since checkString may contain several levels, need to do a string match.
                elif entry.startswith(checkStr):
                        #print 'Looking at entry ' + str(entry)
                        # Walk the entry to build the array hierarchy
                        arrayString = ''
                        for i,item in enumerate(indices):
                                #print 'Looking at key ' + str(indices[0])
                                # Skip top level
                                if item == "multipleUnitUsage": continue
                                
                                # Save current array string
                                preArray = arrayString
                                
                                # Get new level
                                arrayString += '["' + item + '"]'
                                
                                # Used units are array items
                                if item == "usedUnitContainer": arrayString += '[0]'
                                
                                # Init dictionary item if not yet defined
                                cmd = 'if i < (len(indices) - 1) and item not in retDCT' + preArray + ': retDCT' + arrayString + ' = {}'
                                #print cmd
                                try: exec(cmd)
                                except:
                                        #print 'Skipping MSCC extraAVP.  Will happen if USU is 0.'
                                        continue
                        
                        # Build the assignment command
                        # If starts with a "{", then it's a dictionary that needs processing
                        #print 'checkExtraAVP: value = ' + str(value)
                        if str(value).startswith('['):
                                # Set entry to an array
                                cmd = 'retDCT' + arrayString + '= []'
                                #print cmd
                                try:    exec(cmd)
                                except: continue
                                
                                # Split so we can add entries 
                                for item in value[1:-1].split('@'): 
                                        # Add entry after converting to a dictionary
                                        cmd = 'retDCT' + arrayString + '.append(' + item + ')'
                                        print(cmd)
                                        try:    exec(cmd)
                                        except: continue
                        else:
                                # Manage single field
                                cmd = 'retDCT' + arrayString + '= value'
                                #print 'checkExtraAVP, checkStr = ' + checkStr + ': cmd = ' + cmd
                                try:
                                        #print cmd
                                        exec(cmd)
                                except: continue
                        
                        # Remove entry from extraAVP
                        #del extraAVP['add'][entry]
                
                        # Remove sections that should be excluded (based on special input data)
                        if sectionsToRemove:
                                for element in sectionsToRemove:
                                        try:    del retDCT[element]
                                        except: pass
        return retDCT

#-----------------------------------------------------------
def getTrigger():
    trigger={ "triggers": [
                {
                  "triggerCategory": "IMMEDIATE_REPORT",
                  "triggerType": "FINAL"
                }
              ]
    }

    '''
    trigger = {}
    trigger["triggers"] = []
    trigger["triggers"].append({"triggerCategory": "IMMEDIATE_REPORT", "triggerType": "MANAGEMENT_INTERVENTION"})
    trigger["triggers"].append({"triggerCategory": "IMMEDIATE_REPORT", "triggerType": "QHT"})   
    trigger["triggers"].append({"triggerCategory": "DEFERRED_REPORT",  "triggerType": "UNIT_COUNT_INACTIVITY_TIMER"})   
    '''
    
    return trigger

def printObj(x):
    y = json.dumps(x, ensure_ascii=False, indent=4)
    print(y)
#-------------------------------------
def getmultipleUnitUsage(ratingGroupsArr = 0, serviceIdArr = 0, usedAmountArr = 0,reqAmountArr = 0, requestType = 'init', serviceType='data', startTime=None, extraAVP={}, sessionId=0):
    multipleUnit=[]
    y={}
    
    '''
    print 'In getmultipleUnitUsage, ratingGroupsArr = '+ str(ratingGroupsArr) + ', reqAmountArr = ' + str(reqAmountArr) + ', usedAmountArr = ' + str(usedAmountArr) + ', serviceIdArr = ' + str(serviceIdArr)
    print 'In getmultipleUnitUsage, extraAVP:'
    pprint.pprint(extraAVP)
    '''
    
    # If no RG passed in, then exit
    if ratingGroupsArr == 0: return multipleUnit
    
    # A mis-match might happen if doing tariff time change.  Check for this.
    if usedAmountArr != 0:
     if type(usedAmountArr[0]) is list:
        print('Building TTC array')
        
        # Build TTC array
        ttcArray = [x[1] for x in usedAmountArr]
        
        # Split out USU array
        usedAmountArr = [x[0] for x in usedAmountArr]
        
        # Assume second item in USU is before(0)/after(1) value.
        if serviceIdArr != 0:
                while len(serviceIdArr) != len(usedAmountArr): serviceIdArr.append(serviceIdArr[0])
     else:  ttcArray = [None for x in usedAmountArr]
    else: ttcArray = 0
    #print 'In getmultipleUnitUsage part 2, ratingGroupsArr = '+ str(ratingGroupsArr) + ', reqAmountArr = ' + str(reqAmountArr) + ', usedAmountArr = ' + str(usedAmountArr) + ', serviceIdArr = ' + str(serviceIdArr)
    
    # Verify Attr elements have same length
    '''
    if usedAmountArr != 0 and (len(ratingGroupsArr) != len(usedAmountArr)):
        # Error
        print 'ERROR: getmultipleUnitUsage ratingGroupsArr length = ' + str(len(ratingGroupsArr)) + ' and usedAmountArr length = ' + str(len(usedAmountArr))
        pprint.pprint(ratingGroupsArr)
        pprint.pprint(usedAmountArr)
        sys.exit('Exiting due to errors')
    elif reqAmountArr != 0 and (len(ratingGroupsArr) != len(reqAmountArr)):
        print 'ERROR: getmultipleUnitUsage ratingGroupsArr length = ' + str(len(ratingGroupsArr)) + ' and reqAmountArr length = ' + str(len(reqAmountArr))
        pprint.pprint(ratingGroupsArr)
        pprint.pprint(usedAmountArr)
        sys.exit('Exiting due to errors')
    '''
    if serviceIdArr != 0 and usedAmountArr != 0 and (len(usedAmountArr) != len(serviceIdArr)):
        print('ERROR: getmultipleUnitUsage ratingGroupsArr length = ' + str(len(ratingGroupsArr)) + ' and serviceIdArr length = ' + str(len(serviceIdArr)))
        pprint.pprint(ratingGroupsArr)
        pprint.pprint(usedAmountArr)
        sys.exit('Exiting due to errors')
        
    # If no service ID passed in, then set to array of 0 (so ignored)
    if serviceIdArr == 0 and usedAmountArr != 0: serviceIdArr = [0 for x in usedAmountArr]
    
    # See if uPFID specified
    if extraAVP:
        uPFID = [x for x in extraAVP['add'] if x.startswith('multipleUnitUsage|uPFID')]
        if len(uPFID): uPFID = uPFID[0]
        else:      uPFID = ''
    else:
        uPFID = ''
    
    # Process all RGs.
    for i,rg in enumerate(ratingGroupsArr):
        # Define temp buffer
        x={}
        
        # Store requested units if present
        if requestType not in ['release', 'term'] and reqAmountArr != 0 and int(reqAmountArr[i]):
           # Skip RSU if special value
           if int(reqAmountArr[i]) != 999998:
                # Force an empty RSU iff key value passed in.  SBA will send through a dummy RSU.
                # Else do normal processing
                if int(reqAmountArr[i]) == 999999:      y["requestedUnit"] = {}
                else:                                   y["requestedUnit"] = getRequestedUnitData2(int(reqAmountArr[i]), serviceType, extraAVP=extraAVP)
                x.update(y)
        
        # Store used units if present. Process all of them.
        if usedAmountArr != 0:
            x["usedUnitContainer"] = []
            for j in range(len(usedAmountArr)):
              if int(usedAmountArr[j]):
                z={}
                # Force an empty RSU iff key value passed in.  SBA will send through a dummy RSU.
                # Else do normal processing
                if int(usedAmountArr[j]) != 999999:     z["usedUnitContainer"] = getUsedUnitData2(int(serviceIdArr[j]), int(usedAmountArr[j]), startTime=startTime, serviceType=serviceType, extraAVP=extraAVP, ttc=ttcArray[j], sessionId=sessionId)
                else:                                   z["usedUnitContainer"] = {}
                #x["usedUnitContainer"].extend(copy.deepcopy(z["usedUnitContainer"]))
                x.update(z)
                del z
        
            # Remove USU if nothing populated
            if not len(x["usedUnitContainer"]): del x["usedUnitContainer"]
        
        # Store RG if defined
        if int(rg): x["ratingGroup"] = int(rg)
                
        # If uPFID specified, then add
        if uPFID: x['uPFID'] = uPFID.split(':')[-1]
        
        # Update if anything populated
        if len(x):
                # Append RG results
                multipleUnit.append(copy.deepcopy(x))
                
                # Remove temp buffer (ensures nothing left for next iteration)
                del x
        
    # If uPFID specified, then delete from add and omit lists (omit only has the key, while add has the key + value)
    if uPFID:
        extraAVP['add'].remove(uPFID)
        extraAVP['omit'].remove(uPFID.split(':')[0])
        
    # If a term message them delete the session local sequence number
    if requestType in ['release', 'term']:
        try: del sessionTimeKeeper[str(sessionId)+'localSequenceNumber']
        except: pass
    
    #printObj(multipleUnit)
    return  multipleUnit  

def getUsedUnitData2(serviceId, usedAmount, startTime=None, serviceType='data', extraAVP={}, ttc=None, sessionId=0):
    global filePath
    global moduleCwd
    global sessionTimeKeeper

    #print "serviceId=", str(serviceId), " usedAmount=", str(usedAmount)
    usedData={}
    with open(moduleCwd + "/input/usedUnit.json") as json_file:
        usedData=json.load(json_file, object_pairs_hook=OrderedDict)
    usedUnitList=[]
    usedData_tmp=copy.deepcopy(usedData)
    #print "usedAmountArr=", usedAmount
    
    # Need to set local sequence number
    sessStr = str(sessionId) + 'localSequenceNumber'
    try:        sessionTimeKeeper[sessStr] += 1
    except:     sessionTimeKeeper[sessStr] = 1
    usedData_tmp["localSequenceNumber"] = sessionTimeKeeper[sessStr]
    
    # Include service ID if not 0
    if serviceId != 0: usedData_tmp['serviceId'] = serviceId  #serviceId is not used.
    elif 'serviceId' in usedData_tmp: del usedData_tmp['serviceId']
    
    # Set on/off line indication.  First check if present and defined.
    if 'offlineFlag' in extraAVP and extraAVP['offlineFlag']:
        if   extraAVP['offlineFlag'].lower() == 'show_true':
                usedData_tmp['quotaManagementIndicator'] = "OFFLINE_CHARGING"
        elif extraAVP['offlineFlag'].lower().count('true'):
                del usedData_tmp['quotaManagementIndicator']
        else:   usedData_tmp['quotaManagementIndicator'] = "ONLINE_CHARGING"
    else: usedData_tmp['quotaManagementIndicator'] = "ONLINE_CHARGING"

    # If TTC set for before, then add here
    if ttc and int(ttc) == 0:
        #print 'Adding ttc = ' + str(ttc)
        # Define trigger array
        usedData_tmp['triggers'] = []
        usedData_tmp['triggers'].append({'triggerType': 'TARIFF_TIME_CHANGE', 'triggerCategory':'DEFERRED_REPORT'})
        
    # Different fields to set based on service type

    quantitySelector = DIAMUTILS.getQuantitySelector(serviceType, None)

    if   usedAmount == int(999990): pass
    elif quantitySelector == "totalData":
        usedData_tmp['totalVolume'] = usedAmount
    elif quantitySelector == "inData":
        usedData_tmp['downlinkVolume'] = usedAmount
    elif quantitySelector == "outData":
        usedData_tmp['uplinkVolume'] = usedAmount
    elif quantitySelector == "actualDuration":
        usedData_tmp['time'] = usedAmount
    elif quantitySelector == "serviceSpecific":
        usedData_tmp['serviceSpecificUnits'] = usedAmount

    # Add time if extra values include it
    try:
        usedData_tmp['time'] = extraAVP['usedTime']
        del extraAVP['usedTime']
    except: pass
    
    # Set start time if passed in
    if startTime: usedData_tmp['eventTimeStamps'] = startTime
        
    usedUnitList = [usedData_tmp]
    #print usedUnitList 
    # Not sure what this does....
    usedData_tmp=copy.deepcopy(usedData)
    #print "serviceId=", str(serviceId), " usedAmount=", str(usedAmount)
    #str1=json.dumps(usedUnitList, ensure_ascii=False, indent=4)

    #print 'returning usedUnitList = ' + str(usedUnitList)
    return usedUnitList

def getRequestedUnitData2(reqAmount, serviceType='data', extraAVP={}):  
    global filePath
    global moduleCwd

    with open(moduleCwd + "/input/reqUnit.json") as json_file:
        reqData=json.load(json_file, object_pairs_hook=OrderedDict)
    reqData={}


    quantitySelector = DIAMUTILS.getQuantitySelector(serviceType, None)
    
    # Different fields to set based on service type
    
    # Don't add if a special value
    if   reqAmount == int(999990): pass
    elif quantitySelector == "totalData":
        reqData['totalVolume'] = reqAmount
    elif quantitySelector == "inData":
        reqData['downlinkVolume'] = reqAmount
    elif quantitySelector == "outData":
        reqData['uplinkVolume'] = reqAmount
    elif quantitySelector == "actualDuration":
        reqData['time'] = reqAmount
    elif quantitySelector == "serviceSpecific":
        reqData['serviceSpecificUnits'] = reqAmount
        
    # Add time if extra values include it
    try:
        reqData['time'] = extraAVP['reqTime']
        del extraAVP['reqTime']
    except: pass
    
    return reqData


#-----------------------------------------------------------
# *** This appears to be obsolete ***
def getUsedUnitData(data, ratingGroupsArr, serviceIdArr, usedAmountArr):
    x = getTrigger()
    data.pop("multipleUnitUsage")
    data["multipleUnitUsage"]=[]
    i = 0
    for rg in ratingGroupsArr :
        #print rg 
        dct1= { "usedUnitContainer": [{ 
                   "localSequenceNumber": 1, 
                   "serviceId": serviceIdArr[i], 
                   "serviceSpecificUnits": 0, 
                   "totalVolume": usedAmountArr[i]
           }]
#                   "quotaManagementIndicator": "ONLINE_CHARGING", 
        }
        dct1["usedUnitContainer"][0].update(x)
        dct1["ratingGroup"] = rg
        data["multipleUnitUsage"].append(dct1)
        i+=1
    return data

#-----------------------------------------------------------

def setupEnv(section):
    dct = {}
    Config = QAUTILS.getDiameterRestConfig() #this is used for reading the config sections
    if (Config.has_section(section)):
        sectionItems=Config.items(section)
        for xx in  sectionItems:
            #print xx
            
            # Not sure why code was doing an eval()...
            #dct[xx[0]] = eval(xx[1])
            dct[xx[0]] = xx[1]
    return dct

#-----------------------------------------------------------

def getSbaInfo(sbaEnvDct, item):
   if item in sbaEnvDct:
       return sbaEnvDct[item].strip('"') 
    
#-----------------------------------------------------------
def updateNotifyUriIpAndPort(x):
        global sbaPort
        global notifyUri
        
        # Return if already figured out
        if notifyUri: return notifyUri
        
        # Copy input into global
        notifyUri = x
        
        # TF code: sbaPort is dynamically changed per-test (to support simultaneous tests)
        if sbaPort:
                # Specific format required.  Catch bad format here.
                try:
                        # Split notify URI and add dynamic port.
                        prePort = ':'.join(notifyUri.split(':')[0:2])
                        postPort = notifyUri.split(':')[2]
                        postPort = postPort[postPort.index('/'):]
                        #print 'notifyUri = ' + notifyUri + ', prePort = ' + prePort + ', postPort = ' + postPort
                except:
                        print('ERROR: notifyURI (in Common/config.ini) needs to look like: "notifyUri : http://IP:Port/matrixx/TF".  The directories after the port are required')
                        print('Value configured in config.ini: "' + notifyUri + '".')
                        sys.exit('Exiting due to input config error')
                
                # Build notify URI.  Add the port number at the end so we can distinguish which test this is from
                notifyUri = prePort + ':' + str(sbaPort) + postPort + '-' + str(sbaPort)
        
        # If the notify string contains curly brackets, then we need to replace this with the IP of the server
        if notifyUri.count('{'):
                # Get pre/post of this
                (prefix, remainder) = notifyUri.split('{')
                (interface, suffix) = remainder.split('}')
                
                # See if interface is in global data
                if interface not in ni.interfaces():
                        # Hmmmm.
                        print('WARNING: Specified SBA notify IP interface "' + interface + '" is not on this server.  Valid interface are: ' + str(ni.interfaces()) + '.  Going to try eth0')
                        interface = 'eth0'
                        if interface not in ni.interfaces():
                                # Punt...
                                sys.exit('ERROR: interface "' + interface + '" is not on this server.  Exiting due to errors.')
                
                # Get the IP of the interface
                ip = ni.ifaddresses(interface)[AF_INET][0]['addr']
                notifyUri = prefix + ip + suffix
                print('SBA notification : Using IP ' + ip + ' for interface ' + interface + '.  notifyUri = ' + notifyUri)
        
        return notifyUri

#-----------------------------------------------------------
def sendOneRequestSy(inputfile="/input/init_request_sy.json", deviceId = 0, requestType = 'init', sessionId = 0,policyCounterIds =[],  startTime = 0, sbaIp=0, https=False, httpLevel=1, scpHeaders=None, getResponseHeaders=False):
    global nfGlobal
    global invocationSequenceNumber
        
    # Set sequence number based on message type or stored message
    if requestType.lower().startswith('init') or requestType.lower() == 'event':
        # Use global
        invocationSequenceNumber+=1
    elif sessionId in sessionTimeKeeper:
        sessionTimeKeeper[sessionId] += 1
        invocationSequenceNumber = sessionTimeKeeper[sessionId]
    else:
        print('ERROR: 5G sendOneRequest entered with requestType = '+ requestType + ' but session ID '+ str(sessionId) + ' is not in stored sessions: ' + str(sessionTimeKeeper))
        sys.exit('Exiting due to errors')
    
    url = None
    urls = None
    sbaEnvDct = setupEnv("SBA")
    #print 'sbaEnvDct ', sbaEnvDct
    if sbaEnvDct!= {}:
        url = getSbaInfo(sbaEnvDct, "urlspendingl")
        urls = getSbaInfo(sbaEnvDct, "urlspendingls")
        notifyUri = getSbaInfo(sbaEnvDct, "notifyuri")
        
        # There may be port and/or IP changes needed to the notify URI
        notifyUri = updateNotifyUriIpAndPort(notifyUri)

        # Add session ID to notify URI so it's unique between sessions.
        # Note that this session ID is the internal tool session ID.  The SBA-generated session ID coes in the response.
        notifyUri += '/' + str(sessionId)
    else:
        sys.exit("no SBA url defined on MTXQA/Common/config.ini")

    filePath = os.getcwd()
    moduleCwd = os.path.dirname(__file__)
    inputfile = moduleCwd + inputfile

    with open(inputfile) as json_file:
        data = json.load(json_file, object_pairs_hook=OrderedDict)
        data["supi"] =   "imsi-" + str(deviceId)
        data["gpsi"] = str(deviceId)
        data["policyCounterIds"] = policyCounterIds 
        # Do per-request work
        #data["notifUri"] = notifyUri #+ "?" + data["supi"]
        if requestType.lower().startswith('init'):
            # Notify URL only goes in INIT message
            data["notifUri"] = notifyUri + "?" + data["supi"]
        
        # Convert back to text (only needed for HTTP/1.1, but leave here for now)
        x = json.dumps(data , ensure_ascii=False, indent=4)
        
        # Update URL
        if not requestType.startswith('init'): url += "/" + sessionId
        
        # Debug output
        if QAUTILS.DebugLevel > 0:
                print('RequestType: ' + requestType) 
                print('url: ' , url)
                if requestType not in ['delete', 'term']: print("Payload:", x) 
        
        # Process the request
        if httpLevel == 2:
                # Import HTTP/2 libraries only if using HTTP/2
                from hyper.contrib import HTTP20Adapter
                
                # From Hyper docs.  Integrate with requests.
                s = requests.Session()
                
                # SBA IP and port can be taken from the url entry.
                dest = '/'.join(url.split('/')[0:3])
                s.mount(dest, HTTP20Adapter())
                #s.mount('http://10.0.4.1:33100', HTTP20Adapter())
                
                # Check the requested operation
                if  requestType.startswith('init'):        rsp = s.post(url, json=data, headers=scpHeaders)
                elif requestType in ['update', 'interim']: rsp = s.put(url, json=data, headers=scpHeaders)
                elif requestType in ['delete', 'term']:    rsp = s.delete(url, headers=scpHeaders)
                else:
                        sys.exit('sendOneRequestSy: not yet implemented requestType: ' + str(requestType) + '!')
        else:
                # Standard HTTP/1.1 requests library
                # Check the requested operation
                if  requestType.startswith('init'):        rsp=requests.post(url, x, headers=scpHeaders)
                elif requestType in ['update', 'interim']: rsp=requests.put(url, x, headers=scpHeaders) 
                elif requestType in ['delete', 'term']:    rsp=requests.delete(url, headers=scpHeaders) 
                else:
                        sys.exit('sendOneRequestSy: not yet implemented requestType: ' + str(requestType) + '!')
                
        # Get response and status into common locals
        content = rsp.content
        status = rsp.status_code
        
        # Debug output
        if QAUTILS.DebugLevel > 0:
                print("response is :-------------------------------------")
                print(rsp)
                print("header is ---------------------------------")
                print(rsp.headers)
                print("content is ---------------------------------")
                print(rsp.content)
        
        # Extract or set the session ID
        s = ""
        
        # HTTP/1.1 returns "Location" while HTTP/2 returns "location"...
        if httpLevel == 1: key = "Location"
        else:              key = "location"
        if key in list(rsp.headers.keys()):
            s = rsp.headers[key].split('@')[-1]
            # KEF: Seems 523x 5G N28 needs a different split character...
            #s = rsp.headers[key].split('/')[-1]
            if s == "" : sys.exit('No Session ID in 5G Sy HTTP ' + str(httpLevel) + ' response Location field!!!!!!!!!!!')
        
            # Store session ID with sequence number
            sessionTimeKeeper[s] = int(invocationSequenceNumber)
        elif requestType.startswith('init'):
                print("No Location field in 5G Sy init response!!!!!!!!!!!")
                print("response is :-------------------------------------")
                print(rsp)
                print("header is ---------------------------------")
                print(rsp.headers)
                print("content is ---------------------------------")
                print(rsp.content)
                sys.exit("Exiting due to bad response")
        else: s = sessionId
    if getResponseHeaders:
        return(s, rsp.status_code, rsp.content, rsp.headers)
    return(s, rsp.status_code, rsp.content)

def removeKeys(data, removeList):
    for term in removeList:
        print("Removing term")
        data.pop(term)
    return data

def updateKeys(data, addList, path=None):
    for item in addList:
        key = item[0]
        value = item[1]
        if len(item) > 2: 
            path = item[2]
        data = updateKey(data, key, value, path)
        path = None
    return data

def updateKey(data, key, value, path=None):
    if path == []:
        data[key] = value
        return data
    if isinstance(data, collections.Mapping):
        if path and path[0] in data:
            p = path[0]
            if len(path) == 1:
                data[p][key] = value
                return data
            else:
                path.pop(0)
                data[p] = updateKey(data[p], key, value, path)
                return data
        if key in data and path == None:
            data[key] = value
            return data
        else:
            for item in data:
                data[item] = updateKey(data[item], key, value, path)
            return data
    elif isinstance(data, list):
        for item in data:
            index = data.index(item)
            if path and path[0] in item:
                path.pop(0)
            data[index] = updateKey(data[index], key, value, path)
            return data
    else:
        return data            

def insertKeys(data, removeList):
    return data

def removeNoneKeys(data):
    if isinstance(data, collections.Mapping):
        '''
        # This should work, but it doesn't...
        data = [x for x in data if x != "None"]
        for item in data: data[item] = removeNoneKeys(data[item])
        data = [x for x in data if len(x)]
        '''
        newData = dict(data)
        for item in data:
            if data[item] == "None":
                #print 'Removing None parameter ' + item
                newData.pop(item)
            else: 
                newData[item] = removeNoneKeys(data[item])
                '''
                if data[item] == {} or data[item] == []:
                    data.pop(item)
                '''
        return newData
    elif isinstance(data, list):
        for item in data:
            index = data.index(item)
            data[index] = removeNoneKeys(data[index])
            if data[index] == [] or data[index] == {}:
                data.pop(index)
        return data
    else:
        return data



#_------------------------------------------------------------
def sendOneRequest(inputfile="/input/misc_request.json", deviceId = 0,reqAmountArr = 0, usedAmountArr = 0, requestType = 'init', sessionId = 0, serviceType = 'data', ratingGroupsArr=[2], serviceIdArr=[2], startTime = 0, sbaIp=0, https=False, removeList=[], addList=[], getResponseContent=False, sequenceStartNumnber=0, extraAVP=[], httpLevel=1, eventPass=True, scpHeaders=None, getResponseHeaders=False, accessNumber=0, supi=0):
    global nfGlobal
    global invocationSequenceNumber
    global sessionTimeKeeper

    '''
    if startTime != 0:
        startTime = MDCTIME.convertTime(startTime, forceUtc=True)
    '''
    
    # Set sequence number based on message type or stored message
    if requestType.lower().startswith('init') or requestType.lower() == 'event':
        # Use input if passed in, else use global
        if sequenceStartNumnber: invocationSequenceNumber = sequenceStartNumnber
        else:                    invocationSequenceNumber+=1
    elif sessionId in sessionTimeKeeper:
        sessionTimeKeeper[sessionId] += 1
        invocationSequenceNumber = sessionTimeKeeper[sessionId]
    elif requestType.lower().startswith('term'):
        # Use input if passed in, else use global
        if sequenceStartNumnber: invocationSequenceNumber = sequenceStartNumnber
        else:                    invocationSequenceNumber+=1
    else:
        print('ERROR: 5G sendOneRequest entered with requestType = '+ requestType + ' but session ID '+ str(sessionId) + ' is not in stored sessions: ' + str(sessionTimeKeeper))
        sys.exit('Exiting due to errors')
    
    url = None
    urls = None
    sbaEnvDct = setupEnv("SBA") 

    # Get configured data
    if sbaEnvDct!= {}:
        url = getSbaInfo(sbaEnvDct, "url")
        urls = getSbaInfo(sbaEnvDct, "urls")
        #TBD  Sy uses NotifUri?
        notifyUri = getSbaInfo(sbaEnvDct, "notifyuri")
        
        # There may be port and/or IP changes needed to the notify URI
        notifyUri = updateNotifyUriIpAndPort(notifyUri)
        
        # Add session ID to notify URI so it's unique between sessions.
        # Note that this session ID is the internal tool session ID.  The SBA-generated session ID coes in the response.
        notifyUri += '/' + str(sessionId)
    else:
        sys.exit("no SBA url defined on MTXQA/Common/config.ini")

    filePath = os.getcwd()
    
    # Input file is relative to Common directory
    moduleCwd = os.path.dirname(__file__)
    inputfile = moduleCwd + inputfile

    data = {}
    with open(inputfile) as json_file:
        data = json.load(json_file, object_pairs_hook=OrderedDict)
        if deviceId != 0:       data["subscriberIdentifier"] =  "imsi-" + str(deviceId)
        else:                   data["subscriberIdentifier"] =  "imsi-" + str(supi)
        data["invocationTimeStamp"] = startTime
        data.update(nfGlobal)
        
        # Always need to udpate the PDU
        dataPduSession = getPduSessionData(deviceId=deviceId, sessionId=sessionId, serviceType=serviceType, requestType=requestType, extraAVP=extraAVP,accessNumber=accessNumber )
        data.pop("pDUSessionChargingInformation")
        data.update(dataPduSession)
        
        # Do per-request work 
        if requestType.lower().startswith('init'):
            # Notify URL only goes in INIT message
            data["notifyUri"] = notifyUri + "?" + data["subscriberIdentifier"]
            
            # Get MSCC information
            data["multipleUnitUsage"] = getmultipleUnitUsage(ratingGroupsArr, serviceIdArr, usedAmountArr,reqAmountArr, requestType='init', startTime=startTime, serviceType=serviceType, extraAVP=extraAVP, sessionId=sessionId)

        #----------------------------------------------------

        elif requestType in ['update', 'interim']:
            url = url + "/" + sessionId + "/update"
            data.pop("multipleUnitUsage")
            
            # Get MSCC information
            data["multipleUnitUsage"] = getmultipleUnitUsage(ratingGroupsArr, serviceIdArr, usedAmountArr,reqAmountArr, requestType='update', startTime=startTime, serviceType=serviceType, extraAVP=extraAVP)
            #printObj(data)
        #----------------------------------------------------

        elif requestType in ['release', 'term']:
            url = url + "/" + sessionId + "/release"
            data["multipleUnitUsage"] = getmultipleUnitUsage(ratingGroupsArr, serviceIdArr, usedAmountArr,reqAmountArr, requestType='release', startTime=startTime, serviceType=serviceType, extraAVP=extraAVP)
            #printObj(data["pDUSessionChargingInformation"])
        #----------------------------------------------------

        elif requestType == 'event':
            data["oneTimeEvent"] = True
            data["multipleUnitUsage"] = getmultipleUnitUsage(ratingGroupsArr, serviceIdArr, usedAmountArr,reqAmountArr, requestType=requestType, serviceType=serviceType, startTime=startTime, extraAVP=extraAVP)
            
        else:
            sys.exit('sendOneRequest: Have not yet implemented serviceType/requestType combination of ' + str(serviceType) + '/' + str(requestType) + '!')

        data["invocationSequenceNumber"] = invocationSequenceNumber
        
        # Hard-code App Name to see if it works...
        #data["multipleUnitUsage"][0]['ApplicationName'] = "KEF"
        
        # Process extraAVP entries for "multipleUnitUsage"
        if "multipleUnitUsage" in data:
                '''
                print "\n\nProcessing multipleUnitUsage entries:"
                pprint.pprint(data["multipleUnitUsage"])
                print "\n\nProcessing extraAVP entries:"
                pprint.pprint(extraAVP['add'])
                '''
                # Process each array entry
                for entry in data["multipleUnitUsage"]:
                        #print "\n\nProcessing entry: " + str(entry)
                        # Extra AVPs may have data to add.  Can only add if the structure was defined above.  No creating of the container via eztraAVP.
                        if   "requestedUnit"     in entry: checkExtraAVP("multipleUnitUsage|requestedUnit",     extraAVP, entry)
                        elif "usedUnitContainer" in entry: checkExtraAVP("multipleUnitUsage|usedUnitContainer", extraAVP, entry)
                
                # Always check for top-level multi-unit fields
                #print "\n\nChecking entry: " + str(entry)
                checkExtraAVP("multipleUnitUsage", extraAVP, entry)
        
        # See what we have now...
        '''
        print "\n\nMessage contents:"
        pprint.pprint(data)
        '''
        
        # Do custom mappings.  The following list is derived by running the following comamnd against the charging request mapping file:
        # grep "^      [A-Z,a-z]" ChargingDataRequest-5200-mapping.yaml | cut -f1 -d: | cut -f1 -d'!' | cut -c7- | tr "\n" " "
        # Remove items that were processed above (e.g. pduSession, multipleUnitUsage)
        for entry in ['TextInformation', 'VoiceInformation', 'sponsorInformation', 'InvocationSequenceNumber', 'InvocationTimestamp', 'nfConsumerIdentification', 'NotifyUri', 'OneTimeEvent', 'OneTimeEventType', 'RoamingQbcInfo', 'SmsChargingInfo', 'SubscriberId', 'TriggerArray', 'HeaderData']:
                checkExtraAVP(entry, extraAVP, data)
        for entry in ['ServiceSpecInfo']: checkExtraAVP(None, extraAVP, data)
        
        # Process removed and added keys
        data = removeKeys(data, removeList)
        data = updateKeys(data, addList)
        
        # Remove empty keys
        data = removeNoneKeys(data)
     #   print(data)
        # Convert back to text (only needed for HTTP/1.1, but leave here for now)
        x = json.dumps(data , ensure_ascii=False, indent=4)
      #  print(x)
        headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
        if scpHeaders:
          headers.update(scpHeaders)
        
        # Debug output
        if QAUTILS.DebugLevel > 0:
                print("sending url...............: " + url + '" with headers: ' + str(headers))
                print("sending ...............................................", x) 
        
        # Post the request
        if httpLevel == 2:
                # Import HTTP/2 libraries only if using HTTP/2
                from hyper.contrib import HTTP20Adapter
                
                # From Hyper docs.  Integrate with requests.
                s = requests.Session()
                
                # SBA IP and port can be taken from the url entry.
                dest = '/'.join(url.split('/')[0:3])
                #dest = 'http://10.0.4.1:33100'
                s.mount(dest, HTTP20Adapter())
                rsp = s.post(url, json=data)
        else:
                # Standard HTTP/1.1 requests library
                rsp=requests.post(url, x, headers=headers)
        
        # Get response into common local variables
        content = rsp.content
        status = rsp.status_code
        
        '''
        from hyper import HTTPConnection
        # Hyper standalone HTTP/2 call (not working - all calls look like an init)
        c = HTTPConnection('10.0.4.1:33100')
        c.request('POST', '/nchf-convergedcharging/v2/chargingdata', body=x, headers=headers)
        rsp = c.get_response()
        content = rsp.read()
        status = rsp.status
        '''
        
        # Debug output
        if QAUTILS.DebugLevel > 0:
                print("\nresponse is :-------------------------------------")
                print(rsp)
                print("\nheader is ---------------------------------")
                try:    pprint.pprint(json.loads(rsp.headers))
                except: print(rsp.headers)
                print("\ncontent is ---------------------------------")
                if content: 
                        try: pprint.pprint(json.loads(content))
                        except: print(content)
                print("---------------------------------\n")
#               print rsp.text
#               print rsp.json()
        
        # Sanity check the response
        s = ""
        
        # Should get location in all responses
        if "location" in rsp.headers:
            # HTTP/1
            if httpLevel == 1:  s = rsp.headers['Location'].split('/')[-1]
            else:               s = rsp.headers['location'].split('/')[-1]
            '''
                # HTTP/2
                for item in rsp.headers:
                        print 'Item = ' + str(item)
                        try: (name,value) = item
                        except: continue
                        
                        # Only want location for now.  Several names have minus characters, which break python variable name rules.
                        if name == 'location':
                                cmd = name + ' = "' + value + '"'
                                exec(cmd)
                                s = location.split('/')[-1]
                                break
            '''
                
            # Check what we get back
            if s == "" :
                print("Session ID was blank in the response!!!!!!!!!!!")
                
                # Debug if not already reported
                if QAUTILS.DebugLevel <= 0: 
                        print("sending url...............: " , url)
                        print("sending ...............................................", x) 
                        print("\nresponse is :-------------------------------------")
                        print(rsp)
                        print("\nheader is ---------------------------------")
                        print(rsp.headers)
                        print("\ncontent is ---------------------------------")
                        print(rsp.content)
                        print("---------------------------------\n")
                
                sys.exit("Exiting due to errors")
            
            # Store session ID with sequence number
            sessionTimeKeeper[s] = int(invocationSequenceNumber)
        elif requestType.lower().startswith('init'):
                print("no Session ID in the initial response !!!!!!!!!!!")
                
                # Debug if not already reported
                if QAUTILS.DebugLevel <= 0: 
                        print("sending url...............: " , url)
                        print("sending ...............................................", x) 
                        print("\nresponse is :-------------------------------------")
                        print(rsp)
                        print("\nheader is ---------------------------------")
                        print(rsp.headers)
                        print("\ncontent is ---------------------------------")
                        print(rsp.content)
                        print("---------------------------------\n")
                
                # Exit from here
                if eventPass: 
                    sys.exit('Exiting due to errors') 
        
    if getResponseContent:
        try:    content = rsp.json()
        except:
                if content:     content = json.loads(content)
                else:           content = {}
        
        if getResponseHeaders:
            return(s, status, content, rsp.headers)
        else:
            return(s, status, content)
    if getResponseHeaders:
        return(s, status, rsp.headers)
    return(s, rsp.status_code)

#-----------------------------------------------------------
def main():
   startTime = MDCTIME.getTime()
   if len(sys.argv) == 1:
       sys.exit("Usage: <Imsi>")
   deviceId = sys.argv[1]
   #sessionId = str(sys.argv[2])
   getmultipleUnitUsage(ratingGroupsArr=[2,25], serviceIdArr=[2,2], usedAmountArr=[10,20],reqAmountArr=[30,40], requestType='update')
   #sys.exit(1)
   #getUsedUnitData2(data=None, ratingGroupsArr=[1,2], serviceIdArr=[1,2], usedAmountArr=[1,2])
   #["nfConsumerIdentification"]["nFIPv4Address"]

   startTime = MDCTIME.getTime()
   requestType='init'

   (sessionId, response) = sendOneRequest(deviceId=deviceId ,reqAmountArr=[1024] , usedAmountArr=[20202], requestType=requestType, sessionId=0, ratingGroupsArr=[2], startTime=startTime , sbaIp="10.0.4.1", https=False, removeList=["[\"nfConsumerIdentification\"][\"nFIPv4Address\"]"], addList=[])

   '''
   #sys.exit(1)
   getmultipleUnitUsage(ratingGroupsArr=[10,20], serviceIdArr=[100,200], usedAmountArr=[300,400],reqAmountArr=[1,4])


    

   #PduSessionData(ratingGroupsArr=[1,2], deviceId=204, sessionId=10000)
   print "assuming Imsi is already created!!!!!!!!!!!!!!!!!!"

   #------------------------------------------------------------

   '''
   s = sendOneRequest(inputfile="/input/misc_request.json", deviceId=deviceId ,reqAmountArr=[1024] , usedAmountArr=[1024], requestType='update', sessionId='12345678', ratingGroupsArr=[2], serviceIdArr=[2], startTime=startTime , sbaIp="10.10.126.61")
   #------------------------------------------------------------

   s = sendOneRequest(inputfile="/input/misc_request.json", deviceId=deviceId ,reqAmountArr=[1024] , usedAmountArr=[1024], requestType='release', sessionId='12345678', ratingGroupsArr=[2], serviceIdArr=[2], startTime=startTime , sbaIp="10.10.126.61")



if __name__ == "__main__":
    main()

