#! /usr/bin/python3
#
# @2to3-3 --no-diffs -x input -w  : Thu 2022-02-03T10:22:32
#
# @futurize --stage2 --no-diffs -n -w  : Thu 2022-02-03T10:22:27
#
# @futurize --stage1 --no-diffs -n -w  : Thu 2022-02-03T10:22:20
#  HTTP/2 Server code
#
# The hyper library is not supported!!!  Any issues and the user is on their own.

from __future__ import print_function
# from builtins import str
# from builtins import range
from future import standard_library
standard_library.install_aliases()
# from builtins import str
# from builtins import range
import socket, json
import csv_5G as FIVEG
import threading, queue
from optparse import OptionParser
import h2.connection
import h2.events
from h2.events import (
    ConnectionTerminated, DataReceived, RequestReceived, StreamEnded
)

global options
idToSession = {}

# ------------------------------------------------------------------------------
# Define input
def commandInput():
        global options
        
        # -----------------------------------------------------------------------------
        # Program Usage and Options
        # -----------------------------------------------------------------------------
        #define the options and parameter
        parser = OptionParser(usage="usage: %prog [options] ",
                      version="%prog 0.1")

        parser.add_option("-v", "--verbose",
                      action="store",
                      dest="verbose",
                      default='normal',
                      help="Reporting verbosity")
        
        parser.add_option("-i", "--ip",
                      action="store",
                      dest="ip",
                      default='0.0.0.0',
                      help="http2 server IP address")

        parser.add_option("-p", "--port",
                      action="store",
                      dest="port",
                      default='8000',
                      help="http2 server port")

        # Set the subman mode of operation
        (options, args) = parser.parse_args()

#===============================================================================
# Setup thread for processing the request
class processingThread(threading.Thread):
    def __init__(self,threadNum,queue):
        threading.Thread.__init__(self)
        self.threadNum=threadNum
        self.input_queue=queue

    def run(self):
        count = 0

        # Loop forever
        resp = ''
        while True:
                # Get a request from the queue
                request = self.input_queue.get(block=True)
                #print 'Thread ' + str(self.threadNum) + ' retrieved request from queue '

                # Bump the count
                count += 1
                
                # Call the handling function, passing in what was previously returned
                handle(request)
                #processData(request)
        
#===============================================================================
# Process data within a thread
def processData(threadData):
        lclSession = []
        
        # Split data
        (sock, conn, data) = threadData
        
        # Output spacing
        if options.verbose not in ['low', 'none']: print('\n\nMessage Started\n')
        
        connBuffer = ''
        
        # Get events
        events = conn.receive_data(data)
        
        # Process each event
        for event in events:
            if options.verbose not in ['low', 'none']: print('Event: ' + str(event))
            if isinstance(event, RequestReceived):
                (session,connBuffer) = receive_request(conn, event, connBuffer)
                
                # Check and store session
                if event.stream_id in idToSession:
                        # Shouldn't be here
                        print('ERROR: stream_id ' + str(event.stream_id) + ' is in idToSession when a request was received')
                        
                # Always update with the latest ID to session data
                idToSession[event.stream_id] = session
                
            elif isinstance(event, DataReceived):
                # Session better be in global data
                if event.stream_id not in idToSession:
                        # Shouldn be here
                        print('ERROR: stream_id ' + str(event.stream_id) + ' is not in idToSession when a data request was received')
                        return
                
                # Get the session from global data
                session = idToSession[event.stream_id]
                
                connBuffer = receive_data(conn, event, session, connBuffer)
            elif isinstance(event, StreamEnded):
                # Session better be in global data
                if event.stream_id not in idToSession:
                        # Shouldn be here
                        print('ERROR: stream_id ' + str(event.stream_id) + ' is not in idToSession when a stream end request was received')
                        return
                
                # Get the session from global data
                session = idToSession[event.stream_id]
                
                # Remove from global data
                del idToSession[event.stream_id]
                
                # Process message
                lclSession.append(stream_complete(conn, event, session, connBuffer, sock))
        
        # Send if anything queued to send
        data_to_send = conn.data_to_send()
        if data_to_send: sock.sendall(data_to_send)
        
        # Get response from client.
        # *** Move back to inside stream_complete()- then can return failures if needed.  Here the SBA has already been replied to.
        # *** Was having timing issues (SBA expects a response quicker than TF was sending due to messages coming randomly (and TF commands look for a specific message).
        for session in lclSession:
                # Build dictionary (kludgy...)
                lclDCT = {}
                lclDCT['sessionId'] = session
                lclDCT['timeToWait'] = 5
                lclDCT['timeToWaitInterval'] = 0.5
                lclDCT['interface'] = 'HTTP'
                lclDCT['eventPass'] = True
                lclDCT['verbose'] = options.verbose
                msg = FIVEG.getHttpServerMessage(lclDCT, "HTTP")
    
                # Debug
                if options.verbose not in ['low', 'none']: print('Stream Complete.  Received response from client for session ' + session)
        
        # Output spacing
        if options.verbose not in ['low', 'none']: print('\nMessage Ended\n')
        
#===============================================================================
# Request received.  Get headers and session value.
def receive_request(conn, event, connBuffer):
    stream_id = event.stream_id
    headers = event.headers
    '''
    try: data = event.data
    except: data = 'None Here'
    '''
    
    #print 'Received Request'
    #print 'Headers: ' + str(headers)
    
    # Set locals for each item in the header list
    hdrData = ''
    lclDCT = {}
    for entry in headers:
        # Split into parts
        (name,value) = entry
        
        # HTTP2 data names sometimes start with a ":".  Python doesn't like this :-).
        if name[0] == ':': name = name[1:]
        name = name.replace('-', 'X', 10)
        
        # Make assignment
        #cmd=name + ' = "' + value + '"'
        #print cmd
        #exec(cmd)
        lclDCT[name] = value
        
        # Add to string
        #hdrData += cmd + '\n'
        hdrData += name + ' = "' + lclDCT[name] + '"\n'
        
    # Build output file content
    outStr = ''
    outStr += 'Path: ' + lclDCT['path'] + '\n'
    session = lclDCT['path'].split('?')[0].split('/')[-1]
    
    # If this is a notify message, then we want to include the preceeding part of the path to distinguish it from other requests.
    # Preceeding part will always be "TF-####" so grab the number.
    if session == 'notify': session = lclDCT['path'].split('?')[0].split('/')[-2].split('-')[1] + session
    outStr += 'Session: ' + session + '\n'
    outStr += 'Headers:\n'
    outStr += hdrData
    
    # Add to global data
    connBuffer += outStr
    
    return session,connBuffer
    
#===============================================================================
# Stream complete.  Send data to client and wait for client response.
def stream_complete(conn, event, session, connBuffer, sock):
    global options
    
    stream_id = event.stream_id
    if options.verbose not in ['low', 'none']: print('Stream Complete.  Sending to client for session ' + session)
    #print 'outStr: ' + str(connBuffer)
    
    # Send message to client processing SBA messages
    FIVEG.sendHttpServerMessage(connBuffer, session, 'HTTP')
   
    '''
    # Get response from client
    # Build dictionary (kludgy...)
    lclDCT = {}
    lclDCT['sessionId'] = session
    lclDCT['timeToWait'] = 5
    lclDCT['timeToWaitInterval'] = 0.5
    lclDCT['interface'] = 'HTTP'
    lclDCT['eventPass'] = True
    lclDCT['verbose'] = options.verbose
    msg = FIVEG.getHttpServerMessage(lclDCT, "HTTP")
    
    # Debug
    print 'Stream Complete.  Received response from client for session ' + session
    #print msg
    
    # For now get only the first line
    response = int(msg.strip().split('\n')[0])
    '''
    print('Stream Complete.  Responding to SBA for session ' + session)
    response = 0
    
    # Reply with no content if reply is 0, else if reply is positive then reply with error, or if negative then no reply.
    if   response == 0:
            #print 'Replying success for session ' + session
            status = '204'
    elif response > 0:
            #print 'Replying failure for session ' + session
            #status = '500'
            # AlWAYS SUCCESS FOR NOW!!
            status = '204'
    else:
            #print 'Not replying for session ' + session
            status = ''
    
    # Queue headers if responding
    if status:
        conn.send_headers(
               stream_id=stream_id,
               headers=[
                (':status', status),
                ('server', 'basic-h2-server/1.0')
                ],
               end_stream=True,
        )

    # Return the session so we process each one after completing the message
    return session
    
#===============================================================================
# Received Data.  Get data from the message.
def receive_data(conn, event, session, connBuffer):
    stream_id = event.stream_id
    data = event.data
    #print 'Received data: ' + str(data)

    # Put content into JSON
    content = json.loads(data)
    #print 'Received content: ' + str(content)
    
    connBuffer += 'Content: ' + str(content)
    
    return connBuffer

#===============================================================================
# Incoming socket handling function.
def handle(sock):
    # Do socket exchanges with the client
    conn = h2.connection.H2Connection(client_side=False)
    conn.initiate_connection()
    sock.sendall(conn.data_to_send())
    
    # Process data
    while True:
        # Read a block
        data = sock.recv(65535)
        
        # Break if nothing more read
        if not data: break
        
        # Put data onto the queue for a thread to process
        threadData = ((sock, conn, data))
        processData(threadData)
        #q.put(threadData)
        
    if options.verbose not in ['low', 'none']: print('Closing a socket')

#===============================================================================
# Main function
# Get inputs
commandInput()

# *** Queue and thread setup ***
# Set up a queue
q=queue.Queue()
r=queue.Queue()

# Create threads and start them
pool=[]
for i in range(10):
          t=processingThread(i,q)
          pool.append(t)
          t.daemon = True
          t.start()

# Open the socket
print('Opening socket ' + str(options.ip) + ':' + str(options.port))
sock = socket.socket()
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
sock.bind((options.ip, int(options.port)))
sock.listen(10)

# Loop forever
while True:
        print('Waiting for a connection')
        # Get incoming socket indication
        #handle(sock.accept()[0])
        q.put(sock.accept()[0])
        
