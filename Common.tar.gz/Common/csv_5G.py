#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:35:20
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:35:20
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:35:19
#===============================================================================
#
# Copyright 2011 - 2019, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
from __future__ import print_function
# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
import os, time, sys, pprint
import csv_prim as PRIM
import csv_data as DATA
import qa_utils_5G as QAUTILS5G

# 5G Server data
FiveGServerRunning = False

# Define where to write the temp files
tempFileDir='/home/mtx/'

#==========================================================
def retrieveAndValidate5GSyPolicyData(lclDCT, msg):
        #pprint.pprint(msg)
        
        # Assume success
        validation = True
        
        # Get policy data from the message.  Input is a string.
        # Input from Event is a string but in a dictionary format, so leverage this to create the dictionary.
        try:
                # Sometimes seeing multiple Content coming back.  Not good...  Make sure the content ends with a "}" and to be double sure take the last one.
                prefix = 'Content: '
                policyData = [x for x in msg.split('\n') if x.startswith(prefix) and x[-1] == '}'][-1]
        except:
                #print('Hmmm.  Had issues processing policy data.  Maybe multiple responses were sent back.  Using the full message: ' + msg)
                policyData = msg
                prefix = ''
        
        # Convert string to dictionary
        try: policyData = eval(policyData[len(prefix):])
        except:
                # Have seen this when there are multiple 5G messges queued
                print('ERROR:  Couldn\'t parse policy data.  Receive data is: ' + msg)
                return False 
        
        # Debug output
        if 'verbose' in lclDCT and lclDCT['verbose'].lower() not in ['low', 'none']:
                print('policyData: ')
                for key in list(policyData['statusInfos'].keys()): print(key + ': ' + policyData['statusInfos'][key]['currentStatus'])
        
        # Shrink policy data to key and value
        lclPolicyData = {}
        for key in list(policyData['statusInfos'].keys()): lclPolicyData[key] = policyData['statusInfos'][key]['currentStatus']
        
        # Check if we should evaluate policy
        if not PRIM.policyValidationInputChecks(lclDCT): return validation
        
        # Get policy info to validate
        policyIdentifier = lclDCT['policyIdentifier']
        policyStatus = lclDCT['policyStatus']
        policyPartial = lclDCT['policyPartial']
        
        # Process each parameter to evaluate
        for i in range(len(policyIdentifier)):
                failFlag = False
                policyId = policyIdentifier[i]
                policySt = policyStatus[i]
                
                # See if policy was returned
                if policyId not in lclPolicyData: 
                        # Expected policy was not returned
                        print('ERROR: command referenced policy "' + policyId + '" that wasn\'t returned')
                        failFlag = True
                        validation = False
                
                # See if status matches
                if lclPolicyData[policyId] != policySt:
                        # Expected state not present
                        print('ERROR: policy "' + policyId + '" expected value is "' + policySt + '" but returned as "' + lclPolicyData[policyId] + '"')
                        failFlag = True
                        validation = False
                
                # If here then we matched or failed.
                # Remove entry so we can detect if policy was returned that wasn;t explicitly called out
                if not failFlag: del lclPolicyData[policyId]
        
        # See if additional policy was returned
        if len(lclPolicyData):
                # FYI output
                print('Policies were returned that were not listed to be validated')
                print('Additional returned policies:' + str(lclPolicyData))
                
                # Check if expected
                if not policyPartial:
                        print('The policyPartial parameter was not set.')
                        validation = False
        # Debug
        print('5G Sy validation result: ' + str(validation))
        
        # Return result
        return validation

#==========================================================
# This function receives a message from the HTTP server.
# For now it uses files to pass the data.  Can (and should) use messages but this is easier for the author...
def getHttpServerMessage(lclDCT, recipient="TF"):
        global tempFileDir
        
        # *** lclDCT[] has all the values.
        
        # Sender/receiver use file prefix to distinguish direction.
        if recipient == 'HTTP': prefix = 'X'
        else:                   prefix = ""
        
        # Expect a file in tempFileDir with the session ID.
        # Notifications use the word "notify" and not the session ID.
        #if lclDCT['interface'].lower() == '5gsy': sessionId = QAUTILS5G.sbaPort + 'notify'
        #else: sessionId = lclDCT['sessionId'] # Added during Python3 migration
        sessionId = lclDCT['sessionId'] # Added during Python3 migration
        
        fileName = tempFileDir + prefix + sessionId
        try:
                if lclDCT['verbose'].lower() not in ['low', 'none']: print(recipient + ' - ' + lclDCT['interface'] + ' Notify: Looking for session ' + sessionId + ' file: ' + fileName)
        except: pass
        
        # timeToWaitInterval is the time per check.
        # timeToWait is the total time to wait.
        # Get the number of times to try to look for the file.
        intervals = int(float(lclDCT['timeToWait']) / float(lclDCT['timeToWaitInterval']))
        i = 0
        sleepTime = float(lclDCT['timeToWaitInterval'])
        while int(i)< intervals and not os.path.exists(fileName):
                # Wait small increments for file to appear
                time.sleep(sleepTime)
                i += sleepTime
        
        # See if we timed out
        if int(i) >= intervals:
                # See if not expected
                if lclDCT['eventPass']:
                        # Didn't get one and expected to fail
                        print('ERROR: ' + recipient + ' Waiting for session ID ' + sessionId + ' ' + lclDCT['interface'] + ' Notify file ' + fileName + ' but it never came')
                        sys.exit('Exiting due to errors')
                
                # Return if nothing received
                try:
                        if lclDCT['verbose'].lower() not in ['low', 'none']: print(recipient + ' - No ' + lclDCT['interface'] + ' message received for session ' + sessionId + ', OK as eventPass = ' + str(lclDCT['eventPass']))
                except: pass
                return
        
        # Read file
        f = open(fileName, 'r')
        msg = f.read() + '\n'
        f.close()
        
        # Remove the file
        os.remove(fileName)
        
        return msg

#==========================================================
# This function receives a message from the HTTP server.
# For now it uses files to pass the data.  Can (and should) use messages but this is easier for the author...
def sendHttpServerMessage(msg, sessionId, sender="TF"):
        global tempFileDir
        
        # Sender/receiver use file prefix to distinguish direction.
        if sender == 'TF': prefix = 'X'
        else:              prefix = ""
        
        # Write the response to the file
        fileName = tempFileDir + prefix + sessionId
        f = open(fileName, 'w')
        f.write(msg)
        f.close()
        print (sender + ' - message for session ' + sessionId + ' written to file: ' + fileName)
        
        return
        
#==========================================================
# This function processes SBA notifications
def FiveGReceiveNotify(lclDCT, options, diamConnection, extraAVP):
        # *** lclDCT[] has all the values.
        
        # Get the message from the HTTP server
        msg = getHttpServerMessage(lclDCT, "TF")
        
        # If expecting a failure, then return now
        if not lclDCT['eventPass']: return
        
        # Change session ID value if this is not session ID based (i.e. Sy notifications)
        #if lclDCT['interface'].lower() == '5gsy': sessionId = QAUTILS5G.sbaPort + 'notify'
        #else: sessionId = lclDCT['sessionId'] # Added during Python3 migration
        sessionId = lclDCT['sessionId'] # Added during Python3 migration
        
        # Debug 
        if lclDCT['verbose'].lower() not in ['low', 'none']:
                print('TF - Notify message for session ' + sessionId + ': ')
                print(msg)
        
        # Validate the counters
        if lclDCT['interface'].lower() == '5gsy': validation = retrieveAndValidate5GSyPolicyData(lclDCT, msg)
        else: validation = True
        
        # Formulate the response
        if lclDCT['noReply']:
                if lclDCT['verbose'].lower() not in ['low', 'none']: print('Indicate no reply to 5G SBA for session ' + sessionId)
                outStr = '-1\n'
        elif lclDCT['failCode'] > 0:
                if lclDCT['verbose'].lower() not in ['low', 'none']: print('Indicate failure to 5G SBA for session ' + sessionId)
                outStr = lclDCT['failCode'] + '\n'
        elif not validation:
                if lclDCT['verbose'].lower() not in ['low', 'none']: print('Validation failed.  Indicate failure to 5G SBA for session ' + sessionId)
                outStr = '500\n'
        else:
                if lclDCT['verbose'].lower() not in ['low', 'none']: print('Indicate success to 5G SBA for session ' + sessionId)
                outStr = '0\n'
        
        # Send the message to the HTTP server
        #sendHttpServerMessage(outStr, sessionId, 'TF')
        
        # Sleep for a second so HTTP server can act
        #time.sleep(1)
        
        # See if validation failed and was expecting a success
        if validation != lclDCT['eventPass']:
                print('Exiting 5G Sy validation becuase result (' + str(validation) + ') didn\'t match expectation (' + str(lclDCT['eventPass']) + ')')
                
                # Now exit
                sys.exit()
        
#==========================================================
def main():
    x = 1


if __name__ == '__main__':
    main()

#===============================================================================
#
# Copyright 2011 - 2019, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

