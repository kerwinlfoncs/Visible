#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:44
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:24
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:05
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================



defaultnourl = 'none'
defaultnoinput = '99999'

# Define a single structure that manages service definitions
serviceIdDefs = {}
serviceIdDefs['voice'] =        {'serviceIdDct':'3',    'serviceIdContextDct':'3',      'serviceContextQSMsccDct':'actualDuration',     'serviceContextQSDct':'actualDuration'}
serviceIdDefs['data'] =         {'serviceIdDct':'2',    'serviceIdContextDct':'2',      'serviceContextQSMsccDct':'totalData',          'serviceContextQSDct':'totalData'}
serviceIdDefs['sms'] =          {'serviceIdDct':'1',    'serviceIdContextDct':'1',      'serviceContextQSMsccDct':None,                 'serviceContextQSDct':None}
serviceIdDefs['mms'] =          {'serviceIdDct':'1',    'serviceIdContextDct':'1',      'serviceContextQSMsccDct':'serviceSpecific',    'serviceContextQSDct':'serviceSpecific'}
serviceIdDefs['msg'] =          {'serviceIdDct':'1',    'serviceIdContextDct':'1',      'serviceContextQSMsccDct':None,                 'serviceContextQSDct':None}
serviceIdDefs['stream']=        {'serviceIdDct':'3',    'serviceIdContextDct':'3',      'serviceContextQSMsccDct':None,                 'serviceContextQSDct':None}
serviceIdDefs['fixed'] =        {'serviceIdDct':'3',    'serviceIdContextDct':'3',      'serviceContextQSMsccDct':None,                 'serviceContextQSDct':None}
serviceIdDefs['text']  =        {'serviceIdDct':'4',    'serviceIdContextDct':'4',      'serviceContextQSMsccDct':'serviceSpecific',    'serviceContextQSDct':'serviceSpecific'}
serviceIdDefs['gprs2'] =        {'serviceIdDct':'33',   'serviceIdContextDct':'33',     'serviceContextQSMsccDct':'totalData',                 'serviceContextQSDct':'totalData'}
serviceIdDefs['gprs22'] =       {'serviceIdDct':'7783', 'serviceIdContextDct':'7783',   'serviceContextQSMsccDct':'totalData',            'serviceContextQSDct':'totalData'}
serviceIdDefs['gprs23'] =       {'serviceIdDct':'7789', 'serviceIdContextDct':'7789',   'serviceContextQSMsccDct':'totalData',            'serviceContextQSDct':'totalData'}
serviceIdDefs['gprs3'] =        {'serviceIdDct':'25',   'serviceIdContextDct':'25',     'serviceContextQSMsccDct':'totalData',          'serviceContextQSDct':'totalData'}
serviceIdDefs['gprs55'] =       {'serviceIdDct':'555',  'serviceIdContextDct':'555',    'serviceContextQSMsccDct':'totalData',          'serviceContextQSDct':None}
serviceIdDefs['gprs333'] =       {'serviceIdDct':'330', 'serviceIdContextDct':'330',    'serviceContextQSMsccDct':'totalData',          'serviceContextQSDct':'totalData'}
serviceIdDefs['netflix'] =      {'serviceIdDct':'2',    'serviceIdContextDct':'54321',  'serviceContextQSMsccDct':'inData',             'serviceContextQSDct':'inData'}
serviceIdDefs['netflix3'] =     {'serviceIdDct':'25',   'serviceIdContextDct':'67890',  'serviceContextQSMsccDct':'inData',             'serviceContextQSDct':'inData'}
serviceIdDefs['netflix55'] =    {'serviceIdDct':'555',  'serviceIdContextDct':'55123',  'serviceContextQSMsccDct':'inData',             'serviceContextQSDct':None}
serviceIdDefs['netflix_out55'] ={'serviceIdDct':'555',  'serviceIdContextDct':'55124',  'serviceContextQSMsccDct':'outData',            'serviceContextQSDct':None}
serviceIdDefs['netflix_total55'] = {'serviceIdDct':'555','serviceIdContextDct':'55125', 'serviceContextQSMsccDct':'totalData',          'serviceContextQSDct':None}
serviceIdDefs['skype1'] =       {'serviceIdDct':'25',   'serviceIdContextDct':'60001',  'serviceContextQSMsccDct':'totalData',          'serviceContextQSDct':None}
serviceIdDefs['skype2'] =       {'serviceIdDct':'25',   'serviceIdContextDct':'60002',  'serviceContextQSMsccDct':'totalData',          'serviceContextQSDct':None}
serviceIdDefs['skype3'] =       {'serviceIdDct':'25',   'serviceIdContextDct':'60003',  'serviceContextQSMsccDct':'totalData',          'serviceContextQSDct':None}
serviceIdDefs['skype4'] =       {'serviceIdDct':'25',   'serviceIdContextDct':'60004',  'serviceContextQSMsccDct':'totalData',          'serviceContextQSDct':None}
serviceIdDefs['skype5'] =       {'serviceIdDct':'25',   'serviceIdContextDct':'60005',  'serviceContextQSMsccDct':'totalData',          'serviceContextQSDct':None}
serviceIdDefs['skype6'] =       {'serviceIdDct':'25',   'serviceIdContextDct':'60006',  'serviceContextQSMsccDct':'totalData',          'serviceContextQSDct':None}
serviceIdDefs['skype7'] =       {'serviceIdDct':'25',   'serviceIdContextDct':'60007',  'serviceContextQSMsccDct':'totalData',          'serviceContextQSDct':None}
serviceIdDefs['netflix_out'] =  {'serviceIdDct':'2',    'serviceIdContextDct':'54322',  'serviceContextQSMsccDct':'outData',            'serviceContextQSDct':'outData'}
serviceIdDefs['voice1'] =       {'serviceIdDct':'3',    'serviceIdContextDct':'99881',  'serviceContextQSMsccDct':'actualDuration',     'serviceContextQSDct':None}
serviceIdDefs['voice2'] =       {'serviceIdDct':'3',    'serviceIdContextDct':'99882',  'serviceContextQSMsccDct':'actualDuration',     'serviceContextQSDct':None}
serviceIdDefs['talk1'] =        {'serviceIdDct':'800',  'serviceIdContextDct':'89881',  'serviceContextQSMsccDct':'actualDuration',     'serviceContextQSDct':'actualDuration'}
serviceIdDefs['talk2'] =        {'serviceIdDct':'800',  'serviceIdContextDct':'89882',  'serviceContextQSMsccDct':'actualDuration',     'serviceContextQSDct':'actualDuration'}
serviceIdDefs['video1'] =       {'serviceIdDct':'330',  'serviceIdContextDct':'77889',  'serviceContextQSMsccDct':'totalData',     	'serviceContextQSDct':'totalData'}
serviceIdDefs['video2'] =       {'serviceIdDct':'330',  'serviceIdContextDct':'77888',  'serviceContextQSMsccDct':'totalData',     	'serviceContextQSDct':'totalData'}
serviceIdDefs['video3'] =       {'serviceIdDct':'330',  'serviceIdContextDct':'77890',  'serviceContextQSMsccDct':'totalData',     	'serviceContextQSDct':'totalData'}
serviceIdDefs['movie1'] =       {'serviceIdDct':'330',  'serviceIdContextDct':'77887',  'serviceContextQSMsccDct':'totalData',     	'serviceContextQSDct':'totalData'}
serviceIdDefs['movie2'] =       {'serviceIdDct':'330',  'serviceIdContextDct':'77886',  'serviceContextQSMsccDct':'totalData',     	'serviceContextQSDct':'totalData'}
serviceIdDefs['money'] =       {'serviceIdDct':'888',  'serviceIdContextDct':'888',  'serviceContextQSMsccDct':'monetary',          'serviceContextQSDct':'monetary'}
serviceIdDefs['multiFields'] =  {'serviceIdDct':'44',   'serviceIdContextDct':'44',     'serviceContextQSMsccDct':'totalData',          'serviceContextQSDct':'totalData'}
serviceIdDefs['netflix_actual_duration'] = {'serviceIdDct':'2', 'serviceIdContextDct':'54323',  'serviceContextQSMsccDct':'actualDuration', 'serviceContextQSDct':'actualDuration'}
serviceIdDefs['mixvoicemsg'] = {'serviceIdDct':'7777', 'serviceIdContextDct':'7777',  'serviceContextQSMsccDct':'actualDuration', 'serviceContextQSDct':'actualDuration'}
serviceIdDefs['mixvoice2'] = {'serviceIdDct':'7777', 'serviceIdContextDct':'99882',  'serviceContextQSMsccDct':'mixvoicemsg', 'serviceContextQSDct':'actualDuration'}
serviceIdDefs['mixvoice3'] = {'serviceIdDct':'7777', 'serviceIdContextDct':'9883',  'serviceContextQSMsccDct':'mixvoicemsg', 'serviceContextQSDct':'actualDuration'}
serviceIdDefs['mixvoice1'] = {'serviceIdDct':'7777', 'serviceIdContextDct':'99881',  'serviceContextQSMsccDct':'actualDuration', 'serviceContextQSDct':'actualDuration'}
serviceIdDefs['rgmixvoicemsg'] = {'serviceIdDct':'7777', 'serviceIdContextDct':'17777',  'serviceContextQSMsccDct':'actualDuration', 'serviceContextQSDct':'actualDuration'}
#serviceIdDefs['rgmixvoicemsg'] = {'serviceIdDct':'7777', 'serviceIdContextDct':'17777',  'serviceContextQSMsccDct':'service_specific', 'serviceContextQSDct':'service_specific'}
serviceIdDefs['TextAuthFull']  =        {'serviceIdDct':'4',    'serviceIdContextDct':'4444',      'serviceContextQSMsccDct':'serviceSpecific',    'serviceContextQSDct':'serviceSpecific'}
serviceIdDefs['TextAggregated']  =        {'serviceIdDct':'4',    'serviceIdContextDct':'44443',      'serviceContextQSMsccDct':'serviceSpecific',    'serviceContextQSDct':'serviceSpecific'}
serviceIdDefs['TextAggregatedSession']  =        {'serviceIdDct':'4',    'serviceIdContextDct':'44445',      'serviceContextQSMsccDct':'serviceSpecific',    'serviceContextQSDct':'serviceSpecific'}
serviceIdDefs['voice3'] =       {'serviceIdDct':'3',    'serviceIdContextDct':'99883',  'serviceContextQSMsccDct':'actualDuration',     'serviceContextQSDct':None}
serviceIdDefs['gprsauthfull'] =         {'serviceIdDct':'2',    'serviceIdContextDct':'54324',      'serviceContextQSMsccDct':'totalData',          'serviceContextQSDct':'totalData'}

serviceIdDefs['voice4_fui_notif'] = {'serviceIdDct':'3', 'serviceIdContextDct':'99884',  'serviceContextQSMsccDct':'actualDuration', 'serviceContextQSDct':'actualDuration'}
serviceIdDefs['voice5_fui_notif_GSU0'] = {'serviceIdDct':'3', 'serviceIdContextDct':'99885',  'serviceContextQSMsccDct':'actualDuration', 'serviceContextQSDct':'actualDuration'}
#  ** Entry for an undefined service (MTX-11410) **
serviceIdDefs['badservice'] =    {'serviceIdDct':'999999',    'serviceIdContextDct':'999999',      'serviceContextQSMsccDct':'actualDuration',     'serviceContextQSDct':'actualDuration'}
serviceIdDefs['TextAuthFull']  =        {'serviceIdDct':'4',    'serviceIdContextDct':'4444',      'serviceContextQSMsccDct':'serviceSpecific',    'serviceContextQSDct':'serviceSpecific'}
serviceIdDefs['data_context_notify'] =         {'serviceIdDct':'2',    'serviceIdContextDct':'54325',      'serviceContextQSMsccDct':'totalData',          'serviceContextQSDct':'totalData'}

serviceIdDefs['gprs_event_mapping'] = {'serviceIdDct':'7778', 'serviceIdContextDct':'7778',  'serviceContextQSMsccDct':'totalData', 'serviceContextQSDct':'totalData'}
serviceIdDefs['gprs_event_mapping_subtype'] = {'serviceIdDct':'7780', 'serviceIdContextDct':'7780',  'serviceContextQSMsccDct':'totalData', 'serviceContextQSDct':'totalData'}
serviceIdDefs['gprs3_subtype'] = {'serviceIdDct':'7782', 'serviceIdContextDct':'7782',  'serviceContextQSMsccDct':'totalData', 'serviceContextQSDct':'totalData'}

serviceIdDefs['gprs_aggregated']  =        {'serviceIdDct':'2',    'serviceIdContextDct':'54326',      'serviceContextQSMsccDct':'totalData',    'serviceContextQSDct':'totalData'}
serviceIdDefs['gprs_track_session']  =     {'serviceIdDct':'2',    'serviceIdContextDct':'54327',      'serviceContextQSMsccDct':'totalData',    'serviceContextQSDct':'totalData'}

serviceIdDefs['voice_min_auth'] =        {'serviceIdDct':'3',    'serviceIdContextDct':'99889',      'serviceContextQSMsccDct':'actualDuration',     'serviceContextQSDct':'actualDuration'}
serviceIdDefs['voice_aggregated']  =     {'serviceIdDct':'3',    'serviceIdContextDct':'99890',      'serviceContextQSMsccDct':'actualDuration',    'serviceContextQSDct':'actualDuration'}
serviceIdDefs['voice_aggregated_daily']  =     {'serviceIdDct':'3',    'serviceIdContextDct':'99891',      'serviceContextQSMsccDct':'actualDuration',    'serviceContextQSDct':'actualDuration'}


serviceIdDefs['units_cumulative'] =       {'serviceIdDct':'3',    'serviceIdContextDct':'99886',  'serviceContextQSMsccDct':'actualDuration',     'serviceContextQSDct':None}
serviceIdDefs['usu_cumulative'] =       {'serviceIdDct':'3',    'serviceIdContextDct':'99887',  'serviceContextQSMsccDct':'actualDuration',     'serviceContextQSDct':None}
serviceIdDefs['gsu_cumulative'] =       {'serviceIdDct':'3',    'serviceIdContextDct':'99888',  'serviceContextQSMsccDct':'actualDuration',     'serviceContextQSDct':None}
serviceIdDefs['gprs_global'] = {'serviceIdDct':'7788', 'serviceIdContextDct':'7788',  'serviceContextQSMsccDct':'totalData', 'serviceContextQSDct':'totalData'}

serviceIdDefs['gprs_authorize_simple'] = {'serviceIdDct':'7786', 'serviceIdContextDct':'7786', 'serviceContextQSMsccDct':'totalData', 'serviceContextQSDct':'totalData'}
serviceIdDefs['gprs_authorize_full_beat'] = {'serviceIdDct':'7786', 'serviceIdContextDct':'77860', 'serviceContextQSMsccDct':'totalData', 'serviceContextQSDct':'totalData'}
serviceIdDefs['gprs_authorize_full_request'] = {'serviceIdDct':'7786', 'serviceIdContextDct':'77861', 'serviceContextQSMsccDct':'totalData', 'serviceContextQSDct':'totalData'}
serviceIdDefs['gprs_authorize_minimum_request'] = {'serviceIdDct':'7786', 'serviceIdContextDct':'77862', 'serviceContextQSMsccDct':'totalData', 'serviceContextQSDct':'totalData'}
serviceIdDefs['gprs_total_data'] = {'serviceIdDct':'7787', 'serviceIdContextDct':'77870', 'serviceContextQSMsccDct':'totalData', 'serviceContextQSDct':'totalData'}
serviceIdDefs['gprs_actual_duration'] = {'serviceIdDct':'7787', 'serviceIdContextDct':'77871', 'serviceContextQSMsccDct':'actualDuration', 'serviceContextQSDct':'actualDuration'}
serviceIdDefs['gprs_vf'] = {'serviceIdDct':'7793', 'serviceIdContextDct':'7793', 'serviceContextQSMsccDct':'totalData', 'serviceContextQSDct':'totalData'}
serviceIdDefs['sessionBased'] = {'serviceIdDct':'7793',   'serviceIdContextDct':'67123',  'serviceContextQSMsccDct':'totalData', 'serviceContextQSDct':'totalData'}
serviceIdDefs['voice_session_monitor'] =        {'serviceIdDct':'7795',    'serviceIdContextDct':'7795',      'serviceContextQSMsccDct':'actualDuration',     'serviceContextQSDct':'actualDuration'}
serviceIdDefs['data_session_monitor'] =         {'serviceIdDct':'7794',    'serviceIdContextDct':'7794',      'serviceContextQSMsccDct':'totalData',          'serviceContextQSDct':'totalData'}
serviceIdDefs['voice_session_monitor_aggregation'] =        {'serviceIdDct':'7795',    'serviceIdContextDct':'7796',      'serviceContextQSMsccDct':'actualDuration',     'serviceContextQSDct':'actualDuration'}




# These are 3GPP defined values for the message request type.
# NOTE:  these are changed in MEF records to match RADIUS values.  Those are 2, 3, 4, 1.
reqTypeDct = {'initial':'1', 'startAuthId':'1','interim':'2', 'term':'3', 'event':'4'}

# extra AVPs?

url='x.com'
qos='qos'
appid='123'
appbw='something'
appbearer='som'
networkid='1.2.3.5'
demoRatingGroup='12'
demoDeviceType=1
demoLocation='nowhere'
demoQos='34'

# Define session ID prefix used by framework
GySessionIdPrefix = 'MATRIXX-QA-TESTING.;1;'
GxSessionIdPrefix = 'MATRIXX-GX-TESTING.;1;'
SySessionIdPrefix = 'MATRIXX-SY-TESTING.;1;'
ShSessionIdPrefix = 'MATRIXX-SH-TESTING.;1;'
RxSessionIdPrefix = 'MATRIXX-RX-TESTING.;1;'

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

