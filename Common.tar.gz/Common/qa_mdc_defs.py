#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:50
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:30
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:09
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================



# from builtins import str
# from builtins import str
import os,sys,re
import data_container_defs as MDCDEFS
import data_container as MDC
import QA_subscriber_management_restv3 as REST_UTIL
import qa_utils as QAUTILS
import timeToMDCtime as MDCTIME
import xml.etree.cElementTree as ET
import restV3 as REST
import json

#====================================================================
def getSessionId (queryResult):
     if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
     else :
       resMdc = queryResult

     MtxDiamRoMsg = resMdc.getUsingKey(MDCDEFS.kMtxResponseRatingObjectIdFldKey)
     return resMdc.getUsingKey(MDCDEFS.kMtxResponseGroupObjectIdFldKey)

#====================================================================
def getDeviceSessionId (queryResult):
     if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
     else :
       resMdc = queryResult

     chargingSessions = resMdc.getUsingKey(MDCDEFS.kMtxResponseDeviceSessionChargingSessionArrayFldKey)
     sessionIds = []

     if chargingSessions is not None:
        for session in chargingSessions:
            id = session.getUsingKey(MDCDEFS.kMtxChargingSessionInfoSessionIdFldKey)
            sessionIds.append(id)

     policySessions = resMdc.getUsingKey(MDCDEFS.kMtxResponseDeviceSessionPolicySessionArrayFldKey)

     if policySessions is not None:
        for session in policySessions:
            id = session.getUsingKey(MDCDEFS.kMtxPolicySessionInfoSessionIdFldKey)
            sessionIds.append(id)

     return sessionIds

#====================================================================
def getDeviceSession5G (queryResult):
     if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
     else :
       resMdc = queryResult

     chargingSessions = resMdc.getUsingKey(MDCDEFS.kMtxResponseDeviceSessionChargingSessionArrayFldKey)
     sessionIds = []

     if chargingSessions is not None:
        for session in chargingSessions:
            id = session.getUsingKey(MDCDEFS.kMtxChargingSessionInfoIs5GFldKey)
            sessionIds.append(id)

     policySessions = resMdc.getUsingKey(MDCDEFS.kMtxResponseDeviceSessionPolicySessionArrayFldKey)

     if policySessions is not None:
        for session in policySessions:
            id = session.getUsingKey(MDCDEFS.kMtxPolicySessionInfoIs5GFldKey)
            sessionIds.append(id)

     return sessionIds

#====================================================================
def getGroupOid (queryResult):
     print(queryResult)
     if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
     else :
       resMdc = queryResult

     return resMdc.getUsingKey(MDCDEFS.kMtxResponseGroupObjectIdFldKey)
   
#====================================================================
def getGroupExternalId (queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxResponseGroupExternalIdFldKey)

#====================================================================
def getGroupParentOid (queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxResponseGroupParentGroupIdFldKey)

#====================================================================
def getGroupNotificationPreference (queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxResponseGroupNotificationPreferenceFldKey
)
#====================================================================
def getGroupSubscriberMemberArray (queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxResponseGroupSubscriberMemberIdArrayFldKey)

#====================================================================
def getGroupGroupMemberArray (queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxResponseGroupGroupMemberIdArrayFldKey)

#====================================================================
def getGroupAdminIdArray (queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxResponseGroupAdminIdArrayFldKey)

#====================================================================
def getGroupSubscriberMemberCount (queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxResponseGroupSubscriberMemberCountFldKey)

#====================================================================
def getGroupAdminCount (queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxResponseGroupAdminCountFldKey)


#====================================================================
def getGroupSubscriberMemberCursor (queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxResponseGroupSubscriberMemberCursorFldKey)


#====================================================================
def getGroupAdminCursor (queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxResponseGroupAdminCursorFldKey)


#====================================================================
def getGroupGroupMemberCursor (queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdR.getUsingKey(MDCDEFS.kMtxResponseGroupGroupMemberCursorFldKey)

#====================================================================
def getMemberResultSetObjectIdArray (queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxResponseMemberResultSetObjectIdArrayFldKey)

#====================================================================
def getMemberResultSetExternalIdArray (queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult
    print(resMdc)
    return resMdc.getUsingKey(MDCDEFS.kMtxResponseMemberResultSetExternalIdArrayFldKey)

#====================================================================
def getGroupBalanceArray(queryResult):
    return queryResult.getUsingKey(MDCDEFS.kMtxResponseGroupBalanceArrayFldKey)

#====================================================================
def getSubscriberOid (queryResult):
    if REST_UTIL.restVersion == 'REST' :
       oid = REST.getOID(queryResult)
    else :
       #resMdc = queryResult
       oid = queryResult.getUsingKey(MDCDEFS.kMtxResponseSubscriberObjectIdFldKey)
    #return resMdc.getUsingKey(MDCDEFS.kMtxResponseSubscriberObjectIdFldKey)
    return oid

#====================================================================
def getSubscriberAggregateGroupId (queryResult):
    if REST_UTIL.restVersion == 'REST' :
       #queryResult = re.sub(r'false','0',queryResult)
       #queryResult = re.sub(r'true','1',queryResult)
       #resMdc = MDC.readFromElementBasedXMLStr(queryResult)
       aggregateId = REST.getAggregateGroupId(queryResult)
    else :
       #resMdc = queryResult
       balanceArray = queryResult.getUsingKey(MDCDEFS.kMtxResponseSubscriberBalanceArrayFldKey)
       aggregateId = balanceArray[0].getUsingKey(MDCDEFS.kMtxBalanceInfoAggregateGroupIdFldKey)
    return aggregateId

#====================================================================
def getGroupAggregateGroupId (queryResult):
    if REST_UTIL.restVersion == 'REST' :
       #queryResult = re.sub(r'false','0',queryResult)
       #queryResult = re.sub(r'true','1',queryResult)
       #resMdc = MDC.readFromElementBasedXMLStr(queryResult)
       aggregateId = REST.getAggregateGroupId(queryResult)
    else :
       #resMdc = queryResult
       balanceArray = queryResult.getUsingKey(MDCDEFS.kMtxResponseGroupBalanceArrayFldKey)
       aggregateId = balanceArray[0].getUsingKey(MDCDEFS.kMtxBalanceInfoAggregateGroupIdFldKey)
    return aggregateId

#====================================================================
def getWalletAggregateGroupId (queryResult):
    if REST_UTIL.restVersion == 'REST' :
       #queryResult = re.sub(r'false','0',queryResult)
       #queryResult = re.sub(r'true','1',queryResult)
       #resMdc = MDC.readFromElementBasedXMLStr(queryResult)
       aggregateId = REST.getAggregateGroupId(queryResult)
    else :
       #resMdc = queryResult
       balanceArray = queryResult.getUsingKey(MDCDEFS.kMtxResponseWalletBalanceArrayFldKey)
       aggregateId = balanceArray[0].getUsingKey(MDCDEFS.kMtxBalanceInfoAggregateGroupIdFldKey)
    return aggregateId

#====================================================================
def getSubscriberExternalId (queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxResponseSubscriberExternalIdFldKey)

#====================================================================
def getSubscriberDeviceArray (queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxResponseSubscriberDeviceIdArrayFldKey)

#====================================================================
def getSubscriberBalanceArray(queryResult):
    return queryResult.getUsingKey(MDCDEFS.kMtxResponseSubscriberBalanceArrayFldKey)

#====================================================================
def getSubscriberNotificationPreference (queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxResponseSubscriberNotificationPreferenceFldKey)

#====================================================================
def getSubscriberParentGroupCursor (queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxResponseSubscriberParentGroupCursorFldKey)


#====================================================================
def getSubscriberParentGroupIdArray (queryResult):
    #print queryResult
   # if REST_UTIL.restVersion == 'REST' :
   #    queryResult = re.sub(r'false','0',queryResult)
   #    queryResult = re.sub(r'true','1',queryResult)
   #    resMdc = MDC.readFromElementBasedXMLStr(queryResult)
   # else :
   #    resMdc = queryResult

   # return resMdc.getUsingKey(MDCDEFS.kMtxResponseSubscriberParentGroupIdArrayFldKey)
    try:
        IdArray = queryResult.getUsingKey(MDCDEFS.kMtxResponseSubscriberParentGroupIdArrayFldKey)
    except:
        queryResult = re.sub(r'false','0',queryResult)
        queryResult = re.sub(r'true','1',queryResult)
        resMdc = MDC.readFromElementBasedXMLStr(queryResult)
        IdArray = resMdc.getUsingKey(MDCDEFS.kMtxResponseSubscriberParentGroupIdArrayFldKey)
    
    return IdArray


#=ne=================================================================
def getDeviceOid(queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxResponseDeviceObjectIdFldKey)

#====================================================================
def getDeviceExternalId(queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxResponseDeviceExternalIdFldKey)

#====================================================================
def getDeviceSubscriberId(queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxResponseDeviceSubscriberIdFldKey)

#====================================================================
def getDeviceAttr(queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxResponseDeviceAttrFldKey)

#====================================================================
def getDeviceImsi(queryResult):
    attr = getDeviceAttr(queryResult)
    return attr.getUsingKey(MDCDEFS.kMtxMobileDeviceExtensionImsiFldKey)
    
#====================================================================
def getDeviceAccessNumberArray(queryResult):
    attr = getDeviceAttr(queryResult)
    return attr.getUsingKey(MDCDEFS.kMtxMobileDeviceExtensionImsiFldKey)

#====================================================================
def getDeviceRecurringChargeArray(queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxResponseDeviceRecurringChargeArrayFldKey)


#====================================================================
def getWalletBalanceArray(queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxResponseWalletBalanceArrayFldKey)

#====================================================================
def getWalletSimpleBalanceArray(queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxWalletObjectSimpleBalanceArrayFldKey)

#====================================================================
def getWalletPeriodicBalanceArray(queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxWalletObjectPeriodicBalanceArrayFldKey)

#====================================================================
def getPeriodicBalanceThresholdId(balancePeriodicInfoObj, idx):
    thresholdArray = balancePeriodicInfoObj.getUsingKey(MDCDEFS.kMtxBalanceInfoPeriodicThresholdArrayFldKey)
    return thresholdArray[idx].getUsingKey(MDCDEFS.kMtxThresholdInfoThresholdIdFldKey)

#====================================================================
def getEventId(eventQueryResult) :
    eventIds=[]
    if REST_UTIL.restVersion == 'REST' :
        root = ET.fromstring(eventQueryResult)
        elist = root.find('EventList')
        for child in elist:
            eventIds.append(child.find('EventId').text)
    elif REST_UTIL.restVersion == 'JSON' :
        r1 = re.findall(r'HQGQA_[0-9]+:[0-9]+:[0-9]+:[0-9]+', eventQueryResult)
        for child in r1:
            eventIds.append(child)
    else :
        events = eventQueryResult.getUsingKey(MDCDEFS.kMtxResponseEventInfoEventListFldKey)
        for e in events :
            eid = e.getUsingKey(MDCDEFS.kMtxEventEventIdFldKey)
            eventIds.append(eid)
   
    return eventIds

#====================================================================
def getMultiRequestResponseList(queryResult):
    print(queryResult)
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxResponseMultiResponseListFldKey)

#====================================================================
# return string type or None
def getEligibilityCatalogItemId(response):
    eligibilityCatalogItemId = None
    if REST_UTIL.restVersion == 'REST' :
       try:
          responseXml = ET.XML(response)
          eligibilityCatalogItemId = responseXml.findtext('EligibilityCatalogItemId') 
       except Exception as inst:
          return None
    else :
       if response is None:
         return None
       try:
         eligibilityCatalogItemId = response.getUsingKey(MDCDEFS.kMtxResponsePurchaseEligibilityCatalogItemIdFldKey)
       except Exception as NameError:
         return None

    if eligibilityCatalogItemId is not None:
       return str(eligibilityCatalogItemId)
    else:
       return None

#====================================================================
# we must handle 2 cases: eligibility pass or fail 
#For pass, not return at moment, will enhance  in future
#For failure, will skip evaulation once there's failure reason, hence only 1 return for failure 
#each element under tuple returned are string type
def getEligibilityResultList(response, actionType='purchase'):

    resultList = []

    ruleTypeMap = {
       1: "requires",
       2: "excludes"
       }
    objectTypeMap = {
       1: "catalog_item",
       2: "subscriber",
       3: "group",
       4: "device"
       }
    entityTypeMap = {
       1: "feature",
       2: "attribute"
       }
    resultMap = {
       0: "false",
       1: "true"
       }    


    if REST_UTIL.restVersion == 'REST' :
       responseXml = ET.XML(response)
       eligibilityResultList = responseXml.find('EligibilityResultList')
       if eligibilityResultList is None:
          return None

       for eligibilityRuleResult in eligibilityResultList:
          catalogItemId = int(eligibilityRuleResult.findtext("CatalogItemId"))
          ruleType = eligibilityRuleResult.findtext("RuleType")
          eligibilityRule = eligibilityRuleResult.find("EligibilityRule")
          detailedEligibilityRule = None
          value = None
          if eligibilityRule.find("MtxPricingEligibilityStringRule") is not None:
              detailedEligibilityRule = eligibilityRule.find("MtxPricingEligibilityStringRule")
          elif eligibilityRule.find("MtxPricingEligibilityInt64Rule") is not None:
              detailedEligibilityRule = eligibilityRule.find("MtxPricingEligibilityInt64Rule")
          elif eligibilityRule.find("MtxPricingEligibilityDecimalRule") is not None:
              detailedEligibilityRule = eligibilityRule.find("MtxPricingEligibilityDecimalRule")
          elif eligibilityRule.find("MtxPricingEligibilityRule") is not None:
              detailedEligibilityRule = eligibilityRule.find("MtxPricingEligibilityRule")

          if detailedEligibilityRule is not None and detailedEligibilityRule.find("Value") is not None:
              value = detailedEligibilityRule.findtext("Value")
          objectType = detailedEligibilityRule.findtext("ObjectType")
          entityType = detailedEligibilityRule.findtext("EntityType")
          name = detailedEligibilityRule.findtext("Name")
          result = eligibilityRuleResult.findtext("EligibilityResult")
          print((catalogItemId, ruleType, objectType, entityType, name, value, result))
          resultList.append((catalogItemId, ruleType, objectType, entityType, name, value, result))         
       return resultList
    else :
       try:
         if actionType == 'purchase':
           lists = response.getUsingKey(MDCDEFS.kMtxResponsePurchaseEligibilityResultListFldKey)
         elif actionType == 'cancel':
           lists = response.getUsingKey(MDCDEFS.kMtxResponseCancelEligibilityResultListFldKey)
         elif actionType == 'query':
           lists = response.getUsingKey(MDCDEFS.kMtxPricingCatalogItemInfoEligibilityResultListFldKey)
       except Exception as NameError:
         return None

       if lists is None:
         return None
       for list in lists:
         catalogItemId = list.getUsingKey(MDCDEFS.kMtxEligibilityRuleResultCatalogItemIdFldKey)
         ruleType = list.getUsingKey(MDCDEFS.kMtxEligibilityRuleResultRuleTypeFldKey)
         eligibilityRule = list.getUsingKey(MDCDEFS.kMtxEligibilityRuleResultEligibilityRuleFldKey)

         value = None
         if eligibilityRule.descObj.containerKey == MDCDEFS.kMtxPricingEligibilityStringRuleMdcDesc.containerKey:
             value = eligibilityRule.getUsingKey(MDCDEFS.kMtxPricingEligibilityStringRuleValueFldKey)
         elif eligibilityRule.descObj.containerKey == MDCDEFS.kMtxPricingEligibilityInt64RuleMdcDesc.containerKey:
             value = str(eligibilityRule.getUsingKey(MDCDEFS.kMtxPricingEligibilityInt64RuleValueFldKey))
         elif eligibilityRule.descObj.containerKey == MDCDEFS.kMtxPricingEligibilityDecimalRuleMdcDesc.containerKey:
             value = str(eligibilityRule.getUsingKey(MDCDEFS.kMtxPricingEligibilityDecimalRuleValueFldKey))
         objectType = eligibilityRule.getUsingKey(MDCDEFS.kMtxPricingEligibilityRuleObjectTypeFldKey)
         entityType = eligibilityRule.getUsingKey(MDCDEFS.kMtxPricingEligibilityRuleEntityTypeFldKey)
         name = eligibilityRule.getUsingKey(MDCDEFS.kMtxPricingEligibilityRuleNameFldKey)
         result = list.getUsingKey(MDCDEFS.kMtxEligibilityRuleResultEligibilityResultFldKey)

         #Map some field into the type of rest response
         resultList.append((catalogItemId, ruleTypeMap[ruleType], objectTypeMap[objectType], entityTypeMap[entityType], name, value, resultMap[result]))         

       return resultList
    
#====================================================================
# The EligibilityResult returned is list 
# Only called by  query catalog item for subscriber/device/group, not for pricing query
def getEligibilityResultForCatalogItem(response, catalogItemId) :
    catalogItem = None
    if REST_UTIL.restVersion == 'REST' :
        root = ET.fromstring(response)
        clist = root.find('CatalogItemList')
        if clist is not None:
            for child in clist:
                if child.findtext('CatalogItemId') == str(catalogItemId): 
                    catalogItem = ET.tostring(child)
                    break
        else:
            if  root.find('CatalogItemInfo').find('MtxPricingCatalogItemDetailInfo').findtext('CatalogItemId') == str(catalogItemId):
                catalogItem = ET.tostring(root.find('CatalogItemInfo').find('MtxPricingCatalogItemDetailInfo'))
    else:
        if response.descObj.containerKey == MDCDEFS.kMtxResponsePricingCatalogItemListMdcDesc.containerKey:
            catalogItems = response.getUsingKey(MDCDEFS.kMtxResponsePricingCatalogItemListCatalogItemListFldKey)
            for c in catalogItems :
                if c.getUsingKey(MDCDEFS.kMtxPricingCatalogItemInfoCatalogItemIdFldKey) == catalogItemId:
                    catalogItem = c
                    break
        elif response.descObj.containerKey == MDCDEFS.kMtxResponsePricingCatalogItemMdcDesc.containerKey:
            catalogItemInfo  = response.getUsingKey(MDCDEFS.kMtxResponsePricingCatalogItemCatalogItemInfoFldKey)
            catalogItemId = catalogItemInfo.getUsingKey(MDCDEFS.kMtxPricingCatalogItemInfoCatalogItemIdFldKey)
            if catalogItemId == catalogItemId:
                catalogItem = catalogItemInfo

    print("catalog item:", catalogItem)
    return getEligibilityResultList(catalogItem, actionType='query')
#====================================================================
#====================================================================
# Support 2 kinds of response: response from query all catalogs; query for certain catalog by catalog id or external id 
# The size of  catalogIds could be 0 or many
def getCatalogIds(response) :
    catalogIds=[]
    if REST_UTIL.restVersion == 'REST' :
        root = ET.fromstring(response)
        catalogList = root.find('CatalogList')
        if  catalogList is not None:
            for catalog in catalogList:
                if catalog.find('CatalogId') is not None: 
                    catalogIds.append(int(catalog.findtext('CatalogId')))
        else:
            catalogId = root.find('CatalogInfo').find('MtxPricingCatalogDetailInfo').findtext('CatalogId')
            if catalogId is not None:
                catalogIds.append(int(catalogId))
    else :
        if response.descObj.containerKey == MDCDEFS.kMtxResponsePricingCatalogListMdcDesc.containerKey:
            catalogs = response.getUsingKey(MDCDEFS.kMtxResponsePricingCatalogListCatalogListFldKey)
            for c in catalogs :
                cid = c.getUsingKey(MDCDEFS.kMtxPricingCatalogInfoCatalogIdFldKey)
                catalogIds.append(cid)
        elif response.descObj.containerKey == MDCDEFS.kMtxResponsePricingCatalogMdcDesc.containerKey:
            catalogInfo  = response.getUsingKey(MDCDEFS.kMtxResponsePricingCatalogCatalogInfoFldKey)
            catalogId = catalogInfo.getUsingKey(MDCDEFS.kMtxPricingCatalogInfoCatalogIdFldKey)
            catalogIds.append(catalogId)

    #print catalogIds
    return catalogIds

#====================================================================
# Support 2 kinds of response: response from query all contract payment scheduls; query for certain contract payment schedule  by contract payment schedule id or external id 
# The size of  contractPaymentScheduleIds could be 0 or many
def getContractPaymentScheduleIds(response) :
    contractPaymentScheduleIds=[]

    if REST_UTIL.restVersion == 'REST' :
        root = ET.fromstring(response)
        contractPaymentScheduleList = root.find('ContractPaymentScheduleList')
        if  contractPaymentScheduleList is not None:
            for contractPaymentSchedule in contractPaymentScheduleList:
                if contractPaymentSchedule.find('ContractPaymentScheduleId') is not None: 
                    contractPaymentScheduleIds.append(int(contractPaymentSchedule.findtext('ContractPaymentScheduleId')))
        else:
            contractPaymentScheduleId = root.find('ContractPaymentScheduleInfo').find('MtxPricingContractPaymentScheduleInfo').findtext('ContractPaymentScheduleId')
            if contractPaymentScheduleId is not None:
                contractPaymentScheduleIds.append(int(contractPaymentScheduleId))

    elif REST_UTIL.restVersion == 'MDC' :
        if response.descObj.containerKey == MDCDEFS.kMtxResponsePricingContractPaymentScheduleListMdcDesc.containerKey:
            contractPaymentSchedules = response.getUsingKey(MDCDEFS.kMtxResponsePricingContractPaymentScheduleListContractPaymentScheduleListFldKey)
            for c in contractPaymentSchedules :
                cid = c.getUsingKey(MDCDEFS.kMtxPricingContractPaymentScheduleInfoContractPaymentScheduleIdFldKey)
                contractPaymentScheduleIds.append(cid)
        elif response.descObj.containerKey == MDCDEFS.kMtxResponsePricingContractPaymentScheduleMdcDesc.containerKey:
            contractPaymentScheduleInfo  = response.getUsingKey(MDCDEFS.kMtxResponsePricingContractPaymentScheduleContractPaymentScheduleInfoFldKey)
            contractPaymentScheduleId = contractPaymentScheduleInfo.getUsingKey(MDCDEFS.kMtxPricingContractPaymentScheduleInfoContractPaymentScheduleIdFldKey)
            contractPaymentScheduleIds.append(contractPaymentScheduleId)

    elif REST_UTIL.restVersion == 'JSON' : 
        print("")
        try:
            respDict = json.loads(response)
        except Exception as inst:
            print(inst)
            return (999, 'Could not parse response')
        
        if 'ContractPaymentScheduleList' in list(respDict.keys()):
            for paymentSchedule in respDict['ContractPaymentScheduleList']:
                contractPaymentScheduleIds.append(int(paymentSchedule['ContractPaymentScheduleId']))
        else:
            contractPaymentScheduleInfo = respDict['ContractPaymentScheduleInfo']
            contractPaymentScheduleIds.append(int(contractPaymentScheduleInfo['ContractPaymentScheduleId']))
            
    #print contractPaymentScheduleIds
    return contractPaymentScheduleIds
#====================================================================
# return string type or None
def getEligibilityCatalogItemId(response):
    eligibilityCatalogItemId = None
    if REST_UTIL.restVersion == 'REST' :
       try:
          responseXml = ET.XML(response)
          eligibilityCatalogItemId = responseXml.findtext('EligibilityCatalogItemId')
       except Exception as inst:
          return None
    else :
       if response is None:
         return None
       try:
         eligibilityCatalogItemId = response.getUsingKey(MDCDEFS.kMtxResponsePurchaseEligibilityCatalogItemIdFldKey)
       except Exception as NameError:
         return None

    if eligibilityCatalogItemId is not None:
       return str(eligibilityCatalogItemId)
    else:
       return None


#====================================================================
# we must handle 2 cases: eligibility pass or fail
#For pass, not return at moment, will enhance  in future
#For failure, will skip evaulation once there's failure reason, hence only 1 return for failure
#each element under tuple returned are string type
def getEligibilityResultList(response, actionType='purchase'):

    resultList = []

    ruleTypeMap = {
       1: "requires",
       2: "excludes"
       }
    objectTypeMap = {
       1: "catalog_item",
       2: "subscriber",
       3: "group",
       4: "device"
       }
    entityTypeMap = {
       1: "feature",
       2: "attribute"
       }
    resultMap = {
       0: "false",
       1: "true"
       }

    if REST_UTIL.restVersion == 'REST' :
       responseXml = ET.XML(response)
       eligibilityResultList = responseXml.find('EligibilityResultList')
       if eligibilityResultList is None:
          return None

       for eligibilityRuleResult in eligibilityResultList:
          catalogItemId = int(eligibilityRuleResult.findtext("CatalogItemId"))
          ruleType = eligibilityRuleResult.findtext("RuleType")
          eligibilityRule = eligibilityRuleResult.find("EligibilityRule")
          detailedEligibilityRule = None
          value = None
          if eligibilityRule.find("MtxPricingEligibilityStringRule") is not None:
              detailedEligibilityRule = eligibilityRule.find("MtxPricingEligibilityStringRule")
          elif eligibilityRule.find("MtxPricingEligibilityInt64Rule") is not None:
              detailedEligibilityRule = eligibilityRule.find("MtxPricingEligibilityInt64Rule")
          elif eligibilityRule.find("MtxPricingEligibilityDecimalRule") is not None:
              detailedEligibilityRule = eligibilityRule.find("MtxPricingEligibilityDecimalRule")
          elif eligibilityRule.find("MtxPricingEligibilityRule") is not None:
              detailedEligibilityRule = eligibilityRule.find("MtxPricingEligibilityRule")

          if detailedEligibilityRule is not None and detailedEligibilityRule.find("Value") is not None:
              value = detailedEligibilityRule.findtext("Value")
          objectType = detailedEligibilityRule.findtext("ObjectType")
          entityType = detailedEligibilityRule.findtext("EntityType")
          name = detailedEligibilityRule.findtext("Name")
          result = eligibilityRuleResult.findtext("EligibilityResult")
          print((catalogItemId, ruleType, objectType, entityType, name, value, result))
          resultList.append((catalogItemId, ruleType, objectType, entityType, name, value, result))
       return resultList
    else :
       try:
         if actionType == 'purchase':
           lists = response.getUsingKey(MDCDEFS.kMtxResponsePurchaseEligibilityResultListFldKey)
         elif actionType == 'cancel':
           lists = response.getUsingKey(MDCDEFS.kMtxResponseCancelEligibilityResultListFldKey)
         elif actionType == 'query':
           lists = response.getUsingKey(MDCDEFS.kMtxPricingCatalogItemInfoEligibilityResultListFldKey)
       except Exception as NameError:
         return None

       if lists is None:
         return None
       for list in lists:
         catalogItemId = list.getUsingKey(MDCDEFS.kMtxEligibilityRuleResultCatalogItemIdFldKey)
         ruleType = list.getUsingKey(MDCDEFS.kMtxEligibilityRuleResultRuleTypeFldKey)
         eligibilityRule = list.getUsingKey(MDCDEFS.kMtxEligibilityRuleResultEligibilityRuleFldKey)

         value = None
         if eligibilityRule.descObj.containerKey == MDCDEFS.kMtxPricingEligibilityStringRuleMdcDesc.containerKey:
             value = eligibilityRule.getUsingKey(MDCDEFS.kMtxPricingEligibilityStringRuleValueFldKey)
         elif eligibilityRule.descObj.containerKey == MDCDEFS.kMtxPricingEligibilityInt64RuleMdcDesc.containerKey:
             value = str(eligibilityRule.getUsingKey(MDCDEFS.kMtxPricingEligibilityInt64RuleValueFldKey))
         elif eligibilityRule.descObj.containerKey == MDCDEFS.kMtxPricingEligibilityDecimalRuleMdcDesc.containerKey:
             value = str(eligibilityRule.getUsingKey(MDCDEFS.kMtxPricingEligibilityDecimalRuleValueFldKey))
         objectType = eligibilityRule.getUsingKey(MDCDEFS.kMtxPricingEligibilityRuleObjectTypeFldKey)
         entityType = eligibilityRule.getUsingKey(MDCDEFS.kMtxPricingEligibilityRuleEntityTypeFldKey)
         name = eligibilityRule.getUsingKey(MDCDEFS.kMtxPricingEligibilityRuleNameFldKey)
         result = list.getUsingKey(MDCDEFS.kMtxEligibilityRuleResultEligibilityResultFldKey)

         #Map some field into the type of rest response
         resultList.append((catalogItemId, ruleTypeMap[ruleType], objectTypeMap[objectType], entityTypeMap[entityType], name, value, resultMap[result]))

       return resultList

#====================================================================
#The reponse may contain different container name  or xml name
#The size of  catalogItemIds could be 0 or many
#Enhance to handle 3 cases:
#      CatalogItemList => CatalogItemId
#      CatalogInfo => CatalogItemList => CatalogItemId
#      CatalogItemInfo => CatalogItemId
def getCatalogItemList(response) :
    catalogItemIds=[]
    try:
        if REST_UTIL.restVersion == 'REST' :
            root = ET.fromstring(response)
            clist = root.find('CatalogItemList')
            if clist is None and root.find('CatalogInfo') is not None:
                clist = root.find('CatalogInfo').find('MtxPricingCatalogDetailInfo').find('CatalogItemList')
            if clist is not None:
                for child in clist:
                    catalogItemIds.append(int(child.findtext('CatalogItemId')))
            else:
                cii = root.find('CatalogItemInfo').find('MtxPricingCatalogItemDetailInfo').findtext('CatalogItemId')
                catalogItemIds.append(int(cii))
        else :
            if response.descObj.containerKey == MDCDEFS.kMtxResponsePricingCatalogItemListMdcDesc.containerKey:
                catalogItems = response.getUsingKey(MDCDEFS.kMtxResponsePricingCatalogItemListCatalogItemListFldKey)
                for c in catalogItems :
                    cid = c.getUsingKey(MDCDEFS.kMtxPricingCatalogItemInfoCatalogItemIdFldKey)
                    catalogItemIds.append(cid)
            elif response.descObj.containerKey == MDCDEFS.kMtxResponsePricingCatalogItemMdcDesc.containerKey:
                catalogItemInfo  = response.getUsingKey(MDCDEFS.kMtxResponsePricingCatalogItemCatalogItemInfoFldKey)
                catalogItemId = catalogItemInfo.getUsingKey(MDCDEFS.kMtxPricingCatalogItemInfoCatalogItemIdFldKey)
                catalogItemIds.append(catalogItemId)
            elif response.descObj.containerKey == MDCDEFS.kMtxResponsePricingCatalogMdcDesc.containerKey:
                catalogDetailInfo = response.getUsingKey(MDCDEFS.kMtxResponsePricingCatalogCatalogInfoFldKey)
                catalogItems = catalogDetailInfo.getUsingKey(MDCDEFS.kMtxPricingCatalogDetailInfoCatalogItemListFldKey)
                for c in catalogItems :
                    cid = c.getUsingKey(MDCDEFS.kMtxPricingCatalogItemInfoCatalogItemIdFldKey)
                    catalogItemIds.append(cid)
    except:
        print("Warning: error from parse response")
        return []
    return catalogItemIds

#====================================================================
# The EligibilityResult returned is list
# Only called by  query catalog item for subscriber/device/group, not for pricing query
def getEligibilityResultForCatalogItem(response, catalogItemId) :
    catalogItem = None
    if REST_UTIL.restVersion == 'REST' :
        root = ET.fromstring(response)
        clist = root.find('CatalogItemList')
        if clist is not None:
            for child in clist:
                if child.findtext('CatalogItemId') == str(catalogItemId):
                    catalogItem = ET.tostring(child)
                    break
        else:
            if  root.find('CatalogItemInfo').find('MtxPricingCatalogItemDetailInfo').findtext('CatalogItemId') == str(catalogItemId):
                catalogItem = ET.tostring(root.find('CatalogItemInfo').find('MtxPricingCatalogItemDetailInfo'))
    else:
        if response.descObj.containerKey == MDCDEFS.kMtxResponsePricingCatalogItemListMdcDesc.containerKey:
            catalogItems = response.getUsingKey(MDCDEFS.kMtxResponsePricingCatalogItemListCatalogItemListFldKey)
            for c in catalogItems :
                if c.getUsingKey(MDCDEFS.kMtxPricingCatalogItemInfoCatalogItemIdFldKey) == catalogItemId:
                    catalogItem = c
                    break
        elif response.descObj.containerKey == MDCDEFS.kMtxResponsePricingCatalogItemMdcDesc.containerKey:
            catalogItemInfo  = response.getUsingKey(MDCDEFS.kMtxResponsePricingCatalogItemCatalogItemInfoFldKey)
            catalogItemId = catalogItemInfo.getUsingKey(MDCDEFS.kMtxPricingCatalogItemInfoCatalogItemIdFldKey)
            if catalogItemId == catalogItemId:
                catalogItem = catalogItemInfo

    print("catalog item:", catalogItem)
    return getEligibilityResultList(catalogItem, actionType='query')

#====================================================================
# Support 2 kinds of response: response from query all catalogs; query for certain catalog by catalog id or external id
# The size of  catalogIds could be 0 or many
def getCatalogIds(response) :
    catalogIds=[]
    if REST_UTIL.restVersion == 'REST' :
        root = ET.fromstring(response)
        catalogList = root.find('CatalogList')
        if  catalogList is not None:
            for catalog in catalogList:
                if catalog.find('CatalogId') is not None:
                    catalogIds.append(int(catalog.findtext('CatalogId')))
        else:
            catalogId = root.find('CatalogInfo').find('MtxPricingCatalogDetailInfo').findtext('CatalogId')
            if catalogId is not None:
                catalogIds.append(int(catalogId))
    else :
        if response.descObj.containerKey == MDCDEFS.kMtxResponsePricingCatalogListMdcDesc.containerKey:
            catalogs = response.getUsingKey(MDCDEFS.kMtxResponsePricingCatalogListCatalogListFldKey)
            for c in catalogs :
                cid = c.getUsingKey(MDCDEFS.kMtxPricingCatalogInfoCatalogIdFldKey)
                catalogIds.append(cid)
        elif response.descObj.containerKey == MDCDEFS.kMtxResponsePricingCatalogMdcDesc.containerKey:
            catalogInfo  = response.getUsingKey(MDCDEFS.kMtxResponsePricingCatalogCatalogInfoFldKey)
            catalogId = catalogInfo.getUsingKey(MDCDEFS.kMtxPricingCatalogInfoCatalogIdFldKey)
            catalogIds.append(catalogId)

    #print catalogIds
    return catalogIds

#====================================================================
#There may be one catalog item or multiple catalog items. The mdc container name is different
#The size of  catalogItemIds could be 0 or many
def getCatalogItemIdsForCatalog(response) :
    catalogItemIds=[]
    if REST_UTIL.restVersion == 'REST' :
        root = ET.fromstring(response)

        if root.find('CatalogInfo') is not None  and root.find('CatalogInfo').find('MtxPricingCatalogDetailInfo') is not None and root.find('CatalogInfo').find('MtxPricingCatalogDetailInfo').find('CatalogItemList') is not None:
            catalogItemList = root.find('CatalogInfo').find('MtxPricingCatalogDetailInfo').find('CatalogItemList')
            for catalogItem in catalogItemList:
                if catalogItem.find('CatalogItemId') is not None:
                    catalogItemIds.append(int(catalogItem.findtext('CatalogItemId')))
    else :
        if response.descObj.containerKey == MDCDEFS.kMtxResponsePricingCatalogMdcDesc.containerKey:
            catalogItemList = response.getUsingKey(MDCDEFS.kMtxResponsePricingCatalogCatalogInfoFldKey).getUsingKey(MDCDEFS.kMtxPricingCatalogDetailInfoCatalogItemListFldKey)
            for c in catalogItemList:
                cid = c.getUsingKey(MDCDEFS.kMtxPricingCatalogItemInfoCatalogItemIdFldKey)
                catalogItemIds.append(cid)

    #print catalogItemIds, len(catalogItemIds)
    return catalogItemIds

#====================================================================
#It is assumed that there will always having 1 revision in  the response
def getCatalogItemRev(response) :
    catalogItemId = None
    catalogItemRev = None
    catalogItemExtId = None
    catalogItemTemplateRev = None
    catalogItemTemplateAttr = None
    catalogItemTemplateAttrName = None
    catalogItemTemplateAttrFirstFieldName = None
    
    if REST_UTIL.restVersion == 'REST' :
        root = ET.fromstring(response)
        catalogItemInfo = root.find('CatalogItemInfo')
        catalogItemId = catalogItemInfo.find('MtxPricingCatalogItemDetailInfo').findtext('CatalogItemId')
        catalogItemExtId = catalogItemInfo.find('MtxPricingCatalogItemDetailInfo').findtext('ExternalId')

        catalogItemRev = catalogItemInfo.find('MtxPricingCatalogItemDetailInfo').findtext('Rev')        
        catalogItemTemplateRev = catalogItemInfo.find('MtxPricingCatalogItemDetailInfo').findtext('TemplateRev')
        catalogItemTemplateAttr = catalogItemInfo.find('MtxPricingCatalogItemDetailInfo').find('TemplateAttr')
        catalogItemTemplateAttrName = catalogItemTemplateAttr[0].tag
        catalogItemTemplateAttrFirstFieldName = catalogItemTemplateAttr[0][0].tag
        #print "name:", catalogItemTemplateAttrName
        #print "field:", catalogItemTemplateAttrFirstFieldName

    else :
        catalogItemInfo  = response.getUsingKey(MDCDEFS.kMtxResponsePricingCatalogItemCatalogItemInfoFldKey)

        catalogItemRev = str(catalogItemInfo.getUsingKey(MDCDEFS.kMtxPricingCatalogItemDetailInfoRevFldKey))        
        catalogItemTemplateRev = str(catalogItemInfo.getUsingKey(MDCDEFS.kMtxPricingCatalogItemDetailInfoTemplateRevFldKey))
        catalogItemTemplateAttr  = catalogItemInfo.getUsingKey(MDCDEFS.kMtxPricingCatalogItemDetailInfoTemplateAttrFldKey)
        catalogItemTemplateAttrName = catalogItemTemplateAttr.getDescriptorName() 
        catalogItemTemplateAttrFirstFieldName = catalogItemTemplateAttr.descObj.fieldNameList[0]
        #print "template attr name:", catalogItemTemplateAttrName
        #print "field name:", catalogItemTemplateAttrFirstFieldName

        catalogItemId = str(catalogItemInfo.getUsingKey(MDCDEFS.kMtxPricingCatalogItemInfoCatalogItemIdFldKey))
        catalogItemExtId  = catalogItemInfo.getUsingKey(MDCDEFS.kMtxPricingCatalogItemInfoExternalIdFldKey)
       

    #return all in str type
    return (catalogItemId, catalogItemRev, catalogItemTemplateRev, catalogItemExtId, catalogItemTemplateAttrName, catalogItemTemplateAttrFirstFieldName)

def getSubscriberGeoCode(queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxResponseSubscriberGeoCodeFldKey)

def getGroupGeoCode(queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxResponseGroupGeoCodeFldKey)

def getSubscriptionGeoCode(queryResult):
    if REST_UTIL.restVersion == 'REST' :
       queryResult = re.sub(r'false','0',queryResult)
       queryResult = re.sub(r'true','1',queryResult)
       resMdc = MDC.readFromElementBasedXMLStr(queryResult)
    else :
       resMdc = queryResult

    return resMdc.getUsingKey(MDCDEFS.kMtxResponseSubscriptionGeoCodeFldKey)


#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

