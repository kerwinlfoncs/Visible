#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:35:32
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:35:31
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:35:30
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
from __future__ import print_function
from __future__ import division
# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
from past.utils import old_div
import copy, math, pprint
import diameter_utils
import create_diameter_pkt_base
import os, sys, time, json
from primitives import timeToMDCtime as MDCTIME
import commonDefs as cd
import qa_utils as QAUTILS
import qa_utils_5G as QAUTILS5G
import csv_track as TRACK
import csv_id as CSVID
import csv_rx as CSVRX
import csv_aqm as AQM
import csv_prim as PRIM
import csv_data as DATA
import csv_CmdMisc as MISC
import csv_CmdDiamSy as CMDDIAMSY
import csv_CmdDiamSh as CMDDIAMSH
import csv_5G as FIVEG

try:
   import custSpecific as CUST
except ImportError:
   print('\n\n\ndid not find custSpecific!!\n\n\n')
   os.system(' echo \"\" > custSpecific.py ')

# Define globals
lastAbortSessionDct = {}
lastReAuthDct = {}
lastWatchdogDct = {}
RefundData = {}

# Define MSCC data parameter parts
parameterNames = ['ratingGroup', 'msccServiceId', 'reqAmount', 'usedAmount', 'reportingReason', 'eventPass']

# =========================================================================================
# ===========================  Diameter Gy commands ==== ==================================
# =========================================================================================

#==========================================================
def CmdDiam_changediamconnections(lclDCT, options, diamConnection, extraAVP={}):
        # *** lclDCT[] has all the values.
        '''
        '''
        diameterDestinationIpAddressGy = lclDCT['diameterDestinationIpAddressGy']
        diameterDestinationIpAddressSy = lclDCT['diameterDestinationIpAddressSy']
        diameterDestinationIpAddressGx = lclDCT['diameterDestinationIpAddressGx']
        diameterDestinationIpAddressRx = lclDCT['diameterDestinationIpAddressRx']
        mark = lclDCT['mark']

        # If nothing passed in, then warn the user
        if not diameterDestinationIpAddressGy and not diameterDestinationIpAddressSy and not diameterDestinationIpAddressGx and not diameterDestinationIpAddressRx and not mark:
                print('WARN: No Sy or Gy IP address input for this command and no mark.  Nothing will happen.')
                print('The command should include one of the following: diameterDestinationIpAddressGy, diameterDestinationIpAddressSy, mark')

        # If Gx passed in, then set this up
        if diameterDestinationIpAddressGx:
                print('Changing Gx address to : ' + diameterDestinationIpAddressGx)
                # Get Gy diameter connection.
                PRIM.connectToDiameterGateway(diameterDestinationIpAddressGx, 'gx', lclDCT=lclDCT, mark=mark)

        # If Gy passed in, then set this up
        if diameterDestinationIpAddressGy:
                print('Changing Gy address to : ' + diameterDestinationIpAddressGy)
                # Get Gy diameter connection.
                PRIM.connectToDiameterGateway(diameterDestinationIpAddressGy, 'gy', lclDCT=lclDCT, mark=mark)

        # If Sy passed in, then set this up
        if diameterDestinationIpAddressSy:
                print('Changing Sy address to : ' + diameterDestinationIpAddressSy)
                # Get Sy diameter connection.
                PRIM.connectToDiameterGateway(diameterDestinationIpAddressSy, 'sy', lclDCT=lclDCT, mark=mark)
        
        # If Rx passed in, then set this up
        if diameterDestinationIpAddressRx:
                print('Changing Rx address to : ' + diameterDestinationIpAddressSy)
                # Get Sy diameter connection.
                PRIM.connectToDiameterGateway(diameterDestinationIpAddressSy, 'rx', lclDCT=lclDCT, mark=mark)

        # If only mark passed in, then try both
        if not diameterDestinationIpAddressGy and not diameterDestinationIpAddressSy and not diameterDestinationIpAddressGx and not diameterDestinationIpAddressRx and mark:
                print('Checking for mark: ' + mark)
                PRIM.connectToDiameterGateway(None, 'gy', mark=mark)
                PRIM.connectToDiameterGateway(None, 'sy', mark=mark)
                PRIM.connectToDiameterGateway(None, 'gx', mark=mark)
                PRIM.connectToDiameterGateway(None, 'rx', mark=mark)

        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdDiam_diameterreceiveabortsessionrequest(lclDCT, options, diamConnection, extraAVP={}):
        global lastAbortSessionDct
        
        # *** lclDCT[] has all the values.
        '''
        '''
        eventPass = lclDCT['eventPass']
        noReply = lclDCT['noReply']
        timeToWait = lclDCT['timeToWait']

        # Receive message
        (diamDct, diamResp) = diameter_utils.receiveDiameterPacket(diamConnection = diamConnection, msgId=DATA.DiameterMessageIds['GyASR'], timeout=timeToWait)
        
        # Check response
        if (not diamResp and eventPass) or (diamResp and not eventPass):
                if eventPass: sys.exit('CmdDiam_diameterreceiveabortsessionrequest() received a unexpected failure from diameter_utils.receiveDiameterPacket()')
                else:         sys.exit('CmdDiam_diameterreceiveabortsessionrequest() received a unexpected success from diameter_utils.receiveDiameterPacket()')
        
        #print 'Received ASR.  Packet contents: ' + str(diamDct)

        # If we're supposed to save data, then do so here
        if saveData: MISC.CmdMisc_saveData(lclDCT, 'Diameter', None)
         
        # Reply if we're supposed to
        if not noReply:
                print('Sending ASA')

                # Turn around a ASA
                create_diameter_pkt_base.sendAbortSessionAnswer(diamDct, diamConnection = diamConnection, eventPass=eventPass, extraAVP=extraAVP)

        else:
                # Save last message (so WDA can use it if response is delayed)
                 lastAbortSessionDct = copy.deepcopy(diamDct)

        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdDiam_diametersendabortsessionanswer(lclDCT, options, diamConnection, extraAVP={}):
        global lastAbortSessionDct
        
        # *** lclDCT[] has all the values.
        '''
        '''
        eventPass = lclDCT['eventPass']

        # Send WDA.  Use last saved WDR dictionary (command needs data from previous WDR command)
        create_diameter_pkt_base.sendAbortSessionAnswer(lastAbortSessionDct, diamConnection = diamConnection, eventPass=eventPass, extraAVP=extraAVP)

        # Clear global, as we will have used whatever was saved
        lastAbortSessionDct = {}
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdDiam_diameterabortsession(lclDCT, options, diamConnection, extraAVP={}):
        # *** lclDCT[] has all the values.
        '''
        '''
        eventPass = lclDCT['eventPass']

        # Send message out, get response
        extraAVP = {}
        diamDct = create_diameter_pkt_base.createAbortSessionRequest(cd.GySessionIdPrefix+sessionId, diamConnection = diamConnection, eventPass=eventPass, extraAVP = extraAVP)

        # Check result codes
        diamResult = diameter_utils.checkDiameterResultCodes(diamDct)
        #print 'Returned diamResult = ' + str(diamResult)

        # Exit if received an unexpected result code
        diameter_utils.exitOnFailureDiameterResultCodes(diamResult, eventPass=eventPass, continuePastError=lclDCT['continuePastError'])
        
        # If we're supposed to save data, then do so here
        if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, 'Diameter', None)
         
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdDiam_diameterreceivewatchdogrequest(lclDCT, options, diamConnection, extraAVP={}):
        global lastWatchdogDct
        
        # *** lclDCT[] has all the values.
        '''
        '''
        eventPass = lclDCT['eventPass']
        noReply = lclDCT['noReply']
        timeToWait = lclDCT['timeToWait']

        # Receive message
        (diamDct, diamResp) = diameter_utils.receiveDiameterPacket(diamConnection = diamConnection, msgId=DATA.DiameterMessageIds['WDR'], timeout=timeToWait)
        
        # Check response
        if (not diamResp and eventPass) or (diamResp and not eventPass):
                if eventPass: sys.exit('CmdDiam_diameterreceivewatchdogrequest() received a unexpected failure from diameter_utils.receiveDiameterPacket()')
                else:  sys.exit('CmdDiam_diameterreceivewatchdogrequest() received a unexpected success from diameter_utils.receiveDiameterPacket()')
        
        #print 'Received WDR.  Packet contents: ' + str(diamDct)

        # If we're supposed to save data, then do so here
        if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, 'Diameter', None)
         
        # Reply if we're supposed to
        if not noReply:
                print('Sending WDA')

                # Turn around a WDA
                create_diameter_pkt_base.sendDeviceWatchdogAnswer(diamDct, diamConnection = diamConnection, eventPass=eventPass)

        else:
                # Save last message (so WDA can use it if response is delayed)
                 lastWatchdogDct = copy.deepcopy(diamDct)

        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdDiam_diametersendwatchdoganswer(lclDCT, options, diamConnection, extraAVP={}):
        global lastWatchdogDct
        
        # *** lclDCT[] has all the values.
        '''
        '''
        eventPass = lclDCT['eventPass']

        # Send WDA.  Use last saved WDR dictionary (command needs data from previous WDR command)
        create_diameter_pkt_base.sendDeviceWatchdogAnswer(lastWatchdogDct, diamConnection = diamConnection, eventPass=eventPass, extraAVP=extraAVP)

        # Clear last watchdog, as we will have used whatever was saved
        lastWatchdogDct = {}
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdDiam_diameterwatchdog(lclDCT, options, diamConnection, extraAVP={}):
        # *** lclDCT[] has all the values.
        '''
        '''
        eventPass = lclDCT['eventPass']

        # Send message out, get response
        extraAVP = {}
        diamDct = create_diameter_pkt_base.createDeviceWatchdogRequest(diamConnection = diamConnection, eventPass=eventPass, extraAVP = extraAVP)

        # Check result codes
        diamResult = diameter_utils.checkDiameterResultCodes(diamDct)
        #print 'Returned diamResult = ' + str(diamResult)

        # Exit if received an unexpected result code
        diameter_utils.exitOnFailureDiameterResultCodes(diamResult, eventPass=eventPass, continuePastError=lclDCT['continuePastError'])
        
        # If we're supposed to save data, then do so here
        if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, 'Diameter', None)
         
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdDiam_diametercapabilityexchange(lclDCT, options, diamConnection, extraAVP={}):
        # *** lclDCT[] has all the values.
        '''
        '''
        eventPass = lclDCT['eventPass']

        # Send message out, get response
        extraAVP = {}
        diamDct = create_diameter_pkt_base.createCapabilityExchangeRequest(diamConnection = diamConnection, eventPass=eventPass, extraAVP = extraAVP)

        # Check result codes
        diamResult = diameter_utils.checkDiameterResultCodes(diamDct)
        #print 'Returned diamResult = ' + str(diamResult)

        # Exit if received an unexpected result code
        diameter_utils.exitOnFailureDiameterResultCodes(diamResult, eventPass=eventPass, continuePastError=lclDCT['continuePastError'])
        
        # If we're supposed to save data, then do so here
        if lclDCT['saveData']: MISC.CmdMisc_saveData(lclDCT, 'Diameter', None)
         
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def CmdDiam_diameterdisconnectpeerrequest(lclDCT, options, diamConnection, extraAVP={}):
        # *** lclDCT[] has all the values.
        '''
        '''
        eventPass = lclDCT['eventPass']
        saveData = lclDCT['saveData']

        # Send message out, get response
        extraAVP = {}
        diamDct = create_diameter_pkt_base.createDisconnectPeerRequest(diamConnection = diamConnection, eventPass=eventPass, extraAVP = extraAVP)

        # Check result codes
        diamResult = diameter_utils.checkDiameterResultCodes(diamDct)
        #print 'Returned diamResult = ' + str(diamResult)

        # Exit if received an unexpected result code
        diameter_utils.exitOnFailureDiameterResultCodes(diamResult, eventPass=eventPass, continuePastError=lclDCT['continuePastError'])

        # If we're supposed to save data, then do so here
        if saveData: MISC.CmdMisc_saveData(lclDCT, 'Diameter', None)
         
        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
# Receive Rx response.  Need to separate these when Gx RAR is inbetween Rx AAR and Rx AAA messages.
def CmdDiam_diameterreceiverxresponse(lclDCT, options, diamConnection, extraAVP):
        # *** lclDCT[] has all the values.
        '''
        '''
        eventPass = lclDCT['eventPass']
        saveData = lclDCT['saveData']
        
        # Receive message
        (diamDct, diamResp) = diameter_utils.receiveDiameterPacket(diamConnection=diamConnection, msgId=DATA.DiameterMessageIds['RxAAR'], timeout=lclDCT['timeToWait'], extraAVP = extraAVP)
        
        # Check response
        if (not diamResp and eventPass) or (diamResp and not eventPass):
                if eventPass:   sys.exit('CmdDiam_diameterreceiverxresponse() received a unexpected failure from diameter_utils.receiveDiameterPacket()')
                else:           sys.exit('CmdDiam_diameterreceiverxresponse() received a unexpected success from diameter_utils.receiveDiameterPacket()')
        #print 'Received AAA.  Packet contents: ' + str(diamDct)
        
        # Nothing to query in this scenario
        queryType = queryValue = None
        
        # If failure expected, then return here
        if not eventPass: return (queryType, queryValue)
        
        # If we're supposed to save data, then do so here
        if saveData: MISC.CmdMisc_saveData(lclDCT, 'Diameter', None)
         
        # Return
        return (queryType, queryValue)

#==========================================================
def CmdDiam_diameterreceivereauthrequest(lclDCT, options, diamConnection, extraAVP):
        global lastReAuthDct
        
        # If 5G or Sy then handle totally different
        if lclDCT['interface'].lower().startswith('5g'):
                FIVEG.FiveGReceiveNotify(lclDCT, options, diamConnection, extraAVP)
                return (None, None)
        
        # *** lclDCT[] has all the values.
        '''
        '''
        eventPass = lclDCT['eventPass']
        saveData = lclDCT['saveData']
        interface = lclDCT['interface']
        noReply = lclDCT['noReply']
        
        # If Sy request then call Sy function
        if interface.lower() == 'sy':
                # Send command
                (queryType, queryValue) = CMDDIAMSY.CmdDiam_diameterreceivespendnotificationrequest(lclDCT, options, diamConnection, extraAVP = extraAVP)
        else:
                # Receive message
                (diamDct, diamResp) = diameter_utils.receiveDiameterPacket(diamConnection=diamConnection, msgId=DATA.DiameterMessageIds['GyRAR'], timeout=lclDCT['timeToWait'], extraAVP = extraAVP)
                
                # Check response
                if (not diamResp and eventPass) or (diamResp and not eventPass):
                        if eventPass:   sys.exit('CmdDiam_diameterreceivereauthrequest() received a unexpected failure from diameter_utils.receiveDiameterPacket()')
                        else:           sys.exit('CmdDiam_diameterreceivereauthrequest() received a unexpected success from diameter_utils.receiveDiameterPacket()')
        
                #print 'Received RAR.  Packet contents: ' + str(diamDct)
        
        # Nothing to query in this scenario
        queryType = queryValue = None

        # If failure expected, then return here
        if not eventPass: return (queryType, queryValue)
        
        # If we're supposed to save data, then do so here
        if saveData: MISC.CmdMisc_saveData(lclDCT, 'Diameter', None)
         
        # Policy work for some interfaces
        if interface.lower() in ['gx', 'rx']:
                # Get Gx policy data
                misc = PRIM.retrieveAndValidatePolicyRules(diamDct, lclDCT, printFlag=True, interface=interface.lower())
        
        # Gy/Gx work
        if interface.lower() != 'sy':
                # Reply if we're supposed to
                if not noReply:
                        print('Sending RAA')
                        
                        # Turn around a RAA
#                       print 'sending RAA with eventPass = ' + str(eventPass)
                        create_diameter_pkt_base.sendReauthAnswer(diamDct, diamConnection = diamConnection, eventPass=eventPass, extraAVP=extraAVP)
                
                else:
                        print('Not sending RAA')
                        # Save last ReAuth message (so RAA can use it if response is delayed)
                        lastReAuthDct = copy.deepcopy(diamDct)
        
        return (queryType, queryValue)
        
#==========================================================
def CmdDiam_diametersendreauthanswer(lclDCT, options, diamConnection, extraAVP={}):
        global lastReAuthDct
        
        # *** lclDCT[] has all the values.
        '''
        '''
        eventPass = lclDCT['eventPass']
        interface = lclDCT['interface']

        # If Sy request then call Sy function
        if interface.lower() == 'sy':
                # Send command
                (queryType, queryValue) = CMDDIAMSY.CmdDiam_diametersendspendnotificationanswer(lclDCT, options, diamConnection)
        else:
                # Send RAA.  Use last saved RAR dictionary (command needs data from previous RAR command)
                create_diameter_pkt_base.sendReauthAnswer(lastReAuthDct, diamConnection = diamConnection, eventPass=eventPass)
        
                # Clear last reauth, as we will have used whatever was saved
                lastReAuthDct = {}

        # Nothing to query in this scenario
        queryType = queryValue = None

        return (queryType, queryValue)
        
#==========================================================
def buildMsccData(ratingGroup, msccServiceId, reqAmount, usedAmount, reportingReason, eventPass):
        cmdStr = ''
        
        # Need to avoid putting "None" in there, as that's harder to get out from below...
        if ratingGroup: cmdStr += str(ratingGroup)
        cmdStr += '/'
        
        if msccServiceId: cmdStr += str(msccServiceId)
        cmdStr += '/'
        
        if reqAmount: cmdStr += str(reqAmount)
        cmdStr += '/'
        
        if usedAmount: cmdStr += str(usedAmount)
        cmdStr += '/'
        
        if reportingReason: cmdStr += str(reportingReason)
        cmdStr += '/'
        
        if eventPass: cmdStr += str(eventPass)
        cmdStr += '/'
        
        # Build the entry, minus the last separator character
        multiMsccData = [(cmdStr[:-1])]
                        
        return multiMsccData

#==========================================================
def separateMsccDataElement(msccIndividualData, request, tariffChangeUsage, lclDCT, _eventPass, sessionId):
        # Initialize key parameters
        ratingGroup = msccServiceId = reqAmount = usedAmount = reportingReason = eventPass = None
        
        # Process input parameters
#       print str(msccIndividualData)
        for i,entry in enumerate(msccIndividualData):
                # If not param = value then use parameterNames index
                try:
                        # This is parameter=value syntax
                        (parameter,value) = entry.split(DATA.msccParamNameChar)
                except:
                        # Value-only entry
                        parameter = parameterNames[i]
                        value = entry
                
                if   parameter == 'ratingGroup':     ratingGroup = value
                elif parameter == 'msccServiceId':   msccServiceId = value
                elif parameter == 'reqAmount':       reqAmount = value
                elif parameter == 'usedAmount':      usedAmount = value
                elif parameter == 'reportingReason': reportingReason = value
                elif parameter == 'eventPass':       eventPass = value
                
        # Clear some of these (e.g. if init then no used, if term then no request).
        # Also make sure they're not None (need to be 0 to signal lower-level functions to skip).
        # Finally, if "x" set for used amount, change to -2 (need to wait for translations before checking session data).
        if request == 'initial': usedAmount = 0
        elif not usedAmount:     usedAmount = 0
        elif usedAmount.lower() == 'x':  usedAmount = '-2'
        
        if request == 'term':    reqAmount = 0
        elif not reqAmount:      reqAmount = 0
                                                
        # If mscc Service ID passed in, then set the flag
        if msccServiceId: incServiceId = True
        else:             incServiceId = False
                                
        # OK; want to allow translations of these.  Regular translations occured a long time ago.
        # NOTE: saving dictionary was taking a loooong time!  Don't really need to save it.  Just want parameter values stored.  
        #saveLclDCT = copy.deepcopy(lclDCT)
        saveLclDCT = {}
        
        # Update saved dictionary with the parameters.
        # Don't lose the "None" items (i.e. can't blindly make them a string)
        for param in parameterNames:
                # Mixed up names...
                parameter = param
                
                # Get parameter value
                if   parameter == 'ratingGroup':     value = ratingGroup
                elif parameter == 'msccServiceId':   value = msccServiceId
                elif parameter == 'reqAmount':       value = reqAmount
                elif parameter == 'usedAmount':      value = usedAmount
                elif parameter == 'reportingReason': value = reportingReason
                elif parameter == 'eventPass':       value = eventPass
                saveLclDCT[param] = value
        
                # Do name translations
                if parameter and parameter in DATA.parameterTranslate: PRIM.translateTextFromMapping(parameter, saveLclDCT)
        
                # Do unit translations
                if parameter and parameter in DATA.unitParameters: saveLclDCT[parameter] = PRIM.convertAmountsToIntegers(str(saveLclDCT[parameter]))
        
                # Extract desired values to locals
                value = saveLclDCT[param]
                if   parameter == 'ratingGroup':     ratingGroup = value
                elif parameter == 'msccServiceId':   msccServiceId = value
                elif parameter == 'reqAmount':       reqAmount = value
                elif parameter == 'usedAmount':      usedAmount = value
                elif parameter == 'reportingReason': reportingReason = value
                elif parameter == 'eventPass':       eventPass = value
        
        # Want to support used unit value of "x", which means to use the granted amount.  It was changed to "-2" above.
        # Needed to wait until post-translations, as the rating group value may have been a string that was translated.
        if usedAmount == '-2':
                # Make sure the session exists
                if not TRACK.checkIfSessionTracked(sessionId, ratingGroup):
                        print('WARNING: used is supposed to use the last granted amount, but there\'s no session for session ID/rating group ' + str(sessionId) + '/' + str(ratingGroup))
                        usedAmount = 0
                else:
                        usedAmount = TRACK.sessionGetValue(sessionId, ratingGroup, 'lastGrant')
                        print('MSCC - using last granted amount of ' + str(usedAmount))

        # Fix parameters that require non-None values
        if not usedAmount or str(usedAmount).lower() == 'none': saveLclDCT['usedAmount'] = usedAmount = '0'
        if not reqAmount  or str(reqAmount).lower()  == 'none': saveLclDCT['reqAmount']  = reqAmount = '0'
        
        # If time change parameter specified, then need to split usage between before and after
        usedDetails = []
        if tariffChangeUsage:
                if tariffChangeUsage != '3':
                        # Single value item
                        usedDetails.append([str(usedAmount), tariffChangeUsage])
                else:
                        usedDetails.append([str(old_div(int(usedAmount), 2)), '1'])
                        usedDetails.append([str(old_div(int(usedAmount), 2)), '0'])
        else:
                # Store non-list value
                usedDetails = usedAmount
        
        # Can't exec a return statement :-(.  Need to hard-code return parameter list.
        return (ratingGroup, msccServiceId, reqAmount, usedDetails, reportingReason, incServiceId, eventPass)
        
#==========================================================
def diamMessageSanityCheck(requestType, eventPass, action, noChecks):
        # If noChecks and the command requires searching for objects, then it won't work
        if noChecks and 'Every' in action:
                print('ERROR: can\'t run command ' + action + ' with noChecks parameter set')
                sys.exit('Error on command: ' + action)

        # If session specified and expecting to fail, then inconsistent.
        if requestType == 'session' and eventPass in ['0', 0, False]:
                print('WARNING: can\'t specify a request type of session when expecting a failure (as the term will always pass).  Changing the type to "initial"')
                requestType == 'initial'
                
        # Validate Sy commands
        if action == 'diameterSendSpendLimitRequest' and requestType not in ['initial', 'interim']:
                print('WARNING: request type must be initial or interim for action ' + action)
                print('RequestType value = ' + requestType)
                sys.exit('Error on command: ' + action)
         
        if action == 'diameterSendSessionTerminateRequest' and requestType != 'term':
                print('WARNING: request type must be term for action ' + action + '. Canging the type to "term"')
                requestType == 'term'
         
        return requestType
        
#==========================================================
def currencyProcess(amountList, index):
        # Get currencySymbol to check for
        currencySymbol = DATA.localCurrency[DATA.localCurrencyToUse].lower()
        
        # List may be populated, or use the last value
        try:
                amount = str(amountList[index])
        except:
                amount = str(amountList[-1])
        
        # See if currency character is here
        if amount.lower().startswith(currencySymbol):
                # Amount could be a decimal.  Need to check for this.
                _x = amount[len(currencySymbol):].split('.')
                if len(_x) == 2:
                        # We have an exponent.
                        # NOTE:  not checking if someone did something silly like $2.1.  There are limits to what the tool will enforce...
                        exponent = -1 * len(_x[1])
                        retAmount = int(str(_x[0] + _x[1]))
                else:
                        # No exponent.  Assume input was in dollars so add two '0' characters and set exponent to 2.
                        retAmount = int(str(_x[0])+'00')
                        exponent = -2
                
                # Set currency flag
                currencyFlag = True
                print('Found currency: amount/retAmount/exponet = ' + amount + '/' + str(retAmount) + '/' + str(exponent))
        else:
                retAmount = int(amount)
                currencyFlag = False
                exponent = 0
        
        return currencyFlag, exponent, retAmount
        
#==========================================================
def CmdDiam_usage(lclDCT, testName, sessionId, line, headers, extraAVP, options, lclStartTime, RESTInst, step, repeatCount, diamConnection):
         global RefundData
         
         # *** lclDCT[] has all the values.
         '''
         '''
         
         interface = lclDCT['interface']
         diamDebug = lclDCT['diamDebug']
         ratingGroup = lclDCT['ratingGroup']
         startTime = lclDCT['startTime']
         sessionId = lclDCT['sessionId']
         eventPass = lclDCT['eventPass']
         on = lclDCT['on']
         verbose = lclDCT['verbose']
         amount = lclDCT['amount']
         command = lclDCT['command']
         requestType = lclDCT['requestType']
         totalToUse = lclDCT['totalToUse']
         reportingReason = lclDCT['reportingReason']
         noChecks = lclDCT['noChecks']
         msccServiceId = lclDCT['msccServiceId']
         lclStartTime = lclDCT['lclStartTime']
         refundInformation = lclDCT['refundInformation']
         delay = lclDCT['delay']
         strip = lclDCT['strip']
         serviceId = lclDCT['serviceId']
         reqAmount = lclDCT['reqAmount']
         aqmFunction = lclDCT['aqmFunction']
         ACTION = lclDCT['ACTION']
         name = lclDCT['name']
         mark = lclDCT['mark']
         deviceId = lclDCT['deviceId']
         usedAmount = lclDCT['usedAmount']
         requestAction = lclDCT['requestAction']
         refundOverride = lclDCT['refundOverride']
         externalId = lclDCT['externalId']
         events = lclDCT['events']
         noMscc = lclDCT['noMscc']
         refundSessionId = lclDCT['refundSessionId']
         continuePastError = lclDCT['continuePastError']
         saveFunc = lclDCT['saveFunc']
         omit = lclDCT['omit']
         cmd = lclDCT['cmd']
         tracking = lclDCT['tracking']
         subscriber = lclDCT['subscriber']
         requestDirection = lclDCT['requestDirection']
         reqData = lclDCT['reqData']
         multiMsccData = lclDCT['multiMsccData']
         maxToUse = lclDCT['maxToUse']
         LoginId = lclDCT['LoginId']
         customer = lclDCT['customer']
         aqmRealTimeFlag = lclDCT['aqmRealTimeFlag']
         usedTime = lclDCT['usedTime']
         usedData = lclDCT['usedData']
         sendOnlyFlag = lclDCT['sendOnlyFlag']
         reqTime = lclDCT['reqTime']
         ratingGroupRequiredForSession = lclDCT['ratingGroupRequiredForSession']
         printFlag = lclDCT['printFlag']
         eventMoney = lclDCT['eventMoney']
         devAddress = lclDCT['devAddress']
         currencyCode = lclDCT['currencyCode']
         user = lclDCT['user']
         tz = lclDCT['tz']
         testName = lclDCT['testName']
         subTimeZone = lclDCT['subTimeZone']
         step = lclDCT['step']
         startDelay = lclDCT['startDelay']
         savedstartTime = lclDCT['savedstartTime']
         query = lclDCT['query']
         off = lclDCT['off']
         msisdn = lclDCT['msisdn']
         mscc = lclDCT['mscc']
         level = lclDCT['level']
         iteration = lclDCT['iteration']
         imsi = lclDCT['imsi']
         httpLevel = lclDCT['httpLevel']
         diffOnly = lclDCT['diffOnly']
         createMsccFlag = lclDCT['createMsccFlag']
         childService = lclDCT['childService']
         aqmMaxVelocity = lclDCT['aqmMaxVelocity']
         accessNumbers = lclDCT['accessNumbers']
         usedUnitRatType = lclDCT['usedUnitRatType']
         usedDirection = lclDCT['usedDirection']
         triggerType = lclDCT['triggerType']
         trace = lclDCT['trace']
         tariffChangeUsage = lclDCT['tariffChangeUsage']
         skipMsisdn = lclDCT['skipMsisdn']
         skipImsi = lclDCT['skipImsi']
         scope = lclDCT['scope']
         scenario = lclDCT['scenario']
         saveData = lclDCT['saveData']
         repeatCount = lclDCT['repeatCount']
         querySize = lclDCT['querySize']
         policyStatus = lclDCT['policyStatus']
         policyIdentifier = lclDCT['policyIdentifier']
         pauseFlag = lclDCT['pauseFlag']
         pause = lclDCT['pause']
         origStartTime = lclDCT['origStartTime']
         offline = lclDCT['offline']
         maxCommands = lclDCT['maxCommands']
         location = lclDCT['location']
         groupId = lclDCT['groupId']
         calledStation = lclDCT['calledStation']
         
         # Device should exist if not an "Every" command.  Punt on logins for now (will fix tracking checks for this later)
         if not LoginId and deviceId not in TRACK.deviceTracking and not noChecks and not lclDCT['ACTION'].count('Every'):
                print('ERROR: device with ID "' + deviceId + '" is not defined.  Exiting')
                sys.exit('Error on command: ' + lclDCT['ACTION'])
         
         # Sanity Check the message.  May change the request type value, so store back into global and local variables.
         lclDCT['requestType'] = requestType = diamMessageSanityCheck(requestType, eventPass, lclDCT['ACTION'], noChecks)
         
         # **** Sanity Check Data ******
#        print 'Session ID at time when command is started: ' + str(sessionId)
         
         # ** Adding support for request type "event".  It's really a "term" message until building the MSCC structure.
         if requestType == 'event':
                requestType = 'term'
                eventFlag = True
         else:  eventFlag = False
         
         # Restore original time, as we don't want to jump ahead just yet...
         lclStartTime = origStartTime

         # Default start time to current time
         startTime = lclStartTime
         
         # Assume no errors
         errorFlag = False
         
         # *** Figure out where to send messages to ***
         # Want to send one or more events.  How many to send depends on the action.
         (deviceId, queryValue, queryType, deviceIdToSend, accessNumberToSend) = \
                PRIM.getListToSendTo(lclDCT['ACTION'], deviceId, externalId, groupId, mark, scope, accessNumbers, LoginId=LoginId)

         # *** Build set of requests to make ***
         requestList = PRIM.getRequestList(totalToUse[0], maxToUse, amount, requestType, maxCommands)

         # Save extraAVP - It's changed each call into sendOneRequest
         tmpExtraAvp = copy.deepcopy(extraAVP)

         # Set default session ID
#        print 'Session ID at time when array is created: ' + str(sessionId)
         lclSessionId = sessionId

         # Decrement session ID, as next loop will always bump by at least one.
         # Want to save last used session ID into max ID array, and want to keep it from growing
         # too high (so IDs of last work in subsequent commands)
         try: sessionId = int(sessionId) - 1
         except: pass
        
         # Setup next event array.
         # entries are: device, accessNumber, time delta, session ID, rating group, msccServiceId.
         nextEvents = []
         queueCount = 0
         absoluteDelay = 0
         for i in range(len(deviceIdToSend)):
                # Get desired starting delay
                if i >= len(startDelay): delay = float(startDelay[-1])
                else: delay = float(startDelay[i])
                
                # If negative, then we want to store an absolute delay
                if delay < 0:  
                        absoluteDelay += abs(delay)
                        delay = absoluteDelay
                #print('Delay: ' + str(delay))
                
                # Bump the session ID
                try: sessionId = int(sessionId) + 1
                except: pass
                        
                # Store event
                nextEvents.append((deviceIdToSend[i], accessNumberToSend[i], int(delay), sessionId, ratingGroup, msccServiceId))
                
                # Count number of events queued
                queueCount += 1

         # Total number of events is the device list * the request list
         #print('queueCount = ' + str(queueCount) + ', len(requestList) = ' + str(len(requestList)))
         queueCount *= len(requestList)

         # Set return session ID value
         returnSessionId = str(sessionId)

         # Also need to bump max assigned IDs, or else we'll end up with duplicate session IDs on subsequent commands.
         try:
                if int(returnSessionId) > int(DATA.maxAssignedIds['sessionId']): DATA.maxAssignedIds['sessionId'] = returnSessionId
         except: pass
         
         # Set parameter index
         parameterIndex = 0
         
         # Get quantity selector (so we can distinguish the top-level service)
         quantitySelector = diameter_utils.getQuantitySelector(serviceId, mscc = True)
         
         # Keep going until we have no events to process
         noCheckIndex = -1
         currentResv = 0
         clearMsccDataFlag = False
         absoluteDelay = 0
         while len(nextEvents) > 0:
                # Service ID may be a child service (e.g. VoLTE).  If so map service ID to parent, as upcoming logic assumes a parent service (e.g. voice, data, text).
                try:    serviceId = CUST.childServiceToParent[childService]
                except: pass
                
                # Clear any previous RG list
                ratingGroupList = []
                
                # Bump index to use when no checks are in effect
                noCheckIndex += 1

                # Sort the event list
                nextEvents = sorted(nextEvents, key=lambda time: time[2])
                #print('nextEvents (device/accessNumber/startDelta/lclSessionId/ratingGroup/msccServiceId): ' + str(nextEvents[0]))

                # Get key items
                device       = imsi   = nextEvents[0][0]
                accessNumber = msisdn = nextEvents[0][1]
                startDelta      = float(nextEvents[0][2])
                lclSessionId    = nextEvents[0][3]
                ratingGroup     = nextEvents[0][4]
                msccServiceId   = nextEvents[0][5]
                
                # If we're waiting absolute time, then sleep until the time
                if aqmRealTimeFlag:
                        timeToSleep = startDelta - absoluteDelay
                        if timeToSleep > 0:
                                print('Will sleep ' + str(timeToSleep) + ' seconds until the event is supposed to run')
                                time.sleep(timeToSleep)
                        
                        # Update absolute time
                        absoluteDelay = startDelta
                
                # Need to store back parameters we "think" may be added via custKeys.  Not an exact science...
                lclDCT['deviceId'] = lclDCT['imsi'] = imsi
                lclDCT['accessNumbers'] = lclDCT['msisdn'] = msisdn
                
                # For Shane:
                if verbose.lower() == 'full':
                        # Define common file name starting string
                        formatted_step = u'%03d' % step
                        name = testName + DATA.fileChar + str(formatted_step)

                        # For diameter events we want to add the request type to the string
                        if lclDCT['ACTION'].startswith('diameter'):
                                name += DATA.fileChar + requestType

                        # Add common ending to the file name
                        name += DATA.fileChar + lclDCT['ACTION'] + str(device) + str(noCheckIndex)

                        print('Saving Shane query to file ' + name)

                        # Now do the query
                        if saveFunc == 'saveMDC':         QAUTILS.saveMDC(queryValue, name, queryType=queryType, queryTime=lclStartTime)
                        elif saveFunc == 'saveDeviceMDC': QAUTILS.saveDeviceMDC(queryValue, name, queryType=queryType, queryTime=lclStartTime)
                        else:                             QAUTILS.saveGroupMDC(queryValue, name, queryType=queryType, queryTime=lclStartTime, querySize=querySize)

#               print ' There are ' + str(len(nextEvents)) + ' left to process'
                # Remove this item from the list
                nextEvents.pop(0)

                # If checking, then gather data
                if TRACK.checkIfSessionTracked(lclSessionId, ratingGroup):
                        externalId  = TRACK.sessionGetValue(lclSessionId, ratingGroup, 'externalId')
                        index       = TRACK.sessionGetValue(lclSessionId, ratingGroup, 'index')
                        aqmFunc     = TRACK.sessionGetValue(lclSessionId, ratingGroup, 'aqmFunction')
                        ttu         = TRACK.sessionGetValue(lclSessionId, ratingGroup, 'totalToUse')
                        SkipFlag    = TRACK.sessionGetValue(lclSessionId, ratingGroup, 'SkipFlag')
                        sessionOffset = TRACK.sessionGetValue(lclSessionId, ratingGroup, 'sessionOffset')
                        currentResv = TRACK.sessionGetValue(lclSessionId, ratingGroup, 'currentReservation')

                        # If first time through the loop, then session was open and this is a subsequent command.
                        # Don't want to use old values and may want to use input values...
                        if noCheckIndex == 0:
                                #index = 0
                                SkipFlag = False

                                # If totalToUse was input, then override the value here
                                if totalToUse[0] != -1: ttu = totalToUse[0]

                                # Get aqmFunction
                                aqmFunc = aqmFunction[0]

                        # Exit if we encountered an error
                        if eventFlag:
                                print('ERROR:  can\'t send a requesttype of "event" in the middle of a session')
                                sys.exit('Exiting due to error encountered')

                        # Debug output
                        if diamDebug:
                         print('Restored values from session/rating group ' + str(lclSessionId) + '/' + str(ratingGroup) + \
                                ': ' + str((externalId,index,aqmFunc,ttu,SkipFlag,sessionOffset)))
                else:
                        if diamDebug: print('Not tracking this session: sesison ID = ' + str(lclSessionId) + ', rating group = ' + str(ratingGroup))
                        
                        # If nochecks are in effect, then use the loop counter.  Else use first entry when starting a new session.
                        if noChecks: index = noCheckIndex
                        else:        index = 0
                        SkipFlag = False

                        # Other parameters are as per input commands.
                        if parameterIndex >= len(aqmFunction): aqmFunc = aqmFunction[-1]
                        else: aqmFunc = aqmFunction[parameterIndex]

                        if parameterIndex >= len(totalToUse): ttu = totalToUse[-1]
                        else: ttu = totalToUse[parameterIndex]

                        #print 'totalToUse[' + str(parameterIndex) + '] = ' + str(ttu)

                        sessionOffset = startDelta

                        # Increment parameter index
                        parameterIndex += 1
                        
                        if diamDebug: 
                         print('Set values for session/rating group ' + str(lclSessionId) + '/' + str(ratingGroup) + \
                                ': ' + str((externalId,index,aqmFunc,ttu,SkipFlag,sessionOffset)))
                
                if SkipFlag: break

                # Make sure we don't go beyond the end of the specified set of requests.
                # AQM will self-end with a QHT, so allow it to terminate that way.
                if aqmFunc == '0' and noCheckIndex >= queueCount: break

                # Get request for this event
                try:
                        request = requestList[index]
                        #print 'requestList[' + str(index) + '] = ' + request
                except:
                        request = requestList[-1]
                        #print 'requestList[-1] = ' + request
                lclDCT['currenctUsageCommandRequest'] = request

                # Restore extraAVP, so we don't have any residual settings from the previous command
                extraAVP = copy.deepcopy(tmpExtraAvp)

                # Additional Sy processing.
                # Current customer Sy doesn't send SL-Request-Type AVP for interim SLR messages.
                # Eventually want to parameterize this...
                #if interface.lower() == 'sy' and request == 'interim': extraAVP['omit'].append('SL-Request-Type')

                # Get requested and used amounts for this message.  May start with a $ if currency is involved.
                currencyFlag = {}
                exponent = {}
                
                if interface.lower() in ['gy', '5g']:
                 # Requested/Used amounts may be a formula.  Need to support that here.  Always get integer back (no fractions in usage).
                 # Always re-run the last formula if we're over the index.
                 if index < len(reqAmount):  
                        # Save the index value
                        reqFormulaSave = reqAmount[index]
                        reqAmount[index]  = str(PRIM.processAmountFormula('subscriber', externalId, reqAmount[index], lclStartTime, lclDCT['ACTION'], noUnits = False))
                        
                        # Remove decimals except if a currency
                        if reqAmount[index][0] != '$': reqAmount[index] = reqAmount[index].split('.')[0]
                 else:  
                        # If single term on an existing session, then set saved to the last entry
                        reqFormulaSave = reqAmount[-1]
                        reqAmount[-1]  = str(PRIM.processAmountFormula('subscriber', externalId, reqFormulaSave,   lclStartTime, lclDCT['ACTION'], noUnits = False))
                        
                        # Remove decimals except if a currency
                        if reqAmount[-1][0] != '$': reqAmount[-1] = reqAmount[-1].split('.')[0]
                
                 # Process used amounts
                 if index < len(usedAmount): 
                        # Save the index value
                        usedFormulaSave = usedAmount[index]
                        usedAmount[index] = str(PRIM.processAmountFormula('subscriber', externalId, usedAmount[index],  lclStartTime, lclDCT['ACTION'], noUnits = False))
                        
                        # Remove decimals except if a currency
                        if usedAmount[index][0] != '$': usedAmount[index] = usedAmount[index].split('.')[0]
                 else:  
                        # If single term on an existing session, then set saved to the last entry
                        usedFormulaSave = usedAmount[-1]
                        usedAmount[-1]  = str(PRIM.processAmountFormula('subscriber', externalId, usedFormulaSave   , lclStartTime, lclDCT['ACTION'], noUnits = False))
                
                        # Remove decimals except if a currency
                        if usedAmount[-1][0] != '$': usedAmount[-1] = usedAmount[-1].split('.')[0]
                
                 # Get data
                 (currencyFlag['req'], exponent['req'], requested) = currencyProcess(reqAmount, index)
                 (currencyFlag['used'], exponent['used'], used)    = currencyProcess(usedAmount, index)
                 
                 # Copy lines above may have left used non-zero in request, and request non-zero in term.
                 # Fix that here (as they're ignored by the code for these scenarios anyway)
                 usedInput = used
                 usedCleared = False
                 reqInput = requested
                 reqCleared = False
                 if   request == 'initial':
                        used = 0
                        usedCleared = True
                 elif request == 'term' and not eventFlag:
                        requested = 0
                        reqCleared = True

                 # Default calculation values
                 timeBuffer = 0.0
                 velocity = 1.0
                 validityTime = 1

                 # Retrieve key amounts
                 granted = TRACK.sessionGetValue(lclSessionId, ratingGroup, 'lastGrant')
                 vqt = TRACK.sessionGetValue(lclSessionId, ratingGroup, 'vqt')
                 validityTime = TRACK.sessionGetValue(lclSessionId, ratingGroup, 'validityTime')
                 
                 # The current reserved amount needs to decrement by the granted amount
                 if currentResv: currentResv -= int(granted)
#                print 'currentResv decremented by ' + str(granted) + ', now equal ' + str(currentResv)
                 
#                print 'Before used check: ' + str((used,request,noChecks,lclSessionId,ratingGroup,aqmFunc))
                 # If used is -1, then need to set
                 if used == -1:
                        # Make sure not the start of a session, in which case no session exists (and used is not used :-).
                        # Also if we're not checking then alwys set to 0.
                        '''
                        elif noChecks and not eventFlag:
                                # Nothing input for used units and not tracking.
                                # Set to something meaningful per-service.
                                if   'Data' in quantitySelector:            used = 1048576
                                elif 'Duration' in quantitySelector:        used = 3600
                                elif 'serviceSpecific' in quantitySelector: used = 1
                                else:
                                        print 'WARNING:  running with noChecks on and an unknown serviceId value: ' + serviceId + '. Setting used units to 1.'
                                        used = 1
                        '''
                        if request == 'initial': used = 0
                        else:
                                # Assume we're going to use everything
                                used = int(granted)

                                # Debug output
                                #print 'aqmFunction = ' + str(aqmFunc)

                                # If aqm function was input, then determine factor here
                                if aqmFunc != '0':
                                        # Get AQM parameters
                                        (startTime, timeBuffer, used, velocity, validityTime) =  \
                                                AQM.aqmGetEventParameters(aqmFunc, lclSessionId, ratingGroup, requestType, aqmMaxVelocity, index, used, vqt)

                                        # Get elapsed time calculations for used amount adjustments
                                        (_x, _y, _z, used) = AQM.aqmCalculateElapsedTime(used, velocity, timeBuffer, validityTime, aqmFunc)

                 else:
                        # If used amount is specified, then set the velocity equal to the used (as we're not really calculating this)
                        if used > 0: velocity = float(used)

                        # Hard-coded usage means the whole managing of current reservations doesn't work well.  So zero that value if we have fixed usage.
                        if request != 'initial': currentResv = 0

                 # Support totalToUse and maxToUse parameters
                 (used, ttu, maxToUse, reportingReason, request, requested, SkipFlag) = PRIM.totalAndMaxToUse(ttu, maxToUse, used, requestType, reportingReason, request, requested, SkipFlag, currentResv)

                # Initialize MSCC structures for CCR commands
                combinedList = []
                allMsccList = []
                
                if interface.lower() in ['gy', '5g']:
                        # See if we should block MSCC
                        if noMscc:
                                if diamDebug: print('Removing all MSCC information')
                                # Remove all MSCC items from the message
                                extraAVP['omit'].append('Multiple-Services-Credit-Control')
                                extraAVP['omit'].append('Multiple-Services-Indicator')
                                #extraAVP['omit'].append('Requested-Service-Unit')
                                
                                # Copy requested and used amounts to locals
                                reqamount = requested
                                usedamount = used
                                
                                # Set Service ID at top level
                                avp = 'Service-Identifier'
                                value = ratingGroup
                                extraAVP['omit'].append(avp)
                                if value: extraAVP['add'].append(avp + ':' + value)
                                
                                # Set local exponent if one exists.  The logic doesn't hold if both requested and used have exponents...
                                if   currencyFlag['used']: lclExponent = exponent['used']
                                elif currencyFlag['req']:  lclExponent = exponent['req']
                                else:                      lclExponent = None
                                #print 'Sending through reqamount = ' + str(reqamount) + ', usedamount = ' + str(usedamount) + ', lclExponent = ' + str(lclExponent)
                                
                                # Set lists
                                combinedList.append((ratingGroup, reqamount, usedamount))
                                allMsccList.append((ratingGroup, reqamount, usedamount, reportingReason, None, eventPass))
                                
                                # May be a refund
                                if request == 'event' and requestAction == '1':
                                        # Need to have saved the refund information or overridden it
                                        if refundOverride == '0':
                                                if diamDebug: print('Refund override indicates no Refund-Information AVP for session ID ' + str(sessionId))
                                                refundInformation = None
                                        elif refundOverride:
                                                if diamDebug: print('Refund override indicates ' + refundOverride + ' to be sent in the Refund-Information AVP for session ID ' + str(sessionId))
                                                refundInformation = refundOverride
                                        elif str(refundSessionId) in RefundData:
                                                refundInformation = RefundData[str(refundSessionId)]
                                                if diamDebug: print('Saved refund data ' + refundInformation + ' to be sent in the Refund-Information AVP for session ID ' + str(sessionId))
                                        else:   sys.exit('ERROR: refund session ' + str(refundSessionId) + ' was not saved.')
                                
                                # If refund information was specified or calculated, then add to the message.
                                if refundInformation:   extraAVP['add'].append('Refund-Information:' + refundInformation)
                                        
                        else:
                                # Don't use these locals
                                reqamount = usedamount = 0
                                lclExponent = None
                                
                                # Hack: force data in each request.
                                #if request != 'initial':
                                        #extraAVP['add'].append('Multiple-Services-Credit-Control|Used-Service-Unit$1|CC-Input-Octets:1048576')
                                        #extraAVP['add'].append('Multiple-Services-Credit-Control|Used-Service-Unit$1|CC-Output-Octets:1048576')
                                        #extraAVP['add'].append('Multiple-Services-Credit-Control|Used-Service-Unit$1|CC-Time:10')
                                        #extraAVP['add'].append('Multiple-Services-Credit-Control|Used-Service-Unit$1|Reporting-Reason:5')
                                        #extraAVP['add'].append('Multiple-Services-Credit-Control|Used-Service-Unit$1|CC-Service-Specific-Units:1')

                                # If eventFlag, then change request to be event
                                if eventFlag: request = 'event'
                                
                                # Make life simple.  If multi MSCC NOT defined or we previously created it (prior loop), then set here.
                                if (not multiMsccData) or clearMsccDataFlag:
                                        # NOTE: store the input values if they were artifically cleared earlier.  MSCC code will clear as needed.
                                        if usedCleared: used = usedInput
                                        if reqCleared:  requested = reqInput
                                        multiMsccData = buildMsccData(ratingGroup, msccServiceId, requested, used, reportingReason, eventPass)
                                        
                                        # Need to re-run each iteration, as we created MSCC data here
                                        clearMsccDataFlag = True
                                
                                # Get MSCC data for this command
                                try:
                                        msccFullData = multiMsccData[index]
                                except:
                                        msccFullData = multiMsccData[-1]
                                if diamDebug:
                                 print('msccFullData[' + str(index) + '] = ' + str(msccFullData) + ', eventPass = ' + str(eventPass))
                                
                                # Separate into the number of individual MSCC context to send for this message
                                msccContext = msccFullData.split('|')
                                
                                # Need to process each MSCC context
                                ratingGroupList = []
                                reqAmountList = []
                                usedAmountList = []
                                savedEventPass = eventPass
                                for i in range(len(msccContext)):
                                        # Get mscc data
                                        msccData = msccContext[i]
                                        
                                        # Split into individual values
                                        msccIndividualData = msccData.split('/')
                                        
                                        # Now the fun stuff.  Not all values may be set.  
                                        (ratingGroupForCall, msccServiceIdForCall, requestForCall, usedDetails, reportingReasonForCall, incServiceId, eventPass) = \
                                                separateMsccDataElement(msccIndividualData, request, tariffChangeUsage, lclDCT, eventPass, lclSessionId)
                                        
                                        # NOTE: No tyet gotten scenario where multi-MSCC with some expected failures.  Will work on this if needed...
                                        eventPass = savedEventPass
                                        
                                        # May be a refund
                                        if request == 'event' and requestAction == '1':
                                                # Need to have saved the refund information or overridden it
                                                if refundOverride == '0':
                                                        if diamDebug: print('Refund override indicates no Refund-Information AVP for session ID ' + str(sessionId))
                                                        refundInformation = None
                                                elif refundOverride:
                                                        if diamDebug: print('Refund override indicates ' + refundOverride + ' to be sent in the Refund-Information AVP for session ID ' + str(sessionId))
                                                        refundInformation = refundOverride
                                                elif str(refundSessionId) in RefundData:
                                                        refundInformation = RefundData[str(refundSessionId)]
                                                        if diamDebug: print('Saved refund data ' + refundInformation + ' to be sent in the Refund-Information AVP for session ID ' + str(sessionId))
                                                else:   sys.exit('ERROR: refund session ' + str(refundSessionId) + ' was not saved.')
                                        
                                        # If refund information was specified or calculated, then add to the message.
                                        if refundInformation:   extraAVP['add'].append('Refund-Information:' + refundInformation)
                                        
                                        extraAVP = diameter_utils.getMsccGroupedAvp(
                                                extraAVP, request, requestForCall, usedDetails, serviceId, usedDirection, 
                                                requestDirection, ratingGroupForCall, reportingReasonForCall, msccCount=i, 
                                                incServiceId=incServiceId, currencyFlag=currencyFlag, exponent=exponent, 
                                                currencyCode=currencyCode, triggerType=triggerType, msccServiceId=msccServiceIdForCall, refundInformation = refundInformation, usedUnitRatType=usedUnitRatType)
                                
                                        # Add to lists
                                        ratingGroupList.append(ratingGroupForCall)
                                        reqAmountList.append(requestForCall)
                                        if type(usedDetails) is list:   usedAmountList.extend(usedDetails)
                                        else:                           usedAmountList.append(usedDetails)
                                        combinedList.append((ratingGroupForCall, requestForCall, usedDetails))
                                        allMsccList.append((ratingGroupForCall, requestForCall, usedDetails, reportingReasonForCall, msccServiceIdForCall, eventPass))
                                        #print 'MSCC data returned: ' + str(allMsccList[-1])
                                        
                                # If eventFlag, then change request to be term
                                if eventFlag: request ='term'
                        
                        # If time desired to be reported, add in here (exclude voice as this would be a test error)
                        if serviceId != 'voice':
                                if request != 'initial' and usedTime:
                                        if not interface.lower().startswith('5g'): extraAVP['add'].append('Multiple-Services-Credit-Control|Used-Service-Unit$0|CC-Time:' + str(usedTime))
                                        else:                                      extraAVP['usedTime'] = usedTime
                                if request != 'term' and reqTime:
                                        if not interface.lower().startswith('5g'): extraAVP['add'].append('Multiple-Services-Credit-Control|Requested-Service-Unit$0|CC-Time:' + str(reqTime))
                                        else:                                      extraAVP['reqTime'] = reqTime
                        
                        # If data desired to be reported, add in here (exclude data as this would be a test error)
                        if serviceId != 'data':
                                if request != 'initial' and usedData:
                                        if not interface.lower().startswith('5g'): extraAVP['add'].append('Multiple-Services-Credit-Control|Used-Service-Unit|CC-Total-Octets:' + str(usedData))
                                        else:                                      extraAVP['usedData'] = usedData
                                if (request != 'term' or eventFlag) and reqData:
                                        if not interface.lower().startswith('5g'): extraAVP['add'].append('Multiple-Services-Credit-Control|Requested-Service-Unit$0|CC-Total-Octets:' + str(reqData))
                                        else:                                      extraAVP['reqData'] = reqData
                                        print("\n\nAdding reqData to message\n\n")
                        
                        # If money desired to be reported, add in here
                        if eventMoney:
                                if not interface.lower().startswith('5g'): extraAVP['add'].append('Multiple-Services-Credit-Control|Requested-Service-Unit$0|CC-Money|Unit-Value|Value-Digits:' + str(eventMoney))
                                else:                                      extraAVP['eventMoney'] = eventMoney
                        
                        # Get elapsed time calculations (for real this time)
                        (elapsedTime, timeBuffer, modVelocity, used) = AQM.aqmCalculateElapsedTime(used, velocity, timeBuffer, validityTime, aqmFunc)
                        
                else:
                        # Not needed for other protocols, but referenced later
                        requested = reqamount = usedamount = lclExponent = currencyCode = elapsedTime = used = modVelocity = timeBuffer = 0
                
                # Adjust time, so subsequent events are pushed ahead as per the command line.
                # If session and not the start of the session, then don't adjust.
                # May change start time if we're testng aqm.
                # NEW FEATURE:  Need to support array of times...
                ###if (requestType == 'session' and request == 'initial') or not (requestType == 'session'):
                # See which startTime value to use.  "startTime" is valid only on the first loop.  Otherwise need savedstartTime.
                if noCheckIndex == 0: startValue = 'startTime'
                else:                 startValue = 'savedstartTime'
                if aqmFunc != '0': startTime = MDCTIME.getTime(int(elapsedTime), startTime=startTime, tz=subTimeZone)
                elif startValue in lclDCT and lclDCT[startValue] != '' and lclDCT[startValue] != None:
#                       print 'Getting updated start time:  current time = ' + startTime + ', input = ' + lclDCT[startValue]
                        startTime = CSVID.getCommandLineTime(startValue, lclDCT[startValue], startTime, DATA.timeSepChar)
#                       print 'new start time = ' + startTime
                else:   startTime = lclStartTime

                # Want session start time (which is not this time if we're not at the start of a session).
                # Also if we're not checking then always set to current tool time.
                if (request == 'initial') or noChecks:
                        sessionStartTime = startTime
                else:
                        # Get saved session time
                        sessionStartTime = TRACK.sessionGetSessionStartTime(lclSessionId, ratingGroup)

                        # If previously opened a shell of a session, then nothing saved (i.e. no rating group).  Need to account for this.
                        if sessionStartTime == 0: sessionStartTime = startTime

                # Get time delta from start of session
#               print 'Getting delta of ' + str(sessionStartTime) + ' and ' + str(startTime)
                timeDelta = MDCTIME.timeDelta(sessionStartTime, startTime)

                # OK, after all of the above, if we're NOT using AQM, then the used velocity calculations are not correct.  Fix here.
                if aqmFunc == '0':
                        if int(timeDelta) > 0: modVelocity = float(used) / float(timeDelta)
                        else:                  modVelocity = 0

                # Sanity check (for now).  If the elapsed time is not the same as the startDelta, then we have issues (i.e. look ahead didn't work right)
                # Only care on non-term messages, as term means things are closing (and they may close for a number of reasons).
                if aqmFunc != '0' and request != 'term' and int(elapsedTime) > timeDelta and not aqmRealTimeFlag:
                        print('WARNING: elapsedTime = ' + str(elapsedTime) + ' but timeDelta = ' + str(timeDelta))
#                       sys.exit('Exiting due to error')
                if aqmFunc != '0' and request != 'term' and timeDelta != startDelta and startDelta > 0 and not aqmRealTimeFlag:
                        print('WARNING: startDelta = ' + str(startDelta) + ' and timeDelta = ' + str(timeDelta))
#                       sys.exit('Exiting due to error')
                
                # These are per-customer AVPs where logic of whether to include them, and if so what value to use, is involved.
                lclDCT['request'] = request
                #print 'Storing request = '+ request
                
                # Want to force a number of AVPs to be sent.  The OCS may drop them, but
                # need to show that we're able to process them without incident.
                lclDCT['savedStartTime'] = startTime
                
                # If an Rx command then add the Media Description
                if interface.lower() == 'rx' and request != 'term': CSVRX.addRxMediaData(extraAVP, lclDCT, options)
                
                # Process key AVPs that we may want to include/exclude in Diameter messages.
                PRIM.additionalAVPs(lclDCT, extraAVP, options, sessionStartTime, serviceId, interface, calledStation)
                
                # If eventFlag, make final adjustments
                if eventFlag:
                        # Change request to be event
                        request ='event'
                        
                        # If a requestAction, then add it
                        if int(requestAction) > 0: extraAVP['add'].append('Requested-Action:' + requestAction)
                        
                # Debug output
#               print 'extraAVP = ' + str(extraAVP)
                
                # Debug output
                if aqmFunc != '0':
                        # Build output string
                        midString='Used = velocity(M) * elapsed time:'
                        format = "Session %-10s '%-7s': %36s %10s = %10.2f * %5s: timeBuffer = %4.3f, Total delta = %4s, TTU = %s, Reserved = %s\n"
                        sys.stdout.write(format % (str(lclSessionId), request, midString,
                                         str(used), modVelocity, str(elapsedTime), timeBuffer, str(timeDelta), str(ttu), str(currentResv)))

#                       if diamDebug: print 'Diameter session ' + str(lclSessionId) + ' ' + request + ' request:  Used amount = mod_velocity * elapsed time: ' + str(used) + ' = ' + str(modVelocity) + ' * ' + str(elapsedTime) + ': timeBuffer = ' + str(timeBuffer)

                else:
                        # Output what we're doing...
                        if device != '-1' and accessNumber != '-1':
                                if verbose.lower() not in ['low', 'none']:
                                 print('Sending a ' + interface + ' ' + request + ' event to device/accessNumber ' + \
                                        device + '/' + accessNumber + ' with time ' + startTime + ' session ID ' + str(lclSessionId) + ', RatingGroup/requested/used = ' + str(combinedList))
                                queryValue = device
                        elif device != '-1':
                                if verbose.lower() not in ['low', 'none']:
                                 print('Sending a ' + interface + ' ' + request + ' event to device ' + device + \
                                        ' with time ' + startTime + ', session ID ' + str(lclSessionId) + ', RatingGroup/requested/used = ' + str(combinedList))
                                queryValue = device
                        else:
                                if verbose.lower() not in ['low', 'none']:
                                 print('Sending a ' + interface + ' ' + request + ' event to access number ' + accessNumber + \
                                        ' with time ' + startTime + ', session ID ' + str(lclSessionId) + ', RatingGroup/requested/used = ' + str(combinedList))
                                queryValue = accessNumber
                
                # Last minor hack:  requested could have ben -1 (flag to signal to include grouped AVP but no data).  Reset to 0 if so.
                if requested == -1: requested = 0
                
                # Never done with hacks...  To support SIP URL the parameter devAddress was added.  This is the address part of the device.
                # If set, then combine deviceId and address with a @ between and set the right fields.
                if devAddress:
                        # Set login parameter
                        loginId = 'sip:+' + device + '@' + devAddress
                        
                        # Clear other parameters
                        devId = 0
                        accessNumberId = 0
                elif LoginId:
                        # Use this
                        loginId = LoginId
                        devId = 0
                        accessNumberId = 0
                else:
                        # Clear loginId and use other parameters
                        loginId = None
                        devId = device
                        accessNumberId = accessNumber
                
                # Minor hack.  Skip MSISDN and/or IMSI based on input flag
                supi = 0
                if skipMsisdn:  accessNumberId = 0
                if skipImsi:
                        supi=devId
                        devId = 0
                
                # Allow for per-customer customizations
                if hasattr(CUST, "custDeviceRatingAttributes"): CUST.custDeviceRatingAttributes(lclDCT, extraAVP)
                
                # CUST code may decide not to run the command.  This would be a value in dictionary entry "doNotRunCommand"
                if "doNotRunCommand" in lclDCT:
                        # CUST code wants to skip command execution
                        if diamDebug: print('Custom code custDeviceRatingAttributes() defined entry "doNotRunCommand", so skipping command execution')
                        return (queryType, queryValue)


                # Service ID may have been changed to a parent above.  Restore to child here.
                serviceId = lclDCT['childService']
         
                if diamDebug: print('Rating group = ' + str(ratingGroup) + ', eventPass = ' + str(eventPass))
#               print 'ratingGroupRequiredForSession = ' + str(ratingGroupRequiredForSession)
#               print('loginId = ' + str(loginId))
                # Set on/off line charging into extraAVP
                if extraAVP:
                        extraAVP['offlineFlag'] = str(offline)
                        extraAVP['addTriggers'] = True
                
#               if extraAVP: print('extraAVP: ' + pprint.pprint(extraAVP))
                # Send the request
                if not interface.lower().startswith('5g'):
                 diamDct = QAUTILS.sendOneRequest(
                 deviceId=devId,
                 reqamount=reqamount,
                 usedamount=usedamount,
                 requestType=request,
                 sessionId=lclSessionId,
                 serviceId=serviceId,
                 startTime=startTime,
                 extraAVP = extraAVP,
                 accessNumber = accessNumberId,
                 loginId = loginId,
                 diamConnection = diamConnection,
                 commandType = interface,
                 SkipCERFlag=True,
                 exponent=lclExponent,
                 currencyCode=currencyCode,
                 verbose=verbose,
                 sendOnlyFlag=sendOnlyFlag,
                 )
                elif interface.lower() == '5gsy':
                 # Fix session offset so actual session ID is sent in the notify URI
                 if not int(sessionOffset): sessionOffset = str(lclSessionId)
                 
                 # Send to 5G API
                 (sessionId, status, diamDct) = QAUTILS5G.sendOneRequestSy(
                 deviceId=devId,
                 requestType=request,
                 startTime=startTime,
                 sessionId=sessionOffset,
                 policyCounterIds=policyIdentifier,
                 httpLevel=httpLevel,
                 )
                 
                 # Convert returned string to a dictionary
                 diamDct = json.loads(diamDct)
                 
                 # Debug
                 if diamDebug: print('5G Sy event: session = ' + str(sessionId) + ', status = ' + str(status) + ', content = ' + str(diamDct))
                 sessionOffset = sessionId
                else:
                 # Fix session offset so actual session ID is sent in the notify URI
                 try:
                         if not int(sessionOffset): sessionOffset = str(lclSessionId)
                 except: pass
                 
                 # Send to 5G API
                 '''
                 # Test code - easy multi-MSCC
                 reqAmountList = ['1048576', '1048576','1048576']
                 usedAmountList = ['1048576', '1048576','1048576']
                 ratingGroupList = ['1', '2', '3']
                 '''
                 (sessionId, status, diamDct) = QAUTILS5G.sendOneRequest(
                 deviceId=devId,
                 reqAmountArr=reqAmountList,
                 usedAmountArr=usedAmountList ,
                 serviceIdArr = copy.deepcopy(ratingGroupList),
                 serviceType = serviceId,
                 requestType=request,
                 ratingGroupsArr=ratingGroupList,
                 startTime=startTime,
                 sessionId=sessionOffset,
                 getResponseContent=True,
                 extraAVP=extraAVP,
                 httpLevel=httpLevel,
                 eventPass=eventPass,
                 accessNumber = accessNumberId,
                 supi=supi,
                 )
                 
                 # Copy data so sdaveData processing can use it
                 MISC.SavedData = copy.deepcopy(diamDct)
                 
                 sessionOffset = sessionId
                
                # Debug 
                if diamDebug:
                        print(interface + ' usage event; session = ' + str(sessionId))
                        pprint.pprint(diamDct)
                
                # Pass the message to custom code if defined.
                try:    CUST.processRatingResponse(interface, diamDct)
                except: pass
                
                # Debug output
                '''
                print 'diamConnection: ' + str(diamConnection)
                print 'CCA diamDct: ' 
                if diamDct: pprint.pprint(diamDct)
                else: print 'None'
                '''

                # Some customers support time based charging for data sessions.  Allow for a change in quantity selector here.
                # Only matters for Gy
                policyData = ''
                key = ''
                if interface.lower() in ['gy', '5g']:
                        # Field to check for depends on the value of the requestDirection and the service being processed.
                        #print 'quantitySelector = ' + str(quantitySelector)
                        # HACK: dictionary returning currency data reversed!
                        if currencyFlag['req']:                         key = 'Unit-Value->CC-Money->Value-Digits'
                        elif 'Data' in quantitySelector:
                                fivegkey = 'totalVolume'
                                if   requestDirection.lower() == 'in':  key = 'CC-Input-Octets'
                                elif requestDirection.lower() == 'out': key = 'CC-Output-Octets'
                                else:                                   key = 'CC-Total-Octets'
                        elif 'Duration' in quantitySelector:
                                fivegkey = 'time'
                                key = 'CC-Time'
                        else:           
                                fivegkey = 'serviceSpecificUnits'
                                key = 'CC-Service-Specific-Units'
                        
                        try:
                                if ratingGroup == CUST.ratingGroupMapping['Time']: key = 'CC-Time'
                                #key = CUST.quantitySelectorOveride(quantitySelector, ratingGroup, key)
                        except:
                                kef = 1
                
                # Check result code.  If not expecting a response, then assume success
                if sendOnlyFlag: diamResult = 0
                elif not interface.lower().startswith('5g'):
                        # Check outer result codes
                        diamResult = diameter_utils.checkDiameterResultCodes(diamDct)
                else:
                        # If we get a success result code then indicate success, else fail
                        if int(status) >= 200 and int(status) < 300:
                                diamResult = 0
                        else:   diamResult = 1
                
                # Exit if received an unexpected result.
                # Note: always check diameter results (regardless of noChecks status).
                # For 5G, HTTP result is always success.  Will detect issues within MSCC replies
                if interface.lower().startswith('5g'): errorFlag = False
                else: errorFlag = diameter_utils.exitOnFailureDiameterResultCodes(diamResult, eventPass=eventPass, diamDct=diamDct, continuePastError=continuePastError)
                # Check if errors encountered
                if errorFlag:
                        if continuePastError:
                                print('Continuing with the test file as continuePastError flag is True')
                                continue
                                break
                        else:
                                # Exit if we encountered an error
                                sys.exit('Exiting due to error encountered')
                        
                # Do non-Gy processing
                if interface.lower() not in ['gy', '5g', '5gsy']:
                        # Stuff to do if success expected and we received a response
                        if eventPass and not sendOnlyFlag:
                                # Debug
                                if lclDCT['verbose'].lower() not in ['low', 'none']:
                                 if (request == 'initial') and mark and diamDebug: print('Tracking ' + str(interface) + ' session ' + str(lclSessionId) + ' with mark ' + str(mark))
                                
                                # Update context
                                TRACK.updateSessionTrackingData(
                                        device, accessNumber, request, lclSessionId, None, startTime, 
                                        None, None, None, mark, interface.lower(), verbose=lclDCT['verbose'].lower(), diamDebug=diamDebug)
                                
                                # Get policy/user data
                                if request != 'term':
                                        if   interface.lower() in ['gx', 'rx']:
                                                policyData = PRIM.retrieveAndValidatePolicyRules(diamDct, lclDCT, printFlag=True, interface=interface.lower())
                                        elif interface.lower() == 'sy': policyData = CMDDIAMSY.retrieveAndValidateSyPolicyData(diamDct, lclDCT, printFlag=True)
                                        else:                                   policyData = CMDDIAMSH.retrieveAndValidateShUserData(diamDct, lclDCT, printFlag=True)
                                
                        # Track the session if Rx (not sure why it's not being tracked otherwise...)
                        if interface.lower() in ['rx']:
                                TRACK.updateSessionTrackingData(
                                        device, accessNumber, request, lclSessionId, None, mark=mark,
                                        interface=interface.lower(), index=index+1, 
                                        sessionOffset=sessionOffset, verbose=verbose, diamDebug=diamDebug)
                        
                elif interface.lower().startswith('5g'):
                        # Don't track events
                        if not eventFlag:
                          # Get MSCC information.  NOTE: Nothing returned on a TERM, but want to update the session tracking to get the session end data.
                          if 'multipleUnitInformation' in diamDct:
                                if diamDebug and lclDCT['verbose'].lower() not in ['low', 'none']:
                                        print('5G MSCC response:')
                                        #pprint.pprint(diamDct['multipleUnitInformation'])
                                        pprint.pprint(diamDct)
                                        print('allMsccList:')
                                        pprint.pprint(allMsccList)
                                        
                                # NOTE: Loop through allMsccList, find values in diamDct['multipleUnitInformation'], then track each RG
                                for entry in diamDct['multipleUnitInformation']:
                                         # Make sure RG is specified
                                         if 'ratingGroup' not in entry:
                                                print('Hmmm.  Expected rating group to be returned')
                                                pprint.pprint(entry)
                                         else:
                                                # If no validity time returned, then need to assume something
                                                try:    validityTime = entry['Validity-Time'].strip()
                                                except: validityTime = 3600
                                        
                                                # Update context
                                                if diamDebug: print('Tracking RG ' + str(entry['ratingGroup']))
                                                try:    grantedAmount = entry['grantedUnit'][fivegkey]
                                                except: grantedAmount = '0'
                                                
                                                # Calculate granted velocity
                                                if validityTime: velocity = float(float(grantedAmount) / float(validityTime))
                                                else:            velocity = 0.0
                                                
                                                if diamDebug: print('Granted amount = ' + str(grantedAmount))
                                                #print('Tracking in MSCC for request ' + request + ', ratingGroup = ' + str(entry['ratingGroup']) + ', fivegkey = ' + fivegkey)
                                                TRACK.updateSessionTrackingData(
                                                        device, accessNumber, request, lclSessionId, entry['ratingGroup'], grantedAmount=grantedAmount, mark=mark,
                                                        interface=interface.lower(), index=index+1, totalToUse=ttu, aqmFunction=aqmFunc, grantedVelocity=velocity, 
                                                        sessionOffset=sessionOffset, verbose=verbose, diamDebug=diamDebug, validityTime=validityTime)
                          else:
                                # NOTE: Should check if unexpected. 5GSy will fall here, so address that by adding a RG if missing.
                                if not len(ratingGroupList): ratingGroupList = [0] 
                                #print('Tracking outside MSCC for request ' + request)
                                TRACK.updateSessionTrackingData(
                                        device, accessNumber, request, lclSessionId, ratingGroupList[0], mark=mark,
                                        interface=interface.lower(), index=index+1, totalToUse=ttu, aqmFunction=aqmFunc,
                                        sessionOffset=sessionOffset, verbose=verbose, diamDebug=diamDebug)
                        
                        # Validate returned policies
                        if interface.lower() == '5gsy' and request != 'term' and FIVEG.retrieveAndValidate5GSyPolicyData(lclDCT, str(diamDct)) != eventPass:
                                sys.exit('ERROR: ' + interface + ' validation of returned policy did not match expected result (' + str(eventPass) + ')')
                        
                        '''
                        TRACK.updateSessionTrackingData(
                                                device, accessNumber, requestToUse, lclSessionId, trackId, timeToReport, 
                                                requested, usedValue, grantedAmount, mark, interface.lower(),
                                                vqt=vqt, validityTime=validityTime, timeBuffer=timeBuffer,   
                                                usedVelocity=modVelocity, grantedVelocity=velocity, eventDelta=int(timeDelta),
                                                aqmFunction=aqmFunc, totalToUse=ttu, index=index+1, SkipFlag=SkipFlag,
                                                sessionOffset=sessionOffset, verbose=verbose, diamDebug=diamDebug)
                        '''
                        
                        # Add event if not a term and user requested a session
                        if requestType == 'session' and not SkipFlag: nextEvents.append((device, accessNumber, int(timeDelta), lclSessionId, ratingGroup, msccServiceId))
                
                # Call post-event custom function if defined
                try: (queryType,queryValue) = CUST.postEventProcessing(queryType,queryValue, serviceId)
                except: pass
                
                # Gy work to do if outer success and not expecting failures
                if interface.lower() in ['gy', '5g'] and not errorFlag and eventPass:
                  # Key can be either service ID or rating group, as both are not required.  If both present use rating group.
                  if ratingGroup is not None:     
                        eventKey = 'Rating-Group'
                        trackId = ratingGroup
                  elif msccServiceId is not None:
                        eventKey = 'Service-Identifier'
                        trackId = msccServiceId
                  else: 
                        eventKey = None
                        trackId = None
                  
                  # Process each MSCC response
                  for i in range(len(allMsccList)):
                        # If 5G and not term/event and returned MSCC data not right length, then skip here
                        if interface.lower() == '5g':
                                if request == 'term' or eventFlag: continue
                                elif ('multipleUnitInformation' not in diamDct or len(diamDct['multipleUnitInformation']) <= i):
                                        print('WARNING: ' + interface.lower() + ' response did not contain ' + str(i+1) + ' MSCC items.')
                                        if 'multipleUnitInformation' in diamDct: print('  It contains ' + str(len(diamDct['multipleUnitInformation'])) + ' items')
                                        continue
                        
                        # Set Mscc String (or not) based on noMscc .
                        # **FIXME:  Need enhancements for multi-MSCC support.
                        if noMscc: msccPtr = ''
                        else:      msccPtr = 'Mscc' + str(i) + '->'
                        
                        # Get the event key.  May not be returned if not sent.
                        if noMscc or msccPtr+str(eventKey) not in diamDct:
                                # Pick something...
                                eventId = ratingGroup
                        else:   
                                # 5G in a separate location
                                try:    eventId = diamDct[msccPtr+eventKey].strip()
                                except: eventId = diamDct['multipleUnitInformation'][i]['ratingGroup']
                        
                        # Need to loop through the MSCC list, as the returned items may not be in the same order as what we stored.
                        eventKeyFound = False
                        for j in range(len(allMsccList)):
                                # Get the entry
                                (ratingGroup, requested, used, reportingReason, msccServiceId, eventPass) = allMsccList[j]
                                
                                # If keys match, then break
                                if eventKey == 'Rating-Group' and ratingGroup == eventId:
                                        eventKeyFound = True
                                        break
                                
                                if eventKey == 'Service-Identifier' and msccServiceId == eventId:
                                        eventKeyFound = True
                                        break
                        
                        # Sanity check that we found something
                        if (not createMsccFlag) and eventKey and (not eventKeyFound) and request != 'event':
                                print('ERROR: returned message has ' + str(eventKey) + ' set to ' + str(eventId) + ', but not found in MSCC data: ' + str(allMsccList))
                                sys.exit('Exiting Due To Errors')
#                       print 'Processing rating group ' + str(ratingGroup) + ' response, eventPass = ' + eventPass
                        trackId = ratingGroup
                        
                        # If expected key present, then use for granted amount, else assume nothing granted
#                       print 'Looking at key: ' + key
                        if msccPtr+'Granted-Service-Unit->'+key in diamDct:
                                grantedAmount = diamDct[msccPtr+'Granted-Service-Unit->'+key].strip()
                        elif interface.lower() == '5g' and 'grantedUnit' in diamDct['multipleUnitInformation'][i]:
                                # Still may not receive anything back...
                                try:    grantedAmount = diamDct['multipleUnitInformation'][i]['grantedUnit'][fivegkey]
                                except: grantedAmount = '0'
                        else:
                                grantedAmount = '0'
                        
                        # See if FUI was returned
                        if msccPtr+'Final-Unit-Indication->Final-Unit-Action' in diamDct:
                                fuiFlag = True
                        elif interface.lower() == '5g' and 'FinalUnitIndication' in diamDct['multipleUnitInformation'][i] and 'finalUnitAction' in diamDct['multipleUnitInformation'][i]['FinalUnitIndication']:
                                fuiFlag = True
                        else:   fuiFlag = False
                        
                        # May want to play with other parameters, so capture those as well
                        if msccPtr+'Volume-Quota-Threshold' in diamDct:
                                vqt = diamDct[msccPtr+'Volume-Quota-Threshold'].strip()
                        elif interface.lower() == '5g' and 'Volume-Quota-Threshold' in diamDct['multipleUnitInformation'][i]:
                                vqt = diamDct['multipleUnitInformation'][i]['Volume-Quota-Threshold'].strip()
                        else:
                                vqt = '0'
                
                        # If no validity time returned, then need to assume something
                        if msccPtr+'Validity-Time' in diamDct:
                                validityTime = diamDct[msccPtr+'Validity-Time'].strip()
                        elif interface.lower() == '5g' and 'Validity-Time' in diamDct['multipleUnitInformation'][i]:
                                validityTime = diamDct['multipleUnitInformation'][i]['Validity-Time'].strip()
                        else:   validityTime = 3600
                        
                        # If VQT is zero, then print.
                        # Actually, only care if AQM not enabled, so check for that (as we already have this data for AQM).
                        if lclDCT['verbose'].lower() not in ['low', 'none']:
                         if vqt == '0' and aqmFunc == '0' and diamDebug: print('VQT is zero; granted amount = ' + str(grantedAmount))
                        
                        # Check result codes
                        if interface.lower() == '5g':
                                try:
                                        if diamDct['multipleUnitInformation'][i]['resultCode'].lower() == 'success': diamResult = 0
                                        else: diamResult = 1
                                except: diamResult = 0
                        else: diamResult = diameter_utils.checkDiameterResultCodes(diamDct, index = i)
        
                        # Exit if received an unexpected result.
                        # Note: always check diameter results (regardless of noChecks status).
                        errorFlag = diameter_utils.exitOnFailureDiameterResultCodes(diamResult, eventPass=eventPass,
                                        grantedAmount=int(grantedAmount), fuiFlag=fuiFlag, continuePastError=continuePastError)
                
                        # If eventFlag, stuff to do
                        if eventFlag:
                                # Change request back to "term"
                                request ='term'
                                
                                # Make sure refund ID was returned
                                if msccPtr+'Refund-Information' in diamDct:
                                        RefundData[str(lclSessionId)] = diamDct[msccPtr+'Refund-Information']
                                        if diamDebug: print('Saved refund information for session ' + str(lclSessionId))
                                elif 'Refund-Information' in diamDct:
                                        # Not really standards supported but a customer wanted this...
                                        RefundData[str(lclSessionId)] = diamDct['Refund-Information']
                                        if diamDebug: print('Saved non-MSCC refund information for session ' + str(lclSessionId))
                                
                                # Should flag an issue if debit event and no refund, but then need to make sure RSU was used instead of GSU...
                                # Encountered customers that don't want refund returned (so not an error).
#                               elif requestAction == '0' and RSU used instead of GSU (wou;ld need to add this logic):
#                                       # Error if no refund information provided 
#                                       print 'WARNING: expecting refund information returned from event processing, but none rceived'
#                                       sys.exit('Exiting with errors')
                                        
                        # Want to store policy data.  Overloading the session table to handle this (using requested parameter - OK, kind of a hack...).
                        if interface.lower() == 'sy' and request != 'term':
                                # Set requested parameter to policy data.  Data read above
                                requested = policyData
                        
                                # Validate response if input specified.
                                if lclDCT['policyStatus']:
                                        # Validate
                                        retVal = CMDDIAMSY.validateSyMessage(diamDct, 'None', lclDCT)
                                        
                                        # Check response
                                        if not retVal: sys.exit('Failed Sy validation.  Exiting')
                        
                        # Should we track this event?
                        if (not eventFlag) and eventPass and interface.lower() != '5g' and (ratingGroup or (not ratingGroupRequiredForSession)):
                                # Calculate granted velocity
                                if validityTime: velocity = float(float(grantedAmount.strip()) / float(validityTime))
                                else:            velocity = 0.0
                                
                                # Hmmm.  Don't recall the logic for this.  The time of the event is always startTime.
                                # Issus when a session is run from separate commands, which means index is always 0, which means we never record the actual event time.
                                # For now use startTime always
#                               if index == 0:  timeToReport = sessionStartTime
#                               else:           timeToReport = startTime
                                timeToReport = startTime
                        
                                # OK, want to update things.  If this is a reporting reason that means the sub-session is done,
                                # then need to set the request type as if it was a term.
                                # 1 = QHT, 2 = Final, 3 = quota exhausted.  Not sure why I originally had all three meaning the session was done...
                                #if reportingReason == '1' or reportingReason == '2' or reportingReason == '3':
                                if reportingReason == '2': requestToUse = 'term'
                                else:                      requestToUse = request
                                
                                # If dealing with currency then need to check if an exponent was returned.
                                if currencyFlag['req']:
                                        key = 'Unit-Value->CC-Money->Exponent'
                                        if msccPtr+'Granted-Service-Unit->'+key in diamDct:
                                                exponent = diamDct[msccPtr+'Granted-Service-Unit->'+key]
                                                if lclDCT['verbose'].lower() not in ['low', 'none']:
                                                 if diamDebug: print('Unit/exponent = ' + grantedAmount + '/' + exponent)
                                                grantedAmount = str(int(grantedAmount) * math.pow(10,int(exponent)))
                                        
                                        # Save currency sign so we know to use currency in the usage
                                        grantedAmount = '$' + grantedAmount
                                
                                #elif not noChecks:
                                else:
                                        # Saving currency just not working well...
                                        
                                        # Get single entry for used amount
                                        usedValue = used
                                        while type(usedValue) is list: usedValue = usedValue[0]
                                        
                                        # Debug
                                        if lclDCT['verbose'].lower() not in ['low', 'none']:
                                         if (request == 'initial') and mark and diamDebug: print('Tracking ' + interface + ' session ' + str(lclSessionId) + ' with mark ' + mark)
                                
                                        # Update context
                                        if diamDebug: print('Tracking this event')
                                        TRACK.updateSessionTrackingData(
                                                device, accessNumber, requestToUse, lclSessionId, trackId, timeToReport, 
                                                requested, usedValue, grantedAmount, mark, interface.lower(),
                                                vqt=vqt, validityTime=validityTime, timeBuffer=timeBuffer,   
                                                usedVelocity=modVelocity, grantedVelocity=velocity, eventDelta=int(timeDelta),
                                                aqmFunction=aqmFunc, totalToUse=ttu, index=index+1, SkipFlag=SkipFlag,
                                                sessionOffset=sessionOffset, verbose=verbose, diamDebug=diamDebug)
                                
                        # Skipping session updates
                        elif noMscc and diamDebug: print('Skipping Diameter event session ' + str(lclSessionId) + ' updates due to the noMscc flag set')
        
                        # Skipping session updates
#                       elif noChecks: print 'Skipping Diameter event session ' + str(lclSessionId) + ' updates due to the noChecks flag set'
                        
                        # Skipping session updates
                        elif ((not ratingGroup) or (not int(ratingGroup)) or (not ratingGroupRequiredForSession)) and diamDebug: print('Skipping Diameter event session ' + str(lclSessionId) + ' updates due to no ratingGroup entered')
                        
                        # Skipping events
                        elif eventFlag and diamDebug: print('Skipping Diameter event session ' + str(lclSessionId) + ' updates due to this being an event')
                        
                        # Skipping expected failures
                        elif not eventPass and diamDebug: print('Skipping Diameter event session ' + str(lclSessionId) + ' updates due to expected failure')
                        
                        # Skipping session updates
                        elif diamDebug: print('Skipping Diameter event session ' + str(lclSessionId) + ' updates due to ???')
                        
                        # Checking for granted units is key on all non-Term that are expected to pass.
                        # Skip for currency request/grant, as not sure this makes sense (and it's not working)
                        if (request != 'term') and eventPass and not currencyFlag['req']:
                         # See if anything granted
                         if int(grantedAmount) != 0 or createMsccFlag:
                                # The current reserved amount needs to increment by the granted amount
                                currentResv += int(grantedAmount)
#                               print 'currentResv incremented by ' + str(grantedAmount) + ', now equal ' + str(currentResv)
                                
                                # Want separate output for AQM (so easy to grab)
                                if aqmFunc != '0':
                                        # This will be used to graph the session AQM parameters
                                        midString='Granted = velocity * elapsed time:'
                                        format = "Session %-10s '%-7s': %36s %10s = %10.2f * %5s, VQT = %10s\n"
                                        sys.stdout.write(format % (str(lclSessionId), request, midString, str(grantedAmount).strip(), velocity, str(validityTime), str(vqt)))
                                else:
                                        if diamDebug:
                                         print('Diameter session ' + str(lclSessionId) + ' ' + request + ' response: Granted amount and validity time: ' + str(grantedAmount).strip() + ', ' + str(validityTime))
                        
                                # Want to queue up the next event for this device (as it's not yet done)
                                # entries are: device, accessNumber, time delta, session ID, rating group
                                if aqmFunc == '0':
                                        if 'startTime' in lclDCT and lclDCT['startTime'] != '':
                                                # Get time of next event
                                                nextStartTime = CSVID.getCommandLineTime('startTime', lclDCT['startTime'], startTime, DATA.timeSepChar)
                                        
                                                # Get time delta from start of session
                                                #print 'Post Grant.  sessionStartTime/nextStartTime = ' + str(sessionStartTime) + '/' + str(nextStartTime)
                                                timeDelta = MDCTIME.timeDelta(sessionStartTime, nextStartTime)
                                        else:   timeDelta = 0
                                elif not noChecks:
                                        # Get delta to start of next command
                                        timeDelta = AQM.aqmLookAhead(lclSessionId, ratingGroup, aqmFunc, requestType, 
                                                aqmMaxVelocity, index+1, ttu, maxToUse, reportingReason, request, requested, SkipFlag, sessionOffset, currentResv)

                                        # Get this absolute time
                                        nextStartTime = MDCTIME.getTime(timeDelta, startTime=startTime, tz=subTimeZone)
                                        
                                        # Get time delta from start of session
                                        timeDeltaa = timeDelta
                                        timeDelta = MDCTIME.timeDelta(sessionStartTime, nextStartTime)
                                        
                                        # Sanity check
                                        if request != 'term' and timeDeltaa > timeDelta:
                                                # Having issues with timeDelta of 0, so allow for 0.1 and 0 to be the values and change delta to be 0.1.
                                                if timeDeltaa == 0.1 and timeDelta == 0: timeDelta = timeDeltaa
                                                else:
                                                        print('Hmmm  timeDeltaa = ' + str(timeDeltaa) + ', while timeDelta = ' + str(timeDelta))
                                                        print('sessionStartTime = ' + str(sessionStartTime) + ', nextStartTime = ' + str(nextStartTime) + ', startTime = ' + str(startTime))
                                                        sys.exit('Exiting with errors')

                                else:
                                        print('WARNING: don\'t yet support aqmFunc with no checks...  Will requeue same event')

                                # Add event iff we're not doing single messages to multiple objects
                                if not (len(deviceIdToSend) == 1 and requestType != 'session'):
                                 if not (len(deviceIdToSend) > 1 and requestType != 'session') and not SkipFlag and not interface.lower().startswith('5g'):
                                        # If we're working on real-time, then need to add absolute delay and validity time to get wall clock
                                        if aqmRealTimeFlag: timeDelta = int(validityTime) + int(absoluteDelay)
                                        nextEvents.append((device, accessNumber, int(timeDelta), lclSessionId, ratingGroup, msccServiceId))
                                        #print('Queued event for device ' + str(accessNumber) + ' to be run at time ' + str(timeDelta) + '.  Current absolute delay is ' + str(absoluteDelay))
#                                print 'Queuing another event.  Queue length is ' + str(len(nextEvents))
                         else:
                                # Nothing returned for granted amount.  May be OK.
                                # Check for non-CCR commands (nothing granted on non-Gy)
                                if interface.lower() != 'gy': 
                                        if diamDebug: print('No granted amount due to command not a gy interface (' + interface.lower() + ').')
                                
                                # If no rating group passed in
                                elif not (ratingGroup and int(ratingGroup)):
                                        if diamDebug: print('Nothing granted because no ratingGroup value passed in and it\'s required for session management.')
                                
                                # Check reporting reason
                                # Data on reporting reason (FYI from https://developer.opencloud.com/devportal/devportal/tools/diameter-simulators/diameter-connectivity-pack/2.0/docs/api/diameter-ratype/constant-values.html#org.jainslee.resources.diameter.ro.types.ReportingReason._QUOTA_EXHAUSTED):
                                
                                # Nothing expected to be granted
                                elif noMscc:
                                        if diamDebug: print('No granted amount due to noMscc flag set')
                                
                                # QHT reason.  Nothing expected.
                                elif reportingReason == DATA.reportingReasonMapping['qht']:
                                        if diamDebug: print('No granted amount due to reporting reason set to QHT reporting reason (' + reportingReason + ')')
                                
                                # QHT or FINAL reason.  Nothing expected.
                                elif reportingReason == DATA.reportingReasonMapping['final']:
                                        if diamDebug: print('No granted amount due to reporting reason set to FINAL reporting reason (' + reportingReason + ')')
                        
                                # Quota Exhausted reason.  Nothing expected.
                                elif reportingReason == DATA.reportingReasonMapping['quota']:
                                        if diamDebug: print('No granted amount due to reporting reason set to quota exhausted reporting reason (' + reportingReason + ')')
                                
                                # Check totalToUse feature
                                elif SkipFlag:
                                        if diamDebug: print('No granted amount due to nothing being requested as part of totalToUse feature.')
                            
                                # See if anything requested.  TRICKY: pricing may have auto request enabled...
                                elif not requested:
                                        if diamDebug: print('No granted amount due to nothing being requested.')
                                
                                # See if requestAction is suh that nothing will be granted.
                                elif requestAction != '0':
                                        if diamDebug: print('requestAction is setup so no granted amount will be returned (' + str(requestAction) + ').')
                                
                                # Not good...
                                else:
                                        # Don't hit them with multiple error messages if already in a failed mode.
                                        if not errorFlag:
                                                print('ERROR:  No granted units returned on the last request.')
                                                errorFlag=True
                                
                        # Check if errors encountered
                        if errorFlag:
                                if continuePastError:
                                        if diamDebug: print('Continuing with the test file as continuePastError flag is True')
                                        break
                                else:
                                        # Exit if we encountered an error
                                        sys.exit('xxxExiting due to error encountered')
                        
                # If the request was not for a session and we're not using the totalToUse feature, then we want to bump the local session ID
                if requestType != 'session' and ttu != -1: lclSessionId = str(int(lclSessionId) + 1)
                
                # If not the last iteration and verbose and trace option was specified, then run trace command (output goes to std out).
                # Only need to do this for a Gy command (others don't change the object).
                if i < len(reqAmount) and verbose.lower() == 'full' and interface.lower() == 'gy':
                        PRIM.printToScreen(saveFunc, queryValue, queryType, lclDCT, startTime)

                '''
                # Now done as part of generic saveMDC logic
                # If diffOnly set and verbose not shut off and last item in the command, then do a diff
                elif lclDCT['verbose'].lower() not in ['none', 'no', 'low'] and diffOnly and i == len(reqAmount):
                        if   saveFunc == 'saveMDC':             MISC.CmdMisc_subdiffdata(lclDCT, options, line)
                        elif saveFunc == 'saveDeviceMDC':       MISC.CmdMisc_devdiffdata(lclDCT, options, line)
                        else:                                   MISC.CmdMisc_groupdiffdata(lclDCT, options, line)
                '''
                
                # See if we should pause between commands
                QAUTILS.pauseCheck(pauseFlag)
                
         # If we're supposed to save data, then do so here
         if saveData: MISC.CmdMisc_saveData(lclDCT, interface, None)
         
         # Bump overall timer, so it's used in all subsequent commands
         lclDCT['lclStartTime'] = startTime
         
         # If not a usage command then return nothing
         if interface.lower() not in ['gy', '5g', '5gsy']: 
                return (None, None)
         else:  return (queryType, queryValue)

