#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:15
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:35:57
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:34:44

# import system primitives

# from builtins import str
# from builtins import range
from future import standard_library
standard_library.install_aliases()
# from builtins import str
# from builtins import range
import sys, copy, time, traceback, os
import optparse
import subprocess
#import configparser
from queue import Queue
import threading
import qa_utils as QAUTILS

NUM_THREADS=10
threadFlag = False

# Global Data
fqdnSeparator = ':'
createConfigSeparator = ';'
createConfigQuestion = '?'
bashCommandSeparator = ';'
globalProcessToKill = 'mdc_gateway'

# Signals whether queue initialization has taken place
q = None

# Data read from create_config.info
engineIpData = {}

# This holds the SNMP queried data
ClusterMemberData = {}

# Define target data
targetData = {}
_type = 'custom'
targetData[_type] = {}
targetData[_type]['targetDir'] = '/home/mtx/' + _type
targetData[_type]['targetScript'] = 'configure_engine.py'
targetData[_type]['sourceFileExt'] = 'cust.tgz'
targetData[_type]['mgmtOnly'] = True

_type = 'checkpoint'
targetData[_type] = {}
targetData[_type]['targetDir'] = '/home/mtx/' + _type
targetData[_type]['targetScript'] = None
targetData[_type]['sourceFileExt'] = 'chkpt.tgz'
targetData[_type]['mgmtOnly'] = True

_type = 'rpm'
targetData[_type] = {}
targetData[_type]['targetDir'] = '/home/mtx/' + _type
targetData[_type]['targetScript'] = './rpm_apply'
targetData[_type]['sourceFileExt'] = 'rpm'
targetData[_type]['mgmtOnly'] = False

_type = 'pricing'
targetData[_type] = {}
targetData[_type]['targetDir'] = '/home/mtx/' + _type
targetData[_type]['targetScript'] = 'load_pricing.py'
targetData[_type]['sourceFileExt'] = 'xml'
targetData[_type]['mgmtOnly'] = True

# SNMP query IDs, and their starting strings (that are removed from dictionary entries).
# NOTE:  Chicken and egg here.  A couple of these are needed at the start.  The rest are
# initialized by the SNMP init function.
# The command used to generate the list of objects that can be queried is:
# grep "::= { " matrixx_mib.txt | grep -v IDENTIFIER | cut -f2 -d"{" | cut -f1 -d"}" | cut -f2 -d" " | sort -u | 
# while read query; do echo "Running query $query"; snmpwalk -Os -v 2c -c public -OQ 10.10.115.185:4700 MATRIXX-MIB::$query; echo "Done with query $query"; done > _z
snmpQuery = {}
snmpQuery['sysPeerClusterEntry'] = {}
snmpQuery['sysPeerClusterEntry']['string'] = 'sysPeerCluster'
snmpQuery['sysPeerClusterTable'] = copy.deepcopy(snmpQuery['sysPeerClusterEntry'])

snmpQuery['sysClusterMemberEntry'] = {}
snmpQuery['sysClusterMemberEntry']['string'] = 'sysClusterMember'
snmpQuery['sysClusterMemberTable'] = copy.deepcopy(snmpQuery['sysClusterMemberEntry'])
        
#===============================================================================
# Setup thread for processing the request
class processingThread(threading.Thread):
    def __init__(self,threadNum,queue):
        threading.Thread.__init__(self)
        self.threadNum=threadNum
        self.input_queue=queue

    def run(self):
        count = 0
        currentObj = None

        # Loop
        while True:

          # Get a request from the queue
          item=self.input_queue.get(block=True)
#          print 'Thread %d retrieved from queue %s'%(self.threadNum,str(item))

          # If None, then there will be nothing more and we should exit
          if item is None:
            print('Thread ' + str(self.threadNum) + ' exiting after processing ' + str(count) + ' records')
            return

          # Extract the items that were put
          area, fqdn, sourceData, targetScript, targetDir, sourceDataFileExt, apply = item
          print('Thread ' + str(self.threadNum) + ' processing area ' + area + ' for engine ' + fqdn)
          
          # Exec the proper process function
          retCode = sendToEngineBladeWork(area, fqdn, sourceData, targetScript, targetDir, sourceDataFileExt, apply)
          
          # If failed, then???
          if not retCode:
                print('Thread ' +  str(self.threadNum) + ' detected a command failed.  Exiting')
                sys.exit('Exiting due to errors')
        
          # Bump count of items processed
          count += 1
          
#==================================================================
def runCmd(cmd):
        # filter some prints out
        if not ('snmpwalk' in cmd or \
                'grep'     in cmd or \
                'echo'     in cmd or \
                'ifconfig' in cmd): print('runCmd command: ' + cmd)
        else: print('runCmd command: ' + cmd)
        
##      if not cmd.startswith('snmpwalk'): return 'Not Run'
        
        # Standard stuff...
        p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        out = p.stdout.read().strip()
        return out  #This is the stdout from the shell command
#       return call(cmd, shell=True)

#==================================================================
def parseCreateConfig():
        global engineIpData
        global snmpQuery
        
        # May call this within a test (i.e. if changing configuration of an engine).
        # Reset global so it's rebuilt.
        engineIpData = {}
        
        # Point to create_config.info file
        file = os.path.expandvars(os.getenv('MTX_CUSTOM_DIR', '/opt/mtx/custom')) + '/create_config.info'

        # Grep physical blades
        cmd = 'grep PhysicalBlade ' + file
        physBladeInfo = runCmd(cmd)
        physBladeInfo = physBladeInfo.decode('utf-8')
        physBladeInfo = physBladeInfo.split("\n")

        # Get the mappings
        physInfo = {}
        for line in physBladeInfo:
                # Separate into fields
                fields = line.split(fqdnSeparator)

                # Fields are site, rack, blade enclosure, IP address
                site = fields[0].split(' ')[1]
                rack = fields[1].split(' ')[1]
                be   = fields[2].split(' ')[1]
                blade= fields[3].split(' ')[1]
                ipAddr = fields[4].split(createConfigQuestion)[1]

                # Store into dictionary
                physInfo[site+fqdnSeparator+rack+fqdnSeparator+be+fqdnSeparator+blade] = ipAddr

        # Get the number of engines defined
        cmd = 'grep "What are your engine IDs" ' + file
        engineList = runCmd(cmd).split(createConfigQuestion)[1].split(createConfigSeparator)

        # Process each engine
        for engine in engineList:
                # Get the cluster IDs
                cmd = 'grep "Engine ' + str(engine) + ':What are your cluster IDs" ' + file
                clusterList = runCmd(cmd).split(createConfigQuestion)[1].split(createConfigSeparator)

                # Process each cluster
                for cluster in clusterList:
                        # Get the blade enclosure
                        cmd = 'grep "Engine ' + str(engine) + ':Cluster ' + str(cluster) + ':What is the fully-qualified blade enclosure ID for this cluster" ' + file
                        be = runCmd(cmd).split(createConfigQuestion)[1]

                        # Now get the logical blade IDs
                        cmd = 'grep "Engine ' + str(engine) + ':Cluster ' + str(cluster) + ':What are your logical blade IDs" ' + file
                        logicalList = runCmd(cmd).split(createConfigQuestion)[1].split(createConfigSeparator)

                        # Process each logical blade
                        for logical in logicalList:
                                # Get the physical blade
                                cmd = 'grep "Engine ' + str(engine) + ':Cluster ' + str(cluster) + ':LogicalBlade ' + str(logical) + ':What is the physical blade ID" ' + file
                                physBlade = runCmd(cmd).split(createConfigQuestion)[1]

                                # Now can store the data
                                engineIpData[str(engine)+fqdnSeparator+str(cluster)+fqdnSeparator+str(logical)] = physInfo[be+fqdnSeparator+physBlade]
        
        # Debug output
        print('engineIpData Info: ' + str(engineIpData))

        # Get the port to use (from create_config.info'
        cmd = 'grep "SNMP:What port number do you want the SNMP Agent to listen on" ' + file
        snmpQuery['port'] = runCmd(cmd).split(createConfigQuestion)[1]

#==================================================================
def waitForBladeToRestore(fqdn, waitFlag=True):
        return waitForRestore(fqdn, waitFlag=waitFlag)

#==================================================================
def waitForEngineToRestore(fqdn, waitFlag=True):
        # Account for only engine passed in.  Assume cluster 1 in this case.
        # BladeId set to 0 to signals an engine wait.
        if fqdnSeparator not in fqdn: newFqdn = fqdn + fqdnSeparator + '1' + fqdnSeparator + '0'
        else:
                # Get pieces of fqdn
                engineId  = fqdn.split(fqdnSeparator)[0]
                clusterId = fqdn.split(fqdnSeparator)[1]
                
                # Need bladeId set to 0 to signal an engine wait
                newFqdn = engineId + fqdnSeparator + clusterId + fqdnSeparator + '0'
        
        return waitForRestore(newFqdn, waitFlag=waitFlag)
        
#==================================================================
def waitForRestore(fqdn, waitFlag=True):
        # Get pieces of fqdn
        engineId  = fqdn.split(fqdnSeparator)[0]
        clusterId = fqdn.split(fqdnSeparator)[1]
        bladeId   = fqdn.split(fqdnSeparator)[2]
        
        # Setup data depending on whether blade was passed in
        if bladeId == '0':
                bladeId = None
                bladeData = ''
        else:   bladeData = ' blade ' + bladeId
        
        # Set limits based on wait flag
        if waitFlag:
                if bladeId: totalTime  = int(QAUTILS.gatewaysConfig.get('HA','bladeRestoreTime'))
                else:       totalTime  = int(QAUTILS.gatewaysConfig.get('HA','engineRestoreTime'))
                sleepTime  = int(QAUTILS.gatewaysConfig.get('HA','timeBetweenRetries'))
        else:   
                totalTime = 1
                sleepTime = 2
        
        # Loop a maximum of times for operation to complete
        i = 0
        while i <= totalTime:
                # See if restore
                if bladeId:
                        # Get blade list
                        retData = getAllActiveBlades(fqdn, mustRead=True)
                
                        # If found, then break
                        if int(bladeId) in retData: break
                        
                else:
                        # Restoring engine
                        retData = getEnginePeerData(fqdn)

                        if engineId in retData and (retData[engineId]['HaState'].lower() in ['active', 'standby']): break

                # Bump loop counter
                i += sleepTime
                
                if i <= totalTime:
                        print('Sleep waiting for engine ' + engineId + bladeData + ' to restore.  Try ' + str(i) + ' out of ' + str(totalTime) + '.')
                
                        # Sleep 
                        time.sleep(sleepTime)
                
        # See if we didn't break
        if i > totalTime: 
                print('WARNING: Expected engine ' + str(engineId) + bladeData + ' to go inservice, but it did not')
                print(str(retData))
                #traceback.print_stack()
                return False
                
        # If processing a blade, then can exit now
        if bladeId: return True
        
        # If starting an engine, then may have started the engine while active (to restore all blades).  Need to check every blade state for inservice.
        for blade in range(1,10):
                newFqdn = engineId + fqdnSeparator + clusterId + fqdnSeparator + str(blade)
                if newFqdn in engineIpData:
                        if not waitForRestore(newFqdn): return False
                
        # If here, than all baldes are active
        return True
        
#==================================================================
def getBladeList(fqdn, state='active', func='processing', stateVal='equal', waitFlag=False):
    global ClusterMemberData

    retData = []
    
    # Can overload this function and pass in the desired dictionary.
    if type(fqdn) == type(dict()): lclDct = copy.deepcopy(fqdn)
    else:
        # Get engine ID, then get global cluster data
        engineId = fqdn.split(fqdnSeparator)[0]
        
        # Could get here for an unknown engine
        if engineId in ClusterMemberData: lclDct = copy.deepcopy(ClusterMemberData[engineId])
        else: lclDct = {}

    # Sanity check that the dictionary is not empty
#    print 'getBladeList, lclDct = ' + str(lclDct)
    if not lclDct: 
        print('WARNING: empty dictionary in getBladeList for fqdn ' + str(fqdn))
        if type(fqdn) != type(dict()): traceback.print_stack()
        return retData

    # Always checking the same entry
    statName = 'ServiceState'
    
    # If we're waiting for a state, then need config variables
    if waitFlag:
        totalTime = int(QAUTILS.gatewaysConfig.get('HA','bladeList'))
        sleepTime = int(QAUTILS.gatewaysConfig.get('HA','timeBetweenRetries'))
    else:
        totalTime = 1
        sleepTime = 2
        
    # Loop max number of times
    i = 0
    while i <= totalTime:
        # Get list of keys (sorted seems to be a good idea...)
        keyList = sorted(lclDct.keys())
    
        # Loop through each entry
        for key in keyList:
                # Get data
                item = lclDct[key]

                # Get list of blade types
                if statName in item:
#                       print 'Checking state/func/stateVal = ' + state + '/' + func + '/' + stateVal + ' against = ' + str(item)
                        # Skip if not matching the function
                        if func.lower() not in [item['ServiceRole'].lower(), 'any']: continue
                
                        # Skip if not matching the state
                        if state.lower() != 'any' and \
                                ((stateVal.lower() == 'not_equal' and item[statName].lower() == state) or
                                 (stateVal.lower() == 'equal'     and item[statName].lower() != state)): continue
                
                        # If here, then we have a match
                        retData.append(int(item['NodeId']))
                
        # If here and we found something, then exit right away.  Only loop if not yet found anything.
        if retData: return retData
        
        # Bump counter
        i += sleepTime
        
        # Sleep unless last loop
        if i <= totalTime:
                print('getBladeList: sleeping ' + str(sleepTime) + ' seconds: ' + str(i) + ' out of ' + str(totalTime))
                time.sleep(sleepTime)
        
                # If waiting, then we need to read data (or else we'll never find the change:-)
                lclDct = getEngineClusterData(fqdn)
        
    return retData

# =================== Selection primitives ====================
def convertEngineAndBladeStatusToFqdn(engineState='active', engineRelative = None, blade=None, bladeRelative='lowest'):
        global ClusterMemberData

        # Loop through until find the desired state.
        # Get list of keys (sorted seems to be a good idea...)
        keyList = sorted(ClusterMemberData['peer'].keys())

        # Loop through each entry
        found = False
        clusterId = '0'
        engineId = '0'
        
        for engine in keyList:
                if ClusterMemberData['peer'][engine]['HaState'].lower() == engineState.lower(): 
                        # Found one
                        found = True
                        
                        # If looking for engine relative data, then need to compare agaisnt the previously stored value
                        if engineRelative:
                                if engineId == '0':
                                        # First one - use data
                                        engineId = engine
                                        clusterId = ClusterMemberData['peer'][engine]['ClusterId'].lower()
                                        
                                elif (engineRelative == 'lowest'  and int(engine) < int(engineId)) or \
                                     (engineRelative == 'highest' and int(engine) > int(engineId)):
                                        # Update data to use this
                                        engineId = engine
                                        clusterId = ClusterMemberData['peer'][engine]['ClusterId'].lower()
                        else:
                                # Want the first one found
                                engineId = engine
                                clusterId = ClusterMemberData['peer'][engine]['ClusterId'].lower()
                                break

        # Check if found
        if not found:
                print('WARNING: did not find an engine in state ' + str(engineState) + '.  Peer data is:' + str(ClusterMemberData['peer']) + '.  Returning 0.')
                traceback.print_stack()
                return '0'
        
        # See if a blade type is desired
        if not blade:
                # return first blade in engine data
                for i in range(1,10):
                        fqdn = engineId + fqdnSeparator + clusterId + fqdnSeparator + str(i)
                        if fqdn in engineIpData: return fqdn
                
                # If here, then nothing found for this engine.  Weird...
                print('convertEngineAndBladeStatusToFqdn: did not find a blade in engineIpData for engine/cluster = ' + engineId + '/' + clusterId)
                traceback.print_stack()
                return '0'
                
        # Blade could be a number or a word
        if blade.isdigit(): retList = [blade]
        else:
                # OK, find the desired blade type
                cmd = 'retList = get' + blade.capitalize() + 'Blades(ClusterMemberData[engineId])'
                exec(cmd)
        
        # See if any returned
        if not retList:
                print('WARNING: did not find a blade in engine ' + str(engineId) + ' with service ' + str(blade) + '.  Peer data is:' + str(ClusterMemberData['peer']))
                traceback.print_stack()

                # Return invalid
                return '0'
        
        # Return the relative fqdn
        if bladeRelative.lower() == 'lowest':   return engineId + fqdnSeparator + clusterId + fqdnSeparator + str(retList[0])
        else:                                   return engineId + fqdnSeparator + clusterId + fqdnSeparator + str(retList[-1])
        
def getEngineIp(fqdn):
        global engineIpData
        
        # Expect fully qualified input
        if fqdnSeparator in str(fqdn): 
                # Sometimes come here with no blade (set to 0).  In those cases, set it to 1.
                engineId  = fqdn.split(fqdnSeparator)[0]
                clusterId = fqdn.split(fqdnSeparator)[1]
                bladeId   = fqdn.split(fqdnSeparator)[2]
                
                # Fix values
                if clusterId == '0': clusterId = '1'
                if bladeId   == '0': bladeId = '1'
                
                # Update FQDN
                updatedFqdn = engineId + fqdnSeparator + clusterId + fqdnSeparator + bladeId
                
                # Return data
                return engineIpData[updatedFqdn]
        else:
                # Error
                print('WARNING: getEngineIp requires a fully qualified input')
                traceback.print_stack()
                sys.exit('Exiting Early')

def getBladeHost(fqdn):
        global engineIpData
        
        # Process blade ID if input and fully qualified
        if fqdnSeparator in str(fqdn): return engineIpData[fqdn]
        else:
                # Error
                print('WARNING: getBladeHost requires a fully qualified input')
                traceback.print_stack()
                sys.exit('Exiting Early')
        
# =================== Engine Peer Data ====================
def getEnginePeerData(fqdn):
        # Can overload this function and pass in the desired dictionary.
        if type(fqdn) == type(dict()):  return fqdn
        
        return getAndProcessSnmpQuery('sysPeerClusterTable', fqdn)

# =================== Specific Engine Cluster Data ====================
def getEngineClusterData(fqdn):
        # Can overload this function and pass in the desired dictionary.
        if type(fqdn) == type(dict()): return fqdn
        
        return getAndProcessSnmpQuery('sysClusterMemberEntry', fqdn)

#================== Generic to-all and to-engine processing  ============================================
def extractTargetDirFiles(targetDir, fqdn):
        global engineIpData
        
        # Get IP address from global data
        ipAddr = engineIpData[fqdn]
        
        # Copy extract file to target directory
        cmd = 'scp /home/mtx/workspace/trunk/MTXQA/Common/extractScript ' + ipAddr + fqdnSeparator + targetDir
        runCmd(cmd)
        
        # Run the extra script
        cmd = 'cd ' + targetDir
        cmd += bashCommandSeparator + 'chmod +x extractScript'
        cmd += bashCommandSeparator + './extractScript'
        print('\n' + runSshCmd(fqdn,cmd) + '\n')
        
#==============================================================
def sendToAll(area, data, apply=True):
        global ClusterMemberData
        
        # Error if peer data not present
        if 'peer' not in ClusterMemberData: sys.exit('sendToAll: peer data not present in ClusterMemberData')
        
        # If doing custom work, then it has it's own "ToAll" function
        if area.lower() == 'custom' or area.lower() == 'pricing': 
                print('ERROR: sendToAll called with area set to custom or pricing.')
                traceback.print_stack()
                sys.exit('Exiting due to errors')
        
        # Execute for each defined engine.  
        for engine in list(ClusterMemberData['peer'].keys()): sendToEngine(area, engine, data, apply)
        
#==============================================================
def sendToEngine(area, fqdn, data, apply=True):
        global ClusterMemberData
        global targetData
        
        # Get the engine ID
        engineId = fqdn.split(fqdnSeparator)[0]
        clusterId = fqdn.split(fqdnSeparator)[1]
        
        # If doing custom work, then shouldn't get here
        if area.lower() == 'custom': sys.exit('ERROR: shouldn\'t call sendToEngine with a type of custom')
        
        # Update every blade
        for bladeId in ClusterMemberData[engineId]:
                # Build a local fqdn
                lclFqdn = engineId + fqdnSeparator + clusterId + fqdnSeparator + str(bladeId)
                
                # Send to the blade
                return sendToEngineBlade(area, lclFqdn, data, \
                        targetData[area.lower()]['targetScript'], \
                        targetData[area.lower()]['targetDir'], \
                        targetData[area.lower()]['sourceFileExt'], \
                        apply)
                
#==============================================================
def sendToEngineBlade(area, fqdn, sourceData, targetScript, targetDir, sourceDataFileExt, apply=True):
        global q
        
        # Queue this if queues are defined, else call function directly
        if q:
                q.put((area, fqdn, sourceData, targetScript, targetDir, sourceDataFileExt, apply))
                
                # Can only return success when queuing the event
                return True
        else: return sendToEngineBladeWork(area, fqdn, sourceData, targetScript, targetDir, sourceDataFileExt, apply)

#==============================================================
def sendToEngineBladeWork(area, fqdn, sourceData, targetScript, targetDir, sourceDataFileExt, apply=True):
        global engineIpData
        
        # Assume success if no validation
        retCode = True
        
        # Get the engine ID
        engineId  = fqdn.split(fqdnSeparator)[0]
        clusterId = fqdn.split(fqdnSeparator)[1]
        bladeId   = fqdn.split(fqdnSeparator)[2]
        
        # Get IP Address
        ipAddr = engineIpData[fqdn]
        
        # See if this is a file or a directory
        if os.path.isdir(sourceData):
                # Add in the file extension
                extraString = '/*' + sourceDataFileExt
        else:
                # Nothing extra needed
                extraString = ''
        
        # First make the directory on the target
        cmd = 'mkdir -p ' + targetDir
        
        # Empty the directory
        cmd += bashCommandSeparator + 'rm -rf ' + targetDir + '/*'
        print('\n' + runSshCmd(fqdn,cmd) + '\n')
        
        # Copy source files to target
        cmd = 'scp ' + sourceData + extraString + ' ' + ipAddr + fqdnSeparator + targetDir
        runCmd(cmd)
        
        # Extract target files that may be compressed
        extractTargetDirFiles(targetDir, fqdn)

        # Do any per-type special commands 
        cmd = area.lower() + 'ToEngineBladeWork(ipAddr, fqdn, sourceData, targetScript, targetDir, sourceDataFileExt, apply)'
        exec(cmd)

        # Execute command if one specified and we're allowed
        if apply and targetScript:
                # Always go to the target directory
                cmd = 'cd ' + targetDir 
                
                # If executing a local file, then chmod on it
                if targetScript[0] == '.': cmd += bashCommandSeparator + 'chmod +x ' + targetScript
                
                # Always execute the target script
                cmd += bashCommandSeparator + targetScript
                
                runOut = runSshCmd(fqdn,cmd)
                
                # Might as well check for the word ERROR...
                if 'ERROR' in runOut:
                        print('WARNING: found "ERROR" in the returned string.')
                        print('\n\n' + runOut + '\n\n')
        
                # Call command-specific validation function
                cmd = 'retCode = validate' + area.lower().capitalize() + '(engineId, bladeId, runOut, sourceData)'
                try:
                        exec(cmd)
                except:
                        print('Area ' + area.lower() + ' doesn\'t have a validation function')
                        print('\n\n' + runOut + '\n\n')
                        
        return retCode

#==============================================================
def verifyRpm(fqdn, rpmString):
        # Run the RPM query
        cmd = 'rpm -q matrixxsw-engine;rpm -q matrixxsw-proxy-server;rpm -q matrixxsw-seagull;rpm -q matrixxsw-activemq-connector'
        retData = runSshCmd(fqdn,cmd)
        
        # If the source data is in the response, then it worked.
        found = notFound = False
        for line in retData.split('\n'):
                # Skip if package not loaded
                if 'is not installed' in line: continue
                
                # See if the desired string is there
                if rpmString in retData: found = True
                else:                    notFound = True
        
        # If anything found, then success
        if found:
                print('RPM verify succeeded')
                if notFound: print('NOTE: not all packages match string ' + rpmString)
                return True
        elif notFound:
                print('RPM verify failed - checking for "' + rpmString + '"')
                print('\n\n' + retData + '\n\n')
                return False
        else:
                print('No MATRIXX packages installed.  Considering this a failure.')
                return False
        
#==============================================================
def validateRpm(fqdn, outData, sourceData):
        # If the source data was a directory, then can't (easily) validate via rpm query.
        # That's additional development...
        if not os.path.isfile(sourceData):
                print('RPM input was not a file.  Can\'t validate it via RPM queries')
                return True
        
        # Get/check the data against the RPM string
        return verifyRpm(fqdn, sourceData[:-4])

#==============================================================
def validatePricing(fqdn, outData, sourceData):
        # Check for successful response
        if 'SUCCEEDED' in outData:
                print('Price loading succeeded')
                return True
        else:
                print('Price loading failed')
                print('\n\n' + outData + '\n\n')
                return False
        
#==============================================================
def sendToEngineMgmtOnly(area, fqdn, sourceData, apply=True):
        global ClusterMemberData
        global targetData
        
        # Get the engine ID
        engineId = fqdn.split(fqdnSeparator)[0]
        clusterId = fqdn.split(fqdnSeparator)[1]
        
        # Find the management blade for this engine
        retData = getManagementBlades(fqdn)
        
        # If no active blade, then send to blade 1
        if not retData or retData[0] == '':
                print('WARNING: did not find an active management blade for engine ' + engineId + '.  Will send to blade 1.')
                print(str(ClusterMemberData))
                bladeId = '1'
        else:   bladeId = retData[0]
        
        # Rebuild fqdn with the right blade number
        fqdn = engineId + fqdnSeparator + clusterId + fqdnSeparator + str(bladeId)
        
        # Send to engine+blade
        # custom needs additional data in the target script.  Should parameterize this...
        if area.lower() == 'custom': targetScript = targetData[area.lower()]['targetScript'] + ' -e ' + engineId
        if area.lower() == 'pricing':
                # Need to specify a file here
                if os.path.isdir(sourceData):
                        print('ERROR: Pricing requires a file to be specified')
                        sys.exit('Exiting due to errors')
                
                # Extract the file name.  Not sure -1 work is only 
                fileName = sourceData.split('/')[-1]
                
                # Add file name to target script
                targetScript = targetData[area.lower()]['targetScript'] + ' -f ' + fileName
        else:   targetScript = targetData[area.lower()]['targetScript']
        
        return sendToEngineBlade(area, fqdn, sourceData, \
                targetScript, \
                targetData[area.lower()]['targetDir'], \
                targetData[area.lower()]['sourceFileExt'], \
                apply)
        
#==============================================================
def processMgmtOnly(area, sourceData, apply=True, fqdn=None):
        global ClusterMemberData
        
        # Init to nothing done
        doneFlag = False
        
        # Error if peer data not present
        if 'peer' not in ClusterMemberData: sys.exit('processMgmtOnly: peer data not present in ClusterMemberData')
        
        # Execute for specified engine (or both if none specified) 
        for key in list(ClusterMemberData['peer'].keys()): 
                # Need an engine ID.  If specified, use it, else use the key
                if fqdn:
                        engineId  = fqdn.split(fqdnSeparator)[0]
                        clusterId = fqdn.split(fqdnSeparator)[1]
                        bladeId   = fqdn.split(fqdnSeparator)[2]
                else:
                        # No fqdn input.  Assume cluster 1, blade 1
                        engineId = key
                        clusterId = bladeId = '1'

                # Filter on engine
                if engineId != key: continue
                
                lclFqdn = key + fqdnSeparator + clusterId + fqdnSeparator + bladeId
                print(area + ': Sending to engine ' + lclFqdn)
                retCode = sendToEngineMgmtOnly(area, lclFqdn, sourceData, apply)
                
                # Check for errors
                if not retCode:
                        print('processMgmtOnly: failed send to engine call for fqdn ' + lclFqdn)
                        traceback.print_stack()
                        return False
                 
                # Set flag signaling something done
                doneFlag = True
        
        # If nothing done, then engine doesn't exist
        if not doneFlag:
                print('WARNING: engine ' + str(fqdn) + ' does not exist')
                traceback.print_stack()
                return False
        
        # If here, then all went well
        return True
        
#================== Pricing processing  ============================================
def pricingToEngineBladeWork(ipAddr, fqdn, sourceData, targetScript, targetDir, sourceDataFileExt, apply=True):
        return True
        
#================== Custom processing  ============================================
def customToEngineBladeWork(ipAddr, fqdn, sourceData, targetScript, targetDir, sourceDataFileExt, apply=True):
        # copy extra and info files to custom directory
        cmd = 'cd ' + targetDir + bashCommandSeparator + 'cp *info *extra ' + os.path.expandvars(os.getenv('MTX_CUSTOM_DIR', '/opt/mtx/custom'))
        
        # Run the commands
        print('\n' + runSshCmd(fqdn,cmd) + '\n')
        
        return True
        
#================== RPM processing  ============================================
def rpmToEngineBladeWork(ipAddr, fqdn, sourceData, targetScript, targetDir, sourceDataFileExt, apply=True):
        global engineIpData
        
        # Get IP Address
        ipAddr = engineIpData[fqdn]
        
        # copy rpm apply script to target
        cmd = 'scp /home/mtx/workspace/trunk/MTXQA/Common/' + targetScript + ' ' + ipAddr + fqdnSeparator + targetDir
        runCmd(cmd)
        
        return True
        
#================== Checkpoint processing  ============================================
def checkpointToEngineBladeWork(ipAddr, fqdn, sourceData, targetScript, targetDir, sourceDataFileExt, apply=True):
        global ClusterMemberData
        
##      destDir = os.path.expandvars(os.getenv('MTX_SHARED_DIR', '/mnt/mtx/shared')) + '/checkpoints'
        destDir = ClusterMemberData['shared_dir']
        
        # Mount shared dir
        cmd = 'remount_shared_dir.py -c -w -m ' + ClusterMemberData['shared_dir']
        
        # Go to the shared dir
        cmd += bashCommandSeparator + 'cd ' + destDir
        
        # Remove all existing checkpoints, TX logs, etc.
        # Can't seem to get a "find" command through SSH (evaluates it first), so be specific about directories.
        for dir in ['event_files', 'checkpoints', 'staging', 'txnlogs/*']:
                cmd += bashCommandSeparator + 'rm -rf ' + dir + '/*'
        
        # destDir is now the checkpoint directory
        destDir += '/checkpoints'
        
        # Go to the target dir
        cmd += bashCommandSeparator + 'cd ' + targetDir
        
        # Make the checkpoint directory
        #cmd += bashCommandSeparator + 'mkdir ' + destDir
        
        # Copy directory to the destination location
        cmd += bashCommandSeparator + 'cp -R mtx_ckpt_* ' + destDir
        
        # Leave target dir
        cmd += bashCommandSeparator + 'cd '
        
        # Unmount shared dir
        cmd += bashCommandSeparator + 'remount_shared_dir.py -u -m ' + ClusterMemberData['shared_dir']
        
        # Run the commands
        print('\n' + runSshCmd(fqdn,cmd) + '\n')
        
        return True
        
#================== SNMP processing  ============================================
def processSnmpQuery(query, queryOut):
        nodeData = {}
        
        # Check for nothing back
        if not queryOut or (len(queryOut) == 1 and queryOut[0] == ''): return nodeData
        
        # Debug output
        #print 'Engine ' + engineId + ' queryOut = '+ str(queryOut)
        
        # All queries should follow the common processing.  
        return processSnmpQueryPerEntryInfo(query, queryOut)
        # Scripts for now are not handling clusters well, so the cluster table query ignores cluster.
        # Will take a full day of scrubbing this file to supoprt clusters properly...
        if query in ['sysPeerClusterTable']:
                return processSnmpQueryPerBladeInfo(query, queryOut)
        else:   return processSnmpQueryPerEntryInfo(query, queryOut)

#==============================================================
def processSnmpQueryPerEntryInfo(query, queryOut):
        global snmpQuery
        
        nodeData = {}
        
        # Get string that we should remove from start of query items
        try:
                queryReturnString = snmpQuery[query]['string']
        except:
                print('ERROR: query ' + str(query) + ' not defined in global table snmpQuery')
                traceback.print_stack()
                sys.exit('Exit on error')
        
        # Make sure query string is a list, as some entries are and sone are not
        if type(queryReturnString) is not list: queryReturnString = [queryReturnString]
        
        # Process every returned value
        #print 'processSnmpQueryPerEntryInfo: query ' + str(query) + ' returned ' + str(queryOut)
        for j in range(len(queryOut)):
                # Separate out key and value
                data = queryOut[j].split('=')
                key = data[0].strip()
                value = data[1].strip()
                
                # See if we got back a complete set of data
                keySplit = key.split('.')
                if len(keySplit) < 2:
                        print('WARNING: returned query ' + query + ' data did not return valid info: ' + str(queryOut[j]) + '.  Stopping at record ' + str(j))
                        return nodeData
        
                # Now get the entry from the Key.
                key    = keySplit[0].strip()
                entry1 = keySplit[1].strip()
                
                # May have a third value in the key
                try:
                        entry2 = keySplit[2].strip()
                except:
                        entry2 = None
                
                # Minor hack.  SOme queries need to ignore cluster data, as the APIs are not really cluster-proof at this time.
                if query in ['sysPeerClusterTable']: entry2 = None
                
                # Remove common key string from the start
                for startString in queryReturnString:
                        if key.startswith(startString): key = key[len(startString):]
                        break;
                        
                # Add to returned data
                if entry1 not in nodeData: nodeData[entry1] = {}
                
                # May need additional dimensions
                if not entry2:
                        # Entry items will have a stop value.  Don't want that, so check for data already populated.
                        if key not in nodeData[entry1]: nodeData[entry1][key] = value
                else:
                        # Same game for entry 2 and value as per above
                        if entry2 not in nodeData[entry1]: nodeData[entry1][entry2] = {}
                        if key not in nodeData[entry1][entry2]: nodeData[entry1][entry2][key] = value
                        
#       print 'Query ' + query + ' translated to: ' + str(nodeData)
        return nodeData

#==============================================================
def processSnmpQueryPerBladeInfo(query, queryOut):
        global snmpQuery
        
        nodeData = {}
        
        # Get string that we should remove from start of query items
        try:
                queryReturnString = snmpQuery[query]['string']
        except:
                print('ERROR: query ' + str(query) + ' not defined in global table snmpQuery')
                traceback.print_stack()
                sys.exit('Exit on error')
        
        # Make sure query string is a list, as some entries are and sone are not
        if type(queryReturnString) is not list: queryReturnString = [queryReturnString]
        
        # Process every returned value
        #print 'processSnmpQueryPerBladeInfo: query ' + str(query) + ' returned ' + str(queryOut)
        for j in range(len(queryOut)):
                # Separate out key and value
                data = queryOut[j].split('=')
                key = data[0].strip()
                value = data[1].strip()
                
                # See if we got back a complete set of data
                keySplit = key.split('.')
                if len(keySplit) < 2:
                        print('WARNING: returned query ' + query + ' data did not return valid info: ' + str(queryOut[j]) + '.  Stopping at record ' + str(j))
                        return nodeData
        
                # Now get the node ID from the Key.
                # Also remove common key string from the start (sysClusterMember).
                nodeId = key.split('.')[1]
                key = key.split('.')[0]
                
                # Remove common key string from the start
                for startString in queryReturnString:
                        if key.startswith(startString): key = key[len(startString):]
                        break;
                        
                # Add to returned data
                if nodeId not in nodeData: nodeData[nodeId] = {}
                nodeData[nodeId][key] = value

#       print 'Query ' + query + ' translated to: ' + str(nodeData)
        return nodeData

#==============================================================
def initSnmpData():
        global snmpQuery
        global ClusterMemberData
        global engineIpData

        snmpQuery['chrgMIBScalars'] = {}
        snmpQuery['chrgMIBScalars']['string'] = 'chrgNotification'
        snmpQuery['chrgMIBTables'] = copy.deepcopy(snmpQuery['chrgMIBScalars'])
        
        snmpQuery['chrgNotificationSendTryStatsEntry'] = {}
        snmpQuery['chrgNotificationSendTryStatsEntry']['string'] = 'chrgNotificationSendTryStats'
        snmpQuery['chrgNotificationSendTryStatsTable'] = copy.deepcopy(snmpQuery['chrgNotificationSendTryStatsEntry'])
        
        snmpQuery['diamMIBObjects'] = {}
        snmpQuery['diamMIBObjects']['string'] = 'diam'
        
        snmpQuery['diamPduStatsEntry'] = {}
        snmpQuery['diamPduStatsEntry']['string'] = 'diamPduStats'
        snmpQuery['diamPduStatsTable'] = copy.deepcopy(snmpQuery['diamPduStatsEntry'])
        
        snmpQuery['sysBufferPoolStatsEntry'] = {}
        snmpQuery['sysBufferPoolStatsEntry']['string'] = 'sysBufferPoolStats'
        snmpQuery['sysBufferPoolStatsTable'] = copy.deepcopy(snmpQuery['sysBufferPoolStatsEntry'])
        
        snmpQuery['sysMIBScalars'] = {}
        snmpQuery['sysMIBScalars']['string'] = 'sys'
        snmpQuery['sysMIBTables'] = copy.deepcopy(snmpQuery['sysMIBScalars'])
        
        snmpQuery['sysQueueStatsEntry'] = {}
        snmpQuery['sysQueueStatsEntry']['string'] = 'sysQueueStats'
        snmpQuery['sysQueueStatsTable'] = copy.deepcopy(snmpQuery['sysQueueStatsEntry'])
        
        snmpQuery['sysServiceStatsEntry'] = {}
        snmpQuery['sysServiceStatsEntry']['string'] = 'sysServiceStats'
        snmpQuery['sysServiceStatsTable'] = copy.deepcopy(snmpQuery['sysServiceStatsEntry'])
        
        snmpQuery['txnDatabaseIndexStatsEntry'] = {}
        snmpQuery['txnDatabaseIndexStatsEntry']['string'] = 'txnDatabaseIndex'
        snmpQuery['txnDatabaseIndexStatsTable'] = copy.deepcopy(snmpQuery['txnDatabaseIndexStatsEntry'])
        
        snmpQuery['txnDatabaseObjectStatsEntry'] = {}
        snmpQuery['txnDatabaseObjectStatsEntry']['string'] = 'txnDatabaseObject'
        snmpQuery['txnDatabaseObjectStatsTable'] = copy.deepcopy(snmpQuery['txnDatabaseObjectStatsEntry'])
        
        snmpQuery['txnDatabaseSegmentStatsEntry'] = {}
        snmpQuery['txnDatabaseSegmentStatsEntry']['string'] = 'txnDatabaseSegment'
        snmpQuery['txnDatabaseSegmentStatsTable'] = copy.deepcopy(snmpQuery['txnDatabaseSegmentStatsEntry'])
        
        snmpQuery['txnDatabaseStatsEntry'] = {}
        snmpQuery['txnDatabaseStatsEntry']['string'] = 'txnDatabase'
        snmpQuery['txnDatabaseStatsTable'] = copy.deepcopy(snmpQuery['txnDatabaseStatsEntry'])
        
        snmpQuery['txnMIBScalars'] = {}
        snmpQuery['txnMIBScalars']['string'] = 'txn'
        snmpQuery['txnMIBTables'] = copy.deepcopy(snmpQuery['txnMIBScalars'])
        
        # Find an inservice engine
        engine = None
        for key in list(ClusterMemberData['peer'].keys()): 
                if ClusterMemberData['peer'][key]['HaState'].lower() in ['active', 'standby']:
                        # Record engine
                        engine = key
                        
                        # Now need to find an inservice blade
                        found = False
                        for blade in list(ClusterMemberData[engine].keys()):
                                if ClusterMemberData[engine][blade]['ServiceState'] in ['active', 'standby']:
                                        found = True
                                        break
        
        # If no active engine found, then exit
        if not engine:
                print('SNMP init returning without fully initializing data, as no in service blade found')
                return
                
        # Find an active blade on this engine.
        # Assume cluster 1 for now...
        fqdn = engine + fqdnSeparator + '1' + fqdnSeparator + blade
        
        # Fill in entry dictionaries with per-entry data
        for key in snmpQuery:
                # skip the port key
                if key == 'port': continue
                
                # Only have elements for entry and scalers
                if not (key.endswith('Entry') or key.endswith('Scalers')): continue
                
                # Query and process returned data
                snmpQuery[key]['data'] = getAndProcessSnmpQuery(key, fqdn)
                
#       print 'SNMP Data after init: '
#       print str(snmpQuery)
        
#==============================================================
def checkBladeProcesses(fqdn, status='up'):
        # Sanity check the input
        if status.lower() != 'up' and status.lower() != 'down':
                # Not good.  Exit
                print('checkBladeProcesses: invalid status passed in: ' + str(status) + '. Must be "up" or "down".')
                sys.exit('Exiting due to errors')
                
        # May need to run this on multiple blades (for emgine operations)
        # Get IDs
        engineId  = fqdn.split(fqdnSeparator)[0]
        clusterId = fqdn.split(fqdnSeparator)[1]
        bladeId   = fqdn.split(fqdnSeparator)[2]
        
        # Go through global fqdn data
        for node in engineIpData:
                # Get IDs
                nodeEngineId  = node.split(fqdnSeparator)[0]
                nodeClusterId = node.split(fqdnSeparator)[1]
                nodeBladeId   = node.split(fqdnSeparator)[2]
        
                # See if we can skip
                if engineId  != '0' and engineId  != nodeEngineId:  continue
                if clusterId != '0' and clusterId != nodeClusterId: continue
                if bladeId   != '0' and bladeId   != nodeBladeId:   continue
        
                # Run command to get the number of MTX processes running
                cmd = "ps aux | grep 'mtx -e' | grep -v grep | wc -l"
                lclFqdn = nodeEngineId + fqdnSeparator + nodeClusterId + fqdnSeparator + nodeBladeId
                result = runSshCmd(lclFqdn, cmd)
                
                # Sanity check that we got a digit back
                if (not result) or not result.isdigit(): 
                        # Not good.  Return a failure
                        print('Warning: lclFqdn ' + lclFqdn + ' didn\'t return ps aux output.  Returned data: ' + str(result))
                        return False
        
                # We found something.  Check for errors (as we return immediately on errors)
                if not  ((status.lower() == 'up'   and int(result) == 7) or \
                         (status.lower() == 'down' and int(result) == 0)):
                        print('WARNING: checkBladeProcesses checking ' + lclFqdn + ' for ' + status.lower() + ' failed.  ps aux command returned ' + str(result) + ' processes running.')
                        return False
        
        # If here, then all good
        return True
#================== Init Cluster Data  ============================================
def initClusterData():
        global ClusterMemberData
        global engineIpData
        
        # Will get called after all engines down to reset data.  Also called at startup (and realistically anytime inbetween).
        # Save shared data if present.
        if 'shared_dir' in ClusterMemberData: savedShared = ClusterMemberData['shared_dir']
        else:                                 savedShared = QAUTILS.gatewaysConfig.get('HA','sharedDir')
        
        # Reset to empty
        ClusterMemberData = {}
        ClusterMemberData['peer'] = {}
        
        # Need to find an engine to read from (may not have any inservice)
        found = None
        notActiveBlades = []
        for fqBlade in sorted(engineIpData):
                # See if the blade is active
                result = checkBladeProcesses(fqBlade)
                
                # If success, then we may read more
                if result:
                        # Record we found something
                        found = fqBlade
                        
                        # Get IDs
                        engineId  = fqBlade.split(fqdnSeparator)[0]
                        clusterId = fqBlade.split(fqdnSeparator)[1]
                        bladeId   = fqBlade.split(fqdnSeparator)[2]
                        
                        # Get cluster data from inservice engine if not yet read
                        if engineId not in ClusterMemberData['peer']:
                                print('Reading peer data from blade ' + fqBlade)
                                ClusterMemberData['peer'] = getEnginePeerData(fqBlade)
                        
                        # Get engine data if not yet read
                        if engineId not in ClusterMemberData:
                                print('Reading engine data from blade ' + fqBlade)
                                ClusterMemberData[engineId] = getEngineClusterData(fqBlade)
                
                else:   notActiveBlades.append(fqBlade)
        
        print('\nPost reading of active data, cluster info is: ' + str(ClusterMemberData))
        
        # Need to initialize any engine/blade that's not already read.  
        # Could have an entire engine that was OOS and thus needs data initialized, or individual blades.
        for fqBlade in sorted(engineIpData):
                # Address engine and/or blade not in service
                if fqBlade in notActiveBlades:
                        # Get IDs
                        engineId  = fqBlade.split(fqdnSeparator)[0]
                        clusterId = fqBlade.split(fqdnSeparator)[1]
                        bladeId   = fqBlade.split(fqdnSeparator)[2]
                        
                        # See if the engine has been defined
                        if engineId not in ClusterMemberData['peer']: 
                                print('Engine ' + engineId + ' not inservice.  Defaulting data.')
                                ClusterMemberData['peer'][engineId] = {}
                                ClusterMemberData['peer'][engineId]['HaState'] = 'unknown'
                                ClusterMemberData['peer'][engineId]['ClusterId'] = clusterId
                        if engineId not in ClusterMemberData:
                                ClusterMemberData[engineId] = {}
                        if bladeId not in ClusterMemberData[engineId]:
                                ClusterMemberData[engineId][bladeId] = {}
                                ClusterMemberData[engineId][bladeId]['ServiceState'] = 'unknown'
                                ClusterMemberData[engineId][bladeId]['NodeId'] = bladeId
                                ClusterMemberData[engineId][bladeId]['MgmtIpAddress'] = '0.0.0.0'
                                ClusterMemberData[engineId][bladeId]['ClusterLeaderId'] = clusterId
                        
                                # Need to designate one of them as a management, so upgrades work.
                                # Management blade may already exist, or may not.
                                # Probably a smarter way to do this...
                                mgmtFound = False
                                for blade in list(ClusterMemberData[engineId].keys()):
                                        if 'ServiceRole' in ClusterMemberData[engineId][blade] and \
                                           ClusterMemberData[engineId][blade]['ServiceRole'] == 'management':
                                                mgmtFound = True
                                                break
                                # Assign blade as management if none already identified
                                if not mgmtFound: 
                                        ClusterMemberData[engineId][bladeId]['ServiceRole'] = 'management'
                                else:   ClusterMemberData[engineId][bladeId]['ServiceRole'] = 'unknown'
                                
                                print('Blade ' + fqBlade + ' is not inservice.  Defaulting data to show role of ' + ClusterMemberData[engineId][bladeId]['ServiceRole'] + '.')
        # If no active engine found, then exit
        if not found:
                print('NOTE: Cluster init found no in service engine.  Engine and blade data (from create_config.info) defaulted.')
                ClusterMemberData['shared_dir'] = savedShared
                print('\n\nClusterMemberData =' + str(ClusterMemberData) + '\n\n')
                return
                
        # Want to get shared dir value from the target.
        # Always use cluster management blade, as this is where the SAN will be mounted.
        # Code assumes the share is the same across all engines, so picking any one will work.
        mgmtList = getActiveManagementBlade(fqBlade)
        
        # See if there's a MGMT blade (single VMs won't have these)
        cmd = 'echo $MTX_SHARED_DIR'
        if mgmtList:
                # Save value
                ClusterMemberData['shared_dir'] = runSshCmd(found, cmd)
        else:   ClusterMemberData['shared_dir'] = runCmd(cmd)
                
        print('\n\nClusterMemberData =' + str(ClusterMemberData) + '\n\n')
        
def initThreadsAndQueues():
        global q, pool
        
        # Set up a queue
        q=Queue()

        ##### PROCESS GROUP DATA #####
        # Create threads and start them
        pool=[]
        for i in range(NUM_THREADS):
          t=processingThread(i,q)
          pool.append(t)
          t.daemon = True
          t.start()

def waitForThreadsToEnd():
        global q, pool
        
        # Put as many None's in the queue as there are threads, so that each thread gets one (signals to terminate)
        for t in pool: q.put(None)

        # Wait for all threads to exit
        for t in pool: t.join()

        # clear q, so code knows the queues are gone
        q = None
        
#==================================================================
def checkBladeForNotInservice(fqdn):
        # Get IDs
        if fqdn:
                engineId  = fqdn.split(fqdnSeparator)[0]
                clusterId = fqdn.split(fqdnSeparator)[1]
                bladeId   = fqdn.split(fqdnSeparator)[2]
        else:   engineId = clusterId = bladeId = '0'
        
        outOfServiceFlag = True
        # process every engine
        for engine in list(ClusterMemberData['peer'].keys()):
                # See if we should skip this one
                if engineId != '0' and engineId != engine: continue
                
                # OK, need to process this puppy. Go through each blade.
                for blade in ClusterMemberData[engineId]:
                        # See if we should check this blade
                        if bladeId != '0' and blade != bladeId: continue
                        
                        # Don't expect this blade to be present
                        if blade not in ClusterMemberData[engineId]: continue
                        
                        # May be present iff starting from engine out of service state
                        if ClusterMemberData[engineId][blade]['ServiceState'] == 'unknown': continue
                        
                        # Clear flag.  Only need to find one and then break out.
                        outOfServiceFlag = False
                        
                        print('WARNING: checkBladeForNotInservice, checking fqdn ' + fqdn + ', engine ' + engine + ' found inservice blade')
                        print(str(ClusterMemberData[engineId]))
                        break
                
                # If outOfServiceFlag clear, then can break
                if not outOfServiceFlag: break

        # Check flag
        if not outOfServiceFlag:        
                print('checkBladeForNotInservice - found inservice blade')
                return False
                
        return True
        
#==================================================================
def getAnotherInserviceEngine(fqdn):
        global ClusterMemberData

        # Get engine ID
        engineId = fqdn.split(fqdnSeparator)[0]

        # Need to read peer data from other engine, as the command may have failed.
        # Loop through until find the desired state.
        # Get list of keys (sorted seems to be a good idea...)
        keyList = sorted(ClusterMemberData['peer'].keys())

        # Loop through each entry
        found = False
        for key in keyList:
                # Skip the engine we just tried to remove
                if key == engineId: continue

                # Make sure other engine has a defined state
                if ClusterMemberData[key]['HaState'].lower() == 'unknown': continue

                found = True
                break

        # Check if found
        if not found:
                print('WARNING: no other inservice engine found besides ' + engineId)
                return None

        # If here, then we have a winner.  Return engine:1:1
        return key + fqdnSeparator + '1' + fqdnSeparator + '1'

#==================================================================
def getAnotherActiveBlade(fqdn):
        global ClusterMemberData
        
        # Get fqdn components
        engineId = fqdn.split(fqdnSeparator)[0]
        clusterId = fqdn.split(fqdnSeparator)[1]
        bladeId  = fqdn.split(fqdnSeparator)[2]
        
        # Copy from current data
        lclDct = copy.deepcopy(ClusterMemberData[engineId])
        
        # Get all blades
        allList = getAllBlades(lclDct)
        
#       print 'In getAnotherActiveBlade'
#       print 'lclDCT = ' + str(lclDct)
#       print 'allList = ' + str(allList)
        
        # Need to find another blade to read from, as this blade has stopped
        found = False
        for newBlade in allList:
                if str(newBlade) != bladeId:
                        found = True
                        break
        
        # Return found fqdn or none
        if found: return engineId + fqdnSeparator + clusterId + fqdnSeparator + str(newBlade)
        else:     return None
        
#==================================================================
def verifyEngineStarted(fqdn, expectError, lclDctInitial, lclDctFinal):
        global ClusterMemberData
        
        found = False
        
        # Get engine ID
        engineId = fqdn.split(fqdnSeparator)[0]
        
        # No errors
        errorFlag = False
        
        # Verify that the state of the restored engine is known
        if lclDctFinal[engineId]['HaState'].lower() not in ['active', 'standby']:
                print('WARNING: engine ' + engineId + ' was not restored')
                if not expectError: traceback.print_stack()
                errorFlag = True
                
        # Verify there's an active engine
        for key in list(ClusterMemberData['peer'].keys()):
                if lclDctFinal[key]['HaState'].lower() == 'active':
                        found = True
                        break
        if not found:
                print('WARNING: no active engine found after the restore')
                if not expectError: traceback.print_stack()
                errorFlag = True
        else:   
                # Run print blade stats -C on active engine
                execPrintBladeStats(fqdn, '-C')
                
        # Make sure all MTX processes are up on the entire engine
        if not errorFlag and not checkBladeProcesses(engineId + fqdnSeparator + '0' + fqdnSeparator + '0', status='up'):
                # Not all up.  May be OK or may be an error...
                if not expectError:
                        print('WARNING: verifyEngineStarted successful but not all processes are up')
                        traceback.print_stack()
                        errorFlag = not expectError
                else:   errorFlag = expectError
        
        # What to return depends on expected failure setting
        if expectError == errorFlag:
                # Overwrite ClusterMemberData data
                if not expectError: 
                        ClusterMemberData['peer'] = copy.deepcopy(lclDctFinal)
                        ClusterMemberData[engineId] = getEngineClusterData(fqdn)
                
                        # Reset SNMP, in case it hasn't yet been initialized
                        initSnmpData()
                
                return True,engineId
        else:
                if expectError: print('verifyEngineStarted: expected this to fail but the it succeeded.')
                else:           print('verifyEngineStarted: expected this to succeed but it failed.')
                return False,None
        
#==================================================================
def verifyEngineStopped(fqdn, expectError=False):
        global ClusterMemberData
        
        allEngineDownFlag = False
        errorFlag = False
        
        # Get engine ID
        engineId = fqdn.split(fqdnSeparator)[0]
        
        # Need to read peer data from other engine, as the command may have failed.
        newFqdn = getAnotherInserviceEngine(fqdn)

        if newFqdn:
                # Get inservice engine ID
                newEngineId = newFqdn.split(fqdnSeparator)[0]
        
                # Get peer data from inservice peer
                lclDctFinal = getEnginePeerData(newFqdn)

                # Verify that the state of the removed engine is not inservice
                if lclDctFinal['peer'][engineId]['HaState'].lower() in ['active', 'standby']:
                        print('WARNING: engine ' + engineId + ' was not removed')
                        if not expectError: traceback.print_stack()
                        errorFlag = True

                # Verify there's an active engine
                if lclDctFinal[newEngineId]['HaState'].lower() != 'active':
                        print('WARNING: engine ' + newEngineId + ' is not active post the engine remove')
                        if not expectError: traceback.print_stack()
                        errorFlag = True

                # Run print blade stats -C on active engine
                execPrintBladeStats(newFqdn, '-C')
        else:   
                # All engines down
                print('WARNING: it seems the last engine has been removed.  Set cluster data so it reflects all engines down.')
                initClusterData()
                
                # Nothing read post the operation
                lclDctFinal = {}
                
                # Set flag signalling this happened
                allEngineDownFlag = True
                
        # Make sure all MTX processes are down on the entire engine
        if not errorFlag and not checkBladeProcesses(engineId + fqdnSeparator + '0' + fqdnSeparator + '0', status='down'):
                print('ERROR: verifyEngineStopped successful but not all processes are down')
                traceback.print_stack()
                return False,None,allEngineDownFlag
        
        # What to return depends on expected failure setting
        if expectError == errorFlag:
                # Overwrite ClusterMemberData data
                if not expectError and lclDctFinal: ClusterMemberData['peer'] = copy.deepcopy(lclDctFinal)

                return True,engineId,allEngineDownFlag
        else:   return False,None,allEngineDownFlag

#================== APIs  ============================================

#==================================================================
def debugLogFileRotate(fqdn):
        return logFileRotate(fqdn, '/var/log/mtx/mtx_debug.log')

#==================================================================
def logFileRotate(fqdn, fileName):
        global engineIpData
        
        # Get fqdn components
        engineId  = fqdn.split(fqdnSeparator)[0]
        clusterId = fqdn.split(fqdnSeparator)[1]
        bladeId   = fqdn.split(fqdnSeparator)[2]
        
        # May rotate a single server or an entire engine
        # Need to go through the engineIP list and get all matching engine/cluster values
        fqdnList = []
        for sysFqdn in engineIpData:
                # Get system fqdn components
                sysEngineId  = sysFqdn.split(fqdnSeparator)[0]
                sysClusterId = sysFqdn.split(fqdnSeparator)[1]
                sysBladeId   = sysFqdn.split(fqdnSeparator)[2]
                        
                # Easier to check for no match...
                if   engineId  != '0' and sysEngineId  != engineId:  continue
                elif clusterId != '0' and sysClusterId != clusterId: continue
                elif bladeId   != '0' and sysBladeId   != bladeId:   continue
                
                # If here, than add to the list
                fqdnList.append(sysFqdn)
                
        # Sanity check this
        if not fqdnList:
                print('WARNING: no blades found that match input fqdn = ' + fqdn)
                print('Engine blade list: ' + str(engineIpData))
                return
        
        # Setup the command 
        currentTime = time.strftime("%Y_%m_%dT%H_%M_%S")
        newFile = fileName + '.' + currentTime
        cmd  = 'cp ' + fileName + ' ' + newFile
        cmd += bashCommandSeparator + 'echo > ' + fileName
        
        # Run the command on every identified blade
        for bladeFqdn in fqdnList:
                print('Rotating blade ' + bladeFqdn + ' file ' + fileName + ' into file ' + newFile)
                runSshCmd(bladeFqdn, cmd)
        
#==================================================================
def clearExcludeList(fqdn):
        # Define command to get the data
        cmd = 'cluster_mgr_cli.py -t localhost:4800 clear excluded_nodes'
        
        # Get fqdn components
        engineId  = fqdn.split(fqdnSeparator)[0]
        clusterId = fqdn.split(fqdnSeparator)[1]
        bladeId   = fqdn.split(fqdnSeparator)[2]
        
        # Must send clear exclusion to management blade
        mgmtList = getActiveManagementBlade(fqdn)
        
        # If starting from duplex failed engine, then may not have an active management blade...
        if mgmtList: blade = str(mgmtList[0])
        else:        blade = '1'
        
        # Send to the fqdn
        newFqdn = engineId + fqdnSeparator + clusterId + fqdnSeparator + blade
        outData = runSshCmd(newFqdn, cmd)
        
        # If return data is not 0, then something still excluded
        if outData != '0':
                print('ERROR: clearExcludeList returned excluded items: ' + outData)
                return False
        
        return True
        
#==================================================================
def getExcludeList(fqdn):
        retList = []
        
        # Get fqdn components
        engineId  = fqdn.split(fqdnSeparator)[0]
        clusterId = fqdn.split(fqdnSeparator)[1]
        bladeId   = fqdn.split(fqdnSeparator)[2]
        
        # Define command to get the data
        cmd = 'cluster_mgr_cli.py -t localhost:4800 get excluded_nodes'
        
        # Send to the fqdn
        outData = runSshCmd(fqdn, cmd)
        
        # If return data is empty, then nothing excluded.
        # Empty string changed between releases.  CHeck for old and new strings.
        if outData in ['()','0']: return retList
        
        # If here, then we have a non-zero list of blades.  Get into Python list of fqdn.
        # Format appears to be (x,y,z,).  Drop first and last items, as well as the last comma.
        bladeList = outData[1:-2].split(',')
        for blade in bladeList: retList.append(engineId + fqdnSeparator + clusterId + fqdnSeparator + str(blade))
        
        print('Excluded list: ' + str(retList))
        return retList
        
#==================================================================
def processPricing(fqdn, sourceData, apply=True):
        # Blade must be in service
        if checkBladeForNotInservice(fqdn):
                print('WARNING: can\'t process pricing to an out of service blade: ' + fqdn)
                return False
        
        area = 'pricing'
        
        # May want to use default data, or may have specified the actual data
        if sourceData.lower() == 'default':
                cmd = "data = QAUTILS.gatewaysConfig.get('HA','" + area.lower() + "Data')"
                exec(cmd)
        else:   data = sourceData 
                        
        # Process this request
        return sendToEngineMgmtOnly(area, fqdn, data, apply)
        
#==================================================================
def processCustom(fqdn, sourceData, apply=True):
        area = 'custom'
        
        # May want to use default data, or may have specified the actual data
        if sourceData.lower() == 'default':
                cmd = "data = QAUTILS.gatewaysConfig.get('HA','" + area.lower() + "Data')"
                exec(cmd)
        else:   data = sourceData 
                        
        return processMgmtOnly(area, data, apply, fqdn)
        
#==================================================================
def processCheckpoint(fqdn, sourceData, apply=True):
        global ClusterMemberData
        
        area = 'checkpoint'
        
        # May want to use default data, or may have specified the actual data
        if sourceData.lower() == 'default':
                cmd = "data = QAUTILS.gatewaysConfig.get('HA','" + area.lower() + "Data')"
                exec(cmd)
        else:   data = sourceData 
                        
        # Check engine status, as impacted engines need to be out of service
        retCode = checkEngineServiceState(fqdn)
        if not retCode: return False
        
        return processMgmtOnly(area, data, apply, fqdn)
        
#==================================================================
def checkEngineServiceState(fqdn, state='down'):
        # Check for invalid state value
        if state.lower() not in ['up', 'down']:
                print('ERROR: checkEngineServiceState invalid state value: ' + str(state))
                traceback.print_stack()
                return False
        
        print('checkEngineServiceState: checking engine for ' + state + ': ' + fqdn)
        
        # Get engine and blade from fqdn
        engineId = fqdn.split(fqdnSeparator)[0]
        
        # If engine is not defined, then by default it's down
        if engineId not in ClusterMemberData['peer']:
                if state.lower() == 'down': return True
                else:                       return False
        
        # Check for down state
        if state.lower() == 'down' and (ClusterMemberData['peer'][engineId]['HaState'].lower() in ['active', 'standby']):
                print('ERROR: Can\'t process data to an inservice engine')
                traceback.print_stack()
                return False
                
        # Check for up state
        if state.lower() == 'up' and (ClusterMemberData['peer'][engineId]['HaState'].lower() not in ['active', 'standby']):
                print('ERROR: Can\'t process data to an out of service engine')
                traceback.print_stack()
                return False
        
        # If here, then success
        return True
#==================================================================
def processRpm(fqdn, sourceData, apply=True):
        global targetData
        
        area = 'rpm'
        
        # May want to use default data, or may have specified the actual data
        if sourceData.lower() == 'default':
                cmd = "data = QAUTILS.gatewaysConfig.get('HA','" + area.lower() + "Data')"
                exec(cmd)
        else:   data = sourceData
                        
        # Get fqdn components
        engineId = fqdn.split(fqdnSeparator)[0]
        clusterId = fqdn.split(fqdnSeparator)[1]
        bladeId  = fqdn.split(fqdnSeparator)[2]
        
        # Check blade status, as impacted blades need to be out of service
        retCode = checkBladeForNotInservice(fqdn)
        if not retCode: return False
        
        # Check if this should process across all engines
        if not fqdn: return sendToAll(area, data, apply)
        
        # Check if going to all blades in the engine
        if bladeId == '0':
                print("processRpm calling sendToEngine")
                return sendToEngine(area, fqdn, data, apply)
        
        # If here, then only want to send to one blade.
        # Check that the blade is not part of the current cluster data.
        if not checkBladeForNotInservice(fqdn):
                print('ERROR: Can\'t process RPM data to an inservice blade')
                traceback.print_stack()
                return False
        
        # If here, then can send to single blade
        return sendToEngineBlade(area, fqdn, data, \
                targetData[area.lower()]['targetScript'], \
                targetData[area.lower()]['targetDir'], \
                targetData[area.lower()]['sourceFileExt'], \
                apply)
        
#==================================================================
def stopHighestNumberedActiveProcessingBlade(fqdn, expectError=False):
        # Get the engine ID
        engineId = fqdn.split(fqdnSeparator)[0]
        
        # Get sorted list of processing blades
        bladeList = getActiveProcessingBlades(engineId).sort()
        
        # Sanity check:  need at least two proc blades (as this primitive should't be used to kill an engine)
        if len(bladeList) < 2: 
                print('WARNING: stopHighestNumberedActiveProcessingBlade won\'t remove the last processing blade')
                traceback.print_stack()
                if expectError: return True,'0'
                else:           return False,'0'
        
        # Get highest numbered blade
        blade = bladeList[-1]
        
        # Stop and verify this
        (retCode, bladeId) = stopAndVerifyBlade(fqdn, dictionary = {}, expectError = expectError)
        
        # See if success.  Called function already accounts for expect error.
        if not retCode:
                print('WARNING: stopHighestNumberedActiveProcessingBlade stopAndVerifyBlade failed')
                traceback.print_stack()
                return False,'0'
        
        # return the ID of the stopped blade
        return True,bladeId
        
#==================================================================
def doSpecialProcessing(lclFqdn, specialInfo, bladeType, thread=False):
        print('Doing special processing for blade ' + lclFqdn)
        
        # Init threads/queues
        if threadFlag: initThreadsAndQueues()
                        
        # Process individual items
        for item in specialInfo:
                if specialInfo[item]: 
                        # Don't process MGMT-only item on non-MGMT blades
                        if bladeType.lower() != 'management' and targetData[item]['mgmtOnly']:
                                print('Skipping item ' + item + ' because this is not a management blade')
                                continue
                        else:   print('Processing item ' + item + ' on this blade')
                        
                        # Execute the specific item
                        cmd = 'retCode = process' + item.capitalize() + '(lclFqdn, specialInfo[item], apply)'
                        exec(cmd)
                                        
                        # Check for failure
                        if not retCode:
                                print('process' + item.capitalize() + ' failed')
                                traceback.print_stack()
                                return False

        # Wait for queued stuff to end
        if threadFlag: waitForThreadsToEnd()
        
        return True
                
#==================================================================
def rollEngine(fqdn, specialInfo=None, apply=True, noMgmt=False):
        # Check fqdn is specified
        if not fqdn:
                print('WARNING: can\'t roll an engine without passing in the fqdn')
                return False
        
        # Get the engine ID
        engineId  = fqdn.split(fqdnSeparator)[0]
        clusterId = fqdn.split(fqdnSeparator)[1]
        bladeId   = fqdn.split(fqdnSeparator)[2]
        
        # Sanity check that the engine is present in global data
        if engineId not in ClusterMemberData['peer']:
                print('WARNING: can\'t roll an engine that\'s not defined in global data.  Tried to roll engine ' + fqdn + '. Cluster data:' + str(ClusterMemberData))
                return False
                
        # Engine needs to be inservice to roll.
        if ClusterMemberData['peer'][engineId]['HaState'] not in ['active', 'standby']:
                print('WARNING: can\'t roll an engine that\'s not inservice.')
                return False
        
        # Get list of blades (sorted)
        bladeList = sorted(getAllBlades(fqdn))
        print('rollEngine bladeList = ' + str(bladeList))
        
        # If no mgmt set, then need to get management blades
        if noMgmt: mgmtList = getManagementBlades(fqdn)
        
        # Stop/start each blade
        for blade in bladeList:
                # Skip if no mgmt and this is the mgmt blade
                if noMgmt and blade in mgmtList: continue
                
                # Get the blade type
                bladeType = ClusterMemberData[engineId][str(blade)]['ServiceRole'].lower()
                        
                # Build local fqdn
                lclFqdn = engineId + fqdnSeparator + clusterId + fqdnSeparator + str(blade)
                
                # Stop the blade
                retCode = stopAndVerifyBlade(lclFqdn)
                
                # Check if failed
                if not retCode:
                        print('rollEngine: stopAndVerifyBlade returned a failure for fqdn ' + lclFqdn)
                        traceback.print_stack()
                        return False
                
                # If I'm going to do anything, then queue work to do
                if specialInfo:
                        # NOTE: for rolling upgrades, always assume it's a PROC blade.  Can't really roll 
                        # MGMT stuff, since the MGMT blade will change (and the engine won't be out of service).
                        retCode = doSpecialProcessing(lclFqdn, specialInfo, 'processing')
                        if not retCode: return retCode
                
                # Start the blade
                (retCode,newFqdn) = startAndVerifyBlade(lclFqdn)
        
                # Check if failed
                if not retCode:
                        print('rollEngine: startAndVerifyBlade returned a failure for fqdn ' + lclFqdn)
                        traceback.print_stack()
                        return False
                        
        # If here, it all worked
        return True
        
#==================================================================
def rollingUpgrade(fqdn, specialInfo=None, apply=True, noMgmt = False):
        global ClusterMemberData
        
        # Error if peer data not present
        if 'peer' not in ClusterMemberData: sys.exit('rollingUpgrade: peer data not present in ClusterMemberData')
        
        # Execute for specified engine (or both if none specified) 
        for key in list(ClusterMemberData['peer'].keys()): 
                # Need an engine ID.  If specified, use it, else use the key
                if fqdn:
                        engineId = fqdn.split(fqdnSeparator)[0]
                        clusterId = fqdn.split(fqdnSeparator)[1]
                else:
                        # Nothing input.  Assume cluster 1.
                        engineId = key
                        clusterId = '1'
                
                # Filter on engine
                if engineId != key: continue
                
                lclFqdn = engineId+fqdnSeparator+clusterId+fqdnSeparator+'0'
                print('rollingUpgrade: Sending to engine ' + lclFqdn)
                retCode = rollEngine(lclFqdn, specialInfo, apply, noMgmt)

                # If failing, then exit
                if not retCode:
                        print('rollUpgrade: rollEngine returned a failure for fqdn ' + lclFqdn)
                        traceback.print_stack()
                        return False

        # If here, it all worked
        return True
        
#==================================================================
def restartBladesAll(fqdn):
        return rollingUpgrade(fqdn, apply=True, noMgmt = False)

#==================================================================
def restartBladesNoMgmt(fqdn):
        return rollingUpgrade(fqdn, apply=True, noMgmt = True)

#==================================================================
def restartEngine(fqdn):
        return engineUpgrade(fqdn)

#==================================================================
def execPrintBladeStats(fqdn, cmdOptions='-C', printFlag = True):
        engineId = fqdn.split(fqdnSeparator)[0]
        cmd = 'print_blade_stats.py -e ' + engineId
        if cmdOptions: cmd += ' ' + cmdOptions
        outData = runSshCmd(fqdn,cmd)
        if printFlag: print('\n\n' + outData + '\n\n')
        return outData

#==================================================================
def engineUpgrade(fqdn=None, specialInfo=None, apply=True):
        global ClusterMemberData
        
        # Error if peer data not present
        if 'peer' not in ClusterMemberData: 
                print('engineUpgrade: peer data not present in ClusterMemberData')
                traceback.print_stack()
                sys.exit('Exit due to errors')
        
        # Which engines to do depends on what was input
        if not fqdn:    
                # Want to upgrade all engines.
                # Can have two standby engines and one active engine.  Ugh...
                # Only way around this is to store the IDs instead of the functionality.
                unknownList = []
                standbyList = []
                activeList = []
                
                # Engine IDs start at 1.  Unknown states get mapped to the unknown bucket.
                for engine in range(1, len(ClusterMemberData['peer']) + 1):
                        if ClusterMemberData['peer'][str(engine)]['HaState'] in ['active', 'standby']:
                                listType = ClusterMemberData['peer'][str(engine)]['HaState']
                        else:   listType = 'unknown'
                        
                        # Get cluster value
                        clusterId = ClusterMemberData['peer'][str(engine)]['ClusterId']
                        
                        # Want to identify the management blade here, so we restore from that blade
                        mgmtList = getManagementBlades(str(engine) + fqdnSeparator + clusterId + fqdnSeparator + '0')
                        
                        # If on a single VM, then may not have a management blade...
                        if mgmtList:    data = str(mgmtList[0])
                        else:           data = '1'
                        
                        cmd = listType + 'List.append(str(engine) + fqdnSeparator + clusterId + fqdnSeparator + data)'
                        exec(cmd)
                
                # OK, start with unknown, then higher number standby (i.e. reverse sorted), then active
                englineList = []
                englineList.extend(unknownList)
                englineList.extend(sorted(standbyList, reverse=True))
                englineList.extend(activeList)
                
        else:   englineList = [fqdn]
        
        # Execute for specified engine(s)
        for lclFqdn in englineList:
                # Stop engine
                print('engineUpgrade: Sending to engine ' + lclFqdn)
                (retCode,engineId) = stopAndVerifyEngine(lclFqdn)
                
                # Check if failed
                if not retCode:
                        print('engineUpgrade: stopAndVerifyEngine returned a failure for fqdn ' + lclFqdn)
                        traceback.print_stack()
                        return False
                        
                # Do special processing
                # If pricing specified, then save it and do at the end (as it needs to be done on an inservice engine
                if 'pricing' in specialInfo:
                        specialPricingData = specialInfo['pricing']
                        del specialInfo['pricing']
                else:   specialPricingData = None
                
                # NOTE: need to go through every blade in the engine...
                if specialInfo:
                        # Get IDs for this guy
                        engineId  = lclFqdn.split(fqdnSeparator)[0]
                        clusterId = lclFqdn.split(fqdnSeparator)[1]
                        
                        # Process every item in the global data
                        for item in engineIpData:
                                # See if they don't match
                                itemEngineId  = item.split(fqdnSeparator)[0]
                                itemClusterId = item.split(fqdnSeparator)[1]
                                itemBladeId   = item.split(fqdnSeparator)[2]
                                if engineId != itemEngineId or clusterId != itemClusterId: continue
                                
                                # If here, then we have a blade to process.  Now need to get the blade type.
                                if itemEngineId in ClusterMemberData and itemBladeId in ClusterMemberData[itemEngineId]:
                                        bladeType = ClusterMemberData[itemEngineId][itemBladeId]['ServiceRole'].lower()
                                else:
                                        print('ERROR: egine ' + item + ' not in global cluster data.')
                                        print(str(ClusterMemberData))
                                        return False
                        
                                retCode = doSpecialProcessing(item, specialInfo, bladeType)
                                if not retCode: return retCode
                                
                # Start engine
                (retCode,engineId) = startAndVerifyEngine(lclFqdn)

                # Check if failed
                if not retCode:
                        print('engineUpgrade: stastAndVerifyEngine returned a failure for fqdn ' + lclFqdn)
                        traceback.print_stack()
                        return False
                        
                # See if we need to do pricing work (that would have been skipped above since it needs to be done at the end)
                if specialPricingData:
                        area = 'pricing'
                        data = {}
                        data[area] = specialPricingData
                        retCode = doSpecialProcessing(lclFqdn, data, 'management')
                        if not retCode: return retCode
                                
                        # Restore data
                        specialInfo[area] = specialPricingData
                        specialPricingData = None
                        
        # If here, it all worked
        return True
        
#==================================================================
def startAndVerifyBlade(fqdn, dictionary = {}, expectError=False, addExcluded=False):
        global ClusterMemberData
        
        # Get engine ID
        engineId = fqdn.split(fqdnSeparator)[0]
        clusterId = fqdn.split(fqdnSeparator)[1]
        bladeId  = fqdn.split(fqdnSeparator)[2]
        
        # Can pass in the desired dictionary.
        if dictionary:  lclDct = copy.deepcopy(dictionary)
        else:           lclDct = copy.deepcopy(ClusterMemberData[engineId])
        
        # No errors
        errorFlag = False
        
        # Get initial lists
        procListInitial = getProcessingBlades(lclDct)
        mgmtListInitial = getManagementBlades(lclDct)

        # Run print blade stats -C on current engine
        execPrintBladeStats(getAnotherActiveBlade(fqdn), '-C')
                
        # Start the blade
        retCode = startBlade(fqdn, lclDct, expectError, addExcluded=addExcluded)
        
        # See if stop blade failed
        if not retCode:
                print('startBlade returned a failure')
                
                # What to return depends on expected failure setting
                if expectError: return True,fqdn
                else:           return False,None
        
        # See what state we're in.  Don't wait if expecting a failure.
        retCode = waitForBladeToRestore(fqdn, waitFlag=(not expectError))
        
        # See if we failed (return and expect should be different)
        if expectError == retCode:
                print('ERROR: blade ' + bladeId + ' expected error is ' + str(expectError) + ' and the restore value is ' + str(retCode))
                traceback.print_stack()
                return False,None
                
        # All the rest of the checks are meant for successful restores
        if expectError: return True,None
        
        # Make sure all MTX processes are up
        if not checkBladeProcesses(fqdn, status='up'):
                print('ERROR: startBlade() and waitForBladeToRestore() returned success but not all processes are up')
                traceback.print_stack()
                return False,None
        
        # Get updated cluster data
        ClusterMemberData[engineId] = getEngineClusterData(fqdn)
        lclDct = copy.deepcopy(ClusterMemberData[engineId])
        
        # Get the blade type (used later)
        bladeType = lclDct[bladeId]['ServiceRole'].lower()
        
        # Get new lists
        procListFinal = getProcessingBlades(lclDct, mustRead=True)
        mgmtListFinal = getManagementBlades(lclDct, mustRead=True)
        
        # What to check depends on what was removed
        if bladeType.lower() == 'processing':
                # Management blade list should not change on mgmt removal
                if mgmtListInitial != mgmtListFinal:
                        print('ERROR: management blade should not change during PROC blade restore')
                        if not expectError: traceback.print_stack()
                        errorFlag = True

                # Make sure only one proc blade was restored
                if len(procListFinal) != len(procListInitial) + 1:
                        print('ERROR: proc blade restore caused more than one PROC blade impact')
                        if not expectError: traceback.print_stack()
                        errorFlag = True
                
                # Make sure only the one blade was added
                procListInitial.append(bladeId)
                if procListInitial.sort() != procListFinal.sort():
                        print('ERROR: proc blade restore did not result in just the addition of the one processing blade')
                        if not expectError: traceback.print_stack()
                        errorFlag = True
                
        else:   sys.exit('ERROR: unexpected blade type retruned: ' + bladeType)
        
        # Run print blade stats -C on active engine
        execPrintBladeStats(fqdn, '-C')
                
        # What to return depends on expected failure setting
        if expectError == errorFlag:
                return True,fqdn
        else:   return False,None
        
#==================================================================
def startEngine(fqdn, expectError=False, background=False):
        # Get engine ID
        engineId = fqdn.split(fqdnSeparator)[0]
        
        # If starting from engine down, then engine will be null in the cluster data.
        if engineId in ClusterMemberData and ClusterMemberData[engineId]:
                # See if engine is in service
                if ClusterMemberData['peer'][engineId]['HaState'].lower() != 'unknown':
                        print('WARNING: engine ' + str(engineId) + ' is in service.  Will run command anyways.')
                        if not expectError: traceback.print_stack()
        
                # Need to read peer data from other engine, as the command may have failed.
                newFqdn = getAnotherInserviceEngine(fqdn)

                # Run print blade stats -C on active engine
                if newFqdn: execPrintBladeStats(newFqdn)
        else:   newFqdn = None
        
        # Execute command to start the engine
        print('Will start engine ' + fqdn)
        cmd = 'start_engine.py -e ' + engineId
        if background: cmd = 'nohup ' + cmd + ' > /dev/null 2>&1  &'
        retCode = runSshCmd(fqdn, cmd)
        
        # If here, then success
        return True, newFqdn
        
#==================================================================
def startAndVerifyEngine(fqdn, expectError=False, addExcluded=False):
        global ClusterMemberData

        # ** Assumption is peer data exists OR you pased in a dictionary **
        # ** Primitve tries to read from engine passed in if no dictionary input...
        
        # Get cluster data
        lclDctInitial = copy.deepcopy(ClusterMemberData['peer'])
        
        # No errors
        errorFlag = False
        
        # Start the engine
        (retCode, newFqdn) = startEngine(fqdn, expectError)
        
        # Note:  don't check start_engine return code, as it sometimes comes back too soon and declares a failure.
        # Wait for the state to go inservice.  Don't spend time if expected to fail.
        retCode = waitForEngineToRestore(fqdn, waitFlag=(not expectError))
        
        # Get peer data from inservice peer
        if retCode: lclDctFinal = getEnginePeerData(fqdn)
        elif newFqdn:   
                lclDctFinal = getEnginePeerData(newFqdn)
                fqdn = newFqdn
        else:
                print('No inservice engines and start engine failed.  Can\'t validate this action')
                if expectError: return True,None
                else:           return False,None
        
        # See if we should address exclusion
        if addExcluded:
                # There may be some blades excluded.  Resolve that here.
                excludeList = getExcludeList(fqdn)
                if excludeList:
                        # Try to clear everything
                        if not clearExcludeList(fqdn):
                                print('startAndVerifyEngine: couldn\'t clear the exclusion list: ' + str(excludeList) + ' when sending to fqdn ' + fqdn)
                                return False,None
                
                        # Get engine ID
                        engineId = fqdn.split(fqdnSeparator)[0]
        
                        # Normally update at the end of verification, but need to update now for exclusion processing to work.
                        ClusterMemberData['peer'] = copy.deepcopy(lclDctFinal)
                        ClusterMemberData[engineId] = getEngineClusterData(fqdn)
        
                        # Need to start and verify each blade in the exclude list
                        for bladeFqdn in excludeList: 
                                (retCode,dummy) = startAndVerifyBlade(bladeFqdn)
                                if not retCode: 
                                        print('startAndVerifyEngine: call to startAndVerifyBlade for excluded blade ' + bladeFqdn + ' failed.')
                                        return False,None
        
        # Verify the action
        (retCode, engineId) = verifyEngineStarted(fqdn, expectError, lclDctInitial, lclDctFinal)
        
        return retCode, engineId
        
#==================================================================
def stopEngine(fqdn, expectError=False, background=False):
        global ClusterMemberData
        
        # ** Assumption is the input engine is in service OR you pased in a dictionary **
        # ** Primitve tries to read from engine passed in if no dictionary input...
        
        # Get engine ID
        engineId = fqdn.split(fqdnSeparator)[0]
        
        # Get cluster data
        lclDctInitial = copy.deepcopy(ClusterMemberData['peer'])
        
        # If nothing returned, then this engine has no data
        if not lclDctInitial:
                print('WARNING: stopAndVerifyEngine is not processing engine ' + str(engineId) + ' due to no data for this engine')
                
                # What to return depends on expected error
                if expectError: return True
                else:           return False
        
        # No errors
        errorFlag = False
        
        # See if engine is in service
        if lclDctInitial[engineId]['HaState'].lower() == 'unknown':
                print('WARNING: engine ' + str(engineId) + ' is not in service.  Will run command anyways.')
                if not expectError: traceback.print_stack()
        else:
                # Run print blade stats -C on active engine
                execPrintBladeStats(fqdn, '-C')
        
        # Execute command to stop the engine
        print('Will stop engine ' + engineId)
        cmd = 'stop_engine.py -e ' + engineId
        if background: cmd = 'nohup ' + cmd + ' > /dev/null 2>&1  &'
        retCode = runSshCmd(fqdn, cmd)
        
        # Need to read peer data from other engine, as the command may have failed.
        newFqdn = getAnotherInserviceEngine(fqdn)

        if newFqdn:
                # Get new engine ID
                newEngineId = newFqdn.split(fqdnSeparator)[0]
        
                # Get peer data from inservice peer
                lclDctFinal = getEnginePeerData(newFqdn)

                # Verify that the state of the removed engine is unknown
                if lclDctFinal['peer'][engineId]['HaState'].lower() in ['active', 'standby']:
                        print('WARNING: engine ' + engineId + ' was not removed')
                        if not expectError: traceback.print_stack()
                        errorFlag = True

                # Verify there's an active engine
                if lclDctFinal[newEngineId]['HaState'].lower() != 'active':
                        print('WARNING: engine ' + newEngineId + ' is not active post the engine remove')
                        if not expectError: traceback.print_stack()
                        errorFlag = True

                # Run print blade stats -C on active engine
                execPrintBladeStats(newFqdn, '-C')
        else:   
                # All engines down
                print('WARNING: it seems the last engine has been removed.  Clearing cluster peer data since it can\'t be read.')
                for key in list(ClusterMemberData['peer'].keys()): ClusterMemberData['peer'][engineId]['HaState'] = 'unknown'
                
        # What to return depends on expected failure setting
        if expectError != retCode: return True
        else:                      return False
        
#==================================================================
def stopAndVerifyEngine(fqdn, expectError=False):
        # Get engine ID
        engineId = fqdn.split(fqdnSeparator)[0]
        
        # Stop the engine
        retCode = stopEngine(fqdn, expectError)
        
        # Verify the engine stop
        if retCode and not expectError: (retCode, engineId, allEngineDownFlag) = verifyEngineStopped(fqdn, expectError)
        
        return retCode, engineId
        
#==================================================================
def waitForMgmtRecoveryComplete(fqdn):
        # Get string to look for
        mgmtRecoveryCompleteString = "FsmTxnSvrStateBase::handleSharedStorageEvent: Management blade recovery complete"
        cmd = "grep '" + mgmtRecoveryCompleteString + "' /var/log/mtx/mtx_debug.log | wc -l"
                
        print('Checking management blade ' + fqdn + ' for recovery complete.')
        print('Debug logfile string: ' + cmd)
        
        # Grep for the key line
        found = False
        i = 0
        totalTime = int(QAUTILS.gatewaysConfig.get('HA','managementRecovery'))
        sleepTime = int(QAUTILS.gatewaysConfig.get('HA','timeBetweenRetries'))
        while i <= totalTime:
                # Run the command
                outData = runSshCmd(fqdn, cmd)
                
                # Check if the value is > 0
                if outData.isdigit() and int(outData) > 0:
                        print('New management blade ' + fqdn + ' recovery complete')
                        found = True
                        break
                
                # Bump loop counter
                i += sleepTime
                
                # If here, then not yet found
                # Sleep unless last loop
                if i <= totalTime:
                        print('New management blade ' + fqdn + ' recovery NOT YET complete.  Sleep for ' + str(sleepTime) + ' seconds.  Try ' + str(i) + ' out of ' + str(totalTime))
                        time.sleep(sleepTime)
                
        # Check if we broke out
        if not found:
                print('ERROR: new management blade ' + fqdn + ' did not have the recovery complete string in the debug log file')
                if not expectError: traceback.print_stack()
                errorFlag = True
        else:   errorFlag = False
        
        return errorFlag
#==================================================================
def stopAndVerifyBlade(fqdn, dictionary = {}, expectError=False, processToKill = None, quorumLost=False):
        global ClusterMemberData
        
        # Get IDs
        engineId  = fqdn.split(fqdnSeparator)[0]
        clusterId = fqdn.split(fqdnSeparator)[1]
        bladeId   = fqdn.split(fqdnSeparator)[2]
        
        # Can pass in the desired dictionary.
        if dictionary:  lclDct = copy.deepcopy(dictionary)
        else:           lclDct = copy.deepcopy(ClusterMemberData[engineId])
        
        # Get the blade type
        bladeType = lclDct[bladeId]['ServiceRole'].lower()
        
        # If removing a management blade, then need to rotate logs for the cluster or else a false positive may arise
        if bladeType.lower() == 'management': debugLogFileRotate(engineId + fqdnSeparator + clusterId + fqdnSeparator + '0')
        
        # No errors
        errorFlag = False

        # Get initial lists
        procListInitial = getProcessingBlades(lclDct)
        mgmtListInitial = getManagementBlades(lclDct)
        allList = copy.deepcopy(procListInitial)
        allList.extend(mgmtListInitial)

        # Run print blade stats -C on active engine
        execPrintBladeStats(fqdn, '-C')
                
        # Stop the blade
        retCode = stopBlade(fqdn, lclDct, expectError, processToKill)
        
        # See if stop blade failed
        if not retCode:
                print('stopBlade returned a failure')
                
                # What to return depends on expected failure setting
                if expectError: return True
                else:           return False
        
        # Make sure all MTX processes are down
        if not checkBladeProcesses(fqdn, status='down'):
                print('ERROR: stopBlade() returned success but not all processes are down')
                traceback.print_stack()
                return False
        
        # Check if engine is expected to drop due to quorum being lost
        if quorumLost:
                # Verify the engine stopped
                (retCode, engineId, allEngineDownFlag) = verifyEngineStopped(fqdn, expectError)
                
                # See if we got a failed return code
                if not retCode:
                        print('ERROR: verifyEngineStopped returned a failure.')
                        return False
                
                # If all engines are now supposedly down, then we still need to verify that this engine is really down...
                if allEngineDownFlag:
                        # Get the peer data
                        peerData = getEnginePeerData(fqdn)
                        
                        # If we got something and we weren't expecting an error, then this is a failure
                        if peerData and not expectError: 
                                print('ERROR: stopAndVerifyBlade called with quorum set and expect error, but we didn\'t remove the engine.')
                                retCode = False
                
                return retCode

        # Need to find another blade to read from, as this blade has stopped
        found = False
        for newBlade in allList:
                if newBlade != int(bladeId):
                        found = True
                        break
        
        # Get new fqdn if something was found
        if found: readFqdn = engineId + fqdnSeparator + clusterId + fqdnSeparator + str(newBlade)
        else:
                # Be nice here.  Engine always goes down when last blade is removed.  Not an error.
                print('Removed last blade in an engine.  Expect the engine to be down')

                # Get other engine fqdn
                readFqdn = getAnotherInserviceEngine(fqdn)

                # If we found something, then update peer data
                if readFqdn: ClusterMemberData['peer'] = getEnginePeerData(readFqdn)
                else:
                        print('WARNING: it seems the last engine has been removed.  Clearing cluster peer data since it can\'t be read.')
                        for key in list(ClusterMemberData['peer'].keys()): ClusterMemberData[key] = {}

                        # Return from here, as there's nothing else to do
                        return True

        # Get new lists
        procListFinal = getProcessingBlades(readFqdn, mustRead=True)
        mgmtListFinal = getManagementBlades(readFqdn, mustRead=True)
        print('Proc initial list: ' + str(procListInitial))
        print('Proc final list: ' + str(procListFinal))
        print('Mgmt initial list: ' + str(mgmtListInitial))
        print('Mgmt final list: ' + str(mgmtListFinal))

        # What to check depends on what was removed
        if bladeType.lower() == 'management':
                # Management blade list should change on mgmt removal
                if mgmtListInitial == mgmtListFinal:
                        print('ERROR: management blade should change during MGMT blade remove')
                        if not expectError: traceback.print_stack()
                        errorFlag = True

                # Make sure only one proc blade was removed
                if len(procListFinal) != len(procListInitial) - 1:
                        print('ERROR: mgmt blade remove caused unexpected PROC blade impact')
                        if not expectError: traceback.print_stack()
                        errorFlag = True

        elif bladeType.lower() == 'processing':
                # Management blade list should not change on proc removal
                if mgmtListInitial != mgmtListFinal:
                        print('ERROR: management blade should not have changed during PROC blade remove')
                        if not expectError: traceback.print_stack()
                        errorFlag = True

                # Make sure only one proc blade was removed
                if len(procListFinal) != len(procListInitial) - 1:
                        print('ERROR: processing blade remove caused unexpected PROC blade impact')
                        if not expectError: traceback.print_stack()
                        errorFlag = True

                # Make sure the right blade was removed :-)
                if procListFinal.count(bladeId):
                        print('ERROR: processing blade remove did not remove a processing blade...')
                        if not expectError: traceback.print_stack()
                        errorFlag = True
        
        else:   sys.exit('ERROR: unexpected blade type returned: ' + bladeType)
        
        # If a management blade, then need to find the new management blade and wait for the recovery complete message
        if bladeType.lower() == 'management' and not errorFlag:
                # Point to new management blade
                newMgmtFqdn = engineId + fqdnSeparator + clusterId + fqdnSeparator + str(mgmtListFinal[0])
                
                # Wait for recovery (or timeout)
                errorFlag = waitForMgmtRecoveryComplete(newMgmtFqdn)
        
        # Run print blade stats -C on active engine
        execPrintBladeStats(readFqdn, '-C')
                
        # What to return depends on expected failure setting
        if expectError == errorFlag:
                # Update global data
                if not expectError: ClusterMemberData[engineId] = getEngineClusterData(readFqdn)
                
                return True
        else:   return False
        
# =================== Process Any Query - return single desired field ====================
def getAndProcessSnmpFieldQuery(query, fqdn, field, bucket1='0', bucket2=None):
        retDict = getAndProcessSnmpQuery(query, fqdn)
        if not retDict:
                print('Query of ' + query + ' returned nothing.')
                return None
        
        # Return field value if present, else None
        if bucket1:
                if bucket2: dataToCheck = copy.deepcopy(retDict[bucket1][bucket2])
                else:       dataToCheck = copy.deepcopy(retDict[bucket1])
        else:               dataToCheck = copy.deepcopy(retDict)
        
        # If user entered the full string, then remove the common part that's not included in the stored data
        fullField = field
        if field.startswith(snmpQuery[query]['string']): field = field[len(snmpQuery[query]['string']):]
                        
        # Finally get to the field check....
        if field in dataToCheck: return dataToCheck[field]
        else:   
                print('Query of ' + query + ' field ' + fullField + ' bucket1 ' + str(bucket1) + ' bucket2 ' + str(bucket2) + ' returned nothing.')
                print(str(dataToCheck))      
                return None
        
# =================== Process Any Query ====================
def getAndProcessSnmpQuery(query, fqdn):
        queryOut = getSnmpQuery(query, fqdn)
        
        retDict = processSnmpQuery(query, queryOut)
        
        return retDict
        
#==================================================================
def getSnmpQuery(query, fqdn):
        global snmpQuery
        
        # Get the engine ID
        engineIp = getEngineIp(fqdn)

        # Get the port ID
        portId = snmpQuery['port']

        # Query
        cmd = 'snmpwalk -Os -v 2c -c public -OQ '
        cmd += engineIp + fqdnSeparator + portId
        cmd += ' MATRIXX-MIB::' + query
        queryOut = runCmd(cmd).split('\n')
        
        return queryOut

#==================================================================
def startBlade(fqdn, dictionary = {}, expectError = False, background=False, addExcluded=False):
        # Can pass in the desired dictionary.
        if dictionary:  lclDct = copy.deepcopy(dictionary)
        else:           lclDct = getEngineClusterData(fqdn)
        
        # Get IDs
        engineId = fqdn.split(fqdnSeparator)[0]
        clusterId = fqdn.split(fqdnSeparator)[1]
        bladeId  = fqdn.split(fqdnSeparator)[2]
        
        # Check that the blade is not already active
        bladeData = getProcessingBlades(lclDct)
        bladeData.extend(getManagementBlades(lclDct))
        print('start blade: list of inservice blades = ' + str(bladeData))
        
        # Minor sanity check...
        if int(bladeId) in bladeData:
                print('WARNING: trying to start blade ' + str(bladeId) + ' that\'s already in service.')
        
        # See if we should handle exclusion
        if addExcluded:
                # Get exclusion list.
                # Need to query on an inservice blade on the same engine
                exFqdn = engineId + fqdnSeparator + clusterId + fqdnSeparator + str(bladeData[0])
                exclusionList = getExcludeList(exFqdn)
        
                # See if the blade ID is exlucded
                if fqdn in exclusionList:
                        print('WARNING: blade ' + fqdn + ' is in the exclusion list: ' + str(exclusionList) + '.  Will clear the list first.')
                        if not clearExcludeList(exFqdn): return False

        # Execute command to start the blade
        print('Will start blade ' + str(fqdn))
        cmd = 'start_blade.py -b ' + bladeId + ' -e ' + engineId
        if background: cmd = 'nohup ' + cmd + ' > /dev/null 2>&1  &'
        retCode = runSshCmd(fqdn, cmd)

        # Return true at this point, as this API doesn't verify anything
        return True

#==================================================================
def stopBlade(fqdn, dictionary = {}, expectError=False, processToKill = None, background=False):
        # No errors
        errorFlag = False
        
        # Can pass in the desired dictionary.
        if dictionary:  lclDct = copy.deepcopy(dictionary)
        else:           lclDct = getEngineClusterData(fqdn)
        
        # Sanity check that the dictionary is not empty
#       print 'stopBlade, lclDct = ' + str(lclDct)
        if not lclDct: sys.exit('ERROR: stopBlade, empty dictionary')

        # Get lists
        procList = getProcessingBlades(lclDct)
        mgmtList = getManagementBlades(lclDct)
        
        # Get engine and blade IDs
        engineId = fqdn.split(fqdnSeparator)[0]
        bladeId  = fqdn.split(fqdnSeparator)[2]
        
        # Want to stop by expicit blade #.
        # Sanity check that we have this.
        id = int(bladeId)
        if   id in mgmtList:
                print('Will stop management blade ' + str(id))
        elif id in procList:
                print('Will stop processing blade ' + str(id))
        else: 
                print('WARNING: blade '+ str(id) + ' not in the engine')
                if not expectError: traceback.print_stack()
                if expectError: return True
                else:           return False
        
        # Execute command to stop the blade
        if not processToKill: 
                cmd = 'stop_blade.py -b '+ str(id) + ' -e ' + engineId
                if background: cmd = 'nohup ' + cmd + ' > /dev/null 2>&1  &'
                retCode = runSshCmd(fqdn, cmd)
        else:
                # Get pid for process
                cmd = 'ps aux | grep ' + processToKill + ' | grep -v grep | cut -c10-15'
                pid = runSshCmd(fqdn,cmd)

                # Make sure we got a pid back...
                if not pid:
                        print('ERROR: did not find a ' + processToKill + ' PID on engine ' + lclFqdn)
                        return False

                # Kill that process
                cmd = 'kill -9 ' + pid
                if background: cmd = 'nohup ' + cmd + ' > /dev/null 2>&1  &'
                retCode = runSshCmd(fqdn, cmd)

                # Sleep until all processes are dead
                timeToSleep = QAUTILS.gatewaysConfig.get('HA','postProcessKillUntilAllProcessesDie')
                print('Sleeping ' + timeToSleep + ' seconds to let blade processes terminate')
                time.sleep(int(timeToSleep))
        
        # Return true at this point, as this API doesn't verify anything
        return True
        
#==================================================================
def getActiveManagementBlade(fqdn, waitFlag=False, mustRead=False):
        if mustRead:
                data = getEngineClusterData(fqdn)
        else:   data = copy.deepcopy(fqdn)
        
        return getBladeList(data, 'active', 'management', 'equal', waitFlag=waitFlag)

#==================================================================
def getNonActiveManagementBlade(fqdn, waitFlag=False):
        return getBladeList(fqdn, 'active', 'management', 'not_equal', waitFlag=waitFlag)

#==================================================================
def getManagementBlades(fqdn, waitFlag=False, mustRead=False):
        if mustRead:
                data = getEngineClusterData(fqdn)
        else:   data = copy.deepcopy(fqdn)
        
        return getBladeList(data, '', 'management', 'any', waitFlag=waitFlag)

#==================================================================
def getProcessingBlades(fqdn, waitFlag=False, mustRead=False):
        if mustRead:
                data = getEngineClusterData(fqdn)
        else:   data = copy.deepcopy(fqdn)
        
        return getBladeList(data, '', 'processing', 'any', waitFlag=waitFlag)

#==================================================================
def getActiveProcessingBlades(fqdn, waitFlag=False, mustRead=False):
        if mustRead:
                data = getEngineClusterData(fqdn)
        else:   data = copy.deepcopy(fqdn)
        
        return getBladeList(data, 'active', 'processing', 'equal', waitFlag=waitFlag)

#==================================================================
def getActiveSyncProcessingBlades(fqdn, waitFlag=False):
        return getBladeList(fqdn, 'active-sync', 'processing', 'equal', waitFlag=waitFlag)

#==================================================================
def getNonActiveProcessingBlades(fqdn, waitFlag=False):
        return getBladeList(fqdn, 'active', 'processing', 'not_equal', waitFlag=waitFlag)

#==================================================================
def getAllBlades(fqdn, waitFlag=False, mustRead=False):
        if mustRead:
                data = getEngineClusterData(fqdn)
        else:   data = copy.deepcopy(fqdn)
        
        return getBladeList(data, 'any', 'any', waitFlag=waitFlag)
        
#==================================================================
def getAllActiveBlades(fqdn, waitFlag=False, mustRead=False):
        if mustRead:
                data = getEngineClusterData(fqdn)
        else:   data = copy.deepcopy(fqdn)

        return getBladeList(data, 'active', 'any', 'equal', waitFlag=waitFlag)
        
#===============================================================================
# This function is used to run bash scripts on a target server
def runSshCmd(fqdn, cmd):
        # Command assume passwordless SSH.
        # Also assumes the engine IPs are in the SSH file (so we don't get prompted for adding them)
        
        # Get IP address from global data
        ipAddr = engineIpData[fqdn]
        
        # Need full paths for ssh.  If the string starts with key MATRIXX strings, then assume MATRIXX command and prefix /opt/mtx/bin
        if cmd.startswith("print_blade") or \
           cmd.startswith("start_engine") or \
           cmd.startswith("stop_engine")  or \
           cmd.startswith("start_blade") or \
           cmd.startswith("stop_blade")  or \
           cmd.startswith("create_config")  or \
           cmd.startswith("load_pricing")  or \
           cmd.startswith("create_checkpoint")  or \
           cmd.startswith("remount")  or \
           cmd.startswith("cluster_")  or \
           cmd.startswith("configure_engine"): cmd = '/opt/mtx/bin/' + cmd
        
        # Build the command
        cmd = 'ssh -A ' + ipAddr +' "' + cmd + '"'
        
        # Run the command
        return runCmd(cmd)
        
#===============================================================================
def createCheckpoint(fqdn):
        # Get engine ID
        engineId = fqdn.split(fqdnSeparator)[0]
        clusterId = fqdn.split(fqdnSeparator)[1]

        # Get the active management blade
        retList = getActiveManagementBlade(fqdn)

        # Make sure we have a mgmt blade...
        if not retList:
                print('ERROR: trying to kill management blade on engine ' + engineId + ', but one is not defined.')
                return False

        # Build local fqdn
        lclFqdn = engineId + fqdnSeparator + clusterId + fqdnSeparator + str(retList[0])
        
        # Define command
        cmd = 'create_checkpoint.py'
        
        # Run the commands
        print('\n' + runSshCmd(lclFqdn,cmd) + '\n')
        
#===============================================================================
def killManagementBlade(fqdn):
        global ClusterMemberData
        
        # Get engine ID
        # Get engine and blade IDs
        engineId  = fqdn.split(fqdnSeparator)[0]
        clusterId = fqdn.split(fqdnSeparator)[1]
        bladeId   = fqdn.split(fqdnSeparator)[2]
        
        # Get the active management blade
        retList = getActiveManagementBlade(fqdn)
        
        # Make sure we have a mgmt blade...
        if not retList:
                print('ERROR: trying to kill management blade on engine ' + engineId + ', but one is not defined.')
                return False,None
        
        # Build local fqdn
        lclFqdn = engineId + fqdnSeparator + clusterId + fqdnSeparator + str(retList[0])
        
        # Stop and verify a blade via kill of the globally configured process
        return stopAndVerifyBlade(lclFqdn, processToKill = globalProcessToKill)
        
#===============================================================================
def killBladeProcess(fqdn, processToKill = globalProcessToKill):
        return stopAndVerifyBlade(fqdn, processToKill=processToKill)

#===============================================================================
def verifyEngineStatus(fqdn, status='active', waitFlag=False):
        global ClusterMemberData
        
        # Get engine ID
        engineId = fqdn.split(fqdnSeparator)[0]
        
        # Sanity check the global data
        if (engineId not in ClusterMemberData['peer']) or ('HaState' not in ClusterMemberData['peer'][engineId]):
                print('ERROR: cluser global data not fully populated for engine ' + engineId)
                print(str(ClusterMemberData))
                traceback.print_stack()
                return False
        
        # If we're waiting for a state, then need config variables
        if waitFlag:
                totalTime =  int(QAUTILS.gatewaysConfig.get('HA','engineStatus'))
                sleepTime = int(QAUTILS.gatewaysConfig.get('HA','timeBetweenRetries'))
        else:   
                totalTime = 1
                sleepTime = 2
        
        # Loop waiting for state
        i = 0
        while i <= totalTime:
                # Break if we found the desired state
                if ClusterMemberData['peer'][engineId]['HaState'].lower() == status.lower(): break
                
                # Bump counter
                i += sleepTime
        
                # Sleep unless last loop
                if i <= totalTime:
                        print('verifyEngineStatus: sleeping ' + str(sleepTime) + ' seconds: ' + str(i) + ' out of ' + str(sleepTime) + ' total')
                        time.sleep(sleepTime)
        
        # Return true if we broke early
        return (i <= totalTime)
        
#===============================================================================
def haSetup(thread=False):
        global threadFlag
        
        # Store thread value in global
        threadFlag = thread
        
        # If QA utils not yet initialized, then do that here
        if not QAUTILS.gatewaysConfig: QAUTILS.gatewaysConfig = QAUTILS.getDiameterRestConfig()
        
        # Parse create_config for engine to IP mappings
        parseCreateConfig()
        
        # Initialize cluster data
        initClusterData()
        
        # Initialize SNMP data
        initSnmpData()
        
#================== Main function  ================================================
def main():
    global ClusterMemberData
    
    # Setup data
    haSetup(True)
    
    engine = 'active'
    blade = 'processing'
    fqdn = convertEngineAndBladeStatusToFqdn(engine, blade=blade, bladeRelative='highest')
    if fqdn == '0':
        print('convertEngineAndBladeStatusToFqdn returned failure')
        sys.exit('Exiting early')
    query = 'sysQueueStatsEntry'
    field = 'sysQueueStatsServiceId'
    retValue = getAndProcessSnmpFieldQuery(query, fqdn, field, 'transaction', '0')
    if not retValue:
        print('getAndProcessSnmpFieldQuery did not return a value for query/field ' + query + '/' + field)
        print() 
        sys.exit('Exiting early')
    else: print('returned value ' + retValue)

    sys.exit('Exiting early')
    
    # ***********  engine upgrade *************
    specialItemList = {}
#    specialItemList['rpm'] = '/home/mtx/kef/matrixxsw-engine-4530-build_20140901_031113.x86_64.rpm'
#    specialItemList['pricing'] = '/home/mtx/kef/mtx_pricing_Swisscom_v3_20131224053752.xml'
    specialItemList['rpm'] = 'Default'
    specialItemList['custom'] = '/home/mtx/kef/hp1_cust_1engine.tgz'
    specialItemList['pricing'] = 'default'
    specialItemList['checkpoint'] = '/home/mtx/kef/hp1_chkpt_1engine.tgz'
    fqdn = None
#    engine = 'active'
#    fqdn = convertEngineAndBladeStatusToFqdn(engine)
#    if fqdn == '0':
#       print 'convertEngineAndBladeStatusToFqdn returned failure'
#       sys.exit('Exiting early')
    print('engine ' + str(fqdn) + ' upgrade with everything applied')
    specialItemList = {}
    retCode = engineUpgrade(fqdn, specialItemList)
    if not retCode: 
        print('engineUpgrade returned failure')
        sys.exit('Exiting early')
    
    sys.exit('Exiting early')
    
    # ***********  kill processing blade, show blade/engine expectError, clear exclusion, then engine start *************
    engine = 'active'
    blade = 'processing'
    fqdn = convertEngineAndBladeStatusToFqdn(engine, blade=blade, bladeRelative='highest')
    if fqdn == '0':
        print('convertEngineAndBladeStatusToFqdn returned failure')
        sys.exit('Exiting early')
    retCode = killBladeProcess(fqdn)
    if not retCode: 
        print('killBladeProcess returned failure')
        sys.exit('Exiting early')
    (retCode, newFqdn) = startAndVerifyBlade(fqdn, expectError=True)
    if not retCode: 
        print('startAndVerifyBlade returned failure')
        sys.exit('Exiting early')
    engine = 'active'
    blade = 'management'
    fqdn = convertEngineAndBladeStatusToFqdn(engine, blade=blade)
    if fqdn == '0':
        print('convertEngineAndBladeStatusToFqdn returned failure')
        sys.exit('Exiting early')
    (retCode, engineId) = startAndVerifyEngine(fqdn, expectError=True)
    if not retCode: 
        print('startAndVerifyEngine returned failure')
        sys.exit('Exiting early')
    
    engine = 'active'
    blade='management'
    fqdn = convertEngineAndBladeStatusToFqdn(engine, blade=blade)
    if fqdn == '0':
        print('convertEngineAndBladeStatusToFqdn returned failure')
        sys.exit('Exiting early')
    exList = getExcludeList(fqdn)
    if not exList:
        print('getExcludeList returned bad data: ' + str(exList))
        sys.exit('Exiting early')
    retCode = clearExcludeList(fqdn)
    if not retCode: 
        print('clearExcludeList returned failure')
        sys.exit('Exiting early')
    (retCode, engineId) = startAndVerifyEngine(fqdn)
    if not retCode: 
        print('startAndVerifyEngine returned failure')
        sys.exit('Exiting early')
    
    sys.exit('Exiting early')
    
    engine = 'active'
    blade='processing'
    fqdn = convertEngineAndBladeStatusToFqdn(engine, blade=blade)
    if fqdn == '0':
        print('convertEngineAndBladeStatusToFqdn returned failure')
        sys.exit('Exiting early')
    for query in ['chrgNotificationSendTryStatsEntry', 'diamPduStatsEntry']:
        print('query blade ' + fqdn + ' for query ' + query)
        retData = getAndProcessSnmpQuery(query, fqdn)
        print('Query = ' + query + ': ')
        for key1 in list(retData.keys()):
                print('Key ' + key1 + ': ')
                print(str(retData[key1]))
    #sys.exit('Exiting early')
    
    # ***********  kill management blade *************
    engine = 'active'
    blade = 'management'
    fqdn = convertEngineAndBladeStatusToFqdn(engine, blade=blade)
    if fqdn == '0':
        print('convertEngineAndBladeStatusToFqdn returned failure')
        sys.exit('Exiting early')
    retCode = killManagementBlade(fqdn)
    if not retCode: 
        print('killManagementBlade returned failure')
        sys.exit('Exiting early')
    (retCode, newFqdn) = startAndVerifyBlade(fqdn, expectError=True)
    if not retCode: 
        print('startAndVerifyBlade returned failure')
        sys.exit('Exiting early')
    
    #sys.exit('Exiting early')
    
    # ***********  clear exclusion and start blade *************
    engine = 'active'
    blade='management'
    fqdn = convertEngineAndBladeStatusToFqdn(engine, blade=blade)
    if fqdn == '0':
        print('convertEngineAndBladeStatusToFqdn returned failure')
        sys.exit('Exiting early')
    exList = getExcludeList(fqdn)
    if not exList:
        print('getExcludeList returned bad data: ' + str(exList))
        sys.exit('Exiting early')
    retCode = clearExcludeList(fqdn)
    if not retCode: 
        print('clearExcludeList returned failure')
        sys.exit('Exiting early')
        
    (retCode, newFqdn) = startAndVerifyBlade('1:1:1')
    if not retCode: 
        print('startAndVerifyBlade returned failure')
        sys.exit('Exiting early')
    
    #sys.exit('Exiting early')
    
    # ***********  Stop/Start blade  *************
    engine = 'active'
    blade='processing'
    fqdn = convertEngineAndBladeStatusToFqdn(engine, blade=blade)
    if fqdn == '0':
        print('convertEngineAndBladeStatusToFqdn returned failure')
        sys.exit('Exiting early')
    print('Stopping balde ' + fqdn)
    retCode = stopAndVerifyBlade(fqdn)
    if not retCode: 
        print('stopAndVerifyBlade returned failure')
        sys.exit('Exiting early')
        
    (retCode, newFqdn) = startAndVerifyBlade(fqdn)
    if not retCode: 
        print('startAndVerifyBlade returned failure')
        sys.exit('Exiting early')
    
    #sys.exit('Exiting early')
    
    # ***********   Engine Status APIs  *************
    print('Executing Engine Status APIs')
    engine = 'active'
    blade = 'management'
    fqdn = convertEngineAndBladeStatusToFqdn(engine, blade=blade)
    if fqdn == '0':
        print('convertEngineAndBladeStatusToFqdn returned failure')
        sys.exit('Exiting early')
    print('Engine active check, with wait: ' + str(verifyEngineStatus(fqdn, status='active', waitFlag=True)))
    #print 'Engine standby check, with wait: ' + str(verifyEngineStatus(fqdn, status='standby', waitFlag=True))
#    sys.exit('Exiting early')
    
    # ***********   getXXBlade APIs  *************
    print('Executing getXXBlade APIs')
    engine = 'active'
    blade = 'management'
    fqdn = convertEngineAndBladeStatusToFqdn(engine, blade=blade)
    if fqdn == '0':
        print('convertEngineAndBladeStatusToFqdn returned failure')
        sys.exit('Exiting early')
    print('Active managemnet blades: ' + str(getActiveManagementBlade(fqdn)))
    print('Active processing blades: ' + str(getActiveProcessingBlades(fqdn)))
    print('All blades: ' + str(getAllBlades(fqdn)))
    #print 'Active sync blades with wait: ' 
    #print str(getActiveSyncProcessingBlades(fqdn, waitFlag=True))

    # ***********   Pricing stuff  *************
    print('Executing processPricing')
    engine = 'active'
    blade = 'management'
    fqdn = convertEngineAndBladeStatusToFqdn(engine, blade=blade)
    if fqdn == '0':
        print('convertEngineAndBladeStatusToFqdn returned failure')
        sys.exit('Exiting early')
    sourceData = 'default'
    retCode = processPricing(fqdn, sourceData)
    if not retCode:
        print('processPricing returned failure')
        sys.exit('Exiting early')
    
    #sys.exit('Exiting early')
    
    # ***********  roll engine  *************
    specialItemList = {}
    specialItemList['rpm'] = 'Default'
    engine = 'active'
    fqdn = convertEngineAndBladeStatusToFqdn(engine)
    if fqdn == '0':
        print('convertEngineAndBladeStatusToFqdn returned failure')
        sys.exit('Exiting early')
    print('roll upgrade ' + fqdn + ' with RPM applied')
    retCode = rollingUpgrade(fqdn, specialItemList)
    if not retCode: 
        print('rollUpgrade returned failure')
        sys.exit('Exiting early')
    
    #sys.exit('Exiting early')
    
    # ***********  Get/Clear exclusion *************
    engine = 'active'
    blade = 'processing'
    fqdn = convertEngineAndBladeStatusToFqdn(engine, blade=blade)
    retCode = killBladeProcess(fqdn)
    if not retCode: 
        print('killBladeProcess returned failure')
        sys.exit('Exiting early')
    
    newFqdn = getAnotherActiveBlade(fqdn)
    if not newFqdn:
        print('getAnotherActiveBlade returned no active blades')
        sys.exit('Exiting early')
    
    exList = getExcludeList(newFqdn)
    if not exList:
        print('getExcludeList returned bad data: ' + str(exList))
        sys.exit('Exiting early')
    retCode = clearExcludeList(newFqdn)
    if not retCode: 
        print('clearExcludeList returned failure')
        sys.exit('Exiting early')
        
    (retCode, newFqdn) = startAndVerifyBlade(fqdn)
    if not retCode: 
        print('startAndVerifyBlade returned failure')
        sys.exit('Exiting early')
    
    sys.exit('Exiting early')
    
    # ***********  Stop blade w/quorum lost error *************
    engine = 'active'
    blade='processing'
    fqdn = convertEngineAndBladeStatusToFqdn(engine, blade=blade)
    if fqdn == '0':
        print('convertEngineAndBladeStatusToFqdn returned failure')
        sys.exit('Exiting early')
    print('Stopping blade ' + fqdn)
    retCode = stopAndVerifyBlade(fqdn, expectError=True)
    if not retCode: 
        print('stopAndVerifyBlade returned failure')
        sys.exit('Exiting early')
        
    (retCode, newFqdn) = startAndVerifyEngine(fqdn)
    if not retCode: 
        print('startAndVerifyEngine returned failure')
        sys.exit('Exiting early')
    
    #sys.exit('Exiting early')
    
    # ***********  roll engine  *************
    specialItemList = {}
    specialItemList['rpm'] = '/home/mtx/kef/matrixxsw-engine-4530-Ming_Wen.Sung_20140902_114327.x86_64.rpm'
    engine = 'active'
    fqdn = convertEngineAndBladeStatusToFqdn(engine)
    print('roll engine ' + fqdn + ' with RPM applied')
    retCode = rollEngine(fqdn, specialItemList)
    if not retCode: 
        print('rollEngine returned failure')
        sys.exit('Exiting early')
    
    sys.exit('Exiting early')
    
    # ***********  Stop/Start engine  *************
    engine = 'active'
    fqdn = convertEngineAndBladeStatusToFqdn(engine)
    print('Stopping engine ' + fqdn)
    retCode = stopAndVerifyEngine(fqdn)
    if not retCode: 
        print('stopEngine returned failure')
        sys.exit('Exiting early')
    
        
    retCode = startAndVerifyEngine(fqdn)
    if not retCode: 
        print('startAndVerifyEngine returned failure')
        sys.exit('Exiting early')
    
    sys.exit('Exiting early')
    
    # ***********  Stop/Start blade  *************
    engine = 'active'
    blade='processing'
    fqdn = convertEngineAndBladeStatusToFqdn(engine, blade=blade)
    print('Stopping balde ' + fqdn)
    retCode = stopAndVerifyBlade(fqdn)
    if not retCode: 
        print('stopBlade returned failure')
        sys.exit('Exiting early')
    
        
    (retCode, newFqdn) = startAndVerifyBlade(fqdn)
    if not retCode: 
        print('startAndVerifyBlade returned failure')
        sys.exit('Exiting early')
    
    sys.exit('Exiting early')
    
    # ***********  Need engine out to do RPM/Checkpoint work  *************
    fqdn = '1:1:1'
    print('Executing stopAndVerifyEngine')
    retCode = stopAndVerifyEngine(fqdn)
    if not retCode: 
        print('stopAndVerifyEngine returned failure')
        sys.exit('Exiting early')
    
    # ***********   RPM stuff  *************
#    print 'Executing processRpm'
#    fqdn = '1:1:0'
#    sourceData = '/home/mtx/kef/matrixxsw-engine-4530-Ming_Wen.Sung_20140902_114327.x86_64.rpm'
#    retCode = processRpm(fqdn, sourceData)
#    if not retCode:
#       print 'processRpm returned failure'
#       sys.exit('Exiting early')
    
    # ***********   Checkpoint stuff  *************
    print('Executing processCheckpoint')
    sourceData = '/home/mtx/kef/hp1_chkpt.tgz'
    retCode = processCheckpoint(fqdn, sourceData)
    if not retCode:
        print('processCheckpoint returned failure')
        sys.exit('Exiting early')
    
    # ***********  Restore engine *************
    fqdn = '1:1:1'
    print('Executing startAndVerifyEngine')
    retCode = startAndVerifyEngine(fqdn)
    if not retCode:
        print('startAndVerifyEngine returned failure')
        sys.exit('Exiting early')
    
    sys.exit('Exiting early')
   
    # ***********   Custom stuff  *************
    sourceData = 'hp1_cust.tgz'
    processCustom(sourceData, engine='1')
        
    # ***********   Play with active engine *************
    # Stop engine
    engine = 'active'
    fqdn = convertEngineAndBladeStatusToFqdn(engine)
    engineId = fqdn.split(fqdnSeparator)[0]
    print('\n' + runSshCmd(fqdn,pbs) + '\n')
    #(result, id) = stopAndVerifyEngine(fqdn)
    result = stopBlade(fqdn,background=True)
    if not result: print('ERROR:  did not get expected result from the last command')
    elif str(id) != engineId: print('ERROR:  returned engine ID from stop and verify not equal to the ID passed in.  ' + engineId + ' passed in, ' + str(id) + ' returned')
    print('Wait for 10 sec for stop to finish')
    time.sleep(10)
    
    # Start if we had stopped something
    if id: 
        print('Preparing to start engine ' + str(fqdn))
        (result, id) = startAndVerifyEngine(fqdn)
        (result, id) = startEngine(fqdn, background=True)
        if not result: print('ERROR:  did not get expected result from the last command')
        print('Wait for 10 sec for start to finish')
        time.sleep(10)
        print('\n' + runSshCmd(fqdn,pbs) + '\n')
    sys.exit('Exiting early')
    
    # Get SNMP data
#    snmpAddress = logicalBlade.getMgmtIpAddress()
#    snmpPort = logicalBlade.snmpAgentPort
#    errCode = topology.getSnmpStats(snmpAddress, snmpPort)
#    #print 'errCode = ' + str(errCode)
#    if (errCode):
#        print 'topology.getSnmpStats returned an error'
#        return

    # Stuff that's available in topology.xxx:
    #   snmpStatsSysInfoDictionary
    #   snmpStatsServiceInfoDictionary
    #   snmpStatsChrgNotificationInfoDictionary
    #   snmpStatsChrgNotificationSendTryInfoDictionary
    #   snmpStatsBufferPoolInfoDictionary
    #   snmpStatsTxnDatabaseInfoDictionary
    #   snmpStatsTxnDatabaseSegmentInfoDictionary
    #   snmpStatsTxnDatabaseObjectInfoDictionary
    #   snmpStatsTxnDatabaseIndexInfoDictionary
    #   snmpStatsDiamAppIdCmdCodeInfoDictionary
    #   snmpStatsDiamAppIdCmdCodeResultCodeCountDictionary
    #   snmpStatsDiamTotalInfoDictionary
    #   snmpStatsTaskQueueInfoDictionary
    #   snmpStatsTxnReplayInfoDictionary
    #   snmpStatsTxnInfoDictionary
    #   snmpStatsClusterMemberInfoDictionary
    #   snmpStatsPeerClusterInfoDictionary
    #
    
    # Init threads/queues
    #initThreadsAndQueues()
    
    # Wait for queued stuff to end
    waitForThreadsToEnd()
    
    sys.exit('Exiting early')
    
    engine = 'active'
    killManagementBlade(engine)
    killManagementBlade('5')
    
    restartBladesAll(engine)
    restartBladesNoMgmt(engine)
    # ***********   Verify stuff  *************
    print('act/act  return (pass) = ' + str(verifyEngineStatus(engine='active', status='active')))
    print('act/stby return (fail) = ' + str(verifyEngineStatus(engine='active', status='standby')))
    print('3/unknown return (pass) = ' + str(verifyEngineStatus(engine='3', status='unknown')))
    print('5/unknown return (fail) = ' + str(verifyEngineStatus(engine='5', status='unknown')))
    createCheckpoint('active')
    
    # ***********   Upgrade stuff  *************
    specialInfo = {}
    specialInfo['rpm'] = '/home/mtx/kef/*rpm.gz'
    specialInfo['custom'] = 'hp1_cust.tgz'
    specialInfo['checkpoint'] = 'hp1_chkpt.tgz'
    rollingUpgrade(engine=None, specialInfo=specialInfo)
    engineUpgrade(engine=None, customInfo='hp1_cust.tgz',checkpointInfo='hp1_chkpt.tgz')

    # ***********   Gather Blade status *************
    engine = 'active'
    engineId = getEngineIp(engine)
    # Get active processing blades
    retData = getActiveProcessingBlades(engineId)
    print('Engine = ' + engine + ', Active Processing blades:' + str(retData))

    # Get non-active processing blades
    retData = getNonActiveProcessingBlades(ClusterMemberData[engineId])
    if len(retData): print('Engine = ' + engine + ', non-active Processing blades:' + str(retData))

    # Get active management blade
    retData = getActiveManagementBlade(ClusterMemberData[getEngineIp(engine)])
    print('Engine = ' + engine + ', Active Management blade:' + str(retData))

    # ***********   Play with active engine blades*************
    engine = 'active'
    blade = 'processing'
    cmd = 'print_blade_stats.py -C -e ' + getEngineIp(engine)
    
    print('Preparing to stop engine ' + engine + ' blade type ' + blade)
    print('\n' + runSshCmd(engine,cmd) + '\n')
    (result, id) = stopAndVerifyBlade(engine, blade, ClusterMemberData[getEngineIp(engine)])
    if not result: print('ERROR:  did not get expected result from the last command')
    print('\n' + runSshCmd(engine,cmd) + '\n')
    
    # Start if we had stopped something
    if id: 
        print('Preparing to start engine ' + engine + ' blade type ' + blade + ' ID = ' + str(id))
        (result, newFqdn) = startAndVerifyBlade(engine, id)
        print('\n' + runSshCmd(engine,cmd) + '\n')
        if not result: 
                print('ERROR:  did not get expected result from the last command')
                sys.exit('Exiting because start blade command failed')
    
    # Test error conditions
    print('Preparing to start engine ' + engine + ' blade type ' + blade + ', using previous dictionary showing it active (so should fail)')
    (result, newFqdn) = startAndVerifyBlade(engine, id, ClusterMemberData[getEngineIp(engine)], expectError=True)
    if not result: print('ERROR:  did not get expected result from the last command')
    
    print('Preparing to start engine ' + engine + ' blade type ' + blade + ', that\'s already active (so should fail)')
    (result, newFqdn) = startAndVerifyBlade(engine, id, expectError=True)
    if not result: print('ERROR:  did not get expected result from the last command')
    
    print('Preparing to stop engine ' + engine + ' blade 15 (error - blade ID non-existent)')
    (result, x) = stopAndVerifyBlade(engine, '15', expectError=True)
    if not result: print('ERROR:  did not get expected result from the last command')
        
    # ***********   Play with standby engine blades*************
    engine = 'standby'
    cmd = 'print_blade_stats.py -C -e ' + getEngineIp(engine)
    
    print('Preparing to stop engine ' + engine + ' blade type processing (default)')
    print('\n' + runSshCmd(engine,cmd) + '\n')
    (result, id) = stopAndVerifyBlade(engine)
    if not result: print('ERROR:  did not get expected result from the last command')
    print('\n' + runSshCmd(engine,cmd) + '\n')
    
    # Start if we had stopped something
    if id: 
        print('Preparing to start engine ' + engine + ' blade type ' + blade + ' ID = ' + str(id))
        (result, newFqdn) = startAndVerifyBlade(engine, id)
        print('\n' + runSshCmd(engine,cmd) + '\n')
        if not result: 
                print('ERROR:  did not get expected result from the last command')
                sys.exit('Exiting because start blade command failed')

    # ***********   Play with standby engine *************
    # Stop engine
    engine = 'standby'
    engineId = getEngineIp(engine)
    cmd = 'print_blade_stats.py -C -e ' + engineId
    print('\n' + runSshCmd(engineId,cmd) + '\n')
    (result, id) = stopAndVerifyEngine(engineId)
    if not result: print('ERROR:  did not get expected result from the last command')
    elif str(id) != engineId: print('ERROR:  returned engine ID from stop and verify not equal to the ID passed in.  ' + engineId + ' passed in, ' + str(id) + ' returned')
    engine = 'active'
    engineId = getEngineIp(engine)
    cmd = 'print_blade_stats.py -C -e ' + engineId
    print('\n' + runSshCmd(engineId,cmd) + '\n')
    
    # Start if we had stopped something
    if id: 
        print('Preparing to start engine ' + str(id))
        (result, id) = startAndVerifyEngine(id)
        if not result: print('ERROR:  did not get expected result from the last command')
        print('\n' + runSshCmd(id,cmd) + '\n')
    
    # ***********   Play with active engine *************
    # Stop engine
    engine = 'active'
    engineId = getEngineIp(engine)
    cmd = 'print_blade_stats.py -C -e ' + engineId
    print('\n' + runSshCmd(engineId,cmd) + '\n')
    (result, id) = stopAndVerifyEngine(engineId)
    if not result: print('ERROR:  did not get expected result from the last command')
    elif str(id) != engineId: print('ERROR:  returned engine ID from stop and verify not equal to the ID passed in.  ' + engineId + ' passed in, ' + str(id) + ' returned')
    engine = 'active'
    engineId = getEngineIp(engine)
    cmd = 'print_blade_stats.py -C -e ' + engineId
    print('\n' + runSshCmd(engineId,cmd) + '\n')
    
    # Start if we had stopped something
    if id: 
        print('Preparing to start engine ' + str(id))
        (result, id) = startAndVerifyEngine(id)
        if not result: print('ERROR:  did not get expected result from the last command')
        print('\n' + runSshCmd(id,cmd) + '\n')
    
    #sys.exit()


if __name__ ==  '__main__':
    main()

