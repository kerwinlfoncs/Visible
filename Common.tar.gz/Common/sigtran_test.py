#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:47
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:27
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:07
#===============================================================================
#
# Copyright 2016-2019, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
import os
import subprocess
import shutil
import socket
import atexit
import signal
from time import sleep
import common_mdc as COMMON
import qa_utils


_QADIR=os.environ['QADIR']
defaultBindAddress="127.0.0.1"
defaultM3uaPort=2905
defaultNodeType='client'
defaultOpc=401
defaultDpc=402
defaultMinPeers=1
controlHost="localhost"
controlPort=29700-1
K8S_CTL="k8s:"
K8S_POD="pod/"
K8S_SVC="svc/"

ignoreThese=dict()
subProcessPipes=dict()
sockets=None
testNames=dict()
pods=dict()
hlrInst=None

#===============================================================================
#===============================================================================
#  Test API Functions
#===============================================================================

#===============================================================================
def sigtranTest(callsPerSec=1, testDurationInSecs=1, scenario="TestCall", imsi="10", imsiRange=1,
                camelVersion=2, additionalConfigOptions=None, paramsToIgnore=None, testName=None):
    '''This function configures and invokes the sigtranTest tool to launch SIGTRAN based call(s)
    into the CAMEL Gateway via the Network Enabler(s), both of which need to be running for the call
    to succeed. Returns True if scenario was successful.'''

    return _sigtranTest(callsPerSec, testDurationInSecs, scenario, imsi, imsiRange,
                camelVersion, additionalConfigOptions, paramsToIgnore, nameOfTest=testName)

#===============================================================================
def sigtranTestStart(callsPerSec=1, testDurationInSecs=1, scenario="TestCall", imsi="10", imsiRange=1,
                camelVersion=3, additionalConfigOptions=None, paramsToIgnore=None, testName=None):
    '''This function configures and invokes the sigtranTest tool to start to launch SIGTRAN based call(s)
    into the CAMEL Gateway via the Network Enabler(s), both of which need to be running for the call
    to succeed. If running multiple instances concurrently make sure testName is different for each.
    Returns reference to instance of sigtranTest tool'''

    return _sigtranTest(callsPerSec, testDurationInSecs, scenario, imsi, imsiRange,
                camelVersion, additionalConfigOptions, paramsToIgnore, commandable=True, nameOfTest=testName)

#===============================================================================
def waitForIndication(sigtranTestInst, expected=None, allowUnexpected=True, quitOnUnallowedUnexpected=True):
    '''Blocks waiting for Indication from supplied instance of sigtranTest tool.
    Only "expected" indication(s) will be returned. If "allowNonExpected" is True
    then non-expected results will be allowed but not returned, otherwise
    non-expected results will cause None to be returned. If "expected" is None
    then the next indication will be returned whatever it is
    If "quitOnUnallowedUnexpected" is True and"allowUnexpected" is True then any unexpected indication
    will cause the quit command to be issued and the control connection will be closed.'''

    #python3 fix
    indication = sockets[sigtranTestInst].recv(1024).decode('utf-8').rstrip().split(":")
    if (not expected):
        return indication
    if (type(expected) is not list):
        expected = [expected]
    while (indication[0] not in expected):
        #print "RECEIVED: ",indication
        if (not allowUnexpected):
            if (quitOnUnallowedUnexpected):
                sendInstruction(sockets[sigtranTestInst],'quit')
            return None
        # Wait for next indication
        indication = sockets[sigtranTestInst].recv(1024).decode('utf-8')
    return indication

#===============================================================================
def sendInstruction(sigtranTestInst, instruction="quit"):
    '''Sends instructioni (String) to supplied instance of sigtranTest tool.
    If "instruction" is "end" or "quit" this function will block until
    sigtranTest tool has closed and returns True if scenario was successful.'''

    #print( "SENDING: ",instruction)
    if (instruction):
        #python3 fix
        sockets[sigtranTestInst].sendall(bytes(instruction+"\n","utf-8"))
        if (instruction=="end" or instruction=="quit"):
            res = subProcessPipes[sigtranTestInst].wait()
            subProcessPipes[sigtranTestInst] = None
            #print"Got RES="+str(res)
            _processSigtranResults(testNames[sigtranTestInst], ignoreThese[sigtranTestInst], pods[sigtranTestInst])
            return True if res == 0 else False
    return None

#===============================================================================
def sigtranTestStartHlr(additionalConfigOptions=None, paramsToIgnore=None, testName=None):
    '''This function configures and invokes the sigtranTest tool to start and simulate an HLR to which
    the CAMEL Gateway can connect via the Network Enabler(s).
    If will continue to run until the invoking script is completed/exited or sigtranTestStopHlr() is called'''

    hlrConfigOptions = ['map.hlr=true', 'alwaysLog=true']
    if additionalConfigOptions is not None:
        hlrConfigOptions.extend(additionalConfigOptions)
    global hlrInst
    hlrInst = _sigtranTest(None, None, 'HLR', additionalConfigOptions=hlrConfigOptions, commandable=True,
                        paramsToIgnore=paramsToIgnore, nameOfTest=testName)


#===============================================================================
def sigtranTestStopHlr():
    '''This function stops a simulated HLR previously started with sigtranTestStartHlr()
    and writes the results to the results directory'''

    os.kill(subProcessPipes[hlrInst].pid, signal.SIGTERM)
    os.waitpid(subProcessPipes[hlrInst].pid, 0)
    subProcessPipes[hlrInst] = None
    _processSigtranResults(testNames[hlrInst], ignoreThese[hlrInst], pods[hlrInst])


#===============================================================================
#===============================================================================
#  Internal Functions
#===============================================================================
#===============================================================================

#===============================================================================
def _sigtranTest(callsPerSec=1, testDurationInSecs=1, scenario="TestCall", imsi="10", imsiRange=1,
                camelVersion=3, additionalConfigOptions=None, paramsToIgnore=None,
                nodeType=None, opc=None, sigtranDestinationIpAddresses=None, bindAddress=None, dpc=None, minPeers=None,
                commandable=False, nameOfTest=None):
    ''' Actually used to run sigtranTest tool script/binary'''

    sigtranTestDir=_QADIR + "/SCP/Tools/sigtranTest/"
    sigtranTestBin=sigtranTestDir + "sigtranTest"

    if nameOfTest is None:
        nameOfTest = os.path.basename(os.getcwd())

    (sigtranDestinationIpAddresses, bindAddress, nodeType, opc, dpc, minPeers) = _config(
        sigtranDestinationIpAddresses, bindAddress, nodeType, opc, dpc, minPeers)
    # print "CONFIG:", sigtranDestinationIpAddresses, bindAddress, nodeType, opc, dpc, minPeers
    k8sPod = None
    if sigtranDestinationIpAddresses[0].startswith(K8S_CTL):
        k8sPod = sigtranDestinationIpAddresses[0].replace(K8S_CTL, "")
        cmd = [ "kubectl", "get", "pod",  k8sPod, "--template={{.status.podIP}}" ]
        global controlHost
        controlHost = subprocess.check_output(cmd)
        cmd = [ "kubectl", "exec", k8sPod, "sigtranTest", "k8s" ]
        opts = additionalConfigOptions
        additionalConfigOptions = [ "minPeers=" + str(minPeers) ]
        additionalConfigOptions.extend(opts)
    else:
        # Copy files.  If anything copied, then do edits, else leave as-is.
        if not _copySigtranTestConfigFiles():
            print('NOTE: reusing existing sigtran config files.  No templates were copied.')
        _sigtranClient(sigtranDestinationIpAddresses, bindAddress, nodeType, opc, dpc, minPeers)
        cmd = [sigtranTestBin, 'qa']
    if callsPerSec is None or testDurationInSecs is None:
        cmd.extend([ scenario ])
    else:
        cmd.extend([str(callsPerSec), str(testDurationInSecs), scenario, 'imsiRange.start='+str(imsi),
             'imsiRange.size='+str(imsiRange), 'camel.version='+str(camelVersion)])

    try:
        logTcapPrimitives = qa_utils.getDiameterRestConfig().get('SIGTRAN', 'logTcapPrimitives')
    except:
        logTcapPrimitives = "true"
    cmd.extend(['logTcapPrimitives=' + logTcapPrimitives])

    if additionalConfigOptions is not None:
        cmd.extend(additionalConfigOptions)

    if not commandable:
        res = subprocess.call(cmd) # waits to end
        print('sigtranTest result',res)
        _processSigtranResults(nameOfTest, paramsToIgnore, k8sPod)
        return True if res == 0 else False
    else:
        global controlPort
        controlPort += 1
        testNames[controlPort] = nameOfTest
        ignoreThese[controlPort] = paramsToIgnore
        pods[controlPort] = k8sPod
        cmd.extend(["controlPort="+str(controlPort)])
        subProcessPipes[controlPort] = subprocess.Popen(cmd)
        global sockets
        if not sockets:
            sockets = dict()
            atexit.register(_killSubProcesses)
        if k8sPod is not None:
           # wait for any previous exectution on pod to die
           sleep(0.5)
        sockets[controlPort] = _openControlSocket(controlPort)
        return controlPort

#===============================================================================
def _killSubProcesses():
    '''Make sure any active subprcesses are killed'''
    for port, subProcessPipe in list(subProcessPipes.items()):
        if subProcessPipe:
            print("Killing subprocess "+str(subProcessPipe.pid)+" on port "+str(port))
            os.kill(subProcessPipe.pid, signal.SIGTERM)


#===============================================================================
def _openControlSocket(port):
    '''Open an control socket to the sigtranTest tool'''
    controlSock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    tries = 0
    while (tries < 30):
        try:
            controlSock.connect((controlHost, port))
            return controlSock
        except:
            sleep(0.2)
        tries += 1
    controlSock.close()
    return None

#===============================================================================
def _processSigtranResults(testName, additionalParamsToIgnore, k8sPod=None):
    '''Processes sigtranTest tool's ouput files for results directory'''

    outFile="sigtranTest.out"
    path = os.getcwd()
    resultsDir= path + '/' + COMMON.resultsDir + '/'
    resultsFilename="ECT_sigtran_"+testName+".txt"
    resultsFile=resultsDir+resultsFilename
    allMdcFilesListFile=resultsDir+"allMdcFilesList"

    if k8sPod is not None:
        # bring results file back from pod
        f = open(outFile, "w")
        cmd = [ "kubectl", "exec", k8sPod, "cat", outFile ]
        res = subprocess.call(cmd, stdout=f)
        f.close()

    # Process operation output file and copy into results directory and remove variable params
    #prettyPrintOutput(outFile, resultsFile)
    shutil.copyfile(outFile, resultsFile)
    _removeECTsigtranVariableParams(resultsFile, additionalParamsToIgnore)

    # Add to allMdcFilesList file
    with open(allMdcFilesListFile, "a") as allMdcFilesList:
        allMdcFilesList.write(resultsFile+"\n")

#===============================================================================
def _removeECTsigtranVariableParams(resultsFile, additionalParamsToIgnore=None):
    ''' Remove parameters that are always variable from supplied operations file'''

    variableParamsToRemove=[ 'year', 'month', 'day', 'hour', 'minute', 'second', 'timeZone', 'imsiDigits']

    if additionalParamsToIgnore is not None:
        variableParamsToRemove.extend(additionalParamsToIgnore)

    sedCmd = ["sed", "-i"]

    for param in variableParamsToRemove:
        sedCmd.append("-e")
        if "." in param:
            params=param.split(".")
            sedCmd.append(r"/"+params[0]+"=/,/\]/s/\( "+params[1]+"=\).*/\\1____/g")
        else:
            sedCmd.append(r"s/\( "+param+"=\).*/\\1____/g")

    # correlationID is more complex to process
    cIdSection=r"/correlationID=Digits/,/\]/"
    sedCmd.append("-e")
    sedCmd.append(cIdSection + r"s/hexData={.*}/hexData={ ____ }/")
    sedCmd.append("-e")
    sedCmd.append(cIdSection + r"s/^\( *\)[0-9]*$/\1____/")
    sedCmd.append("-e")
    sedCmd.append(cIdSection + r"s/\([ao]dd....\)=[0-9]*/\1=____/")

    sedCmd.append(resultsFile)
    subprocess.call(sedCmd)

#===============================================================================
def _copySigtranTestConfigFiles():
    '''If not defined locally copy site defined sigtranTest config files'''

    srcDir =  _QADIR + "/Common/sigtran/"
    dirs = os.listdir(srcDir)

    # Copy files
    copyFlag = False
    for srcFile in dirs:
        if srcFile.startswith("qa") or srcFile.startswith("mtx_config.properties"):
            if (not os.path.isfile(srcFile)):
                # print 'copy file ' + srcDir+srcFile + ' to dir ' +  path
                shutil.copyfile(srcDir+srcFile, srcFile)
                copyFlag = True
    return copyFlag

#===============================================================================
def _config(sigtranDestinationIpAddresses=None, bindAddress=None, nodeType=None, opc=None, dpc=None, minPeers=None):
    '''Config defined based on supplied info or from Common/config.ini file'''

    gatewaysConfig = qa_utils.getDiameterRestConfig()

    if not sigtranDestinationIpAddresses:
        try:
            peers = gatewaysConfig.get('SIGTRAN', 'peers')
        except:
            peers = "localhost:2905"
        sigtranDestinationIpAddresses = peers.split(',')

    for i in range(len(sigtranDestinationIpAddresses)):
        if sigtranDestinationIpAddresses[i].startswith(K8S_SVC):
            k8ref = sigtranDestinationIpAddresses[i].replace(K8S_SVC, "").split(":")
            cmd = [ "kubectl", "get", "service", k8ref[0],
                '''--template={{.spec.clusterIP}}:{{range $i := .spec.ports}}{{if (eq $i.name "m3ua")}}{{$i.port}}{{end}}{{end}}''' ]
            sigtranDestinationIpAddresses[i] = subprocess.check_output(cmd)
        elif sigtranDestinationIpAddresses[i].startswith(K8S_POD):
            k8ref = sigtranDestinationIpAddresses[i].replace(K8S_POD, "").split(":")
            cmd = [ "kubectl", "get", "pod",  k8ref[0], "--template={{.status.podIP}}:" +  k8ref[1] ]
            sigtranDestinationIpAddresses[i] = subprocess.check_output(cmd)

    if not bindAddress:
        try:
            bindAddress = gatewaysConfig.get('SIGTRAN', 'bindAddress')
        except:
            bindAddress = defaultBindAddress + ":" + str(defaultM3uaPort)

    if not nodeType:
        try:
            nodeType = gatewaysConfig.get('SIGTRAN', 'nodeType')
        except:
            nodeType = defaultNodeType

    if not opc:
        try:
            opc = gatewaysConfig.get('SIGTRAN', 'opc')
        except:
            opc = str(defaultOpc)

    if not dpc:
        try:
            dpc = gatewaysConfig.get('SIGTRAN', 'dpc')
        except:
            dpc = str(defaultDpc)

    if not minPeers:
        try:
            minPeers = gatewaysConfig.get('SIGTRAN', 'minPeers')
            if minPeers.startswith('all'):
                minPeers = len(sigtranDestinationIpAddresses)
        except:
            minPeers = str(defaultMinPeers)

    return (sigtranDestinationIpAddresses, bindAddress, nodeType, opc, dpc, minPeers)

#===============================================================================
def _sigtranClient(sigtranDestinationIpAddresses=None, bindAddress=None, nodeType=None, opc=None, dpc=None, minPeers=None):
    '''Creates SIGTRAN stack config files based on supplied info'''

    links=''
    asps=''
    servers = ''
    serverName='testserver'

    if bindAddress.count(':'):
        bindPort = bindAddress.rpartition(':')[2]
    else:
        bindPort = str(defaultM3uaPort)
    bindHost = bindAddress.rpartition(':')[0]

    # Server section depends on node type
    # pylint: disable=line-too-long
    if nodeType.lower() == 'client':
        servers = '<servers/>\n'
    else:
        servers = '''
<servers>
        <server name="''' + serverName + '''" started="true" hostAddress="''' + bindHost + '" hostPort="' + bindPort +'''" ipChannelType="0" acceptAnonymousConnections="true" maxConcurrentConnectionsCount="0" extraHostAddresseSize="0">
                <associations>
                        '''
        for i,_ in enumerate(sigtranDestinationIpAddresses, start=1):
            servers += ' <string value="externalAssoc' + str(i) + '"/>'
        servers += '''
                </associations>
        </server>
</servers>
'''
    # print 'Servers: ' + servers

    # Process each NE address
    assocs = '<associations>\n'
    for i,sigtranDestinationIpAddress in enumerate(sigtranDestinationIpAddresses, start=1):
        if i > 1:
            links += '\\n'
            asps += '\\n'
        if sigtranDestinationIpAddress.count(':'):
            port = sigtranDestinationIpAddress.rpartition(':')[2]
        else:
            port = defaultM3uaPort
        host = sigtranDestinationIpAddress.rpartition(':')[0]
        if nodeType.lower() == 'client':
            assocs += '    <name value="externalAssoc{0}"/>\n    <association name="externalAssoc{0}" assoctype="{5}" hostAddress="{1}" hostPort="{2}" peerAddress="{3}" peerPort="{4}" serverName="" ipChannelType="0" extraHostAddresseSize="0"/>'. \
            format(i, bindHost, bindPort, host, port, nodeType.upper())
        else:
            assocs += '    <name value="externalAssoc{0}"/>\n    <association name="externalAssoc{0}" assoctype="{3}" hostAddress="" hostPort="0" peerAddress="{1}" peerPort="{2}" serverName="{4}" ipChannelType="0" extraHostAddresseSize="0"/>'. \
            format(i, host, port, nodeType.upper(), serverName)

        links += '''    <aspFactory name=\"RASP_ExternalLink{0}\" assocName=\"externalAssoc{0}\" started=\"true\" maxseqnumber=\"256\" aspid=\"2\" heartbeat=\"false\"\/>'''.format(i)
        asps +=  '''                    <asp name=\"RASP_ExternalLink{0}\"\/>'''.format(i)
    # pylint: enable=line-too-long

    # Close associations
    assocs += '\n</associations>'
    # print 'associations: ' + assocs

    path = os.getcwd()
    qaSctpFile = path + "/qa_sctp.xml"
    qaM3uaFile = path + "/qa_m3ua.xml"
    qaSccpFile  = path + "/qaSccpStack_sccprouter2.xml"
    qaSccpResFile  = path + "/qaSccpStack_sccpresource2.xml"

    # Create sctp file
    cmd = "echo '" + servers + assocs + "' > " + qaSctpFile
    # print 'cmd: ' + cmd
    qa_utils.runCmd(cmd)

    # Edit m3ua file
    subCmd = r'''/<{0}>/{{p;:a;N;/<\/{0}>/!ba;s/.*\n/{1}\n/}};p'''
    subprocess.call(["sed", "-i", "-n", "-e", subCmd.format('aspFactoryList', links), qaM3uaFile])
    subprocess.call(["sed", "-i", "-n", "-e", subCmd.format('asps', asps), qaM3uaFile])
    sedCmd = ["sed", "-i", "-e", "s/minAspActiveForLb=\"[0-9]*/minAspActiveForLb=\""+str(minPeers)+"/", 
              "-e" , "s/DPC/"+str(dpc)+"/g", qaM3uaFile]
    subprocess.call(sedCmd)

    # Update point code in router file
    sedCmd = ["sed", "-i", "-e", "s/OPC/"+str(opc)+"/g", "-e" , "s/DPC/"+str(dpc)+"/g", qaSccpFile]
    # print 'sedCmd: ' + sedCmd
    subprocess.call(sedCmd)

    # Update point code in resource file
    # pylint: disable=line-too-long
    sedCmd = "sed -i '/<remoteSsns>/,/<\/remoteSsns>/s/remoteSpc=\".*\" remoteSsn=/remoteSpc=\"" + str(dpc) + "\" remoteSsn=/1 ' " + qaSccpResFile
    #print 'sedCmd: ' + sedCmd
    qa_utils.runCmd(sedCmd)
    sedCmd = "sed -i '/<remoteSpcs>/,/<\/remoteSpcs>/s/remoteSpc=\".*\" remoteSpc/remoteSpc=\"" + str(dpc) + "\" remoteSpc/1 ' " + qaSccpResFile
    #print 'sedCmd: ' + sedCmd
    # pylint: enable=line-too-long
    qa_utils.runCmd(sedCmd)
