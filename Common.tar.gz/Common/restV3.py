#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:41:18
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:37:00
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:33
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

#subUrl = 'subscription'


# from builtins import bytes
# from builtins import str
# from builtins import range
# from builtins import object
from future import standard_library
standard_library.install_aliases()
# from builtins import bytes
# from builtins import str
# from builtins import range
# from builtins import object
import base64
import http.client
#pylint: disable=import-error,multiple-imports
#pylint: disable=import-error,multiple-imports
#pylint: disable=import-error,multiple-imports
#pylint: disable=import-error,multiple-imports
import urllib.request, urllib.parse, urllib.error
import QA_subscriber_management_rest_helper as RESTHELPER
from xml.etree import ElementTree as ET
import common_mdc as COMMON
import data_container_defs as MDCDEFS
import data_container as MDC
import re, sys , os
#import configparser
try:
    import configparser
except:
    from six.moves import configparser

import time
import socket
import qa_utils as QAUTILS
import timeToMDCtime as MDCTIME
import urllib.parse as URL
import commonDefs as cd
import csv_data as CSV
import qa_mdc_defs as QA_MDCDEFS
import QA_subscriber_management_restv3 as RESTV3
import json


#V3inst = 0
templates = ''

# Supports basic authentication.  Will be overridden by other code.
basicAuthUserName = None
basicAuthPassword = None

#
# Socket wrapper to enable socket.TCP_NODELAY
#
realsocket = socket.socket

def socketwrap(family=socket.AF_INET, type=socket.SOCK_STREAM, proto=0):
        sockobj = realsocket(family, type, proto)
        sockobj.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        return sockobj

socket.socket = socketwrap

class RestClient(object):
    def __init__(self, host, port, basePath = '/rsgateway/data'):
        self._host = host
        self._port = port
        self._basePath = basePath 
        self.status = 0
        self.reason = ""
        self.connection = http.client.HTTPConnection(self._host, self._port)
        try:
            services = self.get("/v3")
        except:
            raise RuntimeError("unable to connect to the rsgateway name=" + host + " port=" + str(port))
        if services == None:
            raise RuntimeError("unable to connect to the rsgateway")
        if self.getStatus() != 200:
            raise RuntimeError("error getting services from the rsgateway " + self.getReason())

    def getStatus(self):
        return self.status

    def getReason(self):
        return self.reason

    def _makeRequest(self, method, resource, payload=None, headers = None):
        # Refresh the connection.  Long duration tests leave the connection hung so ensure it's always fresh.
        # NOTE: try/except logic below manages resetting connection if errors occurred.
        #self.connection = httplib.HTTPConnection(self._host, self._port)
        url = self._basePath + str(resource)
        #print url
        #print payload
        
        # Setup headers
        if headers == None: headers = {}
        headers['Connection'] = 'Keep-alive'
        
        # Support basic auth
        if basicAuthUserName:
                authCredsEnc = base64.b64encode(bytes(basicAuthUserName + ':' + basicAuthPassword))
                headers['Authorization'] = 'Basic ' + authCredsEnc
        
        # Add content encoding
        # Sometimes the request fails due to a stale connection
        try:
            # Normal case
            self.connection.request(method, url, payload, headers)
        except:
            print('WARNING: received httplib request error "' + str(e) + '".  Making a new connection and retrying.')
            self.connection = http.client.HTTPConnection(self._host, self._port)
            
            # Retry the request
            self.connection.request(method, url, payload, headers)
        
        # Sometimes the response fails when the request doesn't...
        try:
                response = self.connection.getresponse()
        except:
                print('WARNING: received httplib response error.  Making a new connection and retrying.')
                self.connection = http.client.HTTPConnection(self._host, self._port)
                
                # Retry the request
                self.connection.request(method, url, payload, headers)
                
                # Retry the response
                response = self.connection.getresponse()
                
        self.status = response.status
        self.reason = response.reason
        msg = response.read()
        if (isinstance(msg,bytes)): 
            msg = msg.decode('utf-8')
        return msg

    # GET operation
    def get(self, resource, time=None, amp=False):
        return self._makeRequest("GET", encodeParams(resource, time, amp))

    # PUT operation
    def put(self, resource, payload=None, time=None, amp=False, headers=None):
        return self._makeRequest("PUT", encodeParams(resource, time, amp), payload, headers)

    # POST operation
    def post(self, resource, payload, time=None, headers=None):
        return self._makeRequest("POST", encodeParams(resource, time), payload, headers)

    # DELETE operation
    def delete(self, resource, time=None, amp=False, payload=None, headers=None):
        return self._makeRequest("DELETE", encodeParams(resource, time, amp), payload=payload, headers=headers)

#=============================================================
def getSubscriptionOID(V3inst=0, queryValue=None, queryType='ExternalId', now=None):
        return getSubscriberOID(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)

#=============================================================
def getSubscriberOID(V3inst=0, queryValue=None, queryType='ExternalId', now=None):
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=None)
        if queryResponse: return getOID(queryResponse)
        else:             return None

#=============================================================
def getGroupOID(V3inst=0, queryValue=None, queryType='ExternalId', now=None):
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=None)
        if queryResponse: return getOID(queryResponse)
        else:             return None

#=============================================================
def getDeviceOID(V3inst=0, queryValue=None, queryType='ExternalId', now=None):
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=None)
        if queryResponse: return getOID(queryResponse)
        else:             return None

#=============================================================
def getUserOID(V3inst=0, queryValue=None, queryType='ExternalId', now=None):
        queryResponse = queryUser(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=None)
        if queryResponse: return getOID(queryResponse)
        else:             return None

#=============================================================
def encodeParams(resource, time=None, amp=False):
    
    resource = resource + getTimeStampStr(time, amp=amp)
    newResource = resource
    delim = '?'

    if '?' in resource:
        splitUrl = resource.split('?', 1)
        newResource = splitUrl[0] 
        params = splitUrl[1].split('&')
        for i in params:
            param = i.split('=',1)
            # encode just the value
            newResource = newResource + str(delim) + param[0] + "=" + URL.quote_plus(param[1])
            delim = '&'
        
        if QAUTILS.DebugLevel > 0: print('encoded url: ' + newResource)
    return newResource

#=============================================================
def getTimeStampStr(time = None, amp=False):

    if time is None:
        return ''
    if amp is True:
       return '&timestamp=' + str(time)
    else:
       return '?timestamp=' + str(time)

#=============================================================
def getResultStatus(response):

    if RESTV3.restVersion == 'OPENAPI':
        res = 'result'
        resText = 'resultText'
    else:
        res = 'Result'
        resText = 'ResultText'

    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        try:
            resp_dict = json.loads(response)
        except Exception as inst:
            return (999, 'Could not parse json response')
        
        if not resp_dict.get(resText):
            resText = '_resultText'
            res = '_resultCode'

        try:
            result = resp_dict[res]
        except Exception as inst:
            return (998, 'Result field not present')

        try:
            resultText = resp_dict[resText]
        except Exception as inst:
            return (997, 'ResultText field not present')
    else:
        try:
            responseXml = ET.XML(response)
        except Exception as inst:
            return (999, 'Could not parse xml response')

        result = responseXml.findtext(res)

        if not result:
            return (998, 'Result field not present')

        resultText = responseXml.findtext(resText)

    # CSV code needs to store these values as constants
    try:
        CSV.constantValue['LastProvisioningResult'] = result
        CSV.constantValue['LastProvisioningResultText'] = resultText
    except: pass
    
    return (result, resultText)

#=============================================================
def getJsonSearchItem(response, searchItem):
    if RESTV3.restVersion == 'OPENAPI':
        searchItem = searchItem[:1].lower() + searchItem[1:]

    try:
        resp_dict = json.loads(response)
    except Exception as inst:
        return None
    try:
        result = resp_dict[searchItem]
    except Exception as inst:
        return None

    return result

#=============================================================
def getSubscriberId(response):
    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        return getJsonSearchItem(response, 'SubscriberId')
    else:
        try:
            responseXml = ET.XML(response)
        except Exception as inst:
            return None
        return responseXml.findtext('SubscriberId')

#=============================================================
def getIMSI(response):
    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        return getJsonSearchItem(response, 'Imsi')
    else:
        try:
            responseXml = ET.XML(response)
        except Exception as inst:
            return None
        ET.dump(responseXml)
        return responseXml.findtext('./Attr/CustDeviceExtension/Imsi')

#=============================================================
def getExternalId(response):
    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        return getJsonSearchItem(response, 'ExternalId')
    else:
        responseXml = ET.XML(response)
        try:
            responseXml = ET.XML(response)
        except Exception as inst:
            return None

        return responseXml.findtext('ExternalId')

#=============================================================
def getOID(response):
    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        return getJsonSearchItem(response, 'ObjectId')
    else:
        try:
            responseXml = ET.XML(response)
        except Exception as inst:
            return None

        return responseXml.findtext('ObjectId')

#=============================================================
def getAggregateGroupId(response):
    try:
        responseXml = ET.XML(response)
    except Exception as inst:
        return None

    return responseXml.findtext('.//AggregateGroupId')

#=============================================================
def getResourceId(response):
    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        return getJsonSearchItem(response, 'ResourceIdArray')
    else:
        try:
            responseXml = ET.XML(response)
        except Exception as inst:
            return None

        resourceIdArray = responseXml.find('ResourceIdArray')
        if resourceIdArray is not None:
            values = resourceIdArray.findall('value')
            resourceIds =[]
            for value in values:
               resourceIds.append(value.text)
            return resourceIds
        return None

#=============================================================
def getQueryCursor(response):
    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        return getJsonSearchItem(response, 'QueryCursor')
    else:
        try:
            responseXml = ET.XML(response)
        except Exception as inst:
            return None
        return responseXml.findtext('QueryCursor')

#=============================================================
def getSessionId(response):

    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        ratingResponse = getJsonSearchItem(response, 'RatingResponse')
        return ratingResponse['SessionId']
    else:
        try:
            responseXml = ET.XML(response)
        except Exception as inst:
            return None

        ratingResponse = responseXml.find('RatingResponse')
        msg = ratingResponse.find('MtxDiamRoMsg')
        if msg is not None:
            print('msg', msg)
            return msg.findtext('SessionId')
        msg = ratingResponse.find('DemoDiamRoMsg')
        if msg is not None:
            return msg.findtext('SessionId')
    return None

#=============================================================
def getEventStreamingSessionIdList(response):
    try:
        responseXml = ET.XML(response)
    except Exception as inst:
        return None

    sessionIdArray = responseXml.find('SessionIdArray')
    
    sessionIdList = []
    if sessionIdArray is not None:
        for sessionId in sessionIdArray:
           sessionIdList.append(sessionId.text)
    return sessionIdList
    
#=============================================================
def getEventStreamingSessionId(response):
    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        return getJsonSearchItem(response, 'SessionId')
    else:
        try:
            responseXml = ET.XML(response)
        except Exception as inst:
            return None
        return responseXml.findtext('SessionId')

#=============================================================
def getEventStreamingSessionCursor(response):
    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        return getJsonSearchItem(response, 'StreamCursor')
    else:
        try:
            responseXml = ET.XML(response)
        except Exception as inst:
            return None
        return responseXml.findtext('StreamCursor')

#=============================================================
def getFUI(response):
    try:
        responseXml = ET.XML(response)
    except Exception as inst:
        return None

    ratingResponse = responseXml.find('RatingResponse')
    msg = ratingResponse.find('MtxDiamRoMsg')
    if msg is None:
        msg = ratingResponse.find('DemoDiamRoMsg')
    if msg is not None:
        multiList = msg.find('MultiServiceList')
        multiData = multiList.find('MtxMultiServiceData')
        info = multiData.find('LastUnitInfo')
        return ET.tostring(info)
    return None

#=============================================================
def getMsg(response):
    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        return getJsonSearchItem(response, 'ResultText')
    else:
        try:
            responseXml = ET.XML(response)
        except Exception as inst:
            return None
        return responseXml.findtext('ResultText')

#=============================================================
def validateResponse(response, method, shouldPass=True, returnParam=None):
    # Remove comment for debugging
    # print response

    (result, text) = getResultStatus(response)
    if returnParam == 'ObjectId':
        foundParam = getOID(response)
    elif returnParam == 'ResourceId':
        foundParam = getResourceId(response)
    elif returnParam == 'queryCursor':
        foundParam = getQueryCursor(response)
    if str(result) != '0' or text != 'OK':
        # Special case for queries meant to test whether an object already exists
        if shouldPass is None:
            return False

        if returnParam:
            return (COMMON.debugFailure(method=method, status=result, msg=text, shouldPass=shouldPass, response=response), foundParam)
        else:
            return COMMON.debugFailure(method=method, status=result, msg=text, shouldPass=shouldPass, response=response)

    # Special case for queries meant to test whether an object already exists
    if shouldPass is None:
        return True

    if returnParam:
        return (COMMON.debugSuccess(method=method, shouldPass=shouldPass), foundParam)
    else:
        return COMMON.debugSuccess(method=method, shouldPass=shouldPass)

#=============================================================
def failed(eventPass = True):
    if eventPass:
        return False
    else:
        return True

#=============================================================
def passed(eventPass = True):
    if eventPass:
        return True
    else:
        return False

#=============================================================
def parseParameterList(parameterList):
    # Example List   
    #parameterList = [ {'ParameterName': 'PurchaseFee', 'DecimalValue': decimal.Decimal('8.0')}]

    jsonParameterArray = "["
    openapiParameterArray = "["
    xmlParameterArray = ""

    for parameter in parameterList:
        jsonParameterString = '{ "$": "MtxParameterData",'
        openapiParameterString = '{ "mtx_container_name": "MtxParameterData",'
        xmlParameterString = '<MtxParameterData>'

        for i in parameter:
            if i in ('ParameterName', 'ParameterDefnId'):
                jsonParameterString += ' "' + str(i) + '" : "' + str(parameter[i]) + '", '
                iLower = i[0].lower() + i[1:]
                openapiParameterString += ' "' + str(iLower) + '" : "' + str(parameter[i]) + '", '
                xmlParameterString += '<' + str(i) + '>' + str(parameter[i]) + '</' + str(i) + '>'
        for i in parameter:
            if i not in ('ParameterName', 'ParameterDefnId'):
                jsonParameterString += '"Value" : {"$": "MtxParameter' + str(i) + '",  "Value" : "' + str(parameter[i]) + '"}'
                openapiParameterString += '"value" : {"mtx_container_name": "MtxParameter' + str(i) + '",  "value" : "' + str(parameter[i]) + '"}'
                xmlParameterString += '<Value><MtxParameter' + str(i) + '><Value>' + str(parameter[i]) + '</Value></MtxParameter' + str(i) + '></Value>'

        jsonParameterString += '},'
        openapiParameterString += '},'
        xmlParameterString += '</MtxParameterData>'

        jsonParameterArray += jsonParameterString
        openapiParameterArray += openapiParameterString
        xmlParameterArray += xmlParameterString

    jsonParameterArray +="]"
    openapiParameterArray +="]"

    if RESTV3.restVersion == 'JSON':
        return jsonParameterArray
    elif RESTV3.restVersion == 'OPENAPI':
        return openapiParameterArray
    else:
        return xmlParameterArray

#=============================================================
def parseAttrMdc(attr):
    if attr is None:
        return None
    
    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        return parseJsonAttrMdc(attr)

    # Open attribute XML item and if that fails just return the attr as is
    try:
        attrStr = '<' + attr.getDescriptorName() + '>'
    except:
        return attr
        
    
    # Process all containers sent in (usually only one)
    fieldPresent = False
    for container in attr.descObj.descObjList:
        # Process each field in the container
        for fieldName in container.fieldNameList:
            # Only care if field is populated
            if attr.isPresent(fieldName):
                # Indicate something found
                fieldPresent = True
                
                # Get field value
                fieldValue = attr.getUsingName(fieldName)
                
                # See if a list (extra processing if so)
                if type(fieldValue) is list:
                    # Open XML item
                    attrStr += '<' + fieldName + '>'
                    
                    # Process each list item
                    for value in fieldValue: # Add to XML item
                        attrStr += '<value>' + str(value) + '</value>'
                    
                    # Close XML item
                    attrStr += '</' + fieldName + '>'
                
                #MTX-22291 MtxAddressData within MtxBraintreeChargeMethodExtension
                elif fieldName in ['ShippingAddress', 'BillingAddress', 'CardholderAccountInfo', 'CardholderInfo', 'Order']:
                    attrStr += '<' + fieldName + '>'
                    attrStr +=  parseAttrMdc(fieldValue)
                    attrStr += '</' + fieldName + '>'
                else:
                    # Just a single value. Add to overall structure iff defined
                    fieldValue = attr.getUsingName(fieldName)
                    
                    # If the field value is in a special set, then want to clear the parameter
                    if str(fieldValue).lower() in ['empty', 'blank']: fieldValue = ''
                    
                    # Set the parameter
                    attrStr += '<' + fieldName + '>' + str(fieldValue) + '</' + fieldName + '>'
    
    # Close attribute XML item
    if fieldPresent:    attrStr += '</' + attr.getDescriptorName() + '>'
    else:               attrStr = None
     
    return attrStr

#=============================================================
def parseJsonAttrMdc(attr):
    if attr is None:
        return None

    fieldPresent = False

    # Open attribute XML item and if that fails just return the attr as is
    try:
        attrStr = '{ "$": "' + attr.getDescriptorName() + '"'
    except:
        return attr

    # Process all containers sent in (usually only one)
    for container in attr.descObj.descObjList:
        # Process each field in the container
        for fieldName in container.fieldNameList:
            # Only care if field is populated
            if attr.isPresent(fieldName):
                fieldPresent = True

                # Get field value
                fieldValue = attr.getUsingName(fieldName)

                # See if a list (extra processing if so)
                if type(fieldValue) is list:
                    # Open XML item
                    attrStr += ', "' + fieldName + '": ['

                    # Process each list item
                    cnt = len(fieldValue)
                    for value in fieldValue:
                        attrStr += '"' + str(value) + '"'
                        if cnt > 1:
                            attrStr += ','
                            cnt -= 1
                    attrStr += ']'
                elif fieldName in ['ShippingAddress', 'BillingAddress', 'CardholderAccountInfo', 'CardholderInfo', 'Order']:
                    attrStr += ', "' + fieldName + '": '
                    attrStr +=  parseAttrMdc(fieldValue)
                else:
                    # Just a single value. Add to overall structure iff defined
                    fieldValue = attr.getUsingName(fieldName)

                    # If the field value is in a special set, then want to clear the parameter
                    if str(fieldValue).lower() in ['empty', 'blank']: fieldValue = ''

                    attrStr += ', "' + fieldName + '": "' + str(fieldValue) + '"'

    # Close attribute XML item
    if fieldPresent:    attrStr += '}'
    else:               attrStr = None

    return attrStr
#=============================================================
def createCycleData(cycleType=None, cycleResourceId=None, cycleOffset=None, cycleStartTime=None, cycleEndTime=None, useTargetResource=None,
                    immediateChange=None, isRecurringFailureAllowed=None, cycleAlignmentDisabled=None, cycleOwnerType=None):

    template = 'offer_cycle_data' + RESTV3.fileType

    cycleTemplate = open(templates + template).read()
    cycleTemplate = RESTHELPER.checkIfDefined(cycleType, None, 'OFFERCYCLETYPE', cycleTemplate, 'CycleType')
    cycleTemplate = RESTHELPER.checkIfDefined(cycleResourceId, None, 'OFFERCYCLERESOURCEID', cycleTemplate, 'CycleResourceId')
    cycleTemplate = RESTHELPER.checkIfDefined(cycleOffset, None, 'OFFERCYCLEOFFSET', cycleTemplate, 'CycleOffset')
    cycleTemplate = RESTHELPER.checkIfDefined(cycleStartTime, None, 'OFFERCYCLEsTARTTIME', cycleTemplate, 'CycleStartTime')
    cycleTemplate = RESTHELPER.checkIfDefined(cycleEndTime, None, 'OFFERCYCLEENDTIME', cycleTemplate, 'CycleEndTime')
    cycleTemplate = RESTHELPER.checkIfDefined(useTargetResource, None, 'USETARGETRESOURCE', cycleTemplate, 'UseTargetResource')
    cycleTemplate = RESTHELPER.checkIfDefined(immediateChange, None, 'IMMEDIATECHANGE', cycleTemplate, 'ImmediateChange')
    cycleTemplate = RESTHELPER.checkIfDefined(isRecurringFailureAllowed, None, 'ISRECURRINGFAILUREALLOWED', cycleTemplate, 'IsRecurringFailureAllowed')
    cycleTemplate = RESTHELPER.checkIfDefined(cycleAlignmentDisabled, None, 'CYCLEALIGNMENTDISABLED', cycleTemplate, 'CycleAlignmentDisabled')
    cycleTemplate = RESTHELPER.checkIfDefined(cycleOwnerType, None, 'CYCLEOWNERTYPE', cycleTemplate, 'CycleOwnerType')
    cycleTemplate = re.sub('.*xml version.*\n?','',cycleTemplate)
    cycleTemplate = cycleTemplate.rstrip('\n')

    return cycleTemplate

#=============================================================
def createChargeMethodData(chargeMethod=None, paymentMethodResourceId=None, paymentGatewayId=None, paymentGatewayUserId=None,
        paymentGatewayOneTimeToken=None, chargeMethodAttr=None, deferredSettlement=None, deferredSettlementTimeout=None,
        deferredSettlementTimeoutAction=None):

    chargeMethodData = open(templates + 'charge_method_data'+RESTV3.fileType).read()
    chargeMethodData = RESTHELPER.checkIfDefined(chargeMethod, None, 'CHARGEMETHOD', chargeMethodData, 'ChargeMethod')
    chargeMethodData = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', chargeMethodData, 'PaymentMethodResourceId')
    chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayId, None, 'PAYMENTGATEWAYID', chargeMethodData, 'PaymentGatewayId')
    chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayUserId, None, 'PAYMENTGATEWAYUSERID', chargeMethodData, 'PaymentGatewayUserId')
    chargeMethodData = RESTHELPER.checkIfDefined(paymentGatewayOneTimeToken, None, 'PAYMENTGATEWAYONETIMETOKEN', chargeMethodData, 'PaymentGatewayOneTimeToken')
    chargeMethodData = RESTHELPER.checkIfDefined(chargeMethodAttr, None, 'ATTR', chargeMethodData, 'ChargeMethodAttr')
    chargeMethodData = RESTHELPER.checkIfDefined(deferredSettlement, None, 'DEFERREDSETTLEMENT', chargeMethodData, 'DeferredSettlement')
    chargeMethodData = RESTHELPER.checkIfDefined(deferredSettlementTimeout, None, 'DEFERREDsETTLEMENTTIMEOUT', chargeMethodData, 'DeferredSettlementTimeout')
    chargeMethodData = RESTHELPER.checkIfDefined(deferredSettlementTimeoutAction, None, 'DEFERREDsETTLEMENTtIMEOUTACTION', chargeMethodData, 'DeferredSettlementTimeoutAction')
    chargeMethodData = re.sub('.*xml version.*\n?','',chargeMethodData)
    chargeMethodData = chargeMethodData.rstrip('\n')

    return chargeMethodData

#=============================================================
def createContractParameterOverrideData(etcScheduleRangeArray=None, etcScheduleRangeUnit=None, paymentScheduleRangeArray=None, paymentScheduleAmountArray=None, paymentScheduleLastAmount=None, delayCharge=None, contractPeriod=None, contractInterval=None, commitmentPeriod=None, commitmentPeriodInterval=None, isOpenContract=None):

    contractParameterOverrideDataTemplate =None
    if etcScheduleRangeArray or etcScheduleRangeUnit or paymentScheduleRangeArray or paymentScheduleAmountArray or paymentScheduleLastAmount or delayCharge:

        template = 'offer_contract_parameter_override_data' + RESTV3.fileType

        contractParameterOverrideDataTemplate = open(templates + template).read()

        # For field name with Array, need special handling 
        #   for xml format, it is required to use <value> to concantrate each value
        #   for json etc format, it is required to use [ str(value), str(value2), str(value3) ]
        etcScheduleRangeArray = RESTHELPER.populateSimpleValueArray(etcScheduleRangeArray, RESTV3.restVersion)
        paymentScheduleRangeArray = RESTHELPER.populateSimpleValueArray(paymentScheduleRangeArray, RESTV3.restVersion)
        paymentScheduleAmountArray = RESTHELPER.populateSimpleValueArray(paymentScheduleAmountArray, RESTV3.restVersion)
        
        # NOTE: Some names here are a subset of others (e.g.commitmentPeriod and commitmentPeriodInterval).  Always put the longer name first or there will be issues. 
        contractParameterOverrideDataTemplate = RESTHELPER.checkIfDefined(contractPeriod, None, 'CONTRACTPERIOD', contractParameterOverrideDataTemplate, 'ContractPeriod')
        contractParameterOverrideDataTemplate = RESTHELPER.checkIfDefined(contractInterval, None, 'CONTRACTINTERVAL', contractParameterOverrideDataTemplate, 'ContractInterval')
        contractParameterOverrideDataTemplate = RESTHELPER.checkIfDefined(commitmentPeriodInterval, None, 'COMMITMENTPERIODINTERVAL', contractParameterOverrideDataTemplate, 'CommitmentPeriodInterval')
        contractParameterOverrideDataTemplate = RESTHELPER.checkIfDefined(commitmentPeriod, None, 'COMMITMENTPERIOD', contractParameterOverrideDataTemplate, 'CommitmentPeriod')
        contractParameterOverrideDataTemplate = RESTHELPER.checkIfDefined(isOpenContract, None, 'ISOPENCONTRACT', contractParameterOverrideDataTemplate, 'IsOpenContract')
        
        contractParameterOverrideDataTemplate = RESTHELPER.checkIfDefined(etcScheduleRangeArray, None, 'ETCSCHEDULERANGEARRAY', contractParameterOverrideDataTemplate, 'EtcScheduleRangeArray')
        contractParameterOverrideDataTemplate = RESTHELPER.checkIfDefined(etcScheduleRangeUnit, None, 'ETCSCHEDULERANGEUNIT', contractParameterOverrideDataTemplate, 'EtcScheduleRangeUnit')
        contractParameterOverrideDataTemplate = RESTHELPER.checkIfDefined(paymentScheduleAmountArray, None, 'PAYMENTSCHEDULEAMOUNTARRAY', contractParameterOverrideDataTemplate, 'PaymentScheduleAmountArray')
        contractParameterOverrideDataTemplate = RESTHELPER.checkIfDefined(paymentScheduleRangeArray, None, 'PAYMENTSCHEDULERANGEARRAY', contractParameterOverrideDataTemplate, 'PaymentScheduleRangeArray')
        contractParameterOverrideDataTemplate = RESTHELPER.checkIfDefined(paymentScheduleLastAmount, None, 'PAYMENTSCHEDULELASTAMOUNT', contractParameterOverrideDataTemplate, 'PaymentScheduleLastAmount')
        contractParameterOverrideDataTemplate = RESTHELPER.checkIfDefined(delayCharge, None, 'DELAYCHARGE', contractParameterOverrideDataTemplate, 'DelayCharge')
        contractParameterOverrideDataTemplate = contractParameterOverrideDataTemplate.rstrip('\n')
    
    return contractParameterOverrideDataTemplate 

#=============================================================
def createContactPushTokenList(contactPushTokenList=None):
    contactPushTokenListStr = ''
    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        if type(contactPushTokenList) is not list:
            contactPushTokenList=[contactPushTokenList]
        contactPushTokenListStr = str(contactPushTokenList).replace("'", '"')
    else:
        if type(contactPushTokenList) is list:
            for value in contactPushTokenList:
                contactPushTokenListStr += '<value>' + str(value) + '</value>'
        else :
           contactPushTokenListStr = '<value>' + str(contactPushTokenList) + '</value>'
    return contactPushTokenListStr

#=============================================================
def createAdminArrayStr(V3inst, admins, queryType, now=None):
    adminStr = ''

    if admins != 0:
        if type(admins) is list:
            for admin in admins:
                if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
                    adminStr += '{"$": "MtxSubscriberSearchData", "' + str(queryType) + '": "' + str(admin) + '"}'
                else:
                    if queryType != 'ObjectId':
                        queryResponse = querySubscriber(V3inst=V3inst, queryValue=admin, queryType=queryType, now=now)
                        admin = getOID(queryResponse)
                    adminStr += '<MtxSubscriberSearchData><ObjectId>' +str(admin)+ '</ObjectId></MtxSubscriberSearchData>'
        else:
            if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
                adminStr += '{"$": "MtxSubscriberSearchData", "' + str(queryType) + '": "' + str(admins) + '"}'
            else:
                if queryType != 'ObjectId':
                    queryResponse = querySubscriber(V3inst=V3inst, queryValue=admins, queryType=queryType, now=now)
                    admins = getOID(queryResponse)
            adminStr += '<MtxSubscriberSearchData><ObjectId>' + str(admins) + '</ObjectId></MtxSubscriberSearchData>'

    return adminStr

#=============================================================
def getRoleArray(rolesPricingIds=None, rolesExternalIds=None):
    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        roleArray = ''
        if rolesPricingIds:
            if type(rolesPricingIds) is list:
                for pricingId in rolesPricingIds:
                    roleArray += '{"$": "MtxRoleData", "PricingId": ' + str(pricingId) + '}'
            else:
                roleArray += '{"$": "MtxRoleData", "PricingId": ' + str(rolesPricingIds) + '}'

        if rolesExternalIds:
            if type(rolesExternalIds) is list:
                for externalId in rolesExternalIds:
                    roleArray += '{"$": "MtxRoleData", "ExternalId": "' + str(externalId) + '"}'
            else:
                roleArray += '{"$": "MtxRoleData", "ExternalId": "' + str(rolesExternalIds) + '"}'
    else:
        roleArray = '\n'
        if rolesPricingIds:
            if type(rolesPricingIds) is list:
                for pricingId in rolesPricingIds:
                    roleArray += '    <MtxRoleData><PricingId>' + str(pricingId) + '</PricingId></MtxRoleData>\n'
            else:
                roleArray += '    <MtxRoleData><PricingId>' + str(rolesPricingIds) + '</PricingId></MtxRoleData>\n'
                  
        if rolesExternalIds:
            if type(rolesExternalIds) is list:
                for externalId in rolesExternalIds:
                    roleArray += '    <MtxRoleData><ExternalId>' + str(externalId) + '</ExternalId></MtxRoleData>\n'
            else:
                roleArray += '    <MtxRoleData><ExternalId>' + str(rolesExternalIds) + '</ExternalId></MtxRoleData>\n'

    return roleArray


#=============================================================
def createExemptionCodeList(exemptionCodeList=None):
    exemptionCodeListStr = ''
    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        if type(exemptionCodeList) is not list:
            exemptionCodeList=[exemptionCodeList]
        exemptionCodeListStr = str(exemptionCodeList).replace("'", '"')
    else:
        if type(exemptionCodeList) is list:
            for value in exemptionCodeList:
                exemptionCodeListStr += '<value>' + str(value) + '</value>'
        else :
           exemptionCodeListStr = '<value>' + str(exemptionCodeList) + '</value>'

    return exemptionCodeListStr

#=============================================================
def importSubscriberBalanceValue(V3inst=0, queryType='ExternalId', externalId=None, resourceId=None,
            amount=0, startTime=None, createOnDemand=True, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Need in OID format
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=externalId, queryType=queryType, now=now)
        externalId = getOID(queryResponse)

    profTemplate = open(templates + 'subscriber_import_balance'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(resourceId, None, 'BALANCERESOURCEID', profTemplate,
        'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(startTime, None, 'STARTTIME', profTemplate, 'StartTime')
    profTemplate = RESTHELPER.checkIfDefined(createOnDemand, None, 'CREATEONDEMAND', profTemplate, 'CreateOnDemand')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    
    url = '/'+RESTV3.urlPrefix
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
    
    # Must use multi-request to send this through, as there is no URL for this action.
    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    #print response
    return validateResponse(response=response, method='multiRequest', shouldPass=eventPass, returnParam='ObjectId')

#====================================================================
def deleteUserSubscription(V3inst, queryValue=None, queryType='ExternalId', subQueryValue=None, subQueryType='ExternalId',
        apiEventData=None, now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True, multiRequestBuild=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/'+RESTV3.urlPrefix+'/service/user/' + str(queryType) + '+' + str(queryValue) + '/subscription/' + str(subQueryType) + '+' + str(subQueryValue)

    delim = '?'
    amp = False
    if routingType and routingValue :
        url += '?TrafficRouteData='+routingType + str(routingValue)
        delim = '&'
        amp = True

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip(): url += delim + 'ApiEventData=' + apiEventDataStr

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=================================================================
def createUserSubscription(V3inst=0, queryValue=None, queryType=None,
    # Subscription
    subExternalId=None, subStatus=None, timeZone=None, billingCycle=None, dateOffset=None,
    taxStatus=None, taxCertificate=None, taxLocation=None, glCenter=None, name=None, subAttr=None,
    subApiEventData=None, 
    customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
    # Role
    rolesExternalIds=None, rolesPricingIds=None,
    #
    apiEventData=None, now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    subscription = createSubscription(V3inst, externalId=subExternalId, status=subStatus, timeZone=timeZone,
                          billingCycle=billingCycle, dateOffset=dateOffset, taxStatus=taxStatus,
                          taxCertificate=taxCertificate, taxLocation=taxLocation, glCenter=glCenter, name=name, attr=subAttr,
                          customerType=customerType, serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId,
                          exemptionCodeList=exemptionCodeList,
                          returnTemplate=True)
    subscription = re.sub('.*xml version.*\n?','',subscription)
    subscription = subscription.rstrip('\n')

    roleArray = None
    if rolesPricingIds or rolesExternalIds:
        roleArray = getRoleArray(rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds)

    template = 'user_create_subscription'+RESTV3.fileType

    profTemplate = open(templates + template).read()
    profTemplate = RESTHELPER.checkIfDefined(subscription, None, 'SUBSCRIPTION', profTemplate, 'Subscription')
    profTemplate = RESTHELPER.checkIfDefined(roleArray, None, 'ROLES', profTemplate, 'Role')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')

    url = '/'+RESTV3.urlPrefix+'/service/user/' + str(queryType) + '+' + str(queryValue) + '/subscription' 
    if routingType and routingValue :
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)


    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    # Must use multi-request to send this through, as there is no URL for this action.
    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    #print response
    return validateResponse(response=response, method='createUserSubscription', shouldPass=eventPass, returnParam='ObjectId')

#Extended Service to Create Subscriber, Device and Purchase Offer
#=============================================================r===
def createSubscriberAndDevice(V3inst=0, externalId=None, queryValue=None, queryType=None,
        # User
        userId=None, userExternalId=None, firstName=None, lastName=None, contactEmail=None, contactPhoneNumber=None,
        contactPushTokenList=None, notificationPreference=None, language=None, userAttr=None,  userStatus=None,
        userApiEventData=None, 
        # Subscription
        subStatus=None, timeZone=None, billingCycle=None, dateOffset=None, subAttr=None, taxStatus=None, taxCertificate=None,
        taxLocation=None, glCenter=None, payload=None, subApiEventData=None,
        # Role
        rolesExternalIds=None, rolesPricingIds=None,
        # Device
        deviceId=None, deviceType=1, devAttr=None, accessNumbers=None, devStatus=None, deviceExternalId=None,
        devApiEventData=None,
        # PaymentMethod
        paymentGatewayId=None, paymentGatewayUserId=None, paymentGatewayOneTimeToken=None, paymentAttr=None, paymentName=None,
        paymentType=None, paymentIsDefault=None, paymentIsSysDefault=None, paymentApiEventData=None,
        # Recharge Schedule
        firstRechargeTime=None, rechargePeriodType=None, rechargePeriodCoef=None, rechargeCycleTimeOfDay=None, rechargeCycleOffset=None,
        rechargeAmount=None, rechargeEndTimeExtensionOffsetUnit=None, rechargeEndTimeExtensionOffset=None, scheduledRechargeNotificationProfileId=None,
        rechargeApiEventData=None,
        # Offer
        chargeMethod=None, offerId=0, catalogItemId=None, offerStartTime=None, offerEndTime=None, offerIsExternal=None,
        offerAttr=None, endTimeRelativeOffset=None, endTimeRelativeOffsetUnit=None, downPayment=None,
        isTargetResource=None, useTargetResource=None, isRecurringFailureAllowed=None, offerStatusValue=None,
        paymentDueDate=None, chargePurchaseProrationType=None, grantPurchaseProrationType=None, reason=None, info=None, parameterList=None,
        offerLifecycleProfileId=None,
        # Offer Activation
        preActiveState=None, activationExpirationTime=None, activationExpirationRelativeOffsetUnit=None, activationExpirationRelativeOffset=None,
        autoActivationCycleResourceId=None, autoActivationTime=None, autoActivationRelativeOffsetUnit=None, autoActivationRelativeOffset=None,
        isPendingActivationAllowed=None,
        # Offer Cycle
        offerCycleType=None, offerCycleOffset=None, offerCycleResourceId=None, offerCycleStartTime=None, offerApiEventData=None,
        #
        apiEventData=None, now=None, eventPass=True, routingType=None, routingValue=None, purchaseInfo=False, executeMode=None,
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        multiRequestBuild=None, eligibilityCheck=True, geoData=None):

    subscriber = None
    subscription = None
    user = None
    roleArray = None
    device = None
    paymentMethod = None
    rechargeSchedule = None
    offer = None

    if now is None:
        now = offerStartTime
    # No queryValue, so create user/subscription/subscriber
    if not queryValue:

        # Create User, Subscription and Role
        if RESTV3.subUrl == 'user' or userId:
            url = '/'+RESTV3.urlPrefix+'/service/user'
            funcName = 'createUserSubscriptionAndDevice'
            template = 'user_create_subscription_device_offer'+RESTV3.fileType
            # Populate the User Payload
            user = createUser(V3inst, userId=userId, externalId=userExternalId, firstName=firstName,
                      lastName=lastName, contactEmail=contactEmail, contactPhoneNumber=contactPhoneNumber,
                      contactPushTokenList=contactPushTokenList, notificationPreference=notificationPreference,
                      language=language, attr=userAttr, status=userStatus, tenantId=tenantId, apiEventData=userApiEventData,
                      returnTemplate=True)
            user = re.sub('.*xml version.*\n?','',user)
            user = user.rstrip('\n')

            # Populate the subscription Payload
            subscription = createSubscription(V3inst, externalId=externalId, status=subStatus, timeZone=timeZone,
                      billingCycle=billingCycle, dateOffset=dateOffset, taxStatus=taxStatus,
                      taxCertificate=taxCertificate, taxLocation=taxLocation, glCenter=glCenter, attr=subAttr,
                      customerType=customerType, serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId,
                      exemptionCodeList=exemptionCodeList,
                      apiEventData=subApiEventData, returnTemplate=True)
            subscription = re.sub('.*xml version.*\n?','',subscription)
            subscription = subscription.rstrip('\n')

            # Populate the roleArray Payload
            if rolesPricingIds or rolesExternalIds:
                roleArray = getRoleArray(rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds)

        # Create Subscription
        elif RESTV3.subUrl == 'subscription':
            url = '/'+RESTV3.urlPrefix+'/service/subscription'
            funcName = 'createSubscriptionAndDevice'
            template = 'subscription_create_with_device_and_offer'+RESTV3.fileType
            subscription = createSubscription(V3inst, externalId=externalId, status=subStatus, timeZone=timeZone,
                      billingCycle=billingCycle, dateOffset=dateOffset, taxStatus=taxStatus,
                      taxCertificate=taxCertificate, taxLocation=taxLocation, glCenter=glCenter, attr=subAttr,
                      customerType=customerType, serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId,
                      exemptionCodeList=exemptionCodeList, apiEventData=subApiEventData, returnTemplate=True)
            subscription = re.sub('.*xml version.*\n?','',subscription)
            subscription = subscription.rstrip('\n')

        # Create Subscriber
        else:
            url = '/'+RESTV3.urlPrefix+'/service/subscriber'
            funcName = 'createSubscriberAndDevice'
            template = 'subscriber_create_with_device_and_offer'+RESTV3.fileType
            subscriber = createSubscriber(V3inst=V3inst, externalId=externalId, payload=payload, billingCycle=billingCycle, dateOffset=dateOffset,
                eventPass=eventPass, firstName=firstName, lastName=lastName, contactEmail=contactEmail, contactPhoneNumber=contactPhoneNumber,
                contactPushTokenList=contactPushTokenList, notificationPreference=notificationPreference, timeZone=timeZone, attr=subAttr, status=subStatus,
                taxStatus=taxStatus, taxCertificate=taxCertificate, taxLocation=taxLocation, language=language, glCenter=glCenter,
                customerType=customerType, serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId, exemptionCodeList=exemptionCodeList,
                apiEventData=subApiEventData, returnTemplate=True )
            subscriber = re.sub('.*xml version.*\n?','',subscriber)
            subscriber = subscriber.rstrip('\n')

    # We have an queryValue, so we must have an existing Subscriber/Subscription
    # We do not have an Offer or CatalogItem, so we just need to add a Device
    elif offerId == 0  and catalogItemId == None:
        url = '/'+RESTV3.urlPrefix+'/service/' + RESTV3.subUrl + '/' + str(queryType) + '+' + str(queryValue) + '/device'
        funcName = 'subscriberCreateDevice'
        template = 'subscriber_create_device'+RESTV3.fileType

    # We have an queryValue, so we must have an existing Subscriber/Subscription
    # We do have an OfferId/CatalogItem so we need to add a Device and Purchase an Offer/Catalog
    else:
        funcName = 'subscriberCreateDeviceAndOffer'
        template = 'subscriber_add_device_and_offer'+RESTV3.fileType
        url = '/'+RESTV3.urlPrefix+'/service/' + RESTV3.subUrl + '/' + str(queryType) + '+' + str(queryValue) + '/deviceandoffer'

    # So by now we have worked out Which Template, URL and function to use
    # ====================================================================

    # If we have a DeviceId, populate the device Payload
    if deviceId is not None:
        device = createDevice(V3inst, deviceId, externalId=deviceExternalId, deviceType=deviceType, attr=devAttr,
            accessNumbers=accessNumbers, status=devStatus, mobile=None, tenantId=tenantId, apiEventData=devApiEventData, executeMode=executeMode,
            returnTemplate=True)
        device = re.sub('.*xml version.*\n?','',device)
        device = device.rstrip('\n')

    # If we have a Paymant Method, populate the paymentMethod Payload
    if paymentGatewayId is not None and paymentGatewayOneTimeToken is not None:
        paymentMethod = subscriberAddPaymentMethod(V3inst, queryValue = None, paymentGatewayUserId=paymentGatewayUserId,
        paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, paymentGatewayId=paymentGatewayId,
        paymentType=paymentType, name=paymentName, isDefault=paymentIsDefault, isSysDefault=paymentIsSysDefault, queryType='ObjectId',
        paymentAttr=paymentAttr, eventPass=eventPass, executeMode=executeMode, returnTemplate=True)
        paymentMethod = re.sub('.*xml version.*\n?','',paymentMethod)
        paymentMethod = paymentMethod.rstrip('\n')

    # If we have a rechargeSchedule, populate the rechargeSchedule Payload
    if rechargePeriodType is not None and rechargeAmount is not None:
        rechargeSchedule = subscriberAddRechargeSchedule(V3inst, queryValue = None, firstRechargeTime=firstRechargeTime, queryType='ObjectId',
        periodType= rechargePeriodType, periodCoef=rechargePeriodCoef, cycleTimeOfDay=rechargeCycleTimeOfDay, cycleOffset=rechargeCycleOffset,
        amount=rechargeAmount, paymentMethodResourceId=None, endTimeExtensionOffsetUnit=rechargeEndTimeExtensionOffsetUnit,
        endTimeExtensionOffset=rechargeEndTimeExtensionOffset,
        scheduledRechargeNotificationProfileId=scheduledRechargeNotificationProfileId, eventPass=eventPass, executeMode=executeMode, returnTemplate=True)
        rechargeSchedule = re.sub('.*xml version.*\n?','', rechargeSchedule)
        rechargeSchedule = rechargeSchedule.rstrip('\n')

    # If we have a Offer/Catalog, populate the offer Payload
    # Put the offerId and/or catalogItemId into a list, that way we pick up the correct template on purchase
    # Set queryType to ObjectId to stop subscribeToOffer from doing a subscriber query
    if offerId != 0 or catalogItemId:
        if catalogItemId and type(catalogItemId) is not list:
            catalogItemId = [catalogItemId]
        if offerId != 0 and type(offerId) is not list:
            offerId = [offerId]
        offer = subscribeToOffer(V3inst=V3inst, externalId=None, queryType='ObjectId', offerId=offerId, catalogItemId=catalogItemId,
            offerStartTime=offerStartTime, offerEndTime=offerEndTime, offerIsExternal=offerIsExternal, attr=offerAttr,
            preActiveState=preActiveState, autoActivationTime=autoActivationTime,
            autoActivationRelativeOffsetUnit=autoActivationRelativeOffsetUnit, autoActivationRelativeOffset=autoActivationRelativeOffset,
            autoActivationCycleResourceId=autoActivationCycleResourceId, activationExpirationTime=activationExpirationTime,
            activationExpirationRelativeOffsetUnit=activationExpirationRelativeOffsetUnit, activationExpirationRelativeOffset=activationExpirationRelativeOffset,
            chargeMethod=chargeMethod, paymentMethodResourceId=None, paymentGatewayId=paymentGatewayId,
            paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, paymentGatewayUserId=paymentGatewayUserId, purchaseInfo=purchaseInfo, returnDataTemplate=True,
            offerCycleType=offerCycleType, offerCycleOffset=offerCycleOffset, offerCycleResourceId=offerCycleResourceId, offerCycleStartTime=offerCycleStartTime,
            endTimeRelativeOffsetUnit=endTimeRelativeOffsetUnit, endTimeRelativeOffset=endTimeRelativeOffset, downPayment=downPayment,
            isTargetResource=isTargetResource, useTargetResource=useTargetResource, isRecurringFailureAllowed=None,
            paymentDueDate=paymentDueDate, chargePurchaseProrationType=chargePurchaseProrationType, grantPurchaseProrationType=grantPurchaseProrationType,
            isPendingActivationAllowed=isPendingActivationAllowed, offerLifecycleProfileId=offerLifecycleProfileId,
            routingType=routingType, routingValue=routingValue, reason=reason, info=info, apiEventData=offerApiEventData, offerStatusValue=offerStatusValue,
            parameterList=parameterList, eligibilityCheck=eligibilityCheck, geoData=geoData)
        offer = re.sub('.*xml version.*\n?','',offer)
        offer = offer.rstrip('\n')

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    # We now need to populate the Service Payload with any Payloads we have populated above
    profTemplate = open(templates + template).read()
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(subscriber, None, 'SUBSCRIBER', profTemplate, 'Subscriber')
    profTemplate = RESTHELPER.checkIfDefined(user, None, 'USER', profTemplate, 'User')
    profTemplate = RESTHELPER.checkIfDefined(subscription, None, 'SUBSCRIPTION', profTemplate, 'Subscription')
    profTemplate = RESTHELPER.checkIfDefined(roleArray, None, 'ROLES', profTemplate, 'Role')
    profTemplate = RESTHELPER.checkIfDefined(device, None, 'DEVICE', profTemplate, 'Device')
    profTemplate = RESTHELPER.checkIfDefined(paymentMethod, None, 'PAYMENTMETHOD', profTemplate, 'PaymentMethod')
    profTemplate = RESTHELPER.checkIfDefined(rechargeSchedule, None, 'RECHARGESCHEDULE', profTemplate, 'RechargeSchedule')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(eligibilityCheck, None, 'ELIGIBILITYCHECK', profTemplate, 'EligibilityCheck')

    # Attempt to Populate both, only one will actually work
    profTemplate = RESTHELPER.checkIfDefined(offer, None, 'OFFER', profTemplate, 'SubscriptionOfferArray')
    profTemplate = RESTHELPER.checkIfDefined(offer, None, 'OFFER', profTemplate, 'SubscriberOfferArray')

    if routingType and routingValue :
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if purchaseInfo:
       return (passed(eventPass), response)
    else:
       return validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='ObjectId')

#=============================================================
def addSubscriber(V3inst = 0, externalId = None, deviceId = None, deviceType = 1, offerId = 0, catalogItemId=None,
        offerStartTime = None, offerEndTime = None, serviceId = None, payload = None, subAttr = None, devAttr = None,
        billingCycle = None, eventPass=True, firstName=None, lastName=None, contactEmail=None, contactPhoneNumber=None, contactPushTokenList=None,
        notificationPreference=None, timeZone=None, sharedWalletQuery=None, now=None, accessNumbers=None,
        subStatus=None, devStatus=None, taxStatus=None, taxCertificate=None, taxLocation=None, language=None,
        offerIsExternal=False, offerAttr=None, dateOffset=None, glCenter=None, name=None, noTouch=False, devOid=None,
        devQueryType='PhoneNumber', chargeMethod=None, paymentMethodResourceId=None, paymentGatewayId=None, chargeMethodAttr=None,
        paymentGatewayOneTimeToken=None, routingType=None, routingValue=None, preActiveState=None, paymentGatewayUserId=None,
        autoActivationTime=None, autoActivationRelativeOffsetUnit=None, autoActivationRelativeOffset=None, autoActivationCycleResourceId=None,
        activationExpirationTime=None, activationExpirationRelativeOffsetUnit=None, activationExpirationRelativeOffset=None,
        endTimeRelativeOffsetUnit=None, endTimeRelativeOffset=None, offerCycleType=None, offerCycleOffset=None, offerCycleStartTime=None,
        subApiEventData=None, devApiEventData=None, offerApiEventData=None, parameterList=None, offerStatusValue=None, 
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        isPendingActivationAllowed=None, offerLifecycleProfileId=None,
        paymentDueDate=None, chargePurchaseProrationType=None, grantPurchaseProrationType=None, reason=None, info=None, eligibilityCheck=True, geoData=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    #RESTHELPER.saveResultsIntoMainDriver(externalId, deviceId)
    time.sleep(0.09)
    if now is None:
        now = offerStartTime

    # Issue subscriber create command.  Validate response
    (retValue, oid) = createSubscriber(V3inst=V3inst, externalId = externalId, now = now,
        payload = payload, billingCycle = billingCycle, eventPass = eventPass, firstName = firstName,
        lastName = lastName, contactEmail = contactEmail, contactPhoneNumber = contactPhoneNumber, contactPushTokenList = contactPushTokenList,
        notificationPreference = notificationPreference, timeZone = timeZone, sharedWalletQuery = sharedWalletQuery,
        attr = subAttr, apiEventData=subApiEventData, status = subStatus, taxStatus=taxStatus, taxCertificate=taxCertificate, taxLocation=taxLocation, 
        customerType=customerType, serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId, exemptionCodeList=exemptionCodeList,
        language = language, dateOffset=dateOffset, glCenter=glCenter, name=name, routingType=routingType, routingValue=routingValue)
       

    # create a new device if a deviceId is provided
    if deviceId is not None:
        # Add device to the subscriber if one was specified.
        (retCode, deviceOid) = addDeviceToSubscriber(V3inst, oid, deviceId, deviceType, accessNumbers=accessNumbers,
            subQueryType = 'ObjectId', devQueryType = devQueryType, eventPass = eventPass, status=devStatus, attr = devAttr,
            tenantId=tenantId, apiEventData=devApiEventData, now = now, routingType=routingType, routingValue=routingValue)
        if not retCode:
            return (failed(eventPass), oid)

    if offerId != 0 or catalogItemId:
        if not subscribeToOffer(V3inst = V3inst, externalId = oid, offerId = offerId, catalogItemId=catalogItemId,
                offerStartTime = offerStartTime, offerEndTime = offerEndTime, eventPass = eventPass,
                queryType = 'ObjectId', now=now, offerIsExternal=offerIsExternal, attr=offerAttr,
                chargeMethod=chargeMethod, paymentMethodResourceId=paymentMethodResourceId, paymentGatewayId=paymentGatewayId, 
                paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, preActiveState=preActiveState,
                autoActivationTime=autoActivationTime, autoActivationRelativeOffsetUnit=autoActivationRelativeOffsetUnit,
                paymentGatewayUserId=paymentGatewayUserId,
                autoActivationRelativeOffset=autoActivationRelativeOffset, autoActivationCycleResourceId=autoActivationCycleResourceId,
                activationExpirationTime=activationExpirationTime, chargeMethodAttr=chargeMethodAttr,
                activationExpirationRelativeOffsetUnit=activationExpirationRelativeOffsetUnit,
                activationExpirationRelativeOffset=activationExpirationRelativeOffset, endTimeRelativeOffsetUnit=endTimeRelativeOffsetUnit,
                endTimeRelativeOffset=endTimeRelativeOffset, offerCycleType=offerCycleType, offerCycleOffset=offerCycleOffset,
                offerCycleStartTime=offerCycleStartTime, parameterList=parameterList, routingType=routingType, routingValue=routingValue,
                chargePurchaseProrationType=chargePurchaseProrationType, grantPurchaseProrationType=grantPurchaseProrationType,
                isPendingActivationAllowed=isPendingActivationAllowed, offerLifecycleProfileId=offerLifecycleProfileId,
                paymentDueDate=paymentDueDate, apiEventData=offerApiEventData, offerStatusValue=offerStatusValue, reason=reason, info=info, eligibilityCheck=eligibilityCheck, geoData=geoData):
            return (failed(eventPass), oid)

    return (passed(eventPass), oid)

#=============================================================
def createSubscription(V3inst=None, externalId=None, status=None, timeZone=None, billingCycle=None, attr=None,
        dateOffset=None, taxStatus=None, taxCertificate=None, taxLocation=None, glCenter=None, name=None, apiEventData=None, 
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True, returnTemplate=False, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    global templates

    attrStr = None
    if attr is not None:
        #print 'Create subscriber:  attr = ' + str(attr)
        attrStr = parseAttrMdc(attr)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

   #check if we passed a string for billingCycle and convert it to a billing cycle template
    if billingCycle and type(billingCycle) is int :
        billingCycle = createBillingCycleData(int(billingCycle), startTime=now, dateOffset=dateOffset)

    exemptionCodeListStr = None
    if  exemptionCodeList is not None:
        exemptionCodeListStr = createExemptionCodeList(exemptionCodeList)

    profTemplate = open(templates + 'subscription_create'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'EXTERNALID', profTemplate, 'ExternalId')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    profTemplate = RESTHELPER.checkIfDefined(timeZone, None, 'TIMEZONE', profTemplate, 'TimeZone')
    profTemplate = RESTHELPER.checkIfDefined(name, None, 'NAME', profTemplate, 'Name')
    profTemplate = RESTHELPER.checkIfDefined(billingCycle, None, 'BILLINGCYCLE', profTemplate, 'BillingCycle')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(taxStatus, None, 'TAXsTATUS', profTemplate, 'TaxStatus')
    profTemplate = RESTHELPER.checkIfDefined(taxCertificate, None, 'TAXCERTIFICATE', profTemplate, 'TaxCertificate')
    profTemplate = RESTHELPER.checkIfDefined(taxLocation, None, 'TAXLOCATION', profTemplate, 'TaxLocation')
    profTemplate = RESTHELPER.checkIfDefined(glCenter, None, 'GLCENTER', profTemplate, 'GlCenter')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(customerType, None, 'CUSTOMERTYPE', profTemplate, 'CustomerType')
    profTemplate = RESTHELPER.checkIfDefined(serviceAddress, None, 'SERVICEADDRESS', profTemplate, 'ServiceAddress')
    profTemplate = RESTHELPER.checkIfDefined(npa, None, 'NPA', profTemplate, 'Npa') 
    profTemplate = RESTHELPER.checkIfDefined(nxx, None, 'NXX', profTemplate, 'Nxx')
    profTemplate = RESTHELPER.checkIfDefined(tenantId, None, 'TENANTID', profTemplate, 'TenantId')
    profTemplate = RESTHELPER.checkIfDefined(exemptionCodeListStr, None, 'EXEMPTIONCODELIST', profTemplate, 'ExemptionCodeList')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    if returnTemplate: return profTemplate

    url = '/'+RESTV3.urlPrefix+'/subscription'
    if routingType and routingValue :
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method='createSubscription', shouldPass=eventPass, returnParam='ObjectId')

#=============================================================
def querySubscription(V3inst, queryValue, queryType='ExternalId', querySize=None, eventPass=True, now=None,
                      routingType=None, routingValue=None, useResponseSubscriptionTransformer=False, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/'+RESTV3.urlPrefix+'/subscription/' + str(queryType) + '+' + str(queryValue)

    amp = False
    delim = '?'

    # Add query size if specified
    if querySize:
        amp = True
        url += delim + 'querySize=' + str(querySize)
        delim='&'
    else: amp = False
    if routingType and routingValue :
        url += delim + 'TrafficRouteData=' + str(routingType) + str(routingValue)
   
    # rest not support ResponseSubscriptionTransformer
    # only json / openapi 

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#====================================================================
def modifySubscription(V3inst, queryValue=None, queryType='ExternalId', externalId=None, status=None, timeZone=None, name=None, 
        billingCycle=None, dateOffset=None, immediateChange=None, billingCycleDisabled=None,
        attr=None, taxStatus=None, taxCertificate=None, taxLocation=None, glCenter=None, lastActivityUpdateTime=None,
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        currentPaymentTokenResourceId=None, sysPaymentTokenResourceId=None, routingType=None, routingValue=None,
        apiEventData=None, now=None, executeMode=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    global templates
    # Get subscription OID if queryType is not ObjectId
    if queryType != 'ObjectId':
        queryResponse = querySubscription(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    attrStr = None
    if attr is not None:
        attrStr = parseAttrMdc(attr)

    if billingCycleDisabled:
        billingCycleDisabled='true'
    elif billingCycleDisabled == False:
        billingCycleDisabled='false'

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    exemptionCodeListStr = None
    if  exemptionCodeList is not None:
        exemptionCodeListStr = createExemptionCodeList(exemptionCodeList)

    #check if we passed a string for billingCycle and convert it to a billing cycle template
    if billingCycle and type(billingCycle) is int :
        billingCycle = createBillingCycleData(int(billingCycle), startTime=now, dateOffset=dateOffset, immediateChange=immediateChange)

    profTemplate = open(templates + 'subscription_modify'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'EXTERNALID', profTemplate, 'ExternalId')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    profTemplate = RESTHELPER.checkIfDefined(timeZone, None, 'TIMEZONE', profTemplate, 'TimeZone')
    profTemplate = RESTHELPER.checkIfDefined(name, None, 'NAME', profTemplate, 'Name')
    profTemplate = RESTHELPER.checkIfDefined(billingCycle, None, 'BILLINGCYCLE', profTemplate, 'BillingCycle')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(taxStatus, None, 'TAXsTATUS', profTemplate, 'TaxStatus')
    profTemplate = RESTHELPER.checkIfDefined(taxCertificate, None, 'TAXCERTIFICATE', profTemplate, 'TaxCertificate')
    profTemplate = RESTHELPER.checkIfDefined(taxLocation, None, 'TAXLOCATION', profTemplate, 'TaxLocation')
    profTemplate = RESTHELPER.checkIfDefined(glCenter, None, 'GLCENTER', profTemplate, 'GlCenter')
    profTemplate = RESTHELPER.checkIfDefined(lastActivityUpdateTime, None, 'LASTACTIVITYUPDATETIME',
        profTemplate, 'LastActivityUpdateTime')
    profTemplate = RESTHELPER.checkIfDefined(currentPaymentTokenResourceId, None, 'CURRENTPAYMENTTOKENRECOURCEID',
        profTemplate, 'CurrentPaymentTokenResourceId')
    profTemplate = RESTHELPER.checkIfDefined(sysPaymentTokenResourceId, None, 'SYSPAYMENTTOKENRECOURCEID',
        profTemplate, 'SysPaymentTokenResourceId')
    profTemplate = RESTHELPER.checkIfDefined(billingCycleDisabled, None, 'billingCYCLEDISABLED', profTemplate, 'BillingCycleDisabled')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(customerType, None, 'CUSTOMERTYPE', profTemplate, 'CustomerType')
    profTemplate = RESTHELPER.checkIfDefined(serviceAddress, None, 'SERVICEADDRESS', profTemplate, 'ServiceAddress')
    profTemplate = RESTHELPER.checkIfDefined(npa, None, 'NPA', profTemplate, 'Npa')
    profTemplate = RESTHELPER.checkIfDefined(nxx, None, 'NXX', profTemplate, 'Nxx')
    profTemplate = RESTHELPER.checkIfDefined(tenantId, None, 'TENANTID', profTemplate, 'TenantId')
    profTemplate = RESTHELPER.checkIfDefined(exemptionCodeListStr, None, 'EXEMPTIONCODELIST', profTemplate, 'ExemptionCodeList')

    url = '/'+RESTV3.urlPrefix+'/subscription/' + str(queryValue)
    if routingType and routingValue :
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#====================================================================
def deleteSubscription(V3inst, queryValue=None, queryType='ExternalId', deleteSession=False, deleteDevices=False,
        apiEventData=None, now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True, multiRequestBuild=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()

    # Get subscriber OID if queryType is not ObjectId
    if queryType != 'ObjectId':
        queryResponse = querySubscription(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/subscription/' + str(queryValue)

    # URL extension for delete devices
    if deleteDevices == True or deleteDevices == '1' or deleteDevices == 1:
                 url += '?deleteDevice=True'
    else:        url += '?deleteDevice=False'
    if deleteSession == True:
        url += '&deleteSession=True'
    if routingType and routingValue :
        url += '&TrafficRouteData='+routingType + str(routingValue)

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        #print apiEventDataStr
        if apiEventDataStr and apiEventDataStr.strip(): url += '&ApiEventData=' + apiEventDataStr

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        #if apiEventData is not None:
        #    print 'apiEventData', apiEventDataStr

    response = V3inst.delete(url, amp=True)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#====================================================================
def createUserAndSubscription(V3inst,
        # User
        userId=None, userExternalId=None, firstName=None, lastName=None,
        contactEmail=None, contactPhoneNumber=None, contactPushTokenList=None, notificationPreference=None,
        language=None, userAttr=None,  userStatus=None, userApiEventData=None, 
        # Subscription
        subExternalId=None, subStatus=None, timeZone=None, billingCycle=None, dateOffset=None,
        taxStatus=None, taxCertificate=None, taxLocation=None, glCenter=None, name=None, subAttr=None,
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        subApiEventData=None,
        # Role
        rolesExternalIds=None, rolesPricingIds=None,
        #
        now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True):

        # User
        (uRetCode, uOid) = createUser(V3inst, userId=userId, externalId=userExternalId, firstName=firstName,
                              lastName=lastName, contactEmail=contactEmail, contactPhoneNumber=contactPhoneNumber,
                              contactPushTokenList=contactPushTokenList, notificationPreference=notificationPreference,
                              language=language, attr=userAttr, status=userStatus, tenantId=tenantId, apiEventData=userApiEventData,
                              now=now, routingType=routingType, routingValue=routingValue, executeMode=executeMode,
                              eventPass=eventPass)
        # Subscription
        (sRetCode, sOid) = createSubscription(V3inst, externalId=subExternalId, status=subStatus, timeZone=timeZone,
                              billingCycle=billingCycle, dateOffset=dateOffset, taxStatus=taxStatus,
                              taxCertificate=taxCertificate, taxLocation=taxLocation, glCenter=glCenter, name=name, attr=subAttr,
                              customerType=customerType, serviceAddress=serviceAddress, npa=npa, nxx=nxx, tenantId=tenantId,
                              apiEventData=subApiEventData, now=now, routingType=routingType, routingValue=routingValue,
                              executeMode=executeMode, eventPass=eventPass)

        # userAddSubscription
        retCode = userAddSubscription(V3inst, userQueryValue=uOid, subQueryValue=sOid, 
                  rolesExternalIds=rolesExternalIds, rolesPricingIds=rolesPricingIds,
                  now=now, routingType=routingType, routingValue=routingValue, executeMode=executeMode, eventPass=eventPass)

        # For nor just assume it passes
        return (COMMON.debugSuccess(method='createUserAndSubscription', shouldPass=eventPass), uOid, sOid)

#=============================================================
def createUser(V3inst, userId=None, externalId=None, firstName=None, lastName=None,
        contactEmail=None, contactPhoneNumber=None, contactPushTokenList=None, notificationPreference=None,
        language=None, attr=None,  status=None, apiEventData=None, now=None, routingType=None, routingValue=None, executeMode=None,
        tenantId=None, eventPass=True, multiRequestBuild=None, returnTemplate=False, timeZone=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    global templates

    attrStr = None
    if attr is not None:
        #print 'Create subscriber:  attr = ' + str(attr)
        attrStr = parseAttrMdc(attr)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    #build ContactPushTokenList with  value
    contactPushTokenListStr = ''
    if contactPushTokenList is not None:
        contactPushTokenListStr = createContactPushTokenList(contactPushTokenList)

    profTemplate = open(templates + 'user_create'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(userId, None, 'USERID', profTemplate, 'UserId')
    profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'EXTERNALID', profTemplate, 'ExternalId')
    profTemplate = RESTHELPER.checkIfDefined(firstName, None, 'FIRSTNAME', profTemplate, 'FirstName')
    profTemplate = RESTHELPER.checkIfDefined(lastName, None, 'LASTNAME', profTemplate, 'LastName')
    profTemplate = RESTHELPER.checkIfDefined(contactEmail, None, 'EMAIL', profTemplate, 'ContactEmail')
    profTemplate = RESTHELPER.checkIfDefined(contactPhoneNumber, None, 'PHONENUMBER', profTemplate, 'ContactPhoneNumber')
    profTemplate = RESTHELPER.checkIfDefined(contactPushTokenListStr, '', 'PUSHTOKENLIST',
                         profTemplate,'ContactPushTokenList')
    profTemplate = RESTHELPER.checkIfDefined(notificationPreference, None, 'NOTIFICATION', profTemplate,
        'NotificationPreference')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(language, None, 'LANGUAGE', profTemplate, 'Language')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    profTemplate = RESTHELPER.checkIfDefined(tenantId, None, 'TENANTID', profTemplate, 'TenantId')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(timeZone, None, 'TIMEZONE', profTemplate, 'TimeZone')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    if returnTemplate: return profTemplate
   

    url = '/'+RESTV3.urlPrefix+'/user'
    if routingType and routingValue :
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method='createUser', shouldPass=eventPass, returnParam='ObjectId')

#=============================================================
def queryUser(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None, routingType=None, routingValue=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    # Get start of URL
    if   queryType == 'ObjectId':       url = '/'+RESTV3.urlPrefix+'/user/'
    elif queryType == 'ExternalId':     url = '/'+RESTV3.urlPrefix+'/user/ExternalId+'
    elif queryType == 'UserId':         url = '/'+RESTV3.urlPrefix+'/user/UserId+'
    elif queryType == 'SubscriptionObjectId': url = '/'+RESTV3.urlPrefix+'/user/SubscriptionObjectId+'
    elif queryType == 'SubscriptionExternalId': url = '/'+RESTV3.urlPrefix+'/user/SubscriptionExternalId+'
    elif queryType == 'GroupObjectId': url ='/'+RESTV3.urlPrefix+'/user/GroupObjectId+'
    elif queryType == 'GroupExternalId': url = '/'+RESTV3.urlPrefix+'/user/GroupExternalId+'
 
    # Add value
    url += str(queryValue)

    if routingType and routingValue :
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#====================================================================
def modifyUserAndAuthData(V3inst, queryValue=None, queryType='ExternalId', userId=None, externalId=None, firstName=None, lastName=None,
        contactEmail=None, contactPhoneNumber=None, contactPushTokenList=None, notificationPreference=None,
        language=None, attr=None, status=None, loginId=None, password=None, userApiEventData=None, authApiEventData=None, 
        routingType=None, routingValue=None, now=None, executeMode=None, eventPass=True, lastActivityUpdateTime=None, 
        apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    global templates

    userData = None
    authData = None

    userData = modifyUser(V3inst=V3inst, queryValue=queryValue, queryType=queryType, userId=userId, externalId=externalId,
        firstName=firstName, lastName=lastName, contactEmail=contactEmail, contactPhoneNumber=contactPhoneNumber,
        contactPushTokenList=contactPushTokenList, notificationPreference=notificationPreference,
        language=language, attr=attr, status=status, lastActivityUpdateTime=lastActivityUpdateTime, apiEventData=userApiEventData,
        returnTemplate=True)

    userData = re.sub('.*xml version.*\n?','',userData)
    userData = userData.rstrip('\n')

    authData = userModifyAuthData(V3inst=V3inst, queryValue=queryValue, queryType=queryType,
        loginId=loginId, password=password, apiEventData=authApiEventData, returnTemplate=True)
    authData = re.sub('.*xml version.*\n?','',authData)
    authData = authData.rstrip('\n')

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'user_modify_user_and_authdata'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(userData, None, 'USER', profTemplate, 'User')
    profTemplate = RESTHELPER.checkIfDefined(authData, None, 'AUTHDATA', profTemplate, 'AuthData')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')

    url = '/'+RESTV3.urlPrefix+'/service/user/' + str(queryValue)
    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#====================================================================
def modifyUser(V3inst, queryValue=None, queryType='ExternalId', userId=None, externalId=None, firstName=None, lastName=None,
        contactEmail=None, contactPhoneNumber=None, contactPushTokenList=None, notificationPreference=None,
        language=None, attr=None, status=None, routingType=None, routingValue=None, now=None, executeMode=None,
        lastActivityUpdateTime=None, tenantId=None, apiEventData=None, eventPass=True, multiRequestBuild=None, returnTemplate=False):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    global templates
    # Get subscriber OID if queryType is not ObjectId
    if queryType != 'ObjectId':
        queryResponse = queryUser(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    attrStr = None
    if attr is not None:
        attrStr = parseAttrMdc(attr)

    #build ContactPushTokenList with  value
    contactPushTokenListStr = ''
    if contactPushTokenList is not None:
        contactPushTokenListStr = createContactPushTokenList(contactPushTokenList)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'user_modify'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'EXTERNALID', profTemplate, 'ExternalId')
    profTemplate = RESTHELPER.checkIfDefined(userId, None, 'USERID', profTemplate, 'UserId')
    profTemplate = RESTHELPER.checkIfDefined(firstName, None, 'FIRSTNAME', profTemplate, 'FirstName')
    profTemplate = RESTHELPER.checkIfDefined(lastName, None, 'LASTNAME', profTemplate, 'LastName')
    profTemplate = RESTHELPER.checkIfDefined(contactEmail, None, 'EMAIL', profTemplate, 'ContactEmail')
    profTemplate = RESTHELPER.checkIfDefined(contactPhoneNumber, None, 'PHONENUMBER', profTemplate, 'ContactPhoneNumber')
    profTemplate = RESTHELPER.checkIfDefined(contactPushTokenListStr, '', 'PUSHTOKENLIST',
                         profTemplate,'ContactPushTokenList')
    profTemplate = RESTHELPER.checkIfDefined(notificationPreference, None, 'NOTIFICATION', profTemplate,
        'NotificationPreference')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(language, None, 'LANGUAGE', profTemplate, 'Language')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    profTemplate = RESTHELPER.checkIfDefined(tenantId, None, 'TENANTID', profTemplate, 'TenantId')
    profTemplate = RESTHELPER.checkIfDefined(lastActivityUpdateTime, None, 'LASTACTIVITYUPDATETIME',
        profTemplate, 'LastActivityUpdateTime')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    if returnTemplate:
        return profTemplate

    url = '/'+RESTV3.urlPrefix+'/user/' + str(queryValue)
    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#====================================================================
def deleteUser(V3inst, queryValue=None, queryType='ExternalId', userId=None, apiEventData=None, 
        deleteSubscription=None, deleteDevices=None, deleteSession=None,
        now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True, multiRequestBuild=None, removeExplicitMembership=False):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/'+RESTV3.urlPrefix+'/user/' 
    if queryType == 'ObjectId':
        url += str(queryValue)
    else:
        url += str(queryType) + '+' + str(queryValue)

    delim = '?'
    amp = False
    
    if routingType and routingValue :
        url += str(delim) + 'TrafficRouteData='+routingType + str(routingValue)
        delim = '&'
        amp = True

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip():
                url += delim + 'ApiEventData=' +apiEventDataStr
                delim = '&'
                amp = True

    if deleteDevices == True or deleteDevices == '1' or deleteDevices == 1:
        url += str(delim) + 'deleteDevice=True'
    else: url += delim + 'deleteDevice=False'
    delim = '&'
    amp = True

    if deleteSubscription == True or deleteSubscription == '1' or deleteSubscription == 1:
          url += str(delim) + 'deleteSubscription=True'
    else: url += delim + 'deleteSubscription=False'

    if deleteSession == True or deleteSession == '1' or deleteSession == 1:
          url += str(delim) + 'deleteSession=True'
    else: url += delim + 'deleteSession=False'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#====================================================================
def userQueryAuthData(V3inst, queryValue=None, queryType='ExternalId', now=None,
        routingType=None, routingValue=None, executeMode=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    # Get start of URL
    if   queryType == 'ObjectId':       url = '/'+RESTV3.urlPrefix+'/user/'
    elif queryType == 'ExternalId':     url = '/'+RESTV3.urlPrefix+'/user/ExternalId+'
    elif queryType == 'UserId':         url = '/'+RESTV3.urlPrefix+'/user/UserId+'

    # Add value
    url += str(queryValue) + '/authentication'
    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)

    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def userVerifyAuthData(V3inst, queryValue=None, queryType='ExternalId', password='pwd', now=None,
        routingType=None, routingValue=None, executeMode=None, eventPass=True, multiRequestBuild=None):

   # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryUser(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    profTemplate = open(templates + 'user_verify_authdata'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(password, None, 'PASSWORD', profTemplate, 'Password')
    url = '/'+RESTV3.urlPrefix+'/service/user/' + str(queryValue) + '/authentication/verify'
    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
            print(funcName + ' url: ' + url)
            print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def userModifyAuthData(V3inst, queryValue=None, queryType='ExternalId', loginId=None, password=None, now=None,
        routingType=None, routingValue=None, executeMode=None, eventPass=True, isService=False, multiRequestBuild=None,
        apiEventData=None, returnTemplate=False):

   # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryUser(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'user_modify_authdata'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(loginId, None, 'LOGINID', profTemplate, 'LoginId')
    profTemplate = RESTHELPER.checkIfDefined(password, None, 'PASSWORD', profTemplate, 'Password')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    if returnTemplate:
        return profTemplate
    serviceUrl=''
    if isService :
        serviceUrl ='/service'
    url = '/'+RESTV3.urlPrefix+serviceUrl+'/user/' + str(queryValue) + '/authentication'
    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
            print(funcName + ' url: ' + url)
            print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def userModifyPassword(V3inst, queryValue=None, queryType='ExternalId', oldPassword='old', newPassword='new', now=None,
        apiEventData=None, routingType=None, routingValue=None, executeMode=None, eventPass=True, multiRequestBuild=None):

   # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryUser(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'user_modify_password'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(oldPassword, None, 'OLDPASSWORD', profTemplate, 'OldPassword')
    profTemplate = RESTHELPER.checkIfDefined(newPassword, None, 'NEWPASSWORD', profTemplate, 'NewPassword')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    url = '/'+RESTV3.urlPrefix+'/service/user/' + str(queryValue) + '/password'
    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
            print(funcName + ' url: ' + url)
            print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def userAddGroup(V3inst, userQueryValue=None, userQueryType='ObjectId', grpQueryValue=None, grpQueryType='ObjectId',
        rolesPricingIds=None, rolesExternalIds=None, now=None, routingType=None, routingValue=None, executeMode=None,
        apiEventData=None, eventPass=True, multiRequestBuild=None):

   # Get function name
    funcName = QAUTILS.getFunctionName()

    if userQueryType != 'ObjectId':
        queryResponse = queryUser(V3inst=V3inst, queryValue=userQueryValue, queryType=userQueryType, now=now)
        userQueryValue = getOID(queryResponse)

    if grpQueryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=grpQueryValue, queryType=grpQueryType, now=now)
        grpQueryValue = getOID(queryResponse)

    roleArray = None
    if rolesPricingIds or rolesExternalIds:
        roleArray = getRoleArray(rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    tag = 'MtxRequestUserAddGroup'
    profTemplate = open(templates + 'user_roles'+RESTV3.fileType).read()
    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        profTemplate = RESTHELPER.checkIfDefined(tag, None, 'STARTTAG', profTemplate, '$')
    else:
        profTemplate = RESTHELPER.checkIfDefined('<' + tag + '>', None, 'STARTTAG', profTemplate, 'ONEWORDLINE')
        profTemplate = RESTHELPER.checkIfDefined('</' + tag + '>', None, 'ENDTAG', profTemplate, 'ONEWORDLINE')
    profTemplate = RESTHELPER.checkIfDefined(roleArray, None, 'ROLES', profTemplate, 'RoleArray')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')

    url = '/'+RESTV3.urlPrefix+'/user/' + str(userQueryValue) + '/group/' + str(grpQueryValue)
    if routingType and routingValue :
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def userModifyGroup(V3inst, userQueryValue=None, userQueryType='ObjectId', grpQueryValue=None, grpQueryType='ObjectId',
        rolesPricingIds=None, rolesExternalIds=None, now=None, routingType=None, routingValue=None, executeMode=None,
        apiEventData=None, eventPass=True, multiRequestBuild=None, removeExplicitMembership=False):

   # Get function name
    funcName = QAUTILS.getFunctionName()

    if userQueryType != 'ObjectId':
        queryResponse = queryUser(V3inst=V3inst, queryValue=userQueryValue, queryType=userQueryType, now=now)
        userQueryValue = getOID(queryResponse)

    if grpQueryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=grpQueryValue, queryType=grpQueryType, now=now)
        grpQueryValue = getOID(queryResponse)

    roleArray = None
    if rolesPricingIds or rolesExternalIds:
        roleArray = getRoleArray(rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    tag = 'MtxRequestUserModifyGroup'
    profTemplate = open(templates + 'user_roles'+RESTV3.fileType).read()
    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        profTemplate = RESTHELPER.checkIfDefined(tag, None, 'STARTTAG', profTemplate, '$')
    else:
        profTemplate = RESTHELPER.checkIfDefined('<' + tag + '>', None, 'STARTTAG', profTemplate, 'ONEWORDLINE')
        profTemplate = RESTHELPER.checkIfDefined('</' + tag + '>', None, 'ENDTAG', profTemplate, 'ONEWORDLINE')
    profTemplate = RESTHELPER.checkIfDefined(roleArray, None, 'ROLES', profTemplate, 'RoleArray')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')

    url = '/'+RESTV3.urlPrefix+'/user/' + str(userQueryValue) + '/group/' + str(grpQueryValue)
    if routingType and routingValue :
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def userRemoveGroup(V3inst, userQueryValue=None, userQueryType='ObjectId', grpQueryValue=None, grpQueryType='ObjectId',
        roles=None, apiEventData=None, now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True, multiRequestBuild=None, removeExplicitMembership=False):

   # Get function name
    funcName = QAUTILS.getFunctionName()

    if userQueryType != 'ObjectId':
        queryResponse = queryUser(V3inst=V3inst, queryValue=userQueryValue, queryType=userQueryType, now=now)
        userQueryValue = getOID(queryResponse)

    if grpQueryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=grpQueryValue, queryType=grpQueryType, now=now)
        grpQueryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/user/' + str(userQueryValue) + '/group/' + str(grpQueryValue)

    delim = '?'
    amp = False
    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType + str(routingValue)
        delim = '&'

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip():
                url += delim + 'ApiEventData=' +apiEventDataStr
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def userAddSubscription(V3inst, userQueryValue=None, userQueryType='ObjectId', subQueryValue=None, subQueryType='ObjectId',
        rolesPricingIds=None, rolesExternalIds=None, now=None, routingType=None, routingValue=None, executeMode=None,
        apiEventData=None, eventPass=True, multiRequestBuild=None):

   # Get function name
    funcName = QAUTILS.getFunctionName()

    if userQueryType != 'ObjectId':
        queryResponse = queryUser(V3inst=V3inst, queryValue=userQueryValue, queryType=userQueryType, now=now)
        userQueryValue = getOID(queryResponse)

    if subQueryType != 'ObjectId':
        queryResponse = querySubscription(V3inst=V3inst, queryValue=subQueryValue, queryType=subQueryType, now=now)
        subQueryValue = getOID(queryResponse)

    roleArray = None
    if rolesPricingIds or rolesExternalIds:
        roleArray = getRoleArray(rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    tag = 'MtxRequestUserAddSubscription'
    profTemplate = open(templates + 'user_roles'+RESTV3.fileType).read()
    if RESTV3.restVersion != 'REST':
        profTemplate = RESTHELPER.checkIfDefined(tag, None, 'STARTTAG', profTemplate, '$')
    else:
        profTemplate = RESTHELPER.checkIfDefined('<' + tag + '>', None, 'STARTTAG', profTemplate, 'ONEWORDLINE')
        profTemplate = RESTHELPER.checkIfDefined('</' + tag + '>', None, 'ENDTAG', profTemplate, 'ONEWORDLINE')
    profTemplate = RESTHELPER.checkIfDefined(roleArray, None, 'ROLES', profTemplate, 'RoleArray')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')

    url = '/'+RESTV3.urlPrefix+'/user/' + str(userQueryValue) + '/subscription/' + str(subQueryValue)

    if routingType and routingValue :
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def userModifySubscription(V3inst, userQueryValue=None, userQueryType='ObjectId', subQueryValue=None, subQueryType='ObjectId',
        rolesPricingIds=None, rolesExternalIds=None, now=None, routingType=None, routingValue=None, executeMode=None,
        apiEventData=None, eventPass=True, multiRequestBuild=None, removeExplicitMembership=False):

   # Get function name
    funcName = QAUTILS.getFunctionName()

    if userQueryType != 'ObjectId':
        queryResponse = queryUser(V3inst=V3inst, queryValue=userQueryValue, queryType=userQueryType, now=now)
        userQueryValue = getOID(queryResponse)

    if subQueryType != 'ObjectId':
        queryResponse = querySubscription(V3inst=V3inst, queryValue=subQueryValue, queryType=subQueryType, now=now)
        subQueryValue = getOID(queryResponse)

    roleArray = None
    if rolesPricingIds or rolesExternalIds:
        roleArray = getRoleArray(rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    tag = 'MtxRequestUserModifySubscription'
    profTemplate = open(templates + 'user_roles'+RESTV3.fileType).read()
    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        profTemplate = RESTHELPER.checkIfDefined(tag, None, 'STARTTAG', profTemplate, '$')
    else:
        profTemplate = RESTHELPER.checkIfDefined('<' + tag + '>', None, 'STARTTAG', profTemplate, 'ONEWORDLINE')
        profTemplate = RESTHELPER.checkIfDefined('</' + tag + '>', None, 'ENDTAG', profTemplate, 'ONEWORDLINE')
    profTemplate = RESTHELPER.checkIfDefined(roleArray, None, 'ROLES', profTemplate, 'RoleArray')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')

    url = '/'+RESTV3.urlPrefix+'/user/' + str(userQueryValue) + '/subscription/' + str(subQueryValue)
    if routingType and routingValue :
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def userRemoveSubscription(V3inst, userQueryValue=None, userQueryType='ObjectId', subQueryValue=None, subQueryType='ObjectId',
        roles=None, apiEventData=None, now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True, multiRequestBuild=None, removeExplicitMembership=False):

   # Get function name
    funcName = QAUTILS.getFunctionName()

    if userQueryType != 'ObjectId':
        queryResponse = queryUser(V3inst=V3inst, queryValue=userQueryValue, queryType=userQueryType, now=now)
        userQueryValue = getOID(queryResponse)

    if subQueryType != 'ObjectId':
        queryResponse = querySubscription(V3inst=V3inst, queryValue=subQueryValue, queryType=subQueryType, now=now)
        subQueryValue = getOID(queryResponse)

    delim = '?'
    amp = False

    url = '/'+RESTV3.urlPrefix+'/user/' + str(userQueryValue) + '/subscription/' + str(subQueryValue)
    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType + str(routingValue)
        delim = '&'
        amp = True

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip():
                url += delim + 'ApiEventData=' + apiEventDataStr
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#============================================================
def queryUserEvent(V3inst, queryValue, queryType='ExternalId', querySize=None, queryCursor=None,
    eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypeStringArray =None, now=None, eventPass=True):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    # Some parameters should be lists of strings
    if eventTypeStringArray:
        if type(eventTypeStringArray) is list:  eventTypeStringArray = [str(i) for i in eventTypeStringArray]
        else:                                   eventTypeStringArray = [str(eventTypeStringArray)]

    # Translate subscriber to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryUser(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)
        if not eventPass and queryValue is None :
            queryValue = "9-9-9-9"

    # Assume optional parameters in the URL
    amp = False
    delim = '?'
    # Build the URL
    url = '/'+RESTV3.urlPrefix+'/user/' + queryValue + '/events'

    if querySize is not None:
        url += delim + 'querySize=' + str(querySize)
        amp = True
        delim = '&'
    if queryCursor is not None:
        url += delim + 'queryCursor=' + str(queryCursor)
        amp = True
        delim = '&'
    if eventTimeLowerBound is not None:
        url += delim + 'eventTimeLowerBound=' + convertTimeToUrlFormat(eventTimeLowerBound)
        amp = True
        delim = '&'
    if eventTimeUpperBound is not None:
        url += delim + 'eventTimeUpperBound=' + convertTimeToUrlFormat(eventTimeUpperBound)
        amp = True
        delim = '&'
    if eventTypeStringArray is not None:
        url += delim + 'eventTypes=' + ",".join(eventTypeStringArray)
        amp = True
        delim = '&'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    # Make the REST call
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    (result, cursor) = validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='queryCursor')
    if result : return (response,cursor)

#=============================================================
def groupAddUser(V3inst, userQueryValue=None, userQueryType='ObjectId', grpQueryValue=None, grpQueryType='ObjectId',
        rolesPricingIds=None, rolesExternalIds=None, now=None, routingType=None, routingValue=None, executeMode=None,
        apiEventData=None, eventPass=True, multiRequestBuild=None):

   # Get function name
    funcName = QAUTILS.getFunctionName()

    if userQueryType != 'ObjectId':
        queryResponse = queryUser(V3inst=V3inst, queryValue=userQueryValue, queryType=userQueryType, now=now)
        userQueryValue = getOID(queryResponse)

    if grpQueryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=grpQueryValue, queryType=grpQueryType, now=now)
        grpQueryValue = getOID(queryResponse)

    roleArray = None
    if rolesPricingIds or rolesExternalIds:
        roleArray = getRoleArray(rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    tag = 'MtxRequestGroupAddUser'
    profTemplate = open(templates + 'user_roles'+RESTV3.fileType).read()
    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        profTemplate = RESTHELPER.checkIfDefined(tag, None, 'STARTTAG', profTemplate, '$')
    else:
        profTemplate = RESTHELPER.checkIfDefined('<' + tag + '>', None, 'STARTTAG', profTemplate, 'ONEWORDLINE')
        profTemplate = RESTHELPER.checkIfDefined('</' + tag + '>', None, 'ENDTAG', profTemplate, 'ONEWORDLINE')
    profTemplate = RESTHELPER.checkIfDefined(roleArray, None, 'ROLES', profTemplate, 'RoleArray')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')

    url = '/'+RESTV3.urlPrefix+'/group/' + str(grpQueryValue) + '/user/' + str(userQueryValue)
    if routingType and routingValue :
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupModifyUser(V3inst, userQueryValue=None, userQueryType='ObjectId', grpQueryValue=None, grpQueryType='ObjectId',
        rolesPricingIds=None, rolesExternalIds=None, now=None, routingType=None, routingValue=None, executeMode=None,
        apiEventData=None, eventPass=True, multiRequestBuild=None, removeExplicitMembership=False):

   # Get function name
    funcName = QAUTILS.getFunctionName()

    if userQueryType != 'ObjectId':
        queryResponse = queryUser(V3inst=V3inst, queryValue=userQueryValue, queryType=userQueryType, now=now)
        userQueryValue = getOID(queryResponse)

    if grpQueryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=grpQueryValue, queryType=grpQueryType, now=now)
        grpQueryValue = getOID(queryResponse)

    roleArray = None
    if rolesPricingIds or rolesExternalIds:
        roleArray = getRoleArray(rolesPricingIds=rolesPricingIds, rolesExternalIds=rolesExternalIds)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    tag = 'MtxRequestGroupModifyUser'
    profTemplate = open(templates + 'user_roles'+RESTV3.fileType).read()
    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        profTemplate = RESTHELPER.checkIfDefined(tag, None, 'STARTTAG', profTemplate, '$')
    else:
        profTemplate = RESTHELPER.checkIfDefined('<' + tag + '>', None, 'STARTTAG', profTemplate, 'ONEWORDLINE')
        profTemplate = RESTHELPER.checkIfDefined('</' + tag + '>', None, 'ENDTAG', profTemplate, 'ONEWORDLINE')
    profTemplate = RESTHELPER.checkIfDefined(roleArray, None, 'ROLES', profTemplate, 'RoleArray')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')

    url = '/'+RESTV3.urlPrefix+'/group/' + str(grpQueryValue) + '/user/' + str(userQueryValue)
    if routingType and routingValue :
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupRemoveUser(V3inst, userQueryValue=None, userQueryType='ObjectId', grpQueryValue=None, grpQueryType='ObjectId',
        apiEventData=None, roles=None, now=None, routingType=None, routingValue=None, executeMode=None, eventPass=True, multiRequestBuild=None, removeExplicitMembership=False):

   # Get function name
    funcName = QAUTILS.getFunctionName()

    if userQueryType != 'ObjectId':
        queryResponse = queryUser(V3inst=V3inst, queryValue=userQueryValue, queryType=userQueryType, now=now)
        userQueryValue = getOID(queryResponse)

    if grpQueryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=grpQueryValue, queryType=grpQueryType, now=now)
        grpQueryValue = getOID(queryResponse)

    delim = '?'
    amp = False

    url = '/'+RESTV3.urlPrefix+'/group/' + str(grpQueryValue) + '/user/' + str(userQueryValue)
    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType + str(routingValue)
        delim = '&'
        amp = True

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip():
                url += delim + 'ApiEventData=' + apiEventDataStr
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def queryGroupUsers(V3inst, queryValue=None, queryType='ObjectId', returnExternalId=None, querySize=None, queryCursor=None,
        routingType=None, routingValue=None, eventPass=True, now=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    # Translate subscriber to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)

    # Assume optional parameters in the URL
    amp = False
    delim = '?'
    # Build the URL
    url = '/'+RESTV3.urlPrefix+'/group/' + queryValue + '/users'

    if querySize is not None:
        url += delim + 'querySize=' + str(querySize)
        amp = True
        delim = '&'
    if queryCursor is not None:
        url += delim + 'queryCursor=' + str(queryCursor)
        amp = True
        delim = '&'
    if returnExternalId is not None:
        url += delim + 'returnExternalId=' + str(returnExternalId)
        amp = True
        delim = '&'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    # Make the REST call
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    (result, cursor) = validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='queryCursor')
    if result : return (response,cursor)

#=============================================================
def queryUserGroups(V3inst, queryValue=None, queryType='ObjectId', returnExternalId=None, querySize=None, queryCursor=None,
        routingType=None, routingValue=None, eventPass=True, now=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    # Translate subscriber to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryUser(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)

    # Assume optional parameters in the URL
    amp = False
    delim = '?'
    # Build the URL
    url = '/'+RESTV3.urlPrefix+'/user/' + queryValue + '/groups'

    if querySize is not None:
        url += delim + 'querySize=' + str(querySize)
        amp = True
        delim = '&'
    if queryCursor is not None:
        url += delim + 'queryCursor=' + str(queryCursor)
        amp = True
        delim = '&'
    if returnExternalId is not None:
        url += delim + 'returnExternalId=' + str(returnExternalId)
        amp = True
        delim = '&'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    # Make the REST call
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    (result, cursor) = validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='queryCursor')
    if result : return (response,cursor)

#=============================================================
def queryUserSubscriptions(V3inst, queryValue=None, queryType='ObjectId', returnExternalId=None, querySize=None, queryCursor=None,
        routingType=None, routingValue=None, eventPass=True, now=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    # Translate subscriber to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryUser(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)

    # Assume optional parameters in the URL
    amp = False
    delim = '?'
    # Build the URL
    url = '/'+RESTV3.urlPrefix+'/user/' + queryValue + '/subscriptions'

    if querySize is not None:
        url += delim + 'querySize=' + str(querySize)
        amp = True
        delim = '&'
    if queryCursor is not None:
        url += delim + 'queryCursor=' + str(queryCursor)
        amp = True
        delim = '&'
    if returnExternalId is not None:
        url += delim + 'returnExternalId=' + str(returnExternalId)
        amp = True
        delim = '&'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    # Make the REST call
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    (result, cursor) = validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='queryCursor')
    if result : return (response,cursor)

#=============================================================
def querySubscriberUsers(V3inst, queryValue=None, queryType='ObjectId', returnExternalId=None, querySize=None, queryCursor=None,
        routingType=None, routingValue=None, eventPass=True, now=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    

    # Translate subscriber to OID if needed
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)

    # Assume optional parameters in the URL
    amp = False
    delim = '?'
    # Build the URL
    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + queryValue + '/users'

    if querySize is not None:
        url += delim + 'querySize=' + str(querySize)
        amp = True
        delim = '&'
    if queryCursor is not None:
        url += delim + 'queryCursor=' + str(queryCursor)
        amp = True
        delim = '&'
    if returnExternalId is not None:
        url += delim + 'returnExternalId=' + str(returnExternalId)
        amp = True
        delim = '&'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    # Make the REST call
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    (result, cursor) = validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='queryCursor')
    if result : return (response,cursor)

#=============================================================
def createSubscriber(V3inst, externalId=None, now=None, payload=None, billingCycle=None, eventPass=True,
        firstName=None, lastName=None, contactEmail=None, contactPhoneNumber=None, contactPushTokenList=None, notificationPreference=None,
        timeZone=None, attr=None, sharedWalletQuery=None, status=None, taxStatus=None, taxCertificate=None, taxLocation=None,
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        language=None, dateOffset=None, glCenter=None, name=None, apiEventData=None, routingType=None, routingValue=None, executeMode=None,
        returnTemplate=False, multiRequestBuild=None, apiEventSecurityInfo=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    global templates
    if payload:
        firstName = payload['firstName'] 
        lastName = payload['lastName']
        contactEmail = payload['contactEmail']
        contactPhoneNumber = payload['contactPhoneNumber']
        timeZone = payload['timeZone']
        attr = payload['attr']
        notificationPreference = payload['notificationPreference']

    attrStr = None
    if attr is not None:
        #print 'Create subscriber:  attr = ' + str(attr)
        attrStr = parseAttrMdc(attr)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    #build ContactPushTokenList with  value
    contactPushTokenListStr = ''
    if contactPushTokenList is not None:
        contactPushTokenListStr = createContactPushTokenList(contactPushTokenList)

    exemptionCodeListStr = None
    if  exemptionCodeList is not None:
        exemptionCodeListStr = createExemptionCodeList(exemptionCodeList)

    #check if we passed a string for billingCycle and convert it to a billing cycle template
    if billingCycle and type(billingCycle) is int :
        billingCycle = createBillingCycleData(int(billingCycle), startTime=now, dateOffset=dateOffset)

    apiEventSecurityInfoStr = None
    if apiEventSecurityInfo is not None:
        apiEventSecurityInfoStr = parseAttrMdc(apiEventSecurityInfo)

    profTemplate = open(templates + 'subscriber_create'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'EXTERNALID', profTemplate, 'ExternalId')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    profTemplate = RESTHELPER.checkIfDefined(firstName, None, 'FIRSTNAME', profTemplate, 'FirstName')
    profTemplate = RESTHELPER.checkIfDefined(lastName, None, 'LASTNAME', profTemplate, 'LastName')
    profTemplate = RESTHELPER.checkIfDefined(contactEmail, None, 'EMAIL', profTemplate, 'ContactEmail')
    profTemplate = RESTHELPER.checkIfDefined(contactPhoneNumber, None, 'PHONENUMBER', profTemplate,
        'ContactPhoneNumber')
    profTemplate = RESTHELPER.checkIfDefined(contactPushTokenListStr, '', 'PUSHTOKENLIST',
                         profTemplate,'ContactPushTokenList')
    profTemplate = RESTHELPER.checkIfDefined(notificationPreference, None, 'NOTIFICATION', profTemplate,
        'NotificationPreference')
    profTemplate = RESTHELPER.checkIfDefined(timeZone, None, 'TIMEZONE', profTemplate, 'TimeZone')
    profTemplate = RESTHELPER.checkIfDefined(billingCycle, None, 'BILLINGCYCLE', profTemplate, 'BillingCycle')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(sharedWalletQuery, None, 'SHAREDWALLETDATA', profTemplate,
        'SharedWalletData')
    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        profTemplate = RESTHELPER.checkIfDefined(taxStatus, None, 'TAXsTATUS', profTemplate, 'TaxStatus')
    else: profTemplate = RESTHELPER.checkIfDefined(taxStatus, None, 'TAXSTATUS', profTemplate, 'TaxStatus')
    profTemplate = RESTHELPER.checkIfDefined(taxCertificate, None, 'TAXCERTIFICATE', profTemplate, 'TaxCertificate')
    profTemplate = RESTHELPER.checkIfDefined(taxLocation, None, 'TAXLOCATION', profTemplate, 'TaxLocation')
    profTemplate = RESTHELPER.checkIfDefined(glCenter, None, 'GLCENTER', profTemplate, 'GlCenter')
    profTemplate = RESTHELPER.checkIfDefined(name, None, 'NAME', profTemplate, 'Name')
    profTemplate = RESTHELPER.checkIfDefined(language, None, 'LANGUAGE', profTemplate, 'Language')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(customerType, None, 'CUSTOMERTYPE', profTemplate, 'CustomerType')
    profTemplate = RESTHELPER.checkIfDefined(serviceAddress, None, 'SERVICEADDRESS', profTemplate, 'ServiceAddress')
    profTemplate = RESTHELPER.checkIfDefined(npa, None, 'NPA', profTemplate, 'Npa')
    profTemplate = RESTHELPER.checkIfDefined(nxx, None, 'NXX', profTemplate, 'Nxx')
    profTemplate = RESTHELPER.checkIfDefined(tenantId, None, 'TENANTID', profTemplate, 'TenantId')
    profTemplate = RESTHELPER.checkIfDefined(exemptionCodeListStr, None, 'EXEMPTIONCODELIST', profTemplate, 'ExemptionCodeList')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventSecurityInfoStr, None, 'APIEVENTSECURITYINFO', profTemplate, 'ApiEventSecurityInfo')
#    profTemplate = RESTHELPER.checkIfDefined(routeData, None, 'ROUTEDATA', profTemplate, 'RouteData')
    
#    profTemplate = RESTHELPER.checkIfDefined(now, None, 'ROUTINGTYPE', profTemplate, 'RoutingType')
#    profTemplate = RESTHELPER.checkIfDefined(now, None, 'ROUTINGVALUE', profTemplate, 'RoutingValue')

    if returnTemplate:
        return profTemplate

    if routingType and routingValue :
        url = '/'+RESTV3.urlPrefix+'/subscriber?TrafficRouteData='+routingType + str(routingValue)
    else:
        url = '/'+RESTV3.urlPrefix+'/subscriber'
    
    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method='createSubscriber', shouldPass=eventPass, returnParam='ObjectId')

#========================================================
def modifySubscriber(V3inst, queryValue, payload=None, eventPass=True, queryType='ExternalId',
        firstName=None, lastName=None, contactEmail=None, contactPhoneNumber=None, contactPushTokenList=None, notificationPreference=None,
        timeZone=None, attr=None, billingCycle=None, now=None, status=None, taxStatus=None, taxCertificate=None, taxLocation=None,
        language=None, externalId=None, dateOffset=None, glCenter=None, name=None, paymentGatewayUserId=None, currentPaymentTokenResourceId=None,
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        apiEventData=None, lastActivityUpdateTime=None, executeMode=None, billingCycleDisabled=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    global templates
    # Get subscriber OID if queryType is not ObjectId
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    if payload:
        firstName = payload['firstName'] 
        lastName = payload['lastName']
        contactEmail = payload['contactEmail']
        contactPhoneNumber = payload['contactPhoneNumber']
        timeZone = payload['timeZone']
        attr = payload['attr']
        notificationPreference = payload['notificationPreference']

    attrStr = None
    if attr is not None:
        attrStr = parseAttrMdc(attr)

    #build ContactPushTokenList with  value
    contactPushTokenListStr = ''
    if contactPushTokenList is not None:
        contactPushTokenListStr = createContactPushTokenList(contactPushTokenList)

    if billingCycleDisabled:
        billingCycleDisabled='true'
    elif billingCycleDisabled == False:
        billingCycleDisabled='false'

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    exemptionCodeListStr = None
    if  exemptionCodeList is not None:
        exemptionCodeListStr = createExemptionCodeList(exemptionCodeList)

    #check if we passed a string for billingCycle and convert it to a billing cycle template
    if billingCycle and type(billingCycle) is int :
        billingCycle = createBillingCycleData(int(billingCycle), startTime=now, dateOffset=dateOffset)

    profTemplate = open(templates + 'subscriber_modify'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'EXTERNALID', profTemplate, 'ExternalId')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    profTemplate = RESTHELPER.checkIfDefined(firstName, None, 'FIRSTNAME', profTemplate, 'FirstName')
    profTemplate = RESTHELPER.checkIfDefined(lastName, None, 'LASTNAME', profTemplate, 'LastName')
    profTemplate = RESTHELPER.checkIfDefined(contactEmail, None, 'EMAIL', profTemplate, 'ContactEmail')
    profTemplate = RESTHELPER.checkIfDefined(contactPhoneNumber, None, 'PHONENUMBER', profTemplate,
        'ContactPhoneNumber')
    profTemplate = RESTHELPER.checkIfDefined(contactPushTokenListStr, '', 'PUSHTOKENLIST', profTemplate,
        'ContactPushTokenList')
    profTemplate = RESTHELPER.checkIfDefined(notificationPreference, None, 'NOTIFICATION', profTemplate,
        'NotificationPreference')
    profTemplate = RESTHELPER.checkIfDefined(timeZone, None, 'TIMEZONE', profTemplate, 'TimeZone')
    profTemplate = RESTHELPER.checkIfDefined(billingCycle, None, 'BILLINGCYCLE', profTemplate, 'BillingCycle')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        profTemplate = RESTHELPER.checkIfDefined(taxStatus, None, 'TAXsTATUS', profTemplate, 'TaxStatus')
    else: profTemplate = RESTHELPER.checkIfDefined(taxStatus, None, 'TAXSTATUS', profTemplate, 'TaxStatus')
    profTemplate = RESTHELPER.checkIfDefined(taxCertificate, None, 'TAXCERTIFICATE', profTemplate, 'TaxCertificate')
    profTemplate = RESTHELPER.checkIfDefined(taxLocation, None, 'TAXLOCATION', profTemplate, 'TaxLocation')
    profTemplate = RESTHELPER.checkIfDefined(glCenter, None, 'GLCENTER', profTemplate, 'GlCenter')
    profTemplate = RESTHELPER.checkIfDefined(name, None, 'NAME', profTemplate, 'Name')
    profTemplate = RESTHELPER.checkIfDefined(language, None, 'LANGUAGE', profTemplate, 'Language')
    profTemplate = RESTHELPER.checkIfDefined(paymentGatewayUserId, None, 'PAYMENTGATEWAYUSERID', profTemplate, 'PaymentGatewayUserId')
    profTemplate = RESTHELPER.checkIfDefined(currentPaymentTokenResourceId, None, 'CURRENTPAYMENTTOKENRECOURCEID',
        profTemplate, 'CurrentPaymentTokenResourceId')
    profTemplate = RESTHELPER.checkIfDefined(lastActivityUpdateTime, None, 'LASTACTIVITYUPDATETIME', 
        profTemplate, 'LastActivityUpdateTime')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(customerType, None, 'CUSTOMERTYPE', profTemplate, 'CustomerType')
    profTemplate = RESTHELPER.checkIfDefined(serviceAddress, None, 'SERVICEADDRESS', profTemplate, 'ServiceAddress')
    profTemplate = RESTHELPER.checkIfDefined(npa, None, 'NPA', profTemplate, 'Npa')
    profTemplate = RESTHELPER.checkIfDefined(nxx, None, 'NXX', profTemplate, 'Nxx')
    profTemplate = RESTHELPER.checkIfDefined(tenantId, None, 'TENANTID', profTemplate, 'TenantId')
    profTemplate = RESTHELPER.checkIfDefined(exemptionCodeListStr, None, 'EXEMPTIONCODELIST', profTemplate, 'ExemptionCodeList')

    profTemplate = RESTHELPER.checkIfDefined(billingCycleDisabled, None, 'billingCYCLEDISABLED', profTemplate, 'BillingCycleDisabled')

    url = '/'+RESTV3.urlPrefix+'/subscriber/' + str(queryValue)
    
    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

# Rehome a Subscriber (Requires a multi sub-domain engine configuration)
#=============================================================
def subscriberRehome(V3inst, queryValue, queryType='ObjectId', routingType='RouteId', routingValue=2, eventPass=True,
    apiEventData=None, multiRequestBuild=None):
    
    global restVersion

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/rehome/' + str(routingType) + '+' + str(routingValue)
    
    amp = False
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip():
                url += '&ApiEventData=' +apiEventDataStr
                amp = True

    # If Debug if globally se QAUTILS.DebugLevel t
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        
    response = V3inst.put(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    #print response
    if validateResponse(response=response, method='subscriberRehome', shouldPass=eventPass):
        return response

#=============================================================
def userRehome(V3inst, queryValue, queryType='ObjectId', routingType='RouteId', routingValue=2, eventPass=True,
    apiEventData=None, multiRequestBuild=None):
    global restVersion

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryUser(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/user/' + str(queryValue) + '/rehome/' + str(routingType) + '+' + str(routingValue)

    amp = False
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip():
                url += '&ApiEventData=' +apiEventDataStr
                amp = True

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.put(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    #print response
    if validateResponse(response=response, method='userRehome', shouldPass=eventPass):
        return response

#====================================================
def subscribeToOffer(V3inst, externalId, offerId=None, catalogItemId=None, offerStartTime=None,
        offerEndTime=None, eventPass=True, queryType='ExternalId', now=None, offerIsExternal=False,
        offerId2=None, attr=None,dupAttr=True,future=False, purchaseInfo=False, executeMode=None,
        chargeMethod=None, paymentMethodResourceId=None, paymentGatewayId=None, paymentGatewayOneTimeToken=None, chargeMethodAttr=None,
        paymentDueDate=None, paymentGatewayUserId=None, deferredSettlement=None, deferredSettlementTimeout=None, deferredSettlementTimeoutAction=None,
        returnDataTemplate=False, offerCycleType=None, offerCycleResourceId=None, offerCycleOffset=None, offerCycleStartTime=None,
        preActiveState=None, autoActivationTime=None, autoActivationRelativeOffsetUnit=None, autoActivationRelativeOffset=None, autoActivationCycleResourceId=None,
        activationExpirationTime=None, activationExpirationRelativeOffsetUnit=None, activationExpirationRelativeOffset=None, endTimeRelativeOffsetUnit=None, endTimeRelativeOffset=None,
        downPayment=None, isTargetResource=None, useTargetResource=None, isRecurringFailureAllowed=None, apiEventData=None,
        chargePurchaseProrationType=None, grantPurchaseProrationType=None, reason=None, info=None, eligibilityCheck=True, offerStatusValue=None, 
        contractPeriod=None, contractInterval=None, commitmentPeriod=None, commitmentPeriodInterval=None, isOpenContract=None,
        isPendingActivationAllowed=None, offerLifecycleProfileId=None,
        routingType=None, routingValue=None, parameterList=None, multiRequestBuild=None, etcScheduleRangeArray=None, etcScheduleRangeUnit=None,
        paymentScheduleRangeArray=None, paymentScheduleAmountArray=None, paymentScheduleLastAmount=None, delayCharge=None, geoData=None, endAfterCycleCount=None, noEndTime=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if now is None :
        now = offerStartTime
    if preActiveState:
        preActiveState = 'true'
    elif preActiveState == False:
        preActiveState = 'false'
    if deferredSettlement:
        deferredSettlement='true'
    if isRecurringFailureAllowed:
        isRecurringFailureAllowed = 'true'
    elif isRecurringFailureAllowed == False:
        isRecurringFailureAllowed = 'false'
    if isPendingActivationAllowed:
        isPendingActivationAllowed = 'true'
    elif isPendingActivationAllowed == False:
        isPendingActivationAllowed = 'false'

    # Get subscriber OID if queryType is not ObjectId
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=externalId, queryType=queryType, eventPass=None, now=now)
        externalId = getOID(queryResponse)
    
    # Process any input attributes
    attrStr = None
    if attr is not None:
        attrStr = parseAttrMdc(attr)
    chargeMethodAttrStr = None
    if chargeMethodAttr is not None:
        chargeMethodAttrStr = parseAttrMdc(chargeMethodAttr)
    
    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    if geoData is None:
       geoData = ""

    parameterArray = None
    if parameterList:
        parameterArray = parseParameterList(parameterList)

    # Allow for custom URLs (for BGAPI code)
    if CSV.overrideURL and 'purchase' in CSV.overrideOperations: custom = '/' + CSV.overrideURL
    else: custom = ''
    url = '/' + RESTV3.urlPrefix + custom + '/'+RESTV3.subUrl+'/' + str(externalId) + '/offers'
        
    if type(catalogItemId) is list:
        offerId = catalogItemId

    # populate contractParameterOverrideDataTemplate, which only support single one at moment
    contractParameterOverrideDataTemplate = createContractParameterOverrideData(etcScheduleRangeArray=etcScheduleRangeArray, etcScheduleRangeUnit=etcScheduleRangeUnit, paymentScheduleRangeArray=paymentScheduleRangeArray, paymentScheduleAmountArray=paymentScheduleAmountArray, paymentScheduleLastAmount=paymentScheduleLastAmount, delayCharge=delayCharge, contractPeriod=contractPeriod, contractInterval=contractInterval, commitmentPeriod=commitmentPeriod, commitmentPeriodInterval=commitmentPeriodInterval, isOpenContract=isOpenContract)   
 
    # Input may be a list or may be a single item
    if type(offerId) is list:
        offerDataList = ""
        # Purchase offer and validate for each, append created resource id to list
        profTemplate = open(templates + 'subscriber_purchase_offerList'+RESTV3.fileType).read()
        for offer in offerId:
            dataTemplate = open(templates + 'purchased_offer_data'+RESTV3.fileType).read()

            # populate paymentDueDate
            if type(paymentDueDate) is list:
                i = offerId.index(offer)
                dataTemplate = RESTHELPER.checkIfDefined(paymentDueDate[i], None, 'PAYMENTDUEDATE', dataTemplate, 'PaymentDueDate')
            else:
                dataTemplate = RESTHELPER.checkIfDefined(paymentDueDate, None, 'PAYMENTDUEDATE', dataTemplate, 'PaymentDueDate')

            # populate contractParameterOverride
            if contractParameterOverrideDataTemplate:
                dataTemplate = RESTHELPER.checkIfDefined(contractParameterOverrideDataTemplate, None, 'CONTRACTPARAMETEROVERRIDEDATA', dataTemplate, 'ONEWORDLINE')
            else:
                dataTemplate = RESTHELPER.removeOneWordLine(dataTemplate, 'CONTRACTPARAMETEROVERRIDEDATA')
                

            # Conditionally select product offer by ExternalId or ProductOfferId
            if offerIsExternal:
                dataTemplate = RESTHELPER.removeItem(dataTemplate, 'ProductOfferId')
                dataTemplate = RESTHELPER.removeItem(dataTemplate, 'CatalogItemId')
                dataTemplate = RESTHELPER.checkIfDefined(offer, None, 'OFFEREXTID', dataTemplate, 'ExternalId')
            else:
                dataTemplate = RESTHELPER.removeItem(dataTemplate, 'ExternalId')
                if catalogItemId:
                    dataTemplate = RESTHELPER.removeItem(dataTemplate, 'ProductOfferId')
                    dataTemplate = RESTHELPER.checkIfDefined(offer, None, 'CATALOGITEMID', dataTemplate, 'CatalogItemId')
                else:
                    dataTemplate = RESTHELPER.removeItem(dataTemplate, 'CatalogItemId')
                    dataTemplate = RESTHELPER.checkIfDefined(offer, None, 'OFFERID', dataTemplate, 'ProductOfferId')

            target = None
            cycle = None
            if isTargetResource is not None and useTargetResource is not None:
                i = offerId.index(offer)
                resource = isTargetResource[i]
                dataTemplate = RESTHELPER.checkIfDefined(resource, None, 'ISTARGETRESOURCE', dataTemplate, 'IsTargetResource')
                target = useTargetResource[i]
                cycle = offerCycleType[i]
            else:
                dataTemplate = RESTHELPER.removeItem(dataTemplate, 'IsTargetResource')
                cycle = offerCycleType

            if offerCycleType or offerCycleResourceId or offerCycleOffset or offerCycleStartTime:
                cycleTemplate = createCycleData(cycleType=cycle, cycleResourceId=offerCycleResourceId, cycleOffset=offerCycleOffset,
                                                cycleStartTime=offerCycleStartTime, useTargetResource=target)
            else: cycleTemplate = None
            dataTemplate = RESTHELPER.checkIfDefined(cycleTemplate, None, 'CYCLEDATA', dataTemplate, 'ONEWORDLINE')

            dataTemplate = RESTHELPER.checkIfDefined(offerStartTime, None, 'STARTTIME', dataTemplate, 'StartTime')
            dataTemplate = RESTHELPER.checkIfDefined(offerStatusValue, None, 'OFFERSTATUSVALUE', dataTemplate, 'OfferStatusValue')
            dataTemplate = RESTHELPER.checkIfDefined(offerLifecycleProfileId, None, 'OFFERLIFECYCLEPROFILEID', dataTemplate, 'OfferLifecycleProfileId')
            dataTemplate = RESTHELPER.checkIfDefined(endTimeRelativeOffsetUnit, None, 'ENDTIMERELATIVEOFFSETUNIT', dataTemplate, 'EndTimeRelativeOffsetUnit')
            dataTemplate = RESTHELPER.checkIfDefined(endTimeRelativeOffset, None, 'ENDTIMERELATIVEOFFSET', dataTemplate, 'EndTimeRelativeOffset')
            dataTemplate = RESTHELPER.checkIfDefined(offerEndTime, None, 'ENDTIME', dataTemplate, 'EndTime')
            dataTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', dataTemplate, 'Attr')
            dataTemplate = RESTHELPER.checkIfDefined(parameterArray, None, 'PARAMETERARRAY', dataTemplate, 'ParameterArray')

            dataTemplate = RESTHELPER.checkIfDefined(preActiveState, None, 'PREACTIVESTATE', dataTemplate, 'PreActiveState')
            dataTemplate = RESTHELPER.checkIfDefined(autoActivationTime, None, 'AUTOACTIVATIONTIME', dataTemplate, 'AutoActivationTime')
            dataTemplate = RESTHELPER.checkIfDefined(autoActivationRelativeOffsetUnit, None, 'AUTOACTIVATIONRELATIVEOFFSETUNIT', dataTemplate, 'AutoActivationRelativeOffsetUnit')
            dataTemplate = RESTHELPER.checkIfDefined(autoActivationRelativeOffset, None, 'aUTOACTIVATIONRELATIVEOFFSET', dataTemplate, 'AutoActivationRelativeOffset')
            dataTemplate = RESTHELPER.checkIfDefined(autoActivationCycleResourceId, None, 'AUTOACTIVATIONCYCLERESOURCEID', dataTemplate, 'AutoActivationCycleResourceId')
            dataTemplate = RESTHELPER.checkIfDefined(isPendingActivationAllowed, None, 'ISPENDINGACTIVATIONALLOWED', dataTemplate, 'IsPendingActivationAllowed')

            if type(chargePurchaseProrationType) is list:
                i = offerId.index(offer)
                dataTemplate = RESTHELPER.checkIfDefined(chargePurchaseProrationType[i], None, 'CHARGEPURCHASEPRORATIONTYPE', dataTemplate, 'ChargePurchaseProrationType')
                dataTemplate = RESTHELPER.checkIfDefined(grantPurchaseProrationType[i], None, 'GRANTPURCHASEPRORATIONTYPE', dataTemplate, 'GrantPurchaseProrationType')
                dataTemplate = RESTHELPER.checkIfDefined(reason[i], None, 'REASON', dataTemplate, 'Reason')
                dataTemplate = RESTHELPER.checkIfDefined(info[i], None, 'INFO', dataTemplate, 'Info')
            else:
                dataTemplate = RESTHELPER.checkIfDefined(chargePurchaseProrationType, None, 'CHARGEPURCHASEPRORATIONTYPE', dataTemplate, 'ChargePurchaseProrationType')
                dataTemplate = RESTHELPER.checkIfDefined(grantPurchaseProrationType, None, 'GRANTPURCHASEPRORATIONTYPE', dataTemplate, 'GrantPurchaseProrationType')
                dataTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', dataTemplate, 'Reason')
                dataTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', dataTemplate, 'Info')

            dataTemplate = RESTHELPER.checkIfDefined(activationExpirationTime, None, 'ACTIVATIONEXPIRATIONTIME', dataTemplate,
                'ActivationExpirationTime')
            dataTemplate = RESTHELPER.checkIfDefined(activationExpirationRelativeOffsetUnit, None, 'ACTIVATIONEXPIRATIONRELATIVEOFFSETUNIT',
                dataTemplate, 'ActivationExpirationRelativeOffsetUnit')
            dataTemplate = RESTHELPER.checkIfDefined(activationExpirationRelativeOffset, None, 'ACTIVATIONEXPIRATIONRELATIVEOFFSET', 
                dataTemplate, 'ActivationExpirationRelativeOffset')
            
            # Support backwards compatibility for down payment
            if downPayment:
                downPaymentData = open(templates + 'downPayment_data'+RESTV3.fileType).read()
                downPaymentData = RESTHELPER.checkIfDefined(downPayment, None, 'DOWNPAYMENT', downPaymentData, 'DownPayment')
            else: downPaymentData = None
            dataTemplate = RESTHELPER.checkIfDefined(downPaymentData, None, 'DOWNPAYMENT', dataTemplate, 'ONEWORDLINE')
            dataTemplate = RESTHELPER.checkIfDefined(isRecurringFailureAllowed, None, 'ISRECURRINGFAILUREALLOWED', dataTemplate, 'IsRecurringFailureAllowed')
            dataTemplate = RESTHELPER.checkIfDefined(endAfterCycleCount, None, 'ENDAFTERCYCLECOUNT', dataTemplate, 'EndAfterCycleCount')
            dataTemplate = RESTHELPER.checkIfDefined(noEndTime, None, 'NOENDTIME', dataTemplate, 'NoEndTime')

            if chargeMethod or paymentMethodResourceId or paymentGatewayId or paymentGatewayOneTimeToken or chargeMethodAttr:
                chargeMethodData = createChargeMethodData(chargeMethod=chargeMethod, paymentMethodResourceId=paymentMethodResourceId,
                                                          paymentGatewayId=paymentGatewayId, paymentGatewayUserId=paymentGatewayUserId,
                                                          paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, chargeMethodAttr=chargeMethodAttrStr,
                                                          deferredSettlement=deferredSettlement, deferredSettlementTimeout=deferredSettlementTimeout,
                                                          deferredSettlementTimeoutAction=deferredSettlementTimeoutAction)
            else: chargeMethodData = None
            profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')
            profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
            profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
            
            # Add template to list
            offerDataList = offerDataList + dataTemplate 

        if returnDataTemplate:
            return offerDataList

        profTemplate = RESTHELPER.checkIfDefined(offerDataList, None, 'OFFERDATALIST',profTemplate, 'OFFERDATALIST')
        if future: profTemplate = RESTHELPER.removeItem(profTemplate, 'EventTime')
        else:      profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
        profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'SUBID', profTemplate, 'ObjectId')
        
        profTemplate = RESTHELPER.checkIfDefined(eligibilityCheck, None, 'ELIGIBILITYCHECK', profTemplate, 'EligibilityCheck')
        profTemplate = RESTHELPER.checkIfDefined(geoData, None, 'GEODATA', profTemplate, 'GeoData')

        # If future, then more work to do
        if future:
                # Return from here, as we're scheuling future purchases as a task
                return profTemplate
        
        if routingType and routingValue :
            url += '?TrafficRouteData=' + str(routingType) + str(routingValue)
        # If Debug if globally set
        if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + profTemplate)

        response = V3inst.put(url, payload=profTemplate)
        if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

        vals = validateResponse(response=response, method=funcName,
            shouldPass=eventPass, returnParam='ResourceId')
        if type(vals) is bool:
               success = vals
               resourceId = None
        else:  (success, resourceId) = vals

        if purchaseInfo:
           return (passed(eventPass), response)
        else :
           return (passed(eventPass), resourceId)
    else:
        # Purchase offer and validate, return created resourceId
        profTemplate = open(templates + 'subscriber_purchase_offer'+RESTV3.fileType).read()

        # Conditionally select product offer by ExternalId or ProductOfferId
        if offerIsExternal:
            #print offerId2
            #profTemplate = RESTHELPER.removeItem(profTemplate, 'ProductOfferId')
            if catalogItemId:
                profTemplate = RESTHELPER.checkIfDefined(catalogItemId, None, 'OFFEREXTID', profTemplate, 'ExternalId')
                profTemplate = RESTHELPER.checkIfDefined(offerId2, None, 'CATALOGITEMID', profTemplate, 'CatalogItemId')
                profTemplate = RESTHELPER.removeItem(profTemplate, 'ProductOfferId')
            else:
                profTemplate = RESTHELPER.checkIfDefined(offerId, None, 'OFFEREXTID', profTemplate, 'ExternalId')
                profTemplate = RESTHELPER.checkIfDefined(offerId2, None, 'OFFERID', profTemplate, 'ProductOfferId')
                profTemplate = RESTHELPER.removeItem(profTemplate, 'CatalogItemId')
        else:
            #profTemplate = RESTHELPER.removeItem(profTemplate, 'ExternalId')
            #print offerId2
            profTemplate = RESTHELPER.checkIfDefined(catalogItemId, None, 'CATALOGITEMID', profTemplate, 'CatalogItemId')
            profTemplate = RESTHELPER.checkIfDefined(offerId, None, 'OFFERID', profTemplate, 'ProductOfferId')
            profTemplate = RESTHELPER.checkIfDefined(offerId2, None, 'OFFEREXTID', profTemplate, 'ExternalId')

        profTemplate = RESTHELPER.checkIfDefined(offerStartTime, None, 'STARTTIME', profTemplate, 'StartTime')
        profTemplate = RESTHELPER.checkIfDefined(paymentDueDate, None, 'PAYMENTDUEDATE', profTemplate, 'PaymentDueDate')
        # populate ContractParameterOverriderData
        if contractParameterOverrideDataTemplate:
            profTemplate = RESTHELPER.checkIfDefined(contractParameterOverrideDataTemplate, None, 'CONTRACTPARAMETEROVERRIDEDATA', profTemplate, 'ONEWORDLINE')
        else:
            profTemplate = RESTHELPER.removeOneWordLine(profTemplate, 'CONTRACTPARAMETEROVERRIDEDATA')

        profTemplate = RESTHELPER.checkIfDefined(offerStatusValue, None, 'OFFERSTATUSVALUE', profTemplate, 'OfferStatusValue')
        profTemplate = RESTHELPER.checkIfDefined(offerLifecycleProfileId, None, 'OFFERLIFECYCLEPROFILEID', profTemplate, 'OfferLifecycleProfileId')

        if offerCycleType or offerCycleResourceId or offerCycleOffset or offerCycleStartTime:
            cycleTemplate = createCycleData(cycleType=offerCycleType, cycleResourceId=offerCycleResourceId, cycleOffset=offerCycleOffset,
                                            cycleStartTime=offerCycleStartTime)
        else: cycleTemplate = None
        profTemplate = RESTHELPER.checkIfDefined(cycleTemplate, None, 'CYCLEDATA', profTemplate, 'ONEWORDLINE')

        profTemplate = RESTHELPER.checkIfDefined(endTimeRelativeOffsetUnit, None, 'ENDTIMERELATIVEOFFSETUNIT', profTemplate, 'EndTimeRelativeOffsetUnit')
        profTemplate = RESTHELPER.checkIfDefined(endTimeRelativeOffset, None, 'ENDTIMERELATIVEOFFSET', profTemplate, 'EndTimeRelativeOffset')
        profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
        profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
        if future: profTemplate = RESTHELPER.removeItem(profTemplate, 'EventTime')
        else:      profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
        profTemplate = RESTHELPER.checkIfDefined(offerEndTime, None, 'ENDTIME', profTemplate, 'EndTime')
        profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
        profTemplate = RESTHELPER.checkIfDefined(parameterArray, None, 'PARAMETERARRAY', profTemplate, 'ParameterArray')
        profTemplate = RESTHELPER.checkIfDefined(preActiveState, None, 'PREACTIVESTATE', profTemplate, 'PreActiveState')
        profTemplate = RESTHELPER.checkIfDefined(autoActivationTime, None, 'AUTOACTIVATIONTIME', profTemplate, 'AutoActivationTime')
        profTemplate = RESTHELPER.checkIfDefined(autoActivationRelativeOffsetUnit, None, 'AUTOACTIVATIONRELATIVEOFFSETUNIT', profTemplate, 'AutoActivationRelativeOffsetUnit')
        profTemplate = RESTHELPER.checkIfDefined(autoActivationRelativeOffset, None, 'aUTOACTIVATIONRELATIVEOFFSET', profTemplate, 'AutoActivationRelativeOffset')
        profTemplate = RESTHELPER.checkIfDefined(autoActivationCycleResourceId, None, 'AUTOACTIVATIONCYCLERESOURCEID', profTemplate, 'AutoActivationCycleResourceId')
        profTemplate = RESTHELPER.checkIfDefined(activationExpirationTime, None, 'ACTIVATIONEXPIRATIONTIME', profTemplate, 'ActivationExpirationTime')
        profTemplate = RESTHELPER.checkIfDefined(activationExpirationRelativeOffsetUnit, None, 'ACTIVATIONEXPIRATIONRELATIVEOFFSETUNIT', 
             profTemplate, 'ActivationExpirationRelativeOffsetUnit')
        profTemplate = RESTHELPER.checkIfDefined(activationExpirationRelativeOffset, None, 'ACTIVATIONEXPIRATIONRELATIVEOFFSET', profTemplate, 
            'ActivationExpirationRelativeOffset')
        profTemplate = RESTHELPER.checkIfDefined(isPendingActivationAllowed, None, 'ISPENDINGACTIVATIONALLOWED', profTemplate, 'IsPendingActivationAllowed')
        profTemplate = RESTHELPER.checkIfDefined(chargePurchaseProrationType, None, 'CHARGEPURCHASEPRORATIONTYPE', profTemplate, 'ChargePurchaseProrationType')
        profTemplate = RESTHELPER.checkIfDefined(grantPurchaseProrationType, None, 'GRANTPURCHASEPRORATIONTYPE', profTemplate, 'GrantPurchaseProrationType')
        profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
        profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
        profTemplate = RESTHELPER.checkIfDefined(geoData, None, 'GEODATA', profTemplate, 'GeoData')
        
        # Support backwards compatibility for down payment
        if downPayment:
                downPaymentData = open(templates + 'downPayment_data'+RESTV3.fileType).read()
                downPaymentData = RESTHELPER.checkIfDefined(downPayment, None, 'DOWNPAYMENT', downPaymentData, 'DownPayment')
        else:   downPaymentData = None
        profTemplate = RESTHELPER.checkIfDefined(downPaymentData, None, 'DOWNPAYMENT', profTemplate, 'ONEWORDLINE')
        profTemplate = RESTHELPER.checkIfDefined(isRecurringFailureAllowed, None, 'ISRECURRINGFAILUREALLOWED', profTemplate, 'IsRecurringFailureAllowed')
        profTemplate = RESTHELPER.checkIfDefined(endAfterCycleCount, None, 'ENDAFTERCYCLECOUNT', profTemplate, 'EndAfterCycleCount')
        profTemplate = RESTHELPER.checkIfDefined(noEndTime, None, 'NOENDTIME', profTemplate, 'NoEndTime')

        if chargeMethod or paymentMethodResourceId or paymentGatewayId or paymentGatewayOneTimeToken or chargeMethodAttr:
            chargeMethodData = createChargeMethodData(chargeMethod=chargeMethod, paymentMethodResourceId=paymentMethodResourceId,
                                                      paymentGatewayId=paymentGatewayId, paymentGatewayUserId=paymentGatewayUserId,
                                                      paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, chargeMethodAttr=chargeMethodAttrStr,
                                                      deferredSettlement=deferredSettlement, deferredSettlementTimeout=deferredSettlementTimeout,
                                                      deferredSettlementTimeoutAction=deferredSettlementTimeoutAction)
        else: chargeMethodData = None
        profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')
        profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'SUBID', profTemplate, 'ObjectId')

        profTemplate = RESTHELPER.checkIfDefined(eligibilityCheck, None, 'ELIGIBILITYCHECK', profTemplate, 'EligibilityCheck')
        if future:
                # Return from here, as we're scheuling future purchases as a task
#               print 'profTemplate from future: ' + profTemplate
                return profTemplate
        
        if routingType and routingValue :
            url += '?TrafficRouteData=' + str(routingType) + str(routingValue)
        # Debug output if globally set
        if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + profTemplate)
        response = V3inst.put(url, payload=profTemplate)
        if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

        # Debug output if globally set
        #if QAUTILS.DebugLevel > 0: print funcName + '  response: ' + str(response)
        
        (success, resourceId) = validateResponse(response=response, method=funcName,
            shouldPass=eventPass, returnParam='ResourceId')
        if purchaseInfo:
           return (passed(eventPass), response)
        else:
           return (passed(eventPass), resourceId)

#=============================================================
def unsubscribeFromOffer(V3inst, subscriberId, resourceId=0, endTime=None, eventPass=True, apiEventData=None, 
        queryType='ExternalId', cancelInfo=False, executeMode=None, multiRequestBuild=None, eligibilityCheck=True):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=subscriberId, queryType=queryType, now=endTime)
        subscriberId = getOID(queryResponse)

    # Build resource id list if resourceId is list
    if type(resourceId) is list:
        numEntries = len(resourceId)
        entryCounter = 1
        resourceIdList = resourceId
        resourceId = ''
        for resource in resourceIdList:
            resourceId += str(resource)
            if entryCounter != numEntries:
                entryCounter += 1
                resourceId += ','

    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(subscriberId) + '/offers/' + str(resourceId)

    delim = '?'
    amp = False

    if executeMode is not None:
        url+= '?executeMode=' + str(executeMode)
        delim = '&'
        amp = True

    if endTime is not None:
        #url+= delim + 'timestamp=' + endTime.replace('-', '+')
        url+= delim + 'timestamp=' + endTime
        endTime=None
        delim = '&'
        amp = True

    if eligibilityCheck is not None:
        url+= delim + 'eligibilityCheck=' + str(eligibilityCheck).lower()
        delim = '&'
        amp = True

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip():
                url += delim +'ApiEventData=' +apiEventDataStr
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        
    response = V3inst.delete(url, time=endTime, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if cancelInfo :
        return (validateResponse(response=response, method=funcName, shouldPass=eventPass), response)
    else:
        return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def subscriberCancelOffer(V3inst, queryValue, resourceId=0, cancelType=None, grantCancelProrationType=None, chargeCancelProrationType=None,
        reason=None, info=None, now=None, queryType='ExternalId', cancelInfo=False, cancelOfferDataList='', eventPass=True, executeMode=None,
        apiEventData=None, contractCancelMode=None, debtCancellationMode=None, multiRequestBuild=None, isWaiveEarlyTerminationCharge=None, eligibilityCheck=True):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    profTemplate = open(templates + 'subscriber_cancel_offer'+RESTV3.fileType).read()

    if type(resourceId) is not list:
        resourceId = [resourceId]
    cancelTemplate=''
    idArray=''

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    if cancelOfferDataList:
        for cancelOfferData in cancelOfferDataList:
            template = open(templates + 'cancel_offer_data'+RESTV3.fileType).read()
            template = RESTHELPER.checkIfDefined(cancelOfferData["ResourceId"], None, 'RESOURCEID', template, 'ResourceId')
            template = RESTHELPER.checkIfDefined(cancelOfferData["CancelType"], None, 'CANCELTYPE', template, 'CancelType')
            template = RESTHELPER.checkIfDefined(cancelOfferData["GrantCancelProrationType"], None, 'GRANTCANCELPRORATIONTYPE', template, 'GrantCancelProrationType')
            template = RESTHELPER.checkIfDefined(cancelOfferData["ChargeCancelProrationType"], None, 'CHARGECANCELPRORATIONTYPE', template, 'ChargeCancelProrationType')
            template = RESTHELPER.checkIfDefined(cancelOfferData["ContractCancelMode"], None, 'CONTRACTCANCELMODE', template, 'ContractCancelMode')
            template = RESTHELPER.checkIfDefined(cancelOfferData["DebtCancellationMode"], None, 'DEBTCANCELLATIONMODE', template, 'DebtCancellationMode')
            template = RESTHELPER.checkIfDefined(cancelOfferData["IsWaiveEarlyTerminationCharge"], None, 'ISWAIVEEARLYTERMINATIONCHARGE', template, 'IsWaiveEarlyTerminationCharge')
            template = RESTHELPER.checkIfDefined(cancelOfferData["Reason"], None, 'REASON', template, 'Reason')
            template = RESTHELPER.checkIfDefined(cancelOfferData["Info"], None, 'INFO', template, 'Info')
            cancelTemplate += template
    elif cancelType or grantCancelProrationType or chargeCancelProrationType or reason or info or contractCancelMode or debtCancellationMode:
        profTemplate = RESTHELPER.removeItem(profTemplate, 'ResourceIdArray')
        for id in resourceId:
            template = open(templates + 'cancel_offer_data'+RESTV3.fileType).read()
            template = RESTHELPER.checkIfDefined(id, None, 'RESOURCEID', template, 'ResourceId')
            template = RESTHELPER.checkIfDefined(cancelType, None, 'CANCELTYPE', template, 'CancelType')
            template = RESTHELPER.checkIfDefined(grantCancelProrationType, None, 'GRANTCANCELPRORATIONTYPE', template, 'GrantCancelProrationType')
            template = RESTHELPER.checkIfDefined(chargeCancelProrationType, None, 'CHARGECANCELPRORATIONTYPE', template, 'ChargeCancelProrationType')
            template = RESTHELPER.checkIfDefined(contractCancelMode, None, 'CONTRACTCANCELMODE', template, 'ContractCancelMode')
            template = RESTHELPER.checkIfDefined(debtCancellationMode, None, 'DEBTCANCELLATIONMODE', template, 'DebtCancellationMode')
            template = RESTHELPER.checkIfDefined(isWaiveEarlyTerminationCharge, None, 'ISWAIVEEARLYTERMINATIONCHARGE', template, 'IsWaiveEarlyTerminationCharge')
            template = RESTHELPER.checkIfDefined(reason, None, 'REASON', template, 'Reason')
            template = RESTHELPER.checkIfDefined(info, None, 'INFO', template, 'Info')
            cancelTemplate += template
            print('cancelTemplate', cancelTemplate)
    else:
        idArray = ''
        if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
            idArray = resourceId
        else:
            for id in resourceId:
                idArray += '<value>' + str(id) + '</value>'

    profTemplate = RESTHELPER.checkIfDefined(cancelTemplate, '', 'CANCELDATAARRAY', profTemplate, 'CancelDataArray')
    profTemplate = RESTHELPER.checkIfDefined(idArray, '', 'RESOURCEIDARRAY', profTemplate, 'ResourceIdArray')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(eligibilityCheck, None, 'ELIGIBILITYCHECK', profTemplate, 'EligibilityCheck')

    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/offers'
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if cancelInfo :
        return (validateResponse(response=response, method=funcName, shouldPass=eventPass), response)
    else:
        return validateResponse(response=response, method=funcName, shouldPass=eventPass)
        
#=============================================================
def addSubscriberThreshold(V3inst, queryValue, thresholdId, resourceId, threshName, val, notify, eventPass=True,
        now=None, queryType='ExternalId', recurringStart = None, recurringStop = None, virtualCreditLimitIsPercent = 0,
        rechargeAmount=None, rechargePaymentMethodResourceId=None, executeMode=None,
        apiEventData=None, isTemporaryCreditLimit=None, multiRequestBuild=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if notify:
        thresholdNotification = 'true'
    elif notify==None:
        thresholdNotification = None
    else:
        thresholdNotification = 'false'
    if isTemporaryCreditLimit:
        isTemporaryCreditLimit = 'true'
    elif isTemporaryCreditLimit==None:
        isTemporaryCreditLimit = None 
    else:
        isTemporaryCreditLimit = 'false'

    if resourceId is None:
        v3inst = QAUTILS.getDatacontainerConnection()
        walletMdc = v3inst.subscriberQueryWallet(queryType=queryType, queryValue=queryValue, now=now)
        resourceId = COMMON.getResourceId(walletMdc, thresholdId)
        if resourceId is None:
            return COMMON.debugFailure(method='addSubscriberThreshold', status=1, msg='ThresholdId not found')

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_add_threshold'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(thresholdId, None, 'THRESHOLDID', profTemplate, 'ThresholdId')
    profTemplate = RESTHELPER.checkIfDefined(threshName, None, 'NAME', profTemplate, 'Name')
    profTemplate = RESTHELPER.checkIfDefined(val, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(recurringStart, None, 'RECURRINGSTART', profTemplate, 'RecurringStart')
    profTemplate = RESTHELPER.checkIfDefined(recurringStop, None, 'RECURRINGSTOP', profTemplate, 'RecurringStop')
    profTemplate = RESTHELPER.checkIfDefined(thresholdNotification, None, 'NOTIFICATIONSTATE', profTemplate,
        'NotificationState')
    profTemplate = RESTHELPER.checkIfDefined(virtualCreditLimitIsPercent, None, 'VIRTUALCREDITLIMITISPERCENT', profTemplate,
        'VirtualCreditLimitIsPct')
    if rechargeAmount or rechargePaymentMethodResourceId:
        rechargeData = open(templates + 'recharge_threshold_data'+RESTV3.fileType).read()
        rechargeData = RESTHELPER.checkIfDefined(rechargeAmount, None, 'RECHARGEAMOUNT', rechargeData, 'Amount')
        rechargeData = RESTHELPER.checkIfDefined(rechargePaymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID',
            rechargeData, 'PaymentMethodResourceId')
    else:
        rechargeData = None
    profTemplate = RESTHELPER.checkIfDefined(rechargeData, None, 'RECHARGEDATA', profTemplate, 'RechargeData')
    profTemplate = RESTHELPER.checkIfDefined(isTemporaryCreditLimit, None, 'ISTEMPORARYCREDITLIMIT', profTemplate, 'IsTemporaryCreditLimit')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')

    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/wallet/' + str(resourceId) + '/thresholds'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def removeSubscriberThreshold(V3inst, subscriberId, indexId, thresholdId, queryType='ExternalId', now=None,
    removeThresholdOnly=None, removeRechargeDataOnly=None, isTemporaryCreditLimit=False,
    apiEventData=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=subscriberId, queryType=queryType, now=now)
        subscriberId = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(subscriberId) + '/wallet/' + str(indexId) + '/thresholds/' + str(thresholdId)

    delim = '?'
    amp = False

    if removeThresholdOnly:
        url += '?removeThresholdOnly=true'
        delim = '&'
        amp = True

    if removeRechargeDataOnly:
        url += delim + 'removeRechargeDataOnly=true'
        delim = '&'
        amp = True

    if isTemporaryCreditLimit:
        url += delim + 'isTemporaryCreditLimit=true'
        delim = '&'
        amp = True

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip():
                url += delim +'ApiEventData=' +apiEventDataStr
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName)

#=============================================================
def querySubscriberThresholdRechargeDefn(V3inst, queryValue, balanceResourceId=None, now=None, queryType='ExternalId', eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/threshold_recharge_defn'
    if balanceResourceId:
        url += '?resourceId=' + str(balanceResourceId)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def addSubscriberBalance(V3inst, subscriberId, balanceList, now=None, queryType='ExternalId', eventPass=True,
    apiEventData=None, executeMode=None, multiRequestBuild=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=subscriberId, queryType=queryType, now=now)
        subscriberId = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    # Make separate REST calls for each balance to add
    for balance in balanceList:
        templateId = balance['BalanceTemplateId']
        if balance['InitAmount']:
            initAmount = balance['InitAmount']
        profTemplate = open(templates + 'subscriber_add_balance'+RESTV3.fileType).read()
        profTemplate = RESTHELPER.checkIfDefined(templateId, None, 'TEMPLATEID', profTemplate, 'BalanceTemplateId')
        profTemplate = RESTHELPER.checkIfDefined(initAmount, None, 'INITAMOUNT', profTemplate, 'InitAmount')
        profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
        profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
        profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
        url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(subscriberId)
           
        # Debug output if globally set
        if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + profTemplate)
        
        response = V3inst.put(url, payload=profTemplate)
        if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
        return validateResponse(response=response, method='addSubscriberBalance', shouldPass=eventPass)


#=============================================================
def multiQuery(V3inst, subscriberValues = [], groupValues = [], deviceValues = [], userValues = [], subscriptionValues = [],
    queryType='ExternalId', eventPass=True, now=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    amp = False
    request = '/'+RESTV3.urlPrefix+'/service/multiquery?'
    if queryType == 'ObjectId':
        for s in subscriberValues:
            request = request + 'subscriber='+s+'&'
        for g in groupValues:
            request = request + 'group='+g+'&'
        for d in deviceValues:
            request = request + 'device='+d+'&'
        for u in userValues:
            request = request + 'user='+u+'&'
        for t in subscriptionValues:
            request = request + 'subscription='+t+'&'
    else:
        for s in subscriberValues:
            request = request + 'subscriber='+queryType+'+'+s+'&'
        for g in groupValues:
            request = request + 'group='+queryType+'+'+g+'&'
        for d in deviceValues:
            request = request + 'device='+queryType+'+'+d+'&'
        for u in userValues:
            request = request + 'user='+queryType+'+'+u+'&'
        for t in subscriptionValues:
            request = request + 'subscription='+queryType+'+'+t+'&'

    request = request[:-1]
    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + request)
        
    response = V3inst.get(request, time=now, amp=False)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method='multiquery', shouldPass=eventPass):
        return response

#=============================================================
def querySubscriber(V3inst, queryValue, queryType='ExternalId', querySize=None, eventPass=True, now=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Get start of URL
    # subscription query is only by ObjectId, no new urls for others. 
    if   queryType == 'ObjectId':       url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/'
    elif queryType == 'ExternalId':     url = '/'+RESTV3.urlPrefix+'/subscriber/query/ExternalId/'
    elif queryType == 'PhoneNumber':    url = '/'+RESTV3.urlPrefix+'/subscriber/query/PhoneNumber/'
    elif queryType == 'LoginId':        url = '/'+RESTV3.urlPrefix+'/subscriber/query/LoginId/'
    elif queryType == 'AccessId':       url = '/'+RESTV3.urlPrefix+'/subscriber/query/AccessId/'
    elif queryType == 'AccessNumber':   url = '/'+RESTV3.urlPrefix+'/subscriber/query/AccessNumber/'


    # Add value
    url += str(queryValue)
    
    # Add query size if specified
    if querySize:
        amp = True
        url += '?querySize=' + str(querySize)
    else: amp = False
        
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def querySubscriberCursor(V3inst, queryValue, queryType='ExternalId', querySize=None, eventPass=True, now=None, multiRequestBuild=None):
    # Query the sub
    response = querySubscriber(V3inst, queryValue, queryType=queryType, querySize=querySize, eventPass=eventPass, now=now)
        
    # Want to extract any QueryCursor value.  
    # There has to be a better way then this...
    # Assume nothing found
    queryCursor = {}
    
    # Split response into dictionary per line
    if isinstance(response, bytes):
        response = response.decode('utf-8') #fix for python3

    respDict = response.split('\n')
    # Look at each line
    for item in respDict:
     for cursor in ['AdminGroupCursor', 'ParentGroupCursor']:
        # See if string is in this entry
        if cursor in item:
                # Get value
                queryCursor[cursor] = str(item.split('>')[1].split('<')[0])
                
    # Debug output
    #print 'queryCursor = ' + str(queryCursor)
    
    # Return response and dictionary
    return (response, queryCursor)

#=============================================================
def queryGroupCursor(V3inst, queryValue, queryType='ExternalId', querySize=None, eventPass=True, now=None, multiRequestBuild=None):
    # Query the sub
    response = queryGroup(V3inst, queryValue, queryType=queryType, querySize=querySize, eventPass=eventPass, now=now)
        
    # Want to extract any QueryCursor value.  
    # There has to be a better way then this...
    # Assume nothing found
    queryCursor = {}
    

    # Split response into dictionary per line
    respDict = response.split('\n')
   
    
    # Look at each line
    for item in respDict:
     for cursor in ['AdminCursor', 'SubscriberMemberCursor', 'GroupMemberCursor']:
        # See if string is in this entry
        if cursor in item:
                # Get value
                queryCursor[cursor] = item.split('>')[1].split('<')[0]
                
    # Debug output
    #print 'queryCursor = ' + str(queryCursor)
    
    # Return response and dictionary
    return (response, queryCursor)

#========================================================
def subscriberModifyOffer(V3inst, queryValue, queryType, resourceId, now=None, startTime=None, endTime=None, attr=None,
     eventPass=True, executeMode=None,  cycleType=None, cycleResourceId=None, cycleOffset=None, cycleAlignmentDisabled=None, cycleStartTime=None, cycleEndTime=None, apiEventData=None, immediateChange=None, isRecurringFailureAllowed=None, status=None, offerStatusValue=None, modifyInfo=False, parameterList=None, multiRequestBuild=None, endTimeExtensionOffset=None, endTimeExtensionOffsetUnit=None, endAfterCycleCount=None, noEndTime=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Get subscriber OID if queryType is not ObjectId
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    attrStr = None
    if attr is not None:
        attrStr = parseAttrMdc(attr)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    parameterArray = None
    if parameterList:
        parameterArray = parseParameterList(parameterList)

    # Need to force binary items to None if false as Engine interprets a value of "False" as set.
    if cycleAlignmentDisabled and str(cycleAlignmentDisabled).lower() in ['1', 'true']:
          cycleAlignmentDisabled = '1'
    else: cycleAlignmentDisabled = None
    if immediateChange and str(immediateChange).lower() in ['1', 'true']:
          immediateChange = '1'
    else: immediateChange = None

    profTemplate = open(templates + 'subscriber_modify_offer'+RESTV3.fileType).read()
    
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(startTime, None, 'STARTTIME', profTemplate, 'StartTime')
    profTemplate = RESTHELPER.checkIfDefined(endTime, None, 'ENDTIME', profTemplate, 'EndTime')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(parameterArray, None, 'PARAMETERARRAY', profTemplate, 'ParameterArray')
    profTemplate = RESTHELPER.checkIfDefined(offerStatusValue, None, 'OFFERSTATUSVALUE', profTemplate, 'OfferStatusValue')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffset, None, 'ENDTIMEEXTENSIONOFFSETNUM', profTemplate, 'EndTimeExtensionOffset')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffsetUnit, None, 'ENDTIMEEXTENSIONOFFSETUNIT', profTemplate, 'EndTimeExtensionOffsetUnit')
    profTemplate = RESTHELPER.checkIfDefined(endAfterCycleCount, None, 'ENDAFTERCYCLECOUNT', profTemplate, 'EndAfterCycleCount')
    profTemplate = RESTHELPER.checkIfDefined(noEndTime, None, 'NOENDTIME', profTemplate, 'NoEndTime')

    if cycleType or cycleResourceId or cycleOffset or cycleStartTime or cycleEndTime or cycleAlignmentDisabled or immediateChange or isRecurringFailureAllowed:
        cycleTemplate = createCycleData(cycleType=cycleType, cycleResourceId=cycleResourceId, cycleOffset=cycleOffset, cycleStartTime=cycleStartTime, cycleEndTime=cycleEndTime, cycleAlignmentDisabled=cycleAlignmentDisabled, immediateChange=immediateChange, isRecurringFailureAllowed=isRecurringFailureAllowed) 
    else: cycleTemplate = None
    profTemplate = RESTHELPER.checkIfDefined(cycleTemplate, None, 'CYCLEDATA', profTemplate, 'ONEWORDLINE')

    # Allow for custom URLs (for BGAPI code)
    if CSV.overrideURL and 'purchase' in CSV.overrideOperations: custom = '/' + CSV.overrideURL
    else: custom = ''
    url = '/' + RESTV3.urlPrefix + custom + '/'+RESTV3.subUrl+'/' + str(queryValue) + '/offers/' + str(resourceId)
           
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    if modifyInfo :
        return (validateResponse(response=response, method=funcName, shouldPass=eventPass), response)    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#===================================================================
def subscriberModifyStatus(V3inst, queryValue=None, statusTransitionTime=None, statusValue=None, queryType='ExternalId', now=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    template = 'subscriber_modify_status' + RESTV3.fileType
    data = open(templates + template).read()

    eventTime=now
    scheduledStatusTransitionTime=statusTransitionTime
    if apiEventData is not None:
        apiEventData = parseAttrMdc(apiEventData)
		
    individualFields = ['scheduledStatusTransitionTime', 'statusValue', 'eventTime', 'apiEventData', 'executeMode']

    for field in individualFields:
        cmd = "RESTHELPER.checkIfDefined(" + field + ", None, '" + field.upper() + "', data, '" + field[0].capitalize() + field[1:] + "')"
        data = eval(cmd)

    data = re.sub('.*xml version.*\n?','', data)
    data = data.rstrip('\n')

    url = '/'+RESTV3.urlPrefix+'/subscription/' + str(queryType) + '+' + str(queryValue) + '/status'

    if routingType and routingValue :
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' data:\n' + data)

    response = V3inst.put(url, payload=data)
    #if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response.decode('utf-8'))
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)


#=============================================================
def subscriberRemoveScheduledStatusChange(V3inst=None, queryValue=None, queryType='ExternalId', now=None, eventPass=True,
    apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/subscription/' + str(queryValue) + '/scheduled_status_change'
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip():
                url += '?ApiEventData=' +apiEventDataStr
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response


#=============================================================
def subscriberSuspendOffer(V3inst, queryValue=None, resourceId=None, scheduledSuspendTime=None, queryType='ExternalId', now=None,
                           isPauseMode=None, autoResumeRelativeOffset=None, autoResumeRelativeOffsetUnit=None, autoResumeTime=None,
                           grantSuspendProrationType=None, chargeSuspendProrationType=None,
                           grantResumeProrationType=None, chargeResumeProrationType=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    template = 'subscriber_suspend_offer' + RESTV3.fileType
    data = open(templates + template).read()

    eventTime=now
    if apiEventData is not None:
        apiEventData = parseAttrMdc(apiEventData)

    individualFields = ['scheduledSuspendTime', 'isPauseMode', 'autoResumeRelativeOffsetUnit', 'autoResumeRelativeOffset', \
                        'autoResumeTime', 'grantSuspendProrationType', 'chargeSuspendProrationType', \
                        'grantResumeProrationType', 'chargeResumeProrationType', \
                        'eventTime', 'apiEventData', 'executeMode']

    for field in individualFields:
        cmd = "RESTHELPER.checkIfDefined(" + field + ", None, '" + field.upper() + "', data, '" + field[0].capitalize() + field[1:] + "')"
        data = eval(cmd)

    data = re.sub('.*xml version.*\n?','', data)
    data = data.rstrip('\n')

    url = '/'+RESTV3.urlPrefix+'/subscription/' + str(queryType) + '+' + str(queryValue) + '/offers/' + str(resourceId) + '/suspend'

    if routingType and routingValue :
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' data:\n' + data)

    response = V3inst.put(url, payload=data)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)


#=============================================================
def subscriberResumeOffer(V3inst, queryValue=None, resourceId=None, scheduledResumeTime=None, queryType='ExternalId', now=None,
                           resumeRelativeOffset=None, resumeRelativeOffsetUnit=None, grantResumeProrationType=None,
                           chargeResumeProrationType=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    template = 'subscriber_resume_offer' + RESTV3.fileType
    data = open(templates + template).read()

    eventTime=now
    if apiEventData is not None:
        apiEventData = parseAttrMdc(apiEventData)

    individualFields = ['scheduledResumeTime', 'resumeRelativeOffsetUnit', 'resumeRelativeOffset', \
                        'grantResumeProrationType', 'chargeResumeProrationType', \
                        'eventTime', 'apiEventData', 'executeMode']

    for field in individualFields:
        cmd = "RESTHELPER.checkIfDefined(" + field + ", None, '" + field.upper() + "', data, '" + field[0].capitalize() + field[1:] + "')"
        data = eval(cmd)

    data = re.sub('.*xml version.*\n?','', data)
    data = data.rstrip('\n')

    url = '/'+RESTV3.urlPrefix+'/subscription/' + str(queryType) + '+' + str(queryValue) + '/offers/' + str(resourceId) + '/resume'

    if routingType and routingValue :
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' data:\n' + data)

    response = V3inst.put(url, payload=data)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def subscriberRemoveScheduledOfferStatusChange(V3inst=None, queryValue=None, queryType='ExternalId', resourceId=None, now=None, eventPass=True,
    apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/subscription/' + str(queryValue) + '/offers/' + str(resourceId) + '/scheduled_status_change'
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip():
                url += '?ApiEventData=' +apiEventDataStr
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#========================================================
def subscriberActivateOffer(V3inst, queryValue, queryType, resourceId=None, now=None, executeMode=None,
                             routingType=None, routingValue=None, eventPass=True, apiEventData=None, multiRequestBuild=None):

    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix + '/subscription/' + str(queryValue) + '/offers/' + str(resourceId) + '/activate'

    delim = '?'
    amp = False

    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType+str(routingValue)
        delim = '&'
        amp = True
                
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip():
                url += delim + 'ApiEventData=' +apiEventDataStr
                amp = True

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.put(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#========================================================
def groupModifyOffer(V3inst, queryType, queryValue, resourceId, now=None, startTime=None, endTime=None, attr=None,
    eventPass=True, executeMode=None, cycleType=None, cycleResourceId=None, cycleOffset=None, cycleAlignmentDisabled=None, cycleStartTime=None, cycleEndTime=None, apiEventData=None, immediateChange=None, isRecurringFailureAllowed=None, status=None, offerStatusValue=None, modifyInfo=False, parameterList=None, multiRequestBuild=None, endTimeExtensionOffset=None, endTimeExtensionOffsetUnit=None, endAfterCycleCount=None, noEndTime=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Get group OID if queryType is not ObjectId
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    attrStr = None
    if attr is not None:
        attrStr = parseAttrMdc(attr)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    parameterArray = None
    if parameterList:
        parameterArray = parseParameterList(parameterList)

    # Need to force binary items to None if false as Engine interprets a value of "False" as set.
    if cycleAlignmentDisabled and str(cycleAlignmentDisabled).lower() in ['1', 'true']:
          cycleAlignmentDisabled = '1'
    else: cycleAlignmentDisabled = None
    if immediateChange and str(immediateChange).lower() in ['1', 'true']:
          immediateChange = '1'
    else: immediateChange = None

    profTemplate = open(templates + 'group_modify_offer'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(startTime, None, 'STARTTIME', profTemplate, 'StartTime')
    profTemplate = RESTHELPER.checkIfDefined(endTime, None, 'ENDTIME', profTemplate, 'EndTime')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(parameterArray, None, 'PARAMETERARRAY', profTemplate, 'ParameterArray')
    profTemplate = RESTHELPER.checkIfDefined(offerStatusValue, None, 'OFFERSTATUSVALUE', profTemplate, 'OfferStatusValue')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffset, None, 'ENDTIMEEXTENSIONOFFSETNUM', profTemplate, 'EndTimeExtensionOffset')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffsetUnit, None, 'ENDTIMEEXTENSIONOFFSETUNIT', profTemplate, 'EndTimeExtensionOffsetUnit')
    profTemplate = RESTHELPER.checkIfDefined(endAfterCycleCount, None, 'ENDAFTERCYCLECOUNT', profTemplate, 'EndAfterCycleCount')
    profTemplate = RESTHELPER.checkIfDefined(noEndTime, None, 'NOENDTIME', profTemplate, 'NoEndTime')

    if cycleType or cycleResourceId or cycleOffset or cycleStartTime or cycleEndTime or cycleAlignmentDisabled or immediateChange or isRecurringFailureAllowed:
        cycleTemplate = createCycleData(cycleType=cycleType, cycleResourceId=cycleResourceId, cycleOffset=cycleOffset, cycleStartTime=cycleStartTime, cycleEndTime=cycleEndTime, cycleAlignmentDisabled=cycleAlignmentDisabled, immediateChange=immediateChange, isRecurringFailureAllowed=isRecurringFailureAllowed)
    else: cycleTemplate = None
    profTemplate = RESTHELPER.checkIfDefined(cycleTemplate, None, 'CYCLEDATA', profTemplate, 'ONEWORDLINE')

    # Allow for custom URLs (for BGAPI code)
    if CSV.overrideURL and 'purchase' in CSV.overrideOperations: custom = '/' + CSV.overrideURL
    else: custom = ''
    url = '/' + RESTV3.urlPrefix + custom + '/group/' + str(queryValue) + '/offers/' + str(resourceId)
           
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    if modifyInfo :
        return (validateResponse(response=response, method=funcName, shouldPass=eventPass), response)
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#===================================================================
def groupModifyStatus(V3inst, queryValue=None, statusTransitionTime=None, statusValue=None, queryType='ExternalId', now=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    template = 'group_modify_status' + RESTV3.fileType
    data = open(templates + template).read()

    eventTime=now
    scheduledStatusTransitionTime=statusTransitionTime
    if apiEventData is not None:
        apiEventData = parseAttrMdc(apiEventData)
		
    individualFields = ['scheduledStatusTransitionTime', 'statusValue', 'eventTime', 'apiEventData', 'executeMode']

    for field in individualFields:
        cmd = "RESTHELPER.checkIfDefined(" + field + ", None, '" + field.upper() + "', data, '" + field[0].capitalize() + field[1:] + "')"
        data = eval(cmd)

    data = re.sub('.*xml version.*\n?','', data)
    data = data.rstrip('\n')

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryType) + '+' + str(queryValue) + '/status'

    if routingType and routingValue :
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' data:\n' + data)

    response = V3inst.put(url, payload=data)
    #if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response.decode('utf-8'))
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)


#=============================================================
def groupRemoveScheduledStatusChange(V3inst=None, queryValue=None, queryType='ExternalId', now=None, eventPass=True,
    apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/scheduled_status_change'
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip():
                url += '?ApiEventData=' +apiEventDataStr
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response


#=============================================================
def groupSuspendOffer(V3inst, queryValue=None, resourceId=None, scheduledSuspendTime=None, queryType='ExternalId', now=None,
                           isPauseMode=None, autoResumeRelativeOffset=None, autoResumeRelativeOffsetUnit=None, autoResumeTime=None,
                           grantSuspendProrationType=None, chargeSuspendProrationType=None,
                           grantResumeProrationType=None, chargeResumeProrationType=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    template = 'group_suspend_offer' + RESTV3.fileType
    data = open(templates + template).read()

    eventTime=now
    if apiEventData is not None:
        apiEventData = parseAttrMdc(apiEventData)

    individualFields = ['scheduledSuspendTime', 'isPauseMode', 'autoResumeRelativeOffsetUnit', 'autoResumeRelativeOffset', \
                        'autoResumeTime', 'grantSuspendProrationType', 'chargeSuspendProrationType', \
                        'grantResumeProrationType', 'chargeResumeProrationType', \
                        'eventTime', 'apiEventData', 'executeMode']

    for field in individualFields:
        cmd = "RESTHELPER.checkIfDefined(" + field + ", None, '" + field.upper() + "', data, '" + field[0].capitalize() + field[1:] + "')"
        data = eval(cmd)

    data = re.sub('.*xml version.*\n?','', data)
    data = data.rstrip('\n')

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryType) + '+' + str(queryValue) + '/offers/' + str(resourceId) + '/suspend'

    if routingType and routingValue :
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' data:\n' + data)

    response = V3inst.put(url, payload=data)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)


#=============================================================
def groupResumeOffer(V3inst, queryValue=None, resourceId=None, scheduledResumeTime=None, queryType='ExternalId', now=None,
                           resumeRelativeOffset=None, resumeRelativeOffsetUnit=None, grantResumeProrationType=None,
                           chargeResumeProrationType=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    template = 'group_resume_offer' + RESTV3.fileType
    data = open(templates + template).read()

    eventTime=now
    if apiEventData is not None:
        apiEventData = parseAttrMdc(apiEventData)

    individualFields = ['scheduledResumeTime', 'resumeRelativeOffsetUnit', 'resumeRelativeOffset', \
                        'grantResumeProrationType', 'chargeResumeProrationType', \
                        'eventTime', 'apiEventData', 'executeMode']

    for field in individualFields:
        cmd = "RESTHELPER.checkIfDefined(" + field + ", None, '" + field.upper() + "', data, '" + field[0].capitalize() + field[1:] + "')"
        data = eval(cmd)

    data = re.sub('.*xml version.*\n?','', data)
    data = data.rstrip('\n')

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryType) + '+' + str(queryValue) + '/offers/' + str(resourceId) + '/resume'

    if routingType and routingValue :
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' data:\n' + data)

    response = V3inst.put(url, payload=data)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupRemoveScheduledOfferStatusChange(V3inst=None, queryValue=None, queryType='ExternalId', resourceId=None, now=None, eventPass=True,
    apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/offers/' + str(resourceId) + '/scheduled_status_change'
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip():
                url += '?ApiEventData=' +apiEventDataStr
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#========================================================
def groupActivateOffer(V3inst, queryValue, queryType, resourceId=None, now=None, executeMode=None,
                             routingType=None, routingValue=None, eventPass=True, apiEventData=None, multiRequestBuild=None):

    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix + '/group/' + str(queryValue) + '/offers/' + str(resourceId) + '/activate'

    delim = '&'
    amp = True
    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType+str(routingValue)
        delim = '&'
        amp = True

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip():
                url += delim + 'ApiEventData=' +apiEventDataStr
                amp = True

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.put(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def deviceModifyOffer(V3inst, queryType, queryValue, resourceId, now=None, startTime=None, endTime=None, attr=None,
    eventPass=True, executeMode=None, cycleType=None, cycleResourceId=None, cycleOffset=None, cycleAlignmentDisabled=None,
    apiEventData=None, cycleStartTime=None, cycleEndTime=None, immediateChange=None, isRecurringFailureAllowed=None, status=None, offerStatusValue=None, modifyInfo=False,
    parameterList=None, multiRequestBuild=None, endTimeExtensionOffset=None, endTimeExtensionOffsetUnit=None, endAfterCycleCount=None, noEndTime=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    attrStr = None
    if attr is not None:
        attrStr = parseAttrMdc(attr)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    parameterArray = None
    if parameterList:
        parameterArray = parseParameterList(parameterList)

    # Need to force binary items to None if false as Engine interprets a value of "False" as set.
    if cycleAlignmentDisabled and str(cycleAlignmentDisabled).lower() in ['1', 'true']:
          cycleAlignmentDisabled = '1'
    else: cycleAlignmentDisabled = None
    if immediateChange and str(immediateChange).lower() in ['1', 'true']:
          immediateChange = '1'
    else: immediateChange = None

    profTemplate = open(templates + 'device_modify_offer'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(startTime, None, 'STARTTIME', profTemplate, 'StartTime')
    profTemplate = RESTHELPER.checkIfDefined(endTime, None, 'ENDTIME', profTemplate, 'EndTime')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(offerStatusValue, None, 'OFFERSTATUSVALUE', profTemplate, 'OfferStatusValue')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(parameterArray, None, 'PARAMETERARRAY', profTemplate, 'ParameterArray')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffset, None, 'ENDTIMEEXTENSIONOFFSETNUM', profTemplate, 'EndTimeExtensionOffset')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffsetUnit, None, 'ENDTIMEEXTENSIONOFFSETUNIT', profTemplate, 'EndTimeExtensionOffsetUnit')
    profTemplate = RESTHELPER.checkIfDefined(endAfterCycleCount, None, 'ENDAFTERCYCLECOUNT', profTemplate, 'EndAfterCycleCount')
    profTemplate = RESTHELPER.checkIfDefined(noEndTime, None, 'NOENDTIME', profTemplate, 'NoEndTime')
    if cycleType or cycleResourceId or cycleOffset or cycleStartTime or cycleEndTime or cycleAlignmentDisabled or immediateChange or isRecurringFailureAllowed:
        cycleTemplate = createCycleData(cycleType=cycleType, cycleResourceId=cycleResourceId, cycleOffset=cycleOffset, cycleStartTime=cycleStartTime, cycleEndTime=cycleEndTime, cycleAlignmentDisabled=cycleAlignmentDisabled, immediateChange=immediateChange, isRecurringFailureAllowed=isRecurringFailureAllowed)
    else: cycleTemplate = None
    profTemplate = RESTHELPER.checkIfDefined(cycleTemplate, None, 'CYCLEDATA', profTemplate, 'ONEWORDLINE')

    # Allow for custom URLs (for BGAPI code)
    if CSV.overrideURL and 'purchase' in CSV.overrideOperations: custom = '/' + CSV.overrideURL
    else: custom = ''
    url = '/' + RESTV3.urlPrefix + custom + '/device/' + str(queryValue) + '/offers/' + str(resourceId)
           
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    if modifyInfo :
        return (validateResponse(response=response, method=funcName, shouldPass=eventPass), response) 
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#===================================================================
def deviceModifyStatus(V3inst, queryValue=None, statusTransitionTime=None, statusValue=None, queryType='PhoneNumber', now=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    template = 'device_modify_status' + RESTV3.fileType
    data = open(templates + template).read()

    eventTime=now
    scheduledStatusTransitionTime=statusTransitionTime
    if apiEventData is not None:
        apiEventData = parseAttrMdc(apiEventData)
		
    objectId=queryValue
    individualFields = ['scheduledStatusTransitionTime', 'statusValue', 'eventTime', 'apiEventData', 'executeMode']

    for field in individualFields:
        cmd = "RESTHELPER.checkIfDefined(" + field + ", None, '" + field.upper() + "', data, '" + field[0].capitalize() + field[1:] + "')"
        data = eval(cmd)

    data = re.sub('.*xml version.*\n?','', data)
    data = data.rstrip('\n')

    if queryType == 'ObjectId':
        url = '/'+RESTV3.urlPrefix+'/device/' + str(queryValue) + '/status'
    else:
        url = '/'+RESTV3.urlPrefix+'/device/' + str(queryType) + '+' + str(queryValue) + '/status'

    if routingType and routingValue :
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' data:\n' + data)

    response = V3inst.put(url, payload=data)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)


#=============================================================
def deviceRemoveScheduledStatusChange(V3inst=None, queryValue=None, queryType='PhoneNumber', now=None, eventPass=True,
    apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/device/' + str(queryValue) + '/scheduled_status_change'
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip():
                url += '?ApiEventData=' +apiEventDataStr
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response


#=============================================================
def deviceSuspendOffer(V3inst, queryValue=None, resourceId=None, scheduledSuspendTime=None, queryType='PhoneNumber', now=None,
                           isPauseMode=None, autoResumeRelativeOffset=None, autoResumeRelativeOffsetUnit=None, autoResumeTime=None,
                           grantSuspendProrationType=None, chargeSuspendProrationType=None,
                           grantResumeProrationType=None, chargeResumeProrationType=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    template = 'device_suspend_offer' + RESTV3.fileType
    data = open(templates + template).read()

    eventTime=now
    if apiEventData is not None:
        apiEventData = parseAttrMdc(apiEventData)

    individualFields = ['scheduledSuspendTime', 'isPauseMode', 'autoResumeRelativeOffsetUnit', 'autoResumeRelativeOffset', \
                        'autoResumeTime', 'grantSuspendProrationType', 'chargeSuspendProrationType', \
                        'grantResumeProrationType', 'chargeResumeProrationType', \
                        'eventTime', 'apiEventData', 'executeMode']

    for field in individualFields:
        cmd = "RESTHELPER.checkIfDefined(" + field + ", None, '" + field.upper() + "', data, '" + field[0].capitalize() + field[1:] + "')"
        data = eval(cmd)

    data = re.sub('.*xml version.*\n?','', data)
    data = data.rstrip('\n')

    url = '/'+RESTV3.urlPrefix+'/device/' + str(queryType) + '+' + str(queryValue) + '/offers/' + str(resourceId) + '/suspend'

    if routingType and routingValue :
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' data:\n' + data)

    response = V3inst.put(url, payload=data)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)


#=============================================================
def deviceResumeOffer(V3inst, queryValue=None, resourceId=None, scheduledResumeTime=None, queryType='PhoneNumber', now=None,
                           resumeRelativeOffset=None, resumeRelativeOffsetUnit=None, grantResumeProrationType=None,
                           chargeResumeProrationType=None,
                           apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None, eventPass=True):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    template = 'device_resume_offer' + RESTV3.fileType
    data = open(templates + template).read()

    eventTime=now
    if apiEventData is not None:
        apiEventData = parseAttrMdc(apiEventData)

    individualFields = ['scheduledResumeTime', 'resumeRelativeOffsetUnit', 'resumeRelativeOffset', \
                        'grantResumeProrationType', 'chargeResumeProrationType', \
                        'eventTime', 'apiEventData', 'executeMode']

    for field in individualFields:
        cmd = "RESTHELPER.checkIfDefined(" + field + ", None, '" + field.upper() + "', data, '" + field[0].capitalize() + field[1:] + "')"
        data = eval(cmd)

    data = re.sub('.*xml version.*\n?','', data)
    data = data.rstrip('\n')

    url = '/'+RESTV3.urlPrefix+'/device/' + str(queryType) + '+' + str(queryValue) + '/offers/' + str(resourceId) + '/resume'

    if routingType and routingValue :
        url += '?TrafficRouteData='+routingType + str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' data:\n' + data)

    response = V3inst.put(url, payload=data)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def deviceRemoveScheduledOfferStatusChange(V3inst=None, queryValue=None, queryType='PhoneNumber', resourceId=None, now=None, eventPass=True,
    apiEventData=None, executeMode=None, routingType=None, routingValue=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/device/' + str(queryValue) + '/offers/' + str(resourceId) + '/scheduled_status_change'
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip():
                url += '?ApiEventData=' +apiEventDataStr
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#========================================================
def deviceActivateOffer(V3inst, queryValue, queryType, resourceId=None, now=None, executeMode=None,
                             routingType=None, routingValue=None, eventPass=True, apiEventData=None, multiRequestBuild=None):

    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix + '/device/' + str(queryValue) + '/offers/' + str(resourceId) + '/activate'

    delim = '?'
    amp = False

    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType+str(routingValue)
        delim = '&'
        amp = True

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip():
                url += delim + 'ApiEventData=' +apiEventDataStr
                amp = True

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.put(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def queryMembership(V3inst,queryValue, membershipType, queryCursor=None, querySize=None, object='subscriber', now=None, returnExternalId=False, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Map membershipType to URL string
    if object == 'subscriber':
        if membershipType == '1':
                membershipTypeStr = 'groups'
        elif membershipType == '2':
                membershipTypeStr = 'administers'
        else:
                return COMMON.debugFailure(method='querySubscriberMembership', status=10, msg=str(membershipType) + ' is not a valid subscriber membership type value')  
    else:
        if membershipType == '1':
                membershipTypeStr = 'subscribers'
        elif membershipType == '2':
                membershipTypeStr = 'subgroups'
        elif membershipType == '3': 
                membershipTypeStr = 'administrators'
        else:
                return COMMON.debugFailure(method='queryGroupMembership', status=10, msg=str(membershipType) + ' is not a valid group membership type value')   

    # Build URL string
    amp = False
    url = '/'+RESTV3.urlPrefix+'/' + object + '/' + str(queryValue) + '/' + membershipTypeStr
    if returnExternalId: url += '?returnExternalId='+ str(returnExternalId)

    # If either query parameter is specified
    if querySize or queryCursor:
        # Add question mark or ampersand (depends if question mark alreay in the URL)
        if not url.count('?'): url += '?'
        else: url += '&'
        amp = True
        
        # Add querySize
        if querySize:
                url += 'querySize=' + str(querySize)
                # Add ampersand if also have other parameter
                if queryCursor: url += '&'
        
        # Add queryCursor
        if queryCursor: url += 'queryCursor=' + str(queryCursor)
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
   # print url  
    # Get the data
    response = V3inst.get(url,  time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    
    # Debug output
    #print 'Object ' + object + '  response: ' + response     
    
    # Want to extract any QueryCursor value.  
    # There has to be a better way then this...
    # Assume nothing found
    queryCursor = '0'
    
    # Split response into dictionary per line
    if isinstance(response, bytes):
        response = response.decode('utf-8') #fix for python3

    respDict = response.split('\n')
    
    # Look at each line
    for item in respDict:
        # See if string is in this entry
        if 'QueryCursor' in item:
                # Get value
                if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
                    queryCursor = str(item.split(':')[1].split(',')[0])
                else:
                    queryCursor = str(item.split('>')[1].split('<')[0])
                
                # Exit once found
                break
                
    return (response, queryCursor)
    
#=============================================================
def querySubscriberMembership(V3inst,queryValue, membershipType=None, queryType='ExternalId', queryCursor=None, querySize=None, now=None, eventPass=True, returnExternalId=False, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # get object OID if not passed in   
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, querySize=querySize, eventPass=eventPass, now=now)
        queryValue = getOID(queryResponse)

    # Complete membership event
    (response, queryCursor) = queryMembership(V3inst,queryValue, membershipType, queryCursor=queryCursor, querySize=querySize, object='subscriber', now=now, returnExternalId=returnExternalId)
    
    # Validate
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return (response, queryCursor)

#=============================================================
def queryGroupMembership(V3inst,queryValue, membershipType=None, queryType='ExternalId', queryCursor=None, querySize=None, now=None, eventPass=True, returnExternalId=False, multiRequestBuild=None):
  
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Map membershipType to URL string
    # get object OID if not passed in
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, querySize=querySize, eventPass=eventPass, now=now)
        queryValue = getOID(queryResponse)

    # Complete membership event
    (response, queryCursor) = queryMembership(V3inst,queryValue, membershipType, queryCursor=queryCursor, querySize=querySize, object='group', now=now, returnExternalId=returnExternalId)
    
    # Validate
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return (response, queryCursor)

#=============================================================
def querySubscriberWallet(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass, now=now)
        queryValue = getOID(queryResponse)
    
    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/wallet'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        
    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberCheckPurchasedItemCycleAlignment(V3inst, queryValue, queryType='ExternalId', offerExternalId=None, catalogId=None, offerId=None, offerResourceId=None, now=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass, now=now)
        queryValue = getOID(queryResponse)

    if offerResourceId:
        profTemplate = open(templates + 'subscriber_check_alignment_resource'+RESTV3.fileType).read()
        profTemplate = RESTHELPER.checkIfDefined(offerResourceId, None, 'OFFERRESOURCEID', profTemplate, 'OfferResourceId')    
    else:
        profTemplate = open(templates + 'subscriber_check_alignment'+RESTV3.fileType).read()
        profTemplate = RESTHELPER.checkIfDefined(offerExternalId, None, 'OFFEREXTID', profTemplate, 'ExternalId')
        profTemplate = RESTHELPER.checkIfDefined(offerId, None, 'OFFERID', profTemplate, 'ProductOfferId')
        profTemplate = RESTHELPER.checkIfDefined(catalogId, None, 'CATALOGITEMID', profTemplate, 'CatalogItemId')
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OID', profTemplate, 'ObjectId')
    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/cycle_alignment'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, time=now, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def deviceCheckPurchasedItemCycleAlignment(V3inst, queryValue, queryType='ExternalId', offerExternalId=None, catalogId=None, offerId=None, offerResourceId=None, now=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass, now=now)
        queryValue = getOID(queryResponse)

    if offerResourceId:
        profTemplate = open(templates + 'device_check_alignment_resource'+RESTV3.fileType).read()
        profTemplate = RESTHELPER.checkIfDefined(offerResourceId, None, 'OFFERRESOURCEID', profTemplate, 'OfferResourceId')

    else:
        profTemplate = open(templates + 'device_check_alignment'+RESTV3.fileType).read()
        profTemplate = RESTHELPER.checkIfDefined(offerExternalId, None, 'OFFEREXTID', profTemplate, 'ExternalId')
        profTemplate = RESTHELPER.checkIfDefined(offerId, None, 'OFFERID', profTemplate, 'ProductOfferId')
        profTemplate = RESTHELPER.checkIfDefined(catalogId, None, 'CATALOGITEMID', profTemplate, 'CatalogItemId')

    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OID', profTemplate, 'ObjectId')
    url = '/'+RESTV3.urlPrefix+'/device/' + str(queryValue) + '/cycle_alignment'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, time=now, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def groupCheckPurchasedItemCycleAlignment(V3inst, queryValue, queryType='ExternalId', offerExternalId=None, catalogId=None, offerId=None, offerResourceId=None, now=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass, now=now)
        queryValue = getOID(queryResponse)

    if offerResourceId:
        profTemplate = open(templates + 'group_check_alignment_resource'+RESTV3.fileType).read()
        profTemplate = RESTHELPER.checkIfDefined(offerResourceId, None, 'OFFERRESOURCEID', profTemplate, 'OfferResourceId')

    else:
        profTemplate = open(templates + 'group_check_alignment'+RESTV3.fileType).read()
        profTemplate = RESTHELPER.checkIfDefined(offerExternalId, None, 'OFFEREXTID', profTemplate, 'ExternalId')
        profTemplate = RESTHELPER.checkIfDefined(offerId, None, 'OFFERID', profTemplate, 'ProductOfferId')
        profTemplate = RESTHELPER.checkIfDefined(catalogId, None, 'CATALOGITEMID', profTemplate, 'CatalogItemId')

    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OID', profTemplate, 'ObjectId')
    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/cycle_alignment'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, time=now, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def createDevice(V3inst, imsi, externalId=None, deviceType=None, attr=None, now=None, accessNumbers=None,
        eventPass=True, status=None, mobile=None, routingType=None, routingValue=None, executeMode=None,
        tenantId=None, apiEventData=None, returnTemplate=False, multiRequestBuild=None, apiEventSecurityInfo=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if accessNumbers is not None and type(accessNumbers) is not list:
        accessNumbers = [accessNumbers]

    attrStr = None
    if attr is None:
        try:
            attr = MDCDEFS.kMtxMobileDeviceExtensionMdcDesc.create()
        except:
            return COMMON.debugFailure(method='createDevice', status=9, msg='Error creating attr',
                shouldPass=eventPass)

    if imsi is not None:
        try:
            attr.setUsingKey(MDCDEFS.kMtxMobileDeviceExtensionImsiFldKey, imsi)
        except:
            return COMMON.debugFailure(method='createDevice', status=10, msg='Error setting imsi in attr',
                shouldPass=eventPass)
            
    if accessNumbers is not None:
        try:
            attr.setUsingKey(MDCDEFS.kMtxMobileDeviceExtensionAccessNumberArrayFldKey, accessNumbers)
        except:
            return COMMON.debugFailure(method='createDevice', status=11, msg='Error setting access numbers in attr',
                shouldPass=eventPass)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    apiEventSecurityInfoStr = None
    if apiEventSecurityInfo is not None:
        apiEventSecurityInfoStr = parseAttrMdc(apiEventSecurityInfo)

    attrStr = parseAttrMdc(attr)
    profTemplate = open(templates + 'device_create'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'EXTERNALID', profTemplate, 'ExternalId')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    profTemplate = RESTHELPER.checkIfDefined(deviceType, None, 'DEVICETYPE', profTemplate, 'DeviceType')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(tenantId, None, 'TENANTID', profTemplate, 'TenantId')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventSecurityInfoStr, None, 'APIEVENTSECURITYINFO', profTemplate, 'ApiEventSecurityInfo')
    #print 'Create device:  payload = ' + str(profTemplate)
    if returnTemplate:
        return profTemplate

    if routingType and routingValue:
                url = '/'+RESTV3.urlPrefix+'/device?TrafficRouteData='+routingType+str(routingValue)
    else:       url = '/'+RESTV3.urlPrefix+'/device'
           
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method='createDevice', shouldPass=eventPass, returnParam='ObjectId')

#=============================================================
def subscriberCreateDevice(V3inst, queryValue=None, queryType='ObjectId', deviceId=None, externalId=None, deviceType=None, attr=None,
        now=None, accessNumbers=None,eventPass=True, status=None, mobile=None, routingType=None, routingValue=None, executeMode=None,
        tenantId=None, returnTemplate=False, apiEventData=None, multiRequestBuild=None):

    funcName = QAUTILS.getFunctionName()

    profTemplate = createDevice(V3inst, deviceId, externalId=None, deviceType=deviceType, attr=attr, apiEventData=apiEventData,
            tenantId=tenantId, now=now, accessNumbers=accessNumbers, status=status, mobile=None, executeMode=executeMode, returnTemplate=True)
    profTemplate = re.sub('.*xml version.*\n?','',profTemplate)

    url = '/'+RESTV3.urlPrefix+'/service/'+RESTV3.subUrl+'/' + str(queryType) + '+' + str(queryValue) + '/device'
    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType+str(routingValue)

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def createDeviceLogin(V3inst, loginId, externalId=None, deviceType=None, attr=None, now=None, apiEventData=None, tenantId=None,
        accessIds=None, eventPass=True, status=None, routingType=None, routingValue=None, executeMode=None, multiRequestBuild=None, apiEventSecurityInfo=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if accessIds is not None and type(accessIds) is not list:
        accessIds = [accessIds]

    attrStr = None
    if attr is None:
        try:
            attr = MDCDEFS.kMtxLoginDeviceExtensionMdcDesc.create()
        except:
            return COMMON.debugFailure(method='createDeviceLogin', status=9, msg='Error creating attr',
                shouldPass=eventPass)

    if loginId is not None:
        try:
            attr.setUsingKey(MDCDEFS.kMtxLoginDeviceExtensionLoginIdFldKey, loginId)
        except:
            return COMMON.debugFailure(method='createDeviceLogin', status=10, msg='Error setting login in attr',
                shouldPass=eventPass)

    if accessIds is not None:
        try:
            attr.setUsingKey(MDCDEFS.kMtxLoginDeviceExtensionAccessIdArrayFldKey, accessIds)
        except:
            return COMMON.debugFailure(method='createDeviceLogin', status=11, msg='Error setting access ids in attr',
                shouldPass=eventPass)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    attrStr = parseAttrMdc(attr)
    profTemplate = open(templates + 'device_create'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'EXTERNALID', profTemplate, 'ExternalId')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    profTemplate = RESTHELPER.checkIfDefined(deviceType, None, 'DEVICETYPE', profTemplate, 'DeviceType')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(tenantId, None, 'TENANTID', profTemplate, 'TenantId')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(apiEventSecurityInfo, None, 'APIEVENTSECURITYINFO', profTemplate, 'ApiEventSecurityInfo')
    
    if routingType and routingValue:
                url = '/'+RESTV3.urlPrefix+'/device?TrafficRouteData='+routingType+str(routingValue)
    else:       url = '/'+RESTV3.urlPrefix+'/device'
           
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method='createDeviceLogin', shouldPass=eventPass, returnParam='ObjectId')


#=============================================================
def subscriberDeleteDevice(V3inst, queryValue=None, queryType='ObjectId', devQueryValue=None, devQueryType='Imsi', now=None, eventPass=True,
    apiEventData=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/'+RESTV3.urlPrefix+'/service/'+RESTV3.subUrl+'/' + str(queryType) + '+' + str(queryValue) + '/device/' + str(devQueryType) + '+' + str(devQueryValue)
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip():
                url += '?ApiEventData=' +apiEventDataStr
                amp = True

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def deleteDevice(V3inst, queryValue, queryType='Imsi', deleteSession=False, now=None, eventPass=True,
    apiEventData=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/device/' + str(queryValue)

    delim = '?'
    amp = False

    if deleteSession:
        url += '?deleteSession=true'
        delim = '&'
        amp = True
           
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip():
                url += delim + 'ApiEventData=' +apiEventDataStr
                amp = True

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.delete(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def addDeviceToSubscriber(V3inst, externalId, deviceId=None, deviceType=1, subQueryType='ExternalId',
        devQueryType='PhoneNumber', eventPass=True, accessNumbers=None, attr=None, status=None, now=None, executeMode=None,
        tenantId=None, apiEventData=None, isCreateDevice=True, noTouch=False, devOid=None, routingType=None, routingValue=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    # for negative tests that do not want to create device
    if deviceId and not isCreateDevice :
        queryValue = None
        # Need to get object OID values
        if subQueryType != 'ObjectId':
                queryResponse = querySubscriber(V3inst=V3inst, queryValue=externalId, queryType=subQueryType, now=now)
                externalId = getOID(queryResponse)
        if devQueryType != 'ObjectId':
             queryResponse = queryDevice(V3inst=V3inst, queryValue=deviceId, queryType=devQueryType, eventPass=eventPass,now=now)
             queryValue = getOID(queryResponse)

        if not eventPass and queryValue is None:
            pass
        else:
             deviceId = queryValue

        url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(externalId) + '/device/' + str(deviceId)
    
        amp = False
        if apiEventData is not None:
            apiEventDataStr = parseAttrMdc(apiEventData)
            if apiEventDataStr and apiEventDataStr.strip():
                url += '?ApiEventData=' +apiEventDataStr
                amp = True

        # If Debug if globally set
        if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
    
        # Send in the command
        response = V3inst.put(url, time=now, amp=amp)
        if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
        success = validateResponse(response=response, method=funcName, shouldPass=eventPass)
        return (success, deviceId)

    # Check if the device already exists
    existed = True
    if deviceId:
        if (devQueryType == 'PhoneNumber' or devQueryType == 'LoginId')  and eventPass:
            if noTouch:
                #if using the noTouch option, device must not exist OR device oid must be passed in
                if devOid:
                    oid = devOid
                else:
                    existed = False
            elif not queryDevice(V3inst=V3inst, queryType=devQueryType, queryValue=deviceId, eventPass=None, now=now):
                # Device does not exist.
                existed = False
            if not existed:
                # If device ID passed in, then go ahead and create device.
                if deviceId is not None and devQueryType == 'PhoneNumber':
                    (retCode, deviceId) = createDevice(V3inst, imsi=deviceId, deviceType=deviceType, tenantId=tenantId,
                        accessNumbers=accessNumbers, eventPass=eventPass, attr=attr, status=status, now=now, routingType=routingType, routingValue=routingValue)
                    if not retCode:
                        return (COMMON.debugFailure(method=funcName, status=21,
                            msg='could not create device with id ' + str(deviceId), shouldPass=eventPass), None)
                elif deviceId is not None and devQueryType == 'LoginId' : #and eventPass:
                     (retCode, deviceId) = createDeviceLogin(V3inst, loginId=deviceId, deviceType=deviceType, tenantId=tenantId,
                           attr=attr, accessIds=accessNumbers, status=status, now=now, routingType=routingType, routingValue=routingValue)
                     if not retCode:
                         return (COMMON.debugFailure(method=funcName, status=21,
                           msg='could not create device with login id ' + str(deviceId), shouldPass=eventPass), None)
                # If call is expected to pass, device does not exist, and no ID is passed in, should fail!
                elif eventPass:
                    return (COMMON.debugFailure(method=funcName, status=20,
                        msg='no device id passed in', shouldPass=True), None)

                # Continue on for negative testing
                elif not eventPass:
                    oid = None

    else:
        return (COMMON.debugFailure(method=funcName, status=20, msg='no device id passed in',
            shouldPass=True), None)

    # Get device OID if queryType is not ObjectId
    if existed and devQueryType != 'ObjectId' and not noTouch:
        queryResponse = queryDevice(V3inst=V3inst, queryValue=deviceId, queryType=devQueryType, now=now)
        deviceId = getOID(queryResponse)
    
    if noTouch:
        pass
    # Check if device already has an owner (devices can only belong to one subscriber)
    elif existed or eventPass:
        queryResponse = queryDevice(V3inst=V3inst, queryValue=deviceId, queryType='ObjectId', now=now)
        if getSubscriberId(queryResponse):
            if not existed:
                return (COMMON.debugFailure(method=funcName, status=19,
                    msg='Device is already associated with a subscriber', shouldPass=eventPass), deviceId)
            else:
                return (COMMON.debugFailure(method=funcName, status=19,
                    msg='Device is already associated with a subscriber', shouldPass=eventPass), None)

    # Get subscriber OID if queryType is not ObjectId
    if subQueryType != 'ObjectId' and not noTouch:
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=externalId, queryType=subQueryType, now=now)
        externalId = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(externalId) + '/device/' + str(deviceId)

    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip():
                url += '?ApiEventData=' +apiEventDataStr
                amp = True

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    # Now add the device to the subscriber
    response = V3inst.put(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    success = validateResponse(response=response, method=funcName, shouldPass=eventPass)
    if not existed:
        return (success, deviceId)
    else:
        return (success, None)

#=============================================================
def removeDeviceFromSubscriber(V3inst, subscriberId, deviceId, subQueryType, devQueryType, deleteSession, eventPass, now,
    apiEventData=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if subQueryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=subscriberId, queryType=subQueryType, now=now,eventPass=eventPass)
        subscriberId = getOID(queryResponse)
    if devQueryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=deviceId, queryType=devQueryType, eventPass=None,now=now)
        deviceId = getOID(queryResponse)
    
    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(subscriberId) + '/device/' + str(deviceId)

    amp = False

    delim = '?'
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip():
                url += '?ApiEventData=' +apiEventDataStr
                amp = True
                delim = '&'

    # Delete session can be boolean, string, or int
    if deleteSession == True or deleteSession == '1' or deleteSession == 1:
        url += delim + 'deleteSession=true'
        amp = True
    
    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def modifyDevice(V3inst, queryValue, queryType='PhoneNumber', deviceType=None, attr=None, now=None, eventPass=True,
                  status=None, accessNumbers=None, externalId=None, lastActivityUpdateTime=None, imsi=None,
                  tenantId=None, apiEventData=None, loginId=None, executeMode=None, multiRequestBuild=None):

    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if accessNumbers is not None and type(accessNumbers) is not list:
       accessNumbers = [accessNumbers]

    attrStr = None
    if attr is None and accessNumbers is not None:
        try:
            if queryType=='LoginId' or queryType=='AccessId':
               attr = MDCDEFS.kMtxLoginDeviceExtensionMdcDesc.create()

            else:
               attr = MDCDEFS.kMtxMobileDeviceExtensionMdcDesc.create()

        except:
            return COMMON.debugFailure(method='modifyDevice', status=9, msg='Error setting access numbers in attr',
                shouldPass=eventPass)
            
    if accessNumbers is not None:
        try:
            if queryType=='LoginId' or  queryType=='AccessId':
               attr.setUsingKey(MDCDEFS.kMtxLoginDeviceExtensionAccessIdArrayFldKey, accessNumbers)

            else:
                attr.setUsingKey(MDCDEFS.kMtxMobileDeviceExtensionAccessNumberArrayFldKey, accessNumbers)
        except:
            return COMMON.debugFailure(method='modifyDevice', status=9, msg='Error setting access numbers in attr',
                shouldPass=eventPass)

    attrStr = parseAttrMdc(attr)
    #modify imsi/loginId can be only done outside of attr
    #To modify non-imsi attr, we need to remove Imsi/LoginId
    if attr is not None and attrStr: 
        attrStr = RESTHELPER.removeItem(attrStr, 'Imsi')
        attrStr = RESTHELPER.removeItem(attrStr, 'LoginId')
        
    # Get subscriber OID if queryType is not ObjectId
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)
    
    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'device_modify'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'EXTERNALID', profTemplate, 'ExternalId')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    profTemplate = RESTHELPER.checkIfDefined(deviceType, None, 'DEVICETYPE', profTemplate, 'DeviceType')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(lastActivityUpdateTime, None, 'LASTACTIVITYUPDATETIME',
        profTemplate, 'LastActivityUpdateTime')
    profTemplate = RESTHELPER.checkIfDefined(imsi, None, 'IMSI', profTemplate, 'Imsi')
    profTemplate = RESTHELPER.checkIfDefined(loginId, None, 'LOGINID', profTemplate, 'LoginId')
    profTemplate = RESTHELPER.checkIfDefined(tenantId, None, 'TENANTID', profTemplate, 'TenantId')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    
    url = '/'+RESTV3.urlPrefix+'/device/' + str(queryValue)
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

# Rehome a Device (Requires a multi sub-domain engine configuration)
#=============================================================
def deviceRehome(V3inst, queryValue, queryType='ObjectId', routingType='RouteId', routingValue=2, eventPass=True,
    apiEventData=None, multiRequestBuild=None):
    global restVersion

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/device/' + str(queryValue) + '/rehome/' + str(routingType) + '+' + str(routingValue)
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip():
                url += '?ApiEventData=' +apiEventDataStr
                amp = True
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        
    response = V3inst.put(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if validateResponse(response=response, method='deviceRehome', shouldPass=eventPass):
        return response

#====================================================
def devicePurchaseOffer(V3inst, queryValue, offerId=None, catalogItemId=None, offerStartTime=None,
        offerEndTime=None, queryType='PhoneNumber', eventPass=True, now=None, offerIsExternal=False,
        attr=None, chargeMethod=None, paymentMethodResourceId=None, paymentGatewayId=None, paymentGatewayOneTimeToken=None,
        paymentGatewayUserId=None, purchaseInfo=False, executeMode=None, etcScheduleRangeArray=None, etcScheduleRangeUnit=None, paymentScheduleRangeArray=None,
        paymentScheduleAmountArray=None, paymentScheduleLastAmount=None, delayCharge=None, deferredSettlement=None, deferredSettlementTimeout=None, deferredSettlementTimeoutAction=None,
        offerCycleType=None, offerCycleResourceId=None, offerCycleOffset=None, cycleOwnerType=None, offerCycleStartTime=None,
        preActiveState=None, autoActivationTime=None, autoActivationRelativeOffsetUnit=None, autoActivationRelativeOffset=None, autoActivationCycleResourceId=None,
        activationExpirationTime=None, activationExpirationRelativeOffsetUnit=None, activationExpirationRelativeOffset=None,
        chargeMethodAttr=None, endTimeRelativeOffsetUnit=None, endTimeRelativeOffset=None, downPayment=None, future=False,
        isRecurringFailureAllowed=None, multiRequestBuild=None, isTargetResource=None, useTargetResource=None, parameterList=None, offerStatusValue=None,
        chargePurchaseProrationType=None, grantPurchaseProrationType=None, reason=None, info=None, apiEventData=None,
        paymentDueDate=None, contractPeriod=None, contractInterval=None, commitmentPeriod=None, commitmentPeriodInterval=None, isOpenContract=None,
        isPendingActivationAllowed=None, offerLifecycleProfileId=None,
        routingType=None, routingValue=None, eligibilityCheck=True, geoData=None, endAfterCycleCount=None, noEndTime=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if now is None:
        now = offerStartTime

    # Get device OID if queryType is not ObjectId
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    # Process any input attributes
    attrStr = None
    if attr is not None:
        attrStr = parseAttrMdc(attr)
    chargeMethodAttrStr = None
    if chargeMethodAttr is not None:
        chargeMethodAttrStr = parseAttrMdc(chargeMethodAttr)
    if isRecurringFailureAllowed:
        isRecurringFailureAllowed = 'true'
    elif isRecurringFailureAllowed == False:
        isRecurringFailureAllowed = 'false'
    if isPendingActivationAllowed:
        isPendingActivationAllowed = 'true'
    elif isPendingActivationAllowed == False:
        isPendingActivationAllowed = 'false'
    if deferredSettlement:
        deferredSettlement='true'
    
    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    if geoData is None:
        geoData = ""

    parameterArray = None
    if parameterList:
        parameterArray = parseParameterList(parameterList)

    # Allow for custom URLs (for BGAPI code)
    if CSV.overrideURL and 'purchase' in CSV.overrideOperations: custom = '/' + CSV.overrideURL
    else: custom = ''
    url = '/' + RESTV3.urlPrefix + custom + '/device/' + str(queryValue) + '/offers'
    
    # Input may be a list or may be a single item
    if type(catalogItemId) is list:
        offerId = catalogItemId


    # populate contractParameterOverrideDataTemplate, which only support single one at moment
    contractParameterOverrideDataTemplate = createContractParameterOverrideData(etcScheduleRangeArray=etcScheduleRangeArray, etcScheduleRangeUnit=etcScheduleRangeUnit, paymentScheduleRangeArray=paymentScheduleRangeArray, paymentScheduleAmountArray=paymentScheduleAmountArray, paymentScheduleLastAmount=paymentScheduleLastAmount, delayCharge=delayCharge, contractPeriod=contractPeriod, contractInterval=contractInterval, commitmentPeriod=commitmentPeriod, commitmentPeriodInterval=commitmentPeriodInterval, isOpenContract=isOpenContract)


    if type(offerId) is list:
        createResourceIds = []
        for offer in offerId:
            # Purchase offer and validate for each, append created resource id to list
            profTemplate = open(templates + 'device_purchase_offer'+RESTV3.fileType).read()
            if offerIsExternal:
                profTemplate = RESTHELPER.removeItem(profTemplate, 'ProductOfferId')
                profTemplate = RESTHELPER.removeItem(profTemplate, 'CatalogItemId')
                profTemplate = RESTHELPER.checkIfDefined(offer, None, 'OFFERID', profTemplate, 'ExternalId')
            else:
                profTemplate = RESTHELPER.removeItem(profTemplate, 'ExternalId')
                if catalogItemId:
                    profTemplate = RESTHELPER.checkIfDefined(offer, None, 'CATALOGITEMID', profTemplate, 'CatalogItemId')
                    profTemplate = RESTHELPER.removeItem(profTemplate, 'ProductOfferId')
                else:
                    profTemplate = RESTHELPER.checkIfDefined(offer, None, 'OFFERID', profTemplate, 'ProductOfferId')
                    profTemplate = RESTHELPER.removeItem(profTemplate, 'CatalogItemId')

            profTemplate = RESTHELPER.checkIfDefined(offerStartTime, None, 'STARTTIME', profTemplate, 'StartTime')
            profTemplate = RESTHELPER.checkIfDefined(paymentDueDate, None, 'PAYMENTDUEDATE', profTemplate, 'PaymentDueDate')
            profTemplate = RESTHELPER.checkIfDefined(offerStatusValue, None, 'OFFERSTATUSVALUE', profTemplate, 'OfferStatusValue')
            profTemplate = RESTHELPER.checkIfDefined(offerLifecycleProfileId, None, 'OFFERLIFECYCLEPROFILEID', profTemplate, 'OfferLifecycleProfileId')
            profTemplate = RESTHELPER.checkIfDefined(endTimeRelativeOffsetUnit, None, 'ENDTIMERELATIVEOFFSETUNIT', profTemplate, 'EndTimeRelativeOffsetUnit')
            profTemplate = RESTHELPER.checkIfDefined(endTimeRelativeOffset, None, 'ENDTIMERELATIVEOFFSET', profTemplate, 'EndTimeRelativeOffset')
            profTemplate = RESTHELPER.checkIfDefined(offerEndTime, None, 'ENDTIME', profTemplate, 'EndTime')
            profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
            profTemplate = RESTHELPER.checkIfDefined(parameterArray, None, 'PARAMETERARRAY', profTemplate, 'ParameterArray')
            profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
            profTemplate = RESTHELPER.checkIfDefined(preActiveState, None, 'PREACTIVESTATE', profTemplate, 'PreActiveState')
            profTemplate = RESTHELPER.checkIfDefined(autoActivationTime, None, 'AUTOACTIVATIONTIME', profTemplate, 'AutoActivationTime')
            profTemplate = RESTHELPER.checkIfDefined(autoActivationRelativeOffsetUnit, None, 'AUTOACTIVATIONRELATIVEOFFSETUNIT', profTemplate, 'AutoActivationRelativeOffsetUnit')
            profTemplate = RESTHELPER.checkIfDefined(autoActivationRelativeOffset, None, 'aUTOACTIVATIONRELATIVEOFFSET', profTemplate, 'AutoActivationRelativeOffset')
            profTemplate = RESTHELPER.checkIfDefined(autoActivationCycleResourceId, None, 'AUTOACTIVATIONCYCLERESOURCEID', profTemplate, 'AutoActivationCycleResourceId')
            profTemplate = RESTHELPER.checkIfDefined(activationExpirationTime, None, 'ACTIVATIONEXPIRATIONTIME', profTemplate,
                'ActivationExpirationTime')
            profTemplate = RESTHELPER.checkIfDefined(activationExpirationRelativeOffsetUnit, None, 'ACTIVATIONEXPIRATIONRELATIVEOFFSETUNIT',
                profTemplate, 'ActivationExpirationRelativeOffsetUnit')
            profTemplate = RESTHELPER.checkIfDefined(activationExpirationRelativeOffset, None, 'ACTIVATIONEXPIRATIONRELATIVEOFFSET',
                profTemplate, 'ActivationExpirationRelativeOffset')
            profTemplate = RESTHELPER.checkIfDefined(isPendingActivationAllowed, None, 'ISPENDINGACTIVATIONALLOWED', profTemplate, 'IsPendingActivationAllowed')
            profTemplate = RESTHELPER.checkIfDefined(isRecurringFailureAllowed, None, 'ISRECURRINGFAILUREALLOWED', profTemplate, 'IsRecurringFailureAllowed')
            profTemplate = RESTHELPER.checkIfDefined(endAfterCycleCount, None, 'ENDAFTERCYCLECOUNT', profTemplate, 'EndAfterCycleCount')
            profTemplate = RESTHELPER.checkIfDefined(noEndTime, None, 'NOENDTIME', profTemplate, 'NoEndTime')
            profTemplate = RESTHELPER.checkIfDefined(chargePurchaseProrationType, None, 'CHARGEPURCHASEPRORATIONTYPE', profTemplate, 'ChargePurchaseProrationType')     
            profTemplate = RESTHELPER.checkIfDefined(grantPurchaseProrationType, None, 'GRANTPURCHASEPRORATIONTYPE', profTemplate, 'GrantPurchaseProrationType')
            profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
            profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
            profTemplate = RESTHELPER.checkIfDefined(geoData, None, 'GEODATA', profTemplate, 'GeoData')
            if chargeMethod or paymentMethodResourceId or paymentGatewayId or paymentGatewayOneTimeToken or chargeMethodAttr:
                chargeMethodData = createChargeMethodData(chargeMethod=chargeMethod, paymentMethodResourceId=paymentMethodResourceId,
                                                          paymentGatewayId=paymentGatewayId, paymentGatewayUserId=paymentGatewayUserId,
                                                          paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, chargeMethodAttr=chargeMethodAttrStr,
                                                          deferredSettlement=deferredSettlement, deferredSettlementTimeout=deferredSettlementTimeout,
                                                          deferredSettlementTimeoutAction=deferredSettlementTimeoutActionr)
            else:
                chargeMethodData = None
            profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')
            profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
            profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')

            if offerCycleType or offerCycleResourceId or offerCycleOffset or offerCycleStartTime or cycleOwnerType:
                cycleTemplate = createCycleData(cycleType=offerCycleType, cycleResourceId=offerCycleResourceId, cycleOffset=offerCycleOffset,
                                        cycleStartTime=offerCycleStartTime, cycleOwnerType=cycleOwnerType)
            else: cycleTemplate = None
            profTemplate = RESTHELPER.checkIfDefined(cycleTemplate, None, 'CYCLEDATA', profTemplate, 'ONEWORDLINE')

            profTemplate = RESTHELPER.checkIfDefined(eligibilityCheck, None, 'ELIGIBILITYCHECK', profTemplate, 'EligibilityCheck')
   
            # populate contractParameterOverride
            if contractParameterOverrideDataTemplate:
                profTemplate = RESTHELPER.checkIfDefined(contractParameterOverrideDataTemplate, None, 'CONTRACTPARAMETEROVERRIDEDATA', profTemplate, 'ONEWORDLINE')
            else:
                profTemplate = RESTHELPER.removeOneWordLine(profTemplate, 'CONTRACTPARAMETEROVERRIDEDATA')

            
            if routingType and routingValue :
                url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

            # Debug output if globally set
            if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + profTemplate)
        
            response = V3inst.put(url, payload=profTemplate)
            if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
            (success, resourceId) = validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='ResourceId')
            createResourceIds.append(resourceId)

        if purchaseInfo:
           return (passed(eventPass), response)
        else:
           return (passed(eventPass), createResourceIds)
    else:
        # Purchase offer and validate, return created resourceId
        profTemplate = open(templates + 'device_purchase_offer'+RESTV3.fileType).read()
        if offerIsExternal:
            profTemplate = RESTHELPER.removeItem(profTemplate, 'ProductOfferId')
            profTemplate = RESTHELPER.removeItem(profTemplate, 'CatalogItemId')
            if catalogItemId:
                profTemplate = RESTHELPER.checkIfDefined(catalogItemId, None, 'OFFERID', profTemplate, 'ExternalId')
            else:
                profTemplate = RESTHELPER.checkIfDefined(offerId, None, 'OFFERID', profTemplate, 'ExternalId')
        else:
            profTemplate = RESTHELPER.removeItem(profTemplate, 'ExternalId')
            profTemplate = RESTHELPER.checkIfDefined(offerId, None, 'OFFERID', profTemplate, 'ProductOfferId')
            profTemplate = RESTHELPER.checkIfDefined(catalogItemId, None, 'CATALOGITEMID', profTemplate, 'CatalogItemId')

        profTemplate = RESTHELPER.checkIfDefined(offerStartTime, None, 'STARTTIME', profTemplate, 'StartTime')
        profTemplate = RESTHELPER.checkIfDefined(paymentDueDate, None, 'PAYMENTDUEDATE', profTemplate, 'PaymentDueDate')
        profTemplate = RESTHELPER.checkIfDefined(offerStatusValue, None, 'OFFERSTATUSVALUE', profTemplate, 'OfferStatusValue')
        profTemplate = RESTHELPER.checkIfDefined(offerLifecycleProfileId, None, 'OFFERLIFECYCLEPROFILEID', profTemplate, 'OfferLifecycleProfileId')

        if offerCycleType or offerCycleResourceId or offerCycleOffset or offerCycleStartTime or cycleOwnerType:
            cycleTemplate = createCycleData(cycleType=offerCycleType, cycleResourceId=offerCycleResourceId, cycleOffset=offerCycleOffset,
                                        cycleStartTime=offerCycleStartTime, cycleOwnerType=cycleOwnerType)
        else: cycleTemplate = None
        profTemplate = RESTHELPER.checkIfDefined(cycleTemplate, None, 'CYCLEDATA', profTemplate, 'ONEWORDLINE')

        profTemplate = RESTHELPER.checkIfDefined(endTimeRelativeOffsetUnit, None, 'ENDTIMERELATIVEOFFSETUNIT', profTemplate, 'EndTimeRelativeOffsetUnit')
        profTemplate = RESTHELPER.checkIfDefined(endTimeRelativeOffset, None, 'ENDTIMERELATIVEOFFSET', profTemplate, 'EndTimeRelativeOffset')
        profTemplate = RESTHELPER.checkIfDefined(offerEndTime, None, 'ENDTIME', profTemplate, 'EndTime')
        profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
        profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
        profTemplate = RESTHELPER.checkIfDefined(parameterArray, None, 'PARAMETERARRAY', profTemplate, 'ParameterArray')
        profTemplate = RESTHELPER.checkIfDefined(preActiveState, None, 'PREACTIVESTATE', profTemplate, 'PreActiveState')
        profTemplate = RESTHELPER.checkIfDefined(autoActivationTime, None, 'AUTOACTIVATIONTIME', profTemplate, 'AutoActivationTime')
        profTemplate = RESTHELPER.checkIfDefined(autoActivationRelativeOffsetUnit, None, 'AUTOACTIVATIONRELATIVEOFFSETUNIT', profTemplate, 'AutoActivationRelativeOffsetUnit')
        profTemplate = RESTHELPER.checkIfDefined(autoActivationRelativeOffset, None, 'aUTOACTIVATIONRELATIVEOFFSET', profTemplate, 'AutoActivationRelativeOffset')
        profTemplate = RESTHELPER.checkIfDefined(autoActivationCycleResourceId, None, 'AUTOACTIVATIONCYCLERESOURCEID', profTemplate, 'AutoActivationCycleResourceId')
        profTemplate = RESTHELPER.checkIfDefined(activationExpirationTime, None, 'ACTIVATIONEXPIRATIONTIME', profTemplate,
            'ActivationExpirationTime')
        profTemplate = RESTHELPER.checkIfDefined(activationExpirationRelativeOffsetUnit, None, 'ACTIVATIONEXPIRATIONRELATIVEOFFSETUNIT',
            profTemplate, 'ActivationExpirationRelativeOffsetUnit')
        profTemplate = RESTHELPER.checkIfDefined(activationExpirationRelativeOffset, None, 'ACTIVATIONEXPIRATIONRELATIVEOFFSET',
            profTemplate, 'ActivationExpirationRelativeOffset')
        profTemplate = RESTHELPER.checkIfDefined(isPendingActivationAllowed, None, 'ISPENDINGACTIVATIONALLOWED', profTemplate, 'IsPendingActivationAllowed')
        profTemplate = RESTHELPER.checkIfDefined(isRecurringFailureAllowed, None, 'ISRECURRINGFAILUREALLOWED', profTemplate, 'IsRecurringFailureAllowed')
        profTemplate = RESTHELPER.checkIfDefined(endAfterCycleCount, None, 'ENDAFTERCYCLECOUNT', profTemplate, 'EndAfterCycleCount')
        profTemplate = RESTHELPER.checkIfDefined(noEndTime, None, 'NOENDTIME', profTemplate, 'NoEndTime')
        profTemplate = RESTHELPER.checkIfDefined(chargePurchaseProrationType, None, 'CHARGEPURCHASEPRORATIONTYPE', profTemplate, 'ChargePurchaseProrationType') 
        profTemplate = RESTHELPER.checkIfDefined(grantPurchaseProrationType, None, 'GRANTPURCHASEPRORATIONTYPE', profTemplate, 'GrantPurchaseProrationType')
        profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
        profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
        if chargeMethod or paymentMethodResourceId or paymentGatewayId or paymentGatewayOneTimeToken or chargeMethodAttr:
            chargeMethodData = createChargeMethodData(chargeMethod=chargeMethod, paymentMethodResourceId=paymentMethodResourceId,
                                                      paymentGatewayId=paymentGatewayId, paymentGatewayUserId=paymentGatewayUserId,
                                                      paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, chargeMethodAttr=chargeMethodAttrStr,
                                                      deferredSettlement=deferredSettlement, deferredSettlementTimeout=deferredSettlementTimeout,
                                                      deferredSettlementTimeoutAction=deferredSettlementTimeoutAction)
        else:
            chargeMethodData = None
        profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')
        profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
        profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
        profTemplate = RESTHELPER.checkIfDefined(eligibilityCheck, None, 'ELIGIBILITYCHECK', profTemplate, 'EligibilityCheck')
        profTemplate = RESTHELPER.checkIfDefined(geoData, None, 'GEODATA', profTemplate, 'GeoData')

        # populate contractParameterOverride
        if contractParameterOverrideDataTemplate:
            profTemplate = RESTHELPER.checkIfDefined(contractParameterOverrideDataTemplate, None, 'CONTRACTPARAMETEROVERRIDEDATA', profTemplate, 'ONEWORDLINE')
        else:
            profTemplate = RESTHELPER.removeOneWordLine(profTemplate, 'CONTRACTPARAMETEROVERRIDEDATA')

        # If future, then more work to do
        if future:
                # Return from here, as we're scheuling future purchases as a task
                return profTemplate

        if routingType and routingValue :
            url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

        # Debug output if globally set
        if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + profTemplate)
        
        response = V3inst.put(url, payload=profTemplate)
        if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
        (success, resourceId) = validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='ResourceId')

        if purchaseInfo:
           return (passed(eventPass), response)
        else:
           return (passed(eventPass), resourceId)

#=============================================================
def deviceCancelOffer(V3inst, queryValue, resourceId=0, endTime=None, eventPass=True, queryType='PhoneNumber', attr=None, now=None,  
        cancelInfo=False, apiEventData=None, executeMode=None, multiRequestBuild=None, eligibilityCheck=True):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Get device OID if queryType is not ObjectId
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=endTime)
        queryValue = getOID(queryResponse)

    # Build resource id list if resourceId is list
    if type(resourceId) is list:
        numEntries = len(resourceId)
        entryCounter = 1
        resourceIdList = resourceId
        resourceId = ''
        for resource in resourceIdList:
            resourceId += str(resource)
            if entryCounter != numEntries:
                entryCounter += 1
                resourceId += ','
    else:
        resourceId = str(resourceId) + ','

    url = '/'+RESTV3.urlPrefix+'/device/' + str(queryValue) + '/offers/' + str(resourceId)
    delim = '?'
    amp = False

    if executeMode is not None:
        url+= '?executeMode=' + str(executeMode)
        delim = '&'
        amp = True

    if endTime is not None:
        url+= delim + 'timestamp=' + endTime
        delim = '&'
        amp = True
        endTime=None

    if eligibilityCheck is not None:
        url+= delim + 'eligibilityCheck=' + str(eligibilityCheck).lower()
        amp = True
        endTime=None

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip(): 
                url += '?ApiEventData=' +apiEventDataStr
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        
    response = V3inst.delete(url, time=endTime, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if cancelInfo:
        return (validateResponse(response=response, method=funcName, shouldPass=eventPass), response)
    else:
        return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def deviceCancelOfferExt(V3inst, queryValue, resourceId=0, cancelType=None, grantCancelProrationType=None, chargeCancelProrationType=None,
        reason=None, info=None, now=None, queryType='PhoneNumber', cancelInfo=False, cancelOfferDataList='', eventPass=True, executeMode=None,
        apiEventData=None, contractCancelMode=None, debtCancellationMode=None, multiRequestBuild=None, isWaiveEarlyTerminationCharge=None, eligibilityCheck=True):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    profTemplate = open(templates + 'device_cancel_offer'+RESTV3.fileType).read()

    if type(resourceId) is not list:
        resourceId = [resourceId]
    cancelTemplate=''
    idArray=''

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    if cancelOfferDataList:
        for cancelOfferData in cancelOfferDataList:
            template = open(templates + 'cancel_offer_data'+RESTV3.fileType).read()
            template = RESTHELPER.checkIfDefined(cancelOfferData["ResourceId"], None, 'RESOURCEID', template, 'ResourceId')
            template = RESTHELPER.checkIfDefined(cancelOfferData["CancelType"], None, 'CANCELTYPE', template, 'CancelType')
            template = RESTHELPER.checkIfDefined(cancelOfferData["GrantCancelProrationType"], None, 'GRANTCANCELPRORATIONTYPE', template, 'GrantCancelProrationType')
            template = RESTHELPER.checkIfDefined(cancelOfferData["ChargeCancelProrationType"], None, 'CHARGECANCELPRORATIONTYPE', template, 'ChargeCancelProrationType')
            template = RESTHELPER.checkIfDefined(cancelOfferData["ContractCancelMode"], None, 'CONTRACTCANCELMODE', template, 'ContractCancelMode')
            template = RESTHELPER.checkIfDefined(cancelOfferData["DebtCancellationMode"], None, 'DEBTCANCELLATIONMODE', template, 'DebtCancellationMode')

            template = RESTHELPER.checkIfDefined(cancelOfferData["IsWaiveEarlyTerminationCharge"], None, 'ISWAIVEEARLYTERMINATIONCHARGE', template, 'IsWaiveEarlyTerminationCharge')
            template = RESTHELPER.checkIfDefined(cancelOfferData["Reason"], None, 'REASON', template, 'Reason')
            template = RESTHELPER.checkIfDefined(cancelOfferData["Info"], None, 'INFO', template, 'Info')
            cancelTemplate += template
    elif cancelType or grantCancelProrationType or chargeCancelProrationType or reason or info or contractCancelMode or debtCancellationMode:
        profTemplate = RESTHELPER.removeItem(profTemplate, 'ResourceIdArray')
        for id in resourceId:
            template = open(templates + 'cancel_offer_data'+RESTV3.fileType).read()
            template = RESTHELPER.checkIfDefined(id, None, 'RESOURCEID', template, 'ResourceId')
            template = RESTHELPER.checkIfDefined(cancelType, None, 'CANCELTYPE', template, 'CancelType')
            template = RESTHELPER.checkIfDefined(grantCancelProrationType, None, 'GRANTCANCELPRORATIONTYPE', template, 'GrantCancelProrationType')
            template = RESTHELPER.checkIfDefined(chargeCancelProrationType, None, 'CHARGECANCELPRORATIONTYPE', template, 'ChargeCancelProrationType')
            template = RESTHELPER.checkIfDefined(contractCancelMode, None, 'CONTRACTCANCELMODE', template, 'ContractCancelMode')
            template = RESTHELPER.checkIfDefined(debtCancellationMode, None, 'DEBTCANCELLATIONMODE', template, 'DebtCancellationMode')

            template = RESTHELPER.checkIfDefined(isWaiveEarlyTerminationCharge, None, 'ISWAIVEEARLYTERMINATIONCHARGE', template, 'IsWaiveEarlyTerminationCharge')
            template = RESTHELPER.checkIfDefined(reason, None, 'REASON', template, 'Reason')
            template = RESTHELPER.checkIfDefined(info, None, 'INFO', template, 'Info')

            cancelTemplate += template
    else:
        idArray = ''
        if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
            idArray = resourceId
        else:
            for id in resourceId:
                idArray += '<value>' + str(id) + '</value>'

    profTemplate = RESTHELPER.checkIfDefined(cancelTemplate, '', 'CANCELDATAARRAY', profTemplate, 'CancelDataArray')
    profTemplate = RESTHELPER.checkIfDefined(idArray, '', 'RESOURCEIDARRAY', profTemplate, 'ResourceIdArray')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(eligibilityCheck, None, 'ELIGIBILITYCHECK', profTemplate, 'EligibilityCheck')
 
    url = '/'+RESTV3.urlPrefix+'/device/' + str(queryValue) + '/offers'
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if cancelInfo :
        return (validateResponse(response=response, method=funcName, shouldPass=eventPass), response)
    else:
        return validateResponse(response=response, method=funcName, shouldPass=eventPass)
#=============================================================
def queryDevice(V3inst, queryValue, queryType='PhoneNumber', eventPass=True, now=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType == 'ObjectId':         url = '/'+RESTV3.urlPrefix+'/device/'
    elif queryType == 'ExternalId':
        queryValue = URL.quote(queryValue,'')
        url = '/'+RESTV3.urlPrefix+'/device/query/ExternalId/'
    elif queryType == 'PhoneNumber':    url = '/'+RESTV3.urlPrefix+'/device/query/PhoneNumber/'
    elif queryType == 'Imsi':           url = '/'+RESTV3.urlPrefix+'/device/query/PhoneNumber/'
    elif queryType == 'AccessNumber':   url = '/'+RESTV3.urlPrefix+'/device/query/AccessNumber/'
    elif queryType == 'LoginId':        url = '/'+RESTV3.urlPrefix+'/device/query/LoginId/'
    elif queryType == 'AccessId':       url = '/'+RESTV3.urlPrefix+'/device/query/AccessId/'
    else:  sys.exit('ERROR: queryDevice parameter queryType has an unsupported value (' + queryType + ')')

    # Add ID
    url += str(queryValue)
    
    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        
    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def deviceRating(V3inst, queryValue, queryType="Imsi", requestType='start', service=None, amount=None, sessionId=None, serviceContextId=None, calledStationId=None, QaUliMccMnc=None, eventPass=True, attr=None, eventTime=None, objectIdConversion=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    # If attributes passed in, then extract those.
    if attr:
        # Set to local variables
        for parameter in attr:
                cmd = parameter + ' = attr["' + parameter + '"]'
                exec(cmd)
    
    # Make sure to get OID
    if objectIdConversion and queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType)
        queryValue = getOID(queryResponse)
    
    # Get template file
    try:
        # Use value if passed in
        profTemplate = open(templates + templateFile).read()
    except:
        # Use default
        profTemplate = open(templates + 'usage_simple'+RESTV3.fileType).read()
    
    # Check hard-coded parameters
    profTemplate = RESTHELPER.checkIfDefined(calledStationId, None, 'CALLEDSTATIONID', profTemplate, 'CalledStationId')
    profTemplate = RESTHELPER.checkIfDefined(QaUliMccMnc, None, 'QAULIMCCMNC', profTemplate, 'QaUliMccMnc')
    profTemplate = RESTHELPER.checkIfDefined(eventTime, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(service, None, 'SERVICE', profTemplate, 'Service')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(sessionId, None, 'SESSIONID', profTemplate, 'SessionId')
    profTemplate = RESTHELPER.checkIfDefined(serviceContextId, None, 'serviceCONTEXTID', profTemplate, 'ServiceContextId')


    # The following differed in restV3.py and rest_json.py
    # At the moment just treat rest xml and json differently
    # Try and combine them later!

    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        # Check attributes
        if attr:
            # HACK alert: "OP" is a parameter but also conflicts with prefix names (e.g. OPL).
            # Need to do this first parameter first.
            parameter = 'op'
            if parameter in attr:
                # Assume template key to search for is the capitalized name of the parameter
                cmd = "profTemplate = RESTHELPER.checkIfDefined(" + parameter + ", None, '" + parameter.upper() + "', profTemplate, '" + parameter + "')"
                exec(cmd)

                # Remove this from the list
                del attr[parameter]

            # Process each one
            for parameter in attr:
                    # Special code for adding custom parameters
                if parameter in ['DiamRoParams', 'MsccParams']:
                            # Define template insertion point string
                    if parameter == 'DiamRoParams': templateInsertionPoint = 'DIAMPARAMS'
                    else:                           templateInsertionPoint = 'CUSTMSCCPARAMS'

                        # Proces each item in this array
                    for item in attr[parameter]:
                        # Store values (readability)
                        name = item
                        value = str(attr[parameter][item])

                        # Add to template
                        profTemplate = re.sub(templateInsertionPoint, templateInsertionPoint + '\n        "' + name + '": "' + value + '",', profTemplate)

                    # Remove insertion line
                    profTemplate = RESTHELPER.checkIfDefined(None, None, templateInsertionPoint, profTemplate, None)
                else:
                    # Assume template key to search for is the capitalized name of the parameter
                    cmd = "profTemplate = RESTHELPER.checkIfDefined(" + parameter + ", None, '" + parameter.upper() + "', profTemplate, '" + parameter + "')"
                    exec(cmd)

        # URL may have been passed in in attr structure.  Not sure best way to check if local variable set, so use try/except.
        try:
            kef = url
        except:
            additionalUrl = ''
            if not objectIdConversion and queryType != 'ObjectId':
                additionalUrl += str(queryType) + '+'
            url = '/json/service/device/' + additionalUrl + str(queryValue) + '/rating/' + str(requestType)
    else:
       # Check attributes.
        if attr:
            # Process each one
            for parameter in attr:
                # Special code for adding DiamRoMsg parameters
                if parameter == 'DiamRoMsg':
                    # Proces each item in this array
                    for item in attr[parameter]:
                        # Split item into components
                        (name,value) = item
    
                        # Add to template
                        profTemplate = re.sub('DIAMROPARAMS', 'DIAMROPARAMS\n"' + name + '": "' + str(value) + '",', profTemplate)
    
                    # Remove template line
                    profTemplate = RESTHELPER.checkIfDefined(None, None, 'DIAMROPARAMS', profTemplate, 'DIAMROPARAMS')
                else:
                    # Assume template key to search for is the capitalized name of the parameter
                    cmd = "profTemplate = RESTHELPER.checkIfDefined(" + parameter + ", None, '" + parameter.upper() + "', profTemplate, '" + parameter + "')"
                    exec(cmd)

        additionalUrl = ''
        if not objectIdConversion and queryType != 'ObjectId':
            additionalUrl += str(queryType) + '+' 
        url = '/'+RESTV3.urlPrefix+'/service/device/' + additionalUrl + str(queryValue) + '/rating/' + str(requestType)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def deviceRatingCompleteFormat(V3inst, queryValue, queryType="Imsi", requestType='start', service=None, amount=None, sessionId=None, serviceContextId=None, QaUliMccMnc=None, eventPass=True, objectIdConversion=True, multiRequestBuild=None, now=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    # Make sure to get OID
    if objectIdConversion and queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType)
        queryValue = getOID(queryResponse)


    profTemplate = open(templates + 'usage'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(service, None, 'SERVICE', profTemplate, 'Service')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(sessionId, None, 'SESSIONID', profTemplate, 'SessionId')
    profTemplate = RESTHELPER.checkIfDefined(serviceContextId, None, 'serviceCONTEXTID', profTemplate, 'ServiceContextId')

    additionalUrl = ''
    if not objectIdConversion and queryType != 'ObjectId':
        additionalUrl += str(queryType) + '+'
    url = '/'+RESTV3.urlPrefix+'/service/device/' + additionalUrl + str(queryValue) + '/rating/' + str(requestType)
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def simulateUsage(V3inst, queryValue, queryType="Imsi", serviceType=None, quantity=None, timestamp=None, callee=None, networkId=None, sourceHost=None, sourceRealm=None, destHost=None, destRealm=None, objectIdConversion = True, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    # Make sure to get OID
    if objectIdConversion and queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType)
        queryValue = getOID(queryResponse)


    profTemplate = open(templates + 'simulate'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(timestamp, None, 'TIMESTAMP', profTemplate, 'Timestamp')
    profTemplate = RESTHELPER.checkIfDefined(quantity, None, 'QUANTITY', profTemplate, 'Quantity')
    profTemplate = RESTHELPER.checkIfDefined(serviceType, None, 'SERVICETYPE', profTemplate, 'ServiceType')
    profTemplate = RESTHELPER.checkIfDefined(callee, None, 'CALLEE', profTemplate, 'Callee')
    profTemplate = RESTHELPER.checkIfDefined(networkId, None, 'NETWORKID', profTemplate, 'NetworkId')
    profTemplate = RESTHELPER.checkIfDefined(sourceHost, None, 'SOURCEHOST', profTemplate, 'SourceHost')
    profTemplate = RESTHELPER.checkIfDefined(sourceRealm, None, 'SOURCEREALM', profTemplate, 'SourceRealm')
    profTemplate = RESTHELPER.checkIfDefined(destHost, None, 'DESTHOST', profTemplate, 'DestHost')
    profTemplate = RESTHELPER.checkIfDefined(destRealm, None, 'DESTREALM', profTemplate, 'DestRealm')

    additionalUrl = ''
    if not objectIdConversion and queryType != 'ObjectId':
        additionalUrl += str(queryType) + '+'
    url = '/'+RESTV3.urlPrefix+'/service/device/' + additionalUrl + str(queryValue) + '/rating/simulate'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def createGroup(V3inst, groupId=None, name=None, tier=None, administrator_id=0, eventPass=True, attr=None, now=None, status=None,
        billingCycle=None, queryType='ExternalId', taxStatus=None, taxCertificate=None, taxLocation=None,
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        timeZone=None, notificationPreference=None, dateOffset=None, groupReAuthPreference=None, glCenter=None, apiEventData=None,
        routingType=None, routingValue=None, executeMode=None, multiRequestBuild=None, apiEventSecurityInfo=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    adminStr = createAdminArrayStr(V3inst, administrator_id, queryType, now=now)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    exemptionCodeListStr = None
    if  exemptionCodeList is not None:
        exemptionCodeListStr = createExemptionCodeList(exemptionCodeList)

    #check if we passed a string for billingCycle and convert it to a billing cycle template
    if billingCycle and type(billingCycle) is int:
        billingCycle = createBillingCycleData(int(billingCycle), startTime=now, dateOffset=dateOffset)
   
    apiEventSecurityInfoStr = None
    if apiEventSecurityInfo is not None:
        apiEventSecurityInfoStr = parseAttrMdc(apiEventSecurityInfo)
 
    url = '/'+RESTV3.urlPrefix+'/group'
    
    attrStr = None
    if attr is not None:
        attrStr = parseAttrMdc(attr)
    profTemplate = open(templates + 'group_create'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(groupId, None, 'EXTERNALID', profTemplate, 'ExternalId')
    profTemplate = RESTHELPER.checkIfDefined(name, None, 'NAME', profTemplate, 'Name')
    profTemplate = RESTHELPER.checkIfDefined(tier, None, 'TIER', profTemplate, 'Tier')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    profTemplate = RESTHELPER.checkIfDefined(billingCycle, None, 'BILLINGCYCLE', profTemplate, 'BillingCycle')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(adminStr, '', 'ADMINIDS', profTemplate, 'AdminArray')
    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        profTemplate = RESTHELPER.checkIfDefined(taxStatus, None, 'TAXsTATUS', profTemplate, 'TaxStatus')
    else: profTemplate = RESTHELPER.checkIfDefined(taxStatus, None, 'TAXSTATUS', profTemplate, 'TaxStatus')
    profTemplate = RESTHELPER.checkIfDefined(taxCertificate, None, 'TAXCERTIFICATE', profTemplate, 'TaxCertificate')
    profTemplate = RESTHELPER.checkIfDefined(taxLocation, None, 'TAXLOCATION', profTemplate, 'TaxLocation')
    profTemplate = RESTHELPER.checkIfDefined(glCenter, None, 'GLCENTER', profTemplate, 'GlCenter')
    profTemplate = RESTHELPER.checkIfDefined(timeZone, None, 'TIMEZONE', profTemplate, 'TimeZone')
    profTemplate = RESTHELPER.checkIfDefined(notificationPreference, None, 'NOTIFPREFERENCE', profTemplate, 'NotificationPreference')
    profTemplate = RESTHELPER.checkIfDefined(groupReAuthPreference, None, 'GROUPREAUTHPREFERENCE', profTemplate, 'GroupReAuthPreference')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(customerType, None, 'CUSTOMERTYPE', profTemplate, 'CustomerType')
    profTemplate = RESTHELPER.checkIfDefined(serviceAddress, None, 'SERVICEADDRESS', profTemplate, 'ServiceAddress')
    profTemplate = RESTHELPER.checkIfDefined(npa, None, 'NPA', profTemplate, 'Npa')
    profTemplate = RESTHELPER.checkIfDefined(nxx, None, 'NXX', profTemplate, 'Nxx')
    profTemplate = RESTHELPER.checkIfDefined(tenantId, None, 'TENANTID', profTemplate, 'TenantId')
    profTemplate = RESTHELPER.checkIfDefined(exemptionCodeListStr, None, 'EXEMPTIONCODELIST', profTemplate, 'ExemptionCodeList')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventSecurityInfoStr, None, 'APIEVENTSECURITYINFO', profTemplate, 'ApiEventSecurityInfo')
#    print 'Create group:  payload = ' + str(profTemplate)
        
    # Add to URL if needed
    if routingType and routingValue: url += '?TrafficRouteData='+routingType+str(routingValue)
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='ObjectId')

#===#============================================================e==========================================================
def addGroupAdmins(V3inst, groupId=None, groupQueryType='ObjectId', admins=None, adminQueryType='ExternalId',
        apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    adminStr = createAdminArrayStr(V3inst, admins, adminQueryType, now=now)
    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    if groupQueryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=groupId, queryType=groupQueryType)
        groupId = getOID(queryResponse)
    if adminStr != '':
        adminTemplate = open(templates + 'group_add_admins'+RESTV3.fileType).read()
        if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
            adminTemplate = RESTHELPER.checkIfDefined(adminStr, '', 'ADMINIDS', profTemplate, 'AdminArray')
        else:
            adminTemplate = RESTHELPER.checkIfDefined(adminStr, '', 'OBJECTID', adminTemplate, 'ObjectId')
        profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
        adminTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', adminTemplate, 'EventTime')
        adminTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
        
        url = '/'+RESTV3.urlPrefix+'/group' + str(groupId) + '/add_members/'
    
        # Debug output if globally set
        if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + adminTemplate)
        
        response = V3inst.put(url, payload=adminTemplate)
        if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
        if not validateResponse(response=response, method=funcName, shouldPass=eventPass):
            return (not eventPass)
    return eventPass

#=============================================================
def modifyGroup(V3inst, groupId, name=None, tier=None, administrator_id=0, billingCycle=None, attr=None,
        subQueryType='ExternalId', groupQueryType='ExternalId', now=None, status=None, eventPass=True, notificationPreference = None,
        taxStatus=None, taxCertificate=None, taxLocation=None, externalId=None, timeZone=None, groupReAuthPreference=None,
        dateOffset = None, glCenter=None, paymentGatewayUserId=None, currentPaymentTokenResourceId=None,
        apiEventData=None, lastActivityUpdateTime=None, executeMode=None, billingCycleDisabled=None, multiRequestBuild=None,
        customerType=None, serviceAddress=None, npa=None, nxx=None, tenantId=None, exemptionCodeList=None,
        maxUserCount=None, maxSubscriberCount=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    admin_groupId = groupId
    # Get group OID if queryType is not ObjectId
    if groupQueryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=groupId, queryType=groupQueryType, now=now)
        groupId = getOID(queryResponse)

    if administrator_id != 0:
        if not addAdminToGroup(V3inst, admin_groupId, administrator_id, subQueryType=subQueryType, groupQueryType=groupQueryType, now=now,
                               apiEventData=apiEventData):
            return False

    if billingCycleDisabled:
        billingCycleDisabled='true'
    elif billingCycleDisabled == False:
        billingCycleDisabled='false'

    attrStr = None
    if attr is not None:
        attrStr = parseAttrMdc(attr) 

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    exemptionCodeListStr = None
    if  exemptionCodeList is not None:
        exemptionCodeListStr = createExemptionCodeList(exemptionCodeList)

    profTemplate = open(templates + 'group_modify'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(externalId, None, 'EXTERNALID', profTemplate, 'ExternalId')
    profTemplate = RESTHELPER.checkIfDefined(name, None, 'NAME', profTemplate, 'Name')
    profTemplate = RESTHELPER.checkIfDefined(tier, None, 'TIER', profTemplate, 'Tier')
    profTemplate = RESTHELPER.checkIfDefined(status, None, 'STATUS', profTemplate, 'Status')
    profTemplate = RESTHELPER.checkIfDefined(billingCycle, None, 'BILLINGCYCLE', profTemplate, 'BillingCycle')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        profTemplate = RESTHELPER.checkIfDefined(taxStatus, None, 'TAXsTATUS', profTemplate, 'TaxStatus')
    else: profTemplate = RESTHELPER.checkIfDefined(taxStatus, None, 'TAXSTATUS', profTemplate, 'TaxStatus')
    profTemplate = RESTHELPER.checkIfDefined(taxCertificate, None, 'TAXCERTIFICATE', profTemplate, 'TaxCertificate')
    profTemplate = RESTHELPER.checkIfDefined(taxLocation, None, 'TAXLOCATION', profTemplate, 'TaxLocation')
    profTemplate = RESTHELPER.checkIfDefined(glCenter, None, 'GLCENTER', profTemplate, 'GlCenter')
    profTemplate = RESTHELPER.checkIfDefined(timeZone, None, 'TIMEZONE', profTemplate, 'TimeZone')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(notificationPreference, None, 'NOTIFPREFERENCE', profTemplate, 'NotificationPreference')
    profTemplate = RESTHELPER.checkIfDefined(groupReAuthPreference, None, 'GROUPREAUTHPREFERENCE', profTemplate, 'GroupReAuthPreference')
    profTemplate = RESTHELPER.checkIfDefined(paymentGatewayUserId, None, 'PAYMENTGATEWAYUSERID', profTemplate, 'PaymentGatewayUserId')
    profTemplate = RESTHELPER.checkIfDefined(currentPaymentTokenResourceId, None, 'CURRENTPAYMENTTOKENRECOURCEID',
        profTemplate, 'CurrentPaymentTokenResourceId')
    profTemplate = RESTHELPER.checkIfDefined(lastActivityUpdateTime, None, 'LASTACTIVITYUPDATETIME',
        profTemplate, 'LastActivityUpdateTime')
    profTemplate = RESTHELPER.checkIfDefined(maxSubscriberCount, None, 'MAXSUBSCRIBERCOUNT', profTemplate, 'MaxSubscriberCount')
    profTemplate = RESTHELPER.checkIfDefined(maxUserCount, None, 'MAXUSERCOUNT', profTemplate, 'MaxUserCount')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(customerType, None, 'CUSTOMERTYPE', profTemplate, 'CustomerType')
    profTemplate = RESTHELPER.checkIfDefined(serviceAddress, None, 'SERVICEADDRESS', profTemplate, 'ServiceAddress')
    profTemplate = RESTHELPER.checkIfDefined(npa, None, 'NPA', profTemplate, 'Npa')
    profTemplate = RESTHELPER.checkIfDefined(nxx, None, 'NXX', profTemplate, 'Nxx')
    profTemplate = RESTHELPER.checkIfDefined(tenantId, None, 'TENANTID', profTemplate, 'TenantId')
    profTemplate = RESTHELPER.checkIfDefined(exemptionCodeListStr, None, 'EXEMPTIONCODELIST', profTemplate, 'ExemptionCodeList')
    profTemplate = RESTHELPER.checkIfDefined(billingCycleDisabled, None, 'billingCYCLEDISABLED', profTemplate, 'BillingCycleDisabled')

    url = '/'+RESTV3.urlPrefix+'/group/' + str(groupId)
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

# Rehome a group (Requires a multi sub-domain engine configuration)
#=============================================================
def groupRehome(V3inst, queryValue, queryType='ObjectId', routingType='RouteId', routingValue=2, eventPass=True,
    apiEventData=None, multiRequestBuild=None):
    global restVersion

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/rehome/' + str(routingType) + '+' + str(routingValue)
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip(): 
                url += '?ApiEventData=' +apiEventDataStr
                amp = True

    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.put(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    #print response
    if validateResponse(response=response, method='groupRehome', shouldPass=eventPass):
        return response

#=============================================================
def groupSubscribeToOffer(V3inst, groupId, offerId=None, catalogItemId=None, offerStartTime=None,
        offerEndTime=None, eventPass=True, queryType='ExternalId', now=None, offerIsExternal=False,
        attr=None, dupAttr=True, chargeMethod=None, paymentMethodResourceId=None, paymentGatewayId=None,
        chargeMethodAttr=None, paymentGatewayOneTimeToken=None, future=False, purchaseInfo=False, executeMode=None,
        paymentGatewayUserId=None, paymentDueDate=None, etcScheduleRangeArray=None, etcScheduleRangeUnit=None, paymentScheduleRangeArray=None,
        paymentScheduleAmountArray=None, paymentScheduleLastAmount=None, delayCharge=None, deferredSettlement=None, deferredSettlementTimeout=None, deferredSettlementTimeoutAction=None,
        offerCycleType=None, offerCycleResourceId=None, offerCycleOffset=None, preActiveState=None, offerCycleStartTime=None,
        autoActivationTime=None, autoActivationRelativeOffsetUnit=None, autoActivationRelativeOffset=None, autoActivationCycleResourceId=None,
        activationExpirationTime=None, activationExpirationRelativeOffsetUnit=None, activationExpirationRelativeOffset=None, 
        endTimeRelativeOffsetUnit=None, endTimeRelativeOffset=None, downPayment=None, isRecurringFailureAllowed=None, apiEventData=None,
        chargePurchaseProrationType=None, grantPurchaseProrationType=None, reason=None, info=None, parameterList=None,
        contractPeriod=None, contractInterval=None, commitmentPeriod=None, commitmentPeriodInterval=None, isOpenContract=None,
        isPendingActivationAllowed=None, offerLifecycleProfileId=None,
        routingType=None, routingValue=None, offerStatusValue=None, multiRequestBuild=None, eligibilityCheck=True, geoData=None, endAfterCycleCount=None, noEndTime=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if now is None:
        now = offerStartTime

    # Get group OID if queryType is not ObjectId
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=groupId, queryType=queryType, now=now)
        groupId = getOID(queryResponse)
    # Process any input attributes
    attrStr = None
    if attr is not None:
        attrStr = parseAttrMdc(attr)
    chargeMethodAttrStr = None
    if chargeMethodAttr is not None:
        chargeMethodAttrStr = parseAttrMdc(chargeMethodAttr)
    if deferredSettlement:
        deferredSettlement='true'
    if isRecurringFailureAllowed:
        isRecurringFailureAllowed = 'true'
    elif isRecurringFailureAllowed == False:
        isRecurringFailureAllowed = 'false'
    if isPendingActivationAllowed:
        isPendingActivationAllowed = 'true'
    elif isPendingActivationAllowed == False:
        isPendingActivationAllowed = 'false'
    
    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    if geoData is None:
       geoData = ""

    parameterArray = None
    if parameterList:
        parameterArray = parseParameterList(parameterList)

    # Allow for custom URLs (for BGAPI code)
    if CSV.overrideURL and 'purchase' in CSV.overrideOperations: custom = '/' + CSV.overrideURL
    else: custom = ''
    url = '/' + RESTV3.urlPrefix + custom + '/group/' + str(groupId) + '/offers'
    
    # populate contractParameterOverrideDataTemplate, which only support single one at moment
    contractParameterOverrideDataTemplate = createContractParameterOverrideData(etcScheduleRangeArray=etcScheduleRangeArray, etcScheduleRangeUnit=etcScheduleRangeUnit, paymentScheduleRangeArray=paymentScheduleRangeArray, paymentScheduleAmountArray=paymentScheduleAmountArray, paymentScheduleLastAmount=paymentScheduleLastAmount, delayCharge=delayCharge, contractPeriod=contractPeriod, contractInterval=contractInterval, commitmentPeriod=commitmentPeriod, commitmentPeriodInterval=commitmentPeriodInterval, isOpenContract=isOpenContract)

    # Input may be a list or may be a single item
    if type(catalogItemId) is list:
        offerId = catalogItemId
    if type(offerId) is list:
        offerDataList = ""
        profTemplate = open(templates + 'group_purchase_offerList'+RESTV3.fileType).read()
        createResourceIds = []

        for offer in offerId:
            # Purchase offer and validate for each, append created resource id to list
            #profTemplate = open(templates + 'group_purchase_offer'+RESTV3.fileType).read()
            dataTemplate = open(templates + 'purchased_offer_data'+RESTV3.fileType).read()
            dataTemplate = RESTHELPER.removeItem(dataTemplate, 'UseTargetResource')
            dataTemplate = RESTHELPER.removeItem(dataTemplate, 'IsTargetResource')

            # populate paymentDueDate
            if type(paymentDueDate) is list:
                i = offerId.index(offer)
                dataTemplate = RESTHELPER.checkIfDefined(paymentDueDate[i], None, 'PAYMENTDUEDATE', dataTemplate, 'PaymentDueDate')
            else:
                dataTemplate = RESTHELPER.checkIfDefined(paymentDueDate, None, 'PAYMENTDUEDATE', dataTemplate, 'PaymentDueDate')

            # populate contractParameterOverride
            if contractParameterOverrideDataTemplate:
                dataTemplate = RESTHELPER.checkIfDefined(contractParameterOverrideDataTemplate, None, 'CONTRACTPARAMETEROVERRIDEDATA', dataTemplate, 'ONEWORDLINE')
            else:
                dataTemplate = RESTHELPER.removeOneWordLine(dataTemplate, 'CONTRACTPARAMETEROVERRIDEDATA')


            # Conditionally select product offer by ExternalId or ProductOfferId
            if offerIsExternal:
                dataTemplate = RESTHELPER.removeItem(dataTemplate, 'ProductOfferId')
                dataTemplate = RESTHELPER.removeItem(dataTemplate, 'CatalogItemId')
                dataTemplate = RESTHELPER.checkIfDefined(offer, None, 'OFFEREXTID', dataTemplate, 'ExternalId')
            else:
                dataTemplate = RESTHELPER.removeItem(dataTemplate, 'ExternalId')
                if catalogItemId:
                    dataTemplate = RESTHELPER.checkIfDefined(offer, None, 'CATALOGITEMID', dataTemplate, 'CatalogItemId')
                    dataTemplate = RESTHELPER.removeItem(dataTemplate, 'ProductOfferId')
                else:
                    dataTemplate = RESTHELPER.checkIfDefined(offer, None, 'OFFERID', dataTemplate, 'ProductOfferId')
                    dataTemplate = RESTHELPER.removeItem(dataTemplate, 'CatalogItemId')

            #Remove isTargetResource and useTargetResource since they are not in the API request yet
            dataTemplate = RESTHELPER.removeItem(dataTemplate, 'IsTargetResource')
            dataTemplate = RESTHELPER.removeItem(dataTemplate, 'UseTargetResource')
            
            dataTemplate = RESTHELPER.checkIfDefined(offerStartTime, None, 'STARTTIME', dataTemplate, 'StartTime')
            
            #Remove isTargetResource and useTargetResource since they are not in the API request yet
            dataTemplate = RESTHELPER.removeItem(dataTemplate, 'IsTargetResource')
            dataTemplate = RESTHELPER.removeItem(dataTemplate, 'UseTargetResource')

            if offerCycleType or offerCycleResourceId or offerCycleOffset or offerCycleStartTime:
                cycleTemplate = createCycleData(cycleType=offerCycleType, cycleResourceId=offerCycleResourceId, cycleOffset=offerCycleOffset,
                                                cycleStartTime=offerCycleStartTime)
            else: cycleTemplate = None
            dataTemplate = RESTHELPER.checkIfDefined(cycleTemplate, None, 'CYCLEDATA', dataTemplate, 'ONEWORDLINE')
            # Process cycle data
            dataTemplate = RESTHELPER.checkIfDefined(offerCycleType, None, 'OFFERCYCLETYPE', dataTemplate, 'CycleType')
            dataTemplate = RESTHELPER.checkIfDefined(offerCycleResourceId, None, 'OFFERCYCLERESOURCEID', dataTemplate, 'CycleResourceId')
            dataTemplate = RESTHELPER.checkIfDefined(offerCycleOffset, None, 'OFFERCYCLEOFFSET', dataTemplate, 'CycleOffset')
            dataTemplate = RESTHELPER.checkIfDefined(offerCycleStartTime, None, 'OFFERCYCLEsTARTTIME', dataTemplate, 'CycleStartTime')
            
            # Support backwards compatibility for down payment
            if downPayment:
                downPaymentData = open(templates + 'downPayment_data'+RESTV3.fileType).read()
                downPaymentData = RESTHELPER.checkIfDefined(downPayment, None, 'DOWNPAYMENT', downPaymentData, 'DownPayment')
            else: downPaymentData = None
            dataTemplate = RESTHELPER.checkIfDefined(downPaymentData, None, 'DOWNPAYMENT', dataTemplate, 'ONEWORDLINE')
            dataTemplate = RESTHELPER.checkIfDefined(isRecurringFailureAllowed, None, 'ISRECURRINGFAILUREALLOWED', dataTemplate, 'IsRecurringFailureAllowed')
            dataTemplate = RESTHELPER.checkIfDefined(endAfterCycleCount, None, 'ENDAFTERCYCLECOUNT', dataTemplate, 'EndAfterCycleCount')
            dataTemplate = RESTHELPER.checkIfDefined(noEndTime, None, 'NOENDTIME', dataTemplate, 'NoEndTime')
            dataTemplate = RESTHELPER.checkIfDefined(offerEndTime, None, 'ENDTIME', dataTemplate, 'EndTime')
            if chargeMethod or paymentMethodResourceId or paymentGatewayId or paymentGatewayOneTimeToken or chargeMethodAttr:
                chargeMethodData = createChargeMethodData(chargeMethod=chargeMethod, paymentMethodResourceId=paymentMethodResourceId,
                                                      paymentGatewayId=paymentGatewayId, paymentGatewayUserId=paymentGatewayUserId,
                                                      paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, chargeMethodAttr=chargeMethodAttrStr,
                                                      deferredSettlement=deferredSettlement, deferredSettlementTimeout=deferredSettlementTimeout,
                                                      deferredSettlementTimeoutAction=deferredSettlementTimeoutAction)
            else:
                chargeMethodData = None
            dataTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', dataTemplate, 'Attr')
            dataTemplate = RESTHELPER.checkIfDefined(parameterArray, None, 'PARAMETERARRAY', dataTemplate, 'ParameterArray')
            dataTemplate = RESTHELPER.checkIfDefined(preActiveState, None, 'PREACTIVESTATE', dataTemplate, 'PreActiveState')
            dataTemplate = RESTHELPER.checkIfDefined(offerStatusValue, None, 'OFFERSTATUSVALUE', dataTemplate, 'OfferStatusValue')
            dataTemplate = RESTHELPER.checkIfDefined(offerLifecycleProfileId, None, 'OFFERLIFECYCLEPROFILEID', dataTemplate, 'OfferLifecycleProfileId')
            dataTemplate = RESTHELPER.checkIfDefined(autoActivationTime, None, 'AUTOACTIVATIONTIME', dataTemplate, 'AutoActivationTime')
            dataTemplate = RESTHELPER.checkIfDefined(autoActivationRelativeOffsetUnit, None, 'AUTOACTIVATIONRELATIVEOFFSETUNIT', dataTemplate, 'AutoActivationRelativeOffsetUnit')
            dataTemplate = RESTHELPER.checkIfDefined(autoActivationRelativeOffset, None, 'aUTOACTIVATIONRELATIVEOFFSET', dataTemplate, 'AutoActivationRelativeOffset')
            dataTemplate = RESTHELPER.checkIfDefined(autoActivationCycleResourceId, None, 'AUTOACTIVATIONCYCLERESOURCEID', dataTemplate, 'AutoActivationCycleResourceId')
            dataTemplate = RESTHELPER.checkIfDefined(activationExpirationTime, None, 'ACTIVATIONEXPIRATIONTIME', dataTemplate,
                'ActivationExpirationTime')
            dataTemplate = RESTHELPER.checkIfDefined(activationExpirationRelativeOffsetUnit, None, 'ACTIVATIONEXPIRATIONRELATIVEOFFSETUNIT',
                dataTemplate, 'ActivationExpirationRelativeOffsetUnit')
            dataTemplate = RESTHELPER.checkIfDefined(activationExpirationRelativeOffset, None, 'ACTIVATIONEXPIRATIONRELATIVEOFFSET',
                dataTemplate, 'ActivationExpirationRelativeOffset')
            dataTemplate = RESTHELPER.checkIfDefined(isPendingActivationAllowed, None, 'ISPENDINGACTIVATIONALLOWED', dataTemplate, 'IsPendingActivationAllowed')
            dataTemplate = RESTHELPER.checkIfDefined(endTimeRelativeOffsetUnit, None, 'ENDTIMERELATIVEOFFSETUNIT', dataTemplate, 'EndTimeRelativeOffsetUnit')
            dataTemplate = RESTHELPER.checkIfDefined(endTimeRelativeOffset, None, 'ENDTIMERELATIVEOFFSET', dataTemplate, 'EndTimeRelativeOffset')
            dataTemplate = RESTHELPER.checkIfDefined(chargePurchaseProrationType, None, 'CHARGEPURCHASEPRORATIONTYPE', dataTemplate, 'ChargePurchaseProrationType')     
            dataTemplate = RESTHELPER.checkIfDefined(grantPurchaseProrationType, None, 'GRANTPURCHASEPRORATIONTYPE', dataTemplate, 'GrantPurchaseProrationType')
            dataTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', dataTemplate, 'Reason')
            dataTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', dataTemplate, 'Info')

            offerDataList = offerDataList + dataTemplate

        # fields out of offerRequestArray
        profTemplate = RESTHELPER.checkIfDefined(offerDataList, None, 'OFFERDATALIST',profTemplate, 'OFFERDATALIST')
        profTemplate = RESTHELPER.checkIfDefined(groupId, None, 'GROUPID', profTemplate, 'ObjectId')
        profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
        profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
        profTemplate = RESTHELPER.checkIfDefined(eligibilityCheck, None, 'ELIGIBILITYCHECK', profTemplate, 'EligibilityCheck')
        profTemplate = RESTHELPER.checkIfDefined(geoData, None, 'GEODATA', profTemplate, 'GeoData')

        if future: profTemplate = RESTHELPER.removeItem(profTemplate, 'EventTime')
        else:      profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
        profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')

        # If future, then don't send via this API
        if future:
            # Return from here, as we're scheuling future purchases as a task
            #print 'profTemplate from future: ' + profTemplate
            return profTemplate
            
        if routingType and routingValue :
            url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

        # Debug output if globally set
        if QAUTILS.DebugLevel > 0:
            print(funcName + ' url: ' + url)
            print(funcName + ' payload:\n' + profTemplate)
        
        # Send in the message
        response = V3inst.put(url, payload=profTemplate)
        if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
        (success, resourceId) = validateResponse(response=response, method='groupSubscribeToOffer',
                shouldPass=eventPass, returnParam='ResourceId')
        createResourceIds = resourceId
     
        if purchaseInfo:
           return (passed(eventPass), response)
        else: 
           return (passed(eventPass), createResourceIds)
    else:
        # Purchase offer and validate, return created resourceId
        profTemplate = open(templates + 'group_purchase_offer'+RESTV3.fileType).read()

        # Conditionally select product offer by ExternalId or ProductOfferId
        if offerIsExternal:
            profTemplate = RESTHELPER.removeItem(profTemplate, 'ProductOfferId')
            profTemplate = RESTHELPER.removeItem(profTemplate, 'CatalogItemId')
            if catalogItemId:
                profTemplate = RESTHELPER.checkIfDefined(catalogItemId, None, 'OFFERID', profTemplate, 'ExternalId')
            else:
                profTemplate = RESTHELPER.checkIfDefined(offerId, None, 'OFFERID', profTemplate, 'ExternalId')
        else:
            profTemplate = RESTHELPER.removeItem(profTemplate, 'ExternalId')
            profTemplate = RESTHELPER.checkIfDefined(offerId, None, 'OFFERID', profTemplate, 'ProductOfferId')
            profTemplate = RESTHELPER.checkIfDefined(catalogItemId, None, 'CATALOGITEMID', profTemplate, 'CatalogItemId')

        profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
        profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
        profTemplate = RESTHELPER.checkIfDefined(eligibilityCheck, None, 'ELIGIBILITYCHECK', profTemplate, 'EligibilityCheck')
        profTemplate = RESTHELPER.checkIfDefined(offerStartTime, None, 'STARTTIME', profTemplate, 'StartTime')
        profTemplate = RESTHELPER.checkIfDefined(offerStatusValue, None, 'OFFERSTATUSVALUE', profTemplate, 'OfferStatusValue')
        profTemplate = RESTHELPER.checkIfDefined(offerLifecycleProfileId, None, 'OFFERLIFECYCLEPROFILEID', profTemplate, 'OfferLifecycleProfileId')
        profTemplate = RESTHELPER.checkIfDefined(paymentDueDate, None, 'PAYMENTDUEDATE', profTemplate, 'PaymentDueDate')

        # populate contractParameterOverride
        if contractParameterOverrideDataTemplate:
            profTemplate = RESTHELPER.checkIfDefined(contractParameterOverrideDataTemplate, None, 'CONTRACTPARAMETEROVERRIDEDATA', profTemplate, 'ONEWORDLINE')
        else:
            profTemplate = RESTHELPER.removeOneWordLine(profTemplate, 'CONTRACTPARAMETEROVERRIDEDATA')
           
        # Support backwards compatibility for down payment
        if downPayment:
                downPaymentData = open(templates + 'downPayment_data'+RESTV3.fileType).read()
                downPaymentData = RESTHELPER.checkIfDefined(downPayment, None, 'DOWNPAYMENT', downPaymentData, 'DownPayment')
        else: downPaymentData = None
        profTemplate = RESTHELPER.checkIfDefined(downPaymentData, None, 'DOWNPAYMENT', profTemplate, 'ONEWORDLINE')
        profTemplate = RESTHELPER.checkIfDefined(isRecurringFailureAllowed, None, 'ISRECURRINGFAILUREALLOWED', profTemplate, 'IsRecurringFailureAllowed')
        profTemplate = RESTHELPER.checkIfDefined(endAfterCycleCount, None, 'ENDAFTERCYCLECOUNT', profTemplate, 'EndAfterCycleCount')
        profTemplate = RESTHELPER.checkIfDefined(noEndTime, None, 'NOENDTIME', profTemplate, 'NoEndTime')
 
        if offerCycleType or offerCycleResourceId or offerCycleOffset or offerCycleStartTime:
            cycleTemplate = createCycleData(cycleType=offerCycleType, cycleResourceId=offerCycleResourceId, cycleOffset=offerCycleOffset,
                                            cycleStartTime=offerCycleStartTime)
        else: cycleTemplate = None
        profTemplate = RESTHELPER.checkIfDefined(cycleTemplate, None, 'CYCLEDATA', profTemplate, 'ONEWORDLINE')
        profTemplate = RESTHELPER.checkIfDefined(offerEndTime, None, 'ENDTIME', profTemplate, 'EndTime')
        if chargeMethod or paymentMethodResourceId or paymentGatewayId or paymentGatewayOneTimeToken or chargeMethodAttr:
            chargeMethodData = createChargeMethodData(chargeMethod=chargeMethod, paymentMethodResourceId=paymentMethodResourceId,
                                                  paymentGatewayId=paymentGatewayId, paymentGatewayUserId=paymentGatewayUserId,
                                                  paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, chargeMethodAttr=chargeMethodAttrStr,
                                                  deferredSettlement=deferredSettlement, deferredSettlementTimeout=deferredSettlementTimeout,
                                                  deferredSettlementTimeoutAction=deferredSettlementTimeoutAction)
        else:
            chargeMethodData = None
        profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')
        profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'ATTR', profTemplate, 'Attr')
        profTemplate = RESTHELPER.checkIfDefined(parameterArray, None, 'PARAMETERARRAY', profTemplate, 'ParameterArray')
        profTemplate = RESTHELPER.checkIfDefined(preActiveState, None, 'PREACTIVESTATE', profTemplate, 'PreActiveState')
        profTemplate = RESTHELPER.checkIfDefined(autoActivationTime, None, 'AUTOACTIVATIONTIME', profTemplate, 'AutoActivationTime')
        profTemplate = RESTHELPER.checkIfDefined(autoActivationRelativeOffsetUnit, None, 'AUTOACTIVATIONRELATIVEOFFSETUNIT', profTemplate, 'AutoActivationRelativeOffsetUnit')
        profTemplate = RESTHELPER.checkIfDefined(autoActivationRelativeOffset, None, 'aUTOACTIVATIONRELATIVEOFFSET', profTemplate, 'AutoActivationRelativeOffset')
        profTemplate = RESTHELPER.checkIfDefined(autoActivationCycleResourceId, None, 'AUTOACTIVATIONCYCLERESOURCEID', profTemplate, 'AutoActivationCycleResourceId')
        profTemplate = RESTHELPER.checkIfDefined(activationExpirationTime, None, 'ACTIVATIONEXPIRATIONTIME', profTemplate,
            'ActivationExpirationTime')
        profTemplate = RESTHELPER.checkIfDefined(activationExpirationRelativeOffsetUnit, None, 'ACTIVATIONEXPIRATIONRELATIVEOFFSETUNIT',
            profTemplate, 'ActivationExpirationRelativeOffsetUnit')
        profTemplate = RESTHELPER.checkIfDefined(activationExpirationRelativeOffset, None, 'ACTIVATIONEXPIRATIONRELATIVEOFFSET',
            profTemplate, 'ActivationExpirationRelativeOffset')
        profTemplate = RESTHELPER.checkIfDefined(isPendingActivationAllowed, None, 'ISPENDINGACTIVATIONALLOWED', profTemplate, 'IsPendingActivationAllowed')
        profTemplate = RESTHELPER.checkIfDefined(endTimeRelativeOffsetUnit, None, 'ENDTIMERELATIVEOFFSETUNIT', profTemplate, 'EndTimeRelativeOffsetUnit')
        profTemplate = RESTHELPER.checkIfDefined(endTimeRelativeOffset, None, 'ENDTIMERELATIVEOFFSET', profTemplate, 'EndTimeRelativeOffset')
        profTemplate = RESTHELPER.checkIfDefined(chargePurchaseProrationType, None, 'CHARGEPURCHASEPRORATIONTYPE', profTemplate, 'ChargePurchaseProrationType') 
        profTemplate = RESTHELPER.checkIfDefined(grantPurchaseProrationType, None, 'GRANTPURCHASEPRORATIONTYPE', profTemplate, 'GrantPurchaseProrationType')
        profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
        profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
        profTemplate = RESTHELPER.checkIfDefined(geoData, None, 'GEODATA', profTemplate, 'GeoData')

        if future: profTemplate = RESTHELPER.removeItem(profTemplate, 'EventTime')
        else:      profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
        profTemplate = RESTHELPER.checkIfDefined(groupId, None, 'GROUPID', profTemplate, 'ObjectId')
        
        # If future, then don't send via this API
        if future:
                # Return from here, as we're scheuling future purchases as a task
#               print 'profTemplate from future: ' + profTemplate
                return profTemplate
            
        if routingType and routingValue :
            url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

        # Debug output if globally set
        if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + profTemplate)
        
        # Send in the message
        response = V3inst.put(url, payload=profTemplate)
        if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
        (success, resourceId) = validateResponse(response=response, method=funcName,
            shouldPass=eventPass, returnParam='ResourceId')

        if purchaseInfo:
           return (passed(eventPass), response)
        else:
           return (passed(eventPass), resourceId)

#=============================================================
def groupUnsubscribeFromOffer(V3inst, groupId, resourceIds, now=None, eventPass=True, queryType='ExternalId', 
        cancelInfo=False, apiEventData=None, executeMode=None, multiRequestBuild=None, eligibilityCheck=True):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Get group OID if queryType is not ObjectId
    if eventPass and queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=groupId, queryType=queryType, now=now)
        groupId = getOID(queryResponse)

    # Build resource id list if resourceId is list
    if type(resourceIds) is list:
        numEntries = len(resourceIds)
        entryCounter = 1
        resourceIdList = resourceIds
        resourceIds = ''
        for resource in resourceIdList:
            resourceIds += str(resource)
            if entryCounter != numEntries:
                entryCounter += 1
                resourceIds += ','

    url = '/'+RESTV3.urlPrefix+'/group/' + str(groupId) + '/offers/' + str(resourceIds)
    delim = '?'
    amp = False

    if executeMode is not None:
        url+= '?executeMode=' + str(executeMode)
        delim = '&'
        amp = True

    if now is not None:
        url+= delim + 'timestamp=' + now
        now=None
        delim = '&'
        amp = True

    if eligibilityCheck is not None:
        url+= delim + 'eligibilityCheck=' + str(eligibilityCheck).lower()
        delim = '&'
        amp = True

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip(): 
                url += delim +'ApiEventData=' +apiEventDataStr
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.delete(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if cancelInfo:
        return (validateResponse(response=response, method=funcName, shouldPass=eventPass), response)
    else:
        return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupCancelOffer(V3inst, queryValue, resourceId=0, cancelType=None, grantCancelProrationType=None, chargeCancelProrationType=None,
        reason=None, info=None, now=None, queryType='ExternalId', cancelInfo=False, cancelOfferDataList='', eventPass=True, executeMode=None,
        apiEventData=None, contractCancelMode=None, debtCancellationMode=None, multiRequestBuild=None, isWaiveEarlyTerminationCharge=None, eligibilityCheck=True):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    profTemplate = open(templates + 'group_cancel_offer'+RESTV3.fileType).read()

    if type(resourceId) is not list:
        resourceId = [resourceId]
    cancelTemplate=''
    idArray=''

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    if cancelOfferDataList:
        for cancelOfferData in cancelOfferDataList:
            template = open(templates + 'cancel_offer_data'+RESTV3.fileType).read()
            template = RESTHELPER.checkIfDefined(cancelOfferData["ResourceId"], None, 'RESOURCEID', template, 'ResourceId')
            template = RESTHELPER.checkIfDefined(cancelOfferData["CancelType"], None, 'CANCELTYPE', template, 'CancelType')
            template = RESTHELPER.checkIfDefined(cancelOfferData["GrantCancelProrationType"], None, 'GRANTCANCELPRORATIONTYPE', template, 'GrantCancelProrationType')
            template = RESTHELPER.checkIfDefined(cancelOfferData["ChargeCancelProrationType"], None, 'CHARGECANCELPRORATIONTYPE', template, 'ChargeCancelProrationType')
            template = RESTHELPER.checkIfDefined(cancelOfferData["ContractCancelMode"], None, 'CONTRACTCANCELMODE', template, 'ContractCancelMode')
            template = RESTHELPER.checkIfDefined(cancelOfferData["DebtCancellationMode"], None, 'DEBTCANCELLATIONMODE', template, 'DebtCancellationMode')
            template = RESTHELPER.checkIfDefined(cancelOfferData["IsWaiveEarlyTerminationCharge"], None, 'ISWAIVEEARLYTERMINATIONCHARGE', template, 'IsWaiveEarlyTerminationCharge')

            template = RESTHELPER.checkIfDefined(cancelOfferData["Reason"], None, 'REASON', template, 'Reason')
            template = RESTHELPER.checkIfDefined(cancelOfferData["Info"], None, 'INFO', template, 'Info')
            cancelTemplate += template
    elif cancelType or grantCancelProrationType or chargeCancelProrationType or reason or info or contractCancelMode or debtCancellationMode or isWaiveEarlyTerminationCharge:
        profTemplate = RESTHELPER.removeItem(profTemplate, 'ResourceIdArray')
        for id in resourceId:
            template = open(templates + 'cancel_offer_data'+RESTV3.fileType).read()
            template = RESTHELPER.checkIfDefined(id, None, 'RESOURCEID', template, 'ResourceId')
            template = RESTHELPER.checkIfDefined(cancelType, None, 'CANCELTYPE', template, 'CancelType')
            template = RESTHELPER.checkIfDefined(grantCancelProrationType, None, 'GRANTCANCELPRORATIONTYPE', template, 'GrantCancelProrationType')
            template = RESTHELPER.checkIfDefined(chargeCancelProrationType, None, 'CHARGECANCELPRORATIONTYPE', template, 'ChargeCancelProrationType')
            template = RESTHELPER.checkIfDefined(contractCancelMode, None, 'CONTRACTCANCELMODE', template, 'ContractCancelMode')
            template = RESTHELPER.checkIfDefined(debtCancellationMode, None, 'DEBTCANCELLATIONMODE', template, 'DebtCancellationMode')
            template = RESTHELPER.checkIfDefined(isWaiveEarlyTerminationCharge, None, 'ISWAIVEEARLYTERMINATIONCHARGE', template, 'IsWaiveEarlyTerminationCharge')
            template = RESTHELPER.checkIfDefined(reason, None, 'REASON', template, 'Reason')
            template = RESTHELPER.checkIfDefined(info, None, 'INFO', template, 'Info')
            cancelTemplate += template
    else:
        idArray = ''
        if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
            idArray = resourceId
        else:
            for id in resourceId:
                idArray += '<value>' + str(id) + '</value>'

    profTemplate = RESTHELPER.checkIfDefined(cancelTemplate, '', 'CANCELDATAARRAY', profTemplate, 'CancelDataArray')
    profTemplate = RESTHELPER.checkIfDefined(idArray, '', 'RESOURCEIDARRAY', profTemplate, 'ResourceIdArray')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(eligibilityCheck, None, 'ELIGIBILITYCHECK', profTemplate, 'EligibilityCheck')

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/offers'
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if cancelInfo :
        return (validateResponse(response=response, method=funcName, shouldPass=eventPass), response)
    else:
        return validateResponse(response=response, method=funcName, shouldPass=eventPass)
#=============================================================
def addGroupThreshold(V3inst, groupId, thresholdId, resourceId, threshName, val, notify, eventPass=True, now=None,
        queryType='ExternalId', recurringStart=None, recurringStop=None, virtualCreditLimitIsPercent=0,
        rechargeAmount=None, rechargePaymentMethodResourceId=None, executeMode=None,
        isTemporaryCreditLimit=None, apiEventData=None, multiRequestBuild=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if notify:
        thresholdNotification = 'true'
    elif notify==None:
        thresholdNotification = None
    else:
        thresholdNotification = 'false'
    if isTemporaryCreditLimit:
        isTemporaryCreditLimit = 'true'
    elif isTemporaryCreditLimit==None:
        isTemporaryCreditLimit = None 
    else:
        isTemporaryCreditLimit = 'false'

    # Use helper to look for resourceId based on thresholdId if not passed in
    if resourceId is None:
        v3inst = QAUTILS.getDatacontainerConnection()
        walletMdc = v3inst.groupQueryWallet(queryType=queryType, queryValue=groupId, now=now)
        resourceId = COMMON.getResourceId(walletMdc, thresholdId)
        if resourceId is None:
            return COMMON.debugFailure(method='addGroupThreshold', status=1, msg='ThresholdId not found')

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=groupId, queryType=queryType, now=now)
        groupId = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_add_threshold'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(thresholdId, None, 'THRESHOLDID', profTemplate, 'ThresholdId')
    profTemplate = RESTHELPER.checkIfDefined(threshName, None, 'NAME', profTemplate, 'Name')
    profTemplate = RESTHELPER.checkIfDefined(val, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(thresholdNotification, None, 'NOTIFICATIONSTATE', profTemplate, 'NotificationState')
    profTemplate = RESTHELPER.checkIfDefined(recurringStart, None, 'RECURRINGSTART', profTemplate, 'RecurringStart')
    profTemplate = RESTHELPER.checkIfDefined(recurringStop, None, 'RECURRINGSTOP', profTemplate, 'RecurringStop')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(virtualCreditLimitIsPercent, None, 'VIRTUALCREDITLIMITISPERCENT', profTemplate,
        'VirtualCreditLimitIsPct')
    if rechargeAmount or rechargePaymentMethodResourceId:
        rechargeData = open(templates + 'recharge_threshold_data'+RESTV3.fileType).read()
        rechargeData = RESTHELPER.checkIfDefined(rechargeAmount, None, 'RECHARGEAMOUNT', rechargeData, 'Amount')
        rechargeData = RESTHELPER.checkIfDefined(rechargePaymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID',
            rechargeData, 'PaymentMethodResourceId')
    else:
        rechargeData = None
    profTemplate = RESTHELPER.checkIfDefined(rechargeData, None, 'RECHARGEDATA', profTemplate, 'RechargeData')
    profTemplate = RESTHELPER.checkIfDefined(isTemporaryCreditLimit, None, 'ISTEMPORARYCREDITLIMIT', profTemplate, 'IsTemporaryCreditLimit')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    url = '/'+RESTV3.urlPrefix+'/group/' + str(groupId) + '/wallet/' + str(resourceId) + '/thresholds'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def removeGroupThreshold(V3inst, groupId, resourceId, thresholdId, now=None, queryType='ExternalId',
    removeThresholdOnly=None, removeRechargeDataOnly=None, isTemporaryCreditLimit=False, apiEventData=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=groupId, queryType=queryType, now=now)
        groupId = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/group/' + str(groupId) + '/wallet/' + str(resourceId) + '/thresholds/' + str(thresholdId)

    delim = '?'
    amp = False

    if removeThresholdOnly:
        url += '?removeThresholdOnly=true'
        delim = '&'
        amp = True

    if removeRechargeDataOnly:
        url += delim + 'removeRechargeDataOnly=true'
        delim = '&'
        amp = True

    if isTemporaryCreditLimit:
        url += delim + 'isTemporaryCreditLimit=true'
        delim = '&'
        amp = True

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip(): 
                url += delim +'ApiEventData=' +apiEventDataStr
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method='removeGroupThreshold')

#=============================================================
def queryGroupThresholdRechargeDefn(V3inst, queryValue, balanceResourceId=None, now=None, queryType='ExternalId', eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/threshold_recharge_defn'
    if balanceResourceId:
        url += '?resourceId=' + str(balanceResourceId)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def addAdminToGroup(V3inst, groupId, subscriberId, subQueryType='ExternalId', groupQueryType='ExternalId',
        eventPass=True, now=None,executeMode=None, apiEventData=None, multiRequestBuild=None):
    global templates
  
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if groupQueryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=groupId, queryType=groupQueryType, now=now)
        groupId = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    # Make separate REST calls for each subscriber to add
    url = '/'+RESTV3.urlPrefix+'/group/' + str(groupId) + '/add_members/'
    if type(subscriberId) is list and RESTV3.fileType == '.v3':
        for sub in subscriberId:
            if eventPass and subQueryType != 'ObjectId':
                queryResponse = querySubscriber(V3inst=V3inst, queryValue=sub, queryType=subQueryType, now=now)
                sub = getOID(queryResponse)
            profTemplate = open(templates + 'group_add_admins'+RESTV3.fileType).read()
            profTemplate = RESTHELPER.checkIfDefined(sub, None, 'OBJECTID', profTemplate, 'ObjectId')
            profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
            profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
            profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
            
            # Debug output if globally set
            if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + profTemplate)
        
            response = V3inst.put(url, payload=profTemplate)
            if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
            if not validateResponse(response=response, method=funcName, shouldPass=eventPass):
                return False
        return True
    else:
        profTemplate = open(templates + 'group_add_admins'+RESTV3.fileType).read()
        if RESTV3.fileType == '.v3':
            if eventPass and subQueryType != 'ObjectId':
                queryResponse = querySubscriber(V3inst=V3inst, queryValue=subscriberId, queryType=subQueryType, now=now)
                subscriberId = getOID(queryResponse)
            profTemplate = RESTHELPER.checkIfDefined(subscriberId, None, 'OBJECTID', profTemplate, 'ObjectId')
        else:
            adminStr = ''
            if type(subscriberId) is not list:
                subscriberId = [subscriberId]
            for sub in subscriberId:
                adminStr += '{"$": "MtxSubscriberSearchData", "' + str(subQueryType) + '": "' + str(sub) + '"}'
            profTemplate = RESTHELPER.checkIfDefined(adminStr, None, 'ADMINIDS', profTemplate, None)

        profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
        profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
        profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    
        # Debug output if globally set
        if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + profTemplate)
        
        response = V3inst.put(url, payload=profTemplate)
        if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
        return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def removeAdminFromGroup(V3inst, groupId, admins, adminQueryType='ExternalId', groupQueryType='ExternalId',
        eventPass=True, now=None, executeMode=None, apiEventData=None, multiRequestBuild=None):
    global templates
    
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if groupQueryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=groupId, queryType=groupQueryType, now=now)
        groupId = getOID(queryResponse)

    adminStr=None
    adminStr = createAdminArrayStr(V3inst, admins, adminQueryType, now=now)
    if adminStr == '':
        return False

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_remove_admins'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(adminStr, None, 'ADMIN', profTemplate, 'AdminArray')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')    
            
    url = '/'+RESTV3.urlPrefix+'/group/' + str(groupId) + '/remove_members/'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def addSubscriberToGroup(V3inst, groupId, subscriberId, subQueryType='ExternalId', groupQueryType='ExternalId',
        apiEventData=None, eventPass=True, now=None, executeMode=None, multiRequestBuild=None):
    global templates
    
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if groupQueryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=groupId, queryType=groupQueryType, now=now)
        groupId = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    # Make separate REST calls for each subscriber to add
    url = '/'+RESTV3.urlPrefix+'/group/' + str(groupId) + '/add_members/'
    if type(subscriberId) is list and RESTV3.fileType == '.v3':
        for sub in subscriberId:
            if eventPass and subQueryType != 'ObjectId':
                queryResponse = querySubscriber(V3inst=V3inst, queryValue=sub, queryType=subQueryType, now=now)
                sub = getOID(queryResponse)
            profTemplate = open(templates + 'group_add_subscriber'+RESTV3.fileType).read()
            profTemplate = RESTHELPER.checkIfDefined(sub, None, 'OBJECTID', profTemplate, 'ObjectId')
            profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
            profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
            profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
            
            # Debug output if globally set
            if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + profTemplate)
        
            response = V3inst.put(url, payload=profTemplate)
            if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
            if not validateResponse(response=response, method=funcName, shouldPass=eventPass):
                return False
        return True
    else:
        profTemplate = open(templates + 'group_add_subscriber'+RESTV3.fileType).read()
        if RESTV3.fileType == '.v3':
            if eventPass and subQueryType != 'ObjectId':
                queryResponse = querySubscriber(V3inst=V3inst, queryValue=subscriberId, queryType=subQueryType, now=now)
                subscriberId = getOID(queryResponse)
            profTemplate = RESTHELPER.checkIfDefined(subscriberId, None, 'OBJECTID', profTemplate, 'ObjectId')
        else:
            subscriberArray = ''
            if type(subscriberId) is not list:
                subscriberId = [subscriberId]
            for subId in subscriberId:
                subscriberArray += '{"$": "MtxSubscriberSearchData", "' + str(subQueryType) + '": "' + str(subId) + '"}'
            profTemplate = RESTHELPER.checkIfDefined(subscriberArray, None, 'SUBSCRIBERARRAY', profTemplate, None)
        profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
        profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
        profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    
        # Debug output if globally set
        if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + profTemplate)
        
        response = V3inst.put(url, payload=profTemplate)
        if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
        return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def removeSubscriberFromGroup(V3inst, groupId, subscriberId, subQueryType='ExternalId', groupQueryType='ExternalId',
        apiEventData=None, eventPass=True, now=None, executeMode=None, multiRequestBuild=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if groupQueryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=groupId, queryType=groupQueryType, eventPass=eventPass,
            now=now)
        groupId = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    # Make separate REST calls for each subscriber to remove
    url = '/'+RESTV3.urlPrefix+'/group/' + str(groupId) + '/remove_members/'
    if type(subscriberId) is list and RESTV3.fileType == '.v3':
        for sub in subscriberId:
            if eventPass and subQueryType != 'ObjectId':
                queryResponse = querySubscriber(V3inst=V3inst, queryValue=sub, queryType=subQueryType, now=now)
                sub = getOID(queryResponse)
            profTemplate = open(templates + 'group_remove_subscriber'+RESTV3.fileType).read()
            profTemplate = RESTHELPER.checkIfDefined(sub, None, 'OBJECTID', profTemplate, 'ObjectId')
            profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
            profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
            profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
            
            # Debug output if globally set
            if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + profTemplate)
        
            response = V3inst.put(url, payload=profTemplate)
            if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
            if not validateResponse(response=response, method=funcName, shouldPass=eventPass):
                return False
        return True
    else:
        profTemplate = open(templates + 'group_remove_subscriber'+RESTV3.fileType).read()
        if RESTV3.fileType == '.v3':
            if eventPass and subQueryType != 'ObjectId':
                queryResponse = querySubscriber(V3inst=V3inst, queryValue=subscriberId, queryType=subQueryType, now=now)
                subscriberId = getOID(queryResponse)
            profTemplate = RESTHELPER.checkIfDefined(subscriberId, None, 'OBJECTID', profTemplate, 'ObjectId')
        else:
            subscriberArray = []
            if type(subscriberId) is not list:
                subscriberId = [subscriberId]
            for subId in subscriberId:
                subscriberArray.append('{"$": "MtxSubscriberSearchData", "' + str(subQueryType) + '": "' + str(subId) + '"}')
            profTemplate = RESTHELPER.checkIfDefined(subscriberArray, None, 'SUBSCRIBERARRAY', profTemplate, 'SubscriberArray')

        profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
        profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
        profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    
        # Debug output if globally set
        if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + profTemplate)
        
        response = V3inst.put(url, payload=profTemplate)
        if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
        return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def addSubGroupToGroup(V3inst, groupId, subGroupId, subQueryType='ExternalId', groupQueryType='ExternalId',
        apiEventData=None, eventPass=True, now=None, executeMode=None, multiRequestBuild=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if groupQueryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=groupId, queryType=groupQueryType, now=now)
        groupId = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    # Make separate REST calls for each group to add
    url = '/'+RESTV3.urlPrefix+'/group/' + str(groupId) + '/add_members/'
    if type(subGroupId) is list and RESTV3.fileType == '.v3':
        for group in subGroupId:
            if eventPass and subQueryType != 'ObjectId':
                queryResponse = queryGroup(V3inst=V3inst, queryValue=group, queryType=subQueryType, now=now)
                group = getOID(queryResponse)
            profTemplate = open(templates + 'group_add_group'+RESTV3.fileType).read()
            profTemplate = RESTHELPER.checkIfDefined(group, None, 'OBJECTID', profTemplate, 'ObjectId')
            profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
            profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
            profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
            
            # Debug output if globally set
            if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + profTemplate)
        
            response = V3inst.put(url, payload=profTemplate)
            if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
            if not validateResponse(response=response, method=funcName, shouldPass=eventPass):
                return False
        return True
    else:
        profTemplate = open(templates + 'group_add_group'+RESTV3.fileType).read()
        if RESTV3.fileType == '.v3':
            if eventPass and subQueryType != 'ObjectId':
                queryResponse = queryGroup(V3inst=V3inst, queryValue=subGroupId, queryType=subQueryType, now=now)
                subGroupId = getOID(queryResponse)
            profTemplate = RESTHELPER.checkIfDefined(subGroupId, None, 'OBJECTID', profTemplate, 'ObjectId')
        else:
            groupArray = []
            if type(subGroupId) is not list:
                subGroupId = [subGroupId]
            for group in subGroupId:
                groupArray.append('{"$": "MtxGroupSearchData", "' + str(subQueryType) + '": "' + str(group) + '"}')

            profTemplate = RESTHELPER.checkIfDefined(groupArray, None, 'GROUPARRAY', profTemplate, None)

        profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
        profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
        profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    
        # Debug output if globally set
        if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + profTemplate)
        
        response = V3inst.put(url, payload=profTemplate)
        if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
        return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def removeSubGroupFromGroup(V3inst, groupId, subGroupId, subQueryType='ExternalId', groupQueryType='ExternalId',
        apiEventData=None, eventPass=True, now=None, executeMode=None, multiRequestBuild=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if groupQueryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=groupId, queryType=groupQueryType, now=now)
        groupId = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    # Make separate REST calls for each group to remove
    url = '/'+RESTV3.urlPrefix+'/group/' + str(groupId) + '/remove_members/'

    if type(subGroupId) is list and RESTV3.fileType == '.v3':
        for group in subGroupId:
            if subQueryType != 'ObjectId':
                queryResponse = queryGroup(V3inst=V3inst, queryValue=group, queryType=subQueryType, now=now)
                group = getOID(queryResponse)
            profTemplate = open(templates + 'group_remove_group'+RESTV3.fileType).read()
            profTemplate = RESTHELPER.checkIfDefined(group, None, 'OBJECTID', profTemplate, 'ObjectId')
            profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
            profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
            profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
            
            # Debug output if globally set
            if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + profTemplate)
        
            response = V3inst.put(url, payload=profTemplate)
            if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
            if not validateResponse(response=response, method=funcName, shouldPass=eventPass):
                return False
        return True
    else:
        profTemplate = open(templates + 'group_remove_group'+RESTV3.fileType).read()
        if RESTV3.fileType == '.v3':
            if subQueryType != 'ObjectId':
                queryResponse = queryGroup(V3inst=V3inst, queryValue=subGroupId, queryType=subQueryType, now=now)
                subGroupId = getOID(queryResponse)
            profTemplate = RESTHELPER.checkIfDefined(subGroupId, None, 'OBJECTID', profTemplate, 'ObjectId')
        else:
            groupArray = []
            if type(subGroupId) is not list:
                subGroupId = [subGroupId]
            for group in subGroupId:
                groupArray.append('{"$": "MtxGroupSearchData", "' + str(subQueryType) + '": "' + str(group) + '"}')
            profTemplate = RESTHELPER.checkIfDefined(groupArray, None, 'GROUPARRAY', profTemplate, 'ObjectId')

        profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
        profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
        profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    
        # Debug output if globally set
        if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + profTemplate)
        
        response = V3inst.put(url, payload=profTemplate)
        if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
        return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def addGroupMembership(V3inst, groupId, subscribers=None, subGroups=None, subQueryType='ExternalId',
        subGroupQueryType='ExternalId', groupQueryType='ExternalId', eventPass=True, now=None,
        admins=None, adminQueryType='ExternalId', apiEventData=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    subPassed = False
    groupPassed = False
    adminPassed = False
    if subscribers:
        if addSubscriberToGroup(V3inst, groupId, subscribers, subQueryType=subQueryType,
                groupQueryType=groupQueryType, apiEventData=apiEventData, now=now):
            subPassed = True

    if subGroups:
        if addSubGroupToGroup(V3inst, groupId, subGroups, subQueryType=subGroupQueryType, groupQueryType=groupQueryType,
                apiEventData=apiEventData, now=now):
            groupPassed = True

    if admins:
        if not addAdminToGroup(V3inst, groupId, admins, subQueryType=subQueryType, groupQueryType=groupQueryType, now=now):
            adminPassed = True

    if eventPass:
        if not subPassed or not groupPassed or not adminPassed:
            return False
    else:
        if subPassed and groupPassed and adminPassed:
            return False

    return True

#=============================================================
def removeGroupMembership(V3inst, groupId, subscribers=None, subGroups=None, subQueryType='ExternalId',
        subGroupQueryType='ExternalId', groupQueryType='ExternalId', eventPass=True, now=None,
        admins=None, adminQueryType='ExternalId', apiEventData=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if subscribers:
        if not removeSubscriberFromGroup(V3inst, groupId, subscribers, subQueryType=subQueryType,
                groupQueryType=groupQueryType, apiEventData=apiEventData, eventPass=eventPass, now=now):
            return False

    if subGroups:
        if not removeSubGroupFromGroup(V3inst, groupId, subGroups, subQueryType=subQueryType,
                groupQueryType=groupQueryType, apiEventData=apiEventData, eventPass=eventPass, now=now):
            return False

    if admins:
        if not removeAdminFromGroup(V3inst, groupId, admins, adminQueryType=subQueryType, groupQueryType=groupQueryType,
                eventPass=eventPass, now=now):
            return False

    return True

#=============================================================
def addGroupBalance(V3inst, groupId, balanceList, now=None, queryType='ExternalId', eventPass=True, executeMode=None,
    apiEventData=None, multiRequestBuild=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=groupId, queryType=queryType, now=now)
        groupId = getOID(queryResponse)

    # Make separate REST calls for each balance to add
    for balance in balanceList:
        templateId = balance['BalanceTemplateId']
        if balance['InitAmount']:
            initAmount = balance['InitAmount']
        profTemplate = open(templates + 'group_add_balance'+RESTV3.fileType).read()
        profTemplate = RESTHELPER.checkIfDefined(templateId, None, 'TEMPLATEID', profTemplate, 'BalanceTemplateId')
        profTemplate = RESTHELPER.checkIfDefined(initAmount, None, 'INITAMOUNT', profTemplate, 'InitAmount')
        profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
        profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    
        url = '/'+RESTV3.urlPrefix+'/group/' + str(groupId)
        
        # Debug output if globally set
        if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + profTemplate)
        
        response = V3inst.put(url, payload=profTemplate)
        if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
        return validateResponse(response=response, method='addGroupBalance', shouldPass=eventPass)
    
#=============================================================
def queryGroup(V3inst, queryValue, queryType='ExternalId', querySize=None, eventPass=True, now=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    amp = False

    if   queryType == 'ObjectId':       url = '/'+RESTV3.urlPrefix+'/group/'
    elif queryType == 'ExternalId':     url = '/'+RESTV3.urlPrefix+'/group/query/ExternalId/'
    elif queryType == 'PhoneNumber':    url = '/'+RESTV3.urlPrefix+'/group/query/PhoneNumber/'
        
    # Add ID
    url += str(queryValue)
    
    # Add size if specified
    if querySize:
        url += '?querySize=' + str(querySize)
        amp = True
    else: amp = False
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def queryGroupWallet(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/wallet'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def deleteGroup(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True, apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue)
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip(): 
                url += '?ApiEventData=' +apiEventDataStr
                amp = True
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.delete(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#========================================================
def deleteSubscriber(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True, deleteDevices=False,
        deleteSession=False, apiEventData=None, multiRequestBuild=None):
    global templates

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Get subscriber OID if queryType is not ObjectId
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/subscriber/' + str(queryValue)
    
    # URL extension for delete devices
    if deleteDevices == True or deleteDevices == '1' or deleteDevices == 1:
                 url += '?deleteDevice=True'
    else:        url += '?deleteDevice=False'

    delim = '&'
    amp = True

    if deleteSession == True: 
        url += delim + 'deleteSession=True'
        delim = '&'
    
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip(): 
                url += delim + 'ApiEventData=' +apiEventDataStr

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def createBillingCycleData(templateId, dateOffset=None, startTime=None, immediateChange=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        billingCycle = '{"$": "MtxBillingCycleData",'
        billingCycle += '"BillingCycleId": "' + str(templateId) + '",'
        
        # Add offset if defined (always > 0 so can just check variable)
        if dateOffset: billingCycle += '"DateOffset": "' + str(dateOffset) + '",'
        
        # Add immediate change if defined
        if immediateChange != None: billingCycle += '"ImmediateChange: "' + str(immediateChange) + '",'
        
        # Close the payload, removing the trailing comma
        billingCycle = billingCycle[:-1] + "}"
    else:
        billingCycle = '<MtxBillingCycleData><BillingCycleId>' + str(templateId) + '</BillingCycleId>'
        if dateOffset: billingCycle += '<DateOffset>' + str(dateOffset) + '</DateOffset>'

        # Add immediate change if defined
        if immediateChange != None: billingCycle += "<ImmediateChange>" + str(immediateChange) + "</ImmediateChange>"

        # Close the payload
        billingCycle += '</MtxBillingCycleData>'

    return billingCycle

#========================================================
def createSubscriberBillingProfile(V3inst, subscriberId, profileId, startTime=None, dateOffset=0,
        queryType='ExternalId', eventPass=True, now=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if now is None:
        now = startTime
    billingCycle = createBillingCycleData(templateId=profileId, dateOffset=dateOffset, startTime=startTime)

    return modifySubscriber(V3inst, subscriberId, queryType=queryType, billingCycle=billingCycle, now=now,
        eventPass=eventPass)

#========================================================
def createGroupBillingProfile(V3inst, groupId, profileId, startTime=None, dateOffset=0,
        queryType='ExternalId', eventPass=True, now=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if now is None:
        now = startTime
    billingCycle = createBillingCycleData(templateId=profileId, dateOffset=dateOffset, startTime=startTime)

    return modifyGroup(V3inst, groupId, groupQueryType=queryType, billingCycle=billingCycle, now=now,
        eventPass=eventPass)

#=============================================================
def getGatewayAuthorizationToken(V3inst, paymentGatewayUserId=None, paymentGatewayId=0, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/'+RESTV3.urlPrefix+'/system/payment_client/' + str(paymentGatewayId) + '/token'

    if paymentGatewayUserId:
        url += '/' +str(paymentGatewayUserId)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.post(url, payload=None)

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' response: ' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response


#========================================================
def subscriberAddPaymentMethod(V3inst, queryValue, paymentGatewayUserId=None, paymentGatewayOneTimeToken=None, paymentGatewayId=0,
        paymentType=None, name=None, isDefault=True, isSysDefault=None, queryType='ExternalId', paymentAttr=None, now=None, eventPass=True,
        executeMode=None, returnTemplate=False, apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    if isDefault:
        isDefault = 'true'
    elif isDefault == False:
        isDefault = 'false'
    if isSysDefault:
        isSysDefault = 'true'
    elif isSysDefault == False:
        isSysDefault = 'false'

    attrStr = None
    if paymentAttr is not None:
        attrStr = parseAttrMdc(paymentAttr)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_add_payment_method'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(paymentGatewayUserId, None, 'PAYMENTGATEWAYUSERID', profTemplate, 'PaymentGatewayUserId')
    profTemplate = RESTHELPER.checkIfDefined(paymentGatewayOneTimeToken, None, 'PAYMENTGATEWAYONETIMETOKEN', profTemplate, 'PaymentGatewayOneTimeToken')
    profTemplate = RESTHELPER.checkIfDefined(paymentGatewayId, None, 'PAYMENTGATEWAYID', profTemplate, 'PaymentGatewayId')
    profTemplate = RESTHELPER.checkIfDefined(paymentType, None, 'PAYMENTTYPE', profTemplate, 'PaymentType')
    profTemplate = RESTHELPER.checkIfDefined(name, None, 'NAME', profTemplate, 'Name')
    profTemplate = RESTHELPER.checkIfDefined(isDefault, None, 'ISDEFAULT', profTemplate, 'IsDefault')
    profTemplate = RESTHELPER.checkIfDefined(isSysDefault, None, 'ISSYSDEFAULT', profTemplate, 'IsSysDefault')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'PAYMENTATTR', profTemplate, 'PaymentAttr')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')

    if returnTemplate:
        return profTemplate

    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/payment_method/' + str(paymentGatewayId)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#========================================================
def subscriberCreatePaymentOneTimeToken(V3inst, queryValue, queryType='ExternalId', paymentMethodResourceId=None, paymentAttr=None,
    eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType)
        queryValue = getOID(queryResponse)

    if not paymentMethodResourceId:
        paymentMethodResourceId=0

    profTemplate = open(templates + 'subscriber_request_payment_token'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(paymentMethodResourceId, 0, 'PAYMENTMETHODRESOURCEID', profTemplate, 'PaymentMethodResourceId')
    profTemplate = RESTHELPER.checkIfDefined(paymentAttr, None, 'PAYMENTATTR', profTemplate, 'PaymentAttr')

    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/payment_token/' + str(paymentMethodResourceId) + '/create_one_time'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload: ' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)

    if QAUTILS.DebugLevel > 0: print(funcName + ' response: ' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response


#========================================================
def subscriberModifyPaymentMethod(V3inst, queryValue, resourceId=None, paymentGatewayUserId=None, paymentType=None, name=None,
        paymentGatewayOneTimeToken=None, isDefault=None, isSysDefault=None, queryType='ExternalId', paymentAttr=None, now=None,
        eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    if isDefault:
        isDefault = 'true'
    elif isDefault == False:
        isDefault = 'false'
    if isSysDefault:
        isSysDefault = 'true'
    elif isSysDefault == False:
        isSysDefault = 'false'

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_modify_payment_method'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(resourceId, None, 'RESOURCEID', profTemplate, 'ResourceId')
    profTemplate = RESTHELPER.checkIfDefined(paymentGatewayUserId, None, 'PAYMENTGATEWAYUSERID', profTemplate, 'PaymentGatewayUserId')
    profTemplate = RESTHELPER.checkIfDefined(paymentGatewayOneTimeToken, None, 'PAYMENTGATEWAYONETIMETOKEN', profTemplate, 'PaymentGatewayOneTimeToken')
    profTemplate = RESTHELPER.checkIfDefined(paymentType, None, 'PAYMENTTYPE', profTemplate, 'PaymentType')
    profTemplate = RESTHELPER.checkIfDefined(name, None, 'NAME', profTemplate, 'Name')
    profTemplate = RESTHELPER.checkIfDefined(isDefault, None, 'ISDEFAULT', profTemplate, 'IsDefault')
    profTemplate = RESTHELPER.checkIfDefined(isSysDefault, None, 'ISSYSDEFAULT', profTemplate, 'IsSysDefault')
    profTemplate = RESTHELPER.checkIfDefined(paymentAttr, None, 'PAYMENTATTR', profTemplate, 'PaymentAttr')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/payment_method/' + str(resourceId)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#========================================================
def subscriberValidatePaymentMethod(V3inst, queryValue, queryType='ExternalId', resourceId=None, postalCode=None,
        now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    paymentMethodValidationData = None
    if postalCode is not None:
        paymentMethodValidationData = parseAttrMdc(RESTV3.createAttr('MtxAddressData', {'PostalCode':postalCode}))

    url = '/'+RESTV3.urlPrefix+'/subscription/' + str(queryValue) + '/validate_payment_method'

    profTemplate = open(templates + 'subscriber_validate_payment_method'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(paymentMethodValidationData, None, 'ADDRESSDATA', profTemplate, 'AddressData')
    profTemplate = RESTHELPER.checkIfDefined(resourceId, None, 'RESOURCEID', profTemplate, 'ResourceId')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#========================================================
def subscriberQueryPaymentMethod(V3inst, queryValue, paymentGatewayId=None, returnDefault=None, returnSysDefault=None,
        queryType='ObjectId', now=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/payment_method'
    if paymentGatewayId or paymentGatewayId == 0 or returnDefault or returnSysDefault:
        url +=  '?'
        if paymentGatewayId or paymentGatewayId == 0:
            url +=  'gatewayId=' + str(paymentGatewayId)
            if returnDefault or returnSysDefault:
                url += '&'
        if returnDefault:
            url += 'returnDefault=true' 
        if returnSysDefault:
            url += 'returnSysDefault=true'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#========================================================
def subscriberRemovePaymentMethod(V3inst, queryValue, resourceId=None, queryType='ObjectId', now=None, eventPass=True,
    apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/payment_method/' + str(resourceId)
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip(): 
                url += '?ApiEventData=' +apiEventDataStr
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#========================================================
def groupAddPaymentMethod(V3inst, queryValue, paymentGatewayUserId=None, paymentGatewayOneTimeToken=None, paymentGatewayId=0,
        paymentType=None, name=None, isDefault=True, isSysDefault=None, queryType='ExternalId', paymentAttr=None, now=None, 
        eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    if isDefault:
        isDefault = 'true'
    elif isDefault == False:
        isDefault = 'false'
    if isSysDefault:
        isSysDefault = 'true'
    elif isSysDefault == False:
        isSysDefault = 'false'

    attrStr = None
    if paymentAttr is not None:
        attrStr = parseAttrMdc(paymentAttr)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_add_payment_method'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(paymentGatewayUserId, None, 'PAYMENTGATEWAYUSERID', profTemplate, 'PaymentGatewayUserId')
    profTemplate = RESTHELPER.checkIfDefined(paymentGatewayOneTimeToken, None, 'PAYMENTGATEWAYONETIMETOKEN', profTemplate, 'PaymentGatewayOneTimeToken')
    profTemplate = RESTHELPER.checkIfDefined(paymentGatewayId, None, 'PAYMENTGATEWAYID', profTemplate, 'PaymentGatewayId')
    profTemplate = RESTHELPER.checkIfDefined(paymentType, None, 'PAYMENTTYPE', profTemplate, 'PaymentType')
    profTemplate = RESTHELPER.checkIfDefined(name, None, 'NAME', profTemplate, 'Name')
    profTemplate = RESTHELPER.checkIfDefined(isDefault, None, 'ISDEFAULT', profTemplate, 'IsDefault')
    profTemplate = RESTHELPER.checkIfDefined(isSysDefault, None, 'ISSYSDEFAULT', profTemplate, 'IsSysDefault')
    profTemplate = RESTHELPER.checkIfDefined(attrStr, None, 'PAYMENTATTR', profTemplate, 'PaymentAttr')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/payment_method/' + str(paymentGatewayId)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#========================================================
def groupCreatePaymentOneTimeToken(V3inst, queryValue, queryType='ExternalId', paymentMethodResourceId=None, paymentAttr=None,
    eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType)
        queryValue = getOID(queryResponse)

    if not paymentMethodResourceId:
        paymentMethodResourceId=0

    profTemplate = open(templates + 'group_request_payment_token'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(paymentMethodResourceId, 0, 'PAYMENTMETHODRESOURCEID', profTemplate, 'PaymentMethodResourceId')
    profTemplate = RESTHELPER.checkIfDefined(paymentAttr, None, 'PAYMENTATTR', profTemplate, 'PaymentAttr')

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/payment_token/' + str(paymentMethodResourceId) + '/create_one_time'

   # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload: ' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)

    if QAUTILS.DebugLevel > 0: print(funcName + ' response: ' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#========================================================
def groupModifyPaymentMethod(V3inst, queryValue, resourceId=None, paymentGatewayUserId=None, paymentType=None, name=None,
        paymentGatewayOneTimeToken=None, isDefault=None, isSysDefault=None, queryType='ExternalId', paymentAttr=None, now=None,
        eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    if isDefault:
        isDefault = 'true'
    elif isDefault == False:
        isDefault = 'false'
    if isSysDefault:
        isSysDefault = 'true'
    elif isSysDefault == False:
        isSysDefault = 'false'

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_modify_payment_method'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(resourceId, None, 'RESOURCEID', profTemplate, 'ResourceId')
    profTemplate = RESTHELPER.checkIfDefined(paymentGatewayUserId, None, 'PAYMENTGATEWAYUSERID', profTemplate, 'PaymentGatewayUserId')
    profTemplate = RESTHELPER.checkIfDefined(paymentGatewayOneTimeToken, None, 'PAYMENTGATEWAYONETIMETOKEN', profTemplate, 'PaymentGatewayOneTimeToken')
    profTemplate = RESTHELPER.checkIfDefined(paymentType, None, 'PAYMENTTYPE', profTemplate, 'PaymentType')
    profTemplate = RESTHELPER.checkIfDefined(name, None, 'NAME', profTemplate, 'Name')
    profTemplate = RESTHELPER.checkIfDefined(isDefault, None, 'ISDEFAULT', profTemplate, 'IsDefault')
    profTemplate = RESTHELPER.checkIfDefined(isSysDefault, None, 'ISSYSDEFAULT', profTemplate, 'IsSysDefault')
    profTemplate = RESTHELPER.checkIfDefined(paymentAttr, None, 'PAYMENTATTR', profTemplate, 'PaymentAttr')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/payment_method/' + str(resourceId)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#========================================================
def groupValidatePaymentMethod(V3inst, queryValue, queryType='ExternalId', resourceId=None, postalCode=None,
        now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    paymentMethodValidationData = None
    if postalCode is not None:
        paymentMethodValidationData = parseAttrMdc(RESTV3.createAttr('MtxAddressData', {'PostalCode':postalCode}))

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/validate_payment_method'

    profTemplate = open(templates + 'group_validate_payment_method'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(paymentMethodValidationData, None, 'ADDRESSDATA', profTemplate, 'AddressData')
    profTemplate = RESTHELPER.checkIfDefined(resourceId, None, 'RESOURCEID', profTemplate, 'ResourceId')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#========================================================
def groupQueryPaymentMethod(V3inst, queryValue, paymentGatewayId=None, returnDefault=None, returnSysDefault=None,
        queryType='ObjectId', now=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/payment_method'
    if paymentGatewayId or paymentGatewayId == 0 or returnDefault or returnSysDefault:
        url +=  '?'
        if paymentGatewayId or paymentGatewayId == 0:
            url +=  'gatewayId=' + str(paymentGatewayId)
            if returnDefault or returnSysDefault:
                url += '&'
        if returnDefault:
            url += 'returnDefault=true'
        if returnSysDefault:
            url += 'returnSysDefault=true'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#========================================================
def groupRemovePaymentMethod(V3inst, queryValue, resourceId=None, queryType='ObjectId', now=None, eventPass=True,
    apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/payment_method/' + str(resourceId)
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip(): 
                url += '?ApiEventData=' +apiEventDataStr
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberPayment(V3inst, queryValue, amount, payNow=None, queryType='ExternalId',
        paymentMethodResourceId=None, paymentGatewayId=None, paymentGatewayOneTimeToken=None, info=None, apiEventData=None, 
        reason=None,  paymentGatewayUserId=None, chargeMethodAttr=None, eventPass=True, now=None, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    chargeMethodAttrStr = None
    if chargeMethodAttr is not None:
        chargeMethodAttrStr = parseAttrMdc(chargeMethodAttr)
    
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_payment'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(payNow, None, 'PAYNOW', profTemplate, 'PayNow')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    if paymentMethodResourceId or paymentGatewayId or paymentGatewayOneTimeToken or chargeMethodAttr:
        chargeMethodData = createChargeMethodData(paymentMethodResourceId=paymentMethodResourceId,
                                                  paymentGatewayId=paymentGatewayId, paymentGatewayUserId=paymentGatewayUserId,
                                                  paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, chargeMethodAttr=chargeMethodAttrStr)
    else:
        chargeMethodData = None
    profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/payment/' + str(amount) 
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def groupPayment(V3inst, queryValue, amount, payNow=None, queryType='ExternalId',
        paymentMethodResourceId=None, paymentGatewayId=None, paymentGatewayOneTimeToken=None, info=None, apiEventData=None,
        reason=None, paymentGatewayUserId=None, chargeMethodAttr=None, eventPass=True, now=None, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)
    chargeMethodAttrStr = None
    if chargeMethodAttr is not None:
        chargeMethodAttrStr = parseAttrMdc(chargeMethodAttr)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_payment'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(payNow, None, 'PAYNOW', profTemplate, 'PayNow')
    if paymentMethodResourceId or paymentGatewayId or paymentGatewayOneTimeToken or chargeMethodAttr:
        chargeMethodData = createChargeMethodData(paymentMethodResourceId=paymentMethodResourceId,
                                                  paymentGatewayId=paymentGatewayId, paymentGatewayUserId=paymentGatewayUserId,
                                                  paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, chargeMethodAttr=chargeMethodAttrStr)
    else:
        chargeMethodData = None
    profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/payment/' + str(amount)
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberSettlePayment(V3inst, queryValue, queryType='ExternalId', resourceId=None, eventPass=True, now=None,
    apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/settle_payment/' + str(resourceId)
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip(): 
                url += '?ApiEventData=' +apiEventDataStr
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.put(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def groupSettlePayment(V3inst, queryValue, queryType='ExternalId', resourceId=None, eventPass=True, now=None,
    apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/settle_payment/' + str(resourceId)
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip(): 
                url += '?ApiEventData=' +apiEventDataStr
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.put(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberAdjustBalance(V3inst=None, queryValue=None, balanceResourceId=None, componentMeterId=None, adjustType=None, amount=None,
        reason=None, queryType='PhoneNumber', info=None, endTime=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,now=None,
        creditLimitPolicy=None, apiEventData=None, startTime=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_adjust_balance'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEID', profTemplate,
        'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(componentMeterId, None, 'COMPONENTMETERID', profTemplate,
        'ComponentMeterId')
    profTemplate = RESTHELPER.checkIfDefined(adjustType, None, 'ADJUSTTYPE', profTemplate, 'AdjustType')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(endTime, None, 'ENDTIME', profTemplate, 'EndTime')
    profTemplate = RESTHELPER.checkIfDefined(startTime, None, 'STARTTIME', profTemplate, 'StartTime')
    #use endTIMEEXTENSIONOFFSETUNIT and endTIMEEXTENSIONOFFSET pattern to differentiate from ENDTIME pattern for the prefix
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffsetUnit, None, 'endTIMEEXTENSIONOFFSETUNIT', profTemplate, 'EndTimeExtensionOffsetUnit')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffset, None, 'endTIMEEXTENSIONOFFSET', profTemplate, 'EndTimeExtensionOffset')
    profTemplate = RESTHELPER.checkIfDefined(creditLimitPolicy, None, 'CREDITLIMITPOLICY', profTemplate, 'CreditLimitPolicy')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/adjustment'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def subscriberTransferBalance(V3inst=None, queryValue=None, queryType='PhoneNumber', balanceResourceId=None, amount=None, amountIsPct=False,
        targetSubscriberSearchData=None, targetGroupSearchData=None, targetQueryType='PhoneNumber', targetBalanceResourceId=None,
        sourceIsEventInitiator=None, creditFloorPolicy=None, reason=None, info=None,
        apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    if (targetGroupSearchData and targetQueryType != 'ObjectId'):
        queryResponse = queryGroup(V3inst=V3inst, queryValue=targetGroupSearchData, queryType=targetQueryType, now=now)
        targetGroupSearchData = getOID(queryResponse)

    if (targetSubscriberSearchData and targetQueryType != 'ObjectId'):
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=targetSubscriberSearchData, queryType=targetQueryType, now=now)
        targetSubscriberSearchData = getOID(queryResponse)

    if amountIsPct:
        amountIsPct = 'true'
    else:
        amountIsPct = 'false'

    if sourceIsEventInitiator:
        sourceIsEventInitiator = 'true'
    elif (not sourceIsEventInitiator and sourceIsEventInitiator is not None):
        sourceIsEventInitiator = 'false'

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_transfer_balance'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'SOURCEOBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'SOURCEBALANCERESOURCEID', profTemplate, 'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(amountIsPct, None, 'amountISPCT', profTemplate, 'AmountIsPct')
    profTemplate = RESTHELPER.checkIfDefined(targetSubscriberSearchData, None, 'TARGETSUBSCRIBERSEARCHDATA', profTemplate, 'TargetSubscriberSearchData')
    profTemplate = RESTHELPER.checkIfDefined(targetGroupSearchData, None, 'TARGETGROUPSEARCHDATA', profTemplate, 'TargetGroupSearchData')
    profTemplate = RESTHELPER.checkIfDefined(targetBalanceResourceId, None, 'TARGETBALANCERESOURCEID', profTemplate, 'TargetBalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(sourceIsEventInitiator, None, 'SOURCEISEVENTINITIATOR', profTemplate, 'SourceIsEventInitiator')
    profTemplate = RESTHELPER.checkIfDefined(creditFloorPolicy, None, 'CREDITFLOORPOLICY', profTemplate, 'CreditFloorPolicy')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/transfer'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def subscriberTopupBalance(V3inst=None, queryValue=None, balanceResourceId=None, amount=None, voucher=None,
        queryType='PhoneNumber', endTime=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
        apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_topup_balance'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEID', profTemplate,
        'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(voucher, None, 'VOUCHER', profTemplate, 'Voucher')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(endTime, None, 'ENDTIME', profTemplate, 'EndTime')
    #use endTIMEEXTENSIONOFFSETUNIT and endTIMEEXTENSIONOFFSET pattern to differentiate from ENDTIME pattern for the prefix
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffsetUnit, None, 'endTIMEEXTENSIONOFFSETUNIT', profTemplate, 'EndTimeExtensionOffsetUnit')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffset, None, 'endTIMEEXTENSIONOFFSET', profTemplate, 'EndTimeExtensionOffset')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/topup'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method='subscriberTopupBalance', shouldPass=eventPass)

#=============================================================
def subscriberRecharge(V3inst=None, queryValue=None, amount=None, balanceResourceId=None, payNow=None, queryType='PhoneNumber',
        endTime=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None, chargeMethodAttr=None,
        paymentMethodResourceId=None, paymentGatewayId=None, paymentGatewayOneTimeToken=None, info=None, reason=None, apiEventData=None,
        paymentGatewayUserId=None, rechargeAttr=None, now=None, eventPass=True, executeMode=None, payload=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
  
    chargeMethodAttrStr = None
    if chargeMethodAttr is not None:
        chargeMethodAttrStr = parseAttrMdc(chargeMethodAttr)
    
    rechargeAttrStr = None
    if rechargeAttr is not None:
        rechargeAttrStr = parseAttrMdc(rechargeAttr)
    
    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    profTemplate = open(templates + 'subscriber_recharge'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEID', profTemplate, 'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(payNow, None, 'PAYNOW', profTemplate, 'PayNow')
    if paymentMethodResourceId or paymentGatewayId or paymentGatewayOneTimeToken or chargeMethodAttr:
        chargeMethodData = createChargeMethodData(paymentMethodResourceId=paymentMethodResourceId,
                                                  paymentGatewayId=paymentGatewayId, paymentGatewayUserId=paymentGatewayUserId,
                                                  paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, chargeMethodAttr=chargeMethodAttrStr)
    else:
        chargeMethodData = None
    profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')
    profTemplate = RESTHELPER.checkIfDefined(rechargeAttrStr, None, 'RECHARGEATTR', profTemplate, 'RechargeAttr')
    profTemplate = RESTHELPER.checkIfDefined(endTime, None, 'ENDTIME', profTemplate, 'EndTime')
    #use endTIMEEXTENSIONOFFSETUNIT and endTIMEEXTENSIONOFFSET pattern to differentiate from ENDTIME pattern for the prefix
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffsetUnit, None, 'endTIMEEXTENSIONOFFSETUNIT', profTemplate, 'EndTimeExtensionOffsetUnit')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffset, None, 'endTIMEEXTENSIONOFFSET', profTemplate, 'EndTimeExtensionOffset')

    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    if not balanceResourceId:
        balanceResourceId = 'default'
    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/recharge/' + str(amount)
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        if payload:
            print(funcName + ' payload:\n' + profTemplate)
        
    if payload:
        response = V3inst.put(url, payload=profTemplate)
    else:
        response = V3inst.put(url, payload=None)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def subscriberAddRechargeSchedule(V3inst=None, queryValue=None, firstRechargeTime=None, queryType='ExternalId',
        periodType=None, periodCoef=None, cycleTimeOfDay=None, cycleOffset=None,
        amount=None, paymentMethodResourceId=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
        scheduledRechargeNotificationProfileId=None, now=None, eventPass=True, executeMode=None, returnTemplate=False,
        apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_add_recharge_schedule'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(firstRechargeTime, None, 'FIRSTRECHARGETIME', profTemplate, 'FirstRechargeTime')
    if periodType or periodCoef or cycleTimeOfDay or cycleOffset:
        dataTemplate = open(templates + 'recharge_cycle_data'+RESTV3.fileType).read()
        dataTemplate = RESTHELPER.checkIfDefined(periodType, None, 'PERIODTYPE', dataTemplate, 'PeriodType')
        dataTemplate = RESTHELPER.checkIfDefined(periodCoef, None, 'PERIODCOEF', dataTemplate, 'PeriodCoef')
        dataTemplate = RESTHELPER.checkIfDefined(cycleTimeOfDay, None, 'CYCLETIMEOFDAY', dataTemplate, 'CycleTimeOfDay')
        dataTemplate = RESTHELPER.checkIfDefined(cycleOffset, None, 'CYCLEOFFSET', dataTemplate, 'CycleOffset')
    else:
        dataTemplate=None
    profTemplate = RESTHELPER.checkIfDefined(dataTemplate, None, 'CYCLEDEFN', profTemplate, 'CycleDefn')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'amount')
    profTemplate = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', profTemplate, 'PaymentMethodResourceId')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffsetUnit, None, 'ENDTIMEEXTENSIONOFFSETUNIT', profTemplate, 'EndTimeExtensionOffsetUnit')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffset, None, 'ENDTIMEEXTENSIONOFFSET', profTemplate, 'EndTimeExtensionOffset')
    profTemplate = RESTHELPER.checkIfDefined(scheduledRechargeNotificationProfileId, None, 'SCHEDULEDRECHARGENOTIFICATIONPOFILEID', profTemplate,
        'ScheduledRechargeNotificationProfileId')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    if returnTemplate:
        return profTemplate

    url = '/'+RESTV3.urlPrefix+'/subscription/' + str(queryValue) + '/recharge_schedule'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def subscriberModifyRechargeSchedule(V3inst=None, queryValue=None, nextRechargeTime=None, queryType='ExternalId',
        periodType=None, periodCoef=None, cycleTimeOfDay=None, cycleOffset=None,
        amount=None, paymentMethodResourceId=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
        scheduledRechargeNotificationProfileId=None, now=None, eventPass=True, executeMode=None,
        apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_modify_recharge_schedule'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(nextRechargeTime, None, 'NEXTRECHARGETIME', profTemplate, 'NextRechargeTime')
    if periodType or periodCoef or cycleTimeOfDay or cycleOffset:
        dataTemplate = open(templates + 'recharge_cycle_data'+RESTV3.fileType).read()
        dataTemplate = RESTHELPER.checkIfDefined(periodType, None, 'PERIODTYPE', dataTemplate, 'PeriodType')
        dataTemplate = RESTHELPER.checkIfDefined(periodCoef, None, 'PERIODCOEF', dataTemplate, 'PeriodCoef')
        dataTemplate = RESTHELPER.checkIfDefined(cycleTimeOfDay, None, 'CYCLETIMEOFDAY', dataTemplate, 'CycleTimeOfDay')
        dataTemplate = RESTHELPER.checkIfDefined(cycleOffset, None, 'CYCLEOFFSET', dataTemplate, 'CycleOffset')
    else:
        dataTemplate=None
    profTemplate = RESTHELPER.checkIfDefined(dataTemplate, None, 'CYCLEDEFN', profTemplate, 'CycleDefn')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', profTemplate, 'PaymentMethodResourceId')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffsetUnit, None, 'ENDTIMEEXTENSIONOFFSETUNIT', profTemplate, 'EndTimeExtensionOffsetUnit')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffset, None, 'ENDTIMEEXTENSIONOFFSET', profTemplate, 'EndTimeExtensionOffset')
    profTemplate = RESTHELPER.checkIfDefined(scheduledRechargeNotificationProfileId, None, 'SCHEDULEDRECHARGENOTIFICATIONPOFILEID', profTemplate,
        'ScheduledRechargeNotificationProfileId')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/'+RESTV3.urlPrefix+'/subscription/' + str(queryValue) + '/recharge_schedule'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def subscriberRemoveRechargeSchedule(V3inst=None, queryValue=None, queryType='ExternalId', now=None, eventPass=True,
    apiEventData=None, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/subscription/' + str(queryValue) + '/recharge_schedule'
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip(): 
                url += '?ApiEventData=' +apiEventDataStr
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberQueryRechargeSchedule(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/subscription/' + str(queryValue) + '/recharge_schedule'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberQueryRecurringRecharge(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/recurring_recharge'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberAddBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId', balanceResourceId=None,
        durationBeforeExpiryInMinutes=None, notificationProfileId=None, paymentMethodResourceId=None, rechargeAmount=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_create_balance_expiry_recharge_defn'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEID', profTemplate, 'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(durationBeforeExpiryInMinutes, None, 'DURATIONBEFOREEXPIRYINMINUTES', profTemplate, 'DurationBeforeExpiryInMinutes')
    profTemplate = RESTHELPER.checkIfDefined(notificationProfileId, None, 'NOTIFICATIONPROFILEID', profTemplate, 'NotificationProfileId')
    profTemplate = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', profTemplate, 'PaymentMethodResourceId')
    profTemplate = RESTHELPER.checkIfDefined(rechargeAmount, None, 'RECHARGEAMOUNT', profTemplate, 'RechargeAmount')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    url = '/'+RESTV3.urlPrefix+'/subscription/' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/balance_expiry_recharge_defn'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberModifyBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId', balanceResourceId=None,
        durationBeforeExpiryInMinutes=None, notificationProfileId=None, paymentMethodResourceId=None, rechargeAmount=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_modify_balance_expiry_recharge_defn'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEID', profTemplate, 'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(durationBeforeExpiryInMinutes, None, 'DURATIONBEFOREEXPIRYINMINUTES', profTemplate, 'DurationBeforeExpiryInMinutes')
    profTemplate = RESTHELPER.checkIfDefined(notificationProfileId, None, 'NOTIFICATIONPROFILEID', profTemplate, 'NotificationProfileId')
    profTemplate = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', profTemplate, 'PaymentMethodResourceId')
    profTemplate = RESTHELPER.checkIfDefined(rechargeAmount, None, 'RECHARGEAMOUNT', profTemplate, 'RechargeAmount')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/'+RESTV3.urlPrefix+'/subscription/' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/balance_expiry_recharge_defn'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberRemoveBalanceExpiryRechargeDefn(V3inst=None, queryValue=None, queryType='ExternalId', balanceResourceId=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/subscription/' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/balance_expiry_recharge_defn'
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip(): 
                url += '?ApiEventData=' +apiEventDataStr
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberQueryBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/subscription/' + str(queryValue) + '/balance_expiry_recharge_defn'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberRefundPayment(V3inst=None, queryValue=None, queryType='PhoneNumber', balanceResourceId=None, apiEventData=None, 
        resourceId=None, amount=None, reason=None, info=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_refund_payment'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEiD', profTemplate, 'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(resourceId, None, 'RESOURCEID', profTemplate, 'ResourceId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/payment_history/' + str(resourceId) + '/refund'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def subscriberQueryPaymentHistory(V3inst=None, queryValue=None, queryType='PhoneNumber',
        now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/payment_history/'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now, amp=False)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberModifyExternalPayment(V3inst=None, queryValue=None, queryType='ExternalId', resourceId=None, apiEventData=None,
        amount=None, reason=None, info=None, opType=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_modify_external_payment'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(opType, None, 'OPTYPE', profTemplate, 'OpType')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/external_payment/' + str(resourceId)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def subscriberQueryExternalPayment(V3inst=None, queryValue=None, queryType='ExternalId',
        now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/external_payment'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now, amp=False)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberAdjustRolloverBalance(V3inst=None, queryValue=None, reason=None, balanceResourceId=None,
           queryType='PhoneNumber', balanceIntervalId=None, adjustType=None, amount=None, info=None, remainingRolloverCounter=None,
           apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'subscriber_adjust_rollover_balance'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEID', profTemplate,
        'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(adjustType, None, 'ADJUSTTYPE', profTemplate, 'AdjustType')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(remainingRolloverCounter, None, 'REMAININGROLLOVERCOUNTER', profTemplate, 'RemainingRolloverCounter')
    profTemplate = RESTHELPER.checkIfDefined(balanceIntervalId, None, 'BALANCEINTERVALID', profTemplate, 'BalanceIntervalId')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/adjust_rollover'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupAdjustBalance(V3inst=None, queryValue=None, balanceResourceId=None, componentMeterId=None, adjustType=None, amount=None,
        reason=None, queryType='ExternalId', info=None, endTime=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None, now=None,
        apiEventData=None, creditLimitPolicy=None, startTime=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_adjust_balance'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEID', profTemplate,
        'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(componentMeterId, None, 'COMPONENTMETERID', profTemplate,
        'ComponentMeterId')
    profTemplate = RESTHELPER.checkIfDefined(adjustType, None, 'ADJUSTTYPE', profTemplate, 'AdjustType')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(endTime, None, 'ENDTIME', profTemplate, 'EndTime')
    profTemplate = RESTHELPER.checkIfDefined(startTime, None, 'STARTTIME', profTemplate, 'StartTime')
    #use endTIMEEXTENSIONOFFSETUNIT and endTIMEEXTENSIONOFFSET pattern to differentiate from ENDTIME pattern for the prefix
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffsetUnit, None, 'endTIMEEXTENSIONOFFSETUNIT', profTemplate, 'EndTimeExtensionOffsetUnit')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffset, None, 'endTIMEEXTENSIONOFFSET', profTemplate, 'EndTimeExtensionOffset')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(creditLimitPolicy, None, 'CREDITLIMITPOLICY', profTemplate, 'CreditLimitPolicy')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/adjustment'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupTransferBalance(V3inst=None, queryValue=None, queryType='PhoneNumber', balanceResourceId=None, amount=None, amountIsPct=False,
        targetSubscriberSearchData=None, targetGroupSearchData=None, targetQueryType='PhoneNumber', targetBalanceResourceId=None,
        sourceIsEventInitiator=None, creditFloorPolicy=None, reason=None, info=None,
        apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    if (targetGroupSearchData and targetQueryType != 'ObjectId'):
        queryResponse = queryGroup(V3inst=V3inst, queryValue=targetGroupSearchData, queryType=targetQueryType, now=now)
        targetGroupSearchData = getOID(queryResponse)

    if (targetSubscriberSearchData and targetQueryType != 'ObjectId'):
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=targetSubscriberSearchData, queryType=targetQueryType, now=now)
        targetSubscriberSearchData = getOID(queryResponse)

    if amountIsPct:
        amountIsPct = 'true'
    else:
        amountIsPct = 'false'

    if sourceIsEventInitiator:
        sourceIsEventInitiator = 'true'
    elif (not sourceIsEventInitiator and sourceIsEventInitiator is not None):
        sourceIsEventInitiator = 'false'

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_transfer_balance'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'SOURCEOBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'SOURCEBALANCERESOURCEID', profTemplate, 'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(amountIsPct, None, 'amountISPCT', profTemplate, 'AmountIsPct')
    profTemplate = RESTHELPER.checkIfDefined(targetSubscriberSearchData, None, 'TARGETSUBSCRIBERSEARCHDATA', profTemplate, 'TargetSubscriberSearchData')
    profTemplate = RESTHELPER.checkIfDefined(targetGroupSearchData, None, 'TARGETGROUPSEARCHDATA', profTemplate, 'TargetGroupSearchData')
    profTemplate = RESTHELPER.checkIfDefined(targetBalanceResourceId, None, 'TARGETBALANCERESOURCEID', profTemplate, 'TargetBalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(sourceIsEventInitiator, None, 'SOURCEISEVENTINITIATOR', profTemplate, 'SourceIsEventInitiator')
    profTemplate = RESTHELPER.checkIfDefined(creditFloorPolicy, None, 'CREDITFLOORPOLICY', profTemplate, 'CreditFloorPolicy')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/transfer'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)


#=============================================================
def groupTopupBalance(V3inst=None, queryValue=None, balanceResourceId=None, amount=None, voucher=None,
        queryType='PhoneNumber', endTime=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
        apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_topup_balance'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEID', profTemplate,
        'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(voucher, None, 'VOUCHER', profTemplate, 'Voucher')
    profTemplate = RESTHELPER.checkIfDefined(endTime, None, 'ENDTIME', profTemplate, 'EndTime')
    #use endTIMEEXTENSIONOFFSETUNIT and endTIMEEXTENSIONOFFSET pattern to differentiate from ENDTIME pattern for the prefix
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffsetUnit, None, 'endTIMEEXTENSIONOFFSETUNIT', profTemplate, 'EndTimeExtensionOffsetUnit')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffset, None, 'endTIMEEXTENSIONOFFSET', profTemplate, 'EndTimeExtensionOffset')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/topup'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupRecharge(V3inst=None, queryValue=None, amount=None, balanceResourceId=None, payNow=None, queryType='ExternalId',
        endTime=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None, chargeMethodAttr=None,
        paymentMethodResourceId=None, paymentGatewayId=None, paymentGatewayOneTimeToken=None, info=None, reason=None, apiEventData=None,
        paymentGatewayUserId=None, rechargeAttr=None, now=None, eventPass=True, executeMode=None, payload=True, multiRequestBuild=None):

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    chargeMethodAttrStr = None
    if chargeMethodAttr is not None:
        chargeMethodAttrStr = parseAttrMdc(chargeMethodAttr)

    rechargeAttrStr = None
    if rechargeAttr is not None:
        rechargeAttrStr = parseAttrMdc(rechargeAttr)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_recharge'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEID', profTemplate, 'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(payNow, None, 'PAYNOW', profTemplate, 'PayNow')
    if paymentMethodResourceId or paymentGatewayId or paymentGatewayOneTimeToken or chargeMethodAttr:
        chargeMethodData = createChargeMethodData(paymentMethodResourceId=paymentMethodResourceId,
                                                  paymentGatewayId=paymentGatewayId, paymentGatewayUserId=paymentGatewayUserId,
                                                  paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, chargeMethodAttr=chargeMethodAttrStr)
    else:
        chargeMethodData = None
    profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')
    profTemplate = RESTHELPER.checkIfDefined(rechargeAttrStr, None, 'RECHARGEATTR', profTemplate, 'RechargeAttr')
    profTemplate = RESTHELPER.checkIfDefined(endTime, None, 'ENDTIME', profTemplate, 'EndTime')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    #use endTIMEEXTENSIONOFFSETUNIT and endTIMEEXTENSIONOFFSET pattern to differentiate from ENDTIME pattern for the prefix
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffsetUnit, None, 'endTIMEEXTENSIONOFFSETUNIT', profTemplate, 'EndTimeExtensionOffsetUnit')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffset, None, 'endTIMEEXTENSIONOFFSET', profTemplate, 'EndTimeExtensionOffset')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    if not balanceResourceId:
        balanceResourceId = 'default'
    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/recharge/' + str(amount)
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        if payload:
            print(funcName + ' payload:\n' + profTemplate)

    if payload:
        response = V3inst.put(url, payload=profTemplate)
    else:
        response = V3inst.put(url, payload=None)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupAddRechargeSchedule(V3inst=None, queryValue=None, firstRechargeTime=None, queryType='ExternalId',
        periodType=None, periodCoef=None, cycleTimeOfDay=None, cycleOffset=None,
        amount=None, paymentMethodResourceId=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
        scheduledRechargeNotificationProfileId=None, now=None, eventPass=True, executeMode=None,
        apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_add_recharge_schedule'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(firstRechargeTime, None, 'FIRSTRECHARGETIME', profTemplate, 'FirstRechargeTime')
    if periodType or periodCoef or cycleTimeOfDay or cycleOffset:
        dataTemplate = open(templates + 'recharge_cycle_data'+RESTV3.fileType).read()
        dataTemplate = RESTHELPER.checkIfDefined(periodType, None, 'PERIODTYPE', dataTemplate, 'PeriodType')
        dataTemplate = RESTHELPER.checkIfDefined(periodCoef, None, 'PERIODCOEF', dataTemplate, 'PeriodCoef')
        dataTemplate = RESTHELPER.checkIfDefined(cycleTimeOfDay, None, 'CYCLETIMEOFDAY', dataTemplate, 'CycleTimeOfDay')
        dataTemplate = RESTHELPER.checkIfDefined(cycleOffset, None, 'CYCLEOFFSET', dataTemplate, 'CycleOffset')
    else:
        dataTemplate=None
    profTemplate = RESTHELPER.checkIfDefined(dataTemplate, None, 'CYCLEDEFN', profTemplate, 'CycleDefn')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'amount')
    profTemplate = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', profTemplate, 'PaymentMethodResourceId')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffsetUnit, None, 'ENDTIMEEXTENSIONOFFSETUNIT', profTemplate, 'EndTimeExtensionOffsetUnit')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffset, None, 'ENDTIMEEXTENSIONOFFSET', profTemplate, 'EndTimeExtensionOffset')
    profTemplate = RESTHELPER.checkIfDefined(scheduledRechargeNotificationProfileId, None, 'SCHEDULEDRECHARGENOTIFICATIONPOFILEID', profTemplate,
        'ScheduledRechargeNotificationProfileId')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/recharge_schedule'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupModifyRechargeSchedule(V3inst=None, queryValue=None, nextRechargeTime=None, queryType='ExternalId',
        periodType=None, periodCoef=None, cycleTimeOfDay=None, cycleOffset=None,
        amount=None, paymentMethodResourceId=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
        scheduledRechargeNotificationProfileId=None, now=None, eventPass=True, executeMode=None,
        apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_modify_recharge_schedule'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(nextRechargeTime, None, 'NEXTRECHARGETIME', profTemplate, 'NextRechargeTime')
    if periodType or periodCoef or cycleTimeOfDay or cycleOffset:
        dataTemplate = open(templates + 'recharge_cycle_data'+RESTV3.fileType).read()
        dataTemplate = RESTHELPER.checkIfDefined(periodType, None, 'PERIODTYPE', dataTemplate, 'PeriodType')
        dataTemplate = RESTHELPER.checkIfDefined(periodCoef, None, 'PERIODCOEF', dataTemplate, 'PeriodCoef')
        dataTemplate = RESTHELPER.checkIfDefined(cycleTimeOfDay, None, 'CYCLETIMEOFDAY', dataTemplate, 'CycleTimeOfDay')
        dataTemplate = RESTHELPER.checkIfDefined(cycleOffset, None, 'CYCLEOFFSET', dataTemplate, 'CycleOffset')
    else:
        dataTemplate=None
    profTemplate = RESTHELPER.checkIfDefined(dataTemplate, None, 'CYCLEDEFN', profTemplate, 'CycleDefn')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', profTemplate, 'PaymentMethodResourceId')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffsetUnit, None, 'ENDTIMEEXTENSIONOFFSETUNIT', profTemplate, 'EndTimeExtensionOffsetUnit')
    profTemplate = RESTHELPER.checkIfDefined(endTimeExtensionOffset, None, 'ENDTIMEEXTENSIONOFFSET', profTemplate, 'EndTimeExtensionOffset')
    profTemplate = RESTHELPER.checkIfDefined(scheduledRechargeNotificationProfileId, None, 'SCHEDULEDRECHARGENOTIFICATIONPOFILEID', profTemplate,
        'ScheduledRechargeNotificationProfileId')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/recharge_schedule'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupRemoveRechargeSchedule(V3inst=None, queryValue=None, queryType='ExternalId', now=None, eventPass=True, executeMode=None,
        apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/recharge_schedule'
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip(): 
                url += '?ApiEventData=' +apiEventDataStr
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def groupQueryRechargeSchedule(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/recharge_schedule'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def groupQueryRecurringRecharge(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/recurring_recharge'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def groupAddBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId', balanceResourceId=None,
        durationBeforeExpiryInMinutes=None, notificationProfileId=None, paymentMethodResourceId=None, rechargeAmount=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None, apiEventSecurityInfo=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_create_balance_expiry_recharge_defn'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEID', profTemplate, 'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(durationBeforeExpiryInMinutes, None, 'DURATIONBEFOREEXPIRYINMINUTES', profTemplate, 'DurationBeforeExpiryInMinutes')
    profTemplate = RESTHELPER.checkIfDefined(notificationProfileId, None, 'NOTIFICATIONPROFILEID', profTemplate, 'NotificationProfileId')
    profTemplate = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', profTemplate, 'PaymentMethodResourceId')
    profTemplate = RESTHELPER.checkIfDefined(rechargeAmount, None, 'RECHARGEAMOUNT', profTemplate, 'RechargeAmount')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(apiEventSecurityInfo, None, 'APIEVENTSECURITYINFO', profTemplate, 'ApiEventSecurityInfo')
    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/balance_expiry_recharge_defn'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def groupModifyBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId', balanceResourceId=None,
        durationBeforeExpiryInMinutes=None, notificationProfileId=None, paymentMethodResourceId=None, rechargeAmount=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_modify_balance_expiry_recharge_defn'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEID', profTemplate, 'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(durationBeforeExpiryInMinutes, None, 'DURATIONBEFOREEXPIRYINMINUTES', profTemplate, 'DurationBeforeExpiryInMinutes')
    profTemplate = RESTHELPER.checkIfDefined(notificationProfileId, None, 'NOTIFICATIONPROFILEID', profTemplate, 'NotificationProfileId')
    profTemplate = RESTHELPER.checkIfDefined(paymentMethodResourceId, None, 'PAYMENTMETHODRESOURCEID', profTemplate, 'PaymentMethodResourceId')
    profTemplate = RESTHELPER.checkIfDefined(rechargeAmount, None, 'RECHARGEAMOUNT', profTemplate, 'RechargeAmount')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/balance_expiry_recharge_defn'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def groupRemoveBalanceExpiryRechargeDefn(V3inst=None, queryValue=None, queryType='ExternalId', balanceResourceId=None,
        now=None, eventPass=True, executeMode=None, apiEventData=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/balance_expiry_recharge_defn'
    amp = False

    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)
        if apiEventDataStr and apiEventDataStr.strip(): 
                url += '?ApiEventData=' +apiEventDataStr
                amp = True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def groupQueryBalanceExpiryRechargeDefn(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/balance_expiry_recharge_defn'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def sysQueryConfigRecurringRecharge(V3inst, eventPass=True, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/'+RESTV3.urlPrefix+'/system/configuration/recurring_recharge'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def groupRefundPayment(V3inst=None, queryValue=None, queryType='ExternalId', balanceResourceId=None, apiEventData=None,
        resourceId=None, amount=None, reason=None, info=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_refund_payment'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEiD', profTemplate, 'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(resourceId, None, 'RESOURCEID', profTemplate, 'ResourceId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/payment_history/' + str(resourceId) + '/refund'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def groupQueryPaymentHistory(V3inst=None, queryValue=None, queryType='ExternalId',
       now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/payment_history'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now, amp=False)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def groupModifyExternalPayment(V3inst=None, queryValue=None, queryType='ExternalId', resourceId=None, apiEventData=None,
        amount=None, reason=None, info=None, opType=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_modify_external_payment'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(opType, None, 'OPTYPE', profTemplate, 'OpType')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/external_payment/' + str(resourceId)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupQueryExternalPayment(V3inst=None, queryValue=None, queryType='ExternalId',
        now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/external_payment'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now, amp=False)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def groupAdjustRolloverBalance(V3inst=None, queryValue=None, reason=None, balanceResourceId=None,
           queryType='ExternalId', balanceIntervalId=None, adjustType=None, amount=None, info=None, remainingRolloverCounter=None,
           apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'group_adjust_rollover_balance'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(queryValue, None, 'OBJECTID', profTemplate, 'ObjectId')
    profTemplate = RESTHELPER.checkIfDefined(balanceResourceId, None, 'BALANCERESOURCEID', profTemplate,
        'BalanceResourceId')
    profTemplate = RESTHELPER.checkIfDefined(adjustType, None, 'ADJUSTTYPE', profTemplate, 'AdjustType')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'Amount')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(remainingRolloverCounter, None, 'REMAININGROLLOVERCOUNTER', profTemplate, 'RemainingRolloverCounter')
    profTemplate = RESTHELPER.checkIfDefined(balanceIntervalId, None, 'BALANCEINTERVALID', profTemplate, 'BalanceIntervalId')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/wallet/' + str(balanceResourceId) + '/adjust_rollover'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)
        
    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def subscriberEstimateRecurringCharge(V3inst, queryValue=None, queryType='ObjectId', now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    # Need in OID format
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/recurringcharge'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return (passed(eventPass), response)

#=============================================================
def groupEstimateRecurringCharge(V3inst, queryValue=None, queryType='ObjectId', now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
   
    # Need in OID format
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/recurringcharge'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0: print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return (passed(eventPass), response)

#=============================================================
def pricingQueryStatus(V3inst, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
   
 
    response = V3inst.get('/'+RESTV3.urlPrefix+'/pricing/status', time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method='pricingQueryStatus', shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryLifecycle(V3inst, objectType, lifecycleProfileId=None, now=None, eventPass=True, useCache=False, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Account for cache request
    if useCache in[True, '1']:
                useCache = '/cache'
    else:       useCache = ''
    url = '/' + RESTV3.urlPrefix + useCache + '/pricing/lifecycle/'+str(objectType)
    if objectType == 'offer':
        if lifecycleProfileId:
            url += '/' + str(lifecycleProfileId)
        else:
            url += '/default'
            
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0: print(funcName + ' url: ' + url)

    #print 'life cycle REST query for object ' + str(objectType)
    response = V3inst.get(url, time=now)
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method='pricingQueryStatus', shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryOffer(V3inst, offerId, queryType='OfferId', version=None, now=None, eventPass=True, useCache=False, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Account for cache request
    if useCache in[True, '1']:
                useCache = '/cache'
    else:       useCache = ''
    url = '/' + RESTV3.urlPrefix + useCache + '/pricing/'
    
    if queryType == 'OfferId':
        url += 'offers/' + str(offerId)
        if version: url += '/version/' + str(version)
    elif queryType == 'ExternalId':
        offerId = URL.quote(offerId,'')
        url += 'offers/query/' + str(offerId)
        
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0: print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if validateResponse(response=response, method='pricingQueryOffer', shouldPass=eventPass):
        return response

#=============================================================
def pricingCacheQueryOffer(V3inst, queryValue=None, queryType='offers', version=None, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/' + RESTV3.urlPrefix + '/cache/pricing/'+queryType+'/'+str(queryValue)
    if version :
        url += str(version)
    
    if QAUTILS.DebugLevel > 0: print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if validateResponse(response=response, method='pricingCacheQueryOffer', shouldPass=eventPass):
        return response
#=============================================================
def pricingQueryOfferList(V3inst, now=None, globalList=False, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    if globalList:
       response = V3inst.get('/'+RESTV3.urlPrefix+'/pricing/offers?globalOffersOnly=true', time=now) 
    else:
       response = V3inst.get('/'+RESTV3.urlPrefix+'/pricing/offers', time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    print(response)
    if validateResponse(response=response, method='pricingQueryOfferList', shouldPass=eventPass):
        return response

#=============================================================
def pricingCacheQueryOfferList(V3inst, now=None, queryType='offers', eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/'+RESTV3.urlPrefix+'/cache/pricing/'+queryType
    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    # some bundle has PhoneNumber field wthout double quote added, which  causing json loads exception
    # we need to add double quote for phone number
    if RESTV3.urlPrefix == 'json': 
        response = re.sub(r'"PhoneNumber": (.*)', r'"PhoneNumber": "\1"', response)

    if validateResponse(response=response, method='pricingCacheQueryOfferList', shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryBalance(V3inst, balanceId, queryType='BalanceId', now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    response = V3inst.get('/'+RESTV3.urlPrefix+'/pricing/balance/' + str(balanceId), time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method='pricingQueryBalance', shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryBalanceList(V3inst, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    response = V3inst.get('/'+RESTV3.urlPrefix+'/pricing/balances', time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method='pricingQueryBalanceList', shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryServiceType(V3inst, queryType='ServiceTypeId', queryValue = None, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    response = V3inst.get('/'+RESTV3.urlPrefix+'/pricing/service_type/' + str(queryValue) , time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method='pricingQueryServiceType', shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryServiceTypeList(V3inst, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    response = V3inst.get('/'+RESTV3.urlPrefix+'/pricing/service_types' , time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method='pricingQueryServiceContext', shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryServiceContext(V3inst, serviceQueryType='ServiceTypeId', serviceQueryValue=None, contextQueryType='ContextId', contextQueryValue=None
                               , now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    response = V3inst.get('/'+RESTV3.urlPrefix+'/pricing/service_context/' + str(serviceQueryValue) + '/' + str(contextQueryValue) , time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method='pricingQueryServiceContext', shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryBalanceClass(V3inst, queryType='BalanceClassId', queryValue = None, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    response = V3inst.get('/'+RESTV3.urlPrefix+'/pricing/balance_class/' + str(queryValue) , time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method='pricingQueryBalanceClass', shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryBalanceClassList(V3inst, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    response = V3inst.get('/'+RESTV3.urlPrefix+'/pricing/balance_classes'  , time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method='pricingQueryBalanceClassList', shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryBalanceThresholdList(V3inst,queryType='BalanceId', queryValue = None, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    response = V3inst.get('/'+RESTV3.urlPrefix+'/pricing/balance/' + str(queryValue) + '/thresholds' , time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method='pricingQueryBalanceThresholdList', shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryBillingCycle(V3inst, queryType='BillingCycleId', queryValue = None, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    response = V3inst.get('/'+RESTV3.urlPrefix+'/pricing/billing_cycle/' + str(queryValue) , time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method='pricingQueryBillingCycle', shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryBillingCycleList(V3inst, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    response = V3inst.get('/'+RESTV3.urlPrefix+'/pricing/billing_cycles'  , time=now)

    if validateResponse(response=response, method='pricingQueryBillingCycleList', shouldPass=eventPass):
        return response

#=============================================================
# Query specified catalog and list of items in catalog for
# specified subscription
def subscriberQueryCatalog(V3inst, queryValue=None, queryType=None, catalogQueryValue=None, catalogQueryType=None, now=None, eventPass=True, eligibilityFilter=True, filterName=None, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    if catalogQueryType == "CatalogId":
        catalogQueryType = "PricingId"

    url = '/'+RESTV3.urlPrefix+'/subscription/' + str(queryType) + '+' + str(queryValue) + '/catalog/' + str(catalogQueryType) + '+' + str(catalogQueryValue)
    
    hasQuestionMark=False

    if eligibilityFilter is not None:
        url += '?eligibilityFilter='+str(eligibilityFilter).lower()
        hasQuestionMark=True
    
    if filterName is not None:
        filterUrl=''
        if type(filterName) is list:
            filterSize = len(filterName)
            for counter,item in enumerate(filterName,1):
                if counter < filterSize:
                    filterUrl +='filterName='+item+'&'
                else:
                    filterUrl +='filterName='+item
        else:
            filterUrl='filterName='+filterName
        
        if hasQuestionMark :
            url = url +'&'+filterUrl    
        else:
            url = url +'?'+filterUrl
    
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
# Query specified catalog and list of items in catalog for
# specified device
def deviceQueryCatalog(V3inst, queryValue=None, queryType=None, catalogQueryValue=None, catalogQueryType=None, now=None, eventPass=True, eligibilityFilter=True, filterName=None, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    if catalogQueryType == "CatalogId":
        catalogQueryType = "PricingId"

    url = '/'+RESTV3.urlPrefix+'/device/' + str(queryType) + '+' + str(queryValue) + '/catalog/' + str(catalogQueryType) + '+' + str(catalogQueryValue)

    hasQuestionMark=False

    if eligibilityFilter is not None:
        url += '?eligibilityFilter='+str(eligibilityFilter).lower()
        hasQuestionMark=True
    
    if filterName is not None:
        filterUrl=''
        if type(filterName) is list:
            filterSize = len(filterName)
            for counter,item in enumerate(filterName,1):
                if counter < filterSize:
                    filterUrl +='filterName='+item+'&'
                else:
                    filterUrl +='filterName='+item
        else:
            filterUrl='filterName='+filterName
        
        if hasQuestionMark :
            url = url +'&'+filterUrl    
        else:
            url = url +'?'+filterUrl

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
# Query specified catalog and list of items in catalog for
# specified group
def groupQueryCatalog(V3inst, queryValue=None, queryType=None, catalogQueryValue=None, catalogQueryType=None, now=None, eventPass=True, eligibilityFilter=True, filterName=None, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    if catalogQueryType == "CatalogId":
        catalogQueryType = "PricingId"

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryType) + '+' + str(queryValue) + '/catalog/' + str(catalogQueryType) + '+' + str(catalogQueryValue)

    hasQuestionMark=False
    if eligibilityFilter is not None:
        url += '?eligibilityFilter='+str(eligibilityFilter).lower()
        hasQuestionMark=True
    
    if filterName is not None:
        filterUrl=''
        if type(filterName) is list:
            filterSize = len(filterName)
            for counter,item in enumerate(filterName,1):
                if counter < filterSize:
                    filterUrl +='filterName='+item+'&'
                else:
                    filterUrl +='filterName='+item
        else:
            filterUrl='filterName='+filterName
        
        if hasQuestionMark :
            url = url +'&'+filterUrl    
        else:
            url = url +'?'+filterUrl

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
# Query One Time Offers
def subscriberQueryOneTimeOffer(V3inst, queryValue=None, queryType=None, now=None, eventPass=True, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/subscription/' + str(queryType) + '+' + str(queryValue) + '/cancelable_one_time_offer'
    
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
# Query One Time Offers
def deviceQueryOneTimeOffer(V3inst, queryValue=None, queryType=None, now=None, eventPass=True, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/device/' + str(queryType) + '+' + str(queryValue) + '/cancelable_one_time_offer'

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
# Query One Time Offers
def groupQueryOneTimeOffer(V3inst, queryValue=None, queryType=None, now=None, eventPass=True, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryType) + '+' + str(queryValue) + '/cancelable_one_time_offer'

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
# Query specified catalog and list of items in catalog for
# specified device
#Query Pricing Catalog List
#=============================================================
def pricingQueryCatalogItemList(V3inst, now=None, routingType=None, routingValue=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    url='/'+RESTV3.urlPrefix+'/pricing/CatalogItem'
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)

    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#Query Pricing Catalog Item
#=============================================================
def pricingQueryCatalogItem(V3inst, queryType=None, queryValue=None, now=None,
                            routingType=None, routingValue=None, eventPass=True, multiRequestBuild=None, catalogItemTime=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType == 'CatalogItemId':
        url = '/'+RESTV3.urlPrefix+'/pricing/CatalogItem/PricingId+' + str(queryValue)
    elif queryType == 'ExternalId':
        url='/'+RESTV3.urlPrefix+'/pricing/CatalogItem/ExternalId+' + str(queryValue)
    else:
        url='/'+RESTV3.urlPrefix+'/pricing/CatalogItem/' + str(queryValue)

    if catalogItemTime is not None:
        url +='?catalogItemTime='+str(catalogItemTime)

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)

    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#Query Pricing Catalog List
#=============================================================
def pricingCacheQueryCatalogItemList(V3inst, now=None, routingType=None, routingValue=None, eventPass=True, queryType='CatalogItem', multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url='/'+RESTV3.urlPrefix+'/cache/pricing/'+queryType

    if queryType not in ['CatalogItem', 'catalogItem']:
        print('ERROR: Query CatalogItemList parameter queryType has an unsupported value (' + queryType + ')')

    response = V3inst.get(url, time=now)

    if QAUTILS.DebugLevel > 0: print(funcName + ' url:'+ url+ ' response:\n' + response)
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#Query Pricing Catalog Item
#=============================================================
def pricingCacheQueryCatalogItem(V3inst, queryValue=None, now=None,
                            routingType=None, routingValue=None, eventPass=True, queryType='CatalogItem', multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/cache/pricing/'+queryType+'/' + str(queryValue)

    if queryType not in ['CatalogItem', 'catalogItem']:
        print('ERROR: Query CatalogItem parameter queryType has an unsupported value (' + queryType + ')')

    response = V3inst.get(url, time=now)

    if QAUTILS.DebugLevel > 0: print(funcName + ' url: ' + url +' response:\n' + response)
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#Query Pricing Rate Tag List
#=============================================================
def pricingQueryRateTagList(V3inst, now=None, routingType=None, routingValue=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    url='/'+RESTV3.urlPrefix+'/pricing/rate_tags'
    if routingType and routingValue :
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)

    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#Query Pricing rate tag  
#=============================================================
def pricingQueryRateTag(V3inst, queryType=None, queryValue=None, now=None,
                            routingType=None, routingValue=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    if queryType == 'RateTagId':
        url = '/'+RESTV3.urlPrefix+'/pricing/rate_tag/' + str(queryValue)
    elif queryType == 'ExternalId':
        url='/'+RESTV3.urlPrefix+'/pricing/rate_tag/query/' + str(queryValue)
    else:
        url='/'+RESTV3.urlPrefix+'/pricing/rate_tag/' + str(queryValue)

    if routingType and routingValue :
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)
    
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)

    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryEventTypeList(V3inst, now=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    url='/'+RESTV3.urlPrefix+'/pricing/event_types/'

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)

    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryEventType(V3inst, queryType='EventTypeId', queryValue=None, now=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    url='/'+RESTV3.urlPrefix+'/pricing/event_type/' + str(queryValue)

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)

    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def getDiameterRestConfig():
    QACommon = os.getenv("QADIR") + '/Common/'
    configIniFile = QACommon + 'config.ini'
    if not os.path.exists(configIniFile):
        configIniFile = os.getenv("MYCONFIGINI")
        if not configIniFile == None:
            if not os.path.exists(configIniFile):
                print('cannot find the config ini in ../../Common or env "MYCONFIGINI"')
                sys.exit(1)
        else:
            print('cannot find the config ini in ../../Common or env "MYCONFIGINI"')
            sys.exit(1)

    print('reading configuration data from ' + str(configIniFile) + '!')
    configG = configparser.ConfigParser()
    configG.read(configIniFile)
    return (configG)

#=============================================================
def subscriberPurchaseOfferInFuture(V3inst, queryValue, offerId=None, purchaseStartTime=None, offerStartTime=None,
                      offerEndTime=None, eventPass=True, queryType='ExternalId', now=None,
                      offerIsExternal=False, offerId2=None, attr=None,  skipVtime=False, dupAttr=True,
                      catalogItemId=None, multiRequestBuild=None):
 
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Get subscriber OID if queryType is not ObjectId
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass)
        queryValue = getOID(queryResponse)
 
    profTemplate = subscribeToOffer(V3inst, externalId=queryValue, offerId=offerId, catalogItemId=catalogItemId,
                                    offerStartTime=offerStartTime, offerEndTime=offerEndTime, eventPass=eventPass,
                                    queryType='ObjectId', now=now, offerIsExternal=offerIsExternal, offerId2=offerId2,
                                    attr=attr, dupAttr=dupAttr, future=True)

    profTemplate = RESTHELPER.addTask(purchaseStartTime,profTemplate)  

    url = '/' + RESTV3.urlPrefix
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + str(profTemplate))
        
    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    (success, objectId) = validateResponse(response=response, method=funcName , shouldPass=eventPass, returnParam='ObjectId')
    #print 'Future subscriber purchase ObjectId = ' + str(objectId)
    return objectId

#=============================================================
def subscriberCancelOfferInFuture(V3inst, cancelStartTime, queryType = 'ExternalId', queryValue = 0, resourceIdList = [], skipVtime = False, eventPass=True, multiRequestBuild=None):
        # Get function name
        funcName = QAUTILS.getFunctionName()
    
        return deleteTask(V3inst, resourceIdList, funcName, eventPass)

#=============================================================
def groupPurchaseOfferInFuture(V3inst, queryValue, offerId=None, purchaseStartTime=None, offerStartTime=None,
                      offerEndTime=None, eventPass=True, queryType='ExternalId', now=None,
                      offerIsExternal=False, offerId2=None, attr=None,  skipVtime=False, dupAttr=True,
                      catalogItemId=None, multiRequestBuild=None):
 
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Get subscriber OID if queryType is not ObjectId
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass)
        queryValue = getOID(queryResponse)
 
    profTemplate = groupSubscribeToOffer(V3inst, queryValue, offerId=offerId, catalogItemId=catalogItemId, 
                                    offerStartTime=offerStartTime, offerEndTime=offerEndTime, eventPass=eventPass,
                                    queryType='ObjectId', now=now, offerIsExternal=offerIsExternal, attr=attr,
                                    dupAttr=dupAttr, future=True)

    profTemplate = RESTHELPER.addTask(purchaseStartTime,profTemplate)  

    #print 'profTemplate =', profTemplate
    response = V3inst.post('/' + RESTV3.urlPrefix, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    (success, objectId) = validateResponse(response=response, method=funcName , shouldPass=eventPass, returnParam='ObjectId')
    #print 'Future group purchase ObjectId = ' + str(objectId)
    return objectId

#=============================================================
def groupCancelOfferInFuture(V3inst, cancelStartTime, queryType = 'ExternalId', queryValue = 0, resourceIdList = [], skipVtime = False, eventPass=True, multiRequestBuild=None):
        # Get function name
        funcName = QAUTILS.getFunctionName()
    
        return deleteTask(V3inst, resourceIdList, funcName, eventPass)

#=============================================================
def devicePurchaseOfferInFuture(V3inst, queryValue, offerId=None, purchaseStartTime=None, offerStartTime=None,
                      offerEndTime=None, eventPass=True, queryType='PhoneNumber', now=None,
                      offerIsExternal=False, offerId2=None, attr=None,  skipVtime=False, dupAttr=True,
                      catalogItemId=None, multiRequestBuild=None):
 
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Get OID if queryType is not ObjectId
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, eventPass=eventPass)
        queryValue = getOID(queryResponse)
 
    profTemplate = devicePurchaseOffer(V3inst, queryValue, offerId=offerId, catalogItemId=catalogItemId,
                                    offerStartTime=offerStartTime, offerEndTime=offerEndTime, eventPass=eventPass,
                                    queryType='ObjectId', now=now, offerIsExternal=offerIsExternal, attr=attr,
                                    dupAttr=dupAttr, future=True)

    profTemplate = RESTHELPER.addTask(purchaseStartTime,profTemplate)  

    url = '/' + RESTV3.urlPrefix
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + str(profTemplate))
        
    response = V3inst.post(url, payload=profTemplate)
    #print 'response=',response
    
    (success, objectId) = validateResponse(response=response, method=funcName , shouldPass=eventPass, returnParam='ObjectId')
    #print 'Future device purchase ObjectId = ' + str(objectId)
    return objectId

#=============================================================
def deviceCancelOfferInFuture(V3inst, cancelStartTime, queryType = 'PhoneNumber', queryValue = 0, resourceIdList = [], skipVtime = False, eventPass=True, multiRequestBuild=None):
        # Get function name
        funcName = QAUTILS.getFunctionName()
    
        return deleteTask(V3inst, resourceIdList[1], funcName, eventPass)

#=============================================================
def deleteTask(V3inst, taskId, fcn, eventPass=True, multiRequestBuild=None):
        # Get function name
        funcName = QAUTILS.getFunctionName()
    
        # Get task cancel 
        profTemplate = open(templates + 'task_delete'+RESTV3.fileType).read()

        # Always have an object ID for task deletion
        profTemplate = RESTHELPER.checkIfDefined(taskId, None, 'OBJID', profTemplate, 'ObjectId')
    
        url = '/' + RESTV3.urlPrefix
    
        # Debug output if globally set
        if QAUTILS.DebugLevel > 0:
                print(funcName + ' url: ' + url)
                print(funcName + ' payload:\n' + str(profTemplate))
        
        response = V3inst.post(url, payload=profTemplate)
        #print 'deleteTask response = ' + response
        return validateResponse(response=response, method=fcn, shouldPass=eventPass)

#=============================================================
def multiRequest(V3inst, requests=None, now=None, eventPass=True, routingType=None, routingValue=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    requestMdc = MDCDEFS.kMtxRequestMultiMdcDesc.create()
    if now != None:
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestEventTimeFldKey, now)
    requestMdc.setUsingKey(
        MDCDEFS.kMtxRequestMultiRequestListFldKey, requests)
    requestXml = requestMdc.printElementBasedXml(indentStr='  ')

    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        f = open("/tmp/myMultiRequest.xml", "w")
        f.write(requestXml)
        f.close()
        cmd = 'java -jar /opt/mtx/bin/converter.jar -config:/opt/mtx/data/mdc_config_system.xml -json -in:xml /tmp/myMultiRequest.xml'
        payload=QAUTILS.runCmd(cmd)
        QAUTILS.runCmd('rm -rf /tmp/myMultiRequest.xml')
    else:
        payload=requestXml

    if routingType and routingValue :
        url = '/' + RESTV3.urlPrefix + '?TrafficRouteData='+routingType + str(routingValue)
    else:
        url = '/' + RESTV3.urlPrefix
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + str(payload))
#    print requestXml
        
    response = V3inst.post(url, payload=payload)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    #print response
    return validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='ObjectId')

#=============================================================
def multiRequestSaveResponse(V3inst, requests, now=None, eventPass=True, routingType=None, routingValue=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    requestMdc = MDCDEFS.kMtxRequestMultiMdcDesc.create()
    if now != None:
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestEventTimeFldKey, now)
    requestMdc.setUsingKey(
        MDCDEFS.kMtxRequestMultiRequestListFldKey, requests)
    requestXml = requestMdc.printElementBasedXml(indentStr='  ')

    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        f = open("/tmp/myMultiRequest.xml", "w")
        f.write(requestXml)
        f.close()
        cmd = 'java -jar /opt/mtx/bin/converter.jar -config:/opt/mtx/data/mdc_config_system.xml -json -in:xml /tmp/myMultiRequest.xml'
        payload=QAUTILS.runCmd(cmd)
        QAUTILS.runCmd('rm -rf /tmp/myMultiRequest.xml')
    else:
        payload=requestXml

    if routingType and routingValue :
        url = '/' + RESTV3.urlPrefix + '?TrafficRouteData='+routingType + str(routingValue)
    else:
        url = '/' + RESTV3.urlPrefix
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + str(payload))
        
    response = V3inst.post(url, payload=payload)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    #print response
    return (validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='ObjectId'), response)

#=============================================================
def addSubscriberBatch(V3inst, batchSize, subExternalIdStartIndex, devExternalIdStartIndex, subscriberIdStartIndex, deviceIdStartIndex, deviceType, offerId, startTime=None, endTime=None, now = None, dateOffset=None, multiRequestBuild=None):
    V3builder = QAUTILS.getSubscInterface(mode = 'BuildRequest')

    requests = []
    offerList = []
    offerList.append({'ProductOfferId':offerId, 'StartTime':startTime, 'EndTime':None})
    for i in range (0,batchSize):

        deviceId = str(int(deviceIdStartIndex)+i)
        devExternalId = str(int(devExternalIdStartIndex)+i)
        subExternalId = str(int(subExternalIdStartIndex)+i)
        subscriberId =  str(int(subscriberIdStartIndex)+i)

        createSubscMdc = V3builder.subscriberCreate(externalId = subExternalId)

        deviceCreateMdc =  V3builder.deviceCreateMobile(externalId = devExternalId, imsi = deviceId, deviceType=deviceType)

        subscAddDeviceMdc = V3builder.subscriberAddDevice(
                       subQueryType = 'MultiRequestIndex', subQueryValue = i*4,
                       devQueryType = 'MultiRequestIndex', devQueryValue = (i*4)+1,
                       now = now)

        subscPurchaseOfferMdc = V3builder.subscriberPurchaseOffer(
                       queryType = 'MultiRequestIndex', queryValue = i*4,
                       offerList = offerList, now = now)

        requests = requests + [createSubscMdc, deviceCreateMdc, subscAddDeviceMdc, subscPurchaseOfferMdc]
    multiRequest(V3inst, requests = requests, now = now)

#=============================================================
def modifySubscriberBatch(V3inst, batchSize, queryValueStartIndex, eventPass=True, queryType='ExternalId', now=None,
        firstName=None, lastName=None, contactEmail=None, contactPhoneNumberStartIndex=None, notificationPreference=None,
        timeZone=None, attr=None, billingCycle=None, status=None, taxStatus=None, taxCertificate=None, taxLocation=None, language=None,
        externalIdStartIndex=None, dateOffset=None, multiRequestBuild=None, glCenter=None, billingCycleDisabled=None):
    V3builder = QAUTILS.getSubscInterface(mode = 'BuildRequest')

    requests = []
    for i in range (0,batchSize):
        if contactPhoneNumberStartIndex:
            contactPhoneNumber = str(int(contactPhoneNumberStartIndex)+i)
        else:
            contactPhoneNumber = None
        if externalIdStartIndex:
            externalId = str(int(externalIdStartIndex)+i)
        else:
            externalId = None

        #check if we passed a string for billingCycle and convert it to a billing cycle template
        if billingCycle:
            if type(billingCycle) is not data_container.DataContainer:
                billingCycle = createBillingCycleData(int(billingCycle), startTime=now, dateOffset=dateOffset)

        subscModifyMdc = V3builder.subscriberModify(queryType = queryType, queryValue = str(int(queryValueStartIndex)+i), now=now,
            firstName=firstName, lastName=lastName, contactEmail=contactEmail, contactPhoneNumber=contactPhoneNumber,
            notificationPreference=notificationPreference, timeZone=timeZone, attr=attr, billingCycle=billingCycle,
            status=status, taxStatus=taxStatus, taxCertificate=taxCertificate, taxLocation=taxLocation, language=language, externalId=externalId, glCenter=glCenter, billingCycleDisabled=billingCycleDisabled)
        requests = requests + [subscModifyMdc]

    multiRequest(V3inst, requests = requests, now = now)

#=============================================================
def querySubscriberBatch(V3inst, batchSize, queryValueStartIndex, queryType='ExternalId', querySize=None, eventPass=True, now=None, multiRequestBuild=None):
    V3builder = QAUTILS.getSubscInterface(mode = 'BuildRequest')
    requests = []

    for i in range (0,batchSize):
        subscQueryMdc = V3builder.subscriberQuery(queryType = queryType, queryValue = str(int(queryValueStartIndex)+i))
        requests = requests + [subscQueryMdc]

    multiResult = multiRequestSaveResponse(V3inst, requests = requests, now = now)
    return  QA_MDCDEFS.getMultiRequestResponseList(multiResult[1])

#=============================================================
def deleteSubscriberBatch(V3inst, queryValue, queryType='ExternalId', deleteDevices=False, eventPass=True, now=None, multiRequestBuild=None):

    if type(queryValue) == str :
        ids = queryValue.split(',')
    else :
        ids = queryValue

    if V3inst == None:
        V3builder = QAUTILS.getSubscInterfaceMDC(mode = 'BuildRequest')

    requests = []

    for i in ids:
        deleteSubMdc = V3builder.subscriberDelete(queryType = queryType, queryValue = i)
        requests.append(deleteSubMdc)

    if V3inst == None:
        restInst = QAUTILS.getSubscInterfaceMDC()
    multiResult = multiRequestSaveResponse(restInst, requests = requests, now = now)

    if V3inst == None:
        return multiResult[1].getUsingKey(MDCDEFS.kMtxResponseMultiResponseListFldKey)
    else:
        return  QA_MDCDEFS.getMultiRequestResponseList(multiResult[1])

#============================================================
def querySubscriberEvent(V3inst, queryValue, queryType='ExternalId', deviceQueryType=None, deviceQueryValue=None,
    querySize=None, queryCursor=None, eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypeStringArray =None, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Some parameters should be lists of strings
    if eventTypeStringArray:
        if type(eventTypeStringArray) is list:  eventTypeStringArray = [str(i) for i in eventTypeStringArray]
        else:                                   eventTypeStringArray = [str(eventTypeStringArray)]
    
    # Translate subscriber to OID if needed
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)
        if not eventPass and queryValue is None : 
            queryValue = "9-9-9-9"

    # Translate device to OID if needed
    if deviceQueryType and deviceQueryValue and deviceQueryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=deviceQueryValue, queryType=deviceQueryType, now=now)
        deviceQueryValue = getOID(queryResponse)

    # Assume optional parameters in the URL
    amp = False
    delim = '?'
    # Build the URL
    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + queryValue + '/events'
    if deviceQueryValue: url += '/' + deviceQueryValue

    if querySize is not None:
        url += delim + 'querySize=' + str(querySize)
        amp = True
        delim = '&'
    if queryCursor is not None:
        url += delim + 'queryCursor=' + str(queryCursor)
        amp = True
        delim = '&'
    if eventTimeLowerBound is not None:
        url += delim + 'eventTimeLowerBound=' + convertTimeToUrlFormat(eventTimeLowerBound)
        amp = True
        delim = '&'
    if eventTimeUpperBound is not None:
        url += delim + 'eventTimeUpperBound=' + convertTimeToUrlFormat(eventTimeUpperBound)
        amp = True
        delim = '&'
    if eventTypeStringArray is not None:
        url += delim + 'eventTypes=' + ",".join(eventTypeStringArray)
        amp = True
        delim = '&'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    # Make the REST call
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    (result, cursor) = validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='queryCursor')
    if result : return (response,cursor)
    
#=============================================================
# No device event store query.  Map to device event query (nothing better to do except fail...).
def queryDeviceEventstore(V3inst, queryValue, queryType='ExternalId', resultSize=None,
    eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypes=None, notificationTypes=None, notification=False,
    now=None, eventPass=True, multiRequestBuild=None):
        # Call device event API
        (response, cursor) = queryDeviceEvent(V3inst, queryValue, queryType=queryType, querySize=resultSize, queryCursor = None,
                eventTimeLowerBound=eventTimeLowerBound, eventTimeUpperBound=eventTimeUpperBound, eventTypeStringArray=eventTypes,
                now=now, eventPass=eventPass)
    
        return response
#=============================================================
def querySubscriberEventstore(V3inst, queryValue=None, queryType='ExternalId', resultSize=None, deviceQueryType=None, deviceQueryValue=None, 
    eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypes=None, notificationTypes=None, notification=False,searchInMemoryDatabase=True,
    applyDefaultFilter=True, routingType=None, routingValue=None, now=None, eventPass=True, multiRequestBuild=None, formatTime=True):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Some parameters should be lists of strings
    if eventTypes:
        if type(eventTypes) is list:    eventTypes = [str(i) for i in eventTypes]
        else:                           eventTypes = [str(eventTypes)]
    if notificationTypes:
        if type(notificationTypes) is list:     notificationTypes = [str(i) for i in notificationTypes]
        else:                                   notificationTypes = [str(notificationTypes)]
    
    # Translate device to PhoneNumber if needed
    if deviceQueryType and deviceQueryValue:
     if deviceQueryType in ['ObjectId', 'ExternalId']:
        # Warn user that for now we can't support this (commented out code below)
        print('WARNING: ' + funcName + ': Current code doesns\';t handle device information passed in other than AccessNumber or PhoneNumber.')
        
        # If subscriber data not passed in then we have an issue...
        if not (queryValue and queryType): sys.exit('ERROR: Either queryValue or queryType is not set so can\'t use subscriber infor for this call')
        
        '''
        queryResponse = queryDevice(V3inst=V3inst, queryValue=deviceQueryValue, queryType=deviceQueryType, now=now)
        queryType = 'PhoneNumber'
        queryValue = getIMSI(queryResponse)
        print 'Returned IMSI ' + queryValue
        '''
     else:
        queryType = deviceQueryType
        queryValue = deviceQueryValue

    '''
    # Translate subscriber to OID if needed
    # NOTE NEEDED as we can use the query type in the URL.
    elif queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)
        if not eventPass and queryValue is None :
            queryValue = "9-9-9-9"
    '''

    # Assume optional parameters in the URL
    amp = False
    delim = '?'
    # Build the URL
    if notification:
        url = '/'+RESTV3.urlPrefix+'/eventstore/notification/'+RESTV3.subUrl+'/' + queryType + '+' + queryValue
    else:
        url = '/'+RESTV3.urlPrefix+'/eventstore/'+RESTV3.subUrl+'/' + queryType + '+' + queryValue

    if resultSize is not None:
        url += delim + 'resultSize=' + str(resultSize)
        amp = True
        delim = '&'
    if eventTypes is not None:
        url += delim + 'eventTypes=' + ",".join(eventTypes)
        amp = True
        delim = '&'
    if notificationTypes is not None:
        url += delim + 'notificationTypes=' + ",".join(notificationTypes)
        amp = True
        delim = '&' 
    if eventTimeLowerBound is not None:
        if formatTime:
            url += delim + 'eventTimeLowerBound=' + convertTimeToUrlFormat(eventTimeLowerBound)
        else: 
            url += delim + 'eventTimeLowerBound=' + eventTimeLowerBound
        amp = True
        delim = '&'
    if eventTimeUpperBound is not None:
        if formatTime:
            url += delim + 'eventTimeUpperBound=' + convertTimeToUrlFormat(eventTimeUpperBound)
        else:
            url += delim + 'eventTimeUpperBound=' + eventTimeUpperBound
        amp = True
        delim = '&'
    if not applyDefaultFilter:
        url += delim + 'applyDefaultFilter=false'
        amp = True
        delim = '&'
    if not searchInMemoryDatabase:
        url += delim + 'searchInMemoryDatabase=false'
        amp = True
        delim = '&'
    if routingType and routingValue :
        url += delim + 'TrafficRouteData=' + str(routingType) + str(routingValue)
        amp = True
        delim = '&'


    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    # Make the REST call
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    result = validateResponse(response=response, method=funcName, shouldPass=eventPass)
    if result : return response

#=============================================================
def queryGroupEvent(V3inst, queryValue, queryType='ExternalId', querySize=None, queryCursor = None,
    eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypeStringArray=None, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Some parameters should be lists of strings
    if eventTypeStringArray:
        if type(eventTypeStringArray) is list:  eventTypeStringArray = [str(i) for i in eventTypeStringArray]
        else:                                   eventTypeStringArray = [str(eventTypeStringArray)]
    
    # Translate subscriber to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)
    
    # Assume optional parameters in the URL
    amp = False
    delim = '?'
    
    if not eventPass : queryValue = "9-9-9-9"
    # Build the URL
    url = '/'+RESTV3.urlPrefix+'/group/' + queryValue + '/events'
    if querySize is not None:
        url += delim + 'querySize=' + str(querySize)
        amp = True
        delim = '&'
    if queryCursor is not None:
        url += delim + 'queryCursor=' + str(queryCursor)
        amp = True
        delim = '&'
    if eventTimeLowerBound is not None:
        url += delim + 'eventTimeLowerBound=' + convertTimeToUrlFormat(eventTimeLowerBound)
        amp = True
        delim = '&'
    if eventTimeUpperBound is not None:
        url += delim + 'eventTimeUpperBound=' + convertTimeToUrlFormat(eventTimeUpperBound)
        amp = True
        delim = '&'
    if eventTypeStringArray is not None:
        url += delim + 'eventTypes=' + ",".join(eventTypeStringArray)
        amp = True
        delim = '&'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    # Make the REST call
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    (result, cursor) =  validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='queryCursor')
    if result: return (response, cursor)
    
#=============================================================
def queryGroupEventstore(V3inst, queryValue, queryType='ExternalId', resultSize=None,
    eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypes=None, notificationTypes=None, notification=False,searchInMemoryDatabase=True,
    applyDefaultFilter=True, routingType=None, routingValue=None, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Some parameters should be lists of strings
    if eventTypes:
        if type(eventTypes) is list:    eventTypes = [str(i) for i in eventTypes]
        else:                           eventTypes = [str(eventTypes)]
    if notificationTypes:
        if type(notificationTypes) is list:     notificationTypes = [str(i) for i in notificationTypes]
        else:                                   notificationTypes = [str(notificationTypes)]
    
    # Translate subscriber to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)

    # Assume optional parameters in the URL
    amp = False
    delim = '?'

    if not eventPass : queryValue = "9-9-9-9"
    # Build the URL
    if notification:
        url = '/'+RESTV3.urlPrefix+'/eventstore/notification/group/' + queryValue
    else:
        url = '/'+RESTV3.urlPrefix+'/eventstore/group/' + queryValue

    if resultSize is not None:
        url += delim + 'resultSize=' + str(resultSize)
        amp = True
        delim = '&'
    if eventTypes is not None:
        url += delim + 'eventTypes=' +  ",".join(eventTypes)
        amp = True
        delim = '&'
    if notificationTypes is not None:
        url += delim + 'notificationTypes=' +  ",".join(notificationTypes)
        amp = True
        delim = '&'
    if eventTimeLowerBound is not None:
        url += delim + 'eventTimeLowerBound=' + convertTimeToUrlFormat(eventTimeLowerBound)
        amp = True
        delim = '&'
    if eventTimeUpperBound is not None:
        url += delim + 'eventTimeUpperBound=' + convertTimeToUrlFormat(eventTimeUpperBound)
        amp = True
        delim = '&'
    if not applyDefaultFilter:
        url += delim + 'applyDefaultFilter=false'
        amp = True
        delim = '&'
    if not searchInMemoryDatabase:
        url += delim + 'searchInMemoryDatabase=false'
        amp = True
        delim = '&'
    if routingType and routingValue :
        url += delim + 'TrafficRouteData=' + str(routingType) + str(routingValue)
        amp = True
        delim = '&'
 

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    # Make the REST call
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    
    result =  validateResponse(response=response, method=funcName, shouldPass=eventPass)
    if result: return response

#=============================================================
def queryEventstore(V3inst,  resultSize=None, eventTimeLowerBound=None, eventTimeUpperBound=None, applyDefaultFilter=True, routingType=None, searchInMemoryDatabase=True,
                    routingValue=None, eventTypes=None,now=None, eventPass=True, multiRequestBuild=None, formatTime=True):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Some parameters should be lists of strings
    if eventTypes:
        if type(eventTypes) is list:    eventTypes = [str(i) for i in eventTypes]
        else:                           eventTypes = [str(eventTypes)]
    
    # Assume optional parameters in the URL
    amp = False
    delim = '?'
    
    url = '/'+RESTV3.urlPrefix+'/eventstore/query'

    if resultSize is not None:
        url += delim + 'resultSize=' + str(resultSize)
        amp = True
        delim = '&'
    if eventTypes is not None:
        url += delim + 'eventTypes=' + ",".join(eventTypes)
        amp = True
        delim = '&'
    if eventTimeLowerBound is not None:
        if formatTime:
            url += delim + 'eventTimeLowerBound=' + convertTimeToUrlFormat(eventTimeLowerBound)
        else: 
            url += delim + 'eventTimeLowerBound=' + eventTimeLowerBound
        amp = True
        delim = '&'
    if eventTimeUpperBound is not None:
        if formatTime:
            url += delim + 'eventTimeUpperBound=' + convertTimeToUrlFormat(eventTimeUpperBound)
        else:
            url += delim + 'eventTimeUpperBound=' + eventTimeUpperBound
        amp = True
        delim = '&'
    if not applyDefaultFilter:
        url += delim + 'applyDefaultFilter=false'
        amp = True
        delim = '&'
    if not searchInMemoryDatabase:
        url += delim + 'searchInMemoryDatabase=false'
        amp = True
        delim = '&'
    if routingType and routingValue :
        url += delim + 'TrafficRouteData=' + str(routingType) + str(routingValue)
        amp = True
        delim = '&'
 
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    # Make the REST call
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    result =  validateResponse(response=response, method=funcName, shouldPass=eventPass)
    if result: return response

#=============================================================
def queryEventstoreById(V3inst, queryValue, queryType = 'EventId', applyDefaultFilter=True, routingType=None, routingValue=None,searchInMemoryDatabase=True,
                         eventPass=True, now=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    amp = False
    delim = '?'
 
    url = '/'+RESTV3.urlPrefix+'/eventstore/query/EventId/'+queryValue
    if not applyDefaultFilter:
        url += delim + 'applyDefaultFilter=false'
        amp = True
        delim = '&'
    if not searchInMemoryDatabase:
        url += delim + 'searchInMemoryDatabase=false'
        amp = True
        delim = '&'
    if routingType and routingValue :
        url += delim + 'TrafficRouteData=' + str(routingType) + str(routingValue)
        amp = True
        delim = '&'
     

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url  , time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def queryUserEventstore(V3inst, queryValue=None, queryType='ExternalId', resultSize=None, 
    eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypes=None, notificationTypes=None, notification=False,searchInMemoryDatabase=True,
    applyDefaultFilter=True, routingType=None, routingValue=None, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    # Some parameters should be lists of strings
    if eventTypes:
        if type(eventTypes) is list:    eventTypes = [str(i) for i in eventTypes]
        else:                           eventTypes = [str(eventTypes)]
    if notificationTypes:
        if type(notificationTypes) is list:     notificationTypes = [str(i) for i in notificationTypes]
        else:                                   notificationTypes = [str(notificationTypes)]


    # Assume optional parameters in the URL
    amp = False
    delim = '?'
    # Build the URL
    if notification:
        url = '/'+RESTV3.urlPrefix+'/eventstore/notification/user/' + queryType + '+' + queryValue
    else:
        url = '/'+RESTV3.urlPrefix+'/eventstore/user/' + queryType + '+' + queryValue

    if resultSize is not None:
        url += delim + 'resultSize=' + str(resultSize)
        amp = True
        delim = '&'
    if eventTypes is not None:
        url += delim + 'eventTypes=' + ",".join(eventTypes)
        amp = True
        delim = '&'
    if notificationTypes is not None:
        url += delim + 'notificationTypes=' + ",".join(notificationTypes)
        amp = True
        delim = '&'
    if eventTimeLowerBound is not None:
        url += delim + 'eventTimeLowerBound=' + convertTimeToUrlFormat(eventTimeLowerBound)
        amp = True
        delim = '&'
    if eventTimeUpperBound is not None:
        url += delim + 'eventTimeUpperBound=' + convertTimeToUrlFormat(eventTimeUpperBound)
        amp = True
        delim = '&'
    if not applyDefaultFilter:
        url += delim + 'applyDefaultFilter=false'
        amp = True
        delim = '&'
    if not searchInMemoryDatabase:
        url += delim + 'searchInMemoryDatabase=false'
        amp = True
        delim = '&'
    if routingType and routingValue :
        url += delim + 'TrafficRouteData=' + str(routingType) + str(routingValue)
        amp = True
        delim = '&'


    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    # Make the REST call
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    result = validateResponse(response=response, method=funcName, shouldPass=eventPass)
    if result : return response


#============================================================
def querySubDomains(V3inst, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/'+RESTV3.urlPrefix+'/service/subDomains'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    # Make the REST call
    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return response

#=============================================================
def serviceGroupQuery(V3inst, queryValue, queryType='ObjectId', querySize=None, queryCursor=None, returnType=None,
                      now=None, eventPass=True, multiRequestBuild=None):
    funcName = QAUTILS.getFunctionName() + str(returnType).capitalize()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)

    url = '/'+RESTV3.urlPrefix+'/service/group/' + str(queryValue)
    if returnType in ['administrators', 'subgroups', 'subscribers']:
        url += '/' + str(returnType)

        # Assume optional parameters in the URL
        amp = False
        delim = '?'

        if querySize is not None:
            url += delim + 'querySize=' + str(querySize)
            amp = True
            delim = '&'
        if queryCursor is not None:
            url += delim + 'queryCursor=' + str(queryCursor)
            amp = True
            delim = '&'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    # Make the REST call
    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return response

#=============================================================
def serviceGroupAddRemoveMembers(V3inst, queryValue, queryType='ObjectId', subscribers=None, administrators=None, groups=None,
                           addRemove='add', apiEventData=None, now=None, eventPass=True, executeMode=None, multiRequestBuild=None):
    funcName = QAUTILS.getFunctionName()

    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)

    subscriberStr = ''
    groupStr = ''
    administratorStr = ''

    if RESTV3.fileType == '.json': 
        delim1 = ''
        delim2 = ', '
    else:
        delim1 = '<value>'
        delim2 = '</value>'

    if type(subscribers) is list:
        for value in subscribers:
            subscriberStr += delim1 + str(value) + delim2
    elif subscribers:
        subscriberStr = delim1 + str(subscribers) + delim2

    if type(groups) is list:
        for value in groups:
            groupStr += delim1 + str(value) + delim2
    elif groups:
        groupStr = delim1 + str(groups) + delim2

    if type(administrators) is list:
        for value in administrators:
            administratorStr += delim1 + str(value) + delim2
    elif administrators:
        administratorStr = delim1 + str(administrators) + delim2

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates + 'manage_group_membership'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(executeMode, None, 'EXECUTEMODE', profTemplate, 'ExecuteMode')
    profTemplate = RESTHELPER.checkIfDefined(subscriberStr, '', 'SUBSCRIBERS', profTemplate, 'SubscriberArray')
    profTemplate = RESTHELPER.checkIfDefined(groupStr, '', 'GROUPS', profTemplate, 'GroupArray')
    profTemplate = RESTHELPER.checkIfDefined(administratorStr, '', 'ADMINISTRATORS', profTemplate, 'AdministratorArray')

    url = '/'+RESTV3.urlPrefix+'/service/group/' + str(queryValue)
    if addRemove =='remove':
        url += '/remove_members'
    else:
        url += '/add_members'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if not validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return False

    return True

#=============================================================
def serviceGroupQueryMemberBalance(V3inst, queryValue, queryType='ObjectId', resourceId=None, now=None, eventPass=True, querySize=None, memberCursor=None, subGroupCursor=None, multiRequestBuild=None):

    funcName = QAUTILS.getFunctionName()

    url = '/'+RESTV3.urlPrefix+'/service/group/' + str(queryType) + '+' + str(queryValue) + '/memberbalance/' + str(resourceId)

    delim = '?'

    if querySize is not None:
        url += delim + 'querySize=' + str(querySize)
        delim = '&'
    if memberCursor is not None:
        url += delim + 'subscriptionCursor=' + str(memberCursor)
        delim = '&'
    if subGroupCursor is not None:
        url += delim + 'subGroupCursor=' + str(subGroupCursor)
        delim = '&'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    # Make the REST call
    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return response

#=============================================================
def serviceSubscriptionQueryGroups(V3inst, queryValue, queryType='ObjectId', now=None, eventPass=True,
                                  querySize=None, queryCursor=None, multiRequestBuild=None):

    funcName = QAUTILS.getFunctionName()

    url = '/'+RESTV3.urlPrefix+'/service/subscription/' + str(queryType) + '+' + str(queryValue) + '/groups'

    delim = '?'

    if querySize is not None:
        url += delim + 'querySize=' + str(querySize)
        delim = '&'
        amp=True
    if queryCursor is not None:
        url += delim + 'queryCursor=' + str(queryCursor)
        amp=True

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    # Make the REST call
    response = V3inst.get(url, amp=amp, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    (result, cursor) =  validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='queryCursor')
    if result: return (response, cursor)

#============================================================
def serviceQuerySubscription(V3inst, queryValue, queryType='ObjectId', now=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/'+RESTV3.urlPrefix+'/service/subscription/' + str(queryType) + '+' + str(queryValue)
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    # Make the REST call
    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return response


#============================================================
def serviceQueryDevice(V3inst, queryValue, queryType='ObjectId', now=None, eventPass=True, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/'+RESTV3.urlPrefix+'/service/device/' + str(queryType) + '+' + str(queryValue)
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    # Make the REST call
    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    return response

#============================================================
def convertTimeToUrlFormat(timeData):
        usec = '.000000'

        # Input may not contain usec, which this function expects
        if not timeData.count('.'):
                # Add before timezone information
                for key in ['+', '-']:
                        if timeData[-6] == key: timeData = timeData[:-6] + usec + timeData[-6:]
                if timeData[-1].lower() == 'z': timeData = timeData[:-1] + usec + timeData[-1]
        
        # Change colon to URL equivalent characters and split time from remainder (msec + tzone)
        timeData = timeData.split(".")
        
        # Get time part sans (msec + tzone)
        timeString = timeData[0]
        
        # Want to get rid of msec part.  It might not be there...
        if len(timeData) == 1: return timeString
        
        # Add time zone if included (looking at remainder of input).
        #print "timeData = " + str(timeData)
        tzone = timeData[1].split('+')
        if len(tzone) > 1: timeString += '+' + tzone[1]
        tzone = timeData[1].split('-')
        if len(tzone) > 1: timeString += '-' + tzone[1]
        
        return timeString
        
#============================================================
def queryDeviceEvent(V3inst, queryValue, queryType='ExternalId', querySize=None, queryCursor = None,
    eventTimeLowerBound=None, eventTimeUpperBound=None, eventTypeStringArray=None, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Some parameters should be lists of strings
    if eventTypeStringArray:
        if type(eventTypeStringArray) is list:  eventTypeStringArray = [str(i) for i in eventTypeStringArray]
        else:                                   cweventTypeStringArrayeventTypes = [str(eventTypeStringArray)]
    
    # Translate subscriber to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)
        if not eventPass and queryValue is None : 
            queryValue = "9-9-9-9"

    # Default optional parameters not in the URL
    amp = False
    delim = '?'
    # Build the URL
    url = '/'+RESTV3.urlPrefix+'/device/' + queryValue + '/events'
    
    if querySize is not None:
        url += delim + 'querySize=' + str(querySize)
        amp = True
        delim = '&'
    if queryCursor is not None:
        url += delim + 'queryCursor=' + str(queryCursor)
        amp = True
        delim = '&'
    if eventTypeStringArray is not None:
        url += delim + 'eventTypes=' + ",".join(eventTypeStringArray)
        amp = True
        delim = '&'
    if eventTimeLowerBound is not None:
        url += delim + 'eventTimeLowerBound=' + convertTimeToUrlFormat(eventTimeLowerBound)
        amp = True
        delim = '&'
    if eventTimeUpperBound is not None:
        url += delim + 'eventTimeUpperBound=' + convertTimeToUrlFormat(eventTimeUpperBound)
        amp = True
        delim = '&'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    # Make the REST call
    response = V3inst.get(url, time=now, amp=amp)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    (result, cursor) = validateResponse(response=response, method=funcName, shouldPass=eventPass, returnParam='queryCursor')
    if result : return (response,cursor)
    
#=============================================================
def queryDeviceAggregation(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Translate subscriber to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)
        if queryValue is None : queryValue = '9-9-9-9'

    # Build the URL
    url = '/'+RESTV3.urlPrefix+'/device/' + queryValue + '/aggregation'
   
    # Make the REST call
    response = V3inst.get(url, time=now, amp=False)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method='queryDeviceAggregation', shouldPass=eventPass): return response

#=============================================================
def querySubscriberAggregation(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Translate subscriber to OID if needed
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)
        if queryValue is None : queryValue = '9-9-9-9'

    # Build the URL
    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + queryValue + '/aggregation'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    # Make the REST call
    response = V3inst.get(url, time=now, amp=False)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method=funcName, shouldPass=eventPass): return response

#=============================================================
def eventQuery(V3inst, queryValue, queryType = 'EventId', eventPass=True, now=None, multiRequestBuild=None):

    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    url = '/'+RESTV3.urlPrefix+'/event/query/EventId/'+queryValue
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.get(url  , time=now, amp=False)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def queryDeviceSession(V3inst, queryValue, queryType='Imsi', eventPass=True, now=None, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Translate device to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)
        if queryValue is None : queryValue = '0-1-5-999'

    # Build the URL
    url = '/'+RESTV3.urlPrefix+'/device/' + queryValue + '/session'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    # Make the REST call
    response = V3inst.get(url, time=now, amp=False)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method=funcName, shouldPass=eventPass): return response

#=============================================================
def validateDeviceSession(V3inst, queryValue, queryType='Imsi', sessionId=None, sessionType=None, eventPass=True, now=None, multiRequestBuild=None):
    global templates
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Translate device to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)
        if queryValue is None : queryValue = '0-1-5-999'
    
    # Define base URL string
    url = '/'+RESTV3.urlPrefix+'/device/' + queryValue + '/session/validate'
    
    # Adjust session ID if only numbers passed in
    if sessionId is not None and sessionId.isdigit():
        # Need proper session prefix.  Usually nothing specified or Gy, so check that first.  Gy also a catch-all for invalid values.
        if not sessionType or sessionType == '1': sessionId = cd.GySessionIdPrefix + sessionId
        elif sessionType == '2':                  sessionId = cd.SySessionIdPrefix + sessionId
        elif sessionType == '3':                  sessionId = cd.GxSessionIdPrefix + sessionId
        else:
                print('WARNNING:  validateDeviceSession() invalid value passed in for sessionType: ' + str(sessionType) + '.  Defaulting to Gy.')
                sessionId = cd.GySessionIdPrefix + sessionId

    # Add rest of URL - mutually exclusive parameters
    if   sessionId is not None:         url += '?sessionId=' + str(sessionId)
    elif sessionType is not None :      url += '?sessionType=' + str(sessionType)
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.post(url, payload=None)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    return validateResponse(response=response, method=funcName, shouldPass=eventPass)


#=============================================================
def deviceEvaluateSyPolicy(V3inst, queryValue ,queryType='Imsi',  now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Translate device to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)
        if queryValue is None : queryValue = '0-1-5-999'

    # Build the URL
    url = '/'+RESTV3.urlPrefix+'/device/' + queryValue + '/policycounter'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    # Make the REST call
    response = V3inst.get(url, time=now, amp=False)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method=funcName, shouldPass=eventPass): return response

#=============================================================
def deleteDeviceSession(V3inst, queryValue, queryType='Imsi', sessionIdList=None, sessionType=None, now=None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # Translate device to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now, eventPass=eventPass)
        queryValue = getOID(queryResponse)
        if queryValue is None : queryValue = '0-1-5-999'

    # Define base URL string
    url = '/'+RESTV3.urlPrefix+'/device/' + queryValue + '/session'
    
    # NOTE:  need to support multiple session IDs (need REST syntax)
    sessionId = "" 
    #check if session is list, parse the session and add & to each session Id
    #the url will be like /'+RESTV3.urlPrefix+'/device/1-2-3-4/session?sessionId=X&sessionId=Y&sessionId=Z
    if type(sessionIdList) is list: 
      #skip to add sessionId= to the first element
      sessionId += str(sessionIdList[0]) +'&'
      for i in sessionIdList[1:]:
             sessionId += 'sessionId='+str(i) +'&'
      #trim the extra & at the end
      sessionId = sessionId.rstrip('&')
    else:
      sessionId = sessionIdList
  
    # Adjust session ID if only numbers passed in
    if sessionId is not None and sessionId.isdigit():
        # Need proper session prefix.  Usually nothing specified or Gy, so check that first.  Gy also a catch-all for invalid values.
        if not sessionType or sessionType == '1': sessionId = cd.GySessionIdPrefix + sessionId
        elif sessionType == '2':                  sessionId = cd.SySessionIdPrefix + sessionId
        elif sessionType == '3':                  sessionId = cd.GxSessionIdPrefix + sessionId
        elif sessionType == '4':                  sessionId = cd.RxSessionIdPrefix + sessionId
        else:
                print('WARNNING:  deleteDeviceSession() invalid value passed in for sessionType: ' + str(sessionType) + '.  Defaulting to Gy.')
                sessionId = cd.GySessionIdPrefix + sessionId

    # Add rest of URL - mutually exclusive parameters
    if sessionId is not None :          url += '?sessionId='+str(sessionId)
    elif sessionType is not None :      url += '?sessionType='+str(sessionType)
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.delete(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method=funcName, shouldPass=eventPass): return response

#=============================================================
def queryNotificationProfile(V3inst, queryType='NotifictionProfileId', queryValue = None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    url = '/'+RESTV3.urlPrefix+'/pricing/notificationProfile/' + str(queryValue)
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def pricingCacheBalanceTemplates(V3inst, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    url = '/'+RESTV3.urlPrefix+'/cache/pricing/balance'
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def pricingCacheBalanceId(V3inst, balanceId = None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    url = '/'+RESTV3.urlPrefix+'/cache/pricing/balance/' + str(balanceId)
    
    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
    
    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)
    

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def customURLCall(V3inst, url, payload=None, operation='get', eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    
    # If Debug if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ':')
        print('url: ' + url)
        print('operation: ' + operation)
        print('payload: ' + str(payload))
        
    # Build the command start
    cmd = 'response = V3inst.' + operation.lower() + '(url'
    
    # Add payload if specified
    if payload: cmd += ', payload=payload'
    
    # Close the command
    cmd += ')'
    
    # Execute the command
    exec(cmd)
    
    # Debug output
    if QAUTILS.DebugLevel > 0: print(funcName + 'response: ' + response)
    
    #print response
    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def queryEventStreamingSessionList(V3inst, routingType = None, routingValue = None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()


    url = '/'+RESTV3.urlPrefix+'/stream_info'
    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType+str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        sessionIdList = getEventStreamingSessionIdList(response)
        return (response, sessionIdList)

#=============================================================
def queryEventStreamingSession(V3inst, queryValue, routingType = None, routingValue = None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/'+RESTV3.urlPrefix+'/stream_info/' + queryValue
    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType+str(routingValue)

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        sessionId = getEventStreamingSessionId(response)
        streamCursor = getEventStreamingSessionCursor(response)
        return (response, sessionId, streamCursor)

#=============================================================
def createEventStreamingSession(V3inst, sessionId, streamCursor = None, routingType = None, routingValue = None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/'+RESTV3.urlPrefix+'/stream_info/' + sessionId
    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType+str(routingValue)


    profTemplate = open(templates + 'event_streaming_create_session'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(streamCursor, None, 'STREAMCURSOR', profTemplate, 'StreamCursor')


    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)


    response = V3inst.post(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def modifyEventStreamingSession(V3inst, queryValue, streamCursor, routingType = None, routingValue = None, eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/'+RESTV3.urlPrefix+'/stream_info/'+queryValue
    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType+str(routingValue)


    profTemplate = open(templates + 'event_streaming_modify_session'+RESTV3.fileType).read()
    profTemplate = RESTHELPER.checkIfDefined(streamCursor, None, 'STREAMCURSOR', profTemplate, 'StreamCursor')


    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)


    response = V3inst.put(url, payload=profTemplate)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def deleteEventStreamingSession(V3inst, sessionId, routingType = None, routingValue = None,  eventPass=True, multiRequestBuild=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()

    url = '/'+RESTV3.urlPrefix+'/stream_info/' + sessionId
    if routingType and routingValue:
        url += '?TrafficRouteData='+routingType+sessionId

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.delete(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def subscriberMakeFinanceContractPrincipalPayment(V3inst, queryValue, offerResourceId, queryType = 'ExternalId',
    isPayoff=True, extraPrincipalAmount=None, paymentMethodResourceId=None, chargeMethod=None, apiEventData=None,
    paymentGatewayId=None, nonce=None, chargeMethodAttr=None, reason=None, info=None, now=None, eventPass=True, multiRequestBuild=None):
    #Get function Name
    funcName = QAUTILS.getFunctionName()

    # Translate subscriber to OID if needed
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates  + 'subscriber_additional_principal_payment'+RESTV3.fileType).read()

    profTemplate = RESTHELPER.checkIfDefined(offerResourceId, None, 'RESOURCEID', profTemplate, 'ResourceId')
    profTemplate = RESTHELPER.checkIfDefined(isPayoff, None, 'ISPAYOFF', profTemplate, 'IsPayoff')
    profTemplate = RESTHELPER.checkIfDefined(extraPrincipalAmount, None, 'EXTRAPRINCIPALAMOUNT', profTemplate, 'ExtraPrincipalAmount')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    if chargeMethod or paymentMethodResourceId or paymentGatewayId or nonce or chargeMethodAttr:
        chargeMethodData = createChargeMethodData(chargeMethod=chargeMethod, paymentMethodResourceId=paymentMethodResourceId,
                                                  paymentGatewayId=paymentGatewayId, paymentGatewayUserId=paymentGatewayUserId,
                                                  paymentGatewayOneTimeToken=paymentGatewayOneTimeToken, chargeMethodAttr=chargeMethodAttrStr)
    else:
        chargeMethodData = None
    profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')

    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/contract/' + str(offerResourceId) + '/payment'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)


    return validateResponse(response=response, method=funcName, shouldPass=eventPass)

#=============================================================
def groupMakeFinanceContractPrincipalPayment(V3inst, queryValue, offerResourceId, queryType = 'ExternalId',
    isPayoff=True, extraPrincipalAmount=None, paymentMethodResourceId=None, chargeMethod=None, apiEventData=None,
    paymentGatewayId=None, nonce=None, chargeMethodAttr=None, reason=None, info=None, now=None, eventPass=True, multiRequestBuild=None):
    #Get function Name
    funcName = QAUTILS.getFunctionName()

    chargeMethodAttrStr = None
    if chargeMethodAttr is not None:
        chargeMethodAttrStr = parseAttrMdc(chargeMethodAttr)

    # Translate group to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates  + 'group_additional_principal_payment'+RESTV3.fileType).read()

    profTemplate = RESTHELPER.checkIfDefined(offerResourceId, None, 'RESOURCEID', profTemplate, 'ResourceId')
    profTemplate = RESTHELPER.checkIfDefined(isPayoff, None, 'ISPAYOFF', profTemplate, 'IsPayoff')
    profTemplate = RESTHELPER.checkIfDefined(extraPrincipalAmount, None, 'EXTRAPRINCIPALAMOUNT', profTemplate, 'ExtraPrincipalAmount')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    if chargeMethod or paymentMethodResourceId or paymentGatewayId or nonce or chargeMethodAttr:
        chargeMethodData = createChargeMethodData(chargeMethod=chargeMethod, paymentMethodResourceId=paymentMethodResourceId,
                                                  paymentGatewayId=paymentGatewayId, paymentGatewayOneTimeToken=nonce,
                                                  chargeMethodAttr=chargeMethodAttrStr)
    else:
        chargeMethodData = None
    profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')


    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/contract/' + str(offerResourceId) + '/payment'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)


    return validateResponse(response=response, method=funcName, shouldPass=eventPass)



#=============================================================
def subscriberContractDebtPayment(V3inst, queryValue, offerResourceId, amount, queryType = 'ExternalId', paymentMethodResourceId=None, chargeMethod=None,
    paymentGatewayId=None, nonce=None, chargeMethodAttr=None, reason=None, info=None, apiEventData=None, now=None, eventPass=True, multiRequestBuild=None):
    #Get function Name
    funcName = QAUTILS.getFunctionName()

    chargeMethodAttrStr = None
    if chargeMethodAttr is not None:
        chargeMethodAttrStr = parseAttrMdc(chargeMethodAttr)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    # Translate subscriber to OID if needed
    if queryType != 'ObjectId':
        queryResponse = querySubscriber(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    profTemplate = open(templates  + 'subscriber_contract_debt_payment'+RESTV3.fileType).read()

    profTemplate = RESTHELPER.checkIfDefined(offerResourceId, None, 'RESOURCEID', profTemplate, 'ResourceId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'IsPayoff')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    if chargeMethod or paymentMethodResourceId or paymentGatewayId or nonce or chargeMethodAttr:
        chargeMethodData = createChargeMethodData(chargeMethod=chargeMethod, paymentMethodResourceId=paymentMethodResourceId,
                                                  paymentGatewayId=paymentGatewayId, paymentGatewayOneTimeToken=nonce,
                                                  chargeMethodAttr=chargeMethodAttrStr)
    else:
        chargeMethodData = None
    profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')


    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/' + str(queryValue) + '/contract/' + str(offerResourceId) + '/debt_payment'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)


    return validateResponse(response=response, method=funcName, shouldPass=eventPass)


#=============================================================
def deviceContractDebtPayment(V3inst, queryValue, offerResourceId, amount, queryType = 'ExternalId', paymentMethodResourceId=None, chargeMethod=None,
    paymentGatewayId=None, nonce=None, chargeMethodAttr=None, reason=None, info=None, apiEventData=None, now=None, eventPass=True, multiRequestBuild=None):
    #Get function Name
    funcName = QAUTILS.getFunctionName()

    chargeMethodAttrStr = None
    if chargeMethodAttr is not None:
        chargeMethodAttrStr = parseAttrMdc(chargeMethodAttr)

    # Translate device to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryDevice(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates  + 'device_contract_debt_payment'+RESTV3.fileType).read()

    profTemplate = RESTHELPER.checkIfDefined(offerResourceId, None, 'RESOURCEID', profTemplate, 'ResourceId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'IsPayoff')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    if chargeMethod or paymentMethodResourceId or paymentGatewayId or nonce or chargeMethodAttr:
        chargeMethodData = createChargeMethodData(chargeMethod=chargeMethod, paymentMethodResourceId=paymentMethodResourceId,
                                                  paymentGatewayId=paymentGatewayId, paymentGatewayOneTimeToken=nonce,
                                                  chargeMethodAttr=chargeMethodAttrStr)
    else:
        chargeMethodData = None
    profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')


    url = '/'+RESTV3.urlPrefix+'/device/' + str(queryValue) + '/contract/' + str(offerResourceId) + '/debt_payment'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)


    return validateResponse(response=response, method=funcName, shouldPass=eventPass)


#=============================================================
def groupContractDebtPayment(V3inst, queryValue, offerResourceId, amount, queryType = 'ExternalId', paymentMethodResourceId=None, chargeMethod=None,
    paymentGatewayId=None, nonce=None, chargeMethodAttr=None, reason=None, info=None, apiEventData=None, now=None, eventPass=True, multiRequestBuild=None):
    #Get function Name
    funcName = QAUTILS.getFunctionName()

    chargeMethodAttrStr = None
    if chargeMethodAttr is not None:
        chargeMethodAttrStr = parseAttrMdc(chargeMethodAttr)

    # Translate group to OID if needed
    if queryType != 'ObjectId':
        queryResponse = queryGroup(V3inst=V3inst, queryValue=queryValue, queryType=queryType, now=now)
        queryValue = getOID(queryResponse)

    apiEventDataStr = None
    if apiEventData is not None:
        apiEventDataStr = parseAttrMdc(apiEventData)

    profTemplate = open(templates  + 'group_contract_debt_payment'+RESTV3.fileType).read()

    profTemplate = RESTHELPER.checkIfDefined(offerResourceId, None, 'RESOURCEID', profTemplate, 'ResourceId')
    profTemplate = RESTHELPER.checkIfDefined(amount, None, 'AMOUNT', profTemplate, 'IsPayoff')
    profTemplate = RESTHELPER.checkIfDefined(reason, None, 'REASON', profTemplate, 'Reason')
    profTemplate = RESTHELPER.checkIfDefined(info, None, 'INFO', profTemplate, 'Info')
    profTemplate = RESTHELPER.checkIfDefined(now, None, 'EVENTTIME', profTemplate, 'EventTime')
    profTemplate = RESTHELPER.checkIfDefined(apiEventDataStr, None, 'APIEVENTDATA', profTemplate, 'ApiEventData')

    if chargeMethod or paymentMethodResourceId or paymentGatewayId or nonce or chargeMethodAttr:
        chargeMethodData = createChargeMethodData(chargeMethod=chargeMethod, paymentMethodResourceId=paymentMethodResourceId,
                                                  paymentGatewayId=paymentGatewayId, paymentGatewayOneTimeToken=nonce,
                                                  chargeMethodAttr=chargeMethodAttrStr)
    else:
        chargeMethodData = None
    profTemplate = RESTHELPER.checkIfDefined(chargeMethodData, None, 'CHARGEMETHODDATA', profTemplate, 'ChargeMethodData')


    url = '/'+RESTV3.urlPrefix+'/group/' + str(queryValue) + '/contract/' + str(offerResourceId) + '/debt_payment'

    # Debug output if globally set
    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)
        print(funcName + ' payload:\n' + profTemplate)

    response = V3inst.put(url, payload=profTemplate, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)


    return validateResponse(response=response, method=funcName, shouldPass=eventPass)


#=============================================================
def pricingQueryContractList(V3inst, routingType=None, routingValue=None, now=None, eventPass=True, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    url = '/'+RESTV3.urlPrefix+'/pricing/contract'
    if routingType and routingValue:
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryContract(V3inst, queryValue, queryType='ContractId', routingType=None, routingValue=None, now=None, eventPass=True, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    url = '/'+RESTV3.urlPrefix+'/pricing/contract/'
    if queryType == 'ContractId':
        url += str(queryValue)
    elif queryType == 'ExternalId':
        contractId = URL.quote(queryValue,'')
        url += '/ExternalId+'+ str(contractId)

    if routingType and routingValue:
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def pricingCacheQueryContract(V3inst, queryValue, queryType='Contract', routingType=None, routingValue=None, now=None, eventPass=True, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()


    url = '/'+RESTV3.urlPrefix+'/cache/pricing/'+queryType+'/'+str(queryValue)

    if queryType not in ['Contract', 'contract']:
        print('ERROR: Query Contract  parameter queryType has an unsupported value (' + queryType + ')')

    if routingType and routingValue:
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryRole(V3inst, queryValue, queryType='PricingId', routingType=None, routingValue=None, now=None, eventPass=True, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    url = '/'+RESTV3.urlPrefix+'/pricing/user_role/'  + str(queryValue)
    if routingType and routingValue:
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response


#=============================================================
def pricingQueryRoleList(V3inst, routingType=None, routingValue=None, now=None, eventPass=True, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    url = '/'+RESTV3.urlPrefix+'/pricing/user_role'
    if routingType and routingValue:
        url += '?TrafficRouteData=' + str(routingType) + str(routingValue)

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
# Query catalog item by subscriber or subscription
# only support query by object id or external id
def subscriberQueryCatalogItemList(V3inst, queryValue=None, queryType=None, now=None, eventPass=True,
                             eligibilityFilter=True, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/'+RESTV3.subUrl+'/'

    if queryType == 'ExternalId':
        url += 'ExternalId+'+str(queryValue)
    elif queryType == 'ObjectId':
        url += str(queryValue)
    else: sys.exit('ERROR: querySubscriber parameter queryType has an unsupported value (' + queryType + ')')

    #if url subscriber is used, only support catalogitem
    #if url subscription,is used,  only support CatalogItem
    # see MTX-28513
    if 'subscriber' in url:
        url += '/catalogitem'
    else:
        url += '/CatalogItem'

    if eligibilityFilter is not None:
        url += '?eligibilityFilter='+str(eligibilityFilter).lower()

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    #below is comment out since response is too long
    #if QAUTILS.DebugLevel > 0: print funcName + ' response:\n' + response

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def deviceQueryCatalogItemList(V3inst, queryValue=None, queryType=None, now=None, eventPass=True,
                             eligibilityFilter=True, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()


    if queryType == 'ObjectId':         url = '/'+RESTV3.urlPrefix+'/device/'
    elif queryType == 'ExternalId':     url = '/'+RESTV3.urlPrefix+'/device/ExternalId+'
    elif queryType == 'PhoneNumber':    url = '/'+RESTV3.urlPrefix+'/device/PhoneNumber+'
    elif queryType == 'Imsi':           url = '/'+RESTV3.urlPrefix+'/device/PhoneNumber+'
    elif queryType == 'AccessNumber':   url = '/'+RESTV3.urlPrefix+'/device/AccessNumber+'
    elif queryType == 'LoginId':        url = '/'+RESTV3.urlPrefix+'/device/LoginId+'
    elif queryType == 'AccessId':       url = '/'+RESTV3.urlPrefix+'/device/AccessId+'
    else:  sys.exit('ERROR: queryDevice parameter queryType has an unsupported value (' + queryType + ')')

    url += str(queryValue)+'/CatalogItem'
    if eligibilityFilter is not None:
        url += '?eligibilityFilter='+str(eligibilityFilter).lower()

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    #if QAUTILS.DebugLevel > 0: print funcName + ' response:\n' + response

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def groupQueryCatalogItemList(V3inst, queryValue=None, queryType=None, now=None, eventPass=True,
                             eligibilityFilter=True, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    if   queryType == 'ObjectId':       url = '/'+RESTV3.urlPrefix+'/group/'
    elif queryType == 'ExternalId':     url = '/'+RESTV3.urlPrefix+'/group/ExternalId+'
    elif queryType == 'PhoneNumber':    url = '/'+RESTV3.urlPrefix+'/group/PhoneNumber+'
    else:  sys.exit('ERROR: queryGroup parameter queryType has an unsupported value (' + queryType + ')')

    url += str(queryValue)+'/CatalogItem'
    if eligibilityFilter is not None:
        url += '?eligibilityFilter='+str(eligibilityFilter).lower()

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    #if QAUTILS.DebugLevel > 0: print funcName + ' response:\n' + response

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response


#=============================================================
def pricingQueryCatalogList(V3inst, eventPass=True, now=None, routingType=None, routingValue=None, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/pricing/Catalog'

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response
#=============================================================
def pricingCacheQueryCatalogList(V3inst, eventPass=True, now=None, routingType=None, routingValue=None, queryType='Catalog', multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/cache/pricing/'+queryType

    if queryType not in ['Catalog', 'catalog']:
        print('ERROR: Query CatalogList parameter queryType has an unsupported value (' + queryType + ')')

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryCatalog(V3inst, queryValue=None, queryType='CatalogId', eventPass=True, now=None, routingType=None, routingValue=None, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    if queryType == 'CatalogId':        url = '/'+RESTV3.urlPrefix+'/pricing/Catalog/'
    elif queryType == 'ExternalId':     url = '/'+RESTV3.urlPrefix+'/pricing/Catalog/ExternalId+'
    else:  sys.exit('ERROR: queryCatalog parameter queryType has an unsupported value (' + queryType + ')')

    url += str(queryValue)

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def pricingCacheQueryCatalog(V3inst, queryValue=None, queryType='Catalog', eventPass=True, now=None, routingType=None, routingValue=None, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/cache/pricing/'+queryType+'/'+str(queryValue)
    if queryType not in ['Catalog', 'catalog']:
        print('ERROR: Query Catalog parameter queryType has an unsupported value (' + queryType + ')')

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def queryPricingStatus(V3inst, now=None, routingType=None, routingValue=None, eventPass=True):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/pricing/status'

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryContractPaymentScheduleList(V3inst, eventPass=True, now=None, routingType=None, routingValue=None, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/pricing/contractPaymentSchedule'

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryContractPaymentSchedule(V3inst, queryValue=None, queryType='ContractPaymentScheduleId', eventPass=True, now=None, routingType=None, routingValue=None, multiRequestBuild=None):

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/pricing/contractPaymentSchedule/'
    if queryType == 'ContractPaymentScheduleId':        url +=str(queryValue)
    elif queryType == 'ExternalId':     url += 'ExternalId+'+str(queryValue)
    else:  sys.exit('ERROR: queryContractPaymentSchedule parameter queryType has an unsupported value (' + queryType + ')')

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryTenantList(V3inst,  now=None, eventPass=True, routingType=None, routingValue=None, multiRequestBuild=None):
    global restVersion

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/pricing/tenant/'

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def pricingQueryTenant(V3inst, queryType='TenantId', queryValue=None,  now=None, eventPass=True, routingType=None, routingValue=None, multiRequestBuild=None):
    global restVersion

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/pricing/tenant/' + str(queryType) + '+' + str(queryValue)

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def taxQueryProductGroupList(V3inst,  now=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/tax/productgroup/'

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def taxQueryProductItemList(V3inst,  productGroup=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/tax/productgroup/'+str(productGroup)+'/productitem'

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response


#=============================================================
def taxQueryCustomerTypeList(V3inst,  now=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/tax/customertype/'

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def taxQueryStatus(V3inst,  now=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/tax/status'

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def taxQueryGeoCode(V3inst,  postalCode=None, plus4=None, npa=None, nxx=None, timeZone=None, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/tax/geocode'
    if postalCode is not None and plus4 is not None:
        url += '?postalCode='+str(postalCode)+ '&plusFour='+str(plus4)
    elif npa is not None and nxx is not None:
        url += '?npa='+str(npa)+ '&nxx='+str(nxx) 

    # on the REST level not support now since it is not public part
    #if now is not None:
    #    url += '&now='+str(now)

    if timeZone is not None:
        url += '&timeZone='+str(timeZone)

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def taxQueryExemptionCodeList(V3inst, now=None, eventPass=True, multiRequestBuild=None):
    global restVersion

    #Get function Name
    funcName = QAUTILS.getFunctionName()

    if V3inst == None:
        V3inst = QAUTILS.getSubscInterfaceMDC()

    url = '/'+RESTV3.urlPrefix+'/tax/exemptioncode/'

    if QAUTILS.DebugLevel > 0:
        print(funcName + ' url: ' + url)

    response = V3inst.get(url, time=now)
    if QAUTILS.DebugLevel > 0: print(funcName + ' response:\n' + response)

    if validateResponse(response=response, method=funcName, shouldPass=eventPass):
        return response

#=============================================================
def createServiceAddressData(streetAddr=None, extendedAddr=None, locality=None, region=None, postalCode=None, extendedPostalCode=None, countryCode=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        ServiceAddress = None
    else:
        ServiceAddress = '<MtxServiceAddressData>' + '\n     '
        startinglen = len(ServiceAddress)
        if streetAddr:
            ServiceAddress += '<StreetAddress>' + str(streetAddr) + '</StreetAddress>' + '\n     '
        if extendedAddr: 
            ServiceAddress += '<ExtendedAddress>' + str(extendedAddr) + '</ExtendedAddress>' + '\n     '
        if locality:
            ServiceAddress += '<Locality>' + str(locality) + '</Locality>' + '\n     '
        if region:
            ServiceAddress += '<Region>' + str(region) + '</Region>' + '\n     '
        if postalCode:
            ServiceAddress += '<PostalCode>' + str(postalCode) + '</PostalCode>' + '\n     '
        if extendedPostalCode:
            ServiceAddress += '<ExtendedPostalCode>' + str(extendedPostalCode) + '</ExtendedPostalCode>' + '\n     '
        if countryCode:
            ServiceAddress += '<CountryCode>' + str(countryCode) + '</CountryCode>' + '\n     ' 
        if len(ServiceAddress) > startinglen: ServiceAddress += '                  </MtxServiceAddressData>'
        else: ServiceAddress = None

    return ServiceAddress 

def createGeoData(geoCode=None, postalCode=None, plus4=None, npa=None, nxx=None):
    # Get function name
    funcName = QAUTILS.getFunctionName()
    if RESTV3.restVersion == 'JSON' or RESTV3.restVersion == 'OPENAPI':
        ServiceAddress = None
    else:
        GeoData = '<MtxGeoData>' + '\n     '
        startinglen = len(GeoData)
        if geoCode:
            GeoData += '<GeoCode>' + str(geoCode) + '</GeoCode>' + '\n     '
        if postalCode:
            GeoData += '<PostalCode>' + str(postalCode) + '</PostalCode>' + '\n     '
        if plus4:
            GeoData += '<Plus4>' + str(plus4) + '</Plus4>' + '\n     '
        if npa:
            GeoData += '<Npa>' + str(npa) + '</Npa>' + '\n     '
        if nxx:
            GeoData += '<Nxx>' + str(nxx) + '</Nxx>' + '\n     '
        if len(GeoData) > startinglen: GeoData += '                  </MtxGeoData>'
        else: GeoData = None

    return GeoData


#=============================================================
def  printAll():

    print("addSubscriber(V3inst=None, externalId = None, deviceId = None, deviceType = 1, offerId = 0, allDevices = True,")
    print("createSubscriber(V3inst, externalId=None, now=None, payload=None, billingCycle=None, eventPass=True,")
    print("modifySubscriber(V3inst, queryValue, payload=None, eventPass=True, queryType='ExternalId',")
    print("subscribeToOffer(V3inst, externalId, offerId, offerStartTime=None, offerEndTime=None, eventPass=True,")
    print("unsubscribeFromOffer(V3inst, subscriberId, resourceId=0, endTime=None, eventPass=True,")
    print("addSubscriberThreshold(V3inst, subscriberId, resourceId, thresholdId, threshName, isCredit, isPercent,")
    print("removeSubscriberThreshold(V3inst, subscriberId, indexId, thresholdId, queryType='ExternalId'):")
    print("querySubscriber(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None):")
    print("querySubscriberWallet(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None):")
    print("createDevice(V3inst, imsi, externalId=None, deviceType=None, attr=None, now=None,")
    print("addDeviceToSubscriber(V3inst, externalId, deviceId=0, deviceType=1, subQueryType='ExternalId',")
    print("modifyDevice(V3inst, queryValue, queryType='PhoneNumber', deviceType=None, attr=None, now=None, eventPass=True):")
    print("devicePurchaseOffer(V3inst, queryValue, offerId, offerStartTime=None, offerEndTime=None, queryType='PhoneNumber',")
    print("deviceCancelOffer(V3inst, queryValue, resourceId=0, endTime=None, eventPass=True, queryType='PhoneNumber'):")
    print("queryDevice(V3inst, queryValue, queryType='PhoneNumber', eventPass=True, now=None):")
    print("createGroup(V3inst, groupId=None, name=None, tier=None, administrator_id=0, eventPass=True, attr=None, now=None,")
    print("modifyGroup(V3inst, groupId, name=None, tier=None, administrator_id=0, billingCycle=None, attr=None,")
    print("groupSubscribeToOffer(V3inst, groupId, offerId, offerStartTime=None, offerEndTime=None, eventPass=True,")
    print("groupUnsubscribeFromOffer(V3inst, groupId, resourceIds, now=None, eventPass=True, queryType='ExternalId'):")
    print("addGroupThreshold(V3inst, groupId, resourceId, thresholdId, threshName, isCredit, isPercent,")
    print("removeGroupThreshold(V3inst, groupId, resourceId, thresholdId, now=None, queryType='ExternalId'):")
    print("addSubscriberToGroup(V3inst, groupId, subscriberId, subQueryType='ExternalId', groupQueryType='ExternalId',")
    print("removeSubscriberFromGroup(V3inst, groupId, subscriberId, subQueryType='ExternalId', groupQueryType='ExternalId',")
    print("addSubGroupToGroup(V3inst, groupId, subGroupId, subQueryType='ExternalId', groupQueryType='ExternalId',")
    print("removeSubGroupFromGroup(V3inst, groupId, subGroupId, subQueryType='ExternalId', groupQueryType='ExternalId',")
    print("addGroupMembership(V3inst, groupId, subscribers=None, subGroups=None, subQueryType='ExternalId',")
    print("removeGroupMembership(V3inst, groupId, subscribers=None, subGroups=None, subQueryType='ExternalId',")
    print("queryGroup(V3inst, queryValue, queryType='ExternalId', eventPass=True, now=None):")
    print("queryGroupWallet(V3inst, queryValue, queryType='ExternalId', now=None, eventPass=True):")
    print("createBillingCycleData(templateId, dateOffset=None, startTime=None):")
    print("createSubscriberBillingProfile(V3inst, subscriberId, profileId, startTime=None, dateOffset=0,")
    print("queryCatalogItemList(V3inst, eventPass=True, now=None, routingType=None, routingValue=None)")
    print("queryCatalogItem(V3inst, queryValue=None, queryType='Id', eventPass=True, now=None, routingType=None, routingValue=None)")
    print("subscriberQueryCatalogItemList(V3inst, queryValue=None, queryType=None, now=None, eventPass=True,eligibilityFilter=True)")
    print("deviceQueryCatalogItemList(V3inst, queryValue=None, queryType=None, now=None, eventPass=True,eligibilityFilter=True)")
    print("groupQueryCatalogItemList(V3inst, queryValue=None, queryType=None, now=None, eventPass=True,eligibilityFilter=True)")
    print("queryCatalogList(V3inst, eventPass=True, now=None, routingType=None, routingValue=None)")
    print("queryCatalog(V3inst, queryValue=None, queryType='CatalogId', eventPass=True, now=None, routingType=None, routingValue=None)")
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

