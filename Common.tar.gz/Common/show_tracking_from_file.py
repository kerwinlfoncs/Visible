#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:41:24
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:37:05
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:21
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

#

import data_container as MDC
# Check if the data_container_defs.py needs to be re-created
import data_container_defs as MDCDEFS
import common_mdc as COMMON
import optparse
import os, string

xmlStatus=True
try:
    import xml_utils
except ImportError:
    xmlStatus=Flase

EventTypeTree = None
outputFile = ''

#-------------------------------------------------------------------------------
def outputTrackingRecord(record, stripFields):
    global outputFile
    tmpRecordFileName = os.getcwd() + '/' + COMMON.resultsDir + '/current_record.txt' 
    tmpRecordFile = open(tmpRecordFileName, 'w')
    print(record.printXml(), file=tmpRecordFile)
    tmpRecordFile.close()

    tmpRecord = open(tmpRecordFileName, 'r')
    lines = tmpRecord.readlines()
    tmpRecord.close()
    lines.append("</root>\n")
    lines.reverse()
    lines.append("<root>\n")
    lines.reverse()
    processedData = "".join([x for x in lines if x.strip() != ''])
    tmpRecord = open(tmpRecordFileName, 'w')
    tmpRecord.write(processedData)
    tmpRecord.close()

    excludeList = ['BalanceSetId', 'WalletId', 'WalletId', 'OwnerId', 'OwnerExternalId']

    if xmlStatus and stripFields:
        print(xml_utils.transformDoc(tmpRecordFileName, excludeList), file=outputFile)
    else:
        print(processedData, file=outputFile)



def extractTrackingRecords(mdc, diffRecords, stripFields):
    # We expect to have a work order in the mdc
    if mdc.descObj.containerKey != MDCDEFS.kMtxWorkOrderMsgMdcDesc.containerKey:
        print("Error: Unexpected MDC type")

    # See if we have any events
    if not mdc.isPresent(MDCDEFS.kMtxWorkOrderMsgTxnBalanceTrackingListFldKey):
        # No events present
        return (None, None, None, None, None, None)

    # Get the action list
    print(MDCDEFS.kMtxWorkOrderMsgTxnBalanceTrackingListFldKey)
    trackingList = mdc.getUsingKey(MDCDEFS.kMtxWorkOrderMsgTxnBalanceTrackingListFldKey)

    eventInfo = (None, None, None, None, None, None)
    for trackingMdc in trackingList:
        if diffRecords:
            eventInfo=outputTrackingRecord(trackingMdc, stripFields)
        else:
            outputTrackingRecord(trackingMdc, stripFields)


    return eventInfo

def readCompactInput(inFile, diffRecords, stripFields):
    for line in inFile:
        line = line.rstrip('\n')
        if (line == ''):
            continue
        if (line.startswith('#')):
            continue

        mdc = MDC.readFromStr(line)
        if mdc == None:
            if debug:
                # Do not terminate on error in debug mode.
                print('Cannot parse MDC for input: ' + line)
                continue
            else:
                print("Fatal Error: Cannot parse input")
                return

        extractTrackingRecords(mdc, diffRecords, stripFields)


def printTrackingRecords(testTag, diffRecords, stripFields = False):
    global outputFile
    path = os.getcwd()
    logFile = path + '/' + COMMON.resultsDir + '/tmpTrackingLog'

    if (not os.path.exists(logFile)):
        print('Error: The input file name (' + logFile + ') does not exist.')
        return (None, None, None, None, None)

    inFile = open(logFile, 'r')

    outputFileName = path + '/' + COMMON.resultsDir + '/' + testTag + '_baltracking'
    outputFile = open(outputFileName, 'a')

    readCompactInput(inFile, diffRecords, stripFields)

    inFile.close()
    outputFile.close()

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

