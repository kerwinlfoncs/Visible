#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:54
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:34
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:12
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


import os,sys
import optparse
import pretty_print as PRINT
import qa_utils as QAUTILS
import QA_subscriber_management_restv3 as RESTV3

restInst = None

def main():
    global restInst

    parser = optparse.OptionParser()
    parser.add_option("-s", "--subscid", action='store', type='int', default=0)
    parser.add_option("-x", "--externalid", action='store', type='string', default=None)
    parser.add_option("-i", "--imsi", action='store', type='string', default=None)
    parser.add_option("-o", "--soid", action='store', type='string', default=None)
    parser.add_option("-w", "--doid", action='store', type='string', default=None)
    parser.add_option("-c", "--goid", action='store', type='string', default=None)
    parser.add_option("-a", "--daccess", action='store', type='string', default=None)
    parser.add_option("-b", "--dexternal", action='store', type='string', default=None)
    parser.add_option("-g", "--groupid", action='store', type='int', default=0)
    parser.add_option("-l", "--level", action='store', type='int', default=1)
    parser.add_option("-t", "--time", action='store', type='string', default='None')
    parser.add_option("-m", "--mdcgw", default="1", help="query by mdc gw")
    parser.add_option("-r", "--restgw", default="", help="query by REST")
    (options, args) = parser.parse_args()

    # Get client to perform query
    gatewaysConfig = QAUTILS.getDiameterRestConfig()
    if options.restgw:
        RESTV3.setVersion('REST')
    else:
        RESTV3.setVersion('MDC')
        RESTV3.mtxflags = 1
    QAUTILS.gatewaysConfig = gatewaysConfig
    restInst = QAUTILS.getSubscInterface()

    if options.time == 'None':
        options.time = None

    if options.imsi:
        delDevice(options.imsi, 'Imsi', options.level, options.time, options.restgw)
    elif options.doid:
        delDevice(options.doid, 'ObjectId', options.level, options.time, options.restgw)
    elif options.daccess:
        delDevice(options.daccess, 'AccessNumber', options.level, options.time, options.restgw)
    elif options.dexternal:
        delDevice(options.dexternal, 'ExternalId', options.level, options.time, options.restgw)

    elif options.soid:
        delSubscriber(options.soid, 'ObjectId', options.level, options.time, options.restgw)
    elif options.subscid:
        delSubscriber(options.subscid, 'PhoneNumber', options.level, options.time, options.restgw)
    elif options.externalid:
        delSubscriber(options.externalid, 'ExternalId', options.level, options.time, options.restgw)
    elif options.groupid:
        delGroup(options.groupid, 'ExternalId', options.level, options.time, options.restgw)
    elif options.goid:
        delGroup(options.goid, 'ObjectId', options.level, options.time, options.restgw)
    else:
        print('done!!!!!!!!!!!')

		 
def delGroup(queryValue, queryType, level, time, rest=None):
        print("delete group not supported")

def delSubscriber(queryValue, queryType, level, time, rest=None):
        print("delete subscriber not supported")
     
def delDevice(queryValue, queryType, level, time, rest=None):
        getDeviceData(queryValue, queryType, level,time, rest)
        print("deleting ", queryValue, " by queryType=", queryType)
        deviceMdc = RESTV3.deleteDevice(restInst,queryValue, queryType=queryType, now=time)
	print(deviceMdc)
def getDeviceData(queryValue, queryType, level, time, rest=None):
        print("querying ", queryValue, " by queryType=", queryType)
        deviceMdc = restInst.deviceQuery(queryValue=queryValue, queryType=queryType, now=time)
        print(deviceMdc)


if __name__ == '__main__':
   main()
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

