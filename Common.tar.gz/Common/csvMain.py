#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:35:18
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:35:18
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:35:17
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
from __future__ import print_function
# from builtins import str
# from builtins import range
from future import standard_library
standard_library.install_aliases()
# from builtins import str
# from builtins import range
import http.server
import socketserver
import copy, re, os, sys, time, json, pprint, urllib.request, urllib.error, urllib.parse, subprocess, random
import QA_subscriber_management_restv3 as REST_UTIL
import diameter as DIAM
import diameter_utils
import qa_utils as QAUTILS
import qa_utils_5G as QAUTILS5G
import csv_track as TRACK
import csv_id as CSVID
import csv_rx as CSVRX
import csv_prim as PRIM
import csv_data as DATA
import csv_CmdCb as CMDCB
import csv_CmdMisc as CMDMISC
import csv_CmdGl as CMDGL
import csv_CmdDiamGy as CMDDIAMGY
import csv_CmdDiamSy as CMDDIAMSY
import csv_CmdDiamSh as CMDDIAMSH
import csv_CmdPricing as CMDPRICE
import csv_CmdSnmp as CMDSNMP
import csv_CmdTax as CMDTAX
import csv_CmdTrack as CMDTRACK
import csv_CmdCombo as CMDCOMBO
import csv_CmdSub as CMDSUB
import csv_CmdDev as CMDDEV
import csv_CmdGroup as CMDGROUP
import csv_CmdPayNow as CMDPAYNOW
import csv_CmdHa as CMDHA
import csv_CmdClient as CMDCLIENT
import csv_Events as CSVEVENTS
import csv_BraintreePayment as CSVBRAINTREE
import csv_qa as CSVQA
import csv_ccf as CCF
import ha_apis as HA
import snmp as SNMP
import customURL as CUSTURL
import common_mdc as COMMON
import csv_CmdUser as CMDUSER
import csv_CmdSubscription as CMDSUBSCRIPTION
import csv_5G as FIVEG
from primitives import timeToMDCtime as MDCTIME
from primitives import primGET as GET
from primitives import primGeneric as GENERIC
from primitives import primXML as XML
import xml.etree.cElementTree as ET

try:
   import custSpecific as CUST
except ImportError:
   os.system(' echo \"\" > custSpecific.py ')

# Declare globals
global DiameterHostName
global MyHostName
global optionsSave

# Define globals
DiameterHostName = ""
MyHostName = ""

# Manage comment strings
commentString = "'''"
commentStringEnabled = 0

# Manage "if" logic
ifElseLocation = []
ifStatus = []

#==========================================================
def getObjectNameFromConstants(objName, options):
        #print 'getObjectNameFromConstants: called with objName = ' + str(objName)
        # Allow name to be constructed
        for constantKey in ['*', '$']:
            while True:
                # Break from while loop if key substrings not in the file name
                if not (objName.count(constantKey+'{') and objName.count('}')): break
                
                # Put key items into local variables
                keyStart = objName.find(constantKey+'{')
                stringStart = keyStart + 2
                stringEnd = stringStart + objName[stringStart:].find('}')
                
                # Extract the string and replace with options value
                variable = objName[stringStart:stringEnd]
                #print 'Object Name is based on ' + constantKey + ' special string "' + variable + '"'
                
                # Replace the value with the parameter
                if constantKey == '*':  x = getattr(options, variable)
                else:                   x = DATA.constantValue[variable]
                objName = objName[0:keyStart] + str(x) + objName[stringEnd+1:]
                #print 'Updated file name: ' + objName
        
        return objName
        
#==========================================================
def loopProcessing(options, line, LoopData, dataFile):
        # If in a for loop,
        # See if this is the start of a FOR loop
        if line.lower().startswith('elihw'):
                # Check if not already in a loop
                if not len(LoopData['loops']):                  sys.exit('ERROR: not in a loop')
                elif LoopData['loops'][-1]['type'] != 'while':  sys.exit('ERROR: not in a while loop')
                
                # See if the condition is valid.  Condition may be made up of constants, so repalce those.
                lclDCT = {}
                lclDCT['operation'] = [getObjectNameFromConstants(LoopData['loops'][-1]['operation'], options)]
                print('While command operation: ' + str(lclDCT['operation']))
                if CMDMISC.CmdMisc_compare(lclDCT, options, line, False): 
                        print('\n\nWhile loop #' + str(len(LoopData['loops'])) + ' looping as operation "' + LoopData['loops'][-1]['operation'] + '" is still true.')
                        
                        # Return line count to the beginning of this for loop
                        LoopData['lineCount'] = LoopData['loops'][-1]['lineCount']
                else:
                        # No more data for for loop.
                        
                        # Debug output
                        print('\n\nExited "while" loop #' + str(len(LoopData['loops'])))
                
                        # Delete for loop entry
                        del LoopData['loops'][-1]
                        
                        # Skip over this line
                        LoopData['lineCount'] += 1
                
                # If this is the last for loop then delete all for lines and reset the line pointer
                if not len(LoopData['loops']):
                        del dataFile[:LoopData['lineCount']]
                        LoopData['lineCount'] = 0
                        print('\n\nDone with all loops\n')
                
                # Nothing more to do with this line
                return line,False
        
        elif line.lower().startswith('rof'):
                # Check if not already in a for loop
                if not len(LoopData['loops']):                  sys.exit('ERROR: not in a loop')
                elif LoopData['loops'][-1]['type'] != 'for':    sys.exit('ERROR: not in a for loop')
                
                # End of the loop.  See if anything else to process.
                if len(LoopData['loops'][-1]['forValues']) > 1:
                        print('\n\nFOR loop #' + str(len(LoopData['loops'])) + ' looping')
                        
                        # Remove just-processed values
                        del LoopData['loops'][-1]['forValues'][0]
                        
                        # Return line count to the beginning of this for loop
                        LoopData['lineCount'] = LoopData['loops'][-1]['lineCount']
                else:
                        # No more data for for loop.
                        
                        # Debug output
                        print('\n\nExited "for" loop #' + str(len(LoopData['loops'])))
                
                        # Delete for loop entry
                        del LoopData['loops'][-1]
                        
                        # Skip over this line
                        LoopData['lineCount'] += 1
                
                # If this is the last for loop then delete all for lines and reset the line pointer
                if not len(LoopData['loops']):
                        del dataFile[:LoopData['lineCount']]
                        LoopData['lineCount'] = 0
                        print('\n\nDone with all loops\n')
                else:
                        # Delete what we are going to add to each line, so we calculate based on new line values.
                        # "Addition" is setup on the first non-for command within a for loop.  Need the try/except to handle case where a for command is the first command in a for loop...
                        try: del LoopData['loops'][-1]['addition']
                        except: pass
                
                # Nothing more to do with this line
                return line,False
        
        elif line.lower().startswith('while'):
                # Add new entry
                loopData = {}
                loopData['type'] = 'while'
                
                # Skip over this line iff already in for loops (else already skipped over)
                if len(LoopData['loops']): LoopData['lineCount'] += 1
                
                # Get line count this for loop will return to
                loopData['lineCount'] = LoopData['lineCount']
                
                # Debug
                print('\n\nEntered "while" loop #' + str(len(LoopData['loops'])+1) + '.  Line = ' + line)
                
                # Save the condition
                loopData['operation'] = line.split(';')[1]
                
                # Copy data to official for loop data (updated from here from now on)
                LoopData['loops'].append((copy.deepcopy(loopData)))
                
                # See if the condition is valid.  Must be valid at the top of the loop.
                # Condition may be made up of constants, so repalce those.
                lclDCT = {}
                lclDCT['operation'] = [getObjectNameFromConstants(LoopData['loops'][-1]['operation'], options)]
                print(loopData['type'] + ' command operation: ' + str(lclDCT['operation']))
                if not CMDMISC.CmdMisc_compare(lclDCT, options, line, False): 
                        print('ERROR: while condition "' + str(LoopData['loops'][-1]['operation']) + '" not True at start of while loop.  Condition must be True at the start.')
                        sys.exit('Exiting due to errors')
                
                # Nothing more to do with this line
                return line,False
        
        elif line.lower().startswith('for'):
                # Add new entry
                loopData = {}
                loopData['type'] = 'for'
                
                # Skip over this line iff already in for loops (else already skipped over)
                if len(LoopData['loops']): LoopData['lineCount'] += 1
                
                # Get line count this for loop will return to
                loopData['lineCount'] = LoopData['lineCount']
                
                # Debug
                print('\n\nEntered "for" loop #' + str(len(LoopData['loops'])+1) + '.  Line = ' + line)
                
                # Split the input line
                lineSplit = line.split(';')
                
                # Allow for constants and/or variables in the list of values or variables
                lineSplit[1] = getObjectNameFromConstants(lineSplit[1], options)
                
                # Set other variables from the command
                loopData['forConstant'] = lineSplit[1].split('@')
                
                # Values are optional (if constants specify a file)
                try:
                        # Allow for constants and/or variables in the list of values or variables
                        lineSplit[2] = getObjectNameFromConstants(lineSplit[2], options)
                        
                        if lineSplit[2].count(','):     loopData['forValues'] = lineSplit[2].split(',')
                        else:                           loopData['forValues'] = lineSplit[2].split('@')
                        addlParamsIdx = 3
                except:
                        loopData['forValues'] = None
                        addlParamsIdx = 2
                
                # Get constant name (in case it's a special word)
                constantName = loopData['forConstant'][0].strip()
                
                # If constants referenes a catalog, then process that
                if constantName.startswith('catalog'):
                        # Get the catalog name
                        catalogName = getObjectNameFromConstants(constantName.split('=')[1], options)
                        print('For loop reading catalog "' + catalogName + '"')
                        
                        # Set constant to be offer ID
                        loopData['forConstant'] = ['offerId']
                        
                        # Process the catalog
                        cmd = 'curl -s http://restgw:8080/rsgateway/data/v3/pricing/Catalog/ExternalId+' + catalogName.replace(' ',"%20")
                        responseData = QAUTILS.runCmd(cmd)
                        try:
                             q=ET.fromstring(responseData)
                        except:
                                print('ERROR: Command "' + cmd + '" returned data is not in XML format')
                                print(responseData)
                                sys.exit("Exiting due to errors")
                        
                        # Get all catalog item external IDs
                        loopData['forValues'] = []
                        for child in q.findall('./CatalogInfo/MtxPricingCatalogDetailInfo/CatalogItemList/MtxPricingCatalogItemInfo'): loopData['forValues'].append(child.find('ExternalId').text.strip())
                        
                        # Debug
                        print(loopData['forValues'])
                        
                # If constants come from a file, then process that here
                if constantName.startswith('file'):
                        # Get the file name
                        fileName = getObjectNameFromConstants(constantName.split('=')[1], options)
                        print('For loop reading from file "' + fileName + '"')
                        
                        # Read CSV file
                        (loopData['forValues'], loopData['forConstant']) = GENERIC.readCsvFile(fileName, 'Entry')
                        '''
                        print heading
                        for row in rows:
                                for idx in range(len(row)): pprint.pprint(row[idx])
                        '''
                        
                # There may be additional parameters passed in (generally via include file).  If any are here then set them as if they 
                # were entered via *<parameter>:<value> or $<constant>:value syntax.
                lclDCT= {}
                for i in range(addlParamsIdx,len(lineSplit),1): 
                        # Two values (parameter = value).  Allow value to have shortcutSplitChar in there.
                        (paramName,paramValue) = lineSplit[i].split('=')
                        
                        # Remove shite space
                        paramName = paramName.strip()
                        paramValue = paramValue.strip()
                        
                        # Store in dictionary (common location for parameter or constant setting)       
                        lclDCT['paramName'] = paramName
                        lclDCT['paramValue'] = paramValue
                        
                        # Check if a TF variable or constant
                        if paramName in DATA.TFVariables:       CMDMISC.CmdMisc_changeparametervalue(lclDCT, options)
                        else:                                   CMDMISC.CmdMisc_setconstantvalue(lclDCT, options)
                
                # Debug output
                if options.verbose == 'high':
                        print('TF parameter ' + str(loopData['forConstant']) + ' will be set from the list:')
                        pprint.pprint(LoopData['forValues'])
                
                # Copy data to official for loop data (updated from here from now on)
                LoopData['loops'].append((copy.deepcopy(loopData)))
                
                # Nothing more to do with this line
                return line,False
        
        elif len(LoopData['loops']):
           # Debug
           print('\nProcessing line ' + str(LoopData['lineCount']))
           
           # Bump counter
           LoopData['lineCount'] += 1
           
           # Only do the rest if in a real for loop (versus while)
           if LoopData['loops'][-1]['type'] == 'for':
                # Add parameter to the command line.  Values entry 0 is always the current one to use.
                try:
                        constants = LoopData['loops'][-1]['forConstant']
                        values    = LoopData['loops'][-1]['forValues'][0]
                except:
                        print('ERROR: Incorrect sytnax.  Parameters are the second item and values are the third item, separated by a semi-colon.  Please check the syntax of:')
                        print(line)
                        sys.exit('Exiting due to errors')
                
                # If a string, then we may need to split.  Will already be an array if it came from a file
                if isinstance(values, str):
                        # See if we split on @ or ,
                        if values.count('@'):   values = values.split('@')
                        else:                   values = values.split(',')
                
                        
                # Sanity check the lengths are equal
                if len(constants) != len(values):
                        print('ERROR: in for loop: constants length not equal to values length')
                        print(str(constants) + '/' + str(values))
                        sys.exit('Exiting due to errors')
                
                # Calculate line additions and setting constants only once, starting from previous values; else reuse calculated line addition (constants remain set)
                if 'addition' not in LoopData['loops'][-1]:
                        try:    LoopData['loops'][-1]['addition'] = LoopData['loops'][-2]['addition']
                        except: LoopData['loops'][-1]['addition'] = ''
                        
                        # Process each constant/value pair
                        for i in range(len(constants)):
                                # Remve white space
                                constant = constants[i].strip()
                                value = values[i].strip()
                                
                                # NOTE: Some TF tools will write normalizer values directory to the XML file.
                                # This means the value needs to be HTML encoded.  When TF reads the normalier 
                                # values it gets back HTML decoded.  All of this means we might have an encoded value.
                                # Decode that here.
                                value = value.replace("&apos;","'").replace("&amp;","&")
                                
                                # Check if a TF variable or constant
                                if constant in DATA.TFVariables:
                                        # Update input parameter
                                        lclDCT= {}
                                        lclDCT['paramName'] = constant
                                        lclDCT['paramValue'] = value
                                        CMDMISC.CmdMisc_changeparametervalue(lclDCT, options)
                                else:
                                        # Add to constants
                                        lclDCT= {}
                                        lclDCT['paramName'] = constant
                                        lclDCT['paramValue'] = value
                                        CMDMISC.CmdMisc_setconstantvalue(lclDCT, options)
                
                # Add to line                   
                line += LoopData['loops'][-1]['addition']
        
        # Return true so we process the line
        return line,True
                
#==========================================================
def processDataFileInput(testName, lclExtraAvp, options, lclStartTime, RESTInst, step, inputDataFile, extraParams=None, incFile=False):
    global DiameterHostName
    global MyHostName
    
    # Convert any environment variables in the filename
    inputDataFile = os.path.expandvars(inputDataFile) 
    
    # ====================== Tell them what we're going to to ======================================
    outputString = 'Started processing data file "' + inputDataFile + '"'
    
    # Debug output
    print(outputString)

    # Output test name to debug log file (for each in debugging)
    if (DiameterHostName == MyHostName) or (DiameterHostName == 'localhost'):
        # Local access
        command = 'echo -e "\n\n**** ' + outputString + ' ****\n\n" >> /var/log/mtx/mtx_debug.log'
    else:
        # Need to remotely access the server
        #command = 'ssh -A mtx@' + DiameterHostName + ' \'echo -e "\n\n**** ' + outputString + ' ****\n\n" >> /var/log/mtx/mtx_debug.log\''
        command = 'echo'

    #print 'command to run: ' + command
    QAUTILS.runCmd(command)

    # ====================== Process datafile ======================================
    # Open data file; get headers
    (dataFile, headers, step) = PRIM.dataFileSetup(inputDataFile, step)
    
    # See if we should check for parameters to pass along to all lines
    alwaysInclude = []
    if extraParams:
        # Split these, removing the first entry which will always be blank
        extra = extraParams.split(';')[1:]
        
        # Walk through the always include items
        for alwaysEntry in DATA.alwaysIncludeParameters:
                # Loop through extra items
                for extraEntry in extra:
                        # If always entry is in this extra parameter, add to the always include list
                        if extraEntry.count(alwaysEntry):
                                alwaysInclude.append(extraEntry)
                                
                                # Only need to find once per entry
                                break
    
    # If we added anything to always include, then make a string
    if len(alwaysInclude): alwaysInclude = ';' + ";".join(alwaysInclude)
    else:                  alwaysInclude = None
    
    # Process lines in the file
    lineCount=0
    saveResult = False
    
    # Create for loop data so we can loop within this file
    LoopData = {}
    LoopData['lineCount'] = 0
    LoopData['loops'] = []
    
    # Process until all lines are done.  Note that we can jump backwards if doing for loop processing.
    while len(dataFile):
        # Get next line to process.  May be looping so account for that.  Remove trailing white space.
        line = dataFile[LoopData['lineCount']].strip()

        # Always increment local step counter (for MDC output file uniqueness).
        # Actually, only increment if it's not stopped
        if not options.stopCountingSteps: step += 1
        
        # If not in a for loop, then delete the line
        if not len(LoopData['loops']): del dataFile[0]
        
        # Check for reasons we may skip this line
        #print 'Processing line "' + line + '"'
        # If a blank line after a strip, then skip (treat as a comment)
        # If this starts with a comment character or a semi-colon, then it's a comment line and we want to skip it
        # If importing a CSV file from Excel, then a blank line is nothing but delimiter characters.  Check for this and skip
        if (not line) or (line[0] in DATA.commentChar) or (not len(re.sub(';','',line))):
                # Bump for loop counter if in for loop
                if len(LoopData['loops']): LoopData['lineCount'] += 1
                
                # Skip this line
                continue
        
        # We have a line to process
        lineCount += 1
        
        # If this is the first line, then want to append any extra params to the line
        if lineCount == 1 and extraParams:
                line += extraParams
                print('Added initial extraParams "' + extraParams + '" to command line ' + str(lineCount))
                print('New line is: "' + line + '"')
        
        if lineCount > 1 and alwaysInclude:
                line += alwaysInclude
                print('Added always include extraParams "' + alwaysInclude + '" to command line ' + str(lineCount))
                print('New line is: "' + line + '"')
        
        # This is always the first instance of executing this line (in case there's a repeat option specified)
        repeatCount = 1

        # Set default session ID
        sessionId = DATA.maxAssignedIds['sessionId']
        
        # Do any loop processing.  May skip line.
        (line,result) = loopProcessing(options, line, LoopData, dataFile)
        if not result: continue
    
        # Enter infinite loop.  Will break out depending on repeat value returned
        while True:
                # Call per-line processing
                (step, lclStartTime, repeat, options, sessionId, saveResult) = processSingleLineInput(testName, sessionId, line, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, repeatCount)
                
                # Debug output
                #if options.debug > 0: print 'repeat = ' + str(repeat) + ', repeatCount = ' + str(repeatCount)

                # parameter "repeat" comes back as a string...
                if int(repeat) == int(repeatCount): break

                # Increment counters needed for iteration
                repeatCount += 1
                if not options.stopCountingSteps: step += 1
                
                # Set flag saying it's OK to mess with marks
                DATA.MessWithMarks = True
                
    #-----  Done processing datafile -----

    # ====================== Tell them what we did ======================================
    # Debug output
    if not incFile:
            outputString = '\n\n\nCompleted processing data file "' + inputDataFile + '"'
            print(outputString)

    # Sanity check that we processed at least one line
    if lineCount == 0:  print("WARNING: file contained no executable commands")
    
    # Output test name to debug log file (for each in debugging)
    if (DiameterHostName == MyHostName) or (DiameterHostName == 'localhost'):
        # Local access
        command = 'echo -e "\n\n**** ' + outputString + ' ****\n\n" >> /var/log/mtx/mtx_debug.log'
    else:
        # Need to remotely access the server.
        # NOTE:  can't always do this...
        #command = 'ssh -A mtx@' + DiameterHostName + ' \'echo -e "\n\n**** ' + outputString + ' ****\n\n" >> /var/log/mtx/mtx_debug.log\''
        command = 'echo'

    #print 'command to run: ' + command
    QAUTILS.runCmd(command)
    
    # If we sould save results, do that here.
    # Want just the file name.
    fname = inputDataFile.split('/')[-1]
    
    # See if we should save results for the test run
    if False and saveResult and not fname.startswith('prep'):
        # Debug output
        print('\n\n\n*** Saving data for test ' + fname)
        
        # Remove any currently saved files
        command = 'rm -f expect/*' + fname + '* >/dev/null 2&>1'
        #print command
        QAUTILS.runCmd(command)
        
        # Copy files to expect directory
        f = open('./' + COMMON.resultsDir + '/allMdcFilesList', 'r')
        for fileName in f:
                command = 'cp ' + fileName + ' expect'
                #print command
                QAUTILS.runCmd(command)
        
    return (step, lclStartTime, options, saveResult)

#==========================================================
def getConnection(interface, options):
        if interface.lower() == 'sy':
                if not options.diameterDestinationIpAddressSy: options.diameterDestinationIpAddressSy = QAUTILS.gatewaysConfig.get('DIAMETER','hostname')
                PRIM.connectToDiameterGateway(options.diameterDestinationIpAddressSy, 'sy', options=options, mark='SyStart')
                options.diameterDestinationIpAddressSy = None
                retVal = TRACK.diamConnectionSy
        elif interface.lower() == 'gy':
                if not options.diameterDestinationIpAddressGy: options.diameterDestinationIpAddressGy = QAUTILS.gatewaysConfig.get('DIAMETER','hostname')
                PRIM.connectToDiameterGateway(options.diameterDestinationIpAddressGy, 'gy', options=options, mark='GyStart')
                options.diameterDestinationIpAddressSy = None
                retVal = TRACK.diamConnectionGy
        elif interface.lower() == 'sh':
                if not options.diameterDestinationIpAddressSh: options.diameterDestinationIpAddressSh = QAUTILS.gatewaysConfig.get('DIAMETER','hostname')
                PRIM.connectToDiameterGateway(options.diameterDestinationIpAddressSh, 'sh', options=options, mark='ShStart')
                options.diameterDestinationIpAddressSh = None
                retVal = TRACK.diamConnectionSh
        elif interface.lower() == 'gx':
                if not options.diameterDestinationIpAddressGx: options.diameterDestinationIpAddressGx = QAUTILS.gatewaysConfig.get('DIAMETER','hostname')
                PRIM.connectToDiameterGateway(options.diameterDestinationIpAddressGx, 'gx', options=options, mark='GxStart')
                options.diameterDestinationIpAddressGx = None
                retVal = TRACK.diamConnectionGx
        elif interface.lower() == 'rx':
                if not options.diameterDestinationIpAddressRx: options.diameterDestinationIpAddressRx = QAUTILS.gatewaysConfig.get('DIAMETER','hostname')
                PRIM.connectToDiameterGateway(options.diameterDestinationIpAddressRx, 'rx', options=options, mark='RxStart')
                options.diameterDestinationIpAddressRx = None
                retVal = TRACK.diamConnectionRx
        else:   sys.exit('ERROR: getConnection called with invalid interface: ' + str(interface))
        
        return  retVal

#==========================================================
def parameterManipulation(lclDCT, lclStartTime):
        # Seems typos are an issue for the request type.  Check that here...
        # Also allow other values (map to ones used by this code).
        requestType = lclDCT['requestType']
        if   requestType.startswith('init'):      requestType = 'initial'
        elif requestType == 'start':              requestType = 'initial'
        elif requestType == 'stop':               requestType = 'term'
        elif requestType == 'update':             requestType = 'interim'
        lclDCT['requestType'] = requestType
        
        # Some parameter need a value, so if not defined then set to "None"
        if not lclDCT['verbose']: lclDCT['verbose'] = 'None'
        
        # If futureTime is set to the current time, then there is no future time...
        if lclDCT['futureTime'] == lclStartTime: lclDCT['futureTime'] = None
        
        # Also want to update the local time if we're bumping up the time (as all command times are relative to the current scenario time).
        lclDCT['origStartTime'] = lclStartTime
        lclDCT['systemTime'] = MDCTIME.getTime()
        
        # Always need a valid start time
        if lclDCT['startTime']: lclStartTime = lclDCT['startTime']
        else: lclDCT['startTime'] = lclStartTime
        
        # Ensure start time has the right timezone
        lclStartTime = MDCTIME.getTime(startTime=lclStartTime, tz=lclDCT['subTimeZone'])
        
        # Save local start time
        lclDCT['lclStartTime'] = lclStartTime
        
        # Completion of minor hack:  Store any translated/calculated value back to the more user-friendly msisdn/imsi value
        # But what if msisdn/imsi were entered??  Then we want to store the other way around...
        # At this point, if msisdn entered then use it, else use original parameters.
        if lclDCT['msisdnEntered']: 
                lclDCT['accessNumbers'] = lclDCT['msisdn']
        else:   lclDCT['msisdn']        = lclDCT['accessNumbers']
        if lclDCT['imsiEntered']: 
                lclDCT['deviceId']  = lclDCT['imsi']
        else:   lclDCT['imsi']      = lclDCT['deviceId']
        
        # Zone IP could have a mask - need to remove that.
        if lclDCT['zoneIpAddress']: lclDCT['zoneIpAddress'] = lclDCT['zoneIpAddress'].split('/')[0]
        
        # dateOffset may have special characters that need resolving
        if lclDCT['dateOffset'] and not lclDCT['dateOffset'].isdigit(): lclDCT['dateOffset'] = convertDateOffset(lclDCT['dateOffset'], lclStartTime)
        
        # Can do replacement of any parameter if value is itself a key parameter name.
        # Only if not a changeParameter or increment command (then we lose the reference).
        if lclDCT['ACTION'] not in ['setConstantValue', 'changeParameterValue', 'increment']:
                for parameter in list(lclDCT.keys()):
                        if lclDCT[parameter] in ['externalId', 'deviceId', 'groupId']: lclDCT[parameter] = lclDCT[lclDCT[parameter]]
        
        # offerCycleOffset is not really a time parameter to the engine.  It's a number.  TF defines it as a time
        # parameter.  Need to fix that before API calls.
        if lclDCT['offerCycleOffset']:
                lclDCT['offerCycleOffset'] = lclDCT['offerCycleOffset'].split('T')[0].split('-')[-1]
                print('Updated offerCycleOffset to ' + str(lclDCT['offerCycleOffset']))
        
        # If a referral code is requested, then get it
        '''
        if lclDCT['referralExternalId']:
                # Get the code
                url = '/rsgateway/data/v3/referral_rewards/subscriber/ExternalId+' + lclDCT['referralExternalId']
                q = GET.curlToETFormat(url)
                
                # Get referral field
                lclDCT['ReferralCode'] = q.find('ReferralCode').text
                print('Found referral code: "' + lclDCT['ReferralCode'] + '"')
        '''
                
#==========================================================
def parameterFileReading(lclDCT):
        # Feature to allow a parameter to be populated by a file.
        for parameter in list(lclDCT.keys()):
                # Skip if not set
                if not lclDCT[parameter]: continue
                
                # If a list, then get first element
                if type(lclDCT[parameter]) is list:     item = str(lclDCT[parameter][0])
                else:                                   item = str(lclDCT[parameter])
                
                # Check for key string
                if item.lower().startswith('file:'):
                        # Get the file name
                        fileName = item.split(':')[1]
                        
                        # Debug output
                        print('Parameter ' + parameter + ' reading in file: ' + fileName)
                        
                        # Read into the parameter
                        with open(fileName, 'r') as myfile:
                                fileData = myfile.read().replace('\n', '')
                        
                        # Debug output
                        print(fileData)
                        
                        # Put back in proper place
                        if type(lclDCT[parameter]) is list:
                                # File contents may be a list
                                lclDCT[parameter] = fileData.split(DATA.listChar)
                        else:   lclDCT[parameter] = fileData
                                        
        # *** Done with Parameter Manipulations

#==========================================================
def convertDateOffset(dateOffset, lclStartTime):
        # Want to return a day to set times to.
        # Support basic time offset (e.g. amount,unit)
        
        # Split the remainder of the offset
        offsetData = dateOffset.split(DATA.timeSepChar)
        
        # Get amount and scale
        amount = int(offsetData[0])
        if len(offsetData) > 1: scale = offsetData[1]
        else:                   scale = 'sec'
        
        # Calculate time relative to the input time
        outTime = MDCTIME.getTime(amount, scale, lclStartTime)
        
        # Get the day of the month
        dayOfTheMonth = outTime.split('-')[2].split('T')[0]
        print('convertDateOffset: Returning day ' + dayOfTheMonth)
        
        return dayOfTheMonth
        
#==========================================================
# Manage any Mark sent in the diameter command
def manageMark(lclDCT):
        # *** lclDCT[] has all the values.
        '''
        '''
        # Set referenced locals
        mark = lclDCT['mark']
        subMark = lclDCT['subMark']
        requestType = lclDCT['requestType']
        externalId = lclDCT['externalId']
        deviceId = lclDCT['deviceId']
        accessNumbers = lclDCT['accessNumbers']
        sessionId = lclDCT['sessionId']
        ratingGroup = lclDCT['ratingGroup']
        interface = lclDCT['interface']
        verbose = lclDCT['verbose']
        ACTION = lclDCT['ACTION']
        
        # Now check the value is valid
        if requestType not in ['initial', 'interim', 'term', 'session', 'event']:
                print("ERROR: requestType not a valid value (" + requestType + ").  Must be in ['initial', 'interim', 'term', 'session', 'event']")
                sys.exit('Error on command: ' + ACTION)
        
        # Process mark if a diameter command
        subSession = 0
        if ACTION.startswith('diameter'): (mark, externalId, deviceId, accessNumbers, subSession, sessionId, ratingGroup, interface) = \
                PRIM.getDiamMark(mark, subMark, lclDCT, requestType, externalId, deviceId, accessNumbers, subSession, sessionId, ratingGroup, interface, verbose=verbose)
                
        # Write all of these into lclDct
        lclDCT['interface'] = interface
        lclDCT['mark'] = mark
        lclDCT['externalId'] = externalId
        lclDCT['deviceId'] = deviceId
        lclDCT['accessNumbers'] = accessNumbers
        lclDCT['subSession'] = subSession
        lclDCT['sessionId'] = sessionId
        lclDCT['ratingGroup'] = ratingGroup
        
        return

#==========================================================
# Get the conenction associated with the input command
def getDiameterConnection(interface, options):
        # Set diameter connection value for this command
        if interface.lower().startswith('5g'):
                if not TRACK.diamConnection5G:
                        '''
                        Handler = SimpleHTTPServer.SimpleHTTPRequestHandler
                        httpd = SocketServer.TCPServer(("", 40000), Handler)
                        
                        print "serving at port 40000"
                        httpd.serve_forever()
                        print "Return from call to httpd.serve_forever"
                        '''
                        
                        # Set global (probabaly not needed...)
                        TRACK.diamConnection5G = diamConnection = 'Dummy'
                else:   diamConnection = TRACK.diamConnection5G
        elif interface.lower() == 'gx':
                # Get connection if we need it
                if not TRACK.diamConnectionGx:
                        diamConnection = getConnection('gx', options)
                else:   diamConnection = TRACK.diamConnectionGx
                
        elif interface.lower() == 'gy':
                # Get connection if we need it
                if not TRACK.diamConnectionGy:
                        diamConnection = getConnection('gy', options)
                else:   diamConnection = TRACK.diamConnectionGy
        
        elif interface.lower() == 'sh':
                # Get connection if we need it
                if not TRACK.diamConnectionSh:
                        diamConnection = getConnection('sh', options)
                else:   diamConnection = TRACK.diamConnectionSh
        
        elif interface.lower() == 'rx':
                # Get connection if we need it
                if not TRACK.diamConnectionRx:
                        diamConnection = getConnection('rx', options)
                else:   diamConnection = TRACK.diamConnectionRx
        
        else:
                # Get connection if we need it
                if not TRACK.diamConnectionSy:
                        diamConnection = getConnection('sy', options)
                else:   diamConnection = TRACK.diamConnectionSy
        
        return diamConnection
        
#==========================================================
# Some commands have shortcut syntax, using ACTION parameter prefix characters.  
def actionParameterShortcuts(lclDCT):
        shortcutSplitChar = ':'
        
        # Format is <prefix>parameter:value.  Can't use "=" as that's already part of command line processing.
        # This is restore parameter shortcut
        prefix = '**'
        newAction = 'restoreParameterValue'
        if lclDCT['ACTION'].startswith(prefix):
                lclDCT['paramName'] = lclDCT['ACTION'][len(prefix):].strip()
                
                # Override the action
                lclDCT['ACTION'] = newAction
        
        # This is change parameter shortcut
        prefix = '*'
        newAction = 'changeParameterValue'
        if lclDCT['ACTION'].startswith(prefix):
                # Two values (parameter = value).  Allow value to have shortcutSplitChar in there.
                cmdData = lclDCT['ACTION'][len(prefix):].split(shortcutSplitChar)
                lclDCT['paramName'] = cmdData[0].strip()
                lclDCT['paramValue'] = shortcutSplitChar.join(cmdData[1:]).strip()
                
                # Override the action
                lclDCT['ACTION'] = newAction
        
        # This is set constant value shortcut
        prefix = '$'
        newAction = 'setConstantValue'
        if lclDCT['ACTION'].startswith(prefix):
                # Two values (parameter = value).  Allow value to have shortcutSplitChar in there.
                cmdData = lclDCT['ACTION'][len(prefix):].split(shortcutSplitChar)
                lclDCT['paramName'] = cmdData[0].strip()
                lclDCT['paramValue'] = shortcutSplitChar.join(cmdData[1:]).strip()
                
                # Override the action
                lclDCT['ACTION'] = newAction
        
#==========================================================
def defaultParamReplace(lclDCT, parameter, index=-1):
     #print 'Entered defaultParamReplace'
     while True:
        # If index is not -1, then we need to use the index
        if index == -1: param = lclDCT[parameter]
        else:           param = lclDCT[parameter][index]
        
        # If nothing else to process, then exit
        #print 'Current value of parameter ' + parameter + ' is: ' + str(param)
        
        # If nothing left to repalce, then exit
        if not param.count('defaultParam'): return
        
        # Get default parameter ID
        paramId = param[param.find('defaultParam') + len('defaultParam')]
        
        # Get parameter name
        paramName = 'defaultParam'+paramId

        # See if nothing referencable
        if paramName not in lclDCT and paramName not in DATA.constantValue:
                print('Warning: command referenced ' + paramName + ' but that\'s not defined in the set of default parameters or constants')
                return

        # Variables have priority over constants
        if paramName in lclDCT:
          if lclDCT[paramName] == None:
                print('Warning: command referenced ' + paramName + ' but that\'s not set')
                return
          else: value = lclDCT[paramName]
        else: value = DATA.constantValue[paramName]

        # If here it should work...
        if index == -1:
                lclDCT[parameter] = lclDCT[parameter].replace('defaultParam'+paramId, value)
                print('Default Param logic: Updated parameter ' + parameter + ' to ' + lclDCT[parameter])
        else:
                lclDCT[parameter][index] = lclDCT[parameter][index].replace('defaultParam'+paramId, value)
                print('Default Param logic: Updated parameter ' + parameter + ' index ' + str(index) + ' to ' + lclDCT[parameter][index])
        
#==========================================================
# Update command parmaeters.  Called at command line start and if processing a data file that can reference items like IDs (e.g. next), time (e.g. 1,day)
# Also called for customURL commands.  This is why all the try/except lines were added.  Only want to process the one parameter but code was expcting all parameters.
# Thus added try/except around most everything that didn't already check if the parameter was set.
def updateInputParameters(lclDCT, lclStartTime, options, cmdLineInput):
        # Allow msisdn and imsi to be specified in a command line
        if lclDCT['msisdnEntered'] and lclDCT['imsiEntered']:
#               print 'Setting separate numbers because imsi and msisdn were input'
                options.separateAccessNumbers = True
        
        # Parameters may reference a constant or another parameter.  
        for parameter in lclDCT:
          foundFlag = False
          origValue = str(lclDCT[parameter])
          
          # Setting to get into the while loop
          breakFlag = False
                
          # Loop until no special strings found.  This allows layering of special keys referencing special keys :-).
          while not breakFlag:
            # Assume breaking
            breakFlag = True
                
            # Check for all special characters
            for constantKey in ['$', '*']:
                # See if parameter contains constantKey + '{', which means replace in the middle of the parameter value
                if str(lclDCT[parameter]).count(constantKey+'{') and lclDCT[parameter].count('}'):
                        foundFlag = True
                        breakFlag = False
                        #print 'Processing curly bracket referenced parameter ' + parameter + ' with value ' + str(lclDCT[parameter])
                        lclDCT[parameter] = CSVID.getDataInMiddle(constantKey, parameter, lclDCT)
                
                # See if it starts with the character and is defined as a constant (as currency amounts won't be)
                if str(lclDCT[parameter]).startswith(constantKey):
                        foundFlag = True
                        #print 'Processing referenced parameter ' + parameter + ' with value ' + str(lclDCT[parameter])
                        oldValue = lclDCT[parameter]
                        lclDCT[parameter] = CSVID.getData(constantKey, parameter, lclDCT)
                        
                        # Break if we didn;t change the value
                        if oldValue != lclDCT[parameter]: breakFlag = False
                        
                # Constant itself could be comprised of constants :-).  Allow for this..
                if str(lclDCT[parameter]).count(constantKey+'{') and lclDCT[parameter].count('}'):
                        foundFlag = True
                        breakFlag = False
                        #print 'Processing curly bracket 2 referenced parameter ' + parameter + ' with value ' + str(lclDCT[parameter])
                        lclDCT[parameter] = CSVID.getDataInMiddle(constantKey, parameter, lclDCT)
                
          # If something found then output
          if foundFlag: print('Updated parameter ' + parameter + ' from "' + origValue + '" to "' + str(lclDCT[parameter]) + '"')
        
        # If repeating a command, then update the mark.  Skip if doing a command that wants to avoid this (OK: hack).
        try:
         if lclDCT['mark'] and lclDCT['repeatCount'] > 1 and DATA.MessWithMarks:
                # Get numeric part of the mark
                if lclDCT['mark'][-1].isdigit(): markIndex = re.match('.*?([0-9]+)$', lclDCT['mark']).group(1)
                else:
                        markIndex = '0'
                        lclDCT['mark'] += markIndex
                
                # Add to the mark.  Always add repeat count - 1 from what was defined so we get a sequential mark regardless of where the user started.
                lclDCT['mark'] = lclDCT['mark'][:-len(markIndex)] + str(int(lclDCT['repeatCount']) + int(markIndex)-1)
                print('Mark updated to "' +  lclDCT['mark'] + '" as part of repeat step ' + str(lclDCT['repeatCount']) + ' processing')
        except: pass
                
        # One more level of indirection.  If parameter value is 'defaultParamx' AND that parameter has been set, then override the value.
        for parameter in lclDCT:
                # Don't convert the paramName parameter (duh...).
                # Also, process list items below.
                if parameter == 'paramName' or parameter in DATA.listParameters: continue
                
                # See if parameter needs to be dereferenced.  Could be anywhere in the parameter value.
                if str(lclDCT[parameter]).count('defaultParam'):
                        defaultParamReplace(lclDCT, parameter)
                
        # *** At this time, all parameters should have something in lclDCT ***
        
        # Parameters can request random values
        PRIM.randomParameters(lclDCT, lclStartTime)
        
        # If MEF analysis desired, then need to wait for old command MEF data to flush
        try:
         if lclDCT['mefProcessingData']:
                # If not local then skip this
                if not DATA.runningLocal:
                        print('WARNING: TF not running on a PROC blade.  Skipping MEF processing')
                        lclDCT['mefProcessingData'] = None
                else:
                        # Need to wait for old MEF data to drain if the previous command didn't specify MEF processing
                        if not DATA.previousCommandMefDataProcessed:
                                timeToSleep = 1
                                print('mefProcessingData parameter entered.  Need to sleep ' + str(timeToSleep) + ' so previous old command MEF data is written.')
                                time.sleep(timeToSleep)
                                print('Completed waiting for old command MEF files to drain')
                        
                        # Reset MEF file time stamp
                        PRIM.initMefFileValues(printFlag=True)
        except: pass
                
        # Get list parameters into their proper python format.
        for param in DATA.listParameters:
                # If not defined, then skip
                if param not in lclDCT: continue
                if not lclDCT[param]: continue
                
                # Convert input to list
                lclDCT[param] = CSVQA.convertToolListToPythonList(lclDCT[param])
                
                # List values may need defaultParam dereferencing
                for i in range(len(lclDCT[param])):
                        # Get the item
                        item = lclDCT[param][i]
                        
                        # See if parameter needs to be dereferenced
                        if str(item).count('defaultParam'): defaultParamReplace(lclDCT, param, index=i)
                
        # If there are any parameters that can be translated (e.g. "free" to "1"), then do that here.
        # DO NOT add checks for parameter in lclDCT here.  Let the data go through.  Special cases require this function be executed.  
        for parameter in DATA.parameterTranslate: PRIM.translateTextFromMapping(parameter, lclDCT)
        
        # May have translated a list item into an additional set of lists.  Cover that case here by repeating the conversoin.
        for param in DATA.listParameters:
                # If not defined, then skip
                if param not in lclDCT: continue
                if not lclDCT[param]: continue
                
                # Convert input to list
                lclDCT[param] = CSVQA.convertToolListToPythonList(lclDCT[param])
        
                # List values may need defaultParam dereferencing
                for i in range(len(lclDCT[param])):
                        # Get the item
                        item = lclDCT[param][i]
                        
                        # See if parameter needs to be dereferenced
                        if str(item).count('defaultParam'): defaultParamReplace(lclDCT, param, index=i)
                
        # Need to account for time parameters, as they may be still relative to the actual time
        for lclVar in DATA.timeParameters: 
                if lclVar in lclDCT:
                        # Save original - may be needed later
                        lclDCT['saved'+lclVar] = lclDCT[lclVar]
                        
                        # Skip if not set
                        if lclDCT[lclVar] == None: continue
                        
                        # Special case - if set to "billcycle" then need to read object and get the next bill cycle time.
                        # Note that the bill cycle may not be set, in which case we use the input time.
                        if lclDCT[lclVar].lower() == 'billcycle':
                                retVal = PRIM.getNextBillCycleStartTime(lclDCT, lclStartTime, False)
                                if retVal: lclDCT[lclVar] = retVal
                                else:      lclDCT[lclVar] = lclStartTime
                        
                        # NEW ADDITION:  If time value is special string then change to an empty string,
                        # else get translated time value
                        if str(lclDCT[lclVar]).lower() in ['empty', 'blank']:   lclDCT[lclVar] = ''
                        else:                                                   lclDCT[lclVar] = CSVID.getCommandLineTime(lclVar, lclDCT[lclVar], lclStartTime, DATA.timeSepChar)
        
        # ** Start special parameter conversion code
        # ULI and/or TgppSgsnMccMnc may only contain the MCC.  Default MNC if so.
        # If an empty string then set to None (as QA code will add these if not set to None).
        try:
         for parameter in ['uli', 'TgppSgsnMccMnc']:
                if lclDCT[parameter] and len(lclDCT[parameter]) == 3:
                        lclDCT[parameter] += '00'
                elif not lclDCT[parameter]:     lclDCT[parameter] = None
        except: pass
        
        # ULI is a special case
        try:
         if lclDCT['uli']:
                #print 'uli before conversion: ' + str(lclDCT['uli'])
                lclDCT['uli'] = diameter_utils.encode3GPPUserLocationInfo(lclDCT['encodeType'], mcc=lclDCT['uli'][0:3], mnc=lclDCT['uli'][3:], xtra1=lclDCT['ulixtra1'], xtra2 = lclDCT['ulixtra2'])
                #print 'uli after  conversion: ' + str(lclDCT['uli'])
        except: pass
                
        # If the timezone was input, then convert to the right format.
        try:
         if lclDCT['timeZone']:
                savedTzString = lclDCT['timeZone']
                
                # Support an error lag for this parameter (not general purpose functionality)
                if lclDCT['timeZone'].lower() == 'error': lclDCT['timeZone'] = 'ffff'
                else:
                        # If first character is not already the time zone, then need to convert it
                        if lclDCT['timeZone'][0] not in ['-', '+']:
                                # Sometimes startTime not yet set...
                                if lclDCT['startTime'] == None: lclDCT['startTime'] = lclStartTime
                                
                                # Assume it's in the format like Europe/Warsaw.  Convert that to time and get the timezone data
                                tzString = MDCTIME.getTime(startTime=lclDCT['startTime'], tz=lclDCT['timeZone'])[26:]
                                
                                # If a Z then set to 0
                                if tzString[0] == 'Z':  lclDCT['timeZone'] = '+00'
                                else:                   lclDCT['timeZone'] = tzString[0:3]
                        
                        # Convert timezone offset to diameter AVP value
                        lclDCT['timeZone'] = DIAM.convertUtcOffsetToDiameterHexString(float(lclDCT['timeZone']), 0)
                        print('Timezone value: changed from ' + savedTzString + ' to ' + lclDCT['timeZone'])
                        '''
                        except:
                                # This format is consistent with using timeZone as a keyAVP (time zones cause issues so this is recommended)
                                #lclDCT['timeZone'] = MDCTIME.getTime(startTime=lclStartTime, tz=lclDCT['timeZone'])
                                lclDCT['startTime'] = MDCTIME.getTime(startTime=lclStartTime, tz=lclDCT['timeZone'])
                                print 'Except: Time from starting time ' + lclStartTime + ', timezone ' + lclDCT['timeZone'] + ' = ' + lclDCT['startTime']
                        '''
        except: pass
        
        # accessNetwork is a special case
        try:
         if lclDCT['accessType']: lclDCT['accessNetwork'] = diameter_utils.encodeAccessNetwork(lclDCT)
        except: pass
        
        # May have custom mappings that require other parameters to be set (e.g. if a list element is defined, then the list type needs to be defined)
        try:
                CUST.checkAdditionalMappings(lclDCT)
        except:
                kef = 1
        
        # *** Access Numbers used to be a single item.  They really should have been a list all along.  
        # *** If only one access number entered, then turn back to a single item.
        try:
         if len(lclDCT['accessNumbers']) == 1: lclDCT['accessNumbers'] = lclDCT['accessNumbers'][0]
        except: pass
        
        # Process parameters that support units in their input.
        # These may be in the form "1.5KB, or 2Day".  Check for this and adjust to numbers if so.  This is just for ease of input.
        # Note: the parameters may be a list or a single item.
        for params in DATA.unitParameters:
                if params in lclDCT and lclDCT[params] != None: lclDCT[params] = PRIM.convertAmountsToIntegers(lclDCT[params])
        
        # ** End special parameter conversion code
        
        # An easy way to reference a created object is to use their mark
        try:
                PRIM.dereferenceMarks(lclDCT, options)
        except: pass
        
        # Run a second time (just in case): Parameters can request random values
        try:
         PRIM.randomParameters(lclDCT, lclStartTime)
        except: pass
        
        # Add B-party prefix/suffix if defined
        try:
         if lclDCT['calledStation'] and lclDCT['calledStationPrefix']: lclDCT['calledStation'] = lclDCT['calledStationPrefix'] + lclDCT['calledStation']
         if lclDCT['calledStation'] and lclDCT['calledStationSuffix']: lclDCT['calledStation'] += lclDCT['calledStationSuffix']
        except: pass
        
        # MINOR HACK: if command is add next subscriber, then set key ID parameters to "next"
        try:
         if lclDCT['ACTION'] == 'addNextSubscriber':
                lclDCT['externalId'] = lclDCT['deviceId'] = lclDCT['accessNumbers'] = 'next'
        except: pass
        
        # Update parameters that can use the 'next', 'last', etc. values to reference an ID
        for param in DATA.idParameter: 
                # Get the variable name and value
                name = param[0]
                if name not in lclDCT: continue
                
                # Get parameter value
                value = lclDCT[name]
                
                # If the parameter is not set, then skip it
                if value == None or value == '': continue
                
                # Get mark allowed value
                markAllowed = param[1]
                
                # Get the ID
                # Also return an optional second parameter, which is the access number if the input is the device ID (special case).
                #print 'name = ' + str(name) + ', value = ' + str(value)
                (lclDCT[name], extra) = CSVID.getAbsoluteIdValue(options, name, value, markAllowed)
                #print 'updateInputParameters: name/old value/new value = ' + name + '/' + value + '/' + lclDCT[name]
                
                try:
                 # Special case - if extra is defined and we're not unconditionally separating access number from device ID and there's no input access number, 
                 # then use the extra as the access number.  Do the same check for IMEI
#                print 'extra = ' + str(extra) + ', accessNumbers = ' + str(accessNumbers) + ', options.accessNumbers = ' + str(options.accessNumbers)
                 if extra and not options.separateAccessNumbers and (str(lclDCT['accessNumbers']) == options.accessNumbers): lclDCT['accessNumbers'] = extra
                 if extra and (str(lclDCT['imei']) == options.imei):
                        #print 'Overriding imei from ' + lclDCT['imei'] + ' to ' + str(extra)
                        lclDCT['imei'] = extra
                except: pass
        
        #try:
        if True:
         #print 'In last check for input parameters'
         # Add access prefix
         if lclDCT['accessNumbersPrefix']:
                lclDCT['accessNumbers'] = lclDCT['accessNumbersPrefix'] + lclDCT['accessNumbers']
                print('Access number prefix added.  New access number is: ' + lclDCT['accessNumbers'])
        
         # When including the same file, need to modify marks.  Check if a mark prefix was input and update the mark if so.
         if lclDCT['markPrefix'] and lclDCT['mark']: lclDCT['mark'] = lclDCT['markPrefix'] + '_' + lclDCT['mark']
        
         # subMark can take on the name of key parameters (e.g. externalId).  Check for that and udpate here.
         # Need for the value to be a mark, not the actual ID, so get the mark of the referenced object.
         varName = 'externalId'
         if lclDCT['subMark'] == varName:
                # Get into a local
                varValue = lclDCT[varName]
                
                # See if there are any subscriber marks
                if len(TRACK.subscriberTracking[varValue]['mark']):
                        # Can use any of them, so pick the last one.
                        lclDCT['subMark'] = TRACK.subscriberTracking[varValue]['mark'][-1]
                        print('setting subMark "' + varName + '" to mark "' + lclDCT['subMark'] + '"')
                else:   print('WARNING: submark is set to "' + varName + '", which is ' + varValue + ', but it doesn\'t have any marks.')
        
         # Juggle two possible marks (in hind sight maybe not the best way to do things...)
         # subMark has priority over mark at this point in the processing.
         if lclDCT['subMark']:
                # Save the fact that no mark was passed in
                markRestoreFlag = True
                markRestoreValue = lclDCT['mark']
                
                # Copy subMark into mark
                lclDCT['mark'] = lclDCT['subMark']
         else:
                # record that there's nothing to change back afterwards
                markRestoreFlag = False
         
         # Feature to concatenate IDs to make a subscriber ID.  Do that here.  Only do if query type is external ID.
         if lclDCT['subExternalIdPrefix']   and lclDCT['subQueryType']   == 'ExternalId': lclDCT['externalId'] = lclDCT['subExternalIdPrefix'] + lclDCT['externalId']
         if lclDCT['groupExternalIdPrefix'] and lclDCT['groupQueryType'] == 'ExternalId': lclDCT['groupId'] = lclDCT['groupExternalIdPrefix'] + lclDCT['groupId']
         if lclDCT['devExternalIdPrefix']   and lclDCT['devQueryType']   == 'ExternalId': lclDCT['deviceId'] = lclDCT['devExternalIdPrefix'] + lclDCT['deviceId']
                
         # Check for mark.  Higher priority than prefix strings
         if lclDCT['mark']: 
                # Special processing if mark set to "externalId"
                if lclDCT['mark'].lower() == 'externalid':
                        # Get device ID from saved subscriber data
                        lclDCT['deviceId'] = TRACK.subscriberTracking[lclDCT['externalId']]['deviceId'][0]
                        lclDCT['accessNumbers'] = '-1'
                        
                        # Don't restore the mark in this case
                        lclDCT['mark'] = None
                        markRestoreFlag = False

                # Else set external ID, deviceID and clear access number if this is a subscriber mark
                elif lclDCT['mark'] in TRACK.subscriberTracking: 
                        print('Resetting external ID because mark already set: ' + lclDCT['mark'])
                        lclDCT['externalId'] = TRACK.subscriberTracking[lclDCT['mark']]
                        lclDCT['deviceId'] = TRACK.subscriberTracking[lclDCT['externalId']]['deviceId'][0]
                        lclDCT['accessNumbers'] = '-1'
         
                # Set group ID if this is a group mark
                elif lclDCT['mark'] in TRACK.groupTracking: lclDCT['groupId'] = TRACK.groupTracking[lclDCT['mark']]
         
                # Set user ID if this is a user mark
                elif lclDCT['mark'] in TRACK.userTracking: lclDCT['userId'] = TRACK.userTracking[lclDCT['mark']]
         
                # If mark is not currently valid, then it'll be used to mark the object or diameter session.
        
         # Post mark processing:  if we need to restore it, then do so
         if markRestoreFlag: lclDCT['mark'] = markRestoreValue
         
         # *** Parameter Manipulations ***
         parameterManipulation(lclDCT, lclStartTime)
        
         # Build custom attribute structures needed for subman commands
         (devAttr, subAttr, groupAttr, offerAttr, userAttr, loginAttr, apiEventDataAttr) = PRIM.getCustomAttributes(lclDCT, cmdLineInput)
         #print 'apiEventDataAttr = ' + str(apiEventDataAttr)
        
         #print 'Getting custom data'
         # Add custom structures to the local dictionary
         lclDCT['customAttr'] = ((devAttr, subAttr, groupAttr, offerAttr, userAttr, loginAttr, apiEventDataAttr))
        
         # Really bad hack.  Store command time in a global.  
         # Issue with curl commands not having time means they execute "now" which wrecks havoc on events in the past.
         # So use a global (too many places to edit otherwise to pass through a timestamp).
         GET.commandTime = lclDCT['startTime']
        
         # Assume we're going to save a subscriber MDC.
         lclDCT['saveFunc'] ='saveMDC'
         
         # Service may actually be a child service
         lclDCT['childService'] = lclDCT['serviceId']
         
         # Prioritize offerIsxxx parameters based on which was input
         if   cmdLineInput.count('offerIsExternal'): lclDCT['offerIsCatalog']  = not lclDCT['offerIsExternal']
         elif cmdLineInput.count('offerIsCatalog'):  lclDCT['offerIsExternal'] = not lclDCT['offerIsCatalog']
         
        #except: pass
        
#==========================================================
def startHTTPServer(lclDCT, options):
        # If already running for this test, then do nothing
        if FIVEG.FiveGServerRunning: return
        
        # See if we need to start the server.  Two possible commands to get the PID.
        '''
        pid = QAUTILS.runCmd('sudo netstat -tulpn | grep 8000 | grep LISTEN | cut -c81- | cut -f1 -d"/"').strip(' ')
        if not pid: pid = QAUTILS.runCmd('ps aef | grep http.*Server | grep -v grep').strip(' ').split(' ')[0]
        '''
        # Always start HTTP server, using dynamic port logic below
        pid = False
        
        # If already running then set global data and exit
        if pid:
                # Already running, so we don't want to touch it
                print('5G Server already running - don\'t touch')
                FIVEG.FiveGServerRunning = True
                return
        
        # Start server.  Which to start depends on the desired HTTP action.
        if lclDCT['httpLevel'] == 1:    fileName = 'http1Server.py'
        else:                           fileName = 'http2Server.py'
        filePath = os.path.expandvars(os.getenv('QACOMMON', '/home/mtx/workspace/trunk/MTXQA/Common')) + '/' + fileName
        
        # HTTP server has some debug logic.  Add parameters to the call.
        cmdExtra = ' --verbose ' + lclDCT['verbose']
                
        # Get SBA notify URL definition, so we can extract the IP and port for the server
        url = QAUTILS.gatewaysConfig.get('SBA', 'notifyuri')
        
        # If quotes in the data then get rid of them
        if url.count('"'): url = url.split('"')[1]
        
        # *** For regression need different port per run ***
        sbaPort = url.split('/')[2].split(':')[1].split('/')[0]
        
        # Port may be absolute or request a random value
        if sbaPort.count('{'):
                print('Getting random SBA notify port between ' + str(options.portStart) + ' and ' + str(options.portStop))
                sbaPort = str(random.randint(options.portStart,options.portStop))
        
        # Sanity check the port is an int
        if not sbaPort.isdigit(): sys.exit('ERROR: SBA port resolution resulted in non-integer: "' + sbaPort + '".  Must be a number')
        
        # Add to the command line
        cmdExtra += ' --port ' + sbaPort
        
        # Assign to global
        QAUTILS5G.sbaPort = sbaPort
        
        # Run function to address if IP is absolute or an interface
        QAUTILS5G.notifyUri = QAUTILS5G.updateNotifyUriIpAndPort(url)
        
        # Build command to execute
        command = filePath + cmdExtra + ' &'                            
        print('Running command: ' + command)
        os.system(command)
        
        # Give the proces time to start
        i = 0
        sleepTime=0.5
        pid = ''
        while int(i) < int(lclDCT['timeToWait']) and not pid.strip():
                # Sleep for a bit
                time.sleep(sleepTime)
                i += sleepTime
                
                # See if program server.  Two possible commands to get the PID.
                pid = QAUTILS.runCmd('sudo netstat -tulpn | grep :' + QAUTILS5G.sbaPort + ' | grep LISTEN | cut -c81- | cut -f1 -d"/"').strip(' ')
        
        # Did we find the pid??
        if not pid: sys.exit('ERROR: the command failed')
        print('HTTP server started and ready for connections')
        
        # Set flag indicating TF started the HTTP server
        FIVEG.FiveGServerRunning = True
        print('Started 5G HTTP ' + str(lclDCT['httpLevel']) + ' Server')
        
        # Create flag file (so QA code can stop this if we exit prematurly)
        httpFile = os.getcwd() + '/' + COMMON.resultsDir + '/httpCreated'
        f = open(httpFile, 'w')
        f.write(QAUTILS5G.sbaPort)
        f.close()
        
#==========================================================
# The workhorse function...
def processSingleLineInput(testName, sessionId, line, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, repeatCount):
        global commentStringEnabled
        
        # Assume no errors
        errorFlag=False
        
        # Assume no change in the session ID parameter
        returnSessionId = sessionId
        
        # Save start of command time
        savedCommandStartTime = lclStartTime
        
        # For later code...
        filterPass = True
        
        # Default to not switching REST APIs
        switchFlag = False
        
        # Assume debug restore not needed
        debuglevelRestore = None
        
        # Command separator string (always output)
        print('\n****************************************************************************\n')
        
        # Sleep a miniscule amount, so other processes can jump in
        time.sleep(0.1)
        
        # Output command
        print('Executing command: "' + line + '" with input time = ' + lclStartTime)
        
        # If time of last command not set, then set here (covers initial command)
        if not DATA.timeOfLastCommand: DATA.timeOfLastCommand = lclStartTime
        
        # ====================== Get parameters for this command, then translate/manipulate as needed  ======================================
        # Restore extraAVP, so we don't have any residual settings from the previous command
        extraAVP = copy.deepcopy(lclExtraAvp)

        # Define list that will highlight if something was input in the command line
        cmdLineInput = []
        
        # Get parameters from the command line
        lclDCT = PRIM.dataFileProcessLine(line, headers, DATA.fullList, commentStringEnabled)
        
        # Add the step value here (so it can be passed around and updated by commands)
        lclDCT['step'] = step
        
        # Add in the tets name (used elsewhere)
        lclDCT['testName'] = testName
        
        # Add repeat count (may be used to update marks)
        lclDCT['repeatCount'] = repeatCount
        
        # Set local time if not already present
        if 'lclStartTime' not in lclDCT: lclDCT['lclStartTime'] = lclStartTime
        
        # OK; here's a minor hack.  Use initial ACTION parameter characters for shortcuts.
        # Also do only if comment string not enabled, as we might have skipped constant settings and thus will fail.
        if (not lclDCT['ACTION'][0].isalpha()) and (not commentStringEnabled): actionParameterShortcuts(lclDCT)
        
        # Get value for each parameter for this command.  It may come from:
        #       a) the command itself (so already in lclDCT[])
        #       b) from default values in the script invocation
        #       c) from parameter defaults hard-coded in Python.  
        # The key is to get a value for each parameter.
        for lclVarTuple in DATA.fullList: PRIM.getVarValue(options, cmdLineInput, extraAVP, lclDCT, lclVarTuple[0])
        
        #if lclDCT['offerId']: print 'Offer ID = ' + str(lclDCT['offerId'])
        
        # Parameter "interface" added late.  It's replacing diameterCommand (to get away from the word "diameter").
        # To keep backwards compatible, if interface not set then set it to the diameterCommand parameter (as that parameter remains).
        if not lclDCT['interface']: lclDCT['interface'] = lclDCT['diameterCommand']
        
        # If command won't execute due to if/else or comment, then skip everything else...
        if lclDCT['ACTION'] not in [commentString, 'if', 'else', 'elif', 'fi']:
                retFlag = False
                if commentStringEnabled:
                        # In the middle of a comment.  Ignore the line.
                        print('Ignoring line due to comment string enabled')
                        retFlag = True
                # See if in an if/else and we should skip
                elif len(ifElseLocation) and \
                     (ifElseLocation[-1] in ['if', 'else'] and ifStatus[-1] in [False, 'skip']):
                        # In the middle of if/else that should be skipped.  Ignore the line.
                        print('Ignoring line due to in ' + ifElseLocation[-1] + ' and status is ' + str(ifStatus[-1]))
                        retFlag = True
                        
                # If skipping then exit with repeatCount passed back (which will terminate this command)
                if retFlag: return (lclDCT['step'], lclDCT['lclStartTime'], repeatCount, options, returnSessionId, lclDCT['saveResults'])
        
        # Only do this if not in a comment string.  Really should skip this whole section if in a comment string...
        savedStartTimeFromRemove = None
        if not commentStringEnabled:
         # Minor hack:  Added msisdn and imsi parameters late.  Much clearer to use these than accessNumbers and deviceId.
         #              Code uses the latter two (much too late to change everything).  Sooo, if msisdn/imsi specified and the 
         #              counterpart not, use that.
         # AHHHH!  If doing a remove opeation and passed in IMSI/MSISDN then will lose the OID here.  Only do if not using a device OID.
         #         Only do this if devQueryType is not ObjectId.
         if lclDCT['devQueryType'] != 'ObjectId':
                if lclDCT['msisdn']:
                        lclDCT['msisdnEntered'] = True
                        lclDCT['accessNumbers'] = lclDCT['msisdn']
                else:   lclDCT['msisdnEntered'] = False
                if lclDCT['imsi']:
                        lclDCT['imsiEntered'] = True
                        lclDCT['deviceId'] = lclDCT['imsi']
                else:   lclDCT['imsiEntered'] = False
         else:
                # MSISDN/IMSI not entered if OID specified
                lclDCT['imsiEntered'] = False
                lclDCT['msisdnEntered'] = False
        
         # Parameters can be read from a file
         parameterFileReading(lclDCT)
        
         # ** Special case;  if any parameter in the command is set to <all>, then we want to write all variations of the command.
         if line.count('<all>'): 
                PRIM.generateCommandCombinations(line, lclDCT)
                
                # Debug output
                #if options.debug > 0: print '\n** Completed command: ' + lclDCT['ACTION'] + '\n'
                if options.debug > 0: print('\n** Completed command\n')
                
                # Exit from the command
                return (lclDCT['step'], lclStartTime, lclDCT['repeat'], options, returnSessionId, lclDCT['saveResults'])
                
         # Update parameters
         updateInputParameters(lclDCT, lclStartTime, options, cmdLineInput)
        
         # Set URL base per-command, as we sometimes need to switch between subscription and subscriber
         if lclDCT['useNewDataModel']:  REST_UTIL.setSubUrl("subscription")
         else:                          REST_UTIL.setSubUrl("subscriber")
         
         # If noChecks and a mark specified then this won't work
         if lclDCT['noChecks'] and lclDCT['mark']:
                print('ERROR: can\'t specify a mark and have noChecks set.  mark = ' + lclDCT['mark'] + ', noChecks = ' + str(lclDCT['noChecks']))
                sys.exit('Exiting due to test file errors')
        
         # saveData not applicable to event store queries (response is so different).  Flag that here.
         if lclDCT['saveData'] and lclDCT['ACTION'].count('EventStore'): 
                print('ERROR: saveData only works with event queries, not eventstore queries.  Response between the two is too differnet.  Please use the event query command')
                sys.exit('Exiting due to test file errors')
         
         # If running a 5G command make sure the 5G HTTP server is running
         #if lclDCT['interface'].lower().startswith('5g') and not FIVEG.FiveGServerRunning: startHTTPServer(lclDCT, options)
         
         # Debug output
         if lclDCT['verbose'].lower() in ['high']:
          print('\n** Starting command: ' + lclDCT['ACTION'])
          print('Absolute IDs for this command:')
          print('Group ID = ' + str(lclDCT['groupId']))
          print('SubGroup ID = ' + str(lclDCT['subGroupId']))
          print('external ID = ' + str(lclDCT['externalId']))
          print('Device ID = ' + str(lclDCT['deviceId']))
          print('User ID = ' + str(lclDCT['userId']))
          print('Access Numbers ID = ' + str(lclDCT['accessNumbers']))
          print('Offer ID = ' + str(lclDCT['offerId']))
          print('Event Start Time = ' + str(lclStartTime))
          print('Event Pass = ' + str(lclDCT['eventPass']))
          print('\n')
#        elif lclDCT['verbose'].lower() not in ['low', 'none']: print '\n** Starting command: ' + lclDCT['ACTION'] + ', Event Start Time = ' + str(lclStartTime)
        
         # If removing something that has a bill cycle, then need to ensure we set the TF time to the current bill cycle.
         # Otherwise command will error out (needs to be in current bill cycle).
         savedStartTimeFromRemove = None
         if (lclDCT['ACTION'].startswith('remove') and lclDCT['ACTION'] not in ['removeUser', 'removeDevice']) or \
            (lclDCT['ACTION'].startswith('delete') and lclDCT['ACTION'] not in ['deleteDevice', 'deleteUser']):
                # Get object data
                if lclDCT['ACTION'] not in ['removeGroup', 'deleteGroup']:
                        objId = lclDCT['externalId']
                        objType='subscriber'
                        queryType = lclDCT['subQueryType']
                else:
                        objId = lclDCT['groupId']
                        objType='group'
                        queryType = lclDCT['groupQueryType']
                
                # Query wallet
                q = GET.getObjectWallet(objId, hostname=QAUTILS.gatewaysConfig.get('REST', 'restServer'), hostport=QAUTILS.gatewaysConfig.get('REST', 'restPort'), queryType=queryType, objType=objType)
                
                # Only do something is we received data back
                if q is not None:
                        # Get bill cycle data
                        xmlDctName = './BillingCycle/MtxBillingCycleInfo'
                        dct = {}
                        dct = XML.getObjectStructureFields(q, dct, xmlDctName)
                        #pprint.pprint(dct)
                        
                        # Check if defined
                        if 'CurrentPeriodStartTime' in dct:
                                # Save current time
                                savedStartTimeFromRemove = lclDCT['lclStartTime']
                                lclStartTime = startTime = lclDCT['startTime'] = lclDCT['lclStartTime'] = dct['CurrentPeriodStartTime']
                                print('Resetting TF time to start of bill cycle: ' + dct['CurrentPeriodStartTime'])
                
         # If event time lower bound is 0, then set to the saved last command time so it defaults to processing the previous command
         if not lclDCT['eventTimeLowerBound']: lclDCT['eventTimeLowerBound'] = DATA.timeOfLastCommand
        
         # If repeating, then add a repeat counter indication
         if repeatCount > 1:
                extraString=' (' + str(repeatCount) + ')'
         else:
                extraString=''
        
         # Output per-command line information (if defined) and verbose allows it
         if lclDCT['verbose'].lower() not in ['low', 'none'] and (lclDCT['outputString'] or extraString):
          print(lclDCT['outputString'] + extraString)
          print('\n')
        
         # Output string to debug log file if local host (as remote requires SSH and sometimes that's not enabled ...).
         # Only do this is results are desired.
         if (not lclDCT['noResults']) and (DiameterHostName == MyHostName) or (DiameterHostName == 'localhost'):
                '''
                # If defined, use output string as-is, else use input command line
                if len(lclDCT['outputString'].strip()) > 0: outstr = lclDCT['outputString'] + extraString
                else:                                       outstr = line + extraString
                '''
                outstr = line + extraString
                
                # Run the echo command.
                # Echoing constants causes issues, so escape the $
                command = 'echo -e "\n\n**** TEST FRAMEWORK step ' + str(step) + ': ' + outstr.replace('$', '\$')  + ' ****\n\n" >> /var/log/mtx/mtx_debug.log'
                QAUTILS.runCmd(command)
        
         # Set target in case we want to do event viewing/processing
         target = None
                
         # See if we should update global debug levels
         if str(lclDCT['debug']) != str(QAUTILS.DebugLevel):
                print('NOTE: Individual command requested a different debug level.  Changing from ' + str(QAUTILS.DebugLevel) + ' to ' + str(lclDCT['debug']) + '.')
                debuglevelRestore = str(QAUTILS.DebugLevel)
                
                # Set global debug level
                QAUTILS.DebugLevel = int(lclDCT['debug'])
                
         # If user specified a per-command change, allow this
         if lclDCT['rest'].upper() != REST_UTIL.restVersion:
                switchFlag = lclDCT['rest'].upper()
                # Debug output
                print('NOTE: Individual command requested a different REST interface.  Converting from ' + str(REST_UTIL.restVersion) + ' to ' + switchFlag + '.')
                
         elif REST_UTIL.restVersion != 'JSON' and lclDCT['outputFileName'] and lclDCT['outputFileName'].lower() == 'view':
                switchFlag = 'JSON'
                # Debug output
                print('NOTE: option outputFileName set to ' + lclDCT['outputFileName'] + ' command needs ' + switchFlag + ' format.  Converting to ' + switchFlag + '.')
         # Multi Request processing needs MDC to setup payloads.  Don't change on MR start or stop (start is benign, but stop would be bad).
         elif REST_UTIL.restVersion != 'MDC' and DATA.mrEnabled and lclDCT['ACTION'] != "mrStop":
                switchFlag = 'MDC'
                # Debug output
                print('NOTE: Multi-Request processing needs MDC format (to build message).  Converting to ' + switchFlag + '.')
         # NOTE: need to change default provisioning command format as certain combinations are not supported.
         # Offer purchase needs to be REST (need full response to process more than one returned data; TF needs REST for this).
         elif REST_UTIL.restVersion != 'REST' and lclDCT['ACTION'].lower().count('subscribetooffer'):
                switchFlag = 'REST'
                # Debug output
                print('NOTE: ' + lclDCT['ACTION'] + ' needs REST format.  Converting to ' + switchFlag + '.')
         # Device purchase offer needs same mapping
         elif REST_UTIL.restVersion != 'REST' and lclDCT['ACTION'].lower().count('purchaseoffer'):
                switchFlag = 'REST'
                # Debug output
                print('NOTE: ' + lclDCT['ACTION'] + ' needs REST format.  Converting to ' + switchFlag + '.')
         # Event store processing needs to be MDC
         elif REST_UTIL.restVersion == 'JSON' and lclDCT['saveData'] and not lclDCT['ACTION'].startswith('streamCompare'):
                switchFlag = 'MDC'
                # Debug output
                print('NOTE: saveData option needs non-JSON format.  Converting to ' + switchFlag + '.')

         elif REST_UTIL.restVersion != 'JSON' and lclDCT['ACTION'] in ['deviceRating']:
                switchFlag = 'JSON'
                # Debug output
                print('NOTE: ' + lclDCT['ACTION'] + ' needs JSON format.  Converting to ' + switchFlag + '.')
         elif REST_UTIL.restVersion == 'MDC' and (lclDCT['saveEvents'] or lclDCT['saveNotifications']):
                switchFlag = 'REST'
                # Debug output
                print('NOTE: parameters saveEvents and saveNotifications need non-' + REST_UTIL.restVersion + ' format.  Converting to ' + switchFlag + '.')
         elif REST_UTIL.restVersion != 'REST' and lclDCT['ACTION'].count('EstimateRecurringCharge'):
                switchFlag = 'REST'
                # Debug output
                print('NOTE: ' + lclDCT['ACTION'] + ' command needs ' + switchFlag + ' format.  Converting to ' + switchFlag + '.')
         elif REST_UTIL.restVersion != 'JSON' and lclDCT['ACTION'].startswith('streamCompare'):
                switchFlag = 'JSON'
                # Debug output
                print('NOTE: ' + lclDCT['ACTION'] + ' command needs ' + switchFlag + ' format.  Converting to ' + switchFlag + '.')
         elif REST_UTIL.restVersion == 'MDC' and lclDCT['ACTION'] in ['createSubscriberAndDevice']:
                switchFlag = 'REST'
                # Debug output
                print('NOTE: ' + lclDCT['ACTION'] + ' needs non-' + REST_UTIL.restVersion + ' API.  Converting to ' + switchFlag + '.')
         elif REST_UTIL.restVersion != 'REST' and (lclDCT['ACTION'].count('User') or lclDCT['ACTION'].count('Subscription')) and lclDCT['ACTION'] != 'createUserAndSubscriptionAndDevice':
                switchFlag = 'REST'
                # Debug output
                print('NOTE: ' + lclDCT['ACTION'] + ' command needs ' + switchFlag + ' format.  Converting to ' + switchFlag + '.')
         elif REST_UTIL.restVersion != 'REST' and lclDCT['ACTION'].startswith('delete'):
                switchFlag = 'REST'
                # Debug output
                print('NOTE: ' + lclDCT['ACTION'] + ' command needs ' + switchFlag + ' format.  Converting to ' + switchFlag + '.')
         '''
         elif REST_UTIL.restVersion != 'REST' and lclDCT['eventProcessing'] and not lclDCT['ACTION'].count('QueryEvent'):
                switchFlag = 'REST'
                # Debug output
                print 'NOTE: event processing needs to be ' + switchFlag + ' for TF to proper decode.'
         '''
        
         # Switch if needed
         if switchFlag: RESTInst = REST_UTIL.switchVersion(RESTInst, switchFlag)
        
         # We may want to filter out this command...
         if 'filterCmd' in lclDCT and lclDCT['filterCmd'] and len(lclDCT['filterCmd']) and not commentStringEnabled:
                # Process each filter item
                for filterCmd in lclDCT['filterCmd']:
                        # Get components
                        variable = filterCmd.split(',')[0]
                        value    = filterCmd.split(',')[1]
                        
                        # Address true/false items (most used filterCmd values)
                        if    value.lower() in ['true',  '1']: value = [True,  '1', 1]
                        elif  value.lower() in ['false', '0']: value = [False, '0', 0]
                        else: value = [value]
                        
                        # Check for parameter name vs constant (which will already have been evaluated)
                        if variable in lclDCT:
                                print('Checking filterCmd = ' + filterCmd + ', variable/value = ' + variable + '/' + str(value))
                                
                                # Get variable value
                                varValue = lclDCT[variable]
                                
                                print('Variable ' + variable + ' = ' + str(varValue))
                        else:
                                # Use constant
                                varValue = variable
                                
                                print('Checking filterCmd = ' + filterCmd + ', constant/value = ' + str(varValue) + '/' + str(value))
                        
                        # Debug putput
                        
                        # Check parameter not set
                        if varValue == 'None' and str(value[0]).lower() != 'none':
                                print('command ' + lclDCT['ACTION'] + ' filter ' + variable + ' failed.  Value is ' + str(varValue) + ', filter value is ' + str(value[0]))
                                filterPass = False
                                break
                        
                        # See if values are different
                        if varValue not in value:
                                print('command ' + lclDCT['ACTION'] + ' filter ' + variable + ' failed.  Value is ' + str(varValue) + ', filter value is ' + str(value))
                                filterPass = False
                                break
        
         # If snmp data involved, then need to do setup work
         if lclDCT['snmpCheck']: SNMP.SNMPCommandSetup(lclDCT)
        
        # If in a Multi-request, then bump the index before the command
        if DATA.mrEnabled: DATA.mrIndex += 1
        
        # TF defaults routingType to non-None but routingValue to None.  This causes MDC interface errors...
        if not lclDCT['routingValue']: lclDCT['routingType'] = None
        
        # New API parameters defined, but some TF parameters don't default to None, so there were issues in API calls...
        # FIX LATER
        if float(DATA.release) < 5120:
                for param in ['reason', 'info']: 
                        if lclDCT[param].startswith('test_'): lclDCT[param] = None
        
        # One final hack: set tracking noChecks value based on the command value (not passed in API call - need to fix this)
        TRACK.noCheckFlag = lclDCT['noChecks']
        
        # Parameter addlIncludeParameters should extend always include for this command
        if lclDCT['addlIncludeParameters']:
                DATA.alwaysIncludeParameters.extend(lclDCT['addlIncludeParameters'])
                #pprint.pprint(DATA.alwaysIncludeParameters)
        
        # Default target
        target = None
                
        # =========================================================================================
        # =================================   Process Command   ===================================
        # =========================================================================================
        # See if filter failed
        if not filterPass:
                print('Skipping command ' + lclDCT['ACTION'])
        
        # OK, what's the action...
        
        # =========================================================================================
        # ====================================   Comment   ========================================
        # =========================================================================================
        elif lclDCT['ACTION'] == commentString:
                # Start/stop the comment
                commentStringEnabled = 1 - commentStringEnabled
                
                # Debug output
                if commentStringEnabled: print("Comment string enabled")
                else:                    print("Comment string disabled")
                
                # Nothing to query
                queryValue = None
                
                # Set target
                target = None
        
        elif commentStringEnabled:
                # In the middle of a comment.  Ignore the line.
                print('Ignoring line due to comment string enabled')
                
                # Nothing to query
                queryValue = None
                
                # Set target
                target = None
                
        # =========================================================================================
        # ====================================   if/else/fi   ========================================
        # =========================================================================================
        elif lclDCT['ACTION'] == 'fi':
                # Check we're in an if statement
                if not len(ifElseLocation):
                        sys.exit("ERROR: action " + lclDCT['ACTION'] + ' input but not in an "if" consruct')
                
                # End the last if
                # Debug output
                print("Ending if at level " + str(len(ifElseLocation)))
                
                del ifElseLocation[-1]
                del ifStatus[-1]
                
                # Nothing to query
                queryValue = None
                
                # Set target
                target = None
        
        elif lclDCT['ACTION'] in ['if', 'elif', 'else']:
                # Check we're in an if statement
                if lclDCT['ACTION'] != 'if' and not len(ifElseLocation):
                        sys.exit("ERROR: action " + lclDCT['ACTION'] + ' input but not in an "if" consruct')
                
                # See if new level
                if lclDCT['ACTION'] == 'if':
                        # Starting if
                        ifElseLocation.append(('if'))
                        
                        # Debug output
                        print("Starting if at level " + str(len(ifElseLocation)))
                        
                        # If nesting and previous level is false, then force this level to also be false
                        if len(ifStatus) and ifStatus[-1] in [False, 'skip']:
                                print('Forcing this level to be false since previous level is false')
                                ifStatus.append(('skip'))
                        else:
                                # Invoke compare logic to figure things out.  Create new level
                                ifStatus.append(CMDMISC.CmdMisc_compare(lclDCT, options, line, _validate=False))
                
                elif ifStatus[-1] in [True, 'skip']:
                        # Don't execute elif if currently in true statement or previosuly were in a true statement
                        print('Skiping elif at level ' + str(len(ifElseLocation)) + ' becuase currently in True state')
                        ifStatus[-1] = 'skip'
                else:
                        # Debug output
                        print("Starting elif at level " + str(len(ifElseLocation)))
                        
                        # If nesting and previous level is false, then force this level to also be false
                        if len(ifStatus) > 1 and ifStatus[-2] in [False, 'skip']:
                                print('Forcing this level to be false since previous level is false')
                                ifStatus[-1] = 'skip'
                        elif lclDCT['ACTION'] == 'else':
                                # Set to True if here, as else si true if previous items were false
                                print('Forcing else to be true since previous commands were false')
                                ifStatus[-1] = True
                        else:
                                # Invoke compare logic to figure things out.  Overwrite existing level status
                                ifStatus[-1] = CMDMISC.CmdMisc_compare(lclDCT, options, line, _validate=False)
                
                # Report status
                print(lclDCT['ACTION'] + ' status at this level is ' + str(ifStatus[-1]))
        
                # Nothing to query
                queryValue = None
                
                # Set target
                target = None
        
        # See if in an if/else and we should skip
        elif len(ifElseLocation) and \
             (       (ifElseLocation[-1] == 'if'   and ifStatus[-1] in [False, 'skip']) or \
                     (ifElseLocation[-1] == 'else' and ifStatus[-1] != True)       \
             ):
                # In the middle of if/else that should be skipped.  Ignore the line.
                print('Ignoring line due to in ' + ifElseLocation[-1] + ' and status is ' + str(ifStatus[-1]))
                
                # Nothing to query
                queryValue = None
                
                # Set target
                target = None
                
        # =========================================================================================
        # ====================================   Custom    ========================================
        # =========================================================================================
        elif lclDCT['ACTION'].lower().startswith('cust'):
                # Customer may have forgotten to define custom code handler...
                if not hasattr(CUST, "customCommand"):
                        sys.exit('ERROR: custom command invoked but no customCommand() handler defined in custSpecific.py')
                
                # Manage marks as we need to set values that may be restored by the mark
                if lclDCT['mark']: manageMark(lclDCT)
                
                # Get diameter connection 
                if lclDCT['ACTION'].lower().count('diam'): diamConnection = getDiameterConnection(lclDCT['interface'], options)
                else:                                      diamConnection = None
                
                # Invoke custom command handler
                (queryType, queryValue, target) = CUST.customCommand(lclDCT, testName, sessionId, line, headers, extraAVP, options, lclStartTime, RESTInst, step, repeatCount, diamConnection)
        
                
        # =========================================================================================
        # ===========================   Client events  ============================================
        # =========================================================================================
        
        elif lclDCT['ACTION'] == 'clientAddSubscriber' or \
             lclDCT['ACTION'] == 'clientModifySubscriber' or \
             lclDCT['ACTION'] == 'clientQuerySubscriber' or \
             lclDCT['ACTION'] == 'clientGetNotification' or \
             lclDCT['ACTION'] == 'clientClearNotification' or \
             lclDCT['ACTION'] == 'clientPushNotification' or \
             lclDCT['ACTION'] == 'clientSubscribeToOffer':
                cmd = '(_a, _b) = CMDCLIENT.CmdClient_' + lclDCT['ACTION'].lower() + '(lclDCT, options)'
                exec(cmd)
                queryType = locals()['_a']
                queryValue = locals()['_b']
                
                # ** Block query until we get a local testbed
                queryValue = None
                
                # Set target
                target = None
                
        # =========================================================================================
        # ===========================  Payment events  ============================================
        # =========================================================================================
        
        elif lclDCT['ACTION'] == 'paymentCreate' or \
             lclDCT['ACTION'] == 'paymentDelete' or \
             lclDCT['ACTION'] == 'paymentAdd':
                (queryType, queryValue) = CSVBRAINTREE.CmdPayment(lclDCT, options)
                
                # Set target
                target = 'Subscriber'
                
        # =========================================================================================
        # ===========================  CCF events ============================================
        # =========================================================================================
        
        elif lclDCT['ACTION'] == 'ccfEvent' or \
             lclDCT['ACTION'] == 'ccfStartHlr' or \
             lclDCT['ACTION'] == 'ccfStopHlr' or \
             lclDCT['ACTION'] == 'ccfEveryAccessNumberInSubEvent' or \
             lclDCT['ACTION'] == 'ccfEveryAccessNumberInGroupEvent' or \
             lclDCT['ACTION'] == 'ccfEveryAccessNumberEvent':
                (queryType, queryValue) = CCF.CmdCcfEvent(lclDCT, options)
        
                # Set target
                target = 'Subscriber'
                
        # =========================================================================================
        # ===========================  Query CB events ============================================
        # =========================================================================================
        
        elif lclDCT['ACTION'] == 'cbQueryNormalizer' or \
             lclDCT['ACTION'] == 'cbQueryRateTable'  or \
             lclDCT['ACTION'] == 'cbQueryPriceComponent' or \
             lclDCT['ACTION'] == 'cbQueryOfferList' or \
             lclDCT['ACTION'] == 'cbQueryOffer':   
                (queryType, queryValue) = CMDCB.CmdCbQuery(lclDCT, options)
         
                # Set target
                target = None
                
        # =========================================================================================
        # ===========================  HA commands ==============================================
        # =========================================================================================
        
        elif lclDCT['ACTION'] == 'verifyRpm' or \
             lclDCT['ACTION'] == 'stopAndVerifyBlade' or \
             lclDCT['ACTION'] == 'startAndVerifyBlade' or \
             lclDCT['ACTION'] == 'stopAndVerifyEngine' or \
             lclDCT['ACTION'] == 'startAndVerifyEngine' or \
             lclDCT['ACTION'] == 'processRpm' or \
             lclDCT['ACTION'] == 'processCustom' or \
             lclDCT['ACTION'] == 'stopAndVerifyBlade' or \
             lclDCT['ACTION'] == 'startAndVerifyBlade' or \
             lclDCT['ACTION'] == 'stopAndVerifyEngine' or \
             lclDCT['ACTION'] == 'startAndVerifyEngine' or \
             lclDCT['ACTION'] == 'stopHighestNumberedActiveProcessingBlade' or \
             lclDCT['ACTION'] == 'rollEngine' or \
             lclDCT['ACTION'] == 'rollingUpgrade' or \
             lclDCT['ACTION'] == 'restartBladesAll' or \
             lclDCT['ACTION'] == 'restartBladesNoMgmt' or \
             lclDCT['ACTION'] == 'restartEngine' or \
             lclDCT['ACTION'] == 'engineUpgrade' or \
             lclDCT['ACTION'] == 'execPrintBladeStats' or \
             lclDCT['ACTION'] == 'startEngine' or \
             lclDCT['ACTION'] == 'stopEngine' or \
             lclDCT['ACTION'] == 'getAndProcessSnmpQuery' or \
             lclDCT['ACTION'] == 'stopBlade' or \
             lclDCT['ACTION'] == 'startBlade' or \
             lclDCT['ACTION'] == 'getActiveManagementBlade' or \
             lclDCT['ACTION'] == 'getNonActiveManagementBlade' or \
             lclDCT['ACTION'] == 'getManagementBlades' or \
             lclDCT['ACTION'] == 'getActiveProcessingBlade' or \
             lclDCT['ACTION'] == 'getNonActiveProcessingBlade' or \
             lclDCT['ACTION'] == 'getProcessingBlades' or \
             lclDCT['ACTION'] == 'getAllBlades' or \
             lclDCT['ACTION'] == 'getAllActiveBlades' or \
             lclDCT['ACTION'] == 'runSshCmd' or \
             lclDCT['ACTION'] == 'createCheckpoint' or \
             lclDCT['ACTION'] == 'killManagementBlade' or \
             lclDCT['ACTION'] == 'killBladeProcess' or \
             lclDCT['ACTION'] == 'verifyEngineStatus' or \
             lclDCT['ACTION'] == 'haSetup' or \
             lclDCT['ACTION'] == 'processCheckpoint':
                # Run HA setup if it hasn't been run before
                if not HA.engineIpData: HA.haSetup()
                
                # Sanity check cluster data
                if 'peer' not in HA.ClusterMemberData: sys.exit('ERROR:  need to have global peer data when calling startAndVerifyEngine without passing in a dictionary.')
                
                # See if command requires an fqdn
                errorFound = False
                if lclDCT['ACTION'] != 'haSetup':
                        # If fqdn not specified and engine/blade is, then convert
                        if not lclDCT['fqdn'] and lclDCT['ACTION'] != 'haSetup':
                                if not lclDCT['engine']: 
                                        print('ERROR:  must specify fqdn or engine')
                                        
                                        # If not expecting an error, then exit
                                        if not lclDCT['eventPass']: sys.exit('Exiting due to errors')
                                        else: errorFound = True
                                
                                # Convert data
                                else:
                                        lclDCT['fqdn'] = HA.convertEngineAndBladeStatusToFqdn(lclDCT['engine'], lclDCT['engineRelative'], lclDCT['blade'], lclDCT['bladeRelative'])
                                        print('Converted engine/cluster/blade ' + lclDCT['engine'] + '/' + '1' + '/' + str(lclDCT['blade']) + ' to ' + lclDCT['fqdn'])
                                        
                                        # Check for conversion errors
                                        if lclDCT['fqdn'] == '0':
                                                if lclDCT['eventPass']: sys.exit('Exiting due to errors')
                                                else: errorFound = True
                
                # Invoke primitive
                if not errorFound:
                        cmd = '(_a, _b) = CMDHA.CmdHa_' + lclDCT['ACTION'].lower() + '(lclDCT, options)'
                        exec(cmd)
                        queryType  = locals()['_a']
                        queryValue = locals()['_b']
                else: queryType = queryValue = None
        
                # Set target
                target = None
                
        # =========================================================================================
        # ===========================  Misc commands ==============================================
        # =========================================================================================
        
        elif lclDCT['ACTION'] == 'include' or \
             lclDCT['ACTION'] == 'mrStart' or \
             lclDCT['ACTION'] == 'mrStop':
                # Execute command
                cmd = '(_a, _b) = CMDMISC.CmdMisc_' + lclDCT['ACTION'].lower() + '(lclDCT, testName, sessionId, line, headers, extraAVP, options, lclStartTime, RESTInst, step, repeatCount, cmdLineInput)'
                exec(cmd)
                queryType  = locals()['_a']
                queryValue = locals()['_b']
        
        elif lclDCT['ACTION'] == 'resetTrackingData':
                TRACK.setupTrackingData()
                queryType = queryValue = None
        
        elif lclDCT['ACTION'] == 'showSubscriptionTrackingData':
                TRACK.showSubscriptionTrackingData([lclDCT['externalId']])
                queryType = queryValue = None
        
        elif lclDCT['ACTION'] == 'saveTime' or \
             lclDCT['ACTION'] == 'restoreTime' or \
             lclDCT['ACTION'] == 'setTime' or \
             lclDCT['ACTION'] == 'runCmd' or \
             lclDCT['ACTION'] == 'exit' or \
             lclDCT['ACTION'] == 'pause' or \
             lclDCT['ACTION'] == 'sleep' or \
             lclDCT['ACTION'] == 'setSpoofTime' or \
             lclDCT['ACTION'] == 'clearSpoofTime' or \
             lclDCT['ACTION'] == 'purgeSubscriberBalances' or \
             lclDCT['ACTION'] == 'changeAssignedValue' or \
             lclDCT['ACTION'] == 'restoreAssignedValue' or \
             lclDCT['ACTION'] == 'changeParameterValue' or \
             lclDCT['ACTION'] == 'restoreParameterValue' or \
             lclDCT['ACTION'] == 'setConstantValue' or \
             lclDCT['ACTION'] == 'subSaveData' or \
             lclDCT['ACTION'] == 'subDiffData' or \
             lclDCT['ACTION'] == 'groupSaveData' or \
             lclDCT['ACTION'] == 'groupDiffData' or \
             lclDCT['ACTION'] == 'devSaveData' or \
             lclDCT['ACTION'] == 'devDiffData' or \
             lclDCT['ACTION'] == 'startDiffData' or \
             lclDCT['ACTION'] == 'stopDiffData' or \
             lclDCT['ACTION'] == 'clearDebugLog' or \
             lclDCT['ACTION'] == 'saveDebugLog' or \
             lclDCT['ACTION'] == 'notificationCheck' or \
             lclDCT['ACTION'] == 'compare' or \
             lclDCT['ACTION'] == 'clearMEF' or \
             lclDCT['ACTION'] == 'queryEvent' or \
             lclDCT['ACTION'] == 'increment' or \
             lclDCT['ACTION'] == 'echo':
                # Add RESTInst to parameter list (some calls here now need it)
                lclDCT['V3inst'] = RESTInst
                
                # Build command
                cmd = '(_a, _b) = CMDMISC.CmdMisc_' + lclDCT['ACTION'].lower() + '(lclDCT, options, line)'
                exec(cmd)
                queryType  = locals()['_a']
                queryValue = locals()['_b']

                # Set target
                target = None
                
        # =========================================================================================
        # ===========================  G/L commands ==============================================
        # =========================================================================================
        
        elif lclDCT['ACTION'] == 'getGlData' or \
             lclDCT['ACTION'] == 'clearGlData':
                cmd = '(_a, _b) = CMDGL.CmdGl_' + lclDCT['ACTION'].lower() + '(lclDCT, options, line)'
                exec(cmd)
                queryType  = locals()['_a']
                queryValue = locals()['_b']
        
                # Set target
                queryType = queryValue = target = None
                
        # =========================================================================================
        # ===========================  Diameter Rx Commands =======================================
        # =========================================================================================
        
        elif lclDCT['ACTION'] == 'buildRxMediaData':
                # Send command
                CSVRX.buildRxMediaData(lclDCT)
         
                # Set target
                queryType = queryValue = target = None
                
        # =========================================================================================
        # ===========================  Diameter Gx/Gy Non-Usage Commands ==========================
        # =========================================================================================
        
        elif lclDCT['ACTION'] == 'changeDiamConnections' or \
             lclDCT['ACTION'] == 'diameterAbortSession' or \
             lclDCT['ACTION'] == 'diameterReceiveAbortSessionRequest' or \
             lclDCT['ACTION'] == 'diameterSendAbortSessionAnswer' or \
             lclDCT['ACTION'] == 'diameterReceiveWatchdogRequest' or \
             lclDCT['ACTION'] == 'diameterSendWatchdogAnswer' or \
             lclDCT['ACTION'] == 'diameterWatchDog' or \
             lclDCT['ACTION'] == 'diameterCapabilityExchange' or \
             lclDCT['ACTION'] == 'diameterDisconnectPeerRequest' or \
             lclDCT['ACTION'] == 'diameterReceiveOCSUpdate' or \
             lclDCT['ACTION'] == 'diameterSendOCSResponse' or \
             lclDCT['ACTION'] == 'diameterReceiveReAuthRequest' or \
             lclDCT['ACTION'] == 'diameterReceiveRxResponse' or \
             lclDCT['ACTION'] == 'diameterSendReAuthAnswer' or \
             lclDCT['ACTION'] == '5GReceiveOCSUpdate' or \
             lclDCT['ACTION'] == '5GSendOCSResponse' or \
             lclDCT['ACTION'] == '5GReceiveReAuthRequest' or \
             lclDCT['ACTION'] == '5GSendReAuthAnswer' or \
             lclDCT['ACTION'] == '5GNotify':
                # Can't specify just "5g" here since 5gEvent would get caught here...
                if lclDCT['ACTION'].lower()[0:2] == '5g':
                        # Set diameter command
                        lclDCT['interface'] = lclDCT['ACTION'].lower()[0:2]
                
                        # Change action to common one
                        if lclDCT['ACTION'] == '5GNotify':
                                lclDCT['ACTION'] = 'diameterReceiveReAuthRequest'
                        else:   lclDCT['ACTION'] = 'diameter' + lclDCT['ACTION'][2:]
                        
                # Start 5G server if not running
                if lclDCT['interface'].lower().startswith('5g') and not FIVEG.FiveGServerRunning: startHTTPServer(lclDCT, options)
                        
                # Manage marks as we need to set values that may be restored by the mark
                if lclDCT['mark']: manageMark(lclDCT)
                
                # Get diameter connection 
                diamConnection = getDiameterConnection(lclDCT['interface'], options)
                
                # Map policy generic names to reauth actions
                if   lclDCT['ACTION'] == 'diameterReceiveOCSUpdate':    lclDCT['ACTION'] = 'diameterReceiveReAuthRequest'
                elif lclDCT['ACTION'] == 'diameterSendOCSResponse':     lclDCT['ACTION'] = 'diameterSendReAuthAnswer'
                
                # Set current command request
                lclDCT['currenctUsageCommandRequest'] = lclDCT['requestType']
                
                # Process key AVPs that we may want to include/exclude in Diameter messages.
                # Usage done inside CmdDiam_usage.  Non-Usage done outside every message.
                PRIM.additionalAVPs(lclDCT, extraAVP, options, lclStartTime)
                
                # Send command
                cmd = '(_a, _b) = CMDDIAMGY.CmdDiam_' + lclDCT['ACTION'].lower() + '(lclDCT, options, diamConnection, extraAVP)'
                exec(cmd)
                queryType  = locals()['_a']
                queryValue = locals()['_b']
         
                # Set target
                target = None
                
        # =========================================================================================
        # ===========================  Diameter Sh Commands =======================================
        # =========================================================================================
        
        elif lclDCT['ACTION'] == 'diameterReceivePushNotificationRequest' or \
             lclDCT['ACTION'] == 'diameterSendsPushdNotificationAnswer':
                # Force interface parameter to be Sh
                lclDCT['interface'] = 'Sh'
                
                # Manage marks as we need to set values that may be restored by the mark
                if lclDCT['mark']: manageMark(lclDCT)
                
                # Get diameter connection 
                diamConnection = getDiameterConnection(lclDCT['interface'], options)
                
                # Process key AVPs that we may want to include/exclude in Diameter messages.
                # Usage done inside CmdDiam_usage().  Non-Usage done outside every message.
                PRIM.additionalAVPs(lclDCT, extraAVP, options, lclStartTime)
                
                # Send command
                cmd = '(_a, _b) = CMDDIAMSH.CmdDiam_' + lclDCT['ACTION'].lower() + '(lclDCT, options, diamConnection)'
                exec(cmd)
                queryType  = locals()['_a']
                queryValue = locals()['_b']
         
                # Set target
                target = None
                
        # =========================================================================================
        # ===========================  Diameter Sy Commands =======================================
        # =========================================================================================
        
        # *** Add STR support ***
        elif lclDCT['ACTION'] == 'diameterReceiveSpendNotificationRequest' or \
             lclDCT['ACTION'] == 'diameterSendSpendNotificationAnswer' or \
             lclDCT['ACTION'] == '5GReceiveSpendNotificationRequest' or \
             lclDCT['ACTION'] == '5GSendSpendNotificationAnswer' or \
             lclDCT['ACTION'] == '5GSyNotify':
                # Hack: 5GSyNotify should be 5GReceiveSpendNotificationRequest (which is then processed again below)
                if lclDCT['ACTION'] == '5GSyNotify': lclDCT['ACTION'] = '5GReceiveSpendNotificationRequest'
                
                # Can't specify just "5g" here since 5gEvent would get caught here...
                if lclDCT['ACTION'].lower()[0:2] == '5g':
                        # Set diameter command
                        lclDCT['interface'] = lclDCT['ACTION'].lower()[0:2] + 'Sy'
                
                        # Change action to common one
                        lclDCT['ACTION'] = 'diameter' + lclDCT['ACTION'][2:]
                        
                # Allow interface of 5G for these commands to be 5GSy.
                elif lclDCT['interface'].lower() == '5g': lclDCT['interface'] = '5gsy'
                
                # Force interface parameter to be Sy iff not already 5gsy.
                elif lclDCT['interface'].lower() != '5gsy': lclDCT['interface'] = 'Sy'
                
                # Start 5G server if not running
                if lclDCT['interface'].lower().startswith('5g') and not FIVEG.FiveGServerRunning: startHTTPServer(lclDCT, options)
                        
                # Manage marks as we need to set values that may be restored by the mark
                if lclDCT['mark']: manageMark(lclDCT)
                
                # Get diameter connection 
                diamConnection = getDiameterConnection(lclDCT['interface'], options)
                
                # Process key AVPs that we may want to include/exclude in Diameter messages.
                # Usage done inside CmdDiam_usage().  Non-Usage done outside every message.
                PRIM.additionalAVPs(lclDCT, extraAVP, options, lclStartTime)
                
                # Send command
                cmd = '(_a, _b) = CMDDIAMSY.CmdDiam_' + lclDCT['ACTION'].lower() + '(lclDCT, options, diamConnection, extraAVP=extraAVP)'
                exec(cmd)
                queryType  = locals()['_a']
                queryValue = locals()['_b']
         
                # Set target
                target = None
                
        elif lclDCT['ACTION'] == 'diameterSendSessionTerminateRequest' or \
             lclDCT['ACTION'] == 'diameterSendSpendLimitRequest':
                # Force interface parameter to be Sy
                lclDCT['interface'] = 'Sy'
                
                # Manage marks as we need to set values that may be restored by the mark
                if lclDCT['mark']: manageMark(lclDCT)
                
                # Get diameter connection 
                diamConnection = getDiameterConnection(lclDCT['interface'], options)
                
                # Send command
                (queryType, queryValue) = CMDDIAMGY.CmdDiam_usage(lclDCT, testName, sessionId, line, headers, extraAVP, options, lclStartTime, RESTInst, step, repeatCount, diamConnection)
        
                # Set target
                target = None
                
        # =========================================================================================
        # ===========================  OCS Price Commands =========================================
        # =========================================================================================
        
        elif lclDCT['ACTION'] == 'pricingQueryStatus' or \
             lclDCT['ACTION'] == 'pricingQueryContractList' or \
             lclDCT['ACTION'] == 'pricingQueryContract' or \
             lclDCT['ACTION'] == 'pricingQueryRateTagList' or \
             lclDCT['ACTION'] == 'pricingQueryRatetag' or \
             lclDCT['ACTION'] == 'pricingQueryCatalogItemList' or \
             lclDCT['ACTION'] == 'pricingQueryCatalogItem' or \
             lclDCT['ACTION'] == 'pricingQueryOfferList' or \
             lclDCT['ACTION'] == 'pricingQueryOffer' or \
             lclDCT['ACTION'] == 'pricingQueryBalanceClass' or \
             lclDCT['ACTION'] == 'pricingQueryBalanceClassList' or \
             lclDCT['ACTION'] == 'pricingQueryBalance' or \
             lclDCT['ACTION'] == 'pricingQueryBalanceList' or \
             lclDCT['ACTION'] == 'pricingQueryLifecycle' or \
             lclDCT['ACTION'] == 'pricingQueryServiceType' or \
             lclDCT['ACTION'] == 'pricingQueryServiceTypeList' or \
             lclDCT['ACTION'] == 'pricingQueryBillingCycleList' or \
             lclDCT['ACTION'] == 'pricingQueryBillingCycle' or \
             lclDCT['ACTION'] == 'pricingQueryServiceContext' or \
             lclDCT['ACTION'] == 'pricingQueryRole' or \
             lclDCT['ACTION'] == 'pricingQueryRoleList' or \
             lclDCT['ACTION'] == 'pricingQueryTenant' or \
             lclDCT['ACTION'] == 'pricingQueryTenantList' or \
             lclDCT['ACTION'] == 'pricingQueryContractPaymentSchedule' or \
             lclDCT['ACTION'] == 'pricingQueryContractPaymentScheduleList' or \
             lclDCT['ACTION'] == 'pricingQueryBalanceThresholdList' :
                cmd = '(_a, _b) = CMDPRICE.CmdPrice_' + lclDCT['ACTION'].lower() + '(lclDCT, options, RESTInst=RESTInst)'
                exec(cmd)
                queryType  = locals()['_a']
                queryValue = locals()['_b']
         
                # Set target
                target = None
                
        # =========================================================================================
        # ===========================  Tax Commands ==============================================
        # =========================================================================================
        
        elif lclDCT['ACTION'] == 'taxQueryProductGroupList' or \
             lclDCT['ACTION'] == 'taxQueryProductItemList' or \
             lclDCT['ACTION'] == 'taxQueryCustomerTypeList' or \
             lclDCT['ACTION'] == 'taxQueryStatus' or \
             lclDCT['ACTION'] == 'taxQueryGeoCode' or \
             lclDCT['ACTION'] == 'taxQueryExemptionCodeList' :
                cmd = '(_a, _b) = CMDTAX.CmdTax_' + lclDCT['ACTION'].lower() + '(lclDCT, options, RESTInst=RESTInst)'
                exec(cmd)
                queryType  = locals()['_a']
                queryValue = locals()['_b']
         
                # Set target
                target = None
                
        # =========================================================================================
        # ===========================  SNMP Commands ==============================================
        # =========================================================================================
        
        elif lclDCT['ACTION'] == 'snmpBase' or \
             lclDCT['ACTION'] == 'snmpDelta' :
                cmd = '(_a, _b) = CMDSNMP.CmdSnmp_' + lclDCT['ACTION'].lower() + '(lclDCT, options, RESTInst=RESTInst)'
                exec(cmd)
                queryType  = locals()['_a']
                queryValue = locals()['_b']
         
                # Set target
                target = None
                
        # =========================================================================================
        # ===========================  Tracking Commands ==========================================
        # =========================================================================================
        
        elif lclDCT['ACTION'] == 'setSubscriberMark' or \
             lclDCT['ACTION'] == 'setSubscriptionMark' or \
             lclDCT['ACTION'] == 'setGroupMark' or \
             lclDCT['ACTION'] == 'setDeviceMark' or \
             lclDCT['ACTION'] == 'showGroupData' or \
             lclDCT['ACTION'] == 'showSubscriberData':
                # Save subUrl value if a subscription command (overloaded with subscriber commands)
                prefix = 'subscription'
                prefixStart = lclDCT['ACTION'].lower().find(prefix)
                if prefixStart != -1:
                        # We have a subscription command
                        subUrl = REST_UTIL.subUrl
                        REST_UTIL.setSubUrl(prefix)
                        
                        # Change the action
                        if prefixStart == 0:
                                # Replace prefix at the start
                                action = 'subscriber' + lclDCT['ACTION'][len(prefix):]
                        else:
                                # Replace prefix in the middle
                                action = lclDCT['ACTION'][:prefixStart] + 'Subscriber' + lclDCT['ACTION'][prefixStart+len(prefix):]
                else:   action = lclDCT['ACTION']
                
                cmd = '(_a, _b) = CMDTRACK.CmdTrack_' + lclDCT['ACTION'].lower() + '(lclDCT, options)'
                exec(cmd)
                queryType  = locals()['_a']
                queryValue = locals()['_b']
                
                # Restore previous value
                if prefixStart != -1: REST_UTIL.setSubUrl(subUrl)
                
                # Set target
                target = None
                
        # =========================================================================================
        # ===========================  Combo Subman Commands =================================
        # =========================================================================================
        
        elif lclDCT['ACTION'] == 'validateSubscriberBalanceValue' or \
             lclDCT['ACTION'] == 'validateGroupBalanceValue' or \
             lclDCT['ACTION'] == 'waitforSubscriberBalanceValue' or \
             lclDCT['ACTION'] == 'waitforGroupBalanceValue' or \
             lclDCT['ACTION'] == 'setGroupBalanceValue' or \
             lclDCT['ACTION'] == 'setSubscriberBalanceValue':
                cmd = '(_a, _b) = CMDCOMBO.CmdCombo_' + lclDCT['ACTION'].lower() + '(lclDCT, options, RESTInst)'
                exec(cmd)
                queryType  = locals()['_a']
                queryValue = locals()['_b']

                # Set target
                target = None
                for item in ['Subscriber', 'Device', 'Group']:
                        if lclDCT['ACTION'].count(item): target = item
                
        # =========================================================================================
        # ===========================  Subscriber Subman Commands =================================
        # =========================================================================================
        
        elif lclDCT['ACTION'] == 'subscriberQueryEvent' or \
             lclDCT['ACTION'] == 'subscriberQueryEventStore' or \
             lclDCT['ACTION'] == 'subscriberDeleteSession' or \
             lclDCT['ACTION'] == 'importSubscriberBalanceValue' or \
             lclDCT['ACTION'] == 'createSubscriber' or \
             lclDCT['ACTION'] == 'modifySubscriber' or \
             lclDCT['ACTION'] == 'addSubscriber' or \
             lclDCT['ACTION'] == 'createSubscriberAndDevice' or \
             lclDCT['ACTION'] == 'addNextSubscriber' or \
             lclDCT['ACTION'] == 'createSubscriberBillingProfile' or \
             lclDCT['ACTION'] == 'subscribeToOffer' or \
             lclDCT['ACTION'] == 'unsubscribeFromOffer' or \
             lclDCT['ACTION'] == 'modifySubscriberOffer' or \
             lclDCT['ACTION'] == 'addSubscriberThreshold' or \
             lclDCT['ACTION'] == 'removeSubscriberThreshold' or \
             lclDCT['ACTION'] == 'querySubscriber' or \
             lclDCT['ACTION'] == 'queryEverySubEvent' or \
             lclDCT['ACTION'] == 'queryEverySubInGroupEvent' or \
             lclDCT['ACTION'] == 'querySubscriberWallet' or \
             lclDCT['ACTION'] == 'subscriberAdjustBalance' or \
             lclDCT['ACTION'] == 'subscriberAdjustRolloverBalance' or \
             lclDCT['ACTION'] == 'subscriberTransferBalance' or \
             lclDCT['ACTION'] == 'subscriberClearBalance' or \
             lclDCT['ACTION'] == 'subscriberTopupBalance' or \
             lclDCT['ACTION'] == 'deleteSubscriber' or \
             lclDCT['ACTION'] == 'querySubscriberCursor' or \
             lclDCT['ACTION'] == 'querySubscriberMembership' or \
             lclDCT['ACTION'] == 'subscriberWaitforState' or \
             lclDCT['ACTION'] == 'subscriberRehome' or \
             lclDCT['ACTION'] == 'subscriberCancelOffer' or \
             lclDCT['ACTION'] == 'subscriberCheckPurchasedItemCycleAlignment' or \
             lclDCT['ACTION'] == 'subscriberContractDebtPayment' or \
             lclDCT['ACTION'] == 'subscriberContractPrinciplePayment' or \
             lclDCT['ACTION'] == 'subscriberAddRechargeSchedule' or \
             lclDCT['ACTION'] == 'subscriberModifyRechargeSchedule' or \
             lclDCT['ACTION'] == 'subscriberRemoveRechargeSchedule' or \
             lclDCT['ACTION'] == 'subscriberQueryRechargeSchedule' or \
             lclDCT['ACTION'] == 'subscriberQueryRecurringRecharge' or \
             lclDCT['ACTION'] == 'subscriberSettlePayment' or \
             lclDCT['ACTION'] == 'subscriberQueryAggregation' or \
             lclDCT['ACTION'] == 'subscriberQueryEligibleCi' or \
             lclDCT['ACTION'] == 'subscriberQueryCatalog' or \
             lclDCT['ACTION'] == 'subscriptionSubscribeToOffer' or \
             lclDCT['ACTION'] == 'subscriptionUnsubscribeFromOffer' or \
             lclDCT['ACTION'] == 'importSubscriptionBalanceValue' or \
             lclDCT['ACTION'] == 'createSubscriptionBillingProfile' or \
             lclDCT['ACTION'] == 'modifySubscriptionOffer' or \
             lclDCT['ACTION'] == 'addSubscriptionThreshold' or \
             lclDCT['ACTION'] == 'removeSubscriptionThreshold' or \
             lclDCT['ACTION'] == 'querySubscriptionCursor' or \
             lclDCT['ACTION'] == 'querySubscriptionMembership' or \
             lclDCT['ACTION'] == 'subscriptionAdjustBalance' or \
             lclDCT['ACTION'] == 'subscriptionAdjustRolloverBalance' or \
             lclDCT['ACTION'] == 'subscriptionTransferBalance' or \
             lclDCT['ACTION'] == 'subscriptionClearBalance' or \
             lclDCT['ACTION'] == 'subscriptionTopupBalance' or \
             lclDCT['ACTION'] == 'subscriptionQueryEvent' or \
             lclDCT['ACTION'] == 'subscriptionQueryEventStore' or \
             lclDCT['ACTION'] == 'subscriptionDeleteSession' or \
             lclDCT['ACTION'] == 'subscriptionRehome' or \
             lclDCT['ACTION'] == 'subscriptionCancelOffer' or \
             lclDCT['ACTION'] == 'subscriptionCheckPurchasedItemCycleAlignment' or \
             lclDCT['ACTION'] == 'subscriptionContractDebtPayment' or \
             lclDCT['ACTION'] == 'subscriptionContractPrinciplePayment' or \
             lclDCT['ACTION'] == 'subscriptionAddRechargeSchedule' or \
             lclDCT['ACTION'] == 'subscriptionModifyRechargeSchedule' or \
             lclDCT['ACTION'] == 'subscriptionRemoveRechargeSchedule' or \
             lclDCT['ACTION'] == 'subscriptionQueryRechargeSchedule' or \
             lclDCT['ACTION'] == 'subscriptionQueryRecurringRecharge' or \
             lclDCT['ACTION'] == 'subscriptionQueryEligibleCi' or \
             lclDCT['ACTION'] == 'subscriptionQueryCatalog' or \
             lclDCT['ACTION'] == 'subscriptionSettlePayment' or \
             lclDCT['ACTION'] == 'subscriptionQueryAggregation' or \
             lclDCT['ACTION'] == 'subscriberCurrencyTopup':
                # Save subUrl value if a subscription command (overloaded with subscriber commands)
                prefix = 'subscription'
                prefixStart = lclDCT['ACTION'].lower().find(prefix)
                
                # Logic for setting subUrl global
                if prefixStart != -1 or lclDCT['useUser']:
                        # We have a subscription command
                        subUrl = REST_UTIL.subUrl
                        REST_UTIL.setSubUrl(prefix)
                        
                        # Set change flag
                        changeFlag = True
                else:   changeFlag = False
                        
                # Do remainder of work for command prefix
                if prefixStart != -1:
                        # Change the action.  Handle special cases upfront.
                        if   lclDCT['ACTION'] in ['subscriptionSubscribeToOffer', 'subscriptionUnsubscribeFromOffer']:
                                # Remove the prefix
                                action = lclDCT['ACTION'][len(prefix):]
                        elif prefixStart == 0:
                                # Replace prefix at the start
                                action = 'subscriber' + lclDCT['ACTION'][len(prefix):]
                        else:
                                # Replace prefix in the middle
                                action = lclDCT['ACTION'][:prefixStart] + 'Subscriber' + lclDCT['ACTION'][prefixStart+len(prefix):]
                else:   action = lclDCT['ACTION']
                
                # Execute the command using local action variable
                cmd = '(_a, _b) = CMDSUB.CmdSub_' + action.lower() + '(lclDCT, options, RESTInst, cmdLineInput)'
                exec(cmd)
                queryType  = locals()['_a']
                queryValue = locals()['_b']
                
                # Restore previous value
                if changeFlag: REST_UTIL.setSubUrl(subUrl)
                
                # Set target
                if lclDCT['ACTION'].lower().count('query'):
                        target = None
                elif prefixStart != -1:
                        target = prefix.capitalize()
                else:   target = 'Subscriber'
                
        # =========================================================================================
        # ===========================  User Subman Commands =================================
        # =========================================================================================
        
        elif lclDCT['ACTION'] == 'removeUser':
                # Processing command
                cmd = '(_a, _b) = CMDUSER.CmdUser_' + lclDCT['ACTION'].lower() + '(lclDCT, testName, sessionId, line, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, repeatCount)'
                exec(cmd)
                queryType  = locals()['_a']
                queryValue = locals()['_b']
                
                # Set target
                target = None
                
        elif lclDCT['ACTION'] == 'createUser' or \
             lclDCT['ACTION'] == 'createUserSubscription' or \
             lclDCT['ACTION'] == 'createUserAndSubscription' or \
             lclDCT['ACTION'] == 'createUserAndSubscriptionAndDevice' or \
             lclDCT['ACTION'] == 'modifyUser' or \
             lclDCT['ACTION'] == 'queryUser' or \
             lclDCT['ACTION'] == 'addSubscription' or \
             lclDCT['ACTION'] == 'modifyUserSubscription' or \
             lclDCT['ACTION'] == 'removeSubscriptionFromUser' or \
             lclDCT['ACTION'] == 'modifyUserAuthData' or \
             lclDCT['ACTION'] == 'queryUserAuthData' or \
             lclDCT['ACTION'] == 'userAddGroup' or \
             lclDCT['ACTION'] == 'userRemoveGroup' or \
             lclDCT['ACTION'] == 'userModifyGroup' or \
             lclDCT['ACTION'] == 'deleteUser':
                # Save subUrl value
                subUrl = REST_UTIL.subUrl
                REST_UTIL.setSubUrl('subscription')
                
                # Execute the command
                cmd = '(_a, _b) = CMDUSER.CmdUser_' + lclDCT['ACTION'].lower() + '(lclDCT, options, RESTInst, cmdLineInput)'
                exec(cmd)
                queryType  = locals()['_a']
                queryValue = locals()['_b']
                queryType = locals()['_a']
                queryValue = locals()['_b']
                
                # Restore previous value
                REST_UTIL.setSubUrl(subUrl)
                
                # Set target
                target = 'User'
                
        # =========================================================================================
        # ===========================  Subscription Subman Commands =================================
        # =========================================================================================
        
        elif lclDCT['ACTION'] == 'createSubscription' or \
             lclDCT['ACTION'] == 'modifySubscription' or \
             lclDCT['ACTION'] == 'deleteSubscription' or \
             lclDCT['ACTION'] == 'querySubscription':
                # Save subUrl value
                subUrl = REST_UTIL.subUrl
                REST_UTIL.setSubUrl('subscription')
                
                # Execute the command
                cmd = '(_a, _b) = CMDSUBSCRIPTION.CmdSubscription_' + lclDCT['ACTION'].lower() + '(lclDCT, options, RESTInst, cmdLineInput)'
                exec(cmd)
                queryType  = locals()['_a']
                queryValue = locals()['_b']
                
                # Restore previous value
                REST_UTIL.setSubUrl(subUrl)
                
                # Set target
                target = 'Subscription'
                
        # =========================================================================================
        # ===========================  Subscription Hierarchy Subman Commands =====================
        # =========================================================================================
        
        elif lclDCT['ACTION'] == 'removeSubscription':
                # Save subUrl value
                subUrl = REST_UTIL.subUrl
                REST_UTIL.setSubUrl('subscription')
                
                # Execute the command
                cmd = '(_a, _b) = CMDSUBSCRIPTION.CmdSubscription_' + lclDCT['ACTION'].lower() + '(lclDCT, testName, sessionId, line, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, repeatCount)'
                exec(cmd)
                queryType  = locals()['_a']
                queryValue = locals()['_b']
                
                # Restore previous value
                REST_UTIL.setSubUrl(subUrl)
                
                # Set target
                target = 'Subscription'
                
        # =========================================================================================
        # ===========================  Device Subman Commands =====================================
        # =========================================================================================
        
        elif lclDCT['ACTION'] == 'createDevice' or \
             lclDCT['ACTION'] == 'deleteDevice' or \
             lclDCT['ACTION'] == 'createDeviceLogin' or \
             lclDCT['ACTION'] == 'modifyDevice' or \
             lclDCT['ACTION'] == 'removeDeviceFromSubscriber' or \
             lclDCT['ACTION'] == 'removeDeviceFromSubscription' or \
             lclDCT['ACTION'] == 'addDeviceToSubscriber' or \
             lclDCT['ACTION'] == 'addDeviceToSubscription' or \
             lclDCT['ACTION'] == 'devicePurchaseOffer' or \
             lclDCT['ACTION'] == 'deviceSubscribeToOffer' or \
             lclDCT['ACTION'] == 'deviceModifyOffer' or \
             lclDCT['ACTION'] == 'deviceUnsubscribeFromOffer' or \
             lclDCT['ACTION'] == 'deviceCancelOffer' or \
             lclDCT['ACTION'] == 'deviceValidateSession' or \
             lclDCT['ACTION'] == 'deviceDeleteSession' or \
             lclDCT['ACTION'] == 'deviceQuerySession' or \
             lclDCT['ACTION'] == 'deviceQueryEvent' or \
             lclDCT['ACTION'] == 'deviceQueryEventStore' or \
             lclDCT['ACTION'] == 'queryDevice' or \
             lclDCT['ACTION'] == 'deviceQueryEligibleCi' or \
             lclDCT['ACTION'] == 'deviceQueryCatalog' or \
             lclDCT['ACTION'] == 'modifyDeviceOffer' or \
             lclDCT['ACTION'] == 'deviceEvaluateSyPolicy' or \
             lclDCT['ACTION'] == 'deviceWaitforState' or \
             lclDCT['ACTION'] == 'deviceRating' or \
             lclDCT['ACTION'] == 'deviceCheckPurchasedItemCycleAlignment' or \
             lclDCT['ACTION'] == 'deviceContractDebtPayment' or \
             lclDCT['ACTION'] == 'deviceQueryAggregation':
                # Manage marks as we need to set values that may be restored by the mark
                if lclDCT['mark']: manageMark(lclDCT)
                
                # Having issues with device external IDs.  Default of "D" + input external ID is not good.  If starts with D then force to be D + current device ID.
                if lclDCT['devExternalId'] and lclDCT['deviceId'] and lclDCT['devExternalId'].startswith('D'): lclDCT['devExternalId'] = 'D' + lclDCT['deviceId']
                
                # Save subUrl value if a subscription command (overloaded with subscriber commands)
                prefix = 'subscription'
                prefixStart = lclDCT['ACTION'].lower().find(prefix)
                if prefixStart != -1:
                        # We have a subscription command
                        subUrl = REST_UTIL.subUrl
                        REST_UTIL.setSubUrl(prefix)
                        
                        # Change the action
                        if prefixStart == 0:
                                # Replace prefix at the start
                                action = 'subscriber' + lclDCT['ACTION'][len(prefix):]
                        else:
                                # Replace prefix in the middle
                                action = lclDCT['ACTION'][:prefixStart] + 'Subscriber' + lclDCT['ACTION'][prefixStart+len(prefix):]
                else:   action = lclDCT['ACTION']
                
                # Execute the command using local action variable
                cmd = '(_a, _b) = CMDDEV.CmdDev_' + action.lower() + '(lclDCT, options, RESTInst, cmdLineInput)'
                exec(cmd)
                queryType  = locals()['_a']
                queryValue = locals()['_b']
                
                # Restore previous value
                if prefixStart != -1: REST_UTIL.setSubUrl(subUrl)
                
                # Set target
                if lclDCT['ACTION'].lower().count('query'):
                        target = None
                else:   target = 'Device'
                
        # =========================================================================================
        # ================  Group (non-Payment) Subman Commands ===================================
        # =========================================================================================
        
        elif lclDCT['ACTION'] == 'groupQueryEvent' or \
             lclDCT['ACTION'] == 'groupQueryEventStore' or \
             lclDCT['ACTION'] == 'deleteGroup' or \
             lclDCT['ACTION'] == 'modifyGroup' or \
             lclDCT['ACTION'] == 'addAdminToGroup' or \
             lclDCT['ACTION'] == 'removeAdminFromGroup' or \
             lclDCT['ACTION'] == 'addSubscriberToGroup' or \
             lclDCT['ACTION'] == 'removeSubscriptionFromGroup' or \
             lclDCT['ACTION'] == 'addSubscriptionToGroup' or \
             lclDCT['ACTION'] == 'removeSubscriberFromGroup' or \
             lclDCT['ACTION'] == 'addSubGroupToGroup' or \
             lclDCT['ACTION'] == 'removeSubGroupFromGroup' or \
             lclDCT['ACTION'] == 'groupSubscribeToOffer' or \
             lclDCT['ACTION'] == 'groupUnsubscribeFromOffer' or \
             lclDCT['ACTION'] == 'addGroupThreshold' or \
             lclDCT['ACTION'] == 'removeGroupThreshold' or \
             lclDCT['ACTION'] == 'queryGroupCursor' or \
             lclDCT['ACTION'] == 'queryGroupMembership' or \
             lclDCT['ACTION'] == 'queryGroup' or \
             lclDCT['ACTION'] == 'queryGroupWallet' or \
             lclDCT['ACTION'] == 'groupAdjustBalance' or \
             lclDCT['ACTION'] == 'groupTransferBalance' or \
             lclDCT['ACTION'] == 'groupClearBalance' or \
             lclDCT['ACTION'] == 'groupTopupBalance' or \
             lclDCT['ACTION'] == 'groupWaitforState' or \
             lclDCT['ACTION'] == 'groupCancelOffer' or \
             lclDCT['ACTION'] == 'groupCheckPurchasedItemCycleAlignment' or \
             lclDCT['ACTION'] == 'groupContractDebtPayment' or \
             lclDCT['ACTION'] == 'groupContractPrinciplePayment' or \
             lclDCT['ACTION'] == 'queryGroupWallet' or \
             lclDCT['ACTION'] == 'creategroupbillingprofile' or \
             lclDCT['ACTION'] == 'groupAdjustRolloverBalance' or \
             lclDCT['ACTION'] == 'groupAddRechargeSchedule' or \
             lclDCT['ACTION'] == 'groupModifyRechargeSchedule' or \
             lclDCT['ACTION'] == 'groupRemoveRechargeSchedule' or \
             lclDCT['ACTION'] == 'groupQueryRechargeSchedule' or \
             lclDCT['ACTION'] == 'groupQueryRecurringRecharge' or \
             lclDCT['ACTION'] == 'groupQueryEligibleCi' or \
             lclDCT['ACTION'] == 'groupQueryCatalog' or \
             lclDCT['ACTION'] == 'groupSettlePayment' or \
             lclDCT['ACTION'] == 'modifyGroupOffer':
                # Save subUrl value if a subscription command (overloaded with subscriber commands)
                prefix = 'subscription'
                prefixStart = lclDCT['ACTION'].lower().find(prefix)
                if prefixStart != -1:
                        # We have a subscription command
                        subUrl = REST_UTIL.subUrl
                        REST_UTIL.setSubUrl(prefix)
                        
                        # Change the action
                        if prefixStart == 0:
                                # Replace prefix at the start
                                action = 'subscriber' + lclDCT['ACTION'][len(prefix):]
                        else:
                                # Replace prefix in the middle
                                action = lclDCT['ACTION'][:prefixStart] + 'Subscriber' + lclDCT['ACTION'][prefixStart+len(prefix):]
                else:   action = lclDCT['ACTION']
                
                # Execute the command using local action variable
                cmd = '(_a, _b) = CMDGROUP.CmdGroup_' + action.lower() + '(lclDCT, options, RESTInst, cmdLineInput)'
                exec(cmd)
                queryType  = locals()['_a']
                queryValue = locals()['_b']
                
                # Restore previous value
                if prefixStart != -1: REST_UTIL.setSubUrl(subUrl)
                
                # Set target
                if lclDCT['ACTION'].lower().count('query'):
                        target = None
                else:   target = 'Group'
                
        # =========================================================================================
        # ============================= PayNow Subman Commands ====================================
        # =========================================================================================
        
        elif lclDCT['ACTION'] == 'groupAddPaymentMethod' or \
             lclDCT['ACTION'] == 'groupModifyPaymentMethod' or \
             lclDCT['ACTION'] == 'groupRemovePaymentMethod' or \
             lclDCT['ACTION'] == 'groupQueryPaymentMethod' or \
             lclDCT['ACTION'] == 'groupQueryPaymentHistory' or \
             lclDCT['ACTION'] == 'groupRefundPayment' or \
             lclDCT['ACTION'] == 'groupPayment' or \
             lclDCT['ACTION'] == 'groupRecharge' or \
             lclDCT['ACTION'] == 'subscriberAddPaymentMethod' or \
             lclDCT['ACTION'] == 'subscriberModifyPaymentMethod' or \
             lclDCT['ACTION'] == 'subscriberRemovePaymentMethod' or \
             lclDCT['ACTION'] == 'subscriberQueryPaymentMethod' or \
             lclDCT['ACTION'] == 'subscriberQueryPaymentHistory' or \
             lclDCT['ACTION'] == 'subscriberRefundPayment' or \
             lclDCT['ACTION'] == 'subscriberPayment' or \
             lclDCT['ACTION'] == 'subscriberRecharge' or \
             lclDCT['ACTION'] == 'subscriberEstimateRecurringCharge' or \
             lclDCT['ACTION'] == 'subscriptionAddPaymentMethod' or \
             lclDCT['ACTION'] == 'subscriptionModifyPaymentMethod' or \
             lclDCT['ACTION'] == 'subscriptionRemovePaymentMethod' or \
             lclDCT['ACTION'] == 'subscriptionQueryPaymentMethod' or \
             lclDCT['ACTION'] == 'subscriptionQueryPaymentHistory' or \
             lclDCT['ACTION'] == 'subscriptionRefundPayment' or \
             lclDCT['ACTION'] == 'subscriptionPayment' or \
             lclDCT['ACTION'] == 'subscriptionRecharge' or \
             lclDCT['ACTION'] == 'groupEstimateRecurringCharge' or \
             lclDCT['ACTION'] == 'getGatewayAuthorizationToken':
                # Save subUrl value if a subscription command (overloaded with subscriber commands)
                prefix = 'subscription'
                prefixStart = lclDCT['ACTION'].lower().find(prefix)
                if prefixStart != -1:
                        # We have a subscription command
                        subUrl = REST_UTIL.subUrl
                        REST_UTIL.setSubUrl(prefix)
                        
                        # Change the action
                        if prefixStart == 0:
                                # Replace prefix at the start
                                action = 'subscriber' + lclDCT['ACTION'][len(prefix):]
                        else:
                                # Replace prefix in the middle
                                action = lclDCT['ACTION'][:prefixStart] + 'Subscriber' + lclDCT['ACTION'][prefixStart+len(prefix):]
                else:   action = lclDCT['ACTION']
                
                # Execute the command using local action variable
                cmd = '(_a, _b) = CMDPAYNOW.CmdPayNow_' + action.lower() + '(lclDCT, options, RESTInst, cmdLineInput)'
                exec(cmd)
                queryType  = locals()['_a']
                queryValue = locals()['_b']
                
                # Restore previous value
                if prefixStart != -1: REST_UTIL.setSubUrl(subUrl)
                
                # Set target.  Nothing to query if a Method or query ation.
                if lclDCT['ACTION'].count('Method') or lclDCT['ACTION'].count('Query') or lclDCT['ACTION'] == 'getGatewayAuthorizationToken':
                        queryType = queryValue = target = None
                elif lclDCT['ACTION'].startswith('group'): 
                        target = 'Group'
                elif prefixStart != -1:
                        target = prefix.capitalize()
                else:   target = 'Subscriber'
        
        # =========================================================================================
        # ===========================  Group Hierarchy Commands ==================================
        # =========================================================================================
        elif lclDCT['ACTION'] == 'createFullGroup' or \
             lclDCT['ACTION'] == 'createGroup' or \
             lclDCT['ACTION'] == 'removeGroup' or \
             lclDCT['ACTION'] == 'createEnterprise':
                # if creating an enteerprise or a full group, decrement the groupId so we use the input value (otherwise it's +1)
                #if lclDCT['ACTION'] in ['createEnterprise']:
                #       DATA.maxAssignedIds['groupId'] = str(int(DATA.maxAssignedIds['groupId']) - 1)
                
                # Clear flag saying it's OK to mess with marks
                DATA.MessWithMarks = False
                
                cmd = '(_a, _b) = CMDGROUP.CmdGroup_' + lclDCT['ACTION'].lower() + '(lclDCT, testName, sessionId, line, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, repeatCount)'
                exec(cmd)
                queryType  = locals()['_a']
                queryValue = locals()['_b']
         
                # Set target
                target = None
                
        # =========================================================================================
        # ===========================  Subscriber Hierarchy Commands ==============================
        # =========================================================================================
        elif lclDCT['ACTION'] == 'removeSubscriber':
                # Processing command
                cmd = '(_a, _b) = CMDSUB.CmdSub_' + lclDCT['ACTION'].lower() + '(lclDCT, testName, sessionId, line, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, repeatCount)'
                exec(cmd)
                queryType  = locals()['_a']
                queryValue = locals()['_b']
                
                # Set target
                target = None
                
        # =========================================================================================
        # ===========================  Device Hierarchy Commands ==================================
        # =========================================================================================
        elif lclDCT['ACTION'] == 'removeDevice':
                # Having issues with device external IDs.  Default of "D" + input external ID is not good.  If starts with D then force to be D + current device ID.
                if lclDCT['devExternalId'] and lclDCT['devExternalId'].startswith('D'): lclDCT['devExternalId'] = 'D' + lclDCT['deviceId']
                
                # Processing command
                cmd = '(_a, _b) = CMDDEV.CmdDev_' + lclDCT['ACTION'].lower() + '(lclDCT, testName, sessionId, line, headers, lclExtraAvp, options, lclStartTime, RESTInst, step, repeatCount)'
                exec(cmd)
                queryType  = locals()['_a']
                queryValue = locals()['_b']
                
                # Set target
                target = None
                
        # =========================================================================================
        # ===========================  Diameter Usage events ======================================
        # =========================================================================================
        
        elif lclDCT['ACTION'] == 'diameterEvent' or \
             lclDCT['ACTION'] == 'diameterEverySubEvent' or \
             lclDCT['ACTION'] == 'diameterEverySubInGroupEvent' or \
             lclDCT['ACTION'] == 'diameterEveryDeviceEvent' or \
             lclDCT['ACTION'] == 'diameterEveryDeviceInSubEvent' or \
             lclDCT['ACTION'] == 'diameterEveryDeviceInGroupEvent' or \
             lclDCT['ACTION'] == 'diameterEveryAccessNumberInSubEvent' or \
             lclDCT['ACTION'] == 'diameterEveryAccessNumberInGroupEvent' or \
             lclDCT['ACTION'] == 'diameterEveryAccessNumberEvent' or \
             lclDCT['ACTION'].lower()[0:2] in ['5g', 'rx', 'gx']:
                # See if a subscription command
                if lclDCT['subscriptionCommand']:
                        # We have a subscription command
                        subUrl = REST_UTIL.subUrl
                        REST_UTIL.setSubUrl('subscription')
                
                # If not Gy then change parameters
                if lclDCT['ACTION'].lower()[0:2] in ['5g', 'rx', 'gx']:
                        # Set interface iff not already set (must be set for 5GSy)
                        if not lclDCT['interface'].lower().startswith('5g'): lclDCT['interface'] = lclDCT['ACTION'].lower()[0:2]
                
                        # Change action to common one
                        lclDCT['ACTION'] = 'diameter' + lclDCT['ACTION'][2:]
                        
                # Start HTTP server if needed
                if lclDCT['interface'].lower().startswith('5g') and not FIVEG.FiveGServerRunning: startHTTPServer(lclDCT, options)
                
                # Manage marks as we need to set values that may be restored by the mark
                if lclDCT['mark']: manageMark(lclDCT)
                
                # Get diameter connection 
                diamConnection = getDiameterConnection(lclDCT['interface'], options)
                
                # Processing command
                (queryType, queryValue) = CMDDIAMGY.CmdDiam_usage(lclDCT, testName, sessionId, line, headers, extraAVP, options, lclStartTime, RESTInst, step, repeatCount, diamConnection)
                
                # Restore subUrl flag if it was changed
                if lclDCT['subscriptionCommand']: REST_UTIL.setSubUrl(subUrl)
                
                # Set target to subscriber (handled below for subscription)
                target = 'Subscriber'
                
        # =========================================================================================
        # ===========================  Stream Server events = =====================================
        # =========================================================================================
        
        elif lclDCT['ACTION'].startswith('streamCompare'):
            if lclDCT['ACTION'].count('Subscriber'):
                queryType = lclDCT['subQueryType']
                queryValue = lclDCT['externalId']
                target='Subscriber'
            elif lclDCT['ACTION'].count('Group'):
                queryType = lclDCT['groupQueryType']
                queryValue = lclDCT['groupId']
                target='Group'
            else:
                queryType = lclDCT['devQueryType']
                queryValue = lclDCT['deviceId']
                target='Device'
                
            # Make the call
            CSVEVENTS.streamcompare(lclDCT, options, lclStartTime, RESTInst, queryValue, queryType, target)
                
            # Nothing to query
            queryType = queryValue = target = None
                
        # =========================================================================================
        # ===========================  Unknown input... ===========================================
        # =========================================================================================
        
        else:
                print('ERROR: unknown action was received: ' + lclDCT['ACTION'] + '.  Exiting')
                sys.exit('Error:  bad command action')
        
        # =========================================================================================
        # ===========================  Done processing input file line ============================
        # =========================================================================================
        
        # *** For now treat all subscription commands as subscriber (so saves work now).
        if target == 'Subscription': target = 'Subscriber'
        
        # Parameter addlIncludeParameters should unextend always if defined for this command
        if lclDCT['addlIncludeParameters']:
                DATA.alwaysIncludeParameters = DATA.alwaysIncludeParameters[:-len(lclDCT['addlIncludeParameters'])]
                #pprint.pprint(DATA.alwaysIncludeParameters)
        
        # Do more stuff if not skipping due to comment string enabled
        if not commentStringEnabled:
         # If snmp diff desired then we need to get the diff
         if lclDCT['snmpCheck']:
                if lclDCT['snmpCheck'] == 'diff':
                        SNMP.SNMPPost(lclDCT['outputFileName'], lclDCT['snmpMIBs'])
                else:
                        # Want to see the values (not the diffs)
                        SNMP.SNMPCheck(lclDCT['outputFileName'], lclDCT['snmpMIBs'])
                
         # See if notification checking desired and proper data passed in
         if lclDCT['notificationCheck'] and len(lclDCT['notificationCheck']): PRIM.perCommandNotificationCheck(lclDCT)
        
         # See if event processing desired and the command itself was not an event query
         if lclDCT['eventProcessing'] and not lclDCT['ACTION'].count('QueryEvent'):
                # See if we have the right target and something to query
                if target and queryType and queryValue:
                        CSVEVENTS.checkEvents(target, queryType, queryValue, lclDCT, RESTInst, lclStartTime, testName+'_'+str(lclDCT['step']))
                else:   print('WARNING: command ' + lclDCT['ACTION'] + ' did not result in any objects to query.  Shouldn\'t specify eventProcessing for this command')
        
         # See if MEF file processing desired
         if lclDCT['mefProcessingData']:
                # Set flag saying this command did MEF analysis
                DATA.previousCommandMefDataProcessed = True
                
                # Process MEF files
                CSVEVENTS.checkmeffiles(lclDCT)
         else:
                # Set flag saying this command did not perform MEF analysis
                DATA.previousCommandMefDataProcessed = False
        
         # Restore local start time (as called functions may have updated it)
         lclStartTime = lclDCT['lclStartTime']
        
         # Additional stuff if we executed the command
         if filterPass:
                # Save and diff iff something to query and we expected the command to pass.
                # If saving data and doing a query, then no output
                if lclDCT['saveData'] and lclDCT['ACTION'].lower().count('query'):
                        print('Not querying because saveData on and command is a query')
                
                # KEF: Fix when save XXX and viewObject support users and subscriptions
                elif queryValue and lclDCT['eventPass'] and target not in ['User', 'Subscription']:
                        # If diff enable flag set and we have a target, then only do diffs
                        if DATA.diffEnableFlag and target:
                                # Minor hack.  Diameter messages are targeted as device (which is right),
                                # but for a diff purpose they need to show the subscriber (where the wallet is).
                                if lclDCT['ACTION'].startswith('diameter') or lclDCT['ACTION'] == 'deviceRating':
                                        if lclDCT['subscriptionCommand']:       target = 'Subscription'
                                        else:                                   target = 'Subscriber'
                                
                                # Invoke diff function.  Save results so buffer is used for save MDC command.
                                lclDCT['doNotRunCommand'] = CMDMISC.CmdMisc_diffdata(lclDCT, target)
                        
                        # If user wants to view events, then show them only what transpired for this command.  Always scope up for viewing events.
                        if lclDCT['viewEvents']: lclDCT['viewEvents'] = "  --scope up -l " + lclDCT['origStartTime'] + ' '
                        
                        # Save data always
                        PRIM.saveCsvMDC(queryValue, queryType, lclDCT, repeatCount, lclDCT['step'], testName, RESTInst)
                
                elif queryValue and target in ['User', 'Subscription'] and lclDCT['verbose'].lower() not in ['low', 'no']:
                        # Just print to screen for now (save not yet setup)
                        PRIM.printToScreen('save'+target, queryValue, queryType, lclDCT, lclStartTime)
                elif lclDCT['verbose'].lower() not in ['low', 'none']:  print('Not querying because queryValue = ' + str(queryValue) + ' and eventPass = ' + str(lclDCT['eventPass']) + ' and target = ' + str(target))
                
                # Debug output
                #if options.debug > 0: print '\n** Completed command: ' + lclDCT['ACTION'] + '\n'
                if options.debug > 0: print('\n** Completed command\n')
                
                # See if we should save the debug log
                if lclDCT['operation'] == 'saveDebugLog':
                        # Create space and save the debug log file
                        print('\n\n')
                        CMDMISC.CmdMisc_savedebuglog(lclDCT, options, line)
                
        # Update time of last command here
        DATA.timeOfLastCommand = savedCommandStartTime
        
        # Restore time if we changed it due to removal command
        if savedStartTimeFromRemove: lclDCT['startTime'] = lclDCT['lclStartTime'] = savedStartTimeFromRemove
        
        # Restore saved REST instance value if changed above
        if switchFlag: RESTInst = REST_UTIL.restoreVersion(RESTInst)
        
        # See if we should update global debug level
        if debuglevelRestore:
                print('NOTE: Restoring debug level to ' + str(debuglevelRestore))
                QAUTILS.DebugLevel = int(debuglevelRestore)
                debuglevelRestore = None
                
        # We're done here!
        return (lclDCT['step'], lclDCT['lclStartTime'], lclDCT['repeat'], options, returnSessionId, lclDCT['saveResults'])

#==========================================================

def main():
    x = 1


if __name__ == '__main__':
    main()

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


