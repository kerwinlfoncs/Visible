#!/bin/bash

mkdir -p /home/mtx/.snmp/mibs
cp /opt/mtx/data/snmp/mibs/* /opt/mtx/conf
cd /home/mtx/.snmp/mibs
rm -f matrixx_*.txt
ln -s /opt/mtx/conf/matrixx_mib.txt .
ln -s /opt/mtx/conf/matrixx_smi.txt .
ln -s /opt/mtx/conf/matrixx_common_mib.txt .
ln -s /opt/mtx/conf/matrixx_web_mib.txt .

echo mibs +MATRIXX-SMI > /home/mtx/.snmp/snmp.conf
echo mibs +MATRIXX-MIB >>  /home/mtx/.snmp/snmp.conf
echo mibs +MATRIXX-COMMON-MIB >>  /home/mtx/.snmp/snmp.conf
echo mibs +MATRIXX-WEB-MIB >> /home/mtx/.snmp/snmp.conf

#ls -l ~/.snmp
#total 0
#lrwxrwxrwx 1 mtx mtx 29 Oct  2 10:54 matrixx_mib.txt -> /opt/mtx/conf/matrixx_mib.txt
#lrwxrwxrwx 1 mtx mtx 29 Oct  2 10:54 matrixx_smi.txt -> /opt/mtx/conf/matrixx_smi.txt

