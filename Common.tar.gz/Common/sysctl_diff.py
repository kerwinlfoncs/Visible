#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:56
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:35
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:13
#


# from builtins import str
# from builtins import str
import os, sys

def main():
    if len(sys.argv) is not 3:
        print("Usage: sysctl_diff.py [sysctl output file 1] [sysctl output file 2]")
        exit(0)

    sysctlFile1 = sys.argv[1]
    sysctlFile2 = sys.argv[2]

    dict1 = {}
    dict2 = {}

    out = open('sysctl_diff.txt','w+')

    sysctl1 = open(sysctlFile1, 'r')
    for line in sysctl1:
        pair = line.strip().replace('\t',' ').split('=')
        dict1[pair[0]] = pair[1]
    sysctl1.close()

    sysctl2 = open(sysctlFile2, 'r')
    for line in sysctl2:
        pair = line.strip().replace('\t',' ').split('=')
        dict2[pair[0]] = pair[1]
    sysctl2.close()

    valsChanged = {}
    valsMissingFrom2 = []
    valsMissingFrom1 = []
    for key, val in list(dict1.items()):
        if key in dict2:
            if dict1[key] != dict2[key]:
                valsChanged[key] = (dict1[key],dict2[key])
        else:
            valsMissingFrom2.append(key)
    for key in dict2:
        if key in dict2:
            continue
        else:
            valsMissingFrom1.append(key)

    out.write("**Values changed from "+sysctlFile1+" to "+sysctlFile2+" ([old value] >> [new value]):**\n\n")
    for key, val in list(valsChanged.items()):
        out.write(key+":"+val[0]+" >>"+val[1]+"\n")
    out.write("----- "+str(len(valsChanged))+" values changed in total.\n\n")
    out.write("**Values present in "+sysctlFile1+" but missing from "+sysctlFile2+":**\n\n")
    for val in valsMissingFrom2:
        out.write(val+"\n")
    out.write("----- "+str(len(valsMissingFrom2))+" values missing in total.\n\n")
    out.write("**Values present in "+sysctlFile2+" but missing from "+sysctlFile1+":**\n\n")
    for val in valsMissingFrom1:
        out.write(val+"\n")
    out.write("----- "+str(len(valsMissingFrom1))+" values missing in total.\n\n")
    out.close()

    print("diff saved to sysctl_diff.txt")
main()
