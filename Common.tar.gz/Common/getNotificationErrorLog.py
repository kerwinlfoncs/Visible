#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:36
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:16
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:00
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


import optparse
import os, sys
import qa_utils as QAUTILS
import fcntl
import get_config as CONFIG

#==========================================================

def main():
    # Process input args
    (options, args) = CONFIG.initializeTest()

    host = options.notificationHost
    outFile = options.file
    print(outFile)

    dateStr = QAUTILS.runCmd('date +"%Y-%m-%d"')
    QAUTILS.runCmd('ssh ' + host + ' "grep ERROR /var/log/mtx/mtx_notifier.log > /tmp/notification.err"' )
    QAUTILS.runCmd('ssh ' + host + ' "grep ERROR /var/log/mtx_activemq_connector/mtx_debug.log | grep ' + dateStr + '  >> /tmp/notification.err"' )
    QAUTILS.runCmd('scp ' + host + ':/tmp/notification.err ' + outFile )
    
if __name__ == '__main__':
    main()

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
