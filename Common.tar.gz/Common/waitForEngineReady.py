#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Tue 2021-08-24T23:40:50
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-24T23:36:30
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-24T23:35:10
#===============================================================================
#
# Copyright 2011,2012,2013,2014,2015,2016 Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


import get_cluster_state
import time

def main(): 
    wait = 0
    while True:
        # Get curent blade state
        state = get_cluster_state.getBladeState('1:1','1:1:1')  
        if 'active' in  state: 
           time.sleep(3)
           print("SUCCESS:  Engine fully up")
           
           break 
        if wait > 60 :
           print("FAIL: time out.  Engine not coming up.")
           exit 
        wait += 1   

main()
