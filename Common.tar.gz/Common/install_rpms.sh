# This script takes an rpm version number, eg 4600-972. It uninstalls the current engine 
# and proxy (if installed),  installs all rpm in the dir it is run from with the given 
# version number, and copies war files to tomcat.
# It stops and starts tomcat but you will have to stop/start engine, proxy etc yourself.


while getopts "h" opt; do
    case $opt in
        h)
            echo "Usage: install_rpms.sh <version number>"
            exit 1
            ;;
        \?)
            echo "Invalid option $opt. \n Usage: install_rpms.sh <version number>"
            exit 1
            ;;
    esac
done

if [ "$#" != "1" ]; then
    echo "Usage: install_rpms.sh <version number>"
    exit 1
fi

sudo rpm -e matrixxsw-engine
sudo rpm -e matrixxsw-proxy-server
rm /var/lib/tomcat6/webapps/*.war 
sudo /etc/init.d/tomcat6 stop

TO_INSTALL=$(find . -type f -name "*$1*.rpm" -maxdepth 1 -print 2>/dev/null)
if $TO_INSTALL == NULL; then
    echo "No rpm of version $VER found."
fi 
for f in $TO_INSTALL ; do
    echo $f
    if [[ $f == *seagull* ]]; then
        sudo rpm -e matrixxsw-seagull
    fi
    if [[ $f == *activemq-connector* ]] || [[ $f == *proxy-server* ]]; then
        sudo rpm -e matrixxsw-activemq-connector
    fi
    sudo rpm -vi $f
done

cp $MTX_BIN_DIR/selfcare.war /var/lib/tomcat6/webapps/
cp $MTX_BIN_DIR/rsgateway.war /var/lib/tomcat6/webapps/
cp $MTX_BIN_DIR/matrixx.war /var/lib/tomcat6/webapps/
sudo /etc/init.d/tomcat6 start
