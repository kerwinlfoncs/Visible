Autopay Utility
===============
This utility gets all subscribers from matrixx imdb and does rest call to VisibleAutoPayapi.

Prerequisites
-------------
* Some additional Python modules are required (as root):
```
pip3 install stompest fasteners dotmap
```
**If pip3 is not available, please use easy_install or manual download from PyPi.
* Login to proxy servers and make sure below directories exist
```
 mkdir /opt/mtx/data/data_container
```

* Login to engine node.
* copy below files from engine to proxy keep same directory structure. 
```
  scp /opt/mtx/bin/subscriber_mgmt_v3.py mtx@10.0.4.13:/opt/mtx/bin/subscriber_mgmt_v3.py
  scp /opt/mtx/bin/data_container.py mtx@10.0.4.13:/opt/mtx/bin/data_container.py
  scp /opt/mtx/bin/data_container_defs.py mtx@10.0.4.13:/opt/mtx/bin/data_container_defs.py
  scp /opt/mtx/bin/command_defs.py mtx@10.0.4.13:/opt/mtx/bin/command_defs.py
  scp /opt/mtx/bin/path_functions.py mtx@10.0.4.13:/opt/mtx/bin/path_functions.py
  scp /opt/mtx/bin/run_time_functions.py mtx@10.0.4.13:/opt/mtx/bin/run_time_functions.py
  scp /opt/mtx/data/data_container/mdc_config_system.pickled mtx@10.0.4.13:/opt/mtx/data/data_container/mdc_config_system.pickled
```

Installation
-------------
* Install application by installing VisibleApiGateway

* Make sure /opt/mtx/bin is in PYTHONPATH:
```
  export PYTHONPATH=$PYTHONPATH:/opt/mtx/bin
```

* Make sure non-default Python modules directory are in PYTHONPATH:
```
  export PYTHONPATH=$PYTHONPATH:/opt/mtx/services/lib/python3.8/site-packages
```

* Make sure fastners is installed
```
sudo python3 -m pip install fasteners
```

* Make sure dotmap is installed
```
sudo python3 -m pip install dotmap
```

Configuration
-------------
Edit below configuration file as required
For example: localhost, port etc.
```
/opt/mtx/conf/autopay.yaml
```
Running the program
-------------------
#### run below command
```
  python3 /opt/mtx/services/bin/autopay.py /opt/mtx/conf/autopay.yaml
```
The configuration file is the first argument.
Subsequent arguments should be of the form key=value, and can be used to override config file 
parameters. For example, to override the log_subscribers parameter, and also take the list of 
subscribers to process from the file subs.txt, call as follows:
```
python3 /opt/mtx/services/bin/autopay.py /opt/mtx/conf/autopay.yaml input_file=subs.txt logfile=/tmp/ver.log
```
