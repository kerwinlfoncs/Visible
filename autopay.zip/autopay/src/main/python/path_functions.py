#!/usr/bin/python3
#===============================================================================
#
# Copyright 2009-2021, MATRIXX Software, Inc. All rights reserved.
#
#-------------------------------------------------------------------------------
#
# @file
# @date       $Date$
#
# $Id$
#
# @2to3-3 --no-diffs -x input -x print -w  : Tue 2021-08-31T20:33:58
#
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-08-31T20:33:54
#
# @futurize --stage1 --no-diffs -n -w  : Tue 2021-08-31T20:33:47
#
#
#
#===============================================================================
#
# This file contains the definitions of the names of paths (directories and
# files) and related functions.
#
# DO NOT IMPORT common_functions!!
# NOTE: This file should not import common_functions nor should it import any
# file that imports common_functions. Doing so will cause a circular dependency.
#
import os
#
# Directories
#===============================================================================
#
# Default directory names.
#
#===============================================================================
mtxProductName = os.getenv('MTX_PRODUCT_NAME', 'mtx')
mtxDefaultDir = '/opt/' + mtxProductName
mtxDir = ''
binDefaultDir = mtxDefaultDir + '/bin'
binDir = ''
libDefaultDir = mtxDefaultDir + '/lib'
libDir = ''
confDefaultDir = mtxDefaultDir + '/conf'
confDir = ''
coreDefaultDir = '/var/' + mtxProductName
coreDir = ''
customDefaultDir = mtxDefaultDir + '/custom'
customDir = ''
dataDefaultDir = mtxDefaultDir + '/data'
dataDir = ''
errorMdcLogDefaultDir = '/var/log/' + mtxProductName
errorMdcLogDir = ''
exportDefaultDir = '/var/log/' + mtxProductName + '/export'
exportDir = ''
logDefaultDir = '/var/log/' + mtxProductName
logDir = ''
pidDefaultDir = '/var/run/' + mtxProductName
pidDir = ''
pricingDir = ''
productUserHomeDir = ''
recoveryDefaultDir = '/var/log/' + mtxProductName + '/recovery'
recoveryDir = ''
rpmDefaultDir = '/tmp'
rpmDir = ''
rsgatewayTomcatDefaultDir = '/opt/tomcat6'
rsgatewayTomcatDir = ''
seagullDataDefaultDir = dataDefaultDir + '/seagull'
seagullDataDir = ''
sharedDefaultDir = '/var/log/' + mtxProductName + '/shared'
sharedDir = ''
txnLogDefaultDir = '/var/log/' + mtxProductName + '/local'
txnLogDir = ''
workDefaultDir = '/var/' + mtxProductName
workDir = ''

#
#===============================================================================
#
# Build-related directory names
#
#===============================================================================
topDir = os.path.expandvars(os.getenv('TOPDIR', ''))
isInstalledEnvironment = False
if (topDir == ''):
    isInstalledEnvironment = True
buildToolsDir = os.path.expandvars(os.getenv('BUILD_TOOLS_DIR', topDir + '/build_tools'))
publishDir = os.path.expandvars(os.getenv('PUBLISH_DIR', topDir + '/publish_linux'))
publishBinDir = os.path.expandvars(os.getenv('PUBLISH_BIN_DIR', publishDir + binDefaultDir))
publishIncludeDir = os.path.expandvars(os.getenv('PUBLISH_INCLUDE_DIR', publishDir + '/opt/mtx/include'))
publishLibDir = os.path.expandvars(os.getenv('PUBLISH_LIB_DIR', publishDir + '/opt/mtx/lib'))
publishConfDir = publishDir + '/opt/mtx/conf'
publishEtcDir = publishDir + '/etc'
#
# This is a special variable that controls what data_container.py does when it is imported.
# If this is True, then the custom MDCs are not loaded.
skipCustomDataContainerInitialization = False
# This is a special variable that controls what data_container.py does when it is imported.
# If this is True, then all MDCs are not loaded.
skipDataContainerInitialization = False

#===============================================================================
baseConfigFileName = 'mtx_config.xml'
configFileName = baseConfigFileName

#===============================================================================

def getConfigFileName(fileName=None):
    '''
    Get the absolute path of a configuration file ("mtx_config.xml") as follows:
    1. If fileName is an absolute path, return it
    2. If fileName is a relative path, return it based in confDir
    3. If fileName is None, return configFileName based in confDir
    '''
    global confDir
    global configFileName
    #
    if fileName is None:
        fileName = configFileName
    return os.path.abspath(os.path.join(confDir, fileName))

#===============================================================================

def setDirectoryNames():
    # Sets the common directory names based upon specific environment variables.
    global binDefaultDir
    global binDir
    global confDefaultDir
    global confDir
    global coreDefaultDir
    global coreDir
    global customDefaultDir
    global customDir
    global dataDefaultDir
    global dataDir
    global errorMdcLogDefaultDir
    global errorMdcLogDir
    global exportDefaultDir
    global exportDir
    global isInstalledEnvironment
    global libDefaultDir
    global libDir
    global logDefaultDir
    global logDir
    global mtxDefaultDir
    global mtxDir
    global mtxProductName
    global pidDefaultDir
    global pidDir
    global pricingDir
    global productUserHomeDir
    global recoveryDefaultDir
    global recoveryDir
    global rpmDefaultDir
    global rpmDir
    global rsgatewayTomcatDefaultDir
    global rsgatewayTomcatDir
    global seagullDataDefaultDir
    global seagullDataDir
    global sharedDefaultDir
    global sharedDir
    global topDir
    global txnLogDefaultDir
    global txnLogDir
    global workDefaultDir
    global workDir
    #
    mtxDir = os.path.expandvars(os.getenv('MTX_DIR', mtxDefaultDir))
    binDir = os.path.expandvars(os.getenv('MTX_BIN_DIR', binDefaultDir))
    confDir = os.path.expandvars(os.getenv('MTX_CONF_DIR', confDefaultDir))
    coreDir = os.path.expandvars(os.getenv('MTX_CORE_DIR', coreDefaultDir))
    customDir = os.path.expandvars(os.getenv('MTX_CUSTOM_DIR', customDefaultDir))
    dataDir = os.path.expandvars(os.getenv('MTX_DATA_DIR', dataDefaultDir))
    errorMdcLogDir = os.path.expandvars(os.getenv('MTX_ERROR_MDC_LOG_DIR', errorMdcLogDefaultDir))
    exportDir = os.path.expandvars(os.getenv('MTX_EXPORT_DIR', exportDefaultDir))
    libDir = os.path.expandvars(os.getenv('MTX_LIB_DIR', libDefaultDir))
    logDir = os.path.expandvars(os.getenv('MTX_LOG_DIR', logDefaultDir))
    pidDir = os.path.expandvars(os.getenv('MTX_PID_DIR', pidDefaultDir))
    rpmDir = os.path.expandvars(os.getenv('MTX_RPM_DIR', rpmDefaultDir))
    pricingDir = customDir
    productUserHomeDir = '/home/' + mtxProductName
    recoveryDir = os.path.expandvars(os.getenv('MTX_RECOVERY_DIR', recoveryDefaultDir))
    rsgatewayTomcatDir = os.path.expandvars(os.getenv('MTX_RSGATEWAY_TOMCAT_DIR', rsgatewayTomcatDefaultDir))
    seagullDataDir = dataDir + '/seagull'
    sharedDir = os.path.expandvars(os.getenv('MTX_SHARED_DIR', sharedDefaultDir))
    topDir = os.path.expandvars(os.getenv('TOPDIR', ''))
    txnLogDir = os.path.expandvars(os.getenv('MTX_TXN_LOG_DIR', txnLogDefaultDir))
    workDir = os.path.expandvars(os.getenv('MTX_WORK_DIR', workDefaultDir))
    # Check if this is an installed environment.
    isInstalledEnvironment = False
    if (topDir == ''):
        isInstalledEnvironment = True
    return

#===============================================================================
#
# Initialization

setDirectoryNames()
