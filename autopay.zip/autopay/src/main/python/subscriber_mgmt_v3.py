#!/usr/bin/python3
#===============================================================================
#
# Copyright 2012-2021, MATRIXX Software, Inc. All rights reserved.
#
#-------------------------------------------------------------------------------
#
# @file
# @date       $Date$
#
# $Id$
#
# @2to3-3 --no-diffs -x input -x print -w  : Thu 2021-08-26T16:53:18
#
# @futurize --stage2 --no-diffs -n -w  : Mon 2021-03-01T15:39:20
#
#
#
#===============================================================================

import data_container as MDC
import data_container_defs as MDCDEFS

# Version number of API requests
submanVersion = 1

# MtxRequest.ExecuteMode
EXECUTE_MODE_NORMAL = 0
EXECUTE_MODE_DRYRUN = 1
EXECUTE_MODE_ADVICE = 2

# pylint: disable=R0904
class SubscriberManagementV3Client(object):
    #
    # Subscriber Management Client operates in one of three modes:
    #
    # * "Normal" mode - the default - each method (e.g. subscriberCreate) builds
    #   an MDC based operaton request and it is sent via the Data Container connection
    #   to the server for processing. The method returns an MtxResponse derived
    #   MDC from the server.
    #
    # * "BuildRequest" mode just builds the MtxRequest derived MDC and returns it. These
    #   MDC's are suitable for embedding into chained requests.
    #
    # * "BuildMessage" mode builds the request and embedded it into the standard MtxOpMsg.
    #   These MDC's are suitable for storage & transmission to the server via test_app or
    #   the data container client connection.
    #
    # In normal mode, connections are automatically opened and closed for each and every
    # request. To manually control connections, call the "openConnection()" method before
    # the requests. This creates a connection and disables auto-connect mode. The
    # connection will persist until "closeConnection()" is called.
    #
    def __init__(self, trace=False, hostName=None, hostPort=None,
            mode='Normal'):
        self.connectionOpen = False
        if mode == 'Normal':
            self.mdcClientConnection = MDC.DataContainerClientConnection(
                sendFormatType='COMPACT', traceMessages=trace,
                hostName=hostName, hostPort=hostPort)
            self.returnResponse = False
        elif mode == 'BuildRequest':
            self.mdcClientConnection = None
            self.returnResponse = True
        elif mode == 'BuildMessage':
            self.returnResponse = False
            self.mdcClientConnection = None
        else:
            raise RuntimeError("Unknown processing mode")

        # The default execute mode (MtxRequest.ExecuteMode) is normal.
        self.executeMode = 0

        # For internal MATRIXX testing use only
        self.mtxFlags = 0
        self.mtxDataMdc = None

    # Send an MDC command to the gateway and get a response
    def _sendRpcRequest(self, requestMdc, searchData=None, routingType=None, routingValue=None):
        global subman_version

        responseMdc = None

        # Set the version number in the API request
        requestMdc.setUsingKey(MDCDEFS.kMtxRequestVersionFldKey, submanVersion)
        if self.mtxFlags != 0:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestFlagsFldKey, self.mtxFlags)

        if self.executeMode != 0:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestExecuteModeFldKey, self.executeMode)

        if self.returnResponse:
            return requestMdc

        # Create an MtxOp msg to send the request inside.
        rpcMdc = MDCDEFS.kMtxOpMsgMdcDesc.create()
        rpcMdc.setUsingKey(MDCDEFS.kMtxOpMsgRequestFldKey, requestMdc)

        if routingType is not None or routingValue is not None:
            # Use explicit routingType/routingValue if specified
            if routingType is None:
                raise RuntimeError('routingValue specified without routingType')
            elif routingValue is None:
                raise RuntimeError('routingType specified without routingValue')
            else:
                if routingType not in ROUTING_TYPES:
                    raise RuntimeError('Unknown routingType: ' + str(routingType))
                else:
                    rpcMdc.setUsingKey(
                        MDCDEFS.kMtxMsgTrafficRouteDataFldKey,
                        routingType + str(routingValue))
        elif searchData is not None:
            # Use implicit search data block to populate routing data
            if searchData.isDescendantOf(MDCDEFS.KEY_MTX_SUBSCRIBER_SEARCH_DATA):
                addSubscriberRoutingData(rpcMdc, searchData)
            elif searchData.isDescendantOf(MDCDEFS.KEY_MTX_GROUP_SEARCH_DATA):
                addGroupRoutingData(rpcMdc, searchData)
            elif searchData.isDescendantOf(MDCDEFS.KEY_MTX_DEVICE_SEARCH_DATA):
                addDeviceRoutingData(rpcMdc, searchData)
            elif searchData.isDescendantOf(MDCDEFS.KEY_MTX_OBJECT_SEARCH_DATA):
                addObjectRoutingData(rpcMdc, searchData)
            elif searchData.isDescendantOf(MDCDEFS.KEY_MTX_TASK_SEARCH_DATA):
                addTaskRoutingData(rpcMdc, searchData)
            elif searchData.isDescendantOf(MDCDEFS.KEY_MTX_EVENT_SEARCH_DATA):
                addEventRoutingData(rpcMdc, searchData)
            elif searchData.isDescendantOf(MDCDEFS.KEY_MTX_MEMBERSHIP_SEARCH_DATA):
                addMembershipRoutingData(rpcMdc, searchData)
            elif searchData.isDescendantOf(MDCDEFS.KEY_MTX_USER_SEARCH_DATA):
                addUserRoutingData(rpcMdc, searchData)
            elif searchData.isDescendantOf(MDCDEFS.KEY_MTX_ACCOUNT_SEARCH_DATA):
                addAccountRoutingData(rpcMdc, searchData)
            elif searchData.isDescendantOf(MDCDEFS.KEY_MTX_SUBSCRIPTION_SEARCH_DATA):
                addSubscriptionRoutingData(rpcMdc, searchData)
            elif searchData.isDescendantOf(MDCDEFS.KEY_MTX_RESOURCE_REGISTER_SEARCH_DATA):
                addResourceRegisterRoutingData(rpcMdc, searchData)
            elif searchData.isDescendantOf(MDCDEFS.KEY_MTX_RESOURCE_REGISTER_SEARCH_DATA_LIST):
                addResourceRegisterListRoutingData(rpcMdc, searchData)
            else:
                raise RuntimeError('Unknown searchData: ' + str(searchData))
        else:
            # For 5010 release, default to RTID1 if no explicit routing data provided
            rpcMdc.setUsingKey(
                MDCDEFS.kMtxMsgTrafficRouteDataFldKey,
                "RTID1")

        if self.mdcClientConnection is None:
            responseMdc = rpcMdc
        else:
            # Send the request
            autoConnect = True
            if self.connectionOpen:
                autoConnect = False

            if autoConnect:
                self.mdcClientConnection.open()

            mdcResponse = self.mdcClientConnection.send(rpcMdc)

            if autoConnect:
                self.mdcClientConnection.close()

            # Get the response
            if mdcResponse is None:
                raise RuntimeError('Connection error: no response object received')

            responseMdc = mdcResponse.getUsingKey(MDCDEFS.kMtxOpMsgResponseFldKey)
            if self.mtxFlags != 0:
                self.mtxDataMdc = mdcResponse.getUsingKey(MDCDEFS.kMtxOpMsgDataFldKey)

        return responseMdc

    def openConnection(self):
        if not self.mdcClientConnection:
            return
        if self.connectionOpen:
            raise RuntimeError("Connection is already open")
        self.mdcClientConnection.open()
        self.connectionOpen = True
        return

    def closeConnection(self):
        if not self.mdcClientConnection:
            return
        if not self.connectionOpen:
            raise RuntimeError("Connection is not open")
        self.mdcClientConnection.close()
        self.connectionOpen = False
        return

    def subscriberCreate(self, now=None, externalId=None, status=None,
            firstName=None, lastName=None, contactEmail=None,
            contactPhoneNumber=None, contactPushTokenList=None,
            notificationPreference=None, timeZone=None, billingCycle=None,
            attr=None, language=None, taxStatus=None, taxCertificate=None,
            taxLocation=None, glCenter=None, name=None, routingType=None,
            routingValue=None, apiEventData=None,
            customerType=None, serviceAddress=None,
            npa=None, nxx=None, tenantId=None, exemptionCodeList=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberCreateMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if externalId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberCreateExternalIdFldKey, externalId)
        if status != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberCreateStatusFldKey, status)
        if firstName != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCreateFirstNameFldKey, firstName)
        if lastName != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCreateLastNameFldKey, lastName)
        if contactEmail != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCreateContactEmailFldKey, contactEmail)
        if contactPhoneNumber != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCreateContactPhoneNumberFldKey, contactPhoneNumber)
        if contactPushTokenList != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCreateContactPushTokenListFldKey, contactPushTokenList)
        if notificationPreference != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCreateNotificationPreferenceFldKey, notificationPreference)
        if timeZone != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCreateTimeZoneFldKey, timeZone)
        if billingCycle != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCreateBillingCycleFldKey, billingCycle)
        if attr != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberCreateAttrFldKey, \
                attr)
        if taxStatus != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCreateTaxStatusFldKey, taxStatus)
        if taxCertificate != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCreateTaxCertificateFldKey, taxCertificate)
        if taxLocation != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCreateTaxLocationFldKey, taxLocation)
        if glCenter != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCreateGlCenterFldKey, glCenter)
        if language != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCreateLanguageFldKey, language)
        if name != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCreateNameFldKey, name)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        if customerType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCreateCustomerTypeFldKey, customerType)
        if npa != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCreateNpaFldKey, npa)
        if nxx != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCreateNxxFldKey, nxx)
        if tenantId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCreateTenantIdFldKey, tenantId)
        if serviceAddress != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCreateServiceAddressFldKey, serviceAddress)
        if exemptionCodeList != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCreateExemptionCodeListFldKey, exemptionCodeList)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def subscriberQuery(self, queryType, queryValue, querySize=None,
            apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberQueryMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberQuerySubscriberSearchDataFldKey, \
            search)
        if querySize != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberQueryQuerySizeFldKey, querySize)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberQueryWallet(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberQueryWalletMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberQueryWalletSubscriberSearchDataFldKey, \
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberQueryMembership(self, queryType, queryValue, membershipType,
            queryCursor=None, querySize=None, returnExternalId=False, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberQueryMembershipMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberQueryMembershipSubscriberSearchDataFldKey, \
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberQueryMembershipMembershipTypeFldKey, membershipType)
        if queryCursor != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberQueryMembershipQueryCursorFldKey, queryCursor)
        if querySize != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberQueryMembershipQuerySizeFldKey, querySize)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberQueryMembershipReturnExternalIdFldKey, returnExternalId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberQueryEvent(self, queryType, queryValue,
            deviceQueryType=None, deviceQueryValue=None,
            queryCursor=None, querySize=None,
            eventTimeLowerBound=None, eventTimeUpperBound=None,
            eventTypeStringArray=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberQueryEventMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberQueryEventSubscriberSearchDataFldKey, \
            search)
        if deviceQueryType is not None and deviceQueryValue is not None:
            devSearch = newDeviceSearch(deviceQueryType, deviceQueryValue)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberQueryEventDeviceSearchDataFldKey, \
                devSearch)
        if queryCursor != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberQueryEventQueryCursorFldKey, queryCursor)
        if querySize != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberQueryEventQuerySizeFldKey, querySize)
        if eventTimeLowerBound != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberQueryEventEventTimeLowerBoundFldKey, eventTimeLowerBound)
        if eventTimeUpperBound != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberQueryEventEventTimeUpperBoundFldKey, eventTimeUpperBound)
        if eventTypeStringArray != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberQueryEventEventTypeArrayFldKey, eventTypeStringArray)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberQueryAggregation(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberQueryAggregationMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberQueryAggregationSubscriberSearchDataFldKey, \
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    # pylint: disable=R0913
    __pychecker__ = '--maxargs=50'
    def subscriberModify(self, queryType, queryValue, now=None,
            status=None, firstName=None, lastName=None, contactEmail=None,
            contactPhoneNumber=None, contactPushTokenList=None,
            notificationPreference=None, timeZone=None, billingCycle=None,
            attr=None, externalId=None, language=None, taxStatus=None,
            taxCertificate=None, taxLocation=None, glCenter=None,
            paymentGatewayUserId=None, currentPaymentTokenResourceId=None,
            lastActivityUpdateTime=None, billingCycleDisabled=None,
            sysPaymentTokenResourceId=None, name=None, apiEventData=None,
            customerType=None, serviceAddress=None,
            npa=None, nxx=None, tenantId=None, exemptionCodeList=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberModifyMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberModifySubscriberSearchDataFldKey, \
            search)
        if status != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyStatusFldKey, status)
        if firstName != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyFirstNameFldKey, firstName)
        if lastName != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyLastNameFldKey, lastName)
        if contactEmail != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyContactEmailFldKey, contactEmail)
        if contactPhoneNumber != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyContactPhoneNumberFldKey, contactPhoneNumber)
        if contactPushTokenList != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyContactPushTokenListFldKey, contactPushTokenList)
        if notificationPreference != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyNotificationPreferenceFldKey, notificationPreference)
        if timeZone != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyTimeZoneFldKey, timeZone)
        if billingCycle != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyBillingCycleFldKey, billingCycle)
        if attr != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberModifyAttrFldKey, \
                attr)
        if taxStatus != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyTaxStatusFldKey, taxStatus)
        if taxCertificate != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyTaxCertificateFldKey, taxCertificate)
        if taxLocation != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyTaxLocationFldKey, taxLocation)
        if language != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyLanguageFldKey, language)
        if externalId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyExternalIdFldKey, externalId)
        if glCenter != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyGlCenterFldKey, glCenter)
        if paymentGatewayUserId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyPaymentGatewayUserIdFldKey, paymentGatewayUserId)
        if currentPaymentTokenResourceId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyCurrentPaymentTokenResourceIdFldKey, currentPaymentTokenResourceId)
        if lastActivityUpdateTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyLastActivityUpdateTimeFldKey, lastActivityUpdateTime)
        if billingCycleDisabled != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyBillingCycleDisabledFldKey, billingCycleDisabled)
        if sysPaymentTokenResourceId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifySysPaymentTokenResourceIdFldKey, sysPaymentTokenResourceId)
        if name != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyNameFldKey, name)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        if customerType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyCustomerTypeFldKey, customerType)
        if npa != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyNpaFldKey, npa)
        if nxx != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyNxxFldKey, nxx)
        if tenantId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyTenantIdFldKey, tenantId)
        if serviceAddress != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyServiceAddressFldKey, serviceAddress)
        if exemptionCodeList != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyExemptionCodeListFldKey, exemptionCodeList)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberDelete(self, queryType, queryValue, deleteDevices=None, deleteSession=None,
                         apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberDeleteMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberDeleteSubscriberSearchDataFldKey, \
            search)
        if deleteDevices != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberDeleteDeleteDeviceFldKey, deleteDevices)
        if deleteSession != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberDeleteDeleteSessionFldKey, deleteSession)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberAddDevice(self, subQueryType, subQueryValue, devQueryType,
            devQueryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberAddDeviceMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        subSearch = newSubscriberSearch(subQueryType, subQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberAddDeviceSubscriberSearchDataFldKey, \
            subSearch)
        devSearch = newDeviceSearch(devQueryType, devQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberAddDeviceDeviceSearchDataFldKey, \
            devSearch)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, subSearch)
        return responseMdc

    def subscriberRemoveDevice(self, subQueryType, subQueryValue, devQueryType,
            devQueryValue, deleteSession=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberRemoveDeviceMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        subSearch = newSubscriberSearch(subQueryType, subQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberRemoveDeviceSubscriberSearchDataFldKey, \
            subSearch)
        devSearch = newDeviceSearch(devQueryType, devQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberRemoveDeviceDeviceSearchDataFldKey, \
            devSearch)
        if deleteSession != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberRemoveDeviceDeleteSessionFldKey, deleteSession)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, subSearch)
        return responseMdc

    def subscriberPurchaseOffer(self, queryType, queryValue, offerList,
            paymentMethodResourceId=None, chargeMethod=None,
            paymentGatewayId=None, paymentGatewayUserId=None, nonce=None,
            chargeMethodAttr=None, deferredSettlement=False,
            deferredSettlementTimeout=None, deferredSettlementTimeoutAction=None,
            eligibilityCheck=None, apiEventData=None, now=None, geoData=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberPurchaseOfferMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberPurchaseOfferSubscriberSearchDataFldKey,
            search)

        offerArray = newOfferPurchaseArray(offerList)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberPurchaseOfferOfferRequestArrayFldKey,
            offerArray)

        if paymentMethodResourceId != None or chargeMethod != None or \
            paymentGatewayId != None or paymentGatewayUserId != None or \
            nonce != None or chargeMethodAttr != None or deferredSettlement:
            chargeMethodData = newChargeMethodData(paymentMethodResourceId,
                chargeMethod, paymentGatewayId, paymentGatewayUserId, nonce, chargeMethodAttr,
                deferredSettlement, deferredSettlementTimeout, deferredSettlementTimeoutAction)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberPurchaseOfferChargeMethodDataFldKey,
                chargeMethodData)

        if eligibilityCheck != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberPurchaseOfferEligibilityCheckFldKey,
                eligibilityCheck)

        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        if geoData is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberPurchaseOfferOneTimeTaxGeoDataFldKey, geoData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberCancelOffer(self, queryType, queryValue, resourceIdList=None, now=None,
                              cancelOfferDataList=None, eligibilityCheck=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberCancelOfferMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberCancelOfferSubscriberSearchDataFldKey,
            search)

        if (resourceIdList != None):
            resourceIdArray = []
            for resourceId in resourceIdList:
                resourceIdArray.append(resourceId)

            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCancelOfferResourceIdArrayFldKey,
                resourceIdArray)
        if (cancelOfferDataList != None):
            cancelOfferDataArray = newCancelOfferDataArray(cancelOfferDataList)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCancelOfferCancelDataArrayFldKey,
                cancelOfferDataArray)
        if (resourceIdList is None and cancelOfferDataList is None):
            raise RuntimeError('Either ResourceIdArray or CancelOfferDataArray must be specified')

        if eligibilityCheck != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCancelOfferEligibilityCheckFldKey,
                eligibilityCheck)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberModifyOffer(self, queryType, queryValue, resourceId, now=None,
            startTime=None, endTime=None, attr=None, cycleType=None,
            cycleResourceId=None, cycleOffset=None, cycleAlignmentDisabled=None,
            immediateChange=None, status=None, offerStatusValue=None,
            cycleStartTime=None, cycleEndTime=None, parameterList=None, apiEventData=None,
            isRecurringFailureAllowed=None, endTimeExtensionOffsetUnit=None,
            endTimeExtensionOffset=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberModifyOfferMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberModifyOfferSubscriberSearchDataFldKey, \
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberModifyOfferResourceIdFldKey, \
            resourceId)

        if startTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyOfferStartTimeFldKey, startTime)
        if endTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyOfferEndTimeFldKey, endTime)
        if endTimeExtensionOffsetUnit != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyOfferEndTimeExtensionOffsetUnitFldKey, endTimeExtensionOffsetUnit)
        if endTimeExtensionOffset != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyOfferEndTimeExtensionOffsetFldKey, endTimeExtensionOffset)
        if attr != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberModifyOfferAttrFldKey, \
                attr)

        # Create and set CycleData if any of the cycle parameters are included
        if cycleOffset or cycleType or cycleResourceId or cycleAlignmentDisabled \
                or immediateChange or cycleStartTime or cycleEndTime:
            cycleData = MDCDEFS.kMtxPurchasedItemCycleDataMdcDesc.create()
            if cycleType != None:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataCycleTypeFldKey,
                    cycleType)
            if cycleResourceId != None:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataCycleResourceIdFldKey,
                    cycleResourceId)
            if cycleOffset != None:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataCycleOffsetFldKey,
                    cycleOffset)
            if cycleAlignmentDisabled != None:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataCycleAlignmentDisabledFldKey,
                    cycleAlignmentDisabled)
            if immediateChange != None:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataImmediateChangeFldKey,
                    immediateChange)
            if cycleStartTime != None:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataCycleStartTimeFldKey,
                    cycleStartTime)
            if cycleEndTime != None:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataCycleEndTimeFldKey,
                    cycleEndTime)
            if isRecurringFailureAllowed != None:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataIsRecurringFailureAllowedFldKey,
                    isRecurringFailureAllowed)
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestSubscriberModifyOfferCycleDataFldKey, cycleData)
        # Status:
        if status != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberModifyOfferStatusFldKey, \
                status)
        # OfferStatusValue:
        if offerStatusValue != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberModifyOfferOfferStatusValueFldKey, \
                offerStatusValue)
        # parameterLIst
        if parameterList != None:
            parameterArray = newParameterDataArray(parameterList)
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestSubscriberModifyOfferParameterArrayFldKey, parameterArray)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberAddThreshold(self, queryType, queryValue, resourceId,
            thresholdId, thresholdAmount, thresholdName=None,
            thresholdNotification=None, recurringStart=None, recurringStop=None,
            virtualCreditLimitIsPercent=None, rechargeAmount=None,
            rechargePaymentMethodResourceId=None, isTemporaryCreditLimit=False,
            apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberAddThresholdMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberAddThresholdSubscriberSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberAddThresholdBalanceResourceIdFldKey,
            resourceId)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberAddThresholdThresholdThresholdIdFldKey,
            thresholdId)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberAddThresholdThresholdAmountFldKey,
            thresholdAmount)
        if thresholdName != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAddThresholdThresholdNameFldKey,
                thresholdName)
        if thresholdNotification != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAddThresholdThresholdNotificationStateFldKey,
                thresholdNotification)
        if recurringStart != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAddThresholdThresholdRecurringStartFldKey, recurringStart)
        if recurringStop != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAddThresholdThresholdRecurringStopFldKey, recurringStop)
        if virtualCreditLimitIsPercent != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAddThresholdThresholdVirtualCreditLimitIsPctFldKey,
                virtualCreditLimitIsPercent)
        if rechargeAmount != None or rechargePaymentMethodResourceId != None:
            rechargeData = newRechargeData(rechargeAmount, rechargePaymentMethodResourceId)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAddThresholdThresholdRechargeDataFldKey,
                rechargeData)
        if isTemporaryCreditLimit:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAddThresholdThresholdIsTemporaryCreditLimitFldKey,
                isTemporaryCreditLimit)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberRemoveThreshold(self, queryType, queryValue, resourceId,
            thresholdId, removeThresholdOnly=None, removeRechargeDataOnly=None,
            isTemporaryCreditLimit=False, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberRemoveThresholdMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberRemoveThresholdSubscriberSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberRemoveThresholdBalanceResourceIdFldKey,
            resourceId)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberRemoveThresholdThresholdIdFldKey,
            thresholdId)
        if removeThresholdOnly != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberRemoveThresholdRemoveThresholdOnlyFldKey,
                removeThresholdOnly)
        if removeRechargeDataOnly != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberRemoveThresholdRemoveRechargeDataOnlyFldKey,
                removeRechargeDataOnly)
        if isTemporaryCreditLimit:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberRemoveThresholdIsTemporaryCreditLimitFldKey,
                isTemporaryCreditLimit)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberAddBalance(self, queryType, queryValue, balanceList,
            apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberAddBalanceMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberAddBalanceSubscriberSearchDataFldKey,
            search)

        balanceArray = []
        for balance in balanceList:
            balanceMdc = MDCDEFS.kMtxBalanceDataMdcDesc.create()
            balanceMdc.setUsingKey(
                MDCDEFS.kMtxBalanceDataBalanceTemplateIdFldKey,
                balance['BalanceTemplateId'])
            if 'InitAmount' in balance:
                balanceMdc.setUsingKey(
                    MDCDEFS.kMtxBalanceDataInitAmountFldKey,
                    balance['InitAmount'])
            balanceArray.append(balanceMdc)

        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberAddBalanceBalanceRequestArrayFldKey,
            balanceArray)

        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberAdjustBalance(self, queryType, queryValue, balanceResourceId,
            adjustType, reason, amount=None, info=None, endTime=None, creditLimitPolicy=None,
            endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
            startTime=None, componentMeterId=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberAdjustBalanceMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberAdjustBalanceSubscriberSearchDataFldKey,
            search)

        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberAdjustBalanceBalanceResourceIdFldKey,
            balanceResourceId)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberAdjustBalanceAdjustTypeFldKey,
            adjustType)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberAdjustBalanceReasonFldKey,
            reason)
        if amount != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAdjustBalanceAmountFldKey,
                amount)
        if info != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAdjustBalanceInfoFldKey,
                info)
        if endTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAdjustBalanceEndTimeFldKey,
                endTime)
        if creditLimitPolicy != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAdjustBalanceCreditLimitPolicyFldKey,
                creditLimitPolicy)
        if endTimeExtensionOffsetUnit != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAdjustBalanceEndTimeExtensionOffsetUnitFldKey,
                endTimeExtensionOffsetUnit)
        if endTimeExtensionOffset != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAdjustBalanceEndTimeExtensionOffsetFldKey,
                endTimeExtensionOffset)
        if startTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAdjustBalanceStartTimeFldKey,
                startTime)
        if componentMeterId is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAdjustBalanceComponentMeterIdFldKey,
                componentMeterId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberTopupBalance(self, queryType, queryValue, balanceResourceId,
            amount, voucher, endTime=None, endTimeExtensionOffsetUnit=None,
            endTimeExtensionOffset=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberTopupBalanceMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberTopupBalanceSubscriberSearchDataFldKey,
            search)

        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberTopupBalanceBalanceResourceIdFldKey,
            balanceResourceId)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberTopupBalanceAmountFldKey,
            amount)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberTopupBalanceVoucherFldKey,
            voucher)
        if endTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberTopupBalanceEndTimeFldKey,
                endTime)
        if endTimeExtensionOffsetUnit != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberTopupBalanceEndTimeExtensionOffsetUnitFldKey,
                endTimeExtensionOffsetUnit)
        if endTimeExtensionOffset != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberTopupBalanceEndTimeExtensionOffsetFldKey,
                endTimeExtensionOffset)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberAdjustRolloverBalance(self, queryType, queryValue, reason,
            balanceResourceId, balanceIntervalId=None, adjustType=None, amount=None,
            remainingRolloverCounter=None, info=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberAdjustRolloverBalanceMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberAdjustRolloverBalanceSubscriberSearchDataFldKey,
            search)

        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberAdjustRolloverBalanceBalanceResourceIdFldKey,
            balanceResourceId)
        if balanceIntervalId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAdjustRolloverBalanceBalanceIntervalIdFldKey,
                balanceIntervalId)
        if adjustType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAdjustRolloverBalanceAdjustTypeFldKey,
                adjustType)
        if amount != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAdjustRolloverBalanceAmountFldKey,
                amount)
        if remainingRolloverCounter != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAdjustRolloverBalanceRemainingRolloverCounterFldKey,
                remainingRolloverCounter)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberAdjustRolloverBalanceReasonFldKey,
            reason)
        if info != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAdjustRolloverBalanceInfoFldKey,
                info)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberQueryAuthData(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberQueryAuthDataMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberQueryAuthDataSubscriberSearchDataFldKey,
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberModifyAuthData(self, queryType, queryValue, loginId=None,
            password=None, roleFlags=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberModifyAuthDataMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberModifyAuthDataSubscriberSearchDataFldKey,
            search)

        if loginId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyAuthDataLoginIdFldKey,
                loginId)
        # This is a BLOB field but represented in Python as a string
        if password != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyAuthDataPasswordFldKey,
                password)
        if roleFlags != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyAuthDataRoleFlagsFldKey,
                roleFlags)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberImportBalanceValue(self, queryType, queryValue, balanceResourceId,
            amount, startTime=None, createOnDemand=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberImportBalanceValueMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberImportBalanceValueSubscriberSearchDataFldKey,
            search)

        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberImportBalanceValueBalanceResourceIdFldKey,
            balanceResourceId)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberImportBalanceValueAmountFldKey,
            amount)

        if startTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberImportBalanceValueStartTimeFldKey,
                startTime)
        if createOnDemand != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberImportBalanceValueCreateOnDemandFldKey,
                createOnDemand)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberTransferBalance(self, queryType, queryValue, balanceResourceId,
        amount, amountIsPct, targetBalanceResourceId, targetSubscriberSearchData=None,
        targetGroupSearchData=None, sourceIsEventInitiator=True, reason=None,
        info=None, creditFloorPolicy=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberTransferBalanceMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberTransferBalanceSubscriberSearchDataFldKey,
            search)

        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberTransferBalanceBalanceResourceIdFldKey,
            balanceResourceId)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberTransferBalanceAmountFldKey,
            amount)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberTransferBalanceAmountIsPctFldKey,
            amountIsPct)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberTransferBalanceTargetBalanceResourceIdFldKey,
            targetBalanceResourceId)
        if targetSubscriberSearchData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberTransferBalanceTargetSubscriberSearchDataFldKey, \
                targetSubscriberSearchData)
        if targetGroupSearchData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberTransferBalanceTargetGroupSearchDataFldKey, \
                targetGroupSearchData)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberTransferBalanceSourceIsEventInitiatorFldKey,
            sourceIsEventInitiator)
        if creditFloorPolicy != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberTransferBalanceCreditFloorPolicyFldKey,
                creditFloorPolicy)
        if reason != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberTransferBalanceReasonFldKey,
                reason)
        if info != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberTransferBalanceInfoFldKey,
                info)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberQueryPaymentMethod(self,
            queryType, queryValue, paymentGatewayId=None, returnDefault=None, returnSysDefault=None,
            apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberQueryPaymentMethodMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberQueryPaymentMethodSubscriberSearchDataFldKey,
            search)

        if paymentGatewayId is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberQueryPaymentMethodPaymentGatewayIdFldKey,
                paymentGatewayId)
        if returnDefault is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberQueryPaymentMethodReturnDefaultFldKey,
                returnDefault)
        if returnSysDefault is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberQueryPaymentMethodReturnSysDefaultFldKey,
                returnSysDefault)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberAddPaymentMethod(self,
            queryType, queryValue, nonce, paymentGatewayId=None, paymentGatewayUserId=None,
            name=None, isDefault=None, paymentType=None, paymentAttr=None, isSysDefault=None,
            apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberAddPaymentMethodMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberAddPaymentMethodSubscriberSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberAddPaymentMethodPaymentGatewayOneTimeTokenFldKey,
            nonce)
        if paymentGatewayId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAddPaymentMethodPaymentGatewayIdFldKey,
                paymentGatewayId)
        if paymentGatewayUserId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAddPaymentMethodPaymentGatewayUserIdFldKey,
                paymentGatewayUserId)
        if name != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAddPaymentMethodNameFldKey,
                name)
        if isDefault != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAddPaymentMethodIsDefaultFldKey,
                isDefault)
        if paymentType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAddPaymentMethodPaymentTypeFldKey,
                paymentType)
        if paymentAttr != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAddPaymentMethodPaymentAttrFldKey,
                paymentAttr)
        if isSysDefault != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberAddPaymentMethodIsSysDefaultFldKey,
                isSysDefault)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberModifyPaymentMethod(self,
            queryType, queryValue, resourceId, paymentGatewayUserId=None, paymentGatewayOneTimeToken=None,
            name=None, isDefault=None, paymentType=None, paymentAttr=None, isSysDefault=None,
            apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberModifyPaymentMethodMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberModifyPaymentMethodSubscriberSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberModifyPaymentMethodResourceIdFldKey,
            resourceId)
        if paymentGatewayUserId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyPaymentMethodPaymentGatewayUserIdFldKey,
                paymentGatewayUserId)
        if paymentGatewayOneTimeToken != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyPaymentMethodPaymentGatewayOneTimeTokenFldKey,
                paymentGatewayOneTimeToken)
        if name != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyPaymentMethodNameFldKey,
                name)
        if isDefault != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyPaymentMethodIsDefaultFldKey,
                isDefault)
        if paymentType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyPaymentMethodPaymentTypeFldKey,
                paymentType)
        if paymentAttr != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyPaymentMethodPaymentAttrFldKey,
                paymentAttr)
        if isSysDefault != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyPaymentMethodIsSysDefaultFldKey,
                isSysDefault)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberRemovePaymentMethod(self, queryType, queryValue, resourceId, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberRemovePaymentMethodMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberRemovePaymentMethodSubscriberSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberRemovePaymentMethodResourceIdFldKey,
            resourceId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberValidatePaymentMethod(self, queryType, queryValue, resourceId=None, postalCode=None,
                                        apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberValidatePaymentMethodMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        searchData = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberValidatePaymentMethodSubscriberSearchDataFldKey,
            searchData)
        if resourceId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberValidatePaymentMethodResourceIdFldKey, resourceId)
        if postalCode != None:
            validationData = newPaymentMethodValidationData(postalCode)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberValidatePaymentMethodPaymentMethodValidationDataFldKey,
                validationData)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, searchData)
        return responseMdc

    def subscriberPayment(self, queryType, queryValue, amount, reason=None, info=None,
            payNow=None, paymentMethodResourceId=None, paymentGatewayId=None,
            paymentGatewayUserId=None, nonce=None, chargeMethodAttr=None,
            apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberPaymentMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberPaymentSubscriberSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberPaymentAmountFldKey,
            amount)
        if reason != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberPaymentReasonFldKey,
                reason)
        if info != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberPaymentInfoFldKey,
                info)
        if payNow is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberPaymentPayNowFldKey,
                payNow)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        if paymentMethodResourceId != None or paymentGatewayId != None \
            or paymentGatewayUserId != None or nonce != None or chargeMethodAttr != None:
            chargeMethodData = newChargeMethodData(paymentMethodResourceId,
                None, paymentGatewayId, paymentGatewayUserId, nonce, chargeMethodAttr)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberPaymentChargeMethodDataFldKey,
                chargeMethodData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberCreatePaymentOneTimeToken(self,
            queryType, queryValue, paymentMethodResourceId=None, paymentAttr=None,
            apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberCreatePaymentOneTimeTokenMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberCreatePaymentOneTimeTokenSubscriberSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberCreatePaymentOneTimeTokenPaymentMethodResourceIdFldKey,
            paymentMethodResourceId)
        if paymentAttr != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCreatePaymentOneTimeTokenPaymentAttrFldKey,
                paymentAttr)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberRecharge(self, queryType, queryValue, amount, balanceResourceId=None,
            payNow=None, endTime=None, endTimeExtensionOffsetUnit=None,
            endTimeExtensionOffset=None, paymentMethodResourceId=None,
            reason=None, info=None, paymentGatewayId=None, paymentGatewayUserId=None,
            nonce=None, chargeMethodAttr=None, rechargeAttr=None, now=None,
            apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberRechargeMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberRechargeSubscriberSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberRechargeAmountFldKey,
            amount)
        if balanceResourceId is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberRechargeBalanceResourceIdFldKey,
                balanceResourceId)
        if payNow is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberRechargePayNowFldKey,
                payNow)
        if endTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberRechargeEndTimeFldKey,
                endTime)
        if endTimeExtensionOffsetUnit != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberRechargeEndTimeExtensionOffsetUnitFldKey,
                endTimeExtensionOffsetUnit)
        if endTimeExtensionOffset != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberRechargeEndTimeExtensionOffsetFldKey,
                endTimeExtensionOffset)
        if reason != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberRechargeReasonFldKey,
                reason)
        if info != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberRechargeInfoFldKey,
                info)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        if paymentMethodResourceId != None or paymentGatewayId != None \
            or paymentGatewayUserId != None or nonce != None or chargeMethodAttr != None:
            chargeMethodData = newChargeMethodData(paymentMethodResourceId,
                None, paymentGatewayId, paymentGatewayUserId, nonce, chargeMethodAttr)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberRechargeChargeMethodDataFldKey,
                chargeMethodData)

        if rechargeAttr != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberRechargeRechargeAttrFldKey,
                rechargeAttr)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberSysInitRecharge(self, queryType, queryValue, amount, balanceResourceId=None,
            payNow=None, endTime=None, endTimeExtensionOffsetUnit=None,
            endTimeExtensionOffset=None, paymentMethodResourceId=None,
            reason=None, info=None, paymentGatewayId=None, paymentGatewayUserId=None,
            nonce=None, chargeMethodAttr=None, rechargeAttr=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberSysInitRechargeMdcDesc.create()
        # Set the 'REQUEST_FLAG_SYSTEM_INITIATED_RECHARGE' flag in the request
        requestMdc.setUsingKey(MDCDEFS.kMtxRequestFlagsFldKey, 16)
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberRechargeSubscriberSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberRechargeAmountFldKey,
            amount)
        if balanceResourceId is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberRechargeBalanceResourceIdFldKey,
                balanceResourceId)
        if payNow is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberRechargePayNowFldKey,
                payNow)
        if endTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberRechargeEndTimeFldKey,
                endTime)
        if endTimeExtensionOffsetUnit != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberRechargeEndTimeExtensionOffsetUnitFldKey,
                endTimeExtensionOffsetUnit)
        if endTimeExtensionOffset != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberRechargeEndTimeExtensionOffsetFldKey,
                endTimeExtensionOffset)
        if reason != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberRechargeReasonFldKey,
                reason)
        if info != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberRechargeInfoFldKey,
                info)

        if paymentMethodResourceId != None or paymentGatewayId != None \
            or paymentGatewayUserId != None or nonce != None or chargeMethodAttr != None:
            chargeMethodData = newChargeMethodData(paymentMethodResourceId,
                None, paymentGatewayId, paymentGatewayUserId, nonce, chargeMethodAttr)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberRechargeChargeMethodDataFldKey,
                chargeMethodData)

        if rechargeAttr != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberRechargeRechargeAttrFldKey,
                rechargeAttr)

        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberRefundPayment(self, queryType, queryValue, resourceId,
        amount=None, reason=None, info=None, balanceResourceId=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberRefundPaymentMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberRefundPaymentSubscriberSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberRefundPaymentResourceIdFldKey,
            resourceId)

        if amount is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberRefundPaymentAmountFldKey,
                amount)
        if reason is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberRefundPaymentReasonFldKey,
                reason)
        if info is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberRefundPaymentInfoFldKey,
                info)
        if balanceResourceId is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberRefundPaymentBalanceResourceIdFldKey,
                balanceResourceId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberSettlePayment(self, queryType, queryValue, resourceId, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberSettlePaymentMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberSettlePaymentSubscriberSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberSettlePaymentResourceIdFldKey,
            resourceId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberQueryPaymentHistory(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberQueryPaymentHistoryMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberQueryPaymentHistorySubscriberSearchDataFldKey,
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberEstimateRecurringCharge(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberEstimateRecurringChargeMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberEstimateRecurringChargeSubscriberSearchDataFldKey,
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberAddRechargeSchedule(self, queryType, queryValue, cycleDefn,
            amount, paymentMethodResourceId=None, firstRechargeTime=None,
            endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
            scheduledRechargeNotificationProfileId=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberAddRechargeScheduleMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberAddRechargeScheduleSubscriberSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberAddRechargeScheduleCycleDefnFldKey,
            cycleDefn)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberAddRechargeScheduleAmountFldKey,
            amount)
        if paymentMethodResourceId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberAddRechargeSchedulePaymentMethodResourceIdFldKey, \
                paymentMethodResourceId)
        if firstRechargeTime != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberAddRechargeScheduleFirstRechargeTimeFldKey, \
                firstRechargeTime)
        if endTimeExtensionOffsetUnit != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberAddRechargeScheduleEndTimeExtensionOffsetUnitFldKey, \
                endTimeExtensionOffsetUnit)
        if endTimeExtensionOffset != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberAddRechargeScheduleEndTimeExtensionOffsetFldKey, \
                endTimeExtensionOffset)
        if scheduledRechargeNotificationProfileId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberAddRechargeScheduleScheduledRechargeNotificationProfileIdFldKey, \
                scheduledRechargeNotificationProfileId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberModifyRechargeSchedule(self, queryType, queryValue, cycleDefn=None,
            amount=None, paymentMethodResourceId=None, nextRechargeTime=None,
            endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
            scheduledRechargeNotificationProfileId=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberModifyRechargeScheduleMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberModifyRechargeScheduleSubscriberSearchDataFldKey,
            search)
        if cycleDefn != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyRechargeScheduleCycleDefnFldKey,
                cycleDefn)
        if amount != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyRechargeScheduleAmountFldKey,
                amount)
        if paymentMethodResourceId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberModifyRechargeSchedulePaymentMethodResourceIdFldKey, \
                paymentMethodResourceId)
        if nextRechargeTime != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberModifyRechargeScheduleNextRechargeTimeFldKey, \
                nextRechargeTime)
        if endTimeExtensionOffsetUnit != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberModifyRechargeScheduleEndTimeExtensionOffsetUnitFldKey, \
                endTimeExtensionOffsetUnit)
        if endTimeExtensionOffset != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberModifyRechargeScheduleEndTimeExtensionOffsetFldKey, \
                endTimeExtensionOffset)
        if scheduledRechargeNotificationProfileId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberModifyRechargeScheduleScheduledRechargeNotificationProfileIdFldKey, \
                scheduledRechargeNotificationProfileId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberRemoveRechargeSchedule(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberRemoveRechargeScheduleMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberRemoveRechargeScheduleSubscriberSearchDataFldKey,
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberQueryRechargeSchedule(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberQueryRechargeScheduleMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberQueryRechargeScheduleSubscriberSearchDataFldKey,
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberQueryRecurringRecharge(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberQueryRecurringRechargeMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberQueryRecurringRechargeSubscriberSearchDataFldKey,
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberCheckPurchasedItemCycleAlignment(self, queryType, queryValue, offerRequest=None,
            offerResourceId=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberCheckPurchasedItemCycleAlignmentMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberCheckPurchasedItemCycleAlignmentSubscriberSearchDataFldKey,
            search)

        if offerRequest != None:
            offerRequest = newOfferPurchaseArray([offerRequest])[0]
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCheckPurchasedItemCycleAlignmentOfferRequestFldKey,
                offerRequest)
        if offerResourceId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberCheckPurchasedItemCycleAlignmentOfferResourceIdFldKey,
                offerResourceId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberQueryThresholdRechargeDefn(self, queryType, queryValue, balanceResourceId=None,
                                             apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberQueryThresholdRechargeDefnMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestSubscriberQueryThresholdRechargeDefnSubscriberSearchDataFldKey, \
            search)
        if balanceResourceId is not None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberQueryThresholdRechargeDefnBalanceResourceIdFldKey, \
                balanceResourceId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberQueryTask(self, queryType, queryValue, queryCursor=None, querySize=None,
                            apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberQueryTaskMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestSubscriberQueryTaskSubscriberSearchDataFldKey, \
            search)
        if queryCursor != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberQueryTaskQueryCursorFldKey, queryCursor)
        if querySize != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberQueryTaskQuerySizeFldKey, querySize)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberMakeFinanceContractPrincipalPayment(self, queryType, queryValue, offerResourceId,
            isPayoff=True, extraPrincipalAmount=None, paymentMethodResourceId=None, chargeMethod=None,
            paymentGatewayId=None, paymentGatewayUserId=None, nonce=None, chargeMethodAttr=None,
            reason=None, info=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberFinanceContractPrincipalPaymentMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberFinanceContractPrincipalPaymentSubscriberSearchDataFldKey,
            search)

        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberFinanceContractPrincipalPaymentResourceIdFldKey,
            offerResourceId)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberFinanceContractPrincipalPaymentIsPayoffFldKey,
            isPayoff)

        if not isPayoff:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberFinanceContractPrincipalPaymentExtraPrincipalAmountFldKey,
                extraPrincipalAmount)

        if paymentMethodResourceId != None or chargeMethod != None or \
            paymentGatewayId != None or paymentGatewayUserId != None or nonce != None or \
            chargeMethodAttr != None:
            chargeMethodData = newChargeMethodData(paymentMethodResourceId,
                chargeMethod, paymentGatewayId, paymentGatewayUserId, nonce, chargeMethodAttr)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberFinanceContractPrincipalPaymentChargeMethodDataFldKey,
                chargeMethodData)

        if reason != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberFinanceContractPrincipalPaymentReasonFldKey,
                reason)

        if info != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberFinanceContractPrincipalPaymentInfoFldKey,
                info)

        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberContractDebtPayment(self, queryType, queryValue, offerResourceId,
            amount, paymentMethodResourceId=None, chargeMethod=None, paymentGatewayId=None,
            paymentGatewayUserId=None, nonce=None, chargeMethodAttr=None, reason=None,
            info=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberContractDebtPaymentMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberContractDebtPaymentSubscriberSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberContractDebtPaymentResourceIdFldKey,
            offerResourceId)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberContractDebtPaymentAmountFldKey,
            amount)

        if paymentMethodResourceId != None or chargeMethod != None or \
            paymentGatewayId != None or paymentGatewayUserId != None or \
            nonce != None or chargeMethodAttr != None:
            chargeMethodData = newChargeMethodData(paymentMethodResourceId,
                chargeMethod, paymentGatewayId, paymentGatewayUserId, nonce, chargeMethodAttr)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberContractDebtPaymentChargeMethodDataFldKey,
                chargeMethodData)

        if reason != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberContractDebtPaymentReasonFldKey,
                reason)
        if info != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberContractDebtPaymentInfoFldKey,
                info)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberQueryCatalogItemList(self, queryType, queryValue, eligibilityFilter=None,
                                       apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberQueryCatalogItemListMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberQueryCatalogItemListSubscriberSearchDataFldKey,
            search)

        if eligibilityFilter != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberQueryCatalogItemListEligibilityFilterFldKey,
                eligibilityFilter)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberQueryCatalog(self, queryType, queryValue, catalogQueryType, catalogQueryValue,
            eligibilityFilter=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberQueryCatalogMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestSubscriberQueryCatalogSubscriberSearchDataFldKey,\
            search)

        catalogSearch = newPricingCatalogSearch(catalogQueryType, catalogQueryValue)
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestSubscriberQueryCatalogCatalogSearchDataFldKey,\
            catalogSearch)

        if eligibilityFilter != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberQueryCatalogEligibilityFilterFldKey,\
                eligibilityFilter)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberAddBalanceExpiryRechargeDefn(self, queryType, queryValue, balanceResourceId,
            durationBeforeExpiryInMinutes, rechargeAmount, paymentMethodResourceId=None,
            notificationProfileId=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberAddBalanceExpiryRechargeDefnMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestSubscriberAddBalanceExpiryRechargeDefnSubscriberSearchDataFldKey, \
            search)
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestSubscriberAddBalanceExpiryRechargeDefnBalanceResourceIdFldKey, \
            balanceResourceId)
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestSubscriberAddBalanceExpiryRechargeDefnDurationBeforeExpiryInMinutesFldKey, \
            durationBeforeExpiryInMinutes)
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestSubscriberAddBalanceExpiryRechargeDefnRechargeAmountFldKey, \
            rechargeAmount)
        if paymentMethodResourceId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberAddBalanceExpiryRechargeDefnPaymentMethodResourceIdFldKey, \
                paymentMethodResourceId)
        if notificationProfileId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberAddBalanceExpiryRechargeDefnNotificationProfileIdFldKey, \
                notificationProfileId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberModifyBalanceExpiryRechargeDefn(self, queryType, queryValue, balanceResourceId,
            durationBeforeExpiryInMinutes=None, rechargeAmount=None, paymentMethodResourceId=None,
            notificationProfileId=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberModifyBalanceExpiryRechargeDefnMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberModifyBalanceExpiryRechargeDefnSubscriberSearchDataFldKey,
            search)
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestSubscriberModifyBalanceExpiryRechargeDefnBalanceResourceIdFldKey, \
            balanceResourceId)
        if durationBeforeExpiryInMinutes != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberModifyBalanceExpiryRechargeDefnDurationBeforeExpiryInMinutesFldKey, \
                durationBeforeExpiryInMinutes)
        if rechargeAmount != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberModifyBalanceExpiryRechargeDefnRechargeAmountFldKey, \
                rechargeAmount)
        if paymentMethodResourceId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberModifyBalanceExpiryRechargeDefnPaymentMethodResourceIdFldKey, \
                paymentMethodResourceId)
        if notificationProfileId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberModifyBalanceExpiryRechargeDefnNotificationProfileIdFldKey, \
                notificationProfileId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberRemoveBalanceExpiryRechargeDefn(self, queryType, queryValue, balanceResourceId,
            apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberRemoveBalanceExpiryRechargeDefnMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberRemoveBalanceExpiryRechargeDefnSubscriberSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberRemoveBalanceExpiryRechargeDefnBalanceResourceIdFldKey,
            balanceResourceId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberQueryBalanceExpiryRechargeDefn(self, queryType, queryValue, balanceResourceId=None,
                                                 apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberQueryBalanceExpiryRechargeDefnMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestSubscriberQueryBalanceExpiryRechargeDefnSubscriberSearchDataFldKey, \
            search)
        if balanceResourceId is not None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriberQueryBalanceExpiryRechargeDefnBalanceResourceIdFldKey, \
                balanceResourceId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberActivateOffer(self, queryType, queryValue, resourceId, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberActivateOfferMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberActivateOfferSubscriberSearchDataFldKey, \
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberActivateOfferResourceIdFldKey, \
            resourceId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberModifyExternalPayment(self, queryType, queryValue, resourceId,
            reason, opType=None, amount=None, info=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberModifyExternalPaymentMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberModifyExternalPaymentSubscriberSearchDataFldKey,
            search)

        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberModifyExternalPaymentResourceIdFldKey,
            resourceId)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberModifyExternalPaymentReasonFldKey,
            reason)
        if opType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyExternalPaymentOpTypeFldKey,
                opType)
        if amount != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyExternalPaymentAmountFldKey,
                amount)
        if info != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyExternalPaymentInfoFldKey,
                info)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberQueryExternalPayment(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberQueryExternalPaymentMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberQueryExternalPaymentSubscriberSearchDataFldKey, \
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberQueryOneTimeOffer(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberQueryOneTimeOfferMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberQueryOneTimeOfferSubscriberSearchDataFldKey, \
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberSuspendOffer(self, queryType, queryValue, resourceId,
        scheduledSuspendTime=None, autoResumeRelativeOffset=None,
        autoResumeRelativeOffsetUnit=None, autoResumeTime=None, isPauseMode=None,
        grantSuspendProrationType=None, chargeSuspendProrationType=None,
        grantResumeProrationType=None, chargeResumeProrationType=None,
        apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberSuspendOfferMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberSuspendOfferSubscriberSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberSuspendOfferResourceIdFldKey,
            resourceId)
        if scheduledSuspendTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberSuspendOfferScheduledSuspendTimeFldKey,
                scheduledSuspendTime)
        if autoResumeRelativeOffset != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberSuspendOfferAutoResumeRelativeOffsetFldKey,
                autoResumeRelativeOffset)
        if autoResumeRelativeOffsetUnit != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberSuspendOfferAutoResumeRelativeOffsetUnitFldKey,
                autoResumeRelativeOffsetUnit)
        if autoResumeTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberSuspendOfferAutoResumeTimeFldKey,
                autoResumeTime)
        if isPauseMode != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberSuspendOfferIsPauseModeFldKey,
                isPauseMode)
        if grantSuspendProrationType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberSuspendOfferGrantSuspendProrationTypeFldKey,
                grantSuspendProrationType)
        if chargeSuspendProrationType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberSuspendOfferChargeSuspendProrationTypeFldKey,
                chargeSuspendProrationType)
        if grantResumeProrationType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberSuspendOfferGrantResumeProrationTypeFldKey,
                grantResumeProrationType)
        if chargeResumeProrationType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberSuspendOfferChargeResumeProrationTypeFldKey,
                chargeResumeProrationType)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberResumeOffer(self, queryType, queryValue, resourceId,
        scheduledResumeTime=None, resumeRelativeOffset=None,
        resumeRelativeOffsetUnit=None, grantResumeProrationType=None,
        chargeResumeProrationType=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberResumeOfferMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberResumeOfferSubscriberSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberResumeOfferResourceIdFldKey,
            resourceId)
        if scheduledResumeTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberResumeOfferScheduledResumeTimeFldKey,
                scheduledResumeTime)
        if resumeRelativeOffset != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberResumeOfferResumeRelativeOffsetFldKey,
                resumeRelativeOffset)
        if resumeRelativeOffsetUnit != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberResumeOfferResumeRelativeOffsetUnitFldKey,
                resumeRelativeOffsetUnit)
        if grantResumeProrationType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberResumeOfferGrantResumeProrationTypeFldKey,
                grantResumeProrationType)
        if chargeResumeProrationType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberResumeOfferChargeResumeProrationTypeFldKey,
                chargeResumeProrationType)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberRemoveScheduledStatusChange(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberRemoveScheduledStatusChangeMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberRemoveScheduledStatusChangeSubscriberSearchDataFldKey,
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberRemoveScheduledOfferStatusChange(self, queryType, queryValue, resourceId,
        apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberRemoveScheduledOfferStatusChangeMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberRemoveScheduledOfferStatusChangeSubscriberSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberRemoveScheduledOfferStatusChangeResourceIdFldKey,
            resourceId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberModifyStatus(self, queryType, queryValue, statusValue,
        statusTransitionTime=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberModifyStatusMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberModifyStatusSubscriberSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberModifyStatusStatusValueFldKey,
            statusValue)
        if statusTransitionTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriberModifyStatusScheduledStatusTransitionTimeFldKey,
                statusTransitionTime)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def deviceCreate(self, attr, externalId=None,
            status=None, deviceType=None, now=None, routingType=None,
            apiEventData=None, routingValue=None, tenantId=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceCreateMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestDeviceCreateAttrFldKey, \
            attr)
        if externalId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestDeviceCreateExternalIdFldKey, externalId)
        if status != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestDeviceCreateStatusFldKey, status)
        if deviceType != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestDeviceCreateDeviceTypeFldKey, deviceType)
        if tenantId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceCreateTenantIdFldKey, tenantId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def deviceCreateMobile(self, imsi, externalId=None,
            status=None, deviceType=None, attr=None,
            accessNumbers=None, now=None, routingType=None,
            routingValue=None, tenantId=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceCreateMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if externalId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestDeviceCreateExternalIdFldKey, externalId)
        if status != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestDeviceCreateStatusFldKey, status)
        if deviceType != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestDeviceCreateDeviceTypeFldKey, deviceType)
        if not attr:
            attr = MDCDEFS.kMtxMobileDeviceExtensionMdcDesc.create()

        if tenantId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceCreateTenantIdFldKey, tenantId)

        # Attr MUST be derived from MtxMobileDeviceExtension. This will fail
        # if this is not the case.
        attr.setUsingKey( \
            MDCDEFS.kMtxMobileDeviceExtensionImsiFldKey, imsi)
        if accessNumbers:
            attr.setUsingKey( \
                MDCDEFS.kMtxMobileDeviceExtensionAccessNumberArrayFldKey, accessNumbers)

        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestDeviceCreateAttrFldKey, attr)

        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def deviceCreateLogin(self, loginId, externalId=None,
            status=None, deviceType=None, attr=None, accessIds=None,
            now=None, routingType=None, routingValue=None, tenantId=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceCreateMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if externalId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestDeviceCreateExternalIdFldKey, externalId)
        if status != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestDeviceCreateStatusFldKey, status)
        if deviceType != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestDeviceCreateDeviceTypeFldKey, deviceType)
        if not attr:
            attr = MDCDEFS.kMtxLoginDeviceExtensionMdcDesc.create()

        # Attr MUST be derived from MtxLoginDeviceExtension. This will fail
        # if this is not the case.
        attr.setUsingKey( \
            MDCDEFS.kMtxLoginDeviceExtensionLoginIdFldKey, loginId)
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestDeviceCreateAttrFldKey, attr)
        if accessIds != None:
            attr.setUsingKey( \
                MDCDEFS.kMtxLoginDeviceExtensionAccessIdArrayFldKey, accessIds)

        if tenantId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceCreateTenantIdFldKey, tenantId)

        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def deviceQuery(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceQueryMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newDeviceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceQueryDeviceSearchDataFldKey, \
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def deviceModify(self, queryType, queryValue, deviceType=None,
            status=None, attr=None, now=None, externalId=None,
            lastActivityUpdateTime=None, imsi=None, loginId=None,
            tenantId=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceModifyMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newDeviceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceModifyDeviceSearchDataFldKey, \
            search)
        if status != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestDeviceModifyStatusFldKey, status)
        if deviceType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceModifyDeviceTypeFldKey, deviceType)
        if attr != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestDeviceModifyAttrFldKey, \
                attr)
        if externalId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestDeviceModifyExternalIdFldKey, externalId)
        if lastActivityUpdateTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceModifyLastActivityUpdateTimeFldKey, lastActivityUpdateTime)
        if imsi != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceModifyImsiFldKey, imsi)
        if loginId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceModifyLoginIdFldKey, loginId)
        if tenantId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceModifyTenantIdFldKey, tenantId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def deviceDelete(self, queryType, queryValue, deleteSession=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceDeleteMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newDeviceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceDeleteDeviceSearchDataFldKey, \
            search)
        if deleteSession != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestDeviceDeleteDeleteSessionFldKey, deleteSession)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def deviceQueryAggregation(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceQueryAggregationMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newDeviceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceQueryAggregationDeviceSearchDataFldKey, \
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def deviceEndAggregation(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceEndAggregationMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newDeviceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceEndAggregationDeviceSearchDataFldKey, \
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def deviceQueryEvent(self, queryType, queryValue,
            queryCursor=None, querySize=None,
            eventTimeLowerBound=None, eventTimeUpperBound=None,
            eventTypeStringArray=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceQueryEventMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        devSearch = newDeviceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceQueryEventDeviceSearchDataFldKey, \
            devSearch)
        if queryCursor != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceQueryEventQueryCursorFldKey, queryCursor)
        if querySize != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceQueryEventQuerySizeFldKey, querySize)
        if eventTimeLowerBound != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceQueryEventEventTimeLowerBoundFldKey, eventTimeLowerBound)
        if eventTimeUpperBound != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceQueryEventEventTimeUpperBoundFldKey, eventTimeUpperBound)
        if eventTypeStringArray != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceQueryEventEventTypeArrayFldKey, eventTypeStringArray)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, devSearch)
        return responseMdc

    def devicePurchaseOffer(self, queryType, queryValue, offerList,
            paymentMethodResourceId=None, chargeMethod=None,
            paymentGatewayId=None, paymentGatewayUserId=None, nonce=None,
            chargeMethodAttr=None, deferredSettlement=False,
            deferredSettlementTimeout=None, deferredSettlementTimeoutAction=None,
            eligibilityCheck=None, apiEventData=None, now=None, geoData=None):
        requestMdc = MDCDEFS.kMtxRequestDevicePurchaseOfferMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newDeviceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDevicePurchaseOfferDeviceSearchDataFldKey,
            search)

        offerArray = newOfferPurchaseArray(offerList)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDevicePurchaseOfferOfferRequestArrayFldKey,
            offerArray)

        if paymentMethodResourceId != None or chargeMethod != None or \
            paymentGatewayId != None or paymentGatewayUserId != None or \
            nonce != None or chargeMethodAttr != None or \
            deferredSettlement:
            chargeMethodData = newChargeMethodData(paymentMethodResourceId,
                chargeMethod, paymentGatewayId, paymentGatewayUserId, nonce, chargeMethodAttr,
                deferredSettlement, deferredSettlementTimeout, deferredSettlementTimeoutAction)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDevicePurchaseOfferChargeMethodDataFldKey,
                chargeMethodData)

        if eligibilityCheck != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDevicePurchaseOfferEligibilityCheckFldKey,
                eligibilityCheck)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        if geoData is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDevicePurchaseOfferOneTimeTaxGeoDataFldKey, geoData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def deviceCancelOffer(self, queryType, queryValue, resourceIdList=None, now=None,
                          cancelOfferDataList=None, eligibilityCheck=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceCancelOfferMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newDeviceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceCancelOfferDeviceSearchDataFldKey,
            search)

        if (resourceIdList != None):
            resourceIdArray = []
            for resourceId in resourceIdList:
                resourceIdArray.append(resourceId)

            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceCancelOfferResourceIdArrayFldKey,
                resourceIdArray)
        if (cancelOfferDataList != None):
            cancelOfferDataArray = newCancelOfferDataArray(cancelOfferDataList)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceCancelOfferCancelDataArrayFldKey,
                cancelOfferDataArray)
        if (resourceIdList is None and cancelOfferDataList is None):
            raise RuntimeError('Either ResourceIdArray or CancelOfferDataArray must be specified')

        if eligibilityCheck != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceCancelOfferEligibilityCheckFldKey,
                eligibilityCheck)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def deviceModifyOffer(self, queryType, queryValue, resourceId, now=None,
            startTime=None, endTime=None, attr=None, cycleType=None,
            cycleResourceId=None, cycleOffset=None, cycleAlignmentDisabled=None,
            immediateChange=None, cycleOwnerType=None, status=None,
            offerStatusValue=None, cycleStartTime=None, cycleEndTime=None,
            parameterList=None, apiEventData=None, isRecurringFailureAllowed=None,
            endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceModifyOfferMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newDeviceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceModifyOfferDeviceSearchDataFldKey, \
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceModifyOfferResourceIdFldKey, \
            resourceId)

        if startTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceModifyOfferStartTimeFldKey, startTime)
        if endTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceModifyOfferEndTimeFldKey, endTime)
        if endTimeExtensionOffsetUnit != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceModifyOfferEndTimeExtensionOffsetUnitFldKey, endTimeExtensionOffsetUnit)
        if endTimeExtensionOffset != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceModifyOfferEndTimeExtensionOffsetFldKey, endTimeExtensionOffset)
        if attr != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestDeviceModifyOfferAttrFldKey, \
                attr)

        # Create and set CycleData if any of the cycle parameters are included
        if cycleOffset or cycleType or cycleResourceId or cycleOwnerType \
                or cycleAlignmentDisabled or immediateChange or cycleStartTime \
                or cycleEndTime:
            cycleData = MDCDEFS.kMtxPurchasedItemCycleDataMdcDesc.create()
            if cycleType != None:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataCycleTypeFldKey,
                    cycleType)
            if cycleResourceId != None:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataCycleResourceIdFldKey,
                    cycleResourceId)
            if cycleOffset != None:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataCycleOffsetFldKey,
                    cycleOffset)
            if cycleOwnerType != None:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataCycleOwnerTypeFldKey,
                    cycleOwnerType)
            if cycleAlignmentDisabled != None:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataCycleAlignmentDisabledFldKey,
                    cycleAlignmentDisabled)
            if immediateChange != None:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataImmediateChangeFldKey,
                    immediateChange)
            if cycleStartTime != None:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataCycleStartTimeFldKey,
                    cycleStartTime)
            if cycleEndTime != None:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataCycleEndTimeFldKey,
                    cycleEndTime)
            if isRecurringFailureAllowed != None:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataIsRecurringFailureAllowedFldKey,
                    isRecurringFailureAllowed)
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestDeviceModifyOfferCycleDataFldKey, cycleData)
        # Status:
        if status != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestDeviceModifyOfferStatusFldKey, \
                status)
        # OfferStatusValue:
        if offerStatusValue != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestDeviceModifyOfferOfferStatusValueFldKey, \
                offerStatusValue)
        # parameterLIst
        if parameterList != None:
            parameterArray = newParameterDataArray(parameterList)
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestDeviceModifyOfferParameterArrayFldKey, parameterArray)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def deviceEvaluateSyPolicy(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceEvaluatePolicyCounterSetMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newDeviceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceEvaluatePolicyCounterSetDeviceSearchDataFldKey, \
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def deviceQuerySession(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceQuerySessionMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newDeviceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceQuerySessionDeviceSearchDataFldKey, \
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def deviceValidateSession(self, queryType, queryValue, sessionId=None, sessionType=None,
                              apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceValidateSessionMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newDeviceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceValidateSessionDeviceSearchDataFldKey, \
            search)
        if sessionId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceValidateSessionSessionIdFldKey, \
                sessionId)
        if sessionType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceValidateSessionSessionTypeFldKey, \
                sessionType)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def deviceDeleteSession(self, queryType, queryValue, sessionIdList=None, sessionType=None,
                            apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceDeleteSessionMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newDeviceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceDeleteSessionDeviceSearchDataFldKey, \
            search)
        if sessionIdList != None:
            sessionIdArray = []
            for sessionId in sessionIdList:
                sessionIdArray.append(sessionId)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceDeleteSessionSessionIdListFldKey, \
                sessionIdArray)
        if sessionType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceDeleteSessionSessionTypeFldKey, \
                sessionType)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def deviceCheckPurchasedItemCycleAlignment(self, queryType, queryValue, offerRequest=None,
            offerResourceId=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceCheckPurchasedItemCycleAlignmentMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newDeviceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceCheckPurchasedItemCycleAlignmentDeviceSearchDataFldKey,
            search)

        if offerRequest != None:
            offerRequest = newOfferPurchaseArray([offerRequest])[0]
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceCheckPurchasedItemCycleAlignmentOfferRequestFldKey,
                offerRequest)
        if offerResourceId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceCheckPurchasedItemCycleAlignmentOfferResourceIdFldKey,
                offerResourceId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def deviceContractDebtPayment(self, queryType, queryValue, offerResourceId,
            amount, paymentMethodResourceId=None, chargeMethod=None, paymentGatewayId=None,
            paymentGatewayUserId=None, nonce=None, chargeMethodAttr=None, reason=None,
            info=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceContractDebtPaymentMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newDeviceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceContractDebtPaymentDeviceSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceContractDebtPaymentResourceIdFldKey,
            offerResourceId)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceContractDebtPaymentAmountFldKey,
            amount)

        if paymentMethodResourceId != None or chargeMethod != None or \
            paymentGatewayId != None or paymentGatewayUserId != None or \
            nonce != None or chargeMethodAttr != None:
            chargeMethodData = newChargeMethodData(paymentMethodResourceId,
                chargeMethod, paymentGatewayId, paymentGatewayUserId,
                nonce, chargeMethodAttr)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceContractDebtPaymentChargeMethodDataFldKey,
                chargeMethodData)

        if reason != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceContractDebtPaymentReasonFldKey,
                reason)
        if info != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceContractDebtPaymentInfoFldKey,
                info)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def deviceQueryCatalogItemList(self, queryType, queryValue, eligibilityFilter=None,
                                   apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceQueryCatalogItemListMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newDeviceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceQueryCatalogItemListDeviceSearchDataFldKey,
            search)

        if eligibilityFilter != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceQueryCatalogItemListEligibilityFilterFldKey,
                eligibilityFilter)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def deviceQueryCatalog(self, queryType, queryValue, catalogQueryType, catalogQueryValue,
            eligibilityFilter=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceQueryCatalogMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newDeviceSearch(queryType, queryValue)
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestDeviceQueryCatalogDeviceSearchDataFldKey,\
            search)

        catalogSearch = newPricingCatalogSearch(catalogQueryType, catalogQueryValue)
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestDeviceQueryCatalogCatalogSearchDataFldKey,\
            catalogSearch)

        if eligibilityFilter != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestDeviceQueryCatalogEligibilityFilterFldKey,\
                eligibilityFilter)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def deviceActivateOffer(self, queryType, queryValue, resourceId, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceActivateOfferMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newDeviceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceActivateOfferDeviceSearchDataFldKey, \
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceActivateOfferResourceIdFldKey, \
            resourceId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def deviceQueryOneTimeOffer(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceQueryOneTimeOfferMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newDeviceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceQueryOneTimeOfferDeviceSearchDataFldKey, \
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def deviceSuspendOffer(self, queryType, queryValue, resourceId,
        scheduledSuspendTime=None, autoResumeRelativeOffset=None,
        autoResumeRelativeOffsetUnit=None, autoResumeTime=None, isPauseMode=None,
        grantSuspendProrationType=None, chargeSuspendProrationType=None,
        grantResumeProrationType=None, chargeResumeProrationType=None,
        apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceSuspendOfferMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newDeviceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceSuspendOfferDeviceSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceSuspendOfferResourceIdFldKey,
            resourceId)
        if scheduledSuspendTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceSuspendOfferScheduledSuspendTimeFldKey,
                scheduledSuspendTime)
        if autoResumeRelativeOffset != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceSuspendOfferAutoResumeRelativeOffsetFldKey,
                autoResumeRelativeOffset)
        if autoResumeRelativeOffsetUnit != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceSuspendOfferAutoResumeRelativeOffsetUnitFldKey,
                autoResumeRelativeOffsetUnit)
        if autoResumeTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceSuspendOfferAutoResumeTimeFldKey,
                autoResumeTime)
        if isPauseMode != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceSuspendOfferIsPauseModeFldKey,
                isPauseMode)
        if grantSuspendProrationType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceSuspendOfferGrantSuspendProrationTypeFldKey,
                grantSuspendProrationType)
        if chargeSuspendProrationType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceSuspendOfferChargeSuspendProrationTypeFldKey,
                chargeSuspendProrationType)
        if grantResumeProrationType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceSuspendOfferGrantResumeProrationTypeFldKey,
                grantResumeProrationType)
        if chargeResumeProrationType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceSuspendOfferChargeResumeProrationTypeFldKey,
                chargeResumeProrationType)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def deviceResumeOffer(self, queryType, queryValue, resourceId,
        scheduledResumeTime=None, resumeRelativeOffset=None,
        resumeRelativeOffsetUnit=None, grantResumeProrationType=None,
        chargeResumeProrationType=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceResumeOfferMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newDeviceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceResumeOfferDeviceSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceResumeOfferResourceIdFldKey,
            resourceId)
        if scheduledResumeTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceResumeOfferScheduledResumeTimeFldKey,
                scheduledResumeTime)
        if resumeRelativeOffset != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceResumeOfferResumeRelativeOffsetFldKey,
                resumeRelativeOffset)
        if resumeRelativeOffsetUnit != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceResumeOfferResumeRelativeOffsetUnitFldKey,
                resumeRelativeOffsetUnit)
        if grantResumeProrationType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceResumeOfferGrantResumeProrationTypeFldKey,
                grantResumeProrationType)
        if chargeResumeProrationType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceResumeOfferChargeResumeProrationTypeFldKey,
                chargeResumeProrationType)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def deviceModifyStatus(self, queryType, queryValue, statusValue,
        statusTransitionTime=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceModifyStatusMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newDeviceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceModifyStatusDeviceSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceModifyStatusStatusValueFldKey,
            statusValue)
        if statusTransitionTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDeviceModifyStatusScheduledStatusTransitionTimeFldKey,
                statusTransitionTime)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def deviceRemoveScheduledStatusChange(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceRemoveScheduledStatusChangeMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newDeviceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceRemoveScheduledStatusChangeDeviceSearchDataFldKey,
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def deviceRemoveScheduledOfferStatusChange(self, queryType, queryValue, resourceId,
        apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceRemoveScheduledOfferStatusChangeMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newDeviceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceRemoveScheduledOfferStatusChangeDeviceSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceRemoveScheduledOfferStatusChangeResourceIdFldKey,
            resourceId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupCreate(self, externalId=None, groupName=None,
            tier=None, adminSearchArray=None, billingCycle=None,
            attr=None, now=None, timeZone=None, status=None, notificationPreference=None,
            groupReAuthPreference=None, taxStatus=None, taxCertificate=None,
            taxLocation=None, glCenter=None, routingType=None, routingValue=None,
            apiEventData=None,
            customerType=None, serviceAddress=None,
            npa=None, nxx=None, tenantId=None, exemptionCodeList=None):
        requestMdc = MDCDEFS.kMtxRequestGroupCreateMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if externalId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupCreateExternalIdFldKey, externalId)
        if groupName != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupCreateNameFldKey, groupName)
        if tier != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupCreateTierFldKey, tier)
        if adminSearchArray != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupCreateAdminArrayFldKey, \
                adminSearchArray)
        if billingCycle != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupCreateBillingCycleFldKey, billingCycle)
        if attr != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupCreateAttrFldKey, \
                attr)
        if taxStatus != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupCreateTaxStatusFldKey, taxStatus)
        if taxCertificate != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupCreateTaxCertificateFldKey, taxCertificate)
        if taxLocation != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupCreateTaxLocationFldKey, taxLocation)
        if timeZone != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupCreateTimeZoneFldKey, timeZone)
        if status != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupCreateStatusFldKey, status)
        if notificationPreference != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupCreateNotificationPreferenceFldKey, notificationPreference)
        if groupReAuthPreference != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupCreateGroupReAuthPreferenceFldKey, groupReAuthPreference)
        if glCenter != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupCreateGlCenterFldKey, glCenter)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        if customerType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupCreateCustomerTypeFldKey, customerType)
        if npa != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupCreateNpaFldKey, npa)
        if nxx != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupCreateNxxFldKey, nxx)
        if tenantId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupCreateTenantIdFldKey, tenantId)
        if serviceAddress != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupCreateServiceAddressFldKey, serviceAddress)
        if exemptionCodeList != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupCreateExemptionCodeListFldKey, exemptionCodeList)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def groupQuery(self, queryType, queryValue, querySize=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupQueryMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupQueryGroupSearchDataFldKey, \
            search)
        if querySize != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupQueryQuerySizeFldKey, querySize)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupQueryWallet(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupQueryWalletMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupQueryWalletGroupSearchDataFldKey, \
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupQueryMembership(self, queryType, queryValue, membershipType,
            queryCursor=None, querySize=None, returnExternalId=False, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupQueryMembershipMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupQueryMembershipGroupSearchDataFldKey, \
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupQueryMembershipMembershipTypeFldKey, membershipType)
        if queryCursor != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupQueryMembershipQueryCursorFldKey, queryCursor)
        if querySize != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupQueryMembershipQuerySizeFldKey, querySize)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupQueryMembershipReturnExternalIdFldKey, returnExternalId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupQueryEvent(self, queryType, queryValue, queryCursor=None, querySize=None,
            eventTimeLowerBound=None, eventTimeUpperBound=None,
            eventTypeStringArray=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupQueryEventMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupQueryEventGroupSearchDataFldKey, \
            search)
        if queryCursor != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupQueryEventQueryCursorFldKey, queryCursor)
        if querySize != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupQueryEventQuerySizeFldKey, querySize)
        if eventTimeLowerBound != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupQueryEventEventTimeLowerBoundFldKey, eventTimeLowerBound)
        if eventTimeUpperBound != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupQueryEventEventTimeUpperBoundFldKey, eventTimeUpperBound)
        if eventTypeStringArray != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupQueryEventEventTypeArrayFldKey, eventTypeStringArray)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupModify(self, queryType, queryValue, groupName=None, tier=None,
            attr=None, billingCycle=None, now=None, externalId=None, timeZone=None,
            status=None, notificationPreference=None, groupReAuthPreference=None,
            taxStatus=None, taxCertificate=None, taxLocation=None, glCenter=None,
            paymentGatewayUserId=None, currentPaymentTokenResourceId=None,
            lastActivityUpdateTime=None, billingCycleDisabled=None,
            sysPaymentTokenResourceId=None, apiEventData=None, maxSubscriberCount=None,
            maxUserCount=None,
            customerType=None, serviceAddress=None,
            npa=None, nxx=None, tenantId=None, exemptionCodeList=None):
        requestMdc = MDCDEFS.kMtxRequestGroupModifyMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupModifyGroupSearchDataFldKey, \
            search)
        if groupName != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyNameFldKey, groupName)
        if tier != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyTierFldKey, tier)
        if billingCycle != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyBillingCycleFldKey, billingCycle)
        if attr != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupModifyAttrFldKey, \
                attr)
        if taxStatus != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyTaxStatusFldKey, taxStatus)
        if taxCertificate != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyTaxCertificateFldKey, taxCertificate)
        if taxLocation != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyTaxLocationFldKey, taxLocation)
        if externalId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyExternalIdFldKey, externalId)
        if timeZone != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyTimeZoneFldKey, timeZone)
        if status != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyStatusFldKey, status)
        if notificationPreference != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyNotificationPreferenceFldKey, notificationPreference)
        if groupReAuthPreference != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyGroupReAuthPreferenceFldKey, groupReAuthPreference)
        if glCenter != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyGlCenterFldKey, glCenter)
        if paymentGatewayUserId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyPaymentGatewayUserIdFldKey, paymentGatewayUserId)
        if currentPaymentTokenResourceId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyCurrentPaymentTokenResourceIdFldKey, currentPaymentTokenResourceId)
        if lastActivityUpdateTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyLastActivityUpdateTimeFldKey, lastActivityUpdateTime)
        if billingCycleDisabled != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyBillingCycleDisabledFldKey, billingCycleDisabled)
        if sysPaymentTokenResourceId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifySysPaymentTokenResourceIdFldKey, sysPaymentTokenResourceId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        if maxSubscriberCount != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyMaxSubscriberCountFldKey,
                maxSubscriberCount)
        if maxUserCount != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyMaxUserCountFldKey,
                maxUserCount)
        if customerType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyCustomerTypeFldKey, customerType)
        if npa != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyNpaFldKey, npa)
        if nxx != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyNxxFldKey, nxx)
        if tenantId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyTenantIdFldKey, tenantId)
        if serviceAddress != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyServiceAddressFldKey, serviceAddress)
        if exemptionCodeList != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyExemptionCodeListFldKey, exemptionCodeList)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupDelete(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupDeleteMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupDeleteGroupSearchDataFldKey, \
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupAddMembership(self, queryType, queryValue,
            subscriberSearchArray=None, subGroupSearchArray=None,
            adminSearchArray=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupAddMembershipMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupAddMembershipGroupSearchDataFldKey, \
            search)
        if subscriberSearchArray != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAddMembershipSubscriberArrayFldKey, \
                subscriberSearchArray)
        if subGroupSearchArray != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAddMembershipGroupArrayFldKey, \
                subGroupSearchArray)
        if adminSearchArray != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAddMembershipAdminArrayFldKey, \
                adminSearchArray)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupRemoveMembership(self, queryType, queryValue,
            subscriberSearchArray=None, subGroupSearchArray=None,
            adminSearchArray=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupRemoveMembershipMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupRemoveMembershipGroupSearchDataFldKey, \
            search)
        if subscriberSearchArray != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupRemoveMembershipSubscriberArrayFldKey, \
                subscriberSearchArray)
        if subGroupSearchArray != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupRemoveMembershipGroupArrayFldKey, \
                subGroupSearchArray)
        if adminSearchArray != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupRemoveMembershipAdminArrayFldKey, \
                adminSearchArray)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupAddUser(self, grpQueryType, grpQueryValue,
            userQueryType, userQueryValue, roles=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupAddUserMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        grpSearch = newGroupSearch(grpQueryType, grpQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupAddUserGroupSearchDataFldKey, \
            grpSearch)
        userSearch = newUserSearch(userQueryType, userQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupAddUserUserSearchDataFldKey, \
            userSearch)
        if roles != None:
            roleDataArray = newRoleDataArray(roles)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAddUserRoleArrayFldKey, roleDataArray)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, grpSearch)
        return responseMdc

    def groupModifyUser(self, grpQueryType, grpQueryValue, userQueryType, userQueryValue,
            roles=None, removeExplicitMembership=False, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupModifyUserMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        grpSearch = newGroupSearch(grpQueryType, grpQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupModifyUserGroupSearchDataFldKey, \
            grpSearch)
        userSearch = newUserSearch(userQueryType, userQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupModifyUserUserSearchDataFldKey, \
            userSearch)
        if roles != None:
            roleDataArray = newRoleDataArray(roles)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyUserRoleArrayFldKey, roleDataArray)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupModifyUserRemoveExplicitMembershipFldKey, \
            removeExplicitMembership)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, grpSearch)
        return responseMdc

    def groupRemoveUser(self, grpQueryType, grpQueryValue, userQueryType, userQueryValue,
            removeExplicitMembership=False, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupRemoveUserMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        grpSearch = newGroupSearch(grpQueryType, grpQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupRemoveUserGroupSearchDataFldKey, \
            grpSearch)
        userSearch = newUserSearch(userQueryType, userQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupRemoveUserUserSearchDataFldKey, \
            userSearch)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupRemoveUserRemoveExplicitMembershipFldKey, \
            removeExplicitMembership)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, grpSearch)
        return responseMdc

    def groupPurchaseOffer(self, queryType, queryValue, offerList,
            paymentMethodResourceId=None, chargeMethod=None,
            paymentGatewayId=None, paymentGatewayUserId=None, nonce=None,
            chargeMethodAttr=None, deferredSettlement=False,
            deferredSettlementTimeout=None, deferredSettlementTimeoutAction=None,
            eligibilityCheck=None, apiEventData=None, now=None, geoData=None):
        requestMdc = MDCDEFS.kMtxRequestGroupPurchaseOfferMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupPurchaseOfferGroupSearchDataFldKey,
            search)

        offerArray = newOfferPurchaseArray(offerList)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupPurchaseOfferOfferRequestArrayFldKey,
            offerArray)

        if paymentMethodResourceId != None or chargeMethod != None or \
            paymentGatewayId != None or paymentGatewayUserId != None or \
            nonce != None or chargeMethodAttr != None or \
            deferredSettlement:
            chargeMethodData = newChargeMethodData(paymentMethodResourceId,
                chargeMethod, paymentGatewayId, paymentGatewayUserId, nonce, chargeMethodAttr,
                deferredSettlement, deferredSettlementTimeout, deferredSettlementTimeoutAction)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupPurchaseOfferChargeMethodDataFldKey,
                chargeMethodData)

        if eligibilityCheck != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupPurchaseOfferEligibilityCheckFldKey,
                eligibilityCheck)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        if geoData is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupPurchaseOfferOneTimeTaxGeoDataFldKey, geoData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupCancelOffer(self, queryType, queryValue, resourceIdList=None, now=None,
                         cancelOfferDataList=None, eligibilityCheck=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestGroupCancelOfferMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupCancelOfferGroupSearchDataFldKey,
            search)

        if (resourceIdList != None):
            resourceIdArray = []
            for resourceId in resourceIdList:
                resourceIdArray.append(resourceId)

            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupCancelOfferResourceIdArrayFldKey,
                resourceIdArray)
        if (cancelOfferDataList != None):
            cancelOfferDataArray = newCancelOfferDataArray(cancelOfferDataList)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupCancelOfferCancelDataArrayFldKey,
                cancelOfferDataArray)
        if (resourceIdList is None and cancelOfferDataList is None):
            raise RuntimeError('Either ResourceIdArray or CancelOfferDataArray must be specified')

        if eligibilityCheck != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupCancelOfferEligibilityCheckFldKey,
                eligibilityCheck)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupModifyOffer(self, queryType, queryValue, resourceId, now=None,
            startTime=None, endTime=None, attr=None, cycleType=None,
            cycleResourceId=None, cycleOffset=None,
            cycleAlignmentDisabled=None, immediateChange=None, status=None,
            offerStatusValue=None, cycleStartTime=None, cycleEndTime=None,
            parameterList=None, apiEventData=None, isRecurringFailureAllowed=None,
            endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None):
        requestMdc = MDCDEFS.kMtxRequestGroupModifyOfferMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupModifyOfferGroupSearchDataFldKey, \
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupModifyOfferResourceIdFldKey, \
            resourceId)

        if startTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyOfferStartTimeFldKey, startTime)
        if endTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyOfferEndTimeFldKey, endTime)
        if endTimeExtensionOffsetUnit != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyOfferEndTimeExtensionOffsetUnitFldKey, endTimeExtensionOffsetUnit)
        if endTimeExtensionOffset != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyOfferEndTimeExtensionOffsetFldKey, endTimeExtensionOffset)
        if attr != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupModifyOfferAttrFldKey, \
                attr)

        # Create and set CycleData if any of the cycle parameters are included
        if cycleOffset or cycleType or cycleResourceId or cycleAlignmentDisabled or immediateChange \
                or cycleStartTime or cycleEndTime:
            cycleData = MDCDEFS.kMtxPurchasedItemCycleDataMdcDesc.create()
            if cycleType != None:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataCycleTypeFldKey,
                    cycleType)
            if cycleResourceId != None:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataCycleResourceIdFldKey,
                    cycleResourceId)
            if cycleOffset != None:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataCycleOffsetFldKey,
                    cycleOffset)
            if cycleAlignmentDisabled != None:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataCycleAlignmentDisabledFldKey,
                    cycleAlignmentDisabled)
            if immediateChange != None:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataImmediateChangeFldKey,
                    immediateChange)
            if cycleStartTime != None:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataCycleStartTimeFldKey,
                    cycleStartTime)
            if cycleEndTime != None:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataCycleEndTimeFldKey,
                    cycleEndTime)
            if isRecurringFailureAllowed != None:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataIsRecurringFailureAllowedFldKey,
                    isRecurringFailureAllowed)
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestGroupModifyOfferCycleDataFldKey, cycleData)
        # Status:
        if status != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupModifyOfferStatusFldKey, \
                status)
        # OfferStatusValue:
        if offerStatusValue != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupModifyOfferOfferStatusValueFldKey, \
                offerStatusValue)
        # parameterLIst
        if parameterList != None:
            parameterArray = newParameterDataArray(parameterList)
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestGroupModifyOfferParameterArrayFldKey, parameterArray)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupAddThreshold(self, queryType, queryValue, resourceId,
            thresholdId, thresholdAmount, thresholdName=None,
            thresholdNotification=None, recurringStart=None,
            recurringStop=None, virtualCreditLimitIsPercent=None,
            rechargeAmount=None, rechargePaymentMethodResourceId=None,
            isTemporaryCreditLimit=False, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupAddThresholdMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupAddThresholdGroupSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupAddThresholdBalanceResourceIdFldKey,
            resourceId)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupAddThresholdThresholdThresholdIdFldKey,
            thresholdId)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupAddThresholdThresholdAmountFldKey,
            thresholdAmount)
        if thresholdName != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAddThresholdThresholdNameFldKey,
                thresholdName)
        if thresholdNotification != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAddThresholdThresholdNotificationStateFldKey,
                thresholdNotification)
        if recurringStart != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAddThresholdThresholdRecurringStartFldKey, recurringStart)
        if recurringStop != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAddThresholdThresholdRecurringStopFldKey, recurringStop)
        if virtualCreditLimitIsPercent != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAddThresholdThresholdVirtualCreditLimitIsPctFldKey,
                virtualCreditLimitIsPercent)
        if rechargeAmount != None or rechargePaymentMethodResourceId != None:
            rechargeData = newRechargeData(rechargeAmount, rechargePaymentMethodResourceId)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAddThresholdThresholdRechargeDataFldKey,
                rechargeData)
        if isTemporaryCreditLimit:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAddThresholdThresholdIsTemporaryCreditLimitFldKey,
                isTemporaryCreditLimit)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupRemoveThreshold(self, queryType, queryValue, resourceId,
            thresholdId, removeThresholdOnly=None, removeRechargeDataOnly=None,
            isTemporaryCreditLimit=False, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupRemoveThresholdMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupRemoveThresholdGroupSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupRemoveThresholdBalanceResourceIdFldKey,
            resourceId)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupRemoveThresholdThresholdIdFldKey,
            thresholdId)
        if removeThresholdOnly != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupRemoveThresholdRemoveThresholdOnlyFldKey,
                removeThresholdOnly)
        if removeRechargeDataOnly != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupRemoveThresholdRemoveRechargeDataOnlyFldKey,
                removeRechargeDataOnly)
        if isTemporaryCreditLimit:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupRemoveThresholdIsTemporaryCreditLimitFldKey,
                isTemporaryCreditLimit)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupAddBalance(self, queryType, queryValue, balanceList,
            apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupAddBalanceMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupAddBalanceGroupSearchDataFldKey,
            search)

        balanceArray = []
        for balance in balanceList:
            balanceMdc = MDCDEFS.kMtxBalanceDataMdcDesc.create()
            balanceMdc.setUsingKey(
                MDCDEFS.kMtxBalanceDataBalanceTemplateIdFldKey,
                balance['BalanceTemplateId'])
            if 'InitAmount' in balance:
                balanceMdc.setUsingKey(
                    MDCDEFS.kMtxBalanceDataInitAmountFldKey,
                    balance['InitAmount'])
            balanceArray.append(balanceMdc)

        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupAddBalanceBalanceRequestArrayFldKey,
            balanceArray)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupAdjustBalance(self, queryType, queryValue, balanceResourceId,
            adjustType, reason, amount=None, info=None, endTime=None, creditLimitPolicy=None,
            endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
            startTime=None, componentMeterId=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupAdjustBalanceMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupAdjustBalanceGroupSearchDataFldKey,
            search)

        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupAdjustBalanceBalanceResourceIdFldKey,
            balanceResourceId)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupAdjustBalanceAdjustTypeFldKey,
            adjustType)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupAdjustBalanceReasonFldKey,
            reason)
        if amount != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAdjustBalanceAmountFldKey,
                amount)
        if info != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAdjustBalanceInfoFldKey,
                info)
        if endTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAdjustBalanceEndTimeFldKey,
                endTime)
        if creditLimitPolicy != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAdjustBalanceCreditLimitPolicyFldKey,
                creditLimitPolicy)
        if endTimeExtensionOffsetUnit != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAdjustBalanceEndTimeExtensionOffsetUnitFldKey,
                endTimeExtensionOffsetUnit)
        if endTimeExtensionOffset != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAdjustBalanceEndTimeExtensionOffsetFldKey,
                endTimeExtensionOffset)
        if startTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAdjustBalanceStartTimeFldKey,
                startTime)
        if componentMeterId is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAdjustBalanceComponentMeterIdFldKey,
                componentMeterId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupTopupBalance(self, queryType, queryValue, balanceResourceId,
            amount, voucher, endTime=None, endTimeExtensionOffsetUnit=None,
            endTimeExtensionOffset=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupTopupBalanceMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupTopupBalanceGroupSearchDataFldKey,
            search)

        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupTopupBalanceBalanceResourceIdFldKey,
            balanceResourceId)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupTopupBalanceAmountFldKey,
            amount)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupTopupBalanceVoucherFldKey,
            voucher)
        if endTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupTopupBalanceEndTimeFldKey,
                endTime)
        if endTimeExtensionOffsetUnit != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupTopupBalanceEndTimeExtensionOffsetUnitFldKey,
                endTimeExtensionOffsetUnit)
        if endTimeExtensionOffset != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupTopupBalanceEndTimeExtensionOffsetFldKey,
                endTimeExtensionOffset)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupAdjustRolloverBalance(self, queryType, queryValue, reason,
            balanceResourceId, balanceIntervalId=None, adjustType=None, amount=None,
            remainingRolloverCounter=None, info=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupAdjustRolloverBalanceMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupAdjustRolloverBalanceGroupSearchDataFldKey,
            search)

        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupAdjustRolloverBalanceBalanceResourceIdFldKey,
            balanceResourceId)
        if balanceIntervalId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAdjustRolloverBalanceBalanceIntervalIdFldKey,
                balanceIntervalId)
        if adjustType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAdjustRolloverBalanceAdjustTypeFldKey,
                adjustType)
        if amount != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAdjustRolloverBalanceAmountFldKey,
                amount)
        if remainingRolloverCounter != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAdjustRolloverBalanceRemainingRolloverCounterFldKey,
                remainingRolloverCounter)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupAdjustRolloverBalanceReasonFldKey,
            reason)
        if info != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAdjustRolloverBalanceInfoFldKey,
                info)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupImportBalanceValue(self, queryType, queryValue, balanceResourceId,
            amount, startTime=None, createOnDemand=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupImportBalanceValueMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupImportBalanceValueGroupSearchDataFldKey,
            search)

        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupImportBalanceValueBalanceResourceIdFldKey,
            balanceResourceId)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupImportBalanceValueAmountFldKey,
            amount)

        if startTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupImportBalanceValueStartTimeFldKey,
                startTime)
        if createOnDemand != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupImportBalanceValueCreateOnDemandFldKey,
                createOnDemand)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupTransferBalance(self, queryType, queryValue, balanceResourceId,
        amount, amountIsPct, targetBalanceResourceId, targetSubscriberSearchData=None,
        targetGroupSearchData=None, sourceIsEventInitiator=True, reason=None,
        info=None, creditFloorPolicy=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupTransferBalanceMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupTransferBalanceGroupSearchDataFldKey,
            search)

        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupTransferBalanceBalanceResourceIdFldKey,
            balanceResourceId)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupTransferBalanceAmountFldKey,
            amount)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupTransferBalanceAmountIsPctFldKey,
            amountIsPct)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupTransferBalanceTargetBalanceResourceIdFldKey,
            targetBalanceResourceId)
        if targetSubscriberSearchData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupTransferBalanceTargetSubscriberSearchDataFldKey, \
                targetSubscriberSearchData)
        if targetGroupSearchData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupTransferBalanceTargetGroupSearchDataFldKey, \
                targetGroupSearchData)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupTransferBalanceSourceIsEventInitiatorFldKey,
            sourceIsEventInitiator)
        if creditFloorPolicy != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupTransferBalanceCreditFloorPolicyFldKey,
                creditFloorPolicy)
        if reason != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupTransferBalanceReasonFldKey,
                reason)
        if info != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupTransferBalanceInfoFldKey,
                info)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupQueryPaymentMethod(self,
            queryType, queryValue, paymentGatewayId=None, returnDefault=None, returnSysDefault=None,
            apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupQueryPaymentMethodMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupQueryPaymentMethodGroupSearchDataFldKey,
            search)

        if paymentGatewayId is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupQueryPaymentMethodPaymentGatewayIdFldKey,
                paymentGatewayId)
        if returnDefault is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupQueryPaymentMethodReturnDefaultFldKey,
                returnDefault)
        if returnSysDefault is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupQueryPaymentMethodReturnSysDefaultFldKey,
                returnSysDefault)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupAddPaymentMethod(self,
            queryType, queryValue, nonce, paymentGatewayId=None, paymentGatewayUserId=None,
            name=None, isDefault=None, paymentType=None, paymentAttr=None, isSysDefault=None,
            apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupAddPaymentMethodMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupAddPaymentMethodGroupSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupAddPaymentMethodPaymentGatewayOneTimeTokenFldKey,
            nonce)
        if paymentGatewayId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAddPaymentMethodPaymentGatewayIdFldKey,
                paymentGatewayId)
        if paymentGatewayUserId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAddPaymentMethodPaymentGatewayUserIdFldKey,
                paymentGatewayUserId)
        if name != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAddPaymentMethodNameFldKey,
                name)
        if isDefault != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAddPaymentMethodIsDefaultFldKey,
                isDefault)
        if paymentType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAddPaymentMethodPaymentTypeFldKey,
                paymentType)
        if paymentAttr != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAddPaymentMethodPaymentAttrFldKey,
                paymentAttr)
        if isSysDefault != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupAddPaymentMethodIsSysDefaultFldKey,
                isSysDefault)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupModifyPaymentMethod(self,
            queryType, queryValue, resourceId, paymentGatewayUserId=None, paymentGatewayOneTimeToken=None,
            name=None, isDefault=None, paymentType=None, paymentAttr=None, isSysDefault=None,
            apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupModifyPaymentMethodMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupModifyPaymentMethodGroupSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupModifyPaymentMethodResourceIdFldKey,
            resourceId)
        if paymentGatewayUserId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyPaymentMethodPaymentGatewayUserIdFldKey,
                paymentGatewayUserId)
        if paymentGatewayOneTimeToken != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyPaymentMethodPaymentGatewayOneTimeTokenFldKey,
                paymentGatewayOneTimeToken)
        if name != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyPaymentMethodNameFldKey,
                name)
        if isDefault != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyPaymentMethodIsDefaultFldKey,
                isDefault)
        if paymentType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyPaymentMethodPaymentTypeFldKey,
                paymentType)
        if paymentAttr != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyPaymentMethodPaymentAttrFldKey,
                paymentAttr)
        if isSysDefault != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyPaymentMethodIsSysDefaultFldKey,
                isSysDefault)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupRemovePaymentMethod(self, queryType, queryValue, resourceId, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupRemovePaymentMethodMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupRemovePaymentMethodGroupSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupRemovePaymentMethodResourceIdFldKey,
            resourceId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupValidatePaymentMethod(self, queryType, queryValue, resourceId=None, postalCode=None,
                                   apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupValidatePaymentMethodMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        searchData = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupValidatePaymentMethodGroupSearchDataFldKey,
            searchData)
        if resourceId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupValidatePaymentMethodResourceIdFldKey, resourceId)
        if postalCode != None:
            validationData = newPaymentMethodValidationData(postalCode)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupValidatePaymentMethodPaymentMethodValidationDataFldKey, validationData)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, searchData)
        return responseMdc

    def groupPayment(self, queryType, queryValue, amount, reason=None, info=None,
            payNow=None, paymentMethodResourceId=None, paymentGatewayId=None,
            paymentGatewayUserId=None, nonce=None, chargeMethodAttr=None,
            apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupPaymentMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupPaymentGroupSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupPaymentAmountFldKey,
            amount)
        if reason != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupPaymentReasonFldKey,
                reason)
        if info != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupPaymentInfoFldKey,
                info)
        if payNow is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupPaymentPayNowFldKey,
                payNow)

        if paymentMethodResourceId != None or paymentGatewayId != None \
            or paymentGatewayUserId != None or nonce != None \
            or chargeMethodAttr != None:
            chargeMethodData = newChargeMethodData(paymentMethodResourceId,
                None, paymentGatewayId, paymentGatewayUserId, nonce, chargeMethodAttr)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupPaymentChargeMethodDataFldKey,
                chargeMethodData)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupCreatePaymentOneTimeToken(self,
            queryType, queryValue, paymentMethodResourceId=None, paymentAttr=None,
            apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupCreatePaymentOneTimeTokenMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupCreatePaymentOneTimeTokenGroupSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupCreatePaymentOneTimeTokenPaymentMethodResourceIdFldKey,
            paymentMethodResourceId)
        if paymentAttr != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupCreatePaymentOneTimeTokenPaymentAttrFldKey,
                paymentAttr)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupRecharge(self, queryType, queryValue, amount, balanceResourceId=None,
            payNow=None, endTime=None, endTimeExtensionOffsetUnit=None,
            endTimeExtensionOffset=None, paymentMethodResourceId=None,
            reason=None, info=None, paymentGatewayId=None,
            paymentGatewayUserId=None, nonce=None, chargeMethodAttr=None,
            rechargeAttr=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupRechargeMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupRechargeGroupSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupRechargeAmountFldKey,
            amount)
        if balanceResourceId is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupRechargeBalanceResourceIdFldKey,
                balanceResourceId)
        if payNow is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupRechargePayNowFldKey,
                payNow)
        if endTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupRechargeEndTimeFldKey,
                endTime)
        if endTimeExtensionOffsetUnit != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupRechargeEndTimeExtensionOffsetUnitFldKey,
                endTimeExtensionOffsetUnit)
        if endTimeExtensionOffset != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupRechargeEndTimeExtensionOffsetFldKey,
                endTimeExtensionOffset)
        if reason != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupRechargeReasonFldKey,
                reason)
        if info != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupRechargeInfoFldKey,
                info)

        if paymentMethodResourceId != None or paymentGatewayId != None \
            or paymentGatewayUserId != None or nonce != None \
            or chargeMethodAttr != None:
            chargeMethodData = newChargeMethodData(paymentMethodResourceId,
                None, paymentGatewayId, paymentGatewayUserId, nonce, chargeMethodAttr)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupRechargeChargeMethodDataFldKey,
                chargeMethodData)

        if rechargeAttr != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupRechargeRechargeAttrFldKey,
                rechargeAttr)

        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupRefundPayment(self, queryType, queryValue, resourceId,
        amount=None, reason=None, info=None, balanceResourceId=None,
        apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupRefundPaymentMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupRefundPaymentGroupSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupRefundPaymentResourceIdFldKey,
            resourceId)

        if amount is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupRefundPaymentAmountFldKey,
                amount)
        if reason is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupRefundPaymentReasonFldKey,
                reason)
        if info is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupRefundPaymentInfoFldKey,
                info)
        if balanceResourceId is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupRefundPaymentBalanceResourceIdFldKey,
                balanceResourceId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupSettlePayment(self, queryType, queryValue, resourceId, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupSettlePaymentMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupSettlePaymentGroupSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupSettlePaymentResourceIdFldKey,
            resourceId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupQueryPaymentHistory(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupQueryPaymentHistoryMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupQueryPaymentHistoryGroupSearchDataFldKey,
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupEstimateRecurringCharge(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupEstimateRecurringChargeMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupEstimateRecurringChargeGroupSearchDataFldKey,
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupAddRechargeSchedule(self, queryType, queryValue, cycleDefn,
            amount, paymentMethodResourceId=None, firstRechargeTime=None,
            endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
            scheduledRechargeNotificationProfileId=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupAddRechargeScheduleMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupAddRechargeScheduleGroupSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupAddRechargeScheduleCycleDefnFldKey,
            cycleDefn)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupAddRechargeScheduleAmountFldKey,
            amount)
        if paymentMethodResourceId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupAddRechargeSchedulePaymentMethodResourceIdFldKey, \
                paymentMethodResourceId)
        if firstRechargeTime != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupAddRechargeScheduleFirstRechargeTimeFldKey, \
                firstRechargeTime)
        if endTimeExtensionOffsetUnit != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupAddRechargeScheduleEndTimeExtensionOffsetUnitFldKey, \
                endTimeExtensionOffsetUnit)
        if endTimeExtensionOffset != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupAddRechargeScheduleEndTimeExtensionOffsetFldKey, \
                endTimeExtensionOffset)
        if scheduledRechargeNotificationProfileId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupAddRechargeScheduleScheduledRechargeNotificationProfileIdFldKey, \
                scheduledRechargeNotificationProfileId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupModifyRechargeSchedule(self, queryType, queryValue, cycleDefn=None,
            amount=None, paymentMethodResourceId=None, nextRechargeTime=None,
            endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
            scheduledRechargeNotificationProfileId=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupModifyRechargeScheduleMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupModifyRechargeScheduleGroupSearchDataFldKey,
            search)
        if cycleDefn != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyRechargeScheduleCycleDefnFldKey,
                cycleDefn)
        if amount != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyRechargeScheduleAmountFldKey,
                amount)
        if paymentMethodResourceId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupModifyRechargeSchedulePaymentMethodResourceIdFldKey, \
                paymentMethodResourceId)
        if nextRechargeTime != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupModifyRechargeScheduleNextRechargeTimeFldKey, \
                nextRechargeTime)
        if endTimeExtensionOffsetUnit != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupModifyRechargeScheduleEndTimeExtensionOffsetUnitFldKey, \
                endTimeExtensionOffsetUnit)
        if endTimeExtensionOffset != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupModifyRechargeScheduleEndTimeExtensionOffsetFldKey, \
                endTimeExtensionOffset)
        if scheduledRechargeNotificationProfileId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupModifyRechargeScheduleScheduledRechargeNotificationProfileIdFldKey, \
                scheduledRechargeNotificationProfileId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupRemoveRechargeSchedule(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupRemoveRechargeScheduleMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupRemoveRechargeScheduleGroupSearchDataFldKey,
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupQueryRechargeSchedule(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupQueryRechargeScheduleMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupQueryRechargeScheduleGroupSearchDataFldKey,
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupQueryRecurringRecharge(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupQueryRecurringRechargeMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupQueryRecurringRechargeGroupSearchDataFldKey,
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupCheckPurchasedItemCycleAlignment(self, queryType, queryValue, offerRequest=None,
            offerResourceId=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupCheckPurchasedItemCycleAlignmentMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupCheckPurchasedItemCycleAlignmentGroupSearchDataFldKey,
            search)

        if offerRequest != None:
            offerRequest = newOfferPurchaseArray([offerRequest])[0]
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupCheckPurchasedItemCycleAlignmentOfferRequestFldKey,
                offerRequest)
        if offerResourceId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupCheckPurchasedItemCycleAlignmentOfferResourceIdFldKey,
                offerResourceId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupQueryThresholdRechargeDefn(self, queryType, queryValue, balanceResourceId=None,
                                        apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupQueryThresholdRechargeDefnMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestGroupQueryThresholdRechargeDefnGroupSearchDataFldKey, \
            search)
        if balanceResourceId is not None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupQueryThresholdRechargeDefnBalanceResourceIdFldKey, \
                balanceResourceId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupQueryTask(self, queryType, queryValue, queryCursor=None, querySize=None,
                       apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupQueryTaskMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestGroupQueryTaskGroupSearchDataFldKey, \
            search)
        if queryCursor != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupQueryTaskQueryCursorFldKey, queryCursor)
        if querySize != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupQueryTaskQuerySizeFldKey, querySize)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupContractDebtPayment(self, queryType, queryValue, offerResourceId,
            amount, paymentMethodResourceId=None, chargeMethod=None, paymentGatewayId=None,
            paymentGatewayUserId=None, nonce=None, chargeMethodAttr=None, reason=None,
            info=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupContractDebtPaymentMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupContractDebtPaymentGroupSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupContractDebtPaymentResourceIdFldKey,
            offerResourceId)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupContractDebtPaymentAmountFldKey,
            amount)

        if paymentMethodResourceId != None or chargeMethod != None or \
            paymentGatewayId != None or paymentGatewayUserId != None \
            or nonce != None or chargeMethodAttr != None:
            chargeMethodData = newChargeMethodData(paymentMethodResourceId,
                chargeMethod, paymentGatewayId, paymentGatewayUserId, nonce,
                chargeMethodAttr)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupContractDebtPaymentChargeMethodDataFldKey,
                chargeMethodData)

        if reason != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupContractDebtPaymentReasonFldKey,
                reason)
        if info != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupContractDebtPaymentInfoFldKey,
                info)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupMakeFinanceContractPrincipalPayment(self, queryType, queryValue, offerResourceId,
            isPayoff=True, extraPrincipalAmount=None, paymentMethodResourceId=None, chargeMethod=None,
            paymentGatewayId=None, paymentGatewayUserId=None, nonce=None, chargeMethodAttr=None, reason=None,
            info=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupFinanceContractPrincipalPaymentMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupFinanceContractPrincipalPaymentGroupSearchDataFldKey,
            search)

        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupFinanceContractPrincipalPaymentResourceIdFldKey,
            offerResourceId)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupFinanceContractPrincipalPaymentIsPayoffFldKey,
            isPayoff)

        if not isPayoff:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupFinanceContractPrincipalPaymentExtraPrincipalAmountFldKey,
                extraPrincipalAmount)

        if paymentMethodResourceId != None or chargeMethod != None or \
            paymentGatewayId != None or paymentGatewayUserId != None or \
            nonce != None or chargeMethodAttr != None:
            chargeMethodData = newChargeMethodData(paymentMethodResourceId,
                chargeMethod, paymentGatewayId, paymentGatewayUserId, nonce, chargeMethodAttr)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupFinanceContractPrincipalPaymentChargeMethodDataFldKey,
                chargeMethodData)

        if reason != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupFinanceContractPrincipalPaymentReasonFldKey,
                reason)

        if info != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupFinanceContractPrincipalPaymentInfoFldKey,
                info)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupQueryCatalogItemList(self, queryType, queryValue, eligibilityFilter=None,
                                  apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupQueryCatalogItemListMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupQueryCatalogItemListGroupSearchDataFldKey,
            search)

        if eligibilityFilter != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupQueryCatalogItemListEligibilityFilterFldKey,
                eligibilityFilter)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupQueryCatalog(self, queryType, queryValue, catalogQueryType, catalogQueryValue,
            eligibilityFilter=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupQueryCatalogMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestGroupQueryCatalogGroupSearchDataFldKey,\
            search)

        catalogSearch = newPricingCatalogSearch(catalogQueryType, catalogQueryValue)
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestGroupQueryCatalogCatalogSearchDataFldKey,\
            catalogSearch)

        if eligibilityFilter != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupQueryCatalogEligibilityFilterFldKey,\
                eligibilityFilter)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupAddBalanceExpiryRechargeDefn(self, queryType, queryValue, balanceResourceId,
            durationBeforeExpiryInMinutes, rechargeAmount, paymentMethodResourceId=None,
            notificationProfileId=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupAddBalanceExpiryRechargeDefnMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestGroupAddBalanceExpiryRechargeDefnGroupSearchDataFldKey, \
            search)
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestGroupAddBalanceExpiryRechargeDefnBalanceResourceIdFldKey, \
            balanceResourceId)
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestGroupAddBalanceExpiryRechargeDefnDurationBeforeExpiryInMinutesFldKey, \
            durationBeforeExpiryInMinutes)
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestGroupAddBalanceExpiryRechargeDefnRechargeAmountFldKey, \
            rechargeAmount)
        if paymentMethodResourceId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupAddBalanceExpiryRechargeDefnPaymentMethodResourceIdFldKey, \
                paymentMethodResourceId)
        if notificationProfileId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupAddBalanceExpiryRechargeDefnNotificationProfileIdFldKey, \
                notificationProfileId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupModifyBalanceExpiryRechargeDefn(self, queryType, queryValue, balanceResourceId,
            durationBeforeExpiryInMinutes=None, rechargeAmount=None, paymentMethodResourceId=None,
            notificationProfileId=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupModifyBalanceExpiryRechargeDefnMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupModifyBalanceExpiryRechargeDefnGroupSearchDataFldKey,
            search)
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestGroupModifyBalanceExpiryRechargeDefnBalanceResourceIdFldKey, \
            balanceResourceId)
        if durationBeforeExpiryInMinutes != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupModifyBalanceExpiryRechargeDefnDurationBeforeExpiryInMinutesFldKey, \
                durationBeforeExpiryInMinutes)
        if rechargeAmount != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupModifyBalanceExpiryRechargeDefnRechargeAmountFldKey, \
                rechargeAmount)
        if paymentMethodResourceId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupModifyBalanceExpiryRechargeDefnPaymentMethodResourceIdFldKey, \
                paymentMethodResourceId)
        if notificationProfileId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupModifyBalanceExpiryRechargeDefnNotificationProfileIdFldKey, \
                notificationProfileId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupRemoveBalanceExpiryRechargeDefn(self, queryType, queryValue, balanceResourceId,
            apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupRemoveBalanceExpiryRechargeDefnMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupRemoveBalanceExpiryRechargeDefnGroupSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupRemoveBalanceExpiryRechargeDefnBalanceResourceIdFldKey,
            balanceResourceId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupQueryBalanceExpiryRechargeDefn(self, queryType, queryValue, balanceResourceId=None,
                                            apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupQueryBalanceExpiryRechargeDefnMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestGroupQueryBalanceExpiryRechargeDefnGroupSearchDataFldKey, \
            search)
        if balanceResourceId is not None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestGroupQueryBalanceExpiryRechargeDefnBalanceResourceIdFldKey, \
                balanceResourceId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupActivateOffer(self, queryType, queryValue, resourceId, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupActivateOfferMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupActivateOfferGroupSearchDataFldKey, \
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupActivateOfferResourceIdFldKey, \
            resourceId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupModifyExternalPayment(self, queryType, queryValue, resourceId,
            reason, opType=None, amount=None, info=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupModifyExternalPaymentMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupModifyExternalPaymentGroupSearchDataFldKey,
            search)

        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupModifyExternalPaymentResourceIdFldKey,
            resourceId)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupModifyExternalPaymentReasonFldKey,
            reason)
        if opType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyExternalPaymentOpTypeFldKey,
                opType)
        if amount != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyExternalPaymentAmountFldKey,
                amount)
        if info != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyExternalPaymentInfoFldKey,
                info)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupQueryExternalPayment(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupQueryExternalPaymentMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupQueryExternalPaymentGroupSearchDataFldKey, \
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupQueryOneTimeOffer(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupQueryOneTimeOfferMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupQueryOneTimeOfferGroupSearchDataFldKey, \
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupSuspendOffer(self, queryType, queryValue, resourceId,
        scheduledSuspendTime=None, autoResumeRelativeOffset=None,
        autoResumeRelativeOffsetUnit=None, autoResumeTime=None, isPauseMode=None,
        grantSuspendProrationType=None, chargeSuspendProrationType=None,
        grantResumeProrationType=None, chargeResumeProrationType=None,
        apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupSuspendOfferMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupSuspendOfferGroupSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupSuspendOfferResourceIdFldKey,
            resourceId)
        if scheduledSuspendTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupSuspendOfferScheduledSuspendTimeFldKey,
                scheduledSuspendTime)
        if autoResumeRelativeOffset != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupSuspendOfferAutoResumeRelativeOffsetFldKey,
                autoResumeRelativeOffset)
        if autoResumeRelativeOffsetUnit != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupSuspendOfferAutoResumeRelativeOffsetUnitFldKey,
                autoResumeRelativeOffsetUnit)
        if autoResumeTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupSuspendOfferAutoResumeTimeFldKey,
                autoResumeTime)
        if isPauseMode != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupSuspendOfferIsPauseModeFldKey,
                isPauseMode)
        if grantSuspendProrationType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupSuspendOfferGrantSuspendProrationTypeFldKey,
                grantSuspendProrationType)
        if chargeSuspendProrationType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupSuspendOfferChargeSuspendProrationTypeFldKey,
                chargeSuspendProrationType)
        if grantResumeProrationType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupSuspendOfferGrantResumeProrationTypeFldKey,
                grantResumeProrationType)
        if chargeResumeProrationType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupSuspendOfferChargeResumeProrationTypeFldKey,
                chargeResumeProrationType)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupResumeOffer(self, queryType, queryValue, resourceId,
        scheduledResumeTime=None, resumeRelativeOffset=None,
        resumeRelativeOffsetUnit=None, grantResumeProrationType=None,
        chargeResumeProrationType=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupResumeOfferMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupResumeOfferGroupSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupResumeOfferResourceIdFldKey,
            resourceId)
        if scheduledResumeTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupResumeOfferScheduledResumeTimeFldKey,
                scheduledResumeTime)
        if resumeRelativeOffset != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupResumeOfferResumeRelativeOffsetFldKey,
                resumeRelativeOffset)
        if resumeRelativeOffsetUnit != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupResumeOfferResumeRelativeOffsetUnitFldKey,
                resumeRelativeOffsetUnit)
        if grantResumeProrationType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupResumeOfferGrantResumeProrationTypeFldKey,
                grantResumeProrationType)
        if chargeResumeProrationType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupResumeOfferChargeResumeProrationTypeFldKey,
                chargeResumeProrationType)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupModifyStatus(self, queryType, queryValue, statusValue,
        statusTransitionTime=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupModifyStatusMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupModifyStatusGroupSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupModifyStatusStatusValueFldKey,
            statusValue)
        if statusTransitionTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestGroupModifyStatusScheduledStatusTransitionTimeFldKey,
                statusTransitionTime)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupRemoveScheduledStatusChange(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupRemoveScheduledStatusChangeMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupRemoveScheduledStatusChangeGroupSearchDataFldKey,
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def groupRemoveScheduledOfferStatusChange(self, queryType, queryValue, resourceId,
        apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupRemoveScheduledOfferStatusChangeMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupRemoveScheduledOfferStatusChangeGroupSearchDataFldKey,
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupRemoveScheduledOfferStatusChangeResourceIdFldKey,
            resourceId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriptionCreate(self, now=None, externalId=None, status=None,
            timeZone=None, billingCycle=None, attr=None, taxStatus=None,
            taxCertificate=None, taxLocation=None, glCenter=None,
            name=None, routingType=None, routingValue=None, apiEventData=None,
            customerType=None, serviceAddress=None,
            npa=None, nxx=None, tenantId=None, exemptionCodeList=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriptionCreateMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if externalId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriptionCreateExternalIdFldKey, externalId)
        if status != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriptionCreateStatusFldKey, status)
        if timeZone != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionCreateTimeZoneFldKey, timeZone)
        if billingCycle != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionCreateBillingCycleFldKey, billingCycle)
        if attr != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriptionCreateAttrFldKey, \
                attr)
        if taxStatus != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionCreateTaxStatusFldKey, taxStatus)
        if taxCertificate != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionCreateTaxCertificateFldKey, taxCertificate)
        if taxLocation != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionCreateTaxLocationFldKey, taxLocation)
        if glCenter != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionCreateGlCenterFldKey, glCenter)
        if name != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionCreateNameFldKey, name)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        if customerType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionCreateCustomerTypeFldKey, customerType)
        if npa != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionCreateNpaFldKey, npa)
        if nxx != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionCreateNxxFldKey, nxx)
        if tenantId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionCreateTenantIdFldKey, tenantId)
        if serviceAddress != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionCreateServiceAddressFldKey, serviceAddress)
        if exemptionCodeList != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionCreateExemptionCodeListFldKey, exemptionCodeList)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def subscriptionQuery(self, queryType, queryValue, querySize=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriptionQueryMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriptionSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriptionQuerySubscriptionSearchDataFldKey, \
            search)
        if querySize != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionQueryQuerySizeFldKey, querySize)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriptionModify(self, queryType, queryValue, now=None,
            status=None, timeZone=None, billingCycle=None, attr=None,
            externalId=None, taxStatus=None, taxCertificate=None,
            taxLocation=None, glCenter=None, currentPaymentTokenResourceId=None,
            lastActivityUpdateTime=None, billingCycleDisabled=None,
            sysPaymentTokenResourceId=None, name=None, apiEventData=None,
            customerType=None, serviceAddress=None,
            npa=None, nxx=None, tenantId=None, exemptionCodeList=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriptionModifyMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriptionSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriptionModifySubscriptionSearchDataFldKey, \
            search)
        if status != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionModifyStatusFldKey, status)
        if timeZone != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionModifyTimeZoneFldKey, timeZone)
        if billingCycle != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionModifyBillingCycleFldKey, billingCycle)
        if attr != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriptionModifyAttrFldKey, \
                attr)
        if taxStatus != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionModifyTaxStatusFldKey, taxStatus)
        if taxCertificate != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionModifyTaxCertificateFldKey, taxCertificate)
        if taxLocation != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionModifyTaxLocationFldKey, taxLocation)
        if externalId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionModifyExternalIdFldKey, externalId)
        if glCenter != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionModifyGlCenterFldKey, glCenter)
        if currentPaymentTokenResourceId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionModifyCurrentPaymentTokenResourceIdFldKey, currentPaymentTokenResourceId)
        if lastActivityUpdateTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionModifyLastActivityUpdateTimeFldKey, lastActivityUpdateTime)
        if billingCycleDisabled != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionModifyBillingCycleDisabledFldKey, billingCycleDisabled)
        if sysPaymentTokenResourceId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionModifySysPaymentTokenResourceIdFldKey, sysPaymentTokenResourceId)
        if name != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionModifyNameFldKey, name)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        if customerType != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionModifyCustomerTypeFldKey, customerType)
        if npa != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionModifyNpaFldKey, npa)
        if nxx != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionModifyNxxFldKey, nxx)
        if tenantId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionModifyTenantIdFldKey, tenantId)
        if serviceAddress != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionModifyServiceAddressFldKey, serviceAddress)
        if exemptionCodeList != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionModifyExemptionCodeListFldKey, exemptionCodeList)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriptionDelete(self, queryType, queryValue, deleteDevices=None, deleteSession=None,
                           apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriptionDeleteMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newSubscriptionSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriptionDeleteSubscriptionSearchDataFldKey, \
            search)
        if deleteDevices != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSubscriptionDeleteDeleteDeviceFldKey, deleteDevices)
        if deleteSession != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSubscriptionDeleteDeleteSessionFldKey, deleteSession)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def userCreate(self, now=None, userId=None, externalId=None,
            firstName=None, lastName=None, contactEmail=None,
            contactPhoneNumber=None, contactPushTokenList=None,
            notificationPreference=None, attr=None, language=None,
            status=None, timeZone=None, routingType=None, routingValue=None,
            tenantId=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestUserCreateMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if userId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestUserCreateUserIdFldKey, userId)
        if externalId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestUserCreateExternalIdFldKey, externalId)
        if firstName != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserCreateFirstNameFldKey, firstName)
        if lastName != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserCreateLastNameFldKey, lastName)
        if contactEmail != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserCreateContactEmailFldKey, contactEmail)
        if contactPhoneNumber != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserCreateContactPhoneNumberFldKey, contactPhoneNumber)
        if contactPushTokenList != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserCreateContactPushTokenListFldKey, contactPushTokenList)
        if notificationPreference != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserCreateNotificationPreferenceFldKey, notificationPreference)
        if attr != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestUserCreateAttrFldKey, \
                attr)
        if language != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserCreateLanguageFldKey, language)
        if status != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserCreateStatusFldKey, status)
        if timeZone != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserCreateTimeZoneFldKey, timeZone)
        if tenantId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserCreateTenantIdFldKey, tenantId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def userQuery(self, queryType, queryValue, querySize=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestUserQueryMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newUserSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserQueryUserSearchDataFldKey, \
            search)
        if querySize != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserQueryQuerySizeFldKey, querySize)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def userModify(self, queryType, queryValue, now=None,
            firstName=None, lastName=None, contactEmail=None,
            contactPhoneNumber=None, contactPushTokenList=None,
            notificationPreference=None, attr=None, userId=None, externalId=None,
            language=None, status=None, lastActivityUpdateTime=None, timeZone=None,
            apiEventData=None, tenantId=None):
        requestMdc = MDCDEFS.kMtxRequestUserModifyMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newUserSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserModifyUserSearchDataFldKey, \
            search)
        if firstName != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserModifyFirstNameFldKey, firstName)
        if lastName != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserModifyLastNameFldKey, lastName)
        if contactEmail != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserModifyContactEmailFldKey, contactEmail)
        if contactPhoneNumber != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserModifyContactPhoneNumberFldKey, contactPhoneNumber)
        if contactPushTokenList != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserModifyContactPushTokenListFldKey, contactPushTokenList)
        if notificationPreference != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserModifyNotificationPreferenceFldKey, notificationPreference)
        if attr != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestUserModifyAttrFldKey, \
                attr)
        if language != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserModifyLanguageFldKey, language)
        if status != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserModifyStatusFldKey, status)
        if userId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserModifyUserIdFldKey, userId)
        if externalId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserModifyExternalIdFldKey, externalId)
        if lastActivityUpdateTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserModifyLastActivityUpdateTimeFldKey, lastActivityUpdateTime)
        if timeZone != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserModifyTimeZoneFldKey, timeZone)
        if tenantId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserModifyTenantIdFldKey, tenantId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def userDelete(self, queryType, queryValue,
            deleteSubscription=None, deleteDevices=None, deleteSession=None,
            removeExplicitMembership=False, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestUserDeleteMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newUserSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserDeleteUserSearchDataFldKey, \
            search)
        if deleteSubscription != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserDeleteDeleteSubscriptionFldKey, deleteSubscription)
        if deleteDevices != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserDeleteDeleteDeviceFldKey, deleteDevices)
        if deleteSession != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestUserDeleteDeleteSessionFldKey, deleteSession)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserDeleteRemoveExplicitMembershipFldKey, \
            removeExplicitMembership)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def userQueryAuthData(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestUserQueryAuthDataMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newUserSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserQueryAuthDataUserSearchDataFldKey,
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def userModifyAuthData(self, queryType, queryValue, loginId=None,
            password=None, roleFlags=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestUserModifyAuthDataMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newUserSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserModifyAuthDataUserSearchDataFldKey,
            search)
        if loginId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserModifyAuthDataLoginIdFldKey,
                loginId)
        # This is a BLOB field but represented in Python as a string
        if password != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserModifyAuthDataPasswordFldKey,
                password)
        if roleFlags != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserModifyAuthDataRoleFlagsFldKey,
                roleFlags)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def userAddAccount(self, userQueryType, userQueryValue,
            accountQueryType, accountQueryValue, roles=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestUserAddAccountMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        userSearch = newUserSearch(userQueryType, userQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserAddAccountUserSearchDataFldKey, \
            userSearch)
        accountSearch = newAccountSearch(accountQueryType, accountQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserAddAccountAccountSearchDataFldKey, \
            accountSearch)
        if roles != None:
            roleDataArray = newRoleDataArray(roles)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserAddAccountRoleArrayFldKey, roleDataArray)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, userSearch)
        return responseMdc

    def userModifyAccount(self, userQueryType, userQueryValue,
            accountQueryType, accountQueryValue, roles=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestUserModifyAccountMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        userSearch = newUserSearch(userQueryType, userQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserModifyAccountUserSearchDataFldKey, \
            userSearch)
        accountSearch = newAccountSearch(accountQueryType, accountQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserModifyAccountAccountSearchDataFldKey, \
            accountSearch)
        if roles != None:
            roleDataArray = newRoleDataArray(roles)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserModifyAccountRoleArrayFldKey, roleDataArray)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, userSearch)
        return responseMdc

    def userRemoveAccount(self, userQueryType, userQueryValue,
            accountQueryType, accountQueryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestUserRemoveAccountMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        userSearch = newUserSearch(userQueryType, userQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserRemoveAccountUserSearchDataFldKey, \
            userSearch)
        accountSearch = newAccountSearch(accountQueryType, accountQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserRemoveAccountAccountSearchDataFldKey, \
            accountSearch)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, userSearch)
        return responseMdc

    def userAddGroup(self, userQueryType, userQueryValue,
            grpQueryType, grpQueryValue, roles=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestUserAddGroupMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        userSearch = newUserSearch(userQueryType, userQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserAddGroupUserSearchDataFldKey, \
            userSearch)
        grpSearch = newGroupSearch(grpQueryType, grpQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserAddGroupGroupSearchDataFldKey, \
            grpSearch)
        if roles != None:
            roleDataArray = newRoleDataArray(roles)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserAddGroupRoleArrayFldKey, roleDataArray)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, userSearch)
        return responseMdc

    def userModifyGroup(self, userQueryType, userQueryValue, grpQueryType, grpQueryValue,
            roles=None, removeExplicitMembership=False, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestUserModifyGroupMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        userSearch = newUserSearch(userQueryType, userQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserModifyGroupUserSearchDataFldKey, \
            userSearch)
        grpSearch = newGroupSearch(grpQueryType, grpQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserModifyGroupGroupSearchDataFldKey, \
            grpSearch)
        if roles != None:
            roleDataArray = newRoleDataArray(roles)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserModifyGroupRoleArrayFldKey, roleDataArray)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserModifyGroupRemoveExplicitMembershipFldKey, \
            removeExplicitMembership)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, userSearch)
        return responseMdc

    def userRemoveGroup(self, userQueryType, userQueryValue, grpQueryType, grpQueryValue,
            removeExplicitMembership=False, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestUserRemoveGroupMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        userSearch = newUserSearch(userQueryType, userQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserRemoveGroupUserSearchDataFldKey, \
            userSearch)
        grpSearch = newGroupSearch(grpQueryType, grpQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserRemoveGroupGroupSearchDataFldKey, \
            grpSearch)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserRemoveGroupRemoveExplicitMembershipFldKey, \
            removeExplicitMembership)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, userSearch)
        return responseMdc

    def userAddSubscription(self, userQueryType, userQueryValue,
            subQueryType, subQueryValue, roles=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestUserAddSubscriptionMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        userSearch = newUserSearch(userQueryType, userQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserAddSubscriptionUserSearchDataFldKey, \
            userSearch)
        subSearch = newSubscriptionSearch(subQueryType, subQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserAddSubscriptionSubscriptionSearchDataFldKey, \
            subSearch)
        if roles != None:
            roleDataArray = newRoleDataArray(roles)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserAddSubscriptionRoleArrayFldKey, roleDataArray)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, userSearch)
        return responseMdc

    def userModifySubscription(self, userQueryType, userQueryValue, subQueryType, subQueryValue,
            roles=None, removeExplicitMembership=False, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestUserModifySubscriptionMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        userSearch = newUserSearch(userQueryType, userQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserModifySubscriptionUserSearchDataFldKey, \
            userSearch)
        subSearch = newSubscriptionSearch(subQueryType, subQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserModifySubscriptionSubscriptionSearchDataFldKey, \
            subSearch)
        if roles != None:
            roleDataArray = newRoleDataArray(roles)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserModifySubscriptionRoleArrayFldKey, roleDataArray)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserModifySubscriptionRemoveExplicitMembershipFldKey, \
            removeExplicitMembership)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, userSearch)
        return responseMdc

    def userRemoveSubscription(self, userQueryType, userQueryValue, subQueryType, subQueryValue,
            removeExplicitMembership=False, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestUserRemoveSubscriptionMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        userSearch = newUserSearch(userQueryType, userQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserRemoveSubscriptionUserSearchDataFldKey, \
            userSearch)
        subSearch = newSubscriptionSearch(subQueryType, subQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserRemoveSubscriptionSubscriptionSearchDataFldKey, \
            subSearch)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserRemoveSubscriptionRemoveExplicitMembershipFldKey, \
            removeExplicitMembership)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, userSearch)
        return responseMdc

    def userQueryMembership(self, queryType, queryValue, membershipType,
            queryCursor=None, querySize=None, returnExternalId=False, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestUserQueryMembershipMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newUserSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserQueryMembershipUserSearchDataFldKey, \
            search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserQueryMembershipMembershipTypeFldKey, membershipType)
        if queryCursor != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserQueryMembershipQueryCursorFldKey, queryCursor)
        if querySize != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserQueryMembershipQuerySizeFldKey, querySize)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserQueryMembershipReturnExternalIdFldKey, returnExternalId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def userQueryTask(self, queryType, queryValue, queryCursor=None, querySize=None,
                      apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestUserQueryTaskMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newUserSearch(queryType, queryValue)
        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestUserQueryTaskUserSearchDataFldKey, \
            search)
        if queryCursor != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserQueryTaskQueryCursorFldKey, queryCursor)
        if querySize != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserQueryTaskQuerySizeFldKey, querySize)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def userQueryEvent(self, queryType, queryValue,
            queryCursor=None, querySize=None,
            eventTimeLowerBound=None, eventTimeUpperBound=None,
            eventTypeStringArray=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestUserQueryEventMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        userSearch = newUserSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserQueryEventUserSearchDataFldKey, \
            userSearch)
        if queryCursor != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserQueryEventQueryCursorFldKey, queryCursor)
        if querySize != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserQueryEventQuerySizeFldKey, querySize)
        if eventTimeLowerBound != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserQueryEventEventTimeLowerBoundFldKey, eventTimeLowerBound)
        if eventTimeUpperBound != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserQueryEventEventTimeUpperBoundFldKey, eventTimeUpperBound)
        if eventTypeStringArray != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestUserQueryEventEventTypeArrayFldKey, eventTypeStringArray)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, userSearch)
        return responseMdc

    def accountCreate(self, now=None, externalId=None, status=None,
            timeZone=None, billingCycle=None, attr=None, taxStatus=None, taxCertificate=None,
            taxLocation=None, glCenter=None, routingType=None, routingValue=None,
            apiEventData=None, tenantId=None):
        requestMdc = MDCDEFS.kMtxRequestAccountCreateMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if externalId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestAccountCreateExternalIdFldKey, externalId)
        if status != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestAccountCreateStatusFldKey, status)
        if timeZone != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestAccountCreateTimeZoneFldKey, timeZone)
        if billingCycle != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestAccountCreateBillingCycleFldKey, billingCycle)
        if attr != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestAccountCreateAttrFldKey, \
                attr)
        if taxStatus != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestAccountCreateTaxStatusFldKey, taxStatus)
        if taxCertificate != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestAccountCreateTaxCertificateFldKey, taxCertificate)
        if taxLocation != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestAccountCreateTaxLocationFldKey, taxLocation)
        if glCenter != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestAccountCreateGlCenterFldKey, glCenter)
        if tenantId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestAccountCreateTenantIdFldKey, tenantId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def accountQuery(self, queryType, queryValue, querySize=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestAccountQueryMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newAccountSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestAccountQueryAccountSearchDataFldKey, \
            search)
        if querySize != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestAccountQueryQuerySizeFldKey, querySize)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def accountQueryWallet(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestAccountQueryWalletMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newAccountSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestAccountQueryWalletAccountSearchDataFldKey, \
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def accountModify(self, queryType, queryValue, now=None,
            status=None, timeZone=None, billingCycle=None,
            attr=None, externalId=None, taxStatus=None,
            taxCertificate=None, taxLocation=None, glCenter=None,
            lastActivityUpdateTime=None, tenantId=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestAccountModifyMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newAccountSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestAccountModifyAccountSearchDataFldKey, \
            search)
        if status != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestAccountModifyStatusFldKey, status)
        if timeZone != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestAccountModifyTimeZoneFldKey, timeZone)
        if billingCycle != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestAccountModifyBillingCycleFldKey, billingCycle)
        if attr != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestAccountModifyAttrFldKey, \
                attr)
        if taxStatus != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestAccountModifyTaxStatusFldKey, taxStatus)
        if taxCertificate != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestAccountModifyTaxCertificateFldKey, taxCertificate)
        if taxLocation != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestAccountModifyTaxLocationFldKey, taxLocation)
        if externalId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestAccountModifyExternalIdFldKey, externalId)
        if glCenter != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestAccountModifyGlCenterFldKey, glCenter)
        if lastActivityUpdateTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestAccountModifyLastActivityUpdateTimeFldKey, lastActivityUpdateTime)
        if tenantId != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestAccountModifyTenantIdFldKey, tenantId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def accountDelete(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestAccountDeleteMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newAccountSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestAccountDeleteAccountSearchDataFldKey, \
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    # For internal MATRIXX usage only.
    def taxQueryGeoCode(self, postalCode=None, plus4=None, npa=None, nxx=None, now=None,
        timeZone=None):
        requestMdc = MDCDEFS.kMtxRequestTaxQueryGeoCodeMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if postalCode is not None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestTaxQueryGeoCodePostalCodeFldKey, postalCode)
        if plus4 is not None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestTaxQueryGeoCodePlus4FldKey, plus4)
        if npa is not None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestTaxQueryGeoCodeNpaFldKey, npa)
        if nxx is not None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestTaxQueryGeoCodeNxxFldKey, nxx)
        if timeZone is not None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestTaxQueryGeoCodeTimeZoneFldKey, timeZone)
        responseMdc = self._sendRpcRequest(requestMdc)
        return responseMdc

    # For internal MATRIXX usage only.
    def taxQueryCustomerTypeList(self):
        requestMdc = MDCDEFS.kMtxRequestTaxQueryCustomerTypeListMdcDesc.create()
        responseMdc = self._sendRpcRequest(requestMdc)
        return responseMdc

    # For internal MATRIXX usage only.
    def taxQueryProductGroupList(self):
        requestMdc = MDCDEFS.kMtxRequestTaxQueryProductGroupListMdcDesc.create()
        responseMdc = self._sendRpcRequest(requestMdc)
        return responseMdc

    # For internal MATRIXX usage only.
    def taxQueryProductItemList(self, productGroup):
        requestMdc = MDCDEFS.kMtxRequestTaxQueryProductItemListMdcDesc.create()
        if productGroup is not None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestTaxQueryProductItemListProductGroupFldKey, productGroup)
        responseMdc = self._sendRpcRequest(requestMdc)
        return responseMdc

    # For internal MATRIXX usage only.
    def taxQueryExemptionCodeList(self):
        requestMdc = MDCDEFS.kMtxRequestTaxQueryExemptionCodeListMdcDesc.create()
        responseMdc = self._sendRpcRequest(requestMdc)
        return responseMdc

    # For internal MATRIXX usage only.
    def taxQueryStatus(self):
        requestMdc = MDCDEFS.kMtxRequestTaxQueryStatusMdcDesc.create()
        responseMdc = self._sendRpcRequest(requestMdc)
        return responseMdc

    # For internal MATRIXX usage only.
    def createDatabaseObject(self, databaseId, objectMdc, routingType=None, routingValue=None):
        requestMdc = MDCDEFS.kMtxRequestDatabaseObjectCreateMdcDesc.create()
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDatabaseObjectCreateObjectFldKey, objectMdc)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDatabaseObjectCreateDatabaseIdFldKey, databaseId)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    # For internal MATRIXX usage only.
    def queryDatabaseObject(self, objectSearchName, objectSearchValue, flags=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestDatabaseObjectQueryMdcDesc.create()
        search = newObjectSearch(objectSearchName, objectSearchValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDatabaseObjectQueryObjectSearchDataFldKey, search)
        if flags is not None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestDatabaseObjectQueryObjectFlagsFldKey, flags)
        if apiEventData is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    # For internal MATRIXX usage only.
    def traceDatabaseObject(self, objectSearchName, objectSearchValue, objectFlags=None, traceCounter=None):
        requestMdc = MDCDEFS.kMtxRequestDatabaseObjectTraceMdcDesc.create()
        search = newObjectSearch(objectSearchName, objectSearchValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDatabaseObjectTraceObjectSearchDataFldKey, search)
        if objectFlags is not None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestDatabaseObjectTraceObjectFlagsFldKey, objectFlags)
        if traceCounter is not None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestDatabaseObjectTraceTraceCounterFldKey, traceCounter)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    # For internal MATRIXX usage only.
    def queryDatabaseMembership(self, membershipSearchName, membershipSearchValue1, membershipSearchValue2=None,
            queryCursor=None, querySize=None, flags=None):
        requestMdc = MDCDEFS.kMtxRequestDatabaseMembershipQueryMdcDesc.create()
        search = newMembershipSearch(membershipSearchName, membershipSearchValue1, membershipSearchValue2)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDatabaseMembershipQueryMembershipSearchDataFldKey, search)
        if queryCursor != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDatabaseMembershipQueryQueryCursorFldKey, queryCursor)
        if querySize != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestDatabaseMembershipQueryQuerySizeFldKey, querySize)
        if flags is not None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestDatabaseMembershipQueryObjectFlagsFldKey, flags)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    # For internal MATRIXX usage only.
    def deleteDatabaseObject(self, objectSearchName, objectSearchValue, objectVersion, flags=None):
        requestMdc = MDCDEFS.kMtxRequestDatabaseObjectDeleteMdcDesc.create()
        search = newObjectSearch(objectSearchName, objectSearchValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDatabaseObjectDeleteObjectSearchDataFldKey, search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDatabaseObjectDeleteObjectVersionFldKey, objectVersion)
        if flags is not None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestDatabaseObjectDeleteObjectFlagsFldKey, flags)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    # For internal MATRIXX usage only.
    def modifyDatabaseObject(self, objectSearchName, objectSearchValue, objectMdc, objectVersion, flags=None):
        requestMdc = MDCDEFS.kMtxRequestDatabaseObjectModifyMdcDesc.create()
        search = newObjectSearch(objectSearchName, objectSearchValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDatabaseObjectModifyObjectSearchDataFldKey, search)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDatabaseObjectModifyObjectFldKey, objectMdc)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDatabaseObjectModifyObjectVersionFldKey, objectVersion)
        if flags is not None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestDatabaseObjectModifyObjectFlagsFldKey, flags)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    # For internal MATRIXX usage only.
    def quarantineDatabaseObjects(self, objectIdList, routingType=None, routingValue=None):
        requestMdc = MDCDEFS.kMtxRequestDatabaseObjectQuarantineMdcDesc.create()
        requestMdc.setUsingKey(MDCDEFS.kMtxRequestDatabaseObjectQuarantineObjectIdArrayFldKey, objectIdList)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    # For internal MATRIXX usage only.
    def queryDataContainerDefn(self, filterType=None, querySize=None, queryCursor=None,
            routingType=None, routingValue=None):
        requestMdc = MDCDEFS.kMtxRequestSysQueryContainerDefnMdcDesc.create()
        if filterType != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSysQueryContainerDefnFilterTypeFldKey, filterType)
        if querySize != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSysQueryContainerDefnQuerySizeFldKey, querySize)
        if queryCursor != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestSysQueryContainerDefnQueryCursorFldKey, queryCursor)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    # For internal MATRIXX usage only.
    def createBalanceSet(self, balanceSetMdc=None, routingType=None, routingValue=None):
        requestMdc = MDCDEFS.kMtxRequestBalanceSetCreateMdcDesc.create()
        if balanceSetMdc is not None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestBalanceSetCreateBalanceSetFldKey, balanceSetMdc)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    # For internal MATRIXX usage only.
    def queryBalanceSet(self, balanceSetId, routingType=None, routingValue=None):
        requestMdc = MDCDEFS.kMtxRequestBalanceSetQueryMdcDesc.create()
        requestMdc.setUsingKey(MDCDEFS.kMtxRequestBalanceSetQueryBalanceSetIdFldKey, balanceSetId)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    # For internal MATRIXX usage only.
    def deleteBalanceSet(self, balanceSetId, balanceSetVersion, routingType=None, routingValue=None):
        requestMdc = MDCDEFS.kMtxRequestBalanceSetDeleteMdcDesc.create()
        requestMdc.setUsingKey(MDCDEFS.kMtxRequestBalanceSetDeleteBalanceSetIdFldKey, balanceSetId)
        requestMdc.setUsingKey(MDCDEFS.kMtxRequestBalanceSetDeleteBalanceSetVersionFldKey, balanceSetVersion)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    # For internal MATRIXX usage only.
    def modifyBalanceSet(self, balanceSetId, balanceSetEntryList, balanceSetVersion,
            routingType=None, routingValue=None):
        requestMdc = MDCDEFS.kMtxRequestBalanceSetModifyMdcDesc.create()
        requestMdc.setUsingKey(MDCDEFS.kMtxRequestBalanceSetModifyBalanceSetIdFldKey, balanceSetId)
        balanceSetEntryMdcList = []
        for balanceSetEntry in balanceSetEntryList:
            balanceSetEntryMdc = MDCDEFS.kMtxBalanceSetEntryDataMdcDesc.create()
            balanceSetEntryMdc.setUsingKey(MDCDEFS.kMtxBalanceSetEntryDataIdFldKey, balanceSetEntry['Id'])
            if 'GrossAmount' in balanceSetEntry:
                balanceSetEntryMdc.setUsingKey(
                    MDCDEFS.kMtxBalanceSetEntryDataGrossAmountFldKey, balanceSetEntry['GrossAmount'])
            if 'ReservedAmount' in balanceSetEntry:
                balanceSetEntryMdc.setUsingKey(
                    MDCDEFS.kMtxBalanceSetEntryDataReservedAmountFldKey, balanceSetEntry['ReservedAmount'])
            balanceSetEntryMdcList.append(balanceSetEntryMdc)
        requestMdc.setUsingKey(MDCDEFS.kMtxRequestBalanceSetModifyBalanceSetEntryArrayFldKey, balanceSetEntryMdcList)
        requestMdc.setUsingKey(MDCDEFS.kMtxRequestBalanceSetModifyBalanceSetVersionFldKey, balanceSetVersion)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    # For internal MATRIXX usage only.
    def createBalanceSetEntry(self, balanceSetId, balanceSetVersion, balanceSetEntry,
            routingType=None, routingValue=None):
        requestMdc = MDCDEFS.kMtxRequestBalanceSetEntryCreateMdcDesc.create()
        requestMdc.setUsingKey(MDCDEFS.kMtxRequestBalanceSetEntryCreateBalanceSetIdFldKey, balanceSetId)
        if balanceSetEntry is not None:
            balanceSetEntryMdc = MDCDEFS.kMtxBalanceSetEntryDataMdcDesc.create()
            if 'Id' in balanceSetEntry:
                balanceSetEntryMdc.setUsingKey(MDCDEFS.kMtxBalanceSetEntryDataIdFldKey, balanceSetEntry['Id'])
            if 'GrossAmount' in balanceSetEntry:
                balanceSetEntryMdc.setUsingKey(
                    MDCDEFS.kMtxBalanceSetEntryDataGrossAmountFldKey, balanceSetEntry['GrossAmount'])
            if 'ReservedAmount' in balanceSetEntry:
                balanceSetEntryMdc.setUsingKey(
                    MDCDEFS.kMtxBalanceSetEntryDataReservedAmountFldKey, balanceSetEntry['ReservedAmount'])
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestBalanceSetEntryCreateBalanceSetEntryFldKey, balanceSetEntryMdc)
        requestMdc.setUsingKey(MDCDEFS.kMtxRequestBalanceSetEntryCreateBalanceSetVersionFldKey, balanceSetVersion)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    # For internal MATRIXX usage only.
    def deleteBalanceSetEntry(self, balanceSetId, balanceSetEntryId, balanceSetVersion,
            routingType=None, routingValue=None):
        requestMdc = MDCDEFS.kMtxRequestBalanceSetEntryDeleteMdcDesc.create()
        requestMdc.setUsingKey(MDCDEFS.kMtxRequestBalanceSetEntryDeleteBalanceSetIdFldKey, balanceSetId)
        requestMdc.setUsingKey(MDCDEFS.kMtxRequestBalanceSetEntryDeleteBalanceSetEntryIdFldKey, balanceSetEntryId)
        requestMdc.setUsingKey(MDCDEFS.kMtxRequestBalanceSetEntryDeleteBalanceSetVersionFldKey, balanceSetVersion)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def multiRequest(self, requests, now=None, routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestMultiMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestMultiRequestListFldKey, requests)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    # For internal MATRIXX usage only.
    def queryPricingIndex(self, routingType=None, routingValue=None):
        requestMdc = MDCDEFS.kMtxRequestSysQueryPricingIndexMdcDesc.create()
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    # For internal MATRIXX usage only.
    def queryPricingKey(self, key, routingType=None, routingValue=None):
        requestMdc = MDCDEFS.kMtxRequestSysQueryPricingKeyMdcDesc.create()
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSysQueryPricingKeyKeyFldKey, key)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryStatus(self, now=None, routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryStatusMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryCatalogList(self, now=None, routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryCatalogListMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryCatalogItemList(self, now=None, routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryCatalogItemListMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryOfferList(self, now=None, allVersions=False,
            globalList=False, routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryOfferListMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestPricingQueryOfferListAllVersionFldKey, allVersions)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestPricingQueryOfferListGlobalListFldKey, globalList)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def notificationProfileQuery(self, queryType, queryValue, now=None, routingType=None,
                                 routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryNotificationProfileMdcDesc.create()
        search = newPricingNotificationProfileSearch(queryType, queryValue)

        requestMdc.setUsingKey( \
            MDCDEFS.kMtxRequestPricingQueryNotificationProfileNotificationProfileSearchDataFldKey, search)

        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        # search = newPricingOfferSearch(queryType, queryValue)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryCatalog(self, queryType, queryValue,
            now=None, routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryCatalogMdcDesc.create()
        search = newPricingCatalogSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestPricingQueryCatalogCatalogSearchDataFldKey,
            search)

        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryCatalogItem(self, queryType, queryValue, catalogItemTime=None,
            now=None, routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryCatalogItemMdcDesc.create()
        search = newPricingCatalogItemSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestPricingQueryCatalogItemCatalogItemSearchDataFldKey,
            search)

        if catalogItemTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestPricingQueryCatalogItemCatalogItemTimeFldKey,
                catalogItemTime)

        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)

        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryOffer(self, queryType, queryValue, version=None,
            now=None, routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryOfferMdcDesc.create()
        search = newPricingOfferSearch(queryType, queryValue)
        if version != None:
            search.setUsingKey(MDCDEFS.kMtxPricingOfferSearchDataVersionFldKey, version)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestPricingQueryOfferOfferSearchDataFldKey,
            search)

        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryBalanceClassList(self, now=None, routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryBalanceClassListMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryBalanceClass(self, queryType, queryValue, now=None, routingType=None,
                                 routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryBalanceClassMdcDesc.create()
        search = newPricingBalanceClassSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestPricingQueryBalanceClassBalanceClassSearchDataFldKey, search)

        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryBalanceList(self, now=None, routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryBalanceListMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryBalance(self, queryType, queryValue, now=None, routingType=None,
                            routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryBalanceMdcDesc.create()
        search = newPricingBalanceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestPricingQueryBalanceBalanceSearchDataFldKey,
            search)

        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryBalanceThresholdList(self, queryType, queryValue,
            now=None, routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryBalanceThresholdListMdcDesc.create()
        search = newPricingBalanceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestPricingQueryBalanceThresholdListBalanceSearchDataFldKey,
            search)

        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryEventTypeList(self, now=None, routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryEventTypeListMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryEventType(self, queryType, queryValue, now=None, routingType=None,
            routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryEventTypeMdcDesc.create()
        search = newPricingEventTypeSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestPricingQueryEventTypeEventTypeSearchDataFldKey, search)

        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryLifecycle(self, objectType, lifecycleProfileId=None, now=None,
            routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryLifecycleMdcDesc.create()
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestPricingQueryLifecycleObjectTypeFldKey,
            objectType)

        if lifecycleProfileId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestPricingQueryLifecycleLifecycleProfileIdFldKey, lifecycleProfileId)

        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryLifecycleProfileList(self, objectType, lifecycleProfileId=None, now=None,
            routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryLifecycleProfileListMdcDesc.create()
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestPricingQueryLifecycleProfileListObjectTypeFldKey,
            objectType)

        if lifecycleProfileId != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestPricingQueryLifecycleProfileListLifecycleProfileIdFldKey, lifecycleProfileId)

        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryServiceTypeList(self, now=None, routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryServiceTypeListMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryServiceType(self, queryType, queryValue, now=None, routingType=None,
                                routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryServiceTypeMdcDesc.create()
        search = newPricingServiceTypeSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestPricingQueryServiceTypeServiceTypeSearchDataFldKey, search)

        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryServiceContext(self, serviceQueryType, serviceQueryValue, contextQueryType, contextQueryValue,
            now=None, routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryServiceContextMdcDesc.create()
        search = newPricingServiceContextSearch(
            serviceQueryType, serviceQueryValue, contextQueryType, contextQueryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestPricingQueryServiceContextServiceContextSearchDataFldKey, search)

        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryBillingCycleList(self, now=None, routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryBillingCycleListMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryBillingCycle(self, queryType, queryValue, now=None, routingType=None,
                                 routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryBillingCycleMdcDesc.create()
        search = newPricingBillingCycleSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestPricingQueryBillingCycleBillingCycleSearchDataFldKey, search)

        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryTaxClassList(self, now=None, routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryTaxClassListMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryTaxClass(self, queryType, queryValue, now=None, routingType=None,
                             routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryTaxClassMdcDesc.create()
        search = newPricingTaxClassSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestPricingQueryTaxClassTaxClassSearchDataFldKey, search)

        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryRateTagList(self, now=None, routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryRateTagListMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryRateTag(self, queryType, queryValue, now=None, routingType=None,
                            routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryRateTagMdcDesc.create()
        search = newPricingRateTagSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestPricingQueryRateTagRateTagSearchDataFldKey, search)

        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryContractList(self, now=None, routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryContractListMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType,
            routingValue=routingValue)
        return responseMdc

    def pricingQueryContract(self, queryType, queryValue, now=None,
        routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryContractMdcDesc.create()
        search = newPricingContractSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestPricingQueryContractContractSearchDataFldKey, search)

        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType,
            routingValue=routingValue)
        return responseMdc

    def pricingQueryRoleList(self, now=None, routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryRoleListMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryRole(self, queryType, queryValue, now=None, routingType=None,
                         routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryRoleMdcDesc.create()
        search = newPricingRoleSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestPricingQueryRoleRoleSearchDataFldKey, search)

        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryContractEtcScheduleList(self, now=None, routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryContractEtcScheduleListMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryContractEtcSchedule(self, queryType, queryValue, now=None, routingType=None,
                                        routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryContractEtcScheduleMdcDesc.create()
        search = newPricingContractEtcScheduleSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestPricingQueryContractEtcScheduleContractEtcScheduleSearchDataFldKey, search)

        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryContractPaymentScheduleList(self, now=None, routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryContractPaymentScheduleListMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryContractPaymentSchedule(self, queryType, queryValue, now=None, routingType=None,
                                        routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryContractPaymentScheduleMdcDesc.create()
        search = newPricingContractPaymentScheduleSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestPricingQueryContractPaymentScheduleContractPaymentScheduleSearchDataFldKey, search)

        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryTenantList(self, now=None, routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryTenantListMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def pricingQueryTenant(self, queryType, queryValue, now=None, routingType=None,
                                        routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestPricingQueryTenantMdcDesc.create()
        search = newTenantScheduleSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestPricingQueryTenantTenantSearchDataFldKey, search)

        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def taskCreate(self, name, parentTaskId=None, attr=None,
            subscriberQueryType=None, subscriberQueryValue=None,
            groupQueryType=None, groupQueryValue=None,
            userQueryType=None, userQueryValue=None,
            timeoutInSeconds=None, maxRetryCount=None, retryDelayInMinutes=None,
            startTime=None, startTimeOffsetUnit=None, startTimeOffset=None,
            now=None, routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestTaskCreateMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)

        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestTaskCreateNameFldKey, name)
        if parentTaskId is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskCreateParentTaskIdFldKey, parentTaskId)
        if attr is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskCreateAttrFldKey, attr)
        if subscriberQueryType is not None and subscriberQueryValue is not None:
            search = newSubscriberSearch(subscriberQueryType, subscriberQueryValue)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskCreateSubscriberSearchDataFldKey, search)
        if groupQueryType is not None and groupQueryValue is not None:
            search = newGroupSearch(groupQueryType, groupQueryValue)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskCreateGroupSearchDataFldKey, search)
        if userQueryType is not None and userQueryValue is not None:
            search = newUserSearch(userQueryType, userQueryValue)
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskCreateUserSearchDataFldKey, search)
        if timeoutInSeconds is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskCreateTimeoutInSecondsFldKey, timeoutInSeconds)
        if maxRetryCount is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskCreateMaxRetryCountFldKey, maxRetryCount)
        if retryDelayInMinutes is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskCreateRetryDelayInMinutesFldKey, retryDelayInMinutes)
        if startTime is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskCreateStartTimeFldKey, startTime)
        if startTimeOffsetUnit is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskCreateStartTimeOffsetUnitFldKey, startTimeOffsetUnit)
        if startTimeOffset is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskCreateStartTimeOffsetFldKey, startTimeOffset)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def taskDelete(self, queryType, queryValue, sendTaskMsg=None, deleteChildTask=None,
                   apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestTaskDeleteMdcDesc.create()
        search = newTaskSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestTaskDeleteTaskSearchDataFldKey,
            search)
        if sendTaskMsg is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskDeleteSendTaskMsgFldKey, sendTaskMsg)
        if deleteChildTask is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskDeleteDeleteChildTaskFldKey, deleteChildTask)
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def taskModify(self, queryType, queryValue, name=None, parentTaskId=None, attr=None,
            timeoutInSeconds=None, maxRetryCount=None, retryDelayInMinutes=None,
            startTime=None, startTimeExtensionOffsetUnit=None, startTimeExtensionOffset=None,
            status=None, taskResult=None, taskResultText=None, sendTaskMsg=None,
            reason=None, info=None, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestTaskModifyMdcDesc.create()
        search = newTaskSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestTaskModifyTaskSearchDataFldKey,
            search)
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)

        if name is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskModifyNameFldKey, name)
        if parentTaskId is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskModifyParentTaskIdFldKey, parentTaskId)
        if attr is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskModifyAttrFldKey, attr)
        if timeoutInSeconds is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskModifyTimeoutInSecondsFldKey, timeoutInSeconds)
        if maxRetryCount is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskModifyMaxRetryCountFldKey, maxRetryCount)
        if retryDelayInMinutes is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskModifyRetryDelayInMinutesFldKey, retryDelayInMinutes)
        if startTime is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskModifyStartTimeFldKey, startTime)
        if startTimeExtensionOffsetUnit is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskModifyStartTimeExtensionOffsetUnitFldKey, startTimeExtensionOffsetUnit)
        if startTimeExtensionOffset is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskModifyStartTimeExtensionOffsetFldKey, startTimeExtensionOffset)
        if status is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskModifyStatusFldKey, status)
        if taskResult is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskModifyTaskResultFldKey, taskResult)
        if taskResultText is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskModifyTaskResultTextFldKey, taskResultText)
        if sendTaskMsg is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskModifySendTaskMsgFldKey, sendTaskMsg)
        if reason is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskModifyReasonFldKey, reason)
        if info is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestTaskModifyInfoFldKey, info)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc)
        return responseMdc

    def taskQuery(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestTaskQueryMdcDesc.create()
        search = newTaskSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestTaskQueryTaskSearchDataFldKey,
            search)
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    # For internal MATRIXX usage only.
    def notificationCreateBalanceExpiration(self, objectId, resourceId, expirationTime,
        notificationProfileType, notificationProfileOffsetType=None,
        notificationProfileOffset=None, intervalIndex=None, intervalStartTime=None,
        intervalEndTime=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestNotificationCreateBalanceExpirationMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)

        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestNotificationCreateBalanceExpirationObjectIdFldKey,
            objectId)
        # Used for populating TrafficRouteData on base MtxMsg
        search = newObjectSearch("ObjectId", objectId)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestNotificationCreateBalanceExpirationResourceIdFldKey,
            resourceId)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestNotificationCreateBalanceExpirationExpirationTimeFldKey,
            expirationTime)

        # NotificationProfileData
        profileDataMdc = MDCDEFS.kMtxNotificationProfileDataMdcDesc.create()
        profileDataMdc.setUsingKey(MDCDEFS.kMtxNotificationProfileDataTypeFldKey,
            notificationProfileType)
        if notificationProfileOffsetType != None:
            profileDataMdc.setUsingKey(MDCDEFS.kMtxNotificationProfileDataOffsetTypeFldKey,
                notificationProfileOffsetType)
        if notificationProfileOffset != None:
            profileDataMdc.setUsingKey(MDCDEFS.kMtxNotificationProfileDataOffsetFldKey,
                notificationProfileOffset)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestNotificationCreateBalanceExpirationNotificationProfileDataFldKey,
            profileDataMdc)

        if intervalIndex != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestNotificationCreateBalanceExpirationIntervalIndexFldKey,
                intervalIndex)
        if intervalStartTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestNotificationCreateBalanceExpirationIntervalStartTimeFldKey,
                intervalStartTime)
        if intervalEndTime != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestNotificationCreateBalanceExpirationIntervalEndTimeFldKey,
                intervalEndTime)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def eventQuery(self, queryType, queryValue, now=None, routingType=None, routingValue=None,
                   apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestEventQueryMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newEventSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestEventQueryEventSearchDataFldKey, \
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, search, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def executeMulti(self, databaseId, containerKey=None, request=None,
        queryCursor=None, querySize=None, now=None, routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestExecuteMultiMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestExecuteMultiDatabaseIdFldKey, databaseId)
        if containerKey != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestExecuteMultiContainerKeyFldKey, containerKey)
        if request != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestExecuteMultiRequestFldKey, request)
        if queryCursor != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestExecuteMultiQueryCursorFldKey, queryCursor)
        if querySize != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestExecuteMultiQuerySizeFldKey, querySize)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)
        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def groupRehomePrepare(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestGroupRehomePrepareMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)

        search = newGroupSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestGroupRehomePrepareGroupSearchDataFldKey, \
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def subscriberRehomePrepare(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestSubscriberRehomePrepareMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)

        search = newSubscriberSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestSubscriberRehomePrepareSubscriberSearchDataFldKey, \
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def deviceRehomePrepare(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestDeviceRehomePrepareMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)

        search = newDeviceSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDeviceRehomePrepareDeviceSearchDataFldKey, \
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def userRehomePrepare(self, queryType, queryValue, apiEventData=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestUserRehomePrepareMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)

        search = newUserSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestUserRehomePrepareUserSearchDataFldKey, \
            search)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def databaseRehome(self, rehomeCtxList, rehomeDataList, routingType, routingValue, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestDatabaseRehomeMdcDesc.create()

        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDatabaseRehomeRehomeContextListFldKey, rehomeCtxList)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDatabaseRehomeRehomeDataListFldKey, rehomeDataList)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def databaseRehomeCommit(self, rehomeCtxList, routingType, routingValue, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestDatabaseRehomeCommitMdcDesc.create()

        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDatabaseRehomeCommitRehomeContextListFldKey, rehomeCtxList)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def databaseRehomeRollback(self, rehomeCtxList, routingType, routingValue, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestDatabaseRehomeRollbackMdcDesc.create()

        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestDatabaseRehomeRollbackRehomeContextListFldKey, rehomeCtxList)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    # For internal MATRIXX usage only.
    def sysQueryDomain(self, domainId=None):
        requestMdc = MDCDEFS.kMtxRequestSysQueryDomainMdcDesc.create()

        if domainId is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSysQueryDomainDomainIdFldKey, domainId)
        # This method is hardcoded with a RTID0 so that TRA can intercept if necessary.
        responseMdc = self._sendRpcRequest(requestMdc, routingType=ROUTING_TYPE_ROUTE_ID, routingValue='0')
        return responseMdc

    def sysCreateClientToken(self,
            paymentGatewayId=None, paymentGatewayUserId=None, now=None, routingType=None,
            routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestSysCreateClientTokenMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)

        if paymentGatewayId is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSysCreateClientTokenPaymentGatewayIdFldKey, paymentGatewayId)
        if paymentGatewayUserId is not None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestSysCreateClientTokenPaymentGatewayUserIdFldKey, paymentGatewayUserId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    # For internal MATRIXX usage only.
    def sysQueryConfigRecurringRecharge(self):
        requestMdc = MDCDEFS.kMtxRequestSysQueryConfigurationRecurringRechargeMdcDesc.create()

        responseMdc = self._sendRpcRequest(requestMdc)
        return responseMdc

    def streamSessionCreate(self, sessionId, streamCursor=None, now=None, routingType=None,
                            routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestStreamSessionCreateMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)

        requestMdc.setUsingKey(MDCDEFS.kMtxRequestStreamSessionCreateSessionIdFldKey, sessionId)

        if streamCursor is not None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestStreamSessionCreateStreamCursorFldKey, streamCursor)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def streamSessionDelete(self, sessionId, now=None, routingType=None,
                            routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestStreamSessionDeleteMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)

        requestMdc.setUsingKey(MDCDEFS.kMtxRequestStreamSessionDeleteSessionIdFldKey, sessionId)

        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def streamSessionModify(self, sessionId, streamCursor, now=None, routingType=None,
                            routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestStreamSessionModifyMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)

        requestMdc.setUsingKey(MDCDEFS.kMtxRequestStreamSessionModifySessionIdFldKey, sessionId)
        requestMdc.setUsingKey(MDCDEFS.kMtxRequestStreamSessionModifyStreamCursorFldKey, streamCursor)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def streamSessionQuery(self, sessionId, now=None, routingType=None,
                           routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestStreamSessionQueryMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        requestMdc.setUsingKey(MDCDEFS.kMtxRequestStreamSessionQuerySessionIdFldKey, sessionId)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def streamSessionQueryList(self, now=None, routingType=None, routingValue=None, apiEventData=None):
        requestMdc = MDCDEFS.kMtxRequestStreamSessionQueryListMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        if apiEventData != None:
            requestMdc.setUsingKey(
                MDCDEFS.kMtxRequestApiEventDataFldKey,
                apiEventData)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def resourceRegisterCreate(self, serviceName, name, typeVar, extraTimeInSeconds,
                            location=None, metadataList=None, resourceRegisterAttr=None,
                            now=None, routingType=None, routingValue=None):
        requestMdc = MDCDEFS.kMtxRequestResourceRegisterCreateMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)

        requestMdc.setUsingKey(MDCDEFS.kMtxRequestResourceRegisterCreateServiceNameFldKey, serviceName)
        requestMdc.setUsingKey(MDCDEFS.kMtxRequestResourceRegisterCreateNameFldKey, name)
        requestMdc.setUsingKey(MDCDEFS.kMtxRequestResourceRegisterCreateTypeFldKey, typeVar)
        requestMdc.setUsingKey(MDCDEFS.kMtxRequestResourceRegisterCreateExtraTimeInSecondsFldKey, extraTimeInSeconds)
        if location != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestResourceRegisterCreateLocationFldKey, location)
        if metadataList != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestResourceRegisterCreateMetadataListFldKey, metadataList)
        if resourceRegisterAttr != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestResourceRegisterCreateResourceRegisterAttrFldKey,
                    resourceRegisterAttr)

        responseMdc = self._sendRpcRequest(requestMdc, routingType=routingType, routingValue=routingValue)
        return responseMdc

    def resourceRegisterDelete(self, queryType, queryValue, now=None):
        requestMdc = MDCDEFS.kMtxRequestResourceRegisterDeleteMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newResourceRegisterSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestResourceRegisterDeleteResourceRegisterSearchDataFldKey, \
            search)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc

    def resourceRegisterModify(self, queryType, queryValue, extraTimeInSeconds=None,
                               metadataList=None, resourceRegisterAttr=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestResourceRegisterModifyMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newResourceRegisterSearch(queryType, queryValue)
        if extraTimeInSeconds != None:
            requestMdc.setUsingKey(
                       MDCDEFS.kMtxRequestResourceRegisterModifyExtraTimeInSecondsFldKey, extraTimeInSeconds)
        if metadataList != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestResourceRegisterModifyMetadataListFldKey, metadataList)
        if resourceRegisterAttr != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestResourceRegisterModifyResourceRegisterAttrFldKey,
                    resourceRegisterAttr)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestResourceRegisterModifyResourceRegisterSearchDataFldKey, \
            search)
        responseMdc = self._sendRpcRequest(requestMdc, search)
        return responseMdc


    def resourceRegisterQuery(self, queryType, queryValue, now=None):
        requestMdc = MDCDEFS.kMtxRequestResourceRegisterQueryMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey( \
                MDCDEFS.kMtxRequestEventTimeFldKey, now)
        search = newResourceRegisterSearch(queryType, queryValue)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestResourceRegisterQueryResourceRegisterSearchDataFldKey, \
            search)
        responseDetailMdc = self._sendRpcRequest(requestMdc, search)
        return responseDetailMdc


    def resourceRegisterQueryList(self, queryType1, queryValue1, queryType2=None, queryValue2=None,
                                        queryType3=None, queryValue3=None, queryType4=None, queryValue4=None,
                                        queryType5=None, queryValue5=None, now=None):
        requestMdc = MDCDEFS.kMtxRequestResourceRegisterQueryListMdcDesc.create()
        if now != None:
            requestMdc.setUsingKey(MDCDEFS.kMtxRequestEventTimeFldKey, now)
        searchList = newResourceRegisterSearchList(queryType1, queryValue1)
        if queryType2 != None:
            existingResourceRegisterSearchList(searchList, queryType2, queryValue2)
        if queryType3 != None:
            existingResourceRegisterSearchList(searchList, queryType3, queryValue3)
        if queryType4 != None:
            existingResourceRegisterSearchList(searchList, queryType4, queryValue4)
        if queryType5 != None:
            existingResourceRegisterSearchList(searchList, queryType5, queryValue5)
        requestMdc.setUsingKey(
            MDCDEFS.kMtxRequestResourceRegisterQueryListResourceRegisterSearchDataListFldKey, \
            searchList)
        responseDetailListMdc = self._sendRpcRequest(requestMdc, searchList)
        return responseDetailListMdc

#
# Role types
#
ROLE_TYPE_OWNER = 1
ROLE_TYPE_ADMIN = 2
ROLE_TYPE_OBSERVER = 3

#
# Purchase-time purchased item time cycle settings
#
PURCHASED_ITEM_CYCLE_TYPE_BILLING_CYCLE = 1
PURCHASED_ITEM_CYCLE_TYPE_PURCHASE_TIME = 2
PURCHASED_ITEM_CYCLE_TYPE_BALANCE_CYCLE = 3
PURCHASED_ITEM_CYCLE_TYPE_OFFER_CYCLE = 4
PURCHASED_ITEM_CYCLE_TYPE_FIXED_OFFSET = 5
PURCHASED_ITEM_CYCLE_TYPE_CURRENT_TIME = 6
PURCHASED_ITEM_CYCLE_TYPE_PURCHASE_DATE = 7

#
# Purchased offer status
#
STATUS_OFFER_ACTIVE = 1
STATUS_OFFER_IN_CANCELATION = 2
STATUS_OFFER_INACTIVE = 3
STATUS_OFFER_SUSPENDED = 4
STATUS_OFFER_PREACTIVE = 5
STATUS_OFFER_GRACE = 6
STATUS_OFFER_RECOVERABLE = 7

#
# Purchased offer status value (based on default offer lifecycle profile)
#
OFFER_STATUS_VALUE_ACTIVE = 1
OFFER_STATUS_VALUE_IN_CANCELATION = 2
OFFER_STATUS_VALUE_INACTIVE = 3
OFFER_STATUS_VALUE_SUSPENDED = 4
OFFER_STATUS_VALUE_PRE_ACTIVE = 5
OFFER_STATUS_VALUE_GRACE = 6
OFFER_STATUS_VALUE_RECOVERABLE = 7
OFFER_STATUS_VALUE_SUSPENDED_GRACE = 8
OFFER_STATUS_VALUE_SUSPENDED_RECOVERABLE = 9
OFFER_STATUS_VALUE_SUSPENDED_PRE_ACTIVE = 10

#
# Purchased offer status class
#
OFFER_STATUS_CLASS_ACTIVE = 1
OFFER_STATUS_CLASS_IN_CANCELATION = 2
OFFER_STATUS_CLASS_INACTIVE = 3
OFFER_STATUS_CLASS_SUSPENDED = 4
OFFER_STATUS_CLASS_PRE_ACTIVE = 5
OFFER_STATUS_CLASS_GRACE = 6
OFFER_STATUS_CLASS_RECOVERABLE = 7

#
# Pricing offer type
#
PRICING_OFFER_TYPE_BASE = 1
PRICING_OFFER_TYPE_OVERRIDE = 2
PRICING_OFFER_TYPE_SUPPLEMENTAL = 3

#
# Pricing lifecycle object type
#
PRICING_LIFECYCLE_TYPE_DEVICE = 1
PRICING_LIFECYCLE_TYPE_SUBSCRIBER = 2
PRICING_LIFECYCLE_TYPE_GROUP = 3
PRICING_LIFECYCLE_TYPE_USER = 4
PRICING_LIFECYCLE_TYPE_ACCOUNT = 5
PRICING_LIFECYCLE_TYPE_OFFER = 6

#
# Balance adjustment types
#
BALANCE_ADJUST_TYPE_CREDIT = 1
BALANCE_ADJUST_TYPE_DEBIT = 2
BALANCE_ADJUST_TYPE_RESET = 3

#
# Lifecycle object types
#
OBJECT_TYPE_DEVICE = 1
OBJECT_TYPE_SUBSCRIBER = 2
OBJECT_TYPE_GROUP = 3

#
# Raw DB query flags
#
DB_OBJECT_QUERY_QUARANTINED_OK = 1

#
# Raw DB modify flags
#
DB_OBJECT_MODIFY_QUARANTINE = 1
DB_OBJECT_MODIFY_UNQUARANTINE = 2

#
# Raw DB delete flags
#
DB_OBJECT_DELETE_QUARANTINED_OK = 1

#
# Subscriber membership query types
#
SUBSCRIBER_QUERY_MEMBER_TYPE_PARENT_GROUPS = 1
SUBSCRIBER_QUERY_MEMBER_TYPE_ADMIN_GROUPS = 2
SUBSCRIBER_QUERY_MEMBER_TYPE_USERS = 3

#
# Group membership query types
#
GROUP_QUERY_MEMBER_TYPE_SUBSCRIBERS = 1
GROUP_QUERY_MEMBER_TYPE_SUBGROUPS = 2
GROUP_QUERY_MEMBER_TYPE_ADMINS = 3
GROUP_QUERY_MEMBER_TYPE_USERS = 4

#
# User membership query types
#
USER_QUERY_MEMBER_TYPE_SUBSCRIPTIONS = 1
USER_QUERY_MEMBER_TYPE_GROUPS = 2

#
# Group notification preference
#
GROUP_NOTIFICATION_PREF_ADMINS = 1
GROUP_NOTIFICATION_PREF_MEMBERS = 2

#
# Purchase payment method type
#
PURCHASE_PAYMENT_METHOD_TYPE_ON_ACCOUNT = 1
PURCHASE_PAYMENT_METHOD_TYPE_PAY_NOW = 2
PURCHASE_PAYMENT_METHOD_TYPE_SPLIT = 3

#
# Offer cancel types
#
OFFER_CANCEL_TYPE_IMMEDIATE = 1
OFFER_CANCEL_TYPE_BILL_CYCLE = 2
OFFER_CANCEL_TYPE_BALANCE_CYCLE = 3
OFFER_CANCEL_TYPE_PURCHASED_ITEM_CYCLE = 4

#
# Offer cancel proration types
#
OFFER_CANCEL_PRORATION_TYPE_NONE = 0
OFFER_CANCEL_PRORATION_TYPE_FULL_AMOUNT = 1
OFFER_CANCEL_PRORATION_TYPE_NO_AMOUNT = 2
OFFER_CANCEL_PRORATION_TYPE_SCALED = 3
OFFER_CANCEL_PRORATION_TYPE_CONSUMPTION_BASED = 4
OFFER_CANCEL_PRORATION_TYPE_FORFEITURE_BASED = 5

#
# Offer cancel modes
# Note: the CONTRACT_OFFER_CANCEL_MODE enums are to be deprecated; use the
#   DEBT_CANCELLATION_MODE enums instead.
CONTRACT_OFFER_CANCEL_MODE_PAY_ALL = 1
CONTRACT_OFFER_CANCEL_MODE_PAY_AND_WRITE_OFF = 2
CONTRACT_OFFER_CANCEL_MODE_WRITE_OFF_ALL = 3
CONTRACT_OFFER_CANCEL_MODE_PAY_NONE = 4
# Debt cancellation modes
DEBT_CANCELLATION_MODE_PAY_ALL = 1
DEBT_CANCELLATION_MODE_PAY_AND_WRITE_OFF = 2
DEBT_CANCELLATION_MODE_WRITE_OFF_ALL = 3
DEBT_CANCELLATION_MODE_PAY_NONE = 4

# PaymentRequestStatusType
PAYMENT_REQUEST_STATUS_TYPE_DUE = 1
PAYMENT_REQUEST_STATUS_TYPE_PENDING = 2
PAYMENT_REQUEST_STATUS_TYPE_PAID = 3
PAYMENT_REQUEST_STATUS_TYPE_WRITTEN_OFF = 4

#
# Return codes. Subset of values defined in MtxUtil/Err.h
#
RC_SUCCESS = 0
RC_BAD_DATA = 10
RC_NOT_FOUND = 11
RC_DUPLICATE = 19
RC_WRONG_TYPE = 21
RC_EXCEPTION = 25
RC_NO_MEMORY = 26
RC_LOGIC_ERROR = 28
RC_PERM_DENIED = 33
RC_CREDIT_LIMIT_REACHED = 38
RC_NOT_SUPPORTED = 40
RC_QUARANTINED_OBJECT = 41
RC_PAYMENT_AUTHORIZATION_FAILED = 52
RC_BALANCE_FLOOR_REACHED = 81
RC_PAYMENT_VALIDATION_FAILED = 94
#
# Routing data types
#
ROUTING_TYPE_ROUTE_ID = "RTID"
ROUTING_TYPE_OBJECT_ID = "OBID"
ROUTING_TYPE_EXTERNAL_ID = "EXID"
ROUTING_TYPE_IMSI = "IMSI"
ROUTING_TYPE_ACCESS_NUMBER = "ACNM"
ROUTING_TYPE_LOGIN_ID = "LOGN"
ROUTING_TYPE_ACCESS_ID = "ACID"
ROUTING_TYPE_SESSION_ID = "SESS"
ROUTING_TYPES = [
    ROUTING_TYPE_ROUTE_ID,
    ROUTING_TYPE_OBJECT_ID,
    ROUTING_TYPE_EXTERNAL_ID,
    ROUTING_TYPE_IMSI,
    ROUTING_TYPE_ACCESS_NUMBER,
    ROUTING_TYPE_LOGIN_ID,
    ROUTING_TYPE_ACCESS_ID,
    ROUTING_TYPE_SESSION_ID
]

# Optional deferred action overrides passed in to purchase
DEFERRED_SETTLEMENT_TIMEOUT_ACTION_VOID = 1
DEFERRED_SETTLEMENT_TIMEOUT_ACTION_SETTLE = 2

# Payment status types (in payment query response)
PAYMENT_STATUS_AUTHORIZED = 1
PAYMENT_STATUS_SETTLED = 2
PAYMENT_STATUS_VOIDED = 3

def checkResultSuccess(responseMdc):
    if responseMdc is None:
        return False
    if not responseMdc.isPresent(MDCDEFS.kMtxResponseResultFldKey):
        return False
    retCode = responseMdc.getUsingKey(MDCDEFS.kMtxResponseResultFldKey)
    if retCode != RC_SUCCESS:
        return False
    return True

def getResultStatus(responseMdc):
    if responseMdc is None:
        return (RC_EXCEPTION, '<NoRespMDC>')
    retCode = responseMdc.getUsingKey(MDCDEFS.kMtxResponseResultFldKey)
    retText = responseMdc.getUsingKey(MDCDEFS.kMtxResponseResultTextFldKey)
    if retText is None:
        retText = "<None>"
    return (retCode, retText)

def getResultStatusString(responseMdc):
    (retCode, retText) = getResultStatus(responseMdc)
    return retText + " [" + str(retCode) + "]"

def newSubscriptionSearch(subscriptionSearchName, subscriptionSearchId):
    subscriptionSearch = MDCDEFS.kMtxSubscriptionSearchDataMdcDesc.create()
    if (subscriptionSearchName == 'ObjectId'):
        subscriptionSearch.setUsingKey(
            MDCDEFS.kMtxSubscriptionSearchDataObjectIdFldKey, subscriptionSearchId)
    elif (subscriptionSearchName == 'ExternalId'):
        subscriptionSearch.setUsingKey(
            MDCDEFS.kMtxSubscriptionSearchDataExternalIdFldKey, subscriptionSearchId)
    elif (subscriptionSearchName == 'PhoneNumber'):
        # TODO: DEVICE_MODEL - remove PhoneNumber lookup key
        subscriptionSearch.setUsingKey(
            MDCDEFS.kMtxSubscriptionSearchDataImsiFldKey, subscriptionSearchId)
    elif (subscriptionSearchName == 'Imsi'):
        subscriptionSearch.setUsingKey(
            MDCDEFS.kMtxSubscriptionSearchDataImsiFldKey, subscriptionSearchId)
    elif (subscriptionSearchName == 'AccessNumber'):
        subscriptionSearch.setUsingKey(
            MDCDEFS.kMtxSubscriptionSearchDataAccessNumberFldKey, subscriptionSearchId)
    elif (subscriptionSearchName == 'LoginId'):
        subscriptionSearch.setUsingKey(
            MDCDEFS.kMtxSubscriptionSearchDataLoginIdFldKey, subscriptionSearchId)
    elif (subscriptionSearchName == 'AccessId'):
        subscriptionSearch.setUsingKey(
            MDCDEFS.kMtxSubscriptionSearchDataAccessIdFldKey, subscriptionSearchId)
    elif (subscriptionSearchName == 'MultiRequestIndex'):
        subscriptionSearch.setUsingKey(
            MDCDEFS.kMtxSubscriptionSearchDataMultiRequestIndexFldKey, subscriptionSearchId)
    else:
        raise RuntimeError('Unknown subscriptionSearchName: ' + str(subscriptionSearchName))

    return subscriptionSearch

def addSubscriptionRoutingData(message, subscriptionSearch):
    searchType = None
    searchTerm = None
    if (subscriptionSearch.isPresent(MDCDEFS.kMtxSubscriptionSearchDataObjectIdFldKey)):
        searchType = "OBID"
        searchTerm = subscriptionSearch.getUsingKey(MDCDEFS.kMtxSubscriptionSearchDataObjectIdFldKey)
    elif (subscriptionSearch.isPresent(MDCDEFS.kMtxSubscriptionSearchDataExternalIdFldKey)):
        searchType = "EXID"
        searchTerm = subscriptionSearch.getUsingKey(MDCDEFS.kMtxSubscriptionSearchDataExternalIdFldKey)
    elif (subscriptionSearch.isPresent(MDCDEFS.kMtxSubscriptionSearchDataImsiFldKey)):
        searchType = "IMSI"
        searchTerm = subscriptionSearch.getUsingKey(MDCDEFS.kMtxSubscriptionSearchDataImsiFldKey)
    elif (subscriptionSearch.isPresent(MDCDEFS.kMtxSubscriptionSearchDataAccessNumberFldKey)):
        searchType = "ACNM"
        searchTerm = subscriptionSearch.getUsingKey(MDCDEFS.kMtxSubscriptionSearchDataAccessNumberFldKey)
    elif (subscriptionSearch.isPresent(MDCDEFS.kMtxSubscriptionSearchDataLoginIdFldKey)):
        searchType = "LOGN"
        searchTerm = subscriptionSearch.getUsingKey(MDCDEFS.kMtxSubscriptionSearchDataLoginIdFldKey)
    elif (subscriptionSearch.isPresent(MDCDEFS.kMtxSubscriptionSearchDataAccessIdFldKey)):
        searchType = "ACID"
        searchTerm = subscriptionSearch.getUsingKey(MDCDEFS.kMtxSubscriptionSearchDataAccessIdFldKey)
    elif (subscriptionSearch.isPresent(MDCDEFS.kMtxSubscriptionSearchDataMultiRequestIndexFldKey)):
        # Multi-request routing data should be supplied in the multiRequest invocation
        return
    else:
        raise RuntimeError('Invalid SubscriptionSearchData: ' + str(subscriptionSearch))

    message.setUsingKey(MDCDEFS.kMtxMsgTrafficRouteDataFldKey, searchType + str(searchTerm))
    return

def newSubscriberSearch(subscriberSearchName, subscriberSearchId):
    subscriberSearch = MDCDEFS.kMtxSubscriberSearchDataMdcDesc.create()
    if (subscriberSearchName == 'ObjectId'):
        subscriberSearch.setUsingKey(
            MDCDEFS.kMtxSubscriberSearchDataObjectIdFldKey, subscriberSearchId)
    elif (subscriberSearchName == 'ExternalId'):
        subscriberSearch.setUsingKey(
            MDCDEFS.kMtxSubscriberSearchDataExternalIdFldKey, subscriberSearchId)
    elif (subscriberSearchName == 'PhoneNumber'):
        # TODO: DEVICE_MODEL - remove PhoneNumber lookup key
        subscriberSearch.setUsingKey(
            MDCDEFS.kMtxSubscriberSearchDataImsiFldKey, subscriberSearchId)
    elif (subscriberSearchName == 'Imsi'):
        subscriberSearch.setUsingKey(
            MDCDEFS.kMtxSubscriberSearchDataImsiFldKey, subscriberSearchId)
    elif (subscriberSearchName == 'AccessNumber'):
        subscriberSearch.setUsingKey(
            MDCDEFS.kMtxSubscriberSearchDataAccessNumberFldKey, subscriberSearchId)
    elif (subscriberSearchName == 'LoginId'):
        subscriberSearch.setUsingKey(
            MDCDEFS.kMtxSubscriberSearchDataLoginIdFldKey, subscriberSearchId)
    elif (subscriberSearchName == 'AccessId'):
        subscriberSearch.setUsingKey(
            MDCDEFS.kMtxSubscriberSearchDataAccessIdFldKey, subscriberSearchId)
    elif (subscriberSearchName == 'MultiRequestIndex'):
        subscriberSearch.setUsingKey(
            MDCDEFS.kMtxSubscriberSearchDataMultiRequestIndexFldKey, subscriberSearchId)
    else:
        raise RuntimeError('Unknown subscriberSearchName: ' + str(subscriberSearchName))

    return subscriberSearch

def newServiceAddressData(streetAddr=None, extendedAddr=None, locality=None,
        region=None, postalCode=None, extendedPostalCode=None, countryCode=None):
    serviceAddrDataMdc = MDCDEFS.kMtxServiceAddressDataMdcDesc.create()
    if streetAddr != None:
        serviceAddrDataMdc.setUsingKey(
            MDCDEFS.kMtxServiceAddressDataStreetAddressFldKey, streetAddr)
    if extendedAddr != None:
        serviceAddrDataMdc.setUsingKey(
            MDCDEFS.kMtxServiceAddressDataExtendedAddressFldKey, extendedAddr)
    if locality != None:
        serviceAddrDataMdc.setUsingKey(
            MDCDEFS.kMtxServiceAddressDataLocalityFldKey, locality)
    if region != None:
        serviceAddrDataMdc.setUsingKey(
            MDCDEFS.kMtxServiceAddressDataRegionFldKey, region)
    if postalCode != None:
        serviceAddrDataMdc.setUsingKey(
            MDCDEFS.kMtxServiceAddressDataPostalCodeFldKey, postalCode)
    if extendedPostalCode != None:
        serviceAddrDataMdc.setUsingKey(
            MDCDEFS.kMtxServiceAddressDataExtendedPostalCodeFldKey, extendedPostalCode)
    if countryCode != None:
        serviceAddrDataMdc.setUsingKey(
            MDCDEFS.kMtxServiceAddressDataCountryCodeFldKey, countryCode)
    return serviceAddrDataMdc

def newPaymentMethodValidationData(postalCode=None):
    paymentMethodValidationData = MDCDEFS.kMtxPaymentMethodValidationDataMdcDesc.create()
    addressData = MDCDEFS.kMtxAddressDataMdcDesc.create()
    paymentMethodValidationData.setUsingKey(MDCDEFS.kMtxPaymentMethodValidationDataAddressDataFldKey, addressData)
    if (postalCode != None):
        addressData.setUsingKey(MDCDEFS.kMtxAddressDataPostalCodeFldKey, postalCode)

    return paymentMethodValidationData

def addSubscriberRoutingData(message, subscriberSearch):
    searchType = None
    searchTerm = None
    if (subscriberSearch.isPresent(MDCDEFS.kMtxSubscriberSearchDataObjectIdFldKey)):
        searchType = "OBID"
        searchTerm = subscriberSearch.getUsingKey(MDCDEFS.kMtxSubscriberSearchDataObjectIdFldKey)
    elif (subscriberSearch.isPresent(MDCDEFS.kMtxSubscriberSearchDataExternalIdFldKey)):
        searchType = "EXID"
        searchTerm = subscriberSearch.getUsingKey(MDCDEFS.kMtxSubscriberSearchDataExternalIdFldKey)
    elif (subscriberSearch.isPresent(MDCDEFS.kMtxSubscriberSearchDataImsiFldKey)):
        searchType = "IMSI"
        searchTerm = subscriberSearch.getUsingKey(MDCDEFS.kMtxSubscriberSearchDataImsiFldKey)
    elif (subscriberSearch.isPresent(MDCDEFS.kMtxSubscriberSearchDataAccessNumberFldKey)):
        searchType = "ACNM"
        searchTerm = subscriberSearch.getUsingKey(MDCDEFS.kMtxSubscriberSearchDataAccessNumberFldKey)
    elif (subscriberSearch.isPresent(MDCDEFS.kMtxSubscriberSearchDataLoginIdFldKey)):
        searchType = "LOGN"
        searchTerm = subscriberSearch.getUsingKey(MDCDEFS.kMtxSubscriberSearchDataLoginIdFldKey)
    elif (subscriberSearch.isPresent(MDCDEFS.kMtxSubscriberSearchDataAccessIdFldKey)):
        searchType = "ACID"
        searchTerm = subscriberSearch.getUsingKey(MDCDEFS.kMtxSubscriberSearchDataAccessIdFldKey)
    elif (subscriberSearch.isPresent(MDCDEFS.kMtxSubscriberSearchDataMultiRequestIndexFldKey)):
        # Multi-request routing data should be supplied in the multiRequest invocation
        return
    else:
        raise RuntimeError('Invalid SubscriberSearchData: ' + str(subscriberSearch))

    message.setUsingKey(MDCDEFS.kMtxMsgTrafficRouteDataFldKey, searchType + str(searchTerm))
    return

def newGroupSearch(groupSearchName, groupSearchId):
    groupSearch = MDCDEFS.kMtxGroupSearchDataMdcDesc.create()
    if (groupSearchName == 'ObjectId'):
        groupSearch.setUsingKey(
            MDCDEFS.kMtxGroupSearchDataObjectIdFldKey, groupSearchId)
    elif (groupSearchName == 'ExternalId'):
        groupSearch.setUsingKey(
            MDCDEFS.kMtxGroupSearchDataExternalIdFldKey, groupSearchId)
    elif (groupSearchName == 'MultiRequestIndex'):
        groupSearch.setUsingKey(
            MDCDEFS.kMtxGroupSearchDataMultiRequestIndexFldKey, groupSearchId)
    else:
        raise RuntimeError('Unknown groupSearchName: ' + str(groupSearchName))

    return groupSearch

def addGroupRoutingData(message, groupSearch):
    searchType = None
    searchTerm = None
    if (groupSearch.isPresent(MDCDEFS.kMtxGroupSearchDataObjectIdFldKey)):
        searchType = "OBID"
        searchTerm = groupSearch.getUsingKey(MDCDEFS.kMtxGroupSearchDataObjectIdFldKey)
    elif (groupSearch.isPresent(MDCDEFS.kMtxGroupSearchDataExternalIdFldKey)):
        searchType = "EXID"
        searchTerm = groupSearch.getUsingKey(MDCDEFS.kMtxGroupSearchDataExternalIdFldKey)
    elif (groupSearch.isPresent(MDCDEFS.kMtxGroupSearchDataMultiRequestIndexFldKey)):
        # Multi-request routing data should be supplied in the multiRequest invocation
        return
    else:
        raise RuntimeError('Invalid GroupSearchData: ' + str(groupSearch))

    message.setUsingKey(MDCDEFS.kMtxMsgTrafficRouteDataFldKey, searchType + str(searchTerm))
    return

def newDeviceSearch(deviceSearchName, deviceSearchId):
    deviceSearch = MDCDEFS.kMtxDeviceSearchDataMdcDesc.create()
    if (deviceSearchName == 'ObjectId'):
        deviceSearch.setUsingKey(
            MDCDEFS.kMtxDeviceSearchDataObjectIdFldKey, deviceSearchId)
    elif (deviceSearchName == 'ExternalId'):
        deviceSearch.setUsingKey(
            MDCDEFS.kMtxDeviceSearchDataExternalIdFldKey, deviceSearchId)
    elif (deviceSearchName == 'PhoneNumber'):
        # TODO: DEVICE_MODEL - remove PhoneNumber lookup key
        deviceSearch.setUsingKey(
            MDCDEFS.kMtxDeviceSearchDataImsiFldKey, deviceSearchId)
    elif (deviceSearchName == 'Imsi'):
        deviceSearch.setUsingKey(
            MDCDEFS.kMtxDeviceSearchDataImsiFldKey, deviceSearchId)
    elif (deviceSearchName == 'AccessNumber'):
        deviceSearch.setUsingKey(
            MDCDEFS.kMtxDeviceSearchDataAccessNumberFldKey, deviceSearchId)
    elif (deviceSearchName == 'LoginId'):
        deviceSearch.setUsingKey(
            MDCDEFS.kMtxDeviceSearchDataLoginIdFldKey, deviceSearchId)
    elif (deviceSearchName == 'AccessId'):
        deviceSearch.setUsingKey(
            MDCDEFS.kMtxDeviceSearchDataAccessIdFldKey, deviceSearchId)
    elif (deviceSearchName == 'MultiRequestIndex'):
        deviceSearch.setUsingKey(
            MDCDEFS.kMtxDeviceSearchDataMultiRequestIndexFldKey, deviceSearchId)
    else:
        raise RuntimeError('Unknown deviceSearchName: ' + str(deviceSearchName))

    return deviceSearch

def addDeviceRoutingData(message, deviceSearch):
    searchType = None
    searchTerm = None
    if (deviceSearch.isPresent(MDCDEFS.kMtxDeviceSearchDataObjectIdFldKey)):
        searchType = "OBID"
        searchTerm = deviceSearch.getUsingKey(MDCDEFS.kMtxDeviceSearchDataObjectIdFldKey)
    elif (deviceSearch.isPresent(MDCDEFS.kMtxDeviceSearchDataExternalIdFldKey)):
        searchType = "EXID"
        searchTerm = deviceSearch.getUsingKey(MDCDEFS.kMtxDeviceSearchDataExternalIdFldKey)
    elif (deviceSearch.isPresent(MDCDEFS.kMtxDeviceSearchDataImsiFldKey)):
        searchType = "IMSI"
        searchTerm = deviceSearch.getUsingKey(MDCDEFS.kMtxDeviceSearchDataImsiFldKey)
    elif (deviceSearch.isPresent(MDCDEFS.kMtxDeviceSearchDataAccessNumberFldKey)):
        searchType = "ACNM"
        searchTerm = deviceSearch.getUsingKey(MDCDEFS.kMtxDeviceSearchDataAccessNumberFldKey)
    elif (deviceSearch.isPresent(MDCDEFS.kMtxDeviceSearchDataLoginIdFldKey)):
        searchType = "LOGN"
        searchTerm = deviceSearch.getUsingKey(MDCDEFS.kMtxDeviceSearchDataLoginIdFldKey)
    elif (deviceSearch.isPresent(MDCDEFS.kMtxDeviceSearchDataAccessIdFldKey)):
        searchType = "ACID"
        searchTerm = deviceSearch.getUsingKey(MDCDEFS.kMtxDeviceSearchDataAccessIdFldKey)
    elif (deviceSearch.isPresent(MDCDEFS.kMtxDeviceSearchDataMultiRequestIndexFldKey)):
        # Multi-request routing data should be supplied in the multiRequest invocation
        return
    else:
        raise RuntimeError('Invalid DeviceSearchData: ' + str(deviceSearch))

    message.setUsingKey(MDCDEFS.kMtxMsgTrafficRouteDataFldKey, searchType + str(searchTerm))
    return

def newUserSearch(userSearchName, userSearchId):
    userSearch = MDCDEFS.kMtxUserSearchDataMdcDesc.create()
    if (userSearchName.startswith('Subscription')):
        subscriptionSearch = newSubscriptionSearch(userSearchName[12:], userSearchId)
        userSearch.setUsingKey(
            MDCDEFS.kMtxUserSearchDataSubscriptionSearchDataFldKey, subscriptionSearch)
    elif (userSearchName.startswith('Group')):
        groupSearch = newGroupSearch(userSearchName[5:], userSearchId)
        userSearch.setUsingKey(
            MDCDEFS.kMtxUserSearchDataGroupSearchDataFldKey, groupSearch)
    elif (userSearchName == 'ObjectId'):
        userSearch.setUsingKey(
            MDCDEFS.kMtxUserSearchDataObjectIdFldKey, userSearchId)
    elif (userSearchName == 'UserId'):
        userSearch.setUsingKey(
            MDCDEFS.kMtxUserSearchDataUserIdFldKey, userSearchId)
    elif (userSearchName == 'ExternalId'):
        userSearch.setUsingKey(
            MDCDEFS.kMtxUserSearchDataExternalIdFldKey, userSearchId)
    elif (userSearchName == 'MultiRequestIndex'):
        userSearch.setUsingKey(
            MDCDEFS.kMtxUserSearchDataMultiRequestIndexFldKey, userSearchId)
    else:
        raise RuntimeError('Unknown userSearchName: ' + str(userSearchName))

    return userSearch

def addUserRoutingData(message, userSearch):
    searchType = None
    searchTerm = None
    if (userSearch.isPresent(MDCDEFS.kMtxUserSearchDataSubscriptionSearchDataFldKey)):
        subscriptionSearchData = userSearch.getUsingKey(MDCDEFS.kMtxUserSearchDataSubscriptionSearchDataFldKey)
        addSubscriptionRoutingData(message, subscriptionSearchData)
        return
    elif (userSearch.isPresent(MDCDEFS.kMtxUserSearchDataGroupSearchDataFldKey)):
        groupSearchData = userSearch.getUsingKey(MDCDEFS.kMtxUserSearchDataGroupSearchDataFldKey)
        addGroupRoutingData(message, groupSearchData)
        return
    elif (userSearch.isPresent(MDCDEFS.kMtxUserSearchDataObjectIdFldKey)):
        searchType = "OBID"
        searchTerm = userSearch.getUsingKey(MDCDEFS.kMtxUserSearchDataObjectIdFldKey)
    elif (userSearch.isPresent(MDCDEFS.kMtxUserSearchDataUserIdFldKey)):
        searchType = "USID"
        searchTerm = userSearch.getUsingKey(MDCDEFS.kMtxUserSearchDataUserIdFldKey)
    elif (userSearch.isPresent(MDCDEFS.kMtxUserSearchDataExternalIdFldKey)):
        searchType = "EXID"
        searchTerm = userSearch.getUsingKey(MDCDEFS.kMtxUserSearchDataExternalIdFldKey)
    elif (userSearch.isPresent(MDCDEFS.kMtxUserSearchDataMultiRequestIndexFldKey)):
        # Multi-request routing data should be supplied in the multiRequest invocation
        return
    else:
        raise RuntimeError('Invalid UserSearchData: ' + str(userSearch))

    message.setUsingKey(MDCDEFS.kMtxMsgTrafficRouteDataFldKey, searchType + str(searchTerm))
    return

def newAccountSearch(accountSearchName, accountSearchId):
    accountSearch = MDCDEFS.kMtxAccountSearchDataMdcDesc.create()
    # AMORAN TODO: support this; also for groups?
    # if (accountSearchName.startswith('Subscription')):
    #     subscriptionSearch = newSubscriptionSearch(accountSearchName[12:], accountSearchId)
    #     accountSearch.setUsingKey(
    #         MDCDEFS.kMtxAccountSearchDataSubscriptionSearchDataFldKey, subscriptionSearch)
    if (accountSearchName == 'ObjectId'):
        accountSearch.setUsingKey(
            MDCDEFS.kMtxAccountSearchDataObjectIdFldKey, accountSearchId)
    elif (accountSearchName == 'ExternalId'):
        accountSearch.setUsingKey(
            MDCDEFS.kMtxAccountSearchDataExternalIdFldKey, accountSearchId)
    elif (accountSearchName == 'MultiRequestIndex'):
        accountSearch.setUsingKey(
            MDCDEFS.kMtxAccountSearchDataMultiRequestIndexFldKey, accountSearchId)
    else:
        raise RuntimeError('Unknown accountSearchName: ' + str(accountSearchName))

    return accountSearch

def addAccountRoutingData(message, accountSearch):
    searchType = None
    searchTerm = None
    # AMORAN TODO: support this; also for groups?
    # if (accountSearch.isPresent(MDCDEFS.kMtxAccountSearchDataSubscriptionSearchDataFldKey)):
    #     subscriptionSearchData = accountSearch.getUsingKey(MDCDEFS.kMtxAccountSearchDataSubscriptionSearchDataFldKey)
    #     addSubscriptionRoutingData(message, subscriptionSearchData)
    #     return
    if (accountSearch.isPresent(MDCDEFS.kMtxAccountSearchDataObjectIdFldKey)):
        searchType = "OBID"
        searchTerm = accountSearch.getUsingKey(MDCDEFS.kMtxAccountSearchDataObjectIdFldKey)
    elif (accountSearch.isPresent(MDCDEFS.kMtxAccountSearchDataExternalIdFldKey)):
        searchType = "EXID"
        searchTerm = accountSearch.getUsingKey(MDCDEFS.kMtxAccountSearchDataExternalIdFldKey)
    elif (accountSearch.isPresent(MDCDEFS.kMtxAccountSearchDataMultiRequestIndexFldKey)):
        # Multi-request routing data should be supplied in the multiRequest invocation
        return
    else:
        raise RuntimeError('Invalid AccountSearchData: ' + str(accountSearch))

    message.setUsingKey(MDCDEFS.kMtxMsgTrafficRouteDataFldKey, searchType + str(searchTerm))
    return

def newPricingNotificationProfileSearch(profileSearchName, profileSearchId):
    profileSearch = MDCDEFS.kMtxPricingNotificationProfileSearchDataMdcDesc.create()
    if (profileSearchName == 'NotificationProfileId'):
        profileSearch.setUsingKey(
            MDCDEFS.kMtxPricingNotificationProfileSearchDataNotificationProfileIdFldKey, profileSearchId)
    else:
        raise RuntimeError('Unknown profileSearchName: ' + str(profileSearchName))

    return profileSearch

def newPricingCatalogSearch(catalogSearchName, catalogSearchId):
    catalogSearch = MDCDEFS.kMtxPricingCatalogSearchDataMdcDesc.create()
    if (catalogSearchName == 'CatalogId'):
        catalogSearch.setUsingKey(
            MDCDEFS.kMtxPricingCatalogSearchDataCatalogIdFldKey, catalogSearchId)
    elif (catalogSearchName == 'ExternalId'):
        catalogSearch.setUsingKey(
            MDCDEFS.kMtxPricingCatalogSearchDataExternalIdFldKey, catalogSearchId)
    else:
        raise RuntimeError('Unknown catalogSearchName: ' + str(catalogSearchName))

    return catalogSearch

def newPricingCatalogItemSearch(catalogItemSearchName, catalogItemSearchId):
    catalogItemSearch = MDCDEFS.kMtxPricingCatalogItemSearchDataMdcDesc.create()
    if (catalogItemSearchName == 'CatalogItemId'):
        catalogItemSearch.setUsingKey(
            MDCDEFS.kMtxPricingCatalogItemSearchDataCatalogItemIdFldKey, catalogItemSearchId)
    elif (catalogItemSearchName == 'ExternalId'):
        catalogItemSearch.setUsingKey(
            MDCDEFS.kMtxPricingCatalogItemSearchDataExternalIdFldKey, catalogItemSearchId)
    else:
        raise RuntimeError('Unknown catalogItemSearchName: ' + str(catalogItemSearchName))

    return catalogItemSearch

def newPricingOfferSearch(offerSearchName, offerSearchId):
    offerSearch = MDCDEFS.kMtxPricingOfferSearchDataMdcDesc.create()
    if (offerSearchName == 'OfferId'):
        offerSearch.setUsingKey(
            MDCDEFS.kMtxPricingOfferSearchDataOfferIdFldKey, offerSearchId)
    elif (offerSearchName == 'ExternalId'):
        offerSearch.setUsingKey(
            MDCDEFS.kMtxPricingOfferSearchDataExternalIdFldKey, offerSearchId)
    elif (offerSearchName == 'CatalogItemId'):
        offerSearch.setUsingKey(
            MDCDEFS.kMtxPricingOfferSearchDataCatalogItemIdIdFldKey, offerSearchId)
    else:
        raise RuntimeError('Unknown offerSearchName: ' + str(offerSearchName))

    return offerSearch

def newObjectSearch(objectSearchName, objectSearchValue):
    objectSearch = MDCDEFS.kMtxObjectSearchDataMdcDesc.create()
    if objectSearchName == 'ObjectId':
        objectSearch.setUsingKey(
            MDCDEFS.kMtxObjectSearchDataObjectIdFldKey, objectSearchValue)
    elif objectSearchName == 'MultiRequestIndex':
        objectSearch.setUsingKey(
            MDCDEFS.kMtxObjectSearchDataMultiRequestIndexFldKey, objectSearchValue)
    else:
        objectSearch.setUsingKey(
            MDCDEFS.kMtxObjectSearchDataIndexKeyNameFldKey, objectSearchName)
        objectSearch.setUsingKey(
            MDCDEFS.kMtxObjectSearchDataIndexKeyValueFldKey, objectSearchValue)

    return objectSearch

def addObjectRoutingData(message, objectSearch):
    searchType = None
    searchTerm = None
    if (objectSearch.isPresent(MDCDEFS.kMtxObjectSearchDataObjectIdFldKey)):
        searchType = "OBID"
        searchTerm = objectSearch.getUsingKey(MDCDEFS.kMtxObjectSearchDataObjectIdFldKey)
    elif (objectSearch.isPresent(MDCDEFS.kMtxObjectSearchDataIndexKeyNameFldKey)):
        indexKey = objectSearch.getUsingKey(MDCDEFS.kMtxObjectSearchDataIndexKeyNameFldKey)
        if indexKey == "ExternalId":
            searchType = "EXID"
        elif indexKey == "Imsi":
            searchType = "IMSI"
        elif indexKey == "AccessNumber":
            searchType = "ACNM"
        elif indexKey == "LoginId":
            searchType = "LOGN"
        elif indexKey == "AccessId":
            searchType = "ACID"
        elif indexKey == "SessionId":
            searchType = "SESS"
        elif indexKey == "Tsan":
            searchType = "TSAN"
        elif indexKey == "UserId":
            searchType = "USID"
        else:
            raise RuntimeError('Unknown ObjectSearchData IndexKeyName: ' + str(indexKey))
        searchTerm = objectSearch.getUsingKey(MDCDEFS.kMtxObjectSearchDataIndexKeyValueFldKey)
    elif (objectSearch.isPresent(MDCDEFS.kMtxObjectSearchDataMultiRequestIndexFldKey)):
        # Multi-request routing data should be supplied in the multiRequest invocation
        return
    else:
        raise RuntimeError('Invalid ObjectSearchData: ' + str(objectSearch))

    message.setUsingKey(MDCDEFS.kMtxMsgTrafficRouteDataFldKey, searchType + str(searchTerm))
    return

def newMembershipSearch(membershipSearchName, membershipSearchValue1, membershipSearchValue2=None):
    membershipSearch = MDCDEFS.kMtxMembershipSearchDataMdcDesc.create()
    membershipSearch.setUsingKey(
        MDCDEFS.kMtxMembershipSearchDataIndexKeyNameFldKey, membershipSearchName)
    membershipSearch.setUsingKey(
        MDCDEFS.kMtxMembershipSearchDataObjectId1FldKey, membershipSearchValue1)
    if membershipSearchValue2 != None:
        membershipSearch.setUsingKey(
            MDCDEFS.kMtxMembershipSearchDataObjectId2FldKey, membershipSearchValue2)

    return membershipSearch

def addMembershipRoutingData(message, memberSearch):
    searchType = "OBID"
    searchTerm = None
    if (memberSearch.isPresent(MDCDEFS.kMtxMembershipSearchDataObjectId1FldKey)):
        searchTerm = memberSearch.getUsingKey(MDCDEFS.kMtxMembershipSearchDataObjectId1FldKey)
    else:
        raise RuntimeError('Invalid MembershipSearchData: ' + str(memberSearch))

    message.setUsingKey(MDCDEFS.kMtxMsgTrafficRouteDataFldKey, searchType + str(searchTerm))
    return

def newPricingBalanceClassSearch(balanceClassSearchName, balanceClassSearchId):
    balanceClassSearch = MDCDEFS.kMtxPricingBalanceClassSearchDataMdcDesc.create()
    if (balanceClassSearchName == 'BalanceClassId'):
        balanceClassSearch.setUsingKey(
            MDCDEFS.kMtxPricingBalanceClassSearchDataBalanceClassIdFldKey, balanceClassSearchId)
    else:
        raise RuntimeError('Unknown balanceClassSearchName: ' + str(balanceClassSearchName))

    return balanceClassSearch

def newPricingBalanceSearch(balanceSearchName, balanceSearchId):
    balanceSearch = MDCDEFS.kMtxPricingBalanceSearchDataMdcDesc.create()
    if (balanceSearchName == 'BalanceId'):
        balanceSearch.setUsingKey(
            MDCDEFS.kMtxPricingBalanceSearchDataBalanceIdFldKey, balanceSearchId)
    else:
        raise RuntimeError('Unknown balanceSearchName: ' + str(balanceSearchName))

    return balanceSearch

def newPricingBillingCycleSearch(billingCycleSearchName, billingCycleSearchId):
    billingCycleSearch = MDCDEFS.kMtxPricingBillingCycleSearchDataMdcDesc.create()
    if (billingCycleSearchName == 'BillingCycleId'):
        billingCycleSearch.setUsingKey(
            MDCDEFS.kMtxPricingBillingCycleSearchDataBillingCycleIdFldKey, billingCycleSearchId)
    else:
        raise RuntimeError('Unknown billingCycleSearchName: ' + str(billingCycleSearchName))

    return billingCycleSearch

def newPricingEventTypeSearch(eventTypeSearchName, eventTypeSearchId):
    eventTypeSearch = MDCDEFS.kMtxPricingEventTypeSearchDataMdcDesc.create()
    if (eventTypeSearchName == 'EventTypeId'):
        eventTypeSearch.setUsingKey(
            MDCDEFS.kMtxPricingEventTypeSearchDataEventTypeIdFldKey, eventTypeSearchId)
    else:
        raise RuntimeError('Unknown eventTypeSearchName: ' + str(eventTypeSearchName))

    return eventTypeSearch

def newPricingServiceTypeSearch(serviceTypeSearchName, serviceTypeSearchId):
    serviceTypeSearch = MDCDEFS.kMtxPricingServiceTypeSearchDataMdcDesc.create()
    if (serviceTypeSearchName == 'ServiceTypeId'):
        serviceTypeSearch.setUsingKey(
            MDCDEFS.kMtxPricingServiceTypeSearchDataServiceTypeIdFldKey, serviceTypeSearchId)
    else:
        raise RuntimeError('Unknown serviceTypeSearchName: ' + str(serviceTypeSearchName))

    return serviceTypeSearch

def newPricingServiceContextSearch(serviceTypeSearchName, serviceTypeSearchId, contextSearchName, contextSearchId):
    serviceContextSearch = MDCDEFS.kMtxPricingServiceContextSearchDataMdcDesc.create()
    if (serviceTypeSearchName == 'ServiceTypeId'):
        serviceContextSearch.setUsingKey(
            MDCDEFS.kMtxPricingServiceContextSearchDataServiceTypeIdFldKey, serviceTypeSearchId)
    else:
        raise RuntimeError('Unknown serviceTypeSearchName: ' + str(serviceTypeSearchName))

    if (contextSearchName == 'ContextId'):
        serviceContextSearch.setUsingKey(
            MDCDEFS.kMtxPricingServiceContextSearchDataContextIdFldKey, contextSearchId)
    else:
        raise RuntimeError('Unknown serviceTypeSearchName: ' + str(contextSearchName))

    return serviceContextSearch

def newPricingTaxClassSearch(taxClassSearchName, taxClassSearchId):
    taxClassSearch = MDCDEFS.kMtxPricingTaxClassSearchDataMdcDesc.create()
    if (taxClassSearchName == 'TaxClassId'):
        taxClassSearch.setUsingKey(
            MDCDEFS.kMtxPricingTaxClassSearchDataTaxClassIdFldKey, taxClassSearchId)
    elif (taxClassSearchName == 'ExternalId'):
        taxClassSearch.setUsingKey(
            MDCDEFS.kMtxPricingTaxClassSearchDataExternalIdFldKey, taxClassSearchId)
    else:
        raise RuntimeError('Unknown taxClassSearchName: ' + str(taxClassSearchName))

    return taxClassSearch

def newPricingRateTagSearch(rateTagSearchName, rateTagSearchId):
    rateTagSearch = MDCDEFS.kMtxPricingRateTagSearchDataMdcDesc.create()
    if (rateTagSearchName == 'RateTagId'):
        rateTagSearch.setUsingKey(
            MDCDEFS.kMtxPricingRateTagSearchDataRateTagIdFldKey, rateTagSearchId)
    elif (rateTagSearchName == 'ExternalId'):
        rateTagSearch.setUsingKey(
            MDCDEFS.kMtxPricingRateTagSearchDataExternalIdFldKey, rateTagSearchId)
    else:
        raise RuntimeError('Unknown rateTagSearchName: ' + str(rateTagSearchName))

    return rateTagSearch

def newPricingRoleSearch(roleSearchName, roleSearchId):
    roleSearch = MDCDEFS.kMtxPricingRoleSearchDataMdcDesc.create()
    if (roleSearchName == 'PricingId'):
        roleSearch.setUsingKey(
            MDCDEFS.kMtxPricingRoleSearchDataPricingIdFldKey, roleSearchId)
    elif (roleSearchName == 'ExternalId'):
        roleSearch.setUsingKey(
            MDCDEFS.kMtxPricingRoleSearchDataExternalIdFldKey, roleSearchId)
    else:
        raise RuntimeError('Unknown roleSearchName: ' + str(roleSearchName))

    return roleSearch

def newTaskSearch(taskSearchType, taskSearchValue):
    taskSearch = MDCDEFS.kMtxTaskSearchDataMdcDesc.create()
    if (taskSearchType == 'ObjectId'):
        taskSearch.setUsingKey(
            MDCDEFS.kMtxTaskSearchDataObjectIdFldKey, taskSearchValue)
    else:
        raise RuntimeError('Unknown taskSearchType: ' + str(taskSearchType))

    return taskSearch

def newPricingContractSearch(queryType, queryValue):
    contractSearch = MDCDEFS.kMtxPricingContractSearchDataMdcDesc.create()
    if (queryType == 'ContractId'):
        contractSearch.setUsingKey(
            MDCDEFS.kMtxPricingContractSearchDataContractIdFldKey, queryValue)
    elif (queryType == 'ExternalId'):
        contractSearch.setUsingKey(
            MDCDEFS.kMtxPricingContractSearchDataExternalIdFldKey, queryValue)
    else:
        raise RuntimeError('Unknown queryType: ' + str(queryType))

    return contractSearch

def newPricingContractEtcScheduleSearch(queryType, queryValue):
    contractSearch = MDCDEFS.kMtxPricingContractEtcScheduleSearchDataMdcDesc.create()
    if (queryType == 'ContractEtcScheduleId'):
        contractSearch.setUsingKey(
            MDCDEFS.kMtxPricingContractEtcScheduleSearchDataContractEtcScheduleIdFldKey, queryValue)
    elif (queryType == 'ExternalId'):
        contractSearch.setUsingKey(
            MDCDEFS.kMtxPricingContractEtcScheduleSearchDataExternalIdFldKey, queryValue)
    else:
        raise RuntimeError('Unknown queryType: ' + str(queryType))

    return contractSearch

def newPricingContractPaymentScheduleSearch(queryType, queryValue):
    contractSearch = MDCDEFS.kMtxPricingContractPaymentScheduleSearchDataMdcDesc.create()
    if (queryType == 'ContractPaymentScheduleId'):
        contractSearch.setUsingKey(
            MDCDEFS.kMtxPricingContractPaymentScheduleSearchDataContractPaymentScheduleIdFldKey, queryValue)
    elif (queryType == 'ExternalId'):
        contractSearch.setUsingKey(
            MDCDEFS.kMtxPricingContractPaymentScheduleSearchDataExternalIdFldKey, queryValue)
    else:
        raise RuntimeError('Unknown queryType: ' + str(queryType))

    return contractSearch

def newTenantScheduleSearch(queryType, queryValue):
    contractSearch = MDCDEFS.kMtxPricingTenantSearchDataMdcDesc.create()
    if (queryType == 'TenantId'):
        contractSearch.setUsingKey(
            MDCDEFS.kMtxPricingTenantSearchDataTenantIdFldKey, queryValue)
    elif (queryType == 'TenantProfileId'):
        contractSearch.setUsingKey(
            MDCDEFS.kMtxPricingTenantSearchDataTenantProfileIdFldKey, queryValue)
    elif (queryType == 'TenantExternalId'):
        contractSearch.setUsingKey(
            MDCDEFS.kMtxPricingTenantSearchDataTenantExternalIdFldKey, queryValue)
    else:
        raise RuntimeError('Unknown queryType: ' + str(queryType))

    return contractSearch

def addTaskRoutingData(message, taskSearch):
    searchType = None
    searchTerm = None
    if (taskSearch.isPresent(MDCDEFS.kMtxTaskSearchDataObjectIdFldKey)):
        searchType = "OBID"
        searchTerm = taskSearch.getUsingKey(MDCDEFS.kMtxTaskSearchDataObjectIdFldKey)
    else:
        raise RuntimeError('Invalid TaskSearchData: ' + str(taskSearch))

    message.setUsingKey(MDCDEFS.kMtxMsgTrafficRouteDataFldKey, searchType + str(searchTerm))
    return

def newEventSearch(eventSearchType, eventSearchValue):
    eventSearch = MDCDEFS.kMtxEventSearchDataMdcDesc.create()
    if (eventSearchType == 'ObjectId'):
        eventSearch.setUsingKey(
            MDCDEFS.kMtxEventSearchDataObjectIdFldKey, eventSearchValue)
    elif (eventSearchType == 'EventId'):
        eventSearch.setUsingKey(
            MDCDEFS.kMtxEventSearchDataEventIdFldKey, eventSearchValue)
    else:
        raise RuntimeError('Unknown eventSearchType: ' + str(eventSearchType))

    return eventSearch

def addEventRoutingData(message, eventSearch):
    searchType = None
    searchTerm = None
    if (eventSearch.isPresent(MDCDEFS.kMtxEventSearchDataObjectIdFldKey)):
        searchType = "OBID"
        searchTerm = eventSearch.getUsingKey(MDCDEFS.kMtxEventSearchDataObjectIdFldKey)
    elif (eventSearch.isPresent(MDCDEFS.kMtxEventSearchDataEventIdFldKey)):
        # AMORAN: Should we add a subman routing code for EventId?
        return
    else:
        raise RuntimeError('Invalid EventSearchData: ' + str(eventSearch))

    message.setUsingKey(MDCDEFS.kMtxMsgTrafficRouteDataFldKey, searchType + str(searchTerm))
    return

def newBillingCycleData(templateId, dateOffset=None, immediateChange=None):
    billCycleMdc = MDCDEFS.kMtxBillingCycleDataMdcDesc.create()
    billCycleMdc.setUsingKey(
        MDCDEFS.kMtxBillingCycleDataBillingCycleIdFldKey, templateId)
    if dateOffset != None:
        billCycleMdc.setUsingKey(
            MDCDEFS.kMtxBillingCycleDataDateOffsetFldKey, dateOffset)
    if immediateChange != None:
        billCycleMdc.setUsingKey(
            MDCDEFS.kMtxBillingCycleDataImmediateChangeFldKey, immediateChange)
    return billCycleMdc

def newGeoData(geoCode=None, postalCode=None, plus4=None, npa=None, nxx=None):
    geodataMdc = MDCDEFS.kMtxGeoDataMdcDesc.create()
    if geoCode is not None:
        geodataMdc.setUsingKey(
            MDCDEFS.kMtxGeoDataGeoCodeFldKey, geoCode)
    if postalCode is not None:
        geodataMdc.setUsingKey(
            MDCDEFS.kMtxGeoDataPostalCodeFldKey, postalCode)
    if plus4 is not None:
        geodataMdc.setUsingKey(
            MDCDEFS.kMtxGeoDataPlus4FldKey, plus4)
    if npa is not None:
        geodataMdc.setUsingKey(
            MDCDEFS.kMtxGeoDataNpaFldKey, npa)
    if nxx is not None:
        geodataMdc.setUsingKey(
            MDCDEFS.kMtxGeoDataNxxFldKey, nxx)
    return geodataMdc

def newOfferPurchaseArray(offerList):
    offerArray = []
    for offer in offerList:
        offerMdc = MDCDEFS.kMtxPurchasedOfferDataMdcDesc.create()
        if 'ProductOfferId' in offer:
            offerMdc.setUsingKey(
                MDCDEFS.kMtxPurchasedOfferDataProductOfferIdFldKey,
                offer['ProductOfferId'])
        if 'ExternalId' in offer:
            offerMdc.setUsingKey(
                MDCDEFS.kMtxPurchasedOfferDataExternalIdFldKey,
                offer['ExternalId'])
        if 'StartTime' in offer:
            offerMdc.setUsingKey(
                MDCDEFS.kMtxPurchasedOfferDataStartTimeFldKey,
                offer['StartTime'])
        if 'EndTime' in offer:
            offerMdc.setUsingKey(
                MDCDEFS.kMtxPurchasedOfferDataEndTimeFldKey,
                offer['EndTime'])
        if 'EndTimeRelativeOffsetUnit' in offer:
            offerMdc.setUsingKey(
                MDCDEFS.kMtxPurchasedOfferDataEndTimeRelativeOffsetUnitFldKey,
                offer['EndTimeRelativeOffsetUnit'])
        if 'EndTimeRelativeOffset' in offer:
            offerMdc.setUsingKey(
                MDCDEFS.kMtxPurchasedOfferDataEndTimeRelativeOffsetFldKey,
                offer['EndTimeRelativeOffset'])
        if 'Attr' in offer:
            offerMdc.setUsingKey(
                MDCDEFS.kMtxPurchasedOfferDataAttrFldKey,
                offer['Attr'])
        if 'ProductOfferVersion' in offer:
            offerMdc.setUsingKey(
                MDCDEFS.kMtxPurchasedOfferDataProductOfferVersionFldKey,
                offer['ProductOfferVersion'])
        if 'CatalogItemId' in offer:
            offerMdc.setUsingKey(
                MDCDEFS.kMtxPurchasedOfferDataCatalogItemIdFldKey,
                offer['CatalogItemId'])
        if 'PreActiveState' in offer:
            offerMdc.setUsingKey(
                MDCDEFS.kMtxPurchasedOfferDataPreActiveStateFldKey,
                offer['PreActiveState'])
        if 'ActivationExpirationTime' in offer:
            offerMdc.setUsingKey(
                MDCDEFS.kMtxPurchasedOfferDataActivationExpirationTimeFldKey,
                offer['ActivationExpirationTime'])
        if 'ActivationExpirationRelativeOffsetUnit' in offer:
            offerMdc.setUsingKey(
                MDCDEFS.kMtxPurchasedOfferDataActivationExpirationRelativeOffsetUnitFldKey,
                offer['ActivationExpirationRelativeOffsetUnit'])
        if 'ActivationExpirationRelativeOffset' in offer:
            offerMdc.setUsingKey(
                MDCDEFS.kMtxPurchasedOfferDataActivationExpirationRelativeOffsetFldKey,
                offer['ActivationExpirationRelativeOffset'])
        if 'AutoActivationTime' in offer:
            offerMdc.setUsingKey(
                MDCDEFS.kMtxPurchasedOfferDataAutoActivationTimeFldKey,
                offer['AutoActivationTime'])
        if 'AutoActivationRelativeOffsetUnit' in offer:
            offerMdc.setUsingKey(
                MDCDEFS.kMtxPurchasedOfferDataAutoActivationRelativeOffsetUnitFldKey,
                offer['AutoActivationRelativeOffsetUnit'])
        if 'AutoActivationRelativeOffset' in offer:
            offerMdc.setUsingKey(
                MDCDEFS.kMtxPurchasedOfferDataAutoActivationRelativeOffsetFldKey,
                offer['AutoActivationRelativeOffset'])
        if 'AutoActivationCycleResourceId' in offer:
            offerMdc.setUsingKey(
                MDCDEFS.kMtxPurchasedOfferDataAutoActivationCycleResourceIdFldKey,
                offer['AutoActivationCycleResourceId'])
        if 'DownPayment' in offer:
            downPaymentInfo = MDCDEFS.kMtxPurchasedItemDownPaymentInfoMdcDesc.create()
            downPaymentInfo.setUsingKey(
                MDCDEFS.kMtxPurchasedItemDownPaymentInfoDownPaymentFldKey,
                offer['DownPayment'])
            offerMdc.setUsingKey(MDCDEFS.kMtxPurchasedOfferDataDownPaymentInfoFldKey, downPaymentInfo)
        if 'IsTargetResource' in offer:
            offerMdc.setUsingKey(
                MDCDEFS.kMtxPurchasedOfferDataIsTargetResourceFldKey,
                offer['IsTargetResource'])
        if 'IsRecurringFailureAllowed' in offer:
            offerMdc.setUsingKey(
                MDCDEFS.kMtxPurchasedOfferDataIsRecurringFailureAllowedFldKey,
                offer['IsRecurringFailureAllowed'])
        if 'GrantPurchaseProrationType' in offer:
            offerMdc.setUsingKey(
                MDCDEFS.kMtxPurchasedOfferDataGrantPurchaseProrationTypeFldKey,
                offer['GrantPurchaseProrationType'])
        if 'ChargePurchaseProrationType' in offer:
            offerMdc.setUsingKey(
                MDCDEFS.kMtxPurchasedOfferDataChargePurchaseProrationTypeFldKey,
                offer['ChargePurchaseProrationType'])
        if 'Reason' in offer:
            offerMdc.setUsingKey(
                MDCDEFS.kMtxPurchasedOfferDataReasonFldKey, offer['Reason'])
        if 'Info' in offer:
            offerMdc.setUsingKey(
                MDCDEFS.kMtxPurchasedOfferDataInfoFldKey, offer['Info'])
        if 'ContractParameterOverrideData' in offer:
            contractParameterOverrideData = \
                MDCDEFS.kMtxPurchasedItemContractParameterOverrideDataMdcDesc.create()
            contractParameterOverrideDataInOffer = offer['ContractParameterOverrideData']
            if 'ContractPeriod' in contractParameterOverrideDataInOffer:
                contractParameterOverrideData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemContractParameterOverrideDataContractPeriodFldKey,
                    contractParameterOverrideDataInOffer['ContractPeriod'])
            if 'ContractInterval' in contractParameterOverrideDataInOffer:
                contractParameterOverrideData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemContractParameterOverrideDataContractIntervalFldKey,
                    contractParameterOverrideDataInOffer['ContractInterval'])
            if 'CommitmentPeriod' in contractParameterOverrideDataInOffer:
                contractParameterOverrideData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemContractParameterOverrideDataCommitmentPeriodFldKey,
                    contractParameterOverrideDataInOffer['CommitmentPeriod'])
            if 'CommitmentPeriodInterval' in contractParameterOverrideDataInOffer:
                contractParameterOverrideData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemContractParameterOverrideDataCommitmentPeriodIntervalFldKey,
                    contractParameterOverrideDataInOffer['CommitmentPeriodInterval'])
            if 'IsOpenContract' in contractParameterOverrideDataInOffer:
                contractParameterOverrideData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemContractParameterOverrideDataIsOpenContractFldKey,
                    contractParameterOverrideDataInOffer['IsOpenContract'])
            if 'EtcScheduleRangeArray' in contractParameterOverrideDataInOffer:
                contractParameterOverrideData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemContractParameterOverrideDataEtcScheduleRangeArrayFldKey,
                    contractParameterOverrideDataInOffer['EtcScheduleRangeArray'])
            if 'EtcScheduleRangeUnit' in contractParameterOverrideDataInOffer:
                contractParameterOverrideData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemContractParameterOverrideDataEtcScheduleRangeUnitFldKey,
                    contractParameterOverrideDataInOffer['EtcScheduleRangeUnit'])
            if 'PaymentScheduleRangeArray' in contractParameterOverrideDataInOffer:
                contractParameterOverrideData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemContractParameterOverrideDataPaymentScheduleRangeArrayFldKey,
                    contractParameterOverrideDataInOffer['PaymentScheduleRangeArray'])
            if 'PaymentScheduleAmountArray' in contractParameterOverrideDataInOffer:
                contractParameterOverrideData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemContractParameterOverrideDataPaymentScheduleAmountArrayFldKey,
                    contractParameterOverrideDataInOffer['PaymentScheduleAmountArray'])
            if 'PaymentScheduleLastAmount' in contractParameterOverrideDataInOffer:
                contractParameterOverrideData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemContractParameterOverrideDataPaymentScheduleLastAmountFldKey,
                    contractParameterOverrideDataInOffer['PaymentScheduleLastAmount'])
            if 'DelayCharge' in contractParameterOverrideDataInOffer:
                contractParameterOverrideData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemContractParameterOverrideDataDelayChargeFldKey,
                    contractParameterOverrideDataInOffer['DelayCharge'])
            offerMdc.setUsingKey(MDCDEFS.kMtxPurchasedOfferDataContractParameterOverrideDataFldKey,
                                contractParameterOverrideData)

        # Create and set CycleData if any of the cycle parameters are included
        if any(_ in offer
               for _ in ['CycleType', 'CycleOffset', 'CycleResourceId', 'CycleOwnerType', \
                         'UseTargetResource', 'CycleStartTime', 'CycleEndTime']):
            cycleData = MDCDEFS.kMtxPurchasedItemCycleDataMdcDesc.create()
            if 'CycleType' in offer:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataCycleTypeFldKey,
                    offer['CycleType'])
            if 'CycleOffset' in offer:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataCycleOffsetFldKey,
                    offer['CycleOffset'])
            if 'CycleResourceId' in offer:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataCycleResourceIdFldKey,
                    offer['CycleResourceId'])
            if 'CycleOwnerType' in offer:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataCycleOwnerTypeFldKey,
                    offer['CycleOwnerType'])
            if 'UseTargetResource' in offer:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataUseTargetResourceFldKey,
                    offer['UseTargetResource'])
            if 'CycleStartTime' in offer:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataCycleStartTimeFldKey,
                    offer['CycleStartTime'])
            if 'CycleEndTime' in offer:
                cycleData.setUsingKey(
                    MDCDEFS.kMtxPurchasedItemCycleDataCycleEndTimeFldKey,
                    offer['CycleEndTime'])

            offerMdc.setUsingKey(MDCDEFS.kMtxPurchasedOfferDataCycleDataFldKey, cycleData)

        # add parameters
        if 'ParameterList' in offer:
            parameterArray = newParameterDataArray(offer['ParameterList'])
            offerMdc.setUsingKey(MDCDEFS.kMtxPurchasedOfferDataParameterArrayFldKey, parameterArray)

        if 'OfferStatusValue' in offer:
            offerMdc.setUsingKey(
                MDCDEFS.kMtxPurchasedOfferDataOfferStatusValueFldKey,
                offer['OfferStatusValue'])

        if 'PaymentDueDate' in offer:
            offerMdc.setUsingKey(
                MDCDEFS.kMtxPurchasedOfferDataPaymentDueDateFldKey,
                offer['PaymentDueDate'])

        offerArray.append(offerMdc)

    return offerArray

def newParameterDataArray(parameterList):
    parameterArray = []
    for parameter in parameterList:
        parameterMdc = MDCDEFS.kMtxParameterDataMdcDesc.create()
        if 'ParameterDefnId' in parameter:
            parameterMdc.setUsingKey(MDCDEFS.kMtxParameterDataParameterDefnIdFldKey, parameter['ParameterDefnId'])
        if 'ParameterName' in parameter:
            parameterMdc.setUsingKey(MDCDEFS.kMtxParameterDataParameterNameFldKey, parameter['ParameterName'])
        if 'DecimalValue' in parameter:
            decimalValue = MDCDEFS.kMtxParameterDecimalValueMdcDesc.create()
            decimalValue.setUsingKey(MDCDEFS.kMtxParameterDecimalValueValueFldKey, parameter['DecimalValue'])
            parameterMdc.setUsingKey(MDCDEFS.kMtxParameterDataValueFldKey, decimalValue)
        if 'Int32Value' in parameter:
            int32Value = MDCDEFS.kMtxParameterInt32ValueMdcDesc.create()
            int32Value.setUsingKey(MDCDEFS.kMtxParameterInt32ValueValueFldKey, parameter['Int32Value'])
            parameterMdc.setUsingKey(MDCDEFS.kMtxParameterDataValueFldKey, int32Value)
        if 'Int64Value' in parameter:
            int64Value = MDCDEFS.kMtxParameterInt64ValueMdcDesc.create()
            int64Value.setUsingKey(MDCDEFS.kMtxParameterInt64ValueValueFldKey, parameter['Int64Value'])
            parameterMdc.setUsingKey(MDCDEFS.kMtxParameterDataValueFldKey, int64Value)
        if 'UnsignedInt32Value' in parameter:
            uint32Value = MDCDEFS.kMtxParameterUnsignedInt32ValueMdcDesc.create()
            uint32Value.setUsingKey(MDCDEFS.kMtxParameterUnsignedInt32ValueValueFldKey,
                parameter['UnsignedInt32Value'])
            parameterMdc.setUsingKey(MDCDEFS.kMtxParameterDataValueFldKey, uint32Value)
        if 'UnsignedInt64Value' in parameter:
            uint64Value = MDCDEFS.kMtxParameterUnsignedInt64ValueMdcDesc.create()
            uint64Value.setUsingKey(MDCDEFS.kMtxParameterUnsignedInt64ValueValueFldKey,
                parameter['UnsignedInt64Value'])
            parameterMdc.setUsingKey(MDCDEFS.kMtxParameterDataValueFldKey, uint64Value)
        if 'BoolValue' in parameter:
            boolValue = MDCDEFS.kMtxParameterBoolValueMdcDesc.create()
            boolValue.setUsingKey(MDCDEFS.kMtxParameterBoolValueValueFldKey, parameter['BoolValue'])
            parameterMdc.setUsingKey(MDCDEFS.kMtxParameterDataValueFldKey, boolValue)
        if 'StringValue' in parameter:
            stringValue = MDCDEFS.kMtxParameterStringValueMdcDesc.create()
            stringValue.setUsingKey(MDCDEFS.kMtxParameterStringValueValueFldKey, parameter['StringValue'])
            parameterMdc.setUsingKey(MDCDEFS.kMtxParameterDataValueFldKey, stringValue)
        if 'DateTimeValue' in parameter:
            dtValue = MDCDEFS.kMtxParameterDateTimeValueMdcDesc.create()
            dtValue.setUsingKey(MDCDEFS.kMtxParameterDateTimeValueValueFldKey, parameter['DateTimeValue'])
            parameterMdc.setUsingKey(MDCDEFS.kMtxParameterDataValueFldKey, dtValue)
        parameterArray.append(parameterMdc)

    return parameterArray

def newRechargeCycleData(periodType=None, periodCoef=None, cycleTimeOfDay=None, cycleOffset=None):
    rechargeCycleMdc = MDCDEFS.kMtxRechargeCycleDataMdcDesc.create()
    if periodType is not None:
        rechargeCycleMdc.setUsingKey(
            MDCDEFS.kMtxRechargeCycleDataPeriodTypeFldKey, periodType)
    if periodCoef is not None:
        rechargeCycleMdc.setUsingKey(
            MDCDEFS.kMtxRechargeCycleDataPeriodCoefFldKey, periodCoef)
    if cycleTimeOfDay is not None:
        rechargeCycleMdc.setUsingKey(
            MDCDEFS.kMtxRechargeCycleDataCycleTimeOfDayFldKey, cycleTimeOfDay)
    if cycleOffset is not None:
        rechargeCycleMdc.setUsingKey(
            MDCDEFS.kMtxRechargeCycleDataCycleOffsetFldKey, cycleOffset)
    return rechargeCycleMdc

def newChargeMethodData(paymentMethodResourceId=None, chargeMethod=None,
        paymentGatewayId=None, paymentGatewayUserId=None, nonce=None,
        chargeMethodAttr=None, deferredSettlement=False,
        deferredSettlementTimeout=None, deferredSettlementTimeoutAction=None):
    chargeMethodDataMdc = MDCDEFS.kMtxChargeMethodDataMdcDesc.create()
    if chargeMethod != None:
        chargeMethodDataMdc.setUsingKey(
            MDCDEFS.kMtxChargeMethodDataChargeMethodFldKey,
            chargeMethod)
    if paymentMethodResourceId != None:
        chargeMethodDataMdc.setUsingKey(
            MDCDEFS.kMtxChargeMethodDataPaymentMethodResourceIdFldKey,
            paymentMethodResourceId)
    if paymentGatewayId != None:
        chargeMethodDataMdc.setUsingKey(
            MDCDEFS.kMtxChargeMethodDataPaymentGatewayIdFldKey,
            paymentGatewayId)
    if paymentGatewayUserId != None:
        chargeMethodDataMdc.setUsingKey(
            MDCDEFS.kMtxChargeMethodDataPaymentGatewayUserIdFldKey,
            paymentGatewayUserId)
    if nonce != None:
        chargeMethodDataMdc.setUsingKey(
            MDCDEFS.kMtxChargeMethodDataPaymentGatewayOneTimeTokenFldKey,
            nonce)
    if chargeMethodAttr != None:
        chargeMethodDataMdc.setUsingKey(
            MDCDEFS.kMtxChargeMethodDataChargeMethodAttrFldKey,
            chargeMethodAttr)
    chargeMethodDataMdc.setUsingKey(
        MDCDEFS.kMtxChargeMethodDataDeferredSettlementFldKey,
        deferredSettlement)
    if deferredSettlementTimeout is not None:
        chargeMethodDataMdc.setUsingKey(
            MDCDEFS.kMtxChargeMethodDataDeferredSettlementTimeoutFldKey,
            deferredSettlementTimeout)
    if deferredSettlementTimeoutAction is not None:
        chargeMethodDataMdc.setUsingKey(
            MDCDEFS.kMtxChargeMethodDataDeferredSettlementTimeoutActionFldKey,
            deferredSettlementTimeoutAction)
    return chargeMethodDataMdc

def newCancelOfferDataArray(cancelOfferDataList):
    cancelOfferDataArray = []
    for cancelOfferData in cancelOfferDataList:
        cancelOfferDataMdc = MDCDEFS.kMtxCancelOfferDataMdcDesc.create()
        if 'ResourceId' in cancelOfferData:
            cancelOfferDataMdc.setUsingKey(
                MDCDEFS.kMtxCancelOfferDataResourceIdFldKey,
                cancelOfferData['ResourceId'])
        if 'CancelType' in cancelOfferData:
            cancelOfferDataMdc.setUsingKey(
                MDCDEFS.kMtxCancelOfferDataCancelTypeFldKey,
                cancelOfferData['CancelType'])
        if 'GrantCancelProrationType' in cancelOfferData:
            cancelOfferDataMdc.setUsingKey(
                MDCDEFS.kMtxCancelOfferDataGrantCancelProrationTypeFldKey,
                cancelOfferData['GrantCancelProrationType'])
        if 'ChargeCancelProrationType' in cancelOfferData:
            cancelOfferDataMdc.setUsingKey(
                MDCDEFS.kMtxCancelOfferDataChargeCancelProrationTypeFldKey,
                cancelOfferData['ChargeCancelProrationType'])
        if 'Reason' in cancelOfferData:
            cancelOfferDataMdc.setUsingKey(
                MDCDEFS.kMtxCancelOfferDataReasonFldKey,
                cancelOfferData['Reason'])
        if 'Info' in cancelOfferData:
            cancelOfferDataMdc.setUsingKey(
                MDCDEFS.kMtxCancelOfferDataInfoFldKey,
                cancelOfferData['Info'])
        if 'ContractCancelMode' in cancelOfferData:
            cancelOfferDataMdc.setUsingKey(
                MDCDEFS.kMtxCancelOfferDataContractCancelModeFldKey,
                cancelOfferData['ContractCancelMode'])
        if 'DebtCancellationMode' in cancelOfferData:
            cancelOfferDataMdc.setUsingKey(
                MDCDEFS.kMtxCancelOfferDataDebtCancellationModeFldKey,
                cancelOfferData['DebtCancellationMode'])
        if 'IsWaiveEarlyTerminationCharge' in cancelOfferData:
            cancelOfferDataMdc.setUsingKey(
                MDCDEFS.kMtxCancelOfferDataIsWaiveEarlyTerminationChargeFldKey,
                cancelOfferData['IsWaiveEarlyTerminationCharge'])
        if 'EtcScheduleRangeArray' in cancelOfferData:
            cancelOfferDataMdc.setUsingKey(
                MDCDEFS.kMtxCancelOfferDataEtcScheduleRangeArrayFldKey,
                cancelOfferData['EtcScheduleRangeArray'])
        if 'EtcScheduleRangeUnit' in cancelOfferData:
            cancelOfferDataMdc.setUsingKey(
                MDCDEFS.kMtxCancelOfferDataEtcScheduleRangeUnitFldKey,
                cancelOfferData['EtcScheduleRangeUnit'])
        if 'PayNow' in cancelOfferData:
            cancelOfferDataMdc.setUsingKey(
                MDCDEFS.kMtxCancelOfferDataPayNowFldKey,
                cancelOfferData['PayNow'])
        cancelOfferDataArray.append(cancelOfferDataMdc)

    return cancelOfferDataArray

def newRechargeData(amount=None, paymentMethodResourceId=None):
    rechargeDataMdc = MDCDEFS.kMtxRechargeDataMdcDesc.create()
    if amount is not None:
        rechargeDataMdc.setUsingKey(
            MDCDEFS.kMtxRechargeDataAmountFldKey,
            amount)
    if paymentMethodResourceId is not None:
        rechargeDataMdc.setUsingKey(
            MDCDEFS.kMtxRechargeDataPaymentMethodResourceIdFldKey,
            paymentMethodResourceId)
    return rechargeDataMdc

def newRoleDataArray(roleDataList):
    roleDataArray = []
    for roleData in roleDataList:
        roleDataMdc = MDCDEFS.kMtxRoleDataMdcDesc.create()
        if 'PricingId' in roleData:
            roleDataMdc.setUsingKey(
                MDCDEFS.kMtxRoleDataPricingIdFldKey, roleData['PricingId'])
        if 'ExternalId' in roleData:
            roleDataMdc.setUsingKey(
                MDCDEFS.kMtxRoleDataExternalIdFldKey, roleData['ExternalId'])
        roleDataArray.append(roleDataMdc)
    return roleDataArray

def newTaskActionSetField(subscriberAttr=None, groupAttr=None, userAttr=None):
    taskActionMdc = MDCDEFS.kMtxTaskActionSetFieldMdcDesc.create()
    if subscriberAttr is not None:
        taskActionMdc.setUsingKey(
            MDCDEFS.kMtxTaskActionSetFieldSubscriberAttrFldKey, subscriberAttr)
    if groupAttr is not None:
        taskActionMdc.setUsingKey(
            MDCDEFS.kMtxTaskActionSetFieldGroupAttrFldKey, groupAttr)
    if userAttr is not None:
        taskActionMdc.setUsingKey(
            MDCDEFS.kMtxTaskActionSetFieldUserAttrFldKey, userAttr)
    return taskActionMdc

def newTaskActionModifyStatus(status, expectedStatus=None):
    taskActionMdc = MDCDEFS.kMtxTaskActionModifyStatusMdcDesc.create()
    taskActionMdc.setUsingKey(
        MDCDEFS.kMtxTaskActionModifyStatusStatusFldKey, status)
    if expectedStatus is not None:
        taskActionMdc.setUsingKey(
            MDCDEFS.kMtxTaskActionModifyStatusExpectedStatusFldKey, expectedStatus)
    return taskActionMdc

def addResourceRegisterRoutingData(message, resourceRegisterSearch):
    searchType = None
    searchTerm = None
    if (resourceRegisterSearch.isPresent(MDCDEFS.kMtxResourceRegisterSearchDataObjectIdFldKey)):
        searchType = "OBID"
        searchTerm = resourceRegisterSearch.getUsingKey(MDCDEFS.kMtxResourceRegisterSearchDataObjectIdFldKey)
    elif (resourceRegisterSearch.isPresent(MDCDEFS.kMtxResourceRegisterSearchDataServiceNameFldKey)):
        searchType = "SESS"
        searchTerm = resourceRegisterSearch.getUsingKey(MDCDEFS.kMtxResourceRegisterSearchDataServiceNameFldKey)
    else:
        raise RuntimeError('Invalid ResourceRegisterSearchData: ' + str(resourceRegisterSearch))

    message.setUsingKey(MDCDEFS.kMtxMsgTrafficRouteDataFldKey, searchType + str(searchTerm))
    return

def newResourceRegisterSearch(resourceRegisterSearchName, resourceRegisterSearchId):
    resourceRegisterSearch = MDCDEFS.kMtxResourceRegisterSearchDataMdcDesc.create()
    if (resourceRegisterSearchName == 'ObjectId'):
        resourceRegisterSearch.setUsingKey(
            MDCDEFS.kMtxResourceRegisterSearchDataObjectIdFldKey, resourceRegisterSearchId)
    elif (resourceRegisterSearchName == 'ServiceName'):
        resourceRegisterSearch.setUsingKey(
            MDCDEFS.kMtxResourceRegisterSearchDataServiceNameFldKey, resourceRegisterSearchId)
    else:
        raise RuntimeError('Unknown resourceRegisterSearchName: ' + str(resourceRegisterSearchName))

    return resourceRegisterSearch

def addResourceRegisterListRoutingData(message, resourceRegisterSearch):
    searchType = None
    searchTerm = None
    # DKDKDK Need to remove additional SESSs
    if (resourceRegisterSearch.isPresent(MDCDEFS.kMtxResourceRegisterSearchDataListObjectIdFldKey)):
        searchType = "OBID"
        searchTerm = resourceRegisterSearch.getUsingKey(MDCDEFS.kMtxResourceRegisterSearchDataListObjectIdFldKey)
    elif (resourceRegisterSearch.isPresent(MDCDEFS.kMtxResourceRegisterSearchDataListServiceNameFldKey)):
        searchType = "SESS"
        searchTerm = resourceRegisterSearch.getUsingKey(MDCDEFS.kMtxResourceRegisterSearchDataListServiceNameFldKey)
    elif (resourceRegisterSearch.isPresent(MDCDEFS.kMtxResourceRegisterSearchDataListNameFldKey)):
        searchType = "SESS"
        searchTerm = resourceRegisterSearch.getUsingKey(MDCDEFS.kMtxResourceRegisterSearchDataListNameFldKey)
    elif (resourceRegisterSearch.isPresent(MDCDEFS.kMtxResourceRegisterSearchDataListTypeFldKey)):
        searchType = "SESS"
        searchTerm = resourceRegisterSearch.getUsingKey(MDCDEFS.kMtxResourceRegisterSearchDataListTypeFldKey)
    elif (resourceRegisterSearch.isPresent(MDCDEFS.kMtxResourceRegisterSearchDataListLocationFldKey)):
        searchType = "SESS"
        searchTerm = resourceRegisterSearch.getUsingKey(MDCDEFS.kMtxResourceRegisterSearchDataListLocationFldKey)
    else:
        raise RuntimeError('Invalid ResourceRegisterSearchData: ' + str(resourceRegisterSearch))

    message.setUsingKey(MDCDEFS.kMtxMsgTrafficRouteDataFldKey, searchType + str(searchTerm))
    return

def newResourceRegisterSearchList(resourceRegisterSearchName, resourceRegisterSearchId):
    resourceRegisterSearchList = MDCDEFS.kMtxResourceRegisterSearchDataListMdcDesc.create()
    if (resourceRegisterSearchName == 'ObjectId'):
        resourceRegisterSearchList.setUsingKey(
            MDCDEFS.kMtxResourceRegisterSearchDataListObjectIdFldKey, resourceRegisterSearchId)
    elif (resourceRegisterSearchName == 'ServiceName'):
        resourceRegisterSearchList.setUsingKey(
            MDCDEFS.kMtxResourceRegisterSearchDataListServiceNameFldKey, resourceRegisterSearchId)
    elif (resourceRegisterSearchName == 'Name'):
        resourceRegisterSearchList.setUsingKey(
            MDCDEFS.kMtxResourceRegisterSearchDataListNameFldKey, resourceRegisterSearchId)
    elif (resourceRegisterSearchName == 'Type'):
        resourceRegisterSearchList.setUsingKey(
            MDCDEFS.kMtxResourceRegisterSearchDataListTypeFldKey, resourceRegisterSearchId)
    elif (resourceRegisterSearchName == 'Location'):
        resourceRegisterSearchList.setUsingKey(
            MDCDEFS.kMtxResourceRegisterSearchDataListLocationFldKey, resourceRegisterSearchId)
    else:
        raise RuntimeError('Unknown resourceRegisterSearchName: ' + str(resourceRegisterSearchName))

    return resourceRegisterSearchList

def existingResourceRegisterSearchList(resourceRegisterSearchList,
                                       resourceRegisterSearchName, resourceRegisterSearchId):
    if (resourceRegisterSearchName == 'ObjectId'):
        resourceRegisterSearchList.setUsingKey(
            MDCDEFS.kMtxResourceRegisterSearchDataListObjectIdFldKey, resourceRegisterSearchId)
    elif (resourceRegisterSearchName == 'ServiceName'):
        resourceRegisterSearchList.setUsingKey(
            MDCDEFS.kMtxResourceRegisterSearchDataListServiceNameFldKey, resourceRegisterSearchId)
    elif (resourceRegisterSearchName == 'Name'):
        resourceRegisterSearchList.setUsingKey(
            MDCDEFS.kMtxResourceRegisterSearchDataListNameFldKey, resourceRegisterSearchId)
    elif (resourceRegisterSearchName == 'Type'):
        resourceRegisterSearchList.setUsingKey(
            MDCDEFS.kMtxResourceRegisterSearchDataListTypeFldKey, resourceRegisterSearchId)
    elif (resourceRegisterSearchName == 'Location'):
        resourceRegisterSearchList.setUsingKey(
            MDCDEFS.kMtxResourceRegisterSearchDataListLocationFldKey, resourceRegisterSearchId)
    else:
        raise RuntimeError('Unknown resourceRegisterSearchName: ' + str(resourceRegisterSearchName))

    return

# END OF FILE
