#!/usr/bin/python3
#===============================================================================
#
# Copyright 2010-2021, MATRIXX Software, Inc. All rights reserved.
#
#-------------------------------------------------------------------------------
#
# @file
# @date       $Date$
#
# $Id$
#
# @2to3-3 --no-diffs -x input -x print -w  : Fri 2021-08-27T10:12:59
#
# @futurize --stage2 --no-diffs -n -w  : Mon 2021-03-01T15:57:10
#
#
#
#===============================================================================
#
# This file defines DataContainerDescriptor variables and DataContainer FieldKeys
# that can be used by the script that imports this file.
#

import os
import time
# This is for performance timing
startTime = time.time()
lastTime = 0
debugPerformanceFlag = os.getenv('MTX_PYTHON_MDC_PERFORMANCE_DEBUG', 0)

def printPerformanceResults(description, startingTime, stoppingTime):
    deltaTimeInSeconds = '%09.6f' % round(stoppingTime - startingTime, 6)
    testInfo = '%-60s' % description
    print('DEBUG:perf: ' + testInfo + ': ' + deltaTimeInSeconds + ' seconds')
#
import data_container as MDC
if (debugPerformanceFlag):
    lastTime = startTime
    currentTime = time.time()
    printPerformanceResults('import data_container', lastTime, currentTime)
    lastTime = currentTime

import path_functions
if (debugPerformanceFlag):
    lastTime = startTime
    currentTime = time.time()
    printPerformanceResults('import path_functions', lastTime, currentTime)
    lastTime = currentTime
#
confDir = path_functions.confDir

# Create the variables for the system MDCs that the importer will use.
# NOTE: This is a lot faster (3-6 millis) than reading a pickled file (100-400 millis).
for (variableName, variableValue) in MDC.kMdcConfigSystemVariableList:
    globals()[variableName] = variableValue
#
if (debugPerformanceFlag):
    lastTime = startTime
    currentTime = time.time()
    printPerformanceResults('created globals', lastTime, currentTime)
    lastTime = currentTime
#
# Create the variables for the custom MDCs that the importer will use.
# NOTE: This is a lot faster (3-7 millis) than reading a pickled file (100-400 millis).
for (variableName, variableValue) in MDC.kMdcConfigCustomVariableList:
    globals()[variableName] = variableValue
#
if (debugPerformanceFlag):
    lastTime = startTime
    currentTime = time.time()
    printPerformanceResults('import mdc_config_custom', lastTime, currentTime)
    lastTime = currentTime
