#!/usr/bin/python3
from distutils.core import setup

setup(name='VisibleAutopay',
      version='0.68',
      info='Test',
      packages=['mtx.vap'],
      scripts=['autopay.py'],
      data_files=[('/opt/mtx/conf', ['autopay.yaml'])]
      )
