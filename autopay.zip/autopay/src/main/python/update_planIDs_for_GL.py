import xml.etree.ElementTree as ET
import yaml


# load yaml file
def read_yaml_file(yaml_file):
    with open(yaml_file, 'r') as file:
        data = yaml.safe_load(file)
    return data


# read properties from yaml file
yaml_file = "/opt/mtx/data/gl/vzw_gl_5252/update_planIDs_for_GL.yaml"
data = read_yaml_file(yaml_file)


def extract_and_replace(xml_file, field_name):
    # Parse the XML file
    tree = ET.parse(xml_file)
    root = tree.getroot()
    # Search for the field, extract its value and replace
    for element in root.iter(journal_entry):
        for nested_element in element:
            if nested_element.tag == field_name and nested_element.text is not None:
                result1 = nested_element.text.split(separator)
                for modified_plan_ID in modified_plan_IDs:
                    if result1 != "" and modified_plan_ID == result1[-1]:
                        updated_glRef = nested_element.text[:-len("_" + result1[-1])]
                        nested_element.text = updated_glRef
                        for sub_element in element:
                            if sub_element.tag == tag_name:
                                sub_element.text = result1[-1]
                                tree.write(directory + "/" + filename)
            if nested_element.tag == dpcGroupList:
                for nesting1 in nested_element:
                    if nesting1.tag == dpcGroupInfo:
                        for nesting2 in nesting1:
                            if nesting2.tag == dpcItemList:
                                element_counts = {}
                                param = nesting2.tag
                                num_elements = len(list(nesting2))
                                element_counts[param] = num_elements
                                for nesting3 in nesting2:
                                    if nesting3.tag == dpcItem and element_counts[param] == dpcItemCount:
                                        for nesting4 in nesting3:
                                            if nesting4.tag == field_name and nesting4.text is not None:
                                                result2 = nesting4.text.split(separator)
                                                for modified_plan_ID in modified_plan_IDs:
                                                    if result2 != "" and modified_plan_ID == result2[-1]:
                                                        updated_glRef = nesting4.text[:-len("_" + result2[-1])]
                                                        nesting4.text = updated_glRef
                                                        for sub_element in element:
                                                            if sub_element.tag == tag_name:
                                                                sub_element.text = result2[-1]
                                                                tree.write(directory + "/" + filename)

    # If the field is not found
    return None


# Properties from yaml file
xml_file = data['gl_filename']
field_name = data['field_with_plan_id']
directory = data['gl_directory']
filename = data['modified_filename']
modified_plan_IDs = data['modified_plan_IDs']
separator = data['separator']
skip_txn_type = data['skip_txn_type']

# Fields names
tag_name = "PlanID"
journal_entry = "JournalEntry"
txn_type = "TxnType"
dpcGroupList = "DpcGroupList"
dpcGroupInfo = "DpcGroupInfo"
dpcItemList = "DpcItemList"
dpcItem = "DpcItem"
dpcItemCount = 1

extract_and_replace(xml_file, field_name)
