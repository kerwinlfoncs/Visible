import sys, yaml, logging, argparse
import fasteners
from dotmap import DotMap
from queue import Queue
from mtx.vap.scanner import Scanner
from mtx.vap.processors import Processors
from mtx.vap.stats import init_stats, get_stats

loglevels={'DEBUG':logging.DEBUG,'INFO':logging.INFO,'ERROR':logging.ERROR}
KEY_OBJID = 0
KEY_EXTID = 1

def load_config(fname):
    global config
    config = DotMap(yaml.safe_load(open(fname)), _dynamic=False)

def parse_input_file(q, fn):
    for l in open(fn):
        if('-' in l or ':' in l):
            q.put((KEY_OBJID, l.strip()))
        else:
            q.put((KEY_EXTID, l.strip()))
        get_stats().incr('050 - Subscribers parsed')

def dumpsubs(logq, fname):
    f = open(fname, 'w')
    while True:
        m = logq.get()
        if m is None:
            break
        f.write(m + '\n')
    f.close()

def main():
    parser = argparse.ArgumentParser(description='Parameters for Autopay.')
    parser.add_argument(dest='params', metavar='params', type=str, nargs='*', default='',
                        help='override properties from autopay.yaml')
    args = parser.parse_args()
    paramlist = getattr(args, "params")
    config_file = '/opt/mtx/conf/autopay.yaml'
    for param in paramlist:
        if ('=' not in param):
            config_file = param
            break

    load_config(config_file)

    for param in paramlist:
        if('=' in param):
            key, val = param.split('=')
            update = yaml.safe_load('%s: %s' % (key, val))
            config.update(update)

    FORMAT = '%(asctime)s %(levelname)-7s %(threadName)-20s %(module)-10s %(funcName)-20s %(message)s'
    logging.basicConfig(format=FORMAT, filename=config['logfile'], level=loglevels[config['loglevel']])
    logging.info(config)

    try:
        logging.info('Program started')
        lock = fasteners.InterProcessLock(config['lockfile'])
        gotten = lock.acquire(blocking=False)
        if gotten:
            logging.info('Lock acquired')
        else:
            logging.error('Could not acquire lock')
            sys.exit(1)

        init_stats(config)
        subq = Queue()

        sublogq = None
        pr = Processors(config, subq, sublogq)
        pr.start()

        if 'input_file' in config:
            parse_input_file(subq, config.input_file)
        else:
            s = Scanner(config, subq)
            s.start()
            s.join()

        pr.wait()
        get_stats().printstats()

        if sublogq is not None:
            sublogq.put(None)

        logging.info('Program exiting')
    except Exception as ex:
        logging.error('Exception %s %s' % (type(ex).__name__, ex.args))
main()
