#!/usr/bin/python3
#=======================================================================================================================
#
# Copyright 2010-2021, MATRIXX Software, Inc. All rights reserved.
#
#-----------------------------------------------------------------------------------------------------------------------
#
# @file
# @date       $Date$
#
# $Id$
#
# @2to3-3 --no-diffs -x input -x print -w  : Fri 2021-08-27T10:12:45
#
# @futurize --stage2 --no-diffs -n -w  : Mon 2021-03-01T15:52:22
#
#
#
#=======================================================================================================================
#
# DO NOT IMPORT common_functions!!
# NOTE: This file should not import common_functions nor should it import any
# file that imports common_functions. We don't want to do this because it causes
# a lot of rebuilds when someone changes common_functions.py.
#
import binascii
import pickle
import decimal
import filecmp
import inspect
import mmap
import os
import path_functions
import re
import socket
import struct
import sys
import xdrlib
import xml.dom.minidom
import xml.etree.ElementTree
import xml.sax.saxutils
import zlib

kTopDir = os.path.expandvars(os.getenv('TOPDIR', ''))
#
# Check to see what configuration file we should use. We look first
# for ${MTX_CONF_DIR}/mtx_config.xml. If it doesn't exist, then we use
# ${MTX_DATA_DIR}/mtx_config_base.xml
#
kConfDirName = os.path.expandvars(os.getenv('MTX_CONF_DIR', ''))
kDataDirName = os.path.expandvars(os.getenv('MTX_DATA_DIR', ''))
configFileName = kConfDirName + '/mtx_config.xml'
if (not os.path.exists(configFileName)):
    configFileName = kDataDirName + '/mtx_config_base.xml'
#
# DEBUG Variables
mdcDebug = False
mdcDebugParsing = False
if (int(os.getenv('MTX_PYTHON_MDC_DEBUG', 0)) != 0):
    mdcDebug = True
if (int(os.getenv('MTX_PYTHON_MDC_PARSING_DEBUG', 0)) != 0):
    mdcDebugParsing = True
#
kDataContainerDirName = kDataDirName + '/data_container'
#
# This dictionary maps the data container ID (name) to its key.
# The key is a string. The value is an integer.
kDataContainerIdToKeyDictionary = {}
#
# This dictionary maps the data container key to its ID (name).
# The key is an integer. The value is a string.
kDataContainerKeyToIdDictionary = {}
#
# This dictionary maps the data container key to its DataContainerSpec.
# The key is an integer. The value is a DataContainerSpec object.
kDataContainerKeyToSpecDictionary = {}
#
kDataContainerRelationshipDirName = kDataContainerDirName + '_relationship'
#
# This is the latest system schema version in the kDataContainerKeyToSpecDictionary
kDataContainerSpecSystemSchemaVersion = 0
#
# This is the latest service provider schema version in the kDataContainerKeyToSpecDictionary
# 0 -> find the latest.
# 1 -> the empty schema
kDataContainerSpecServProvSchemaVersion = 1
#
kDataContainerSubTypeDirName = kDataContainerDirName + '_subtype'
#
# This is a dictionary of EnumSubType objects. The key is the subtype id which is a string.
# The value is a EnumSubType object.
kEnumSubTypeDict = {}
#
# This is the format version for the mdc_config_custom.pickled file. It must be incremented
# if the format of the data or objects in this file changes.
# -- Version 2 has additional doc fields in key classes.
# -- Version 3 has kServProvSchemaVersionToRequiredSystemSchemaVersionDict
kExpectedCustomPickledFormat = 3
#
# This is the format version for the mdc_config_system.pickled file. It must be incremented
# if the format of the data or objects in this file changes.
# -- Version 4 has kEnumSubTypeDict.
# -- Version 5 has comment, rangeOidLookupList in DataContainerSpec; comment in FieldSpec.
kExpectedSystemPickledFormat = 5
#
kMaxStringBlobSizeInBytes = 65535
#
kMdcConfigCustomPickledAbsFileName = os.path.abspath(kConfDirName + '/mdc_config_custom.pickled')
#
# This is a list a tuples that pertain to the current schema of the custom MDCs. The first part of the tuple is
# the variable's name and the second part is the variable's value.
kMdcConfigCustomVariableList = []
#
kMdcConfigCustomXmlAbsFileName = os.path.abspath(kConfDirName + '/mdc_config_custom.xml')
#
kMdcConfigSystemPickledAbsFileName = os.path.abspath(kDataContainerDirName + '/mdc_config_system.pickled')
#
# This is a list a tuples that pertain to the current schema of the system MDCs. The first part of the tuple is
# the variable's name and the second part is the variable's value.
kMdcConfigSystemVariableList = []
#
# This flag is used to control the printing of certain fields that are used in creating our documentation.
# Currently this flag only changes the output of a FieldSpec and a DataContainerSpec.
kPrintDocFieldsFlag = True
#
# This is a dictionary of all data container relationship sets.
# The key is the name (a string) and the value is a list of DataContainerRelationship objects.
kRelationshipSetIdToRelationshipListDict = {}
#
# The name of the script running this code.
kScriptName = os.path.basename(sys.argv[0])
#
# This dictionary contains the mapping of all service provider schema versions to their
# required system schema version.
# The key is the service provider schema version (an integer) and the value is the
# required system schema version (an integer).
kServProvSchemaVersionToRequiredSystemSchemaVersionDict = {}
#
kThisFileName = 'data_container.py'
#
# Common prefix for printDebugMsg
# NOTE The first character is a # which allows this to be treated as a comment when it
# is written to some files.
kPrintDebugMsgPrefix = '# DEBUG: ' + kScriptName + ':' + kThisFileName + ':'
# Common prefix for printErrorMsg
kPrintErrorMsgPrefix = 'ERROR: ' + kScriptName + ':' + kThisFileName + ':'
# Common prefix for printInfoMsg
kPrintInfoMsgPrefix = 'INFO: ' + kScriptName + ':' + kThisFileName + ':'
# Common prefix for printWarningMsg
kPrintWarningMsgPrefix = 'WARNING: ' + kScriptName + ':' + kThisFileName + ':'
#
# Singleton
THE_MDC_DESCRIPTOR_INDEX = None
# Singleton
THE_MDC_DESCRIPTOR_INDEX_LIST = None

#=======================================================================================================================
# pylint: disable=bad-whitespace
# Global enums
# These values must match the values in the C++ implementation.
# In alphabetical order (except the INT<size> names)
DATA_TYPE_BLOB          = 1
DATA_TYPE_BOOLEAN       = 2
DATA_TYPE_BUFFER_ID     = 3
DATA_TYPE_DATE          = 4
DATA_TYPE_DATETIME      = 5
DATA_TYPE_DECIMAL       = 6
DATA_TYPE_FIELD_KEY     = 7
DATA_TYPE_INT8          = 8
DATA_TYPE_INT16         = 9
DATA_TYPE_INT32         = 10
DATA_TYPE_INT64         = 11
DATA_TYPE_INT128        = 12
DATA_TYPE_OBJECT_ID     = 13
DATA_TYPE_PHONE_NUMBER  = 14
DATA_TYPE_STRING        = 15
DATA_TYPE_STRUCT        = 16
DATA_TYPE_TIME          = 17
DATA_TYPE_UINT8         = 18
DATA_TYPE_UINT16        = 19
DATA_TYPE_UINT32        = 20
DATA_TYPE_UINT64        = 21
DATA_TYPE_UINT128       = 22
#
# NOTE: All DATA_TYPE_* names must be in the VALID_DATA_TYPES list.
# NOTE: All DATA_TYPE_* names must be in exactly one of the following lists:
#           INT_DATA_TYPES,
#           DECIMAL_DATA_TYPES,
#           OBJECT_DATA_TYPES,
#           STRING_DATA_TYPES.
# NOTE: A DATA_TYPE name may be in the QUOTED_DATA_TYPES list.
#
# These are data types whose values must be a Python int type
# NOTE The order in which these are specified affect the overall performance
# based upon the data_container_python_perf_test.py. So, the common types
# are first.
INT_DATA_TYPES = [
    DATA_TYPE_UINT32,
    DATA_TYPE_INT32,
    DATA_TYPE_UINT64,
    DATA_TYPE_INT64,
    DATA_TYPE_UINT8,
    DATA_TYPE_INT8,
    DATA_TYPE_BOOLEAN,
    DATA_TYPE_INT16,
    DATA_TYPE_UINT16,
    DATA_TYPE_UINT128,
    DATA_TYPE_INT128,
]
# These are data types whose values must be a Python decimal type
DECIMAL_DATA_TYPES = [
    DATA_TYPE_DECIMAL,
]
# These are data types whose values must be a Python object type
OBJECT_DATA_TYPES = [
    DATA_TYPE_STRUCT,
]
# These are data types whose values must be a Python string type
STRING_DATA_TYPES = [
    DATA_TYPE_BLOB,
    DATA_TYPE_BUFFER_ID,
    DATA_TYPE_DATE,
    DATA_TYPE_DATETIME,
    DATA_TYPE_FIELD_KEY,
    DATA_TYPE_OBJECT_ID,
    DATA_TYPE_PHONE_NUMBER,
    DATA_TYPE_STRING,
    DATA_TYPE_TIME,
]
# These are data types whose values must be quoted
QUOTED_DATA_TYPES = [
    DATA_TYPE_BLOB,
    DATA_TYPE_BUFFER_ID,
    DATA_TYPE_DATE,
    DATA_TYPE_DATETIME,
    DATA_TYPE_DECIMAL,
    DATA_TYPE_FIELD_KEY,
    DATA_TYPE_OBJECT_ID,
    DATA_TYPE_PHONE_NUMBER,
    DATA_TYPE_STRING,
    DATA_TYPE_STRUCT,
    DATA_TYPE_TIME,
]
# These are all of the valid data types
VALID_DATA_TYPES = [
    DATA_TYPE_BLOB,
    DATA_TYPE_BOOLEAN,
    DATA_TYPE_BUFFER_ID,
    DATA_TYPE_DATE,
    DATA_TYPE_DATETIME,
    DATA_TYPE_DECIMAL,
    DATA_TYPE_FIELD_KEY,
    DATA_TYPE_INT8,
    DATA_TYPE_INT16,
    DATA_TYPE_INT32,
    DATA_TYPE_INT64,
    DATA_TYPE_INT128,
    DATA_TYPE_OBJECT_ID,
    DATA_TYPE_PHONE_NUMBER,
    DATA_TYPE_STRING,
    DATA_TYPE_STRUCT,
    DATA_TYPE_TIME,
    DATA_TYPE_UINT8,
    DATA_TYPE_UINT16,
    DATA_TYPE_UINT32,
    DATA_TYPE_UINT64,
    DATA_TYPE_UINT128,
]
#
# These values must match the values that the C++ code use when using the
# MDC XML format.
# NOTE: This MUST be in the same order as the DATA_TYPE_* values!
DATA_TYPE_STRINGS = [
#   xxxxxxxxxx   << Max size
    'NONE',
    'BLOB',
    'BOOLEAN',
    'BUFFER_ID',
    'DATE',
    'DATETIME',
    'DECIMAL',
    'FIELD_KEY',
    'INT8',
    'INT16',
    'INT32',
    'INT64',
    'INT128',
    'OBJECT_ID',
    'PHONE_NO',
    'STRING',
    'STRUCT',
    'TIME',
    'UINT8',
    'UINT16',
    'UINT32',
    'UINT64',
    'UINT128',
]
#
# These values must match the values that the C++ code use when parsing the
# mtx_config.xml file.
dataTypeXmlStrToEnumDictionary = {
    # In alphabetical order
    "blob":             DATA_TYPE_BLOB,
    "bool":             DATA_TYPE_BOOLEAN,
    "buffer id":        DATA_TYPE_BUFFER_ID,
    "date":             DATA_TYPE_DATE,
    "datetime":         DATA_TYPE_DATETIME,
    "decimal":          DATA_TYPE_DECIMAL,
    "field key":        DATA_TYPE_FIELD_KEY,
    "object id":        DATA_TYPE_OBJECT_ID,
    "phone number":     DATA_TYPE_PHONE_NUMBER,
    "signed int8":      DATA_TYPE_INT8,
    "signed int16":     DATA_TYPE_INT16,
    "signed int32":     DATA_TYPE_INT32,
    "signed int64":     DATA_TYPE_INT64,
    "signed int128":    DATA_TYPE_INT128,
    "string":           DATA_TYPE_STRING,
    "struct":           DATA_TYPE_STRUCT,
    "time":             DATA_TYPE_TIME,
    "unsigned int8":    DATA_TYPE_UINT8,
    "unsigned int16":   DATA_TYPE_UINT16,
    "unsigned int32":   DATA_TYPE_UINT32,
    "unsigned int64":   DATA_TYPE_UINT64,
    "unsigned int128":  DATA_TYPE_UINT128,
}
#
# create the reverse of the dataTypeXmlStrToEnumDictionary
dataTypeEnumToXmlStrDictionary = {}
#
for (tempXmlStr, tempEnum) in list(dataTypeXmlStrToEnumDictionary.items()):
    dataTypeEnumToXmlStrDictionary[tempEnum] = tempXmlStr
#
# This dictionary maps each integer type to a tuple consisting of a lowest
# allowed value and a largest allowed value.
intDataTypeEnumToRangesDictionary = {
    DATA_TYPE_BOOLEAN:     (0, 1),
    DATA_TYPE_INT8:     (-1 * 0x80,                 0x7F),
    DATA_TYPE_INT16:    (-1 * 0x8000,               0x7FFF),
    DATA_TYPE_INT32:    (-1 * 0x80000000,           0x7FFFFFFF),
    DATA_TYPE_INT64:    (-1 * 0x8000000000000000,   0x7FFFFFFFFFFFFFFF),
    DATA_TYPE_INT128:   (-1 * 0x80000000000000000000000000000000,
        0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF),
    DATA_TYPE_UINT8:    (0, 0xFF),
    DATA_TYPE_UINT16:   (0, 0xFFFF),
    DATA_TYPE_UINT32:   (0, 0xFFFFFFFF),
    DATA_TYPE_UINT64:   (0, 0xFFFFFFFFFFFFFFFF),
    DATA_TYPE_UINT128:  (0, 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF),
}
#
# This dictionary contains the max sizes for the specific types. A value of -1
# indicates that the max size of should not be changed.
dataTypeEnumToMaxSizeDictionary = {
    # In alphabetical order
    DATA_TYPE_BLOB:         -1,
    DATA_TYPE_BOOLEAN:      1,
    DATA_TYPE_BUFFER_ID:    8,
    DATA_TYPE_DATE:         4,
    DATA_TYPE_DATETIME:     12,
    DATA_TYPE_DECIMAL:      10,
    DATA_TYPE_FIELD_KEY:    35,     # Was 15 for a 3-level FieldKey prior to 4700.
    DATA_TYPE_OBJECT_ID:    8,
    DATA_TYPE_PHONE_NUMBER: 8,
    DATA_TYPE_INT8:         1,
    DATA_TYPE_INT16:        2,
    DATA_TYPE_INT32:        4,
    DATA_TYPE_INT64:        8,
    DATA_TYPE_INT128:       16,
    DATA_TYPE_STRING:       -1,
    DATA_TYPE_STRUCT:       0,
    DATA_TYPE_TIME:         8,
    DATA_TYPE_UINT8:        1,
    DATA_TYPE_UINT16:       2,
    DATA_TYPE_UINT32:       4,
    DATA_TYPE_UINT64:       8,
    DATA_TYPE_UINT128:      16,
}
#
#=======================================================================================================================
# Verify DATA_TYPE lists
#
for tempDataType in VALID_DATA_TYPES:
    tempCount = 0
    if (tempDataType in INT_DATA_TYPES):
        tempCount += 1
    if (tempDataType in DECIMAL_DATA_TYPES):
        tempCount += 1
    if (tempDataType in OBJECT_DATA_TYPES):
        tempCount += 1
    if (tempDataType in STRING_DATA_TYPES):
        tempCount += 1
    if (tempCount == 1):
        continue
    # Error case
    raise RuntimeError('coding error: the dataType (' + str(tempDataType) + ') is not specified in exactly one of ' +
        '[INT, DECIMAL, OBJECT, STRING]_DATA_TYPES lists. Unable to continue.')
#
PRINT_FORMAT_VERBOSE    = 0
PRINT_FORMAT_COMPACT    = 1
PRINT_FORMAT_XML        = 2
#
# This list is used by print_data_container_file.py and possibly other scripts.
kMdcInputFormatStrList = [
    'compact',
    'element_xml',
    'xml',
]
kMdcOutputFormatStrList = [
    'compact',
    'descriptive',
    'element_xml',
    'xml',
]
#
# constants used in parsing (in alphabetical order)
COMMA           = ','
GREATER_THAN    = '>'
LEFT_BRACE      = '{'
LEFT_BRACKET    = '['
LESS_THAN       = '<'
NULL_CHAR       = '\0'
RIGHT_BRACE     = '}'
RIGHT_BRACKET   = ']'
SPECIAL_CHARS   = COMMA + GREATER_THAN + LEFT_BRACE + LEFT_BRACKET + LESS_THAN + NULL_CHAR + RIGHT_BRACE + RIGHT_BRACKET
#
# Field sequence type
FIELD_IS_SIMPLE = 0
FIELD_IS_ARRAY  = 1
FIELD_IS_LIST   = 2
#
VALID_SEQUENCE_TYPES = [
    FIELD_IS_SIMPLE,
    FIELD_IS_ARRAY,
    FIELD_IS_LIST,
]
#
# Field init type
FIELD_INIT_IS_NONE = 0
FIELD_INIT_IS_ONE_LIST = 1
FIELD_INIT_IS_TWO_LISTS_AND_INCREMENT = 2
FIELD_INIT_IS_COUNTER = 3
FIELD_INIT_IS_FROM_FILE = 4
FIELD_INIT_IS_CALCULATED = 5
#
ALL_FIELD_INIT_TYPES = [
    FIELD_INIT_IS_NONE,
    FIELD_INIT_IS_ONE_LIST,
    FIELD_INIT_IS_TWO_LISTS_AND_INCREMENT,
    FIELD_INIT_IS_COUNTER,
    FIELD_INIT_IS_FROM_FILE,
    FIELD_INIT_IS_CALCULATED,
]
#
VALID_FIELD_INIT_TYPES = [
    FIELD_INIT_IS_NONE,
    FIELD_INIT_IS_ONE_LIST,
    FIELD_INIT_IS_TWO_LISTS_AND_INCREMENT,
    FIELD_INIT_IS_COUNTER,
    FIELD_INIT_IS_FROM_FILE,
    FIELD_INIT_IS_CALCULATED,
]
#
ALL_CLIENT_FORMAT_TYPES = [
    'COMPACT',
    'XML',
    'RAW',
]

# Since the string module is being deprecated, we define our own constants
HEX_DIGITS = '0123456789abcdefABCDEF'

DECIMAL_INFINITY = decimal.Decimal('Infinity')
DECIMAL_NEGATIVE_INFINITY = decimal.Decimal('-Infinity')
#
TYPE_OF_FIELD_KEY       = None
TYPE_OF_INT             = type(0)
TYPE_OF_LIST            = type([])
TYPE_OF_MDC             = None

XML_HEADER = '<?xml version="1.0" encoding="iso-8859-1"?>'
#xmlHeader = '<?xml version="1.1" encoding="utf-8"?>'
#xmlHeader = '<?xml version="1.1"?>'
#xmlHeader = '<?xml version="1.1" encoding="iso-8859-1"?>'
#
reDate = re.compile(r'(\d+)\D(\d+)\D(\d+)')
reDateTime = re.compile(r'(\d+\D\d+\D\d+)\D(.*)')
rePhoneNumber = re.compile(r'([0-9a-fA-F]{1,15})$')
reTimeUtcOffset = re.compile(r'(\d{1,2}):(\d{1,2}):(\d{1,2})(?:(\.\d{1,6})){0,1}(.*)')
reStrFormat = re.compile(r'\((\d+):(.*)\)$')
# pylint: enable=bad-whitespace
#
#=======================================================================================================================
#
class FieldSpec(object):
    ''' This class represents the XML tags used to define a DataContainer field.

    The data members of this class are:

        fieldId   - contains the ID (the name) of the field. This is a string.

        comment   - contains the comment if any for the field. This is a string and may contain multiple lines.

        createdSchemaVersion - contains the schema version when this DataContainer was created. This is an integer.

        dataTypeStr  - contains the data type of the field. This is a string.

        deletedSchemaVersion - contains the schema version when this DataContainer was deleted.
                    This is an integer. A value of 0 indicates that the DataContainer has not been deleted.

        docDescription - contains a description of this field. This is used to generate documentation. This is
                    a string that can have multiple lines in it.
                    This will be None if there is no documentation for this field.
                    This will NOT end with a new-line character.
                    This will have all special XML characters escaped to their appropriate character sequence.

        docIsInternal - if this is True, then this indicates that this field is used internally and
                    should not be documented.

        docIsPresent - if this is True, then this indicates that this field is present.

        docIsRequired - if this is True, then this indicates that this field is required.

        isArray   - a boolean that if True, indicates this field is an array,

        isDeleted - a boolean that if True, indicates this field has been deleted.

        isList    - a boolean that if True, indicates this field is a list.

        isPreCreateStruct - a boolean that if True, indicates this is a pre-create struct. If this is True, then
                    the struct field will be created when the DataContainer is created.

        isReadOnly - a boolean that if True, indicates this is a read-only field.

        maxElements - indicates the maximum number of elements an array can contain. If this is 0,
                    then there is no maximum. This is an integer.

        maxSize   - indicates the maximum size of this field in bytes. This applies to STRINGs and BLOBs.
                    If this is 0, then the field does not have a maximum size. This is an integer.

        metaDataList - this is a list of tuples which consists of:
                        name  - a string.
                        value - a string. This will have all special XML characters escaped to their appropriate
                                character sequence.

        structId  - contains the DataContainer ID (name) used for this field. Otherwise this is None.

        subTypeReference - contains the name of the EnumSubType associated with this field. Otherwise this is None.
    '''
    #
    #===================================================================================================================
    # FieldSpec
    def __init__(self, fieldNode):
        self.fieldId = fieldNode.getAttribute('id')
        self.createdSchemaVersion = int(getValue(fieldNode, 'created_schema_version'))
        self.dataTypeStr = getValue(fieldNode, 'datatype')
        self.deletedSchemaVersion = int(getValue(fieldNode, 'deleted_schema_version', 0))
        #
        # Get the documentation metadata
        #
        self.docDescription = getValue(fieldNode, 'doc_description')
        self.docIsInternal = hasTag(fieldNode, 'doc_internal')
        self.docIsPresent = hasTag(fieldNode, 'doc_present')
        self.docIsRequired = hasTag(fieldNode, 'doc_required')
        #
        self.isArray = getBool(getValue(fieldNode, 'array'))
        self.isDeleted = (self.deletedSchemaVersion > 0)
        self.isList = getBool(getValue(fieldNode, 'list'))
        self.isPreCreateStruct = getBool(getValue(fieldNode, 'pre_create_struct'))
        self.isReadOnly = hasTag(fieldNode, 'read_only')
        self.maxElements = getValue(fieldNode, 'max_elements')
        self.maxSize = int(getValue(fieldNode, 'max_size', 0))
        self.metaDataList = None
        self.comment = None
        for node in fieldNode.childNodes:
            if (node.nodeName == 'metadata'):
                nodeName = ''
                nodeValue = ''
                for metaDataNode in node.childNodes:
                    if (metaDataNode.nodeType == xml.dom.Node.ELEMENT_NODE):
                        nodeName = metaDataNode.tagName
                        if (len(metaDataNode.childNodes)):
                            for childNode in metaDataNode.childNodes:
                                # Now escape any XML special characters.
                                nodeValue = xml.sax.saxutils.escape(childNode.data.strip())
                                if (self.metaDataList is None):
                                    self.metaDataList = [(nodeName, nodeValue)]
                                else:
                                    self.metaDataList.append((nodeName, nodeValue))
                                #
                            #
                        #
                    #
                #
            #
            if (node.nodeType == xml.dom.Node.COMMENT_NODE):
                # Handle multiple comments by concatenating them with a new-line in between.
                if (self.comment is None):
                    self.comment = ''
                else:
                    self.comment += '\n'
                self.comment += str(node.data)
        #
        self.structId = getValue(fieldNode, 'struct_id')
        self.subTypeReference = getValue(fieldNode, 'subtype_reference')
    #
    #===================================================================================================================
    # FieldSpec
    def __str__(self):
        return self.printStr('')
    #
    #===================================================================================================================
    # FieldSpec
    def printStr(self, indentStr='', indentFirstLine=True):
        ''' This function will return a string containing the object's member
            variables in human-readable form.

        The parameters are:

        indentStr - this contains a string that is added to the string before
                    the object's member variables are added.

        indentFirstLine - this indicates if the first line should be indented or not.

        returns   - a string containing the object's member
                    variables in human-readable form.
        '''
        # NOTE: We don't print the documentation fields: comment, docDescription, docIsInternal,
        #       docIsPresent, docIsRequired, docUsage unless kPrintDocFieldsFlag is True.
        #       They shouldn't be needed for normal use.
        global kPrintDocFieldsFlag
        #
        retStr = ''
        if (indentFirstLine):
            retStr += indentStr
        retStr += 'FieldSpec:\n'
        retStr += indentStr + '    fieldId=' + str(self.fieldId) + '\n'
        retStr += indentStr + '    createdSchemaVersion=' + str(self.createdSchemaVersion) + '\n'
        retStr += indentStr + '    dataTypeStr=' + str(self.dataTypeStr) + '\n'
        retStr += indentStr + '    deletedSchemaVersion=' + str(self.deletedSchemaVersion) + '\n'
        if (kPrintDocFieldsFlag):
            if self.comment:
                commentStr = indentMultiLineString(self.comment, indentStr + '        ')
                retStr += indentStr + '    comment=\n' + commentStr + '\n'
            else:
                retStr += indentStr + '    comment=None\n'

            if self.docDescription:
                docDescriptionStr = indentMultiLineString(self.docDescription, indentStr + '        ')
                retStr += indentStr + '    docDescription=\n' + docDescriptionStr + '\n'
            else:
                retStr += indentStr + '    docDescription=None\n'

            retStr += indentStr + '    docIsInternal=' + str(self.docIsInternal) + '\n'
            retStr += indentStr + '    docIsPresent=' + str(self.docIsPresent) + '\n'
            retStr += indentStr + '    docIsRequired=' + str(self.docIsRequired) + '\n'
        retStr += indentStr + '    isArray=' + str(self.isArray) + '\n'
        retStr += indentStr + '    isDeleted=' + str(self.isDeleted) + '\n'
        retStr += indentStr + '    isList=' + str(self.isList) + '\n'
        retStr += indentStr + '    isPreCreateStruct=' + str(self.isPreCreateStruct) + '\n'
        retStr += indentStr + '    isReadOnly=' + str(self.isReadOnly) + '\n'
        retStr += indentStr + '    maxElements=' + str(self.maxElements) + '\n'
        retStr += indentStr + '    maxSize=' + str(self.maxSize) + '\n'
        if (self.metaDataList is None):
            retStr += indentStr + '    metaDataList=None' + '\n'
        else:
            retStr += indentStr + '    metaDataList=' + '\n'
            for (metaDataName, metaDataValue) in self.metaDataList:
                retStr += indentStr + '        ' + metaDataName + '=' + metaDataValue + '\n'
            #
        #
        retStr += indentStr + '    structId=' + str(self.structId) + '\n'
        retStr += indentStr + '    subTypeReference=' + str(self.subTypeReference) + '\n'
        #
        return retStr
    #
    #===================================================================================================================
#
#=======================================================================================================================
#
class DataContainerSpec(object):
    ''' This class represents the XML tags used to define a DataContainer.

    The data members of this class are:

        containerId - contains the ID (the name) of the DataContainer. This is a string.

        key -       contains the key (the number) of the DataContainer. This is an integer.

        createdSchemaVersion - contains the schema version when this DataContainer was created. This is an integer.

        deletedSchemaVersion - contains the schema version when this DataContainer was deleted.
                    This is an integer. A value of 0 indicates that the DataContainer has not been deleted.

        baseDataContainerInfoList - if this DataContainer has a base DataContainer then this contains a list of tuples
                    that identify the base DataContainer and the starting schema version when it was valid.
                    The tuples have the format:
                        schemaVersion - an integer
                        baseContainerName - a string. A value of '' indicates that there is no base container.

        comment   - contains the comment if any for the DataContainer. This is a string and may contain multiple lines.

        docDescription - contains a description of this DataContainer. This is used to generate documentation. This is
                    a string that can have multiple lines in it.
                    This will be None if there is no documentation for this DataContainer.
                    This will NOT end with a new-line character.
                    This will have all special XML characters escaped to their appropriate character sequence.

        docIsInternal - if this is True, then this indicates that this DataContainer is used internally and
                    should not be documented.

        docUsage -  this is a string that indicates the primary use of this DataContainer. This is used to generate
                    documentation. The valid values are:
                        "ccf"
                        "database"
                        "event"
                        "message"
                        "notification"
                        "pricing"
                        "subman"
                        None

        fieldSpecList - this is a list of FieldSpec objects.

        isInitialized - this is a boolean and it indicates if the object has been initialized or not.

        joinLookupList - this is a list of strings that contains syntax used for a join lookup.

        metaDataList - this is a list of tuples which consists of:
                        name  - a string.
                        value - a string. This will have all special XML characters escaped to their appropriate
                                character sequence.

        nonUniqueLookupList - this is a list of strings that contains syntax used for a non-unique lookup.

        rangeOidLookupList - this is a list of strings that contains syntax used for a range OID lookup.

        storageSize - this is the storage size of this DataContainer. This is a string and usually is 'large'.
                    This isn't used anymore.

        uniqueLookupList - this is a list of strings that contains syntax used for a unique lookup.

    '''
    #
    #===================================================================================================================
    # DataContainerSpec
    def __init__(self, containerNode):
        global mdcDebugParsing
        #
        # Get basic fields first
        self.containerId = containerNode.getAttribute('id')
        self.key = int(getValue(containerNode, 'key'))
        self.createdSchemaVersion = int(getValue(containerNode, 'created_schema_version'))
        self.deletedSchemaVersion = int(getValue(containerNode, 'deleted_schema_version', 0))
        if (self.deletedSchemaVersion != 0):
            if (self.deletedSchemaVersion < self.createdSchemaVersion):
                printErrorMsg('The base_container\'s deleted_schema_version (' +
                    str(self.deletedSchemaVersion) + ') cannot be less than the container\'s created_schema_version (' +
                    str(self.createdSchemaVersion) + '). Found in the data container ' + self.containerId)
                printErrorMsg('Terminating')
                sys.exit(1)
        #
        # If this has a base dataContainer, identify it as such
        # Gather the list of base containers if they exist.
        # This is a list of tuples:
        #   schemaVersion - an integer
        #   baseContainerName - a string
        self.baseDataContainerInfoList = []
        lastSchemaVersion = 0
        tempSchemaVersion = 0
        for baseContainerNode in containerNode.getElementsByTagName('base_container'):
            lastSchemaVersion = tempSchemaVersion
            tempSchemaVersion = int(baseContainerNode.getAttribute('id'))
            if (tempSchemaVersion < self.createdSchemaVersion):
                printErrorMsg('The base_container\'s schema version (' + str(tempSchemaVersion) +
                    ') cannot be less than the container\'s created_schema_version (' +
                    str(self.createdSchemaVersion) + '). Found in the data container ' + self.containerId)
                printErrorMsg('Terminating')
                sys.exit(1)
            if (tempSchemaVersion < lastSchemaVersion):
                printErrorMsg('The base_container\'s schema version (' + str(tempSchemaVersion) +
                    ') cannot be less than the previous base_container\'s schema version (' +
                    str(lastSchemaVersion) + '). Found in the data container ' + self.containerId)
                printErrorMsg('Terminating')
                sys.exit(1)
            if (self.deletedSchemaVersion != 0):
                if (tempSchemaVersion > self.deletedSchemaVersion):
                    printErrorMsg('The base_container\'s schema version (' + str(tempSchemaVersion) +
                        ') cannot be greater than the container\'s deleted_schema_version (' +
                        str(self.deletedSchemaVersion) + '). Found in the data container ' + self.containerId)
                    printErrorMsg('Terminating')
                    sys.exit(1)
            tempDataContainerId = getTextFromNodeList(baseContainerNode.childNodes)
            self.baseDataContainerInfoList.append((tempSchemaVersion, tempDataContainerId))
        #
        # Get the documentation metadata
        #
        self.docDescription = getValue(containerNode, 'doc_description')
        self.docIsInternal = hasTag(containerNode, 'doc_internal')
        self.docUsage = getValue(containerNode, 'doc_usage')
        #
        # Gather the list of fields
        # This is a list of FieldSpec objects
        self.fieldSpecList = []
        for fieldNode in containerNode.getElementsByTagName('field'):
            fieldSpec = FieldSpec(fieldNode)
            if (mdcDebugParsing):
                printDebugMsg('DataContainerSpec:', 'container id=' + str(self.containerId) + \
                    ':adding fieldSpec.fieldId=' + str(fieldSpec.fieldId))
            self.fieldSpecList.append(fieldSpec)
        #
        self.joinLookupList = getValueList(containerNode, 'join_lookup')
        self.metaDataList = None
        self.comment = None
        for node in containerNode.childNodes:
            if (node.nodeName == 'metadata'):
                nodeName = ''
                nodeValue = ''
                for metaDataNode in node.childNodes:
                    if (metaDataNode.nodeType == xml.dom.Node.ELEMENT_NODE):
                        nodeName = metaDataNode.tagName
                        if (len(metaDataNode.childNodes)):
                            for childNode in metaDataNode.childNodes:
                                # Now escape any XML special characters.
                                nodeValue = xml.sax.saxutils.escape(childNode.data.strip())
                                if (self.metaDataList is None):
                                    self.metaDataList = [(nodeName, nodeValue)]
                                else:
                                    self.metaDataList.append((nodeName, nodeValue))
                                #
                            #
                        #
                    #
                #
            #
            if (node.nodeType == xml.dom.Node.COMMENT_NODE):
                # Handle multiple comments by concatenating them with a new-line in between.
                if (self.comment is None):
                    self.comment = ''
                else:
                    self.comment += '\n'
                self.comment += str(node.data)
        #
        self.nonUniqueLookupList = getValueList(containerNode, 'non_unique_lookup')
        self.rangeOidLookupList = getValueList(containerNode, 'range_oid_lookup')
        self.storageSize = getValue(containerNode, 'storage_size')
        self.uniqueLookupList = getValueList(containerNode, 'unique_lookup')
        self.isInitialized = True
    #
    #===================================================================================================================
    # DataContainerSpec
    def __str__(self):
        return self.printStr('')
    #
    #===================================================================================================================
    # DataContainerSpec
    def printStr(self, indentStr='', indentFirstLine=True):
        ''' This function will return a string containing the object's member
            variables in human-readable form.

        The parameters are:

        indentStr - this contains a string that is added to the string before
                    the object's member variables are added.

        indentFirstLine - this indicates if the first line should be indented or not.

        returns   - a string containing the object's member
                    variables in human-readable form.
        '''
        # NOTE: Normally, we don't print the documentation fields: comment, docDescription, docIsInternal,
        #       docUsage unless kPrintDocFieldsFlag is True. They shouldn't be needed
        #       for normal use.
        global kPrintDocFieldsFlag
        #
        retStr = ''
        if (indentFirstLine):
            retStr += indentStr
        retStr += 'DataContainerSpec:\n'
        # Print basic fields first
        retStr += indentStr + '    id=' + str(self.containerId) + '\n'
        retStr += indentStr + '    key=' + str(self.key) + '\n'
        retStr += indentStr + '    createdSchemaVersion=' + str(self.createdSchemaVersion) + '\n'
        retStr += indentStr + '    deletedSchemaVersion=' + str(self.deletedSchemaVersion) + '\n'
        #
        retStr += indentStr + '    baseDataContainerInfoList=' + str(self.baseDataContainerInfoList) + '\n'
        if (kPrintDocFieldsFlag):
            if self.comment:
                commentStr = indentMultiLineString(self.comment, indentStr + '        ')
                retStr += indentStr + '    comment=\n' + commentStr + '\n'
            else:
                retStr += indentStr + '    comment=None\n'

            if self.docDescription:
                docDescriptionStr = indentMultiLineString(self.docDescription, indentStr + '        ')
                retStr += indentStr + '    docDescription=\n' + docDescriptionStr + '\n'
            else:
                retStr += indentStr + '    docDescription=None\n'

            retStr += indentStr + '    docIsInternal=' + str(self.docIsInternal) + '\n'
            retStr += indentStr + '    docUsage=' + str(self.docUsage) + '\n'
        retStr += indentStr + '    isInitialized=' + str(self.isInitialized) + '\n'
        retStr += indentStr + '    joinLookupList=' + str(self.joinLookupList) + '\n'
        if (self.metaDataList is None):
            retStr += indentStr + '    metaDataList=None' + '\n'
        else:
            retStr += indentStr + '    metaDataList=' + '\n'
            for (metaDataName, metaDataValue) in self.metaDataList:
                retStr += indentStr + '        ' + metaDataName + '=' + metaDataValue + '\n'
            #
        #
        retStr += indentStr + '    nonUniqueLookupList=' + str(self.nonUniqueLookupList) + '\n'
        retStr += indentStr + '    rangeOidLookupList=' + str(self.rangeOidLookupList) + '\n'
        retStr += indentStr + '    storageSize=' + str(self.storageSize) + '\n'
        retStr += indentStr + '    uniqueLookupList=' + str(self.uniqueLookupList) + '\n'
        retStr += indentStr + '    fieldSpecList=\n'
        # pylint: disable=consider-iterating-dictionary
        for fieldSpec in self.fieldSpecList:
            tempStr = fieldSpec.printStr(indentStr=indentStr + '        ', indentFirstLine=False)
            retStr += indentStr + '        ' + tempStr + '\n'
        #
        return retStr
    #
    #===================================================================================================================
#
#=======================================================================================================================
#
class DataContainerField(object):
    ''' This class represents a field in a DataContainer and its value.

    The data members of this class are:

        name      - the name of the field. This is a string value.

        createdSchemaVersion - The schema version where this field was created.
                    This is an integer value.

        dataType  - the data type of the field. This is a numeric value and must
                    be one of these allowed values:
                        DATA_TYPE_BLOB,
                        DATA_TYPE_BOOLEAN,
                        DATA_TYPE_BUFFER_ID,
                        DATA_TYPE_DATE,
                        DATA_TYPE_DATETIME,
                        DATA_TYPE_DECIMAL,
                        DATA_TYPE_FIELD_KEY,
                        DATA_TYPE_INT8,
                        DATA_TYPE_INT16,
                        DATA_TYPE_INT32,
                        DATA_TYPE_INT64,
                        DATA_TYPE_INT128,
                        DATA_TYPE_OBJECT_ID,
                        DATA_TYPE_PHONE_NUMBER,
                        DATA_TYPE_STRING,
                        DATA_TYPE_STRUCT,
                        DATA_TYPE_TIME,
                        DATA_TYPE_UINT8,
                        DATA_TYPE_UINT16,
                        DATA_TYPE_UINT32,
                        DATA_TYPE_UINT64,
                        DATA_TYPE_UINT128

        deletedSchemaVersion - The schema version where this field was
                    deleted. If this field has not been deleted, then
                    this is 0. This is an integer value.

        docDescription - this is the documentation for this DataContainerField. This is a string.
                    This will be None if there is no documentation for this field.
                    This will NOT end with a new-line character.
                    This will have all special XML characters escaped to their appropriate character sequence.
                    NOTE: All lines that have a prefix of 12 spaces ('            ') have had it removed.

        docIsInternal - this flag if True indicates that this DataContainerField
                    is used internally.

        docIsPresent - this flag if True indicates that this DataContainerField
                    is present.

        docIsRequired - this flag if True indicates that this DataContainerField
                    is required.

        docUsage  - this indicate the documentation usage for this DataContainerField.
                    For example, 'database', 'edr', 'subman'.

        isPreCreateStruct - This boolean indicates if this this pre_create_struct
                    or not. This is a boolean.

        maxSize   - the maximum size of a string or blob field. If this is 0,
                    then there isn't a size limit.

        metaDataList - this is a list of metadata.

        sequenceType - this indicates if this field is a sequence or not.
                    This is an integer value. The possible values are:
                        0 (FIELD_IS_SIMPLE) -> not an array or a list.
                        1 (FIELD_IS_ARRAY)  -> is an array.
                        2 (FIELD_IS_LIST)   -> is a list.

        structId  - if this is a struct field, then this value indicates the
                    name of the struct (for named structs). Otherwise this is
                    ''. This is a string field.

        subTypeReference - this indicates if the field is associated with a
                    subtype definition.

        valueIdx  - the index into an array that contains this field's value.
                    This array is in the DataContainer. The type of this
                    field's value is based upon dataType. The value is stored
                    based upon the following:

                        dataType            Python type
                        -------------------------------------
                        DATA_TYPE_BLOB      string
                        DATA_TYPE_BOOLEAN   int
                        DATA_TYPE_BUFFER_ID string
                        DATA_TYPE_DATE      string
                        DATA_TYPE_DATETIME  string
                        DATA_TYPE_DECIMAL   decimal
                        DATA_TYPE_FIELD_KEY string
                        DATA_TYPE_INT8      int
                        DATA_TYPE_INT16     int
                        DATA_TYPE_INT32     int
                        DATA_TYPE_INT64     int
                        DATA_TYPE_INT128    int
                        DATA_TYPE_OBJECT_ID string
                        DATA_TYPE_PHONE_NUMBER string
                        DATA_TYPE_STRING    string
                        DATA_TYPE_STRUCT    class 'data_container.DataContainer'
                        DATA_TYPE_TIME      string
                        DATA_TYPE_UINT8     int
                        DATA_TYPE_UINT16    int
                        DATA_TYPE_UINT32    int
                        DATA_TYPE_UINT64    int
                        DATA_TYPE_UINT128   int
                    See DataContainer::setValue() for the types allowed for
                    input.

    Strings and Blobs
    =================
        The only difference between these two data types is that a STRING is
        terminated with a null. The DataContainer code does not assume an
        encoding scheme in either of these two data types. A STRING is not
        assumed to be displayable text. However, since both of these data types
        are used in input/output, an encoding scheme for input/output is needed.

        Escaped format
        ==============
        The encoding of this data is called the "escaped format". In it,
        the backslash character ('\') is used as an escape character. All
        bytes that fall into the range of (0x20 - 0x7E) ASCII characters are
        represented as a single ASCII character with the exception of the
        backslash character ('\') which is represented as two
        backslash characters ("\\")
        All other bytes are "escaped" by using the format "\hh" where hh is
        the hexadecimal value of the byte. Both hex digits must be specified.
        Lowercase letters (a-f) are used for the values greater than 9.
        For example:

          Char   Hex   I/O
          ===================
           A     41    A
           \     5c    \\
                 10    \10
                 00    \00
                 0c    \0c

        XML escaped format
        ==================
        When data is formatted for XML, we use the same encoding scheme except for
        a few differences. Note that during testing with Xerces (using XML v1.1),
        I had problems with a few displayable characters (labeled with *), so these
        are also handled differently. The differences are noted in the following
        table.

          Char   Hex   I/O      Notes
          ===========================
           &     41    &amp;
           <     3c    &lt;
           >     3e    &gt;
           '     27    &apos;
           "     22    &quot;
           `     2c    \2c     * - would terminate a string
           [     5b    \5b     * - would terminate a string
           ]     5d    \5d     * - to handle the same a [
           {     7b    \7b     * - would terminate a string
           }     7d    \7d     * - would terminate a string

        Python
        ======
        The Python code does not store the DataContainer in the same way that
        the C++ code does. It only interfaces with the C++ code via the
        "compact" or "XML" DataContainers. Since it doesn't need to store a
        STRING or BLOB in the exact binary format, it stores these values in
        the "escaped" format.

        We also use the format: (size:data) to represent STRING and BLOB data
        except when using XML formatting.
        This is preferred method since it allows you to represent a string that
        is terminated with one or more spaces. When using this format, the
        "size" is the size of the "data" in bytes when the data is not encoded.
        For example, The "size" of a single byte containing 0x0c would be 1 and
        would be represented as (1:\0c).

        EXAMPLES
        ========
        DESCRIPTIVE formatting:
            A string formatted using DESCRIPTIVE is displayed:
                (size=22, data=This is a test&string)
            A blob formatted using DESCRIPTIVE is displayed:
                (size=19, data=abcdefghijk\00\10\0912345)
                NOTE: Unprintable characters are converted to an escape sequence
                    starting with an \ following by two characters that
                    represent the hex equivalent of the character (00-FF).
                    An '\' character is converted to '\\'.

        COMPACT formatting:
            A string formatted using COMPACT is displayed:
                (22:This is a test&string)
            A blob formatted using COMPACT is displayed:
                (19:abcdefghijk\00\10\0912345)
                NOTE: Unprintable characters are converted to an escape sequence
                    starting with an \ following by two characters that
                    represent the hex equivalent of the character (00-FF).
                    An '\' character is converted to '\\'.

        XML formatting:
        A string formatted using XML is displayed:
            This is a test&amp;string
        A blob formatted using COMPACT is displayed:
            abcdefghijk\00\10\0912345
            NOTE: Unprintable characters are converted to an escape sequence
                starting with an \ following by two characters that represent
                the hex equivalent of the character (00-FF). An '\'
                character is converted to '\\'.

    Present but empty arrays/lists
    ==============================
        Arrays and lists can be present but have no elements in them. Here is
        the way these fields can be specified.

        COMPACT formatting:
            Fields that have a '{' and a '} will be treated as if they exist.
            [{},{},{},{},{}]

        XML formatting:
            <array name='FieldBoolArray' type='BOOLEAN' size='1'>
                <value></value>
            </array>

    '''
    #
    #===================================================================================================================
    # DataContainerField
    def __init__(
            self,
            name,
            dataType,
            maxSize=0,
            sequenceType=FIELD_IS_SIMPLE,
            structId='',
            valueIdx=None,
            createdSchemaVersion=0,
            deletedSchemaVersion=0,
            isPreCreateStruct=False,
            subTypeReference=None,
            docDescription=None,
            docIsInternal=False,
            docIsPresent=False,
            docIsRequired=False,
            docUsage='',
            metaDataList=None):
        #
        # Initialize from the parameters
        self.name = name
        self.createdSchemaVersion = createdSchemaVersion
        self.dataType = dataType
        self.deletedSchemaVersion = deletedSchemaVersion
        self.docDescription = docDescription
        self.docIsInternal = docIsInternal
        self.docIsPresent = docIsPresent
        self.docIsRequired = docIsRequired
        self.docUsage = docUsage
        self.isPreCreateStruct = isPreCreateStruct
        self.maxSize = maxSize
        self.metaDataList = metaDataList
        self.sequenceType = sequenceType
        self.structId = structId
        self.valueIdx = valueIdx
        self.subTypeReference = subTypeReference
        if (dataType not in VALID_DATA_TYPES):
            raise ValueError('DataContainerField: Invalid dataType (' + str(dataType) + '), name=' + name)
        if (sequenceType not in VALID_SEQUENCE_TYPES):
            raise ValueError('DataContainerField: Invalid sequenceType (' + str(sequenceType) + '), name=' + name)
    #
    #===================================================================================================================
    # DataContainerField
    def __str__(self):
        return self.printStr('')
    #
    #===================================================================================================================
    # DataContainerField
    def convertValue(self, value, mdcDescIndex=None):
        global dataTypeEnumToMaxSizeDictionary
        global kEnumSubTypeDict
        global THE_MDC_DESCRIPTOR_INDEX
        global TYPE_OF_FIELD_KEY
        global TYPE_OF_INT
        global TYPE_OF_MDC
        #
        if (value is None):
            return None
        #
        # Make a local copy of self.dataType for performance reasons.
        dataType = self.dataType
        if (dataType in INT_DATA_TYPES):
            # int32/uint32/int64/uint64 etc
            if (type(value) != TYPE_OF_INT):
                # Ok, this might be ok. we will try to convert this to an int
                try:
                    if isinstance(value, (bytes, str)):
                        if (value.lower()[0:2] == '0x'):        # This is faster than startswith('0x')
                            value = int(value, 0)
                        else:
                            if self.subTypeReference is None:
                                # No subtype reference -- preserve base behavior
                                value = int(value)
                            else:
                                # See if we can process the string as a subtype reference value
                                enumSubTypeObj = kEnumSubTypeDict.get(self.subTypeReference)
                                if enumSubTypeObj is None:
                                    # No subtype reference with this name -- just preserve original behavior
                                    value = int(value)
                                else:
                                    subTypeIntValue = enumSubTypeObj.getEnumInteger(value)
                                    if subTypeIntValue is None:
                                        # No subtype reference with this value -- just preserve original behavior
                                        value = int(value)
                                    else:
                                        # Use the value from the subtype reference
                                        value = subTypeIntValue
                        # Fall through
                    else:
                        value = int(value)
                    # Fall through
                except:
                    raise TypeError('convertValue error: you are trying to set the field (' + self.name + ') that ' + \
                        'has a dataType of (' + self.getDataTypeStr() + ') with a value (' + str(value) + \
                        ') that has the wrong type (' + str(type(value)) + '). This must be done using a ' + \
                        "type that can be converted to an 'int' type. " + 'Config file: ' + configFileName)
            # Now do a range check.
            (lowValue, highValue) = intDataTypeEnumToRangesDictionary[dataType]
            if (value < lowValue):
                raise ValueError('convertValue error: you are trying to set the field (' + self.name + \
                    ') that has a dataType of (' + self.getDataTypeStr() + ') with a value (' + str(value) + \
                    ') that is lower than the lowest allowed (' + str(lowValue) + '). ' + \
                    'Config file: ' + configFileName)
            if (value > highValue):
                raise ValueError('convertValue error: you are trying to set the field (' + self.name + \
                    ') that has a dataType of (' + self.getDataTypeStr() + ') with a value (' + str(value) + \
                    ') that is larger than the largest allowed (' + str(highValue) + '). ' + \
                    'Config file: ' + configFileName)
            return int(value)
        # Check if this is a string type
        if (dataType in STRING_DATA_TYPES):
            retValue = None
            if isinstance(value, (bytes, str)):
                # Ok, this might be ok. we will try to convert this to a str
                try:
                    # Do this in two lines to get around pylint warning:
                    #     Function return types are inconsistent
                    retValue = str(value)
                    # Fall through
                except:
                    raise TypeError('convertValue error: you are trying to set the field (' + self.name + ') that ' + \
                        'has a dataType of (' + self.getDataTypeStr() + ') with a value (' + str(value) + \
                        ') that has the wrong type (' + str(type(value)) + '). This must be done using a ' + \
                        "type that can be converted to a 'str' type. " + 'Config file: ' + configFileName)
            else:
                # Do this in two lines to get around pylint warning:
                #     Function return types are inconsistent
                retValue = str(value)
                # Fall through
            # Do some specific data types checks.
            if (dataType == DATA_TYPE_DATE):
                (valid, newValue) = validateDate(retValue)
                if (valid):
                    return newValue
                raise ValueError('convertValue error: you are trying to set the field (' + self.name + \
                    ') that has a dataType of (' + self.getDataTypeStr() + ') with a value (' + str(value) + \
                    '). ' +  newValue + ' Config file: ' + configFileName)
            if (dataType == DATA_TYPE_DATETIME):
                (valid, newValue) = validateDateTime(retValue)
                if (valid):
                    return newValue
                raise ValueError('convertValue error: you are trying to set the field (' + self.name + \
                    ') that has a dataType of (' + self.getDataTypeStr() + ') with a value (' + str(value) + \
                    '). ' +  newValue + ' Config file: ' + configFileName)
            if (dataType == DATA_TYPE_PHONE_NUMBER):
                (valid, newValue) = validatePhoneNumber(retValue)
                if (valid):
                    return newValue
                raise ValueError('convertValue error: you are trying to set the field (' + self.name + \
                    ') that has a dataType of (' + self.getDataTypeStr() + ') with a value (' + str(value) + \
                    '). ' +  newValue + ' Config file: ' + configFileName)
            if (dataType == DATA_TYPE_TIME):
                (valid, newValue) = validateTime(retValue)
                if (valid):
                    return newValue
                raise ValueError('convertValue error: you are trying to set the field (' + self.name + \
                    ') that has a dataType of (' + self.getDataTypeStr() + ') with a value (' + str(value) + \
                    '). ' +  newValue + ' Config file: ' + configFileName)
            if (dataType == DATA_TYPE_FIELD_KEY):
                if (type(value) == TYPE_OF_FIELD_KEY):
                    if (mdcDescIndex is None):
                        mdcDescIndex = THE_MDC_DESCRIPTOR_INDEX
                    # pylint: disable=E1103
                    return value.getCompactFormat(mdcDescIndex)
                # Must be a string
                # Check if it is a NULL FieldKey
                if (retValue == '0.0:0.0'):
                    return retValue
                partList = retValue.split(':')
                if (len(partList) != 2):
                    raise ValueError('convertValue error: you are trying to set the field (' + self.name + \
                        ') that has a dataType of (' + self.getDataTypeStr() + ') with a value (' + \
                        str(value) + '). Expecting a format "(<n>.<n>)+:<n>.<n>". ' + \
                        'Config file: ' + configFileName)
                subPartList = partList[1].split('.')
                if (len(subPartList) != 2):
                    raise ValueError('convertValue error: you are trying to set the field (' + self.name + \
                        ') that has a dataType of (' + self.getDataTypeStr() + ') with a value (' + \
                        str(value) + '). ). Missing a period in the data after the colon. ' + \
                        'Expecting a format "(<n>.<n>)+:<n>.<n>". Config file: ' + configFileName)
                maxSize = int(subPartList[0])
                subDataType = int(subPartList[1])
                if (subDataType not in dataTypeEnumToMaxSizeDictionary):
                    raise ValueError('convertValue error: you are trying to set the field (' + self.name + \
                        ') that has a dataType of (' + self.getDataTypeStr() + ') with a value (' + str(value) + \
                        '). Invalid fieldKey dataType (' + str(subDataType) + '). ' + \
                        'Config file: ' + configFileName)
                # Fix the maxSize if it is zero for a data type other than
                # STRING or BLOB.
                newMaxSize = dataTypeEnumToMaxSizeDictionary[subDataType]
                if (newMaxSize != -1):
                    maxSize = newMaxSize
                # Put all the data back together
                retValue = partList[0] + ':' + str(maxSize) + '.' + str(subDataType)
                return retValue
            #
            # Do some specific data types checks.
            if ((dataType == DATA_TYPE_BLOB) or (dataType == DATA_TYPE_STRING)):
                # Convert any \xx characters that are printable to the printable
                # character
                outStr = convertEscapedHexCharactersToPrintableCharacters(retValue)
                return outStr
            return retValue
        #
        # Check if this is a decimal type (decimal)
        if (dataType in DECIMAL_DATA_TYPES):
            # Ok, this might be ok. we will try to convert this to a decimal
            # NOTE: str(decimal.Decimal('INFINITY')) results in 'Infinity'
            # and str(decimal.Decimal('-INFINITY')) results in '-Infinity'
            # but we want 'INFINITY' or '-INFINITY' so that the C++ code
            # can read this.
            try:
                # Do this in two lines to get around pylint warning:
                #     Function return types are inconsistent
                # pylint: disable=redefined-variable-type
                retValue = decimal.Decimal(value)
                return retValue
            except:
                raise TypeError('convertValue error: you are trying to set the field (' + self.name + ') that ' + \
                    'has a dataType of (' + self.getDataTypeStr() + ') with a value (' + str(value) + \
                    ') that has the wrong type (' + str(type(value)) + '). This must be done using a ' + \
                    "type that can be converted to a 'decimal' type. " + 'Config file: ' + configFileName)
        # Check if this is a object type (struct)
        if (dataType in OBJECT_DATA_TYPES):
            if (type(value) != TYPE_OF_MDC):
                raise TypeError('convertValue error: you are trying to set the field (' + self.name + ') that ' + \
                    'has a dataType of (' + self.getDataTypeStr() + ') with a value (' + str(value) + \
                    ') that has the wrong type (' + str(type(value)) + '). This must be done using a ' + \
                    "'<class 'data_container.DataContainer'>' type. Config file: " + configFileName)
            return value
        raise RuntimeError('convertValue error: the dataType (' + str(dataType) + ') is not specified in any of ' + \
            '*_DATA_TYPES lists. Unable to handle it correctly.')
    #
    #===================================================================================================================
    # DataContainerField
    def formatValue(self,
            value,
            printFormat,
            indentStr='',
            onlyPresentFields=False):
        ''' This function will format the value of this field and return the
            result.

        The parameters are:

        printFormat - this indicates how to format the result. It can be
                    PRINT_FORMAT_VERBOSE, PRINT_FORMAT_COMPACT,
                    or PRINT_FORMAT_XML.

        indentStr - this contains a string that is printed before each line.
                    This is used to indent the results so that nested fields
                    are indented more than their parent field.

        onlyPresentFields - This indicates that only the fields and elements
                    that are present should be printed. If this is False, then
                    all fields are printed.

        returns   - a string with the formatted value.
        '''
        #
        global configFileName
        global DECIMAL_INFINITY
        global DECIMAL_NEGATIVE_INFINITY
        #
        # We don't need to check if the value is None since it has
        # already been checked by the getValue() method.
        #if (value is None):
        #    return ''
        #
        # TODO Do we need to do something special for DATETIME
        # BLOB, DATE, TIME or PHONE_NUM?
        #
        # Make a local copy of self.dataType for performance reasons.
        dataType = self.dataType
        if (dataType != DATA_TYPE_STRUCT):
            if (dataType == DATA_TYPE_DECIMAL):
                # Handle the special cases of INFINITY and -INFINITY. This
                # will be stored in 'value' as a decimal.Decimal(Infinity). We
                # want to return INFINITY or -INFINITY so that it matches the
                # C++ code.
                # NOTE: For performance reasons, we try to avoid the
                # calls to decimal __eql__.
                decimalStr = str(value)
                if (decimalStr[-1] == 'y'):
                    if (value == DECIMAL_INFINITY):
                        return 'INFINITY'
                    if (value == DECIMAL_NEGATIVE_INFINITY):
                        return '-INFINITY'
                return decimalStr
            if ((dataType == DATA_TYPE_INT128) or
                    (dataType == DATA_TYPE_UINT128)):
                if isinstance(value, (bytes, str)):
                    if (value.lower()[0:2] == '0x'):        # This is faster than startswith('0x')
                        hexValueStr = '0x%x' % int(value, 0)
                        return hexValueStr
                    else:
                        hexValueStr = '0x%x' % int(value)
                        return hexValueStr
                else:
                    hexValueStr = '0x%x' % value
                    return hexValueStr
            inStr = str(value)
            # If it is a STRING or BLOB, then we use a special syntax.
            if ((dataType == DATA_TYPE_STRING) or
                    (dataType == DATA_TYPE_BLOB)):
                sizeInBytes = 0
                if (inStr.find('\\') == -1):
                    sizeInBytes = len(inStr)
                else:
                    sizeInBytes = getUnescapedStrSize(inStr)
                if (sizeInBytes > kMaxStringBlobSizeInBytes):
                    raise ValueError('formatValue error: a String/Blob field (' + self.name  + ') has a value ' + \
                        'with the size of (' + str(sizeInBytes) + ') and that exceeds the maximum size (' + \
                        str(kMaxStringBlobSizeInBytes) + '. Config file: ' + configFileName)
                if (printFormat == PRINT_FORMAT_XML):
                    outStr = convertEscapedStrToEscapedXmlStr(inStr)
                    return outStr
                return inStr
            else:
                return inStr
        else:
            # The value is a DataContainer
            if (printFormat == PRINT_FORMAT_VERBOSE):
                if (value is None):
                    # This happens when we have a not-present element in
                    # an array of structs (or list of structs).
                    return ''
                return value.printStr(indentStr=indentStr + '    ', onlyPresentFields=onlyPresentFields)
            if (printFormat == PRINT_FORMAT_COMPACT):
                # Don't print the header if this has a known structId
                printHeader = True
                if (self.structId != ''):
                    printHeader = False
                return value.printCompact(printHeader)
            if (printFormat == PRINT_FORMAT_XML):
                return str(value)
            raise NameError('formatValue error: unknown format (' +  str(printFormat) + '). Field=' + \
                self.printStr('') + '. Config file: ' + configFileName)
        # Unknown type
        #raise NameError('formatValue error: unknown dataType (' + str(dataType) + '). Config file: ' + configFileName)
    #
    #===================================================================================================================
    # DataContainerField
    def getDataTypeStr(self):
        ''' This function returns the data type of this field in string format.

        returns   - a string that describes the data type of this field.
        '''
        if (self.dataType is None):
            return 'None'
        return DATA_TYPE_STRINGS[self.dataType]
    #
    #===================================================================================================================
    # DataContainerField
    def isArray(self):
        ''' This function returns True if this field is an array.

        returns   - True if this field is an array. Else it returns False.
        '''
        return (self.sequenceType == FIELD_IS_ARRAY)
    #
    #===================================================================================================================
    # DataContainerField
    def isAStruct(self):
        ''' This function returns True if this field is a struct.

        returns   - True if this field is a struct. Else it returns False.
        '''
        return (self.dataType == DATA_TYPE_STRUCT)
    #
    # TODO ADD MORE isA<dataType>
    #
    #===================================================================================================================
    # DataContainerField
    def isList(self):
        ''' This function returns True if this field is a list.

        returns   - True if this field is a list. Else it returns False.
        '''
        return (self.sequenceType == FIELD_IS_LIST)
    #
    #===================================================================================================================
    # DataContainerField
    def isSimple(self):
        ''' This function returns True if this field is not a sequence (i.e. not
            an array and not a list).

        returns   - True if this field is not a sequence. Else it returns False.
        '''
        return (self.sequenceType == FIELD_IS_SIMPLE)
    #
    #===================================================================================================================
    # DataContainerField
    def printIt(self, indentStr=''):
        ''' This function will print the object's member variables.

        The parameters are:

        indentStr - this contains a string that is printed before the object's
                    member variables are printed.
        '''
        print(self.printStr(indentStr))
    #
    #===================================================================================================================
    # DataContainerField
    def printStr(self, indentStr='', indentFirstLine=True):
        ''' This function will return a string containing the object's member
            variables in human-readable form.

        The parameters are:

        indentStr - this contains a string that is added to the string before
                    the object's member variables are added.

        indentFirstLine - this indicates if the first line should be indented or not.

        returns   - a string containing the object's member
                    variables in human-readable form.
        '''
        # NOTE: We don't print the documentation fields: docDescription, docIsInternal,
        #       docIsPresent, docIsRequired, docUsage, metaDataList. They shouldn't be
        #       needed for normal use.
        valStr = 'None'
        # TODO Check the dataType for DATA_TYPE_STRUCT
        if (self.valueIdx is not None):
            valStr = str(self.valueIdx)
        retStr = ''
        if (indentFirstLine):
            retStr += indentStr
        retStr += 'DataContainerField: name=' + str(self.name) + \
            ', createdSchemaVersion=' + str(self.createdSchemaVersion) + \
            ', dataType=' + str(self.dataType) + \
            ', deletedSchemaVersion=' + str(self.deletedSchemaVersion) + \
            ', maxSize=' + str(self.maxSize) + \
            ', sequenceType=' + str(self.sequenceType) + \
            ', structId=' + str(self.structId) + \
            ', valueIdx=' + valStr
        if (self.subTypeReference is not None):
            retStr += ', subTypeReference=' + self.subTypeReference
        return retStr
    #
    #===================================================================================================================
#
#=======================================================================================================================
#
class FieldKey(object):
    ''' This class represents a quick way to access a field in a DataContainer.

    It is composed of two lists of indexes. The reason these are
    lists is so we can support multi-level names. The first element
    in these lists refer to the top-level DataContainer. If there
    are more elements in the lists, then the field that was referenced
    in the first element but be a STRUCT. The second element in the
    lists are indexes into this STRUCT object. The same logic applies
    for any other elements in the lists.

    The data members of this class are:

        descKeyList - contains the descriptor keys of the fields being
                    referenced.

        fieldIdxList - the entries in the fieldIdxList and the descKeyList
                    should be considered paired with each other. Once the
                    container is found that has the same containerKey
                    specified in descKeyList[x], the field being referenced
                    is found by using the value in fieldIdxList[x] as the
                    index into the container's fields.

        levelCount - this indicates the number of levels in this field key.
    '''
    #
    #===================================================================================================================
    # FieldKey
    def __init__(self, descKeyList, fieldIdxList):
        self.descKeyList = tuple(descKeyList)
        self.fieldIdxList = tuple(fieldIdxList)
        self.levelCount = len(self.descKeyList)
    #
    #===================================================================================================================
    # FieldKey
    def __str__(self):
        return self.printStr('')
    #
    #===================================================================================================================
    # FieldKey
    def getCompactFormat(self, mdcDescIndex=None):
        ''' This function will return the object's compact format as a string
            that can be used as a DataContainer field's value.
        '''
        global THE_MDC_DESCRIPTOR_INDEX
        #
        level = -1
        retStr = ''
        # Go though each level one at a time and find both the
        # descriptor index and field index.
        lastDescKey = 0
        lastFieldIdx = 0
        while (True):
            level += 1
            if (level >= self.levelCount):
                break
            if (retStr):
                retStr += '.'
            lastDescKey = self.descKeyList[level]
            lastFieldIdx = self.fieldIdxList[level]
            retStr += str(lastDescKey) + '.' + str(lastFieldIdx)
        #
        # Add the ':<maxSize>.<dataType>'
        retStr += ':'
        if (mdcDescIndex is None):
            mdcDescIndex = THE_MDC_DESCRIPTOR_INDEX
        #
        # Get the DataContainerDescriptor
        descObj = mdcDescIndex.getByKey(lastDescKey)
        if (descObj is None):
            # Invalid key. Just add a default value
            printErrorMsg('Invalid field key. DataContainer key (' + str(lastDescKey) + ') was not found.')
            retStr += '0.0'
            return retStr
        #
        # Get the field
        if (lastFieldIdx >= len(descObj.fieldObjList)):
            # Invalid key. Just add a default value
            printErrorMsg('Invalid field key. DataContainer key (' + str(lastDescKey) +
                ') does not have a field index of ' + str(lastFieldIdx))
            retStr += '0.0'
            return retStr
        fieldObj = descObj.fieldObjList[lastFieldIdx]
        retStr += str(fieldObj.maxSize) + '.' + str(fieldObj.dataType)
        return retStr
    #
    #===================================================================================================================
    # FieldKey
    def printIt(self, indentStr=''):
        ''' This function will print the object's member variables.

        The parameters are:

        indentStr - this contains a string that is printed before the object's
                    member variables are printed.
        '''
        print(self.printStr(indentStr))
    #
    #===================================================================================================================
    # FieldKey
    def printStr(self, indentStr='', indentFirstLine=True):
        ''' This function will return a string containing the object's member
            variables in human-readable form.

        The parameters are:

        indentStr - this contains a string that is added to the string before
                    the object's member variables are added.

        indentFirstLine - this indicates if the first line should be indented or not.

        returns   - a string containing the object's member
                    variables in human-readable form.
        '''
        retStr = ''
        if (indentFirstLine):
            retStr += indentStr
        retStr += 'FieldKey: descKeyList=' + str(self.descKeyList) + ', fieldIdxList=' + str(self.fieldIdxList)
        return retStr
    #
    #===================================================================================================================
#
#=======================================================================================================================
#
class DataContainerDescriptorIndex(object):
    ''' This class represents an object that contains all of the known
        DataContainerDescriptors for a given system and service provider
        schema version.

    The data members of this class are:

        containerKeyToContainerIdDict - this is a dictionary that contains
                    all valid container keys and their ids.
                    The dictionary-key is the container key and the
                    dictionary-value is the container id.

        containerIdToContainerKeyDict - this is a dictionary that contains
                    all valid container ids and their keys.
                    The dictionary-key is the container id and the
                    dictionary-value is the container key.

        containerIdToFieldObjListDict - this is a dictionary that contains
                    all valid container ids and their associated field names.
                    The dictionary-key is the container id and the
                    dictionary-value is a list of DataContainerField objects.

        containerIdToBaseContainerIdDict - this is a dictionary that contains
                    all valid container ids and their associated
                    "base container" id.
                    The dictionary-key is the container id and the
                    dictionary-value is the "base container" id.

        containerIdToSchemaVersionInfoDict - this is a dictionary that contains
                    all valid container ids and their associated
                    schema version info tuple.
                    The dictionary-key is the container id and the
                    dictionary-value is the schema version info tuple which
                    is (createdSchemaVersion, deletedVersion)

        servProvSchemaVersion - This is the largest schema version of all of the
                    Service Provider containers and fields. This is an integer.

        systemSchemaVersion - This is the largest schema version of all of the
                    system containers and fields. This is an integer.
    '''
    #
    #===================================================================================================================
    # DataContainerDescriptorIndex
    def __init__(self, systemSchemaVersion=0, servProvSchemaVersion=0):
        ''' This function will create this object with the passed values.

        The parameters are:

        systemSchemaVersion - This is the schema version to use for the
                    system containers and fields. This is an integer.
                    A value of 0 means to find the latest (the largest used
                    value).

        servProvSchemaVersion - This is the schema version to use for the
                    Service Provider containers and fields. This is an integer.
                    A value of 0 means to find the latest (the largest used
                    value).
                    A value of 1 means to use the "empty" schema that.
        '''
        self.systemSchemaVersion = systemSchemaVersion
        self.servProvSchemaVersion = servProvSchemaVersion
        self.containerKeyToContainerIdDict = {}
        self.containerIdToContainerKeyDict = {}
        self.containerIdToFieldObjListDict = {}
        self.containerIdToBaseContainerIdDict = {}
        self.containerIdToSchemaVersionInfoDict = {}
        self.reset(configFileName)
    #
    #===================================================================================================================
    # DataContainerDescriptorIndex
    def __str__(self):
        return self.printStr('')
    #
    #===================================================================================================================
    # DataContainerDescriptorIndex
    def get(self, containerId):
        ''' This function returns the DataContainerDescriptor for the passed
            container id (name).

        The parameters are:

        containerId - this is the name of the DataContainer that is
                    being requested. This value should be a string.

        returns   - the DataContainerDescriptor object for the containerId.

        If you have the numeric key, then use the getByKey function.
        '''
        containerId = str(containerId)
        containerKey = self.getDescKey(containerId)
        if (containerKey == 0):
            # NOT FOUND
            return None
        baseContainerDescName = self.containerIdToBaseContainerIdDict[containerId]
        baseContainerDescKey = self.getDescKey(baseContainerDescName)
        (createdSchemaVersion, deletedVersion) = self.containerIdToSchemaVersionInfoDict[containerId]
        #
        # Create the object
        mdcDesc = DataContainerDescriptor(containerKey, containerId,
            self.containerIdToFieldObjListDict[containerId],
                baseContainerDescKey, baseContainerDescName,
                createdSchemaVersion, deletedVersion,
                self.systemSchemaVersion,
                self.servProvSchemaVersion)
        return mdcDesc
    #
    #===================================================================================================================
    # DataContainerDescriptorIndex
    def getByKey(self, containerKey):
        ''' This function returns the DataContainerDescriptor for the passed
            container key (numeric value).

        The parameters are:

        containerKey - this is the key of the DataContainer that is
                    being requested. This is an integer value.

        returns   - the DataContainerDescriptor object for the containerKey.

        If you have the id (name), then use the get function.
        '''
        containerKey = int(containerKey)
        if (containerKey == 0):
            # NOT FOUND
            return None
        if (containerKey not in self.containerKeyToContainerIdDict):
            # NOT FOUND
            return None
        containerId = self.containerKeyToContainerIdDict[containerKey]
        baseContainerDescName = self.containerIdToBaseContainerIdDict[containerId]
        baseContainerDescKey = self.getDescKey(baseContainerDescName)
        (createdSchemaVersion, deletedVersion) = self.containerIdToSchemaVersionInfoDict[containerId]
        #
        # Create the object
        mdcDesc = DataContainerDescriptor(containerKey, containerId,
            self.containerIdToFieldObjListDict[containerId],
                baseContainerDescKey, baseContainerDescName,
                createdSchemaVersion, deletedVersion,
                self.systemSchemaVersion,
                self.servProvSchemaVersion)
        return mdcDesc
    #
    #===================================================================================================================
    # DataContainerDescriptorIndex
    def getDescKey(self, containerId):
        ''' This function returns the DataContainer key (numeric value) for
            the passed DataContainer id (name).

        The parameters are:

        containerId - this is the name of the DataContainer that is
                    being requested. This is a string value.

        returns   - the DataContainer key (numeric value) for the passed
                    containerId. If not found, None will be returned.
        '''
        containerId = str(containerId)
        retVal = self.containerIdToContainerKeyDict.get(containerId, 0)
        return retVal
    #
    #===================================================================================================================
    # DataContainerDescriptorIndex
    def printIt(self, indentStr=''):
        ''' This function will print the object's member variables.

        The parameters are:

        indentStr - this contains a string that is printed before the object's
                    member variables are printed.
        '''
        print(self.printStr(indentStr))
        return
    #
    #===================================================================================================================
    # DataContainerDescriptorIndex
    def printStr(self, indentStr='', indentFirstLine=True):
        ''' This function will return a string containing the object's member
            variables in human-readable form.

        The parameters are:

        indentStr - this contains a string that is added to the string before
                    the object's member variables are added.

        indentFirstLine - this indicates if the first line should be indented or not.

        returns   - a string containing the object's member
                    variables in human-readable form.
        '''
        retStr = ''
        if (indentFirstLine):
            retStr += indentStr
        retStr += 'DataContainerDescriptorIndex:\n'
        retStr += indentStr + '    systemSchemaVersion=' + str(self.systemSchemaVersion) + '\n'
        retStr += indentStr + '    servProvSchemaVersion=' + str(self.servProvSchemaVersion)  + '\n'
        retStr += indentStr + '    containerKeyToContainerIdDict=\n'
        # pylint: disable=consider-iterating-dictionary
        for containerKey in sorted(self.containerKeyToContainerIdDict.keys()):
            containerId = self.containerKeyToContainerIdDict[containerKey]
            retStr += indentStr + '        %6d -> %-s\n' % (containerKey, containerId)
        #
        retStr += indentStr + '    containerIdToContainerKeyDict=\n'
        # pylint: disable=consider-iterating-dictionary
        for containerId in sorted(self.containerIdToContainerKeyDict.keys()):
            containerKey = self.containerIdToContainerKeyDict[containerId]
            retStr += indentStr + '        %-64s -> %6d\n' % (containerId, containerKey)
        #
        retStr += indentStr + '    containerIdToFieldObjListDict=\n'
        # pylint: disable=consider-iterating-dictionary
        for containerId in sorted(self.containerIdToFieldObjListDict.keys()):
            fieldObjList = self.containerIdToFieldObjListDict[containerId]
            retStr += indentStr + '        %-64s ->\n' % (containerId)
            for fieldObj in fieldObjList:
                retStr += indentStr + '            ' + str(fieldObj) + '\n'
        #
        retStr += indentStr + '    containerIdToBaseContainerIdDict=\n'
        # pylint: disable=consider-iterating-dictionary
        for containerId in sorted(self.containerIdToBaseContainerIdDict.keys()):
            baseContainerId = self.containerIdToBaseContainerIdDict[containerId]
            retStr += indentStr + '        %-64s -> %-64s\n' % (containerId, baseContainerId)
        #
        retStr += indentStr + '    containerIdToSchemaVersionInfoDict=\n'
        # pylint: disable=consider-iterating-dictionary
        for containerId in sorted(self.containerIdToSchemaVersionInfoDict.keys()):
            schemaVersionInfo = self.containerIdToSchemaVersionInfoDict[containerId]
            retStr += indentStr + '        %-64s -> %-s\n' % (containerId, str(schemaVersionInfo))
        #
        return retStr
    #
    #===================================================================================================================
    # DataContainerDescriptorIndex
    def readMtxConfigFile(self):
        ''' This function reads the mtx_config.xml file and creates all of the
            internal member variables.

        The global variable 'configFileName' is expected to contain the name
        of the file to read. It may be changed prior to calling this function.

        The global variables 'mdcDebug' and 'mdcDebugParsing' may be set
        before calling this function. If one or both are set, additional
        output is displayed to help in debugging.
        '''
        global configFileName
        global dataTypeXmlStrToEnumDictionary
        global kEnumSubTypeDict
        global kServProvSchemaVersionToRequiredSystemSchemaVersionDict
        global mdcDebug
        global mdcDebugParsing
        #
        # Read and parse the config file.
        configFile = None
        #
        kBaseContainerId = sys.intern('base_container')
        kContainerId = sys.intern('container')
        kContainerEnd = sys.intern('/container')
        kContainerKey = sys.intern('key')
        kCreatedSchemaVersion = sys.intern('created_schema_version')
        kDeletedSchemaVersion = sys.intern('deleted_schema_version')
        kFieldDataType = sys.intern('datatype')
        kFieldId = sys.intern('field')
        kFieldIsArray = sys.intern('array')
        kFieldIsList = sys.intern('list')
        kFieldIsPreCreateStruct = sys.intern('pre_create_struct')
        kFieldMaxSize = sys.intern('max_size')
        kFieldStructId = sys.intern('struct_id')
        kFieldSubTypeReference = sys.intern('subtype_reference')
        kFieldEnd = sys.intern('/field')
        kSubTypeId = sys.intern('subtype')
        kSubTypeIdEnd = sys.intern('/subtype')
        kSubTypeValue = sys.intern('value')

        #
        # <${nodeTag} id="${nodeIdAttr}">${nodeText}<...
        # nodeTag may contain leading slash; nodeIdAttr and nodeText are optional
        reTagStr = r'<(%s)(?: id=[\'\"](\w+)[\'\"])?>(?:([^\n]+?)<)?' % '|'.join([
            kBaseContainerId,
            kContainerId,
            kContainerEnd,
            kContainerKey,
            kCreatedSchemaVersion,
            kDeletedSchemaVersion,
            kFieldDataType,
            kFieldId,
            kFieldIsArray,
            kFieldIsList,
            kFieldIsPreCreateStruct,
            kFieldMaxSize,
            kFieldStructId,
            kFieldSubTypeReference,
            kFieldEnd,
            kSubTypeId,
            kSubTypeValue,
            kSubTypeIdEnd,
        ])
        # token can be XML comment or tag
        reToken = re.compile(r'<!--(?:.|\n)*?-->|' + reTagStr)
        if (not os.path.exists(configFileName)):
            printErrorMsg('Missing file: ' + configFileName)
            printErrorMsg('Terminating')
            sys.exit(1)
        configFile = open(configFileName, 'r')
        configText = mmap.mmap(configFile.fileno(), 0, access=mmap.ACCESS_READ)
        if (mdcDebug):
            printDebugMsg('Parsing config file: ' + configFileName)
        baseContainerId = ''
        baseContainerSchemaVersion = 0
        containerCreatedSchemaVersion = 0
        containerDeletedSchemaVersion = 0
        # if self.servProvSchemaVersion == 0, then we use this to find the latest value.
        latestServProvSchemaVersion = 1
        # if self.systemSchemaVersion == 0, then we use this to find the latest value.
        latestSystemSchemaVersion = 0
        containerId = ''
        containerKey = 0
        fieldCreatedSchemaVersion = 0
        fieldDataType = ''
        fieldDeletedSchemaVersion = 0
        fieldId = ''
        fieldIsArray = False
        fieldIsList = False
        fieldIsPreCreateStruct = False
        fieldMaxSize = 0
        fieldObjList = []
        fieldSequenceType = FIELD_IS_SIMPLE
        fieldStructId = ''
        fieldSubTypeReference = None
        insideAField = False
        skipThisField = False
        skipThisContainer = False
        lineNum = 0
        fieldValueIndex = 0
        stringToEnumTupleList = []
        subTypeId = None
        subTypeDataTypeStr = ''
        #
        # If we are looking for the latest schema values, then we need to
        # process the file twice. The first time through, we figure out the
        # latest values. The next time through, we get the appropriate containers
        # and fields.
        #
        # Are we looking for the latest value or a specific one?
        if ((self.systemSchemaVersion == 0) or (self.servProvSchemaVersion == 0)):
            if (mdcDebug):
                printDebugMsg('Pass 1: Parsing config file: ' + configFileName)
            # Looking for the latest value
            for match in reToken.finditer(configText):
                nodeTag, nodeIdAttr, nodeText = match.groups()
                if (nodeTag, nodeIdAttr, nodeText) == (None, None, None):  # comment
                    continue
                nodeTag = sys.intern(nodeTag)
                #
                # Real data
                #
                # Check for a container id (we need this for base_container checking)
                if nodeTag is kContainerId:
                    # get the container id (and save it)
                    containerId = nodeIdAttr
                    # get rid of spaces
                    containerId = containerId.replace(' ', '')
                    if (mdcDebugParsing):
                        printDebugMsg('1:Found container id ' + str(containerId))
                    continue
                #
                # Check for a container key
                if nodeTag is kContainerKey:
                    # get the container key (and save it)
                    containerKey = nodeText
                    # get rid of spaces
                    containerKey = containerKey.replace(' ', '')
                    containerKey = int(containerKey)
                    if (mdcDebugParsing):
                        printDebugMsg('1:Found container key ' + str(containerKey))
                    continue
                #
                # Check for a created_schema_version (field or container)
                if nodeTag is kCreatedSchemaVersion:
                    # get the created_schema_version (field or container)
                    fieldCreatedSchemaVersion = int(nodeText)
                    if (containerKey > 0):
                        # Our MDC
                        if (self.systemSchemaVersion == 0):
                            # Looking for the latest schema version
                            if (fieldCreatedSchemaVersion > latestSystemSchemaVersion):
                                latestSystemSchemaVersion = fieldCreatedSchemaVersion
                                if (mdcDebugParsing):
                                    printDebugMsg('1:latestSystemSchemaVersion is now ' +
                                        str(latestSystemSchemaVersion))
                    else:
                        # Service Provider MDC
                        # BERT TODO Do I need to do anything here with
                        # BERT TODO kServProvSchemaVersionToRequiredSystemSchemaVersionDict
                        if (self.servProvSchemaVersion == 0):
                            # Looking for the latest schema version
                            if (fieldCreatedSchemaVersion > latestServProvSchemaVersion):
                                latestServProvSchemaVersion = fieldCreatedSchemaVersion
                                if (mdcDebugParsing):
                                    printDebugMsg('1:latestServProvSchemaVersion is now ' +
                                        str(latestServProvSchemaVersion))
                    if (mdcDebugParsing):
                        printDebugMsg('1:Found created_schema_version ' + str(fieldCreatedSchemaVersion))
                    continue
                #
                # Check for a deleted_schema_version (field or container)
                if nodeTag is kDeletedSchemaVersion:
                    # get the field's deleted_schema_version
                    fieldDeletedSchemaVersion = int(nodeText)
                    if (containerKey > 0):
                        # Our MDC
                        if (self.systemSchemaVersion == 0):
                            # Looking for the latest
                            if (fieldDeletedSchemaVersion > latestSystemSchemaVersion):
                                latestSystemSchemaVersion = fieldDeletedSchemaVersion
                                if (mdcDebugParsing):
                                    printDebugMsg('1:latestSystemSchemaVersion is now ' +
                                        str(latestSystemSchemaVersion))
                    else:
                        # Service Provider MDC
                        # BERT TODO Do I need to do anything here with
                        # BERT TODO kServProvSchemaVersionToRequiredSystemSchemaVersionDict
                        if (self.servProvSchemaVersion == 0):
                            # Looking for the latest schema version
                            if (fieldDeletedSchemaVersion > latestServProvSchemaVersion):
                                latestServProvSchemaVersion = fieldDeletedSchemaVersion
                                if (mdcDebugParsing):
                                    printDebugMsg('1:latestServProvSchemaVersion is now ' +
                                        str(latestServProvSchemaVersion))
                    if (mdcDebugParsing):
                        printDebugMsg('Found field deleted_schema_version ' + str(fieldDeletedSchemaVersion))
                    continue
                #
                # Look for the schema version on the base container.
                # Check for a base container
                if nodeTag is kBaseContainerId:
                    # get the base container and save it
                    baseContainerSchemaVersion = int(nodeIdAttr)
                    baseContainerId = nodeText
                    # get rid of spaces
                    baseContainerId = baseContainerId.replace(' ', '')
                    if (mdcDebugParsing):
                        printDebugMsg('1:Found base container: schema version (' +
                            str(baseContainerSchemaVersion) + '), name=' +
                            str(baseContainerId) + ')')
                    # NOTE: We need to check the containerId, not the baseContainerId!
                    if (containerKey > 0):
                        # Our MDC
                        if (self.systemSchemaVersion == 0):
                            # Looking for the latest schema version
                            if (baseContainerSchemaVersion > latestSystemSchemaVersion):
                                latestSystemSchemaVersion = baseContainerSchemaVersion
                                if (mdcDebugParsing):
                                    printDebugMsg('1:latestSystemSchemaVersion is now ' +
                                        str(latestSystemSchemaVersion))
                    else:
                        # Service Provider MDC
                        # BERT TODO Do I need to do anything here with
                        # BERT TODO kServProvSchemaVersionToRequiredSystemSchemaVersionDict
                        if (self.servProvSchemaVersion == 0):
                            # Looking for the latest schema version
                            if (baseContainerSchemaVersion > latestServProvSchemaVersion):
                                latestServProvSchemaVersion = baseContainerSchemaVersion
                                if (mdcDebugParsing):
                                    printDebugMsg('1:latestServProvSchemaVersion is now ' +
                                        str(latestServProvSchemaVersion))
                    continue
            #
            configFile.close()
            configFile = open(configFileName, 'r')
            if (mdcDebug):
                printDebugMsg('Pass 2: Parsing config file: ' + configFileName)
        # Save the values found
        if (self.systemSchemaVersion == 0):
            # TODO Should this use kServProvSchemaVersionToRequiredSystemSchemaVersionDict?
            self.systemSchemaVersion = latestSystemSchemaVersion
        if (self.servProvSchemaVersion == 0):
            # Look it up in the kServProvSchemaVersionToRequiredSystemSchemaVersionDict
            servProvSchemaVersion = 1
            for key in sorted(kServProvSchemaVersionToRequiredSystemSchemaVersionDict.keys()):
                tempSystemSchemaVersion = kServProvSchemaVersionToRequiredSystemSchemaVersionDict[key]
                if (tempSystemSchemaVersion > self.systemSchemaVersion):
                    # We are done. Use the current value
                    break
                servProvSchemaVersion = key
            #
            self.servProvSchemaVersion = servProvSchemaVersion
            # OLD self.servProvSchemaVersion = latestServProvSchemaVersion
        #
        # Pass 2
        #
        # Now go through the config file for a specific schema version
        #
        # Reset the container vars
        baseContainerId = ''
        containerCreatedSchemaVersion = 0
        containerDeletedSchemaVersion = 0
        containerId = ''
        containerKey = 0
        fieldObjList = []
        fieldValueIndex = 0
        skipThisContainer = False
        #
        # Reset the field vars
        fieldId = ''
        fieldCreatedSchemaVersion = 0
        fieldDataType = ''
        fieldDeletedSchemaVersion = 0
        fieldIsArray = False
        fieldMaxSize = 0
        fieldSequenceType = FIELD_IS_SIMPLE
        fieldIsList = False
        fieldIsPreCreateStruct = False
        fieldStructId = ''
        fieldSubTypeReference = None
        insideAField = False
        skipThisField = False
        #
        lineNum = 0
        fieldIdList = []
        for match in reToken.finditer(configText):
            nodeTag, nodeIdAttr, nodeText = match.groups()
            if (nodeTag, nodeIdAttr, nodeText) == (None, None, None):  # comment
                continue
            nodeTag = sys.intern(nodeTag)
            #
            # Real data
            #
            # Check for a container id
            if nodeTag is kContainerId:
                # get the container id (and save it)
                containerId = nodeIdAttr
                # get rid of spaces
                containerId = containerId.replace(' ', '')
                if (mdcDebugParsing):
                    printDebugMsg('2:Found container id ' + str(containerId))
                fieldObjList = []
                fieldIdList = []
                continue
            #
            # Check for a container key
            if nodeTag is kContainerKey:
                # get the container key (and save it)
                containerKey = nodeText
                # get rid of spaces
                containerKey = containerKey.replace(' ', '')
                containerKey = int(containerKey)
                if (mdcDebugParsing):
                    printDebugMsg('2:Found container key ' + str(containerKey))
                continue
            #
            # Check for a base container
            if nodeTag is kBaseContainerId:
                # get the base container. Is this valid for this schema version?
                if (containerKey > 0):
                    # Our MDC
                    if (int(nodeIdAttr) > self.systemSchemaVersion):
                        # Skip this one.
                        if (mdcDebugParsing):
                            printDebugMsg('2:Found and skipping base container: ' + 'system schema version (' +
                                str(nodeIdAttr) + '), name=' + str(nodeText) + ')')
                        continue
                else:
                    # ServiceProvider MDC
                    if (int(nodeIdAttr) > self.servProvSchemaVersion):
                        # Skip this one.
                        if (mdcDebugParsing):
                            printDebugMsg('2:Found and skipping base container: ' +
                                'serviceProvider schema version (' + str(nodeIdAttr) +
                                '), name=' + str(nodeText) + ')')
                        continue
                # get the base container (and save it)
                baseContainerSchemaVersion = int(nodeIdAttr)
                baseContainerId = nodeText
                # get rid of spaces
                baseContainerId = baseContainerId.replace(' ', '')
                if (mdcDebugParsing):
                    printDebugMsg('2:Found base container: schema version (' +
                        str(baseContainerSchemaVersion) + '), name=' + str(baseContainerId) + ')')
                continue
            # Skip looking at fields if we are skipping the Container.
            if (not skipThisContainer):
                #
                # Check for a field id
                if nodeTag is kFieldId:
                    # get the field id (and save it)
                    fieldId = nodeIdAttr
                    # get rid of spaces
                    fieldId = fieldId.replace(' ', '')
                    if (mdcDebugParsing):
                        printDebugMsg('2:Found fieldId ' + str(fieldId))
                    insideAField = True
                    continue
                #
                # Check for a field's data type
                if nodeTag is kFieldDataType:
                    # get the field's data type
                    # do not get rid of spaces
                    # convert to the C++ names
                    tempFieldDataType = nodeText
                    if (tempFieldDataType not in dataTypeXmlStrToEnumDictionary):
                        printErrorMsg('The field\'s datatype (' + tempFieldDataType + ') is invalid. ' +
                            'Found on the field ' + fieldId + ' in the data container ' + containerId)
                        printErrorMsg('Terminating')
                        sys.exit(1)
                    fieldDataType = dataTypeXmlStrToEnumDictionary[tempFieldDataType]
                    if (mdcDebugParsing):
                        printDebugMsg('2:Found data type ' + str(fieldDataType))
                    continue
                #
                # Check if this is a max_size field
                if nodeTag is kFieldMaxSize:
                    # get the field max_size (and save it)
                    fieldMaxSize = nodeText
                    # get rid of spaces
                    fieldMaxSize = fieldMaxSize.replace(' ', '')
                    if (mdcDebugParsing):
                        printDebugMsg('2:Found fieldMaxSize ' + str(fieldMaxSize))
                    continue
                #
                # Check to see if the field is an array
                if nodeTag is kFieldIsArray:
                    # Check the field value
                    if (str(nodeText) == "0"):
                        continue
                    fieldIsArray = True
                    fieldSequenceType = FIELD_IS_ARRAY
                    if (mdcDebugParsing):
                        printDebugMsg('2:Found fieldIsArray=' + str(fieldIsArray))
                    continue
                #
                # Check to see if the field is a list
                if nodeTag is kFieldIsList:
                    # Check the field value
                    if (str(nodeText) == "0"):
                        continue
                    fieldIsList = True
                    fieldSequenceType = FIELD_IS_LIST
                    if (mdcDebugParsing):
                        printDebugMsg('2:Found fieldIsList=' + str(fieldIsList))
                    continue
                #
                # Check to see if the field is a pre_create_struct
                if nodeTag is kFieldIsPreCreateStruct:
                    # Check the field value
                    if (str(nodeText) == '0'):
                        continue
                    fieldIsPreCreateStruct = True
                    if (mdcDebugParsing):
                        printDebugMsg('2:Found fieldIsPreCreateStruct=' + str(fieldIsPreCreateStruct))
                    continue
                #
                # Check for a field's struct_id
                if nodeTag is kFieldStructId:
                    # get the field's struct ID
                    fieldStructId = nodeText
                    # get rid of spaces
                    fieldStructId = fieldStructId.replace(' ', '')
                    if (mdcDebugParsing):
                        printDebugMsg('2:Found field struct_id ' + str(fieldStructId))
                    continue

                #
                # Check for a field's subtype reference
                if nodeTag is kFieldSubTypeReference:
                    # get the field's struct ID
                    fieldSubTypeReference = nodeText
                    # get rid of spaces
                    fieldSubTypeReference = fieldSubTypeReference.replace(' ', '')
                    if (mdcDebugParsing):
                        printDebugMsg('2:Found field subtype_reference ' + str(fieldSubTypeReference))
                    continue

            #
            # Check for a created_schema_version (field or container)
            if nodeTag is kCreatedSchemaVersion:
                if (insideAField):
                    if (skipThisContainer):
                        continue
                    # get the field's created_schema_version
                    fieldCreatedSchemaVersion = int(nodeText)
                    # This can't be less than the creation of the data container.
                    if (fieldCreatedSchemaVersion < containerCreatedSchemaVersion):
                        printErrorMsg("The field's created_schema_version " +
                            "cannot be less than the container's created_schema_version (" +
                            str(containerCreatedSchemaVersion) + '). ' +
                            'Found on the field ' + fieldId +
                            ' in the data container ' + containerId)
                        printErrorMsg('Terminating')
                        sys.exit(1)
                    if (containerKey > 0):
                        # Our MDC
                        # Looking for a specific value. Is this field valid
                        # for this schema version?
                        if (fieldCreatedSchemaVersion > self.systemSchemaVersion):
                            skipThisField = True
                            continue
                    else:
                        # Service Provider MDC
                        # Looking for a specific value. Is this field valid
                        # for this schema version?
                        if (fieldCreatedSchemaVersion > self.servProvSchemaVersion):
                            skipThisField = True
                            continue
                    if (mdcDebugParsing):
                        printDebugMsg('2:Found field created_schema_version ' + str(fieldCreatedSchemaVersion) +
                            ', skipThisField=' + str(skipThisField))
                    continue
                #
                # get the MDC's created_schema_version
                containerCreatedSchemaVersion = int(nodeText)
                if (containerKey > 0):
                    # Our MDC
                    # Looking for a specific value. Is this MDC valid
                    # for this schema version?
                    if (containerCreatedSchemaVersion > self.systemSchemaVersion):
                        skipThisContainer = True
                        continue
                else:
                    # Service Provider MDC
                    # Looking for a specific value. Is this MDC valid
                    # for this schema version?
                    if (containerCreatedSchemaVersion > self.systemSchemaVersion):
                        skipThisContainer = True
                        continue
                if (mdcDebugParsing):
                    printDebugMsg('2:Found container created_schema_version ' + str(containerCreatedSchemaVersion) +
                        ', skipThisContainer=' + str(skipThisContainer))
                continue
            #
            # Check for a deleted_schema_version (field or container)
            if nodeTag is kDeletedSchemaVersion:
                if (insideAField):
                    if (skipThisContainer):
                        continue
                    if (skipThisField):
                        continue
                    # get the field's deleted_schema_version
                    fieldDeletedSchemaVersion = int(nodeText)
                    if (fieldDeletedSchemaVersion == 0):
                        continue
                    # This can't be less than the creation of the data container.
                    if (fieldDeletedSchemaVersion < containerCreatedSchemaVersion):
                        printErrorMsg("The field's deleted_schema_version " +
                            "cannot be less than the container's created_schema_version (" +
                            str(containerCreatedSchemaVersion) + '). ' +
                            'Found on the field ' + fieldId +
                            ' in the data container ' + containerId)
                        printErrorMsg('Terminating')
                        sys.exit(1)
                    if (containerKey > 0):
                        # Our MDC
                        # Looking for a specific value. Is this field valid
                        # for this schema version? Has is been deleted?
                        if (fieldDeletedSchemaVersion <= self.systemSchemaVersion):
                            skipThisField = True
                            continue
                    else:
                        # Service Provider MDC
                        if (fieldDeletedSchemaVersion <= self.servProvSchemaVersion):
                            skipThisField = True
                            continue
                    if (mdcDebugParsing):
                        printDebugMsg('2:Found field deleted_schema_version ' + str(fieldDeletedSchemaVersion))
                    continue
                #
                # get the MDC's deleted_schema_version
                containerDeletedSchemaVersion = int(nodeText)
                if (containerDeletedSchemaVersion == 0):
                    continue
                # This can't be less than the creation of the data container.
                if (containerDeletedSchemaVersion < containerCreatedSchemaVersion):
                    printErrorMsg("The container's deleted_schema_version " +
                        "cannot be less than the container's created_schema_version (" +
                        str(containerCreatedSchemaVersion) + '). ' +
                        'Found in the data container ' + containerId)
                    printErrorMsg('Terminating')
                    sys.exit(1)
                if (containerKey > 0):
                    # Our MDC
                    # Looking for a specific value. Is this MDC valid
                    # for this schema version? Has is been deleted?
                    if (containerDeletedSchemaVersion <= self.systemSchemaVersion):
                        skipThisContainer = True
                        continue
                else:
                    # Service Provider MDC
                    # Looking for a specific value. Is this MDC valid
                    # for this schema version? Has is been deleted?
                    if (containerDeletedSchemaVersion <= self.servProvSchemaVersion):
                        skipThisContainer = True
                        continue
                if (mdcDebugParsing):
                    printDebugMsg('2:Found container deleted_schema_version ' + str(containerDeletedSchemaVersion))
                continue
            #
            # Check to see if this is the </field>
            if nodeTag is kFieldEnd:
                # Any non-zero deleted schema version means that
                # it isn't in the schema.
                if ((not skipThisField) and (not skipThisContainer)):
                    # Create the field object and add it to the list.
                    if (mdcDebugParsing):
                        printDebugMsg('2:Adding DataContainerField fieldId ' + str(fieldId))
                    # Check for a duplicate ID/name
                    if (fieldId in fieldIdList):
                        printErrorMsg('Found a duplicated field id (' + fieldId +
                            '). Found in the data container ' + containerId)
                        printErrorMsg('Terminating')
                        sys.exit(1)
                    fieldIdList.append(fieldId)
                    fieldObj = DataContainerField(fieldId, fieldDataType,
                        maxSize=fieldMaxSize, sequenceType=fieldSequenceType,
                        structId=fieldStructId, valueIdx=fieldValueIndex,
                        createdSchemaVersion=fieldCreatedSchemaVersion,
                        deletedSchemaVersion=fieldDeletedSchemaVersion,
                        isPreCreateStruct=fieldIsPreCreateStruct,
                        subTypeReference=fieldSubTypeReference)
                    fieldValueIndex += 1
                    fieldObjList.append(fieldObj)
                    if (mdcDebugParsing):
                        printDebugMsg('2:complete field: id=' + str(fieldId) +
                            ', dataType=' + str(fieldDataType) +
                            ', sequenceType=' + str(fieldSequenceType) +
                            ', structId=' + str(fieldStructId) +
                            ', subTypeReference=' + str(fieldSubTypeReference))
                #
                # Reset the field vars
                fieldId = ''
                fieldCreatedSchemaVersion = 0
                fieldDataType = ''
                fieldDeletedSchemaVersion = 0
                fieldIsArray = False
                fieldMaxSize = 0
                fieldSequenceType = FIELD_IS_SIMPLE
                fieldIsList = False
                fieldIsPreCreateStruct = False
                fieldStructId = ''
                fieldSubTypeReference = None
                insideAField = False
                skipThisField = False
                continue
            #
            # Check to see if this is the </container>
            if nodeTag is kContainerEnd:
                # Add this container to the dictionaries.
                # Check for errors first.
                if (containerKey in self.containerKeyToContainerIdDict):
                    printErrorMsg('file: ' + configFileName +
                        ' has duplicate key value (' + str(containerKey) + '), line number=' + str(lineNum))
                    printErrorMsg('Terminating')
                    sys.exit(1)
                if (containerId in self.containerIdToContainerKeyDict):
                    printErrorMsg('file: ' + configFileName + \
                        ' has duplicate id value (' + str(containerId) + '), line number=' + str(lineNum))
                    printErrorMsg('Terminating')
                    sys.exit(1)
                # A non-zero deleted schema version means that
                # it isn't in the schema.
                if (not skipThisContainer):
                    self.containerKeyToContainerIdDict[containerKey] = containerId
                    self.containerIdToContainerKeyDict[containerId] = containerKey
                    self.containerIdToFieldObjListDict[containerId] = fieldObjList
                    self.containerIdToBaseContainerIdDict[containerId] = baseContainerId
                    self.containerIdToSchemaVersionInfoDict[containerId] = (
                        containerCreatedSchemaVersion,
                        containerDeletedSchemaVersion)
                    if (mdcDebugParsing):
                        printDebugMsg('2: complete container: id=' + containerId)
                #
                # Reset the container vars
                baseContainerId = ''
                containerCreatedSchemaVersion = 0
                containerDeletedSchemaVersion = 0
                containerId = ''
                containerKey = 0
                fieldObjList = []
                fieldValueIndex = 0
                skipThisContainer = False
                continue
            #
            # Check if subtype reference definition
            if nodeTag is kSubTypeId:
                subTypeId = nodeIdAttr
                stringToEnumTupleList = []
                if (mdcDebugParsing):
                    printDebugMsg('2:Found subtype definition=' + str(subTypeId))
                continue
            #
            # Check for a subtype's data type
            if nodeTag is kFieldDataType:
                # get the data type
                tempFieldDataType = nodeText
                if (tempFieldDataType not in dataTypeXmlStrToEnumDictionary):
                    printErrorMsg("The subtype's datatype (" + tempFieldDataType + ') is invalid. ' +
                        'Found on the subtype ' + str(subTypeId))
                    printErrorMsg('Terminating')
                    sys.exit(1)
                subTypeDataTypeStr = tempFieldDataType
            #
            # Check if subtype value
            if nodeTag is kSubTypeValue:
                if subTypeId is None:
                    continue
                subTypeInt = int(nodeIdAttr)
                subTypeStr = nodeText
                stringToEnumTupleList.append((subTypeStr, subTypeInt))
                if (mdcDebugParsing):
                    printDebugMsg('2: Found subtype value. subTypeId=' + str(subTypeId) +
                        ' ValueStr=' + subTypeStr + ' ValueInt=' + str(subTypeInt))
                continue

            #
            # Check if subtype defintion end
            if nodeTag is kSubTypeIdEnd:
                if (mdcDebugParsing):
                    printDebugMsg('Completed subtype definition. subTypeId=' + str(subTypeId) +
                        ' subTypeDataTypeStr=' + str(subTypeDataTypeStr))
                kEnumSubTypeDict[subTypeId] = EnumSubType(subTypeId, subTypeDataTypeStr, stringToEnumTupleList)
                subTypeId = None
                stringToEnumTupleList = []
                continue

        configFile.close()
        return
    #
    #===================================================================================================================
    # DataContainerDescriptorIndex
    def readSpecDictionary(self, processSystemValues=True):
        ''' This function reads the kDataContainerKeyToSpecDictionary and creates all of the
            internal member variables.

            The global variables 'mdcDebug' and 'mdcDebugParsing' may be set
            before calling this function. If one or both are set, additional
            output is displayed to help in debugging.

        The parameters are:

        processSystemValues - If this is True, then the system MDCs are processed. Otherwise the
            system MDCs are not processed.
        '''
        global dataTypeXmlStrToEnumDictionary
        global kDataContainerKeyToSpecDictionary
        global kDataContainerSpecSystemSchemaVersion
        global kDataContainerSpecServProvSchemaVersion
        global mdcDebug
        global mdcDebugParsing
        #
        if (mdcDebugParsing):
            printDebugMsg('parsing')
        baseContainerId = ''
        baseContainerSchemaVersion = 0
        containerCreatedSchemaVersion = 0
        containerDeletedSchemaVersion = 0
        containerId = ''
        containerKey = 0
        fieldCreatedSchemaVersion = 0
        fieldDataType = ''
        fieldDeletedSchemaVersion = 0
        fieldId = ''
        fieldIsArray = False
        fieldIsList = False
        fieldIsPreCreateStruct = False
        fieldMaxSize = 0
        fieldObjList = []
        fieldSequenceType = FIELD_IS_SIMPLE
        fieldStructId = ''
        fieldSubTypeReference = None
        fieldValueIndex = 0

        # If we are looking for the latest schema values, then we need to
        # process the file twice. The first time through, we figure out the
        # latest values. The next time through, we get the appropriate containers
        # and fields.
        #
        # Are we looking for the latest value or a specific one?
        if ((self.systemSchemaVersion == 0) or (self.servProvSchemaVersion == 0)):
            if (mdcDebugParsing):
                printDebugMsg('Looking for the latest schema versions')
        if ((self.systemSchemaVersion == 0) and (self.servProvSchemaVersion == 0)):
            # If both are 0, then we will use the latest of both
            self.systemSchemaVersion = kDataContainerSpecSystemSchemaVersion
            self.servProvSchemaVersion = kDataContainerSpecServProvSchemaVersion
        # Save the values found
        if (self.systemSchemaVersion == 0):
            # TODO Should this use kServProvSchemaVersionToRequiredSystemSchemaVersionDict?
            self.systemSchemaVersion = kDataContainerSpecSystemSchemaVersion
        if (self.servProvSchemaVersion == 0):
            # Look it up in the kServProvSchemaVersionToRequiredSystemSchemaVersionDict
            servProvSchemaVersion = 1
            for key in sorted(kServProvSchemaVersionToRequiredSystemSchemaVersionDict.keys()):
                tempSystemSchemaVersion = kServProvSchemaVersionToRequiredSystemSchemaVersionDict[key]
                if (tempSystemSchemaVersion > self.systemSchemaVersion):
                    # We are done. Use the current value
                    break
                servProvSchemaVersion = key
            #
            self.servProvSchemaVersion = servProvSchemaVersion
        #
        # Pass 2
        #
        # Now go through the kDataContainerKeyToSpecDictionary for a specific schema version
        if (mdcDebugParsing):
            printDebugMsg('Looking for the latest schema versions: systemSchemaVersion=' +
                str(self.systemSchemaVersion))
            printDebugMsg('len(kDataContainerKeyToIdDictionary)=' + str(len(kDataContainerKeyToIdDictionary)))
        #
        fieldIdList = []
        for containerKey in sorted(kDataContainerKeyToIdDictionary.keys()):
            if (not processSystemValues):
                if (containerKey >= 0):
                    continue
            if (mdcDebugParsing):
                printDebugMsg('Processing: containerKey=' + str(containerKey))
            dataContainerSpec = kDataContainerKeyToSpecDictionary[containerKey]
            containerId = dataContainerSpec.containerId
            containerCreatedSchemaVersion = dataContainerSpec.createdSchemaVersion
            schemaVersion = self.systemSchemaVersion
            if (containerKey < 0):
                schemaVersion = self.servProvSchemaVersion
            if (containerCreatedSchemaVersion > schemaVersion):
                # Skip this one.
                if (mdcDebugParsing):
                    printDebugMsg('Found and skipping the data container (key=' + str(containerKey) +
                        ', id=' + containerId + ') because its created_schema_version (' +
                        str(containerCreatedSchemaVersion) +
                        ') is greater than the schema version (' +
                        str(schemaVersion) + ') that we are loading.')
                continue
            #
            containerDeletedSchemaVersion = dataContainerSpec.deletedSchemaVersion
            if (containerDeletedSchemaVersion):
                # This can't be less than the creation of the data container.
                if (containerDeletedSchemaVersion < containerCreatedSchemaVersion):
                    printErrorMsg('The container\'s deleted_schema_version (' +
                        str(containerDeletedSchemaVersion) +
                        ') cannot be less than the container\'s created_schema_version (' +
                        str(containerCreatedSchemaVersion) + '). ' +
                        'Found in the data container (' + containerId + ')')
                    printErrorMsg('Terminating')
                    sys.exit(1)
                #
                if (containerDeletedSchemaVersion <= schemaVersion):
                    # Skip this one.
                    if (mdcDebugParsing):
                        printDebugMsg('Found and skipping the data container (key=' + str(containerKey) +
                            ', id=' + containerId + ') because its deleted_schema_version (' +
                            str(dataContainerSpec.deletedSchemaVersion) +
                            ') is greater than 0 and less than or equal to the schema version (' +
                            str(schemaVersion) + ') that we are loading.')
                    continue
            #
            # Check the base containers
            for (tempSchemaVersion, tempDataContainerId) in dataContainerSpec.baseDataContainerInfoList:
                if (tempSchemaVersion > schemaVersion):
                    # Skip this one.
                    if (mdcDebugParsing):
                        printDebugMsg('Found and skipping the base container (' + tempDataContainerId +
                            ') for data container (key=' + str(containerKey) +
                            ', id=' + containerId + ') because its schema version (' + str(tempSchemaVersion) +
                            ') is greater than the schema version (' +
                            str(schemaVersion) + ') that we are loading.')
                    continue
                # Use the largest one we find without exceeding self.systemSchemaVersion
                if (baseContainerSchemaVersion):
                    # Not the first one. Use the larger value.
                    if (tempSchemaVersion > baseContainerSchemaVersion):
                        baseContainerSchemaVersion = tempSchemaVersion
                        baseContainerId = tempDataContainerId
                else:
                    # First one. Use it.
                    baseContainerSchemaVersion = tempSchemaVersion
                    baseContainerId = tempDataContainerId
                #
            #
            # TODO dataContainerSpec.uniqueLookupList
            # TODO dataContainerSpec.nonUniqueLookupList
            # TODO dataContainerSpec.joinLookupList
            # TODO dataContainerSpec.storageSize
            fieldObjList = []
            fieldIdList = []
            # Process the list of FieldSpec objects
            for fieldSpec in dataContainerSpec.fieldSpecList:
                # get the field's created_schema_version
                fieldCreatedSchemaVersion = fieldSpec.createdSchemaVersion
                fieldDeletedSchemaVersion = fieldSpec.deletedSchemaVersion
                fieldId = fieldSpec.fieldId
                # This can't be less than the creation of the data container.
                if (fieldCreatedSchemaVersion < containerCreatedSchemaVersion):
                    printErrorMsg('The field\'s created_schema_version ' +
                        'cannot be less than the container\'s created_schema_version (' +
                        str(containerCreatedSchemaVersion) + '). ' +
                        'Found on the field (' + fieldId +
                        ') in the data container (' + containerId + ')')
                    printErrorMsg('Terminating')
                    sys.exit(1)
                if (fieldDeletedSchemaVersion):
                    # This can't be less than the creation of the data container.
                    if (fieldDeletedSchemaVersion < containerCreatedSchemaVersion):
                        printErrorMsg("The field's deleted_schema_version (" + str(fieldDeletedSchemaVersion) +
                            ") cannot be less than the container's created_schema_version (" +
                            str(containerCreatedSchemaVersion) + '). ' +
                            'Found on the field (' + fieldId + ') in the data container (' + containerId + ')')
                        printErrorMsg('Terminating')
                        sys.exit(1)
                    # Looking for a specific value. Is this field valid
                    # for this schema version? Has is been deleted?
                    if (fieldDeletedSchemaVersion <= schemaVersion):
                        # Skip this one.
                        if (mdcDebugParsing):
                            printDebugMsg('Found and skipping the field (' + fieldId +
                                ') for data container (key=' + str(containerKey) +
                                ', id=' + containerId + ') because its deleted_schema_version (' +
                                str(fieldDeletedSchemaVersion) +
                                ') is greater than zero and less than or equal to the schema version (' +
                                str(schemaVersion) + ') that we are loading.')
                        continue
                    #
                #
                # Is this field valid for this schema version?
                if (fieldCreatedSchemaVersion > schemaVersion):
                    # Skip this one.
                    if (mdcDebugParsing):
                        printDebugMsg('Found and skipping the field (' + fieldId +
                            ') for data container (key=' + str(containerKey) +
                            ', id=' + containerId + ') because its createdSchemaVersion (' +
                            str(fieldCreatedSchemaVersion) +
                            ') is greater than the schema version (' +
                            str(schemaVersion) + ') that we are loading.')
                    continue
                #
                # get the field's data type. do not get rid of spaces.
                # convert to the C++ names
                tempFieldDataTypeStr = fieldSpec.dataTypeStr
                if (tempFieldDataTypeStr not in dataTypeXmlStrToEnumDictionary):
                    printErrorMsg('The field\'s datatype (' + tempFieldDataTypeStr + ') is invalid. ' +
                        'Found on the field (' + fieldId + ') in the data container (' + containerId + ')')
                    printErrorMsg('Terminating')
                    sys.exit(1)
                fieldDataType = dataTypeXmlStrToEnumDictionary[tempFieldDataTypeStr]
                if (mdcDebugParsing):
                    printDebugMsg('Found data type ' + str(fieldDataType))
                fieldMaxSize = fieldSpec.maxSize
                if (fieldSpec.isArray):
                    fieldIsArray = True
                    fieldSequenceType = FIELD_IS_ARRAY
                    if (mdcDebugParsing):
                        printDebugMsg('Found fieldIsArray=' + str(fieldIsArray))
                    #
                elif (fieldSpec.isList):
                    fieldIsList = True
                    fieldSequenceType = FIELD_IS_LIST
                    if (mdcDebugParsing):
                        printDebugMsg('Found fieldIsList=' + str(fieldIsList))
                    #
                if (fieldSpec.isPreCreateStruct):
                    fieldIsPreCreateStruct = True
                    if (mdcDebugParsing):
                        printDebugMsg('Found fieldIsPreCreateStruct=' + str(fieldIsPreCreateStruct))
                    #
                if (fieldSpec.structId is not None):
                    # get the field's struct ID
                    fieldStructId = fieldSpec.structId
                    if (mdcDebugParsing):
                        printDebugMsg('Found field struct_id ' + str(fieldStructId))
                    #
                if (fieldSpec.subTypeReference is not None):
                    # get the field's struct ID
                    fieldSubTypeReference = fieldSpec.subTypeReference
                    if (mdcDebugParsing):
                        printDebugMsg('Found field subtype_reference ' + str(fieldSubTypeReference))
                    #
                #
                # Create the field object and add it to the list.
                if (mdcDebugParsing):
                    printDebugMsg('Adding DataContainerField fieldId ' + str(fieldId))
                # Check for a duplicate ID/name
                if (fieldId in fieldIdList):
                    printErrorMsg('found a duplicated field id (' + fieldId +  '). Found in the data container ' +
                        containerId)
                    printErrorMsg('Terminating')
                    sys.exit(1)
                fieldIdList.append(fieldId)
                fieldObj = DataContainerField(fieldId, fieldDataType,
                    maxSize=fieldMaxSize, sequenceType=fieldSequenceType,
                    structId=fieldStructId, valueIdx=fieldValueIndex,
                    createdSchemaVersion=fieldCreatedSchemaVersion,
                    deletedSchemaVersion=fieldDeletedSchemaVersion,
                    isPreCreateStruct=fieldIsPreCreateStruct,
                    subTypeReference=fieldSubTypeReference)
                fieldValueIndex += 1
                fieldObjList.append(fieldObj)
                if (mdcDebugParsing):
                    printDebugMsg('complete field: id=' +
                        str(fieldId) +
                        ', dataType=' + str(fieldDataType) +
                        ', sequenceType=' + str(fieldSequenceType) +
                        ', structId=' + str(fieldStructId) +
                        ', subTypeReference=' + str(fieldSubTypeReference))
                #
                # Reset the field vars
                fieldId = ''
                fieldCreatedSchemaVersion = 0
                fieldDataType = ''
                fieldDeletedSchemaVersion = 0
                fieldIsArray = False
                fieldMaxSize = 0
                fieldSequenceType = FIELD_IS_SIMPLE
                fieldIsList = False
                fieldIsPreCreateStruct = False
                fieldStructId = ''
                fieldSubTypeReference = None
                continue
            # end of for fieldSpec in dataContainerSpec.fieldSpecList
            #
            # Add this container to the dictionaries.
            # Check for errors first.
            if (containerKey in self.containerKeyToContainerIdDict):
                printErrorMsg('file: ' + configFileName + ' has duplicate key value (' +
                    str(containerKey) + ')')
                printErrorMsg('Terminating')
                sys.exit(1)
            if (containerId in self.containerIdToContainerKeyDict):
                printErrorMsg('file: ' + configFileName + ' has duplicate id value (' +
                    str(containerId) + ')')
                printErrorMsg('Terminating')
                sys.exit(1)
            # Add this container.
            self.containerKeyToContainerIdDict[containerKey] = containerId
            self.containerIdToContainerKeyDict[containerId] = containerKey
            self.containerIdToFieldObjListDict[containerId] = fieldObjList
            self.containerIdToBaseContainerIdDict[containerId] = baseContainerId
            self.containerIdToSchemaVersionInfoDict[containerId] = (
                containerCreatedSchemaVersion,
                containerDeletedSchemaVersion)
            if (mdcDebugParsing):
                printDebugMsg('complete container: id=' + containerId)
            #
            # Reset the container vars
            baseContainerId = ''
            baseContainerSchemaVersion = 0
            containerCreatedSchemaVersion = 0
            containerDeletedSchemaVersion = 0
            containerId = ''
            containerKey = 0
            fieldObjList = []
            fieldValueIndex = 0
            continue
        # end of for containerKey in sorted(kDataContainerKeyToIdDictionary.keys())
        # NOTE subtypes are not handled here.
        return
    #
    #===================================================================================================================
    # DataContainerDescriptorIndex
    def reset(self, mtxConfigFile):
        ''' This function resets all of this object's dictionaries and re-reads the
            DataContainerSpec in the pickled file.

            self.servProvSchemaVersion and self.systemSchemaVersion must be
            set before calling this function.
        '''
        global configFileName
        global kDataDirName
        global kDataContainerKeyToSpecDictionary
        global mdcDebug
        global mdcDebugParsing
        #
        self.containerKeyToContainerIdDict = {}
        self.containerIdToContainerKeyDict = {}
        self.containerIdToFieldObjListDict = {}
        self.containerIdToBaseContainerIdDict = {}
        self.containerIdToSchemaVersionInfoDict = {}
        # Add the reserved value
        self.containerKeyToContainerIdDict[0] = 'Unknown'
        self.containerIdToContainerKeyDict['Unknown'] = 0
        #
        # Read in the mtx_config.xml file and populate the member variables of this class
        #
        # TODO: Should I do something different based on passed mtxConfigFile???
        #
        if (mdcDebugParsing):
            printDebugMsg('mtxConfigFile is not used. mtxConfigFile=' + mtxConfigFile)
        #mdcDebug = True
        #mdcDebugParsing = True
        if (kDataContainerKeyToSpecDictionary):
            # Use this dictionary to create the other dictionaries
            if (mdcDebugParsing):
                printDebugMsg('calling readSpecDictionary()')
            self.readSpecDictionary()
        else:
            # Initial mode where no pickled file exists.
            dirName = kDataDirName + '/data_container'
            for mdcFileName in sorted(os.listdir(dirName)):
                if (not mdcFileName.endswith('.xml')):
                    continue
                configFileName = dirName + '/' + mdcFileName
                if (mdcDebugParsing):
                    printDebugMsg('reading ' + configFileName)
                self.readMtxConfigFile()
        #
    #
    #===================================================================================================================
    # DataContainerDescriptorIndex
    def updateFrom(self, otherMdcDescIndex, systemFileFlag):
        '''
        This function will take the appropriate data from otherMdcDescIndex based upon systemFileFlag and use it
        to update this object.

        The parameters are:

        otherMdcDescIndex - This is the DataContainerDescriptorIndex to use as input to update this object.

        systemFileFlag - If this is True, then an mdc_config_system.pickled file is created. Otherwise,
            an mdc_config_custom.pickled file is created.

        It does not return anything.
        '''
        #
        # Handle the containerKeyToContainerIdDict and containerIdToContainerKeyDict
        tempDictionary = otherMdcDescIndex.containerKeyToContainerIdDict
        # Instead of blindly updating our variable with this information, we will make sure we
        # only add the appropriate keys
        for key in sorted(tempDictionary.keys()):
            if (systemFileFlag):
                # Don't include negative values.
                if (key < 0):
                    continue
            else:
                # Don't include positive values
                if (key >= 0):
                    # We break here because the list is sorted.
                    break
            containerId = tempDictionary[key]
            self.containerKeyToContainerIdDict[key] = containerId
            self.containerIdToContainerKeyDict[containerId] = key
        #
        # Handle the containerIdToFieldObjListDict
        tempDictionary = otherMdcDescIndex.containerIdToFieldObjListDict
        # Instead of blindly updating our variable with this information, we will make sure we
        # only add the appropriate keys
        for key in tempDictionary:
            if (key not in self.containerIdToContainerKeyDict):
                printErrorMsg('Unknown DataContainer Id=(' + key +
                    ") found in the passed DataContainerDescriptorIndex's containerIdToFieldObjListDict. " +
                    "Skipping this element.")
                #raise RuntimeError('how did we get here:')
                continue
            containerKey = self.containerIdToContainerKeyDict[key]
            if (systemFileFlag):
                # Don't include negative values.
                if (containerKey < 0):
                    continue
            else:
                # Don't include positive values
                if (containerKey >= 0):
                    continue
            self.containerIdToFieldObjListDict[key] = tempDictionary[key]
        #
        # Handle the containerIdToBaseContainerIdDict
        tempDictionary = otherMdcDescIndex.containerIdToBaseContainerIdDict
        # Instead of blindly updating our variable with this information, we will make sure we
        # only add the appropriate keys
        for key in tempDictionary:
            if (key not in self.containerIdToContainerKeyDict):
                printErrorMsg('Unknown DataContainer Id=(' + key +
                    ") found in the passed DataContainerDescriptorIndex's containerIdToBaseContainerIdDict. " +
                    "Skipping this element.")
                continue
            containerKey = self.containerIdToContainerKeyDict[key]
            if (systemFileFlag):
                # Don't include negative values.
                if (containerKey < 0):
                    continue
            else:
                # Don't include positive values
                if (containerKey >= 0):
                    continue
            self.containerIdToBaseContainerIdDict[key] = tempDictionary[key]
        #
        # Handle the containerIdToSchemaVersionInfoDict
        tempDictionary = otherMdcDescIndex.containerIdToSchemaVersionInfoDict
        # Instead of blindly updating our variable with this information, we will make sure we
        # only add the appropriate keys
        for key in tempDictionary:
            if (key not in self.containerIdToContainerKeyDict):
                printErrorMsg('Unknown DataContainer Id=(' + key +
                    ") found in the passed DataContainerDescriptorIndex's containerIdToSchemaVersionInfoDict. " +
                    "Skipping this element.")
                continue
            containerKey = self.containerIdToContainerKeyDict[key]
            if (systemFileFlag):
                # Don't include negative values.
                if (containerKey < 0):
                    continue
            else:
                # Don't include positive values
                if (containerKey >= 0):
                    continue
            self.containerIdToSchemaVersionInfoDict[key] = tempDictionary[key]
        #
        if (systemFileFlag):
            self.systemSchemaVersion = otherMdcDescIndex.systemSchemaVersion
        else:
            self.servProvSchemaVersion = otherMdcDescIndex.servProvSchemaVersion
    #
    #===================================================================================================================
#
#=======================================================================================================================
#
class DataContainerDescriptorIndexList(object):
    ''' This class contains a list of all the DataContainerDescriptorIndex
        currently being used.

    The data members of this class are:

        dataContainerDescriptorIndexList - the list of DataContainerDescriptorIndex objects.
    '''
    #
    #===================================================================================================================
    # DataContainerDescriptorIndexList
    def __init__(self):
        global THE_MDC_DESCRIPTOR_INDEX
        #
        self.dataContainerDescriptorIndexList = [THE_MDC_DESCRIPTOR_INDEX]
    #
    #===================================================================================================================
    # DataContainerDescriptorIndexList
    def __str__(self):
        return self.printStr('')
    #
    #===================================================================================================================
    # DataContainerDescriptorIndexList
    def getDescriptor(self,
            containerId,
            systemSchemaVersion=0,
            servProvSchemaVersion=0,
            addIfNotFound=True):
        ''' This function will look through the list to find a
            DataContainerDescriptorIndex that matches systemSchemaVersion
            and servProvSchemaVersion. If it isn't found, it is added if
            addIfNotFound is True. If one is not found, then None is returned.
            The found/added DataContainerDescriptorIndex is then used to find
            the DataContainerDescriptor based upon the containerId (name).
            The found object is returned. If one is not found, None is returned.
            Use getDescriptorByKey() if you want to find it by the container key.

        The parameters are:

        containerId - this is the Id of the DataContainer (name) that is
                    being requested. This is a string value.

        systemSchemaVersion - This is the system schema version to look for.
                    If this is 0, then the largest system schema version found
                    in the mtx_config.xml file will be used.
                    This is an integer value.

        servProvSchemaVersion - This is the Service Provider schema version to
                    look for. If this is 0, then the largest Service Provider
                    schema version found in the mtx_config.xml file will be used.
                    This is an integer value.

        addIfNotFound - If a matching DataContainerDescriptorIndex is not found
                    and this is True, a new one is added.

        returns   - the DataContainerDescriptorIndex for the passed
                    containerId. If not found and addIfNotFound=False, then
                    None will be returned.
        '''
        dataContainerDescriptorIndex = self.getDescriptorIndex(
            systemSchemaVersion, servProvSchemaVersion, addIfNotFound)
        if (not dataContainerDescriptorIndex):
            return None
        return dataContainerDescriptorIndex.get(containerId)
    #
    #===================================================================================================================
    # DataContainerDescriptorIndexList
    def getDescriptorByKey(self,
            containerKey,
            systemSchemaVersion=0,
            servProvSchemaVersion=0,
            addIfNotFound=True):
        ''' This function will look through the list to find a
            DataContainerDescriptorIndex that matches systemSchemaVersion
            and servProvSchemaVersion. If it isn't found, it is added if
            addIfNotFound is True. If one is not found, then None is returned.
            The found/added DataContainerDescriptorIndex is then used to find
            the DataContainerDescriptor based upon the containerKey (an integer
            value). The found object is returned. If one is not found, None is
            returned.
            Use getDescriptor() if you want to find it by the containerId (name).

        The parameters are:

        containerKey - this is the key of the DataContainer that is
                    being requested. This is an integer value.

        systemSchemaVersion - This is the system schema version to look for.
                    If this is 0, then the largest system schema version found
                    in the mtx_config.xml file will be used.
                    This is an integer value.

        servProvSchemaVersion - This is the Service Provider schema version to
                    look for. If this is 0, then the largest Service Provider
                    schema version found in the mtx_config.xml file will be used.
                    This is an integer value.

        addIfNotFound - If a matching DataContainerDescriptorIndex is not found
                    and this is True, a new one is added.

        returns   - the DataContainerDescriptorIndex for the passed
                    containerId. If not found and addIfNotFound=False, then
                    None will be returned.
        '''
        dataContainerDescriptorIndex = self.getDescriptorIndex(
            systemSchemaVersion, servProvSchemaVersion, addIfNotFound)
        if (not dataContainerDescriptorIndex):
            return None
        return dataContainerDescriptorIndex.getByKey(containerKey)
    #
    #===================================================================================================================
    # DataContainerDescriptorIndexList
    def getDescriptorIndex(self,
            systemSchemaVersion=0,
            servProvSchemaVersion=0,
            addIfNotFound=True):
        ''' This function will look through the list to find a
            DataContainerDescriptorIndex that matches systemSchemaVersion
            and servProvSchemaVersion. If it isn't found, it is added if
            addIfNotFound is True. The found/added DataContainerDescriptorIndex
            is returned. If one is not found, then None is returned.

        The parameters are:

        systemSchemaVersion - This is the system schema version to look for.
                    If this is 0, then the largest system schema version found
                    in the mtx_config.xml file will be used.
                    This is an integer value.

        servProvSchemaVersion - This is the Service Provider schema version to
                    look for. If this is 0, then the largest Service Provider
                    schema version found in the mtx_config.xml file will be used.
                    If systemSchemaVersion is non-zero, then if this is zero, then
                    the largest Service Provider schema version that is valid for
                    specified systemSchemaVersion value.
                    This is an integer value.

        addIfNotFound - If a matching DataContainerDescriptorIndex is not found
                    and this is True, a new one is added.

        returns   - the DataContainerDescriptorIndex for the passed
                    containerId. If not found and addIfNotFound=False, then
                    None will be returned.
        '''
        global kServProvSchemaVersionToRequiredSystemSchemaVersionDict
        global mdcDebug
        #
        # NOTE: the 0, 0 schema version is always the first one.
        if ((systemSchemaVersion == 0) and (servProvSchemaVersion == 0)):
            return self.dataContainerDescriptorIndexList[0]
        if (systemSchemaVersion == 0):
            # TODO Should this use kServProvSchemaVersionToRequiredSystemSchemaVersionDict?
            systemSchemaVersion = self.dataContainerDescriptorIndexList[0].systemSchemaVersion
        if (servProvSchemaVersion == 0):
            # Look it up in the kServProvSchemaVersionToRequiredSystemSchemaVersionDict
            servProvSchemaVersion = 1
            for key in sorted(kServProvSchemaVersionToRequiredSystemSchemaVersionDict.keys()):
                tempSystemSchemaVersion = kServProvSchemaVersionToRequiredSystemSchemaVersionDict[key]
                if (tempSystemSchemaVersion > systemSchemaVersion):
                    # We are done. Use the current value
                    break
                servProvSchemaVersion = key
            #
        #
        for dataContainerDescriptorIndex in self.dataContainerDescriptorIndexList:
            if (dataContainerDescriptorIndex.systemSchemaVersion != systemSchemaVersion):
                continue
            if (dataContainerDescriptorIndex.servProvSchemaVersion != servProvSchemaVersion):
                continue
            return dataContainerDescriptorIndex
        # Not found, should we add it
        if (not addIfNotFound):
            return None
        dataContainerDescriptorIndex = DataContainerDescriptorIndex(systemSchemaVersion, servProvSchemaVersion)
        if (not dataContainerDescriptorIndex):
            raise ValueError('DataContainerDescriptorIndexList::getDescriptorIndex error: ' + \
                'invalid schema version (' + str(systemSchemaVersion) + ', ' + \
                str(servProvSchemaVersion) + '). Config file: ' + configFileName)
        if (mdcDebug):
            printDebugMsg('new DataContainerDescriptorIndex added for schema version (' +
                str(systemSchemaVersion) + ', ' + str(servProvSchemaVersion) + ').')
        self.dataContainerDescriptorIndexList.append(dataContainerDescriptorIndex)
        return dataContainerDescriptorIndex
    #
    #===================================================================================================================
    # DataContainerDescriptorIndexList
    def printIt(self, indentStr=''):
        ''' This function will print the object's member variables.

        The parameters are:

        indentStr - this contains a string that is printed before the object's
                    member variables are printed.
        '''
        print(self.printStr(indentStr))
        return
    #
    #===================================================================================================================
    # DataContainerDescriptorIndexList
    def printStr(self, indentStr='', indentFirstLine=True):
        ''' This function will return a string containing the object's member
            variables in human-readable form.

        The parameters are:

        indentStr - this contains a string that is added to the string before
                    the object's member variables are added.

        indentFirstLine - this indicates if the first line should be indented or not.

        returns   - a string containing the object's member
                    variables in human-readable form.
        '''
        retStr = ''
        if (indentFirstLine):
            retStr += indentStr
        retStr += 'DataContainerDescriptorIndexList: ' '\n'
        idx = 0
        for dataContainerDescriptorIndex in self.dataContainerDescriptorIndexList:
            retStr += dataContainerDescriptorIndex.printStr(indentStr + '    ' + str(idx)) + '\n'
            idx += 1
        return retStr
    #
    #===================================================================================================================
#
#=======================================================================================================================
#
class DataContainerDescriptor(object):
    ''' This class contains all of the information about a DataContainer that
        doesn't change for each DataContainer instance.

    The data members of this class are:

        containerKey - the unique key used to identify a specific
                    DataContainerDescriptor. This is a numeric value.
                    Note: a value of zero (0) indicates an uninitialized
                    object.

        containerId - the unique id (name) used to identify a specific
                    DataContainerDescriptor. This is a string value.

        baseContainerKey - this is the container key (a numeric value) of the
                    base container for this container. If this container does
                    not have a base container, then this will be zero (0).
                    This is a numeric value.

        baseContainerId - this is the container id (name) of the base
                    container for this container. If this container does
                    not have a base container, then this will be ''.
                    This is a string value.

        createdSchemaVersion - The schema version where this container was
                    created. This is an integer value.

        deletedSchemaVersion - The schema version where this container was
                    deleted. If this container has not been deleted, then
                    this is 0. This is an integer value.

        descIndex - this is the DataContainerDescriptorIndex used by this object.

        descObjList - this is a list of DataContainerDescriptor objects. This
                    is created during __init__. To make the code simplier,
                    the first element (index 0) is a reference to this
                    object (self). This will be the only element if this object
                    does not have a base container (baseContainerId == '').
                    If it does have a base container, then the second element
                    in this list is the DataContainerDescriptor object for
                    the base container. If this object also has a base
                    container, then the next element contains its
                    DataContainerDescriptor object, etc.

        docDescription - this is the documentation for this DataContainer. This is a string.
                    This will be None if there is no documentation for this DataContainer.
                    This will NOT end with a new-line character.
                    This will have all special XML characters escaped to their appropriate character sequence.
                    NOTE: All lines that have a prefix of 12 spaces ('            ') have had it removed.

        docIsInternal - this flag if True indicates that this DataContainer
                    is used internally.

        docUsage  - this indicate the documentation usage for this DataContainer.
                    For example, 'database', 'edr', 'subman'.

        fieldObjList - this is a list of the DataContainerField objects
                    that make up this object.

        fieldNameList - this is a list of names that match the
                    fieldObjList. The reason we have this is to make it
                    easier to search for a field's name.

        metaDataList - this is a list of metadata.

        servProvSchemaVersion - This is the container's current schema version
                    for its Service Provider fields. It is the largest
                    Service Provider schema version of all of its fields.
                    This is an integer value.

        systemSchemaVersion - This is the container's schema version for the
                    system fields. It is the largest system schema version of
                    all of its fields.
                    This is an integer value.
    '''
    #
    #===================================================================================================================
    # DataContainerDescriptor
    def __init__(
            self,
            containerKey,
            containerId,
            fieldObjList,
            baseContainerKey,
            baseContainerId,
            createdSchemaVersion,
            deletedSchemaVersion,
            systemSchemaVersion,
            servProvSchemaVersion=1,
            docDescription=None,
            docIsInternal=False,
            docUsage='',
            metaDataList=None):
        global mdcDebug
        global THE_MDC_DESCRIPTOR_INDEX_LIST
        #
        # Find the containerId in the list
        self.containerKey = int(containerKey)
        self.containerId = str(containerId)
        self.docDescription = docDescription
        self.docIsInternal = docIsInternal
        self.docUsage = docUsage
        self.metaDataList = metaDataList
        self.fieldObjList = fieldObjList
        # Now create fieldNameList
        self.fieldNameList = []
        for fieldObj in fieldObjList:
            fieldId = str(fieldObj.name)
            self.fieldNameList.append(fieldId)
        #
        self.baseContainerKey = baseContainerKey
        self.baseContainerId = baseContainerId
        self.createdSchemaVersion = createdSchemaVersion
        self.deletedSchemaVersion = deletedSchemaVersion
        self.systemSchemaVersion = systemSchemaVersion
        self.servProvSchemaVersion = servProvSchemaVersion
        #
        self.descIndex = THE_MDC_DESCRIPTOR_INDEX_LIST.getDescriptorIndex(
            systemSchemaVersion, servProvSchemaVersion, addIfNotFound=True)
        # Create the descObjList
        self.descObjList = [self]
        descObj = self
        if (mdcDebug):
            printDebugMsg('containerId=' + str(containerId))
            printDebugMsg('systemSchemaVersion=' + str(systemSchemaVersion) +
                ', servProvSchemaVersion=' + str(servProvSchemaVersion))
        while (True):
            baseContainerId = descObj.baseContainerId
            if (mdcDebug):
                printDebugMsg('baseContainerId=' + str(baseContainerId))
            if (baseContainerId == ''):
                break
            # We have a base container. Add it to the descObjList
            baseDescObj = self.descIndex.get(baseContainerId)
            self.descObjList.append(baseDescObj)
            # Check if we need to update the schema versions
            if (baseDescObj.systemSchemaVersion > self.systemSchemaVersion):
                self.systemSchemaVersion = baseDescObj.systemSchemaVersion
            if (baseDescObj.servProvSchemaVersion > self.servProvSchemaVersion):
                self.servProvSchemaVersion = baseDescObj.servProvSchemaVersion
            # Now check this DataContainerDescriptor
            descObj = baseDescObj
    #
    #===================================================================================================================
    # DataContainerDescriptor
    def __str__(self):
        return self.printStr('')
    #
    #===================================================================================================================
    # DataContainerDescriptor
    def create(self):
        ''' This function creates and returns a new empty DataContainer.

        returns   - a new DataContainer instance with no fields present.
        '''
        mdc = DataContainer(self)
        return mdc
    #
    #===================================================================================================================
    # DataContainerDescriptor
    def get(self, containerId):
        ''' This function returns the DataContainerDescriptor for
            the passed DataContainer id (name).

        The parameters are:

        containerId - this is the name of the DataContainer that is
                    being requested. This value should be a string.

        returns   - the DataContainerDescriptor for the passed
                    containerId. If not found, None will be returned.
        '''
        mdcDesc = self.descIndex.get(str(containerId))
        return mdcDesc
    #
    #===================================================================================================================
    # DataContainerDescriptor
    def getFieldKey(self, fieldName):
        ''' This function returns a FieldKey that can be used to access the
            named field in a container created using this object.

        The parameters are:

        fieldName - this is the name of the field that is being requested.
                    This value should be a string.

        returns   - the FieldKey for this field if found. If not found, an
                    NameError exception will be raised.
        '''
        global configFileName
        # TODO: There is no checking to make sure this fieldKey
        # is correct for this DataContainer
        #
        fieldLevelNameList = fieldName.split('.')
        # Get the number of levels in this name (zero-relative)
        maxLevels = len(fieldLevelNameList) - 1
        descObjList = self.descObjList
        level = -1
        descKeyList = []
        fieldIdxList = []
        fieldIdx = 0
        # Go though each level one at a time and find both the
        # descriptor index and field index.
        while (True):
            level += 1
            fieldLevelName = fieldLevelNameList[level]
            # Now check each descriptor's fields for a match
            found = False
            for descObj in descObjList:
                if (descObj.fieldNameList.count(fieldLevelName) != 1):
                    continue
                # Here we found the field!
                fieldIdx = descObj.fieldNameList.index(fieldLevelName)
                # Add it to the temp lists
                descKeyList.append(descObj.containerKey)
                fieldIdxList.append(fieldIdx)
                #
                # Have we processed all levels of this fieldKey?
                if (level == maxLevels):
                    newFldKey = FieldKey(descKeyList, fieldIdxList)
                    return newFldKey
                # We have a multi-level fieldKey. This current field
                # must be a STRUCT.
                fieldObj = descObj.fieldObjList[fieldIdx]
                if (fieldObj.dataType != DATA_TYPE_STRUCT):
                    raise NameError('getFieldKey error: field name (' + str(fieldName) + ') is incorrect. The ' + \
                        'zero-relative level (' + str(level) + ') should point to a STRUCT ' + \
                        'but its type is (' + str(fieldObj.dataType) + ':' + fieldObj.getDataTypeStr() + '). ' + \
                        'Config file: ' + configFileName)
                #
                # We need to get the descriptor for this struct.
                # If it is unknown, then we can't continue.
                if (fieldObj.structId == ''):
                    raise NameError('getFieldKey error: field name (' + str(fieldName) + ') is incorrect. The ' + \
                        'zero-relative level (' + str(level) + ') should point to a known ' + \
                        'STRUCT but it has an unknown structId. ' + \
                        'Config file: ' + configFileName)
                newDescObj = self.descIndex.get(fieldObj.structId)
                descObjList = newDescObj.descObjList
                # Now look for the next fieldKey level
                found = True
                break
            if (not found):
                # NOT FOUND
                #for descObj in descObjList:
                #    descObj.printIt()
                raise NameError('getFieldKey error: field name (' + str(fieldName) + ') was not found. The ' + \
                    'current zero-relative level is (' + str(level) + \
                    ') for descriptor (' + self.containerId + '). Check to make sure you are using the correct ' + \
                    'mtx_config.xml file. Config file: ' + configFileName + \
                    '. Current directory=' + os.path.abspath(os.getcwd()))
    #
    #===================================================================================================================
    # DataContainerDescriptor
    def getFieldObjectUsingKey(self, fieldKey):
        ''' This function returns the specified field's DataContainerField object.

        The parameters are:

        fieldKey -  this is the FieldKey instance that identifies the field
                    that is being requested.

        returns   - the DataContainerField object of the field specified by the
                    passed fieldKey.
                    If not found, None will be returned.
        '''
        global configFileName
        # TODO: There is no checking to make sure this fieldKey
        # is correct for this DataContainer
        #
        # Get the number of levels (zero-relative)
        maxLevels = fieldKey.levelCount - 1
        descObjList = self.descObjList
        level = -1
        fieldIdx = 0
        # Go though each level one at a time and find both the
        # descriptor index and field index.
        while (True):
            level += 1
            containerKey = fieldKey.descKeyList[level]
            fieldIdx = fieldKey.fieldIdxList[level]
            # Now check each descriptor's fields for a match
            found = False
            for descObj in descObjList:
                if (descObj.containerKey != containerKey):
                    continue
                # Get the field
                fieldObj = descObj.fieldObjList[fieldIdx]
                #
                # Have we processed all levels of this fieldKey?
                if (level >= maxLevels):
                    # Yes, then return the fieldObj.
                    return fieldObj
                #
                # Here we have a multi-level fieldKey.
                # If the fieldValue is None, then we can't go on. Just return None.
                if (fieldObj is None):
                    # NOT FOUND
                    return None
                # This fieldObj must be a STRUCT.
                if (fieldObj.dataType != DATA_TYPE_STRUCT):
                    raise NameError('getFieldObjectUsingKey error: the fieldKey (' + fieldKey.printStr() + \
                        ') is incorrect. The zero-relative level (' + str(level) + \
                        ') of the fieldKey (which is descriptor key=' + str(containerKey) + \
                        ' and field index=' + str(fieldIdx) + \
                        ') should point to a STRUCT but its type is (' + str(fieldObj.dataType) + \
                        ':' + fieldObj.getDataTypeStr() + '). Config file: ' + configFileName)
                #
                # We need to get the descriptor for this struct.
                # If it is unknown, then we can't continue.
                if (fieldObj.structId == ''):
                    raise NameError('getFieldObjectUsingKey error: the fieldKey (' + fieldKey.printStr() + \
                        ') is incorrect. The zero-relative level (' + str(level) + \
                        ') of the fieldKey (which is descriptor key=' + str(containerKey) + \
                        ' and field index=' + str(fieldIdx) + \
                        ') should point to a known STRUCT but it has an unknown structId. ' + \
                        'Config file: ' + configFileName)
                newDescObj = self.descIndex.get(fieldObj.structId)
                descObjList = newDescObj.descObjList
                # Now look for the next fieldKey level
                found = True
                break
            if (not found):
                # NOT FOUND
                #for descObj in descObjList:
                #    descObj.printIt()
                raise NameError('getFieldObjectUsingKey error: fieldKey (' + fieldKey.printStr() + \
                    ') was not found. The current zero-relative level is (' + str(level) + \
                    ') of the fieldKey (which is descriptor key ' + str(containerKey) + \
                    ' and field index ' + str(fieldIdx) + \
                    '). Check to make sure you are using the correct ' +\
                    'mtx_config.xml file. Config file: ' + configFileName)
    #
    #===================================================================================================================
    # DataContainerDescriptor
    def isDescendantOf(self, containerKey):
        '''Return true if this descriptor is a descendant of the specified
           container key
        '''
        if containerKey == self.containerKey:
            return True
        # Check base containers
        if self.baseContainerKey != 0:
            baseDescObj = self.descIndex.getByKey(self.baseContainerKey)
            return baseDescObj.isDescendantOf(containerKey)
        return False
    #
    #===================================================================================================================
    # DataContainerDescriptor
    def printIt(self, indentStr=''):
        ''' This function will print the object's member variables.

        The parameters are:

        indentStr - this contains a string that is printed before the object's
                    member variables are printed.
        '''
        print(self.printStr(indentStr))
        return
    #
    #===================================================================================================================
    # DataContainerDescriptor
    def printStr(self, indentStr='', indentFirstLine=True):
        ''' This function will return a string containing the object's member
            variables in human-readable form.

        The parameters are:

        indentStr - this contains a string that is added to the string before
                    the object's member variables are added.

        indentFirstLine - this indicates if the first line should be indented or not.

        returns   - a string containing the object's member
                    variables in human-readable form.
        '''
        # NOTE: We don't print the documentation fields: docDescription, docIsInternal,
        #       docUsage, metaDataList. They shouldn't be needed for normal use.
        retStr = ''
        if (indentFirstLine):
            retStr += indentStr
        retStr += 'DataContainerDescriptor: containerKey=' + \
            str(self.containerKey) + \
            ', containerId=' + str(self.containerId) + \
            ', baseContainerKey=' + str(self.baseContainerKey) + \
            ', baseContainerId=' + str(self.baseContainerId) + '\n'
        retStr += indentStr + \
            '  createdSchemaVersion=' + str(self.createdSchemaVersion) + \
            ', deletedSchemaVersion=' + str(self.deletedSchemaVersion) + \
            ', systemSchemaVersion=' + str(self.systemSchemaVersion) + \
            ', servProvSchemaVersion=' + str(self.servProvSchemaVersion) + '\n'
        retStr += indentStr + '  fieldObjList:\n'
        for fieldObj in self.fieldObjList:
            retStr += fieldObj.printStr(indentStr + '    ') + '\n'
        return retStr
    #
    #===================================================================================================================
#
#=======================================================================================================================
#
class DataContainer(object):
    ''' This class contains all of the information about a DataContainer and
        its base DataContainers.

    The data members of this class are:

        descObj -   this is the top-level DataContainerDescriptor object for
                    this object.

        fieldValueArrayArray - this is an array of array of values that make up
                    this object. The first element (index 0) contains the
                    values for the fields in the top-level container. Each
                    subsequent element contains the values for the fields in
                    the base containers if there are any.
    '''
    #
    #===================================================================================================================
    # DataContainer
    def __init__(self, descObj):
        global mdcDebug
        #
        self.descObj = descObj
        # Initialize the fieldValueArrayArray
        self.fieldValueArrayArray = []
        if (descObj is None):
            return
        for tempDescObj in self.descObj.descObjList:
            #if (mdcDebug):
            #    printDebugMsg('processing ' + self.descObj.containerId)
            tempArray = []
            for fieldObj in tempDescObj.fieldObjList:
                if (fieldObj.isPreCreateStruct):
                    # NOTE: this must be a STRUCT
                    if (not fieldObj.isAStruct):
                        raise NameError('pre_create_struct error: field name (' + \
                            str(fieldObj.name) + ') is not a STRUCT. ' + \
                            'Config file: ' + configFileName)
                    # NOTE: this must be a known STRUCT
                    if (fieldObj.structId == ''):
                        raise NameError('pre_create_struct error: field name (' + \
                            str(fieldObj.name) + ') is not a known STRUCT. ' + \
                            'Config file: ' + configFileName)
                    structDescObj = self.descObj.descIndex.get(fieldObj.structId)
                    structMdc = structDescObj.create()
                    tempArray.append(structMdc)
                else:
                    tempArray.append(None)
            # The commented out line also works but pychecker complains about
            # idx being unused and I don't want to turn off localVariablesUsed globally.
            #tempArray = [None for idx in range(len(tempDescObj.fieldObjList))]
            self.fieldValueArrayArray.append(tempArray)
        return
    #
    #===================================================================================================================
    # DataContainer
    def __str__(self):
        return self.printStr('')
    #
    #===================================================================================================================
    # DataContainer
    def appendValue(self, descIdx, fieldObj, value):
        ''' This function appends a value for a list or array field.

        The parameters are:

        descIdx - this is a zero-relative integer that indicates which
                    level of DataContainer the field is in. A value of 0
                    indicates the top-level DataContainer. A value of 1
                    indicates the first base DataContainer, etc.

        fieldObj  - this is the field's DataContainerField.

        value     - this is the value to append to this field. See setValue()
                    for the types allowed for input.
        '''
        # TODO CURRENTLY NOT USED
        if (not fieldObj.isList()):
            raise RuntimeError('appendValue error: you are trying the value ' + str(value) + \
                ' to a field (' + fieldObj.name + ') which is not a list. ' + \
                'Config file: ' + configFileName)
        fieldValueIdx = fieldObj.valueIdx
        fieldValue = self.fieldValueArrayArray[descIdx][fieldValueIdx]
        # DO I NEED THIS ??? value = fieldObj.convertValue(value, self.descObj.descIndex)
        if (fieldValue is None):
            self.fieldValueArrayArray[descIdx][fieldValueIdx] = []
        self.fieldValueArrayArray[descIdx][fieldValueIdx].append(value)
        return
    #
    #===================================================================================================================
    # DataContainer
    def compareExpectedValues(self, expected):
        ''' This function compares the expected values passed in to the
            corresponding field values.

        The parameters are:

        expected -  this is a dictionary of field name to value mappings.
                    Simple values should correspond to the field's type. Structs
                    should be expressed as dictionaries. Lists and arrays should
                    be expressed as lists.

        returns   - True if the expected values match the fields' values.
                    Returns False otherwise.
        '''
        for key, value in list(expected.items()):
            field = self.getUsingName(key)
            if (type(value) == list):
                if (type(field) != list):
                    printErrorMsg('Expecting field ' + key + " to be a list. Found that it's a " + type(field))
                    return False
                if (len(field) != len(value)):
                    printErrorMsg('Expecting field ' + key + ' to be a list with ' + str(len(value)) +
                        ' items. Found ' + str(len(field)) + ' items')
                    return False
                for i in range(0, len(value)):
                    if (type(value[i]) == dict):
                        if (not field[i].compareExpectedValues(value[i])):
                            printErrorMsg('List index ' + str(i) + ' has mismatch.')
                            return False
                    else:
                        if (field[i] != value[i]):
                            printErrorMsg('Expecting field ' + key + ' [' + str(i) +
                                '] to have type ' + str(type(value[i])) +
                                ' and value ' + str(value[i]) +
                                '. Found type ' + str(type(field[i])) +
                                ' and value ' + str(field[i]))
                            return False
            elif (type(value) == dict):
                # pylint: disable=E1103
                if (not field.compareExpectedValues(value)):
                    return False
            else:
                if (field != value):
                    printErrorMsg('Expecting field ' + key + ' to have type ' + str(type(value)) +
                        ' and value ' + str(value) + ' Found type ' + str(type(field)) + ' and value ' + str(field))
                    return False
        return True
    #
    #===================================================================================================================
    # DataContainer
    def getBaseContainerKey(self):
        ''' This function returns the base container's key of this container if
        it has one. If it doesn't, then 0 is returned.

        returns   - this container's base container's key if it has one. If it
                    doesn't, then 0 is returned.
        '''
        if (len(self.descObj.descObjList) > 1):
            return self.descObj.descObjList[1].containerKey
        return 0
    #
    #===================================================================================================================
    # DataContainer
    def getDescriptorKey(self):
        ''' This function returns this container's key.

        returns   - this container's key.
        '''
        return self.descObj.containerKey
    #
    #===================================================================================================================
    # DataContainer
    def getDescriptorName(self):
        ''' This function returns this container's name.

        returns   - this container's name.
        '''
        return self.descObj.containerId
    #
    #===================================================================================================================
    # DataContainer
    def getFieldKey(self, fieldName):
        ''' This function returns a FieldKey for the specified field name.

        This is basically the same as the DataContainerDescriptor::getFieldKey()
        method. The only difference is that this one is able to handle
        getting a FieldKey on an "unknown" struct that is present.

        The parameters are:

        fieldName - this is the name of the field that is being requested.
                    This value is a string.

        returns   - a FieldKey instance for the field.
                    If not found, an NameError exception will be raised.
        '''
        global configFileName
        #
        # TODO: There is no checking to make sure this fieldKey
        # is correct for this DataContainer
        #
        fieldLevelNameList = fieldName.split('.')
        # Get the number of levels in this name (zero-relative)
        maxLevels = len(fieldLevelNameList) - 1
        descObjList = self.descObj.descObjList
        level = -1
        descKeyList = []
        fieldIdxList = []
        fieldIdx = 0
        # Go though each level one at a time and find the both the
        # descriptor index and field index.
        while (True):
            level += 1
            fieldLevelName = fieldLevelNameList[level]
            # Now check each descriptor's fields for a match
            found = False
            for descObj in descObjList:
                if (descObj.fieldNameList.count(fieldLevelName) != 1):
                    continue
                # Here we found the field!
                fieldIdx = descObj.fieldNameList.index(fieldLevelName)
                # Add it to the temp lists
                descKeyList.append(descObj.containerKey)
                fieldIdxList.append(fieldIdx)
                #
                # Have we processed all levels of this fieldKey?
                if (level == maxLevels):
                    return FieldKey(descKeyList, fieldIdxList)
                # We have a multi-level fieldKey. This current field
                # must be a STRUCT.
                fieldObj = descObj.fieldObjList[fieldIdx]
                if (fieldObj.dataType != DATA_TYPE_STRUCT):
                    raise NameError('getFieldKey error: the field name (' + str(fieldName) + \
                        ') is incorrect. The zero-relative level (' + str(level) + \
                        ') should point to a STRUCT but its type is (' + str(fieldObj.dataType) + \
                        ':' + fieldObj.getDataTypeStr() + '). ' + \
                        'Config file: ' + configFileName)
                #
                # We need to get the descriptor for this struct.
                # If it is unknown, then we can't continue.
                if (fieldObj.structId == ''):
                    raise NameError('getFieldKey error: the field name (' + str(fieldName) + \
                        ') is incorrect. The zero-relative level (' + str(level) + \
                        ') should point to a known STRUCT but it has an unknown structId. ' + \
                         'Config file: ' + configFileName)
                newDescObj = self.descObj.descIndex.get(fieldObj.structId)
                descObjList = newDescObj.descObjList
                # Now look for the next fieldKey level
                found = True
                break
            if (not found):
                # NOT FOUND
                raise NameError('getFieldKey error: the field name (' + str(fieldName) + \
                    ') was not found. The current zero-relative level is (' + str(level) + \
                    '). Config file: ' + configFileName)
    #
    #===================================================================================================================
    # DataContainer
    def getUsingKey(self, fieldKey):
        ''' This function returns the specified field's value.

        The parameters are:

        fieldKey -  this is the FieldKey instance that identifies the field
                    that is being requested.

        returns   - the value of the field specified by the passed fieldKey.
                    If not found, None will be returned.
        '''
        global configFileName
        # TODO: There is no checking to make sure this fieldKey
        # is correct for this DataContainer
        #
        # Get the number of levels (zero-relative)
        maxLevels = fieldKey.levelCount - 1
        level = 0
        mdc = self
        while (True):
            descObjList = mdc.descObj.descObjList
            containerKey = fieldKey.descKeyList[level]
            fieldIdx = fieldKey.fieldIdxList[level]
            # Find the descriptor that has the containerKey that we are
            # looking for
            descObj = None
            descIdx = -1
            for descObj in descObjList:
                descIdx += 1
                if (descObj.containerKey == containerKey):
                    break
            # Did we find it?
            if (descObj.containerKey != containerKey):
                # No
                raise NameError('getUsingKey error: the fieldKey (' + fieldKey.printStr() + \
                    ') is incorrect. The zero-relative level (' + str(level) + \
                    ') of the fieldKey (which is descriptor key=' + str(fieldKey.descKeyList[level]) + \
                    ' and field index=' + str(fieldKey.fieldIdxList[level]) + \
                    ') was not found. Config file: ' + configFileName + \
                    ', Container=' + self.printStr())
            # Get the field
            fieldObj = descObj.fieldObjList[fieldIdx]
            fieldValue = mdc.fieldValueArrayArray[descIdx][fieldObj.valueIdx]
            #
            # Have we processed all levels of this fieldKey?
            if (level >= maxLevels):
                # Yes, then return the fieldValue.
                if (fieldObj.dataType == DATA_TYPE_DECIMAL):
                    # NOTE: str(decimal.Decimal('INFINITY')) results in 'Infinity'
                    # and str(decimal.Decimal('-INFINITY')) results in '-Infinity'.
                    # We store 'Infinity' or -Infinity' in the fieldValue.
                    # But we want 'INFINITY' or '-INFINITY' so that the C++ code
                    # can read this.
                    if (str(fieldValue) == 'Infinity'):
                        return 'INFINITY'
                    if (str(fieldValue) == '-Infinity'):
                        return '-INFINITY'
                return fieldValue
            #
            # Here we have a multi-level fieldKey.
            # If the fieldValue is None, then we can't go on. Just return None.
            if (fieldValue is None):
                # NOT FOUND
                return None
            # This fieldValue must be a STRUCT.
            if (fieldObj.dataType != DATA_TYPE_STRUCT):
                raise NameError('getUsingKey error: the fieldKey (' + fieldKey.printStr() + \
                    ') is incorrect. The zero-relative level (' + str(level) + \
                    ') of the fieldKey (which is descriptor key=' + str(fieldKey.descKeyList[level]) + \
                    ' and field index=' + str(fieldKey.fieldIdxList[level]) + \
                    ') should point to a STRUCT but its type is (' + str(fieldObj.dataType) + \
                    ':' + fieldObj.getDataTypeStr() + '). Config file: ' + configFileName)
            level += 1
            # Value is a DataContainer. Get the next level's descObjList
            mdc = fieldValue
    #
    #===================================================================================================================
    # DataContainer
    def getUsingName(self, fieldName):
        ''' This function returns the specified field's value.

        The parameters are:

        fieldName - this is the name of the field that is being requested.
                    This value is a string.

        returns   - the value of the field specified by the passed fieldKey.
                    If not found, None will be returned.
        '''
        fieldKey = self.getFieldKey(fieldName)
        if (fieldKey is None):
            # NOT FOUND
            return None
        return self.getUsingKey(fieldKey)
    #
    #===================================================================================================================
    #
    # getValue - internal function.
    #
    #===================================================================================================================
    # DataContainer
    def getValue(self,
            descIdx,
            fieldObj,
            printFormat,
            indentStr='',
            onlyPresentFields=False):
        ''' This function gets the value for this field and returns it
        formatted based upon the parameters.

        The parameters are:

        descIdx - this is a zero-relative integer that indicates which
                    level of DataContainer the field is in. A value of 0
                    indicates the top-level DataContainer. A value of 1
                    indicates the first base DataContainer, etc.

        fieldObj  - this is the field's DataContainerField.

        printFormat - this is used to identify the formating to do on the field.
                    It can be PRINT_FORMAT_VERBOSE, PRINT_FORMAT_COMPACT,
                    or PRINT_FORMAT_XML.

        indentStr  - this indicated the amount of indenting that should be
                    added to the returned value.

        onlyPresentFields - This indicates that only the fields and elements
                    that are present should be printed. If this is False, then
                    all fields are printed.

        returns   - the formatted field value.
        '''
        fieldValueIdx = fieldObj.valueIdx
        fieldValue = self.fieldValueArrayArray[descIdx][fieldValueIdx]
        if (fieldValue is None):
            return None
        # We don't call isSimple() here because it is slower than
        # doing it this way.
        if (fieldObj.sequenceType != FIELD_IS_SIMPLE):
            if (fieldValue == []):
                return '{}'
            valStr = ''
            if (printFormat == PRINT_FORMAT_COMPACT):
                valStr = '{'
            elif (printFormat == PRINT_FORMAT_VERBOSE):
                valStr = '{'
            firstValueFlag = True
            if (type(fieldValue) != list):
                # We can't return this value since it should be a list.
                # We will display an error but also correct it so that
                # this problem can be fixed.
                printErrorMsg('The field (' + fieldObj.name +
                    ') has a non-list value. It has a type of (' + str(type(fieldValue)) +
                    ') and a value of (' + str(fieldValue) +
                    '). Changing this to be a list. Please correct the problem.')
                self.fieldValueArrayArray[descIdx][fieldValueIdx] = [fieldValue]
            for val in fieldValue:
                if (not firstValueFlag):
                    valStr += ','
                if (val is not None):
                    valStr += fieldObj.formatValue(val, printFormat, indentStr, onlyPresentFields)
                firstValueFlag = False
            if (printFormat in [PRINT_FORMAT_VERBOSE, PRINT_FORMAT_COMPACT]):
                valStr += '}'
            return valStr
        return fieldObj.formatValue(fieldValue, printFormat, indentStr, onlyPresentFields)
    #
    #===================================================================================================================
    # DataContainer
    def isDescendantOf(self, key):
        ''' This function returns True if this container is a descendant of
            the passed container key.

        returns   - this function returns True if this container is a descendant
                    of the passed container key.
        '''
        descObjList = self.descObj.descObjList
        for descObj in descObjList:
            if (descObj.containerKey == key):
                return True
        return False
    #
    #===================================================================================================================
    # DataContainer
    def isEmpty(self):
        descIdx = -1
        for _ in self.descObj.descObjList:
            descIdx += 1
            tempFieldValueArray = self.fieldValueArrayArray[descIdx]
            for value in tempFieldValueArray:
                if (value is None):
                    continue
                return False
        return True

    #
    #===================================================================================================================
    # DataContainer
    def isPresent(self, fieldId):
        ''' This function indicates if the specified field's value is present.

        The parameters are:

        fieldId -   this is used to identify the field. If this is a string,
                    then it is treated as a "field name". Otherwise, it is
                    treated as a FieldKey.

        returns   - True if the specified field is present. Else it returns
                    False.
        '''
        if isinstance(fieldId, (bytes, str)):
            # Type of string
            val = self.getUsingName(fieldId)
        else:
            val = self.getUsingKey(fieldId)
        # NOTE: If the field's value is None, this is the same as "not present"
        if (val is None):
            return False
        return True
    #
    #===================================================================================================================
    # DataContainer
    def printCompact(self, printHeader=True):
        ''' This function returns a string containing the compact format of
            this object.

        The parameters are:

        printHeader - if this is True, then the <n,n,..> header is added to
                    the string before this object is added to the string.

        returns   - a string containing the compact format of this object.
        '''
        global configFileName
        global DECIMAL_INFINITY
        global DECIMAL_NEGATIVE_INFINITY
        global kMaxStringBlobSizeInBytes
        #
        retStr = ''
        sizeInBytes = 0
        descIdx = -1
        for descObj in self.descObj.descObjList:
            descIdx += 1
            # print header
            if (printHeader):
                containerKeyStr = str(descObj.containerKey)
                systemSchemaVersion = descObj.systemSchemaVersion
                servProvSchemaVersion = descObj.servProvSchemaVersion
                retStr += '<1,0,0,' + str(containerKeyStr) + ',' + str(systemSchemaVersion) + ','
                if (servProvSchemaVersion):
                    retStr += str(servProvSchemaVersion) + '>['
                else:
                    retStr += '1>['
            else:
                retStr += '['
            # print fields
            # We want to reduce the display of commas when a struct
            # of a container ends with empty fields. So we use
            # "commaCount" to count the number of commas and only
            # add the commas to "retStr" if we have a field to print.
            commaCount = 0
            #
            fieldObjList = descObj.fieldObjList
            tempFieldValueArray = self.fieldValueArrayArray[descIdx]
            valueIdx = -1
            for value in tempFieldValueArray:
                valueIdx += 1
                if (value is None):
                    commaCount += 1
                    continue
                fieldObj = fieldObjList[valueIdx]
                dataType = fieldObj.dataType
                # We don't call isSimple() here because it is slower than
                # doing it this way.
                if (fieldObj.sequenceType == FIELD_IS_SIMPLE):
                    # We want to avoid calls to getValue() or formatValue()
                    # because we know this is a Simple field and it is faster
                    # to just do the formatting here.
                    if (commaCount):
                        retStr += commaCount * ','
                        commaCount = 0
                    # If it is a STRING or BLOB, then we use a special syntax.
                    if ((dataType == DATA_TYPE_STRING) or (dataType == DATA_TYPE_BLOB)):
                        # Figure out the size of the data minus all of the
                        # escaped chars.
                        # For performance reasons, only call if needed.
                        try:
                            if (value.find('\\') == -1):
                                sizeInBytes = len(value)
                            else:
                                sizeInBytes = getUnescapedStrSize(value)
                            # Fall through
                        except:
                            raise TypeError('printCompact error: you are trying to print a String/Blob field (' + \
                                fieldObj.name  + ') that has a value that has the wrong type (' + \
                                str(type(value)) + '). This must be done using a string type. ' + \
                                'Config file: ' + configFileName)
                        if (sizeInBytes > kMaxStringBlobSizeInBytes):
                            raise ValueError('printCompact error: you are trying to print a String/Blob field (' + \
                                fieldObj.name  + ') that has a value with the size of (' + str(sizeInBytes) + \
                                ') and that exceeds the maximum size (' + str(kMaxStringBlobSizeInBytes) + '. ' + \
                                'Config file: ' + configFileName)
                        retStr += '(' + str(sizeInBytes) + \
                            ':' + value + ')'
                        commaCount = 1
                        continue
                    if (dataType == DATA_TYPE_DECIMAL):
                        # Handle the special cases of INFINITY and -INFINITY.
                        # This will be stored in 'value' as a
                        # decimal.Decimal(Infinity).
                        # We want to return INFINITY or -INFINITY so that it
                        # matches the C++ code.
                        # NOTE: For performance reasons, we try to avoid the
                        # calls to decimal __eql__.
                        decimalStr = str(value)
                        if (decimalStr[-1] == 'y'):
                            if (value == DECIMAL_INFINITY):
                                retStr += 'INFINITY'
                                commaCount = 1
                                continue
                            if (value == DECIMAL_NEGATIVE_INFINITY):
                                retStr += '-INFINITY'
                                commaCount = 1
                                continue
                        retStr += decimalStr
                        commaCount = 1
                        continue
                    if ((dataType == DATA_TYPE_INT128) or (dataType == DATA_TYPE_UINT128)):
                        hexValueStr = ''
                        try:
                            hexValueStr = '0x%x' % value
                            # Fall through
                        except:
                            raise TypeError('printCompact error: you are trying to print a 128-bit field (' + \
                                fieldObj.name  + ') that has a value that has the wrong type (' + \
                                str(type(value)) + \
                                "). This must be done using a type that can be converted to an 'hex' type. " + \
                                'Config file: ' + configFileName)
                        retStr += hexValueStr
                        commaCount = 1
                        continue
                    if (dataType != DATA_TYPE_STRUCT):
                        # We don't call getValue() or formatValue()
                        # because we know this is a Simple field and it is
                        # faster to just do the formatting here.
                        retStr += str(value)
                        commaCount = 1
                        continue
                    # DATA_TYPE_STRUCT
                    # Always print the header to make it easier to visually
                    # find structs.
                    retStr += value.printCompact(True)
                    commaCount = 1
                    continue
                #
                # Array or list
                #
                # We have a real value here
                if (commaCount):
                    retStr += commaCount * ','
                    commaCount = 0
                # NOTE: getValue() handles the sequenceType and structId.
                # DEBUG printDebugMsg('processing field:' + fieldObj.name)
                #retStr += self.getValue(descIdx, fieldObj, PRINT_FORMAT_COMPACT)
                valStr = '{'
                firstValueFlag = True
                if (dataType != DATA_TYPE_STRUCT):
                    if (type(value) != list):
                        # We can't print this container since it has a bad
                        # field. So we will save it so we can display the bad
                        # value. Then we will set this field's value to None so
                        # we can display the container.
                        badValue = value
                        self.setValue(descIdx, fieldObj, None)
                        raise TypeError('printCompact error: the field (' + fieldObj.name + \
                            ') has a non-list value. It has a type of (' + str(type(badValue)) + \
                            ') and a value of (' + str(badValue) + '). ' + \
                            'Config file: ' + configFileName + '. The container with this field removed is: ' + \
                            self.printStr())
                    for val in value:
                        if (val is None):
                            # NOTE: Not-present array elements (sparse arrays) are printed!
                            # NOTE: Not-present list elements are not printed!
                            if (fieldObj.isList()):
                                continue
                        if (not firstValueFlag):
                            valStr += ','
                        else:
                            firstValueFlag = False
                        if (val is None):
                            continue
                        # We want to avoid calls to getValue() or formatValue()
                        # because we know this is a Simple field and it is
                        # faster to just do the formatting here.
                        # If it is a STRING or BLOB, then we use a special syntax.
                        if ((dataType == DATA_TYPE_STRING) or (dataType == DATA_TYPE_BLOB)):
                            # Figure out the size of the data minus all of the escaped chars.
                            # For performance reasons, only call if needed.
                            if (val.find('\\') == -1):
                                sizeInBytes = len(val)
                            else:
                                sizeInBytes = getUnescapedStrSize(val)
                            if (sizeInBytes > kMaxStringBlobSizeInBytes):
                                raise ValueError('printCompact error: ' + \
                                    'you are trying to print a STRING/BLOB list or array field (' + \
                                    fieldObj.name  + ') that has a value with the size of (' + str(sizeInBytes) + \
                                    ') and that exceeds the maximum size (' + str(kMaxStringBlobSizeInBytes) + '. ' + \
                                    'Config file: ' + configFileName)
                            valStr += '(' + str(sizeInBytes) + ':' + val + ')'
                            continue
                        if (dataType == DATA_TYPE_DECIMAL):
                            # Handle the special cases of INFINITY and
                            # -INFINITY.
                            # This will be stored in 'val' as a
                            # decimal.Decimal(Infinity).
                            # We want to return INFINITY or -INFINITY so that it
                            # matches the C++ code.
                            # NOTE: For performance reasons, we try to avoid the
                            # calls to decimal __eql__.
                            decimalStr = str(val)
                            if (decimalStr[-1] == 'y'):
                                if (val == DECIMAL_INFINITY):
                                    valStr += 'INFINITY'
                                    continue
                                if (val == DECIMAL_NEGATIVE_INFINITY):
                                    valStr += '-INFINITY'
                                    continue
                            valStr += str(val)
                            continue
                        if ((dataType == DATA_TYPE_INT128) or (dataType == DATA_TYPE_UINT128)):
                            hexValueStr = ''
                            try:
                                hexValueStr = '0x%x' % val
                                # Fall through
                            except:
                                raise TypeError('printCompact error: ' + \
                                    'you are trying to print a 128-bit list or array field (' + \
                                    fieldObj.name  + ') that has a value that has the wrong type (' + str(type(val)) + \
                                    "). This must be done using a type that can be converted to an 'hex' type. " + \
                                    'Config file: ' + configFileName)
                            valStr += hexValueStr
                            continue
                        valStr += str(val)
                    valStr += '}'
                else:
                    for val in value:
                        if (val is None):
                            # NOTE: Not-present array elements (sparse arrays) are printed!
                            # NOTE: Not-present list elements are not printed!
                            if (fieldObj.isList()):
                                continue
                        if (not firstValueFlag):
                            valStr += ','
                        else:
                            firstValueFlag = False
                        # Always print the header to make it easier to visually
                        # find structs.
                        # NOTE: val can be None when we have a not-present
                        # element in an array of structs (or list of structs).
                        if (val is not None):
                            valStr += val.printCompact(True)
                    valStr += '}'
                commaCount = 1
                retStr += valStr
            retStr += ']'
        return retStr
    #
    #===================================================================================================================
    # DataContainer
    def printElementBasedXml(self, indentStr='', printContainerName=True):
        ''' This function returns a string containing the Elemental XML format
            of this object. Only the fields that are present are printed.

        The parameters are:

        indentStr - this contains a string that is added to each line in the
                    string.

        printContainerName - if this is True, then this name of this object is
                    printed. Else it is not printed. This is needed when
                    printing structs.

        returns   - a string containing the compact format of this object.
        '''
        global kMaxStringBlobSizeInBytes
        #
        retStr = ''
        endBaseContainerStr = ''
        valStr = ''
        descIdx = -1
        containerIndentStr = indentStr
        for descObj in self.descObj.descObjList:
            descIdx += 1
            # print header
            # If this is not the first DescObj, then it is a base container
            # and we do not print this container Id
            if (descIdx == 0):
                # Should we print the container name or has the caller printed
                # the field name?
                if (printContainerName):
                    if self.isEmpty():
                        retStr += containerIndentStr + '<' + descObj.containerId + '/>\n'
                    else:
                        retStr += containerIndentStr + '<' + descObj.containerId + '>\n'
                        endBaseContainerStr = containerIndentStr + '</' + descObj.containerId + '>\n' + \
                        endBaseContainerStr
            # print fields
            # increase the indent for the fields
            fieldIndentStr = containerIndentStr + '    '
            #
            fieldObjList = descObj.fieldObjList
            tempFieldValueArray = self.fieldValueArrayArray[descIdx]
            valueIdx = -1
            for value in tempFieldValueArray:
                valueIdx += 1
                # Skip this if the field is not present
                if (value is None):
                    continue
                fieldObj = fieldObjList[valueIdx]
                # name
                fieldName = str(fieldObj.name)
                # Is this a list or an array?
                if (fieldObj.sequenceType != FIELD_IS_SIMPLE):  # a list or an array
                    valList = value
                    # Handle special case
                    if (valList == [None]):
                        valList = []
                    retStr += fieldIndentStr + '<' + fieldName + '>\n'
                    valueIndentStr = fieldIndentStr + '    '
                    for val in valList:
                        valStr = ''
                        if (val is None):
                            # NOTE: Not-present array elements (sparse arrays) are printed!
                            # NOTE: Not-present list elements are not printed!
                            if (fieldObj.isArray()):
                                if (fieldObj.isAStruct()):
                                    valStr += valueIndentStr +  '<null></null>\n'
                                else:
                                    valStr += valueIndentStr +  '<value></value>\n'
                        elif (fieldObj.isAStruct()):
                            valStr += val.printElementBasedXml(valueIndentStr, True)
                        else:
                            valStr += valueIndentStr + '<value>'
                            # Don't call getValue(PRINT_FORMAT_XML)
                            # because it will return the entire list as a string
                            if ((fieldObj.dataType == DATA_TYPE_INT128) or (fieldObj.dataType == DATA_TYPE_UINT128)):
                                hexValueStr = None
                                if isinstance(val, (bytes, str)):
                                    # If the val is a string, convert it
                                    hexValueStr = '0x%x' % int(val, 16)
                                else:
                                    hexValueStr = '0x%x' % val
                                valStr += hexValueStr
                            elif ((fieldObj.dataType == DATA_TYPE_BLOB) or (fieldObj.dataType == DATA_TYPE_STRING)):
                                # Figure out the size of the data minus all of the escaped chars.
                                # For performance reasons, only call if needed.
                                sizeInBytes = 0
                                if (val.find('\\') == -1):
                                    sizeInBytes = len(val)
                                else:
                                    sizeInBytes = getUnescapedStrSize(val)
                                if (sizeInBytes > kMaxStringBlobSizeInBytes):
                                    raise ValueError('printElementBasedXml error: ' + \
                                        'you are trying to print a String/Blob list or array field (' + \
                                        fieldObj.name  + ') that has a value with the size of (' + str(sizeInBytes) + \
                                        ') and that exceeds the maximum size (' + str(kMaxStringBlobSizeInBytes) + \
                                        '. Config file: ' + configFileName)
                                valStr += convertEscapedStrToEscapedXmlStr(str(val))
                            else:
                                valStr += str(val)
                            valStr += '</value>\n'
                        retStr += valStr
                    retStr += fieldIndentStr + '</' + fieldName + '>\n'
                    continue
                # Not an array or a list
                if (fieldObj.isAStruct()):
                    retStr += fieldIndentStr + '<' + fieldName + '>\n'
                    structObj = value
                    retStr += structObj.printElementBasedXml(fieldIndentStr + '    ', True)
                    retStr += fieldIndentStr + '</' + fieldName + '>\n'
                else:
                    #
                    # check data type
                    # NOTE: getValue() handles the sequenceType
                    # and structId.
                    retStr += fieldIndentStr + '<' + fieldName + '>' + \
                        self.getValue(descIdx, fieldObj, PRINT_FORMAT_XML) + \
                        '</' + fieldName + '>\n'
            #
        # NOTE: We don't put the end container on until after all
        # base containers have been processed.
        if (endBaseContainerStr):
            retStr += endBaseContainerStr
        return retStr
    #
    #===================================================================================================================
    # DataContainer
    def printIt(self, indentStr=''):
        ''' This function will print the object's member variables.

        The parameters are:

        indentStr - this contains a string that is printed before the object's
                    member variables are printed.
        '''
        print(self.printStr(indentStr))
    #
    #===================================================================================================================
    # DataContainer
    def printPythonCmdsStr(self, indentStr=''):
        ''' This function returns a string containing the Python commands that
            can be used to create this object.

        The parameters are:

        indentStr - this contains a string that is added to each line in the
                    string.

        returns   - a string containing the Python commands that can be used
                    to create this object.
        '''
        # Print the python commands to set this MDC
        retStr = ''
        mdcDesc = ''
        mdcVarName = ''
        variablePrefix = ''
        descIdx = -1
        for descObj in self.descObj.descObjList:
            descIdx += 1
            #
            # Check if this is the top level container
            #
            if (descIdx == 0):
                # It is the top level container
                # Lowercase the first character
                mdcVarName = descObj.containerId[0].lower() + descObj.containerId[1:] + 'Mdc'
                variablePrefix = 'k' + descObj.containerId
                mdcDesc = variablePrefix + 'MdcDesc'
                retStr += indentStr + '#\n'
                retStr += indentStr + '# Create a ' + descObj.containerId + ' MDC\n'
                retStr += indentStr + '#\n'
                retStr += indentStr + mdcVarName + ' = MDCDEFS.' + mdcDesc + '.create()\n'
            #
            fieldObjList = descObj.fieldObjList
            tempFieldValueArray = self.fieldValueArrayArray[descIdx]
            valueIdx = -1
            for value in tempFieldValueArray:
                valueIdx += 1
                # Skip this if the field is not present
                if (value is None):
                    continue
                fieldObj = fieldObjList[valueIdx]
                dataType = fieldObj.dataType
                # name
                fieldName = variablePrefix + str(fieldObj.name) + 'FldKey'
                # We don't call isSimple() here because it is slower than
                # doing it this way.
                if (fieldObj.sequenceType != FIELD_IS_SIMPLE):
                    listName = 'my' + str(fieldObj.name)
                    fieldValues = value
                    if (dataType != DATA_TYPE_STRUCT):
                        valueStr = ''
                        for fieldValue in fieldValues:
                            # Must the value be quoted?
                            if (dataType in QUOTED_DATA_TYPES):
                                fieldValue = "'" + str(fieldValue) + "'"
                            if (valueStr != ''):
                                valueStr += ','
                            valueStr += str(fieldValue)
                        retStr += indentStr + mdcVarName + '.setUsingKey(MDCDEFS.' + fieldName + ', [' + \
                            valueStr + '])\n'
                    else:
                        retStr += indentStr + '#\n'
                        retStr += indentStr + listName + ' = []\n'
                        for fieldValue in fieldValues:
                            structObj = fieldValue
                            structStr = structObj.printPythonCmdsStr(indentStr)
                            retStr += structStr
                            structVarName = structObj.descObj.containerId[0].lower() + \
                                structObj.descObj.containerId[1:] + 'Mdc'
                            retStr += indentStr + listName + '.append(' + structVarName + ')\n'
                        retStr += indentStr + '# Now add the ' + listName + ' to the ' + mdcVarName + '\n'
                        retStr += indentStr + mdcVarName + '.setUsingKey(MDCDEFS.' + fieldName + ', ' + listName + ')\n'
                    continue
                if (dataType != DATA_TYPE_STRUCT):
                    fieldValue = str(value)
                    # Must the value be quoted?
                    if (dataType in QUOTED_DATA_TYPES):
                        fieldValue = "'" + fieldValue + "'"
                    retStr += indentStr + mdcVarName + '.setUsingKey(MDCDEFS.' + fieldName + ', ' + fieldValue + ')\n'
                else:
                    structObj = value
                    structStr = structObj.printPythonCmdsStr(indentStr)
                    retStr += structStr
                    structVarName = structObj.descObj.containerId[0].lower() + structObj.descObj.containerId[1:] + 'Mdc'
                    retStr += indentStr + '# Now add the ' + structVarName + ' to the ' + mdcVarName + '\n'
                    retStr += indentStr + mdcVarName + '.setUsingKey(MDCDEFS.' + fieldName + ', ' + \
                        structVarName + ')\n'
        return retStr
    #
    #===================================================================================================================
    # DataContainer
    def printStr(self, indentStr='', onlyPresentFields=False, indentFirstLine=True):
        ''' This function will return a string containing the object's member
            variables in human-readable form.

        The parameters are:

        indentStr - this contains a string that is added to the string before
                    the object's member variables are added.

        onlyPresentFields - This indicates that only the fields and elements
                    that are present should be printed. If this is False, then
                    all fields are printed.

        indentFirstLine - this indicates if the first line should be indented or not.

        returns   - a string containing the object's member
                    variables in human-readable form.
        '''
        allSpaces = '                                                        '  # End of allSpaces
        retStr = ''
        descIdx = -1
        for descObj in self.descObj.descObjList:
            descIdx += 1
            #
            # Check if this is a base container
            #
            if (descIdx > 0):
                retStr += indentStr + '---BaseDataContainer---'
            valStr = ''
            # print header
            if (retStr == ''):
                # This is the first line.
                if (indentFirstLine):
                    retStr += '\n' + indentStr
                retStr += 'DataContainer:\n'
            else:
                retStr += '\n' + indentStr + 'DataContainer:\n'
            systemSchemaVersion = descObj.systemSchemaVersion
            servProvSchemaVersion = descObj.servProvSchemaVersion
            retStr += indentStr + '  containerId=' + descObj.containerId + '(' + str(descObj.containerKey) + ',' + \
                str(systemSchemaVersion) + ',' + str(servProvSchemaVersion) + ')\n'
            # print fields
            retStr += indentStr + '  idx name                           type      L A M P value\n'
            #                          0 Field1                         UINT32    0 0 0 0     4
            counter = 0
            #
            for fieldObj in descObj.fieldObjList:
                # idx
                valStr = '   '
                if (counter < 10):
                    valStr += ' ' + str(counter)
                else:
                    valStr += str(counter)
                # name
                counter += 1
                fieldName = str(fieldObj.name)
                nameLen = len(fieldName)
                if (nameLen < 31):
                    # Add spaces to fieldName
                    fieldName += allSpaces[0:(31 - nameLen)]
                valStr += ' ' + fieldName
                # type
                dataType = fieldObj.getDataTypeStr()
                nameLen = len(dataType)
                if (nameLen < 10):
                    # Add spaces to dataType
                    dataType += allSpaces[0:(10 - nameLen)]
                valStr += dataType
                # L
                if (fieldObj.isList()):
                    valStr += '1 '
                else:
                    valStr += '0 '
                # A
                if (fieldObj.isArray()):
                    valStr += '1 '
                else:
                    valStr += '0 '
                # We don't handle MaxField type fields.
                # M
                valStr += '0 '
                # P
                # NOTE: getValue() handles the sequenceType
                # and structId.
                value = self.fieldValueArrayArray[descIdx][fieldObj.valueIdx]
                if (value is None):
                    if (onlyPresentFields):
                        continue
                    valStr += '0 '
                else:
                    #
                    # check data type (???)
                    # NOTE: getValue can return None if the field's value is [].
                    fieldValue = self.getValue(descIdx, fieldObj,
                        PRINT_FORMAT_VERBOSE, indentStr, onlyPresentFields)
                    if (fieldValue is None):
                        valStr += '0 '
                    else:
                        valStr += '1 '
                        valStr += fieldValue
                retStr += indentStr + valStr + '\n'
        return retStr
    #
    #===================================================================================================================
    # DataContainer
    def printStrUsingFormat(self,
            formatStr,
            indentStr='',
            onlyPresentFields=False,
            indentFirstLine=True,
            printContainerName=True,
            printHeader=True):
        ''' This function returns a string containing the specified format of
            this object.

        The parameters are:

        formatStr - a string that indicates the format to use when printing
                    this object. The possible values are specified in
                    kMdcOutputFormatStrList.

        indentStr - this contains a string that is added to the string before
                    the object's member variables are added.

        onlyPresentFields - This indicates that only the fields and elements
                    that are present should be printed. If this is False, then
                    all fields are printed.

        indentFirstLine - this indicates if the first line should be indented or not.

        printContainerName - if this is True, then this name of this object is
                    printed. Else it is not printed. This is needed when
                    printing structs.

        printHeader - if this is True, then the header fields are also printed.

        returns   - a string containing the specified format of this object.
        '''
        global kMdcOutputFormatStrList
        #
        if (formatStr not in kMdcOutputFormatStrList):
            raise ValueError('printStrUsingFormat error: the passed formatStr parameter (' + formatStr +
                ') is unknown. Valid values are: ' + str(kMdcOutputFormatStrList) + '. ' +
                'Config file: ' + configFileName)
        if (formatStr == 'compact'):
            return self.printCompact(printHeader=printHeader)
        if (formatStr == 'descriptive'):
            return self.printStr(indentStr=indentStr, onlyPresentFields=onlyPresentFields,
                indentFirstLine=indentFirstLine)
        if (formatStr == 'element_xml'):
            return self.printElementBasedXml(indentStr=indentStr, printContainerName=printContainerName)
        if (formatStr == 'xml'):
            return self.printXml(indentStr=indentStr)
        return 'Unknown format'
    #
    #===================================================================================================================
    # DataContainer
    def printXml(self, indentStr='', isAStruct=False):
        ''' This function returns a string containing the XML format of
            this object. Only the fields that are present are printed.

        The parameters are:

        indentStr - this contains a string that is added to each line in the
                    string.

        isAStruct - if this is True, then this object is treated as a struct.
                    Else it is treated as a container.

        returns   - a string containing the compact format of this object.
        '''
        retStr = ''
        endBaseContainerStr = ''
        valStr = ''
        descIdx = -1
        containerIndentStr = indentStr
        for descObj in self.descObj.descObjList:
            descIdx += 1
            #
            # Check if this is a base container
            #
            if (descIdx > 0):
                # Indent for each base container
                containerIndentStr += '    '
            # print header
            # If this is not the first DescObj, then it is a base container
            # and we always print this as a container and not a struct
            if (descIdx > 0):
                retStr += containerIndentStr + "<container name='" + descObj.containerId +  \
                    "' system_schema='" + str(descObj.systemSchemaVersion) + \
                    "' service_provider_schema='" +  str(descObj.servProvSchemaVersion) + "'>\n"
            else:
                if (isAStruct):
                    retStr += containerIndentStr + "<struct name='" + descObj.containerId + "'>\n"
                else:
                    retStr += containerIndentStr + "<container name='" + descObj.containerId + \
                        "' system_schema='" + str(descObj.systemSchemaVersion) + \
                        "' service_provider_schema='" + str(descObj.servProvSchemaVersion) + "'>\n"
            # print fields
            # increase the indent for the fields
            fieldIndentStr = containerIndentStr + '    '
            #
            fieldObjList = descObj.fieldObjList
            tempFieldValueArray = self.fieldValueArrayArray[descIdx]
            valueIdx = -1
            for value in tempFieldValueArray:
                valueIdx += 1
                # Skip this if the field is not present
                if (value is None):
                    continue
                fieldObj = fieldObjList[valueIdx]
                # name
                fieldName = str(fieldObj.name)
                # type
                dataType = fieldObj.getDataTypeStr()
                # Is this a list?
                if (fieldObj.isList()):
                    valList = value
                    # Handle special case
                    if (valList == [None]):
                        valList = []
                    retStr += fieldIndentStr + "<list name='" + fieldName + "' type='" + dataType + "'>\n"
                    nextIndentStr = fieldIndentStr + '    '
                    for val in valList:
                        if (val is None):
                            # NOTE: Not-present array elements (sparse arrays) are printed!
                            # NOTE: Not-present list elements are not printed!
                            continue
                        valStr = ''
                        if (fieldObj.isAStruct()):
                            retStr += val.printXml(nextIndentStr, True)
                        else:
                            valStr += nextIndentStr + "<value>"
                            # Don't call getValue(PRINT_FORMAT_XML)
                            # because it will return the entire list as a string
                            if ((fieldObj.dataType == DATA_TYPE_INT128) or (fieldObj.dataType == DATA_TYPE_UINT128)):
                                hexValueStr = None
                                if isinstance(val, (bytes, str)):
                                    # If the val is a string, convert it
                                    hexValueStr = '0x%x' % int(val, 16)
                                else:
                                    hexValueStr = '0x%x' % val
                                valStr += hexValueStr
                            elif ((fieldObj.dataType == DATA_TYPE_BLOB) or (fieldObj.dataType == DATA_TYPE_STRING)):
                                # Figure out the size of the data minus all of the
                                # escaped chars.
                                # For performance reasons, only call if needed.
                                sizeInBytes = 0
                                if (val.find('\\') == -1):
                                    sizeInBytes = len(val)
                                else:
                                    sizeInBytes = getUnescapedStrSize(val)
                                if (sizeInBytes > kMaxStringBlobSizeInBytes):
                                    raise ValueError('printXml error: ' + \
                                        'you are trying to print a String/Blob list field (' + fieldObj.name  + \
                                        ') that has a value with the size of (' + str(sizeInBytes) + \
                                        ') and that exceeds the maximum size (' + str(kMaxStringBlobSizeInBytes) + \
                                        '. Config file: ' + configFileName)
                                valStr += convertEscapedStrToEscapedXmlStr(str(val))
                            else:
                                valStr += str(val)
                            valStr += "</value>\n"
                        retStr += valStr
                    retStr += fieldIndentStr + "</list>\n"
                    continue
                # Is this an array?
                if (fieldObj.isArray()):
                    valList = value
                    # Handle special case
                    if (valList == [None]):
                        valList = []
                    retStr += fieldIndentStr + "<array name='" + fieldName + \
                        "' type='" + dataType + "' size='" + str(len(valList)) + "'>\n"
                    nextIndentStr = fieldIndentStr + '    '
                    for val in valList:
                        valStr = ''
                        if (val is None):
                            if (fieldObj.isAStruct()):
                                valStr += nextIndentStr + '<struct></struct>\n'
                            else:
                                valStr += nextIndentStr + '<value></value>\n'
                        elif (fieldObj.isAStruct()):
                            retStr += val.printXml(nextIndentStr, True)
                        else:
                            valStr += nextIndentStr + "<value>"
                            # Don't call getValue(PRINT_FORMAT_XML)
                            # because it will return the entire list as a string
                            if ((fieldObj.dataType == DATA_TYPE_INT128) or (fieldObj.dataType == DATA_TYPE_UINT128)):
                                hexValueStr = None
                                if isinstance(val, (bytes, str)):
                                    # If the val is a string, convert it
                                    hexValueStr = '0x%x' % int(val, 16)
                                else:
                                    hexValueStr = '0x%x' % val
                                valStr += hexValueStr
                            elif ((fieldObj.dataType == DATA_TYPE_BLOB) or (fieldObj.dataType == DATA_TYPE_STRING)):
                                # Figure out the size of the data minus all of the escaped chars.
                                # For performance reasons, only call if needed.
                                sizeInBytes = 0
                                if (val.find('\\') == -1):
                                    sizeInBytes = len(val)
                                else:
                                    sizeInBytes = getUnescapedStrSize(val)
                                if (sizeInBytes > kMaxStringBlobSizeInBytes):
                                    raise ValueError('printXml error: ' + \
                                        'you are trying to print a String/Blob array field (' + fieldObj.name  + \
                                        ') that has a value with the size of (' + str(sizeInBytes) + \
                                        ') and that exceeds the maximum size (' + str(kMaxStringBlobSizeInBytes) + \
                                        '. Config file: ' + configFileName)
                                valStr += convertEscapedStrToEscapedXmlStr(str(val))
                            else:
                                valStr += str(val)
                            valStr += "</value>\n"
                        retStr += valStr
                    retStr += fieldIndentStr + "</array>\n"
                    continue
                # Not an array or a list
                if (fieldObj.isAStruct()):
                    retStr += fieldIndentStr + "<field name='" + fieldName + "' type='STRUCT'>\n"
                    structObj = value
                    retStr += structObj.printXml(fieldIndentStr + '    ', True)
                    retStr += fieldIndentStr + '</field>\n'
                else:
                    #
                    # check data type
                    # TODO ???
                    # NOTE: getValue() handles the sequenceType
                    # and structId.
                    retStr += fieldIndentStr + "<field name='" + fieldName + \
                        "' type='" + dataType + "' value='" + \
                        self.getValue(descIdx, fieldObj, PRINT_FORMAT_XML) + "' />\n"
            #
            # Is this a base container?
            if (descIdx > 0):
                # Yes, a base container. Then we save this line and put it
                # before any previous value.
                endBaseContainerStr = containerIndentStr + "</container>\n" + endBaseContainerStr
        # NOTE: We don't put the end container on until after all
        # base containers have been processed.
        if (endBaseContainerStr):
            retStr += endBaseContainerStr
        if (isAStruct):
            retStr += indentStr + '</struct>\n'
        else:
            retStr += indentStr + '</container>\n'
        return retStr
    #
    #===================================================================================================================
    #
    # readFrom - internal function. External callers should call readFromStr()
    #
    #===================================================================================================================
    # DataContainer
    def readFrom(self, inputStr):
        ''' This internal function does the parsing of each field of the data
            container.

        This is an internal function. External callers should call
        readFromStr().

        The parameters are:

        inputStr -  this is the string to be parsed. It represents the fields
                    in a data container in compact format.

        returns   - a tuple of two. The first field is a success flag
                    (True = success, False = Error). The second field is the
                    remaining string.
        '''
        global mdcDebugParsing
        #
        origInputStr = inputStr
        #
        # This loop handles the main DataContainer and all of its
        # base DataContainers (if any).
        beginArrayFound = False
        beginListFound = False
        nextDescKey = 0
        if (mdcDebugParsing):
            printDebugMsg("called: inputStr='" + inputStr + "'")
        descObj = None
        descIdx = -1
        for descObj in self.descObj.descObjList:
            descIdx += 1
            if (mdcDebugParsing):
                printDebugMsg('procesing: container=' + descObj.containerId)
            if (nextDescKey > 0):
                # See if this matches the key of the descObj
                if (int(nextDescKey) != int(descObj.containerKey)):
                    printErrorMsg('Mismatched base container tag. Found ' + str(nextDescKey) +
                        ', expecting to find ' + str(descObj.containerKey) +
                        '\n    Original data is=' + origInputStr +
                        '\n    Current  data is=' + inputStr)
                    return False, inputStr
            fieldIdx = -1
            #
            if (len(descObj.fieldObjList) == 0):
                # eat up blanks
                inputStr = inputStr.lstrip()
                if (inputStr[0] == LEFT_BRACKET):
                    # Bump up to the next token and eat up blanks
                    inputStr = inputStr[1:].lstrip()
            #
            fieldObj = None
            for fieldObj in descObj.fieldObjList:
                fieldIdx += 1
                # Token path
                # eat up blanks
                inputStr = inputStr.lstrip()
                # Do we have any more tokens?
                if (inputStr == ''):
                    # We should have detected the last RIGHT_BRACKET and then returned.
                    reportBadData(inputStr, descObj, fieldObj, RIGHT_BRACKET + ' :(python code location 8)')
                    return False, inputStr
                # If this token is ']', then we treat this as not having any more tokens.
                if (inputStr[0] == RIGHT_BRACKET):
                    # No, we just return which will leave all of the remaining fields "not present".
                    if (mdcDebugParsing):
                        printDebugMsg("Found an early ']'")
                    # Do NOT bump up to the next token!
                    # Break out of the 'for fieldObj in descObj.fieldObjList' loop.
                    break
                # If this is the first token, then it should be a "[".
                # Check and then get the next token.
                # Except if we are in a list. This could be a list or array of
                # structs, so we don't want to bump past the '[' in this case.
                if (fieldIdx == 0):
                    if (inputStr[0] == LEFT_BRACKET):
                        if ((not beginListFound) and (not beginArrayFound)):
                            if (mdcDebugParsing):
                                printDebugMsg("Found and skipping the '['" + ', Field name=' + fieldObj.name +
                                    ', dataType=' + fieldObj.getDataTypeStr())
                            # Bump up to the next token and eat up blanks
                            inputStr = inputStr[1:].lstrip()
                    else:
                        # No data or bad data
                        reportBadData(inputStr, descObj, fieldObj, LEFT_BRACKET + ' :(python code location 10)')
                        return False, inputStr
                # Now allow another comma to indicate a not-present field.
                # This could also be indicated by the stream EOF flag.
                if (inputStr[0] == COMMA):
                    if (mdcDebugParsing):
                        printDebugMsg("1.Found and skipping the ','" + ', Field name=' + fieldObj.name +
                            ', dataType=' + fieldObj.getDataTypeStr())
                    # Bump up to the next token and eat up blanks
                    inputStr = inputStr[1:].lstrip()
                    continue
                # If this token is ']', then we treat this as not having any more tokens.
                if (inputStr[0] == RIGHT_BRACKET):
                    # No, we just return which will leave all of the remaining fields "not present".
                    if (mdcDebugParsing):
                        printDebugMsg("2: Found an early ']'" + ', Field name=' + fieldObj.name +
                            ', dataType=' + fieldObj.getDataTypeStr())
                    # Do NOT bump up to the next token!
                    # Break out of the for fieldObj in descObj.fieldObjList loop
                    break
                if (mdcDebugParsing):
                    printDebugMsg("Processing token '" + inputStr[0] + "'" + ', Field name=' + fieldObj.name +
                        ', dataType=' + fieldObj.getDataTypeStr())
                #
                # Check if this is an array or a list. If it is then we get rid of the '{'
                #
                # We don't call isSimple() here because it is slower than doing it this way.
                if (fieldObj.sequenceType != FIELD_IS_SIMPLE):
                    # This token must be a '{'. Check and get rid of it.
                    if (inputStr[0] != LEFT_BRACE):
                        reportBadData(inputStr, descObj, fieldObj, LEFT_BRACE + ' :(python code location 12)')
                        return False, inputStr
                # Call readFromField to read the entire field, list or array.
                success, inputStr = self.readFromField(inputStr, descIdx, fieldObj)
                if (mdcDebugParsing):
                    printDebugMsg('After readFromField return, success=' + str(success) +
                        ", inputStr='" + inputStr + "'")
                # Get out if we found an error
                if (not success):
                    return False, inputStr
                # Get rid of the comma separator field if present.
                if (inputStr[0] == COMMA):
                    if (mdcDebugParsing):
                        printDebugMsg("4.Found and skipping the ',', Field name=" + fieldObj.name +
                            ', dataType=' + fieldObj.getDataTypeStr())
                    # Bump up to the next token
                    inputStr = inputStr[1:]
                    continue
            # end of 'for fieldObj in descObj.fieldObjList' loop
            #
            # At the end of this DataContainer or Struct. We are expecting a ']'.
            # Token path
            # eat up blanks
            inputStr = inputStr.lstrip()
            # Do we have any more tokens?
            if (inputStr[0] == ''):
                # No, we should have a ']'. Report an error.
                # No data or bad data
                reportBadData(inputStr, descObj, fieldObj, RIGHT_BRACKET + ' :(python code location 14)')
                return False, inputStr
            # See if the next token is a ']'. If so, then get the next token.
            if (inputStr[0] != RIGHT_BRACKET):
                # No, we should have a ']'. Report an error.
                # No data or bad data
                reportBadData(inputStr, descObj, fieldObj, RIGHT_BRACKET + ' :(python code location 16)')
                return False, inputStr
            if (mdcDebugParsing):
                printDebugMsg("Found and skipping the ']' at the end of the fields for descriptor (" +
                    str(descObj.containerId) + ')')
            # Bump up to the next token!
            if (len(inputStr) < 2):
                inputStr = ''
                return True, inputStr
            inputStr = inputStr[1:].lstrip()
            #
            # Check if this has a base container.
            # See if we have a base container to process
            if (descObj.baseContainerKey == 0):
                if (mdcDebugParsing):
                    printDebugMsg("readFrom:returning:2: inputStr='" + inputStr + "'")
                return True, inputStr
            if (mdcDebugParsing):
                printDebugMsg("Processing BASE CLASS: inputStr='" + inputStr + "'")
            # See if the next token is a '<', indicating a specific type
            # of base container.
            if (inputStr[0] == LESS_THAN):
                tempStr = inputStr   # In case of error
                descKey, systemSchemaVersion, servProvSchemaVersion, inputStr = readDescriptorTag(inputStr)
                if (descKey == 0):
                    printErrorMsg('Line is not valid. readDescriptorTag returned a descriptor key of 0.' +
                        '\n    Original data is=' + origInputStr +
                        '\n    Current  data is=' + inputStr +
                        '\n    Temp     data is=' + tempStr)
                    return False, inputStr
                if (systemSchemaVersion != descObj.systemSchemaVersion):
                    printErrorMsg('Line is not valid. ' +
                        'readDescriptorTag returned a system schema version (' +
                        str(systemSchemaVersion) + ') that is different from the ' +
                        'expected value (' + str(descObj.systemSchemaVersion) + ')' +
                        '\n    Original data is=' + origInputStr +
                        '\n    Current  data is=' + inputStr +
                        '\n    Temp     data is=' + tempStr)
                    return False, inputStr
                if (servProvSchemaVersion != descObj.servProvSchemaVersion):
                    printErrorMsg('Line is not valid. ' +
                        'readDescriptorTag returned a service provider schema version (' +
                        str(servProvSchemaVersion) + ') that is different from the ' +
                        'expected value (' + str(descObj.servProvSchemaVersion) + ')' +
                        '\n    Original data is=' + origInputStr +
                        '\n    Current  data is=' + inputStr +
                        '\n    Temp     data is=' + tempStr)
                    return False, inputStr
                # Get the DataContainerDescriptor
                tempDescObj = self.descObj.descIndex.getByKey(descKey)
                if (tempDescObj is None):
                    printErrorMsg('Line is not valid. readDescriptorTag returned an invalid descKey (' +
                        descKey + ')' +
                        '\n    Original data is=' + origInputStr +
                        '\n    Current  data is=' + inputStr +
                        '\n    Temp     data is=' + tempStr)
                    return False, inputStr
                # Save this so we can see if it matches when we process it.
                nextDescKey = descKey
                continue
            # Needs to be a LEFT_BRACKET
            if (inputStr[0] == LEFT_BRACKET):
                nextDescKey = 0
                continue
            # No, we should have a '['. Report an error.
            # No data or bad data
            reportBadData(inputStr, descObj, fieldObj, LEFT_BRACKET + ' :(python code location 18)')
            return False, inputStr
        # end of 'for descObj in self.descObj.descObjList'
        if (mdcDebugParsing):
            printDebugMsg("returning: inputStr='" + inputStr + "'")
        return True, inputStr
    #
    #===================================================================================================================
    #
    # readFromElementBasedXML - internal function.
    # External callers should call readFromElementBasedXMLStr()
    #
    #===================================================================================================================
    # DataContainer
    def readFromElementBasedXML(self, element):
        ''' This internal function does the XML parsing of each field of the
            data container.

        This is an internal function. External callers should call
        readFromElementBasedXMLStr().
        '''
        if (mdcDebugParsing):
            printDebugMsg("called: element='" + xml.etree.ElementTree.tostring(element) + "'")
        descIdx = -1
        for descObj in self.descObj.descObjList:
            descIdx += 1
            if (mdcDebugParsing):
                printDebugMsg('processing: container=' + descObj.containerId)

            fields = {}
            for child in element:
                if (mdcDebugParsing):
                    printDebugMsg('child.tag=' + str(child.tag))
                    printDebugMsg('child.text=' + str(child.text))
                name = child.tag
                fields[name] = child

            for fieldObj in descObj.fieldObjList:
                if (fieldObj.name not in fields):
                    continue

                child = fields[fieldObj.name]
                if (mdcDebugParsing):
                    printDebugMsg('processing ' + str(child.tag))
                    printDebugMsg('type(child)=' + str(type(child)))
                if (fieldObj.sequenceType != FIELD_IS_SIMPLE):  # a list or an array
                    valueList = []
                    for item in child:
                        if (fieldObj.isAStruct()):
                            structMdc = None
                            # Special tag for not present structs...
                            if (item.tag != 'null'):
                                structMdc = readFromElementBasedXMLStruct(item,
                                    descObj.systemSchemaVersion, descObj.servProvSchemaVersion)
                                if (structMdc is None):
                                    # Don't print details because we expect the
                                    # failed function to do that
                                    printErrorMsg('Could not read structure from XML')
                                    return False
                                #
                            #
                            valueList.append(structMdc)
                        else:
                            # This will be a Element of values.
                            # There should only be 1 child node (a text node)
                            if (mdcDebugParsing):
                                printDebugMsg('list of non-structs: item.keys()=' + str(list(item.keys())))
                                printDebugMsg('list of non-structs: child.keys()=' + str(list(child.keys())))
                                printDebugMsg('list of non-structs: tostring(child)=' +
                                    xml.etree.ElementTree.tostring(child))
                                printDebugMsg('list of non-structs: tostring(item)=' +
                                    xml.etree.ElementTree.tostring(item))
                                printDebugMsg('type(item)=' + str(type(item)))
                                printDebugMsg('list of non-structs: len(item)=' + str(len(item)))
                                printDebugMsg('list of non-structs: item.text=' + item.text)
                            #TODO How do we handle <value/> i.e. null value
                            # valueList.append(None)
                            # <value>foo</value>
                            valueList.append(item.text)
                        #
                    #
                    self.setValue(descIdx, fieldObj, valueList)
                elif (fieldObj.isAStruct()):
                    subElements = []
                    for item in child:
                        subElements.append(item)
                        if (mdcDebugParsing):
                            printDebugMsg('struct: called: item="' + xml.etree.ElementTree.tostring(item) + '"')
                    if (len(subElements) != 1):
                        printErrorMsg('More than one subelement found for a simple struct' +
                            '\nNumber subelements=' + str(len(subElements)) +
                            '\nOriginal input is=' + child.toxml())
                        return False
                    if (mdcDebugParsing):
                        printDebugMsg('struct: subElements[0]=' + xml.etree.ElementTree.tostring(subElements[0]))
                    structVal = readFromElementBasedXMLStruct(subElements[0],
                        descObj.systemSchemaVersion, descObj.servProvSchemaVersion)
                    if (structVal is None):
                        # Don't print details because we expect the
                        # failed function to do that
                        printErrorMsg('Could not read structure from XML')
                        return False
                    self.setValue(descIdx, fieldObj, structVal)
                else:
                    # Regular field
                    valueStr = str(child.text)
                    if (mdcDebugParsing):
                        printDebugMsg('regular field: value=' + valueStr)
                    self.setValue(descIdx, fieldObj, valueStr)
            # end of 'for fieldObj in descObj.fieldObjList' loop
        # end of 'for descObj in self.descObj.descObjList'
        return True
    #
    #===================================================================================================================
    #
    # readFromField - internal function.
    # External callers should call readFromStr()
    #
    #===================================================================================================================
    # DataContainer
    def readFromField(self, inputStr, descIdx, fieldObj):
        ''' This internal function parses the passed string and updates the
            passed field's value.

        This is an internal function.

        This routine will handle an entire list or an entire array or an
        entire struct.

        The parameters are:

        inputStr -  this is the string to be parsed. It represents the fields
                    in a data container in compact format.

        descIdx - this is a zero-relative integer that indicates which
                    level of DataContainer the field is in. A value of 0
                    indicates the top-level DataContainer. A value of 1
                    indicates the first base DataContainer, etc.

        fieldObj -  this is the field to be updated. This must be a
                    DataContainerField object.

        returns   - a tuple of two. The first field is a success flag
                    (True = success, False = Error). The second field is the
                    remaining string.
        '''
        global HEX_DIGITS
        global kMaxStringBlobSizeInBytes
        global mdcDebugParsing
        #
        origInputStr = inputStr
        if (mdcDebugParsing):
            printDebugMsg("called: inputStr='" + inputStr + "'")
        foundArrayListStart = False
        while (True):
            if (mdcDebugParsing):
                printDebugMsg("top of loop: inputStr='" + inputStr + "'")
            # We don't call isSimple() here because it is slower than
            # doing it this way.
            if (fieldObj.sequenceType != FIELD_IS_SIMPLE):
                if (not foundArrayListStart):
                    if (inputStr[0] == LEFT_BRACE):
                        foundArrayListStart = True
                        inputStr = inputStr[1:].lstrip()
                        # Quick check to see if this is {}
                        if (inputStr[0] == RIGHT_BRACE):
                            fieldValueIdx = fieldObj.valueIdx
                            self.fieldValueArrayArray[descIdx][fieldValueIdx] = []
                            # We are done, but eat this character first
                            inputStr = inputStr[1:].lstrip()
                            return True, inputStr
                    else:
                        printErrorMsg('Line is not valid. expecting {.' +
                            '\n    Original data is=' + origInputStr +
                            '\n    Current  data is=' + inputStr +
                            '\n    Field name=' + fieldObj.name + ', dataType=' + fieldObj.getDataTypeStr())
                        return False, inputStr
            # Find the end of the value
            strLen = len(inputStr)
            fieldEndIdx = 0
            fieldStartIdx = 0
            usingSpecialStrSyntax = False
            # If it is a STRING or BLOB, then we use a special syntax.
            if (((fieldObj.dataType == DATA_TYPE_STRING) or(fieldObj.dataType == DATA_TYPE_BLOB))
                    and inputStr[0] == '('):        # This is faster than startswith('(')
                # This is using the special syntax: (size:data)
                colonIdx = 0
                while (colonIdx < strLen):
                    testChar = inputStr[colonIdx]
                    if (testChar == ':'):
                        break
                    colonIdx += 1
                if (colonIdx == strLen):
                    printErrorMsg('Line is not valid. String/Blob syntax (size:data) found. Expecting :.' +
                        '\n    Original data is=' + origInputStr +
                        '\n    Current  data is=' + inputStr +
                        '\n    Field name=' + fieldObj.name + ', dataType=' + fieldObj.getDataTypeStr())
                    return False, inputStr
                # NOTE: Python string slice does not include last indexed char!
                fieldSize = int(inputStr[1:colonIdx])
                if (fieldSize > kMaxStringBlobSizeInBytes):
                    raise ValueError('readFromField error: Line is not valid. ' + \
                        'A STRING/BLOB field (' + fieldObj.name  + ') has a value ' + \
                        'with the size of (' + str(fieldSize) + ') and that exceeds the maximum size (' + \
                        str(kMaxStringBlobSizeInBytes) + '. Config file: ' + configFileName)
                fieldStartIdx = colonIdx + 1
                # Make sure the last character is a ')'
                # Note: We allow hex characters to be specified using \dd syntax.
                #
                tempIdx = fieldStartIdx
                remainingSize = fieldSize
                while (tempIdx < strLen):
                    if (remainingSize == 0):
                        break
                    testChar = inputStr[tempIdx]
                    if (testChar == '\\'):
                        # Check for either another backslash or a hex value
                        tempIdx += 1
                        if (tempIdx >= strLen):
                            break
                        testChar = inputStr[tempIdx]
                        if (testChar == '\\'):
                            tempIdx += 1
                            remainingSize -= 1
                            continue
                        else:
                            # We expect two characters that are hex values.
                            if testChar not in HEX_DIGITS:
                                printErrorMsg('Line is not valid. String/Blob syntax (size:data) found. ' +
                                    'Expecting a hex digit after a \\.' +
                                    '\n    First character is:' + str(testChar) +
                                    '\n    Character found at tempIdx=' + str(tempIdx) +
                                    '\n    fieldStartIdx=' + str(fieldStartIdx) +
                                    '\n    fieldSize=' + str(fieldSize) +
                                    '\n    inputStr[' + str(tempIdx) + ']=' + inputStr[tempIdx] +
                                    '\n    Original data is=' + origInputStr +
                                    '\n    Current  data is=' + inputStr +
                                    '\n    Field name=' + fieldObj.name + ', dataType=' + fieldObj.getDataTypeStr())
                                return False, inputStr
                            # Check the next character
                            tempIdx += 1
                            if (tempIdx >= strLen):
                                break
                            testChar = inputStr[tempIdx]
                            if testChar not in HEX_DIGITS:
                                printErrorMsg('Line is not valid. String/Blob syntax (size:data) found. ' +
                                    'Expecting a hex digit after a \\.' +
                                    '\n    Second character is:' + str(testChar) +
                                    '\n    Character found at tempIdx=' + str(tempIdx) +
                                    '\n    fieldStartIdx=' + str(fieldStartIdx) +
                                    '\n    fieldSize=' + str(fieldSize) +
                                    '\n    inputStr[' + str(tempIdx) + ']=' + inputStr[tempIdx] +
                                    '\n    Original data is=' + origInputStr +
                                    '\n    Current  data is=' + inputStr +
                                    '\n    Field name=' + fieldObj.name + ', dataType=' + fieldObj.getDataTypeStr())
                                return False, inputStr
                            tempIdx += 1
                            remainingSize -= 1
                            continue
                    tempIdx += 1
                    remainingSize -= 1
                # end of while
                if (tempIdx >= strLen):
                    printErrorMsg('Line is not valid. ' +
                        'String/Blob syntax (size:data) found. Data size exceeds the data specified.' +
                        '\n    colonIdx=' + str(colonIdx) +
                        '\n    fieldStartIdx=' + str(fieldStartIdx) +
                        '\n    fieldSize=' + str(fieldSize) +
                        '\n    tempIdx=' + str(tempIdx) +
                        '\n    strLen=' + str(strLen) +
                        '\n    Original data is=' + origInputStr +
                        '\n    Current  data is=' + inputStr +
                        '\n    Field name=' + fieldObj.name + ', dataType=' + fieldObj.getDataTypeStr())
                    return False, inputStr
                if (inputStr[tempIdx] != ')'):
                    printErrorMsg('Line is not valid. String/Blob syntax (size:data) found. Expecting ).' +
                        '\n    colonIdx=' + str(colonIdx) +
                        '\n    fieldStartIdx=' + str(fieldStartIdx) +
                        '\n    fieldSize=' + str(fieldSize) +
                        '\n    inputStr[' + str(tempIdx) + ']=' + inputStr[tempIdx] +
                        '\n    Original data is=' + origInputStr +
                        '\n    Current  data is=' + inputStr +
                        '\n    Field name=' + fieldObj.name + ', dataType=' + fieldObj.getDataTypeStr())
                    return False, inputStr
                usingSpecialStrSyntax = True
                fieldEndIdx = tempIdx
                if (mdcDebugParsing):
                    printDebugMsg('colonIdx=' + str(colonIdx))
                    printDebugMsg('fieldStartIdx=' + str(fieldStartIdx))
                    printDebugMsg('fieldEndIdx=' + str(fieldEndIdx))
                    printDebugMsg('fieldSize=' + str(fieldSize))
            else:
                while (fieldEndIdx < strLen):
                    testChar = inputStr[fieldEndIdx]
                    if (testChar in SPECIAL_CHARS):
                        break
                    fieldEndIdx += 1
            #
            if (fieldObj.dataType != DATA_TYPE_STRUCT):
                # NOTE: Python string slice does not include last indexed char!
                fieldValue = inputStr[fieldStartIdx:fieldEndIdx]
                if (mdcDebugParsing):
                    printDebugMsg("Processing NON-STRUCT. inputStr='" + inputStr +
                        "'. Field name=" + fieldObj.name + ", Found fieldValue=" + fieldValue)
                if (fieldValue == ''):
                    # We don't call isSimple() here because it is slower than doing it this way.
                    if (fieldObj.sequenceType == FIELD_IS_SIMPLE):
                        if ((fieldObj.dataType != DATA_TYPE_STRING) and (fieldObj.dataType != DATA_TYPE_BLOB)):
                            printErrorMsg('Line is not valid.' +
                                ' expecting a non-empty value for a NON-STRUCT. Found an empty value' +
                                '\n    Original data is=' + origInputStr +
                                '\n    Current  data is=' + inputStr +
                                '\n    Field name=' + fieldObj.name + ', dataType=' + fieldObj.getDataTypeStr())
                            return False, inputStr
                    else:
                        # Not a simple field (array or list). Set the value to None
                        fieldValue = None
                # Bump past the field
                if (usingSpecialStrSyntax):
                    # Need to bump past the ')'
                    inputStr = inputStr[fieldEndIdx + 1:]
                else:
                    inputStr = inputStr[fieldEndIdx:]
                if (mdcDebugParsing):
                    printDebugMsg("Processing NON-STRUCT. inputStr='" + inputStr + "'")
                # We don't call isSimple() here because it is slower than doing it this way.
                fieldValueIdx = fieldObj.valueIdx
                if (fieldObj.sequenceType != FIELD_IS_SIMPLE):
                    if (self.fieldValueArrayArray[descIdx][fieldValueIdx] is None):
                        self.fieldValueArrayArray[descIdx][fieldValueIdx] = []
                    # TODO use appendValue.
                    self.fieldValueArrayArray[descIdx][fieldValueIdx].append(fieldValue)
                else:
                    # Simple field
                    self.fieldValueArrayArray[descIdx][fieldValueIdx] = \
                        fieldObj.convertValue(fieldValue, self.descObj.descIndex)
                    return True, inputStr
                # Look for possibly more values.
            else:
                # Must be a STRUCT datatype
                if (mdcDebugParsing):
                    printDebugMsg("Processing STRUCT. Field name=" + fieldObj.name +
                        ", inputStr='" + inputStr + "'")
                structMdc = None
                elementIsPresent = True
                # If this is a list or structs or an array of structs, see if this element is not-present.
                if (fieldObj.sequenceType != FIELD_IS_SIMPLE):
                    if ((inputStr[0] == COMMA) or (inputStr[0] == RIGHT_BRACE)):
                        elementIsPresent = False
                if (elementIsPresent):
                    #
                    # See if the next token is a '<', indicating a specific type
                    # of struct. If it is there, then attempt to fetch the proper type of container to use.
                    structDescObj = None
                    # Eat up the blanks
                    inputStr = inputStr.lstrip()
                    if (inputStr[0] == LESS_THAN):
                        descKey, systemSchemaVersion, servProvSchemaVersion, inputStr = readDescriptorTag(inputStr)
                        if (descKey == 0):
                            printErrorMsg('Line is not valid.' +
                                ' readDescriptorTag returned a descriptor key of 0.' +
                                '\n    Original data is=' + origInputStr +
                                '\n    Current  data is=' + inputStr +
                                '\n    Field name=' + fieldObj.name + ', dataType=' + fieldObj.getDataTypeStr())
                            return False, inputStr
                        if (systemSchemaVersion != self.descObj.systemSchemaVersion):
                            printErrorMsg('Line is not valid. ' +
                                'readDescriptorTag returned a system schema version (' +
                                str(systemSchemaVersion) + ') that is different from the ' +
                                'expected value (' + str(self.descObj.systemSchemaVersion) + ')' +
                                '\n    Original data is=' + origInputStr +
                                '\n    Current  data is=' + inputStr +
                                '\n    Field name=' + fieldObj.name + ', dataType=' + fieldObj.getDataTypeStr())
                            return False, inputStr
                        if (servProvSchemaVersion != self.descObj.servProvSchemaVersion):
                            printErrorMsg('Line is not valid. ' +
                                'readDescriptorTag returned a service provider schema version (' +
                                str(servProvSchemaVersion) + ') that is different from the ' +
                                'expected value (' + str(self.descObj.servProvSchemaVersion) + ')' +
                                '\n    Original data is=' + origInputStr +
                                '\n    Current  data is=' + inputStr +
                                '\n    Field name=' + fieldObj.name + ', dataType=' + fieldObj.getDataTypeStr())
                            return False, inputStr
                        # Get the DataContainerDescriptor
                        structDescObj = self.descObj.descIndex.getByKey(descKey)
                        if (structDescObj is None):
                            printErrorMsg('Line is not valid.' +
                                ' readDescriptorTag returned an invalid descKey (' + str(descKey) + ')' +
                                '\n    Original data is=' + origInputStr +
                                '\n    Current  data is=' + inputStr +
                                '\n    Field name=' + fieldObj.name + ', dataType=' + fieldObj.getDataTypeStr())
                            return False, inputStr
                    else:
                        structDescObj = self.descObj.descIndex.get(fieldObj.structId)
                        #
                        # We need to get the descriptor for this struct. If it
                        # is unknown, then we can't continue.
                        if (structDescObj is None):
                            printErrorMsg('Unknown struct name (' + str(fieldObj.structId) +
                                ') for (' + fieldObj.name + ')' +
                                '\n    Original data is=' + origInputStr +
                                '\n    Current  data is=' + inputStr +
                                '\n    Field name=' + fieldObj.name + ', dataType=' + fieldObj.getDataTypeStr())
                            return False, inputStr
                    # A struct starts with a "[" and ends with a "]".
                    # We don't skip over the '[' token here. We will call the internal readFrom to process this Struct.
                    structMdc = structDescObj.create()
                    success, inputStr = structMdc.readFrom(inputStr)
                    if (not success):
                        return False, inputStr
                    if (mdcDebugParsing):
                        printDebugMsg('Processed STRUCT. Field name=' + fieldObj.name +
                            ", inputStr='" + inputStr + "'")
                #
                # Now add the struct MDC to the main MDC
                # We don't call isSimple() here because it is slower than
                # doing it this way.
                fieldValueIdx = fieldObj.valueIdx
                if (fieldObj.sequenceType != FIELD_IS_SIMPLE):
                    if (self.fieldValueArrayArray[descIdx][fieldValueIdx] is None):
                        self.fieldValueArrayArray[descIdx][fieldValueIdx] = []
                    # TODO use appendValue.
                    self.fieldValueArrayArray[descIdx][fieldValueIdx].append(structMdc)
                else:
                    # Simple field
                    self.fieldValueArrayArray[descIdx][fieldValueIdx] = structMdc
                #
                if (fieldObj.sequenceType == FIELD_IS_SIMPLE):
                    return True, inputStr
            #
            # To get here we must be processing a list or an array.
            # The only acceptable characters here are a } or a comma
            if (inputStr[0] == COMMA):
                # Eat the comma and any possible blanks
                inputStr = inputStr[1:].lstrip()
                continue
            if (inputStr[0] == RIGHT_BRACE):
                # We are done, but eat this character first
                inputStr = inputStr[1:].lstrip()
                return True, inputStr
            # Process the next value
            continue

    #
    #===================================================================================================================
    # DataContainer
    # readFromXML - internal function.
    # External callers should call readFromStr()
    def readFromXML(self, element):
        ''' This internal function does the XML parsing of each field of the
            data container.

        This is an internal function. External callers should call
        readFromXMLStr().

        The parameters are:

        element - this is the XML element object representing the data container.

        returns   - True for success. False for Error.
        '''
        if (mdcDebugParsing):
            printDebugMsg("called: element='" + element.toxml('utf-8') + "'")

        descIdx = -1
        for descObj in self.descObj.descObjList:
            descIdx += 1
            if (mdcDebugParsing):
                printDebugMsg('procesing: container=' + descObj.containerId)

            if (not element.hasAttribute('name')):
                printErrorMsg('Element contains no name attribute.' +
                    '\nOriginal input is=' + element.toxml())
                return False

            descObjId = element.getAttribute('name')
            # NOTE: we don't expect a system_schema or service_provider_schema
            # since we already have the DataContainer (self).

            if (descObjId != descObj.containerId):
                printErrorMsg('Mismatched base container tag. Found ' + descObjId +
                    '\nExpecting ' + descObj.containerId +
                    '\nOriginal input is=' + element.toxml())
                return False
            fields = {}
            baseContainers = []
            for child in element.childNodes:
                # For some reason, elements have a text node even if they don't
                # have any text. Skip over them.
                if (isinstance(child, xml.dom.minidom.Text)):
                    continue

                if (child.tagName not in ['list', 'array', 'field', 'container']):
                    printErrorMsg('Element has sub-elements which are not fields, lists, arrays, or containers' +
                        '\nOriginal input is=' + element.toxml())
                    return False

                if (not child.hasAttribute('name')):
                    printErrorMsg('Child element does not have a name attribute' +
                        '\nOriginal input is=' + child.toxml())
                    return False

                if (child.tagName == 'container'):
                    baseContainers.append(child)
                else:
                    name = child.getAttribute('name')
                    fields[name] = child

            for fieldObj in descObj.fieldObjList:
                if (fieldObj.name not in fields):
                    continue

                child = fields[fieldObj.name]
                if (fieldObj.sequenceType != FIELD_IS_SIMPLE):  # a list or an array
                    if (fieldObj.isList()):
                        if (child.tagName != 'list'):
                            printErrorMsg('Field object is a list, but XML tag is ' + child.tagName +
                                '\nOriginal input is=' + child.toxml())
                            return False
                    else:
                        if (child.tagName != 'array'):
                            printErrorMsg('Field object is an array, but XML tag is ' + child.tagName +
                                '\nOriginal input is=' + child.toxml())
                            return False

                        if (not child.hasAttribute('size')):
                            printErrorMsg('Could not find array size' +
                                '\nOriginal input is=' + child.toxml())
                            return False

                    value = []
                    for item in child.childNodes:
                        # For some reason, elements have a text node even if
                        # they don't have any text. Skip over them.
                        if (isinstance(item, xml.dom.minidom.Text)):
                            continue

                        if (fieldObj.isAStruct()):
                            if (item.tagName != 'struct'):
                                printErrorMsg('Found a non-struct element in a list of structs' +
                                    '\nOriginal input is=' + child.toxml())
                                return False

                            if (not item.hasAttribute('name')):
                                # This must be an empty struct.
                                # <value/> i.e. null value
                                value.append(None)
                                continue

                            structName = item.getAttribute('name')

                            if (structName != fieldObj.structId):
                                # Check if this is an unknown/unnamed struct.
                                if (fieldObj.structId):
                                    # This is a named struct.
                                    # Check if structName is a descendant of fieldObj.structId
                                    # Get the DataContainerDescriptor for fieldObj.structId
                                    tempDescObj = self.descObj.descIndex.get(fieldObj.structId)
                                    if (tempDescObj is None):
                                        printErrorMsg('The MDC Descriptor Index did not find a container' +
                                            ' with name=' + fieldObj.structId +
                                            '\nOriginal input is=' + item.toxml())
                                        return False
                                    fieldObjStructKey = tempDescObj.containerKey
                                    # Get the struct's descriptor
                                    # Get the DataContainerDescriptor for structName
                                    tempStructDescObj = self.descObj.descIndex.get(structName)
                                    if (tempStructDescObj is None):
                                        printErrorMsg('The MDC Descriptor Index did not find a container' +
                                            ' with name=' + structName +
                                            '\nOriginal input is=' + item.toxml())
                                        return False
                                    tempDescObj = self.descObj.descIndex.get(fieldObj.structId)
                                    if (not tempStructDescObj.isDescendantOf(fieldObjStructKey)):
                                        printErrorMsg("Struct name and field obj name don't match" +
                                            '\nStruct name=' + structName +
                                            '\nField obj name=' + fieldObj.structId +
                                            '\nOriginal input is=' + item.toxml())
                                        return False

                            structMdc = readFromXMLStruct(item, self.descObj.systemSchemaVersion,
                                self.descObj.servProvSchemaVersion)
                            if (structMdc is None):
                                # Don't print details because we expect the
                                # failed function to do that
                                printErrorMsg('Could not read structure from XML')
                                return False
                            value.append(structMdc)
                        else:
                            if (item.tagName != 'value'):
                                printErrorMsg('Found a non-value element in a list of values' +
                                    '\nOriginal input is=' + child.toxml())
                                return False

                            # There should only be 1 child node (a text node)
                            numChildNodes = len(item.childNodes)
                            if (numChildNodes == 0):
                                # <value/> i.e. null value
                                value.append(None)
                            elif (numChildNodes == 1):
                                # <value>foo</value>
                                value.append(item.childNodes[0].data)
                            else:
                                printErrorMsg('Item has more than one child node' +
                                    '\nOriginal input is=' + item.toxml())
                            #
                        #
                    self.setValue(descIdx, fieldObj, value)
                elif (fieldObj.isAStruct()):
                    if (child.tagName != 'field' or
                            child.getAttribute('type') !=
                            DATA_TYPE_STRINGS[DATA_TYPE_STRUCT]):
                        printErrorMsg('Field obj is a struct but XML tab or type is wrong' +
                            '\nOriginal input is=' + child.toxml())
                        return False

                    subElements = []
                    for item in child.childNodes:
                        # For some reason, elements have a text node even if
                        # they don't have any text. Skip over them.
                        if (isinstance(item, xml.dom.minidom.Text)):
                            continue
                        subElements.append(item)
                    if (len(subElements) != 1):
                        printErrorMsg('More than one subelement found for a simple struct' +
                            '\nNumber subelements=' + str(len(subElements)) +
                            '\nOriginal input is=' + child.toxml())
                        return False

                    structVal = readFromXMLStruct(subElements[0], self.descObj.systemSchemaVersion,
                        self.descObj.servProvSchemaVersion)
                    if (structVal is None):
                        # Don't print details because we expect the
                        # failed function to do that
                        printErrorMsg('Could not read structure from XML')
                        return False

                    self.setValue(descIdx, fieldObj, structVal)
                else:
                    if (child.tagName != 'field' or
                            fieldObj.getDataTypeStr() != child.getAttribute('type')):
                        printErrorMsg('Field obj is a ' + fieldObj.getDataTypeStr() + ' but XML tag or type is wrong' +
                            '\nOriginal input is=' + child.toxml())
                        return False

                    if (len(child.childNodes) != 0):
                        printErrorMsg('Field has children when it should not' +
                            '\nOriginal input is=' + child.toxml())
                        return False

                    if (not child.hasAttribute('value')):
                        printErrorMsg('Could not find attribute named value' +
                            '\nOriginal input is=' + child.toxml())
                        return False
                    value = child.getAttribute('value')

                    self.setValue(descIdx, fieldObj, value)
            # end of 'for fieldObj in descObj.fieldObjList' loop

            #
            # Check if this has a base container.
            # See if we have a base container to process
            if (descObj.baseContainerKey == 0):
                if (len(baseContainers) != 0):
                    printErrorMsg('The MDC should have no base class but does' +
                        '\nOriginal input is=' + element.toxml())
                    return False
                return True
            else:
                if (len(baseContainers) != 1):
                    printErrorMsg('The MDC should have one and only one base class' +
                        '\nNumber of base containers=' + str(len(baseContainers)) +
                        '\nOriginal input is=' + element.toxml())
                    return False

                if (mdcDebugParsing):
                    printDebugMsg("Processing BASE CLASS: XML='" + baseContainers[0].toxml() + "'")

                if (not baseContainers[0].hasAttribute('name')):
                    printErrorMsg('Could not find name of base container' +
                        '\nOriginal input is=' + baseContainers[0].toxml())
                    return False
                baseContainerId = baseContainers[0].getAttribute('name')

                # Get the DataContainerDescriptor
                tempDescObj = self.descObj.descIndex.get(baseContainerId)
                if (tempDescObj is None):
                    printErrorMsg('The MDC Descriptor Index did not find a container' +
                        ' with name=' + baseContainerId +
                        '\nOriginal input is=' + baseContainers[0].toxml())
                    return False

                element = baseContainers[0]
        # end of 'for descObj in self.descObj.descObjList'
        return True
    #
    #===================================================================================================================
    # DataContainer
    def reset(self, saveStructs=False):
        ''' This function sets all fields to None.

        The parameters are:

        saveStructs -  if this is True, then any struct fields will have
                    their field values set to None. Otherwise, the entire
                    struct is set to None.
        '''
        # Set all fields to None. If saveStructs is True, then
        # don't get rid of them, just set their fields to None
        descIdx = -1
        for descObj in self.descObj.descObjList:
            descIdx += 1
            for fieldObj in descObj.fieldObjList:
                value = self.fieldValueArrayArray[descIdx][fieldObj.valueIdx]
                if (value is None):
                    continue
                if (saveStructs):
                    if (fieldObj.dataType == DATA_TYPE_STRUCT):
                        value.reset(saveStructs)
                        continue
                self.fieldValueArrayArray[descIdx][fieldObj.valueIdx] = None
        return
    #
    #===================================================================================================================
    # DataContainer
    def setUsingKey(self, fieldKey, fieldValue):
        ''' This function sets the specified field to the specified value.

        The parameters are:

        fieldKey -  this is the FieldKey instance that identifies the field
                    that is being set.

        fieldValue -  this is the new value to use. If the value is blank,
                    then this function just returns. Since the compact format
                    eats blanks, we can't tell the difference between a
                    not-present field and one that is blank.
        '''
        global configFileName
        global mdcDebug
        # TODO: There is no checking to make sure this fieldKey
        # is correct for this DataContainer
        #
        if (fieldValue == ' '):
            return
        # Get the number of levels (zero-relative)
        maxLevels = fieldKey.levelCount - 1
        descObjList = self.descObj.descObjList
        level = 0
        mdc = self
        while (True):
            containerKey = fieldKey.descKeyList[level]
            fieldIdx = fieldKey.fieldIdxList[level]
            # Find the descriptor that has the containerKey that we are
            # looking for
            descObj = None
            descIdx = -1
            for descObj in descObjList:
                descIdx += 1
                if (descObj.containerKey == containerKey):
                    break
            # Did we find it?
            if (descObj.containerKey != containerKey):
                # No
                raise NameError('setUsingKey error: the fieldKey (' + fieldKey.printStr() + \
                    ') is incorrect. The zero-relative level (' + str(level) + \
                    ') of the fieldKey (which is descriptor key=' + str(fieldKey.descKeyList[level]) + \
                    ' and field index=' + str(fieldKey.fieldIdxList[level]) + \
                    ') was not found. Config file: ' + configFileName + \
                    '. Container=' + self.printStr())
            # Get the field
            fieldObj = descObj.fieldObjList[fieldIdx]
            #
            # Have we processed all levels of this fieldKey?
            if (level >= maxLevels):
                # Yes, then set the value.
                # But first, if this is an array or list, make sure
                # a string version of the compact format is not used.
                # This will cause problems when reading the value in.
                # For example, if '{0, 1}' was passed
                # We don't call isSimple() here because it is slower than doing it this way.
                if (fieldObj.sequenceType != FIELD_IS_SIMPLE):
                    # Is the fieldValue a string?
                    if isinstance(fieldValue, (bytes, str)):
                        fieldValueStr = str(fieldValue)
                        if (fieldValueStr[0] == '{'):       # This is faster than startswith('{')
                            # get rid of the '{' and '}'
                            fieldValueStr = fieldValueStr.replace('{', '')
                            fieldValueStr = fieldValueStr.replace('}', '')
                            # get rid of spaces
                            fieldValueStr = fieldValueStr.replace(' ', '')
                            # create a list
                            fieldValue = fieldValueStr.split(',')
                    else:
                        # Make sure the fieldValue is a list
                        if ((type(fieldValue) != list) and (fieldValue is not None)):
                            raise TypeError('setUsingKey error: the field (' + fieldObj.name + \
                                ') must be a list-type or string or None value. It has a type of (' + \
                                str(type(fieldValue)) + \
                                ') and a value of (' + str(fieldValue) + \
                                '). Config file: ' + configFileName + \
                                '. The fieldObj is: ' + str(fieldObj) + \
                                '. The container is: ' + self.printStr())
                mdc.setValue(descIdx, fieldObj, fieldValue)
                return
            #
            # Here we have a multi-level fieldKey.
            # This value must be a STRUCT.
            if (fieldObj.dataType != DATA_TYPE_STRUCT):
                raise NameError('setUsingKey error: the fieldKey (' + fieldKey.printStr() + \
                    ') is incorrect. The zero-relative level (' + str(level) + \
                    ') of the fieldKey (which is descriptor key=' + str(fieldKey.descKeyList[level]) + \
                    ' and field index=' + str(fieldKey.fieldIdxList[level]) + \
                    ') should point to a STRUCT but its type is (' + str(fieldObj.dataType) + \
                    ':' + fieldObj.getDataTypeStr() + '). ' + \
                    'Config file: ' + configFileName)
            # If the value is None, then we add it if we can.
            value = mdc.fieldValueArrayArray[descIdx][fieldObj.valueIdx]
            if (value is None):
                # Add this STRUCT
                #
                # We need to get the descriptor for this struct.
                # If it is unknown, then we can't continue.
                if (fieldObj.structId == ''):
                    raise NameError('setUsingKey error: the field name (' + str(fieldObj.name) + \
                        ') is incorrect. The zero-relative level (' + str(level) + \
                        ') of the fieldKey (which is descriptor key=' + str(fieldKey.descKeyList[level]) + \
                        ' and field index=' + str(fieldKey.fieldIdxList[level]) + \
                        ') should point to a known STRUCT but it has an unknown structId. ' + \
                        'Config file: ' + configFileName)
                newDescObj = self.descObj.descIndex.get(fieldObj.structId)
                newMdcObj = newDescObj.create()
                mdc.fieldValueArrayArray[descIdx][fieldObj.valueIdx] = newMdcObj
                value = newMdcObj
                # Fall through
            level += 1
            # Value is a DataContainer. Get the next level's descObjList
            descObjList = value.descObj.descObjList
            mdc = value
    #
    #===================================================================================================================
    # DataContainer
    def setUsingName(self, fieldName, fieldValue):
        ''' This function sets the specified field to the specified value.

        The parameters are:

        fieldName - this is the name of the field that is being set.
                    This value is a string.

        fieldValue -  this is the new value to use. If the value is blank,
                    then this function just returns. Since the compact format
                    eats blanks, we can't tell the difference between a
                    not-present field and one that is blank.
        '''
        global configFileName
        fieldKey = self.getFieldKey(fieldName)
        if (fieldKey is None):
            # NOT FOUND
            raise NameError('setUsingName error: the field name (' + str(fieldName) + ') was not found. ' + \
                'Config file: ' + configFileName)
        return self.setUsingKey(fieldKey, fieldValue)
    #
    #===================================================================================================================
    #
    # setValue - internal function.
    #
    #===================================================================================================================
    # DataContainer
    def setValue(self, descIdx, fieldObj, value):
        ''' This function sets the value for this field.

        The parameters are:

        descIdx - this is a zero-relative integer that indicates which
                    level of DataContainer the field is in. A value of 0
                    indicates the top-level DataContainer. A value of 1
                    indicates the first base DataContainer, etc.

        fieldObj  - this is the field's DataContainerField.

        value     - this is the new value to set this field to.

        The Python type of the passed 'value' must be one that can be
        converted to the type listed in the following table with the
        exception that a 'value' of None is allowed for everything.

            dataType                Python type
            -------------------------------------
            DATA_TYPE_BLOB          string
            DATA_TYPE_BOOLEAN       int
            DATA_TYPE_BUFFER_ID     string
            DATA_TYPE_DATE          string
            DATA_TYPE_DATETIME      string
            DATA_TYPE_DECIMAL       decimal
            DATA_TYPE_FIELD_KEY     string
            DATA_TYPE_INT8          int
            DATA_TYPE_INT16         int
            DATA_TYPE_INT32         int
            DATA_TYPE_INT64         int
            DATA_TYPE_INT128        int
            DATA_TYPE_OBJECT_ID     string
            DATA_TYPE_PHONE_NUMBER  string
            DATA_TYPE_STRING        string
            DATA_TYPE_STRUCT        class 'data_container.DataContainer'
            DATA_TYPE_TIME          string
            DATA_TYPE_UINT8         int
            DATA_TYPE_UINT16        int
            DATA_TYPE_UINT32        int
            DATA_TYPE_UINT64        int
            DATA_TYPE_UINT128       int
        '''
        global mdcDebug
        #
        fieldValueIdx = fieldObj.valueIdx
        # We don't call isSimple() here because it is slower than
        # doing it this way.
        if (fieldObj.sequenceType == FIELD_IS_SIMPLE):
            self.fieldValueArrayArray[descIdx][fieldValueIdx] = fieldObj.convertValue(value, self.descObj.descIndex)
            return
        #
        # List or Arrays
        #
        if (value == [] or value is None):
            self.fieldValueArrayArray[descIdx][fieldValueIdx] = value
            return
        if (type(value) != TYPE_OF_LIST):
            seqTypeStr = 'list'
            if (fieldObj.isArray()):
                seqTypeStr = 'array'
            raise TypeError('setValue error: you are trying to set the field (' + fieldObj.name + \
                ') that has a dataType of (' + seqTypeStr + ' of ' + fieldObj.getDataTypeStr() + \
                ') with a value that has the wrong type (' + str(type(value)) + \
                "). This must be done using a 'list' type. " + fieldObj.printStr('') + ', ' + \
                'Config file: ' + configFileName)
        self.fieldValueArrayArray[descIdx][fieldValueIdx] = \
            [fieldObj.convertValue(val, self.descObj.descIndex) for val in value]
        return

    #
    #===================================================================================================================
    #
#
#
# Need to set TYPE_OF_MDC
_tempMdc = DataContainer(None)
TYPE_OF_MDC = type(_tempMdc)
#
# Need to set TYPE_OF_FIELD_KEY
_tempFieldKey = FieldKey([], [])
TYPE_OF_FIELD_KEY = type(_tempFieldKey)
#
#=======================================================================================================================
#
class FieldInitDescriptor(object):
    ''' This class contains information about how a Field should
        be initialized when creating demo data.

    The data members of this class are:

        fieldName  - this is the name of this field.

        initMethod - this indicates the method to call to initialize this field.
                    This value is an integer. The possible values are:
                        0 (FIELD_INIT_IS_NONE) - None.
                        1 (FIELD_INIT_IS_ONE_LIST) - one list (dataOneList) is
                            used in a round-robin manner.
                        2 (FIELD_INIT_IS_TWO_LISTS_AND_INCREMENT) - two lists
                            (dataOneList and dataTwoList) are used.
                        3 (FIELD_INIT_IS_COUNTER) - an initial value with a
                            maximum and minumum value.
                        4 (FIELD_INIT_IS_FROM_FILE) - a file contains one
                            record for each value.
                        5 (FIELD_INIT_IS_CALCULATED) - dataOneList contains a
                            list of Python syntax to use to create each value.

        dataOneList - if initMethod == 1, then this is a list that contains
                    the string values the initMethod uses to initialize this
                    field. If initMethod == 5, then this is a list that contains
                    a list of Python syntax to use to create each value.

        dataOneListLen - this is the length of dataOneList.

        dataTwoList - this is a list that contains the values the initMethod
                    uses to initialize this field.

        dataTwoListLen - this is the length of dataTwoList.

        dataStartingValue - this is a string value that contains the starting
                    value to use by the initMethod when initializing this field.

        dataStartingValueLen - this is the length of dataStartingValue.

        dataInitialValue - this is the initial value of a counter. This is a number.

        dataMinimumValue - this is the minimum value of a counter. This is a
                    number or None. NOTE: None is treated as 0.

        dataMaximumValue - this is the maximum value of a counter. This is a
                    number or None.

        dataFileName - this is the name of the file to read to get the values from.

        dataFile - this is the object that represents the open dataFileName.

        dataDict - this is the dictionary of variables that is used when
                    using the FIELD_INIT_IS_CALCULATED method. If this
                    dictionary does not have a element in it with the key
                    of the fieldName, then it will be added with a value
                    of None.
    '''
    #
    #===================================================================================================================
    # FieldInitDescriptor
    def __del__(self):
        if (self.dataFile):
            self.dataFile.close()
            self.dataFile = None
    #
    #===================================================================================================================
    # FieldInitDescriptor
    def __init__(self, fieldName, initMethod=FIELD_INIT_IS_NONE,
            dataOneList=None, dataTwoList=None, dataStartingValue=None,
            dataInitialValue=0, dataMinimumValue=None, dataMaximumValue=None,
            dataFileName=None, dataDict=None):
        self.fieldName = fieldName
        self.initMethod = ''
        self.dataOneList = None
        self.dataOneListLen = 0
        self.dataTwoList = None
        self.dataTwoListLen = 0
        self.dataStartingValue = None
        self.dataStartingValueLen = 0
        self.dataInitialValue = 0
        self.dataMinimumValue = None
        self.dataMaximumValue = None
        self.dataFileName = None
        self.dataFile = None
        self.dataDict = None
        # Check the params:
        if (initMethod not in ALL_FIELD_INIT_TYPES):
            raise ValueError('Invalid initMethod (' + str(initMethod) + ')')
        self.update(initMethod, dataOneList, dataTwoList, dataStartingValue,
            dataInitialValue, dataMinimumValue, dataMaximumValue,
            dataFileName, dataDict)
    #
    #===================================================================================================================
    # FieldInitDescriptor
    def __str__(self):
        return self.printStr('')
    #
    #===================================================================================================================
    # FieldInitDescriptor
    def createValue(self, count):
        ''' This function creates and returns a value based upon the initMethod.

        The parameters are:

        count -     this is used to determine which value to select from the
                    values in the data*lists. This is a numeric type.

                    NOTE: This value is ignored if the initMethod is
                    FIELD_INIT_IS_FROM_FILE where every call just reads the
                    next value from the file.

        returns   - the value to use for this field. The value returned is
                    a string, a list or None.
        '''
        global mdcDebug
        #
        # This function creates and returns a value based upon the initMethod.
        # The 'count' parameter is used to determine which value
        # to select from the values in the data*lists.
        # The value returned is always a string.
        #
        if (self.initMethod == FIELD_INIT_IS_NONE):
            printErrorMsg('The initMethod is "None" for the DataContainerFieldDescriptor named:' + \
                self.fieldName + '. Returning None')
            return None
        if (self.initMethod == FIELD_INIT_IS_ONE_LIST):
            # This method uses the dataOneList list in a round-robin manner.
            #
            if (self.dataOneListLen == 0):
                return None
            listOneIdx = count % self.dataOneListLen
            #
            result = self.dataOneList[listOneIdx]
            if (not isinstance(result, list)):
                result = str(result)
            return result
        #
        if (self.initMethod == FIELD_INIT_IS_TWO_LISTS_AND_INCREMENT):
            # This method creates and returns a string value based upon
            # two lists (dataOneList and dataTwoList) and an increment
            # (dataStartingValue).
            # The dataStartingValue field is a string and the size of it
            # indicates the max length of this field.
            # For example, if this has a value of '001', then this
            # field will never exceed 999. If it does, then the entire
            # result will be treated as an integer and the full increment
            # value will be added to it before it is converted to a string
            # and returned.
            # This works well for lists with numeric values. However, it
            # will cause a Python error if this happens if a list have
            # non-numeric values. To avoid this problem, either increase
            # the number of elements in the lists or increase the length
            # of the starting increment string.
            #
            if (self.dataOneListLen == 0):
                return None
            if (self.dataTwoListLen == 0):
                return None
            listOneIdx = count % self.dataOneListLen
            listTwoIdx = (count // self.dataOneListLen) % self.dataTwoListLen
            #
            # Since the dataStartingValue can have leading zeros, we will
            # concatenate it as a string first. Then we will add an increment based upon 'count'
            #
            startingIncrement = int(self.dataStartingValue)
            # Calculate the increment
            increment = int(count // (self.dataOneListLen * self.dataTwoListLen))
            newIncrement = startingIncrement + increment
            newIncrementStr = '%0*u' % (self.dataStartingValueLen, newIncrement)
            # Check if this overflowed the length.
            result = None
            if (len(newIncrementStr) > self.dataStartingValueLen):
                newIncrementStr = '%0*u' % (self.dataStartingValueLen, 0)
                # Put them all together
                tempResult = str(self.dataOneList[listOneIdx]) + str(self.dataTwoList[listTwoIdx]) + \
                    str(newIncrementStr)
                tempInt = int(tempResult) + newIncrement
                result = str(tempInt)
            else:
                # Put them all together
                result = str(self.dataOneList[listOneIdx]) + str(self.dataTwoList[listTwoIdx]) + str(newIncrementStr)
            return result
        if (self.initMethod == FIELD_INIT_IS_COUNTER):
            result = self.dataInitialValue + count
            if (not self.dataMaximumValue):
                return str(result)
            moduloValue = self.dataMaximumValue - self.dataMinimumValue + 1
            moduloResult = count % moduloValue
            result = self.dataInitialValue + moduloResult
            if (result > self.dataMaximumValue):
                result -= self.dataMaximumValue
            return str(result)
        if (self.initMethod == FIELD_INIT_IS_FROM_FILE):
            if (self.dataFile is None):
                self.dataFile = open(self.dataFileName, 'r')
            # read next record from the file
            dataLine = self.dataFile.readline()
            # Check if we need to wrap around
            if (dataLine == ''):
                self.dataFile.seek(0, 0)
                dataLine = self.dataFile.readline()
            # get rid of the newline
            dataLine = dataLine.rstrip('\n')
            return str(dataLine)
        if (self.initMethod == FIELD_INIT_IS_CALCULATED):
            # This method uses the dataOneList list.
            #
            if (self.dataOneListLen == 0):
                return None
            for element in self.dataOneList:
                elementList = None
                if (isinstance(element, list)):
                    elementList = element
                else:
                    elementList = [element]
                for line in elementList:
                    # pylint: disable=W0122
                    exec(line, self.dataDict)
                    if (mdcDebug):
                        printDebugMsg('IS_CALCULATED: completed exec of: ' + str(line))
            #
            if (mdcDebug):
                printDebugMsg('IS_CALCULATED: dictionary variables are:')
                for (key, value) in list(self.dataDict.items()):
                    if (key == '__builtins__'):
                        continue
                    printDebugMsg('IS_CALCULATED: key=' + str(key) + ', value=' + str(value))
            result = str(self.dataDict[self.fieldName])
            return result
        raise ValueError('Invalid initMethod (' + str(self.initMethod) + ') detected in createValue()')
    #
    #===================================================================================================================
    # FieldInitDescriptor
    def printIt(self, indentStr=''):
        ''' This function will print the object's member variables.

        The parameters are:

        indentStr - this contains a string that is printed before the object's
                    member variables are printed.
        '''
        print(self.printStr(indentStr))
    #
    #===================================================================================================================
    # FieldInitDescriptor
    def printStr(self, indentStr='', indentFirstLine=True):
        ''' This function will return a string containing the object's member
            variables in human-readable form.

        The parameters are:

        indentStr - this contains a string that is added to the string before
                    the object's member variables are added.

        indentFirstLine - this indicates if the first line should be indented or not.

        returns   - a string containing the object's member
                    variables in human-readable form.
        '''
        retStr = ''
        if (indentFirstLine):
            retStr += indentStr
        retStr += 'FieldInitDescriptor: fieldName=' + str(self.fieldName) + ', initMethod='
        if (self.initMethod == FIELD_INIT_IS_ONE_LIST):
            retStr += 'one_list' + \
                ', dataOneList=' + str(self.dataOneList)
        elif (self.initMethod == FIELD_INIT_IS_TWO_LISTS_AND_INCREMENT):
            retStr += 'two_lists_and_increment' + \
                ', dataOneList=' + str(self.dataOneList) + \
                ', dataTwoList=' + str(self.dataTwoList) + \
                ', dataStartingValue=' + str(self.dataStartingValue)
        elif (self.initMethod == FIELD_INIT_IS_COUNTER):
            retStr += 'counter' + \
                ', dataInitialValue=' + str(self.dataInitialValue) + \
                ', dataMinimumValue=' + str(self.dataMinimumValue) + \
                ', dataMaximumValue=' + str(self.dataMaximumValue)
        elif (self.initMethod == FIELD_INIT_IS_FROM_FILE):
            retStr += 'from_file' + \
                ', dataFileName=' + str(self.dataFileName)
        elif (self.initMethod == FIELD_INIT_IS_CALCULATED):
            retStr += 'calculated' + \
                ', dataOneList=' + str(self.dataOneList) + \
                ', dataDict=['
            for (key, value) in list(self.dataDict.items()):
                if (key == '__builtins__'):
                    continue
                retStr += str(key) + ': ' + str(value) + ','
            retStr += ']'
        else:
            retStr += 'none'
        #
        return retStr
    #
    #===================================================================================================================
    # FieldInitDescriptor
    def update(
            self,
            initMethod=FIELD_INIT_IS_NONE,
            dataOneList=None,
            dataTwoList=None,
            dataStartingValue=None,
            dataInitialValue=0,
            dataMinimumValue=None,
            dataMaximumValue=None,
            dataFileName=None,
            dataDict=None):
        ''' This function will update this object with new values.

        The parameters are:

        initMethod - this indicates the method to call to initialize this field.
                    This value is an integer. The possible values are:
                        0 (FIELD_INIT_IS_NONE) - None.
                        1 (FIELD_INIT_IS_ONE_LIST) - one list (dataOneList) is
                            used in a round-robin manner.
                        2 (FIELD_INIT_IS_TWO_LISTS_AND_INCREMENT) - two lists
                            (dataOneList and dataTwoList) are used.
                        3 (FIELD_INIT_IS_COUNTER) - an initial value with a
                            maximum and minumum value.
                        4 (FIELD_INIT_IS_FROM_FILE) - a file contains one
                            record for each value.
                        5 (FIELD_INIT_IS_CALCULATED) - dataOneList contains a
                            list of Python syntax to use to create each value.

        dataOneList - if initMethod == 1, then this is a list that contains
                    the string values the initMethod uses to initialize this
                    field. If initMethod == 5, then this is a list that contains
                    a list of Python syntax to use to create each value.

        dataTwoList - this is a list that contains the values the initMethod
                    uses to initialize this field.

        dataStartingValue - this is a string value that contains the starting
                    value to use by the initMethod when initializing this field.

        dataInitialValue - this is the initial value of a counter. This is a
                    number.

        dataMinimumValue - this is the minimum value of a counter. This is a
                    number or None. NOTE: None is treated as 0.

        dataMaximumValue - this is the maximum value of a counter. This is a
                    number or None.

        dataFileName - this is the name of the file to read to get the values
                    from.

        dataDict - this is the dictionary of variables that is used when
                    using the FIELD_INIT_IS_CALCULATED method. If this
                    dictionary does not have a element in it with the key
                    of the fieldName, then it will be added with a value
                    of None.
        '''
        self.initMethod = initMethod
        self.dataOneList = dataOneList
        if (self.dataOneList is not None):
            if (not isinstance(dataOneList, list)):
                raise ValueError('data_container.py: Invalid dataOneList. It must be a list and not a ' +
                    str(type(dataOneList)) + '. dataOneList=' + str(dataOneList))
            self.dataOneListLen = len(self.dataOneList)
        self.dataTwoList = dataTwoList
        if (self.dataTwoList is not None):
            if (not isinstance(dataTwoList, list)):
                raise ValueError('data_container.py: Invalid dataTwoList. It must be a list and not a ' +
                    str(type(dataTwoList)) + '. dataTwoList=' + str(dataTwoList))
            self.dataTwoListLen = len(self.dataTwoList)
        self.dataStartingValue = dataStartingValue
        if (self.dataStartingValue is not None):
            self.dataStartingValueLen = len(self.dataStartingValue)
        self.dataInitialValue = dataInitialValue
        self.dataMinimumValue = dataMinimumValue
        if (dataMinimumValue is None):
            self.dataMinimumValue = 0
        self.dataMaximumValue = dataMaximumValue
        if (self.dataFile):
            self.dataFile.close()
            self.dataFile = None
        self.dataFileName = dataFileName
        self.dataDict = dataDict
        # Validate the variables
        if (initMethod not in ALL_FIELD_INIT_TYPES):
            raise ValueError('Invalid initMethod (' + str(initMethod) + ')')
        if (self.initMethod == FIELD_INIT_IS_ONE_LIST):
            if (self.dataOneList is None):
                raise ValueError('Missing dataOneList. initMethod (' + str(initMethod) + ')')
        if (self.initMethod == FIELD_INIT_IS_TWO_LISTS_AND_INCREMENT):
            if (self.dataOneList is None):
                raise ValueError('Missing dataOneList. initMethod (' + str(initMethod) + ')')
            if (self.dataTwoList is None):
                raise ValueError('Missing dataTwoList. initMethod (' + str(initMethod) + ')')
        if (self.initMethod == FIELD_INIT_IS_FROM_FILE):
            if (self.dataFileName is None):
                raise ValueError('Missing dataFileName. initMethod (' + str(initMethod) + ')')
            if (self.dataFileName == ''):
                raise ValueError('Missing dataFileName. initMethod (' + str(initMethod) + ')')
        if (self.initMethod == FIELD_INIT_IS_CALCULATED):
            if (self.dataDict is None):
                raise ValueError('Missing dataDict. initMethod (' + str(initMethod) + ')')
            if (self.fieldName not in self.dataDict):
                self.dataDict[self.fieldName] = None
    #
    #===================================================================================================================
#
#=======================================================================================================================
#
class DataContainerFieldDescriptor(object):
    ''' This class contains information about how a DataContainerField should
        be initialized when creating demo data.

    The data members of this class are:

        fieldInitDescriptor - a FieldInitDescriptor instance

        dataContainerField - a DataContainerField instance

        fieldKey   - this is the field key for this field. This must be set
                    externally since we don't know the container.
    '''
    #
    #===================================================================================================================
    # DataContainerFieldDescriptor
    def __init__(
            self,
            name,
            dataType,
            maxSize=0,
            sequenceType=FIELD_IS_SIMPLE,
            structId='',
            createdSchemaVersion=1,
            deletedSchemaVersion=0,
            initMethod=FIELD_INIT_IS_NONE,
            dataOneList=None,
            dataTwoList=None,
            dataStartingValue=None,
            dataInitialValue=0,
            dataMinimumValue=None,
            dataMaximumValue=None,
            dataFileName=None,
            dataDict=None):
        self.fieldKey = None
        # Check the params:
        if (initMethod not in ALL_FIELD_INIT_TYPES):
            raise ValueError('Invalid initMethod (' + str(initMethod) + ')')
        self.dataContainerField = DataContainerField(name, dataType, maxSize=maxSize,
            sequenceType=sequenceType, structId=structId, valueIdx=None,
            createdSchemaVersion=createdSchemaVersion,
            deletedSchemaVersion=deletedSchemaVersion)
        self.fieldInitDescriptor = FieldInitDescriptor(name, initMethod, dataOneList,
            dataTwoList, dataStartingValue, dataInitialValue, dataMinimumValue,
            dataMaximumValue, dataFileName, dataDict)
    #
    #===================================================================================================================
    # DataContainerFieldDescriptor
    def __str__(self):
        return self.printStr('')
    #
    #===================================================================================================================
    # DataContainerFieldDescriptor
    def convertValue(self, value, mdcDescIndex=None):
        return self.dataContainerField.convertValue(value, mdcDescIndex)
    #
    #===================================================================================================================
    # DataContainerFieldDescriptor
    def createValue(self, count):
        ''' This function creates and returns a value based upon the initMethod.

        The parameters are:

        count -     this is used to determine which value to select from the
                    values in the data*lists. This is a numeric type.

        returns   - the value to use for this field. The value returned is
                    a string, a list or None.
        '''
        # This function creates and returns a value based upon the initMethod.
        # The 'count' parameter is used to determine which value
        # to select from the values in the data*lists.
        # The value returned is always a string.
        #
        result = self.fieldInitDescriptor.createValue(count)
        if (self.isSimple()):
            return result
        #
        if (result is None):
            return None
        if (isinstance(result, list)):
            return result
        return [result]
    #
    #===================================================================================================================
    # DataContainerFieldDescriptor
    def formatValue(self,
            value,
            printFormat,
            indentStr='',
            onlyPresentFields=False):
        return self.dataContainerField.formatValue(
            value,
            printFormat,
            indentStr,
            onlyPresentFields)
    #
    #===================================================================================================================
    # DataContainerFieldDescriptor
    def getDataContainerField(self):
        ''' This function will return the object's DataContainerField member.
        '''
        return self.dataContainerField
    #
    #===================================================================================================================
    # DataContainerFieldDescriptor
    def getDataTypeStr(self):
        return self.dataContainerField.getDataTypeStr()
    #
    #===================================================================================================================
    # DataContainerFieldDescriptor
    def getFieldInitDescriptor(self):
        ''' This function will return the object's FieldInitDescriptor member.
        '''
        return self.fieldInitDescriptor
    #
    #===================================================================================================================
    # DataContainerFieldDescriptor
    def isArray(self):
        return self.dataContainerField.isArray()
    #
    #===================================================================================================================
    # DataContainerFieldDescriptor
    def isAStruct(self):
        return self.dataContainerField.isAStruct()
    #
    #===================================================================================================================
    # DataContainerFieldDescriptor
    def isList(self):
        return self.dataContainerField
    #
    #===================================================================================================================
    # DataContainerFieldDescriptor
    def isSimple(self):
        return self.dataContainerField.isSimple()
    #
    #===================================================================================================================
    # DataContainerFieldDescriptor
    def printIt(self, indentStr=''):
        ''' This function will print the object's member variables.

        The parameters are:

        indentStr - this contains a string that is printed before the object's
                    member variables are printed.
        '''
        print(self.printStr(indentStr))
    #
    #===================================================================================================================
    # DataContainerFieldDescriptor
    def printStr(self, indentStr='', indentFirstLine=True):
        ''' This function will return a string containing the object's member
            variables in human-readable form.

        The parameters are:

        indentStr - this contains a string that is added to the string before
                    the object's member variables are added.

        indentFirstLine - this indicates if the first line should be indented or not.

        returns   - a string containing the object's member
                    variables in human-readable form.
        '''
        retStr = ''
        if (indentFirstLine):
            retStr += indentStr
        retStr += 'DataContainerFieldDescriptor: ' + self.dataContainerField.printStr('') + ':' + \
            self.fieldInitDescriptor.printStr('') + ', fieldKey=' + str(self.fieldKey)
        return retStr
    #
    #===================================================================================================================
    # DataContainerFieldDescriptor
    def update(self, initMethod=FIELD_INIT_IS_NONE, dataOneList=None,
            dataTwoList=None, dataStartingValue=None,
            dataInitialValue=0, dataMinimumValue=None, dataMaximumValue=None,
            dataFileName=None, dataDict=None):
        ''' This function will update this object with new values.

        The parameters are:

        initMethod - this indicates the method to call to initialize this field.
                    This value is an integer. The possible values are:
                        0 (FIELD_INIT_IS_NONE) - None.
                        1 (FIELD_INIT_IS_ONE_LIST) - one list (dataOneList) is
                            used in a round-robin manner.
                        2 (FIELD_INIT_IS_TWO_LISTS_AND_INCREMENT) - two lists
                            (dataOneList and dataTwoList) are used.
                        3 (FIELD_INIT_IS_COUNTER) - an initial value with a
                            maximum and minumum value.
                        4 (FIELD_INIT_IS_FROM_FILE) - a file contains one
                            record for each value.
                        5 (FIELD_INIT_IS_CALCULATED) - dataOneList contains a
                            list of Python syntax to use to create each value.

        dataOneList - if initMethod == 1, then this is a list that contains
                    the string values the initMethod uses to initialize this
                    field. If initMethod == 5, then this is a list that contains
                    a list of Python syntax to use to create each value.

        dataTwoList - this is a list that contains the string values the
                    initMethod uses to initialize this field.

        dataStartingValue - this is a string value that contains the starting
                    value to use by the initMethod when initializing this field.

        dataInitialValue - this is the initial value of a counter. This is a number.

        dataMinimumValue - this is the minimum value of a counter. This is a
                    number or None. NOTE: None is treated as 0.

        dataMaximumValue - this is the maximum value of a counter. This is a
                    number or None.

        dataFileName - this is the name of the file to read to get the values from.

        dataDict - this is the dictionary of variables that is used when
                    using the FIELD_INIT_IS_CALCULATED method. If this
                    dictionary does not have a element in it with the key
                    of the fieldName, then it will be added with a value
                    of None.
        '''
        self.fieldInitDescriptor.update(initMethod, dataOneList, dataTwoList,
            dataStartingValue, dataInitialValue, dataMinimumValue,
            dataMaximumValue, dataFileName, dataDict)
    #
    #===================================================================================================================
#
#=======================================================================================================================
#
class DataContainerClientConnection(object):
    ''' This class represents a synchronous client connection into the system
        that uses data containers to communicate to the server.

    The data members of this class are:

        sendFormatType- this string indicates the data container format that is
                    used in sending to the server. The possible values are:
                        'COMPACT' - The compact data container format.
                        'XML' - The XML data container format.

        recvFormatType- this string indicates the data container format that is
                    received from the server. The possible values are:
                        'COMPACT' - The compact data container format.
                        'XML' - The XML data container format.

        hostName  - this string indicates the host name to use when connecting
                    to the system. If this is None, then 'localhost' is used.

        hostPort  - this integer indicates the host port to use when connecting
                    to the system. If this is None, then the appropriate
                    default value is used.

        socketObj - this is the socket this object is using. This is created by
                    this class and may be access by the caller.

        socketObjToUse - this is only valid after open() is called.
                    If sslContextObj is None, this will be socketObj
                    otherwise it will be sslSocketObj.

        sslContextObj - this is the SSLContext object for this object. This is
                    created by the caller and may be None. One way to create
                    this is to call ssl_functions.createSslContext().

        sslSocketObj - this is the SSLSocket object for this object. This is
                    created by this class and may be access by the caller. This
                    may be None.

        traceMessages - this boolean indicates if the messages sent and received
                    should be traced.
    '''
    #
    #===================================================================================================================
    # DataContainerClientConnection
    def __init__(
            self,
            sendFormatType,
            recvFormatType=None,
            hostName=None,
            hostPort=None,
            traceMessages=False,
            sslContextObj=None):
        ''' This function will create this object with the passed values.

        The parameters are:

        sendFormatType- this string indicates the data container format that is
                    used in sending to the server. The possible values are:
                        'COMPACT' - The compact data container format.
                        'XML' - The XML data container format.
                        'RAW' - The raw data container format.

        recvFormatType- this string indicates the data container format that is
                    received from the server. The possible values are:
                        'COMPACT' - The compact data container format.
                        'XML' - The XML data container format.
                        'RAW' - The raw data container format.
                        None - Use the sendFormatType.

        hostName  - this string indicates the host name to use when connecting
                    to the system. If this is None, then the environment is
                    checked and if this is running on a valid LogicalBlade, its
                    compactMdcAddress is used. If this is not running on a valid
                    LogicalBlade, the first valid LogicalBlade will be used.
                    If no MTX environment variables are found, then 'localhost'
                    is used.

        hostPort  - this integer indicates the host port to use when connecting
                    to the system. If this is None, then the appropriate
                    default value is used.
                    NOTE: This parameter is ignored if hostName is None and
                    a valid LogicalBlade is found. In this case the LogicalBlade's
                    compactMdcAddress value is used.

        traceMessages - this boolean indicates if the messages sent and received
                    should be traced.

        sslContextObj - this is the SSLContext object to use. This may
                    be None. One way to create this is to call
                    ssl_functions.createSslContext().
        '''
        self.sendFormatType = sendFormatType
        self.recvFormatType = recvFormatType
        self.hostName = ''
        self.hostPort = None
        self.socketObj = None
        self.socketObjToUse = None
        self.traceMessages = traceMessages
        self.sslContextObj = sslContextObj
        self.sslSocketObj = None
        # Check the params:
        if (sendFormatType not in ALL_CLIENT_FORMAT_TYPES):
            raise ValueError('Invalid sendFormatType (' + str(sendFormatType) + ')')
        if (recvFormatType is None):
            recvFormatType = sendFormatType
        if (recvFormatType not in ALL_CLIENT_FORMAT_TYPES):
            raise ValueError('Invalid recvFormatType (' + str(recvFormatType) + ')')
        if (hostName is None):
            # Are any MTX_ environment variables present?
            binDir = os.path.expandvars(os.getenv('MTX_BIN_DIR', ''))
            if (binDir == ''):
                # No MTX_ environment variables are present
                self.hostName = 'localhost'
            else:
                import topology
                logicalBlade = topology.getLogicalBlade()
                # Is this a valid LogicalBlade?
                if (logicalBlade is None):
                    # Unknown LogicalBlade. Find first LogicalBlade
                    logicalBladeIdList = sorted(topology.kLogicalBladeFqIdToObjectDictionary.keys())
                    if (len(logicalBladeIdList) == 0):
                        # Give up and just use localhost
                        self.hostName = 'localhost'
                    else:
                        logicalBlade = topology.kLogicalBladeFqIdToObjectDictionary[logicalBladeIdList[0]]
                        if (logicalBlade is None):
                            # Give up and just use localhost
                            self.hostName = 'localhost'
                if (logicalBlade is not None):
                    # Now get the LogicalBlade's compact MDC address.
                    compactMdcAddressAndPort = logicalBlade.compactMdcAddress
                    addressPartList = compactMdcAddressAndPort.split(':')
                    if (len(addressPartList) < 2):
                        self.hostName = compactMdcAddressAndPort
                    else:
                        try:
                            self.hostPort = int(addressPartList[-1])
                            # Must be valid. Remove it from the list
                            addressPartList.pop()
                            self.hostName = ':'.join(addressPartList)
                            # Set hostPort so that we override it in this case.
                            hostPort = self.hostPort
                            # Fall through
                        except:
                            raise TypeError('Invalid port number in the LogicalBlade\'s compactMdcAddress. Found: ' + \
                                compactMdcAddressAndPort)
                        #
                    #
                #
            #
        else:
            self.hostName = hostName
        if (hostPort is None):
            if (sendFormatType == 'XML'):
                self.hostPort = 4040
            else:
                # sendFormatType = Compact
                if (recvFormatType == 'XML'):
                    self.hostPort = 4050
                else:
                    self.hostPort = 4060
        else:
            self.hostPort = hostPort
    #
    #===================================================================================================================
    # DataContainerClientConnection
    def close(self):
        ''' This function will close the connection to the server.
        '''
        if (self.sslSocketObj is not None):
            self.sslSocketObj.close()
            self.sslSocketObj = None
        if (self.socketObj is not None):
            if (self.traceMessages):
                print(kScriptName + ': DataContainerClientConnection:close: Connection to ' + self.hostName + ':' + \
                    str(self.hostPort) + '. Closing connection.')
            self.socketObj.close()
            self.socketObj = None
        self.socketObjToUse = None
    #
    #===================================================================================================================
    # DataContainerClientConnection
    def open(self, noSchemaVersionExchange=False):
        ''' This function will open the connection to the server.
        '''
        global kScriptName
        global THE_MDC_DESCRIPTOR_INDEX
        #
        # Check to see if it is already opened.
        if (self.socketObj is not None):
            self.close()
        family = socket.AF_INET
        if (self.hostName.count(':') > 0):
            family = socket.AF_INET6
        self.socketObj = socket.socket(family, socket.SOCK_STREAM)
        self.socketObj.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        # Set linger on and the time to 1 second so the socket will be
        # closed as soon as possible without losing data.
        self.socketObj.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack('ii', 1, 1))
        self.socketObjToUse = self.socketObj
        messageSubStr = ''
        if (self.sslContextObj is not None):
            messageSubStr = 'secure '
            self.sslSocketObj = self.sslContextObj.wrap_socket(self.socketObj)
            self.socketObjToUse = self.sslSocketObj
        try:
            self.socketObjToUse.connect((self.hostName, self.hostPort))
        except Exception as exception:
            sys.stderr.write(os.path.basename(__file__) + ': Error: DataContainerClientConnection:open(): ' + \
                messageSubStr + 'connect(hostName=' + str(self.hostName) + ', hostPort=' + str(self.hostPort) + \
                ') detected the error: ' + str(exception) + '\n')
            raise
        if (self.traceMessages):
            print(kScriptName + ': DataContainerClientConnection:open: Connection to ' + self.hostName + ':' + \
                str(self.hostPort) + '. Connection opened.')
        if (noSchemaVersionExchange):
            print(kScriptName + ': DataContainerClientConnection:open: NOT SENDING MtxSchemaVersionExchangeMsg.')
            return
        #
        # Send an MtxSchemaVersionExchangeMsg request.
        #
        # We need the definition of this MDC and also the schema version, so need to see if the mtx_config.xml file
        # has already been read. If not, then we need to read it.
        #
        clientSystemSchemaVersion = THE_MDC_DESCRIPTOR_INDEX.systemSchemaVersion
        clientServiceProvSchemaVersion = THE_MDC_DESCRIPTOR_INDEX.servProvSchemaVersion
        if (clientSystemSchemaVersion == 0):
            raise RuntimeError('systemSchemaVersion=0. Check the config file: ' + configFileName)
        # mdcStr = '<1,0,0,373,4300,1>'
        #mdcStr = '<1,2,2,373,4300,1>[5000,1]<1,5,0,411,4300,1>[]<1,14,0,93,4300,1>[,28]'
        mdcStr = '<1,2,2,373,4300,1>[' + str(clientSystemSchemaVersion) + ',' + \
            str(clientServiceProvSchemaVersion) + ']'
        #     # + '<1,5,0,411,4300,1>[]<1,14,0,93,4300,1>[,28]'
        mdcResponse = self.send(mdcStr)
        serverSystemSchemaVersion = mdcResponse.getUsingName('SysSchemaVersion')
        serverServiceProvSchemaVersion = mdcResponse.getUsingName('ServiceProviderSchemaVersion')
        if (self.traceMessages):
            print(kScriptName + ': DataContainerClientConnection:open: Connection to ' + self.hostName + ':' + \
                str(self.hostPort) + '. Local (client) schema version is (' + str(clientSystemSchemaVersion) + ',' +  \
                str(clientServiceProvSchemaVersion) + '). Remote (server) schema version is (' + \
                str(serverSystemSchemaVersion) + ',' + str(serverServiceProvSchemaVersion) + ').')
    #
    #===================================================================================================================
    # DataContainerClientConnection
    def recvOnly(self):
        ''' This function will receive a packet.

        returns   - a DataContainer.
        '''
        global kScriptName
        if (self.socketObjToUse is None or self.socketObj is None):
            raise RuntimeError('DataContainerClientConnection::recvOnly(): Socket is closed')
        returnedMdc = recvOnly(self.socketObjToUse, self.recvFormatType, traceMessages=False)
        if (self.traceMessages):
            print(kScriptName + ': DataContainerClientConnection:recvOnly: Connection to ' + self.hostName + ':' + \
                str(self.hostPort) + '. Received\n' + returnedMdc.printStr())
        return returnedMdc
    #
    #===================================================================================================================
    # DataContainerClientConnection
    def send(self, mdc):
        ''' This function will send the passed mdc and return the response mdc.

        The parameters are:

        mdc       - this is the data container to send. It can be either a
                    DataContainer or a string (either in compact form or
                    in XML form).

        returns   - a DataContainer response to the message sent.
        '''
        self.sendOnly(mdc)
        return self.recvOnly()
    #
    #===================================================================================================================
    # DataContainerClientConnection
    def sendOnly(self, mdc):
        ''' This function will send the passed mdc.

        The parameters are:

        mdc       - this is the data container to send. It can be either a
                    DataContainer or a string (either in compact form or
                    in XML form).
        '''
        global kScriptName
        #
        if (self.socketObj is None):
            raise RuntimeError('DataContainerClientConnection::sendOnly(): Socket is closed')
        sendData = sendOnly(self.socketObjToUse, mdc, self.sendFormatType, traceMessages=False)
        if (self.traceMessages):
            print(kScriptName + ': DataContainerClientConnection:sendOnly: Connection to ' + self.hostName + ':' + \
                str(self.hostPort) + '. Sending (len=' + str(len(sendData) + 4) + ')\n' + \
                sendData.decode('ascii', 'ignore'))
    #
    #===================================================================================================================
#
#=======================================================================================================================
#
class DataContainerFileReader(object):
    ''' This class encapsulates the logic to read a series of MDC's from a data file.
    '''
    #
    #===================================================================================================================
    # DataContainerFileReader
    def __init__(
            self,
            fileHandle,
            mdcFormat=None,
            hexInput=False):
        ''' Initialize an instance of the DataContainerFileReader.

        The parameters are:

        fileHandle - the file to be read from. Must be opened by client and
            support standard Python file reading operations.

        mdcFormat - the expected format of the file. One of:
                        None - Reader will attempt to determine format.
                        'COMPACT' - Compact MDC
                        'COMPRESSED' - Compressed Compact MDC
                        'ELEMENT_XML' - Element XML MDC format
                        'XML' - Standard XML MDC format

        hexInput - this indicates if the file contains the ASCII characters that
            represent the hex value of the data_container. This could be a compact
            or xml format, so this needs to also be specified.
        '''
        self.fileHandle = fileHandle
        self.isCompressed = False
        self.isHexInput = hexInput
        self.isXml = False
        self.mdcFormat = None

        if (mdcFormat is not None):
            if mdcFormat == 'XML' or mdcFormat == 'ELEMENT_XML':
                self.isXml = True
            elif mdcFormat == 'COMPACT':
                self.isCompressed = False
            elif mdcFormat == 'COMPRESSED':
                self.isCompressed = True
            else:
                raise RuntimeError('Illegal value for file format')

            self.mdcFormat = mdcFormat

        return

    #
    #===================================================================================================================
    # DataContainerFileReader
    def readNext(self):
        ''' Read the next MDC from the file.

        Returns the MDC read or None on End of File
        Throws exception on error
        '''
        #
        tagDepth = 0
        startTag = None
        endTag = None
        xmlBody = ''
        inComment = False

        for line in self.fileHandle:
            if isinstance(line, bytes):
                line = line.decode('ascii', 'ignore')
            if (line == ''):
                continue
            if (line[0] == '#'):                    # This is faster than startswith('#')
                continue
            if (self.isHexInput):
                origLine = line
                origLine = origLine.rstrip('\n')
                # We expect this data to be in human readable hex, so
                # we need to convert it to binary.
                try:
                    line = binascii.unhexlify(origLine)
                # pylint: disable=W0703
                except Exception as exception:
                    printErrorMsg('caught an exception while calling binascii.unhexlify. (2).' + \
                        '\n    The exception: ' + str(exception) + \
                        '\n    The input line:' + str(origLine))
                    raise
            if (inComment or line[0:4] == '<!--'):  # This is faster than startswith('<!--')
                line = line.rstrip('\n')
                if (line[-3:] == '-->'):            # This is faster than endswith('-->')
                    inComment = False
                else:
                    inComment = True
                continue

            # Do we already know the file format?
            if (self.mdcFormat is None):
                line = line.rstrip('\n')
                self.isCompressed = True
                if (line == ''):
                    continue
                if (line[0:5] == '<?xml'):          # This is faster than startswith('<?xml')
                    self.isXml = True
                    self.isCompressed = False
                    continue
                if (line.startswith('<container ')):
                    self.mdcFormat = 'XML'
                    self.isXml = True
                    self.isCompressed = False
                # May be compact OR element XML
                elif (line[0] == '<'):              # This is faster than startswith('<')
                    # Compact MDC always has a numeric version value as the first
                    # element. Due to naming, element XML can not start with a number.
                    if (line[1].isdigit()):
                        self.mdcFormat = 'COMPACT'
                        self.isXml = False
                        self.isCompressed = False
                    else:
                        self.mdcFormat = 'ELEMENT_XML'
                        self.isXml = True
                        self.isCompressed = False
                else:
                    raise RuntimeError('Unable to determine MDC serialization format: line=' + line)

            # We now know the file format
            if (self.isXml):
                if (tagDepth == 0):
                    if (self.mdcFormat == 'XML'):
                        # XML
                        if (line.startswith('<container ')):
                            xmlBody += line
                            startTag = '<container '
                            endTag = '</container>'
                            tagDepth += 1
                        else:
                            continue
                    else:
                        # ELEMENT XML
                        if (line[0] == '<'):              # This is faster than startswith('<')
                            xmlBody += line
                            startTag = line.split('>')[0] + '>'
                            endTag = startTag.replace('<', '</')
                            tagDepth += 1
                        else:
                            continue
                else:
                    # We've got the start tag. Now looking for the matching end tag
                    xmlBody += line
                    if (line.startswith(startTag)):
                        tagDepth += 1
                    elif (line.startswith(endTag)):
                        tagDepth -= 1
                    if (tagDepth == 0):
                        if (self.mdcFormat == 'XML'):
                            # PARSE XML
                            mdc = readFromXMLStr(xmlBody)
                            if (mdc is None):
                                raise RuntimeError('Error deserializing MDC. Input: ' + xmlBody)
                            return mdc
                        else:
                            # PARSE ELEMENT XML
                            mdc = readFromElementBasedXMLStr(xmlBody)
                            if (mdc is None):
                                raise RuntimeError('Error deserializing MDC. Input: ' + xmlBody)
                            return mdc
                        #
                    #
                #
            else:
                # Default to compact
                if (not self.isCompressed):
                    # PARSE COMPACT
                    line = line.rstrip('\n')
                    if (line == ''):
                        continue
                    mdc = readFromStr(line)
                    if (mdc is None):
                        raise RuntimeError('Error deserializing a compact MDC. Input: ' + line)
                    return mdc
                else:
                    # is compressed
                    line = line.rstrip('\n')
                    if (line == ''):
                        continue
                    # We expect this data to be in human readable hex, so
                    # we need to convert it to binary.
                    try:
                        binaryLine = binascii.unhexlify(line)
                    # pylint: disable=W0703
                    except Exception as exception:
                        printErrorMsg('caught an exception while calling binascii.unhexlify.' + \
                            '\n    The exception: ' + str(exception) + \
                            '\n    The input line:' + str(line))
                        raise
                    decompressedLine = zlib.decompress(binaryLine)
                    mdc = readFromStr(decompressedLine)
                    if (mdc is None):
                        raise RuntimeError('Error deserializing a compressed MDC. Input:' +
                            line + '\n    decompressed line:' + decompressedLine)
                    return mdc
                #
            #
        # end of for line in self.fileHandle:
    #
    #===================================================================================================================
#
#=======================================================================================================================
#
class DataContainerServerConnection(object):
    ''' This class represents a basic server socket connection using the
        DataContainer protocol.

    The data members of this class are:

        listenerIpAddress  - this string indicates the listener's host name or
                    IP address.

        listenerPort  - this integer indicates the listener's port.

        listenerSocketObj - this is the socket this object is using. This is created by
                    this class and may be access by the caller.

        listenerSocketObjToUse - this is only valid after open() is called.
                    If sslContextObj is None, this will be listenerSocketObj
                    otherwise it will be listenerSslSocketObj.

        listenerSslSocketObj - this is the SSLSocket object for this object. This is
                    created by this class and may be access by the caller. This
                    may be None.

        openSocketObjList - this is a list of open connected sockets associated
                    with this listener.

        recvFormatType- this string indicates the data container format that is
                    received from the client. The possible values are:
                        'COMPACT' - The compact data container format.
                        'XML' - The XML data container format.

        sendFormatType- this string indicates the data container format that is
                    used in sending to the client. The possible values are:
                        'COMPACT' - The compact data container format.
                        'XML' - The XML data container format.

        sslContextObj - this is the SSLContext object for this object. This is
                    created by the caller and may be None. One way to create
                    this is to call ssl_functions.createSslContext().

        traceMessages - this is a flag that if True will cause the packets
                    sent and received to be printed.
    '''
    #
    #===================================================================================================================
    # DataContainerServerConnection
    def __init__(
            self,
            sendFormatType,
            recvFormatType=None,
            listenerIpAddress=None,
            listenerPort=None,
            traceMessages=False,
            sslContextObj=None):
        ''' This function will create this object with the passed values.

        The parameters are:

        sendFormatType- this string indicates the data container format that is
                    used in sending to the client. The possible values are:
                        'COMPACT' - The compact data container format.
                        'XML' - The XML data container format.
                        'RAW' - The raw data container format.

        recvFormatType- this string indicates the data container format that is
                    received from the client. The possible values are:
                        'COMPACT' - The compact data container format.
                        'XML' - The XML data container format.
                        'RAW' - The raw data container format.
                        None - Use the sendFormatType.

        listenerIpAddress  - this string indicates the host name to use when connecting
                    to the system. If this is None, then the LogicalBlade's
                    DataContainer Gateway's IP address is used. If a matching
                    LogicalBlade is not found, then 'localhost' is used.

        listenerPort  - this integer indicates the host port to use when connecting
                    to the system. If this is None, then the LogicalBlade's
                    MDC Gateway's port is used. If a matching LogicalBlade
                    is not found, then 4003 is used.

        traceMessages - this is a flag that if True will cause the packets
                    sent and received to be printed. The default is False.

        sslContextObj - this is the SSLContext object to use. This may be None.
                    One way to create this is to call ssl_functions.createSslContext().
        '''
        self.sendFormatType = sendFormatType
        self.recvFormatType = recvFormatType
        self.listenerSocketObj = None
        self.listenerSocketObjToUse = None
        self.listenerSslSocketObj = None
        self.openSocketObjList = []
        self.traceMessages = traceMessages
        self.sslContextObj = sslContextObj
        # Check the params:
        if (sendFormatType not in ALL_CLIENT_FORMAT_TYPES):
            raise ValueError('Invalid sendFormatType (' + str(sendFormatType) + ')')
        if (recvFormatType is None):
            recvFormatType = sendFormatType
        if (recvFormatType not in ALL_CLIENT_FORMAT_TYPES):
            raise ValueError('Invalid recvFormatType (' + str(recvFormatType) + ')')
        if (listenerIpAddress is None):
            # Are any MTX_ environment variables present?
            binDir = os.path.expandvars(os.getenv('MTX_BIN_DIR', ''))
            if (binDir == ''):
                # No MTX_ environment variables are present
                self.listenerIpAddress = 'localhost'
            else:
                import topology
                logicalBlade = topology.getLogicalBlade()
                # Is this a valid LogicalBlade?
                if (logicalBlade is None):
                    # Unknown LogicalBlade. Find first LogicalBlade
                    logicalBladeIdList = sorted(topology.kLogicalBladeFqIdToObjectDictionary.keys())
                    if (len(logicalBladeIdList) == 0):
                        # Give up and just use localhost
                        self.listenerIpAddress = 'localhost'
                    else:
                        logicalBlade = topology.kLogicalBladeFqIdToObjectDictionary[logicalBladeIdList[0]]
                        if (logicalBlade is None):
                            # Give up and just use localhost
                            self.listenerIpAddress = 'localhost'
                if (logicalBlade is not None):
                    # Now get the LogicalBlade's compact MDC address.
                    compactMdcAddressAndPort = logicalBlade.compactMdcAddress
                    addressPartList = compactMdcAddressAndPort.split(':')
                    if (len(addressPartList) < 2):
                        self.listenerIpAddress = compactMdcAddressAndPort
                    else:
                        try:
                            self.listenerPort = int(addressPartList[-1])
                            # Must be valid. Remove it from the list
                            addressPartList.pop()
                            self.listenerIpAddress = ':'.join(addressPartList)
                            # Set listenerPort so that we override it in this case.
                            listenerPort = self.listenerPort
                            # Fall through
                        except:
                            raise TypeError('Invalid port number in the LogicalBlade\'s compactMdcAddress. Found: ' + \
                                compactMdcAddressAndPort)
                        #
                    #
                #
            #
        else:
            self.listenerIpAddress = listenerIpAddress
        if (listenerPort is None):
            if (sendFormatType == 'XML'):
                self.listenerPort = 4040
            else:
                # sendFormatType = Compact
                if (recvFormatType == 'XML'):
                    self.listenerPort = 4050
                else:
                    self.listenerPort = 4060
        else:
            self.listenerPort = listenerPort
        #
    #
    #===================================================================================================================
    # DataContainerServerConnection
    def accept(self):
        ''' This function will accept a new client connection to the server.

        returns   - a tuple that consists of the accepted socket object and its
                    remote IP address as a string.
        '''
        (serverSocketObj, remoteAddress) = self.listenerSocketObjToUse.accept()
        self.openSocketObjList.append(serverSocketObj)
        return (serverSocketObj, remoteAddress)
    #
    #===================================================================================================================
    # DataContainerServerConnection
    def close(self):
        ''' This function will close the connection to the server. This includes
        all of the open client sockets, the ssl listener socket (if it exists) and
        finally the listener socket.
        '''
        for openSocketObj in self.openSocketObjList:
            openSocketObj.close()
        self.openSocketObjList = []
        if (self.listenerSslSocketObj is not None):
            self.listenerSslSocketObj.close()
            self.listenerSslSocketObj = None
        if (self.listenerSocketObj is not None):
            self.listenerSocketObj.close()
            self.listenerSocketObj = None
        self.listenerSocketObjToUse = None
    #
    #===================================================================================================================
    # DataContainerServerConnection
    def open(self):
        ''' This function will open the listener socket.
        '''
        # Check to see if it is already opened.
        if (self.listenerSocketObj is not None):
            self.close()
        # Clear out anything left over.
        for openSocketObj in self.openSocketObjList:
            openSocketObj.close()
        self.openSocketObjList = []
        #
        # Create a listening socket.
        family = socket.AF_INET
        if (self.listenerIpAddress.count(':') > 0):
            family = socket.AF_INET6
        self.listenerSocketObj = socket.socket(family, socket.SOCK_STREAM)
        self.listenerSocketObj.settimeout(10)
        self.listenerSocketObj.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.listenerSocketObj.bind((self.listenerIpAddress, self.listenerPort))
        # Set linger on and the linger time to 1 second so the socket will be
        # closed as soon as possible without losing data.
        self.listenerSocketObj.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack('ii', 1, 1))
        #
        self.listenerSocketObjToUse = self.listenerSocketObj
        if (self.sslContextObj is not None):
            self.listenerSslSocketObj = self.sslContextObj.wrap_socket(self.listenerSocketObj)
            self.listenerSocketObjToUse = self.listenerSslSocketObj
        #
        # Use backlog value of 5.
        self.listenerSocketObjToUse.listen(5)
    #
    #===================================================================================================================
    # DataContainerServerConnection
    def recvOnly(self, socketObj):
        ''' This function will receive a response packet

        socketObj - This is the socket object to use.

        returns   - a DataContainerPacket response to the message sent.
        '''
        if (socketObj is None):
            raise RuntimeError('DataContainerServerConnection::recvOnly(): socketObj was passed as None.')
        return recvOnly(socketObj, self.recvFormatType, traceMessages=self.traceMessages)
    #
    #===================================================================================================================
    # DataContainerServerConnection
    def send(self, socketObj, mdc):
        ''' This function will send the passed packet and return the response
        packet.

        The parameters are:

        socketObj - This is the socket object to use.

        mdc       - this is the data container to send. It can be either a
                    DataContainer or a string (either in compact form or
                    in XML form).

        returns   - a DataContainerPacket response to the message sent.
        '''
        if (socketObj is None):
            raise RuntimeError('DataContainerServerConnection::send(): socketObj was passed as None.')
        self.sendOnly(socketObj, mdc)
        return self.recvOnly(socketObj)
    #
    #===================================================================================================================
    # DataContainerServerConnection
    def sendOnly(self, socketObj, mdc):
        ''' This function will send the passed MDC.

        The parameters are:

        socketObj - This is the socket object to use.

        mdc       - this is the data container to send. It can be either a
                    DataContainer or a string (either in compact form or
                    in XML form).
        '''
        if (socketObj is None):
            raise RuntimeError('DataContainerServerConnection::sendOnly(): socketObj was passed as None.')
        sendOnly(socketObj, mdc, self.sendFormatType, traceMessages=self.traceMessages)
    #
    #===================================================================================================================
#
#=======================================================================================================================
#
class EnumSubType(object):
    ''' This class represents an enumerated field subtype that has a mapping of strings to integer values.

    The data members of this class are:

        name      - the name of the subType. This is a string value.

        dataType  - the data type of this subType. This is a numeric value and must
                    be one of these allowed values:
                        DATA_TYPE_BLOB,
                        DATA_TYPE_BOOLEAN,
                        DATA_TYPE_BUFFER_ID,
                        DATA_TYPE_DATE,
                        DATA_TYPE_DATETIME,
                        DATA_TYPE_DECIMAL,
                        DATA_TYPE_FIELD_KEY,
                        DATA_TYPE_INT8,
                        DATA_TYPE_INT16,
                        DATA_TYPE_INT32,
                        DATA_TYPE_INT64,
                        DATA_TYPE_INT128,
                        DATA_TYPE_OBJECT_ID,
                        DATA_TYPE_PHONE_NUMBER,
                        DATA_TYPE_STRING,
                        DATA_TYPE_STRUCT,
                        DATA_TYPE_TIME,
                        DATA_TYPE_UINT8,
                        DATA_TYPE_UINT16,
                        DATA_TYPE_UINT32,
                        DATA_TYPE_UINT64,
                        DATA_TYPE_UINT128

        stringToEnumDict  - This is a dictionary that maps a string value to its enumerated integer value. This allows
                            more than one string to map to the same integer.

        enumToStringDict  - This is a dictionary that maps an integer value to a string. This may not be equivalent
                            to stringToEnumDict.
    '''
    #
    #===================================================================================================================
    # EnumSubType
    def __init__(
            self,
            name,
            dataTypeStr,
            stringToEnumTupleList):
        ''' This function will create a new EnumSubType object.

        The parameters are:

        name      - the name of the subType. This is a string value.

        dataTypeStr - this contains a string name of the data type. It must match one of the values in
                    the dataTypeXmlStrToEnumDictionary.

        stringToEnumTupleList - this is list of tuples that maps a string value to its integer enumerated value.
                    You can have multiple string values representing the same integer value. If this happens,
                    then the first one is used when mapping an integer to a string.
        '''
        global dataTypeXmlStrToEnumDictionary
        #
        self.name = name
        if dataTypeStr not in dataTypeXmlStrToEnumDictionary:
            raise ValueError('EnumSubType() error: invalid dataType (' + dataTypeStr +
                '). It must be one of these values: ' + str(list(dataTypeXmlStrToEnumDictionary.keys())))
        self.dataType = dataTypeXmlStrToEnumDictionary[dataTypeStr]
        self.stringToEnumDict = {}
        self.enumToStringDict = {}
        for (enumString, enumInteger) in stringToEnumTupleList:
            # Make sure it is an integer
            enumInteger = int(enumInteger)
            if (enumString in self.stringToEnumDict):
                raise ValueError('EnumSubType() error: duplicate enum string value found (' + enumString + ').')
            self.stringToEnumDict[enumString] = enumInteger
            #
            # Don't check if a value already exists. We want to store the last one as the correct one.
            self.enumToStringDict[enumInteger] = enumString
    #
    #===================================================================================================================
    # EnumSubType
    def __str__(self):
        return self.printStr('')
    #
    #===================================================================================================================
    # EnumSubType
    def getEnumInteger(self, enumString):
        if (enumString not in self.stringToEnumDict):
            return None
        return self.stringToEnumDict[enumString]
    #
    #===================================================================================================================
    # EnumSubType
    def getEnumString(self, enumInteger):
        if (enumInteger not in self.enumToStringDict):
            return None
        return self.enumToStringDict[enumInteger]
    #
    #===================================================================================================================
    # EnumSubType
    def printStr(self, indentStr='', indentFirstLine=True):
        ''' This function will return a string containing the object's member
            variables in human-readable form.

        The parameters are:

        indentStr - this contains a string that is added to the string before
                    the object's member variables are added.

        indentFirstLine - this indicates if the first line should be indented or not.

        returns   - a string containing the object's member variables in human-readable form.
        '''
        global dataTypeEnumToXmlStrDictionary
        #
        retStr = ''
        if (indentFirstLine):
            retStr += indentStr
        retStr += 'EnumSubType:\n'
        retStr += indentStr + '    name=' + self.name + '\n'
        retStr += indentStr + '    dataType=' + dataTypeEnumToXmlStrDictionary[self.dataType] + '\n'
        retStr += indentStr + '    stringToEnumDict=\n'
        for enumString in sorted(self.stringToEnumDict.keys()):
            retStr += indentStr + '        %-42s -> %6d\n' % (enumString, self.stringToEnumDict[enumString])
        retStr += indentStr + '    enumToStringDict=\n'
        for enumInteger in sorted(self.enumToStringDict.keys()):
            retStr += indentStr + '        %6d -> %s\n' % (enumInteger, self.enumToStringDict[enumInteger])
        #
        return retStr
    #
    #===================================================================================================================
#
#=======================================================================================================================
#
class MetaData(object):
    ''' This class represents the data in a metadata tag used when defining a FieldSpec.

    The data members of this class are:

        name      - contains the value in the name tag. This is a string.

        typeStr   - contains the value in the type tag. This is a string.

        value     - contains the value in the value tag. This is a string.
    '''
    #
    #===================================================================================================================
    # MetaData
    def __init__(
            self,
            name,
            typeStr,
            value):
        global dataTypeXmlStrToEnumDictionary
        #
        self.name = name
        self.typeStr = typeStr
        self.value = value
        if typeStr not in dataTypeXmlStrToEnumDictionary:
            raise ValueError('MetaData() error: invalid dataType (' + typeStr +
                '). It must be one of these values: ' + str(list(dataTypeXmlStrToEnumDictionary.keys())))
    #
    #===================================================================================================================
    # MetaData
    def __str__(self):
        return self.printStr('')
    #
    #===================================================================================================================
    # MetaData
    def printStr(self, indentStr='', indentFirstLine=True):
        ''' This function will return a string containing the object's member
            variables in human-readable form.

        The parameters are:

        indentStr - this contains a string that is added to the string before
                    the object's member variables are added.

        indentFirstLine - this indicates if the first line should be indented or not.

        returns   - a string containing the object's member variables in human-readable form.
        '''
        retStr = ''
        if (indentFirstLine):
            retStr += indentStr
        retStr += 'MetaData:\n'
        retStr += indentStr + '    name=' + self.name + '\n'
        retStr += indentStr + '    typeStr=' + self.typeStr + '\n'
        retStr += indentStr + '    value=' + self.value + '\n'
        #
        return retStr
    #
    #===================================================================================================================
#
#=======================================================================================================================
#
kValidParamTypeList = [
    'RestQueryTerm',
    'MtxObjectId',
    'BigInteger',
    'Long',
    'String',
    'integer',
    'Boolean',
    'MtxTimestamp',
    'String[]',
]
#
kValidRequestParamUseList = [
    'required',
    'optional',
]
class RequestParam(object):
    ''' This class represents the data in a request_param tag used when defining a REST_service.

    The data members of this class are:

        description - contains the value in the description tag. This is a string.

        name      - contains the value in the name tag. This is a string.

        typeStr   - contains the value in the type tag. This is a string.

        use       - contains the value in the use tag. This is a string.
    '''
    #
    #===================================================================================================================
    # RequestParam
    def __init__(
            self,
            description,
            name,
            typeStr,
            use):
        global kValidParamTypeList
        global kValidRequestParamUseList
        #
        self.description = description
        self.name = name
        self.typeStr = typeStr
        if (typeStr not in kValidParamTypeList):
            raise ValueError('RequestParam() error: invalid typeStr (' + typeStr +
                '). It must be one of these values: ' + str(kValidParamTypeList))
        self.use = use
        if (use not in kValidRequestParamUseList):
            raise ValueError('RequestParam() error: invalid use (' + use +
                '). It must be one of these values: ' + str(kValidRequestParamUseList))
    #
    #===================================================================================================================
    # RequestParam
    def __str__(self):
        return self.printStr('')
    #
    #===================================================================================================================
    # RequestParam
    def printStr(self, indentStr='', indentFirstLine=True):
        ''' This function will return a string containing the object's member
            variables in human-readable form.

        The parameters are:

        indentStr - this contains a string that is added to the string before
                    the object's member variables are added.

        indentFirstLine - this indicates if the first line should be indented or not.

        returns   - a string containing the object's member variables in human-readable form.
        '''
        retStr = ''
        if (indentFirstLine):
            retStr += indentStr
        retStr += 'RequestParam:\n'
        retStr += indentStr + '    description=' + self.description + '\n'
        retStr += indentStr + '    name=' + self.name + '\n'
        retStr += indentStr + '    typeStr=' + self.typeStr + '\n'
        retStr += indentStr + '    use=' + self.use + '\n'
        #
        return retStr
    #
    #===================================================================================================================
#
#=======================================================================================================================
#
class UrlParam(object):
    ''' This class represents the data in a url_param tag used when defining a REST_service.

    The data members of this class are:

        description - contains the value in the description tag. This is a string.

        name - contains the value in the name tag. This is a string.

        typeStr - contains the value in the type tag. This is a string.
    '''
    #
    #===================================================================================================================
    # UrlParam
    def __init__(
            self,
            description,
            name,
            typeStr):
        global kValidParamTypeList
        #
        self.description = description
        self.name = name
        self.typeStr = typeStr
        if (typeStr not in kValidParamTypeList):
            raise ValueError('UrlParam() error: invalid typeStr (' + typeStr +
                '). It must be one of these values: ' + str(kValidParamTypeList))
    #
    #===================================================================================================================
    # UrlParam
    def __str__(self):
        return self.printStr('')
    #
    #===================================================================================================================
    # UrlParam
    def printStr(self, indentStr='', indentFirstLine=True):
        ''' This function will return a string containing the object's member
            variables in human-readable form.

        The parameters are:

        indentStr - this contains a string that is added to the string before
                    the object's member variables are added.

        indentFirstLine - this indicates if the first line should be indented or not.

        returns   - a string containing the object's member variables in human-readable form.
        '''
        retStr = ''
        if (indentFirstLine):
            retStr += indentStr
        retStr += 'UrlParam:\n'
        retStr += indentStr + '    description=' + self.description + '\n'
        retStr += indentStr + '    name=' + self.name + '\n'
        retStr += indentStr + '    typeStr=' + self.typeStr + '\n'
        #
        return retStr
    #
    #===================================================================================================================
#
#=======================================================================================================================
#
class RestService(object):
    ''' This class represents the data in a REST_service tag used when defining a relationship.

    The data members of this class are:

        name      - contains the value in the name tag. This is a string.

        description - contains the value in the description tag. This is a string.

        classStr  - contains the value in the class tag. This is a string.

        url      - contains the value in the url tag. This is a string.

        method   - contains the value in the method tag. This is a string.

        mappingList - contains the values in the mapping tags. This is a list of strings.

        patchList - contains the values in the patch tags. This is a list of strings.

        calloutStatementList - contains the values in the callout_statement tags. This is a list of strings.

        calloutJsonList - contains the values in the callout_json tags. This is a list of strings.

        calloutXmlList - contains the values in the callout_xml tags. This is a list of strings.

        calloutMethodList - contains the values in the callout_method tags. This is a list of strings.

        calloutClassList - contains the values in the callout_class tags. This is a list of strings.

        filterStrList - contains the values in the filter tags. This is a list of strings.

        urlParamList - contains the values in the url_param tags. This is a list of UrlParam objects.

        requestParamList - contains the values in the request_param tags. This is a list of RequestParam objects.

        metaDataList - contains the values in the metadata tags. This is a list of MetaData objects.
    '''
    #
    #===================================================================================================================
    # RestService
    def __init__(
            self,
            name,
            description,
            classStr,
            url,
            method,
            mappingList,
            patchList,
            calloutStatementList,
            calloutJsonList,
            calloutXmlList,
            calloutMethodList,
            calloutClassList,
            filterStrList,
            urlParamList,
            requestParamList,
            metaDataList):
        # method must be in ["GET", "HEAD", "POST", "PUT", "DELETE"]
        # urlParamList is a list of UrlParam objects
        # requestParamList is a list of RequestParam objects
        #
        self.name = name
        self.description = description
        self.classStr = classStr
        self.url = url
        self.method = method
        self.mappingList = mappingList
        self.patchList = patchList
        self.calloutStatementList = calloutStatementList
        self.calloutJsonList = calloutJsonList
        self.calloutXmlList = calloutXmlList
        self.calloutMethodList = calloutMethodList
        self.calloutClassList = calloutClassList
        self.filterStrList = filterStrList
        self.urlParamList = urlParamList
        self.requestParamList = requestParamList
        self.metaDataList = metaDataList
    #
    #===================================================================================================================
    # RestService
    def __str__(self):
        return self.printStr('')
    #
    #===================================================================================================================
    # RestService
    def printStr(self, indentStr='', indentFirstLine=True):
        ''' This function will return a string containing the object's member
            variables in human-readable form.

        The parameters are:

        indentStr - this contains a string that is added to the string before
                    the object's member variables are added.

        indentFirstLine - this indicates if the first line should be indented or not.

        returns   - a string containing the object's member variables in human-readable form.
        '''
        retStr = ''
        if (indentFirstLine):
            retStr += indentStr
        retStr += 'RestService:\n'
        retStr += indentStr + '    name=' + self.name + '\n'
        retStr += indentStr + '    description=' + self.description + '\n'
        retStr += indentStr + '    classStr=' + self.classStr + '\n'
        retStr += indentStr + '    url=' + self.url + '\n'
        retStr += indentStr + '    method=' + self.method + '\n'
        retStr += indentStr + '    mappingList=\n'
        if (self.mappingList):
            for mapping in self.mappingList:
                retStr += indentStr + '        ' + str(mapping) + '\n'
        #
        retStr += indentStr + '    patchList=\n'
        if (self.patchList):
            for patch in self.patchList:
                retStr += indentStr + '        ' + str(patch) + '\n'
        #
        retStr += indentStr + '    calloutStatementList=\n'
        if (self.calloutStatementList):
            for calloutStatement in self.calloutStatementList:
                retStr += indentStr + '        ' + str(calloutStatement) + '\n'
        #
        retStr += indentStr + '    calloutJsonList=\n'
        if (self.calloutJsonList):
            for calloutJson in self.calloutJsonList:
                retStr += indentStr + '        ' + str(calloutJson) + '\n'
        #
        retStr += indentStr + '    calloutXmlList=\n'
        if (self.calloutXmlList):
            for calloutXml in self.calloutXmlList:
                retStr += indentStr + '        ' + str(calloutXml) + '\n'
        #
        retStr += indentStr + '    calloutClassList=\n'
        if (self.calloutClassList):
            for calloutClass in self.calloutClassList:
                retStr += indentStr + '        ' + str(calloutClass) + '\n'
        #
        retStr += indentStr + '    filterStrList=\n'
        if (self.filterStrList):
            for filterStr in self.filterStrList:
                retStr += indentStr + '        ' + str(filterStr) + '\n'
        #
        retStr += indentStr + '    urlParamList=\n'
        if (self.urlParamList):
            for urlParam in self.urlParamList:
                retStr += urlParam.printStr(indentStr + '        ')
        #
        retStr += indentStr + '    requestParamList=\n'
        if (self.requestParamList):
            for requestParam in self.requestParamList:
                retStr += requestParam.printStr(indentStr + '        ')
        #
        retStr += indentStr + '    metaDataList=\n'
        if (self.metaDataList):
            for metaData in self.metaDataList:
                retStr += metaData.printStr(indentStr + '        ')
        #
        return retStr
    #
    #===================================================================================================================
#
#=======================================================================================================================
#
class Relationship(object):
    ''' This class represents the data in a relationship tag used when defining a DataContainerRelationship.

    The data members of this class are:

        sourceDataContainerId - contains the source DataContainer Id (the name). This is a string.

        targetDataContainerId - contains the target DataContainer Id (the name). This is a string.

        restServiceList - contains a list of RestService objects.
    '''
    #
    #===================================================================================================================
    # Relationship
    def __init__(
            self,
            sourceDataContainerId,      # The request MDC name.
            targetDataContainerId,      # The response MDC name.
            restServiceList):
        self.sourceDataContainerId = sourceDataContainerId
        self.targetDataContainerId = targetDataContainerId
        self.restServiceList = restServiceList
    #
    #===================================================================================================================
    # Relationship
    def __str__(self):
        return self.printStr('')
    #
    #===================================================================================================================
    # Relationship
    def printStr(self, indentStr='', indentFirstLine=True):
        ''' This function will return a string containing the object's member
            variables in human-readable form.

        The parameters are:

        indentStr - this contains a string that is added to the string before
                    the object's member variables are added.

        indentFirstLine - this indicates if the first line should be indented or not.

        returns   - a string containing the object's member variables in human-readable form.
        '''
        retStr = ''
        if (indentFirstLine):
            retStr += indentStr
        retStr += 'Relationship:\n'
        retStr += indentStr + '    sourceDataContainerId=' + self.sourceDataContainerId + '\n'
        retStr += indentStr + '    targetDataContainerId=' + self.targetDataContainerId + '\n'
        retStr += indentStr + '    restServiceList=\n'
        for restService in self.restServiceList:
            retStr += restService.printStr(indentStr + '        ')
        #
        return retStr
    #
    #===================================================================================================================
#
#=======================================================================================================================
#
class DataContainerRelationship(object):
    ''' This class represents the data in a container_relationship tag.

    The data members of this class are:

        name      - contains the name of this object. This is a string.

        relationshipList - contains a list of Relationship objects,
    '''
    #
    #===================================================================================================================
    # DataContainerRelationship
    def __init__(
            self,
            name,
            relationshipList):
        #
        self.name = name
        self.relationshipList = relationshipList
    #
    #===================================================================================================================
    # DataContainerRelationship
    def __str__(self):
        return self.printStr('')
    #
    #===================================================================================================================
    # DataContainerRelationship
    def printStr(self, indentStr='', indentFirstLine=True):
        ''' This function will return a string containing the object's member
            variables in human-readable form.

        The parameters are:

        indentStr - this contains a string that is added to the string before
                    the object's member variables are added.

        indentFirstLine - this indicates if the first line should be indented or not.

        returns   - a string containing the object's member variables in human-readable form.
        '''
        retStr = ''
        if (indentFirstLine):
            retStr += indentStr
        retStr += 'DataContainerRelationship:\n'
        retStr += indentStr + '    name=' + self.name + '\n'
        for relationship in self.relationshipList:
            retStr += relationship.printStr(indentStr + '        ')
        #
        return retStr
    #
    #===================================================================================================================
#
#=======================================================================================================================


#=======================================================================================================================
#
# Functions that are not part of any class.
#
#=======================================================================================================================
#
# This dictionary maps single characters to the escaped XML format.
# NOTE: During testing with Xerces using (XML 1.1), I had problems with these
# hex values.
# 2C -> terminates string  `
# 5B -> terminates string  [
# 7B -> terminates string  {
# 7D -> terminates string  }
# NOTE: I am including ']' to be consistent with ']'
kCharToEscapedXmlStrDictionary = {
    '&' : '&amp;',
    '<' : '&lt;',
    '>' : '&gt;',
    "'" : '&apos;',
    '"' : '&quot;',
    '`' : '\\60',
    '[' : '\\5b',
    ']' : '\\5d',
    '{' : '\\7b',
    '}' : '\\7d',
}
#
#=======================================================================================================================
#
def convertBytesToEscapedStr(inBytes):
    ''' This function will convert the passed raw bytes to a compactMdc escaped string.

    ASCII values from 0x20 -> 0x7E are passed through are strings -- except a backslash which is
    converered to a double backslack.

    Values from 0x00 -> 0x1F and 0x7F -> 0xFF are converted to a backslash followed by the two hex
    digits representing the value. For example, a byte value of 0x81 will convert to string '\81'

    inBytes - the input Python bytes

    It returns the converted string.

    NOTE: In Py3 iterating over an array of bytes actually yields an integer value for
    each element, NOT a byte.
    '''
    outStr = ''
    for testByte in inBytes:
        if testByte == '\\':
            outStr += '\\\\'
        elif testByte <= 0x1f or testByte >= 0x7f:
            outStr += '\\%0.2x' % testByte
        else:
            outStr += '%c' % testByte
    return outStr

#
#=======================================================================================================================
#
def convertCamelCaseToUnderscoreUpperCase(value):
    # This function will take a camelCase string and convert it
    # to a underscore separated string with all letters converted
    # to uppercase. For example, if you pass in "GroupIdArray", it
    # will return "GROUP_ID_ARRAY".
    # NOTE: This is a duplicate on the function with the same name in common_functions.
    newValue = ''
    firstLetter = True
    firstDigit = True
    for letter in value:
        # We only want to add the _ before the first digit of a number.
        if (letter.isdigit()):
            # add the _ if this is the first digit
            if (firstDigit):
                newValue += '_'
            newValue += letter
            firstDigit = False
            continue
        # Not a digit. We only want to add the _ before the first
        # uppercase letter except if this is the first letter of the
        # string.
        upperLetter = letter.upper()
        if (letter == upperLetter):
            # Don't add the _ if this is the first letter
            if (not firstLetter):
                newValue += '_'
        newValue += upperLetter
        firstLetter = False
        firstDigit = True
    return newValue
#
#=======================================================================================================================
#
def convertEscapedHexCharactersToPrintableCharacters(inStr):
    # Convert any \xx characters that are printable to the printable
    # character. For example, '\5d' will be converted to ']'
    global mdcDebug
    #
    # get out fast if there are no '\' characters.
    if (inStr.find('\\') == -1):
        return inStr
    #
    inStrLen = len(inStr)
    idx = 0
    outStr = ''
    while idx < inStrLen:
        testChar = inStr[idx]
        if (mdcDebug):
            printDebugMsg('testChar=' + str(testChar) + ', outStr=' + outStr)
        if (testChar == '\\'):
            idx += 1
            testChar = inStr[idx]
            if (testChar == '\\'):
                idx += 1
                outStr += '\\\\'
                continue
            if ((testChar <= '1') or (testChar >= '8')):
                # Unprintable
                outStr += '\\' + testChar
                # Output the second hex character.
                # Note we don't check to see if idx is valid because we want
                # it to die here and give a Traceback from here.
                idx += 1
                outStr += inStr[idx]
                idx += 1
                continue
            # Printable (except 7f)
            charCode = int(testChar) << 4
            idx += 1
            charCode += int(inStr[idx], 16)
            if (charCode == 0x7f):
                outStr += '\\' + testChar
                # Output the second hex character.
                # Note we don't check to see if idx is valid because we want
                # it to die here and give a Traceback from here.
                outStr += inStr[idx]
                idx += 1
                continue
            newChar = chr(charCode)
            if (newChar == '\\'):
                outStr += newChar
            outStr += newChar
            idx += 1
            continue
        outStr += testChar
        idx += 1
        # See if this is one of the special characters
        #if (testChar not in kCharToEscapedXmlStrDictionary.keys()):
        #    outStr += testChar
        #    idx += 1
        #    continue
        #outStr += kCharToEscapedXmlStrDictionary[testChar]
        #idx += 1
        #
    #
    return outStr
#
#=======================================================================================================================
#
def convertEscapedStrToEscapedXmlStr(inStr):
    ''' This function will convert the passed escaped string to an escaped XML string.

    This function will parse the passed string and convert the escaped
    formatted data to escaped XML data. It converts invalid XML characters
    e.g. (&, <, >, ', ") to their XML equivalent character strings.

    The parameters are:

    inStr - the input "escaped format" string. This can be either the
                '(size:data)' or the 'data' types of strings.

    It returns the converted string. This string does not use the '(size:data)'
    formatting.
    '''
    global reStrFormat
    # Check if the inStr is: (<size>:<data>)
    outStr = ''
    match = reStrFormat.match(inStr)
    inStrSize = None
    inStrData = None
    if match:
        # Using special format: (<size>:<data>)
        inStrSize = int(match.group(1))
        inStrData = match.group(2)
    else:
        # Just a plain string
        inStrData = inStr
    inStrLen = len(inStrData)
    idx = 0
    outByteSize = 0
    while idx < inStrLen:
        testChar = inStrData[idx]
        if (mdcDebug):
            printDebugMsg('testChar=' + str(testChar) + ', outByteSize=' + str(outByteSize) + ', outStr=' + outStr)
        if (testChar == '\\'):
            idx += 1
            testChar = inStrData[idx]
            if (testChar == '\\'):
                idx += 1
                outStr += '\\\\'
                outByteSize += 1
                continue
            else:
                outStr += '\\' + testChar
                outByteSize += 1
                # Output the second hex character.
                # Note we don't check to see if idx is valid because we want
                # it to die here and give a Traceback from here.
                idx += 1
                outStr += inStrData[idx]
                idx += 1
                continue
        # See if this is one of the special characters
        if testChar not in kCharToEscapedXmlStrDictionary:
            outStr += testChar
            outByteSize += 1
            idx += 1
            continue
        outStr += kCharToEscapedXmlStrDictionary[testChar]
        outByteSize += 1
        idx += 1
    #
    # Verify that the size matches what was in the string (if it was passed)
    #
    if (inStrSize):
        if (inStrSize != outByteSize):
            raise TypeError('dataValue error: the input size (' + str(inStrSize) +
                ') does match the calculated size of the passed data (' + str(outByteSize) + '). data=' + inStr)
    return outStr
#
#=======================================================================================================================
#
def convertEscapedXmlStrToEscapedStr(inStr):
    ''' This function will convert the passed escaped XML string to an escaped string.

    This function will parse the passed escaped XML string and convert the XML
    formatted data to escaped data.
    It converts special XML strings to their corresponding characters,
    e.g. from '&amp;' to '&'.

    The parameters are:

    inStr - the input "escaped XML format" string.

    It returns the converted string using the '(size:data)' format.
    '''
    idx = 0
    outByteSize = 0
    inStrLen = len(inStr)
    outStr = ''
    testSliceStr = None
    while idx < inStrLen:
        testChar = inStr[idx]
        if (mdcDebug):
            printDebugMsg('testChar=' + str(testChar))
        if (testChar == '\\'):
            idx += 1
            testChar = inStr[idx]
            if (testChar == '\\'):
                idx += 1
                outStr += '\\\\'
                outByteSize += 1
                continue
        elif (testChar != '&'):
            # The character doesn't start with a \ or a &
            idx += 1
            outByteSize += 1
            outStr += testChar
            continue
        # The character does start with a \ or a &
        if (testChar == '\\'):
            testSliceStr = inStr[idx:idx + 3]
            # Lower case it
            testSliceStr = testSliceStr.lower()
        else:
            testSliceStr = inStr[idx:idx + 6]
        found = False
        for (escChar, escStr) in list(kCharToEscapedXmlStrDictionary.items()):
            if (testSliceStr.startswith(escStr)):
                idx += len(escStr)
                outByteSize += 1
                outStr += escChar
                found = True
                break
        if (found):
            continue
        # Not found. Is this a formatting error? It could be if the char starts
        # with a &.
        if (testChar == '&'):
            raise TypeError('dataValue error: found an unknown "&" token (' + testSliceStr +
                ') at offset ' + str(idx) + '. data=' + inStr)
        # To get here, testChar is not an '&'. It must be a '\'
        outStr += '\\'
        idx += 1
        outByteSize += 1
        outStr += testChar
        # Get the second hex byte
        # Note we don't check to see if idx is valid because we want
        # it to die here and give a Traceback from here.
        outStr += inStr[idx]
        idx += 1
    return '(' + str(outByteSize) + ':' + outStr + ')'

#
#=======================================================================================================================
#
def createDefsFileIfNeeded():
    '''
    This function is obsolete.
    '''
    print('WARN: Invoking createDefsFileIfNeeded() is deprecated.')
    return

#
#=======================================================================================================================
#
def createMdcConfigPickledFile(systemFileFlag):
    ''' This function will create an mdc_config_system.pickled file if systemFileFlag is True or
    an mdc_config_custom.pickled file if systemFileFlag is False. The file that is created will
    only contain the appropriate MDCs.

    NOTE: This will actually create a file with a prefix of 'temp_' and then compare it to an
    existing file. If the existing file is equal to the temp_ file, then the temp_ file is removed.
    If the existing file is not equal to the temp_ file or if there is no existing file, then the
    temp_ file is renamed to remove the 'temp_' prefix.

    The parameters are:

    systemFileFlag - If this is True, then an mdc_config_system.pickled file is created. Otherwise,
        an mdc_config_custom.pickled file is created.

    It does not return anything.
    '''
    global configFileName
    global kCurrentYear
    global kDataContainerKeyToIdDictionary
    global kDataContainerKeyToSpecDictionary
    global kEnumSubTypeDict
    global kExpectedCustomPickledFormat
    global kExpectedSystemPickledFormat
    global kMdcConfigCustomPickledAbsFileName
    global kMdcConfigSystemPickledAbsFileName
    global kMdcConfigSystemVariableList
    global kRevMessage
    global kTopDir
    global mdcDebugParsing
    global THE_MDC_DESCRIPTOR_INDEX
    global THE_MDC_DESCRIPTOR_INDEX_LIST
    #
    expectedPickledFormat = kExpectedSystemPickledFormat
    mdcConfigPickledAbsFileName = kMdcConfigSystemPickledAbsFileName
    schemaVersion = THE_MDC_DESCRIPTOR_INDEX.systemSchemaVersion
    #
    if (not systemFileFlag):
        expectedPickledFormat = kExpectedCustomPickledFormat
        mdcConfigPickledAbsFileName = kMdcConfigCustomPickledAbsFileName
        #
        # Now we need to read in the config file $MTX_CONF_DIR/mdc_config_custom.xml using the
        # current schema (THE_MDC_DESCRIPTOR_INDEX).
        configFileName = kMdcConfigCustomXmlAbsFileName
        # Add the custom MDCs from the custom XML file.
        parseDataContainerXmlFile(kMdcConfigCustomXmlAbsFileName)
        # Get the latest schema version
        THE_MDC_DESCRIPTOR_INDEX.servProvSchemaVersion = 0
        # Now update THE_MDC_DESCRIPTOR_INDEX with only the custom MDCs.
        THE_MDC_DESCRIPTOR_INDEX.readSpecDictionary(processSystemValues=False)
        schemaVersion = kDataContainerSpecServProvSchemaVersion
        # NOTE: At this point THE_MDC_DESCRIPTOR_INDEX will contain both the custom AND system MDCs.
        #
        # NOTE: I don't think the following update to kMdcConfigSystemVariableList is needed at this time. It is
        # definitely needed when load the custom MDCs.
    #
    # Now process this information by the numeric data container key.
    #
    # Create a pickled version of all the dictionaries, etc that we created.
    tempMdcConfigPickledAbsFileName = mdcConfigPickledAbsFileName.replace('mdc_config_', 'temp_mdc_config_')
    mdcConfigPickleFile = open(tempMdcConfigPickledAbsFileName, 'wb')
    #
    # We need to dump all of the information that is created when reading the config file.
    # We also need to make sure we dump and load the info in the same order. This is indicated
    # by the "expectedPickledFormat". This value needs to be changed when either variables are added/removed or
    # the order is changed.
    #
    pickleProtocol = pickle.DEFAULT_PROTOCOL
    pickle.dump(expectedPickledFormat, mdcConfigPickleFile, pickleProtocol)
    #
    # Next for debugging reasons, we dump the schema version.
    pickle.dump(schemaVersion, mdcConfigPickleFile, pickleProtocol)
    #
    # Create a dictionary of only the appropriate MDCs in kDataContainerKeyToIdDictionary
    tempDictionary = {}
    for key in sorted(kDataContainerKeyToIdDictionary.keys()):
        if (systemFileFlag):
            # Don't include negative values.
            if (key < 0):
                continue
        else:
            # Don't include positive values
            if (key >= 0):
                # We break here because the list is sorted.
                break
        tempDictionary[key] = kDataContainerKeyToIdDictionary[key]
    # Dump the appropriate version of kDataContainerKeyToIdDictionary
    pickle.dump(tempDictionary, mdcConfigPickleFile, pickleProtocol)
    #
    # Create a dictionary of only the appropriate MDCs in kDataContainerKeyToSpecDictionary
    tempDictionary = {}
    for key in sorted(kDataContainerKeyToSpecDictionary.keys()):
        if (systemFileFlag):
            # Don't include negative values.
            if (key < 0):
                continue
        else:
            # Don't include positive values
            if (key >= 0):
                # We break here because the list is sorted.
                break
        tempDictionary[key] = kDataContainerKeyToSpecDictionary[key]
    # Dump the appropriate version of kDataContainerKeyToSpecDictionary
    pickle.dump(tempDictionary, mdcConfigPickleFile, pickleProtocol)
    #
    # Create an appropriate version of THE_MDC_DESCRIPTOR_INDEX.
    tempMdcDescIndex = DataContainerDescriptorIndex(0, 0)
    tempMdcDescIndex.updateFrom(THE_MDC_DESCRIPTOR_INDEX, systemFileFlag)
    pickle.dump(tempMdcDescIndex, mdcConfigPickleFile, pickleProtocol)
    # We don't need to dump/load the THE_MDC_DESCRIPTOR_INDEX_LIST because we create it when we load.
    #
    # Create the data for the default schema: this will be loaded in kMdcConfigSystemVariableList
    #
    # This is a list of tuples, where the first value is the variable name, and the second value
    # is the value of that variable,
    variableList = []
    # First create the KEY_* variables
    for containerKey, containerId in list(THE_MDC_DESCRIPTOR_INDEX.containerKeyToContainerIdDict.items()):
        if (systemFileFlag):
            # Don't include negative values.
            if (containerKey < 0):
                continue
        else:
            # Don't include positive values
            if (containerKey >= 0):
                continue
        variableName = 'KEY_' + convertCamelCaseToUnderscoreUpperCase(containerId)
        variableList.append((variableName, containerKey))
    #
    # Now create the *MdcDesc variables and their field keys
    for containerId, fieldObjList in list(THE_MDC_DESCRIPTOR_INDEX.containerIdToFieldObjListDict.items()):
        containerKey = THE_MDC_DESCRIPTOR_INDEX.containerIdToContainerKeyDict[containerId]
        if (systemFileFlag):
            # Don't include negative values.
            if (containerKey < 0):
                continue
        else:
            # Don't include positive values
            if (containerKey >= 0):
                continue
        variablePrefix = ''
        # Lowercase the first character
        variablePrefix = 'k' + containerId
        variableName = variablePrefix + 'MdcDesc'
        mdcDesc = THE_MDC_DESCRIPTOR_INDEX.get(containerId)
        variableList.append((variableName, mdcDesc))
        #
        # Now create the field keys
        #
        # Process this container's fields
        #
        for fieldObjId in fieldObjList:
            fieldId = fieldObjId.name
            # In case someone uses a '-' in the field name.
            fieldId = fieldId.replace('-', '')
            variableName = variablePrefix + fieldId + 'FldKey'
            variableValue = mdcDesc.getFieldKey(fieldId)
            variableList.append((variableName, variableValue))
            #
            # Now if this field is a struct, then create a multi-level field key
            # Skip lists and arrays.
            #
            # For performance reasons, compare the dataType instead of calling isAStruct().
            if (fieldObjId.dataType != DATA_TYPE_STRUCT):
                continue
            # For performance reasons, compare the sequenceType instead of calling isArray().
            if (fieldObjId.sequenceType == FIELD_IS_ARRAY):
                continue
            # For performance reasons, compare the sequenceType instead of calling isList().
            if (fieldObjId.sequenceType == FIELD_IS_LIST):
                continue
            structId = fieldObjId.structId
            if (structId is None):
                continue
            if (structId == ''):
                continue
            #
            # Get this container's field object list
            #
            if (structId not in THE_MDC_DESCRIPTOR_INDEX.containerIdToFieldObjListDict):
                raise ValueError('data_container.py: unknown struct name (' + \
                    structId + ') for field ' + fieldId + ' in ' + containerId)
            subFieldObjList = THE_MDC_DESCRIPTOR_INDEX.containerIdToFieldObjListDict[structId]
            for subFieldObjId in subFieldObjList:
                subFieldId = subFieldObjId.name
                subFieldName = variablePrefix + fieldId + subFieldId + 'FldKey'
                variableValue = mdcDesc.getFieldKey(fieldId + '.' + subFieldId)
                variableList.append((subFieldName, variableValue))
    # NOTE: variableList is related to mdcConfigVariableList.
    pickle.dump(variableList, mdcConfigPickleFile, pickleProtocol)
    if (systemFileFlag):
        pickle.dump(kRelationshipSetIdToRelationshipListDict, mdcConfigPickleFile, pickleProtocol)
        # Version 4 has kEnumSubTypeDict
        pickle.dump(kEnumSubTypeDict, mdcConfigPickleFile, pickleProtocol)
    else:
        pickle.dump(kServProvSchemaVersionToRequiredSystemSchemaVersionDict, mdcConfigPickleFile, pickleProtocol)
    mdcConfigPickleFile.close()
    # Check if there is an existing file and if so, if it is the same.
    if (os.path.exists(mdcConfigPickledAbsFileName)):
        # compare the two files.
        if (filecmp.cmp(mdcConfigPickledAbsFileName, tempMdcConfigPickledAbsFileName)):
            # They are the same. Remove the new file.
            # printMsg('No change is needed to ' + mdcConfigPickledAbsFileName)
            os.remove(tempMdcConfigPickledAbsFileName)
        else:
            # They are different. Remove the old file and rename the new one.
            printMsg('Replacing the file: ' + mdcConfigPickledAbsFileName)
            os.remove(mdcConfigPickledAbsFileName)
            os.rename(tempMdcConfigPickledAbsFileName, mdcConfigPickledAbsFileName)
    else:
        printMsg('Creating the file: ' + mdcConfigPickledAbsFileName)
        os.rename(tempMdcConfigPickledAbsFileName, mdcConfigPickledAbsFileName)
    #
    return
#
#=======================================================================================================================
#
# Convert an integer value to a boolean.
#
# @param value  The value to convert.
#
# @return True, if the value is a non-zero integer.  False, otherwise.
def getBool(value):
    try:
        return int(value) != 0
    except:
        return False
#
#=======================================================================================================================
# Get the concatenation of all comment nodes from the specified minidom node.
#
# @param node  The minidom node from which to retrieve comment nodes.
#
# @return The concatenation of all discovered comment nodes, wrapped as a Doxygen-style comment.
def getComment(node):
    for child in node.childNodes:
        if (child.nodeType == child.COMMENT_NODE):
            return '/** ' + str(child.data) + ' */'

    return ''
#
#=======================================================================================================================
#
def getCompactValue(fieldObj, value):
    global kMaxStringBlobSizeInBytes
    #
    if (value is None):
        return ''

    # We don't call isSimple() here because it is slower than
    # doing it this way.
    if (fieldObj.sequenceType == FIELD_IS_SIMPLE):
        # If it is a STRING or BLOB, then we use a special syntax.
        if ((fieldObj.dataType == DATA_TYPE_STRING) or
                (fieldObj.dataType == DATA_TYPE_BLOB)):
            # Figure out the size of the data minus all of the escaped chars.
            # For performance reasons, only call if needed.
            sizeInBytes = 0
            if (value.find('\\') == -1):
                sizeInBytes = len(value)
            else:
                sizeInBytes = getUnescapedStrSize(value)
            if (sizeInBytes > kMaxStringBlobSizeInBytes):
                raise ValueError('getCompactValue error: a String/Blob field (' + fieldObj.name  +
                    ') has a value with the size of (' + str(sizeInBytes) +
                    ') and that exceeds the maximum size (' + str(kMaxStringBlobSizeInBytes) + '. ' +
                    'Config file: ' + configFileName)
            return '(' + str(sizeInBytes) + ':' + value + ')'
        if ((fieldObj.dataType == DATA_TYPE_INT128) or (fieldObj.dataType == DATA_TYPE_UINT128)):
            hexValueStr = '0x%x' % value
            return hexValueStr
        if (fieldObj.dataType != DATA_TYPE_STRUCT):
            return str(value)
        # DATA_TYPE_STRUCT
        # Always print the header to make it easier to visually
        # find structs.
        return value.printCompact(True)
    # Array or list
    if (value == []):
        return '{}'
    firstValueFlag = True
    if (fieldObj.dataType != DATA_TYPE_STRUCT):
        if (type(value) != list):
            # We can't print this container since it has a bad
            # field. So we will save it so we can display the bad
            # value. Then we will set this field's value to None so
            # we can display the container.
            badValue = value
            # self.setValue(descIdx, fieldObj, None)
            raise TypeError('printCompact error: the field (' + fieldObj.name +
                ') has a non-list value. It has a type of (' + str(type(badValue)) +
                ') and a value of (' + str(badValue) + '). Config file: ' + configFileName + '.')
                #'. The container with this field removed is: ' + self.printStr()
        if ((fieldObj.dataType == DATA_TYPE_INT128) or (fieldObj.dataType == DATA_TYPE_UINT128)):
            hexValueStr = '0x%x' % value
            return '{' + hexValueStr + '}'
        return '{' + str(value) + '}'
    #
    # list or array of structs
    valStr = '{'
    for val in value:
        if (not firstValueFlag):
            valStr += ','
        # Always print the header to make it easier to visually
        # find structs.
        valStr += val.printCompact(True)
        firstValueFlag = False
    valStr += '}'
    return valStr
#
#=======================================================================================================================
# Get the concatenation of all text nodes from the specified node list.
#
# @param nodelist  The minidom node list from which to retrieve text nodes.
#
# @return The concatenation of all discovered text nodes.
def getTextFromNodeList(nodeList):
    rc = []
    for node in nodeList:
        if node.nodeType == node.TEXT_NODE:
            rc.append(node.data)
    return ''.join(rc)
#
#=======================================================================================================================
#
def getUnescapedStrSize(inStr):
    ''' This function will calculate the un-escaped size of the passed escaped string.

    This function will calculate the un-escaped size of the passed escaped
    string. For example, \hh is treated as one byte. \\ is also treated as
    one byte.

    The parameters are:

    inStr - the input "escaped XML format" string.

    It returns the un-escaped size.
    '''
    inStrLen = len(inStr)
    # Quick out if we don't need to check the rest of the string.
    if (inStr.find('\\') == -1):
        return inStrLen
    idx = 0
    outByteSize = 0
    while idx < inStrLen:
        testChar = inStr[idx]
        #if (mdcDebug):
        #    printDebugMsg('testChar=' + str(testChar))
        if (testChar == '\\'):
            idx += 1
            testChar = inStr[idx]
            if (testChar == '\\'):
                idx += 1
                outByteSize += 1
                continue
            # Must be \hh
            idx += 2
            outByteSize += 1
        else:
            idx += 1
            outByteSize += 1
    return outByteSize
#
#=======================================================================================================================
# Get the value of the specified tag from the specified node.
#
# @param parent       The node from which to retrieve the value
# @param tag          The tag for the value.
# @param defaultValue The value to use if one is not found.
#
# @return The value of the tag, if present. 'None' otherwise.
def getValue(parent, tag, defaultValue=None):
    for node in parent.childNodes:
        if (node.nodeName == tag):
            if (len(node.childNodes)):
                return node.childNodes[0].data.strip()
        #
    #
    return defaultValue
#
#=======================================================================================================================
# Get the values of the specified tag from the specified node and return them in a list.
#
# @param parent       The node from which to retrieve the value
# @param tag          The tag for the value.
# @param defaultValue The value to use if one is not found.
#
# @return A list of the values of the tag, if present. 'None' otherwise.
def getValueList(parent, tag, defaultValue=None):
    retList = []
    for node in parent.childNodes:
        if (node.nodeName == tag):
            if (len(node.childNodes)):
                for childNode in node.childNodes:
                    retList.append(childNode.data.strip())
                #
            #
        #
    #
    if (len(retList)):
        return retList
    #
    return defaultValue
#
#=======================================================================================================================
# If the tag exists belonging to the specified node, then return True, else return False>
#
# @param node         The node from which to check for the tag
# @param tag          The tag for the value.
#
# @return True if the tag exists belonging to the specified node, else False.
def hasTag(node, tag):
    for childNode in node.getElementsByTagName(tag):
        # Ignore the nodes below this one.
        if childNode.parentNode == node:
            return True
        #
    #
    return False
#
#=======================================================================================================================
#
def indentMultiLineString(inputLine, indentStr):
    ''' This function will look at the passed inputLine and see if there are any new-lines in it. If there is one
    or more new-lines, then inputLine will be split into a list of multiple lines. Then each line will be
    prefixed with the passed indentStr and a new-line is appended to the line. Then all of lines will be concatenated
    into retStr (a string) and it will returned.
        NOTE: the returned string will NOT end with a new-line character.
    '''
    retStr = ''
    if (inputLine is None):
        retStr = indentStr + 'None'
        return retStr
    #
    tempLineList = inputLine.split('\n')
    for tempLine in tempLineList:
        if (retStr != ''):
            retStr += '\n'
        if (tempLine == ''):
            # Don't indent a blank line
            continue
        retStr += indentStr + tempLine
    return retStr
#
#=======================================================================================================================
#
def loadMdcConfigPickledFile(systemFileFlag):
    ''' This function will load an mdc_config_system.pickled file if systemFileFlag is True or
    an mdc_config_custom.pickled file if systemFileFlag is False. The file that is loaded will
    only contain the appropriate MDCs.

    The parameters are:

    systemFileFlag - If this is True, then an mdc_config_system.pickled file is created. Otherwise,
        an mdc_config_custom.pickled file is created.

    It does not return anything.
    '''
    global kDataContainerKeyToIdDictionary
    global kDataContainerKeyToSpecDictionary
    global kDataContainerSpecServProvSchemaVersion
    global kDataContainerSpecSystemSchemaVersion
    global kEnumSubTypeDict
    global kExpectedCustomPickledFormat
    global kExpectedSystemPickledFormat
    global kMdcConfigCustomPickledAbsFileName
    global kMdcConfigCustomVariableList
    global kMdcConfigSystemPickledAbsFileName
    global kMdcConfigSystemVariableList
    global kRelationshipSetIdToRelationshipListDict
    global kServProvSchemaVersionToRequiredSystemSchemaVersionDict
    global mdcDebug
    global THE_MDC_DESCRIPTOR_INDEX
    global THE_MDC_DESCRIPTOR_INDEX_LIST
    #
    expectedPickledFormat = kExpectedSystemPickledFormat
    mdcConfigPickledAbsFileName = kMdcConfigSystemPickledAbsFileName
    fileType = 'system'
    if (not systemFileFlag):
        expectedPickledFormat = kExpectedCustomPickledFormat
        mdcConfigPickledAbsFileName = kMdcConfigCustomPickledAbsFileName
        fileType = 'custom'
        #
    # The expectedPickledFormat value indicates which variables and the order in which they are stored in the file.
    # This needs to be incremented any time the variables or the objects they contain change.
    if (not os.path.exists(mdcConfigPickledAbsFileName)):
        printErrorMsg('Missing file: ' + mdcConfigPickledAbsFileName)
        sys.exit(1)
    #
    # We need to load all of the information in the same order that it was created. This is indicated
    # by the "expectedPickledFormat". This value needs to be changed when either variables are added/removed or
    # the order is changed or the format of the object change.
    mdcConfigPickleFile = open(mdcConfigPickledAbsFileName, 'rb')
    pickledFormat = pickle.load(mdcConfigPickleFile)
    if (pickledFormat != expectedPickledFormat):
        printWarningMsg('The file: ' + mdcConfigPickledAbsFileName +
            ' has an unexpected version (' + str(pickledFormat) +
            '), expected (' + str(expectedPickledFormat) + '). Removing this file.')
        mdcConfigPickleFile.close()
        os.remove(mdcConfigPickledAbsFileName)
        return
    #
    schemaVersion = pickle.load(mdcConfigPickleFile)
    if (mdcDebug):
        printDebugMsg('Loading ' + fileType + ' data containers with schema version ' +
            str(schemaVersion) + ' from file: ' + mdcConfigPickledAbsFileName)
    #
    # Since we have two files (system and custom) we need to merge the info from this pickled file into our variables.
    #
    # Handle kDataContainerKeyToIdDictionary
    tempDictionary = pickle.load(mdcConfigPickleFile)
    # Instead of blindly updating our variable with this information, we will make sure we
    # only add the appropriate keys
    for key in sorted(tempDictionary.keys()):
        if (systemFileFlag):
            # Don't include negative values.
            if (key < 0):
                continue
        else:
            # Don't include positive values
            if (key >= 0):
                # We break here because the list is sorted.
                break
        kDataContainerKeyToIdDictionary[key] = tempDictionary[key]
    #
    # Handle the kDataContainerKeyToSpecDictionary
    tempDictionary = pickle.load(mdcConfigPickleFile)
    # Instead of blindly updating our variable with this information, we will make sure we
    # only add the appropriate keys
    for key in sorted(tempDictionary.keys()):
        if (systemFileFlag):
            # Don't include negative values.
            if (key < 0):
                continue
        else:
            # Don't include positive values
            if (key >= 0):
                # We break here because the list is sorted.
                break
        kDataContainerKeyToSpecDictionary[key] = tempDictionary[key]
    # Update kDataContainerSpecSystemSchemaVersion or kDataContainerSpecServProvSchemaVersion
    if (systemFileFlag):
        kDataContainerSpecSystemSchemaVersion = schemaVersion
    else:
        kDataContainerSpecServProvSchemaVersion = schemaVersion
    #
    # Handle the THE_MDC_DESCRIPTOR_INDEX
    tempMdcDescIndex = pickle.load(mdcConfigPickleFile)
    if (THE_MDC_DESCRIPTOR_INDEX is None):
        THE_MDC_DESCRIPTOR_INDEX = tempMdcDescIndex
    else:
        THE_MDC_DESCRIPTOR_INDEX.updateFrom(tempMdcDescIndex, systemFileFlag)
    #
    # Handle the THE_MDC_DESCRIPTOR_INDEX_LIST
    THE_MDC_DESCRIPTOR_INDEX_LIST = DataContainerDescriptorIndexList()
    #
    # Handle the kMdcConfigSystemVariableList/kMdcConfigCustomVariableList
    if (systemFileFlag):
        kMdcConfigSystemVariableList = pickle.load(mdcConfigPickleFile)
    else:
        kMdcConfigCustomVariableList = pickle.load(mdcConfigPickleFile)
    #
    # NOTE: We need to update all of the variables that are system MDC descriptors to have this correct
    #   servProvSchemaVersion. This is needed because we create these variables when there is no
    #   custom MDCs and thus the DataContainerDescriptor values all have a servProvSchemaVersion of 0.
    newMdcConfigSystemVariableList = []
    reMdcDescVar = re.compile(r'k(.*)MdcDesc')
    for (variableName, variableValue) in kMdcConfigSystemVariableList:
        match = reMdcDescVar.match(variableName)
        if (not match):
            newMdcConfigSystemVariableList.append((variableName, variableValue))
            continue
        containerId = match.group(1)
        mdcDesc = THE_MDC_DESCRIPTOR_INDEX.get(containerId)
        newMdcConfigSystemVariableList.append((variableName, mdcDesc))
    #
    kMdcConfigSystemVariableList = newMdcConfigSystemVariableList
    #
    if (systemFileFlag):
        kRelationshipSetIdToRelationshipListDict = pickle.load(mdcConfigPickleFile)
        # Version 4 has kEnumSubTypeDict
        kEnumSubTypeDict = pickle.load(mdcConfigPickleFile)
    else:
        kServProvSchemaVersionToRequiredSystemSchemaVersionDict = pickle.load(mdcConfigPickleFile)
    #
    # NOTE: The code that exposes all of the variables in kMdcConfigSystemVariableList and the
    #   kMdcConfigCustomVariableList is done by data_container_defs.py.
    mdcConfigPickleFile.close()
    return
#
#=======================================================================================================================
#
def parseAllDataContainerRelationshipXmlFiles():
    ''' This function finds all of the XML files in the kDataContainerRelationshipDirName
        directory and calls parseDataContainerRelationshipXmlFile() for each file found.
    '''
    global kDataContainerRelationshipDirName
    global mdcDebugParsing
    #
    for foundFileName in os.listdir(kDataContainerRelationshipDirName):
        relationshipType = foundFileName
        foundAbsFileName = kDataContainerRelationshipDirName + '/' + foundFileName
        if (not os.path.isdir(foundAbsFileName)):
            # This is a file
            # We ignore all files found in this directory.
            continue
        # Here it is a directory
        foundAbsFileNameSlash = foundAbsFileName + '/'
        foundSubDirFileNameList = os.listdir(foundAbsFileNameSlash)
        for foundSubDirFileName in foundSubDirFileNameList:
            # There should be nothing here except our xml files.
            if (not foundSubDirFileName.endswith('.xml')):
                continue
            foundSubDirAbsFileName = foundAbsFileNameSlash + foundSubDirFileName
            if (mdcDebugParsing):
                printDebugMsg('Processing: foundSubDirAbsFileName=' + foundSubDirAbsFileName)
            #
            parseDataContainerRelationshipXmlFile(relationshipType, foundSubDirAbsFileName)
        #
    #
    # We need to add an element for 'mdc_customization_type' because it is only for private MDCs.
    if ('mdc_customization_type' not  in kRelationshipSetIdToRelationshipListDict):
        kRelationshipSetIdToRelationshipListDict['mdc_customization_type'] = []
#
#=======================================================================================================================
#
def parseAllDataContainerSubTypeXmlFiles():
    ''' This function finds all of the XML files in the kDataContainerSubTypeDirName
        directory and calls parseDataContainerSubTypeXmlFile() for each file found.
    '''
    global kDataContainerSubTypeDirName
    global mdcDebugParsing
    #
    for foundFileName in os.listdir(kDataContainerSubTypeDirName):
        # There should be nothing here except our xml files.
        if (not foundFileName.endswith('.xml')):
            continue
        foundAbsFileName = kDataContainerSubTypeDirName + '/' + foundFileName
        if (mdcDebugParsing):
            printDebugMsg('Processing: foundAbsFileName=' + foundAbsFileName)
        #
        parseDataContainerSubTypeXmlFile(foundAbsFileName)
    #
#
#=======================================================================================================================
#
def parseAllDataContainerXmlFiles():
    ''' This function finds all of the XML files in the kDataContainerDirName
        directory and calls parseDataContainerXmlFile() for each file found.
    '''
    global kDataContainerDirName
    global mdcDebugParsing
    global THE_MDC_DESCRIPTOR_INDEX
    global THE_MDC_DESCRIPTOR_INDEX_LIST
    #
    for foundFileName in os.listdir(kDataContainerDirName):
        foundAbsFileName = kDataContainerDirName + '/' + foundFileName
        if (not os.path.isdir(foundAbsFileName)):
            # This is a file
            # We ignore all files found in this directory.
            continue
        # Here it is a directory
        foundAbsFileNameSlash = foundAbsFileName + '/'
        foundSubDirFileNameList = os.listdir(foundAbsFileNameSlash)
        for foundSubDirFileName in foundSubDirFileNameList:
            # There should be nothing here except our xml files.
            if (not foundSubDirFileName.endswith('.xml')):
                continue
            foundSubDirAbsFileName = foundAbsFileNameSlash + foundSubDirFileName
            if (mdcDebugParsing):
                printDebugMsg('Processing: foundSubDirAbsFileName=' + foundSubDirAbsFileName)
            #
            parseDataContainerXmlFile(foundSubDirAbsFileName)
    #
    # Now create the default system data.
    THE_MDC_DESCRIPTOR_INDEX = DataContainerDescriptorIndex(0, 0)
    THE_MDC_DESCRIPTOR_INDEX_LIST = DataContainerDescriptorIndexList()
#
#=======================================================================================================================
#
def parseDataContainerRelationshipXmlFile(dataContainerRelationshipId, fileName):
    ''' This function parses the passed XML file name and adds all of the
        data container relationships found in each file. Each new data container relationship is added
        to the kRelationshipSetIdToRelationshipListDict.

    The parameters are:

    fileName - this is the name of the XML file to process.
    '''
    global kDataContainerIdToKeyDictionary
    global kRelationshipSetIdToRelationshipListDict
    global mdcDebugParsing
    #
    if (mdcDebugParsing):
        printDebugMsg('Processing: dataContainerRelationshipId=' + dataContainerRelationshipId +
            ', fileName=' + fileName)
    #
    # parse this using a minidom
    try:
        dom = xml.dom.minidom.parse(fileName)
    except IOError:
        printErrorMsg('cannot parse ' + fileName)
        sys.exit(1)
    #
    relationshipNodeList = dom.getElementsByTagName('relationship')
    relationshipList = []
    for relationshipNode in relationshipNodeList:
        sourceDataContainerId = relationshipNode.getAttribute('id')
        #
        if (sourceDataContainerId not in kDataContainerIdToKeyDictionary):
            printErrorMsg('the container_relationship ID (' + dataContainerRelationshipId +
                ') has a relationship (' + sourceDataContainerId +
                ') that does not match the name of an existing data container. Found in the file: ' +
                os.path.basename(fileName))
            sys.exit(1)

        targetDataContainerId = getValue(relationshipNode, 'target_container')
        #
        if (targetDataContainerId not in kDataContainerIdToKeyDictionary):
            printErrorMsg('the target_container (' + targetDataContainerId +
                ') does not match the name of an existing data container. Found in the file: ' +
                os.path.basename(fileName))
            sys.exit(1)
        #
        restServiceList = []
        restServiceNodeList = relationshipNode.getElementsByTagName('REST_service')
        for restServiceNode in restServiceNodeList:
            restServiceName = getValue(restServiceNode, 'name')
            restServiceDescription = getValue(restServiceNode, 'description')
            restServiceClass = getValue(restServiceNode, 'class')
            restServiceUrl = getValue(restServiceNode, 'url')
            restServiceMethod = getValue(restServiceNode, 'method')
            mappingList = []
            restServiceMappingNodeList = restServiceNode.getElementsByTagName('mapping')
            for restServiceMappingNode in restServiceMappingNodeList:
                mappingList.append(restServiceMappingNode.childNodes[0].data)
            patchList = []
            restServicePatchNodeList = restServiceNode.getElementsByTagName('patch')
            for restServicePatchNode in restServicePatchNodeList:
                patchList.append(restServicePatchNode.childNodes[0].data)
            #
            calloutStatementList = getValueList(restServiceNode, 'callout_statement')
            calloutJsonList = getValueList(restServiceNode, 'callout_json')
            calloutXmlList = getValueList(restServiceNode, 'callout_xml')
            calloutMethodList = getValueList(restServiceNode, 'callout_method')
            calloutClassList = getValueList(restServiceNode, 'callout_class')
            filterStrList = getValueList(restServiceNode, 'filter')
            #
            urlParamList = []
            restServiceUrlParamNodeList = restServiceNode.getElementsByTagName('url_param')
            for restServiceUrlParamNode in restServiceUrlParamNodeList:
                urlParamDescription = getValue(restServiceUrlParamNode, 'description')
                urlParamName = getValue(restServiceUrlParamNode, 'name')
                urlParamType = getValue(restServiceUrlParamNode, 'type')
                urlParam = UrlParam(urlParamDescription, urlParamName, urlParamType)
                if (mdcDebugParsing):
                    printDebugMsg('adding ' + str(urlParam))
                urlParamList.append(urlParam)
            #
            requestParamList = []
            restServiceRequestParamNodeList = restServiceNode.getElementsByTagName('request_param')
            for restServiceRequestParamNode in restServiceRequestParamNodeList:
                requestParamDescription = getValue(restServiceRequestParamNode, 'description')
                requestParamName = getValue(restServiceRequestParamNode, 'name')
                requestParamType = getValue(restServiceRequestParamNode, 'type')
                requestParamUse = getValue(restServiceRequestParamNode, 'use')
                requestParam = RequestParam(requestParamDescription, requestParamName,
                    requestParamType, requestParamUse)
                if (mdcDebugParsing):
                    printDebugMsg('adding ' + str(requestParam))
                requestParamList.append(requestParam)
            #
            metaDataList = []
            restServiceMetaDataNodeList = restServiceNode.getElementsByTagName('metadata')
            for restServiceMetaDataNode in restServiceMetaDataNodeList:
                metaDataName = getValue(restServiceMetaDataNode, 'name')
                metaDataType = getValue(restServiceMetaDataNode, 'type')
                metaDataValue = getValue(restServiceMetaDataNode, 'value')
                metaData = MetaData(metaDataName, metaDataType, metaDataValue)
                if (mdcDebugParsing):
                    printDebugMsg('adding ' + str(metaData))
                metaDataList.append(metaData)
            #
            restService = RestService(
                restServiceName,
                restServiceDescription,
                restServiceClass,
                restServiceUrl,
                restServiceMethod,
                mappingList,
                patchList,
                calloutStatementList,
                calloutJsonList,
                calloutXmlList,
                calloutMethodList,
                calloutClassList,
                filterStrList,
                urlParamList,
                requestParamList,
                metaDataList)
            if (mdcDebugParsing):
                printDebugMsg('adding ' + str(restService))
            restServiceList.append(restService)
            #
        # end of for restServiceNode in restServiceNodeList
        #
        relationship = Relationship(
            sourceDataContainerId,
            targetDataContainerId,
            restServiceList)
        if (mdcDebugParsing):
            printDebugMsg('adding ' + str(relationship))
        relationshipList.append(relationship)
    # end of for relationshipNode in relationshipNodeList
    if dataContainerRelationshipId in kRelationshipSetIdToRelationshipListDict:
        kRelationshipSetIdToRelationshipListDict[dataContainerRelationshipId].extend(relationshipList)
    else:
        kRelationshipSetIdToRelationshipListDict[dataContainerRelationshipId] = relationshipList
#
#=======================================================================================================================
#
def parseDataContainerSubTypeXmlFile(fileName):
    ''' This function parses the passed XML file name and adds all of the
        data container subtypes found in each file. Each new data container subtype is added
        to the kEnumSubTypeDict.

    The parameters are:

    fileName - this is the name of the XML file to process.
    '''
    global kEnumSubTypeDict
    global mdcDebugParsing
    #
    if (mdcDebugParsing):
        printDebugMsg('Processing: fileName=' + fileName)
    #
    # parse this using a minidom
    try:
        dom = xml.dom.minidom.parse(fileName)
    except IOError:
        printErrorMsg('cannot parse ' + fileName)
        sys.exit(1)
    #
    subTypeNodeList = dom.getElementsByTagName('subtype')
    for subTypeNode in subTypeNodeList:
        # Example:
        # <subtype id='PriceLoaderAttributeDefinitionDataType'>
        #     <datatype>unsigned int32</datatype>
        #     <value id='0'>decimal</value>
        #     <value id='1'>int32</value>
        #     <value id='2'>int64</value>
        # </subtype>
        subTypeId = subTypeNode.getAttribute('id')
        if (mdcDebugParsing):
            printDebugMsg('Processing: subTypeId=' + subTypeId)
        #
        # NOTE: The subtype ID (plus '.xml') MUST match the basename of the file.
        subTypeIdXml = subTypeId + '.xml'
        if (subTypeIdXml != os.path.basename(fileName)):
            printErrorMsg('the subtype ID (' + subTypeId + ') does not match ' + \
                'the name of the file: ' + os.path.basename(fileName))
            sys.exit(1)
        #
        if (subTypeId in kEnumSubTypeDict):
            printErrorMsg('Duplicated subtype ID (' + subTypeId + ') found.')
        #
        # datatype is currently not used.
        subTypeDataTypeStr = getValue(subTypeNode, 'datatype')
        # Gather the list of values
        stringToEnumTupleList = []
        for valueNode in subTypeNode.getElementsByTagName('value'):
            enumInteger = int(valueNode.getAttribute('id'))
            enumString = valueNode.childNodes[0].data
            if (mdcDebugParsing):
                printDebugMsg('subtype id=' + subTypeId +
                    ': adding subTypeDataTypeStr=' + subTypeDataTypeStr +
                    ', enumInteger=' + str(enumInteger) +
                    ', enumString=' + str(enumString))
            #
            stringToEnumTupleList.append((enumString, enumInteger))
            # The ctor for EnumSubType will check for duplicates
        #
        kEnumSubTypeDict[subTypeId] = EnumSubType(subTypeId, subTypeDataTypeStr, stringToEnumTupleList)
        #
    #
#
#=======================================================================================================================
#
def parseDataContainerXmlFile(fileName):
    ''' This function parses the passed XML file name and adds all of the
        data containers found in each file. Each new data container is added
        to the kDataContainerIdToKeyDictionary, kDataContainerKeyToIdDictionary,
        and the kDataContainerKeyToSpecDictionary. This function may also update
        kDataContainerSpecSystemSchemaVersion or kDataContainerSpecServProvSchemaVersion.

    The parameters are:

    fileName - this is the name of the XML file to process.
    '''
    global kDataContainerIdToKeyDictionary
    global kDataContainerKeyToIdDictionary
    global kDataContainerKeyToSpecDictionary
    global kDataContainerSpecServProvSchemaVersion
    global kDataContainerSpecSystemSchemaVersion
    global kServProvSchemaVersionToRequiredSystemSchemaVersionDict
    global mdcDebugParsing
    #
    if (mdcDebugParsing):
        printDebugMsg('Processing: fileName=' + fileName)
    #
    # parse this using a minidom
    try:
        dom = xml.dom.minidom.parse(fileName)
    except IOError:
        printErrorMsg('cannot parse ' + fileName)
        sys.exit(1)
    #
    # Get the ServProvSchemaVersion to Required System Schema Version info
    servProvSchemaVersionNodeList = dom.getElementsByTagName('private_schema_version')
    for servProvSchemaVersionNode in servProvSchemaVersionNodeList:
        servProvSchemaVersion = int(servProvSchemaVersionNode.getAttribute('id'))
        requiredSystemSchemaVersion = int(getValue(servProvSchemaVersionNode, 'required_system_schema_version'))
        kServProvSchemaVersionToRequiredSystemSchemaVersionDict[servProvSchemaVersion] = \
            requiredSystemSchemaVersion
    #
    containerNodeList = dom.getElementsByTagName('container')
    for containerNode in containerNodeList:
        dataContainerSpec = DataContainerSpec(containerNode)
        containerKey = int(dataContainerSpec.key)
        #
        # Figure out the max schema version. It is the max of:
        #    the data container's createdSchemaVersion
        #    the data container's deletedSchemaVersion
        #    all of the data container's fields' createdSchemaVersion
        #    all of the data container's fields' deletedSchemaVersion
        createdSchemaVersion = dataContainerSpec.createdSchemaVersion
        deletedSchemaVersion = dataContainerSpec.deletedSchemaVersion
        if (containerKey >= 0):
            if (createdSchemaVersion > kDataContainerSpecSystemSchemaVersion):
                kDataContainerSpecSystemSchemaVersion = createdSchemaVersion
            if (deletedSchemaVersion > kDataContainerSpecSystemSchemaVersion):
                kDataContainerSpecSystemSchemaVersion = deletedSchemaVersion
        else:
            if (createdSchemaVersion > kDataContainerSpecServProvSchemaVersion):
                kDataContainerSpecServProvSchemaVersion = createdSchemaVersion
            if (deletedSchemaVersion > kDataContainerSpecServProvSchemaVersion):
                kDataContainerSpecServProvSchemaVersion = deletedSchemaVersion
        #
        for fieldSpec in dataContainerSpec.fieldSpecList:
            createdSchemaVersion = fieldSpec.createdSchemaVersion
            deletedSchemaVersion = fieldSpec.deletedSchemaVersion
            if (containerKey >= 0):
                if (createdSchemaVersion > kDataContainerSpecSystemSchemaVersion):
                    kDataContainerSpecSystemSchemaVersion = createdSchemaVersion
                if (deletedSchemaVersion > kDataContainerSpecSystemSchemaVersion):
                    kDataContainerSpecSystemSchemaVersion = deletedSchemaVersion
            else:
                if (createdSchemaVersion > kDataContainerSpecServProvSchemaVersion):
                    kDataContainerSpecServProvSchemaVersion = createdSchemaVersion
                if (deletedSchemaVersion > kDataContainerSpecServProvSchemaVersion):
                    kDataContainerSpecServProvSchemaVersion = deletedSchemaVersion
            #
        #
        # NOTE: For system data containers, the container name (plus '.xml') MUST match the basename of the file.
        containerId = dataContainerSpec.containerId
        containerIdXml = containerId + '.xml'
        if (containerKey >= 0):
            if (containerIdXml != os.path.basename(fileName)):
                printErrorMsg('the data container ID (' + containerId + ') does not match ' +
                    'the name of the file: ' + os.path.basename(fileName))
                sys.exit(1)
        #
        if (dataContainerSpec.containerId in kDataContainerIdToKeyDictionary):
            printErrorMsg('Duplicated data container ID (' + dataContainerSpec.containerId +
                ') found. File name=' + fileName)
            sys.exit(1)
        #
        # Check for duplicate keys
        if (containerKey in kDataContainerKeyToIdDictionary):
            printErrorMsg('the data container ID (' + containerId + ') has a duplicate key (' +
                str(containerKey) + ') value. The other data container name is (' +
                kDataContainerKeyToIdDictionary[containerKey] + '). File name=' + fileName)
            sys.exit(1)
        #
        kDataContainerKeyToIdDictionary[containerKey] = containerId
        # NOTE: a duplicate name cannot happen since we already checked that the file name matches the name.
        kDataContainerIdToKeyDictionary[containerId] = containerKey
        kDataContainerKeyToSpecDictionary[containerKey] = dataContainerSpec
        #
    #
#
#=======================================================================================================================
#
def printCmdResultMsg(result, cmd):
    ''' This function can be used to print the command and its result in a banner.

    The parameters are:

    result  - this is the result code returned from the command.

    cmd     - this is the command.
    '''
    printMsg('************************************************')
    printMsg('Error (' + str(result) + ') returned from command: ' + cmd)
    printMsg('current dir - ' + os.path.abspath('.'))
    printMsg('************************************************')
#
#=======================================================================================================================
#
def printDebugMsg(text, caller=None):
    ''' This function can be used to print debug messages.

    The parameters are:

    text    - this is the debug message.

    caller  - if specified, caller is used to specify the name of the calling
              function. By default this gets figured out, but if another print
              function is calling this one, we don't want that print function to
              show up as the caller.
    '''
    global kPrintDebugMsgPrefix
    #
    # Note: saving the frame and then referencing it is a lot faster than calling
    # inspect.stack()[1][3] and inspect.stack()[1][2]. In one test, the time to
    # call inspect.stack() twice took 2m16s. The change to save the frame and use it took 1m8s.
    frame = inspect.stack()[1]
    try:
        if (caller is None):
            # Do we have a class name?
            if ('self' in frame[0].f_locals):
                caller = frame[0].f_locals['self'].__class__.__name__ + '::' + frame[3]
            else:
                caller = frame[3]
            #
        lineNumber = frame[2]
        printMsg(kPrintDebugMsgPrefix + caller + ':' + str(lineNumber) + ': ' + text)
    finally:
        del frame
#
#=======================================================================================================================
#
def printErrorMsg(text, caller=None):
    ''' This function can be used to print error messages.

    The parameters are:

    text    - this is the error message.

    caller  - if specified, caller is used to specify the name of the calling
              function. By default this gets figured out, but if another print
              function is calling this one, we don't want that print function to
              show up as the caller.
    '''
    global kPrintErrorMsgPrefix
    #
    # Note: saving the frame and then referencing it is a lot faster than calling
    # inspect.stack()[1][3] and inspect.stack()[1][2]. In one test, the time to
    # call inspect.stack() twice took 2m16s. The change to save the frame and use it took 1m8s.
    frame = inspect.stack()[1]
    try:
        if (caller is None):
            # Do we have a class name?
            if ('self' in frame[0].f_locals):
                caller = frame[0].f_locals['self'].__class__.__name__ + '::' + frame[3]
            else:
                caller = frame[3]
            #
        printMsg(kPrintErrorMsgPrefix + caller + ': ' + text)
    finally:
        del frame
#
#=======================================================================================================================
#
def printInfoMsg(text, caller=None):
    ''' This function can be used to print info messages.

    The parameters are:

    text    - this is the info message.

    caller  - if specified, caller is used to specify the name of the calling
              function. By default this gets figured out, but if another print
              function is calling this one, we don't want that print function to
              show up as the caller.
    '''
    global kPrintInfoMsgPrefix
    #
    # Note: saving the frame and then referencing it is a lot faster than calling
    # inspect.stack()[1][3] and inspect.stack()[1][2]. In one test, the time to
    # call inspect.stack() twice took 2m16s. The change to save the frame and use it took 1m8s.
    frame = inspect.stack()[1]
    try:
        if (caller is None):
            # Do we have a class name?
            if ('self' in frame[0].f_locals):
                caller = frame[0].f_locals['self'].__class__.__name__ + '::' + frame[3]
            else:
                caller = frame[3]
            #
        printMsg(kPrintInfoMsgPrefix + caller + ': ' + text)
    finally:
        del frame
#
#=======================================================================================================================
#
def printInternalValues():
    global kDataContainerKeyToIdDictionary
    global kDataContainerKeyToSpecDictionary
    global kDataContainerSpecServProvSchemaVersion
    global kDataContainerSpecSystemSchemaVersion
    global kEnumSubTypeDict
    global kRelationshipSetIdToRelationshipListDict
    #
    printMsg('kDataContainerSpecSystemSchemaVersion=' + str(kDataContainerSpecSystemSchemaVersion))
    printMsg('kDataContainerSpecServProvSchemaVersion=' + str(kDataContainerSpecServProvSchemaVersion))
    printMsg('kDataContainerKeyToIdDictionary=')
    # pylint: disable=consider-iterating-dictionary
    for containerKey in sorted(kDataContainerKeyToIdDictionary.keys()):
        containerId = kDataContainerKeyToIdDictionary[containerKey]
        printMsg('    %6d -> %-s' % (containerKey, containerId))
    #
    printMsg('kDataContainerKeyToSpecDictionary=')
    # pylint: disable=consider-iterating-dictionary
    for containerKey in sorted(kDataContainerKeyToSpecDictionary.keys()):
        spec = kDataContainerKeyToSpecDictionary[containerKey]
        specStr = spec.printStr(indentStr='             ', indentFirstLine=False)
        printMsg('    %6d -> %-s' % (containerKey, specStr))
    #
    printMsg('kEnumSubTypeDict=')
    # pylint: disable=consider-iterating-dictionary
    for subTypeId in sorted(kEnumSubTypeDict.keys()):
        enumSubTypeObj = kEnumSubTypeDict[subTypeId]
        printMsg(str(enumSubTypeObj))
    #
    printMsg('kRelationshipSetIdToRelationshipListDict=')
    # pylint: disable=consider-iterating-dictionary
    for relationshipSetId in sorted(kRelationshipSetIdToRelationshipListDict.keys()):
        relationshipList = kRelationshipSetIdToRelationshipListDict[relationshipSetId]
        printMsg('    ' + relationshipSetId)
        for relationship in relationshipList:
            relationshipStr = relationship.printStr(indentStr='             ', indentFirstLine=True)
            print(relationshipStr)
        #
    #
    printMsg('THE_MDC_DESCRIPTOR_INDEX=' + str(THE_MDC_DESCRIPTOR_INDEX))
#
#=======================================================================================================================
#
def printMsg(text):
    ''' This function can be used to print a plain message.

    The parameters are:

    text    - this is the message.
    '''
    print(text)
#
#=======================================================================================================================
#
def printWarningMsg(text, caller=None):
    ''' This function can be used to print warning messages.

    The parameters are:

    text    - this is the warning message.

    caller  - if specified, caller is used to specify the name of the calling
              function. By default this gets figured out, but if another print
              function is calling this one, we don't want that print function to
              show up as the caller.
    '''
    global kPrintWarningMsgPrefix
    #
    # Note: saving the frame and then referencing it is a lot faster than calling
    # inspect.stack()[1][3] and inspect.stack()[1][2]. In one test, the time to
    # call inspect.stack() twice took 2m16s. The change to save the frame and use it took 1m8s.
    frame = inspect.stack()[1]
    try:
        if (caller is None):
            # Do we have a class name?
            if ('self' in frame[0].f_locals):
                caller = frame[0].f_locals['self'].__class__.__name__ + '::' + frame[3]
            else:
                caller = frame[3]
            #
        printMsg(kPrintWarningMsgPrefix + caller + ': ' + text)
    finally:
        del frame
#
#=======================================================================================================================
#
def readDescriptorTag(inputStr):
    ''' This function will parse the descriptor tag, i.e. the <n,n,...> syntax
        used in the compact format of the data container.

    The parameters are:

    inputStr -  this is the string to be parsed. It represents the fields
                in a data container in compact format.

    returns   - a tuple of four fields.
                The first field is the descriptor key in the tag. This is an
                integer value.
                The second field is the system schema version
                The third field is the service provider schema version
                The fourth field is the remaining string after the descriptor tag.
    '''
    # Read the descriptor tag, i.e. the <1, 0, 0, 26, 4300, 2> syntax
    # We return the descriptorKey and the remaining unparsed string
    descKey = 0
    # Get rid of the '<'
    inputStr = inputStr[1:].lstrip()
    # find the '>'
    endIdx = inputStr.find('>')
    if (endIdx == -1):
        printErrorMsg('Did not find a \'>\' in the passed string.' +
            '\n     : passed string=' + inputStr)
        return descKey, 0, 0, inputStr
    tag = inputStr[0:endIdx]
    # get rid of the spaces
    tag.replace(' ', '')
    tagValues = tag.split(',')
    if (len(tagValues) != 6):
        raise ValueError('readDescriptorTag: Invalid descriptor tag (' + \
            str(inputStr) + '), expecting 6 values inside of the <> characters.')
    descKey = int(tagValues[3])
    systemSchemaVersion = int(tagValues[4])
    servProvSchemaVersion = int(tagValues[5])
    # Bump up to the next token.
    newStr = inputStr[endIdx+1:]
    newStr = newStr.strip()
    return descKey, systemSchemaVersion, servProvSchemaVersion, newStr
#
#=======================================================================================================================
#
def readFromElementBasedXMLStr(inputStr):
    ''' This function will parse an Element XML format string and return a
        DataContainer object.

    The parameters are:

    inputStr -  this is the string to be parsed. It represents the fields
                in a data container in XML format.

    returns   - a DataContainer object or None if the input string is blank or
                an error is detected.
    '''
    global THE_MDC_DESCRIPTOR_INDEX
    global THE_MDC_DESCRIPTOR_INDEX_LIST
    #
    # Convert the input string to an MDC.
    if (inputStr == ''):
        return None

    element = None
    try:
        element = xml.etree.ElementTree.fromstring(inputStr)
    # pylint: disable=W0703
    except Exception as exception:
        printErrorMsg('caught the exception: ' + str(exception) +
            '\nInput XML data: ' + inputStr)
        return None

    containerId = element.tag

    # Get the DataContainerDescriptor
    # TODO Get the schema version. But we need Ed to figure out how to do this.
    descObj = THE_MDC_DESCRIPTOR_INDEX.get(containerId)
    if (descObj is None):
        printErrorMsg('The MDC Descriptor Index could not find an object for a container with id=' + containerId +
            '\nInput XML data: ' + inputStr)
        return None
    # Now create the DataContainer
    retMdc = descObj.create()
    if (retMdc is None):
        printErrorMsg('Unable to create a DataContainer (descId=' + containerId + ')' +
            '\nInput XML data: ' + inputStr)
        return None
    # Now parse the rest of the data
    success = retMdc.readFromElementBasedXML(element)
    if (not success):
        printMsg('MDC up to this point=')
        retMdc.printIt()
        return None
    return retMdc
#
#=======================================================================================================================
#
def readFromElementBasedXMLStruct(xmlStruct, systemSchemaVersion, servProvSchemaVersion):
    ''' This internal function parses the passed XML element object and
        returns a struct MDC.

    This is an internal function.

    The parameters are:

    xmlStruct - this is the XML element object representing the structure

    systemSchemaVersion - This is the schema version to use for the
                system containers and fields. This is an integer.
                This must be provided by the caller because this information
                is not in the struct's element.

    servProvSchemaVersion - This is the schema version to use for the
                Service Provider containers and fields. This is an integer.
                This must be provided by the caller because this information
                is not in the struct's element.

    returns   - a struct MDC object on success. None on failure.
    '''
    global THE_MDC_DESCRIPTOR_INDEX_LIST
    #
    # Get the DataContainerDescriptor
    structName = xmlStruct.tag
    # Get the DataContainerDescriptor
    descIndex = THE_MDC_DESCRIPTOR_INDEX_LIST.getDescriptorIndex(
        systemSchemaVersion, servProvSchemaVersion, addIfNotFound=True)
    structDescObj = descIndex.get(structName)
    #
    # We need to get the descriptor for this struct. If it is
    # unknown, then we can't continue.
    if (structDescObj is None):
        printErrorMsg('The MDC Descriptor Index could not find a struct with name=' + structName +
            '\nOriginal input is=' + xmlStruct.toxml())
        return None
    structMdc = structDescObj.create()
    success = structMdc.readFromElementBasedXML(xmlStruct)
    if (not success):
        return None
    return structMdc
#
#=======================================================================================================================
#
def readFromStr(inputStr):
    ''' This function will parse a compact or XML format string and return a
        DataContainer object.

    The parameters are:

    inputStr -  this is the string to be parsed. It represents the fields
                in a data container in compact format.

    returns   - a DataContainer object or None if the input string is blank or
                an error is detected.
    '''
    global THE_MDC_DESCRIPTOR_INDEX_LIST
    #
    # remove leading and trailing blanks
    # returns a DataContainer
    if (inputStr == ''):
        return None
    origInputStr = inputStr
    inputStr = inputStr.strip()
    if (inputStr == ''):
        return None
    dataIsXml = False
    #
    # Check if this starts with a '<'. If it does, then could be
    # either the XML format or it could be the self-describing
    # format that contains the header. Both of which defines
    # DataContainerDescriptor to use.
    if (inputStr[0] != LESS_THAN):
        printErrorMsg("The input string is not valid. Looking for a line that starts with a '<'" + \
            '\n    Original data is=' + origInputStr + \
            '\n    Current  data is=' + inputStr)
        return None
    if (inputStr.startswith('<container')):
        dataIsXml = True
    if (dataIsXml):
        return readFromXMLStr(inputStr)
    #
    # Non-xml format
    #
    descKey, systemSchemaVersion, servProvSchemaVersion, inputStr = readDescriptorTag(inputStr)
    if (descKey == 0):
        printErrorMsg('Line is not valid. readDescriptorTag returned a 0.' + \
            '\n    Original data is=' + origInputStr + \
            '\n    Current  data is=' + inputStr)
        return None

    # Get the DataContainerDescriptor
    descIndex = THE_MDC_DESCRIPTOR_INDEX_LIST.getDescriptorIndex(
        systemSchemaVersion, servProvSchemaVersion, addIfNotFound=True)
    descObj = descIndex.getByKey(descKey)
    if (descObj is None):
        printErrorMsg('Line is not valid. readDescriptorTag returned an invalid descKey (' + \
            str(descKey) + ')' + \
            '\n    Original data is=' + origInputStr + \
            '\n    Current  data is=' + inputStr)
        return None
    # Now create the DataContainer
    retMdc = descObj.create()
    if (retMdc is None):
        printErrorMsg('Unable to create a DataContainer (descKey=' + str(descKey) + ')' + \
            '\n    Original data is=' + origInputStr + \
            '\n    Current  data is=' + inputStr)
        return None
    # Now parse the rest of the data
    try:
        success, inputStr = retMdc.readFrom(inputStr)
        # Fall through
    except Exception:
        printErrorMsg('caught an exception:' + \
            '\n    while parsing the string:' + inputStr)
        raise
    if (not success):
        printMsg('    MDC up to this point=')
        retMdc.printIt()
        return None
    return retMdc
#
#=======================================================================================================================
#
def readFromXMLStr(inputStr):
    ''' This function will parse an XML format string and return a
        DataContainer object.

    The parameters are:

    inputStr -  this is the string to be parsed. It represents the fields
                in a data container in XML format.

    returns   - a DataContainer object or None if the input string is blank or
                an error is detected.
    '''
    global THE_MDC_DESCRIPTOR_INDEX_LIST
    #
    # Convert the input string (in the XML format) to an MDC.
    # remove leading and trailing blanks
    # returns a DataContainer
    if (inputStr == ''):
        return None
    origInputStr = inputStr
    inputStr = inputStr.strip()
    if (inputStr == ''):
        return None
    # Check if this starts with a '<'. If it does, then could be
    # either the XML format or it could be the self-describing
    # format that contains the header. Both of which defines
    # DataContainerDescriptor to use.
    if (inputStr[0] != LESS_THAN):
        printErrorMsg("Line is not valid. Looking for a line that starts with a '<'" +
            '\nOriginal data is=' + origInputStr +
            '\nCurrent  data is=' + inputStr)
        return None
    if (not inputStr.startswith('<container')):
        return None

    document = None
    try:
        document = xml.dom.minidom.parseString(inputStr)
    # pylint: disable=W0703
    except Exception as exception:
        printErrorMsg('caught the exception: ' + str(exception) +
            '\nOriginal data is=' + origInputStr +
            '\nCurrent  data is=' + inputStr)
        return None
    element = document.documentElement
    if (not element.hasAttribute('name')):
        document.unlink()
        printErrorMsg('Could not find container name in XML.' +
            '\nOriginal data is=' + inputStr)
        return None

    containerId = element.getAttribute('name')
    systemSchemaVersion = int(element.getAttribute('system_schema'))
    servProvSchemaVersion = int(element.getAttribute('service_provider_schema'))
    # Get the DataContainerDescriptor
    descIndex = THE_MDC_DESCRIPTOR_INDEX_LIST.getDescriptorIndex(
        systemSchemaVersion, servProvSchemaVersion, addIfNotFound=True)
    descObj = descIndex.get(containerId)
    if (descObj is None):
        document.unlink()
        printErrorMsg('The MDC Descriptor Index could not find an object for a container with id=' + containerId +
            '\nOriginal data is=' + inputStr)
        return None
    # Now create the DataContainer
    retMdc = descObj.create()
    if (retMdc is None):
        document.unlink()
        printErrorMsg('Unable to create a DataContainer (descId=' + containerId + ')' +
            '\nOriginal data is=' + inputStr)
        return None
    # Now parse the rest of the data
    success = retMdc.readFromXML(element)
    if (not success):
        document.unlink()
        printMsg('MDC up to this point=')
        retMdc.printIt()
        return None
    document.unlink()
    return retMdc
#
#=======================================================================================================================
#
def readFromXMLStruct(xmlStruct, systemSchemaVersion, servProvSchemaVersion):
    ''' This internal function parses the passed XML element object and
        returns a struct MDC.

    This is an internal function.

    The parameters are:

    xmlStruct - this is the XML element object representing the structure

    systemSchemaVersion - This is the schema version to use for the
                system containers and fields. This is an integer.
                This must be provided by the caller because this information
                is not in the struct's element.

    servProvSchemaVersion - This is the schema version to use for the
                Service Provider containers and fields. This is an integer.
                This must be provided by the caller because this information
                is not in the struct's element.

    returns   - a struct MDC object on success. None on failure.
    '''
    global THE_MDC_DESCRIPTOR_INDEX_LIST
    #
    if (not xmlStruct.hasAttribute('name')):
        printErrorMsg('Could not find name attribute for struct' +
            '\nOriginal input is=' + xmlStruct.toxml())
        return None
    structName = xmlStruct.getAttribute('name')
    # Get the DataContainerDescriptor
    descIndex = THE_MDC_DESCRIPTOR_INDEX_LIST.getDescriptorIndex(
        systemSchemaVersion, servProvSchemaVersion, addIfNotFound=True)
    structDescObj = descIndex.get(structName)
    #
    # We need to get the descriptor for this struct. If it is
    # unknown, then we can't continue.
    if (structDescObj is None):
        printErrorMsg('The MDC Descriptor Index could not find a struct with name=' + structName +
            '\nOriginal input is=' + xmlStruct.toxml())
        return None
    structMdc = structDescObj.create()
    success = structMdc.readFromXML(xmlStruct)
    if (not success):
        return None
    return structMdc
#
#=======================================================================================================================
#
def recvOnly(socketObj, recvFormatType, traceMessages=False):
    ''' This function will receive a packet.

    socketObj - This is the socket object to use.

    recvFormatType- this string indicates the data container format that is
                being received. The possible values are:
                    'COMPACT' - The compact data container format.
                    'XML' - The XML data container format.
                    'RAW' - The raw data container format.

    traceMessages - this is a flag that if True will cause the message
                to be printed.

    returns   - a DataContainer.
    '''
    # Py3 -- the socket generates a sequence of BYTES
    receiveData = b''
    while (len(receiveData) < 4):
        receiveDataSegment = socketObj.recv(4)
        if (not receiveDataSegment):
            # Error on the socket.
            raise RuntimeError('recvOnly(): Socket error detected.')
        receiveData += receiveDataSegment

    unpacker = xdrlib.Unpacker(receiveData)
    length = unpacker.unpack_uint()
    # Get rid of the length field
    receiveData = receiveData[4:]
    length -= 4
    while (len(receiveData) < length):
        remainingLength = length - len(receiveData)
        maxRecvLength = 4096
        if (remainingLength < maxRecvLength):
            maxRecvLength = remainingLength
        receiveDataSegment = socketObj.recv(maxRecvLength)
        if (not receiveDataSegment):
            # Error on the socket.
            raise RuntimeError('recvOnly(): Socket error detected.')
        receiveData += receiveDataSegment

    # Convert BYTES to STR if necessary. Py3 conversion. IanM.
    # TODO: The actual MDC construction code should operate natively on bytes but
    # that is a major change
    receiveData = receiveData.decode('ascii', 'ignore')

    # Convert the response to a data container
    returnedMdc = None
    if (recvFormatType == 'XML'):
        # convert from an XML MDC string
        returnedMdc = readFromXMLStr(receiveData)
    elif (recvFormatType == 'RAW'):
        returnedMdc = receiveData
    else:
        # convert from a COMPACT MDC string
        returnedMdc = readFromStr(receiveData)
    if (traceMessages):
        traceHdr = 'Received\n'
        print(traceHdr + returnedMdc.printStr())
    return returnedMdc
#
#=======================================================================================================================
#
def reportBadData(inputStr, descObj, fieldObj, expectedData):
    ''' This function reports parsing errors.

    This routine will handle an entire list or an entire array or an
    entire struct.

    The parameters are:

    inputStr -  this is the string being parsed. It represents the fields
                in a data container in compact format.

    descObj -   this is the current DataContainerDescriptor being used.
                This must be a DataContainerDescriptor object.

    fieldObj -  this is the field being processed. This must be a
                DataContainerField object. This may be None.

    expectedData -  this is the data that was expected. This is a string.
    '''
    global configFileName
    #
    fieldStr = '\n   Field=NULL'
    if (fieldObj is not None):
        fieldStr = '\n   Field name=' + fieldObj.name + ', dataType=' + fieldObj.getDataTypeStr()
    printErrorMsg('bad/no data' +
        '\n   MDC Descriptor=' + descObj.containerId + fieldStr +
        '\n   Expecting ' + expectedData +
        '\nParsing >>' + inputStr + '<<' +
        '\nConfig file: ' + configFileName)
#
#=======================================================================================================================
#
def send(socketObj, mdc, sendFormatType, recvFormatType, traceMessages=False):
    ''' This function will send the passed packet and return the response.
    packet.

    The parameters are:

    socketObj - This is the socket object to use.

    mdc       - this is the data container to send. It can be either a
                DataContainer or a string (either in compact form or
                in XML form).

    sendFormatType- this string indicates the data container format that is
                being received. The possible values are:
                    'COMPACT' - The compact data container format.
                    'XML' - The XML data container format.
                    'RAW' - The raw data container format.

    recvFormatType- this string indicates the data container format that is
                being received. The possible values are:
                    'COMPACT' - The compact data container format.
                    'XML' - The XML data container format.
                    'RAW' - The raw data container format.

    traceMessages - this is a flag that if True will cause the message
                to be printed.

    returns   - a DiameterPacket response to the message sent.
    '''
    sendOnly(socketObj, mdc, sendFormatType, traceMessages)
    return recvOnly(socketObj, recvFormatType, traceMessages)
#
#=======================================================================================================================
#
def sendOnly(socketObj, mdc, sendFormatType, traceMessages=False):
    ''' This function will send the passed mdc.

    The parameters are:

    socketObj - This is the socket object to use.

    mdc       - this is the data container to send. It can be either a
                DataContainer or a string (either in compact form or
                in XML form).

    sendFormatType- this string indicates the data container format that is
                being received. The possible values are:
                    'COMPACT' - The compact data container format.
                    'XML' - The XML data container format.
                    'RAW' - The raw data container format.

    traceMessages - this is a flag that if True will cause the message
                to be printed.

    returns   - the data sent. This is a string.
    '''
    #
    sendData = None
    # Check if we need to convert to a string.
    if isinstance(mdc, DataContainer):
        # We need to convert this.
        if (sendFormatType == 'XML'):
            # convert to an XML MDC string
            sendData = mdc.printXml()
        else:
            # convert to a COMPACT MDC string
            sendData = mdc.printCompact(True)
    else:
        sendData = mdc

    # Convert STR to BYTES if necessary. Py3 conversion. IanM.
    if not isinstance(sendData, bytes):
        sendData = sendData.encode('ascii', 'ignore')

    sendLength = len(sendData) + 4
    if (traceMessages):
        traceHdr = 'Sending\n'
        print(traceHdr + sendData)
    packedSendLength = struct.pack('>I', int(sendLength))
    socketObj.send(packedSendLength + sendData)
    return sendData
#
#=======================================================================================================================
#
def useSchemaVersion(systemSchemaVersion, servProvSchemaVersion):
    ''' This function will set THE_MDC_DESCRIPTOR_INDEX to be the one
    using the passed values.

    The parameters are:

    systemSchemaVersion - This is the schema version to use for the
                system containers and fields. This is an integer.
                A value of 0 means to use the latest defined value.

    servProvSchemaVersion - This is the schema version to use for the
                Service Provider containers and fields. This is an integer.
                A value of 0 means to use the latest defined value.
    '''
    global THE_MDC_DESCRIPTOR_INDEX
    global THE_MDC_DESCRIPTOR_INDEX_LIST
    #
    THE_MDC_DESCRIPTOR_INDEX = THE_MDC_DESCRIPTOR_INDEX_LIST.getDescriptorIndex(
        systemSchemaVersion, servProvSchemaVersion, addIfNotFound=True)

#=======================================================================================================================

def validateDate(dateStr):
    # Validate the dateStr value of the format: yyyy-mm-dd.
    # Returns a tuple of that consists of two values:
    #    result: True if the dateStr passes the checks. Else False.
    #    dateStr: If result is True, this is the possibly modified dateStr.
    #            The returned dateStr will always have two digits for the month
    #            and two digits for the day.
    #            If result is False, this is the error message.
    global reDate
    dateStr = str(dateStr).strip()
    # Allow an empty dateStr to indicate the current date.
    if (dateStr == ''):
        return (True, dateStr)
    # split the dateStr into parts
    match = reDate.match(dateStr)
    if (not match):
        errorMessage = 'Error: validateDate: expecting 3 values separated by ' + \
            'a - (or any non-digit) of the form YYYY-MM-DD Found "' + dateStr + '"'
        return (False, errorMessage)
    yearVal = int(match.group(1))
    monthVal = int(match.group(2))
    dayVal = int(match.group(3))
    if ((yearVal < 1) or (yearVal > 65535)):
        errorMessage = 'Error: validateDate: year value range is 1 to 65535. Found ' + str(yearVal) + ' in ' +  \
            dateStr
        return (False, errorMessage)
    if ((monthVal < 1) or (monthVal > 12)):
        errorMessage = 'Error: validateDate: month value range is 1 to 12. Found ' + str(monthVal) + ' in ' +  dateStr
        return (False, errorMessage)
    if ((dayVal < 1) or (dayVal > 31)):
        errorMessage = 'Error: validateDate: day value range is 1 to 31. Found ' + str(dayVal) + ' in ' +  dateStr
        return (False, errorMessage)
    # Note: we do it this way because it is faster (see basic_python_perf_test.py)
    if (monthVal < 10):
        if (dayVal < 10):
            returnStr = str(yearVal) + '-0' + str(monthVal) + '-0' + str(dayVal)
            return (True, returnStr)
        else:
            returnStr = str(yearVal) + '-0' + str(monthVal) + '-' + str(dayVal)
            return (True, returnStr)
    else:
        if (dayVal < 10):
            returnStr = str(yearVal) + '-' + str(monthVal) + '-0' + str(dayVal)
            return (True, returnStr)
        else:
            returnStr = str(yearVal) + '-' + str(monthVal) + '-' + str(dayVal)
            return (True, returnStr)

#=======================================================================================================================

def validateDateTime(dateTimeStr):
    # Validate the dateTimeStr value of the format:
    #    yyyy-mm-ddThh:mm:ss[.mmmmmm][UtcOffset]
    # Returns a tuple of that consists of two values:
    #    result: True if the dateTimeStr passes the checks. Else False.
    #    dateTimeStr: If result is True, this is the possibly modified
    #            dateTimeStr. The returned dateTimeStr will always have
    #            two digits for the month, day, hour, minute and seconds.
    #            If any fractional seconds are specified, then this will be
    #            converted to micros (six digits).
    #            If result is False, this is the error message.
    global reDateTime
    dateTimeStr = str(dateTimeStr).strip()
    # Allow an empty dateTimeStr to indicate the current datetime.
    if (dateTimeStr == ''):
        return (True, dateTimeStr)
    match = reDateTime.match(dateTimeStr)
    if (not match):
        errorMessage = 'Error: validateDateTime: expecting 2 values separated by a T (or a non-digit). Found ' + \
            dateTimeStr
        return (False, errorMessage)
    #
    dateVal = match.group(1)
    inTimeTotalStr = match.group(2)
    # First part is the date
    (dateResult, dateStr) = validateDate(dateVal)
    if (not dateResult):
        return (dateResult, dateStr)
    (timeResult, timeStr) = validateTime(inTimeTotalStr)
    if (not timeResult):
        return (timeResult, timeStr)
    #
    returnStr = dateStr + 'T' + timeStr
    return (True, returnStr)

#=======================================================================================================================

def validatePhoneNumber(phoneNumberStr):
    # Validate the phoneNumberStr value.
    # It can contain the characters 0-9, a-f, A-F and have a max length of 15.
    # Returns a tuple of that consists of two values:
    #    result: True if the phoneNumberStr passes the checks. Else False.
    #    phoneNumberStr: If result is True, this is the passed phoneNumberStr.
    #            If result is False, this is the error message.
    global rePhoneNumber
    match = rePhoneNumber.match(phoneNumberStr)
    if (not match):
        errorMessage = 'Error: validatePhoneNumber: expecting 1-15 characters of 0-9, a-f, or A-F. Found "' + \
            phoneNumberStr + '"'
        return (False, errorMessage)
    return (True, phoneNumberStr)

#=======================================================================================================================

def validateTime(timeStr):
    # Validate the timeStr value of the format: hh:mm:ss[.mmmmmm][UtcOffset]
    # Returns a tuple of that consists of two values:
    #    result: True if the timeStr passes the checks. Else False.
    #    timeStr: If result is True, this is the possibly modified timeStr.
    #            The returned timeStr will always have two digits for the hour,
    #            minute, seconds. If any fractional seconds are specified, then
    #            this will be converted to micros (six digits).
    #            If result is False, this is the error message.
    global reTimeUtcOffset
    #
    timeStr = str(timeStr).strip()
    # Allow an empty timeStr to indicate the current time.
    if (timeStr == ''):
        return (True, timeStr)
    # Check if there is a UtcOffset
    match = reTimeUtcOffset.match(timeStr)
    if (not match):
        errorMessage = 'Error: validateTime: expecting a time string format: ' + \
            '<hour>:<minute>:<second>[.mmmmmm][<UTC offset>] and found ' + timeStr
        return (False, errorMessage)
    hourVal = int(match.group(1))
    minuteVal = int(match.group(2))
    secondVal = int(match.group(3))
    # NOTE: micros and UTC offset are optional
    microValStr = match.group(4)
    utcOffsetStr = match.group(5)
    #
    if (microValStr is None):
        microValStr = '.000000'
    # NOTE: The UTC offset is optional!
    # TODO Validate the utcOffsetStr
    if (utcOffsetStr is None):
        utcOffsetStr = ''
    #
    # Validate the micros part
    microValStrLen = len(microValStr)
    if (microValStrLen > 7):
        errorMessage = 'Error: validateTime: expecting a time with the max resolution ' + \
            'of micro-seconds. Found .' + microValStr + ' in ' +  timeStr
        return (False, errorMessage)
    # Make the length of microValStr == 7 (including the leading '.')
    if (microValStrLen < 7):
        microValStr += (7 - microValStrLen) * '0'
    #
    # Validate the hours part
    if ((hourVal < 0) or (hourVal > 23)):
        errorMessage = 'Error: validateTime: hour value range is 0 to 23. ' + \
            'Found ' + str(hourVal) + ' in ' +  timeStr
        return (False, errorMessage)
    #
    # Validate the minutes part
    if ((minuteVal < 0) or (minuteVal > 59)):
        errorMessage = 'Error: validateTime: minute value range is 0 to 59. ' + \
            'Found ' + str(minuteVal) + ' in ' +  timeStr
        return (False, errorMessage)
    #
    # Validate the seconds part
    if ((secondVal < 0) or (secondVal > 59)):
        errorMessage = 'Error: validateTime: second value range is 0 to 59. ' + \
            'Found ' + str(secondVal) + ' in ' +  timeStr
        return (False, errorMessage)
    # It is valid
    # Note: we do it this way because it is faster (see basic_python_perf_test.py)
    if (hourVal < 10):
        if (minuteVal < 10):
            if (secondVal < 10):
                returnStr = '0' + str(hourVal) + ':0' + str(minuteVal) + ':0' + str(secondVal) + \
                    microValStr + utcOffsetStr
                return (True, returnStr)
            else:
                returnStr = '0' + str(hourVal) + ':0' + str(minuteVal) + ':' + str(secondVal) + \
                    microValStr + utcOffsetStr
                return (True, returnStr)
        else:
            if (secondVal < 10):
                returnStr = '0' + str(hourVal) + ':' + str(minuteVal) + ':0' + str(secondVal) + \
                    microValStr + utcOffsetStr
                return (True, returnStr)
            else:
                returnStr = '0' + str(hourVal) + ':' + str(minuteVal) + ':' + str(secondVal) + \
                    microValStr + utcOffsetStr
                return (True, returnStr)
    else:
        if (minuteVal < 10):
            if (secondVal < 10):
                returnStr = str(hourVal) + ':0' + str(minuteVal) + ':0' + str(secondVal) + microValStr + utcOffsetStr
                return (True, returnStr)
            else:
                returnStr = str(hourVal) + ':0' + str(minuteVal) + ':' + str(secondVal) + microValStr + utcOffsetStr
                return (True, returnStr)
        else:
            if (secondVal < 10):
                returnStr = str(hourVal) + ':' + str(minuteVal) + ':0' + str(secondVal) + microValStr + utcOffsetStr
                return (True, returnStr)
            else:
                returnStr = str(hourVal) + ':' + str(minuteVal) + ':' + str(secondVal) + microValStr + utcOffsetStr
                return (True, returnStr)

#=======================================================================================================================

# Initialize the Singletons
if (not path_functions.skipDataContainerInitialization):
    if (not os.path.exists(kMdcConfigSystemPickledAbsFileName)):
        extraMsg = ''
        if (kTopDir):
            # development environment
            extraMsg = '. Please run create_internal_data_container_data.py.'
        printErrorMsg('Missing file: ' + kMdcConfigSystemPickledAbsFileName + extraMsg,
            caller='data_container:initialization:')
        raise RuntimeError('Fatal error: Missing file: ' + kMdcConfigSystemPickledAbsFileName + extraMsg)
    else:
        loadMdcConfigPickledFile(systemFileFlag=True)

if (not path_functions.skipCustomDataContainerInitialization):
    #
    # Skip the load if the mdc_config_custom.pickled file doesn't exist.
    if (os.path.exists(kMdcConfigCustomPickledAbsFileName)):
        loadMdcConfigPickledFile(systemFileFlag=False)
    elif (os.path.exists(kMdcConfigCustomXmlAbsFileName)):
        # Special case. If the mdc_config_custom.pickled file doesn't exist we will check if there is
        # an mdc_config_custom.xml file. This allows Engineers to print an MDC file from a customer that
        # doesn't give us all of the files that we need. For example, they give us the mdc_config_custom.xml file
        # instead of the mdc_config_custom.pickled file.
        #
        # Now we need to read in the config file $MTX_CONF_DIR/mdc_config_custom.xml using the
        # current schema (THE_MDC_DESCRIPTOR_INDEX).
        configFileName = kMdcConfigCustomXmlAbsFileName
        # Add the custom MDCs from the custom XML file.
        parseDataContainerXmlFile(kMdcConfigCustomXmlAbsFileName)
        # Get the latest schema version
        THE_MDC_DESCRIPTOR_INDEX.servProvSchemaVersion = 0
        # Now update THE_MDC_DESCRIPTOR_INDEX with only the custom MDCs.
        THE_MDC_DESCRIPTOR_INDEX.readSpecDictionary(processSystemValues=False)
        #
        # TODO ??? Should we also allow them to give us their pre-5100 mtx_config.xml file?

#=======================================================================================================================
