import http.client, json, logging, base64, ssl, random, traceback
from threading import Thread

from dotmap import DotMap
from mtx.vap.stats import get_stats
from timeit import default_timer as timer
from decimal import Decimal

XIDURL = '/rsgateway/data/json/visible/1/autopay?subscriptionExternalId='
OIDURL = '/rsgateway/data/json/visible/1/autopay?subscriptionObjectId='
XIDTESTURL = '/rsgateway/data/json/visible/1/autopay?testRun=Y&subscriptionExternalId='
OIDTESTURL = '/rsgateway/data/json/visible/1/autopay?testRun=Y&subscriptionObjectId='

RESULT_CODE_MTX_SUCESS = 0
RESULT_CODE_AUTOPAY_SKIP_SUB = -50;
RESULT_CODE_AUTOPAY_SUCCESS_NOTIF_FAIL = -51;
RESULT_CODE_AUTOPAY_FAIL_NOTIF_FAIL = -52;
KEY_OBJID=0
KEY_EXTID=1

class ConnectionError(Exception):
    pass

class Processor(Thread):

    def __init__(self, config, subq, sublogq):
        Thread.__init__(self)
        self.config = config
        self.subq = subq
        self.sublogq = sublogq
        self.testrun = config.testrun
        self.stats = get_stats()
        self.loggingkey = ''

    def open_connections(self):
        re = random.choice(self.config.rest_endpoints)
        if 'username' in re:
            self.rest_cred = base64.b64encode("%s:%s" % (re.username, re.password))
        else:
            self.rest_cred = None

        if re.use_https:
            self.con = http.client.HTTPSConnection(re.host, re.port, timeout=60,
                                                   context=ssl._create_unverified_context())
        else:
            self.con = http.client.HTTPConnection(re.host, re.port, timeout=60)

        logging.info(self.loggingkey+'Connections opened')

    def run(self):
        logging.info(self.loggingkey+'Thread started')
        logging.info(str(self.sublogq))
        try:
            self.open_connections()
            while True:
                msg = self.subq.get()
                logging.info(str(msg))
                if msg is None:
                    return
                else:
                    try:
                        self.process_one(msg)
                    except ConnectionError:
                        self.stats.incr('899 -   Skip subscriber due to connection error')
                        logging.error(self.loggingkey+'Reopen connections due to connection error and retry')
                        self.open_connections()
                    except Exception as ex:
                        traceback.print_exc()
                        logging.error(self.loggingkey+'Exception %s %s' % (type(ex).__name__, ex.args))
                        self.stats.incr('898 -   Skip subscriber due to data error')
        except Exception as ex:
            logging.error(self.loggingkey+'Exception %s %s' % (type(ex).__name__, ex.args))
        finally:
            logging.info(self.loggingkey+'Thread exiting')

    def setLoggingKey(self,key):
        self.loggingkey = '['+key+'] '

    def process_one(self, q_msg):
        self.stats.incr('100 - Subscribers processed')
        key, value = q_msg
        autopayurl = ''
        if key == KEY_OBJID and self.testrun == 'Y':
            self.setLoggingKey(value)
            logging.info(self.loggingkey+'Processing Subscription Object Id: ' + value)
            autopayurl = OIDTESTURL+value
        elif key == KEY_EXTID and self.testrun == 'Y':
            self.setLoggingKey(value)
            logging.info(self.loggingkey+'Processing Subscription External Id: ' + value)
            autopayurl = XIDTESTURL+value
        elif key == KEY_OBJID:
            self.setLoggingKey(value)
            logging.info(self.loggingkey+'Processing Subscription Object Id: ' + value)
            autopayurl = OIDURL+value
        elif key == KEY_EXTID:
            self.setLoggingKey(value)
            logging.info(self.loggingkey+'Processing Subscription External Id: ' + value)
            autopayurl = XIDURL+value

        logging.debug(self.loggingkey+'autopay url - ' + autopayurl)
        apiresp = ''
        try:
          apiresp=self.call(self.con,autopayurl,cred=self.rest_cred)
        except ConnectionError:
          logging.info(self.loggingkey+'AUDIT RECORD ERROR: Subscriber %s autopay service connection error'%value)
          raise
        respparse = json.loads(apiresp, parse_float=Decimal)
        respmap = DotMap(respparse, _dynamic=False)

        if respmap.Result == RESULT_CODE_MTX_SUCESS:
            self.stats.incr('350 -       Autopay Service recharged subscriber.')
            logging.info(self.loggingkey+'AUDIT RECORD SUCCESS: Subscriber was successfully re-charged. Autopay Response %s' % apiresp)
        elif respmap.Result == RESULT_CODE_AUTOPAY_SKIP_SUB:
            self.stats.incr('351 -       Autopay Service skipped subscriber.')
            logging.info(self.loggingkey+'AUDIT RECORD: Subscriber autopay service response %s' %respmap.ResultText)
        elif respmap.Result == RESULT_CODE_AUTOPAY_SUCCESS_NOTIF_FAIL:
            self.stats.incr('352 -       Autopay success. But notification delivery failed.')
            logging.info(self.loggingkey+'AUDIT RECORD ERROR: Subscriber autopay service response %s' %respmap.ResultText)
        elif respmap.Result == RESULT_CODE_AUTOPAY_FAIL_NOTIF_FAIL:
            self.stats.incr('353 -       Autopay failed. Notification delivery also failed.')
            logging.info(self.loggingkey+'AUDIT RECORD ERROR: Subscriber autopay service response %s' %respmap.ResultText)
        else:
            self.stats.incr('354 -       Autopay Service did not recharge subscriber')
            logging.info(self.loggingkey+'AUDIT RECORD ERROR: Subscriber autopay service response %s'%respmap.ResultText)

        messages = respmap.ResultText.split('|')
        for msg in messages:
            self.stats.incr(msg.strip())

        return respmap

    def get_sub_details(self, q_msg):
        key, value = q_msg
        SVCSUBURL = '/rsgateway/data/json/service/subscription/'+value+'?filterName=rsServiceSubscriptionSimpleFilter'
        apiresp = ''
        try:
          self.open_connections()
          apiresp=self.call(self.con,SVCSUBURL,cred=self.rest_cred)
        except ConnectionError:
            return None
        respparse = json.loads(apiresp, parse_float=Decimal)
        respmap = DotMap(respparse, _dynamic=False)
        print(respmap.ExternalId+'->'+respmap.BillingCycle.CurrentPeriodEndTime)
        return respmap

    def call(self, con, url, cred=None, log_request=True, logq=None):
        use_get = False
        start = timer()
        if use_get:
            meth = 'GET'
        else:
            meth = 'POST'
        headers = {"Connection": "keep-alive", "Content-Type": "application/json"}
        if cred is not None:
            headers['Authorization'] = 'Basic %s' % cred
        try:
            con.request(meth, url, headers=headers)
            response = con.getresponse().read()
        except:
            raise ConnectionError

        elapsed = timer() - start
        if log_request:
            if logq is None:
                logging.debug(self.loggingkey+'Call took %.0f ms' % (elapsed * 1000.0))
                logging.debug(self.loggingkey+'Response\n' + str(response))
            else:
                logq.put('Call took %.0f ms' % (elapsed * 1000.0))
                logq.put('Response\n' + str(response))
        return response
