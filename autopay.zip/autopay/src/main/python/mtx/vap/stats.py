import time as t
import logging
from threading import Thread,Lock

class Stats(Thread):
  def __init__(self,config):
    Thread.__init__(self)
    self.daemon=True
    self.name='Stats'
    self.lock=Lock()
    self.data={}
    self.interval=int(config['statistics_interval'])
  def run(self):
    while True:
      self.printstats()
      t.sleep(self.interval)
  def incr(self,msg,log=True):
    if log: logging.debug(msg)
    self.lock.acquire()
    if msg in self.data:
      self.data[msg]+=1
    else:
      self.data[msg]=1
    self.lock.release()
  def printstats(self):
    keys=list(self.data.keys())
    keys.sort()
    try:
      mlen=max([len(k) for k in keys])
    except ValueError:
      mlen=0
    s='Statistics\n'
    for k in keys:
      s+=k+':'+' '*(mlen+2-len(k))+'%d\n'%self.data[k]
    logging.info(s)

def init_stats(config):
  global stats
  logging.info('Init statistics')
  stats=Stats(config)
  stats.start()

def get_stats():
  global stats
  return stats