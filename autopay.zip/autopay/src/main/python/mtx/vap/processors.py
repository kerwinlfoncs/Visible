import logging
from mtx.vap.processor import Processor

class Processors():
    def __init__(self, config, q, sublogq):
        self.config = config
        self.subq = q
        self.sublogq = sublogq

    def start(self):
        logging.info('Creating processor threads')
        self.threads = []
        for i in range(self.config.threads):
            self.threads.append(Processor(self.config, self.subq, self.sublogq))
        logging.info('Threads created - ' + str(len(self.threads)))
        for t in self.threads:
            t.start()

    def wait(self):
        logging.info('Waiting for processing threads to complete')
        for t in self.threads:
            self.subq.put(None)
        for t in self.threads:
            t.join()
        logging.info('Processor threads exited')
