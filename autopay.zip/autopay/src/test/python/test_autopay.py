import sys

from _pytest import monkeypatch




def test_load_config():
    from autopay import load_config
    load_config("autopay.yaml")
    assert True

def test_main():
    from autopay import main
    #monkeypatch.setattr("sys.argv", ["pytest", "autopay.yaml"])
    sys.argv = ["pytest", "autopay.yaml"]
    main()