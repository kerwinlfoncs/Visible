import sys

import yaml
from dotmap import DotMap
from queue import Queue

def test_load_config():
    from src.main.python.mtx.vap.scanner import Scanner
    config = DotMap(yaml.safe_load(open('/opt/mtx/conf/autopay.yaml')), _dynamic=False)
    subq = Queue()
    s = Scanner(config, subq)
    print(subq)
    assert True

