### **Script to Modify PlanID for GL**
The  script aims at extracting the PlanIDs available in the GlReference field and update it for the respective planID fields in a xml file.

#### **Prerequisites**
* Xml file should be available on the required location to run the script
* The name and location of the xml file should be specified in **update_planIDs_for_GL.yaml** file.
* PlanIDs to be replaced should be updated in _modified_plan_IDs_ field in **update_planIDs_for_GL.yaml**

#### **Running the program**

* Get **update_planIDs_for_GL.py** file from _/autopay/src/python/mtx_ and move to the following path _/opt/mtx/data/gl/vzw_gl_5252_ in publishing blade.
* Get **update_planIDs_for_GL.yaml** file from _/autopay/src/conf_ and move to the following path _/opt/mtx/data/gl/vzw_gl_5252_
* Ssh to publishing blade:
  `ssh mtx@10.0.4.11`
* Run the command to change directory:
  `cd /opt/mtx/data/gl/vzw_gl_5252`
* Execute the script using following command:
  `python3 update_planIDs_for_GL.py`

#### **Verify the Script**

* Run the command to change directory:
  `cd /opt/mtx/data/gl/vzw_gl_5252/sub_daily_posting/`
* Run the command to view the modified xml with updated planIDs
  `ls -l`