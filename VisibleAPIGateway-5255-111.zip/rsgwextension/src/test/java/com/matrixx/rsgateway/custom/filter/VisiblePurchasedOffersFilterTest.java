package com.matrixx.rsgateway.custom.filter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;

import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.platform.JsonObject;
import com.matrixx.platform.XmlNode;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.common.Constants.OFFER_CONSTANTS;
import com.matrixx.vag.common.OneParameterTest;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestUtils;
import com.matrixx.vag.common.ThreeParameterTest;
import com.matrixx.vag.common.TwoParameterTest;
import com.matrixx.vag.util.MDCTest;

public class VisiblePurchasedOffersFilterTest extends MDCTest {

    private VisiblePurchasedOffersFilter instance;

    @BeforeEach
    public void setUp() throws Exception {
        instance = new VisiblePurchasedOffersFilter();
    }

    @Tags({@Tag("VER-464"),@Tag("VER-465")})
    @Test
    public void test_jsonFilter_When_FilterByStatus_Then_CorrectOffersReturned(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[]
                {"Subscriber has some offers in Active status.", "Also has some offers in Inactive and Preactive status."};
        td.when = new String[]{"filter is called for OfferStatusDescription= active or inactive or preactive."};
        td.then = new String[]{"Offers of corrct status should be returned."};

        ThreeParameterTest pTests = (tc,status, offers) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions)tc;
            
        	JsonObject filterInfo = new JsonObject();
        	filterInfo.attribute("FilterFieldName", "OfferStatusDescription");
        	filterInfo.attribute("FilterFieldValue", status.toString());
        	filterInfo.attribute("ResponseOfferFieldList", "OfferStatusDescription,ResourceId,StartTime");
            MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription("1234",tCon.activeCiList, tCon.preactiveCiList,tCon.inactiveCiList, null, true);
            JsonObject input = new JsonObject();
            subscription.toJson(input);
            System.out.println("****************************Input****************************");
            System.out.println(input.toString());
            System.out.println("****************************Filter****************************");
            
            JsonObject output = instance.filter(filterInfo, input);
            MtxResponseSubscription outputSub =  CommonTestHelper.parseJsonMessage(MtxResponseSubscription.class, output.toString());
            System.out.println("****************************Output****************************");
            System.out.println(outputSub.toJson());
            List<String> outputOffers = new ArrayList<String>();
            outputSub.getPurchasedOfferArray().forEach(mpoi->{            	
            	assertEquals(status.toString(),mpoi.getOfferStatusDescription(), "All returned offersh should be "+status.toString());
            	outputOffers.add(mpoi.getCatalogItemExternalId());
            });
            String[] expectedOffers = offers.toString().split(",");            
            for(String eOffer:expectedOffers) {
            	assertTrue(outputOffers.toString().contains(eOffer), eOffer+" should be a returned offer.");
            }  
        };
        
        TestConditions tc = new TestConditions();
        tc.activeCiList = Arrays.asList(CI_EXTERNAL_IDS.SETUP_SERVICES, CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION);
        tc.preactiveCiList = Arrays.asList(CI_EXTERNAL_IDS.BASE3VIS23, CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023);
        tc.inactiveCiList = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.WEARABLE);
        pTests.test(tc,OFFER_CONSTANTS.OFFER_STATUS_ACTIVE,StringUtils.join(tc.activeCiList, ","));
        pTests.test(tc,"inactive",StringUtils.join(tc.inactiveCiList, ","));
        pTests.test(tc, OFFER_CONSTANTS.OFFER_STATUS_PRE_ACTIVE,StringUtils.join(tc.preactiveCiList, ","));
    }

    @Tags({@Tag("VER-464"),@Tag("VER-465")})
    @Test
    public void test_xmlFilter_When_When_FilterByStatus_Then_CorrectOffersReturned(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[]
                {"Subscriber has some offers in Active status.", "Also has some offers in Inactive and Preactive status."};
        td.when = new String[]{"filter is called for OfferStatusDescription= active or inactive or preactive."};
        td.then = new String[]{"Offers of corrct status should be returned."};

        ThreeParameterTest pTests = (tc,status, offers) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions)tc;
            
        	JsonObject filterInfo = new JsonObject();
        	filterInfo.attribute("FilterFieldName", "OfferStatusDescription");
        	filterInfo.attribute("FilterFieldValue", status.toString());
        	filterInfo.attribute("ResponseOfferFieldList", "OfferStatusDescription,ResourceId,StartTime");
            MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription("1234",tCon.activeCiList, tCon.preactiveCiList,tCon.inactiveCiList, null, true);
            XmlNode input = subscription.toXmlNodes();
            System.out.println("****************************Input****************************");
            System.out.println(input.toString());
            System.out.println("****************************Filter****************************");
            
            XmlNode output = instance.filter(filterInfo, input);
            MtxResponseSubscription outputSub =  CommonTestHelper.parseXmlMessage(MtxResponseSubscription.class, output.toString());
            System.out.println("****************************Output****************************");
            System.out.println(outputSub.toXml());
            List<String> outputOffers = new ArrayList<String>();
            outputSub.getPurchasedOfferArray().forEach(mpoi->{            	
            	assertEquals(status.toString(),mpoi.getOfferStatusDescription(), "All returned offersh should be "+status.toString());
            	outputOffers.add(mpoi.getCatalogItemExternalId());
            });
            String[] expectedOffers = offers.toString().split(",");            
            for(String eOffer:expectedOffers) {
            	assertTrue(outputOffers.toString().contains(eOffer), eOffer+" should be a returned offer.");
            }  
        };
        
        TestConditions tc = new TestConditions();
        tc.activeCiList = Arrays.asList(CI_EXTERNAL_IDS.SETUP_SERVICES, CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION);
        tc.preactiveCiList = Arrays.asList(CI_EXTERNAL_IDS.BASE3VIS23, CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023);
        tc.inactiveCiList = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.WEARABLE);
        pTests.test(tc,OFFER_CONSTANTS.OFFER_STATUS_ACTIVE,StringUtils.join(tc.activeCiList, ","));
        pTests.test(tc,"inactive",StringUtils.join(tc.inactiveCiList, ","));
        pTests.test(tc, OFFER_CONSTANTS.OFFER_STATUS_PRE_ACTIVE,StringUtils.join(tc.preactiveCiList, ","));
    }

    @Tags({@Tag("VER-464"),@Tag("VER-465")})
    @Test
    public void test_jsonFilter_When_FilterOnField_NullOrNotNull_Then_ReturnData(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[]
                {"Subscriber has some offers in Active status.", "Also has some offers in Inactive and Preactive status."};
        td.when = new String[]{"filter is called for for a field being null or notnull"};
        td.then = new String[]{"Offers of corrct status should be returned."};

        ThreeParameterTest pTests = (tc,fVal, offers) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions)tc;
            
        	JsonObject filterInfo = new JsonObject();
        	filterInfo.attribute("FilterFieldName", "CancelEndTime");
        	filterInfo.attribute("FilterFieldValue", fVal.toString());
        	filterInfo.attribute("ResponseOfferFieldList", "CancelEndTime,OfferStatusDescription,RecurringSuccessCycleCount,ResourceId");
            MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription("1234",tCon.activeCiList, tCon.preactiveCiList,tCon.inactiveCiList, null, true);
            subscription.getPurchasedOfferArray().forEach(mpoi->{
            	if(mpoi.getCatalogItemExternalId()==null) {
            		return;
            	}else if((fVal.toString().equalsIgnoreCase("notnull")||fVal.toString().equalsIgnoreCase("not null")||fVal.toString().equalsIgnoreCase("!null"))
            			&&tCon.inactiveCiList.contains(mpoi.getCatalogItemExternalId())){
            		mpoi.setCancelEndTime(TestUtils.getFirstDateTimeOfCurrentMonth());            		
            	}            	
            });
            JsonObject input = new JsonObject();
            subscription.toJson(input);
            System.out.println("****************************Input****************************");
            System.out.println(input.toString());
            System.out.println("****************************Filter****************************");
            
            JsonObject output = instance.filter(filterInfo, input);
            MtxResponseSubscription outputSub =  CommonTestHelper.parseJsonMessage(MtxResponseSubscription.class, output.toString());
            System.out.println("****************************Output****************************");
            System.out.println(outputSub.toJson());
            List<String> outputOffers = new ArrayList<String>();
            outputSub.getPurchasedOfferArray().forEach(mpoi->{            	
            	outputOffers.add(mpoi.getCatalogItemExternalId());
            }); 
            System.out.println("expectedOffers: "+offers.toString());
            System.out.println("actualOffers: "+outputOffers);
            for(String offer:outputOffers) {
            	assertTrue(offers.toString().contains(offer), offer+" is not an expeced offer.");
            }  
        };
        
        TestConditions tc = new TestConditions();
        tc.activeCiList = Arrays.asList(CI_EXTERNAL_IDS.SETUP_SERVICES, CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION);
        tc.inactiveCiList = Arrays.asList(CI_EXTERNAL_IDS.BASE3VIS23);
        pTests.test(tc,"null",StringUtils.join(tc.activeCiList, ",")+","+StringUtils.join(tc.inactiveCiList, ","));
        pTests.test(tc,"notnull",StringUtils.join(tc.inactiveCiList, ","));
        pTests.test(tc,"not null",StringUtils.join(tc.inactiveCiList, ","));
        pTests.test(tc,"!null",StringUtils.join(tc.inactiveCiList, ","));
    }

    @Tags({@Tag("VER-464"),@Tag("VER-465")})
    @Test
    public void test_xmlFilter_When_FilterOnField_NullOrNotNull_Then_ReturnData(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[]
                {"Subscriber has some offers in Active status.", "Also has some offers in Inactive and Preactive status."};
        td.when = new String[]{"filter is called for for a field being null or notnull"};
        td.then = new String[]{"Offers of corrct status should be returned."};

        ThreeParameterTest pTests = (tc,fVal, offers) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions)tc;
            
        	JsonObject filterInfo = new JsonObject();
        	filterInfo.attribute("FilterFieldName", "CancelEndTime");
        	filterInfo.attribute("FilterFieldValue", fVal.toString());
        	filterInfo.attribute("ResponseOfferFieldList", "CancelEndTime,OfferStatusDescription,RecurringSuccessCycleCount,ResourceId");
            MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription("1234",tCon.activeCiList, tCon.preactiveCiList,tCon.inactiveCiList, null, true);
            subscription.getPurchasedOfferArray().forEach(mpoi->{
            	if(mpoi.getCatalogItemExternalId()==null) {
            		return;
            	}else if((fVal.toString().equalsIgnoreCase("notnull")||fVal.toString().equalsIgnoreCase("not null")||fVal.toString().equalsIgnoreCase("!null"))
            			&&tCon.inactiveCiList.contains(mpoi.getCatalogItemExternalId())){
            		mpoi.setCancelEndTime(TestUtils.getFirstDateTimeOfCurrentMonth());            		
            	}            	
            });
            XmlNode input = subscription.toXmlNodes();
            System.out.println("****************************Input****************************");
            System.out.println(input.toString());
            System.out.println("****************************Filter****************************");
            
            XmlNode output = instance.filter(filterInfo, input);
            MtxResponseSubscription outputSub =  CommonTestHelper.parseXmlMessage(MtxResponseSubscription.class, output.toString());
            System.out.println("****************************Output****************************");
            System.out.println(outputSub.toXml());
            List<String> outputOffers = new ArrayList<String>();
            outputSub.getPurchasedOfferArray().forEach(mpoi->{            	
            	outputOffers.add(mpoi.getCatalogItemExternalId());
            });
            System.out.println("expectedOffers: "+offers.toString());
            System.out.println("actualOffers: "+outputOffers);
            for(String offer:outputOffers) {
            	assertTrue(offers.toString().contains(offer), offer+" is not an expected offer.");
            } 
        };
        
        TestConditions tc = new TestConditions();
        tc.activeCiList = Arrays.asList(CI_EXTERNAL_IDS.SETUP_SERVICES, CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION);
        tc.inactiveCiList = Arrays.asList(CI_EXTERNAL_IDS.BASE3VIS23);
        pTests.test(tc,"null",StringUtils.join(tc.activeCiList, ",")+","+StringUtils.join(tc.inactiveCiList, ","));
        pTests.test(tc,"notnull",StringUtils.join(tc.inactiveCiList, ","));
        pTests.test(tc,"not null",StringUtils.join(tc.inactiveCiList, ","));
        pTests.test(tc,"!null",StringUtils.join(tc.inactiveCiList, ","));   
    }

    @Tags({@Tag("VER-464"),@Tag("VER-465")})
    @Test
    public void test_jsonFilter_When_FieldsRequested_Then_ReturnAllFields(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[]
                {"Subscriber has some offers in Active status.", "Also has some offers in Inactive and Preactive status."};
        td.when = new String[]{"filter is called to return various fields"};
        td.then = new String[]{"All requested fields should be returned.", "All mandatory fields should be returned."};

        TwoParameterTest pTests = (tc,fList) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions)tc;
            
        	JsonObject filterInfo = new JsonObject();
        	filterInfo.attribute("FilterFieldName", "Status");
        	filterInfo.attribute("FilterFieldValue", "active");
        	filterInfo.attribute("ResponseOfferFieldList", fList.toString());    	
            MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription("1234",tCon.activeCiList, tCon.preactiveCiList,tCon.inactiveCiList, null, true);
            JsonObject input = new JsonObject();
            subscription.toJson(input);
            System.out.println("****************************Input****************************");
            System.out.println(input.toString());
            System.out.println("****************************Filter****************************");
            
            JsonObject output = instance.filter(filterInfo, input);
            MtxResponseSubscription outputSub =  CommonTestHelper.parseJsonMessage(MtxResponseSubscription.class, output.toString());
            System.out.println("****************************Output****************************");
            System.out.println(outputSub.toJson());
            assertNotNull(outputSub.getExternalId(), "Subscription ExternalId should always be returned.");
            outputSub.getPurchasedOfferArray().forEach(mpoi->{
            	assertNotNull(mpoi.getCatalogItemExternalId(), "CatalogItemExternalId should always be returned.");
            	
            	if(fList.toString().contains("OfferStatusDescription")) {
            		assertNotNull(mpoi.getOfferStatusDescription());
            	}
            	if(fList.toString().contains("ResourceId")) {
            		assertNotNull(mpoi.getResourceId());
            	}
            	if(fList.toString().contains("StartTime")) {
            		assertNotNull(mpoi.getStartTime());
            	}
            	if(fList.toString().contains("OfferStatusClass")) {
            		assertNotNull(mpoi.getOfferStatusClass());
            	}
            	if(fList.toString().contains("ProductOfferExternalId")) {
            		assertNotNull(mpoi.getProductOfferExternalId());
            	}
            	if(fList.toString().contains("PurchaseTime")) {
            		assertNotNull(mpoi.getPurchaseTime());
            	}
            });
        };
        
        TestConditions tc = new TestConditions();
        tc.activeCiList = Arrays.asList(CI_EXTERNAL_IDS.SETUP_SERVICES, CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION);
        pTests.test(tc,"OfferStatusDescription,ResourceId,StartTime,OfferStatusClass,ProductOfferExternalId");
        pTests.test(tc,"PurchaseTime,ResourceId,StartTime,ProductOfferExternalId");
    }

    @Tags({@Tag("VER-464"),@Tag("VER-465")})
    @Test
    public void test_xmlFilter_When_FieldsRequested_Then_ReturnAllFields(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[]
                {"Subscriber has some offers in Active status.", "Also has some offers in Inactive and Preactive status."};
        td.when = new String[]{"filter is called to return various fields"};
        td.then = new String[]{"All requested fields should be returned.", "All mandatory fields should be returned."};

        TwoParameterTest pTests = (tc,fList) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions)tc;
            
        	JsonObject filterInfo = new JsonObject();
        	filterInfo.attribute("FilterFieldName", "Status");
        	filterInfo.attribute("FilterFieldValue", "active");
        	filterInfo.attribute("ResponseOfferFieldList", fList.toString());    	
            MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription("1234",tCon.activeCiList, tCon.preactiveCiList,tCon.inactiveCiList, null, true);
            XmlNode input = subscription.toXmlNodes();
            System.out.println("****************************Input****************************");
            System.out.println(input.toString());
            System.out.println("****************************Filter****************************");
            
            XmlNode output = instance.filter(filterInfo, input);
            MtxResponseSubscription outputSub =  CommonTestHelper.parseXmlMessage(MtxResponseSubscription.class, output.toString());
            System.out.println("****************************Output****************************");
            System.out.println(outputSub.toXml());
            assertNotNull(outputSub.getExternalId(), "Subscription ExternalId should always be returned.");
            outputSub.getPurchasedOfferArray().forEach(mpoi->{
            	assertNotNull(mpoi.getCatalogItemExternalId(), "CatalogItemExternalId should always be returned.");
            	
            	if(fList.toString().contains("OfferStatusDescription")) {
            		assertNotNull(mpoi.getOfferStatusDescription());
            	}
            	if(fList.toString().contains("ResourceId")) {
            		assertNotNull(mpoi.getResourceId());
            	}
            	if(fList.toString().contains("StartTime")) {
            		assertNotNull(mpoi.getStartTime());
            	}
            	if(fList.toString().contains("OfferStatusClass")) {
            		assertNotNull(mpoi.getOfferStatusClass());
            	}
            	if(fList.toString().contains("ProductOfferExternalId")) {
            		assertNotNull(mpoi.getProductOfferExternalId());
            	}
            	if(fList.toString().contains("PurchaseTime")) {
            		assertNotNull(mpoi.getPurchaseTime());
            	}
            });
        };
        
        TestConditions tc = new TestConditions();
        tc.activeCiList = Arrays.asList(CI_EXTERNAL_IDS.SETUP_SERVICES, CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION);
        pTests.test(tc,"OfferStatusDescription,ResourceId,StartTime,OfferStatusClass,ProductOfferExternalId");
        pTests.test(tc,"PurchaseTime,ResourceId,StartTime,ProductOfferExternalId");
    }
 
    @Tags({@Tag("VER-464"),@Tag("VER-465")})
    @Test
    public void test_jsonFilter_When_NoFieldsRequested_Then_ReturnAllFields(TestInfo testInfo)
            throws Exception {    	
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[]
                {"Subscriber has some offers in Active status.", "Also has some offers in Inactive and Preactive status."};
        td.when = new String[]{"filter is called for no specific return fields"};
        td.then = new String[]{"All fields should be returned."};

        OneParameterTest pTests = (tc) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions)tc;
            
        	JsonObject filterInfo = new JsonObject();
        	filterInfo.attribute("FilterFieldName", "Status");
        	filterInfo.attribute("FilterFieldValue", "active");    	
            MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription("1234",tCon.activeCiList, tCon.preactiveCiList,tCon.inactiveCiList, null, true);
            JsonObject input = new JsonObject();
            subscription.toJson(input);
            System.out.println("****************************Input****************************");
            System.out.println(input.toString());
            System.out.println("****************************Filter****************************");
            
            JsonObject output = instance.filter(filterInfo, input);
            MtxResponseSubscription outputSub =  CommonTestHelper.parseJsonMessage(MtxResponseSubscription.class, output.toString());
            System.out.println("****************************Output****************************");
            System.out.println(outputSub.toJson());
            outputSub.getPurchasedOfferArray().forEach(mpoi->{
            	//Assert for random fields
            	assertNotNull(mpoi.getCatalogItemExternalId(), "CatalogItemExternalId should always be returned.");            	
           		assertNotNull(mpoi.getResourceId());
           		assertNotNull(mpoi.getPurchaseTime());            	
            });
        };
        
        TestConditions tc = new TestConditions();
        tc.activeCiList = Arrays.asList(CI_EXTERNAL_IDS.SETUP_SERVICES, CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION);
        pTests.test(tc);
    }

    @Tags({@Tag("VER-464"),@Tag("VER-465")})
    @Test
    public void test_xmlFilter_When_NoFieldsRequested_Then_ReturnAllFields(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[]
                {"Subscriber has some offers in Active status.", "Also has some offers in Inactive and Preactive status."};
        td.when = new String[]{"filter is called for no specific return fields"};
        td.then = new String[]{"All fields should be returned."};

        OneParameterTest pTests = (tc) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions)tc;
            
        	JsonObject filterInfo = new JsonObject();
        	filterInfo.attribute("FilterFieldName", "Status");
        	filterInfo.attribute("FilterFieldValue", "active");    	
            MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription("1234",tCon.activeCiList, tCon.preactiveCiList,tCon.inactiveCiList, null, true);
            XmlNode input = subscription.toXmlNodes();
            System.out.println("****************************Input****************************");
            System.out.println(input.toString());
            System.out.println("****************************Filter****************************");
            
            XmlNode output = instance.filter(filterInfo, input);
            MtxResponseSubscription outputSub =  CommonTestHelper.parseXmlMessage(MtxResponseSubscription.class, output.toString());
            System.out.println("****************************Output****************************");
            System.out.println(outputSub.toXml());
            outputSub.getPurchasedOfferArray().forEach(mpoi->{
            	//Assert for random fields
            	assertNotNull(mpoi.getCatalogItemExternalId(), "CatalogItemExternalId should always be returned.");            	
           		assertNotNull(mpoi.getResourceId());
           		assertNotNull(mpoi.getPurchaseTime());            	
            });
        };
        
        TestConditions tc = new TestConditions();
        tc.activeCiList = Arrays.asList(CI_EXTERNAL_IDS.SETUP_SERVICES, CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION);
        pTests.test(tc);
    }
   
    private class TestConditions {
        List<String> activeCiList;
        List<String> preactiveCiList;
        List<String> inactiveCiList;
    }
}