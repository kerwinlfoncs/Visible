package com.matrixx.rsgateway.custom;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import java.lang.reflect.InvocationTargetException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.test.util.ReflectionTestUtils;

import com.matrixx.datacontainer.mdc.ManualPayRequest;
import com.matrixx.datacontainer.mdc.ManualPayResponse;
import com.matrixx.datacontainer.mdc.MtxApiEventDataExtension;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberModify;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberPurchaseOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberRecharge;
import com.matrixx.datacontainer.mdc.MtxResponse;
import com.matrixx.datacontainer.mdc.MtxSubscriberSearchData;
import com.matrixx.datacontainer.mdc.SacModifyRequest;
import com.matrixx.datacontainer.mdc.SacModifyResponse;
import com.matrixx.datacontainer.mdc.SacResponse;
import com.matrixx.datacontainer.mdc.VisibleMultiRequest;
import com.matrixx.datacontainer.mdc.VisibleMultiRequestPurchaseService;
import com.matrixx.datacontainer.mdc.VisibleMultiResponsePurchaseService;
import com.matrixx.datacontainer.mdc.VisibleRequestAutoPay;
import com.matrixx.datacontainer.mdc.VisibleRequestCancelDeviceSwap;
import com.matrixx.datacontainer.mdc.VisibleRequestChangeService;
import com.matrixx.datacontainer.mdc.VisibleRequestChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleRequestChargeNrf;
import com.matrixx.datacontainer.mdc.VisibleRequestDeviceSwap;
import com.matrixx.datacontainer.mdc.VisibleRequestFinanceDevice;
import com.matrixx.datacontainer.mdc.VisibleRequestGetConfig;
import com.matrixx.datacontainer.mdc.VisibleRequestPaymentAdviceService;
import com.matrixx.datacontainer.mdc.VisibleRequestPurchaseDevice;
import com.matrixx.datacontainer.mdc.VisibleRequestPurchaseService;
import com.matrixx.datacontainer.mdc.VisibleRequestQuoteAdviceService;
import com.matrixx.datacontainer.mdc.VisibleRequestRefundService;
import com.matrixx.datacontainer.mdc.VisibleRequestReloadConfig;
import com.matrixx.datacontainer.mdc.VisibleRequestReturnFinancedDevice;
import com.matrixx.datacontainer.mdc.VisibleRequestReturnPurchasedDevice;
import com.matrixx.datacontainer.mdc.VisibleRequestReverseNrf;
import com.matrixx.datacontainer.mdc.VisibleRequestSacSetUpPayment;
import com.matrixx.datacontainer.mdc.VisibleResponseAutoPay;
import com.matrixx.datacontainer.mdc.VisibleResponseCancelDeviceSwap;
import com.matrixx.datacontainer.mdc.VisibleResponseChangeService;
import com.matrixx.datacontainer.mdc.VisibleResponseChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleResponseChargeNrf;
import com.matrixx.datacontainer.mdc.VisibleResponseDeviceSwap;
import com.matrixx.datacontainer.mdc.VisibleResponseFinanceDevice;
import com.matrixx.datacontainer.mdc.VisibleResponseGetConfig;
import com.matrixx.datacontainer.mdc.VisibleResponseMulti;
import com.matrixx.datacontainer.mdc.VisibleResponsePaymentAdviceService;
import com.matrixx.datacontainer.mdc.VisibleResponsePurchaseDevice;
import com.matrixx.datacontainer.mdc.VisibleResponsePurchaseService;
import com.matrixx.datacontainer.mdc.VisibleResponseQuoteAdviceService;
import com.matrixx.datacontainer.mdc.VisibleResponseRefundService;
import com.matrixx.datacontainer.mdc.VisibleResponseReturnFinancedDevice;
import com.matrixx.datacontainer.mdc.VisibleResponseReturnPurchasedDevice;
import com.matrixx.datacontainer.mdc.VisibleResponseReverseNrf;
import com.matrixx.datacontainer.mdc.VisibleResponseSacSetUpPayment;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.advice.service.PaymentAdviceService;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.config.service.ConfigService;
import com.matrixx.vag.device.service.DeviceService;
import com.matrixx.vag.exception.ConfigServiceException;
import com.matrixx.vag.exception.IntegrationServiceException;
import com.matrixx.vag.exception.SacServiceException;
import com.matrixx.vag.payment.service.AutoPayService;
import com.matrixx.vag.payment.service.ManualPayService;
import com.matrixx.vag.sac.service.SacService;
import com.matrixx.vag.subscriber.service.ChangeService;
import com.matrixx.vag.subscriber.service.RefundService;
import com.matrixx.vag.subscriber.service.RefundServiceV3;
import com.matrixx.vag.subscriber.service.SubscriberService;
import com.matrixx.vag.util.MDCTest;

public class VisibleServicesTest extends MDCTest {

    @Spy
    @InjectMocks
    private VisibleServices instance;

    PaymentAdviceService paymentAdviceInstance;
    SubscriberService subscriberServiceInstance;
    ManualPayService manualPayInstance;
    ConfigService configInstance;
    AutoPayService autoPayInstance;
    RefundServiceV3 refundServiceV3;
    RefundService refundService;
    SacService sacService;
    DeviceService deviceService;
    ChangeService changeService;
    private TestInfo testInfo;
    
    @BeforeEach
    public void setUp() throws Exception {
        instance = new VisibleServices();
        paymentAdviceInstance = Mockito.spy(new PaymentAdviceService());
        ReflectionTestUtils.setField(instance, "paymentAdviceService", paymentAdviceInstance);
        subscriberServiceInstance = Mockito.spy(new SubscriberService());
        ReflectionTestUtils.setField(instance, "subscriberService", subscriberServiceInstance);
        manualPayInstance = Mockito.spy(new ManualPayService());
        ReflectionTestUtils.setField(instance, "manualPayService", manualPayInstance);
        configInstance = Mockito.spy(new ConfigService());
        ReflectionTestUtils.setField(instance, "configService", configInstance);
        autoPayInstance = Mockito.spy(new AutoPayService());
        ReflectionTestUtils.setField(instance, "autoPayService", autoPayInstance);
        refundService = Mockito.spy(new RefundService());
        ReflectionTestUtils.setField(instance, "refundService", refundService);
        refundServiceV3 = Mockito.spy(new RefundServiceV3());
        ReflectionTestUtils.setField(instance, "refundServiceV3", refundServiceV3);
        sacService = Mockito.spy(new SacService());
        ReflectionTestUtils.setField(instance, "sacService", sacService);
        deviceService = Mockito.spy(new DeviceService());
        ReflectionTestUtils.setField(instance, "deviceService", deviceService);
        changeService = Mockito.spy(new ChangeService());
        ReflectionTestUtils.setField(instance, "changeService", changeService);

        MockitoAnnotations.openMocks(this);
        this.testInfo = testInfo;
    }

    @Test
    public void test_paymentAdvice_When_ServiceReturnsSuccess_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns success."
        };
        td.then = new String[] {
            "No Exception."
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService request = new VisibleRequestPaymentAdviceService();
        VisibleResponsePaymentAdviceService response = new VisibleResponsePaymentAdviceService();
        doNothing().when(paymentAdviceInstance).getAOP(any(), any());

        assertEquals(0, instance.paymentAdvice(request, response));
    }

    @Test
    public void test_paymentAdvice_When_VisibleServiceException_Then_OutputWithSubId(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService request = new VisibleRequestPaymentAdviceService();
        request.setSubscriberExternalId("1234");
        VisibleResponsePaymentAdviceService response = new VisibleResponsePaymentAdviceService();
        doThrow(
                new IntegrationServiceException(
                        RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS,
                        "Test Message")).when(paymentAdviceInstance).getAOP(any(), any());

        instance.paymentAdvice(request, response);

        assertEquals(
                RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS, response.getResult());
        assertEquals(request.getSubscriberExternalId(), response.getSubscriberExternalId());
    }

    @Test
    public void test_paymentAdvice_When_Exception_Then_OutputWithSubId(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService request = new VisibleRequestPaymentAdviceService();
        request.setSubscriberExternalId("1234");
        VisibleResponsePaymentAdviceService response = new VisibleResponsePaymentAdviceService();
        doThrow(Exception.class).when(paymentAdviceInstance).getAOP(any(), any());

        instance.paymentAdvice(request, response);

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult());
        assertEquals(request.getSubscriberExternalId(), response.getSubscriberExternalId());
    }

    @Test
    public void test_quoteAdvice_When_ServiceReturnsSuccess_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns success."
        };
        td.then = new String[] {
            "No Exception."
        };
        td.printDescription();

        VisibleRequestQuoteAdviceService request = new VisibleRequestQuoteAdviceService();
        VisibleResponseQuoteAdviceService response = new VisibleResponseQuoteAdviceService();
        doNothing().when(paymentAdviceInstance).getQuoteAdvice(any(), any());

        assertEquals(0, instance.quoteAdvice(request, response));
    }

    @Test
    public void test_quoteAdvice_When_VisibleServiceException_Then_OutputWithSubId(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestQuoteAdviceService request = new VisibleRequestQuoteAdviceService();
        request.setSubscriberExternalId("1234");
        VisibleResponseQuoteAdviceService response = new VisibleResponseQuoteAdviceService();
        doThrow(
                new IntegrationServiceException(
                        RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS,
                        "Test Message")).when(paymentAdviceInstance).getQuoteAdvice(any(), any());

        instance.quoteAdvice(request, response);

        assertEquals(
                RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS, response.getResult());
        assertEquals(request.getSubscriberExternalId(), response.getSubscriberExternalId());
    }

    @Test
    public void test_quoteAdvice_When_Exception_Then_OutputWithSubId(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestQuoteAdviceService request = new VisibleRequestQuoteAdviceService();
        request.setSubscriberExternalId("1234");
        VisibleResponseQuoteAdviceService response = new VisibleResponseQuoteAdviceService();
        doThrow(Exception.class).when(paymentAdviceInstance).getQuoteAdvice(any(), any());

        instance.quoteAdvice(request, response);

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult());
        assertEquals(request.getSubscriberExternalId(), response.getSubscriberExternalId());
    }

    @ParameterizedTest(name = "test_getChangeServiceAdvice_Given_NoFreeGPOffer_When_ChangeTo_MidMonthly_Then_Add1Gps")
    @Tag("VER-731")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Request has MtxApiEventDataExtension and not VisibleApiEventData.|"
                +"|When  |Api is called.|"
                +"|Then  |No Error.|"})
    // @formatter:on
    public void test_changeServiceAdvice_When_MtxApiEventDataExtension_Then_NoError(ArgumentsAccessor acceptance) throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setApiEventData(new MtxApiEventDataExtension());
        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();
        doNothing().when(paymentAdviceInstance).getChangeServiceAdvice(any(), any());

        assertEquals(0, instance.changeServiceAdvice(request, response));
    }
    
    @Test
    public void test_changeServiceAdvice_When_ServiceReturnsSuccess_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns success."
        };
        td.then = new String[] {
            "No Exception."
        };
        td.printDescription();

        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();
        doNothing().when(paymentAdviceInstance).getChangeServiceAdvice(any(), any());

        assertEquals(0, instance.changeServiceAdvice(request, response));
    }

    @Test
    public void test_changeServiceAdvice_When_VisibleServiceException_Then_OutputWithSubId(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setSubscriptionExternalId("1234");
        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();
        doThrow(
                new IntegrationServiceException(
                        RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS,
                        "Test Message")).when(paymentAdviceInstance).getChangeServiceAdvice(
                                any(), any());

        instance.changeServiceAdvice(request, response);

        assertEquals(
                RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS, response.getResult());
        assertEquals(request.getSubscriptionExternalId(), response.getSubscriptionExternalId());
    }

    @Test
    public void test_changeServiceAdvice_When_Exception_Then_OutputWithSubId(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setSubscriptionExternalId("1234");
        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();
        doThrow(Exception.class).when(paymentAdviceInstance).getChangeServiceAdvice(any(), any());

        instance.changeServiceAdvice(request, response);

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult());
        assertEquals(request.getSubscriptionExternalId(), response.getSubscriptionExternalId());
    }

    @Test
    public void test_changeService_When_ServiceReturnsSuccess_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns success."
        };
        td.then = new String[] {
            "No Exception."
        };
        td.printDescription();

        VisibleRequestChangeService request = new VisibleRequestChangeService();
        VisibleResponseChangeService response = new VisibleResponseChangeService();
        doNothing().when(changeService).changeBaseOfferService(any(), any());

        assertEquals(0, instance.changeService(request, response));
    }

    @Test
    public void test_changeService_When_VisibleServiceException_Then_OutputWithSubId(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestChangeService request = new VisibleRequestChangeService();
        request.setSubscriptionExternalId("1234");
        VisibleResponseChangeService response = new VisibleResponseChangeService();
        doThrow(
                new IntegrationServiceException(
                        RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS,
                        "Test Message")).when(changeService).changeBaseOfferService(
                                any(), any());

        instance.changeService(request, response);

        assertEquals(
                RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS, response.getResult());
        assertEquals(request.getSubscriptionExternalId(), response.getSubscriptionExternalId());
    }

    @Test
    public void test_changeService_When_Exception_Then_OutputWithSubId(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestChangeService request = new VisibleRequestChangeService();
        request.setSubscriptionExternalId("1234");
        VisibleResponseChangeService response = new VisibleResponseChangeService();
        doThrow(Exception.class).when(changeService).changeBaseOfferService(any(), any());

        instance.changeService(request, response);

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult());
        assertEquals(request.getSubscriptionExternalId(), response.getSubscriptionExternalId());
    }

    @Test
    public void test_purchaseService_When_ServiceReturnsSuccess_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns success."
        };
        td.then = new String[] {
            "No Exception."
        };
        td.printDescription();

        VisibleRequestPurchaseService request = new VisibleRequestPurchaseService();
        VisibleResponsePurchaseService response = new VisibleResponsePurchaseService();
        doNothing().when(subscriberServiceInstance).purchaseService(any(), any());

        assertEquals(0, instance.purchaseService(request, response));
    }

    @Test
    public void test_purchaseService_When_VisibleServiceException_Then_OutputWithSubId(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestPurchaseService request = new VisibleRequestPurchaseService();
        request.setSubscriberExternalId("1234");
        VisibleResponsePurchaseService response = new VisibleResponsePurchaseService();
        doThrow(
                new IntegrationServiceException(
                        RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS,
                        "Test Message")).when(subscriberServiceInstance).purchaseService(
                                any(), any());

        instance.purchaseService(request, response);

        assertEquals(
                RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS, response.getResult());
    }

    @Test
    public void test_purchaseService_When_Exception_Then_OutputWithSubId(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestPurchaseService request = new VisibleRequestPurchaseService();
        request.setSubscriberExternalId("1234");
        VisibleResponsePurchaseService response = new VisibleResponsePurchaseService();
        doThrow(Exception.class).when(subscriberServiceInstance).purchaseService(any(), any());

        instance.purchaseService(request, response);

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult());
    }

    @Test
    public void test_purchaseMultiService_When_ServiceReturnsSuccess_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns success."
        };
        td.then = new String[] {
            "No Exception."
        };
        td.printDescription();

        VisibleMultiRequestPurchaseService request = new VisibleMultiRequestPurchaseService();
        VisibleMultiResponsePurchaseService response = new VisibleMultiResponsePurchaseService();
        doNothing().when(subscriberServiceInstance).purchaseMultiService(any(), any());

        assertEquals(0, instance.purchaseMultiService(request, response));
    }

    @Test
    public void test_purchaseMultiService_When_VisibleServiceException_Then_OutputWithSubId(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleMultiRequestPurchaseService request = new VisibleMultiRequestPurchaseService();
        request.setSubscriberExternalId("1234");
        VisibleMultiResponsePurchaseService response = new VisibleMultiResponsePurchaseService();
        doThrow(
                new IntegrationServiceException(
                        RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS,
                        "Test Message")).when(subscriberServiceInstance).purchaseMultiService(
                                any(), any());

        instance.purchaseMultiService(request, response);
        assertEquals(
                RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS, response.getResult());
    }

    @Test
    public void test_purchaseMultiService_When_Exception_Then_OutputWithSubId(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleMultiRequestPurchaseService request = new VisibleMultiRequestPurchaseService();
        request.setSubscriberExternalId("1234");
        VisibleMultiResponsePurchaseService response = new VisibleMultiResponsePurchaseService();
        doThrow(Exception.class).when(subscriberServiceInstance).purchaseMultiService(any(), any());

        instance.purchaseMultiService(request, response);

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult());
    }

    @Test
    public void test_manualPay_When_ServiceReturnsSuccess_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns success."
        };
        td.then = new String[] {
            "No Exception."
        };
        td.printDescription();

        ManualPayRequest request = new ManualPayRequest();
        ManualPayResponse response = new ManualPayResponse();
        doReturn(0).when(manualPayInstance).manualPay(any(), any(), any());

        assertEquals(0, instance.manualPay(request, response));
    }

    @Test
    public void test_manualPay_When_VisibleServiceException_Then_OutputWithSubId(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        ManualPayRequest request = new ManualPayRequest();
        request.setSubscriberSearchDataExternalId("1234");
        ManualPayResponse response = new ManualPayResponse();
        doThrow(
                new IntegrationServiceException(
                        RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS,
                        "Test Message")).when(manualPayInstance).manualPay(any(), any(), any());

        instance.manualPay(request, response);
        assertEquals(
                RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS, response.getResult());
    }

    @Test
    public void test_manualPay_When_Exception_Then_OutputWithSubId(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        ManualPayRequest request = new ManualPayRequest();
        request.setSubscriberSearchDataExternalId("1234");
        ManualPayResponse response = new ManualPayResponse();
        doThrow(InvocationTargetException.class).when(manualPayInstance).manualPay(
                any(), any(), any());

        instance.manualPay(request, response);

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult());
    }

    @Test
    public void test_refundServiceV2_When_ServiceReturnsSuccess_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns success."
        };
        td.then = new String[] {
            "No Exception."
        };
        td.printDescription();

        VisibleRequestRefundService request = new VisibleRequestRefundService();
        VisibleResponseRefundService response = new VisibleResponseRefundService();
        doNothing().when(refundService).refundServiceV2(any(), any());

        assertEquals(0, instance.refundServiceV2(request, response));
    }

    @Test
    public void test_refundServiceV2_When_VisibleServiceException_Then_OutputWithSubId(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestRefundService request = new VisibleRequestRefundService();
        request.setSubscriberExternalId("1234");
        VisibleResponseRefundService response = new VisibleResponseRefundService();

        doThrow(
                new IntegrationServiceException(
                        RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS,
                        "Test Message")).when(refundService).refundServiceV2(any(), any());

        instance.refundServiceV2(request, response);
        assertEquals(
                RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS, response.getResult());
    }

    @Test
    public void testrefundServiceV2_When_Exception_Then_OutputWithSubId(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestRefundService request = new VisibleRequestRefundService();
        request.setSubscriberExternalId("1234");
        VisibleResponseRefundService response = new VisibleResponseRefundService();

        doThrow(InvocationTargetException.class).when(refundService).refundServiceV2(any(), any());

        instance.refundServiceV2(request, response);

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult());
    }

    @Test
    public void test_sacAddPayment_When_ServiceReturnsSuccess_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns success."
        };
        td.then = new String[] {
            "No Exception."
        };
        td.printDescription();

        SacResponse response = new SacResponse();
        doNothing().when(sacService).sacAddPayment(any(), any(), any(), any());

        assertEquals(0, instance.sacAddPayment(response, "", "", ""));
    }

    @Test
    public void test_sacAddPayment_When_SacServiceException_Then(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        SacResponse response = new SacResponse();
        doThrow(
                new SacServiceException(
                        RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS,
                        "Test Message")).when(sacService).sacAddPayment(any(), any(), any(), any());

        instance.sacAddPayment(response, "", "", "");
        assertEquals(
                RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS, response.getResult());
    }

    @Test
    public void test_sacAddPayment_When_Exception_Then(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        SacResponse response = new SacResponse();

        doThrow(new RuntimeException()).when(sacService).sacAddPayment(any(),any(),any(),any());

        instance.sacAddPayment(response,"","","");

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult());
    }

    @Test
    public void test_sacDeletePaymentOnResourceId_When_ServiceReturnsSuccess_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns success."
        };
        td.then = new String[] {
            "No Exception."
        };
        td.printDescription();

        SacResponse response = new SacResponse();
        doNothing().when(sacService).sacDeletePaymentOnResourceId(response, "", 0);
        
        assertEquals(0, instance.sacDeletePaymentOnResourceId(response, "", 0));
    }

    @Test
    public void test_sacDeletePaymentOnResourceId_When_SacServiceException_Then(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        SacResponse response = new SacResponse();
        doThrow(
                new SacServiceException(
                        RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS,
                        "Test Message")).when(sacService).sacDeletePaymentOnResourceId(response, "", 0);

        instance.sacDeletePaymentOnResourceId(response, "", 0);
        
        assertEquals(
                RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS, response.getResult());
    }

    @Test
    public void test_sacDeletePaymentOnResourceId_When_Exception_Then(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        SacResponse response = new SacResponse();

        doThrow(new RuntimeException()).when(sacService).sacDeletePaymentOnResourceId(response,"",0);

        instance.sacDeletePaymentOnResourceId(response,"",0);

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult());
    }

    @Test
    public void test_sacModifyPayment_When_ServiceReturnsSuccess_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns success."
        };
        td.then = new String[] {
            "No Exception."
        };
        td.printDescription();
        
        SacModifyRequest request = new SacModifyRequest();
        SacModifyResponse response = new SacModifyResponse();
        doReturn(0).when(sacService).sacModifyPayment(any(), any());
        
        assertEquals(0, instance.sacModifyPayment(request,response));
    }

    @Test
    public void test_sacModifyPayment_When_Exception_Then(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        SacModifyRequest request = new SacModifyRequest();
        SacModifyResponse response = new SacModifyResponse();

        doThrow(SacServiceException.class).when(sacService).sacModifyPayment(any(),any());

        instance.sacModifyPayment(request,response);

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult());
    }

    @Test
    public void test_sacCurrentPayment_When_ServiceReturnsSuccess_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns success."
        };
        td.then = new String[] {
            "No Exception."
        };
        td.printDescription();
        
        SacResponse response = new SacResponse();
        doNothing().when(sacService).sacCurrentPayment(response, "", 0);
        
        assertEquals(0, instance.sacCurrentPayment(response, "", 0));
    }
    @Test
    public void test_sacCurrentPayment_When_VisibleServiceException_Then(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        SacResponse response = new SacResponse();

        doThrow(new SacServiceException(RESULT_CODES.MTX_NOT_FOUND, "ErrorText")).when(sacService).sacCurrentPayment(response,"",0);

        instance.sacCurrentPayment(response,"",0);

        assertEquals(RESULT_CODES.MTX_NOT_FOUND, response.getResult());
    }
    
    @Test
    public void test_sacCurrentPayment_When_Exception_Then(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        SacResponse response = new SacResponse();

        doThrow(new RuntimeException()).when(sacService).sacCurrentPayment(response,"",0);

        instance.sacCurrentPayment(response,"",0);

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult());
    }

    @Test
    public void test_sacSetUpPayment_When_ServiceReturnsSuccess_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns success."
        };
        td.then = new String[] {
            "No Exception."
        };
        td.printDescription();
        
        VisibleRequestSacSetUpPayment request = new VisibleRequestSacSetUpPayment();
        VisibleResponseSacSetUpPayment response = new VisibleResponseSacSetUpPayment();
        doNothing().when(sacService).sacSetUpPayment(any(),any());
        
        assertEquals(0, instance.sacSetUpPayment(request,response));
    }
    
    @Test
    public void test_sacSetUpPayment_When_VisibleServiceException_Then(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestSacSetUpPayment request = new VisibleRequestSacSetUpPayment();
        VisibleResponseSacSetUpPayment response = new VisibleResponseSacSetUpPayment();

        doThrow(new SacServiceException(RESULT_CODES.MTX_NOT_FOUND, "ErrorText")).when(sacService).sacSetUpPayment(any(),any());

        instance.sacSetUpPayment(request,response);

        assertEquals(RESULT_CODES.MTX_NOT_FOUND, response.getResult());
    }
    
    @Test
    public void test_sacSetUpPayment_When_Exception_Then(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestSacSetUpPayment request = new VisibleRequestSacSetUpPayment();
        VisibleResponseSacSetUpPayment response = new VisibleResponseSacSetUpPayment();

        doThrow(new RuntimeException()).when(sacService).sacSetUpPayment(any(),any());

        instance.sacSetUpPayment(request,response);

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult());
    }

    @Test
    public void test_purchaseDevice_When_ServiceReturnsSuccess_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns success."
        };
        td.then = new String[] {
            "No Exception."
        };
        td.printDescription();
        
        VisibleRequestPurchaseDevice request = new VisibleRequestPurchaseDevice();
        VisibleResponsePurchaseDevice response = new VisibleResponsePurchaseDevice();
        doNothing().when(deviceService).purchaseDevice(any(),any());
        
        assertEquals(0, instance.purchaseDevice(request,response));
    }
    
    @Test
    public void test_purchaseDevice_When_VisibleServiceException_Then(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestPurchaseDevice request = new VisibleRequestPurchaseDevice();
        VisibleResponsePurchaseDevice response = new VisibleResponsePurchaseDevice();

        doThrow(new SacServiceException(RESULT_CODES.MTX_NOT_FOUND, "ErrorText")).when(deviceService).purchaseDevice(any(),any());

        instance.purchaseDevice(request,response);

        assertEquals(RESULT_CODES.MTX_NOT_FOUND, response.getResult());
    }
    
    @Test
    public void test_purchaseDevice_When_Exception_Then(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestPurchaseDevice request = new VisibleRequestPurchaseDevice();
        VisibleResponsePurchaseDevice response = new VisibleResponsePurchaseDevice();

        doThrow(new RuntimeException()).when(deviceService).purchaseDevice(any(),any());

        instance.purchaseDevice(request,response);

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult());
    }
    
    @Test
    public void test_returnPurchasedDevice_When_ServiceReturnsSuccess_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns success."
        };
        td.then = new String[] {
            "No Exception."
        };
        td.printDescription();
        
        VisibleRequestReturnPurchasedDevice request = new VisibleRequestReturnPurchasedDevice();
        VisibleResponseReturnPurchasedDevice response = new VisibleResponseReturnPurchasedDevice();
        doNothing().when(deviceService).returnPurchasedDevice(any(),any());
        
        assertEquals(0, instance.returnPurchasedDevice(request,response));
    }
    
    @Test
    public void test_returnPurchasedDevice_When_VisibleServiceException_Then(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestReturnPurchasedDevice request = new VisibleRequestReturnPurchasedDevice();
        VisibleResponseReturnPurchasedDevice response = new VisibleResponseReturnPurchasedDevice();

        doThrow(new SacServiceException(RESULT_CODES.MTX_NOT_FOUND, "ErrorText")).when(deviceService).returnPurchasedDevice(any(),any());

        instance.returnPurchasedDevice(request,response);

        assertEquals(RESULT_CODES.MTX_NOT_FOUND, response.getResult());
    }
    
    @Test
    public void test_returnPurchasedDevice_When_Exception_Then(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestReturnPurchasedDevice request = new VisibleRequestReturnPurchasedDevice();
        VisibleResponseReturnPurchasedDevice response = new VisibleResponseReturnPurchasedDevice();

        doThrow(new RuntimeException()).when(deviceService).returnPurchasedDevice(any(),any());

        instance.returnPurchasedDevice(request,response);

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult());
    }

    @Test
    public void test_financeDevice_When_ServiceReturnsSuccess_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns success."
        };
        td.then = new String[] {
            "No Exception."
        };
        td.printDescription();
        
        VisibleRequestFinanceDevice request = new VisibleRequestFinanceDevice();
        VisibleResponseFinanceDevice response = new VisibleResponseFinanceDevice();
        doNothing().when(deviceService).financeDevice(any(),any());
        
        assertEquals(0, instance.financeDevice(request,response));
    }
    
    @Test
    public void test_financeDevice_When_VisibleServiceException_Then(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestFinanceDevice request = new VisibleRequestFinanceDevice();
        VisibleResponseFinanceDevice response = new VisibleResponseFinanceDevice();

        doThrow(new SacServiceException(RESULT_CODES.MTX_NOT_FOUND, "ErrorText")).when(deviceService).financeDevice(any(),any());

        instance.financeDevice(request,response);

        assertEquals(RESULT_CODES.MTX_NOT_FOUND, response.getResult());
    }
    
    @Test
    public void test_financeDevice_When_Exception_Then(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestFinanceDevice request = new VisibleRequestFinanceDevice();
        VisibleResponseFinanceDevice response = new VisibleResponseFinanceDevice();

        doThrow(new RuntimeException()).when(deviceService).financeDevice(any(),any());

        instance.financeDevice(request,response);

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult());
    }

    @Test
    public void test_returnFinancedDevice_When_ServiceReturnsSuccess_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns success."
        };
        td.then = new String[] {
            "No Exception."
        };
        td.printDescription();
        
        VisibleRequestReturnFinancedDevice request = new VisibleRequestReturnFinancedDevice();
        VisibleResponseReturnFinancedDevice response = new VisibleResponseReturnFinancedDevice();
        doNothing().when(deviceService).returnFinancedDevice(any(),any());
        
        assertEquals(0, instance.returnFinancedDevice(request,response));
    }
    
    @Test
    public void test_returnFinancedDevice_When_VisibleServiceException_Then(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestReturnFinancedDevice request = new VisibleRequestReturnFinancedDevice();
        VisibleResponseReturnFinancedDevice response = new VisibleResponseReturnFinancedDevice();

        doThrow(new SacServiceException(RESULT_CODES.MTX_NOT_FOUND, "ErrorText")).when(deviceService).returnFinancedDevice(any(),any());

        instance.returnFinancedDevice(request,response);

        assertEquals(RESULT_CODES.MTX_NOT_FOUND, response.getResult());
    }
    
    @Test
    public void test_returnFinancedDevice_When_Exception_Then(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestReturnFinancedDevice request = new VisibleRequestReturnFinancedDevice();
        VisibleResponseReturnFinancedDevice response = new VisibleResponseReturnFinancedDevice();

        doThrow(new RuntimeException()).when(deviceService).returnFinancedDevice(any(),any());

        instance.returnFinancedDevice(request,response);

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult());
    }

    @Test
    public void test_deviceSwap_When_ServiceReturnsSuccess_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns success."
        };
        td.then = new String[] {
            "No Exception."
        };
        td.printDescription();
        
        VisibleRequestDeviceSwap request = new VisibleRequestDeviceSwap();
        VisibleResponseDeviceSwap response = new VisibleResponseDeviceSwap();
        doNothing().when(deviceService).deviceSwap(any(),any());
        
        assertEquals(0, instance.deviceSwap(request,response));
    }
    
    @Test
    public void test_deviceSwap_When_VisibleServiceException_Then(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestDeviceSwap request = new VisibleRequestDeviceSwap();
        VisibleResponseDeviceSwap response = new VisibleResponseDeviceSwap();

        doThrow(new SacServiceException(RESULT_CODES.MTX_NOT_FOUND, "ErrorText")).when(deviceService).deviceSwap(any(),any());

        instance.deviceSwap(request,response);

        assertEquals(RESULT_CODES.MTX_NOT_FOUND, response.getResult());
    }
    
    @Test
    public void test_deviceSwap_When_Exception_Then(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestDeviceSwap request = new VisibleRequestDeviceSwap();
        VisibleResponseDeviceSwap response = new VisibleResponseDeviceSwap();

        doThrow(new RuntimeException()).when(deviceService).deviceSwap(any(),any());

        instance.deviceSwap(request,response);

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult());
    }

    @Test
    public void test_cancelDeviceSwap_When_ServiceReturnsSuccess_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns success."
        };
        td.then = new String[] {
            "No Exception."
        };
        td.printDescription();
        
        VisibleRequestCancelDeviceSwap request = new VisibleRequestCancelDeviceSwap();
        VisibleResponseCancelDeviceSwap response = new VisibleResponseCancelDeviceSwap();
        doNothing().when(deviceService).cancelDeviceSwap(any(),any());
        
        assertEquals(0, instance.cancelDeviceSwap(request,response));
    }
    
    @Test
    public void test_cancelDeviceSwap_When_VisibleServiceException_Then(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestCancelDeviceSwap request = new VisibleRequestCancelDeviceSwap();
        VisibleResponseCancelDeviceSwap response = new VisibleResponseCancelDeviceSwap();

        doThrow(new SacServiceException(RESULT_CODES.MTX_NOT_FOUND, "ErrorText")).when(deviceService).cancelDeviceSwap(any(),any());

        instance.cancelDeviceSwap(request,response);

        assertEquals(RESULT_CODES.MTX_NOT_FOUND, response.getResult());
    }
    
    @Test
    public void test_cancelDeviceSwap_When_Exception_Then(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestCancelDeviceSwap request = new VisibleRequestCancelDeviceSwap();
        VisibleResponseCancelDeviceSwap response = new VisibleResponseCancelDeviceSwap();

        doThrow(new RuntimeException()).when(deviceService).cancelDeviceSwap(any(),any());

        instance.cancelDeviceSwap(request,response);

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult());
    }

    @Test
    public void test_chargeNonReturnFee_When_ServiceReturnsSuccess_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns success."
        };
        td.then = new String[] {
            "No Exception."
        };
        td.printDescription();
        
        VisibleRequestChargeNrf request = new VisibleRequestChargeNrf();
        VisibleResponseChargeNrf response = new VisibleResponseChargeNrf();
        doNothing().when(deviceService).chargeNonReturnFee(any(),any());
        
        assertEquals(0, instance.chargeNonReturnFee(request,response));
    }
    
    @Test
    public void test_chargeNonReturnFee_When_VisibleServiceException_Then(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestChargeNrf request = new VisibleRequestChargeNrf();
        VisibleResponseChargeNrf response = new VisibleResponseChargeNrf();

        doThrow(new SacServiceException(RESULT_CODES.MTX_NOT_FOUND, "ErrorText")).when(deviceService).chargeNonReturnFee(any(),any());

        instance.chargeNonReturnFee(request,response);

        assertEquals(RESULT_CODES.MTX_NOT_FOUND, response.getResult());
    }
    
    @Test
    public void test_chargeNonReturnFee_When_Exception_Then(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestChargeNrf request = new VisibleRequestChargeNrf();
        VisibleResponseChargeNrf response = new VisibleResponseChargeNrf();

        doThrow(new RuntimeException()).when(deviceService).chargeNonReturnFee(any(),any());

        instance.chargeNonReturnFee(request,response);

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult());
    }

    @Test
    public void test_reverseNonReturnFee_When_ServiceReturnsSuccess_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns success."
        };
        td.then = new String[] {
            "No Exception."
        };
        td.printDescription();
        
        VisibleRequestReverseNrf request = new VisibleRequestReverseNrf();
        VisibleResponseReverseNrf response = new VisibleResponseReverseNrf();
        doNothing().when(deviceService).reverseNonReturnFee(any(),any());
        
        assertEquals(0, instance.reverseNonReturnFee(request,response));
    }
    
    @Test
    public void test_reverseNonReturnFee_When_VisibleServiceException_Then(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestReverseNrf request = new VisibleRequestReverseNrf();
        VisibleResponseReverseNrf response = new VisibleResponseReverseNrf();

        doThrow(new SacServiceException(RESULT_CODES.MTX_NOT_FOUND, "ErrorText")).when(deviceService).reverseNonReturnFee(any(),any());

        instance.reverseNonReturnFee(request,response);

        assertEquals(RESULT_CODES.MTX_NOT_FOUND, response.getResult());
    }
    
    @Test
    public void test_reverseNonReturnFee_When_Exception_Then(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestReverseNrf request = new VisibleRequestReverseNrf();
        VisibleResponseReverseNrf response = new VisibleResponseReverseNrf();

        doThrow(new RuntimeException()).when(deviceService).reverseNonReturnFee(any(),any());

        instance.reverseNonReturnFee(request,response);

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult());
    }

    @Test
    public void test_autoPay_When_ServiceReturnsSuccess_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns success."
        };
        td.then = new String[] {
            "No Exception."
        };
        td.printDescription();

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        doNothing().when(autoPayInstance).autoPay(any(), any());

        assertEquals(0, instance.autoPay(request, response));
    }

    @Test
    public void test_autoPay_When_VisibleServiceException_Then_OutputWithSubId(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId("1234");
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        doThrow(
                new IntegrationServiceException(
                        RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS,
                        "Test Message")).when(autoPayInstance).autoPay(any(), any());

        instance.autoPay(request, response);

        assertEquals(
                RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS, response.getResult());
    }

    @Test
    public void test_autoPay_When_Exception_Then_OutputWithSubId(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId("1234");
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        doThrow(InvocationTargetException.class).when(autoPayInstance).autoPay(any(), any());

        instance.autoPay(request, response);

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult());
    }

    @Test
    public void test_executeVisibleMultiRequest_When_ServiceReturnsSuccess_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns success."
        };
        td.then = new String[] {
            "No Exception."
        };
        td.printDescription();

        VisibleMultiRequest request = new VisibleMultiRequest();
        request.setSubscriberExternalId("1234");
        VisibleResponseMulti response = new VisibleResponseMulti();
        doNothing().when(subscriberServiceInstance).executeMultiRequest(any(), any());

        assertEquals(0, instance.executeVisibleMultiRequest(request, response));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_executeVisibleMultiRequest_When_VisibleServiceException_Then_OutputWithSubId(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleMultiRequest request = new VisibleMultiRequest();
        MtxSubscriberSearchData ssd = new MtxSubscriberSearchData();
        ssd.setExternalId("1234");

        MtxRequestSubscriberPurchaseOffer rspo = new MtxRequestSubscriberPurchaseOffer();
        rspo.setSubscriberSearchData(ssd);
        request.getRequestListAppender().add(rspo);

        MtxRequestSubscriberModify rsm = new MtxRequestSubscriberModify();
        rsm.setSubscriberSearchData(ssd);
        request.getRequestListAppender().add(rsm);

        MtxRequestSubscriberRecharge rsr = new MtxRequestSubscriberRecharge();
        rsr.setSubscriberSearchData(ssd);
        request.getRequestListAppender().add(rsr);

        VisibleResponseMulti response = new VisibleResponseMulti();
        doThrow(
                new IntegrationServiceException(
                        RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS,
                        "Test Message")).when(subscriberServiceInstance).executeMultiRequest(
                                any(), any());

        instance.executeVisibleMultiRequest(request, response);

        assertEquals(
                RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS, response.getResult());
    }

    @Test
    public void test_executeVisibleMultiRequest_When_Exception_Then_OutputWithSubId(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleMultiRequest request = new VisibleMultiRequest();
        request.setSubscriberExternalId("1234");
        VisibleResponseMulti response = new VisibleResponseMulti();
        doAnswer(invocation -> {
            throw new Exception("");
        }).when(subscriberServiceInstance).executeMultiRequest(any(), any());

        instance.executeVisibleMultiRequest(request, response);

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult());
    }

    @Test
    public void test_reloadConfig_When_ServiceReturnsSuccess_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns success."
        };
        td.then = new String[] {
            "No Exception."
        };
        td.printDescription();

        VisibleRequestReloadConfig request = new VisibleRequestReloadConfig();
        MtxResponse response = new MtxResponse();
        doNothing().when(configInstance).reloadConfig(any(), any());

        assertEquals(0, instance.reloadConfig(request, response));
    }

    @Test
    public void test_reloadConfig_When_VisibleServiceException_Then_OutputWithSubId(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestReloadConfig request = new VisibleRequestReloadConfig();
        MtxResponse response = new MtxResponse();
        doThrow(ConfigServiceException.class).when(configInstance).reloadConfig(any(), any());

        instance.reloadConfig(request, response);

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult());
    }

    @Test
    public void test_getConfig_When_ServiceReturnsSuccess_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns success."
        };
        td.then = new String[] {
            "No Exception."
        };
        td.printDescription();

        VisibleRequestGetConfig request = new VisibleRequestGetConfig();
        VisibleResponseGetConfig response = new VisibleResponseGetConfig();
        doNothing().when(configInstance).getConfig(any(), any());

        assertEquals(0, instance.getConfig(request, response));
    }

    @Test
    public void test_getConfig_When_VisibleServiceException_Then_OutputWithSubId(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.when = new String[] {
            "Service returns Exception."
        };
        td.then = new String[] {
            "Output message has subscriber External Id."
        };
        td.printDescription();

        VisibleRequestGetConfig request = new VisibleRequestGetConfig();
        VisibleResponseGetConfig response = new VisibleResponseGetConfig();
        doThrow(ConfigServiceException.class).when(configInstance).getConfig(any(), any());

        instance.getConfig(request, response);

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult());
    }
}