package com.matrixx.vag.device.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.notification.StoppedByUserException;

import com.matrixx.datacontainer.DataContainer;
import com.matrixx.datacontainer.mdc.VisibleDeviceSwapInfo;
import com.matrixx.datacontainer.mdc.VisibleDeviceSwapOrderInfo;
import com.matrixx.datacontainer.mdc.VisibleDeviceSwapShippingInfo;
import com.matrixx.datacontainer.mdc.VisibleRequestCancelDeviceSwap;
import com.matrixx.datacontainer.mdc.VisibleRequestChargeNrf;
import com.matrixx.datacontainer.mdc.VisibleRequestDeviceSwap;
import com.matrixx.datacontainer.mdc.VisibleRequestFinanceDevice;
import com.matrixx.datacontainer.mdc.VisibleRequestPurchaseDevice;
import com.matrixx.datacontainer.mdc.VisibleRequestReturnFinancedDevice;
import com.matrixx.datacontainer.mdc.VisibleRequestReturnPurchasedDevice;
import com.matrixx.datacontainer.mdc.VisibleRequestReverseNrf;
import com.matrixx.platform.JsonObject;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.common.TestConstants.DATA_DIR;
import com.matrixx.vag.exception.InvalidRequestException;
import com.matrixx.vag.exception.InvalidRequestParameterException;
import com.matrixx.vag.exception.MissingRequestParametersException;
import com.matrixx.vag.util.MDCTest;

public class RequestValidatorTest extends MDCTest {

    private RequestValidator instance;

    private String DIR = "src/test/resources/data/purchasedevice/";

    @Before
    public void setUp() throws Exception {
        instance = new RequestValidator();
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_purchaseDeviceRequest_MissingFields() throws IOException {
        ArrayList<String> testFields = new ArrayList<String>(
                Arrays.asList(
                        "SubscriberExternalId", //
                        "OrderId", //
                        "DeviceSku", //
                        "DeviceOfferExternalId", //
                        "DeviceDiscountPrice", //
                        "DeviceTaxDetails", //
                        "DeviceProvidesService", //
                        "DeviceDetails", //
                        "ShippingSku", //
                        "ShipToBid", //
                        "ShippingOfferExternalId", //
                        "ShippingDiscountPrice", //
                        "ShippingTaxDetails", //
                        "TransactionType", //
                        "FraudHomeAddress", //
                        "FraudShippingAddress", //
                        "PaymentMethod", //
                        "PurchaseOrderInfo", //
                        "PurchaseDeviceInfo", //
                        "PurchaseShippingInfo"));

        String msgInput = new String(
                Files.readAllBytes(
                        Paths.get(DIR + "VisibleRequestPurchaseDevice_ValidSimpleRequest.json")));
        for (String removeField : testFields) {
            Exception respException = null;
            try {
                VisibleRequestPurchaseDevice deviceIn = transform_Json_To_VisibleRequestPurchaseDevice(
                        remove_From_VisibleRequestPurchaseDevice(msgInput, removeField));
                instance.validateRequest("", deviceIn);
            } catch (Exception e) {
                respException = e;
            }
            assertEquals(InvalidRequestException.class, respException.getClass());
        }
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_purchaseDeviceRequest_InvalidValues() throws IOException {

        ArrayList<String> testFields = new ArrayList<String>(
                Arrays.asList(
                        "DeviceDiscountPrice", "DeviceAccessNumber", "DeviceIMSI",
                        "ShippingDiscountPrice"));

        String msgInput = new String(
                Files.readAllBytes(
                        Paths.get(DIR + "VisibleRequestPurchaseDevice_ValidSimpleRequest.json")));

        for (String replaceField : testFields) {
            Exception respException = null;
            try {
                VisibleRequestPurchaseDevice deviceIn = transform_Json_To_VisibleRequestPurchaseDevice(
                        replace_From_VisibleRequestPurchaseDevice(msgInput, replaceField));

                instance.validateRequest("", deviceIn);
            } catch (Exception e) {
                respException = e;
            }
            assertEquals(InvalidRequestException.class, respException.getClass());
        }
    }

    // Not Mandatory Field
    @Test
    public void test_purchaseDeviceRequest_PurchaseFraudInfoMissing() throws Exception {
        VisibleRequestPurchaseDevice purchaseDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestPurchaseDevice.class,
                DIR + "VisibleRequestPurchaseDevice_ValidSimpleRequest.json");

        purchaseDeviceRequest.setPurchaseFraudInfo((VisibleRequestPurchaseDevice) null);
        try {
            instance.validateRequest("InvalidRequestException Test: ", purchaseDeviceRequest);
        } catch (InvalidRequestException ex) {
            fail("Expecting Valid Request");
        }

    }

    @Test
    public void test_purchaseDeviceRequest_InvalidDeferredSettlement() throws Exception {
        VisibleRequestPurchaseDevice purchaseDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestPurchaseDevice.class,
                DIR + "VisibleRequestPurchaseDevice_ValidSimpleRequest.json");

        purchaseDeviceRequest.getPurchaseOrderInfo().setDeferredSettlement("test");
        try {
            instance.validateRequest("InvalidRequestException Test: ", purchaseDeviceRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.getMessage().indexOf("DeferredSettlement") > 0);
        }

    }

    @Test
    public void test_purchaseDeviceRequest_ValidDeferredSettlement() throws Exception {
        VisibleRequestPurchaseDevice purchaseDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestPurchaseDevice.class,
                DIR + "VisibleRequestPurchaseDevice_ValidSimpleRequest.json");

        purchaseDeviceRequest.getPurchaseOrderInfo().setDeferredSettlement("Y");
        try {
            instance.validateRequest("InvalidRequestException Test: ", purchaseDeviceRequest);
        } catch (InvalidRequestException ex) {
            fail("Expecting Valid Request");
        }

        purchaseDeviceRequest.getPurchaseOrderInfo().setDeferredSettlement("N");
        try {
            instance.validateRequest("InvalidRequestException Test: ", purchaseDeviceRequest);
        } catch (InvalidRequestException ex) {
            fail("Expecting Valid Request");
        }

        purchaseDeviceRequest.getPurchaseOrderInfo().setDeferredSettlement("");
        try {
            instance.validateRequest("InvalidRequestException Test: ", purchaseDeviceRequest);
        } catch (InvalidRequestException ex) {
            fail("Expecting Valid Request");
        }

    }

    @Test
    public void test_purchaseDeviceRequest_ValidDeferredSettlementTimeout() throws Exception {
        VisibleRequestPurchaseDevice purchaseDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestPurchaseDevice.class,
                DIR + "VisibleRequestPurchaseDevice_ValidSimpleRequest.json");
        purchaseDeviceRequest.getPurchaseOrderInfo().setDeferredSettlement("Y");
        try {
            instance.validateRequest("InvalidRequestException Test: ", purchaseDeviceRequest);
        } catch (InvalidRequestException ex) {
            fail("Expecting Valid Request");
        }

        purchaseDeviceRequest.getPurchaseOrderInfo().setDeferredSettlementTimeout(10);
        try {
            instance.validateRequest("InvalidRequestException Test: ", purchaseDeviceRequest);
        } catch (InvalidRequestException ex) {
            fail("Expecting Valid Request");
        }

    }

    @Test
    public void test_purchaseDeviceRequest_InvalidDeferredSettlementTimeout_Exception()
            throws Exception {
        VisibleRequestPurchaseDevice purchaseDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestPurchaseDevice.class,
                DIR + "VisibleRequestPurchaseDevice_ValidSimpleRequest.json");
        purchaseDeviceRequest.getPurchaseOrderInfo().setDeferredSettlement("Y");
        purchaseDeviceRequest.getPurchaseOrderInfo().setDeferredSettlementTimeout(-10);
        try {
            instance.validateRequest("InvalidRequestException Test: ", purchaseDeviceRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.getMessage().indexOf("PurchaseOrderInfo.DeferredSettlementTimeout") > 0);
        }

    }

    @Test
    public void test_purchaseDeviceRequest_ValidDeferredSettlementTimeoutAction() throws Exception {
        VisibleRequestPurchaseDevice purchaseDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestPurchaseDevice.class,
                DIR + "VisibleRequestPurchaseDevice_ValidSimpleRequest.json");
        purchaseDeviceRequest.getPurchaseOrderInfo().setDeferredSettlement("Y");
        try {
            instance.validateRequest("InvalidRequestException Test: ", purchaseDeviceRequest);
        } catch (InvalidRequestException ex) {
            fail("Expecting Valid Request");
        }

        purchaseDeviceRequest.getPurchaseOrderInfo().setDeferredSettlementTimeoutAction(1);
        try {
            instance.validateRequest("InvalidRequestException Test: ", purchaseDeviceRequest);
        } catch (InvalidRequestException ex) {
            fail("Expecting Valid Request");
        }

        purchaseDeviceRequest.getPurchaseOrderInfo().setDeferredSettlementTimeoutAction(2);
        try {
            instance.validateRequest("InvalidRequestException Test: ", purchaseDeviceRequest);
        } catch (InvalidRequestException ex) {
            fail("Expecting Valid Request");
        }

    }

    @Test
    public void test_purchaseDeviceRequest_InvalidDeferredSettlementTimeoutAction_Exception()
            throws Exception {
        VisibleRequestPurchaseDevice purchaseDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestPurchaseDevice.class,
                DIR + "VisibleRequestPurchaseDevice_ValidSimpleRequest.json");
        purchaseDeviceRequest.getPurchaseOrderInfo().setDeferredSettlement("Y");
        purchaseDeviceRequest.getPurchaseOrderInfo().setDeferredSettlementTimeoutAction(-2);
        try {
            instance.validateRequest("InvalidRequestException Test: ", purchaseDeviceRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(
                    ex.getMessage().indexOf(
                            "PurchaseOrderInfo.DeferredSettlementTimeoutAction") > 0);
        }

        purchaseDeviceRequest.getPurchaseOrderInfo().setDeferredSettlementTimeoutAction(3);
        try {
            instance.validateRequest("InvalidRequestException Test: ", purchaseDeviceRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(
                    ex.getMessage().indexOf(
                            "PurchaseOrderInfo.DeferredSettlementTimeoutAction") > 0);
        }

    }

    @Test
    public void test_purchaseDeviceRequest_deviceType_DeviceAccessNumberMissing_Exception()
            throws Exception {
        VisibleRequestPurchaseDevice purchaseDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestPurchaseDevice.class,
                DIR + "VisibleRequestPurchaseDevice_ValidSimpleRequest.json");
        purchaseDeviceRequest.getPurchaseDeviceInfo().setDeviceAccessNumber(null);
        try {
            instance.validateRequest("InvalidRequestException Test: ", purchaseDeviceRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.toString().contains("PurchaseDeviceInfo.DeviceAccessNumber"));
        }
    }

    @Test
    public void test_purchaseDeviceRequest_deviceType_DeviceIMSIMissing_Exception()
            throws Exception {
        VisibleRequestPurchaseDevice purchaseDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestPurchaseDevice.class,
                DIR + "VisibleRequestPurchaseDevice_ValidSimpleRequest.json");
        purchaseDeviceRequest.getPurchaseDeviceInfo().setDeviceIMSI(null);
        try {
            instance.validateRequest("InvalidRequestException Test: ", purchaseDeviceRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.toString().contains("PurchaseDeviceInfo.DeviceIMSI"));
        }
    }

    @Test
    public void test_purchaseDeviceRequest_InvalidDeviceType() throws Exception {
        VisibleRequestPurchaseDevice purchaseDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestPurchaseDevice.class,
                DIR + "VisibleRequestPurchaseDevice_ValidSimpleRequest.json");
        purchaseDeviceRequest.getPurchaseDeviceInfo().setDeviceProvidesService("test");
        try {
            instance.validateRequest("Invalid Device Type Test: ", purchaseDeviceRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.toString().contains("PurchaseDeviceInfo.DeviceProvidesService"));
        }
        purchaseDeviceRequest.getPurchaseDeviceInfo().setDeviceProvidesService(null);
        try {
            instance.validateRequest("Invalid Device Type Test: ", purchaseDeviceRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.toString().contains("PurchaseDeviceInfo.DeviceProvidesService"));
        }
    }

    @Test
    public void test_purchaseDeviceRequest_DeviceTypeValid() throws Exception {
        VisibleRequestPurchaseDevice purchaseDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestPurchaseDevice.class,
                DIR + "VisibleRequestPurchaseDevice_ValidSimpleRequest.json");
        purchaseDeviceRequest.getPurchaseDeviceInfo().setDeviceProvidesService("sp");
        try {
            instance.validateRequest("Invalid Device Type Test: ", purchaseDeviceRequest);
        } catch (InvalidRequestException ex) {
            fail("Expecting Valid Request");
        }
        purchaseDeviceRequest.getPurchaseDeviceInfo().setDeviceProvidesService("nsp");
        try {
            instance.validateRequest("Invalid Device Type Test: ", purchaseDeviceRequest);
        } catch (InvalidRequestException ex) {
            fail("Expecting Valid Request");
        }
    }

    @Test
    public void test_returnPurchasedDeviceRequest_PurchaseOrderInfoMissing() throws Exception {
        VisibleRequestReturnPurchasedDevice returnPurchaseDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestReturnPurchasedDevice.class,
                "src/test/resources/data/returndevice/VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json");
        returnPurchaseDeviceRequest.setReturnPurchaseOrderInfo(
                (VisibleRequestReturnPurchasedDevice) null);
        try {
            instance.validateRequest("Invalid Device Type Test: ", returnPurchaseDeviceRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.toString().contains("ReturnPurchaseOrderInfo"));
        }
    }
/*
    @Test
    public void test_returnPurchasedDeviceRequest_InvalidDeviceType() throws Exception {
        VisibleRequestReturnPurchasedDevice returnPurchaseDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestReturnPurchasedDevice.class,
                "src/test/resources/data/returndevice/VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json");
        returnPurchaseDeviceRequest.getReturnPurchaseOrderInfo().setDeviceProvidesService("test");
        try {
            instance.validateRequest("Invalid Device Type Test: ", returnPurchaseDeviceRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.toString().contains("ReturnPurchaseOrderInfo.DeviceProvidesService"));
        }
    }

    @Test
    public void test_returnPurchasedDeviceRequest_ValidDeviceType() throws Exception {
        VisibleRequestReturnPurchasedDevice returnPurchaseDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestReturnPurchasedDevice.class,
                "src/test/resources/data/returndevice/VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json");

        returnPurchaseDeviceRequest.getReturnPurchaseOrderInfo().setDeviceProvidesService("sp");
        try {
            instance.validateRequest("Invalid Device Type Test: ", returnPurchaseDeviceRequest);
        } catch (InvalidRequestException ex) {
            fail("Expecting Valid Request");
        }

        returnPurchaseDeviceRequest.getReturnPurchaseOrderInfo().setDeviceProvidesService("nsp");
        try {
            instance.validateRequest("Invalid Device Type Test: ", returnPurchaseDeviceRequest);
        } catch (InvalidRequestException ex) {
            fail("Expecting Valid Request");
        }
    }

    @Test
    public void test_returnPurchasedDeviceRequest_DeviceInstanceIdMissing() throws Exception {
        VisibleRequestReturnPurchasedDevice returnPurchaseDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestReturnPurchasedDevice.class,
                "src/test/resources/data/returndevice/VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json");
        returnPurchaseDeviceRequest.getReturnPurchaseOrderInfo().setDeviceInstanceId(null);
        try {
            instance.validateRequest("Invalid Device Type Test: ", returnPurchaseDeviceRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.toString().contains("ReturnPurchaseOrderInfo.DeviceInstanceId"));
        }
    }
*/
    @Test
    public void test_returnPurchasedDeviceRequest_MissingFields() throws IOException {
        ArrayList<String> testFields = new ArrayList<String>(
                Arrays.asList(
                        "SubscriberExternalId", "ReturnOrderId",
                        "OriginalOrderDate"));

        String msgInput = new String(
                Files.readAllBytes(
                        Paths.get(
                                "src/test/resources/data/returndevice/VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json")));
        for (String removeField : testFields) {
            Exception respException = null;
            try {
                VisibleRequestReturnPurchasedDevice deviceIn = transform_Json_To_VisibleRequestReturnPurchasedDevice(
                        remove_From_VisibleRequestReturnPurchasedDevice(msgInput, removeField));
                instance.validateRequest("", deviceIn);
            } catch (Exception e) {
                respException = e;
            }
            assertEquals(InvalidRequestException.class, respException.getClass());
        }
    }

    @Test
    public void test_returnPurchasedDeviceRequest_InvalidValues() throws IOException {
        ArrayList<String> testFields = new ArrayList<String>(Arrays.asList("OriginalOrderDate"));

        String msgInput = new String(
                Files.readAllBytes(
                        Paths.get(
                                "src/test/resources/data/returndevice/VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json")));

        for (String replaceField : testFields) {
            Exception respException = null;
            try {
                VisibleRequestReturnPurchasedDevice deviceIn = transform_Json_To_VisibleRequestReturnPurchasedDevice(
                        replace_From_VisibleRequestReturnPurchasedDevice(msgInput, replaceField));

                instance.validateRequest("", deviceIn);
            } catch (Exception e) {
                respException = e;
            }
            assertEquals(InvalidRequestException.class, respException.getClass());
        }

    }

    @Test
    public void test_financeDeviceRequest_FinanceOrderInfoMissing() throws Exception {

        VisibleRequestFinanceDevice financeDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestFinanceDevice.class,
                "src/test/resources/data/purchasefinance/VisibleRequestFinanceDevice_ValidRequest.json");

        financeDeviceRequest.setFinanceOrderInfo((VisibleRequestFinanceDevice) null);
        try {
            instance.validateRequest("Invalid Device Type Test: ", financeDeviceRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.getMessage().indexOf("FinanceOrderInfo") > 0);
        }

    }

    @Test
    public void test_financeDeviceRequest_FinanceDeviceInfoMissing() throws Exception {

        VisibleRequestFinanceDevice financeDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestFinanceDevice.class,
                "src/test/resources/data/purchasefinance/VisibleRequestFinanceDevice_ValidRequest.json");

        financeDeviceRequest.setFinanceDeviceInfo((VisibleRequestFinanceDevice) null);
        try {
            instance.validateRequest("Invalid Device Type Test: ", financeDeviceRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.getMessage().indexOf("FinanceDeviceInfo") > 0);
        }

    }

    @Test
    public void test_financeDeviceRequest_FinanceShippingInfoMissing() throws Exception {

        VisibleRequestFinanceDevice financeDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestFinanceDevice.class,
                "src/test/resources/data/purchasefinance/VisibleRequestFinanceDevice_ValidRequest.json");

        financeDeviceRequest.setFinanceShippingInfo((VisibleRequestFinanceDevice) null);
        try {
            instance.validateRequest("Invalid Device Type Test: ", financeDeviceRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.getMessage().indexOf("FinanceShippingInfo") > 0);
        }

    }

    @Test
    public void test_financeDeviceRequest_FinanceDeviceInfo_DeviceAccessNumberMissing()
            throws Exception {

        VisibleRequestFinanceDevice financeDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestFinanceDevice.class,
                "src/test/resources/data/purchasefinance/VisibleRequestFinanceDevice_ValidRequest.json");

        financeDeviceRequest.getFinanceDeviceInfo().setDeviceAccessNumber(null);
        try {
            instance.validateRequest("Invalid Device Type Test: ", financeDeviceRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.toString().contains("FinanceDeviceInfo.DeviceAccessNumber"));
        }

    }

    @Test
    public void test_financeDeviceRequest_FinanceDeviceInfo_DeviceIMSIMissing() throws Exception {

        VisibleRequestFinanceDevice financeDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestFinanceDevice.class,
                "src/test/resources/data/purchasefinance/VisibleRequestFinanceDevice_ValidRequest.json");

        financeDeviceRequest.getFinanceDeviceInfo().setDeviceIMSI(null);
        try {
            instance.validateRequest("Invalid Device Type Test: ", financeDeviceRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.toString().contains("FinanceDeviceInfo.DeviceIMSI"));
        }

    }

    @Test
    public void test_financeDeviceRequest_FinanceDeviceInfo_DeviceIMSIValid() throws Exception {

        VisibleRequestFinanceDevice financeDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestFinanceDevice.class,
                "src/test/resources/data/purchasefinance/VisibleRequestFinanceDevice_ValidRequest.json");

        try {
            instance.validateRequest("Invalid Device Type Test: ", financeDeviceRequest);
        } catch (InvalidRequestException ex) {
            fail("Expecting Valid Request");
        }

    }

    @Test
    public void test_financeDeviceRequest_FinanceDeviceInfo_DeviceTypeInvalid() throws Exception {

        VisibleRequestFinanceDevice financeDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestFinanceDevice.class,
                "src/test/resources/data/purchasefinance/VisibleRequestFinanceDevice_ValidRequest.json");

        financeDeviceRequest.getFinanceDeviceInfo().setDeviceProvidesService(null);
        try {
            instance.validateRequest("Invalid Device Type Test: ", financeDeviceRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.toString().contains("FinanceDeviceInfo.DeviceProvidesService"));
        }

        financeDeviceRequest.getFinanceDeviceInfo().setDeviceProvidesService("test");
        try {
            instance.validateRequest("Invalid Device Type Test: ", financeDeviceRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.toString().contains("FinanceDeviceInfo.DeviceProvidesService"));
        }

    }

    @Test
    public void test_financeDeviceRequest_FinanceDeviceInfo_DeviceTypeValid() throws Exception {

        VisibleRequestFinanceDevice financeDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestFinanceDevice.class,
                "src/test/resources/data/purchasefinance/VisibleRequestFinanceDevice_ValidRequest.json");

        financeDeviceRequest.getFinanceDeviceInfo().setDeviceProvidesService("sp");
        try {
            instance.validateRequest("Invalid Device Type Test: ", financeDeviceRequest);
        } catch (InvalidRequestException ex) {
            fail("Expecting Valid Request");
        }

        financeDeviceRequest.getFinanceDeviceInfo().setDeviceProvidesService("nsp");
        try {
            instance.validateRequest("Invalid Device Type Test: ", financeDeviceRequest);
        } catch (InvalidRequestException ex) {
            fail("Expecting Valid Request");
        }

    }

    @Test
    public void test_financeDeviceRequest_MissingFields() throws IOException {
        ArrayList<String> testFields = new ArrayList<String>(
                Arrays.asList(
                        "SubscriberExternalId", //
                        "OrderId", //
                        "ChargeId", //
                        "DeviceSku", //
                        "DeviceOfferExternalId", //
                        // "DeviceGrossPrice", //
                        "DeviceDiscountPrice", //
                        "DeviceFinanceAmount", //
                        "DeviceTaxDetails", //
                        "DeviceProvidesService", //
                        "DeviceDetails", //
                        "ShippingSku", //
                        // "ShippingGeocode", //
                        "ShipToBid", //
                        "ShippingOfferExternalId", //
                        // "ShippingGrossPrice", //
                        "ShippingDiscountPrice", //
                        // "ShippingTotalTax", //
                        "ShippingTaxDetails"));

        String msgInput = new String(
                Files.readAllBytes(
                        Paths.get(
                                "src/test/resources/data/purchasefinance/VisibleRequestFinanceDevice_ValidRequest.json")));
        for (String removeField : testFields) {
            Exception respException = null;
            try {
                VisibleRequestFinanceDevice deviceIn = transform_Json_To_VisibleRequestFinanceDevice(
                        remove_From_VisibleRequestFinanceDevice(msgInput, removeField));
                instance.validateRequest("", deviceIn);
            } catch (Exception e) {
                respException = e;
            }
            assertEquals(InvalidRequestException.class, respException.getClass());
        }
    }

    @Test
    public void test_financeDeviceRequest_InvalidValues() throws IOException {

        ArrayList<String> testFields = new ArrayList<String>(
                Arrays.asList(
                        "DeviceDiscountPrice", "DeviceAccessNumber", "DeviceFinanceAmount",
                        "DeviceIMSI", "ShippingDiscountPrice"));

        String msgInput = new String(
                Files.readAllBytes(
                        Paths.get(
                                "src/test/resources/data/purchasefinance/VisibleRequestFinanceDevice_ValidRequest.json")));

        for (String replaceField : testFields) {
            Exception respException = null;
            try {
                VisibleRequestFinanceDevice deviceIn = transform_Json_To_VisibleRequestFinanceDevice(
                        replace_From_VisibleRequestFinanceDevice(msgInput, replaceField));

                instance.validateRequest("", deviceIn);
            } catch (Exception e) {
                respException = e;
            }
            assertEquals(InvalidRequestException.class, respException.getClass());
        }
    }

    @Test
    public void test_returnFinanceDeviceRequest_FinanceOrderInfoMissing() throws Exception {

        VisibleRequestReturnFinancedDevice returnFinanceDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestReturnFinancedDevice.class,
                "src/test/resources/data/returnfinance/VisibleRequestReturnFinancedDevice_ValidRequest.json");

        returnFinanceDeviceRequest.setReturnFinanceOrderInfo(
                (VisibleRequestReturnFinancedDevice) null);
        try {
            instance.validateRequest("Invalid Device Type Test: ", returnFinanceDeviceRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.toString().contains("ReturnFinanceOrderInfo"));
        }

    }

    @Test
    public void test_returnFinanceDeviceRequest_FinanceOrderInfo_OriginalOrderDateMissing()
            throws Exception {

        VisibleRequestReturnFinancedDevice returnFinanceDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestReturnFinancedDevice.class,
                "src/test/resources/data/returnfinance/VisibleRequestReturnFinancedDevice_ValidRequest.json");

        returnFinanceDeviceRequest.getReturnFinanceOrderInfo().setOriginalOrderDate(null);
        try {
            instance.validateRequest("Invalid Device Type Test: ", returnFinanceDeviceRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.toString().contains("ReturnFinanceOrderInfo.OriginalOrderDate"));
        }

    }

    @Test
    public void test_returnFinanceDeviceRequest_FinanceOrderInfo_OriginalOrderDateValid()
            throws Exception {

        VisibleRequestReturnFinancedDevice returnFinanceDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestReturnFinancedDevice.class,
                "src/test/resources/data/returnfinance/VisibleRequestReturnFinancedDevice_ValidRequest.json");

        try {
            instance.validateRequest("Invalid Device Type Test: ", returnFinanceDeviceRequest);
        } catch (InvalidRequestException ex) {
            fail("Expecting Valid Request");
        }

    }

    @Test
    public void test_returnFinanceDeviceRequest_FinanceOrderInfo_DeviceInstanceIdMissing()
            throws Exception {

        VisibleRequestReturnFinancedDevice returnFinanceDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestReturnFinancedDevice.class,
                "src/test/resources/data/returnfinance/VisibleRequestReturnFinancedDevice_ValidRequest.json");

        returnFinanceDeviceRequest.getReturnFinanceOrderInfo().setDeviceInstanceId(null);
        try {
            instance.validateRequest("Invalid Device Type Test: ", returnFinanceDeviceRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.toString().contains("ReturnFinanceOrderInfo.DeviceInstanceId"));
        }

    }

    @Test
    public void test_returnFinanceDeviceRequest_FinanceOrderInfo_InvalidDeviceType()
            throws Exception {

        VisibleRequestReturnFinancedDevice returnFinanceDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestReturnFinancedDevice.class,
                "src/test/resources/data/returnfinance/VisibleRequestReturnFinancedDevice_ValidRequest.json");

        returnFinanceDeviceRequest.getReturnFinanceOrderInfo().setDeviceProvidesService("test");
        try {
            instance.validateRequest("Invalid Device Type Test: ", returnFinanceDeviceRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.toString().contains("ReturnFinanceOrderInfo.DeviceProvidesService"));
        }

    }

    @Test
    public void test_returnFinanceDeviceRequest_FinanceOrderInfo_DeviceTypeValid()
            throws Exception {

        VisibleRequestReturnFinancedDevice returnFinanceDeviceRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestReturnFinancedDevice.class,
                "src/test/resources/data/returnfinance/VisibleRequestReturnFinancedDevice_ValidRequest.json");

        returnFinanceDeviceRequest.getReturnFinanceOrderInfo().setDeviceProvidesService("sp");
        try {
            instance.validateRequest("Invalid Device Type Test: ", returnFinanceDeviceRequest);
        } catch (InvalidRequestException ex) {
            fail("Expecting Valid Request");
        }

        returnFinanceDeviceRequest.getReturnFinanceOrderInfo().setDeviceProvidesService("nsp");
        try {
            instance.validateRequest("Invalid Device Type Test: ", returnFinanceDeviceRequest);
        } catch (InvalidRequestException ex) {
            fail("Expecting Valid Request");
        }
    }

    @Test
    public void test_returnFinancedDeviceRequest_MissingFields() throws IOException {
        ArrayList<String> testFields = new ArrayList<String>(
                Arrays.asList(
                        "SubscriberExternalId", "ReturnOrderId", "OriginalOrderId",
                        "OriginalOrderDate", "ChargeId", "DeviceProvidesService"));

        String msgInput = new String(
                Files.readAllBytes(
                        Paths.get(
                                "src/test/resources/data/returnfinance/VisibleRequestReturnFinancedDevice_ValidRequest.json")));
        for (String removeField : testFields) {
            Exception respException = null;
            try {
                VisibleRequestReturnFinancedDevice deviceIn = transform_Json_To_VisibleRequestReturnFinancedDevice(
                        remove_From_VisibleRequestReturnFinancedDevice(msgInput, removeField));
                instance.validateRequest("", deviceIn);
            } catch (Exception e) {
                respException = e;
            }
            assertEquals(InvalidRequestException.class, respException.getClass());
        }
    }

    @Test
    public void test_returnFinancedDeviceRequest_InvalidValues() throws IOException {
        ArrayList<String> testFields = new ArrayList<String>(Arrays.asList("OriginalOrderDate"));

        String msgInput = new String(
                Files.readAllBytes(
                        Paths.get(
                                "src/test/resources/data/returnfinance/VisibleRequestReturnFinancedDevice_ValidRequest.json")));

        for (String replaceField : testFields) {
            Exception respException = null;
            try {
                VisibleRequestReturnFinancedDevice deviceIn = transform_Json_To_VisibleRequestReturnFinancedDevice(
                        replace_From_VisibleRequestReturnFinancedDevice(msgInput, replaceField));

                instance.validateRequest("", deviceIn);
            } catch (Exception e) {
                respException = e;
            }
            assertEquals(InvalidRequestException.class, respException.getClass());
        }
    }

    @Test
    public void test_deviceSwapRequest_RecurringServiceChargeInvalid() throws Exception {

        VisibleRequestDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestDeviceSwap.class,
                "src/test/resources/data/purchasedeviceswap/SampleDeviceSwapRequest.json");
        System.out.println(deviceSwapRequest.toJson());
        RequestValidator.validateRequest("Valid Test", deviceSwapRequest);

        deviceSwapRequest.getDeviceSwapInfo().setRecurringServiceCharge("Fail");
        try {
            RequestValidator.validateRequest(
                    "InvalidRequestParameterException Test: ", deviceSwapRequest);
            fail("Expecting InvalidRequestParameterException");
        } catch (InvalidRequestParameterException ex) {
            assertTrue(ex.getMessage().indexOf("DeviceSwapInfo.RecurringServiceCharge") > 0);
        }

    }

    @Test
    public void test_deviceSwapRequest_SubscriberExternalIdMissing() throws Exception {

        VisibleRequestDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestDeviceSwap.class,
                "src/test/resources/data/purchasedeviceswap/SampleDeviceSwapRequest.json");

        deviceSwapRequest.setSubscriberExternalId(null);
        try {
            RequestValidator.validateRequest(
                    "MissingRequestParametersException Test: ", deviceSwapRequest);
            fail("Expecting MissingRequestParametersException");
        } catch (MissingRequestParametersException ex) {
            assertTrue(ex.getMessage().indexOf("SubscriberExternalId") > 0);
        }

    }

    @Test
    public void test_deviceSwapRequest_PurchaseOrderInfoMissing() throws Exception {

        VisibleRequestDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestDeviceSwap.class,
                "src/test/resources/data/purchasedeviceswap/SampleDeviceSwapRequest.json");

        deviceSwapRequest.setPurchaseOrderInfo((VisibleDeviceSwapOrderInfo) null);
        try {
            RequestValidator.validateRequest(
                    "MissingRequestParametersException Test: ", deviceSwapRequest);
            fail("Expecting MissingRequestParametersException");
        } catch (MissingRequestParametersException ex) {
            assertTrue(ex.getMessage().indexOf("PurchaseOrderInfo") > 0);
        }

    }

    @Test
    public void test_deviceSwapRequest_PurchaseOrderInfo_OrderIdMissing() throws Exception {

        VisibleRequestDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestDeviceSwap.class,
                "src/test/resources/data/purchasedeviceswap/SampleDeviceSwapRequest.json");

        deviceSwapRequest.getPurchaseOrderInfo().setOrderId(null);
        try {
            RequestValidator.validateRequest(
                    "MissingRequestParametersException Test: ", deviceSwapRequest);
            fail("Expecting MissingRequestParametersException");
        } catch (MissingRequestParametersException ex) {
            assertTrue(ex.getMessage().indexOf("PurchaseOrderInfo.OrderId") > 0);
        }

    }

    @Test
    public void test_deviceSwapRequest_DeviceSwapInfoMissing() throws Exception {

        VisibleRequestDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestDeviceSwap.class,
                "src/test/resources/data/purchasedeviceswap/SampleDeviceSwapRequest.json");

        deviceSwapRequest.setDeviceSwapInfo((VisibleDeviceSwapInfo) null);
        try {
            RequestValidator.validateRequest(
                    "MissingRequestParametersException Test: ", deviceSwapRequest);
            fail("Expecting MissingRequestParametersException");
        } catch (MissingRequestParametersException ex) {
            assertTrue(ex.getMessage().indexOf("DeviceSwapInfo") > 0);
        }

    }

    @Test
    public void test_deviceSwapRequest_DeviceSwapInfo_NewDeviceSKUMissing() throws Exception {

        VisibleRequestDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestDeviceSwap.class,
                "src/test/resources/data/purchasedeviceswap/SampleDeviceSwapRequest.json");

        deviceSwapRequest.getDeviceSwapInfo().setNewDeviceSku(null);
        try {
            RequestValidator.validateRequest(
                    "MissingRequestParametersException Test: ", deviceSwapRequest);
            fail("Expecting MissingRequestParametersException");
        } catch (MissingRequestParametersException ex) {
            assertTrue(ex.getMessage().indexOf("DeviceSwapInfo.NewDeviceSku") > 0);
        }

    }

    @Test
    public void test_deviceSwapRequest_DeviceSwapInfo_DeviceSwapOfferExternalIdMissing()
            throws Exception {

        VisibleRequestDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestDeviceSwap.class,
                "src/test/resources/data/purchasedeviceswap/SampleDeviceSwapRequest.json");

        deviceSwapRequest.getDeviceSwapInfo().setDeviceSwapOfferExternalId(null);
        try {
            RequestValidator.validateRequest(
                    "MissingRequestParametersException Test: ", deviceSwapRequest);
            fail("Expecting MissingRequestParametersException");
        } catch (MissingRequestParametersException ex) {
            assertTrue(ex.getMessage().indexOf("DeviceSwapInfo.DeviceSwapOfferExternalId") > 0);
        }

    }

    @Test
    public void test_deviceSwapRequest_DeviceSwapInfo_NewDeviceCOGSMissing() throws Exception {

        VisibleRequestDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestDeviceSwap.class,
                "src/test/resources/data/purchasedeviceswap/SampleDeviceSwapRequest.json");

        // Device Swap Info - New Device COGS
        deviceSwapRequest.getDeviceSwapInfo().setNewDeviceCOGS(null);
        try {
            RequestValidator.validateRequest(
                    "MissingRequestParametersException Test: ", deviceSwapRequest);
            fail("Expecting MissingRequestParametersException");
        } catch (MissingRequestParametersException ex) {
            assertTrue(ex.getMessage().indexOf("DeviceSwapInfo.NewDeviceCOGS") > 0);
        }

    }

    @Test
    public void test_deviceSwapRequest_DeviceSwapInfo_RecurringServiceChargesMissing()
            throws Exception {

        VisibleRequestDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestDeviceSwap.class,
                "src/test/resources/data/purchasedeviceswap/SampleDeviceSwapRequest.json");

        deviceSwapRequest.getDeviceSwapInfo().setRecurringServiceCharge(null);
        try {
            RequestValidator.validateRequest(
                    "MissingRequestParametersException Test: ", deviceSwapRequest);
            fail("Expecting MissingRequestParametersException");
        } catch (MissingRequestParametersException ex) {
            assertTrue(ex.getMessage().indexOf("DeviceSwapInfo.RecurringServiceCharge") > 0);
        }

    }

    @Test
    public void test_deviceSwapRequest_DeviceSwapInfo_NewDeviceTaxDetailsMissing()
            throws Exception {

        VisibleRequestDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestDeviceSwap.class,
                "src/test/resources/data/purchasedeviceswap/SampleDeviceSwapRequest.json");

        deviceSwapRequest.getDeviceSwapInfo().setNewDeviceTaxDetails(null);
        try {
            RequestValidator.validateRequest(
                    "MissingRequestParametersException Test: ", deviceSwapRequest);
            fail("Expecting MissingRequestParametersException");
        } catch (MissingRequestParametersException ex) {
            assertTrue(ex.getMessage().indexOf("DeviceSwapInfo.NewDeviceTaxDetails") > 0);
        }

    }

    @Test
    public void test_deviceSwapRequest_DeviceSwapInfo_NewDeviceDetailsMissing() throws Exception {

        VisibleRequestDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestDeviceSwap.class,
                "src/test/resources/data/purchasedeviceswap/SampleDeviceSwapRequest.json");

        deviceSwapRequest.getDeviceSwapInfo().setNewDeviceDetails(null);
        try {
            RequestValidator.validateRequest(
                    "MissingRequestParametersException Test: ", deviceSwapRequest);
            fail("Expecting MissingRequestParametersException");
        } catch (MissingRequestParametersException ex) {
            assertTrue(ex.getMessage().indexOf("DeviceSwapInfo.NewDeviceDetails") > 0);
        }

    }

    @Test
    public void test_deviceSwapRequest_DeviceSwapInfo_SwappedDeviceResidualValueMissing()
            throws Exception {

        VisibleRequestDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestDeviceSwap.class,
                "src/test/resources/data/purchasedeviceswap/SampleDeviceSwapRequest.json");

        deviceSwapRequest.getDeviceSwapInfo().setSwappedDeviceResidualValue(null);
        try {
            RequestValidator.validateRequest(
                    "MissingRequestParametersException Test: ", deviceSwapRequest);
            fail("Expecting MissingRequestParametersException");
        } catch (MissingRequestParametersException ex) {
            assertTrue(ex.getMessage().indexOf("DeviceSwapInfo.SwappedDeviceResidualValue") > 0);
        }

    }

    @Test
    public void test_deviceSwapRequest_DeviceSwapShippingInfoMissing() throws Exception {

        VisibleRequestDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestDeviceSwap.class,
                "src/test/resources/data/purchasedeviceswap/SampleDeviceSwapRequest.json");

        deviceSwapRequest.setDeviceSwapShippingInfo((VisibleDeviceSwapShippingInfo) null);
        try {
            RequestValidator.validateRequest(
                    "MissingRequestParametersException Test: ", deviceSwapRequest);
            fail("Expecting MissingRequestParametersException");
        } catch (MissingRequestParametersException ex) {
            assertTrue(ex.getMessage().indexOf("DeviceSwapShippingInfo") > 0);
        }

    }

    @Test
    public void test_deviceSwapRequest_DeviceSwapShippingInfo_ShipToBidMissing() throws Exception {

        VisibleRequestDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestDeviceSwap.class,
                "src/test/resources/data/purchasedeviceswap/SampleDeviceSwapRequest.json");

        deviceSwapRequest.getDeviceSwapShippingInfo().setShipToBid(null);
        try {
            RequestValidator.validateRequest(
                    "MissingRequestParametersException Test: ", deviceSwapRequest);
            fail("Expecting MissingRequestParametersException");
        } catch (MissingRequestParametersException ex) {
            assertTrue(ex.getMessage().indexOf("DeviceSwapShippingInfo.ShipToBid") > 0);
        }

    }

    @Test
    public void test_cancelDeviceSwapRequest_SubscriberExternalIdMissing() throws Exception {

        VisibleRequestCancelDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestCancelDeviceSwap.class,
                "src/test/resources/data/canceldeviceswap/VisibleRequestCancelDeviceSwap.json");

        deviceSwapRequest.setSubscriberExternalId(null);
        try {
            instance.validateRequest("MissingRequestParametersException Test: ", deviceSwapRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.getMessage().indexOf("SubscriberExternalId") > 0);
        }
    }

    @Test
    public void test_cancelDeviceSwapRequest_OrderInfoMissing() throws Exception {

        VisibleRequestCancelDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestCancelDeviceSwap.class,
                "src/test/resources/data/canceldeviceswap/VisibleRequestCancelDeviceSwap.json");

        deviceSwapRequest.setCancelDeviceSwapOrderInfo((VisibleRequestCancelDeviceSwap) null);
        try {
            instance.validateRequest("MissingRequestParametersException Test: ", deviceSwapRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.getMessage().indexOf("CancelDeviceSwapOrderInfo") > 0);
        }
    }

    @Test
    public void test_cancelDeviceSwapRequest_OrderInfo_ReturnOrderIdMissing() throws Exception {

        VisibleRequestCancelDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestCancelDeviceSwap.class,
                "src/test/resources/data/canceldeviceswap/VisibleRequestCancelDeviceSwap.json");

        deviceSwapRequest.getCancelDeviceSwapOrderInfo().setReturnOrderId(null);
        try {
            instance.validateRequest("MissingRequestParametersException Test: ", deviceSwapRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.getMessage().indexOf("CancelDeviceSwapOrderInfo.ReturnOrderId") > 0);
        }
    }

    @Test
    public void test_cancelDeviceSwapRequest_OrderInfo_OriginalOrderIdMissing() throws Exception {

        VisibleRequestCancelDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestCancelDeviceSwap.class,
                "src/test/resources/data/canceldeviceswap/VisibleRequestCancelDeviceSwap.json");

        deviceSwapRequest.getCancelDeviceSwapOrderInfo().setOriginalOrderId(null);
        try {
            instance.validateRequest("MissingRequestParametersException Test: ", deviceSwapRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.getMessage().indexOf("CancelDeviceSwapOrderInfo.OriginalOrderId") > 0);
        }
    }

    @Test
    public void test_cancelDeviceSwapRequest_OrderInfo_OfferExternalIdMissing() throws Exception {

        VisibleRequestCancelDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestCancelDeviceSwap.class,
                "src/test/resources/data/canceldeviceswap/VisibleRequestCancelDeviceSwap.json");

        deviceSwapRequest.getCancelDeviceSwapOrderInfo().setDeviceSwapOfferExternalId(null);
        try {
            instance.validateRequest("MissingRequestParametersException Test: ", deviceSwapRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(
                    ex.getMessage().indexOf(
                            "CancelDeviceSwapOrderInfo.DeviceSwapOfferExternalId") > 0);
        }
    }

    @Test
    public void test_cancelDeviceSwapRequest_OrderInfo_OriginalOrderDateMissing() throws Exception {

        VisibleRequestCancelDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestCancelDeviceSwap.class,
                "src/test/resources/data/canceldeviceswap/VisibleRequestCancelDeviceSwap.json");

        deviceSwapRequest.getCancelDeviceSwapOrderInfo().setOriginalOrderDate(null);
        try {
            instance.validateRequest("MissingRequestParametersException Test: ", deviceSwapRequest);
        } catch (InvalidRequestException ex) {
            fail("Expecting Valid Request");
        }
    }

    @Test
    public void test_cancelDeviceSwapRequest_OrderInfo_OriginalOrderDateValid() throws Exception {

        VisibleRequestCancelDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestCancelDeviceSwap.class,
                "src/test/resources/data/canceldeviceswap/VisibleRequestCancelDeviceSwap.json");

        deviceSwapRequest.getCancelDeviceSwapOrderInfo().setOriginalOrderDate("2018-07-15");
        try {
            instance.validateRequest("MissingRequestParametersException Test: ", deviceSwapRequest);
        } catch (InvalidRequestException ex) {
            fail("Expecting Valid Request");
        }
    }

    @Test
    public void test_cancelDeviceSwapRequest_OrderInfo_InvalidOriginalOrderDate() throws Exception {

        VisibleRequestCancelDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestCancelDeviceSwap.class,
                "src/test/resources/data/canceldeviceswap/VisibleRequestCancelDeviceSwap.json");

        deviceSwapRequest.getCancelDeviceSwapOrderInfo().setOriginalOrderDate("test");
        try {
            instance.validateRequest("MissingRequestParametersException Test: ", deviceSwapRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.toString().contains("CancelDeviceSwapOrderInfo.OriginalOrderDate"));
        }
    }

    @Test
    public void test_chargeNRFRequest_MissingFields() throws StoppedByUserException {
        ArrayList<String> testFields = new ArrayList<String>(
                Arrays.asList(
                        "SubscriberExternalId", //
                        "OrderId", //
                        "PaymentMethod", //
                        "OfferSku", //
                        "OfferExternalId", //
                        "OfferDiscountPrice", //
                        "OfferTaxDetails", //
                        "OfferTotalTax", "OfferDetails", //
                        "ShipToBid", //
                        "TransactionType", //
                        "FraudHomeAddress", //
                        "FraudShippingAddress"));

        for (String removeField : testFields) {
            Exception respException = null;
            try {
                VisibleRequestChargeNrf chargeIn = CommonTestHelper.loadJsonMessage(
                        VisibleRequestChargeNrf.class,
                        DATA_DIR.CHARGE_NRF + "VisibleRequestChargeNrf_ValidSimpleRequest.json",
                        removeField);
                instance.validateRequest("", chargeIn);
            } catch (Exception e) {
                respException = e;
            }
            assertEquals(
                    InvalidRequestException.class.getName(), respException.getClass().getName());
        }
    }

    @Test
    public void test_chargeNRFRequest_InvalidValues() throws IOException {

        ArrayList<String> testFields = new ArrayList<String>(
                Arrays.asList("OfferDiscountPrice", "OfferTotalTax"));

        for (String replaceField : testFields) {
            Exception respException = null;
            try {
                VisibleRequestChargeNrf deviceIn = CommonTestHelper.loadJsonMessage(
                        VisibleRequestChargeNrf.class,
                        DATA_DIR.CHARGE_NRF + "VisibleRequestChargeNrf_ValidSimpleRequest.json");
                switch (replaceField) {
                    case "OfferDiscountPrice":
                        deviceIn.getNrfOfferInfo().setOfferDiscountPrice("replaceString");
                        break;
                    case "OfferTotalTax":
                        deviceIn.getNrfOfferInfo().setOfferTotalTax("replaceString");
                        break;
                }

                instance.validateRequest("", deviceIn);
            } catch (Exception e) {
                respException = e;
            }
            assertEquals(
                    InvalidRequestException.class.getName(), respException.getClass().getName());
        }
    }

    @Test
    public void test_chargeNRFRequest_NRFOrderInfoMissing() throws Exception {

        VisibleRequestChargeNrf deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestChargeNrf.class,
                DATA_DIR.CHARGE_NRF + "VisibleRequestChargeNrf_ValidSimpleRequest.json");

        deviceSwapRequest.setNrfOrderInfo((VisibleRequestChargeNrf) null);
        try {
            instance.validateRequest("InvalidRequestException Test: ", deviceSwapRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.getMessage().indexOf("NrfOrderInfo") > 0);
        }

    }

    @Test
    public void test_chargeNRFRequest_NRFOfferInfoMissing() throws Exception {

        VisibleRequestChargeNrf deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestChargeNrf.class,
                DATA_DIR.CHARGE_NRF + "VisibleRequestChargeNrf_ValidSimpleRequest.json");

        deviceSwapRequest.setNrfOfferInfo((VisibleRequestChargeNrf) null);
        try {
            instance.validateRequest("InvalidRequestException Test: ", deviceSwapRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.getMessage().indexOf("NrfOfferInfo") > 0);
        }

    }

    @Test
    public void test_chargeNRFRequest_NRFShippingInfoMissing() throws Exception {

        VisibleRequestChargeNrf deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestChargeNrf.class,
                DATA_DIR.CHARGE_NRF + "VisibleRequestChargeNrf_ValidSimpleRequest.json");

        deviceSwapRequest.setNrfShippingInfo((VisibleRequestChargeNrf) null);
        try {
            instance.validateRequest("InvalidRequestException Test: ", deviceSwapRequest);
            fail("Expecting InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.getMessage().indexOf("NrfShippingInfo") > 0);
        }

    }

    @Test
    public void test_chargeNRFRequest_NRFFraudInfoMissing() throws Exception {

        VisibleRequestChargeNrf deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestChargeNrf.class,
                DATA_DIR.CHARGE_NRF + "VisibleRequestChargeNrf_ValidSimpleRequest.json");

        deviceSwapRequest.setNrfFraudInfo((VisibleRequestChargeNrf) null);
        try {
            instance.validateRequest("InvalidRequestException Test: ", deviceSwapRequest);
        } catch (InvalidRequestException ex) {
            fail("Expecting Valid Request");
        }

    }

    @Test
    public void test_reverseNRFRequest_MissingFields() throws StoppedByUserException {
        ArrayList<String> testFields = new ArrayList<String>(
                Arrays.asList(
                        "SubscriberExternalId", //
                        "OfferExternalId", //
                        "OriginalOrderId", //
                        "ReturnOrderId"));

        for (String removeField : testFields) {
            Exception respException = null;
            try {
                VisibleRequestReverseNrf cancelIn = CommonTestHelper.loadJsonMessage(
                        VisibleRequestReverseNrf.class,
                        DATA_DIR.REVERSE_NRF + "VisibleRequestReverseNrf.json", removeField);
                instance.validateRequest("", cancelIn);
            } catch (Exception e) {
                respException = e;
            }
            assertEquals(
                    InvalidRequestException.class.getName(), respException.getClass().getName());
        }
    }

    @Test
    public void test_reverseNRFRequest_InvalidValue() throws IOException {

        ArrayList<String> testFields = new ArrayList<String>(Arrays.asList("OriginalOrderDate"));

        for (String replaceField : testFields) {
            Exception respException = null;
            try {
                VisibleRequestReverseNrf cancelIn = CommonTestHelper.loadJsonMessage(
                        VisibleRequestReverseNrf.class,
                        DATA_DIR.REVERSE_NRF + "VisibleRequestReverseNrf.json");
                switch (replaceField) {
                    case "OriginalOrderDate":
                        cancelIn.getCancelNrfOrderInfo().setOriginalOrderDate("replaceString");
                        break;
                }

                instance.validateRequest("", cancelIn);
            } catch (Exception e) {
                respException = e;
            }
            assertEquals(
                    InvalidRequestException.class.getName(), respException.getClass().getName());
        }
    }

    @Test
    public void test_reverseNRFRequest_CancelNRFOrderInfoMissing() throws Exception {

        VisibleRequestReverseNrf deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestReverseNrf.class, DATA_DIR.REVERSE_NRF + "VisibleRequestReverseNrf.json");

        deviceSwapRequest.setCancelNrfOrderInfo((VisibleRequestReverseNrf) null);
        try {
            instance.validateRequest("InvalidRequestException Test: ", deviceSwapRequest);
            fail("Expecting InvalidValidException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.toString().contains("CancelNrfOrderInfo"));
        }

    }

    @Test
    public void test_reverseNRFRequest_CancelNRFOrderInfo_OriginalOrderDateMissing()
            throws Exception {

        VisibleRequestReverseNrf deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestReverseNrf.class, DATA_DIR.REVERSE_NRF + "VisibleRequestReverseNrf.json");

        deviceSwapRequest.getCancelNrfOrderInfo().setOriginalOrderDate(null);
        try {
            instance.validateRequest("InvalidRequestException Test: ", deviceSwapRequest);
        } catch (InvalidRequestException ex) {
            fail("Expecting Valid Request");
        }

    }

    @Test
    public void test_reverseNRFRequest_CancelNRFOrderInfo_OriginalOrderDateValid()
            throws Exception {

        VisibleRequestReverseNrf deviceSwapRequest = CommonTestHelper.loadJsonMessage(
                VisibleRequestReverseNrf.class, DATA_DIR.REVERSE_NRF + "VisibleRequestReverseNrf.json");

        deviceSwapRequest.getCancelNrfOrderInfo().setOriginalOrderDate("2018-05-29");
        try {
            instance.validateRequest("InvalidRequestException Test: ", deviceSwapRequest);
        } catch (InvalidRequestException ex) {
            fail("Expecting Valid Request");
        }

    }

    // METHODS USED IN TESTING

    private VisibleRequestPurchaseDevice transform_Json_To_VisibleRequestPurchaseDevice(String messageText) {
        try {

            DataContainer dc = new DataContainer(dcf);

            JsonObject jsonInput = new JsonObject();
            jsonInput.parse(messageText);
            dc.readFrom(jsonInput);

            return new VisibleRequestPurchaseDevice(dc);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private VisibleRequestReturnPurchasedDevice transform_Json_To_VisibleRequestReturnPurchasedDevice(String messageText) {
        try {

            DataContainer dc = new DataContainer(dcf);

            JsonObject jsonInput = new JsonObject();
            jsonInput.parse(messageText);
            dc.readFrom(jsonInput);

            return new VisibleRequestReturnPurchasedDevice(dc);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private VisibleRequestFinanceDevice transform_Json_To_VisibleRequestFinanceDevice(String messageText) {
        try {

            DataContainer dc = new DataContainer(dcf);

            JsonObject jsonInput = new JsonObject();
            jsonInput.parse(messageText);
            dc.readFrom(jsonInput);

            return new VisibleRequestFinanceDevice(dc);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private VisibleRequestReturnFinancedDevice transform_Json_To_VisibleRequestReturnFinancedDevice(String messageText) {
        try {

            DataContainer dc = new DataContainer(dcf);

            JsonObject jsonInput = new JsonObject();
            jsonInput.parse(messageText);
            dc.readFrom(jsonInput);

            return new VisibleRequestReturnFinancedDevice(dc);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private String remove_From_VisibleRequestPurchaseDevice(String messageText,
                                                            String fieldToRemove) {

        JsonObject jsonInput = new JsonObject();
        jsonInput.parse(messageText);
        switch (fieldToRemove) {
            case "PurchaseOrderInfo":
            case "PurchaseDeviceInfo":
            case "PurchaseShippingInfo":
            case "PurchaseFraudInfo":
            case "SubscriberExternalId":
                jsonInput.remove(fieldToRemove);
                break;
            case "OrderId":
            case "PaymentMethod":
            case "PaymentInfo":
                ((JsonObject) jsonInput.get("PurchaseOrderInfo")).remove(fieldToRemove);
                break;

            case "DeviceSku":
            case "DeviceOfferExternalId":
            case "DeviceGrossPrice":
            case "DeviceDiscountPrice":
            case "DeviceTotalTax":
            case "DeviceTaxDetails":
            case "DeviceProvidesService":
            case "DeviceDetails":
                ((JsonObject) jsonInput.get("PurchaseDeviceInfo")).remove(fieldToRemove);
                break;

            case "ShippingSku":
            case "ShippingGeocode":
            case "ShipToBid":
            case "ShippingOfferExternalId":
            case "ShippingGrossPrice":
            case "ShippingDiscountPrice":
            case "ShippingTotalTax":
            case "ShippingTaxDetails":
                ((JsonObject) jsonInput.get("PurchaseShippingInfo")).remove(fieldToRemove);
                break;

            case "TransactionType":
            case "FraudHomeAddress":
            case "FraudShippingAddress":

                ((JsonObject) jsonInput.get("PurchaseFraudInfo")).remove(fieldToRemove);
                break;

            default:
                break;
        }

        return jsonInput.toString();
    }

    private String replace_From_VisibleRequestPurchaseDevice(String messageText,
                                                             String replaceValue) {
        String replaceString = "replaceString";
        JsonObject jsonInput = new JsonObject();
        JsonObject jsonPurchase = new JsonObject();
        jsonInput.parse(messageText);
        switch (replaceValue) {
            case "DeviceDiscountPrice":
            case "DeviceIMSI":
            case "DeviceAccessNumber":
                jsonPurchase = ((JsonObject) jsonInput.get("PurchaseDeviceInfo"));
                jsonPurchase.attribute(replaceValue, replaceString);
                break;

            case "ShippingDiscountPrice":
                jsonPurchase = ((JsonObject) jsonInput.get("PurchaseShippingInfo"));
                jsonPurchase.attribute(replaceValue, replaceString);
                break;

            default:
                break;
        }

        return jsonInput.toString();
    }

    private String remove_From_VisibleRequestReturnPurchasedDevice(String messageText,
                                                                   String fieldToRemove) {
        JsonObject jsonInput = new JsonObject();
        jsonInput.parse(messageText);
        switch (fieldToRemove) {
            case "SubscriberExternalId":
                jsonInput.remove(fieldToRemove);
                break;
            case "ReturnOrderId":
                ((JsonObject) jsonInput.get("ReturnPurchaseOrderInfo")).remove(fieldToRemove);
                break;
            case "PaymentInfo":
                ((JsonObject) jsonInput.get("ReturnPurchaseOrderInfo")).remove(fieldToRemove);
                break;
            case "OriginalOrderDate":
                ((JsonObject) jsonInput.get("ReturnPurchaseOrderInfo")).remove(fieldToRemove);
                break;
            case "DeviceOfferInstanceId":
                ((JsonObject) jsonInput.get("ReturnPurchaseOrderInfo")).remove(fieldToRemove);
                break;
            case "DeviceProvidesService":
                ((JsonObject) jsonInput.get("ReturnPurchaseOrderInfo")).remove(fieldToRemove);
                break;
            default:
                break;
        }

        return jsonInput.toString();
    }

    private String replace_From_VisibleRequestReturnPurchasedDevice(String messageText,
                                                                    String replaceValue) {
        String replaceString = "replaceString";
        JsonObject jsonInput = new JsonObject();
        JsonObject jsonPurchase = new JsonObject();
        jsonInput.parse(messageText);
        if (replaceValue.equals("OriginalOrderDate") || replaceValue.equals("DeviceInstanceId")) {
            jsonPurchase = ((JsonObject) jsonInput.get("ReturnPurchaseOrderInfo"));
            jsonPurchase.attribute(replaceValue, replaceString);
        }
        return jsonInput.toString();
    }

    private String remove_From_VisibleRequestFinanceDevice(String messageText,
                                                           String feildToRemove) {
        JsonObject jsonInput = new JsonObject();
        jsonInput.parse(messageText);
        switch (feildToRemove) {
            case "SubscriberExternalId":
                jsonInput.remove(feildToRemove);
                break;
            case "OrderId":
            case "ChargeId":
                ((JsonObject) jsonInput.get("FinanceOrderInfo")).remove(feildToRemove);
                break;

            case "DeviceSku":
            case "DeviceOfferExternalId":
            case "DeviceGrossPrice":
            case "DeviceDiscountPrice":
            case "DeviceTotalTax":
            case "DeviceFinanceAmount":
            case "DeviceTaxDetails":
            case "DeviceProvidesService":
            case "DeviceDetails":
                ((JsonObject) jsonInput.get("FinanceDeviceInfo")).remove(feildToRemove);
                break;

            case "ShippingSku":
            case "ShippingGeocode":
            case "ShipToBid":
            case "ShippingOfferExternalId":
            case "ShippingGrossPrice":
            case "ShippingDiscountPrice":
            case "ShippingTotalTax":
            case "ShippingTaxDetails":
                ((JsonObject) jsonInput.get("FinanceShippingInfo")).remove(feildToRemove);
                break;

            default:
                break;
        }

        return jsonInput.toString();
    }

    private String replace_From_VisibleRequestFinanceDevice(String messageText,
                                                            String replaceValue) {
        String replaceString = "replaceString";
        JsonObject jsonInput = new JsonObject();
        JsonObject jsonFinance = new JsonObject();
        jsonInput.parse(messageText);
        switch (replaceValue) {
            case "DeviceDiscountPrice":
            case "DeviceIMSI":
            case "DeviceAccessNumber":
            case "DeviceFinanceAmount":
                jsonFinance = ((JsonObject) jsonInput.get("FinanceDeviceInfo"));
                jsonFinance.attribute(replaceValue, replaceString);
                break;

            case "ShippingDiscountPrice":
                jsonFinance = ((JsonObject) jsonInput.get("FinanceShippingInfo"));
                jsonFinance.attribute(replaceValue, replaceString);
                break;

            default:
                break;
        }

        return jsonInput.toString();

    }

    private String remove_From_VisibleRequestReturnFinancedDevice(String messageText,
                                                                  String feildToRemove) {
        JsonObject jsonInput = new JsonObject();
        jsonInput.parse(messageText);
        switch (feildToRemove) {
            case "SubscriberExternalId":
                jsonInput.remove(feildToRemove);
                break;

            case "ReturnOrderId":
            case "ChargeId":
            case "OriginalOrderId":
            case "OriginalOrderDate":
            case "DeviceProvidesService":
            case "DeviceInstanceId":
                ((JsonObject) jsonInput.get("ReturnFinanceOrderInfo")).remove(feildToRemove);
                break;

            default:
                break;
        }

        return jsonInput.toString();
    }

    private String replace_From_VisibleRequestReturnFinancedDevice(String messageText,
                                                                   String replaceValue) {
        String replaceString = "replaceString";
        JsonObject jsonInput = new JsonObject();
        JsonObject jsonPurchase = new JsonObject();
        jsonInput.parse(messageText);
        if (replaceValue.equals("OriginalOrderDate") || replaceValue.equals("DeviceInstanceId")) {
            jsonPurchase = ((JsonObject) jsonInput.get("ReturnFinanceOrderInfo"));
            jsonPurchase.attribute(replaceValue, replaceString);
        }
        return jsonInput.toString();

    }

}
