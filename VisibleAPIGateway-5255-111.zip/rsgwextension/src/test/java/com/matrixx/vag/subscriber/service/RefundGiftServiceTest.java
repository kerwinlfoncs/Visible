package com.matrixx.vag.subscriber.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.EventQueryEventInfo;
import com.matrixx.datacontainer.mdc.EventQueryResponseEvents;
import com.matrixx.datacontainer.mdc.MtxPaymentInfo;
import com.matrixx.datacontainer.mdc.MtxRecurringEvent;
import com.matrixx.datacontainer.mdc.MtxRequest;
import com.matrixx.datacontainer.mdc.MtxRequestMulti;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberAdjustBalance;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberCancelOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberRefundPayment;
import com.matrixx.datacontainer.mdc.MtxResponseMulti;
import com.matrixx.datacontainer.mdc.MtxResponsePaymentHistory;
import com.matrixx.datacontainer.mdc.VisibleApiEventData;
import com.matrixx.datacontainer.mdc.VisibleRequestRefundService;
import com.matrixx.datacontainer.mdc.VisibleResponseRefundService;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.common.Constants.LOG_MESSAGES;
import com.matrixx.vag.common.Constants.MATRIXX_CONSTANTS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.Constants.SUBSCRIBER_SERVICE_CONSTANTS;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.util.MDCTest;

@ExtendWith(MockitoExtension.class)
public class RefundGiftServiceTest extends MDCTest {

    @Spy
    @InjectMocks
    private final RefundService instance = new RefundService();

    @Mock
    private SubscriberManagementApi api;

    private TestInfo testInfo;
    
    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        MockitoAnnotations.openMocks(this);
        this.testInfo = testInfo;
        doReturn("").when(instance).getRoute(any());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name="test_refundServiceGift_When_ApiSuccess_Then_CorrectRefundInfo")
    @Tag("VER-689")  
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Valid Request.|"
                +"|When  |Api is successful.|"
                +"|Then  |Response should have gifter external id and refund amount|"})
    // @formatter:on
    public void test_refundServiceGift_When_ApiSuccess_Then_CorrectRefundInfo(ArgumentsAccessor acceptance) throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        VisibleRequestRefundService request = CommonTestHelper.getRefundGiftRequest("123456789",CI_EXTERNAL_IDS.PLUS3ANNUAL, "I4A0:1:52:517145","I4A0:1:52:517133");
        VisibleResponseRefundService response = new VisibleResponseRefundService();
        printUnitTest(request.toJson());
            
        EventQueryEventInfo eqeiRecurring= CommonTestHelper.getRecurringEventQueryEventInfo(List.of(request.getRefundServiceOrderInfo().getServiceOfferExternalId()),request.getAtRecurringEventIds(0),true);
        EventQueryResponseEvents gifteeRecurEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        gifteeRecurEvents.getEventListAppender().add(eqeiRecurring);
        
        BigDecimal offerPrice = CommonTestHelper.getOfferPrice(request.getRefundServiceOrderInfo().getServiceOfferExternalId());

        String gifterExternalId = ((VisibleApiEventData)((MtxRecurringEvent)eqeiRecurring.getEventDetails()).getApiEventData()).getGifterGlobalKey();
        EventQueryEventInfo eqeiTransfer= CommonTestHelper.getBalanceTransferEventQueryEventInfo(gifterExternalId, offerPrice);
        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        gifterEvents.getEventListAppender().add(eqeiTransfer);
        doReturn(gifterEvents).when(instance).querySubscriberEventList(any(), any(), any(), any(), any());
        
        MtxResponsePaymentHistory payHistory = CommonTestHelper.getMtxResponsePaymentHistory();
        MtxPaymentInfo payInfo = CommonTestHelper.getMtxPaymentInfo(request.getAtPaymentAuthEventIds(0), offerPrice);
        payHistory.getPaymentInfoListAppender().add(payInfo);
        doReturn(payHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        
        EventQueryEventInfo eqeiSec = CommonTestHelper.getSecondaryEventQueryEventInfo(gifterExternalId,request.getSubscriberExternalId(),eqeiTransfer.getEventDetails().getEventId());
        EventQueryResponseEvents gifteeSecEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        gifteeSecEvents.getEventListAppender().add(eqeiSec);
        doReturn(gifteeRecurEvents).doReturn(gifteeSecEvents).when(instance).queryEventListByEventIds(any(), any(), any());
        
        MtxResponseMulti successMulti = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(successMulti).when(instance).multiRequest(any(), any(), any());
        
        instance.refundServiceV2(request, response);
        printUnitTest("Response: "+response.toJson());
        
        assertEquals(RESULT_CODES.MTX_SUCCESS, response.getResult().longValue());
        assertTrue(response.getRefundAmountInfo().contains(gifterExternalId));    
        assertTrue(response.getRefundAmountInfo().contains(offerPrice.intValue()+""));
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name="test_refundServiceGift_When_EventDataAvailable_Then_CorrectOrderOfRequests")
    @Tag("VER-689")  
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Valid Request.|"
                +"|When  |Matching event data is available for both gifter and giftee.|"
                +"|Then  |Multirequest should have 3 requests in order[BalanceAdjust, RefundPayment,CancelOffer]|"})
    // @formatter:on
    public void test_refundServiceGift_When_EventDataAvailable_Then_CorrectOrderOfRequests(ArgumentsAccessor acceptance) throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        VisibleRequestRefundService request = CommonTestHelper.getRefundGiftRequest("123456789",CI_EXTERNAL_IDS.PLUS3ANNUAL, "I4A0:1:52:517145","I4A0:1:52:517133");
        VisibleResponseRefundService response = new VisibleResponseRefundService();
        printUnitTest(request.toJson());
            
        EventQueryEventInfo eqeiRecurring= CommonTestHelper.getRecurringEventQueryEventInfo(List.of(request.getRefundServiceOrderInfo().getServiceOfferExternalId()),request.getAtRecurringEventIds(0),true);
        EventQueryResponseEvents gifteeRecurEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        gifteeRecurEvents.getEventListAppender().add(eqeiRecurring);
        
        BigDecimal offerPrice = CommonTestHelper.getOfferPrice(request.getRefundServiceOrderInfo().getServiceOfferExternalId());

        String gifterExternalId = ((VisibleApiEventData)((MtxRecurringEvent)eqeiRecurring.getEventDetails()).getApiEventData()).getGifterGlobalKey();
        EventQueryEventInfo eqeiTransfer= CommonTestHelper.getBalanceTransferEventQueryEventInfo(gifterExternalId, offerPrice);
        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        gifterEvents.getEventListAppender().add(eqeiTransfer);
        doReturn(gifterEvents).when(instance).querySubscriberEventList(any(), any(), any(), any(), any());
        
        MtxResponsePaymentHistory payHistory = CommonTestHelper.getMtxResponsePaymentHistory();
        MtxPaymentInfo payInfo = CommonTestHelper.getMtxPaymentInfo(request.getAtPaymentAuthEventIds(0), offerPrice);
        payHistory.getPaymentInfoListAppender().add(payInfo);
        doReturn(payHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        
        EventQueryEventInfo eqeiSec = CommonTestHelper.getSecondaryEventQueryEventInfo(gifterExternalId,request.getSubscriberExternalId(),eqeiTransfer.getEventDetails().getEventId());
        EventQueryResponseEvents gifteeSecEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        gifteeSecEvents.getEventListAppender().add(eqeiSec);
        doReturn(gifteeRecurEvents).doReturn(gifteeSecEvents).when(instance).queryEventListByEventIds(any(), any(), any());
        
        ArgumentCaptor<MtxRequestMulti> multiCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti successMulti = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(successMulti).when(instance).multiRequest(any(), any(), multiCaptor.capture());
        
        instance.refundServiceV2(request, response);
        printUnitTest("Response: "+response.toJson());
        printUnitTest("MultiRequest: "+multiCaptor.getValue().toJson());
        
        Iterator<MtxRequest> itr = multiCaptor.getValue().getRequestList().iterator();        
        assertEquals(MtxRequestSubscriberAdjustBalance.class.getSimpleName(), itr.next().getContainer().getName());
        assertEquals(MtxRequestSubscriberRefundPayment.class.getSimpleName(), itr.next().getContainer().getName());
        assertEquals(MtxRequestSubscriberCancelOffer.class.getSimpleName(), itr.next().getContainer().getName());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name="test_refundServiceGift_When_EventDataAvailable_Then_CorrectBalAdjRequest")
    @Tag("VER-689")  
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Valid Request.|"
                +"|When  |Matching event data is available for both gifter and giftee.|"
                +"|Then  |Multirequest should have Balance Adjutment request. Validate balance resourceid, amount, gifter external id and adjustment reason.|"})
    // @formatter:on
    public void test_refundServiceGift_When_EventDataAvailable_Then_CorrectBalAdjRequest(ArgumentsAccessor acceptance) throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        VisibleRequestRefundService request = CommonTestHelper.getRefundGiftRequest("123456789",CI_EXTERNAL_IDS.PLUS3ANNUAL, "I4A0:1:52:517145","I4A0:1:52:517133");
        VisibleResponseRefundService response = new VisibleResponseRefundService();
        printUnitTest(request.toJson());
            
        EventQueryEventInfo eqeiRecurring= CommonTestHelper.getRecurringEventQueryEventInfo(List.of(request.getRefundServiceOrderInfo().getServiceOfferExternalId()),request.getAtRecurringEventIds(0),true);
        EventQueryResponseEvents gifteeRecurEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        gifteeRecurEvents.getEventListAppender().add(eqeiRecurring);
        
        BigDecimal offerPrice = CommonTestHelper.getOfferPrice(request.getRefundServiceOrderInfo().getServiceOfferExternalId());

        String gifterExternalId = ((VisibleApiEventData)((MtxRecurringEvent)eqeiRecurring.getEventDetails()).getApiEventData()).getGifterGlobalKey();
        EventQueryEventInfo eqeiTransfer= CommonTestHelper.getBalanceTransferEventQueryEventInfo(gifterExternalId, offerPrice);        
        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        gifterEvents.getEventListAppender().add(eqeiTransfer);
        doReturn(gifterEvents).when(instance).querySubscriberEventList(any(), any(), any(), any(), any());
        
        MtxResponsePaymentHistory payHistory = CommonTestHelper.getMtxResponsePaymentHistory();
        MtxPaymentInfo payInfo = CommonTestHelper.getMtxPaymentInfo(request.getAtPaymentAuthEventIds(0), offerPrice);
        payHistory.getPaymentInfoListAppender().add(payInfo);
        doReturn(payHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        
        EventQueryEventInfo eqeiSec = CommonTestHelper.getSecondaryEventQueryEventInfo(gifterExternalId,request.getSubscriberExternalId(),eqeiTransfer.getEventDetails().getEventId());
        EventQueryResponseEvents gifteeSecEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        gifteeSecEvents.getEventListAppender().add(eqeiSec);
        doReturn(gifteeRecurEvents).doReturn(gifteeSecEvents).when(instance).queryEventListByEventIds(any(), any(), any());
        
        ArgumentCaptor<MtxRequestMulti> multiCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti successMulti = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(successMulti).when(instance).multiRequest(any(), any(), multiCaptor.capture());
        
        instance.refundServiceV2(request, response);
        printUnitTest("Response: "+response.toJson());
        printUnitTest("MultiRequest: "+multiCaptor.getValue().toJson());
        
        MtxRequestSubscriberAdjustBalance adjRequest = new MtxRequestSubscriberAdjustBalance(multiCaptor.getValue().getAtRequestList(0));
                
        assertEquals(offerPrice.toPlainString(), adjRequest.getAmount().toPlainString());
        assertEquals(MATRIXX_CONSTANTS.BALANCE_ADJUSTMENT_TYPE_CREDIT, adjRequest.getAdjustType().intValue());
        assertEquals(gifterExternalId, adjRequest.getSubscriberSearchData().getExternalId()); 
        assertEquals(eqeiTransfer.getAtBalanceImpactList(0).getBalanceResourceId(), adjRequest.getBalanceResourceId());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name="test_refundServiceGift_When_EventDataAvailable_Then_CorrectRefundRequest")
    @Tag("VER-689")  
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Valid Request.|"
                +"|When  |Matching event data is available for both gifter and giftee.|"
                +"|Then  |Multirequest should have Refund request. Validate payment resourceid, amount gifter external id and adjustment reason|"})
    // @formatter:on
    public void test_refundServiceGift_When_EventDataAvailable_Then_CorrectRefundRequest(ArgumentsAccessor acceptance) throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        VisibleRequestRefundService request = CommonTestHelper.getRefundGiftRequest("123456789",CI_EXTERNAL_IDS.PLUS3ANNUAL, "I4A0:1:52:517145","I4A0:1:52:517133");
        VisibleResponseRefundService response = new VisibleResponseRefundService();
        printUnitTest(request.toJson());
            
        EventQueryEventInfo eqeiRecurring= CommonTestHelper.getRecurringEventQueryEventInfo(List.of(request.getRefundServiceOrderInfo().getServiceOfferExternalId()),request.getAtRecurringEventIds(0),true);
        EventQueryResponseEvents gifteeRecurEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        gifteeRecurEvents.getEventListAppender().add(eqeiRecurring);
        
        BigDecimal offerPrice = CommonTestHelper.getOfferPrice(request.getRefundServiceOrderInfo().getServiceOfferExternalId());

        String gifterExternalId = ((VisibleApiEventData)((MtxRecurringEvent)eqeiRecurring.getEventDetails()).getApiEventData()).getGifterGlobalKey();
        EventQueryEventInfo eqeiTransfer= CommonTestHelper.getBalanceTransferEventQueryEventInfo(gifterExternalId, offerPrice);        
        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        gifterEvents.getEventListAppender().add(eqeiTransfer);
        doReturn(gifterEvents).when(instance).querySubscriberEventList(any(), any(), any(), any(), any());
        
        MtxResponsePaymentHistory payHistory = CommonTestHelper.getMtxResponsePaymentHistory();
        MtxPaymentInfo payInfo = CommonTestHelper.getMtxPaymentInfo(request.getAtPaymentAuthEventIds(0), offerPrice);
        payHistory.getPaymentInfoListAppender().add(payInfo);
        doReturn(payHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        
        EventQueryEventInfo eqeiSec = CommonTestHelper.getSecondaryEventQueryEventInfo(gifterExternalId,request.getSubscriberExternalId(),eqeiTransfer.getEventDetails().getEventId());
        EventQueryResponseEvents gifteeSecEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        gifteeSecEvents.getEventListAppender().add(eqeiSec);
        doReturn(gifteeRecurEvents).doReturn(gifteeSecEvents).when(instance).queryEventListByEventIds(any(), any(), any());
        
        ArgumentCaptor<MtxRequestMulti> multiCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti successMulti = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(successMulti).when(instance).multiRequest(any(), any(), multiCaptor.capture());
        
        instance.refundServiceV2(request, response);
        printUnitTest("Response: "+response.toJson());        
        
        MtxRequestSubscriberRefundPayment refundRequest = new MtxRequestSubscriberRefundPayment(multiCaptor.getValue().getAtRequestList(1));
        printUnitTest("refundRequest: "+refundRequest.toJson());
        
        assertEquals(offerPrice.intValue(), refundRequest.getAmount().intValue());
        assertEquals(SUBSCRIBER_SERVICE_CONSTANTS.GIFT_REFUND_REASON, refundRequest.getReason());
        assertEquals(gifterExternalId, refundRequest.getSubscriberSearchData().getExternalId()); 
        assertEquals(payInfo.getResourceId(), refundRequest.getResourceId());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name="test_refundServiceGift_When_EventDataAvailable_Then_CorrectCancelRequest")
    @Tag("VER-689")  
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Valid Request.|"
                +"|When  |Matching event data is available for both gifter and giftee.|"
                +"|Then  |Multirequest should have Cancel request. Validate payment ciresourceid and giftee external id|"})
    // @formatter:on
    public void test_refundServiceGift_When_EventDataAvailable_Then_CorrectCancelRequest(ArgumentsAccessor acceptance) throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        VisibleRequestRefundService request = CommonTestHelper.getRefundGiftRequest("123456789",CI_EXTERNAL_IDS.PLUS3ANNUAL, "I4A0:1:52:517145","I4A0:1:52:517133");
        VisibleResponseRefundService response = new VisibleResponseRefundService();
        printUnitTest(request.toJson());
        String gifteeExternalId=request.getSubscriberExternalId();
        EventQueryEventInfo eqeiRecurring= CommonTestHelper.getRecurringEventQueryEventInfo(List.of(request.getRefundServiceOrderInfo().getServiceOfferExternalId()),request.getAtRecurringEventIds(0),true);
        EventQueryResponseEvents gifteeRecurEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        gifteeRecurEvents.getEventListAppender().add(eqeiRecurring);
        
        BigDecimal offerPrice = CommonTestHelper.getOfferPrice(request.getRefundServiceOrderInfo().getServiceOfferExternalId());

        String gifterExternalId = ((VisibleApiEventData)((MtxRecurringEvent)eqeiRecurring.getEventDetails()).getApiEventData()).getGifterGlobalKey();
        EventQueryEventInfo eqeiTransfer= CommonTestHelper.getBalanceTransferEventQueryEventInfo(gifterExternalId, offerPrice);        
        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        gifterEvents.getEventListAppender().add(eqeiTransfer);
        doReturn(gifterEvents).when(instance).querySubscriberEventList(any(), any(), any(), any(), any());
        
        MtxResponsePaymentHistory payHistory = CommonTestHelper.getMtxResponsePaymentHistory();
        MtxPaymentInfo payInfo = CommonTestHelper.getMtxPaymentInfo(request.getAtPaymentAuthEventIds(0), offerPrice);
        payHistory.getPaymentInfoListAppender().add(payInfo);
        doReturn(payHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        
        EventQueryEventInfo eqeiSec = CommonTestHelper.getSecondaryEventQueryEventInfo(gifterExternalId,gifteeExternalId,eqeiTransfer.getEventDetails().getEventId());
        EventQueryResponseEvents gifteeSecEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        gifteeSecEvents.getEventListAppender().add(eqeiSec);
        doReturn(gifteeRecurEvents).doReturn(gifteeSecEvents).when(instance).queryEventListByEventIds(any(), any(), any());
        
        ArgumentCaptor<MtxRequestMulti> multiCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti successMulti = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(successMulti).when(instance).multiRequest(any(), any(), multiCaptor.capture());
        
        instance.refundServiceV2(request, response);
        printUnitTest("Response: "+response.toJson());        
        
        MtxRequestSubscriberCancelOffer cancelRequest = new MtxRequestSubscriberCancelOffer(multiCaptor.getValue().getAtRequestList(2));
        printUnitTest("cancelRequest: "+cancelRequest.toJson());        
        
        assertEquals(gifteeExternalId, cancelRequest.getSubscriberSearchData().getExternalId()); 
        assertEquals(((MtxRecurringEvent)eqeiRecurring.getEventDetails()).getAtAppliedCatalogItemArray(0).getCatalogItemResourceId(), cancelRequest.getAtResourceIdArray(0));
    }
    
    @ParameterizedTest(name="test_refundServiceGift_When_RecurringEventsNotFound_Then_Error")
    @Tag("VER-689")  
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Request has recurring event.|"
                +"|When  |Recurring event not found.|"
                +"|Then  |Error|"})
    // @formatter:on
    public void test_refundServiceGift_When_RecurringEventsNotFound_Then_Error(ArgumentsAccessor acceptance) throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        VisibleRequestRefundService request = CommonTestHelper.getRefundGiftRequest("123456789",CI_EXTERNAL_IDS.PLUS3ANNUAL, "I4A0:1:52:517145","I4A0:1:52:517133");
        VisibleResponseRefundService response = new VisibleResponseRefundService();
        printUnitTest(request.toJson());
            
        EventQueryResponseEvents gifteeRecurEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        doReturn(gifteeRecurEvents).when(instance).queryEventListByEventIds(any(), any(), any());
        
        instance.refundServiceV2(request, response);
        printUnitTest(response.toJson());
        assertEquals(RESULT_CODES.HTTP_BAD_REQUEST, response.getResult().longValue());
        assertTrue(response.getResultText().contains(LOG_MESSAGES.SUPPLIED_RECURRING_EVENTS_NOT_FOUND));
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name="test_refundServiceGift_When_CatalogItemNotFound_Then_Error")
    @Tag("VER-689")  
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Recurring event for giftee is found.|"
                +"|When  |RecurringEvent does not have CatalogItem to be cancelled.|"
                +"|Then  |Error|"})
    // @formatter:on
    public void test_refundServiceGift_When_CatalogItemNotFound_Then_Error(ArgumentsAccessor acceptance) throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        VisibleRequestRefundService request = CommonTestHelper.getRefundGiftRequest("123456789",CI_EXTERNAL_IDS.PLUS3ANNUAL, "I4A0:1:52:517145","I4A0:1:52:517133");
        VisibleResponseRefundService response = new VisibleResponseRefundService();
        printUnitTest(request.toJson());
            
        //Offer in parameter should be different from offer in event data 
        EventQueryEventInfo eqeiRecurring= CommonTestHelper.getRecurringEventQueryEventInfo(List.of(CI_EXTERNAL_IDS.BASE3ANNUAL),request.getAtRecurringEventIds(0),true);     
        EventQueryResponseEvents gifteeRecurEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        gifteeRecurEvents.getEventListAppender().add(eqeiRecurring);
        doReturn(gifteeRecurEvents).when(instance).queryEventListByEventIds(any(), any(), any());

        instance.refundServiceV2(request, response);
        printUnitTest(response.toJson());
        assertEquals(RESULT_CODES.HTTP_INTERNAL_ERROR, response.getResult().longValue());
        assertTrue(response.getResultText().contains(LOG_MESSAGES.CATALOG_ITEM_RESOURCE_NOT_FOUND));
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name="test_refundServiceGift_When_RecurringEvent_Has_No_ApiEventData_Then_Error")
    @Tag("VER-689")  
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Recurring event for giftee is found.|"
                +"|When  |RecurringEvent does not have ApiEventData.|"
                +"|Then  |Error|"})
    // @formatter:on
    public void test_refundServiceGift_When_RecurringEvent_Has_No_ApiEventData_Then_Error(ArgumentsAccessor acceptance) throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        VisibleRequestRefundService request = CommonTestHelper.getRefundGiftRequest("123456789",CI_EXTERNAL_IDS.PLUS3ANNUAL, "I4A0:1:52:517145","I4A0:1:52:517133");
        VisibleResponseRefundService response = new VisibleResponseRefundService();
        printUnitTest(request.toJson());
             
        EventQueryEventInfo eqeiRecurring= CommonTestHelper.getRecurringEventQueryEventInfo(List.of(request.getRefundServiceOrderInfo().getServiceOfferExternalId()),request.getAtRecurringEventIds(0),true);     
        EventQueryResponseEvents gifteeRecurEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        ((MtxRecurringEvent)eqeiRecurring.getEventDetails()).setApiEventData((VisibleApiEventData)null);
        gifteeRecurEvents.getEventListAppender().add(eqeiRecurring);
        doReturn(gifteeRecurEvents).when(instance).queryEventListByEventIds(any(), any(), any());

        instance.refundServiceV2(request, response);
        printUnitTest(response.toJson());
        assertEquals(RESULT_CODES.HTTP_INTERNAL_ERROR, response.getResult().longValue());
        assertTrue(response.getResultText().contains(LOG_MESSAGES.NO_GIFTER_API_EVENT_DATA));
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name="test_refundServiceGift_When_RecurringEvent_Has_No_GifterId_Then_Error")
    @Tag("VER-689")  
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Recurring event for giftee is found.|"
                +"|When  |RecurringEvent does not have GifterId.|"
                +"|Then  |Error|"})
    // @formatter:on
    public void test_refundServiceGift_When_RecurringEvent_Has_No_GifterId_Then_Error(ArgumentsAccessor acceptance) throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        VisibleRequestRefundService request = CommonTestHelper.getRefundGiftRequest("123456789",CI_EXTERNAL_IDS.PLUS3ANNUAL, "I4A0:1:52:517145","I4A0:1:52:517133");
        VisibleResponseRefundService response = new VisibleResponseRefundService();
        printUnitTest(request.toJson());
             
        EventQueryEventInfo eqeiRecurring= CommonTestHelper.getRecurringEventQueryEventInfo(List.of(request.getRefundServiceOrderInfo().getServiceOfferExternalId()),request.getAtRecurringEventIds(0),true);     
        EventQueryResponseEvents gifteeRecurEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        ((VisibleApiEventData)((MtxRecurringEvent)eqeiRecurring.getEventDetails()).getApiEventData()).setGifterGlobalKey("");
        gifteeRecurEvents.getEventListAppender().add(eqeiRecurring);
        doReturn(gifteeRecurEvents).when(instance).queryEventListByEventIds(any(), any(), any());

        instance.refundServiceV2(request, response);
        printUnitTest(response.toJson());
        assertEquals(RESULT_CODES.HTTP_INTERNAL_ERROR, response.getResult().longValue());
        assertTrue(response.getResultText().contains(LOG_MESSAGES.GIFTER_INFO_NOT_FOUND));
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name="test_refundServiceGift_When_GifterEventsQueryException_Then_Error")
    @Tag("VER-689")  
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Recurring event for giftee is found.|"
                +"|When  |Gifter event query exception.|"
                +"|Then  |Error|"
                +"|Comment|querySubscriberEventList gets error as not connected to matrixx.|"})
    // @formatter:on
    public void test_refundServiceGift_When_GifterEventsQueryException_Then_Error(ArgumentsAccessor acceptance) throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        VisibleRequestRefundService request = CommonTestHelper.getRefundGiftRequest("123456789",CI_EXTERNAL_IDS.PLUS3ANNUAL, "I4A0:1:52:517145","I4A0:1:52:517133");
        VisibleResponseRefundService response = new VisibleResponseRefundService();
        printUnitTest(request.toJson());
             
        EventQueryEventInfo eqeiRecurring= CommonTestHelper.getRecurringEventQueryEventInfo(List.of(request.getRefundServiceOrderInfo().getServiceOfferExternalId()),request.getAtRecurringEventIds(0),true);     
        EventQueryResponseEvents gifteeRecurEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        gifteeRecurEvents.getEventListAppender().add(eqeiRecurring);
        doReturn(gifteeRecurEvents).when(instance).queryEventListByEventIds(any(), any(), any());
        
        instance.refundServiceV2(request, response);
        printUnitTest(response.toJson());
        assertEquals(RESULT_CODES.HTTP_INTERNAL_ERROR, response.getResult().longValue());
        assertTrue(response.getResultText().contains(LOG_MESSAGES.FAILED_TO_QUERY_SUB_EVENTS));
    }
    
    @SuppressWarnings("unchecked")
    @ParameterizedTest(name="test_refundServiceGift_When_GifterEventsNotFound_Then_Error")
    @Tag("VER-689")  
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Recurring event for giftee is found.|"
                +"|When  |Gifter events (Transfer Balance) not found.|"
                +"|Then  |Error|"})
    // @formatter:on
    public void test_refundServiceGift_When_GifterEventsNotFound_Then_Error(ArgumentsAccessor acceptance) throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        VisibleRequestRefundService request = CommonTestHelper.getRefundGiftRequest("123456789",CI_EXTERNAL_IDS.PLUS3ANNUAL, "I4A0:1:52:517145","I4A0:1:52:517133");
        VisibleResponseRefundService response = new VisibleResponseRefundService();
        printUnitTest(request.toJson());
            
        EventQueryEventInfo eqeiRecurring= CommonTestHelper.getRecurringEventQueryEventInfo(List.of(request.getRefundServiceOrderInfo().getServiceOfferExternalId()),request.getAtRecurringEventIds(0),true);     
        EventQueryResponseEvents gifteeRecurEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        gifteeRecurEvents.getEventListAppender().add(eqeiRecurring);
        doReturn(gifteeRecurEvents).when(instance).queryEventListByEventIds(any(), any(), any());

        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        doReturn(gifterEvents).when(instance).querySubscriberEventList(any(), any(), any(), any(), any());
        
        instance.refundServiceV2(request, response);
        printUnitTest(response.toJson());
        assertEquals(RESULT_CODES.HTTP_INTERNAL_ERROR, response.getResult().longValue());
        assertTrue(response.getResultText().contains(LOG_MESSAGES.NO_GIFTER_EVENTS));
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name="test_refundServiceGift_When_PaymentHistoryNotFound_Then_Error")
    @Tag("VER-689")  
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |GifterId is found. Transfer Balance event is found.|"
                +"|When  |Payment history is not found.|"
                +"|Then  |Error|"})
    // @formatter:on
    public void test_refundServiceGift_When_PaymentHistoryNotFound_Then_Error(ArgumentsAccessor acceptance) throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        VisibleRequestRefundService request = CommonTestHelper.getRefundGiftRequest("123456789",CI_EXTERNAL_IDS.PLUS3ANNUAL, "I4A0:1:52:517145","I4A0:1:52:517133");
        VisibleResponseRefundService response = new VisibleResponseRefundService();
        printUnitTest(request.toJson());
            
        EventQueryEventInfo eqeiRecurring= CommonTestHelper.getRecurringEventQueryEventInfo(List.of(request.getRefundServiceOrderInfo().getServiceOfferExternalId()),request.getAtRecurringEventIds(0),true);     
        EventQueryResponseEvents gifteeRecurEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        gifteeRecurEvents.getEventListAppender().add(eqeiRecurring);
        doReturn(gifteeRecurEvents).when(instance).queryEventListByEventIds(any(), any(), any());

        EventQueryEventInfo eqeiTransfer= CommonTestHelper.getBalanceTransferEventQueryEventInfo(((VisibleApiEventData)((MtxRecurringEvent)eqeiRecurring.getEventDetails()).getApiEventData()).getGifterGlobalKey());
        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        gifterEvents.getEventListAppender().add(eqeiTransfer);
        doReturn(gifterEvents).when(instance).querySubscriberEventList(any(), any(), any(), any(), any());
        
        MtxResponsePaymentHistory payHistory = CommonTestHelper.getMtxResponsePaymentHistory();
        doReturn(payHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        
        instance.refundServiceV2(request, response);
        printUnitTest(response.toJson());
        assertEquals(RESULT_CODES.HTTP_INTERNAL_ERROR, response.getResult().longValue());
        assertTrue(response.getResultText().contains(LOG_MESSAGES.FAILED_TO_GET_MATCHING_PAYMENT_HISTORY_FOR_PAY_AUTH_EVENT_IDS));
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name="test_refundServiceGift_When_SecondaryEventNotFound_Then_Error")
    @Tag("VER-689")  
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Gifter's transfer balance event is found.|"
                +"|When  |Matching secondary event is not found for giftee.|"
                +"|Then  |Error|"})
    // @formatter:on
    public void test_refundServiceGift_When_SecondaryEventNotFound_Then_Error(ArgumentsAccessor acceptance) throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        VisibleRequestRefundService request = CommonTestHelper.getRefundGiftRequest("123456789",CI_EXTERNAL_IDS.PLUS3ANNUAL, "I4A0:1:52:517145","I4A0:1:52:517133");
        VisibleResponseRefundService response = new VisibleResponseRefundService();
        printUnitTest(request.toJson());
             
        EventQueryEventInfo eqeiRecurring= CommonTestHelper.getRecurringEventQueryEventInfo(List.of(request.getRefundServiceOrderInfo().getServiceOfferExternalId()),request.getAtRecurringEventIds(0),true);     
        EventQueryResponseEvents gifteeRecurEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        gifteeRecurEvents.getEventListAppender().add(eqeiRecurring);
        doReturn(gifteeRecurEvents).when(instance).queryEventListByEventIds(any(), any(), any());

        EventQueryEventInfo eqeiTransfer= CommonTestHelper.getBalanceTransferEventQueryEventInfo(((VisibleApiEventData)((MtxRecurringEvent)eqeiRecurring.getEventDetails()).getApiEventData()).getGifterGlobalKey());
        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        gifterEvents.getEventListAppender().add(eqeiTransfer);
        doReturn(gifterEvents).when(instance).querySubscriberEventList(any(), any(), any(), any(), any());
        
        MtxResponsePaymentHistory payHistory = CommonTestHelper.getMtxResponsePaymentHistory();
        MtxPaymentInfo payInfo = CommonTestHelper.getMtxPaymentInfo(request.getAtPaymentAuthEventIds(0), BigDecimal.ONE);
        payHistory.getPaymentInfoListAppender().add(payInfo);
        doReturn(payHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        
        instance.refundServiceV2(request, response);
        printUnitTest(response.toJson());
        assertEquals(RESULT_CODES.HTTP_INTERNAL_ERROR, response.getResult().longValue());
        assertTrue(response.getResultText().contains(LOG_MESSAGES.NO_SECONDARY_EVENT_GIFT));
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name="test_refundServiceGift_When_TB_Amount_Mismatch_PayAuth_Then_Error")
    @Tag("VER-689")  
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Gifter's transfer balance payment history are found.|"
                +"|When  |Transfer balance amount does not match with payment autorization.|"
                +"|Then  |Error|"})
    // @formatter:on
    public void test_refundServiceGift_When_TB_Amount_Mismatch_PayAuth_Then_Error(ArgumentsAccessor acceptance) throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        VisibleRequestRefundService request = CommonTestHelper.getRefundGiftRequest("123456789",CI_EXTERNAL_IDS.PLUS3ANNUAL, "I4A0:1:52:517145","I4A0:1:52:517133");
        VisibleResponseRefundService response = new VisibleResponseRefundService();
        printUnitTest(request.toJson());
            
        EventQueryEventInfo eqeiRecurring= CommonTestHelper.getRecurringEventQueryEventInfo(List.of(request.getRefundServiceOrderInfo().getServiceOfferExternalId()),request.getAtRecurringEventIds(0),true);
        EventQueryResponseEvents gifteeRecurEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        gifteeRecurEvents.getEventListAppender().add(eqeiRecurring);        

        String gifterExternalId = ((VisibleApiEventData)((MtxRecurringEvent)eqeiRecurring.getEventDetails()).getApiEventData()).getGifterGlobalKey();
        EventQueryEventInfo eqeiTransfer= CommonTestHelper.getBalanceTransferEventQueryEventInfo(gifterExternalId);
        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        gifterEvents.getEventListAppender().add(eqeiTransfer);
        doReturn(gifterEvents).when(instance).querySubscriberEventList(any(), any(), any(), any(), any());
        
        MtxResponsePaymentHistory payHistory = CommonTestHelper.getMtxResponsePaymentHistory();
        MtxPaymentInfo payInfo = CommonTestHelper.getMtxPaymentInfo(request.getAtPaymentAuthEventIds(0), BigDecimal.ONE);
        payHistory.getPaymentInfoListAppender().add(payInfo);
        doReturn(payHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        
        EventQueryEventInfo eqeiSec = CommonTestHelper.getSecondaryEventQueryEventInfo(gifterExternalId,request.getSubscriberExternalId(),eqeiTransfer.getEventDetails().getEventId());
        EventQueryResponseEvents gifteeSecEvents = CommonTestHelper.getEmptyEventQueryResponseEvents();
        gifteeSecEvents.getEventListAppender().add(eqeiSec);
        doReturn(gifteeRecurEvents).doReturn(gifteeSecEvents).when(instance).queryEventListByEventIds(any(), any(), any());
        
        instance.refundServiceV2(request, response);
        printUnitTest(response.toJson());
        assertEquals(RESULT_CODES.HTTP_CONFLICT, response.getResult().longValue());
        assertTrue(response.getResultText().contains(LOG_MESSAGES.GIFT_AMOUNT_MISMATCH));
    }

    private void printUnitTest(Object msg) {
        System.out.println(testInfo.getDisplayName() + ":" +msg);
    }
}