package com.matrixx.vag.common;
@FunctionalInterface  
public interface ThreeParameterTest {
	void test(Object p1, Object p2, Object p3) throws Exception; 
}
