package com.matrixx.vag.advice.service;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;

import com.matrixx.datacontainer.mdc.MtxPricingCatalogItemDetailInfo;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.MtxResponsePricingCatalogItem;
import com.matrixx.datacontainer.mdc.MtxResponseRecurringChargeInfo;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.MtxSubscriberExtension;
import com.matrixx.datacontainer.mdc.MtxTemplateAttr;
import com.matrixx.datacontainer.mdc.SubscriptionResponse;
import com.matrixx.datacontainer.mdc.VisibleCatalogItem;
import com.matrixx.datacontainer.mdc.VisibleChangeServiceAddItem;
import com.matrixx.datacontainer.mdc.VisibleChangeServiceCancelItem;
import com.matrixx.datacontainer.mdc.VisibleDeltaPromo;
import com.matrixx.datacontainer.mdc.VisibleFuturePromo;
import com.matrixx.datacontainer.mdc.VisibleRequestChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleRequestPaymentAdviceService;
import com.matrixx.datacontainer.mdc.VisibleRequestQuoteAdviceService;
import com.matrixx.datacontainer.mdc.VisibleTemplate;
import com.matrixx.platform.JsonObject;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.advice.model.CiResourceIdPair;
import com.matrixx.vag.advice.model.ServiceStage;
import com.matrixx.vag.common.Constants.CREDIT_CONSTANTS;
import com.matrixx.vag.common.Constants.EXCEPTION_MESSAGES;
import com.matrixx.vag.common.Constants.GENERIC_CONSTANTS;
import com.matrixx.vag.common.Constants.LOG_MESSAGES;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.Constants.SUBSCRIPTION_CONSTANTS;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestConstants.TAX_CLASS_CODES;
import com.matrixx.vag.exception.InvalidRequestException;
import com.matrixx.vag.exception.VisibleUnitTestException;
import com.matrixx.vag.util.MDCTest;

public class RequestValidatorTest extends MDCTest {

    private RequestValidator instance;
    private TestInfo testInfo;
    
    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        instance = new RequestValidator();
        this.testInfo = testInfo;
    }

    @Test
    @Tag("PaymentAdvice")
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_validateRequest_When_MissingParameter_Then_badRequest_Exception()
            throws IOException, VisibleUnitTestException {

        ArrayList<String> testFields = new ArrayList<String>(Arrays.asList("SubscriberExternalId"));

        VisibleRequestPaymentAdviceService msgInput = new VisibleRequestPaymentAdviceService();
        msgInput.setSubscriberExternalId("123");
        msgInput.setIncludeTaxDetails("N");

        for (String removeField : testFields) {
            VisibleRequestPaymentAdviceService input = CommonTestHelper.parseJsonMessage(
                    VisibleRequestPaymentAdviceService.class,
                    remove_From_VisibleRequestPaymentAdviceService(msgInput.toJson(), removeField));
            Exception exception = assertThrows(
                    InvalidRequestException.class, () -> instance.validateRequest("", input));
            exception.printStackTrace();
        }
    }

    @Test
    @Tag("PaymentAdvice")
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_validateRequest_When_IncorrectRequestType_Then_badRequest_Exception()
            throws IOException, VisibleUnitTestException {
        VisibleRequestPaymentAdviceService msgInput = new VisibleRequestPaymentAdviceService();
        msgInput.setSubscriberExternalId("123");
        msgInput.setIncludeTaxDetails("N");
        msgInput.setRequestType("xyz");
        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequest("", msgInput));
        exception.printStackTrace();
    }
    
    @Test
    @Tag("PaymentAdvice")
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_validateRequest_When_SubHasNoOfferse_Then_Exception()
            throws IOException, VisibleUnitTestException {
        VisibleRequestPaymentAdviceService msgInput = new VisibleRequestPaymentAdviceService();
        msgInput.setSubscriberExternalId("123");
        msgInput.setIncludeTaxDetails("N");
        msgInput.setRequestType("xyz");

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse();

        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequest("", msgInput, subscriptionResponse));
        exception.printStackTrace();
        assertEquals(LOG_MESSAGES.SUBSCRIPTION_HAS_NO_SERVICES, exception.getMessage());
    }

    @Test
    @Tag("PaymentAdvice")
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_validateRequest_When_SubStatusLapse_Then_Exception()
            throws IOException, VisibleUnitTestException {
        VisibleRequestPaymentAdviceService msgInput = new VisibleRequestPaymentAdviceService();
        msgInput.setSubscriberExternalId("123");
        msgInput.setIncludeTaxDetails("N");
        msgInput.setRequestType("xyz");

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse();
        subscriptionResponse.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_LAPSE);
        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequest("", msgInput, subscriptionResponse));
        exception.printStackTrace();
        assertEquals(LOG_MESSAGES.SUBSCRIPTION_IS_LAPSED, exception.getMessage());
    }

    @Test
    @Tag("PaymentAdvice")
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_validateRequest_When_SubStatusTerminated_Then_Exception()
            throws IOException, VisibleUnitTestException {
        VisibleRequestPaymentAdviceService msgInput = new VisibleRequestPaymentAdviceService();
        msgInput.setSubscriberExternalId("123");
        msgInput.setIncludeTaxDetails("N");
        msgInput.setRequestType("xyz");

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse();
        subscriptionResponse.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_TERMINATED);
        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequest("", msgInput, subscriptionResponse));
        exception.printStackTrace();
        assertEquals(LOG_MESSAGES.SUBSCRIPTION_IS_TERMINATED, exception.getMessage());
    }

    @Test
    @Tag("PaymentAdvice")
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_validateRequest_When_NoPayableServices_Then_Exception()
            throws IOException, VisibleUnitTestException {
        VisibleRequestPaymentAdviceService msgInput = new VisibleRequestPaymentAdviceService();
        msgInput.setSubscriberExternalId("123");
        msgInput.setIncludeTaxDetails("N");

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                Arrays.asList(CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION));
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);        
        
        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequest("", msgInput, subscriptionResponse,chargeInfo,false));
        exception.printStackTrace();
        assertEquals(LOG_MESSAGES.SUBSCRIPTION_HAS_NO_PAYABLE_SERVICES, exception.getMessage());
    }

    @Test
    @Tag("PaymentAdvice")
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_validateRequest_When_NoDollarImpact_Then_Exception()
            throws IOException, VisibleUnitTestException {
        VisibleRequestPaymentAdviceService msgInput = new VisibleRequestPaymentAdviceService();
        msgInput.setSubscriberExternalId("123");
        msgInput.setIncludeTaxDetails("N");

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                Arrays.asList(CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION));
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        //anything that is not USD (840=USD)
        chargeInfo.getAtBalanceImpactGroupList(0).getAtBalanceImpactList(0).setBalanceClassId(841L);
        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequest("", msgInput, subscriptionResponse,chargeInfo,false));
        exception.printStackTrace();
        assertEquals(LOG_MESSAGES.SUBSCRIPTION_HAS_NO_SERVICES, exception.getMessage());
    }

    private String remove_From_VisibleRequestPaymentAdviceService(String messageText,
                                                                  String fieldToRemove) {
        JsonObject jsonInput = new JsonObject();
        jsonInput.parse(messageText);
        switch (fieldToRemove) {
            case "SubscriberExternalId":
                jsonInput.remove(fieldToRemove);
                break;
            default:
                break;
        }

        return jsonInput.toString();
    }

    @Test
    @Tag("QuoteAdvice")
    public void test_validateRequest_QuoteAdviceService_MissingParams() throws Exception {
        // All information not populated
        VisibleRequestQuoteAdviceService input = new VisibleRequestQuoteAdviceService();
        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequest("", input));
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("Missing mandatory parameter: "));
    }

    @SuppressWarnings("unchecked")
    @Test
    @Tag("QuoteAdvice")
    public void test_validateRequest_QuoteAdviceService_BillingCycleIdMissing() throws Exception {
        VisibleRequestQuoteAdviceService input = new VisibleRequestQuoteAdviceService();
        input.setIncludeTaxDetails("N");
        input.setSubscriberExternalId("123");
        input.getCatalogItemListAppender().clear();
        VisibleCatalogItem ciBase = new VisibleCatalogItem();
        ciBase.setCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3VIS23);
        ciBase.setDiscountPrice(CommonTestHelper.getOfferPrice(ciBase.getCatalogItemExternalId()));
        ciBase.setGrossPrice(new BigDecimal(1000));
        input.getCatalogItemListAppender().add(ciBase);

        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequest("", input));
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("Missing mandatory parameter: "));
        assertTrue(exception.getMessage().contains("BillingCycleId"));
    }

    @SuppressWarnings("unchecked")
    @Test
    @Tag("QuoteAdvice")
    public void test_validateRequest_QuoteAdviceService_SubscriberExternalIdMissing()
            throws Exception {
        VisibleRequestQuoteAdviceService input = new VisibleRequestQuoteAdviceService();
        input.setIncludeTaxDetails("N");
        input.setBillingCycleId(301);
        input.getCatalogItemListAppender().clear();
        VisibleCatalogItem ciBase = new VisibleCatalogItem();
        ciBase.setCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3VIS23);
        ciBase.setDiscountPrice(CommonTestHelper.getOfferPrice(ciBase.getCatalogItemExternalId()));
        ciBase.setGrossPrice(new BigDecimal(1000));
        input.getCatalogItemListAppender().add(ciBase);

        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequest("", input));
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("Missing mandatory parameter: "));
        assertTrue(exception.getMessage().contains("SubscriberExternalId"));

    }

    @Test
    @Tag("QuoteAdvice")
    public void test_validateRequest_QuoteAdviceService_CatalogItemListMissing() throws Exception {
        VisibleRequestQuoteAdviceService input = new VisibleRequestQuoteAdviceService();
        input.setIncludeTaxDetails("N");
        input.setSubscriberExternalId("123");
        input.setBillingCycleId(301);
        input.getCatalogItemListAppender().clear();
        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequest("", input));
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("Missing mandatory parameter: "));
        assertTrue(exception.getMessage().contains("CatalogItemList"));
    }

    @SuppressWarnings("unchecked")
    @Test
    @Tag("QuoteAdvice")
    public void test_validateRequest_QuoteAdviceService_CatalogItemListEmpty() throws Exception {
        VisibleRequestQuoteAdviceService input = new VisibleRequestQuoteAdviceService();
        input.setIncludeTaxDetails("N");
        input.setSubscriberExternalId("123");
        input.setBillingCycleId(301);        
        input.getCatalogItemListAppender().add(null);
        input.getCatalogItemListAppender().clear();
        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequest("", input));
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("Missing mandatory parameter: "));
        assertTrue(exception.getMessage().contains("CatalogItemList"));
    }

    @SuppressWarnings("unchecked")
    @Test
    @Tag("QuoteAdvice")
    public void test_validateRequest_QuoteAdviceService_CatalogItemList_DiscountPriceMissing()
            throws Exception {
        VisibleRequestQuoteAdviceService input = new VisibleRequestQuoteAdviceService();
        input.setIncludeTaxDetails("N");
        input.setBillingCycleId(301);
        input.setSubscriberExternalId("123");
        input.getCatalogItemListAppender().clear();
        VisibleCatalogItem ciBase = new VisibleCatalogItem();
        ciBase.setCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3VIS23);
        ciBase.setGrossPrice(new BigDecimal(1000));
        input.getCatalogItemListAppender().add(ciBase);

        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequest("", input));
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("Missing mandatory parameter: "));
        assertTrue(exception.getMessage().contains("CatalogItemList.DiscountPrice"));
    }

    @Test
    @Tag("QuoteAdvice")
    public void test_validateRequest_QuoteAdviceService_DuplicateCatalogItems() throws Exception {
        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService("N", CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.PLUS3VIS23);
        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequest("", input));
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("Duplicate catalog items in request "));
    }

    @Test
    @Tag("QuoteAdvice")
    public void test_validateRequest_QuoteAdviceService_Valid() throws Exception {
        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService("N", CI_EXTERNAL_IDS.PLUS3VIS23);
        assertAll(() -> instance.validateRequest("", input));
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_FuturePromos_Then_ReturnTaxes")
    @Tags({
        @Tag("VER-646"), @Tag("FuturePromo"), @Tag("QuoteAdvice")
    })
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber.|"                        
                +"|When  |Api is called with with a service and future promos. FuturePromo does not have ciExternalId.|"
                +"|Then  |QuoteAdvice Request Validation Error.|"})
    // @formatter:on    
    public void test_validateRequest_QuoteAdviceService_When_FuturePromos_Then_RequestValidation(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService("N", CI_EXTERNAL_IDS.PLUS3VIS23);
        VisibleFuturePromo fp = new VisibleFuturePromo();
        fp.setGrantAmount(BigDecimal.valueOf(50));
        input.getAdditionalPromoListAppender().add(fp);
        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequest("", input));
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith(LOG_MESSAGES.FUTURE_GRANT_NO_CI_1003));
    }

    @SuppressWarnings("unchecked")
    @Tags({
        @Tag("VER-646"), @Tag("FuturePromo"), @Tag("QuoteAdvice")
    })
    @ParameterizedTest(name="test_validateRequestQuotePromoOfferTemplateAttributes_When_PricingQueryReturnesNull_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|When  |Request parameter has additional promos. Pricing Query returns null|"
                +"|Then  |Exception.|"})
    // @formatter:on
    public void test_validateRequestQuotePromoOfferTemplateAttributes_When_PricingQueryReturnesNull_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        VisibleRequestQuoteAdviceService request = CommonTestHelper.getVisibleRequestQuoteAdviceService("N", CI_EXTERNAL_IDS.PLUS3VIS23);
        VisibleFuturePromo fp = new VisibleFuturePromo();
        fp.setGrantOfferCI(CI_EXTERNAL_IDS.GENERIC_GRANT);
        fp.setGrantAmount(BigDecimal.valueOf(50));        
        request.getAdditionalPromoListAppender().add(fp);

        MtxResponsePricingCatalogItem pricingCi = null;

        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequestQuotePromoOfferTemplateAttributes("", request, pricingCi));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertEquals("Invalid Catalog Item.", exception.getMessage());
    }

    @SuppressWarnings("unchecked")
    @Tags({
        @Tag("VER-646"), @Tag("FuturePromo"), @Tag("QuoteAdvice")
    })
    @ParameterizedTest(name="test_validateRequestQuotePromoOfferTemplateAttributes_When_PricingQueryReturnsFailure_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|When  |Request parameter has additional promos. Pricing Query returns failure|"
                +"|Then  |Exception.|"})
    // @formatter:on
    public void test_validateRequestQuotePromoOfferTemplateAttributes_When_PricingQueryReturnsFailure_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        VisibleRequestQuoteAdviceService request = CommonTestHelper.getVisibleRequestQuoteAdviceService("N", CI_EXTERNAL_IDS.PLUS3VIS23);
        VisibleFuturePromo fp = new VisibleFuturePromo();
        fp.setGrantOfferCI(CI_EXTERNAL_IDS.GENERIC_GRANT);
        fp.setGrantAmount(BigDecimal.valueOf(50));        
        request.getAdditionalPromoListAppender().add(fp);

        MtxResponsePricingCatalogItem pricingCi = CommonTestHelper.getMtxResponsePricingCatalogItem(
                request.getAtAdditionalPromoList(0).getGrantOfferCI());
        pricingCi.setResult(RESULT_CODES.HTTP_CONFLICT);
        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequestQuotePromoOfferTemplateAttributes("", request, pricingCi));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("Invalid Catalog Item."));
    }

    @SuppressWarnings("unchecked")
    @Tags({
        @Tag("VER-646"), @Tag("FuturePromo"), @Tag("QuoteAdvice")
    })
    @ParameterizedTest(name="test_validateRequestQuotePromoOfferTemplateAttributes_When_PricingQueryReturnsNoCatalogData_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|When  |Request parameter has additional promos. Pricing Query returns no catalog data|"
                +"|Then  |Exception.|"})
    // @formatter:on
    public void test_validateRequestQuotePromoOfferTemplateAttributes_When_PricingQueryReturnsNoCatalogData_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        VisibleRequestQuoteAdviceService request = CommonTestHelper.getVisibleRequestQuoteAdviceService("N", CI_EXTERNAL_IDS.PLUS3VIS23);
        VisibleFuturePromo fp = new VisibleFuturePromo();
        fp.setGrantOfferCI(CI_EXTERNAL_IDS.GENERIC_GRANT);
        fp.setGrantAmount(BigDecimal.valueOf(50));        
        request.getAdditionalPromoListAppender().add(fp);

        MtxResponsePricingCatalogItem pricingCi = CommonTestHelper.getMtxResponsePricingCatalogItem(
                request.getAtAdditionalPromoList(0).getGrantOfferCI());
        pricingCi.setCatalogItemInfo((MtxPricingCatalogItemDetailInfo)null);
        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequestQuotePromoOfferTemplateAttributes("", request, pricingCi));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("Invalid Catalog Item."));
    }

    @SuppressWarnings("unchecked")
    @Tags({
        @Tag("VER-646"), @Tag("FuturePromo"), @Tag("QuoteAdvice")
    })
    @ParameterizedTest(name="test_validateRequestQuotePromoOfferTemplateAttributes_When_CatalogItemHasNoTemplateAttributes_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|When  |Pricing query returns catalog data that has no template attributes.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    public void test_validateRequestQuotePromoOfferTemplateAttributes_When_CatalogItemHasNoTemplateAttributes_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        VisibleRequestQuoteAdviceService request = CommonTestHelper.getVisibleRequestQuoteAdviceService("N", CI_EXTERNAL_IDS.PLUS3VIS23);
        VisibleFuturePromo fp = new VisibleFuturePromo();
        fp.setGrantOfferCI(CI_EXTERNAL_IDS.GENERIC_GRANT);
        fp.setGrantAmount(BigDecimal.valueOf(50));        
        request.getAdditionalPromoListAppender().add(fp);

        MtxResponsePricingCatalogItem pricingCi = CommonTestHelper.getMtxResponsePricingCatalogItem(
                request.getAtAdditionalPromoList(0).getGrantOfferCI());
        pricingCi.getCatalogItemInfo().setTemplateAttr((MtxTemplateAttr) null);
        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequestQuotePromoOfferTemplateAttributes("", request, pricingCi));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("Invalid Catalog Item."));
    }

    @SuppressWarnings("unchecked")
    @Tags({
        @Tag("VER-646"), @Tag("FuturePromo"), @Tag("QuoteAdvice")
    })
    @ParameterizedTest(name="test_validateRequestQuotePromoOfferTemplateAttributes_When_GrantCI_Not_Promo_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|When  |Request parameter has additional promos. PromoCI is not of type promo|"
                +"|Then  |Exception.|"})
    // @formatter:on
    public void test_validateRequestQuotePromoOfferTemplateAttributes_When_GrantCI_Not_Promo_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        VisibleRequestQuoteAdviceService request = CommonTestHelper.getVisibleRequestQuoteAdviceService("N", CI_EXTERNAL_IDS.PLUS3VIS23);
        VisibleFuturePromo fp = new VisibleFuturePromo();
        fp.setGrantOfferCI(CI_EXTERNAL_IDS.GENERIC_GRANT);
        fp.setGrantAmount(BigDecimal.valueOf(50));        
        request.getAdditionalPromoListAppender().add(fp);

        MtxResponsePricingCatalogItem pricingCi = CommonTestHelper.getMtxResponsePricingCatalogItem(
                request.getAtAdditionalPromoList(0).getGrantOfferCI());
        ((VisibleTemplate)pricingCi.getCatalogItemInfo().getTemplateAttr()).setOfferType("xyz");;

        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequestQuotePromoOfferTemplateAttributes("", request, pricingCi));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith(LOG_MESSAGES.GRANT_CI_NOT_PROMO_1004));
    }

    @SuppressWarnings("unchecked")
    @Tags({
        @Tag("VER-646"), @Tag("FuturePromo"), @Tag("QuoteAdvice")
    })
    @ParameterizedTest(name="test_validateRequestQuotePromoOfferTemplateAttributes_When_PromoType_AOC_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|When  |Request parameter has additional promos. Promo is of the type AOC|"
                +"|Then  |Exception.|"})
    // @formatter:on
    public void test_validateRequestQuotePromoOfferTemplateAttributes_When_PromoType_AOC_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        VisibleRequestQuoteAdviceService request = CommonTestHelper.getVisibleRequestQuoteAdviceService("N", CI_EXTERNAL_IDS.PLUS3VIS23);
        VisibleFuturePromo fp = new VisibleFuturePromo();
        fp.setGrantOfferCI(CI_EXTERNAL_IDS.GENERIC_GRANT);
        fp.setGrantAmount(BigDecimal.valueOf(50));        
        request.getAdditionalPromoListAppender().add(fp);

        MtxResponsePricingCatalogItem pricingCi = CommonTestHelper.getMtxResponsePricingCatalogItem(
                request.getAtAdditionalPromoList(0).getGrantOfferCI());
        ((VisibleTemplate)pricingCi.getCatalogItemInfo().getTemplateAttr()).setDiscountCalculationMethod(CREDIT_CONSTANTS.CALCULATION_METHOD_AOC);;

        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequestQuotePromoOfferTemplateAttributes("", request, pricingCi));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith(LOG_MESSAGES.FUTURE_PROMO_NO_AOC_1005));
    }

    @SuppressWarnings("unchecked")
    @Tags({
        @Tag("VER-646"), @Tag("FuturePromo"), @Tag("QuoteAdvice")
    })
    @ParameterizedTest(name="test_validateRequestQuotePromoOfferTemplateAttributes_When_PromoType_NotDollar_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|When  |Request parameter has additional promos. Promo is of the type AOC or Percentage|"
                +"|Then  |Exception.|"})
    // @formatter:on
    public void test_validateRequestQuotePromoOfferTemplateAttributes_When_PromoType_NotDollar_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        VisibleRequestQuoteAdviceService request = CommonTestHelper.getVisibleRequestQuoteAdviceService("N", CI_EXTERNAL_IDS.PLUS3VIS23);
        VisibleFuturePromo fp = new VisibleFuturePromo();
        fp.setGrantOfferCI(CI_EXTERNAL_IDS.GENERIC_GRANT);
        fp.setGrantAmount(BigDecimal.valueOf(50));        
        request.getAdditionalPromoListAppender().add(fp);

        MtxResponsePricingCatalogItem pricingCi = CommonTestHelper.getMtxResponsePricingCatalogItem(
                request.getAtAdditionalPromoList(0).getGrantOfferCI());
        ((VisibleTemplate)pricingCi.getCatalogItemInfo().getTemplateAttr()).setCreditGrantType(CREDIT_CONSTANTS.GRANT_TYPE_PERCENTAGE);

        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequestQuotePromoOfferTemplateAttributes("", request, pricingCi));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith(LOG_MESSAGES.FUTURE_GRANT_TYPE_DOLLAR_1006));
    }

    @ParameterizedTest(name="When_mandatory_params_missing_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|When  |Mandatory parameters missing.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    @Tag("ChangeAdvice")
    public void test_validateRequest_CSA_When_mandatory_params_missing_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        ArrayList<String> testFields = new ArrayList<String>(Arrays.asList("SubscriptionExternalId","DiscountPrice","NewCatalogItemExternalId"));
        

        for (String removeField : testFields) {
            VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
            if(!"SubscriptionExternalId".equalsIgnoreCase(removeField)) {
                requestUp.setSubscriptionExternalId("1234");                
            }
            if(!"DiscountPrice".equalsIgnoreCase(removeField)) {
                requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3VIS23));
                requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
            }
            if(!"NewCatalogItemExternalId".equalsIgnoreCase(removeField)) {
                requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3VIS23);
            }
            requestUp.setIncludePaymentAdvice(GENERIC_CONSTANTS.NO);requestUp.setIncludePaymentAdvice(GENERIC_CONSTANTS.NO);
            
            Exception exception = assertThrows(
                    InvalidRequestException.class, () -> instance.validateRequest("", requestUp));
            System.out.println(td.getTestMethod() + ":");
            exception.printStackTrace();
            assertTrue(exception.getMessage().startsWith("Missing mandatory parameter: "));
        }
    }

    @ParameterizedTest(name = "When_invalid_discount_price_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|When  |Discount price passed is invalid.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    @Tag("ChangeAdvice")
    public void test_validateRequest_CSA_When_invalid_discount_price_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setSubscriptionExternalId("1234");
        requestUp.setDiscountPrice(
                CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3VIS23).negate());
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3VIS23);

        requestUp.setIncludePaymentAdvice(GENERIC_CONSTANTS.NO);
        requestUp.setIncludePaymentAdvice(GENERIC_CONSTANTS.NO);

        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequest("", requestUp));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("DiscountPrice should be positive value."));
    }

    @ParameterizedTest(name = "When_invalid_gross_price_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|When  |Gross price passed is invalid.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    @Tag("ChangeAdvice")
    public void test_validateRequest_CSA_When_invalid_gross_price_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setSubscriptionExternalId("1234");
        requestUp.setDiscountPrice(
                CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3VIS23));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().subtract(BigDecimal.ONE));
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3VIS23);

        requestUp.setIncludePaymentAdvice(GENERIC_CONSTANTS.NO);
        requestUp.setIncludePaymentAdvice(GENERIC_CONSTANTS.NO);

        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequest("", requestUp));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("DiscountPrice should be less than Gross Price."));
    }

    @Tags({
        @Tag("VER-448"), @Tag("VER-535"), @Tag("ChangeAdvice")
    })
    @ParameterizedTest(name="When_CancelItems_NoPaymentAdvice_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|When  |Existing items to be cancelled.|"
                +"|      |IncludePaymentAdvice = N.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    @SuppressWarnings("unchecked")
    public void test_validateRequest_CSA_When_CancelItems_NoPaymentAdvice_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3VIS23);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3VIS23));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId("1234");

        VisibleChangeServiceCancelItem cItem = new VisibleChangeServiceCancelItem();
        cItem.setCatalogItemExternalId(CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023);
        requestUp.getCancelItemsAppender().add(cItem);

        requestUp.setIncludePaymentAdvice(GENERIC_CONSTANTS.NO);
        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequest("", requestUp));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertEquals(EXCEPTION_MESSAGES.ADDON_CANCEL_WITH_AOP_ONLY, exception.getMessage());
    }

    @Tags({
        @Tag("VER-448"), @Tag("VER-535"), @Tag("ChangeAdvice")
    })
    @ParameterizedTest(name="When_CancelItems_NoExternalId_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|When  |Existing items to be cancelled.|"
                +"|      |CatalogItemExternalId not supplied.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    @SuppressWarnings("unchecked")
    public void test_validateRequest_CSA_When_CancelItems_NoExternalId_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        
        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3VIS23);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3VIS23));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId("1234");

        VisibleChangeServiceCancelItem cItem = new VisibleChangeServiceCancelItem();
        cItem.setResourceId(1L);
        requestUp.getCancelItemsAppender().add(cItem);

        requestUp.setIncludePaymentAdvice(GENERIC_CONSTANTS.YES);
        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequest("", requestUp));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertEquals(EXCEPTION_MESSAGES.MANDATORY_ADDON_EXTERNAL_ID, exception.getMessage());
    }

    @Tags({
        @Tag("VER-448"), @Tag("VER-535"), @Tag("ChangeAdvice")
    })
    @ParameterizedTest(name="When_AddItems_NoPaymentAdvice_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|When  |New items to be added.|"
                +"|      |IncludePaymentAdvice = N|"
                +"|Then  |Exception.|"})
    // @formatter:on
    @SuppressWarnings("unchecked")
    public void test_validateRequest_CSA_When_AddItems_NoPaymentAdvice_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3VIS23);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3VIS23));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId("1234");

        VisibleChangeServiceAddItem aItem = new VisibleChangeServiceAddItem();
        aItem.setCatalogItemExternalId(CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023);
        requestUp.getAddItemsAppender().add(aItem);

        requestUp.setIncludePaymentAdvice(GENERIC_CONSTANTS.NO);
        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequest("", requestUp));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertEquals(EXCEPTION_MESSAGES.ADDON_WITH_AOP_ONLY, exception.getMessage());
    }

    @Tags({
        @Tag("VER-448"), @Tag("VER-535"), @Tag("ChangeAdvice")
    })
    @ParameterizedTest(name="When_AddItems_NoExternalId_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|When  |New items to be added.|"
                +"|      |CatalogItemExternalId not supplied.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    @SuppressWarnings("unchecked")
    public void test_validateRequest_CSA_When_AddItems_NoExternalId_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3VIS23);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3VIS23));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId("1234");

        VisibleChangeServiceAddItem aItem = new VisibleChangeServiceAddItem();
        aItem.setDiscountPrice(BigDecimal.TEN);
        requestUp.getAddItemsAppender().add(aItem);

        requestUp.setIncludePaymentAdvice(GENERIC_CONSTANTS.YES);
        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequest("", requestUp));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertEquals(EXCEPTION_MESSAGES.MANDATORY_ADDON_EXTERNAL_ID, exception.getMessage());
    }

    @Tags({
        @Tag("VER-448"), @Tag("VER-535"), @Tag("ChangeAdvice")
    })
    @ParameterizedTest(name="When_AddItems_NoDiscountPrice_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|When  |New items to be added.|"
                +"|      |DiscountPrice not supplied.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    @SuppressWarnings("unchecked")
    public void test_validateRequest_CSA_When_AddItems_NoDiscountPrice_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        
        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3VIS23);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3VIS23));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId("1234");

        VisibleChangeServiceAddItem aItem = new VisibleChangeServiceAddItem();
        aItem.setCatalogItemExternalId(CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023);
        requestUp.getAddItemsAppender().add(aItem);

        requestUp.setIncludePaymentAdvice(GENERIC_CONSTANTS.YES);
        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequest("", requestUp));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertEquals(EXCEPTION_MESSAGES.MANDATORY_ADDON_DISCOUNT_PRICE, exception.getMessage());
    }

    @Tags({
        @Tag("VER-448"), @Tag("VER-535"), @Tag("ChangeAdvice")
    })
    @ParameterizedTest(name="When_AddItem_IsNot_Addon_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |.|"
                +"|When  |New items to be added.|"
                +"|      |NewItem is not Addon, Say it is Insurance|"
                +"|Then  |Exception.|"})
    // @formatter:on
    @SuppressWarnings("unchecked")
    public void test_validateRequest_CSA_When_AddItem_IsNot_Addon_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        
        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3VIS23);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3VIS23));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId("1234");

        VisibleChangeServiceAddItem aItem = new VisibleChangeServiceAddItem();
        aItem.setCatalogItemExternalId(CI_EXTERNAL_IDS.INSURANCE);
        requestUp.getAddItemsAppender().add(aItem);
        requestUp.setIncludePaymentAdvice(GENERIC_CONSTANTS.YES);

        MtxResponsePricingCatalogItem pricingInsurance = CommonTestHelper.getMtxResponsePricingCatalogItem(
                aItem.getCatalogItemExternalId());
        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequestAddonOfferTemplateAttributes(
                        "", requestUp, pricingInsurance));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertEquals(EXCEPTION_MESSAGES.INCORRECT_ADDON_OFFER_TYPE, exception.getMessage());
    }

    @Tags({
        @Tag("VER-448"), @Tag("VER-535"), @Tag("ChangeAdvice")
    })
    @ParameterizedTest(name="When_CancelItem_IsNotAddon_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |.|"
                +"|When  |Existing item that is not Addon needs to be cancelled.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    @SuppressWarnings("unchecked")
    public void test_validateRequest_CSA_When_CancelItem_IsNotAddon_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3VIS23);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3VIS23));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId("1234");

        VisibleChangeServiceCancelItem cItem = new VisibleChangeServiceCancelItem();
        cItem.setCatalogItemExternalId(CI_EXTERNAL_IDS.INSURANCE);
        requestUp.getCancelItemsAppender().add(cItem);
        requestUp.setIncludePaymentAdvice(GENERIC_CONSTANTS.YES);

        MtxResponsePricingCatalogItem pricingInsurance = CommonTestHelper.getMtxResponsePricingCatalogItem(
                cItem.getCatalogItemExternalId());
        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequestAddonOfferTemplateAttributes(
                        "", requestUp, pricingInsurance));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertEquals(EXCEPTION_MESSAGES.INCORRECT_ADDON_OFFER_TYPE, exception.getMessage());

    }

    @Tag("ChangeAdvice")
    @ParameterizedTest(name="When_AddonPricingQueryReturnesNull_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|When  |Pricing query returns null.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_When_AddonPricingQueryReturnesNull_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();

        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.WEARABLE);
        request.setGrossPrice(BigDecimal.valueOf(100));
        request.setDiscountPrice(BigDecimal.valueOf(10));
        request.setSubscriptionExternalId("123");

        MtxResponsePricingCatalogItem pricingCi = null;

        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequestAddonOfferTemplateAttributes("", request, pricingCi));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertEquals("Invalid Catalog Item.", exception.getMessage());
    }

    @Tag("ChangeAdvice")
    @ParameterizedTest(name="When_AddonPricingQueryReturnsFailure_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|When  |Pricing query returns failure.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_When_AddonPricingQueryReturnsFailure_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();

        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.WEARABLE);
        request.setGrossPrice(BigDecimal.valueOf(100));
        request.setDiscountPrice(BigDecimal.valueOf(10));
        request.setSubscriptionExternalId("123");

        MtxResponsePricingCatalogItem pricingCi = CommonTestHelper.getMtxResponsePricingCatalogItem(
                request.getNewCatalogItemExternalId());
        pricingCi.setResult(RESULT_CODES.HTTP_CONFLICT);
        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequestAddonOfferTemplateAttributes("", request, pricingCi));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("Invalid Catalog Item."));
    }

    @Tag("ChangeAdvice")
    @ParameterizedTest(name="When_AddonPricingQueryReturnsNoCatalogData_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|When  |Pricing query returns no catalog data.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_When_AddonPricingQueryReturnsNoCatalogData_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();

        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.WEARABLE);
        request.setGrossPrice(BigDecimal.valueOf(100));
        request.setDiscountPrice(BigDecimal.valueOf(10));
        request.setSubscriptionExternalId("123");

        MtxResponsePricingCatalogItem pricingCi = CommonTestHelper.getMtxResponsePricingCatalogItem(
                request.getNewCatalogItemExternalId());
        pricingCi.setCatalogItemInfo((MtxPricingCatalogItemDetailInfo)null);
        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequestAddonOfferTemplateAttributes("", request, pricingCi));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("Invalid Catalog Item."));
    }

    @Tag("ChangeAdvice")
    @ParameterizedTest(name="When_AddonCatalogItemHasNoTemplateAttributes_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|When  |Pricing query returns catalog data that has no template attributes.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_When_AddonCatalogItemHasNoTemplateAttributes_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();

        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.WEARABLE);
        request.setGrossPrice(BigDecimal.valueOf(100));
        request.setDiscountPrice(BigDecimal.valueOf(10));
        request.setSubscriptionExternalId("123");

        MtxResponsePricingCatalogItem pricingCi = CommonTestHelper.getMtxResponsePricingCatalogItem(
                request.getNewCatalogItemExternalId());
        pricingCi.getCatalogItemInfo().setTemplateAttr((MtxTemplateAttr) null);
        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequestAddonOfferTemplateAttributes("", request, pricingCi));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("Invalid Catalog Item."));
    }
    
    @Tags({
        @Tag("VER-448"), @Tag("VER-535"), @Tag("ChangeAdvice")
    })
    @ParameterizedTest(name="When_CancelItem_IsEnrolled_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|      |Subscription not enrolled in wearable.|"
                +"|When  |Addon needs to be cancelled as per input parameter.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    @SuppressWarnings("unchecked")
    public void test_validateRequest_CSA_When_CancelItem_IsEnrolled_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        
        SubscriptionResponse subscription = CommonTestHelper.getEmptySubscriptionResponse();
        CommonTestHelper.getMtxPurchasedOfferInfo(subscription, CI_EXTERNAL_IDS.BASE3VIS23);

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3VIS23);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3VIS23));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId("1234");

        VisibleChangeServiceCancelItem cItem = new VisibleChangeServiceCancelItem();
        cItem.setCatalogItemExternalId(CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023);
        requestUp.getCancelItemsAppender().add(cItem);
        requestUp.setIncludePaymentAdvice(GENERIC_CONSTANTS.YES);

        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequestCompareSubscription("", requestUp, subscription));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith(EXCEPTION_MESSAGES.NO_OFFER_IN_SUBSCRIPTION));
    }

    @ParameterizedTest(name="When_NoSubscriptionAttributes_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription.|"
                +"|When  |Has no subscription attributes.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    @SuppressWarnings("unchecked")
    public void test_validateRequest_CSA_When_NoSubscriptionAttributes_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        
        SubscriptionResponse subscription = CommonTestHelper.getEmptySubscriptionResponse();
        subscription.setAttr((MtxSubscriberExtension) null);
        CommonTestHelper.getMtxPurchasedOfferInfo(subscription, CI_EXTERNAL_IDS.BASE3VIS23);

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3VIS23);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3VIS23));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId("1234");

        VisibleChangeServiceCancelItem cItem = new VisibleChangeServiceCancelItem();
        cItem.setCatalogItemExternalId(CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023);
        requestUp.getCancelItemsAppender().add(cItem);
        requestUp.setIncludePaymentAdvice(GENERIC_CONSTANTS.YES);

        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequestCompareSubscription("", requestUp, subscription));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("This subscription has no attribute extensions : "));
    }

    @ParameterizedTest(name="When_NoPurchasedOffers_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription.|"
                +"|When  |Has no purchased offers.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    @SuppressWarnings("unchecked")
    public void test_validateRequest_CSA_When_NoPurchasedOffers_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        
        SubscriptionResponse subscription = CommonTestHelper.getEmptySubscriptionResponse();        

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3VIS23);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3VIS23));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId("1234");

        VisibleChangeServiceCancelItem cItem = new VisibleChangeServiceCancelItem();
        cItem.setCatalogItemExternalId(CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023);
        requestUp.getCancelItemsAppender().add(cItem);
        requestUp.setIncludePaymentAdvice(GENERIC_CONSTANTS.YES);

        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequestCompareSubscription("", requestUp, subscription));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("This subscription has no purchased offer details : "));
    }

    @Tag("ChangeAdvice")
    @ParameterizedTest(name="When_SubscriberNull_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                "|When  |Subscriber query returns null.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    @SuppressWarnings("unchecked")
    public void test_validateRequest_CSA_When_SubscriberNull_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();
        
        SubscriptionResponse subscription =null;

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3VIS23);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3VIS23));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId("1234");

        VisibleChangeServiceCancelItem cItem = new VisibleChangeServiceCancelItem();
        cItem.setCatalogItemExternalId(CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023);
        requestUp.getCancelItemsAppender().add(cItem);
        requestUp.setIncludePaymentAdvice(GENERIC_CONSTANTS.YES);

        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequestCompareSubscription("", requestUp, subscription));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("This subscription does not exist : "));
    }

    @Tag("ChangeAdvice")
    @ParameterizedTest(
            name = "test_getChangeServiceAdvice_When_NewOffer_SameAs_PreactiveOffer_Then_Error")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscriber has preactive base offer.|"
                +"|When |CSA called to change for same offer. i.e. New offer same as preactive offer.|"
                +"|Then |Error.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_When_NewOffer_SameAs_PreactiveOffer_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        
        String preactiveOffer = CI_EXTERNAL_IDS.BASE3VIS23;
        VisibleRequestChangeServiceAdvice request = CommonTestHelper.getVisibleRequestChangeServiceAdvice(
                "1234", preactiveOffer);
        String activeOffer = CI_EXTERNAL_IDS.BASE6MONTH25;

        String activeBaseOffer = (String) activeOffer;

        SubscriptionResponse benSubResp = 
                CommonTestHelper.getSubscriptionResponse(
                        request.getSubscriptionExternalId(), List.of(activeBaseOffer),
                        List.of(preactiveOffer));
        benSubResp.getAtPurchasedOfferArray(1).setAutoActivationTime(benSubResp.getBillingCycle().getCurrentPeriodEndTime());
        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequestCompareSubscription("", request, benSubResp));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertEquals(preactiveOffer
                + " is already a preactive offer that gets activated on or before next bill cycle. ", exception.getMessage());
    }

    @Tag("ChangeAdvice")
    @ParameterizedTest(
            name = "test_getChangeServiceAdvice_When_NewOffer_SameAs_ActiveOffer_Then_Error")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscriber has preactive base offer.|"
                +"|When |CSA called to change for same offer. i.e. New offer same as active offer.|"
                +"|Then |Error.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_When_NewOffer_SameAs_ActiveOffer_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        
        String activeOffer = CI_EXTERNAL_IDS.BASE6MONTH25;
        VisibleRequestChangeServiceAdvice request = CommonTestHelper.getVisibleRequestChangeServiceAdvice(
                "1234", activeOffer);
        

        String activeBaseOffer = (String) activeOffer;

        SubscriptionResponse benSubResp = 
                CommonTestHelper.getSubscriptionResponse(
                        request.getSubscriptionExternalId(), List.of(activeBaseOffer));

        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequestCompareSubscription("", request, benSubResp));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertEquals(activeOffer
                + " is already an active offer. ", exception.getMessage());
    }

    @Tag("ChangeAdvice")
    @ParameterizedTest(name="When_PricingQueryReturnesNull_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|When  |Pricing query returns null.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_When_PricingQueryReturnesNull_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();

        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.WEARABLE);
        request.setGrossPrice(BigDecimal.valueOf(100));
        request.setDiscountPrice(BigDecimal.valueOf(10));
        request.setSubscriptionExternalId("123");

        MtxResponsePricingCatalogItem pricingCi = null;

        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequestBaseOfferTemplateAttributes("", request, pricingCi));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertEquals("Invalid Catalog Item.", exception.getMessage());
    }

    @Tag("ChangeAdvice")
    @ParameterizedTest(name="When_PricingQueryReturnsFailure_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|When  |Pricing query returns failure.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_When_PricingQueryReturnsFailure_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();

        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.WEARABLE);
        request.setGrossPrice(BigDecimal.valueOf(100));
        request.setDiscountPrice(BigDecimal.valueOf(10));
        request.setSubscriptionExternalId("123");

        MtxResponsePricingCatalogItem pricingCi = CommonTestHelper.getMtxResponsePricingCatalogItem(
                request.getNewCatalogItemExternalId());
        pricingCi.setResult(RESULT_CODES.HTTP_CONFLICT);
        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequestBaseOfferTemplateAttributes("", request, pricingCi));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("Invalid Catalog Item."));
    }

    @Tag("ChangeAdvice")
    @ParameterizedTest(name="When_PricingQueryReturnsNoCatalogData_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|When  |Pricing query returns no catalog data.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_When_PricingQueryReturnsNoCatalogData_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();

        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.WEARABLE);
        request.setGrossPrice(BigDecimal.valueOf(100));
        request.setDiscountPrice(BigDecimal.valueOf(10));
        request.setSubscriptionExternalId("123");

        MtxResponsePricingCatalogItem pricingCi = CommonTestHelper.getMtxResponsePricingCatalogItem(
                request.getNewCatalogItemExternalId());
        pricingCi.setCatalogItemInfo((MtxPricingCatalogItemDetailInfo)null);
        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequestBaseOfferTemplateAttributes("", request, pricingCi));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("Invalid Catalog Item."));
    }

    @Tag("ChangeAdvice")
    @ParameterizedTest(name="When_CatalogItemHasNoTemplateAttributes_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|When  |Pricing query returns catalog data that has no template attributes.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_When_CatalogItemHasNoTemplateAttributes_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();

        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.WEARABLE);
        request.setGrossPrice(BigDecimal.valueOf(100));
        request.setDiscountPrice(BigDecimal.valueOf(10));
        request.setSubscriptionExternalId("123");

        MtxResponsePricingCatalogItem pricingCi = CommonTestHelper.getMtxResponsePricingCatalogItem(
                request.getNewCatalogItemExternalId());
        pricingCi.getCatalogItemInfo().setTemplateAttr((MtxTemplateAttr) null);
        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequestBaseOfferTemplateAttributes("", request, pricingCi));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("Invalid Catalog Item."));
    }

    @Tag("ChangeAdvice")
    @ParameterizedTest(name="When_NewOffer_Not_Base_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|When  |Api is called with non offer.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_When_NewOffer_Not_Base_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();

        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.WEARABLE);
        request.setGrossPrice(BigDecimal.valueOf(100));
        request.setDiscountPrice(BigDecimal.valueOf(10));
        request.setSubscriptionExternalId("123");

        MtxResponsePricingCatalogItem pricingCi = CommonTestHelper.getMtxResponsePricingCatalogItem(
                request.getNewCatalogItemExternalId());

        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRequestBaseOfferTemplateAttributes("", request, pricingCi));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertEquals(EXCEPTION_MESSAGES.INCORRECT_BASE_OFFER_TYPE, exception.getMessage());
    }

    @Tags({
        @Tag("VER-480"), @Tag("MTXVER2TMA-4555"), @Tag("ChangeAdvice")
    })
    @ParameterizedTest(name="When_DeltaCredits_NoLimit_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|      |Referral Credits available|"
                +"|When  |Api is called for annual upgrade.|"
                +"|      |No promo limit passed in input request.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    public void test_validateRequest_ChangeAdvice_When_DeltaCredits_NoLimit_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3ANNUAL));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId("1234");

        VisibleDeltaPromo csp = new VisibleDeltaPromo();
        csp.setClassCode(TAX_CLASS_CODES.REF20);
        requestUp.appendDeltaPromotionList(csp);

        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequest("", requestUp));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertEquals(EXCEPTION_MESSAGES.DELTA_PROMO_NO_LIMIT, exception.getMessage());
    }
    
    @ParameterizedTest(name="When_DeltaCredits_NoClassCode_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|      |Referral Credits available|"
                +"|When  |Api is called for annual upgrade.|"
                +"|      |No class code for delta promo.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    public void test_validateRequest_ChangeAdvice_When_DeltaCredits_NoClassCode_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3ANNUAL));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId("1234");

        VisibleDeltaPromo csp = new VisibleDeltaPromo();
        csp.setDeltaPromotionLimit(BigDecimal.TEN);
        requestUp.appendDeltaPromotionList(csp);

        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequest("", requestUp));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertEquals(EXCEPTION_MESSAGES.DELTA_PROMO_NO_CLASS_CODE, exception.getMessage());
    }

    @ParameterizedTest(name="test_validateRequestCompareEnrolledCi_When_NoEnrolledBase_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has NO active base service.|"
                +"|When  |Api is called for upgrade.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    @Tag("ChangeAdvice")
    public void test_validateRequestCompareEnrolledCi_When_NoEnrolledBase_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3ANNUAL));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId("1234");
        
        MtxPurchasedOfferInfo enrolledPoi = null;

        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequestCompareEnrolledCi("",requestUp,enrolledPoi));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("Subscription does not have active enrolled offer that is of the same type as "));
    }

    @ParameterizedTest(name="test_validateRequestCompareEnrolledCi_When_Sub_has_same_offer_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.|"
                +"|When  |Api is called for to change to same enrolled offer.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    @Tag("ChangeAdvice")
    public void test_validateRequestCompareEnrolledCi_When_Sub_has_same_offer_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3ANNUAL));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId("1234");
        
        MtxResponseSubscription sub = CommonTestHelper.getMtxResponseSubscription("1234",Arrays.asList(CI_EXTERNAL_IDS.PLUS3ANNUAL));

        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequestCompareEnrolledCi("",requestUp,sub.getAtPurchasedOfferArray(0)));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("Subscription already has "));
    }

    @ParameterizedTest(name="test_validateRequestCompareAopResponse_When_NoEnrolledBase_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription.|"
                +"|When  |Aop returns nothing.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    @Tag("ChangeAdvice")
    public void test_validateRequestCompareAopResponse_When_NoEnrolledBase_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3ANNUAL));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId("1234");
        
        AdviceDataStage stage = null;

        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequestCompareAopResponse("",requestUp,stage));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("Payment advice does not have current service"));
    }

    @ParameterizedTest(name="test_validateRequestCompareAopResponse_When_Sub_has_same_offer_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription.|"
                +"|When  |Aop returns service stage with same catalog item as that of request.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    @Tag("ChangeAdvice")
    public void test_validateRequestCompareAopResponse_When_Sub_has_same_offer_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3ANNUAL));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId("1234");
        
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse(); 
        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);        
        ServiceStage ss = new ServiceStage(requestUp.getNewCatalogItemExternalId());
        aopStage.getPayNowMap().put(new CiResourceIdPair(ss.getCatalogItemExternalId()), ss);
        aopStage.appendVisibleOfferDetailsMap(ss.getCatalogItemExternalId(), ss.getOfferResourceId(), null);
        
        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequestCompareAopResponse("",requestUp,aopStage));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("Payment advice has same service as new catalog item id. No change needed. Enrolled service: "));
    }
    
    @ParameterizedTest(name="test_validateChangeRequestCycleDates_When_NoEnrolledBase_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has no enrolled offer.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    @Tag("ChangeAdvice")
    public void test_validateChangeRequestCycleDates_When_NoEnrolledBase_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3ANNUAL));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId("1234");

        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateChangeRequestCycleDates("", null, "", "") );
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("Subscription does not have active enrolled offer of the type base"));
    }

}
