package com.matrixx.vag.common;
@FunctionalInterface  
public interface OneParameterTest {
	void test(Object p1) throws Exception; 
}
