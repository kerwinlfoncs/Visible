package com.matrixx.vag.advice.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.doReturn;

import java.math.BigDecimal;
import java.util.AbstractMap.SimpleEntry;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixx.datacontainer.MtxDate;
import com.matrixx.datacontainer.MtxObjectId;
import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.EventQueryEventInfo;
import com.matrixx.datacontainer.mdc.EventQueryResponseEvents;
import com.matrixx.datacontainer.mdc.MtxBalanceImpactInfo;
import com.matrixx.datacontainer.mdc.MtxBalanceInfo;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.MtxRecurringEvent;
import com.matrixx.datacontainer.mdc.MtxResponseGroup;
import com.matrixx.datacontainer.mdc.MtxResponseOneTimeOffer;
import com.matrixx.datacontainer.mdc.MtxResponsePricingCatalogItem;
import com.matrixx.datacontainer.mdc.MtxResponsePurchase;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.PurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.SubscriptionResponse;
import com.matrixx.datacontainer.mdc.VisibleOfferDetails;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleRequestChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleResponseChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleSubscriberExtension;
import com.matrixx.datacontainer.mdc.VisibleTemplate;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.advice.model.CreditStage;
import com.matrixx.vag.advice.model.GlobalCreditStage;
import com.matrixx.vag.advice.model.PromoOfferPair;
import com.matrixx.vag.advice.model.ServiceStage;
import com.matrixx.vag.advice.model.SubscriberGroup;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants;
import com.matrixx.vag.common.Constants.CREDIT_CONSTANTS;
import com.matrixx.vag.common.Constants.GROUP_CONSTANTS;
import com.matrixx.vag.common.OneParameterTest;
import com.matrixx.vag.common.TestConstants;
import com.matrixx.vag.common.TestConstants.BALANCE_NAMES;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestConstants.DATA_DIR;
import com.matrixx.vag.common.TestUtils;
import com.matrixx.vag.common.TwoParameterTest;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.tax.client.TaxApiClient;
import com.matrixx.vag.tax.model.ServiceTaxRequest;
import com.matrixx.vag.tax.model.ServiceTaxResponse;
import com.matrixx.vag.util.MDCTest;

public class CsaDeltaOnlyTest extends MDCTest {

    @Spy
    @InjectMocks
    private PaymentAdviceService instance = new PaymentAdviceService();

    @Mock
    private SubscriberManagementApi api;

    private TestInfo testInfo;

    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        instance = new PaymentAdviceService();
        MockitoAnnotations.openMocks(this);
        doReturn("").when(instance).getRoute(any());
        this.testInfo = testInfo;
    }

    @SuppressWarnings("unchecked")
    @Test
    @Tag("557")
    public void test_getChangeServiceAdvice_When_DeltaOnlyTarget_PaidNextCycle_Then_NoNextCycle(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has base offer.", "Manual pay is run for next month."
        };
        td.when = new String[] {
            "Api is called with annual offer."
        };
        td.then = new String[] {
            "Next Cycle should be NOT part of response."
        };
        td.printDescription();
        OneParameterTest pTests = (tc) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions) tc;
            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(tCon.newCi);
            request.setDiscountPrice(tCon.getNewCiPrice());
            request.setGrossPrice(tCon.getNewCiPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            String randomFutureDate = TestUtils.getDistantFutureDate().toString();

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            MtxPurchasedOfferInfo poAsIs = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, tCon.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poAsIs.getAttr();
            poExtn.setPaidCycleStartDate(new MtxDate(randomFutureDate));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiAsIs = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCon.oldCi);
            VisiblePurchasedOfferExtension asisPoiExtn = (VisiblePurchasedOfferExtension) poiAsIs.getAttr();
            asisPoiExtn.setPaidCycleStartDate(new MtxDate(randomFutureDate));
            System.out.println(poiAsIs.toJson());
            emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(tCon.oldCi, tCon.newCi));

            VisibleOfferDetails vodAsIs = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    tCon.oldCi);
            vodAsIs.setConsumableMainBalanceAmount(tCon.getOldCiPrice());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscription, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodAsIs.getCatalogItemExternalId(), Long.valueOf(vodAsIs.getResourceId()),
                    vodAsIs);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                    tCon.newCi);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            String taxApiResp = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxApiResp);
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertNull(response.getNextCycle());
        };

        TestConditions tc1 = new TestConditions() {

            {
                oldCi = CI_EXTERNAL_IDS.PLUS3VIS23;
                newCi = CI_EXTERNAL_IDS.BASE3ANNUAL;
            }
            // {
            // oldCi = CI_EXTERNAL_IDS.PLUS3VIS23;
            // newCi = CI_EXTERNAL_IDS.PLUS3ANNUAL;
            // }
        };
        pTests.test(tc1);
    }

    @SuppressWarnings("unchecked")
    @Test
    @Tag("557")
    public void test_getChangeServiceAdvice_When_MonthlyTarget_PaidNextCycle_Then_NextCycle(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has base offer.", "Manual pay is run for next month."
        };
        td.when = new String[] {
            "Api is called with monthly offer."
        };
        td.then = new String[] {
            "Next Cycle should be part of response."
        };
        td.printDescription();
        OneParameterTest pTests = (tc) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions) tc;
            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(tCon.newCi);
            request.setDiscountPrice(tCon.getNewCiPrice());
            request.setGrossPrice(tCon.getNewCiPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            String randomFutureDate = TestUtils.getDistantFutureDate().toString();

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            MtxPurchasedOfferInfo poAsIs = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, tCon.oldCi);
            poAsIs.getCycleInfo().setCycleEndTime(TestUtils.getLastDateTimeOfCurrentMonth());
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poAsIs.getAttr();
            poExtn.setPaidCycleStartDate(new MtxDate(randomFutureDate));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiAsIs = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCon.oldCi);
            poiAsIs.getCycleInfo().setCycleEndTime(TestUtils.getLastDateTimeOfCurrentMonth());
            VisiblePurchasedOfferExtension asisPoiExtn = (VisiblePurchasedOfferExtension) poiAsIs.getAttr();
            asisPoiExtn.setPaidCycleStartDate(new MtxDate(randomFutureDate));

            emulateMtxResponseWallet(
                    instance, CommonTestHelper.getMtxResponseWallet(tCon.getOldCiPrice()));
            emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(tCon.oldCi, tCon.newCi));

            VisibleOfferDetails vodAsIs = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    tCon.oldCi);
            vodAsIs.setConsumableMainBalanceAmount(tCon.getOldCiPrice());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscription, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodAsIs.getCatalogItemExternalId(), Long.valueOf(vodAsIs.getResourceId()),
                    vodAsIs);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                    tCon.newCi);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            String taxApiResp = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxApiResp);
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertNotNull(response.getNextCycle());
        };

        TestConditions tc1 = new TestConditions() {

            {
                oldCi = CI_EXTERNAL_IDS.PLUS3ANNUAL;
                newCi = CI_EXTERNAL_IDS.PLUS3VIS23;
            }
            {
                oldCi = CI_EXTERNAL_IDS.PLUS3ANNUAL;
                newCi = CI_EXTERNAL_IDS.BASE3VIS23;
            }
            {
                oldCi = CI_EXTERNAL_IDS.BASE3ANNUAL;
                newCi = CI_EXTERNAL_IDS.PLUS3ANNUAL;
            }
        };
        pTests.test(tc1);
    }

    @Test
    public void test_getChangeServiceAdvice_ZeroDelta_DeltaCycle_AfterManualPay_Then_CorrectDeltaCycleOutput(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with base offer. PaidCycleStartDate is in future."
        };
        td.when = new String[] {
            "Api is called for change advice.", "Change is effective next month."
        };
        td.then = new String[] {
            "Validate Fields"
        };

        @SuppressWarnings({
            "unchecked"
        })
        OneParameterTest pTests = (tCase) -> {
            String subscriptionExternalId = "123";
            TestConditions testCase = (TestConditions) tCase;
            td.printDescription();
            System.out.println(
                    "**************************Executing " + testCase.testNum
                            + "********************************");

            MtxDate randomFutureDate = TestUtils.getDistantFutureDate();
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setSubscriptionExternalId(subscriptionExternalId);
            request.setNewCatalogItemExternalId(testCase.newCi);
            request.setDiscountPrice(testCase.getNewCiPrice());
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(1000)));
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            String oldCiId = testCase.oldCi;
            BigDecimal oldPrice = testCase.getOldCiPrice();
            BigDecimal goodwillCredits = BigDecimal.valueOf(testCase.otherPromos);
            BigDecimal promoActualsInSub = BigDecimal.ZERO;

            AppPropertyProvider.getInstance().setProperty(
                    Constants.CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCiId);
            if (poEnrolled.getCycleInfo() != null) {
                // So that annual service will be in its last month.
                poEnrolled.getCycleInfo().setCycleEndTime(
                        TestUtils.getFirstDateTimeOfNextMonth(subscription.getLastActivityTime()));
            }

            MtxResponsePricingCatalogItem pciGoodwill = emulateMtxResponsePricingCatalogItem(
                    instance, TestConstants.CI_EXTERNAL_IDS.GRANT_GOODWILL);
            VisibleTemplate vtGoodwill = (VisibleTemplate) pciGoodwill.getCatalogItemInfo().getTemplateAttr();
            vtGoodwill.setIgnoreTax_ForPayableAmount("false");

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(oldCiId, request.getNewCatalogItemExternalId()));

            String goodwillTax = "{\"msgID\":\"Goodwill-CR\",\"customerType\":\"99\",\"planID\":\"BASE001A\",\"grossPrice\":\"5.00\",\"discountPrice\":\""
                    + goodwillCredits
                    + "\",\"promotionCredit\":\"true\",\"offer606RevAdjDailyRecog\":\"0\",\"promotionReason\":\"Group_Discounts\",\"geocode\":\"US0100108296\",\"taxTreatment\":\"inclusive\",\"classCode\":\"GD-CR\",\"glDate\":\"2019-03-07\",\"transactionElement\":[{\"btcTransactionCode\":\"01\",\"totalTaxAmount\":\"0.07389163\",\"totalFeeAmount\":\"0.00000000\",\"totalNetRevenue\":\"4.92610836\",\"modifiedDisplayNetRevenue\":\"4.93\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"618\",\"cP\":\"0.75\",\"glReference\":\"Visible_Unlimited_Data\",\"dpcItemTaxAmount\":\"0.00000000\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"3.69458128\",\"taxItemList\":[]},{\"dpcItem\":\"601\",\"cP\":\"0.12\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.03546798\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.59113300\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.02364532\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.01182266\"}]},{\"dpcItem\":\"662\",\"cP\":\"0.04\",\"glReference\":\"Visible_Unlimited_Text\",\"dpcItemTaxAmount\":\"0.01182266\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.19704433\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.00788177\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.00394089\"}]},{\"dpcItem\":\"629\",\"cP\":\"0.09\",\"glReference\":\"Visible_Unlimited_MMS\",\"dpcItemTaxAmount\":\"0.02660099\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.44334975\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.01773399\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.00886700\"}]}]}]},{\"btcTransactionCode\":\"93\",\"totalTaxAmount\":\"0.03002956\",\"totalFeeAmount\":\"0.00000000\",\"totalNetRevenue\":\"4.92610836\",\"modifiedDisplayNetRevenue\":\"4.93\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"601\",\"cP\":\"0.12\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.03002956\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.59113300\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000000016\",\"tat\":\"0\",\"taxCategory\":\"00\",\"taxType\":\"35\",\"description\":\"Fed Universal Service Charge\",\"rate\":\"0.050800000000\",\"taxAmount\":\"0.03002956\"}]}]}]}]}";

            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            enrolledExtnSub.setChargeAmount(oldPrice);
            enrolledExtnSub.setPaidCycleStartDate(randomFutureDate);
            enrolledExtnSub.getCreditTaxDetailsArrayAppender().clear();
            if (goodwillCredits.signum() > 0) {
                enrolledExtnSub.getCreditTaxDetailsArrayAppender().add(goodwillTax);
                promoActualsInSub = promoActualsInSub.add(goodwillCredits);
            }

            subscription.getPurchasedOfferArrayAppender().add(poEnrolled);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, testCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(testCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(randomFutureDate);
            if (poiEnrolled.getCycleInfo() != null) {
                // So that annual service will be in its last month.
                poiEnrolled.getCycleInfo().setCycleEndTime(
                        TestUtils.getFirstDateTimeOfNextMonth(
                                subscriptionResponse.getLastActivityTime()));
            }

            MtxBalanceInfo biGoodwillGrant = CommonTestHelper.getMtxBalanceInfo(
                    TestConstants.DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Grant.json", 4,
                    43);
            biGoodwillGrant.setAmount(BigDecimal.ZERO);
            biGoodwillGrant.setAvailableAmount(BigDecimal.ZERO);
            subscription.getBalanceArrayAppender().add(biGoodwillGrant);

            MtxBalanceInfo biGoodwillConsumable = CommonTestHelper.getMtxBalanceInfo(
                    TestConstants.DATA_DIR.PAYMENT_ADVICE
                            + "MtxBalanceInfo_Goodwill_Consumable.json",
                    4, 44);
            biGoodwillConsumable.setAmount(goodwillCredits.negate());
            biGoodwillConsumable.setAvailableAmount(goodwillCredits);
            subscription.getBalanceArrayAppender().add(biGoodwillConsumable);

            BigDecimal mainbalance = CommonTestHelper.getOfferPrice(oldCiId).subtract(
                    goodwillCredits).add(
                            testCase.hasInsurance
                                    ? TestConstants.OFFER_PRICES.INSURANCE : BigDecimal.ZERO).add(
                                            testCase.hasWearable
                                                    ? TestConstants.OFFER_PRICES.WEARABLE
                                                    : BigDecimal.ZERO);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));
            subscription.getAtBalanceArray(0).setAvailableAmount(mainbalance);
            subscription.getAtBalanceArray(0).setAmount(mainbalance.negate());

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class, TestConstants.DATA_DIR.CHANGE_SERVICE_ADVICE
                            + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(oldPrice);
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().add(goodwillTax);
            enrolledExtnEvent.setPaidCycleStartDate(randomFutureDate);

            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCiId);

            List<String> balPriList = Arrays.asList(TestConstants.BALANCE_NAMES.GOODWILL_GRANT);
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");
            MtxPurchasedOfferInfo poiGoodwill = CommonTestHelper.loadJsonMessage(
                    MtxPurchasedOfferInfo.class, TestConstants.DATA_DIR.CHANGE_SERVICE
                            + "MtxPurchasedOfferInfo_Visible_Redeem_Goodwill_Credits.json");
            poiGoodwill.setResourceId(55L);

            emulateMtxResponseOneTimeOffer(instance, poiGoodwill);

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    oldCiId);
            BigDecimal mainbalanceOldCi = BigDecimal.valueOf(35);
            vodOldCi.setConsumableMainBalanceAmount(mainbalanceOldCi);

            VisibleOfferDetails vodInsurance = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    TestConstants.CI_EXTERNAL_IDS.INSURANCE);
            vodInsurance.setConsumableMainBalanceAmount(TestConstants.OFFER_PRICES.INSURANCE);
            vodInsurance.setResourceId("22");
            vodInsurance.setTaxDetails("Insurance Tax");

            VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    TestConstants.CI_EXTERNAL_IDS.WEARABLE);
            vodWearable.setConsumableMainBalanceAmount(TestConstants.OFFER_PRICES.WEARABLE);
            vodWearable.setResourceId("32");
            vodWearable.setTaxDetails("Wearable Tax");

            BigDecimal mainbalanceNewCi = BigDecimal.valueOf(35);
            vodOldCi.setConsumableMainBalanceAmount(mainbalanceNewCi);

            ServiceStage ss = new ServiceStage(oldCiId);

            GlobalCreditStage gcsGoodwill = new GlobalCreditStage(
                    TestConstants.CI_EXTERNAL_IDS.GRANT_GOODWILL, vtGoodwill);
            gcsGoodwill.setPromotionName(vtGoodwill.getPromotionName());
            gcsGoodwill.setAvailableCredits(goodwillCredits);
            gcsGoodwill.setAvailableCreditsConsumable(goodwillCredits);
            gcsGoodwill.setAvailableCreditsGrant(BigDecimal.ZERO);
            gcsGoodwill.setRedeemOfferCi(vtGoodwill.getRedeemOffer());
            gcsGoodwill.setApplicableCiCsv(oldCiId);
            gcsGoodwill.getApplicableCiOrderMap().put(oldCiId, 2L);

            CreditStage csGoodwill = new CreditStage(gcsGoodwill, oldCiId);
            csGoodwill.setCreditTaxDetails(goodwillTax);
            csGoodwill.setApplicableServiceStage(ss);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscription, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.setAvailableMainBalanceAmount(mainbalance);
            aopStage.setConsumableMainBalanceAmount(mainbalance);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            if (testCase.hasInsurance) {
                aopStage.appendVisibleOfferDetailsMap(
                        vodInsurance.getCatalogItemExternalId(),
                        Long.valueOf(vodInsurance.getResourceId()), vodInsurance);
            }
            if (testCase.hasWearable) {
                aopStage.appendVisibleOfferDetailsMap(
                        vodWearable.getCatalogItemExternalId(),
                        Long.valueOf(vodWearable.getResourceId()), vodWearable);
            }
            if (goodwillCredits.signum() > 0) {
                aopStage.getCreditMap().put(
                        new PromoOfferPair(oldCiId, vtGoodwill.getPromotionName()), csGoodwill);
            }

            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            Map<String, BigDecimal> balImpactMap = Map.of(
                    BALANCE_NAMES.GLOBAL_PASS, BigDecimal.ONE);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ONE, null, balImpactMap,
                    true);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ObjectMapper om = TestUtils.getObjectMapper();
                ServiceTaxResponse resp = om.readValue(taxRespString, ServiceTaxResponse.class);
                resp.getTransactionElement().get(0).setTotalFeeAmount(
                        BigDecimal.valueOf(testCase.fixedFee));
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                resp.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());

            System.out.println(
                    "**************************Asserting " + testCase.testNum
                            + "********************************");

            assertNull(response.getNextCycle());
            assertEquals(
                    response.getChangeCycle().getConsumableMainBalance().doubleValue(),
                    response.getConsumableMainBalance().doubleValue(), 0.001);
            assertEquals(
                    response.getChangeCycle().getPayableAmount().subtract(
                            response.getConsumableMainBalance()).doubleValue(),
                    response.getRechargeAmount().doubleValue(), 0.001);
            assertEquals(
                    response.getChangeCycle().getTotalAmount().doubleValue(),
                    response.getTotalAmount().doubleValue(), 0.001);
            System.out.println(
                    "**************************End of " + testCase.testNum
                            + "********************************");
        };
        TestConditions tc = new TestConditions() {

            {
                hasInsurance = true;
                hasWearable = true;
                otherPromos = 10;
                fixedFee = 1.81;
            }
        };

        SimpleEntry<String, String> change1 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.PLUS3VIS23,
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL);
        SimpleEntry<String, String> change2 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.PLUS3VIS23,
                TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL);
        SimpleEntry<String, String> change3 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.BASE3VIS23,
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL);
        SimpleEntry<String, String> change4 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.BASE3VIS23,
                TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL);
        SimpleEntry<String, String> change5 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL);
        List<SimpleEntry<String, String>> changes = List.of(
                change1, change2, change3, change4, change5);

        int testnum = 1;
        for (SimpleEntry<String, String> change : changes) {
            tc.oldCi = change.getKey();
            tc.newCi = change.getValue();
            tc.testNum = "#" + testnum++ + "-AsIsCi-" + tc.oldCi + "-ToBeCi-" + tc.newCi;
            pTests.test(tc);
        }
    }

    @Test
    @Tags({
        @Tag("MTXVER2TMA-4569"), @Tag("addon")
    })
    public void test_getChangeServiceAdvice_When_AddItems_DateOffset31_Then_AoP_AddonDates_Shoulld_Be_Correct(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service.", "base offer could be BASE3VISIBLE23.",
            "Subscribers bill cycle offset is 31."
        };
        td.when = new String[] {
            "Change to PLUS3VIS23WB", "New monthly addons to be added.",
            "Addon could be CD2VISIBLE2023.", "IncludePaymentAdvice = Y",
        };
        td.then = new String[] {
            "Advice shows PaymentAdvice with new addon.",
            "Cycle end date of new base service should be correct"
        };

        @SuppressWarnings("unchecked")
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            request.setDiscountPrice(
                    CommonTestHelper.getOfferPrice(request.getNewCatalogItemExternalId()));
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
            request.setIncludePaymentAdvice("Y");

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(
                            request.getSubscriptionExternalId(), Arrays.asList(tCase.oldCi)));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            request.getSubscriptionExternalId(), Arrays.asList(tCase.oldCi)));
            subscriptionResponse.getBillingCycle().setCurrentPeriodStartTime(
                    TestUtils.getLastDateTimeOfLastMonth(subscriptionResponse.getTimeZone()));
            subscriptionResponse.getBillingCycle().setCurrentPeriodEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth(subscriptionResponse.getTimeZone()));
            subscriptionResponse.getBillingCycle().setDateOffset(31L);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(tCase.oldCi, request.getNewCatalogItemExternalId()));
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getEmptyMtxResponseMulti());

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();

            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) subscription.getAtPurchasedOfferArray(
                    0).getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            emulateMtxResponseWallet(
                    instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));

            doReturn("[" + request.getNewCatalogItemExternalId() + "]").when(
                    instance).getLoggingKey(any());

            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                    request.getNewCatalogItemExternalId());
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getFirstDateTimeOfNextMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, enrolledExtnSub.getPaidCycleStartDate());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            assertNotNull(response.getNextCyclePaymentAdvice());
            assertNotNull(response.getNextCyclePaymentAdvice().getVisibleOfferDetailsList());
            assertEquals(
                    CommonUtils.getNextCycleEndTime(
                            subscriptionResponse.getBillingCycle(),
                            subscriptionResponse.getTimeZone()).getTime(),
                    response.getNextCyclePaymentAdvice().getAtVisibleOfferDetailsList(
                            0).getCycleEndTime());
        };

        String subscriptionExternalId = "123";

        VisibleRequestChangeServiceAdvice request01 = new VisibleRequestChangeServiceAdvice();
        request01.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3VIS23WB);
        request01.setSubscriptionExternalId(subscriptionExternalId);
        TestConditions tc01 = new TestConditions() {

            {
                newCi = request01.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE3VIS23;
            }
        };
        pTests.test(request01, tc01);
    }

    @ParameterizedTest(name = "When_IncludePaymentAdvice_Daylight_Savings_Then_CorrectCycleDates")
    @Tag("VER-626")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given | Subscriber has some mainbalance.|"
                +"|When  | Api is called with with target monthly service.|"
                +"|IncludePaymentAdvice = Y|"
                +"|Timezone will change before end date of next cycle due to daylight savings|"
                +"|Then  | Payment Advice should show correct cycle end date.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_When_IncludePaymentAdvice_Daylight_Savings_Then_CorrectCycleDates(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        @SuppressWarnings("unchecked")
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            request.setDiscountPrice(
                    CommonTestHelper.getOfferPrice(request.getNewCatalogItemExternalId()));
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
            request.setIncludePaymentAdvice("Y");

            String timezone = "Australia/Melbourne";
            // Daylight savings in first week of October AoP cycle starts mid of September ends mid
            // of October
            long offset = 15;
            MtxTimestamp currentCycleStart = new MtxTimestamp(
                    "2024-08-" + offset + "T00:00:00.000000+10:00");

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(
                            request.getSubscriptionExternalId(), Arrays.asList(tCase.oldCi)));
            subscription.setTimeZone(timezone);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            request.getSubscriptionExternalId(), Arrays.asList(tCase.oldCi)));
            subscriptionResponse.setTimeZone(timezone);
            subscriptionResponse.getBillingCycle().setCurrentPeriodStartTime(currentCycleStart);
            subscriptionResponse.getBillingCycle().setCurrentPeriodEndTime(
                    TestUtils.addOneMonth(currentCycleStart, timezone));
            subscriptionResponse.getBillingCycle().setDateOffset(offset);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(tCase.oldCi, request.getNewCatalogItemExternalId()));
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getEmptyMtxResponseMulti());

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();

            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) subscription.getAtPurchasedOfferArray(
                    0).getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            emulateMtxResponseWallet(
                    instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));

            doReturn("[" + request.getNewCatalogItemExternalId() + "]").when(
                    instance).getLoggingKey(any());

            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                    request.getNewCatalogItemExternalId());
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    subscriptionResponse.getBillingCycle().getCurrentPeriodStartTime());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime());

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, enrolledExtnSub.getPaidCycleStartDate());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            assertNotNull(response.getNextCyclePaymentAdvice());
            assertNotNull(response.getNextCyclePaymentAdvice().getVisibleOfferDetailsList());
            assertEquals(
                    CommonUtils.getNextCycleEndTime(
                            subscriptionResponse.getBillingCycle(),
                            subscriptionResponse.getTimeZone()).getTime(),
                    response.getNextCyclePaymentAdvice().getAtVisibleOfferDetailsList(
                            0).getCycleEndTime());
        };

        String subscriptionExternalId = "123";

        VisibleRequestChangeServiceAdvice request01 = new VisibleRequestChangeServiceAdvice();
        request01.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3VIS23WB);
        request01.setSubscriptionExternalId(subscriptionExternalId);
        TestConditions tc01 = new TestConditions() {

            {
                newCi = request01.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE3VIS23;
            }
        };
        pTests.test(request01, tc01);
    }

    @ParameterizedTest(
            name = "test_getChangeServiceAdvice_Given_HasPayer_Then_TaxWithPayerGeoDocde")
    @Tag("Tax")
    @Tag("VER-772")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscriber gets paid by payer for recurring services.|"
                +"|     |Subscriber has BASE3VISIBLE23.|"
                +"|When |CSA called. for upgrade to PLUS4VIS25WB or PLUS4VIS25WBA or PPLUS1VIS25WB or PPLUS1VIS25WBA|"
                +"|Then |CSA should call taxapi with payers geocode.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_Given_HasPayer_Then_TaxWithPayerGeoDocde(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        String payerGeoCode = "ELBISIVNOZIREV";
        String payerExternalID = "67890";
        String oldCi = CI_EXTERNAL_IDS.BASE3VIS23;
        @SuppressWarnings("unchecked")
        OneParameterTest pTests = (req) -> {
            td.printDescription();
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxObjectId caGroupId = new MtxObjectId("1-2-3-4");
            SubscriptionResponse benSubResp = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            request.getSubscriptionExternalId(), List.of(oldCi)));
            benSubResp.getParentGroupIdArrayAppender().add(caGroupId);

            MtxDate paidCycleStartDate = TestUtils.getMtxDateFromMtxTimestamp(
                    benSubResp.getBillingCycle().getCurrentPeriodStartTime());

            MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription(
                    request.getSubscriptionExternalId(), List.of(oldCi));
            benSub.getParentGroupIdArrayAppender().add(caGroupId);
            MtxResponseSubscription paySub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                    payerExternalID);
            paySub.getParentGroupIdArrayAppender().add(caGroupId);
            VisibleSubscriberExtension attr = (VisibleSubscriberExtension) paySub.getAttr();
            attr.setGeoCode(payerGeoCode);
            doReturn(benSub).doReturn(paySub).when(api).subscriptionQuery(any());

            emulateMtxResponsePricingCatalogItems(
                    instance, List.of(oldCi.toString(), request.getNewCatalogItemExternalId()));

            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponseMulti_For_CreditBalances(benSubResp));

            doReturn("[" + request.getSubscriptionExternalId() + "]").when(instance).getLoggingKey(
                    any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), aocAmount, null, null, false);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    oldCi.toString(), paidCycleStartDate);

            AdviceDataStage aopStage = new AdviceDataStage(
                    benSubResp, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(benSubResp));

            MtxResponseGroup respGrp = CommonTestHelper.getMtxResponseGroupCA(
                    benSub.getExternalId(), "CAGroup",
                    List.of(benSub.getObjectId().toString(), "1-2-3-4", "6-7-8-9"),
                    List.of(
                            String.format(
                                    GROUP_CONSTANTS.CA_LINK_FORMAT, benSub.getExternalId(),
                                    payerExternalID)));

            SubscriberGroup sg = new SubscriberGroup(respGrp);
            aopStage.appendSubscriberGroupList(sg);

            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(
                                any(), argumentCaptor.capture())).thenReturn(
                                        taxRespChangeCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            argumentCaptor.getAllValues().forEach(taxReq -> {
                System.out.println(td.getTestMethod() + ":" + taxReq);
            });
            ServiceTaxRequest deltaTaxReq = CommonTestHelper.getJsonFromString(
                    ServiceTaxRequest.class, argumentCaptor.getAllValues().get(0));
            assertEquals(payerGeoCode, deltaTaxReq.getGeocode());
            assertTrue(deltaTaxReq.getMsgID().contains("Payer:" + payerExternalID));

        };
        String subscriptionExternalId = "12345";
        VisibleRequestChangeServiceAdvice request = CommonTestHelper.getVisibleRequestChangeServiceAdvice(
                subscriptionExternalId, CI_EXTERNAL_IDS.PLUS25);
        pTests.test(request);
    }
}
