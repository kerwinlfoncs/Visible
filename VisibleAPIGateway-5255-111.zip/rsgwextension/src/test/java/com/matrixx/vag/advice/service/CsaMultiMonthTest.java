package com.matrixx.vag.advice.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.doReturn;

import java.math.BigDecimal;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import com.matrixx.datacontainer.MtxDate;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.MtxResponseGroup;
import com.matrixx.datacontainer.mdc.MtxResponsePurchase;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.SubscriptionResponse;
import com.matrixx.datacontainer.mdc.VisibleOfferDetails;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleRequestChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleResponseChangeServiceAdvice;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.advice.model.SubscriberGroup;
import com.matrixx.vag.common.Constants.CREDIT_CONSTANTS;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestUtils;
import com.matrixx.vag.common.ThreeParameterTest;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.tax.client.TaxApiClient;
import com.matrixx.vag.tax.model.ServiceTaxResponse;
import com.matrixx.vag.util.MDCTest;

public class CsaMultiMonthTest extends MDCTest {

    @Spy
    @InjectMocks
    private PaymentAdviceService instance = new PaymentAdviceService();

    @Mock
    private SubscriberManagementApi api;

    private TestInfo testInfo;

    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        instance = new PaymentAdviceService();
        MockitoAnnotations.openMocks(this);
        doReturn("").when(instance).getRoute(any());
        this.testInfo = testInfo;
    }

    @Test
    @Disabled
    @Tag("VER-261")
    // This should be moved to class ChangeServiceAdviceTest
    public void test_getChangeServiceAdvice_When_ChangeNextCycle_To_Monthly_Then_CorrectCycleDates(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscriber is enrolled in PlusMonthly."
        };
        td.when = new String[] {
            "ChangeAdvice is called for BaseMonthly."
        };
        td.then = new String[] {
            "Response should show ChangeCycleStartDate as per wallet.",
            "Response should show ChangeCycleEndDate as per wallet."
        };
        Assertions.fail();
    }

    @ParameterizedTest(
            name = "test_getChangeServiceAdvice_When_NewOffer_OtherThan_PreactiveOffer_Then_NoPreactiveInPaymentAdvice")
    @Tag("VER-846")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscriber has preactive base offer.|"
                +"|When |CSA called to change for different offer. i.e. New offer different from preactive offer.|"
                +"|Then |CSA output should not show preactive offer in Next Cycle Payment Advice|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_When_NewOffer_OtherThan_PreactiveOffer_Then_NoPreactiveInPaymentAdvice(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String activeBaseOffer = CI_EXTERNAL_IDS.BASE6MONTH25;
        String preactiveOffer = CI_EXTERNAL_IDS.BASE3VIS23;
        String newOffer = CI_EXTERNAL_IDS.PLUS25;
        VisibleRequestChangeServiceAdvice request = CommonTestHelper.getVisibleRequestChangeServiceAdvice(
                "12345", newOffer);
        request.setIncludePaymentAdvice("Y");
        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        SubscriptionResponse benSubResp = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse_LastMonth(
                        request.getSubscriptionExternalId(), List.of(activeBaseOffer),
                        List.of(preactiveOffer)));
        benSubResp.getAtPurchasedOfferArray(0).setEndTime(benSubResp.getBillingCycle().getCurrentPeriodEndTime());
        
        MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription(benSubResp);
        printUnitTest("benSubResp :" + benSubResp.toJson());

        doReturn(benSub).when(api).subscriptionQuery(any());

        emulateMtxResponsePricingCatalogItems(
                instance,
                List.of(activeBaseOffer, request.getNewCatalogItemExternalId(), preactiveOffer));

        emulateMtxResponseMultiFromObject(
                instance, CommonTestHelper.getMtxResponseMulti_For_CreditBalances(benSubResp));

        doReturn("[" + request.getSubscriptionExternalId() + "]").when(instance).getLoggingKey(
                any());
        BigDecimal aocAmount = BigDecimal.valueOf(4);
        MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                request.getNewCatalogItemExternalId(), aocAmount, null, null, false);
        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
        String taxRespString = CommonTestHelper.getTaxApiResp(
                request.getNewCatalogItemExternalId());

        VisibleOfferDetails vodPreactive = CommonTestHelper.getVisibleOfferDetails(
                preactiveOffer,
                TestUtils.getMtxDateFromMtxTimestamp(
                        benSubResp.getBillingCycle().getCurrentPeriodStartTime()),
                CommonTestHelper.getOfferPrice(preactiveOffer), benSubResp);

        AdviceDataStage aopStage = new AdviceDataStage(
                benSubResp, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodPreactive.getCatalogItemExternalId(), Long.valueOf(vodPreactive.getResourceId()),
                vodPreactive);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(benSubResp));

        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                    ServiceTaxResponse.class, taxRespString);
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), any())).thenReturn(
                    taxRespChangeCycle.toJson());
            instance.getChangeServiceAdvice(request, response);
        }
        printUnitTest("Request :" + request.toJson());
        printUnitTest("Response :" + response.toJson());
        boolean preactiveInVod = false;
        for (VisibleOfferDetails vod : response.getNextCyclePaymentAdvice().getVisibleOfferDetailsList()) {
            if (preactiveOffer.equalsIgnoreCase(vod.getCatalogItemExternalId())) {
                preactiveInVod = true;
            }
        }
        assertFalse(preactiveInVod);
    }

    @ParameterizedTest(
            name = "test_getChangeServiceAdvice_When_NewOffer_OtherThan_PreactiveOffer_Then_PreactiveOfferInResponse")
    @Tag("VER-846")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscriber has preactive base offer.|"
                +"|When |CSA called to change for different offer. i.e. New offer different from preactive offer.|"
                +"|Then |CSA output with preactive offer in response|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_When_NewOffer_OtherThan_PreactiveOffer_Then_PreactiveOfferInResponse(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String activeBaseOffer = CI_EXTERNAL_IDS.BASE6MONTH25;
        String preactiveOffer = CI_EXTERNAL_IDS.BASE3VIS23;
        String newOffer = CI_EXTERNAL_IDS.PLUS25;
        VisibleRequestChangeServiceAdvice request = CommonTestHelper.getVisibleRequestChangeServiceAdvice(
                "12345", newOffer);
        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        SubscriptionResponse benSubResp = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse_LastMonth(
                        request.getSubscriptionExternalId(), List.of(activeBaseOffer),
                        List.of(preactiveOffer)));

        MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription(benSubResp);
        printUnitTest("benSubResp :" + benSubResp.toJson());

        doReturn(benSub).when(api).subscriptionQuery(any());

        emulateMtxResponsePricingCatalogItems(
                instance,
                List.of(activeBaseOffer, request.getNewCatalogItemExternalId(), preactiveOffer));

        emulateMtxResponseMultiFromObject(
                instance, CommonTestHelper.getMtxResponseMulti_For_CreditBalances(benSubResp));

        doReturn("[" + request.getSubscriptionExternalId() + "]").when(instance).getLoggingKey(
                any());
        BigDecimal aocAmount = BigDecimal.valueOf(4);
        MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                request.getNewCatalogItemExternalId(), aocAmount, null, null, false);
        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
        String taxRespString = CommonTestHelper.getTaxApiResp(
                request.getNewCatalogItemExternalId());

        VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                activeBaseOffer, TestUtils.getMtxDateFromMtxTimestamp(
                        benSubResp.getBillingCycle().getCurrentPeriodStartTime()));

        AdviceDataStage aopStage = new AdviceDataStage(
                benSubResp, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                vodOldCi);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(benSubResp));

        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                    ServiceTaxResponse.class, taxRespString);
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), any())).thenReturn(
                    taxRespChangeCycle.toJson());
            instance.getChangeServiceAdvice(request, response);
        }
        printUnitTest("Request :" + request.toJson());
        printUnitTest("Response :" + response.toJson());
        assertEquals(preactiveOffer, response.getPreactiveCatalogItem().getCatalogItemExternalId());
    }

    @ParameterizedTest(
            name = "test_getChangeServiceAdvice_When_NewOffer_OtherThan_PreactiveOffer_Then_CorrectChangetype")
    @Tag("VER-846")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscriber has preactive base offer.|"
                +"|When |CSA called to change for different offer. i.e. New offer different from preactive offer.|"
                +"|Then |CSA changetype should treat active multmonth offer as FROM offer.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_When_NewOffer_OtherThan_PreactiveOffer_Then_CorrectChangetype(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        String preactiveOffer = CI_EXTERNAL_IDS.BASE3VIS23;

        ThreeParameterTest pTests = (activeOffer, req, changeType) -> {
            td.printDescription();
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();
            String activeBaseOffer = (String) activeOffer;
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            SubscriptionResponse benSubResp = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getSubscriptionResponse(
                            request.getSubscriptionExternalId(), List.of(activeBaseOffer),
                            List.of(preactiveOffer)));

            MtxPurchasedOfferInfo PoiEnrolled = benSubResp.getAtPurchasedOfferArray(0);
            VisiblePurchasedOfferExtension EnrolledPoiExtn = (VisiblePurchasedOfferExtension) PoiEnrolled.getAttr();
            MtxDate paidCycleStartDate = TestUtils.getMtxDateFromMtxTimestamp(
                    benSubResp.getBillingCycle().getCurrentPeriodStartTime());
            EnrolledPoiExtn.setPaidCycleStartDate(paidCycleStartDate);
            PoiEnrolled.getCycleInfo().setCycleEndTime(
                    benSubResp.getBillingCycle().getCurrentPeriodEndTime());
            PoiEnrolled.getCycleInfo().setCycleStartTime(
                    TestUtils.subtractMonths(
                            benSubResp.getBillingCycle().getCurrentPeriodEndTime(), 6,
                            benSubResp.getTimeZone()));

            MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription(
                    benSubResp);
            printUnitTest("benSubResp :" + benSubResp.toJson());

            doReturn(benSub).when(api).subscriptionQuery(any());

            emulateMtxResponsePricingCatalogItems(
                    instance,
                    List.of(
                            activeBaseOffer, request.getNewCatalogItemExternalId(),
                            preactiveOffer));

            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponseMulti_For_CreditBalances(benSubResp));

            doReturn("[" + request.getSubscriptionExternalId() + "]").when(instance).getLoggingKey(
                    any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), aocAmount, null, null, false);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    activeBaseOffer, paidCycleStartDate);

            AdviceDataStage aopStage = new AdviceDataStage(
                    benSubResp, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(benSubResp));

            MtxResponseGroup respGrp = CommonTestHelper.getMtxResponseGroupCA(
                    benSub.getExternalId(), "CAGroup",
                    List.of(benSub.getObjectId().toString(), "1-2-3-4", "6-7-8-9"), null);

            SubscriberGroup sg = new SubscriberGroup(respGrp);
            aopStage.appendSubscriberGroupList(sg);

            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), any())).thenReturn(
                        taxRespChangeCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            printUnitTest("Request :" + request.toJson());
            printUnitTest("Response :" + response.toJson());
            assertEquals(changeType.toString(), response.getChangeType());
        };
        String subscriptionExternalId = "12345";
        pTests.test(
                CI_EXTERNAL_IDS.BASE6MONTH25,
                CommonTestHelper.getVisibleRequestChangeServiceAdvice(
                        subscriptionExternalId, CI_EXTERNAL_IDS.PLUS25),
                AppPropertyProvider.getInstance().getString(
                        "change.service.type.name.BASE6VISIBLE25.to.PLUS4VIS25WB"));
    }

    private void printUnitTest(Object msg) {
        System.out.println(testInfo.getDisplayName() + ":" + msg);
    }
}
