package com.matrixx.vag.tax.client;
import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;
import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.mockito.InjectMocks;
import org.mockito.Spy;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.exc.MismatchedInputException;
import com.github.tomakehurst.wiremock.http.Fault;
import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.matrixx.datacontainer.mdc.MtxResponsePricingCatalogItem;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.common.Constants.TAX_CONSTANTS;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestConstants.DATA_DIR;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.device.service.DeviceService;
import com.matrixx.vag.exception.TaxApiException;
import com.matrixx.vag.service.IntegrationService;
import com.matrixx.vag.tax.model.ServiceTaxRequest;
import com.matrixx.vag.tax.model.ServiceTaxResponse;
import com.matrixx.vag.util.MDCTest;

public class TaxApiClientTest extends MDCTest{
	@Spy
	@InjectMocks
	private DeviceService instance = new DeviceService();

	final int PORT = 1198;
    String taxApiPath = null;
    
	@Rule
    public WireMockRule wireMockRule = new WireMockRule(options().port(PORT));
	    
    @Before
    public void setUp() throws Exception {
        AppPropertyProvider.getInstance().setProperty(
                TAX_CONSTANTS.TAX_ON_SERVICES_API_ENDPOINT,
                "http://localhost:" + PORT + "/taxapi/tax/services");

        final String URL_PATH = AppPropertyProvider.getInstance().getString(
                TAX_CONSTANTS.TAX_ON_SERVICES_API_ENDPOINT);

        URL url = new URL(URL_PATH);
        taxApiPath = url.getPath();

        System.out.println("taxApiPath: " + taxApiPath + ", port: " + url.getPort());
    }
    
    @Test
    public void test_getTaxApiResult_whenTaxApiReturnsResult_ClientReturnsResult() throws Exception {

        final String TAX_API_RESPONSE =CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.UNLIMITED); 

        stubFor(
                post(urlEqualTo(taxApiPath)).willReturn(
                        aResponse().withStatus(HttpURLConnection.HTTP_OK).withHeader(
                                "Content-Type", "application/json").withBody(TAX_API_RESPONSE)));

        String result = TaxApiClient.getTaxApiResult("JunitTest",  "Sample");
        assertNotNull(result);
    }
    
    @Test
    public void test_getTaxApiResult_whenTaxApiThrows_BAD_REQUEST_ClientRethrows() throws Exception {
        stubFor(
                post(urlEqualTo(taxApiPath)).willReturn(
                        aResponse().withStatus(HttpURLConnection.HTTP_BAD_REQUEST).withHeader(
                                "Content-Type", "application/json").withBody(
                                        "{\"error\":\"Sample bad request error\"}")));
        Exception exception = assertThrows(IOException.class, () -> TaxApiClient.getTaxApiResult("JunitTest",  "Sample"));
		Assertions.assertTrue(exception.getMessage().contains(HttpURLConnection.HTTP_BAD_REQUEST+""));
    }
    
    @Test
    public void test_getTaxApiResult_whenTaxApiThrows_INTERNAL_ERROR_ClientRethrows() throws Exception {
        stubFor(
                post(urlEqualTo(taxApiPath)).willReturn(
                        aResponse().withStatus(HttpURLConnection.HTTP_INTERNAL_ERROR).withHeader(
                                "Content-Type", "application/json").withBody(
                                        "{\"error\":\"Sample internal error\"}")));
        Exception exception = assertThrows(IOException.class, () -> TaxApiClient.getTaxApiResult("JunitTest",  "Sample"));
		Assertions.assertTrue(exception.getMessage().contains(HttpURLConnection.HTTP_INTERNAL_ERROR+""));
    }
   
    @Test
    public void test_getTaxApiResult_whenTaxApiThrows_MALFORMED_RESPONSE_ClientRethrows() throws Exception {
        stubFor(
                post(urlEqualTo(taxApiPath)).willReturn(
                        aResponse().withFault(Fault.MALFORMED_RESPONSE_CHUNK)));
        assertThrows(IOException.class, () -> TaxApiClient.getTaxApiResult("JunitTest",  "Sample"));		
    }
    
    @Test
    public void test_getTaxApiResult_whenTaxApiThrows_EMPTY_RESPONSE_ClientRethrows() throws Exception {
        stubFor(
                post(urlEqualTo(taxApiPath)).willReturn(
                        aResponse().withFault(Fault.EMPTY_RESPONSE)));
        assertThrows(IOException.class, () -> TaxApiClient.getTaxApiResult("JunitTest", "Sample"));		
    }
    
    @Test
    public void test_getTaxApiResult_whenTaxApiThrows_RANDOM_DATA_ClientRethrows() throws Exception {
        stubFor(
                post(urlEqualTo(taxApiPath)).willReturn(
                        aResponse().withFault(Fault.RANDOM_DATA_THEN_CLOSE)));
        assertThrows(IOException.class, () -> TaxApiClient.getTaxApiResult("JunitTest",  "Sample"));		
    }
    
    @Test
    public void testTaxApiResponseParsing1() throws JsonMappingException, JsonProcessingException{
    	String testResponse = "{\"msgID\":\"CA Service\",\"customerType\":\"99\",\"planID\":\"BASE001A\",\"grossPrice\":\"40.00\",\"discountPrice\":\"40.0\",\"promotionCredit\":\"false\",\"offer606RevAdjDailyRecog\":\"0\",\"geocode\":\"US0608510345\",\"taxTreatment\":\"inclusive\",\"classCode\":\"SVC\",\"glDate\":\"2021-09-30\",\"transactionElement\":[{\"btcTransactionCode\":\"01\",\"totalTaxAmount\":\"0.05386810\",\"totalFeeAmount\":\"0.30000000\",\"totalNetRevenue\":\"39.64613188\",\"modifiedDisplayNetRevenue\":\"39.65\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"618\",\"cP\":\"0.9719167977\",\"glReference\":\"Visible_Unlimited_Data\",\"dpcItemTaxAmount\":\"0.00000000\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"38.53274154\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012004\",\"tat\":\"5\",\"taxCategory\":\"32\",\"taxType\":\"C1\",\"description\":\"CA Local Prepaid MTS\",\"rate\":\"0.000000000000\",\"taxAmount\":\"0.00000000\"}]},{\"dpcItem\":\"601\",\"cP\":\"0.0238925768\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.05386810\",\"dpcItemFeeAmount\":\"0.30000000\",\"dpcItemNetRevenue\":\"0.94724825\",\"taxItemList\":[{\"taxItemType\":\"fee\",\"tai\":\"000012004\",\"tat\":\"1\",\"taxCategory\":\"25\",\"taxType\":\"06\",\"description\":\"CA State 911 Surcharge\",\"rate\":\"0.00\",\"taxAmount\":\"0.30000000\"},{\"taxItemType\":\"tax\",\"tai\":\"000012004\",\"tat\":\"1\",\"taxCategory\":\"00\",\"taxType\":\"17\",\"description\":\"CA State High Cost Fund (B)\",\"rate\":\"0.000000000000\",\"taxAmount\":\"0.00000000\"},{\"taxItemType\":\"tax\",\"tai\":\"000012004\",\"tat\":\"1\",\"taxCategory\":\"00\",\"taxType\":\"18\",\"description\":\"CA Teleconnect Fund Surchg\",\"rate\":\"0.005360000000\",\"taxAmount\":\"0.00507725\"},{\"taxItemType\":\"tax\",\"tai\":\"000012004\",\"tat\":\"1\",\"taxCategory\":\"00\",\"taxType\":\"19\",\"description\":\"CA State High Cost Fund (A)\",\"rate\":\"0.004810000000\",\"taxAmount\":\"0.00455626\"},{\"taxItemType\":\"tax\",\"tai\":\"000012004\",\"tat\":\"1\",\"taxCategory\":\"00\",\"taxType\":\"22\",\"description\":\"Lifeline Surcharge - CA\",\"rate\":\"0.032640000000\",\"taxAmount\":\"0.03091818\"},{\"taxItemType\":\"tax\",\"tai\":\"000012004\",\"tat\":\"1\",\"taxCategory\":\"00\",\"taxType\":\"23\",\"description\":\"CA Advanced Srvcs Fund (CASF)\",\"rate\":\"0.007002000000\",\"taxAmount\":\"0.00663263\"},{\"taxItemType\":\"tax\",\"tai\":\"000012004\",\"tat\":\"1\",\"taxCategory\":\"00\",\"taxType\":\"82\",\"description\":\"CA State PUC Fee\",\"rate\":\"0.003620000000\",\"taxAmount\":\"0.00342904\"},{\"taxItemType\":\"tax\",\"tai\":\"000012004\",\"tat\":\"1\",\"taxCategory\":\"00\",\"taxType\":\"85\",\"description\":\"CA Relay Srvc/Comm Device Fund\",\"rate\":\"0.003436000000\",\"taxAmount\":\"0.00325474\"},{\"taxItemType\":\"tax\",\"tai\":\"000012004\",\"tat\":\"5\",\"taxCategory\":\"32\",\"taxType\":\"C1\",\"description\":\"CA Local Prepaid MTS\",\"rate\":\"0.000000000000\",\"taxAmount\":\"0.00000000\"}]},{\"dpcItem\":\"662\",\"cP\":\"0.0000041959\",\"glReference\":\"Visible_Unlimited_Text\",\"dpcItemTaxAmount\":\"0.00000000\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.00016635\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012004\",\"tat\":\"5\",\"taxCategory\":\"32\",\"taxType\":\"C1\",\"description\":\"CA Local Prepaid MTS\",\"rate\":\"0.000000000000\",\"taxAmount\":\"0.00000000\"}]},{\"dpcItem\":\"629\",\"cP\":\"0.0041864296\",\"glReference\":\"Visible_Unlimited_MMS\",\"dpcItemTaxAmount\":\"0.00000000\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.16597574\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012004\",\"tat\":\"5\",\"taxCategory\":\"32\",\"taxType\":\"C1\",\"description\":\"CA Local Prepaid MTS\",\"rate\":\"0.000000000000\",\"taxAmount\":\"0.00000000\"}]}]}]}]}";
		ObjectMapper objectMapper = new ObjectMapper();
		ServiceTaxResponse str = objectMapper.readValue(testResponse, ServiceTaxResponse.class);
		System.out.println(str.getClassCode());
		Assertions.assertTrue(StringUtils.isNotBlank(str.getClassCode()));
    }

    @Test
    public void testTaxApiResponseParsing2() throws JsonMappingException, JsonProcessingException{
    	String testResponse = "{\"msgID\":\"04826485\",\"customerType\":\"00\",\"planID\":\"BASE001A\",\"grossPrice\":\"40.00\",\"discountPrice\":\"40.00\",\"geocode\":\"US0608510345\",\"taxTreatment\":\"inclusive\",\"classCode\":\"SVC\",\"glDate\":\"2021-08-06\",\"transactionElement\":[{\"btcTransactionCode\":\"01\",\"totalTaxAmount\":\"0.05386810\",\"totalFeeAmount\":\"0.30000000\",\"totalNetRevenue\":\"39.64613188\",\"modifiedDisplayNetRevenue\":\"39.65\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"601\",\"cP\":\"0.0238925768\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.05386810\",\"dpcItemFeeAmount\":\"0.30000000\",\"dpcItemNetRevenue\":\"0.94724825\",\"taxItemList\":[{\"taxItemType\":\"fee\",\"tai\":\"000012004\",\"tat\":\"1\",\"taxCategory\":\"25\",\"taxType\":\"06\",\"description\":\"CA State 911 Surcharge\",\"rate\":\"0.00\",\"taxAmount\":\"0.30000000\"},{\"taxItemType\":\"tax\",\"tai\":\"000012004\",\"tat\":\"1\",\"taxCategory\":\"00\",\"taxType\":\"17\",\"description\":\"CA State High Cost Fund (B)\",\"rate\":\"0.000000000000\",\"taxAmount\":\"0.00000000\"},{\"taxItemType\":\"tax\",\"tai\":\"000012004\",\"tat\":\"1\",\"taxCategory\":\"00\",\"taxType\":\"18\",\"description\":\"CA Teleconnect Fund Surchg\",\"rate\":\"0.005360000000\",\"taxAmount\":\"0.00507725\"},{\"taxItemType\":\"tax\",\"tai\":\"000012004\",\"tat\":\"1\",\"taxCategory\":\"00\",\"taxType\":\"19\",\"description\":\"CA State High Cost Fund (A)\",\"rate\":\"0.004810000000\",\"taxAmount\":\"0.00455626\"},{\"taxItemType\":\"tax\",\"tai\":\"000012004\",\"tat\":\"1\",\"taxCategory\":\"00\",\"taxType\":\"22\",\"description\":\"Lifeline Surcharge - CA\",\"rate\":\"0.032640000000\",\"taxAmount\":\"0.03091818\"},{\"taxItemType\":\"tax\",\"tai\":\"000012004\",\"tat\":\"1\",\"taxCategory\":\"00\",\"taxType\":\"23\",\"description\":\"CA Advanced Srvcs Fund (CASF)\",\"rate\":\"0.007002000000\",\"taxAmount\":\"0.00663263\"},{\"taxItemType\":\"tax\",\"tai\":\"000012004\",\"tat\":\"1\",\"taxCategory\":\"00\",\"taxType\":\"82\",\"description\":\"CA State PUC Fee\",\"rate\":\"0.003620000000\",\"taxAmount\":\"0.00342904\"},{\"taxItemType\":\"tax\",\"tai\":\"000012004\",\"tat\":\"1\",\"taxCategory\":\"00\",\"taxType\":\"85\",\"description\":\"CA Relay Srvc/Comm Device Fund\",\"rate\":\"0.003436000000\",\"taxAmount\":\"0.00325474\"},{\"taxItemType\":\"tax\",\"tai\":\"000012004\",\"tat\":\"5\",\"taxCategory\":\"32\",\"taxType\":\"C1\",\"description\":\"CA Local Prepaid MTS\",\"rate\":\"0.000000000000\",\"taxAmount\":\"0.00000000\"}]},{\"dpcItem\":\"618\",\"cP\":\"0.9719167977\",\"glReference\":\"Visible_Unlimited_Data\",\"dpcItemTaxAmount\":\"0.00000000\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"38.53274154\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012004\",\"tat\":\"5\",\"taxCategory\":\"32\",\"taxType\":\"C1\",\"description\":\"CA Local Prepaid MTS\",\"rate\":\"0.000000000000\",\"taxAmount\":\"0.00000000\"}]},{\"dpcItem\":\"629\",\"cP\":\"0.0041864296\",\"glReference\":\"Visible_Unlimited_MMS\",\"dpcItemTaxAmount\":\"0.00000000\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.16597574\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012004\",\"tat\":\"5\",\"taxCategory\":\"32\",\"taxType\":\"C1\",\"description\":\"CA Local Prepaid MTS\",\"rate\":\"0.000000000000\",\"taxAmount\":\"0.00000000\"}]},{\"dpcItem\":\"662\",\"cP\":\"0.0000041959\",\"glReference\":\"Visible_Unlimited_Text\",\"dpcItemTaxAmount\":\"0.00000000\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.00016635\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012004\",\"tat\":\"5\",\"taxCategory\":\"32\",\"taxType\":\"C1\",\"description\":\"CA Local Prepaid MTS\",\"rate\":\"0.000000000000\",\"taxAmount\":\"0.00000000\"}]}]}]}]}";
		ObjectMapper objectMapper = new ObjectMapper();
		ServiceTaxResponse str = objectMapper.readValue(testResponse, ServiceTaxResponse.class);
		System.out.println(str.getClassCode());
		Assertions.assertTrue(StringUtils.isNotBlank(str.getClassCode()));
    }
    
    @Test
    public void testTaxApiResponseParsing_Error_With_Empty_Payload() throws JsonMappingException, JsonProcessingException{
    	String testResponse = "";
		ObjectMapper objectMapper = new ObjectMapper();
		Exception exception = assertThrows(MismatchedInputException.class, () -> objectMapper.readValue(testResponse, ServiceTaxResponse.class));
		Assertions.assertEquals(MismatchedInputException.class.getSimpleName(), exception.getClass().getSimpleName());
    }
    
    @Test
    public void testTaxApiRequestParsing() throws JsonMappingException, JsonProcessingException{
    	String testRequest = "{\"msgID\":\"CA Service\",\"customerType\":\"99\",\"planID\":\"BASE001A\",\"grossPrice\":40.00,\"discountPrice\":40.0,\"geocode\":\"US0608510345\",\"taxTreatment\":\"inclusive\",\"classCode\":\"SVC\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"618\",\"cP\":0.9719167977,\"cycleNSR\":0,\"glReference\":\"Visible_Unlimited_Data\"},{\"dpcItem\":\"601\",\"cP\":0.0238925768,\"cycleNSR\":0,\"glReference\":\"Visible_Unlimited_Voice\"},{\"dpcItem\":\"662\",\"cP\":0.0000041959,\"cycleNSR\":0,\"glReference\":\"Visible_Unlimited_Text\"},{\"dpcItem\":\"629\",\"cP\":0.0041864296,\"cycleNSR\":0,\"glReference\":\"Visible_Unlimited_MMS\"}]}],\"promotionReason\":null,\"vendorPayable\":null,\"vendorPayableNonProrated\":null,\"offer606RevAdjDailyRecog\":0,\"promotionCredit\":false,\"glDate\":\"2021-09-30\"}";
		ObjectMapper objectMapper = new ObjectMapper();
		ServiceTaxRequest str = objectMapper.readValue(testRequest, ServiceTaxRequest.class);
		System.out.println(str.getClassCode());
		Assertions.assertTrue(StringUtils.isNotBlank(str.getClassCode()));
    }
    
	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_getServiceTaxDetails_InvalidService_IntegrationServiceException() throws Exception {

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.PAYMENT_ADVICE + "MtxResponseSubscription.json");

		String ciExternalId = "Visible_Device_Swap";
		String goodType = "Device_Swap";
	
	    Exception exception = Assertions.assertThrows(TaxApiException.class, 
	    		() -> TaxApiClient.getServiceTaxDetails(subRes, null, null, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, ciExternalId, goodType,
				"", "", ""));
	    exception.printStackTrace();
	    Assertions.assertTrue(exception.getMessage().contains("Unknown service type"));
	}

	@Test
	public void test_getServiceTaxDetails_whenTaxApiReturnsServiceResult_ClientReturnsResult() throws Exception {
		MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription();
		String ciExternalId = "Visible_Device_Swap";
		String goodType = "Device_Swap";
		MtxResponsePricingCatalogItem pci =CommonTestHelper.getMtxResponsePricingCatalogItem(CI_EXTERNAL_IDS.UNLIMITED);

        final String TAX_API_RESPONSE =CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.UNLIMITED); 

        stubFor(
                post(urlEqualTo(taxApiPath)).willReturn(
                        aResponse().withStatus(HttpURLConnection.HTTP_OK).withHeader(
                                "Content-Type", "application/json").withBody(TAX_API_RESPONSE)));
        
        String result = TaxApiClient.getServiceTaxDetails(subRes, pci, null, BigDecimal.ZERO, 
	    		BigDecimal.ZERO, BigDecimal.ZERO, ciExternalId, goodType,
	    		IntegrationService.SERVICE_TYPE_SERVICE, "", "");
	    assertNotNull(result);
	}

	@Test
	public void test_getServiceTaxDetails_whenTaxApiReturnsInsuranceResult_ClientReturnsResult() throws Exception {
		MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription();
		String ciExternalId = "Visible_Device_Swap";
		String goodType = "Device_Swap";
		MtxResponsePricingCatalogItem pci =CommonTestHelper.getMtxResponsePricingCatalogItem(CI_EXTERNAL_IDS.INSURANCE);

        final String TAX_API_RESPONSE =CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.INSURANCE); 

        stubFor(
                post(urlEqualTo(taxApiPath)).willReturn(
                        aResponse().withStatus(HttpURLConnection.HTTP_OK).withHeader(
                                "Content-Type", "application/json").withBody(TAX_API_RESPONSE)));
        
        String result = TaxApiClient.getServiceTaxDetails(subRes, null, pci, BigDecimal.ZERO, 
	    		BigDecimal.ZERO, BigDecimal.ZERO, ciExternalId, goodType,
	    		IntegrationService.SERVICE_TYPE_INSURANCE, "", "");
	    assertNotNull(result);
	}
	
	@Test
	public void test_getServiceTaxDetails_whenTaxApiReturnsException_ClientRethrows() throws Exception {
		MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription();
		String ciExternalId = "Visible_Device_Swap";
		String goodType = "Device_Swap";
		MtxResponsePricingCatalogItem pci =CommonTestHelper.getMtxResponsePricingCatalogItem(CI_EXTERNAL_IDS.UNLIMITED);

        stubFor(
                post(urlEqualTo(taxApiPath)).willReturn(
                        aResponse().withFault(Fault.MALFORMED_RESPONSE_CHUNK)));
        assertThrows(TaxApiException.class, () -> TaxApiClient.getServiceTaxDetails(subRes, pci, null, BigDecimal.ZERO, 
	    		BigDecimal.ZERO, BigDecimal.ZERO, ciExternalId, goodType,
	    		IntegrationService.SERVICE_TYPE_SERVICE, "", ""));

	}
}
