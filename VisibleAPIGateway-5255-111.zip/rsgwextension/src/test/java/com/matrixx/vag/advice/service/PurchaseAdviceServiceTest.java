package com.matrixx.vag.advice.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.matrixx.datacontainer.mdc.*;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.advice.model.VisibleOfferDetailsInternal;
import com.matrixx.vag.advice.model.VisibleResponsePurchaseAdvice;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.OneParameterTest;
import com.matrixx.vag.common.TestUtils;
import com.matrixx.vag.common.TwoParameterTest;
import com.matrixx.vag.common.Constants.CREDIT_CONSTANTS;
import com.matrixx.vag.common.Constants.CYCLE_LENGTHS;
import com.matrixx.vag.common.TestConstants.BALANCE_NAMES;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestConstants.DATA_DIR;
import com.matrixx.vag.common.TestConstants.OFFER_PRICES;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.TaxApiException;
import com.matrixx.vag.tax.client.TaxApiClient;
import com.matrixx.vag.tax.model.DpcGroupTax;
import com.matrixx.vag.tax.model.DpcItemTax;
import com.matrixx.vag.tax.model.ServiceTaxResponse;
import com.matrixx.vag.util.MDCTest;

public class PurchaseAdviceServiceTest extends MDCTest {

    @Spy
    @InjectMocks
    private PaymentAdviceService instance = new PaymentAdviceService();

    @Mock
    private SubscriberManagementApi api;

    private TestInfo testInfo;

    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        instance = new PaymentAdviceService();
        MockitoAnnotations.openMocks(this);
        this.testInfo = testInfo;
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getPurchaseAdvice_When_NonZeroMainbalance_Then_CorrectChargeAmount()
            throws Exception {

        VisibleMultiRequestPurchaseService purchaseInput = CommonTestHelper.loadJsonMessage(
                VisibleMultiRequestPurchaseService.class,
                DATA_DIR.PAYMENT_ADVICE + "VisibleMultiRequestPurchaseService_TwoCI.json");

        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.INSURANCE);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        BigDecimal mainbalance = new BigDecimal("20.0");
        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(mainbalance);
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        MtxResponsePurchase aocRespService = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_VisibleUnlimited.json");

        MtxResponsePurchase aocRespInsurance = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_VisibleInsurance.json");

        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();
        subscription.getBalanceArrayAppender().clear();
        MtxBalanceInfo mbiMainbalance = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.MAIN_BALANCE, mainbalance);
        subscription.getBalanceArrayAppender().add(mbiMainbalance);

        doReturn(aocRespService).when(instance).doSubscriberPurchaseOfferAOC(
                any(), eq("Visible_Unlimited"), any(), any());
        doReturn(aocRespInsurance).when(instance).doSubscriberPurchaseOfferAOC(
                any(), eq("Visible_Device_Insurance_Bundle_CI"), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        doReturn(BigDecimal.ZERO).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(CI_EXTERNAL_IDS.PARTY_PAY_REDEEM), any(),
                any(MtxSubscriberSearchData.class));

        // method to test
        VisibleResponsePaymentAdviceService aopResp = instance.getPurchaseAdvice(
                null, null, purchaseInput, subscription);
        System.out.println(subscription.toJson());
        System.out.println(aopResp.toJson());

        //@formatter:on
        assertEquals(
                aopResp.getEstimatedPayableAmount().add(
                        aopResp.getConsumableMainBalanceAmount()).doubleValue(),
                aopResp.getTotalEstimatedAmount().doubleValue(), 0.011);

        assertEquals(
                subscription.getBalanceArray().stream().filter(
                        balInfo -> balInfo.getName().equals("Mainbalance")).map(
                                balInfo -> balInfo.getAvailableAmount()).findFirst().get().doubleValue(),
                aopResp.getAvailableMainBalanceAmount().doubleValue(), 0.01);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getPurchaseAdvice_When_ZeroDollarOffer_FixedFeeGeoCode_Then_PayAsPerFixedFeeIgnoreFlag()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscribers tax geocode is subject to fixed fee."
        };
        td.when = new String[] {
            "PurchaseAdvice is called. Taxapi provides fixedfee."
        };
        td.then = new String[] {
            "PurchaseAdvice response should show payable amount as per fixedfee ignore flag."
        };
        td.printDescription();
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        OneParameterTest pTests = (fixedFeeIgnore) -> {
            BigDecimal discountPrice = BigDecimal.ZERO;

            VisibleMultiRequestPurchaseService purchaseInput = new VisibleMultiRequestPurchaseService();
            purchaseInput.setSubscriberExternalId("123");
            VisiblePurchaseInfo vpi = CommonTestHelper.getVisiblePurchaseInfo(
                    CI_EXTERNAL_IDS.TRIAL22);
            vpi.getPurchaseServiceInfo().setServiceDiscountPrice(discountPrice.toPlainString());
            purchaseInput.getPurchaseInfoAppender().add(vpi);

            String baseCi = CI_EXTERNAL_IDS.TRIAL22;
            BigDecimal fixedFee = BigDecimal.valueOf(1.91);

            ObjectMapper om = TestUtils.getObjectMapper();
            ServiceTaxResponse resp = om.readValue(
                    purchaseInput.getAtPurchaseInfo(
                            0).getPurchaseServiceInfo().getServiceTaxDetails(),
                    ServiceTaxResponse.class);
            resp.getTransactionElement().get(0).setTotalFeeAmount(fixedFee);
            purchaseInput.getAtPurchaseInfo(0).getPurchaseServiceInfo().setServiceTaxDetails(
                    resp.toJson());

            MtxResponsePricingCatalogItem pci = emulateMtxResponsePricingCatalogItem(
                    instance, baseCi);
            VisibleTemplate vt = (VisibleTemplate) pci.getCatalogItemInfo().getTemplateAttr();
            if (fixedFeeIgnore == null) {
                vt.setIgnoreTax_ForPayableAmount((String) null);
            } else {
                vt.setIgnoreTax_ForPayableAmount(fixedFeeIgnore.toString());
            }

            MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();
            subscription.getBalanceArrayAppender().clear();

            MtxTimestamp walletCycleStartDate = TestUtils.getDateTimeOfMidnightToday();

            MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);

            MtxBalanceInfo biMainBalance = CommonTestHelper.getMtxBalanceInfo(
                    BALANCE_NAMES.MAIN_BALANCE, 1L, 2L, null);
            subscription.getBalanceArrayAppender().add(biMainBalance);

            MtxResponsePurchase aocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfo(
                    baseCi, BALANCE_NAMES.MAIN_BALANCE, discountPrice);
            aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);

            MtxTimestamp tsNow = CommonUtils.getMtxTimestampTodayZeroHours(
                    walletCycleStartDate, subscription.getTimeZone());
            aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    tsNow);
            aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.addOneYear(tsNow));

            emulateMtxResponseMultiFromObject(instance, null);

            doReturn(aocResp).when(instance).doSubscriberPurchaseOfferAOC(
                    any(), eq(baseCi), any(), any());
            emulateMtxResponseSubscription(instance, subscription);
            doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

            // method to test
            VisibleResponsePaymentAdviceService aopResp = instance.getPurchaseAdvice(
                    null, null, purchaseInput, subscription);

            System.out.println(aopResp.toJson());
            double expectedAmount = StringUtils.isBlank(vt.getIgnoreTax_ForPayableAmount())
                    ? fixedFee.doubleValue()
                    : (vt.getIgnoreTax_ForPayableAmount().equalsIgnoreCase("True")
                            ? 0 : fixedFee.doubleValue());
            assertEquals(
                    expectedAmount,
                    aopResp.getAtVisibleOfferDetailsList(0).getPayableAmount().doubleValue(),
                    0.001);
            assertEquals(expectedAmount, aopResp.getEstimatedPayableAmount().doubleValue(), 0.001);
            assertEquals(expectedAmount, aopResp.getTotalEstimatedAmount().doubleValue(), 0.001);
        };

        pTests.test("True");
        pTests.test("False");
        pTests.test("");
        pTests.test(null);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getPurchaseAdvice_When_Subscription_HasMoreGift_Then_FixedFeeNotPayable()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber has gift amount.", "Subscribers tax geocode is subject to fixed fee.",
            "Gift amount is more than fixedfee."
        };
        td.when = new String[] {
            "PurchaseAdvice is called. Taxapi provides fixedfee."
        };
        td.then = new String[] {
            "PurchaseAdvice response should show no payable amount."
        };
        td.printDescription();
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        BigDecimal discountPrice = BigDecimal.valueOf(2);

        VisibleMultiRequestPurchaseService purchaseInput = new VisibleMultiRequestPurchaseService();
        purchaseInput.setSubscriberExternalId("123");
        VisiblePurchaseInfo vpi = CommonTestHelper.getVisiblePurchaseInfo(
                CI_EXTERNAL_IDS.BASE2ANNUAL);
        vpi.getPurchaseServiceInfo().setServiceDiscountPrice(discountPrice.toPlainString());
        purchaseInput.getPurchaseInfoAppender().add(vpi);

        String annualBaseCi = CI_EXTERNAL_IDS.BASE2ANNUAL;
        String giftGrantCi = CI_EXTERNAL_IDS.GIFT_GRANT;
        BigDecimal giftConsumable = BigDecimal.valueOf(5);
        BigDecimal giftGrant = BigDecimal.valueOf(5);
        BigDecimal giftAmount = giftGrant.add(giftConsumable);
        BigDecimal fixedFee = BigDecimal.valueOf(8);

        ObjectMapper om = TestUtils.getObjectMapper();
        ServiceTaxResponse resp = om.readValue(
                purchaseInput.getAtPurchaseInfo(0).getPurchaseServiceInfo().getServiceTaxDetails(),
                ServiceTaxResponse.class);
        resp.getTransactionElement().get(0).setTotalFeeAmount(fixedFee);
        purchaseInput.getAtPurchaseInfo(0).getPurchaseServiceInfo().setServiceTaxDetails(
                resp.toJson());

        emulateMtxResponsePricingCatalogItem(instance, annualBaseCi);
        emulateMtxResponsePricingCatalogItem(instance, giftGrantCi);

        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();
        subscription.getBalanceArrayAppender().clear();

        MtxTimestamp walletCycleStartDate = TestUtils.getDateTimeOfMidnightToday();

        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);

        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, giftGrantCi, null, giftGrant, giftConsumable);

        MtxBalanceInfo biMainBalance = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.MAIN_BALANCE, 1L, 2L, null);
        subscription.getBalanceArrayAppender().add(biMainBalance);

        MtxResponsePurchase aocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfo(
                annualBaseCi, BALANCE_NAMES.MAIN_BALANCE, discountPrice);
        aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);
        // For Aoc cycle dates will be today to nne year plus
        MtxTimestamp tsNow = CommonUtils.getMtxTimestampTodayZeroHours(
                walletCycleStartDate, subscription.getTimeZone());
        aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(tsNow);
        aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                TestUtils.addOneYear(tsNow));

        List<String> balPriList = Arrays.asList(BALANCE_NAMES.GIFT_GRANT);
        emulateMtxResponseMultiFromObject(
                instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));

        doReturn(aocResp).when(instance).doSubscriberPurchaseOfferAOC(
                any(), eq(annualBaseCi), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        // method to test
        VisibleResponsePaymentAdviceService aopResp = instance.getPurchaseAdvice(
                null, null, purchaseInput, subscription);

        System.out.println(aopResp.toJson());

        assertEquals(
                giftAmount.compareTo(fixedFee), 1,
                "Dummy Assert to make sure that testcase always has fee lower than gift");
        assertEquals(
                0, aopResp.getAtVisibleOfferDetailsList(0).getPayableAmount().doubleValue(), 0.001,
                "Payable amount should be nil");
        assertEquals(
                0, aopResp.getEstimatedPayableAmount().doubleValue(), 0.001,
                "Payable amount should be nil");
        assertEquals(
                0, aopResp.getTotalEstimatedAmount().doubleValue(), 0.001,
                "Payable amount should be nil");
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getPurchaseAdvice_When_Subscription_HasLessGiftAsConsumables_Then_GiftUsedToPayFixedFee()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber has gift amount.", "Subscribers tax geocode is subject to fixed fee.",
            "Gift amount is less than fixedfee."
        };
        td.when = new String[] {
            "PurchaseAdvice is called. Taxapi provides fixedfee."
        };
        td.then = new String[] {
            "PurchaseAdvice response should show gift to be used to fixedfee."
        };
        td.printDescription();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        BigDecimal discountPrice = BigDecimal.valueOf(2);

        VisibleMultiRequestPurchaseService purchaseInput = new VisibleMultiRequestPurchaseService();
        purchaseInput.setSubscriberExternalId("123");
        VisiblePurchaseInfo vpi = CommonTestHelper.getVisiblePurchaseInfo(
                CI_EXTERNAL_IDS.BASE2ANNUAL);
        vpi.getPurchaseServiceInfo().setServiceDiscountPrice(discountPrice.toPlainString());
        purchaseInput.getPurchaseInfoAppender().add(vpi);

        String annualBaseCi = CI_EXTERNAL_IDS.BASE2ANNUAL;
        String giftGrantCi = CI_EXTERNAL_IDS.GIFT_GRANT;
        BigDecimal giftConsumable = BigDecimal.valueOf(5);
        BigDecimal giftGrant = BigDecimal.valueOf(0);
        BigDecimal giftAmount = giftGrant.add(giftConsumable);
        BigDecimal fixedFee = BigDecimal.valueOf(8);

        ObjectMapper om = TestUtils.getObjectMapper();
        ServiceTaxResponse resp = om.readValue(
                purchaseInput.getAtPurchaseInfo(0).getPurchaseServiceInfo().getServiceTaxDetails(),
                ServiceTaxResponse.class);
        resp.getTransactionElement().get(0).setTotalFeeAmount(fixedFee);
        purchaseInput.getAtPurchaseInfo(0).getPurchaseServiceInfo().setServiceTaxDetails(
                resp.toJson());

        emulateMtxResponsePricingCatalogItem(instance, annualBaseCi);
        emulateMtxResponsePricingCatalogItem(instance, giftGrantCi);

        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();
        subscription.getBalanceArrayAppender().clear();

        MtxTimestamp walletCycleStartDate = TestUtils.getDateTimeOfMidnightToday();

        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);

        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, giftGrantCi, null, giftGrant, giftConsumable);

        MtxBalanceInfo biMainBalance = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.MAIN_BALANCE, 1L, 2L, null);
        subscription.getBalanceArrayAppender().add(biMainBalance);

        MtxResponsePurchase aocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfo(
                annualBaseCi, BALANCE_NAMES.MAIN_BALANCE, discountPrice);
        aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);
        // For Aoc cycle dates will be today to nne year plus
        MtxTimestamp tsNow = CommonUtils.getMtxTimestampTodayZeroHours(
                walletCycleStartDate, subscription.getTimeZone());
        aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(tsNow);
        aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                TestUtils.addOneYear(tsNow));

        List<String> balPriList = Arrays.asList(BALANCE_NAMES.GIFT_GRANT);
        emulateMtxResponseMultiFromObject(
                instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));

        doReturn(aocResp).when(instance).doSubscriberPurchaseOfferAOC(
                any(), eq(annualBaseCi), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        System.out.println(subscription.toJson());
        // method to test
        VisibleResponsePaymentAdviceService aopResp = instance.getPurchaseAdvice(
                null, null, purchaseInput, subscription);

        System.out.println(aopResp.toJson());

        assertEquals(
                giftAmount.compareTo(fixedFee), -1,
                "Dummy Assert to make sure that testcase always has fee higher than gift");
        assertEquals(
                giftAmount.doubleValue(),
                aopResp.getAtCredits(0).getRedeemableCredits().doubleValue(), 0.001,
                "All gift should be used");
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getPurchaseAdvice_When_Subscription_HasLessGiftAsGrant_Then_GiftUsedToPayFixedFee()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber has gift amount.", "Subscribers tax geocode is subject to fixed fee.",
            "Gift amount is less than fixedfee."
        };
        td.when = new String[] {
            "PurchaseAdvice is called. Taxapi provides fixedfee."
        };
        td.then = new String[] {
            "PurchaseAdvice response should show gift to be used to fixedfee."
        };
        td.printDescription();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        BigDecimal discountPrice = BigDecimal.valueOf(2);

        VisibleMultiRequestPurchaseService purchaseInput = new VisibleMultiRequestPurchaseService();
        purchaseInput.setSubscriberExternalId("123");
        VisiblePurchaseInfo vpi = CommonTestHelper.getVisiblePurchaseInfo(
                CI_EXTERNAL_IDS.BASE2ANNUAL);
        vpi.getPurchaseServiceInfo().setServiceDiscountPrice(discountPrice.toPlainString());
        purchaseInput.getPurchaseInfoAppender().add(vpi);

        String annualBaseCi = CI_EXTERNAL_IDS.BASE2ANNUAL;
        String giftGrantCi = CI_EXTERNAL_IDS.GIFT_GRANT;
        BigDecimal giftConsumable = BigDecimal.valueOf(0);
        BigDecimal giftGrant = BigDecimal.valueOf(5);
        BigDecimal giftAmount = giftGrant.add(giftConsumable);
        BigDecimal fixedFee = BigDecimal.valueOf(8);

        ObjectMapper om = TestUtils.getObjectMapper();
        ServiceTaxResponse resp = om.readValue(
                purchaseInput.getAtPurchaseInfo(0).getPurchaseServiceInfo().getServiceTaxDetails(),
                ServiceTaxResponse.class);
        resp.getTransactionElement().get(0).setTotalFeeAmount(fixedFee);
        purchaseInput.getAtPurchaseInfo(0).getPurchaseServiceInfo().setServiceTaxDetails(
                resp.toJson());

        emulateMtxResponsePricingCatalogItem(instance, annualBaseCi);
        emulateMtxResponsePricingCatalogItem(instance, giftGrantCi);

        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();
        subscription.getBalanceArrayAppender().clear();

        MtxTimestamp walletCycleStartDate = TestUtils.getDateTimeOfMidnightToday();

        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);

        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, giftGrantCi, null, giftGrant, giftConsumable);

        MtxBalanceInfo biMainBalance = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.MAIN_BALANCE, 1L, 2L, null);
        subscription.getBalanceArrayAppender().add(biMainBalance);

        MtxResponsePurchase aocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfo(
                annualBaseCi, BALANCE_NAMES.MAIN_BALANCE, discountPrice);
        aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);
        // For Aoc cycle dates will be today to nne year plus
        MtxTimestamp tsNow = CommonUtils.getMtxTimestampTodayZeroHours(
                walletCycleStartDate, subscription.getTimeZone());
        aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(tsNow);
        aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                TestUtils.addOneYear(tsNow));

        List<String> balPriList = Arrays.asList(BALANCE_NAMES.GIFT_GRANT);
        emulateMtxResponseMultiFromObject(
                instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));

        doReturn(aocResp).when(instance).doSubscriberPurchaseOfferAOC(
                any(), eq(annualBaseCi), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        // method to test
        VisibleResponsePaymentAdviceService aopResp = instance.getPurchaseAdvice(
                null, null, purchaseInput, subscription);

        System.out.println(aopResp.toJson());

        assertEquals(
                giftAmount.compareTo(fixedFee), -1,
                "Dummy Assert to make sure that testcase always has fee higher than gift");
        assertEquals(
                giftAmount.doubleValue(),
                aopResp.getAtCredits(0).getRedeemableCredits().doubleValue(), 0.001,
                "All gift should be used");
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getPurchaseAdvice_When_InputHasChannel_Then_AocHasChannel(TestInfo testInfo)
            throws Exception {

        VisibleMultiRequestPurchaseService purchaseInput = CommonTestHelper.loadJsonMessage(
                VisibleMultiRequestPurchaseService.class,
                DATA_DIR.PAYMENT_ADVICE + "VisibleMultiRequestPurchaseService_TwoCI.json");

        String expectedChannel = "ChannelXYZ";
        VisiblePurchasedOfferExtension attr = new VisiblePurchasedOfferExtension();
        attr.setChannel(expectedChannel);
        purchaseInput.getPurchaseInfo().forEach(vpi -> {
            vpi.setAttrData(attr);
        });

        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.INSURANCE);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        BigDecimal mainbalance = new BigDecimal("20.0");
        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(mainbalance);
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        MtxResponsePurchase aocRespService = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_VisibleUnlimited.json");

        MtxResponsePurchase aocRespInsurance = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_VisibleInsurance.json");

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poUnlimited = CommonTestHelper.getMtxPurchasedOfferInfo(
                DATA_DIR.PAYMENT_ADVICE + "VisiblePurchasedOfferInfo_Visible_Unlimited.json");
        subscription.getPurchasedOfferArrayAppender().add(poUnlimited);

        ArgumentCaptor<MtxPurchasedOfferData> argumentCaptor = ArgumentCaptor.forClass(
                MtxPurchasedOfferData.class);

        doReturn(aocRespService).when(instance).doSubscriberPurchaseOfferAOC(
                any(), eq("Visible_Unlimited"), argumentCaptor.capture(), any());
        doReturn(aocRespInsurance).when(instance).doSubscriberPurchaseOfferAOC(
                any(), eq("Visible_Device_Insurance_Bundle_CI"), argumentCaptor.capture(), any());

        emulateMtxResponseSubscription(instance, subscription);
        doReturn(BigDecimal.ZERO).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(CI_EXTERNAL_IDS.PARTY_PAY_REDEEM), any(),
                any(MtxSubscriberSearchData.class));

        // method to test
        VisibleResponsePaymentAdviceService aopResp = instance.getPurchaseAdvice(
                null, null, purchaseInput, subscription);

        System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + aopResp.toJson());

        //@formatter:on
        String serviceChannel = argumentCaptor.getAllValues().stream().filter(
                pod -> pod.getExternalId().equals(CI_EXTERNAL_IDS.UNLIMITED)).map(
                        pod -> ((VisiblePurchasedOfferExtension) pod.getAttr()).getChannel()).findAny().get();
        String insuranceChannel = argumentCaptor.getAllValues().stream().filter(
                pod -> pod.getExternalId().equals(CI_EXTERNAL_IDS.INSURANCE)).map(
                        pod -> ((VisiblePurchasedOfferExtension) pod.getAttr()).getChannel()).findAny().get();

        assertEquals(2, argumentCaptor.getAllValues().size());
        assertEquals(expectedChannel, serviceChannel);
        assertEquals(expectedChannel, insuranceChannel);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getPurchaseAdvice_When_InputHasDuration_Then_AocHasDurationl(TestInfo testInfo)
            throws Exception {

        VisibleMultiRequestPurchaseService purchaseInput = CommonTestHelper.loadJsonMessage(
                VisibleMultiRequestPurchaseService.class,
                DATA_DIR.PAYMENT_ADVICE + "VisibleMultiRequestPurchaseService_TwoCI.json");

        String expectedDuration = "123456";
        VisiblePurchasedOfferExtension attr = new VisiblePurchasedOfferExtension();
        attr.setDuration(expectedDuration);
        purchaseInput.getPurchaseInfo().forEach(vpi -> {
            vpi.setAttrData(attr);
        });

        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.INSURANCE);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        BigDecimal mainbalance = new BigDecimal("20.0");
        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(mainbalance);
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        MtxResponsePurchase aocRespService = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_VisibleUnlimited.json");

        MtxResponsePurchase aocRespInsurance = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_VisibleInsurance.json");

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poUnlimited = CommonTestHelper.getMtxPurchasedOfferInfo(
                DATA_DIR.PAYMENT_ADVICE + "VisiblePurchasedOfferInfo_Visible_Unlimited.json");
        subscription.getPurchasedOfferArrayAppender().add(poUnlimited);

        ArgumentCaptor<MtxPurchasedOfferData> argumentCaptor = ArgumentCaptor.forClass(
                MtxPurchasedOfferData.class);

        doReturn(aocRespService).when(instance).doSubscriberPurchaseOfferAOC(
                any(), eq("Visible_Unlimited"), argumentCaptor.capture(), any());
        doReturn(aocRespInsurance).when(instance).doSubscriberPurchaseOfferAOC(
                any(), eq("Visible_Device_Insurance_Bundle_CI"), argumentCaptor.capture(), any());

        emulateMtxResponseSubscription(instance, subscription);
        doReturn(BigDecimal.ZERO).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(CI_EXTERNAL_IDS.PARTY_PAY_REDEEM), any(),
                any(MtxSubscriberSearchData.class));

        // method to test
        VisibleResponsePaymentAdviceService aopResp = instance.getPurchaseAdvice(
                null, null, purchaseInput, subscription);

        System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + aopResp.toJson());

        //@formatter:on
        String serviceDuration = argumentCaptor.getAllValues().stream().filter(
                pod -> pod.getExternalId().equals(CI_EXTERNAL_IDS.UNLIMITED)).map(
                        pod -> ((VisiblePurchasedOfferExtension) pod.getAttr()).getDuration()).findAny().get();
        String insuranceDuration = argumentCaptor.getAllValues().stream().filter(
                pod -> pod.getExternalId().equals(CI_EXTERNAL_IDS.INSURANCE)).map(
                        pod -> ((VisiblePurchasedOfferExtension) pod.getAttr()).getDuration()).findAny().get();

        assertEquals(2, argumentCaptor.getAllValues().size());
        assertEquals(expectedDuration, serviceDuration);
        assertEquals(expectedDuration, insuranceDuration);
    }

    @Test
    public void test_getPurchaseAdvice_When_PromosNotApplicableToOffer_Then_PromosNotReported()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber has consumables and grants.", "Applicable CI is not being purchased"
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "Percentage promo is ignored."
        };

        td.printDescription();

        String changedCiId = CI_EXTERNAL_IDS.UNLIMITED + "_1";

        VisibleMultiRequestPurchaseService purchaseInput = CommonTestHelper.loadJsonMessage(
                VisibleMultiRequestPurchaseService.class,
                DATA_DIR.PAYMENT_ADVICE + "VisibleMultiRequestPurchaseService_TwoCI.json");
        purchaseInput.getPurchaseInfo().forEach(pi -> {
            if (CI_EXTERNAL_IDS.UNLIMITED.equalsIgnoreCase(
                    pi.getPurchaseServiceInfo().getServiceOfferExternalId())) {
                pi.getPurchaseServiceInfo().setServiceOfferExternalId(changedCiId);
            }
        });

        MtxResponsePricingCatalogItem serviceTemplate = emulateMtxResponsePricingCatalogItem(
                instance,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingCatalogItem_Visible_Unlimited.json",
                changedCiId);
        serviceTemplate.getCatalogItemInfo().setExternalId(changedCiId);

        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.INSURANCE);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        BigDecimal mainbalance = new BigDecimal("20.0");
        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(mainbalance);
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        MtxResponsePurchase aocRespService = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_VisibleUnlimited.json");
        for (MtxPurchaseInfo pi : aocRespService.getPurchaseInfoArray()) {
            for (MtxBalanceImpactInfoGroup biig : pi.getBalanceImpactGroupList()) {
                for (MtxBalanceImpactInfo bii : biig.getBalanceImpactList()) {
                    for (MtxBalanceImpactOfferInfo bioi : bii.getBalanceImpactOfferList()) {
                        bioi.setCatalogItemExternalId(changedCiId);
                    }
                }
            }
        }

        MtxResponsePurchase aocRespInsurance = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_VisibleInsurance.json");

        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();

        doReturn(aocRespService).when(instance).doSubscriberPurchaseOfferAOC(
                any(), eq(changedCiId), any(), any());
        doReturn(aocRespInsurance).when(instance).doSubscriberPurchaseOfferAOC(
                any(), eq(CI_EXTERNAL_IDS.INSURANCE), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        doReturn(BigDecimal.ZERO).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(CI_EXTERNAL_IDS.PARTY_PAY_REDEEM), any(),
                any(MtxSubscriberSearchData.class));

        // method to test
        VisibleResponsePaymentAdviceService aopResp = instance.getPurchaseAdvice(
                null, null, purchaseInput, subscription);
        System.out.println(aopResp.toJson());
        assertNull(aopResp.getCredits());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getPurchaseAdvice_When_PromoTaxBySubtraction_Then_Agnostic_Dpc_Item_Oder(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Active Subscription. PurchaseService called with taxString. Order of dpc items in tax string is different from that of template attributes of promotion."
        };
        td.when = new String[] {
            "Api is called"
        };
        td.then = new String[] {
            "credit tax by subtraction method is correct."
        };
        td.printDescription();

        String serviceOffer = CI_EXTERNAL_IDS.PLUS_CURRENT;
        BigDecimal servicePrice = OFFER_PRICES.PLUS_CURRENT;
        ObjectMapper mapper = CommonUtils.getObjectMapper();

        String taxRespService = CommonTestHelper.getTaxApiResp(serviceOffer);
        ServiceTaxResponse stResponse = mapper.readValue(taxRespService, ServiceTaxResponse.class);
        stResponse.setMsgID("XyzServiceTax");

        // Change order of dpcItems and verify that code still works.
        List<DpcItemTax> xList = new ArrayList<DpcItemTax>();
        for (DpcItemTax dit : stResponse.getTransactionElement().get(0).getDpcGroupList().get(
                0).getDpcItemList()) {
            xList.add(dit);
        }
        stResponse.getTransactionElement().get(0).getDpcGroupList().get(0).getDpcItemList().clear();
        for (int i = xList.size() - 1; i >= 0; i--) {
            stResponse.getTransactionElement().get(0).getDpcGroupList().get(0).getDpcItemList().add(
                    xList.get(i));
        }
        taxRespService = stResponse.toJson();

        String taxRespServiceMinus = CommonTestHelper.getTaxApiResp(serviceOffer, 20);
        ServiceTaxResponse stResponseMinus = mapper.readValue(
                taxRespServiceMinus, ServiceTaxResponse.class);
        stResponse.setMsgID("XyzServiceTaxMinus");
        taxRespServiceMinus = stResponseMinus.toJson();

        Map<String, BigDecimal> mapService = new HashMap<String, BigDecimal>();
        for (DpcGroupTax dgt : stResponse.getTransactionElement().get(0).getDpcGroupList()) {            
            for (DpcItemTax dit : dgt.getDpcItemList()){
                //Rollup Visible_Unlimited_Data_GP2535MP and Visible_Unlimited_Data
                mapService.put(dit.getDpcItem(), CommonUtils.zeroIfNull(mapService.get(dit.getDpcItem())).add(dit.getDpcItemNetRevenue()));
            }                            
        }
        Map<String, BigDecimal> mapServiceMinus = new HashMap<String, BigDecimal>();
        for (DpcGroupTax dgt : stResponseMinus.getTransactionElement().get(0).getDpcGroupList()) {
            for (DpcItemTax dit : dgt.getDpcItemList()){
              //Rollup Visible_Unlimited_Data_GP2535MP and Visible_Unlimited_Data
                mapServiceMinus.put(dit.getDpcItem(), CommonUtils.zeroIfNull(mapServiceMinus.get(dit.getDpcItem())).add(dit.getDpcItemNetRevenue()));
            }            
        }
        
        VisibleMultiRequestPurchaseService purchaseInput = new VisibleMultiRequestPurchaseService();
        purchaseInput.setSubscriberExternalId("123");
        VisiblePurchaseInfo purchaseInfo = CommonTestHelper.getVisiblePurchaseInfo(serviceOffer);
        purchaseInfo.getPurchaseServiceInfo().setServiceTaxDetails(taxRespService);
        purchaseInput.getPurchaseInfoAppender().add(purchaseInfo);

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItem(instance, serviceOffer);
        MtxResponsePricingCatalogItem pciGoodwill = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        VisibleTemplate vtGoodwill = (VisibleTemplate) pciGoodwill.getCatalogItemInfo().getTemplateAttr();
        vtGoodwill.setTaxResponseUnchanged("N");

        List<String> balPriList = Arrays.asList(BALANCE_NAMES.GOODWILL_GRANT);
        emulateMtxResponseMultiFromObject(
                instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));

        BigDecimal mainbalance = new BigDecimal("20.0");
        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(mainbalance);
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        MtxResponsePurchase aocRespService = CommonTestHelper.getMtxResponsePurchase(
                serviceOffer, servicePrice);

        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();
        subscription.getBalanceArrayAppender().clear();
        MtxBalanceInfo mbiGoodwill = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.GOODWILL_GRANT, BigDecimal.valueOf(20));
        subscription.getBalanceArrayAppender().add(mbiGoodwill);

        doReturn(aocRespService).when(instance).doSubscriberPurchaseOfferAOC(
                any(), eq(serviceOffer), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);

        VisibleResponsePaymentAdviceService aopResp = null;

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxRespServiceMinus);
            aopResp = instance.getPurchaseAdvice(null, null, purchaseInput, subscription);

            System.out.println(aopResp.toJson());
        }
        ServiceTaxResponse promoTaxResponse = mapper.readValue(
                aopResp.getCredits().get(0).getTaxDetails(), ServiceTaxResponse.class);        
        
        boolean anyfail = false;
        mapService.forEach((k,v)->{
            System.out.println(k+":"+v);
        });
        for(DpcItemTax diTax:CommonUtils.emptyIfNull(promoTaxResponse.getTransactionElement().get(0).getDpcGroupList().get(
                0).getDpcItemList())) {
            System.out.println("ServiceValue:"+mapService.get(diTax.getDpcItem())+"|ServiceMinusValue:"+mapServiceMinus.get(diTax.getDpcItem())+"|FinalValue:"+diTax.getDpcItemNetRevenue());
            BigDecimal diff = mapService.get(diTax.getDpcItem()).subtract(mapServiceMinus.get(diTax.getDpcItem())); 
            if(diff.subtract(diTax.getDpcItemNetRevenue()).abs().floatValue()>0.01) {
                System.out.println(mapService.get(diTax.getDpcItem()) + "-" + mapServiceMinus.get(diTax.getDpcItem())
                        + "==" + diff);

                System.out.println(mapService.get(diTax.getDpcItem()) + "-" + mapServiceMinus.get(diTax.getDpcItem())
                        + "!=" + diTax.getDpcItemNetRevenue());
                anyfail = true;
            }
            System.out.println("***************************************************");
        }

        if(anyfail) {
            fail("Check console logs");
        }
//        promoTaxResponse.getTransactionElement().get(0).getDpcGroupList().get(
//                0).getDpcItemList().forEach(diTax -> {
//                    assertEquals(
//                            mapService.get(diTax.getDpcItem()).getDpcItemNetRevenue().subtract(
//                                    mapServiceMinus.get(
//                                            diTax.getDpcItem()).getDpcItemNetRevenue()).doubleValue(),
//                            diTax.getDpcItemNetRevenue().doubleValue(), 0.001,
//                            mapService.get(diTax.getDpcItem()).getDpcItemNetRevenue() + "-"
//                                    + mapServiceMinus.get(diTax.getDpcItem()).getDpcItemNetRevenue()
//                                    + "!=" + diTax.getDpcItemNetRevenue());
//                });
    }

    @SuppressWarnings("unchecked")
    @Test
    @Tag("VER-461")
    public void test_getPurchaseAdvice_When_Always_Then_ProvideNextCycleDates(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Active Subscription. PurchaseService called for a service."
        };
        td.when = new String[] {
            "Api is called"
        };
        td.then = new String[] {
            "Api should provide cycle dates to puchase service"
        };

        TwoParameterTest pTests = (svc, expectedLength) -> {
            td.printDescription();

            String serviceOffer = svc.toString();
            BigDecimal servicePrice = CommonTestHelper.getOfferPrice(serviceOffer);
            String taxRespService = CommonTestHelper.getTaxApiResp(serviceOffer);

            VisibleMultiRequestPurchaseService purchaseInput = new VisibleMultiRequestPurchaseService();
            purchaseInput.setSubscriberExternalId("123");
            VisiblePurchaseInfo purchaseInfo = CommonTestHelper.loadJsonMessage(
                    VisiblePurchaseInfo.class,
                    DATA_DIR.PAYMENT_ADVICE + "VisiblePurchaseInfo.json");
            purchaseInfo.getPurchaseServiceInfo().setServiceOfferExternalId(serviceOffer);
            purchaseInfo.getPurchaseServiceInfo().setServiceDiscountPrice(
                    servicePrice.toPlainString());
            purchaseInfo.getPurchaseServiceInfo().setServiceTaxDetails(taxRespService);
            purchaseInput.getPurchaseInfoAppender().add(purchaseInfo);

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
            emulateMtxResponsePricingCatalogItem(instance, serviceOffer);

            BigDecimal mainbalance = new BigDecimal("20.0");
            MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(mainbalance);
            doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

            MtxResponsePurchase aocRespService = CommonTestHelper.getMtxResponsePurchase(
                    serviceOffer, servicePrice);

            MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();
            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            doReturn(aocRespService).when(instance).doSubscriberPurchaseOfferAOC(
                    any(), eq(serviceOffer), any(), any());
            emulateMtxResponseSubscription(instance, subscription);

            VisibleResponsePaymentAdviceService aopResp = null;

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), any())).thenReturn(
                        taxRespService);
                aopResp = instance.getPurchaseAdvice(null, null, purchaseInput, subscription);
            }
            System.out.println(aopResp.toJson());
            assertTrue(
                    StringUtils.isNotBlank(
                            aopResp.getAtVisibleOfferDetailsList(0).getCycleStartTime()));
            VisibleOfferDetails vod = aopResp.getAtVisibleOfferDetailsList(0);
            LocalDate ldStart = LocalDate.parse(
                    vod.getCycleStartTime().substring(0, vod.getCycleStartTime().indexOf("T")));
            LocalDate ldEnd = LocalDate.parse(
                    vod.getCycleEndTime().substring(0, vod.getCycleStartTime().indexOf("T")));
            String cycleLength;
            if (ldStart.plusYears(1).isBefore(ldEnd) || ldStart.plusYears(1).isEqual(ldEnd)) {
                cycleLength = CYCLE_LENGTHS.YEAR;
            } else {
                cycleLength = CYCLE_LENGTHS.MONTH;
            }
            assertEquals(expectedLength.toString(), cycleLength);
        };
        pTests.test(CI_EXTERNAL_IDS.PLUS3VIS23, CYCLE_LENGTHS.MONTH);
        pTests.test(CI_EXTERNAL_IDS.PLUS3ANNUAL, CYCLE_LENGTHS.YEAR);
    }

    @SuppressWarnings("unchecked")
    @Test
    @Tag("VER-597")
    public void test_getPurchaseAdvice_When_CreditsTaxError_Then_ErrorInTaxResponse(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Active Subscription. PurchaseService called for a service."
        };
        td.when = new String[] {
            "Credit tax error"
        };
        td.then = new String[] {
            "Api should provide tax error in tax field"
        };

        TwoParameterTest pTests = (svc, promo) -> {
            td.printDescription();

            String serviceOffer = svc.toString();
            String grantOffer = promo.toString();
            BigDecimal servicePrice = CommonTestHelper.getOfferPrice(serviceOffer);
            String taxRespService = CommonTestHelper.getTaxApiResp(serviceOffer);

            VisibleMultiRequestPurchaseService purchaseInput = new VisibleMultiRequestPurchaseService();
            purchaseInput.setSubscriberExternalId("123");
            VisiblePurchaseInfo purchaseInfo = CommonTestHelper.loadJsonMessage(
                    VisiblePurchaseInfo.class,
                    DATA_DIR.PAYMENT_ADVICE + "VisiblePurchaseInfo.json");
            purchaseInfo.getPurchaseServiceInfo().setServiceOfferExternalId(serviceOffer);
            purchaseInfo.getPurchaseServiceInfo().setServiceDiscountPrice(
                    servicePrice.toPlainString());
            purchaseInfo.getPurchaseServiceInfo().setServiceTaxDetails(taxRespService);
            purchaseInput.getPurchaseInfoAppender().add(purchaseInfo);

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
            emulateMtxResponsePricingCatalogItems(instance, List.of(serviceOffer, grantOffer));

            BigDecimal mainbalance = new BigDecimal("20.0");
            MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(mainbalance);
            doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

            MtxResponsePurchase aocRespService = CommonTestHelper.getMtxResponsePurchase(
                    serviceOffer, servicePrice);

            MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();
            MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                    grantOffer, BigDecimal.valueOf(20));
            subscription.getBalanceArrayAppender().add(mbiGoodGrant);
            MtxBalanceInfo mbiGoodConsump = CommonTestHelper.getMtxBalanceInfoForPromoConsumable(
                    grantOffer, BigDecimal.ZERO);
            subscription.getBalanceArrayAppender().add(mbiGoodConsump);
            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            doReturn(aocRespService).when(instance).doSubscriberPurchaseOfferAOC(
                    any(), eq(serviceOffer), any(), any());
            emulateMtxResponseSubscription(instance, subscription);

            VisibleResponsePaymentAdviceService aopResp = null;
            String creditTaxError = "xyz-TestException-xyz";
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), any())).thenThrow(
                        new TaxApiException(999L, creditTaxError));
                aopResp = instance.getPurchaseAdvice(null, null, purchaseInput, subscription);
            }
            System.out.println(aopResp.toJson());
            assertTrue(
                    aopResp.getAtCredits(0).getTaxDetails().contains(
                            "Error while calling taxapi. Check logs for details"));
        };
        pTests.test(CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.GRANT_GOODWILL);
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_getPurchaseAdvice_When_BadServiceTax_Then_Error")
    @Tag("Tax")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber. Input has bad tax.|"                        
                +"|When  |api called.|"
                +"|Then  |Purchase Advice should return error.|"})
    // @formatter:on    
    public void test_getPurchaseAdvice_When_BadServiceTax_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleMultiRequestPurchaseService purchaseInput = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", List.of(CI_EXTERNAL_IDS.PLUS3VIS23WB));
        purchaseInput.getAtPurchaseInfo(0).getPurchaseServiceInfo().setServiceTaxDetails("xyz");

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.PLUS3VIS23WB);

        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();
        subscription.getBalanceArrayAppender().clear();
        MtxBalanceInfo mbiMainbalance = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.MAIN_BALANCE, BigDecimal.ZERO);
        subscription.getBalanceArrayAppender().add(mbiMainbalance);

        MtxResponsePurchase aocResp = CommonTestHelper.getMtxResponsePurchase(
                CI_EXTERNAL_IDS.PLUS3VIS23WB, OFFER_PRICES.PLUS3VIS23);

        doReturn(aocResp).when(instance).doSubscriberPurchaseOfferAOC(any(), any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);

        // method to test
        VisibleResponsePaymentAdviceService aopResp = instance.getPurchaseAdvice(
                null, null, purchaseInput, subscription);

        System.out.println(aopResp.toJson());
        assertTrue(
                aopResp.getResultText().contains(
                        "Tax String supplied by purchase service is not parseable."));
    }

    @Tag("VER-845")
    @ParameterizedTest(name = "test_getPurchaseAdvice_When_Always_Then_VisibleOfferDetailsInternal")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Active Subscription.|"                
                +"|When |Api is called with multimonth offer. AocResponse has end date.|"
                +"|Then |vod should have end date from aoc response.|"})
    // @formatter:on
    public void test_getPurchaseAdvice_When_Aoc_Has_EndDate_Then_VOD_HasEndDate(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String serviceOffer = CI_EXTERNAL_IDS.PLUS6MONTH25;
        VisibleMultiRequestPurchaseService purchaseInput = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", List.of(serviceOffer));

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItem(instance, serviceOffer);

        BigDecimal mainbalance = new BigDecimal("20.0");
        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(mainbalance);
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        MtxResponsePurchase aocRespService = CommonTestHelper.getMtxResponsePurchase(
                serviceOffer,
                new BigDecimal(
                        purchaseInput.getAtPurchaseInfo(
                                0).getPurchaseServiceInfo().getServiceDiscountPrice()));

        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();
        emulateMtxResponseMultiFromObject(
                instance, CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

        doReturn(aocRespService).when(instance).doSubscriberPurchaseOfferAOC(
                any(), eq(serviceOffer), any(), any());
        emulateMtxResponseSubscription(instance, subscription);

        VisibleResponsePurchaseAdvice aopResp = null;

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), any())).thenReturn("");
            aopResp = instance.getPurchaseAdvice(null, null, purchaseInput, subscription);
        }
        printUnitTest(aopResp.toJson());
        VisibleOfferDetailsInternal vod = aopResp.getVodList().get(0);
        assertEquals(
                aocRespService.getAtPurchaseInfoArray(0).getEndTime().getTime(),
                vod.getPurchaseOfferEndTime().getTime());
    }

    private void printUnitTest(Object msg) {
        System.out.println(testInfo.getDisplayName() + ":" + msg);
    }
}
