package com.matrixx.vag.advice.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.doReturn;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.AbstractMap.SimpleEntry;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import com.matrixx.datacontainer.MtxDate;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.MtxBalanceImpactInfo;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.MtxResponsePricingCatalogItem;
import com.matrixx.datacontainer.mdc.MtxResponsePurchase;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.PurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.SubscriptionResponse;
import com.matrixx.datacontainer.mdc.VisibleOfferDetails;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleRequestChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleResponseChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleTemplate;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.advice.model.CreditStage;
import com.matrixx.vag.advice.model.GlobalCreditStage;
import com.matrixx.vag.advice.model.PromoOfferPair;
import com.matrixx.vag.advice.model.ServiceStage;
import com.matrixx.vag.common.OneParameterTest;
import com.matrixx.vag.common.TestConstants;
import com.matrixx.vag.common.TestUtils;
import com.matrixx.vag.common.Constants.CREDIT_CONSTANTS;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestConstants.DATA_DIR;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.tax.client.TaxApiClient;
import com.matrixx.vag.tax.model.ServiceTaxResponse;
import com.matrixx.vag.util.MDCTest;

public class CsaReversePromoTest extends MDCTest {

    @Spy
    @InjectMocks
    private PaymentAdviceService instance = new PaymentAdviceService();

    @Mock
    private SubscriberManagementApi api;

    @BeforeEach
    public void setUp() throws Exception {
        instance = new PaymentAdviceService();
        MockitoAnnotations.openMocks(this);
        doReturn("").when(instance).getRoute(any());
    }

    @Test
    public void getChangeServiceAdvice_When_CoreMonthly2CoreMonthly_Then_CorrectReverseCredits(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "PaidCycleStartDate is in future.", "Subscriber has CoreMonthly.",
            "Subscriber has 2535."
        };
        td.when = new String[] {
            "ChangeAdvice is called for PlusMonthly offer."
        };
        td.then = new String[] {
            "ChangeAdvice response should show next cycle.",
            "ChangeAdvice response should show correct 253base5 reverse credits."
        };
        td.comments = new String[] {
            "MTXVER2-204, VER-209"
        };
        @SuppressWarnings({
            "unchecked", "rawtypes"
        })
        OneParameterTest pTests = (tc) -> {
            td.printDescription();
            // TestConditions tCase = (TestConditions) tc;
            SimpleEntry tCase = (SimpleEntry) tc;
            String newCi = tCase.getValue().toString();
            String oldCi = tCase.getKey().toString();

            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(newCi);
            request.setDiscountPrice(CommonTestHelper.getOfferPrice(newCi));
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);

            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            Map<String, MtxResponsePricingCatalogItem> pciMap = emulateMtxResponsePricingCatalogItems(
                    instance,
                    List.of(
                            oldCi, request.getNewCatalogItemExternalId(),
                            CI_EXTERNAL_IDS.PLUS_2535_GRANT, CI_EXTERNAL_IDS.BASE_2535_GRANT));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, oldCi);
            MtxDate paidCycleStartDate = new MtxDate("4712-12-31");
            ((VisiblePurchasedOfferExtension) poEnrolled.getAttr()).setPaidCycleStartDate(
                    paidCycleStartDate);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(paidCycleStartDate);

            String oldGrantOffer = CI_EXTERNAL_IDS.BASE_CURRENT.equalsIgnoreCase(oldCi)
                    ? CI_EXTERNAL_IDS.BASE_2535_GRANT : CI_EXTERNAL_IDS.PLUS_2535_GRANT;
            CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldGrantOffer, BigDecimal.valueOf(5000), BigDecimal.valueOf(5000),
                    BigDecimal.ZERO);

            List<String> grantBalances = new ArrayList();
            subscription.getBalanceArray().forEach(mbi -> {
                if ("Credits".equalsIgnoreCase(mbi.getClassName())) {
                    grantBalances.add(mbi.getName());
                }
            });
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(grantBalances));

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    oldCi, paidCycleStartDate);

            ServiceStage ss = new ServiceStage(oldCi);
            VisibleTemplate vt2535 = (VisibleTemplate) pciMap.get(
                    oldGrantOffer).getCatalogItemInfo().getTemplateAttr();

            GlobalCreditStage gcs2535 = new GlobalCreditStage(oldGrantOffer, vt2535);
            gcs2535.setPromotionName(vt2535.getPromotionName());
            gcs2535.setAvailableCredits(BigDecimal.valueOf(5000));
            gcs2535.setAvailableCreditsConsumable(vt2535.getPromotionLimit());
            gcs2535.setAvailableCreditsGrant(BigDecimal.valueOf(5000));
            gcs2535.setRedeemOfferCi(vt2535.getRedeemOffer());
            gcs2535.setApplicableCiCsv(oldCi);
            gcs2535.getApplicableCiOrderMap().put(oldCi, 2L);

            CreditStage cs2535 = new CreditStage(gcs2535, oldCi);
            cs2535.setApplicableServiceStage(ss);
            cs2535.setRedeemableCredits(vt2535.getPromotionLimit());
            cs2535.setEstimatedTransferableCredits(BigDecimal.ZERO);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscription, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.getCreditMap().put(
                    new PromoOfferPair(oldCi, vt2535.getPromotionName()), cs2535);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                // if (CI_EXTERNAL_IDS.PLUS2VIS22.equalsIgnoreCase(oldCi)
                // && CI_EXTERNAL_IDS.BASE2VIS22.equalsIgnoreCase(newCi)) {
                // Since new Ci starts next cycle there will be no prorated charge. TaxApi gets
                // called only once.
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespNextCycle.toJson());

                // } else {
                // mockedStatic.when(
                // () -> TaxApiClient.getTaxApiResult(
                // any(), anyString())).thenReturn(
                // taxRespChangeCycle.toJson()).thenReturn(
                // taxRespNextCycle.toJson());
                // }
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertEquals(
                    1, response.getNextCycle().getReverseCredits().size(),
                    "When there is consumable balance, There should be a reversible credit. ");
            assertEquals(
                    vt2535.getPromotionName(),
                    response.getNextCycle().getAtReverseCredits(0).getPromotionName());
            assertEquals(
                    vt2535.getRedeemOffer(),
                    response.getNextCycle().getAtReverseCredits(0).getRedeemableOfferCI());
            assertEquals(
                    vt2535.getPromotionLimit(),
                    response.getNextCycle().getAtReverseCredits(0).getAvailableCreditsConsumable());
        };

        // PlusMonthly2BaseMonthly
        SimpleEntry<String, String> change1 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.PLUS_CURRENT,
                TestConstants.CI_EXTERNAL_IDS.BASE_CURRENT);
        pTests.test(change1);
        // BaseMonthly2PlusMonthly
        SimpleEntry<String, String> change2 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.BASE_CURRENT,
                TestConstants.CI_EXTERNAL_IDS.PLUS_CURRENT);
        pTests.test(change2);
    }

}
