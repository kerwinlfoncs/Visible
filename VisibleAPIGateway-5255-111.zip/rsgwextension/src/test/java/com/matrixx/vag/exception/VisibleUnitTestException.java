package com.matrixx.vag.exception;

public class VisibleUnitTestException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1096586610025639572L;

	public VisibleUnitTestException(Throwable cause) {
        super(cause);
    }
}
