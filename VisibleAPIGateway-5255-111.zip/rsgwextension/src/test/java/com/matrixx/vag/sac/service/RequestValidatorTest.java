package com.matrixx.vag.sac.service;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;

import com.matrixx.datacontainer.mdc.VisibleRequestCaLink;
import com.matrixx.datacontainer.mdc.VisibleRequestCaUnlink;
import com.matrixx.datacontainer.mdc.VisibleRequestChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleRequestSacSetUpPayment;
import com.matrixx.platform.JsonObject;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.exception.InvalidRequestException;
import com.matrixx.vag.exception.MissingRequestParametersException;
import com.matrixx.vag.util.MDCTest;

public class RequestValidatorTest extends MDCTest {

    private RequestValidator instance;
    private TestInfo testInfo;
    
    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        instance = new RequestValidator();
        this.testInfo = testInfo;
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_validateRequest_MissingFieldsInSacSetUpPaymentRequest_Exception()
            throws IOException {
        ArrayList<String> testFields = new ArrayList<String>(
                Arrays.asList(
                        "SubscriberExternalId", //
                        "Nonce"));

        String msgInput = new String(
                Files.readAllBytes(
                        Paths.get(
                                "src/test/resources/data/sacService/VisibleRequestSacSetUpPayment_Default_Y.json")));
        for (String removeField : testFields) {
            Exception respException = null;
            try {
            	VisibleRequestSacSetUpPayment sacPayRequest = CommonTestHelper.parseJsonMessage(VisibleRequestSacSetUpPayment.class, remove_From_VisibleRequestSacSetUpPayment(msgInput, removeField));
                instance.validateRequest("", sacPayRequest);
            } catch (Exception e) {
                respException = e;
            }
            assertEquals(MissingRequestParametersException.class, respException.getClass());
        }
    }

    @ParameterizedTest(name="test_validateRequest_CaLink_When_NoBeneficiaryId_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |NA.|"
                +"|Whe n |No BeneficiaryId in request.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    @Tag("CA")@Tag("VER-795")
    public void test_validateRequest_CaLink_When_NoBeneficiaryId_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();

        VisibleRequestCaLink request = new VisibleRequestCaLink();
        request.setPayerExternalId("1234");

        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequest("", request) );
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
    }

    @ParameterizedTest(name="test_validateRequest_CaLink_When_NoPayerId_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |NA.|"
                +"|When  |No PayerId in request.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    @Tag("CA")@Tag("VER-795")
    public void test_validateRequest_CaLink_When_NoPayerId_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();

        VisibleRequestCaLink request = new VisibleRequestCaLink();
        request.setBeneficiaryExternalId("4567");

        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequest("", request) );
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
    }

    @ParameterizedTest(name="test_validateRequest_CaLink_When_BaneficiarySameAsPayer_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |NA.|"
                +"|When  |BeneficiaryId == PayerId in request.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    @Tag("CA")@Tag("VER-795")
    public void test_validateRequest_CaLink_When_BaneficiarySameAsPayer_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();

        VisibleRequestCaLink request = new VisibleRequestCaLink();
        request.setBeneficiaryExternalId("4567");
        request.setPayerExternalId("4567");
        
        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequest("", request) );
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
    }

    @ParameterizedTest(name="test_validateRequest_CaUnlink_When_NoBeneficiaryId_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |NA.|"
                +"|Whenn |No BeneficiaryId in request.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    @Tag("CA")@Tag("VER-795")
    public void test_validateRequest_CaUnlink_When_NoBeneficiaryId_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo,acceptance);
        td.printDescription();

        VisibleRequestCaUnlink request = new VisibleRequestCaUnlink();        

        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequest("", request) );
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
    }

    
    private String remove_From_VisibleRequestSacSetUpPayment(String messageText,
                                                             String feildToRemove) {

        JsonObject jsonInput = new JsonObject();
        jsonInput.parse(messageText);
        switch (feildToRemove) {
            case "SubscriberExternalId":
            case "Nonce":
                jsonInput.remove(feildToRemove);
                break;

            default:
                break;
        }

        return jsonInput.toString();
    }

}
