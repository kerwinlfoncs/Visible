package com.matrixx.vag.common;

import java.math.BigDecimal;
import java.util.List;

public final class TestConstants {

    public static final class DATE_TIME_CONSTANTS {

        public static final long MILLISECONDS_IN_A_DAY = 86400000;
    }

    public static final class PURCHASE_SERVICE_TYPES {

        public static final String NIB_TO_CORE_MIGRATION = "N2CMigration";
        public static final String MID_CYCLE_CHANGE = "MCUpgrade";
        public static final String MID_CYCLE_ADDON = "MCAddon";
    }

    public static final class CI_EXTERNAL_IDS {

        //Grandfathered
        public static final String UNLIMITED = "Visible_Unlimited";
        public static final String BASE2VIS22 = "BASE2VISIBLE22";
        public static final String BASE2ANNUAL = "BASE2VISANNUAL22";
        public static final String PLUS2VIS22 = "PLUS2VIS22WB";
        public static final String PLUS2ANNUAL = "PLUS2VISANNUAL22";
        public static final String PLUS3VIS23 = "PLUS3VIS23WB";
        public static final String PLUS3VIS23WB = "PLUS3VIS23WB";
        public static final String PLUS3ANNUAL = "PLUS3VIS23WBA";
        public static final String WEARABLE = "CDVISIBLE2022";
        public static final String PARTY_PAY_GRANT = "Visible_Group_Grant";
        public static final String PARTY_PAY_REDEEM = "Visible_Redeem_Group_Discount";
        public static final String CHIME_AOC_GRANT = "Visible_CHIME_AOC_CI";
        public static final String CHIME_AOC_REDEEM = "Visible_Redeem_Chime_AOC_Discount";
        public static final String VBPP25_AOC_REDEEM = "Visible_Redeem_VBPP_Discount";
        public static final String VBPP25_AOC_GRANT = "Visible_VBPP25_AOC_Grant";
        public static final String VBPP5_AOC_GRANT = "Visible_VBPP5_AOC_Grant";
        public static final String VBPP5_AOC_REDEEM = "Visible_Redeem_VBPP5_Discount";
        public static final String VBPP_CORE_REDEEM = "Visible_VBPP-CORE_Redeem";
        public static final String REF_REDEEM = "Visible_Redeem_Referral_Credits";
        public static final String REF35_GRANT = "Visible_REF35_Grant";
        public static final String REF35_REDEEM = "Visible_REF35_Redeem";
        
        //In Market
        public static final String BASE3VIS23 = "BASE3VISIBLE23";
        public static final String BASE6MONTH25 = "BASE6VISIBLE25";
        public static final String BASE3ANNUAL = "BASE3VISIBLE23A";

        public static final String PLUS25 = "PLUS4VIS25WB";
        public static final String PLUS6MONTH25 = "PLUS6VIS25WB";
        public static final String PLUS25ANNUAL = "PLUS4VIS25WBA";

        public static final String PRO25 = "PPLUS1VIS25WB";
        public static final String PRO6MONTH25 = "PPLUS6VIS25WB";
        public static final String PRO25ANNUAL = "PPLUS1VIS25WBA";

        public static final String PRO_CURRENT = PRO25;
        public static final String PLUS_CURRENT = PLUS25;
        public static final String BASE_CURRENT = BASE3VIS23;
        
        public static final String SETUP_SERVICES = "Setup_Services";

        public static final String WEARABLE_MONTHLY_2023 = "CD3VISIBLE2023";
        public static final String WEARABLE_ANNUAL_2023 = "CD2VISIBLE2023A";
        public static final String FREE_WEARABLE_MONTHLY_ACTIVATION = "CD2VISIBLE2023";
        public static final String INSURANCE = "Visible_Device_Insurance_Bundle_CI";
        public static final String WEARABLE_INSURANCE = "Visible_Wearable_Insurance_CI";
        public static final String TRIAL22 = "VISIBLETRIAL22";

        public static final String UNLIMITED_VOICE = "Visible_Unlimited_Voice";
        public static final String UNLIMITED_DATA = "Visible_Unlimited_Data";
        public static final String UNLIMITED_TEXT = "Visible_Unlimited_Text";
        public static final String UNLIMITED_MMS = "Visible_Unlimited_MMS";

        public static final String UNLIMITED_VOICE_ANNUAL = "Visible_Unlimited_Voice_MM";
        public static final String UNLIMITED_DATA_ANNUAL = "Visible_Unlimited_Data_MM";
        public static final String UNLIMITED_TEXT_ANNUAL = "Visible_Unlimited_Text_MM";
        public static final String UNLIMITED_MMS_ANNUAL = "Visible_Unlimited_MMS_MM";
        
        public static final String DEVICE_INSURANCE = "Visible_Device_Insurance_Offer";

        public static final String SETUP_VOICE = "Setup Voice";
        public static final String SETUP_DATA = "Setup Data";
        public static final String SETUP_TEXT = "Setup Text";
        public static final String SETUP_MMS = "Setup MMS";

        public static final String MULTIMONTH_COUNTER = "Visible_MulitMonth_Counter";
        public static final String WEARABLE_FREE = "Visible_Wearable_Offer_Free";
        public static final String FREEGP_HI = "Visible_Free_GP_VHigh_A";
        public static final String TRAVEL_FREE = "Visible_TravelPass_Free";
        public static final String PBLINK = "PBLinkCI";
        
        public static final String UPDATE_SERVICE_PAYMENTS = "Visible_Update_Service_Payments";
        public static final String MEMBERSHIP = "Visible_Membership";

        public static final String CA5_GRANT = "Visible_CA5_Grant";
        public static final String CA5_REDEEM = "Visible_CA5_Redeem";

        public static final String BONUS_MONEY_REDEEM = "Visible_BonusMoney_Redeem";

        public static final String GRANT_GOODWILL = "Visible_Grant_Goodwill_Credits";
        public static final String GOODWILL_REDEEM = "Visible_Redeem_Goodwill_Credits";
        public static final String REF20_GRANT = "Visible_REF20_Grant";
        public static final String REF20_REDEEM = "Visible_REF20_Redeem";

        public static final String FIRST25_GRANT = "Visible_FIRST25_Grant";
        public static final String FIRST25_REDEEM = "Visible_FIRST25_Redeem";
        public static final String GIFT_GRANT = "Visible_AnnualPlanGift_Grant";
        public static final String GIFT_REDEEM = "Visible_AnnualPlanGift_Redeem";
        public static final String AMAZON_REDEEM = "Visible_Redeem_Amazon_PrePay_Discount";
        public static final String THIRTY_FOR_TWO_GRANT = "Visible_30FOR2_Grant";
        public static final String THIRTY_FOR_TWO_REDEEM = "Visible_30FOR2_Redeem";
        public static final String PLUS_2535_GRANT = "Visible_2535PLUS_Grant";
        public static final String PLUS_2535_REDEEM = "Visible_2535PLUS_Redeem";
        public static final String BASE_2535_GRANT = "Visible_2535BASE_Grant";
        public static final String BASE_2535_REDEEM = "Visible_2535BASE_Redeem";
        public static final String FIFTEEN_OFFN_GRANT = "Visible_15OFFN_Grant";
        public static final String FIFTEEN_OFFN_REDEEM = "Visible_15OFFN_Redeem";
        public static final String GENERIC_GRANT = "Visible_GENRICPROMO_Grant";
        public static final String GENERIC_REDEEM = "Visible_GENRICPROMO_Redeem";

        public static final String AOC_CORE_ONLY = VBPP5_AOC_GRANT + "," + CHIME_AOC_GRANT;
        public static final String AOC_NIB_CORE = AOC_CORE_ONLY + "," + PARTY_PAY_GRANT + ","
                + VBPP25_AOC_GRANT;

        public static final List<String> BASE_LIST = List.of(
                TRIAL22, UNLIMITED, BASE2VIS22, BASE3VIS23, PLUS2VIS22, PLUS3VIS23, BASE2ANNUAL,
                BASE3ANNUAL, PLUS2ANNUAL, PLUS3ANNUAL, PLUS25, PLUS25ANNUAL, PRO25,
                PRO25ANNUAL);
        public static final List<String> ADDON_LIST = List.of(
                WEARABLE, WEARABLE_MONTHLY_2023, WEARABLE_ANNUAL_2023,
                FREE_WEARABLE_MONTHLY_ACTIVATION);
        public static final List<String> INSURANCE_LIST = List.of(INSURANCE);
    }

    public static final class BALANCE_NAMES {

        public static final String MAIN_BALANCE = "Mainbalance";
        public static final String LONGEVITY_COUNTER = "Visible_Longevity_Counter";
        public static final String COUNTER_MULTIMONTH = "Visible_MultiMonth_Counter";
        public static final String COUNTER_FREE_TP = "Visible_FreeTP_Counter";

        public static final String REFFERAL_GRANT = "Referral_Credits";
        public static final String REFFERAL_CONSUMABLE = "Referral_Credits_Consumable";
        public static final String GROUP_CONSUMABLE = "Group_Discount_Consumable";
        public static final String GOODWILL_GRANT = "Goodwill_Credits_Grant";
        public static final String GOODWILL_CONSUMABLE = "Goodwill_Credits_Consumable";
        public static final String FIRST25_GRANT = "Promo_Discount_Grant";
        public static final String FIRST25_CONSUMABLE = "Promo_Discount_Consumable";
        public static final String REF35_GRANT = "Referral_Credits2_Grant";
        public static final String REF35_CONSUMABLE = "Referral_Credits2_Consumable";
        public static final String REF20_GRANT = "REF20_Grant";
        public static final String REF20_CONSUMABLE = "REF20_Consumable";
        public static final String THIRTY_FOR_TWO_GRANT = "PROMO7_Grant";
        public static final String THIRTY_FOR_TWO_CONSUMABLE = "PROMO7_Consumable";
        public static final String AMZN_GRANT = "Visible_Redeem_Amazon_PrePay_Discount";
        public static final String GIFT_GRANT = "AnnualPlanGift_Grant";
        public static final String GIFT_CONSUMABLE = "AnnualPlanGift_Consumable";
        public static final String PLUS2535_GRANT = "2535PLUS_Grant";
        public static final String PLUS2535_CONSUMABLE = "2535PLUS_Consumable";
        public static final String BASE2535_GRANT = "2535BASE_Grant";
        public static final String BASE2535_CONSUMABLE = "2535BASE_Consumable";
        public static final String FIFTEEN_OFFN_GRANT = "15OFFN_Grant";
        public static final String FIFTEEN_OFFN_CONSUMABLE = "15OFFN_Consumable";
        
        public static final String GENERIC_GRANT = "GENRICPROMO_Grant";
        public static final String GENERIC_CONSUMABLE = "GENRICPROMO_Consumable";
        public static final String VBPP_CORE_CONSUMABLE = "VBPP-CORE_Consumable";
        public static final String CA5_GRANT = "CA5_Grant";
        public static final String CA5_CONSUMABLE = "CA5_Consumable";
        
        public static final String GLOBAL_PASS = "Free_GP_Count";
        public static final String GP_GL = "GPGLBalance";        
    }

    public static final class BALANCE_IDS {
        public static final long MAIN_BALANCE = 1;
    }
    
    public static final class DATA_DIR {

        public static final String PAYMENT_ADVICE = "src/test/resources/data/aop/";
        public static final String QUOTE_ADVICE = "src/test/resources/data/quoteadvice/";
        public static final String PURCHASE_SERVICE = "src/test/resources/data/purchaseservice/";
        public static final String REFUND_SERVICE = "src/test/resources/data/refundservice/";
        public static final String FINANCED_DEVICE = "src/test/resources/data/purchasefinance/";
        public static final String PURCHASED_DEVICE = "src/test/resources/data/purchasedevice/";
        public static final String RETURN_FINANCED_DEVICE = "src/test/resources/data/returnfinance/";
        public static final String RETURN_PURCHASED_DEVICE = "src/test/resources/data/returndevice/";
        public static final String CHARGE_NRF = "src/test/resources/data/chargenrf/";
        public static final String CANCEL_SWAP = "src/test/resources/data/canceldeviceswap/";
        public static final String DEVICE_SWAP = "src/test/resources/data/purchasedeviceswap/";
        public static final String REVERSE_NRF = "src/test/resources/data/reversenrf/";
        public static final String SUBSCRIBER_SERVICE = "src/test/resources/data/subscriberService/";
        public static final String SAC = "src/test/resources/data/sacService/";
        public static final String MULTIPURCHASE_SERVICE = "src/test/resources/data/purchaseservicemulti/";
        public static final String COMMON = "src/test/resources/data/common/";
        public static final String MANUAL_PAY = "src/test/resources/data/manualpay/";
        public static final String CHANGE_SERVICE_ADVICE = "src/test/resources/data/changeserviceadvice/";
        public static final String CHANGE_SERVICE = "src/test/resources/data/changeservice/";
        public static final String AUTOPAY = "src/test/resources/data/autopay/";
        public static final String VISIBLEAPIGATEWAY = "../";
        public static final String GIFT_SERVICE = "src/test/resources/data/giftservice/";
        public static final String ONSHORE = "src/test/resources/data/onshore/";
    }

    public static final class OFFER_PRICES {

        //Grandfathered
        public final static BigDecimal UNLIMITED = BigDecimal.valueOf(40);
        public final static BigDecimal BASE2VIS22 = BigDecimal.valueOf(30);
        public final static BigDecimal BASE2ANNUAL = BigDecimal.valueOf(300);
        public final static BigDecimal PLUS2VIS22 = BigDecimal.valueOf(45);
        public final static BigDecimal PLUS2ANNUAL = BigDecimal.valueOf(450);
        public final static BigDecimal PLUS3VIS23 = BigDecimal.valueOf(45);        
        public final static BigDecimal PLUS3ANNUAL = BigDecimal.valueOf(395);

        //InMarket
        public final static BigDecimal BASE3VIS23 = BigDecimal.valueOf(25);
        public final static BigDecimal BASE6MONTH25 = BigDecimal.valueOf(125);
        public final static BigDecimal BASE3ANNUAL = BigDecimal.valueOf(275);

        public final static BigDecimal PLUS25 = BigDecimal.valueOf(35);
        public final static BigDecimal PLUS6MONTH25 = BigDecimal.valueOf(190);
        public final static BigDecimal PLUS25ANNUAL = BigDecimal.valueOf(375);

        public final static BigDecimal PRO25 = BigDecimal.valueOf(45);
        public final static BigDecimal PRO6MONTH25 = BigDecimal.valueOf(225);
        public final static BigDecimal PRO25ANNUAL = BigDecimal.valueOf(450);

        public static final BigDecimal PRO_CURRENT = PRO25;
        public static final BigDecimal PLUS_CURRENT = PLUS25;
        public static final BigDecimal BASE_CURRENT = BASE3VIS23;

        public final static BigDecimal TRIAL22 = BigDecimal.ZERO;
        public final static BigDecimal INSURANCE = BigDecimal.valueOf(10);
        public final static BigDecimal WEARABLE_INSURANCE = BigDecimal.valueOf(7);
        public final static BigDecimal WEARABLE = BigDecimal.valueOf(5);
        public final static BigDecimal WEARABLE_MONTHLY_2023 = BigDecimal.valueOf(10);
        public final static BigDecimal FREE_WEARABLE_MONTHLY_ACTIVATION = BigDecimal.ZERO;
    }

    public static final class OFFER_STATUS {

        public static final String ACTIVE = "active";
        public static final String CANCELLATION = "in_cancellation";
        public static final String INACTIVE = "inactive";
        public static final String SUSPENDED = "suspended";
        public static final String GRACE = "grace";
        public static final String RECOVERABLE = "recoverable";
        public static final String PREACTIVE = "pre_active";
        public static final String SUSPENDED_PREACTIVE = "suspended_pre_active";
    }

    public static final class OFFER_STATUS_INTEGER {

        public static final Integer ACTIVE = 1;
        public static final Integer CANCELLATION = 2;
        public static final Integer INACTIVE = 3;
        public static final Integer SUSPENDED = 4;
        public static final Integer GRACE = 6;
        public static final Integer RECOVERABLE = 7;
        public static final Integer PREACTIVE = 5;
        public static final Integer SUSPENDED_PREACTIVE = 10;
    }

    public static final class SUBSCRIPTION_STATUS_INTEGER {

        public static final Integer ACTIVE = 1;
        public static final Integer TERMINATED = 2;
        public static final Integer LAPSE = 3;
        public static final Integer PREACTIVE = 4;
        public static final Integer PAUSE = 5;
        public static final Integer REGISTERED = 6;
        public static final Integer SUSPENDED = 7;
        public static final Integer ANNUAL_ACTIVE = 8;
        public static final Integer ANNUAL_SUSPEND = 9;
        public static final Integer ANNUAL_ACTIVE_SUSPEND = 10;
    }

    public static final class TAX_CLASS_CODES {

        public static final String SERVICE = "SVC";
        public static final String WEARABLE = "SVC-W";
        public static final String INSURANCE = "FEA";

        public static final String PARTY_PAY = "GRPD-CR";
        public static final String REFERRAL = "REF-CR";
        public static final String REF35 = "REF-35";
        public static final String REF20 = "REF-20";
        public static final String GOODWILL = "GOOD-CR";
        public static final String PLUS2535 = "2535PLUS";
        public static final String BASE2535 = "2535BASE";
        public static final String GENRIC = "GENRICPROMO";
        public static final String VBPPCORE = "VBPP-CORE";
        public static final String CA5 = "CA5";
    }

    public static final class TAX_PLAN_IDS {

        public static final String UNLIMITED = "BASE001A";
        public static final String WEARABLE = "WEAR001";
        public static final String INSURANCE = "INS+ESC_WARNTY-TIER_1-10";
    }

    public static final class CI_BUNDLES {

        public static final String PLUS3VIS23 = CI_EXTERNAL_IDS.UNLIMITED_VOICE + ","
                + CI_EXTERNAL_IDS.UNLIMITED_DATA + "," + CI_EXTERNAL_IDS.UNLIMITED_TEXT + ","
                + CI_EXTERNAL_IDS.UNLIMITED_MMS + "," + CI_EXTERNAL_IDS.WEARABLE_FREE + ","
                + CI_EXTERNAL_IDS.TRAVEL_FREE;
        public static final String BASE3VIS23 = CI_EXTERNAL_IDS.UNLIMITED_VOICE + ","
                + CI_EXTERNAL_IDS.UNLIMITED_DATA + "," + CI_EXTERNAL_IDS.UNLIMITED_TEXT + ","
                + CI_EXTERNAL_IDS.UNLIMITED_MMS;
        public static final String UNLIMITED = CI_EXTERNAL_IDS.UNLIMITED_VOICE + ","
                + CI_EXTERNAL_IDS.UNLIMITED_DATA + "," + CI_EXTERNAL_IDS.UNLIMITED_TEXT + ","
                + CI_EXTERNAL_IDS.UNLIMITED_MMS;
        public static final String SETUP_SERVICES = CI_EXTERNAL_IDS.SETUP_VOICE + ","
                + CI_EXTERNAL_IDS.SETUP_DATA + "," + CI_EXTERNAL_IDS.SETUP_TEXT + ","
                + CI_EXTERNAL_IDS.SETUP_MMS;
    }

}
