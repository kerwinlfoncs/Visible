package com.matrixx.vag.common;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.CALLS_REAL_METHODS;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.mdc.MtxBillingCycleInfo;
import com.matrixx.datacontainer.mdc.MtxResponse;
import com.matrixx.datacontainer.mdc.SubscriptionResponse;
import com.matrixx.platform.JsonObject;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.common.Constants.CYCLE_PERIODS;
import com.matrixx.vag.common.Constants.DATE_POLICY;
import com.matrixx.vag.common.Constants.MATRIXX_CONSTANTS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.exception.IntegrationServiceException;
import com.matrixx.vag.exception.PaymentAdviceException;
import com.matrixx.vag.util.MDCTest;

public class CommonUtilsTest extends MDCTest {

    private static final Logger m_logger = LoggerFactory.getLogger(CommonUtilsTest.class);

    private TestInfo testInfo;

    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        this.testInfo = testInfo;
    }

    @Test
    public void getReversalInfoTest() {
        Set<String> eventIds = new HashSet<String>();

        String result = CommonUtils.getReversalDetails(null);
        assertNull(result);
        result = CommonUtils.getReversalDetails(eventIds);
        assertNull(result);

        eventIds.add("GUW0:1:52:2795");
        result = CommonUtils.getReversalDetails(eventIds);
        assertTrue(result.startsWith(CommonUtils.REVERSAL_PREFIX));
        for (String eventId : eventIds) {
            assertTrue(result.indexOf(eventId) > 0);
        }

        eventIds.add("GUW0:1:52:1");
        eventIds.add("GUW0:1:52:22");
        eventIds.add("GUW0:1:52:333");
        eventIds.add("GUW0:1:52:4444");
        eventIds.add("GUW0:1:52:55555");
        result = CommonUtils.getReversalDetails(eventIds);
        assertTrue(result.startsWith(CommonUtils.REVERSAL_PREFIX));
        for (String eventId : eventIds) {
            assertTrue(result.indexOf(eventId) > 0);
        }
    }

    @Test
    public void getPartialReversalInfoTest() {
        Set<String> eventIds = new HashSet<String>();

        String result = CommonUtils.getPartialReversalPrefixDetails(null);
        assertNull(result);
        result = CommonUtils.getPartialReversalPrefixDetails(eventIds);
        assertNull(result);

        eventIds.add("GUW0:1:52:2795");
        result = CommonUtils.getPartialReversalPrefixDetails(eventIds);
        assertTrue(result.startsWith(CommonUtils.PARTIAL_REVERSAL_PREFIX));
        for (String eventId : eventIds) {
            assertTrue(result.indexOf(eventId) > 0);
        }

        eventIds.add("GUW0:1:52:1");
        eventIds.add("GUW0:1:52:22");
        eventIds.add("GUW0:1:52:333");
        eventIds.add("GUW0:1:52:4444");
        eventIds.add("GUW0:1:52:55555");
        result = CommonUtils.getPartialReversalPrefixDetails(eventIds);
        assertTrue(result.startsWith(CommonUtils.PARTIAL_REVERSAL_PREFIX));
        for (String eventId : eventIds) {
            assertTrue(result.indexOf(eventId) > 0);
        }
    }

    @Test
    public void checkIfNonZeroTest() {
        BigDecimal[] ZEROS = {
            new BigDecimal("0"), new BigDecimal("0.0"), new BigDecimal("0.00"),
            new BigDecimal("00"), BigDecimal.ZERO
        };

        assertTrue(CommonUtils.checkIfNonZero(new BigDecimal("1")));
        assertTrue(CommonUtils.checkIfNonZero(new BigDecimal("100")));
        assertFalse(CommonUtils.checkIfNonZero(null));
        for (BigDecimal value : ZEROS) {
            assertFalse(CommonUtils.checkIfNonZero(value));
        }
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_validateResponse_MessageExceptionServicePassed_ExceptionThrown(TestInfo testInfo)
            throws IntegrationServiceException, NoSuchMethodException, SecurityException,
            InstantiationException, IllegalAccessException, IllegalArgumentException,
            InvocationTargetException {
        MtxResponse mr = new MtxResponse();
        mr.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
        mr.setResultText("test text");
        Exception exception = assertThrows(
                PaymentAdviceException.class,
                () -> CommonUtils.validateResponse(
                        "testLoggingKey", "testExceptionMessage", m_logger,
                        PaymentAdviceException.class, mr));
        System.out.println(testInfo.getDisplayName() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().contains("testExceptionMessage"));
        assertTrue(exception.getMessage().contains(mr.getResultText()));
    }

    @Test
    public void remove_UnusedFields_Test() throws IOException {
        String messageText = new String(
                Files.readAllBytes(
                        Paths.get("src/test/resources/data/misc/ManualPayRequest.json")));
        JsonObject jsonInput = new JsonObject();
        jsonInput.parse(messageText);
        System.out.println(CommonTestHelper.remove_UnusedFields(jsonInput));
    }

    @Test
    @Tag("VER-225")
    @Tag("MTXVER2TMA-4486")
    public void test_getDaysRemainingInCycle_WhenEndTimeWithZone_ThenCorrectNumberOfDays() {
        MtxTimestamp refTime = new MtxTimestamp("2023-11-23T13:46:48.000000+11:00");
        int expectedDays = 25;
        long reduceLastDayByMilli = 3 * 1000;
        long curMillis = System.currentTimeMillis();
        long moreMillis = 1000L * 60 * 60 * 24 * expectedDays - reduceLastDayByMilli;

        MtxTimestamp endTime = MtxTimestamp.ofEpochMilli(curMillis + moreMillis, refTime);

        int remainingDays = CommonUtils.getDaysRemainingInCycle(endTime, "Australia/Melbourne");
        assertEquals(expectedDays, remainingDays);
    }

    @Test
    @Tag("VER-225")
    @Tag("MTXVER2TMA-4486")
    public void test_getDaysRemainingInCycle_WhenEndTimeWithZone_ThenCorrectNumberOfDays_1() {
        // These numbers were taken from Smitha's test case that had failed
        MtxTimestamp endTime = new MtxTimestamp("2023-11-23T13:46:48.000000+11:00");
        MtxTimestamp curTime = new MtxTimestamp("2023-10-24T13:46:51.55993+11:00");

        System.out.println("curTime: " + curTime);
        System.out.println("endTime: " + endTime);

        Instant instant = Instant.ofEpochMilli(curTime.longValue());
        ZonedDateTime zCurTime = ZonedDateTime.ofInstant(instant, ZoneId.of("Australia/Melbourne"));
        int remainingDays = 1;
        int expectedRemainingDays = 30;
        try (MockedStatic<CommonUtils> mockedStatic = Mockito.mockStatic(
                CommonUtils.class, CALLS_REAL_METHODS)) {
            mockedStatic.when(() -> CommonUtils.getZonedDateTimeNow(isA(ZoneId.class))).thenReturn(
                    zCurTime);
            remainingDays = CommonUtils.getDaysRemainingInCycle(endTime, "Australia/Melbourne");
        }
        assertEquals(expectedRemainingDays, remainingDays);
    }

    @Test
    @Tag("VER-225")
    @Tag("MTXVER2TMA-4486")
    public void test_getDaysRemainingInCycle_WhenEndTimeWithZone_ThenCorrectNumberOfDays_2() {
        // These numbers were taken from Smitha's test case that had failed
        MtxTimestamp endTime = new MtxTimestamp("2024-10-24T00:00:00.000000-04:00");
        MtxTimestamp curTime = new MtxTimestamp("2023-10-25T01:16:00.029142-04:00");

        System.out.println("curTime: " + curTime);
        System.out.println("endTime: " + endTime);

        Instant instant = Instant.ofEpochMilli(curTime.longValue());
        ZonedDateTime zCurTime = ZonedDateTime.ofInstant(instant, ZoneId.of("Australia/Melbourne"));
        int remainingDays = 1;
        int expectedRemainingDays = 365;
        try (MockedStatic<CommonUtils> mockedStatic = Mockito.mockStatic(
                CommonUtils.class, CALLS_REAL_METHODS)) {
            mockedStatic.when(() -> CommonUtils.getZonedDateTimeNow(isA(ZoneId.class))).thenReturn(
                    zCurTime);
            remainingDays = CommonUtils.getDaysRemainingInCycle(endTime, "Australia/Melbourne");
        }
        assertEquals(expectedRemainingDays, remainingDays);
    }

    @Test
    @Tags({
        @Tag("VER-448"), @Tag("VER-535"), @Tag("MTXVER2TMA-4559")
    })
    public void test_JsonObject_parse_When_BadInput_Then_ReproduceError(TestInfo testInfo) {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Api"
        };
        td.when = new String[] {
            "called with bad input."
        };
        td.then = new String[] {
            "reproduce error", "Error Reads like: ",
            "java.lang.NullPointerException: null\r\n"
                    + "	at com.matrixx.platform.JsonObject.getValue(JsonObject.java:727) ~[dataContainer-5255-uber.jar:5255]\r\n"
                    + "	at com.matrixx.platform.JsonObject.parse(JsonObject.java:803) ~[dataContainer-5255-uber.jar:5255]\r\n"
                    + "	at com.matrixx.platform.JsonObject.parse(JsonObject.java:851) ~[dataContainer-5255-uber.jar:5255]"
        };
        String input = "			  { \"$\": \"VisibleChangeServiceAddItem\",\r\n"
                + "         \"CatalogItemExternalId\" : \"Visible_Device_Insurance_Bundle_CI\",\r\n"
                + "         \"DiscountPrice\":,\r\n" + "         \"GrossPrice\": 100\r\n"
                + "    	  }";

        System.out.println("Start parsing");
        JsonObject jsonInput = new JsonObject();
        boolean result = jsonInput.parse(input);
        System.out.println("parse result: " + result);
    }

    @ParameterizedTest(
            name = "When_IncludePaymentAdvice_Daylight_Savings_Savings_Missing_Hour_Then_CorrectCycleDates")
    @Tags({
        @Tag("MTXVER2TMA-4568"), @Tag("VER-576")
    })
    // @formatter:off
    @CsvSource(delimiter = '|', value={
	          "|Given |Subscriber with offset.|"                        
	         +"|When  |Always.|"
	         +"|Then  |Next bill cycle end date should be correct.|"
               })
    // @formatter:on
    public void test_getNextCycleEndTime_When_offsetPresent_Then_EndDateAsPerOffset(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        OneParameterTest pTests = (tMap) -> {
            td.printDescription();
            @SuppressWarnings("unchecked")
            Map<String, String> testMap = (Map<String, String>) tMap;
            SubscriptionResponse subscription = CommonTestHelper.getEmptySubscriptionResponse(
                    "1234");
            subscription.setTimeZone("Australia/Melbourne");
            MtxBillingCycleInfo billCycle = subscription.getBillingCycle();
            MtxTimestamp start = new MtxTimestamp(testMap.get("START"));
            MtxTimestamp end = new MtxTimestamp(testMap.get("END"));
            long offset = Long.valueOf(testMap.get("OFFSET"));
            billCycle.setCurrentPeriodStartTime(start);
            billCycle.setCurrentPeriodEndTime(end);
            billCycle.setDateOffset(offset);
            billCycle.setDatePolicy(DATE_POLICY.OFFSET_FROM_START);
            MtxTimestamp endTime = CommonUtils.getNextCycleEndTime(
                    billCycle, subscription.getTimeZone());

            assertEquals(testMap.get("NEXTEND"), endTime.toString());
            System.out.println(endTime);

        };
        Map<String, String> tMap1 = Map.of(
                "START", "2023-12-31T00:00:00.000000+10:00", "END",
                "2024-01-31T00:00:00.000000+10:00", "OFFSET", "31", "NEXTEND",
                "2024-02-29T00:00:00.000000+11:00");
        pTests.test(tMap1);
        Map<String, String> tMap2 = Map.of(
                "START", "2023-12-29T00:00:00.000000+10:00", "END",
                "2024-01-29T00:00:00.000000+10:00", "OFFSET", "29", "NEXTEND",
                "2024-02-29T00:00:00.000000+11:00");
        pTests.test(tMap2);
        Map<String, String> tMap3 = Map.of(
                "START", "2023-12-28T00:00:00.000000+10:00", "END",
                "2024-01-28T00:00:00.000000+10:00", "OFFSET", "28", "NEXTEND",
                "2024-02-28T00:00:00.000000+11:00");
        pTests.test(tMap3);
        Map<String, String> tMap4 = Map.of(
                "START", "2024-01-31T00:00:00.000000+10:00", "END",
                "2024-02-29T00:00:00.000000+10:00", "OFFSET", "31", "NEXTEND",
                "2024-03-31T00:00:00.000000+11:00");
        pTests.test(tMap4);
        Map<String, String> tMap5 = Map.of(
                "START", "2024-01-30T00:00:00.000000+10:00", "END",
                "2024-02-29T00:00:00.000000+10:00", "OFFSET", "30", "NEXTEND",
                "2024-03-30T00:00:00.000000+11:00");
        pTests.test(tMap5);
        Map<String, String> tMap6 = Map.of(
                "START", "2024-02-29T00:00:00.000000+10:00", "END",
                "2024-03-31T00:00:00.000000+10:00", "OFFSET", "31", "NEXTEND",
                "2024-04-30T00:00:00.000000+10:00");
        pTests.test(tMap6);
        Map<String, String> tMap7 = Map.of(
                "START", "2024-02-29T00:00:00.000000+10:00", "END",
                "2024-03-30T00:00:00.000000+10:00", "OFFSET", "30", "NEXTEND",
                "2024-04-30T00:00:00.000000+10:00");
        pTests.test(tMap7);
        Map<String, String> tMap8 = Map.of(
                "START", "2024-02-29T00:00:00.000000+10:00", "END",
                "2024-03-29T00:00:00.000000+10:00", "OFFSET", "29", "NEXTEND",
                "2024-04-29T00:00:00.000000+10:00");
        pTests.test(tMap8);
    }

    @Test
    @Tags({
        @Tag("MTXVER2TMA-4568"), @Tag("VER-576")
    })
    public void test_getNextCycleEndTime_When_offsetPresent_Then_NextEndDateAsPerOffset(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscriber with offset."
        };
        td.when = new String[] {
            "always"
        };
        td.then = new String[] {
            "next to next bill cycle end date should be correct."
        };

        OneParameterTest pTests = (tMap) -> {
            td.printDescription();
            @SuppressWarnings("unchecked")
            Map<String, String> testMap = (Map<String, String>) tMap;
            SubscriptionResponse subscription = CommonTestHelper.getEmptySubscriptionResponse(
                    "1234");
            MtxBillingCycleInfo billCycle = subscription.getBillingCycle();
            subscription.setTimeZone("Australia/Brisbane"); // No Daylight savings. Good.
            MtxTimestamp start = new MtxTimestamp(testMap.get("START"));
            MtxTimestamp end = new MtxTimestamp(testMap.get("END"));
            long offset = Long.valueOf(testMap.get("OFFSET"));
            billCycle.setCurrentPeriodStartTime(start);
            billCycle.setCurrentPeriodEndTime(end);
            billCycle.setDateOffset(offset);
            MtxTimestamp endTime = CommonUtils.getNextToNextCycleEndTime(
                    billCycle, subscription.getTimeZone());

            assertEquals(testMap.get("NEXTEND"), endTime.toString());
            System.out.println(endTime);

        };
        Map<String, String> tMap1 = Map.of(
                "START", "2023-11-30T00:00:00.000000+10:00", "END",
                "2023-12-31T00:00:00.000000+10:00", "OFFSET", "31", "NEXTEND",
                "2024-02-29T00:00:00.000000+10:00");
        pTests.test(tMap1);
        Map<String, String> tMap2 = Map.of(
                "START", "2023-11-29T00:00:00.000000+10:00", "END",
                "2023-12-29T00:00:00.000000+10:00", "OFFSET", "29", "NEXTEND",
                "2024-02-29T00:00:00.000000+10:00");
        pTests.test(tMap2);
        Map<String, String> tMap3 = Map.of(
                "START", "2023-11-28T00:00:00.000000+10:00", "END",
                "2023-12-28T00:00:00.000000+10:00", "OFFSET", "28", "NEXTEND",
                "2024-02-28T00:00:00.000000+10:00");
        pTests.test(tMap3);
        Map<String, String> tMap4 = Map.of(
                "START", "2023-12-31T00:00:00.000000+10:00", "END",
                "2024-01-31T00:00:00.000000+10:00", "OFFSET", "31", "NEXTEND",
                "2024-03-31T00:00:00.000000+10:00");
        pTests.test(tMap4);
    }

    @ParameterizedTest(
            name = "test_subtractOneMonth_Given_TZ_London_When_MarchDST_Then_AddsZ")
    @Tags({
        @Tag("Timezone")
    })
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                  "|Given |London timezone with +01:00. Has micros.|"                        
                 +"|When  |One month subtraction results in +00:00.|"
                 +"|Then  |resulting date should have Z in place of +00:00|"
               })
    // @formatter:on
    public void test_subtractOneMonth_Given_TZ_London_When_MarchDST_Then_AddsZ(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        MtxTimestamp refDate = new MtxTimestamp("2025-04-13T00:00:00.000000+01:00");
        MtxTimestamp subOneMonth = CommonUtils.subtractOneMonth(refDate, "Europe/London");
        System.out.println(refDate+"-->"+subOneMonth);
        assertEquals("2025-03-13T00:00:00.000000Z", subOneMonth.getTime());
     
    }
    
    @ParameterizedTest(
            name = "test_subtractOneMonth_Given_TZ_London_When_OctoberDST_Then_DropsZ")
    @Tags({
        @Tag("Timezone")
    })
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                  "|Given |London timezone with Z. Has micros.|"                        
                 +"|When  |One month subtraction results in +01:00.|"
                 +"|Then  |resulting date should have +01:00 in place of Z|"
               })
    // @formatter:on
    public void test_subtractOneMonth_Given_TZ_London_When_OctoberDST_Then_DropsZ(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        MtxTimestamp refDate = new MtxTimestamp("2025-11-13T00:00:00.000000Z");
        MtxTimestamp subOneMonth = CommonUtils.subtractOneMonth(refDate, "Europe/London");
        System.out.println(refDate+"-->"+subOneMonth);
        assertEquals("2025-10-13T00:00:00.000000+01:00", subOneMonth.getTime());
    }
    
    @ParameterizedTest(
            name = "test_subtractOneMonth_Given_TZ_London_When_OctoberDST_Then_DropsZ")
    @Tags({
        @Tag("Timezone")
    })
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                  "|Given |an MtxTimestamp and Subs timezone areavailable.|"
                 +"|When  |Always.|"
                 +"|Then  |Return midnight today as date|"
               })
    // @formatter:on
    public void test_getMtxTimestampTodayZeroHours_Given_TZ_Timestamp_Then_TodayMidnight(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        MtxTimestamp refDate = new MtxTimestamp("2025-11-13T00:00:00.000000Z");
        MtxTimestamp today = CommonUtils.getMtxTimestampTodayZeroHours(refDate, "Europe/London");
        
        ZonedDateTime zdt = ZonedDateTime.now(ZoneId.of("Europe/London")).truncatedTo(ChronoUnit.DAYS);
        System.out.println(zdt+"-->"+zdt);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(MATRIXX_CONSTANTS.MTX_DATE_TIME_FORMAT);
        String formattedToday = zdt.format(formatter);
        if(formattedToday.endsWith("+00:00")) {
            formattedToday=formattedToday.replace("+00:00", "Z");
        }  
        assertEquals(formattedToday, today.getTime());
    }
    
    @ParameterizedTest(
            name = "test_subtractOneMonth_Given_TZ_London_When_OctoberDST_Then_DropsZ")
    @Tags({
        @Tag("Timezone")
    })
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                  "|Given |an MtxTimestamp and Subs timezone areavailable.|"
                 +"|When  |Always.|"
                 +"|Then  |Return midnight today as date|"
               })
    // @formatter:on
    public void test_getCycleEndDate_When_endDateInDST_Then_CorrectEndDate(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String startDateString = "2025-10-13T00:00:00.000000+01:00";
        String timeZone = "Europe/London";
        MtxTimestamp cycleStartTime = new MtxTimestamp(startDateString);
        MtxTimestamp endDateTime = CommonUtils.getCycleEndDate(cycleStartTime, timeZone, 
                        (long)CYCLE_PERIODS.MONTHLY, 1L,
                        CommonTestHelper.getMonthlyMtxBillingCycleInfo(LocalDate.of(2025, 10, 13),timeZone));    
        String endDateString = "2025-11-13T00:00:00.000000Z";
        
        assertEquals(endDateString, endDateTime.getTime());
    }
}
