package com.matrixx.vag.subscriber.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.test.util.ReflectionTestUtils;

import com.matrixx.datacontainer.MtxDate;
import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.MtxApiEventDataExtension;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferData;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.MtxRequest;
import com.matrixx.datacontainer.mdc.MtxRequestMulti;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberAdjustBalance;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberCancelOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberModifyOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberPurchaseOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriptionModify;
import com.matrixx.datacontainer.mdc.MtxResponseMulti;
import com.matrixx.datacontainer.mdc.MtxResponseOneTimeOffer;
import com.matrixx.datacontainer.mdc.MtxResponsePurchase;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.SubscriptionResponse;
import com.matrixx.datacontainer.mdc.VisiblNextCycle;
import com.matrixx.datacontainer.mdc.VisibleApiEventData;
import com.matrixx.datacontainer.mdc.VisibleAttribute;
import com.matrixx.datacontainer.mdc.VisibleCatalogItem;
import com.matrixx.datacontainer.mdc.VisibleChangeCycle;
import com.matrixx.datacontainer.mdc.VisibleChangeOfferInfo;
import com.matrixx.datacontainer.mdc.VisibleChangeServiceCredit;
import com.matrixx.datacontainer.mdc.VisibleChangeServicePromo;
import com.matrixx.datacontainer.mdc.VisibleCredits;
import com.matrixx.datacontainer.mdc.VisibleDeltaPromo;
import com.matrixx.datacontainer.mdc.VisibleNextCyclePaymentAdvice;
import com.matrixx.datacontainer.mdc.VisibleNonRedeemableCredit;
import com.matrixx.datacontainer.mdc.VisibleOfferDetails;
import com.matrixx.datacontainer.mdc.VisiblePromoExtension;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleRequestChangeService;
import com.matrixx.datacontainer.mdc.VisibleRequestChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleResponseChangeService;
import com.matrixx.datacontainer.mdc.VisibleResponseChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleReverseCredit;
import com.matrixx.datacontainer.mdc.VisibleSubscriberExtension;
import com.matrixx.platform.JsonObject;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.advice.service.PaymentAdviceService;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants;
import com.matrixx.vag.common.Constants.CHANGE_SERVICE_CONSTANTS;
import com.matrixx.vag.common.Constants.CYCLE_LENGTHS;
import com.matrixx.vag.common.Constants.GENERIC_CONSTANTS;
import com.matrixx.vag.common.Constants.LOG_MESSAGES;
import com.matrixx.vag.common.Constants.MATRIXX_CONSTANTS;
import com.matrixx.vag.common.Constants.OFFER_CONSTANTS;
import com.matrixx.vag.common.Constants.PAYMENT_CONSTANTS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.OneParameterTest;
import com.matrixx.vag.common.TestConstants.BALANCE_NAMES;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestConstants.DATA_DIR;
import com.matrixx.vag.common.TestConstants.OFFER_PRICES;
import com.matrixx.vag.common.TestConstants.TAX_CLASS_CODES;
import com.matrixx.vag.common.TestUtils;
import com.matrixx.vag.common.ThreeParameterTest;
import com.matrixx.vag.common.TwoParameterTest;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.InvalidRequestException;
import com.matrixx.vag.util.MDCTest;

public class ChangeServiceTest extends MDCTest {

    @Spy
    @InjectMocks
    private final ChangeService instance = new ChangeService();

    @Mock
    private SubscriberManagementApi api;

    PaymentAdviceService adviceInstance = null;
    private TestInfo testInfo;

    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        adviceInstance = Mockito.spy(new PaymentAdviceService());
        ReflectionTestUtils.setField(instance, "paymentAdviceService", adviceInstance);
        MockitoAnnotations.openMocks(this);
        this.testInfo = testInfo;
        doReturn("").when(instance).getRoute(any());
    }

    @Test
    public void test_changeService_When_NewOffer_SameAs_EnrolledOffer_Then_Exception(TestInfo testInfo)
            throws Exception {
        String subscriptionExternalId = "123";
        BigDecimal somePrice = BigDecimal.TEN;
        OneParameterTest pTests = (newOfferCi) -> {
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);
            newCi.setCatalogItemExternalId((String) newOfferCi);
            newCi.setDiscountPrice(somePrice);
            VisibleResponseChangeService response = new VisibleResponseChangeService();
            doThrow(
                    new InvalidRequestException(
                            null, "Subscription already has " + newOfferCi)).when(
                                    adviceInstance).getAdviceForChangeService(any(), any(), any());
            Exception exception = assertThrows(
                    InvalidRequestException.class,
                    () -> instance.changeBaseOfferService(request, response));
            System.out.println(testInfo.getDisplayName() + ":");
            exception.printStackTrace();
            assertEquals("Subscription already has " + newOfferCi, exception.getMessage());

        };
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has base offer."
        };
        td.when = new String[] {
            "Api is called with same offer."
        };
        td.then = new String[] {
            "Throw Exception via ChangeService Advice"
        };
        td.printDescription();
        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT);
    }

    @Test
    public void test_changeService_When_NewOffer_Not_Enrollable_Then_Exception(TestInfo testInfo)
            throws Exception {
        String subscriptionExternalId = "123";
        BigDecimal somePrice = BigDecimal.TEN;
        OneParameterTest pTests = (newOfferCi) -> {
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);
            newCi.setCatalogItemExternalId((String) newOfferCi);
            newCi.setDiscountPrice(somePrice);
            VisibleResponseChangeService response = new VisibleResponseChangeService();
            Exception exception = assertThrows(
                    InvalidRequestException.class,
                    () -> instance.changeBaseOfferService(request, response));
            System.out.println(testInfo.getDisplayName() + ":");
            exception.printStackTrace();
            assertEquals(
                    "Requested Catalog Item can not be enrolled through change service.".trim(),
                    exception.getMessage().trim());
        };
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has base offer."
        };
        td.when = new String[] {
            "Api is called with new offer. New offer is not enrollable"
        };
        td.then = new String[] {
            "Throw Exception"
        };
        td.printDescription();
        pTests.test(CI_EXTERNAL_IDS.UNLIMITED);
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void test_changeService_When_Mainbalance_Not_Enough_Then_Exception(TestInfo testInfo)
            throws Exception {
        String subscriptionExternalId = "123";
        BigDecimal somePrice = BigDecimal.TEN;
        String newOfferCi = CI_EXTERNAL_IDS.PLUS_CURRENT;
        ThreeParameterTest pTests = (oldSvc, newSvc, rechargeAmount) -> {
            long oldCiResourceId = 21;
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);
            newCi.setCatalogItemExternalId((String) newOfferCi);
            newCi.setDiscountPrice(somePrice);
            VisibleResponseChangeService response = new VisibleResponseChangeService();
            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount((BigDecimal) rechargeAmount);
                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    if (CI_EXTERNAL_IDS.PLUS_CURRENT.equalsIgnoreCase(oldSvc.toString())) {
                        oldCi.setEndDate(TestUtils.getLastDateTimeOfCurrentMonth());
                    }
                    oldCi.setCatalogItemExternalId(oldSvc.toString());
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());
            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);
            doReturn(multiResPurchase).when(instance).multiRequest(any(), any(), any());

            instance.changeBaseOfferService(request, response);
            System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + response.toJson());

            if (((BigDecimal) rechargeAmount).signum() > 0) {
                assertEquals(
                        response.getResult().longValue(),
                        RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
                assertThat(response.getResultText()).contains(
                        LOG_MESSAGES.NOT_ENOUGH_BALANCE_TO_CHANGE_SERVICE);
            } else {
                assertThat(response.getResult().longValue()).isNotEqualTo(
                        RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
                assertThat(response.getResultText()).doesNotContain(
                        LOG_MESSAGES.NOT_ENOUGH_BALANCE_TO_CHANGE_SERVICE);
            }
        };

        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has base offer. Subscribes mainbalance and promotions are not enough to do change service."
        };
        td.when = new String[] {
            "Api is called with valid base offer."
        };
        td.then = new String[] {
            "Attributes are passed to final MultiRequest to engine."
        };
        // Run for 8 different cases.
        td.printDescription();
        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT, BigDecimal.TEN);
        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT, BigDecimal.ZERO);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT, BigDecimal.TEN);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT, BigDecimal.ZERO);
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void test_changeService_When_ApiEventData_In_Request_Then_ApiEventData_In_Purchase_MultiRequest(TestInfo testInfo)
            throws Exception {
        String subscriptionExternalId = "123";
        String orderId = "SomeOrderId";
        BigDecimal somePrice = BigDecimal.TEN;
        String newOfferCi = CI_EXTERNAL_IDS.PLUS_CURRENT;
        ThreeParameterTest pTests = (oldSvc, newSvc, apiEventData) -> {
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            long oldCiResourceId = 21;
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            request.setApiEventData((MtxApiEventDataExtension) apiEventData);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);
            newCi.setCatalogItemExternalId((String) newOfferCi);
            newCi.setDiscountPrice(somePrice);

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));

            VisibleResponseChangeService response = new VisibleResponseChangeService();
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);
                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    if (CI_EXTERNAL_IDS.PLUS_CURRENT.equalsIgnoreCase(oldSvc.toString())) {
                        oldCi.setEndDate(TestUtils.getLastDateTimeOfCurrentMonth());
                    }
                    oldCi.setCatalogItemExternalId(oldSvc.toString());
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);

            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + multi.toJson());
            });
            MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(0);

            if (apiEventData != null) {
                assertThat(multiReq.getApiEventData()).isNotNull();
                assertEquals(
                        orderId, ((VisibleApiEventData) multiReq.getApiEventData()).getOrderId());
            } else {
                assertThat(multiReq.getApiEventData()).isNull();
            }
        };

        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has base offer."
        };
        td.when = new String[] {
            "Api is called with ApiEventData."
        };
        td.then = new String[] {
            "ApiEventData is passed to engine via multirequest to purchase new offer."
        };
        td.printDescription();

        VisibleApiEventData notEmpty = new VisibleApiEventData();
        notEmpty.setOrderId(orderId);
        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT, notEmpty);
        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT, null);
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void test_changeService_When_ApiEventData_In_Request_Then_ApiEventData_In_Modify_MultiRequest(TestInfo testInfo)
            throws Exception {
        String subscriptionExternalId = "123";
        String orderId = "SomeOrderId";
        BigDecimal somePrice = BigDecimal.TEN;
        String newOfferCi = CI_EXTERNAL_IDS.PLUS_CURRENT;
        ThreeParameterTest pTests = (oldSvc, newSvc, apiEventData) -> {
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            long oldCiResourceId = 21;
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            request.setApiEventData((MtxApiEventDataExtension) apiEventData);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);
            newCi.setCatalogItemExternalId((String) newOfferCi);
            newCi.setDiscountPrice(somePrice);
            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));
            VisibleResponseChangeService response = new VisibleResponseChangeService();
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);
                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    if (CI_EXTERNAL_IDS.PLUS_CURRENT.equalsIgnoreCase(oldSvc.toString())) {
                        oldCi.setEndDate(TestUtils.getLastDateTimeOfCurrentMonth());
                    }
                    oldCi.setCatalogItemExternalId(oldSvc.toString());
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);

            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + multi.toJson());
            });
            MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(1);

            if (apiEventData != null) {
                assertThat(multiReq.getApiEventData()).isNotNull();
                assertEquals(
                        orderId, ((VisibleApiEventData) multiReq.getApiEventData()).getOrderId());
            } else {
                assertThat(multiReq.getApiEventData()).isNull();
            }
        };

        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has base offer."
        };
        td.when = new String[] {
            "Api is called with ApiEventData."
        };
        td.then = new String[] {
            "ApiEventData is passed to engine via multirequest to modify new offer."
        };
        td.printDescription();

        VisibleApiEventData notEmpty = new VisibleApiEventData();
        notEmpty.setOrderId(orderId);
        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT, notEmpty);
        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT, null);
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void test_changeService_When_PromotionsRedeemedForNextCycle_Then_CancelRedeem(TestInfo testInfo)
            throws Exception {
        String subscriptionExternalId = "123";
        TwoParameterTest pTests = (oldSvc, newSvc) -> {
            long oldCiResourceId = 21;
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);
            newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(newSvc.toString()));
            newCi.setCatalogItemExternalId(newSvc.toString());

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));

            VisibleResponseChangeService response = new VisibleResponseChangeService();
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);

                    VisibleCatalogItem oldCi = new VisibleCatalogItem();

                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    if (CI_EXTERNAL_IDS.PLUS_CURRENT.equalsIgnoreCase(oldSvc.toString())) {
                        oldCi.setEndDate(TestUtils.getLastDateTimeOfCurrentMonth());
                    }
                    oldCi.setCatalogItemExternalId(oldSvc.toString());
                    advice.setCurrentCatalogItem(oldCi);
                    VisiblNextCycle nc = new VisiblNextCycle();

                    VisibleReverseCredit rcGoodwill = new VisibleReverseCredit();
                    rcGoodwill.setApplicableCI(oldCi.getCatalogItemExternalId());
                    rcGoodwill.setPromotionName("GOODWILL");
                    rcGoodwill.setRedeemableOfferCI(CI_EXTERNAL_IDS.GOODWILL_REDEEM);
                    rcGoodwill.setAvailableCreditsConsumable(BigDecimal.valueOf(20));
                    nc.appendReverseCredits(rcGoodwill);

                    VisibleReverseCredit rcVbpp25 = new VisibleReverseCredit();
                    rcVbpp25.setApplicableCI(oldCi.getCatalogItemExternalId());
                    rcVbpp25.setPromotionName("VBPP25");
                    rcVbpp25.setRedeemableOfferCI(CI_EXTERNAL_IDS.VBPP25_AOC_REDEEM);
                    rcVbpp25.setAvailableCreditsConsumable(BigDecimal.valueOf(15));
                    nc.appendReverseCredits(rcVbpp25);

                    advice.setNextCycle(nc);
                    advice.setNewCatalogItem(newCi);

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);

            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");
            MtxPurchasedOfferInfo poiGoodwill = CommonTestHelper.loadJsonMessage(
                    MtxPurchasedOfferInfo.class, DATA_DIR.CHANGE_SERVICE
                            + "MtxPurchasedOfferInfo_Visible_Redeem_Goodwill_Credits.json");
            long goodwillResourceId = 456;
            poiGoodwill.setResourceId(goodwillResourceId);
            reverseOffers.appendOneTimeOfferArray(poiGoodwill);

            MtxPurchasedOfferInfo poiVbpp = CommonTestHelper.loadJsonMessage(
                    MtxPurchasedOfferInfo.class, DATA_DIR.CHANGE_SERVICE
                            + "MtxPurchasedOfferInfo_Visible_Redeem_VBPP_Discount.json");

            long vbpp25ResourceId = 789;
            poiVbpp.setResourceId(vbpp25ResourceId);
            reverseOffers.appendOneTimeOfferArray(poiVbpp);

            doReturn(reverseOffers).when(instance).querySubscriptionOneTimeOffer(any(), any());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + multi.toJson());
            });
            MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(0);

            long goodwillCancelCount = multiReq.getRequestList().stream().filter(
                    req -> MtxRequestSubscriberCancelOffer.class.getSimpleName().equalsIgnoreCase(
                            req.getContainer().getName())).map(
                                    req -> (MtxRequestSubscriberCancelOffer) req).filter(
                                            canReq -> canReq.getResourceIdArray().contains(
                                                    goodwillResourceId)).count();
            assertEquals(1, goodwillCancelCount);

            long vbpp25CancelCount = multiReq.getRequestList().stream().filter(
                    req -> MtxRequestSubscriberCancelOffer.class.getSimpleName().equalsIgnoreCase(
                            req.getContainer().getName())).map(
                                    req -> (MtxRequestSubscriberCancelOffer) req).filter(
                                            canReq -> canReq.getResourceIdArray().contains(
                                                    vbpp25ResourceId)).count();
            assertEquals(1, vbpp25CancelCount);

        };

        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has base offer. PaidCycleStartDate is in future. Payment for next cycle is done using promotions."
        };
        td.when = new String[] {
            "Api is called with valid base offer."
        };
        td.then = new String[] {
            "Cancel redeem requests should be present in final MultiRequest to engine."
        };
        // Run for 4 different cases.
        td.printDescription();
        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT);
    }

    @Test
    public void test_changeService_When_ImmidiateChange_Then_CorrectOldOfferEndDate(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has base offer."
        };
        td.when = new String[] {
            "Api is called with valid base offer. Change will be applied immidiately."
        };
        td.then = new String[] {
            "Old offer should end immidiate."
        };

        String subscriptionExternalId = "123";
        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (oldSvc, newSvc) -> {
            td.printDescription();
            long oldCiResourceId = 21;
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);

            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(
                    CommonTestHelper.getOfferPrice(newCi.getCatalogItemExternalId()));

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(newSvc.toString())));

            VisibleResponseChangeService response = new VisibleResponseChangeService();
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);

                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    oldCi.setCatalogItemExternalId(oldSvc.toString());

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);

                    VisiblNextCycle nc = new VisiblNextCycle();
                    nc.setTotalAmount(newCi.getDiscountPrice());
                    nc.setPayableAmount(newCi.getDiscountPrice());
                    nc.setConsumableMainBalance(BigDecimal.ZERO);
                    nc.setTaxDetails("FullTax");
                    advice.setNextCycle(nc);
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);

            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + multi.toJson());
            });

            MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(0);

            long count = multiReq.getRequestList().stream().filter(
                    req -> MtxRequestSubscriberCancelOffer.class.getSimpleName().equalsIgnoreCase(
                            req.getContainer().getName())).count();
            if (count > 0) {
                long count1 = multiReq.getRequestList().stream().filter(
                        req -> MtxRequestSubscriberCancelOffer.class.getSimpleName().equalsIgnoreCase(
                                req.getContainer().getName())).map(
                                        req -> (MtxRequestSubscriberCancelOffer) req).filter(
                                                modReq -> modReq.getAtResourceIdArray(
                                                        0) == oldCiResourceId).count();
                assertEquals(
                        1, count1, "Cancel requests should be present for "
                                + newCi.getCatalogItemExternalId());

                assertEquals(1, count1);
            }
            System.out.println(
                    "**************************End of test iteration********************************");
        };

        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT);
        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.BASE2ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS2ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE2ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.PLUS2ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.BASE2ANNUAL, CI_EXTERNAL_IDS.PLUS2ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.PLUS2ANNUAL, CI_EXTERNAL_IDS.BASE2ANNUAL);
    }

    @Test
    public void test_changeService_When_NextCycleChange_Then_CorrectOldOfferEndDate(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has base offer."
        };
        td.when = new String[] {
            "Api is called with valid base offer."
        };
        td.then = new String[] {
            "For Core2Core Downgrade old offer should end on end of current bill cycle. Otherwise old offer should end immidiate."
        };

        String subscriptionExternalId = "123";
        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (oldSvc, newSvc) -> {
            td.printDescription();
            long oldCiResourceId = 21;
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);
            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(
                    CommonTestHelper.getOfferPrice(newCi.getCatalogItemExternalId()));
            newCi.setStartDate(TestUtils.getFirstDateTimeOfNextMonth());

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));

            VisibleResponseChangeService response = new VisibleResponseChangeService();
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);

                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    oldCi.setCatalogItemExternalId(oldSvc.toString());
                    oldCi.setEndDate(TestUtils.getFirstDateTimeOfNextMonth());

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);

                    VisiblNextCycle nc = new VisiblNextCycle();
                    nc.setTotalAmount(newCi.getDiscountPrice());
                    nc.setPayableAmount(newCi.getDiscountPrice());
                    nc.setConsumableMainBalance(BigDecimal.ZERO);
                    nc.setTaxDetails("FullTax");
                    advice.setNextCycle(nc);
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);

            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + multi.toJson());
            });

            MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(0);

            MtxRequestSubscriberModifyOffer modifyReq = multiReq.getRequestList().stream().filter(
                    req -> MtxRequestSubscriberModifyOffer.class.getSimpleName().equalsIgnoreCase(
                            req.getContainer().getName())).map(
                                    req -> (MtxRequestSubscriberModifyOffer) req).filter(
                                            modReq -> modReq.getResourceId() == oldCiResourceId).findFirst().get();
            assertEquals(
                    TestUtils.getFirstDateTimeOfNextMonth().getTime(),
                    modifyReq.getEndTime().getTime());

            System.out.println(
                    "**************************End of test iteration********************************");
        };
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.PLUS2ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS2ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE2ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.BASE2ANNUAL);
    }

    @Test
    public void test_changeService_When_NextCycle_Then_No_Attributes_In_ModifyOldOfferRequest(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has PLUS2VIS22WB offer."
        };
        td.when = new String[] {
            "Api is called with VisiblePurchasedOfferExtension attributes. Target offer is BASE2VISIBLE22."
        };
        td.then = new String[] {
            "Attributes are passed in Modify old offer request to engine."
        };

        String subscriptionExternalId = "123";
        @SuppressWarnings("rawtypes")
        ThreeParameterTest pTests = (oldSvc, newSvc, attrData) -> {
            td.printDescription();
            long oldCiResourceId = 21;
            long goodwillResourceId = 22;
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);
            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(newSvc.toString()));

            VisiblePurchasedOfferExtension extnExpected = (VisiblePurchasedOfferExtension) attrData;
            coi.setAttrData(extnExpected);

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));

            VisibleResponseChangeService response = new VisibleResponseChangeService();
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);
                    VisibleReverseCredit rc = new VisibleReverseCredit();
                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    if (CI_EXTERNAL_IDS.PLUS_CURRENT.equalsIgnoreCase(oldSvc.toString())) {
                        rc.setApplicableCI(CI_EXTERNAL_IDS.PLUS_CURRENT);
                        oldCi.setCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
                        oldCi.setDiscountPrice(OFFER_PRICES.PLUS_CURRENT);
                        oldCi.setEndDate(TestUtils.getFirstDateTimeOfNextMonth());
                    }
                    rc.setPromotionName("GOODWILL");
                    rc.setRedeemableOfferCI(CI_EXTERNAL_IDS.GOODWILL_REDEEM);
                    rc.setAvailableCreditsConsumable(BigDecimal.valueOf(20));
                    VisiblNextCycle nc = new VisiblNextCycle();
                    nc.appendReverseCredits(rc);
                    advice.setNextCycle(nc);
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);
            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");
            MtxPurchasedOfferInfo poiGoodwill = CommonTestHelper.loadJsonMessage(
                    MtxPurchasedOfferInfo.class, DATA_DIR.CHANGE_SERVICE
                            + "MtxPurchasedOfferInfo_Visible_Redeem_Goodwill_Credits.json");

            poiGoodwill.setResourceId(goodwillResourceId);
            reverseOffers.appendOneTimeOfferArray(poiGoodwill);
            doReturn(reverseOffers).when(instance).querySubscriptionOneTimeOffer(any(), any());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + multi.toJson());
            });

            MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(0);

            MtxRequestSubscriberModifyOffer modifyReq = multiReq.getRequestList().stream().filter(
                    req -> MtxRequestSubscriberModifyOffer.class.getSimpleName().equalsIgnoreCase(
                            req.getContainer().getName())).map(
                                    req -> (MtxRequestSubscriberModifyOffer) req).filter(
                                            modReq -> modReq.getResourceId() == oldCiResourceId).findFirst().get();

            assertNull(modifyReq.getAttr());
        };

        VisiblePurchasedOfferExtension extension = new VisiblePurchasedOfferExtension();
        extension.setChannel("XYZChannel");
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT, extension);

    }

    @Test
    public void test_changeService_When_ValidChange_Then_CorrectOldOfferCancel(TestInfo testInfo)
            throws Exception {
        String subscriptionExternalId = "123";
        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (oldSvc, newSvc) -> {
            long oldCiResourceId = 21;
            long goodwillResourceId = 22;
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);
            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(newSvc.toString()));

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));

            VisibleResponseChangeService response = new VisibleResponseChangeService();
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);
                    VisibleReverseCredit rc = new VisibleReverseCredit();
                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    if (CI_EXTERNAL_IDS.PLUS_CURRENT.equalsIgnoreCase(oldSvc.toString())) {
                        oldCi.setEndDate(TestUtils.getFirstDateTimeOfNextMonth());
                    }
                    oldCi.setCatalogItemExternalId(oldSvc.toString());

                    rc.setPromotionName("GOODWILL");
                    rc.setRedeemableOfferCI(CI_EXTERNAL_IDS.GOODWILL_REDEEM);
                    rc.setAvailableCreditsConsumable(BigDecimal.valueOf(20));
                    VisiblNextCycle nc = new VisiblNextCycle();
                    nc.appendReverseCredits(rc);
                    advice.setNextCycle(nc);
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);
            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");
            MtxPurchasedOfferInfo poiGoodwill = CommonTestHelper.loadJsonMessage(
                    MtxPurchasedOfferInfo.class, DATA_DIR.CHANGE_SERVICE
                            + "MtxPurchasedOfferInfo_Visible_Redeem_Goodwill_Credits.json");

            poiGoodwill.setResourceId(goodwillResourceId);
            reverseOffers.appendOneTimeOfferArray(poiGoodwill);
            doReturn(reverseOffers).when(instance).querySubscriptionOneTimeOffer(any(), any());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + multi.toJson());
            });

            MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(0);

            long countCancelRequests = multiReq.getRequestList().stream().filter(
                    req -> MtxRequestSubscriberCancelOffer.class.getSimpleName().equalsIgnoreCase(
                            req.getContainer().getName())).count();
            long countOfferCancel = 0;
            if (countCancelRequests > 0) {
                countOfferCancel = multiReq.getRequestList().stream().filter(
                        req -> MtxRequestSubscriberCancelOffer.class.getSimpleName().equalsIgnoreCase(
                                req.getContainer().getName())).map(
                                        req -> (MtxRequestSubscriberCancelOffer) req).filter(
                                                canReq -> canReq.getResourceIdArray().contains(
                                                        oldCiResourceId)).count();
            } else {
                fail("No Cancel Requests Found.");
            }

            if (CI_EXTERNAL_IDS.PLUS_CURRENT.equalsIgnoreCase(oldSvc.toString())
                    && CI_EXTERNAL_IDS.BASE_CURRENT.equalsIgnoreCase(newSvc.toString())) {
                assertEquals(0, countOfferCancel);
            } else {
                assertEquals(1, countOfferCancel);
            }
        };

        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has base offer."
        };
        td.when = new String[] {
            "Api is called with valid base offer."
        };
        td.then = new String[] {
            "If not Core2Core Downgrade old offer should cancel immidiate."
        };
        td.printDescription();

        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT);
    }

    @SuppressWarnings("unused")
    @Test
    public void test_changeService_When_ChangeAndNextCycle_Then_PriceAsPerDeltaAdvice(TestInfo testInfo)
            throws Exception {
        String subscriptionExternalId = "123";
        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (oldSvc, newSvc) -> {
            long oldCiResourceId = 21;
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);
            String targetOffer = newSvc.toString();
            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));

            VisibleResponseChangeService response = new VisibleResponseChangeService();
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);

                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    if (CI_EXTERNAL_IDS.PLUS_CURRENT.equalsIgnoreCase(oldSvc.toString())) {
                        oldCi.setEndDate(TestUtils.getLastDateTimeOfCurrentMonth());
                    }
                    oldCi.setCatalogItemExternalId(oldSvc.toString());

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);

                    VisiblNextCycle nc = new VisiblNextCycle();
                    nc.setTotalAmount(newCi.getDiscountPrice());
                    nc.setPayableAmount(newCi.getDiscountPrice());
                    nc.setConsumableMainBalance(BigDecimal.ZERO);
                    nc.setTaxDetails("FullTax");
                    advice.setNextCycle(nc);
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(targetOffer);
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(targetOffer);
            multiResPurchase.appendResponseList(purchaseResponse);

            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + multi.toJson());
            });

            MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(0);

            long countPurchaseRequests = multiReq.getRequestList().stream().filter(
                    req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                            req.getContainer().getName())).count();

            if (countPurchaseRequests > 0) {
                long ponewCiCount = multiReq.getRequestList().stream().filter(
                        req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                                req.getContainer().getName())).map(
                                        req -> (MtxRequestSubscriberPurchaseOffer) req).filter(
                                                poReq -> targetOffer.equalsIgnoreCase(
                                                        poReq.getAtOfferRequestArray(
                                                                0).getExternalId())).count();
                if (ponewCiCount > 0) {
                    VisiblePurchasedOfferExtension attrNewCi = (VisiblePurchasedOfferExtension) ((MtxPurchasedOfferData) multiReq.getRequestList().stream().filter(
                            req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                                    req.getContainer().getName())).map(
                                            req -> (MtxRequestSubscriberPurchaseOffer) req).filter(
                                                    poReq -> targetOffer.equalsIgnoreCase(
                                                            poReq.getAtOfferRequestArray(
                                                                    0).getExternalId())).findFirst().get().getAtOfferRequestArray(
                                                                            0)).getAttr();

                    assertEquals(aocDelta.intValue(), attrNewCi.getChargeAmount().intValue());
                } else {
                    fail("No Purchase Requests Found for " + targetOffer);
                }
            } else {
                fail("No Purchase Requests Found.");
            }
        };

        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has Valid Base Offer."
        };
        td.when = new String[] {
            "Api is called with Valid Base Offer. Advice has new offer and price"
        };
        td.then = new String[] {
            "Purchased Offer request should be present with delta price as per advice."
        };
        td.printDescription();

        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT);
    }

    @Test
    public void test_changeService_When_ChangeCycleOnly_Then_ServiceTaxAsPerAdvice(TestInfo testInfo)
            throws Exception {
        String subscriptionExternalId = "123";
        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (oldSvc, newSvc) -> {
            long oldCiResourceId = 21;
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);
            String targetOffer = newSvc.toString();
            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(newSvc.toString()));

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));

            VisibleResponseChangeService response = new VisibleResponseChangeService();
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);

                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    if (CI_EXTERNAL_IDS.PLUS_CURRENT.equalsIgnoreCase(oldSvc.toString())) {
                        oldCi.setEndDate(TestUtils.getLastDateTimeOfCurrentMonth());
                    }
                    oldCi.setCatalogItemExternalId(oldSvc.toString());

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);

                    VisiblNextCycle nc = new VisiblNextCycle();
                    nc.setTotalAmount(newCi.getDiscountPrice());
                    nc.setPayableAmount(newCi.getDiscountPrice());
                    nc.setConsumableMainBalance(BigDecimal.ZERO);
                    nc.setTaxDetails("FullTax");
                    advice.setNextCycle(nc);
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(targetOffer);
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(targetOffer);
            multiResPurchase.appendResponseList(purchaseResponse);

            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + multi.toJson());
            });

            MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(0);

            long countPurchaseRequests = multiReq.getRequestList().stream().filter(
                    req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                            req.getContainer().getName())).count();

            if (countPurchaseRequests > 0) {
                long ponewCiCount = multiReq.getRequestList().stream().filter(
                        req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                                req.getContainer().getName())).map(
                                        req -> (MtxRequestSubscriberPurchaseOffer) req).filter(
                                                poReq -> targetOffer.equalsIgnoreCase(
                                                        poReq.getAtOfferRequestArray(
                                                                0).getExternalId())).count();
                if (ponewCiCount > 0) {
                    VisiblePurchasedOfferExtension attrNewCi = (VisiblePurchasedOfferExtension) ((MtxPurchasedOfferData) multiReq.getRequestList().stream().filter(
                            req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                                    req.getContainer().getName())).map(
                                            req -> (MtxRequestSubscriberPurchaseOffer) req).filter(
                                                    poReq -> targetOffer.equalsIgnoreCase(
                                                            poReq.getAtOfferRequestArray(
                                                                    0).getExternalId())).findFirst().get().getAtOfferRequestArray(
                                                                            0)).getAttr();

                    assertEquals(deltaTax, attrNewCi.getTaxDetails());
                } else {
                    fail("No Purchase Requests Found for " + targetOffer);
                }
            } else {
                fail("No Purchase Requests Found.");
            }
        };

        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has Valid Base Offer."
        };
        td.when = new String[] {
            "Api is called with Valid Base Offer. Advice with or without service tax"
        };
        td.then = new String[] {
            "When advice has tax, it should be passed in multirequest.",
            "When advice has no tax, it should not be passed in multirequest."
        };
        // Run for 2 different cases. Core2CoreDowngrade without tax. Rest with Tax
        td.printDescription();

        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT);
    }

    @Test
    public void test_changeService_When_ImmidiateChange_Then_CorrectNewOfferStart(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has base offer."
        };
        td.when = new String[] {
            "Api is called with valid base offer that will affect immidiately."
        };
        td.then = new String[] {
            "New offer should start immidiate."
        };
        // Run for 4 different cases.

        String subscriptionExternalId = "123";
        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (oldSvc, newSvc) -> {
            td.printDescription();
            long oldCiResourceId = 21;
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);
            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(
                    CommonTestHelper.getOfferPrice(newCi.getCatalogItemExternalId()));

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));

            VisibleResponseChangeService response = new VisibleResponseChangeService();
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);

                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    oldCi.setCatalogItemExternalId(oldSvc.toString());

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);

                    VisiblNextCycle nc = new VisiblNextCycle();
                    nc.setTotalAmount(newCi.getDiscountPrice());
                    nc.setPayableAmount(newCi.getDiscountPrice());
                    nc.setConsumableMainBalance(BigDecimal.ZERO);
                    nc.setTaxDetails("FullTax");
                    advice.setNextCycle(nc);
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);

            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + multi.toJson());
            });

            MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(0);

            long countPurchaseRequests = multiReq.getRequestList().stream().filter(
                    req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                            req.getContainer().getName())).count();

            if (countPurchaseRequests > 0) {
                long ponewCiCount = multiReq.getRequestList().stream().filter(
                        req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                                req.getContainer().getName())).map(
                                        req -> (MtxRequestSubscriberPurchaseOffer) req).filter(
                                                poReq -> newCi.getCatalogItemExternalId().equalsIgnoreCase(
                                                        poReq.getAtOfferRequestArray(
                                                                0).getExternalId())).count();
                if (ponewCiCount > 0) {
                    MtxPurchasedOfferData pob = ((MtxPurchasedOfferData) multiReq.getRequestList().stream().filter(
                            req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                                    req.getContainer().getName())).map(
                                            req -> (MtxRequestSubscriberPurchaseOffer) req).filter(
                                                    poReq -> newCi.getCatalogItemExternalId().equalsIgnoreCase(
                                                            poReq.getAtOfferRequestArray(
                                                                    0).getExternalId())).findFirst().get().getAtOfferRequestArray(
                                                                            0));
                    assertNull(pob.getAutoActivationTime());
                } else {
                    fail("No Purchase Requests Found for " + newCi.getCatalogItemExternalId());
                }
            } else {
                fail("No Purchase Requests Found.");
            }
            System.out.println(
                    "**************************End of test iteration********************************");
        };

        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT);
        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.BASE2ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS2ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE2ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.PLUS2ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.BASE2ANNUAL, CI_EXTERNAL_IDS.PLUS2ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.PLUS2ANNUAL, CI_EXTERNAL_IDS.BASE2ANNUAL);
    }

    @Test
    public void test_changeService_When_ImmidiateChangeWithDates_Then_CorrectNewOfferStart(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has base offer."
        };
        td.when = new String[] {
            "Api is called with valid base offer that will affect immidiately. End dates for enrolled offer are in past."
                    + ""
        };
        td.then = new String[] {
            "New offer should start immidiate."
        };
        // Run for 4 different cases.

        String subscriptionExternalId = "123";
        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (oldSvc, newSvc) -> {
            td.printDescription();
            long oldCiResourceId = 21;
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);

            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(
                    CommonTestHelper.getOfferPrice(newCi.getCatalogItemExternalId()));
            newCi.setStartDate(TestUtils.getYesterdayThisTime());
            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));

            VisibleResponseChangeService response = new VisibleResponseChangeService();
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);

                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    oldCi.setCatalogItemExternalId(oldSvc.toString());
                    oldCi.setEndDate(TestUtils.getYesterdayThisTime());

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);

                    VisiblNextCycle nc = new VisiblNextCycle();
                    nc.setTotalAmount(newCi.getDiscountPrice());
                    nc.setPayableAmount(newCi.getDiscountPrice());
                    nc.setConsumableMainBalance(BigDecimal.ZERO);
                    nc.setTaxDetails("FullTax");
                    advice.setNextCycle(nc);
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);

            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + multi.toJson());
            });

            MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(0);

            long count = multiReq.getRequestList().stream().filter(
                    req -> MtxRequestSubscriberCancelOffer.class.getSimpleName().equalsIgnoreCase(
                            req.getContainer().getName())).count();
            assertEquals(
                    1, count,
                    "Cancel requests should be present for " + newCi.getCatalogItemExternalId());
            if (count > 0) {
                long count1 = multiReq.getRequestList().stream().filter(
                        req -> MtxRequestSubscriberCancelOffer.class.getSimpleName().equalsIgnoreCase(
                                req.getContainer().getName())).map(
                                        req -> (MtxRequestSubscriberCancelOffer) req).filter(
                                                modReq -> modReq.getAtResourceIdArray(
                                                        0).longValue() == oldCiResourceId).count();
                assertEquals(
                        1, count1, "Cancel requests should be present for "
                                + newCi.getCatalogItemExternalId());

                if (count1 > 1) {
                    fail();
                }
            }

            System.out.println(
                    "**************************End of test iteration********************************");
        };

        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT);
        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.BASE2ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS2ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE2ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.PLUS2ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.BASE2ANNUAL, CI_EXTERNAL_IDS.PLUS2ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.PLUS2ANNUAL, CI_EXTERNAL_IDS.BASE2ANNUAL);
    }

    @Test
    public void test_changeService_When_NextCycleChange_Then_CorrectNewOfferStart(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has base offer."
        };
        td.when = new String[] {
            "Api is called with valid base offer."
        };
        td.then = new String[] {
            "For Core2Core Downgrade and monthly2annual changes offer should start on next bill cycle."
        };

        String subscriptionExternalId = "123";
        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (oldSvc, newSvc) -> {
            td.printDescription();
            long oldCiResourceId = 21;
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);

            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(
                    CommonTestHelper.getOfferPrice(newCi.getCatalogItemExternalId()));
            newCi.setStartDate(TestUtils.getFirstDateTimeOfNextMonth());

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(newSvc.toString())));

            VisibleResponseChangeService response = new VisibleResponseChangeService();
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);

                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    oldCi.setCatalogItemExternalId(oldSvc.toString());
                    oldCi.setEndDate(TestUtils.getFirstDateTimeOfNextMonth());

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);

                    VisiblNextCycle nc = new VisiblNextCycle();
                    nc.setTotalAmount(newCi.getDiscountPrice());
                    nc.setPayableAmount(newCi.getDiscountPrice());
                    nc.setConsumableMainBalance(BigDecimal.ZERO);
                    nc.setTaxDetails("FullTax");
                    advice.setNextCycle(nc);
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);

            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + multi.toJson());
            });

            MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(0);

            long countPurchaseRequests = multiReq.getRequestList().stream().filter(
                    req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                            req.getContainer().getName())).count();

            if (countPurchaseRequests > 0) {
                long ponewCiCount = multiReq.getRequestList().stream().filter(
                        req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                                req.getContainer().getName())).map(
                                        req -> (MtxRequestSubscriberPurchaseOffer) req).filter(
                                                poReq -> newCi.getCatalogItemExternalId().equalsIgnoreCase(
                                                        poReq.getAtOfferRequestArray(
                                                                0).getExternalId())).count();
                if (ponewCiCount > 0) {
                    MtxPurchasedOfferData pob = ((MtxPurchasedOfferData) multiReq.getRequestList().stream().filter(
                            req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                                    req.getContainer().getName())).map(
                                            req -> (MtxRequestSubscriberPurchaseOffer) req).filter(
                                                    poReq -> newCi.getCatalogItemExternalId().equalsIgnoreCase(
                                                            poReq.getAtOfferRequestArray(
                                                                    0).getExternalId())).findFirst().get().getAtOfferRequestArray(
                                                                            0));
                    assertEquals(
                            TestUtils.getFirstDateTimeOfNextMonth().longValue(),
                            pob.getAutoActivationTime().longValue(), 1000);
                } else {
                    fail("No Purchase Requests Found for " + newCi.getCatalogItemExternalId());
                }
            } else {
                fail("No Purchase Requests Found.");
            }
            System.out.println(
                    "**************************End of test iteration********************************");
        };
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.PLUS2ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS2ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE2ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.BASE2ANNUAL);
    }

    @Test
    public void test_changeService_When_ChangeAndNextCycle_Then_PriceAsPerNextCycleAdvice(TestInfo testInfo)
            throws Exception {
        String subscriptionExternalId = "123";
        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (oldSvc, newSvc) -> {
            long oldCiResourceId = 21;
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);
            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(newSvc.toString()));

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));

            VisibleResponseChangeService response = new VisibleResponseChangeService();
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);

                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    if (CI_EXTERNAL_IDS.PLUS_CURRENT.equalsIgnoreCase(oldSvc.toString())) {
                        oldCi.setEndDate(TestUtils.getLastDateTimeOfCurrentMonth());
                    }
                    oldCi.setCatalogItemExternalId(oldSvc.toString());

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);

                    VisiblNextCycle nc = new VisiblNextCycle();
                    nc.setTotalAmount(newCi.getDiscountPrice());
                    nc.setPayableAmount(newCi.getDiscountPrice());
                    nc.setConsumableMainBalance(BigDecimal.ZERO);
                    nc.setTaxDetails("FullTax");
                    advice.setNextCycle(nc);
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);

            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + multi.toJson());
            });

            MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(1);

            long countModifyRequests = multiReq.getRequestList().stream().filter(
                    req -> MtxRequestSubscriberModifyOffer.class.getSimpleName().equalsIgnoreCase(
                            req.getContainer().getName())).count();

            if (countModifyRequests > 0) {
                long ponewCiCount = multiReq.getRequestList().stream().filter(
                        req -> MtxRequestSubscriberModifyOffer.class.getSimpleName().equalsIgnoreCase(
                                req.getContainer().getName())).map(
                                        req -> (MtxRequestSubscriberModifyOffer) req).count();
                if (ponewCiCount > 0) {
                    VisiblePurchasedOfferExtension attrNewCi = (VisiblePurchasedOfferExtension) ((MtxRequestSubscriberModifyOffer) multiReq.getRequestList().stream().filter(
                            req -> MtxRequestSubscriberModifyOffer.class.getSimpleName().equalsIgnoreCase(
                                    req.getContainer().getName())).map(
                                            req -> (MtxRequestSubscriberModifyOffer) req).findFirst().get()).getAttr();

                    assertEquals(
                            newCi.getDiscountPrice().intValue(),
                            attrNewCi.getChargeAmount().intValue());
                } else {
                    fail("No Modify Offer Requests Found for " + newCi.getCatalogItemExternalId());
                }
            } else {
                fail("No Modify Offer Requests Found.");
            }
        };

        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has Valid Base Offer."
        };
        td.when = new String[] {
            "Api is called with Valid Base Offer. Advice has new offer and price"
        };
        td.then = new String[] {
            "Modify Purchased Offer request should be present to change price as per advice."
        };
        td.printDescription();

        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT);
    }

    @Test
    public void test_changeService_When_ChangeAndNextCycle_Then_ServiceTaxAsPerAdvice(TestInfo testInfo)
            throws Exception {
        String subscriptionExternalId = "123";
        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (oldSvc, newSvc) -> {
            long oldCiResourceId = 21;
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            String fullTax = "FullTax";
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);
            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(newSvc.toString()));

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(newSvc.toString())));

            VisibleResponseChangeService response = new VisibleResponseChangeService();
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);

                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    if (CI_EXTERNAL_IDS.PLUS_CURRENT.equalsIgnoreCase(oldSvc.toString())) {
                        oldCi.setEndDate(TestUtils.getLastDateTimeOfCurrentMonth());
                        oldCi.setStartDate(TestUtils.getLastDateTimeOfCurrentMonth());
                    }
                    oldCi.setCatalogItemExternalId(oldSvc.toString());

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);

                    VisiblNextCycle nc = new VisiblNextCycle();
                    nc.setTotalAmount(newCi.getDiscountPrice());
                    nc.setPayableAmount(newCi.getDiscountPrice());
                    nc.setConsumableMainBalance(BigDecimal.ZERO);
                    nc.setTaxDetails(fullTax);
                    advice.setNextCycle(nc);
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);

            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + multi.toJson());
            });

            MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(1);

            long countModifyRequests = multiReq.getRequestList().stream().filter(
                    req -> MtxRequestSubscriberModifyOffer.class.getSimpleName().equalsIgnoreCase(
                            req.getContainer().getName())).count();

            if (countModifyRequests > 0) {
                long ponewCiCount = multiReq.getRequestList().stream().filter(
                        req -> MtxRequestSubscriberModifyOffer.class.getSimpleName().equalsIgnoreCase(
                                req.getContainer().getName())).map(
                                        req -> (MtxRequestSubscriberModifyOffer) req).count();
                if (ponewCiCount > 0) {
                    VisiblePurchasedOfferExtension attrNewCi = (VisiblePurchasedOfferExtension) ((MtxRequestSubscriberModifyOffer) multiReq.getRequestList().stream().filter(
                            req -> MtxRequestSubscriberModifyOffer.class.getSimpleName().equalsIgnoreCase(
                                    req.getContainer().getName())).map(
                                            req -> (MtxRequestSubscriberModifyOffer) req).findFirst().get()).getAttr();

                    assertEquals(fullTax, attrNewCi.getTaxDetails());
                } else {
                    fail("No Modify Offer Requests Found for " + newCi.getCatalogItemExternalId());
                }
            } else {
                fail("No Modify Offer Requests Found.");
            }
        };

        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has Valid Base Offer."
        };
        td.when = new String[] {
            "Api is called with Valid Base Offer. Advice has next cycle with service tax"
        };
        td.then = new String[] {
            "Tax from advice should be passed in multirequest."
        };
        td.printDescription();

        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT);
    }

    @Test
    public void test_changeService_When_Attributes_In_Request_Then_Attributes_In_ModifyNewOfferRequest(TestInfo testInfo)
            throws Exception {
        String subscriptionExternalId = "123";
        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (oldSvc, newSvc) -> {
            long oldCiResourceId = 21;
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            String fullTax = "FullTax";
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);
            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(newSvc.toString()));

            VisiblePurchasedOfferExtension attrReq = new VisiblePurchasedOfferExtension();
            String xyzChannel = "XYZChannel";
            attrReq.setChannel(xyzChannel);
            coi.setAttrData(attrReq);
            VisibleResponseChangeService response = new VisibleResponseChangeService();

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));

            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);

                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    if (CI_EXTERNAL_IDS.PLUS_CURRENT.equalsIgnoreCase(oldSvc.toString())) {
                        oldCi.setEndDate(TestUtils.getLastDateTimeOfCurrentMonth());
                        oldCi.setStartDate(TestUtils.getLastDateTimeOfCurrentMonth());
                    }
                    oldCi.setCatalogItemExternalId(oldSvc.toString());

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);

                    VisiblNextCycle nc = new VisiblNextCycle();
                    nc.setTotalAmount(newCi.getDiscountPrice());
                    nc.setPayableAmount(newCi.getDiscountPrice());
                    nc.setConsumableMainBalance(BigDecimal.ZERO);
                    nc.setTaxDetails(fullTax);
                    advice.setNextCycle(nc);
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);

            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + multi.toJson());
            });

            MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(1);

            long countModifyRequests = multiReq.getRequestList().stream().filter(
                    req -> MtxRequestSubscriberModifyOffer.class.getSimpleName().equalsIgnoreCase(
                            req.getContainer().getName())).count();

            if (countModifyRequests > 0) {
                long ponewCiCount = multiReq.getRequestList().stream().filter(
                        req -> MtxRequestSubscriberModifyOffer.class.getSimpleName().equalsIgnoreCase(
                                req.getContainer().getName())).map(
                                        req -> (MtxRequestSubscriberModifyOffer) req).count();
                if (ponewCiCount > 0) {
                    VisiblePurchasedOfferExtension attrNewCi = (VisiblePurchasedOfferExtension) ((MtxRequestSubscriberModifyOffer) multiReq.getRequestList().stream().filter(
                            req -> MtxRequestSubscriberModifyOffer.class.getSimpleName().equalsIgnoreCase(
                                    req.getContainer().getName())).map(
                                            req -> (MtxRequestSubscriberModifyOffer) req).findFirst().get()).getAttr();

                    assertEquals(xyzChannel, attrNewCi.getChannel());
                } else {
                    fail("No Modify Offer Requests Found for " + newCi.getCatalogItemExternalId());
                }
            } else {
                fail("No Modify Offer Requests Found.");
            }
        };

        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has Valid Base Offer."
        };
        td.when = new String[] {
            "Api is called with Valid Base Offer. Advice has next cycle. Input request has attributes"
        };
        td.then = new String[] {
            "Attributes from input request should be passed in modify price request."
        };
        td.printDescription();

        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT);
    }

    @Test
    public void test_changeService_When_Attributes_In_Request_Then_Attributes_In_PurchaseNewOfferRequest(TestInfo testInfo)
            throws Exception {
        String subscriptionExternalId = "123";
        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (oldSvc, newSvc) -> {
            long oldCiResourceId = 21;
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            String fullTax = "FullTax";
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);
            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(newSvc.toString()));

            VisiblePurchasedOfferExtension attrReq = new VisiblePurchasedOfferExtension();
            String xyzChannel = "XYZChannel";
            attrReq.setChannel(xyzChannel);
            coi.setAttrData(attrReq);
            VisibleResponseChangeService response = new VisibleResponseChangeService();

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));

            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);

                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    if (CI_EXTERNAL_IDS.PLUS_CURRENT.equalsIgnoreCase(oldSvc.toString())) {
                        oldCi.setEndDate(TestUtils.getLastDateTimeOfCurrentMonth());
                        oldCi.setStartDate(TestUtils.getLastDateTimeOfCurrentMonth());
                    }
                    oldCi.setCatalogItemExternalId(oldSvc.toString());

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);

                    VisiblNextCycle nc = new VisiblNextCycle();
                    nc.setTotalAmount(newCi.getDiscountPrice());
                    nc.setPayableAmount(newCi.getDiscountPrice());
                    nc.setConsumableMainBalance(BigDecimal.ZERO);
                    nc.setTaxDetails(fullTax);
                    advice.setNextCycle(nc);
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);

            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + multi.toJson());
            });

            MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(0);

            long countModifyRequests = multiReq.getRequestList().stream().filter(
                    req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                            req.getContainer().getName())).count();

            if (countModifyRequests > 0) {
                long ponewCiCount = multiReq.getRequestList().stream().filter(
                        req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                                req.getContainer().getName())).map(
                                        req -> (MtxRequestSubscriberPurchaseOffer) req).count();
                if (ponewCiCount > 0) {
                    VisiblePurchasedOfferExtension attrNewCi = (VisiblePurchasedOfferExtension) multiReq.getRequestList().stream().filter(
                            req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                                    req.getContainer().getName())).map(
                                            req -> (MtxRequestSubscriberPurchaseOffer) req).findFirst().get().getAtOfferRequestArray(
                                                    0).getAttr();

                    assertEquals(xyzChannel, attrNewCi.getChannel());
                } else {
                    fail(
                            "No Purchase Offer Requests Found for "
                                    + newCi.getCatalogItemExternalId());
                }
            } else {
                fail("No Purchase Offer Requests Found.");
            }
        };

        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has Valid Base Offer."
        };
        td.when = new String[] {
            "Api is called with Valid Base Offer. Input request has attributes"
        };
        td.then = new String[] {
            "Attributes from input request should be passed in purchase new offer request."
        };
        td.printDescription();

        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT);
    }

    @Test
    public void test_changeService_When_ChangeAndNextCycle_Then_PromosAsPerAdvice(TestInfo testInfo)
            throws Exception {
        String subscriptionExternalId = "123";
        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (oldSvc, newSvc) -> {
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            long oldCiResourceId = 21;
            BigDecimal goodwillRedeem = BigDecimal.valueOf(20);
            BigDecimal vbppRedeem = BigDecimal.valueOf(5);
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);
            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(newSvc.toString()));

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));

            VisibleResponseChangeService response = new VisibleResponseChangeService();
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);

                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    if (CI_EXTERNAL_IDS.PLUS_CURRENT.equalsIgnoreCase(oldSvc.toString())) {
                        oldCi.setEndDate(TestUtils.getLastDateTimeOfCurrentMonth());
                        oldCi.setStartDate(TestUtils.getLastDateTimeOfCurrentMonth());
                    }
                    oldCi.setCatalogItemExternalId(oldSvc.toString());

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);

                    VisiblNextCycle nc = new VisiblNextCycle();
                    VisibleCredits goodwill = new VisibleCredits();
                    goodwill.setApplicableCI(newCi.getCatalogItemExternalId());
                    goodwill.setPromotionName("GOODWILL");
                    goodwill.setCreditRedeemableOfferCI(CI_EXTERNAL_IDS.GOODWILL_REDEEM);
                    goodwill.setAvailableCreditsGrant(goodwillRedeem);
                    goodwill.setEstimatedTransferableCredits(goodwillRedeem);
                    goodwill.setAvailableCredits(goodwillRedeem);
                    goodwill.setRedeemableCredits(goodwillRedeem);
                    goodwill.setAvailableCreditsConsumable(BigDecimal.ZERO);
                    nc.appendCredits(goodwill);

                    VisibleCredits vbpp = new VisibleCredits();
                    vbpp.setApplicableCI(newCi.getCatalogItemExternalId());
                    vbpp.setPromotionName("VBPP25");
                    vbpp.setCreditRedeemableOfferCI(CI_EXTERNAL_IDS.VBPP25_AOC_REDEEM);
                    vbpp.setAvailableCreditsGrant(vbppRedeem);
                    vbpp.setEstimatedTransferableCredits(vbppRedeem);
                    vbpp.setAvailableCredits(vbppRedeem);
                    vbpp.setRedeemableCredits(vbppRedeem);
                    vbpp.setAvailableCreditsConsumable(BigDecimal.ZERO);
                    nc.appendCredits(vbpp);

                    advice.setNextCycle(nc);
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);

            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            instance.changeBaseOfferService(request, response);

            MtxRequestMulti multiReq = argumentCaptor.getValue();
            System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + multiReq.toJson());

            long countPurchaseRequests = multiReq.getRequestList().stream().filter(
                    req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                            req.getContainer().getName())).count();

            if (countPurchaseRequests > 0) {
                long goodwillCount = multiReq.getRequestList().stream().filter(
                        req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                                req.getContainer().getName())).map(
                                        req -> (MtxRequestSubscriberPurchaseOffer) req).filter(
                                                poReq -> CI_EXTERNAL_IDS.GOODWILL_REDEEM.equalsIgnoreCase(
                                                        poReq.getAtOfferRequestArray(
                                                                0).getExternalId())).count();
                if (goodwillCount > 0) {
                    VisiblePurchasedOfferExtension attrGoodwill = (VisiblePurchasedOfferExtension) ((MtxPurchasedOfferData) multiReq.getRequestList().stream().filter(
                            req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                                    req.getContainer().getName())).map(
                                            req -> (MtxRequestSubscriberPurchaseOffer) req).filter(
                                                    poReq -> CI_EXTERNAL_IDS.GOODWILL_REDEEM.equalsIgnoreCase(
                                                            poReq.getAtOfferRequestArray(
                                                                    0).getExternalId())).findFirst().get().getAtOfferRequestArray(
                                                                            0)).getAttr();

                    assertEquals(
                            goodwillRedeem.intValue(), attrGoodwill.getChargeAmount().intValue());
                    assertEquals(
                            newCi.getCatalogItemExternalId(), attrGoodwill.getCoreBasePlanCI());

                } else {
                    fail("No Purchase Requests Found for Goodwill.");
                }

                long vbppAocCount = multiReq.getRequestList().stream().filter(
                        req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                                req.getContainer().getName())).map(
                                        req -> (MtxRequestSubscriberPurchaseOffer) req).filter(
                                                poReq -> CI_EXTERNAL_IDS.VBPP25_AOC_REDEEM.equalsIgnoreCase(
                                                        poReq.getAtOfferRequestArray(
                                                                0).getExternalId())).count();
                if (vbppAocCount > 0) {
                    VisiblePurchasedOfferExtension attrVbpp = (VisiblePurchasedOfferExtension) ((MtxPurchasedOfferData) multiReq.getRequestList().stream().filter(
                            req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                                    req.getContainer().getName())).map(
                                            req -> (MtxRequestSubscriberPurchaseOffer) req).filter(
                                                    poReq -> CI_EXTERNAL_IDS.VBPP25_AOC_REDEEM.equalsIgnoreCase(
                                                            poReq.getAtOfferRequestArray(
                                                                    0).getExternalId())).findFirst().get().getAtOfferRequestArray(
                                                                            0)).getAttr();

                    assertEquals(vbppRedeem.intValue(), attrVbpp.getChargeAmount().intValue());
                    assertEquals(newCi.getCatalogItemExternalId(), attrVbpp.getCoreBasePlanCI());
                } else {
                    fail("No Purchase Requests Found for VBPP25.");
                }
            } else {
                fail("No Purchase Requests Found.");
            }
        };

        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has Valid Base Offer."
        };
        td.when = new String[] {
            "Api is called with Valid Base Offer. Advice has next cycle with promos"
        };
        td.then = new String[] {
            "Promo redeem requests as per advice should be passed in multirequest."
        };
        td.printDescription();

        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT);
    }

    @Test
    public void test_changeService_When_ChangeAndNextCycle_Then_PromoTaxAsPerAdvice(TestInfo testInfo)
            throws Exception {
        String subscriptionExternalId = "123";
        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (oldSvc, newSvc) -> {
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            String vbppTax = "vbppTax";
            String goodwillTax = "goodwillTax";
            long oldCiResourceId = 21;
            BigDecimal goodwillRedeem = BigDecimal.valueOf(20);
            BigDecimal vbppRedeem = BigDecimal.valueOf(5);
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);
            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(newSvc.toString()));

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));

            VisibleResponseChangeService response = new VisibleResponseChangeService();
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);

                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    if (CI_EXTERNAL_IDS.PLUS_CURRENT.equalsIgnoreCase(oldSvc.toString())) {
                        oldCi.setEndDate(TestUtils.getLastDateTimeOfCurrentMonth());
                        oldCi.setStartDate(TestUtils.getLastDateTimeOfCurrentMonth());
                    }
                    oldCi.setCatalogItemExternalId(oldSvc.toString());

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);

                    VisiblNextCycle nc = new VisiblNextCycle();
                    VisibleCredits goodwill = new VisibleCredits();
                    goodwill.setApplicableCI(newCi.getCatalogItemExternalId());
                    goodwill.setPromotionName("GOODWILL");
                    goodwill.setCreditRedeemableOfferCI(CI_EXTERNAL_IDS.GOODWILL_REDEEM);
                    goodwill.setAvailableCreditsGrant(goodwillRedeem);
                    goodwill.setEstimatedTransferableCredits(goodwillRedeem);
                    goodwill.setAvailableCredits(goodwillRedeem);
                    goodwill.setRedeemableCredits(goodwillRedeem);
                    goodwill.setAvailableCreditsConsumable(BigDecimal.ZERO);
                    goodwill.setTaxDetails(goodwillTax);
                    nc.appendCredits(goodwill);

                    VisibleCredits vbpp = new VisibleCredits();
                    vbpp.setApplicableCI(newCi.getCatalogItemExternalId());
                    vbpp.setPromotionName("VBPP25");
                    vbpp.setCreditRedeemableOfferCI(CI_EXTERNAL_IDS.VBPP25_AOC_REDEEM);
                    vbpp.setAvailableCreditsGrant(vbppRedeem);
                    vbpp.setEstimatedTransferableCredits(vbppRedeem);
                    vbpp.setAvailableCredits(vbppRedeem);
                    vbpp.setRedeemableCredits(vbppRedeem);
                    vbpp.setAvailableCreditsConsumable(BigDecimal.ZERO);
                    vbpp.setTaxDetails(vbppTax);
                    nc.appendCredits(vbpp);

                    advice.setNextCycle(nc);
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);

            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            instance.changeBaseOfferService(request, response);

            VisiblePurchasedOfferExtension modifyExtn = null;

            for (MtxRequestMulti multi : argumentCaptor.getAllValues()) {
                System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + multi.toJson());
                for (MtxRequest req : multi.getRequestList()) {
                    if (req instanceof MtxRequestSubscriberModifyOffer) {
                        MtxRequestSubscriberModifyOffer mReq = (MtxRequestSubscriberModifyOffer) req;
                        modifyExtn = (VisiblePurchasedOfferExtension) mReq.getAttr();
                    }
                }
            }
            ;

            if (modifyExtn == null) {
                fail("No modify offer requests found.");
            } else {
                if (modifyExtn.getCreditTaxDetailsArray() == null
                        || modifyExtn.getCreditTaxDetailsArray().isEmpty()) {
                    fail("No credit tax strings found.");
                } else {
                    assertThat(modifyExtn.getCreditTaxDetailsArray()).contains(goodwillTax);
                    assertThat(modifyExtn.getCreditTaxDetailsArray()).contains(vbppTax);
                }
            }
        };

        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has Valid Base Offer."
        };
        td.when = new String[] {
            "Api is called with Valid Base Offer. Advice has next cycle with promo tax"
        };
        td.then = new String[] {
            "Promo Tax from advice should be passed in multirequest."
        };
        td.printDescription();

        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT);
    }

    @Test
    public void test_changeService_When_Attributes_In_Request_Then_Attributes_In_RedeemPromoOfferRequest(TestInfo testInfo)
            throws Exception {
        String subscriptionExternalId = "123";
        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (oldSvc, newSvc) -> {
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            String vbppTax = "vbppTax";
            String goodwillTax = "goodwillTax";
            long oldCiResourceId = 21;
            BigDecimal goodwillRedeem = BigDecimal.valueOf(20);
            BigDecimal vbppRedeem = BigDecimal.valueOf(5);
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);
            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(newSvc.toString()));

            VisiblePurchasedOfferExtension attrReq = new VisiblePurchasedOfferExtension();
            String xyzChannel = "XYZChannel";
            attrReq.setChannel(xyzChannel);
            coi.setAttrData(attrReq);

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));

            VisibleResponseChangeService response = new VisibleResponseChangeService();
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);

                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    if (CI_EXTERNAL_IDS.PLUS_CURRENT.equalsIgnoreCase(oldSvc.toString())) {
                        oldCi.setEndDate(TestUtils.getLastDateTimeOfCurrentMonth());
                        oldCi.setStartDate(TestUtils.getLastDateTimeOfCurrentMonth());
                    }
                    oldCi.setCatalogItemExternalId(oldSvc.toString());

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);

                    VisiblNextCycle nc = new VisiblNextCycle();
                    VisibleCredits goodwill = new VisibleCredits();
                    goodwill.setApplicableCI(newCi.getCatalogItemExternalId());
                    goodwill.setPromotionName("GOODWILL");
                    goodwill.setCreditRedeemableOfferCI(CI_EXTERNAL_IDS.GOODWILL_REDEEM);
                    goodwill.setAvailableCreditsGrant(goodwillRedeem);
                    goodwill.setEstimatedTransferableCredits(goodwillRedeem);
                    goodwill.setAvailableCredits(goodwillRedeem);
                    goodwill.setRedeemableCredits(goodwillRedeem);
                    goodwill.setAvailableCreditsConsumable(BigDecimal.ZERO);
                    goodwill.setTaxDetails(goodwillTax);
                    nc.appendCredits(goodwill);

                    VisibleCredits vbpp = new VisibleCredits();
                    vbpp.setApplicableCI(newCi.getCatalogItemExternalId());
                    vbpp.setPromotionName("VBPP25");
                    vbpp.setCreditRedeemableOfferCI(CI_EXTERNAL_IDS.VBPP25_AOC_REDEEM);
                    vbpp.setAvailableCreditsGrant(vbppRedeem);
                    vbpp.setEstimatedTransferableCredits(vbppRedeem);
                    vbpp.setAvailableCredits(vbppRedeem);
                    vbpp.setRedeemableCredits(vbppRedeem);
                    vbpp.setAvailableCreditsConsumable(BigDecimal.ZERO);
                    vbpp.setTaxDetails(vbppTax);
                    nc.appendCredits(vbpp);

                    advice.setNextCycle(nc);
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);

            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            instance.changeBaseOfferService(request, response);

            MtxRequestMulti multiReq = argumentCaptor.getValue();
            System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + multiReq.toJson());

            long countPurchaseRequests = multiReq.getRequestList().stream().filter(
                    req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                            req.getContainer().getName())).count();

            if (countPurchaseRequests > 0) {
                long goodwillCount = multiReq.getRequestList().stream().filter(
                        req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                                req.getContainer().getName())).map(
                                        req -> (MtxRequestSubscriberPurchaseOffer) req).filter(
                                                poReq -> CI_EXTERNAL_IDS.GOODWILL_REDEEM.equalsIgnoreCase(
                                                        poReq.getAtOfferRequestArray(
                                                                0).getExternalId())).count();
                if (goodwillCount > 0) {
                    VisiblePurchasedOfferExtension attrGoodwill = (VisiblePurchasedOfferExtension) ((MtxPurchasedOfferData) multiReq.getRequestList().stream().filter(
                            req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                                    req.getContainer().getName())).map(
                                            req -> (MtxRequestSubscriberPurchaseOffer) req).filter(
                                                    poReq -> CI_EXTERNAL_IDS.GOODWILL_REDEEM.equalsIgnoreCase(
                                                            poReq.getAtOfferRequestArray(
                                                                    0).getExternalId())).findFirst().get().getAtOfferRequestArray(
                                                                            0)).getAttr();
                    assertEquals(xyzChannel, attrGoodwill.getChannel());

                } else {
                    fail("No Purchase Requests Found for Goodwill.");
                }

                long vbppAocCount = multiReq.getRequestList().stream().filter(
                        req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                                req.getContainer().getName())).map(
                                        req -> (MtxRequestSubscriberPurchaseOffer) req).filter(
                                                poReq -> CI_EXTERNAL_IDS.VBPP25_AOC_REDEEM.equalsIgnoreCase(
                                                        poReq.getAtOfferRequestArray(
                                                                0).getExternalId())).count();
                if (vbppAocCount > 0) {
                    VisiblePurchasedOfferExtension attrVbpp = (VisiblePurchasedOfferExtension) ((MtxPurchasedOfferData) multiReq.getRequestList().stream().filter(
                            req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                                    req.getContainer().getName())).map(
                                            req -> (MtxRequestSubscriberPurchaseOffer) req).filter(
                                                    poReq -> CI_EXTERNAL_IDS.VBPP25_AOC_REDEEM.equalsIgnoreCase(
                                                            poReq.getAtOfferRequestArray(
                                                                    0).getExternalId())).findFirst().get().getAtOfferRequestArray(
                                                                            0)).getAttr();
                    assertEquals(xyzChannel, attrVbpp.getChannel());
                } else {
                    fail("No Purchase Requests Found for VBPP25.");
                }
            } else {
                fail("No Purchase Requests Found.");
            }
        };

        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has Valid Base Offer."
        };
        td.when = new String[] {
            "Api is called with Valid Base Offer. Request has attributes.Advice has next cycle with promo"
        };
        td.then = new String[] {
            "Attributes should be passed promo redeem requests."
        };
        td.printDescription();

        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT);
    }

    @Test
    public void test_changeService_When_NextCycle_Then_PurchaseServiceType_Is_Renewal(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has Valid Base Offer."
        };
        td.when = new String[] {
            "Api is called with Valid Base Offer. Request has attributes.Advice has next cycle with promo"
        };
        td.then = new String[] {
            "PurchaseServiceType of next cycle is 'Renewal'."
        };
        td.printDescription();
        String subscriptionExternalId = "123";
        @SuppressWarnings("rawtypes")
        ThreeParameterTest pTests = (oldSvc, newSvc, attrData) -> {
            td.printDescription();
            long oldCiResourceId = 21;
            long goodwillResourceId = 22;
            long newCiResourceId = 99;
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);
            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(newSvc.toString()));
            VisiblePurchasedOfferExtension extnExpected = (VisiblePurchasedOfferExtension) attrData;
            coi.setAttrData(extnExpected);

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));

            VisibleResponseChangeService response = new VisibleResponseChangeService();
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);
                    VisibleReverseCredit rc = new VisibleReverseCredit();
                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    if (CI_EXTERNAL_IDS.PLUS_CURRENT.equalsIgnoreCase(oldSvc.toString())) {
                        oldCi.setEndDate(TestUtils.getLastDateTimeOfCurrentMonth());
                        oldCi.setStartDate(TestUtils.getLastDateTimeOfCurrentMonth());
                    }
                    oldCi.setCatalogItemExternalId(oldSvc.toString());

                    rc.setPromotionName("GOODWILL");
                    rc.setRedeemableOfferCI(CI_EXTERNAL_IDS.GOODWILL_REDEEM);
                    rc.setAvailableCreditsConsumable(BigDecimal.valueOf(20));
                    VisiblNextCycle nc = new VisiblNextCycle();
                    nc.appendReverseCredits(rc);
                    advice.setNextCycle(nc);
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setResourceId(newCiResourceId);
            multiResPurchase.appendResponseList(purchaseResponse);
            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");
            MtxPurchasedOfferInfo poiGoodwill = CommonTestHelper.loadJsonMessage(
                    MtxPurchasedOfferInfo.class, DATA_DIR.CHANGE_SERVICE
                            + "MtxPurchasedOfferInfo_Visible_Redeem_Goodwill_Credits.json");

            poiGoodwill.setResourceId(goodwillResourceId);
            reverseOffers.appendOneTimeOfferArray(poiGoodwill);
            doReturn(reverseOffers).when(instance).querySubscriptionOneTimeOffer(any(), any());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(
                        testInfo.getDisplayName() + StringUtils.SPACE + multiResPurchase.toJson());
            });

            VisiblePurchasedOfferExtension modReqExtn = null;
            for (MtxRequestMulti multiReq : argumentCaptor.getAllValues()) {
                for (MtxRequest req : multiReq.getRequestList()) {
                    if (MtxRequestSubscriberModifyOffer.class.getSimpleName().equalsIgnoreCase(
                            req.getContainer().getName())) {
                        MtxRequestSubscriberModifyOffer modReq = (MtxRequestSubscriberModifyOffer) req;
                        if (newCiResourceId == modReq.getResourceId()) {
                            modReqExtn = (VisiblePurchasedOfferExtension) modReq.getAttr();
                            System.out.println(
                                    testInfo.getDisplayName() + StringUtils.SPACE + req.toJson());
                        }
                    }
                }
            }

            if (modReqExtn == null) {
                fail("Attributes for modify request not found.");
            } else {
                assertEquals(
                        PAYMENT_CONSTANTS.PURCHASE_SERVICE_TYPE_RENEWAL,
                        modReqExtn.getPurchaseServiceType());
            }

        };

        VisiblePurchasedOfferExtension extension = new VisiblePurchasedOfferExtension();
        extension.setPurchaseServiceType("XYZ");
        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT, extension);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT, extension);
    }

    @Test
    public void test_changeService_When_NextCycle_Then_PaidCycleStartDate_Is_CopiedFromAdvice(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has Valid Base Offer."
        };
        td.when = new String[] {
            "Api is called with Valid Base Offer. Advice has next cycle. Advice has PaidCycleStartDate."
        };
        td.then = new String[] {
            "PaidCycleStartDate is populated in ModifyOfferRequest for new Base Offer."
        };
        td.printDescription();
        String subscriptionExternalId = "123";
        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (oldSvc, newSvc) -> {
            td.printDescription();
            long oldCiResourceId = 21;
            long goodwillResourceId = 22;
            long newCiResourceId = 99;
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            MtxDate paidCycleStartDate = new MtxDate("4712-12-31");
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);
            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(newSvc.toString()));

            VisiblePurchasedOfferExtension extnExpected = new VisiblePurchasedOfferExtension();
            coi.setAttrData(extnExpected);

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));

            VisibleResponseChangeService response = new VisibleResponseChangeService();
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);
                    advice.setPaidCycleStartDate(paidCycleStartDate);
                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    if (CI_EXTERNAL_IDS.PLUS_CURRENT.equalsIgnoreCase(oldSvc.toString())) {
                        oldCi.setEndDate(TestUtils.getLastDateTimeOfCurrentMonth());
                        oldCi.setStartDate(TestUtils.getLastDateTimeOfCurrentMonth());
                    }
                    oldCi.setCatalogItemExternalId(oldSvc.toString());

                    VisiblNextCycle nc = new VisiblNextCycle();
                    advice.setNextCycle(nc);
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setResourceId(newCiResourceId);
            multiResPurchase.appendResponseList(purchaseResponse);
            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");
            MtxPurchasedOfferInfo poiGoodwill = CommonTestHelper.loadJsonMessage(
                    MtxPurchasedOfferInfo.class, DATA_DIR.CHANGE_SERVICE
                            + "MtxPurchasedOfferInfo_Visible_Redeem_Goodwill_Credits.json");

            poiGoodwill.setResourceId(goodwillResourceId);
            reverseOffers.appendOneTimeOfferArray(poiGoodwill);
            doReturn(reverseOffers).when(instance).querySubscriptionOneTimeOffer(any(), any());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(
                        testInfo.getDisplayName() + StringUtils.SPACE + multiResPurchase.toJson());
            });

            VisiblePurchasedOfferExtension modReqExtn = null;
            for (MtxRequestMulti multiReq : argumentCaptor.getAllValues()) {
                for (MtxRequest req : multiReq.getRequestList()) {
                    if (MtxRequestSubscriberModifyOffer.class.getSimpleName().equalsIgnoreCase(
                            req.getContainer().getName())) {
                        MtxRequestSubscriberModifyOffer modReq = (MtxRequestSubscriberModifyOffer) req;
                        if (newCiResourceId == modReq.getResourceId()) {
                            modReqExtn = (VisiblePurchasedOfferExtension) modReq.getAttr();
                            System.out.println(
                                    testInfo.getDisplayName() + StringUtils.SPACE + req.toJson());
                        }
                    }
                }
            }

            if (modReqExtn == null) {
                fail("Attributes for modify request not found.");
            } else {
                assertEquals(
                        paidCycleStartDate.getTimestamp().getTime(),
                        modReqExtn.getPaidCycleStartDate().getTimestamp().getTime());
            }

        };

        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT);
    }

    @Test
    public void test_changeService_When_NextCycle_Then_ChargePurchaseProrationType_Is_1(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has Valid Base Offer."
        };
        td.when = new String[] {
            "Api is called with Valid Base Offer. Request has attributes.Advice has next cycle with promo"
        };
        td.then = new String[] {
            "PurchaseServiceType of next cycle is 'renewal'."
        };
        td.printDescription();
        String subscriptionExternalId = "123";
        @SuppressWarnings("rawtypes")
        ThreeParameterTest pTests = (oldSvc, newSvc, attrData) -> {
            td.printDescription();
            long oldCiResourceId = 21;
            long goodwillResourceId = 22;
            long newCiResourceId = 99;
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);
            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(newSvc.toString()));

            VisiblePurchasedOfferExtension extnExpected = (VisiblePurchasedOfferExtension) attrData;
            coi.setAttrData(extnExpected);

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));

            VisibleResponseChangeService response = new VisibleResponseChangeService();
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);
                    VisibleReverseCredit rc = new VisibleReverseCredit();
                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    if (CI_EXTERNAL_IDS.PLUS_CURRENT.equalsIgnoreCase(oldSvc.toString())) {
                        oldCi.setEndDate(TestUtils.getLastDateTimeOfCurrentMonth());
                        oldCi.setStartDate(TestUtils.getLastDateTimeOfCurrentMonth());
                    }
                    oldCi.setCatalogItemExternalId(oldSvc.toString());

                    rc.setPromotionName("GOODWILL");
                    rc.setRedeemableOfferCI(CI_EXTERNAL_IDS.GOODWILL_REDEEM);
                    rc.setAvailableCreditsConsumable(BigDecimal.valueOf(20));
                    VisiblNextCycle nc = new VisiblNextCycle();
                    nc.appendReverseCredits(rc);
                    advice.setNextCycle(nc);
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setResourceId(newCiResourceId);
            multiResPurchase.appendResponseList(purchaseResponse);
            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");
            MtxPurchasedOfferInfo poiGoodwill = CommonTestHelper.loadJsonMessage(
                    MtxPurchasedOfferInfo.class, DATA_DIR.CHANGE_SERVICE
                            + "MtxPurchasedOfferInfo_Visible_Redeem_Goodwill_Credits.json");

            poiGoodwill.setResourceId(goodwillResourceId);
            reverseOffers.appendOneTimeOfferArray(poiGoodwill);
            doReturn(reverseOffers).when(instance).querySubscriptionOneTimeOffer(any(), any());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(
                        testInfo.getDisplayName() + StringUtils.SPACE + multiResPurchase.toJson());
            });

            MtxPurchasedOfferData modReqData = null;

            for (MtxRequestMulti multiReq : argumentCaptor.getAllValues()) {
                for (MtxRequest req : multiReq.getRequestList()) {
                    if (MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                            req.getContainer().getName())) {
                        MtxRequestSubscriberPurchaseOffer modReq = (MtxRequestSubscriberPurchaseOffer) req;
                        modReqData = (MtxPurchasedOfferData) modReq.getAtOfferRequestArray(0);
                        System.out.println(
                                testInfo.getDisplayName() + StringUtils.SPACE + req.toJson());
                    }
                }
            }

            if (modReqData == null) {
                fail("Attributes for modify request not found.");
            } else {
                assertEquals(
                        Constants.MATRIXX_CONSTANTS.CHRG_PURCHASE_FULL_AMOUNT,
                        modReqData.getChargePurchaseProrationType());
            }

        };

        VisiblePurchasedOfferExtension extension = new VisiblePurchasedOfferExtension();
        extension.setPurchaseServiceType("XYZ");
        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT, extension);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT, extension);
    }

    @Test
    public void test_changeService_When_ValidChange_Then_PopulateOfferChangeType(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has Valid Base Offer."
        };
        td.when = new String[] {
            "Api is called with Valid Base Offer. Advice returns change type."
        };
        td.then = new String[] {
            "OfferChangetype is populated'."
        };
        td.comments = new String[] {
            "MTXVER2-170", "VER-142"
        };

        String subscriptionExternalId = "123";
        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (oldSvc, newSvc) -> {
            td.printDescription();
            long oldCiResourceId = 21;
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);
            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(newSvc.toString()));

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));

            VisibleResponseChangeService response = new VisibleResponseChangeService();
            String offerChangeType = AppPropertyProvider.getInstance().getString(
                    CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_PREFIX + oldSvc
                            + CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_OFFER_SEPARATOR_TO
                            + newSvc);
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);
                    advice.setChangeType(offerChangeType);
                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    if (CI_EXTERNAL_IDS.PLUS_CURRENT.equalsIgnoreCase(oldSvc.toString())) {
                        oldCi.setEndDate(TestUtils.getLastDateTimeOfCurrentMonth());
                        oldCi.setStartDate(TestUtils.getLastDateTimeOfCurrentMonth());
                    }
                    oldCi.setCatalogItemExternalId(oldSvc.toString());

                    VisiblNextCycle nc = new VisiblNextCycle();
                    advice.setNextCycle(nc);
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);
            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");

            doReturn(reverseOffers).when(instance).querySubscriptionOneTimeOffer(any(), any());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + multi.toJson());
            });

            MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(0);

            MtxRequestSubscriberPurchaseOffer purchReq = multiReq.getRequestList().stream().filter(
                    req -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                            req.getContainer().getName())).map(
                                    req -> (MtxRequestSubscriberPurchaseOffer) req).findFirst().get();
            VisiblePurchasedOfferExtension purch_attr = (VisiblePurchasedOfferExtension) purchReq.getAtOfferRequestArray(
                    0).getAttr();
            System.out.println(purch_attr.toJson());

            assertEquals(offerChangeType, purch_attr.getOfferChangeType());

        };

        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT);
    }

    @ParameterizedTest(
            name = "test_changeService_When_RequestHasNewPromotion_Then_GrantNewPromotion")
    @Tags(value = {
        @Tag("MTXVER2-204"), @Tag("VER-207"), @Tag("VER-209")
    })
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has Valid Base Offer.|"
                +"|When  |Api is called with new promotions.|"
                +"|Then  |Grant Offer for new promotion purchased, if grant does not preexist|"})
 // @formatter:on
    public void test_changeService_When_RequestHasNewPromotion_Then_GrantNewPromotion(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (chgReq, oldSvc) -> {
            td.printDescription();
            long oldCiResourceId = 21;
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            VisibleRequestChangeService request = (VisibleRequestChangeService) chgReq;

            String newSvc = request.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId();
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(newSvc.toString()));

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));

            VisibleResponseChangeService response = new VisibleResponseChangeService();
            String offerChangeType = AppPropertyProvider.getInstance().getString(
                    CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_PREFIX + oldSvc
                            + CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_OFFER_SEPARATOR_TO
                            + newSvc);
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);
                    advice.setChangeType(offerChangeType);
                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    oldCi.setCatalogItemExternalId(oldSvc.toString());

                    VisiblNextCycle nc = new VisiblNextCycle();
                    advice.setNextCycle(nc);
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);

                    VisibleChangeServiceCredit csc = new VisibleChangeServiceCredit();
                    csc.setClassCode("2535PLUS");
                    csc.setPromotionName(
                            request.getAtNewPromotionList(0).getAttr().getPromotionName());
                    csc.setApplicableCI(newSvc);
                    csc.setGrantAmount(request.getAtNewPromotionList(0).getGrantAmount());
                    csc.setGrantOfferCI(request.getAtNewPromotionList(0).getGrantOfferCI());
                    csc.setPromotionLimit(
                            request.getAtNewPromotionList(0).getAttr().getPromotionLimit());
                    advice.appendNewRedeemableCredits(csc);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);
            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");

            doReturn(reverseOffers).when(instance).querySubscriptionOneTimeOffer(any(), any());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(
                        testInfo.getDisplayName() + StringUtils.SPACE + "multi.toJson(): "
                                + multi.toJson());
            });

            MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(0);
            MtxRequestSubscriberPurchaseOffer purchReq = multiReq.getRequestList().stream().filter(
                    req1 -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                            req1.getContainer().getName())).map(
                                    req1 -> (MtxRequestSubscriberPurchaseOffer) req1).findFirst().get();
            VisiblePurchasedOfferExtension purch_attr = (VisiblePurchasedOfferExtension) purchReq.getAtOfferRequestArray(
                    0).getAttr();
            System.out.println(purch_attr.toJson());

            assertEquals(
                    request.getAtNewPromotionList(0).getGrantOfferCI(),
                    purchReq.getAtOfferRequestArray(0).getExternalId());
            assertEquals(
                    request.getAtNewPromotionList(0).getGrantAmount().intValue(),
                    purch_attr.getChargeAmount().intValue());
            assertEquals(
                    request.getAtNewPromotionList(0).getAttr().getPromotionName(),
                    purch_attr.getPromotionName());
            assertEquals(
                    request.getAtNewPromotionList(0).getAttr().getPromotionLimit().intValue(),
                    purch_attr.getPromotionLimit().intValue());

        };

        String subscriptionExternalId = "123";
        VisibleRequestChangeService request = CommonTestHelper.getVisibleRequestChangeService(
                subscriptionExternalId, CI_EXTERNAL_IDS.PRO_CURRENT);
        CommonTestHelper.addNewGrantToVisibleRequestChangeService(
                request, CI_EXTERNAL_IDS.PLUS_2535_GRANT, "PLUS2535", GENERIC_CONSTANTS.NO,
                BigDecimal.valueOf(5000), BigDecimal.valueOf(9));
        pTests.test(request, CI_EXTERNAL_IDS.BASE_CURRENT);
    }

    @ParameterizedTest(
            name = "test_changeService_When_RequestHasNewPromotion_GrantExists_Then_GrantAmountNoChange")
    @Tags(value = {
        @Tag("MTXVER2-204"), @Tag("VER-207"), @Tag("VER-209")
    })
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has Valid Base Offer.|"
                +"|When  |Api is called with new promotions.|"
                +"|Then  |Grant Offer for new promotion NOT purchased, if grant DOES preexist|"})
    // @formatter:on
    public void test_changeService_When_RequestHasNewPromotion_GrantExists_Then_GrantAmountNoChange(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (chgReq, oldSvc) -> {
            td.printDescription();
            long oldCiResourceId = 21;
            long grantResourceId = 22;
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            VisibleRequestChangeService request = (VisibleRequestChangeService) chgReq;
            String newSvc = request.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId();
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(newSvc.toString()));

            VisibleResponseChangeService response = new VisibleResponseChangeService();
            String offerChangeType = AppPropertyProvider.getInstance().getString(
                    CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_PREFIX + oldSvc
                            + CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_OFFER_SEPARATOR_TO
                            + newSvc);

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));

            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setSubscriptionExternalId(request.getSubscriptionExternalId());
                    advice.setRechargeAmount(BigDecimal.ZERO);
                    advice.setChangeType(offerChangeType);
                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    oldCi.setCatalogItemExternalId(oldSvc.toString());

                    VisiblNextCycle nc = new VisiblNextCycle();
                    advice.setNextCycle(nc);
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);

                    VisiblePromoExtension pe = request.getAtNewPromotionList(0).getAttr();
                    VisibleChangeServiceCredit csc = new VisibleChangeServiceCredit();
                    csc.setClassCode(pe.getClassCode());
                    csc.setGrantOfferCI(request.getAtNewPromotionList(0).getGrantOfferCI());
                    csc.setPromotionName(pe.getPromotionName());
                    csc.setPromotionLimit(pe.getPromotionLimit());
                    csc.setApplicableCI(newSvc);
                    csc.setGrantAmount(request.getAtNewPromotionList(0).getGrantAmount());
                    csc.setResourceId(grantResourceId);
                    advice.appendNewRedeemableCredits(csc);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);
            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");

            doReturn(reverseOffers).when(instance).querySubscriptionOneTimeOffer(any(), any());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(
                        testInfo.getDisplayName() + StringUtils.SPACE + "multi.toJson(): "
                                + multi.toJson());
            });

            MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(0);
            MtxRequestSubscriberModifyOffer modReq = multiReq.getRequestList().stream().filter(
                    req1 -> MtxRequestSubscriberModifyOffer.class.getSimpleName().equalsIgnoreCase(
                            req1.getContainer().getName())).map(
                                    req1 -> (MtxRequestSubscriberModifyOffer) req1).findFirst().get();
            System.out.println(
                    testInfo.getDisplayName() + StringUtils.SPACE + "multi.toJson(): "
                            + modReq.toJson());
            assertEquals(grantResourceId, modReq.getResourceId().longValue());

            VisiblePurchasedOfferExtension attr = (VisiblePurchasedOfferExtension) modReq.getAttr();
            System.out.println(attr.toJson());
            assertTrue(attr.getChargeAmount() == null);
        };
        String subscriptionExternalId = "123";
        VisibleRequestChangeService request = CommonTestHelper.getVisibleRequestChangeService(
                subscriptionExternalId, CI_EXTERNAL_IDS.PRO_CURRENT);
        CommonTestHelper.addNewGrantToVisibleRequestChangeService(
                request, CI_EXTERNAL_IDS.PLUS_2535_GRANT, "PLUS2535", GENERIC_CONSTANTS.NO,
                BigDecimal.valueOf(5000), BigDecimal.valueOf(9));
        pTests.test(request, CI_EXTERNAL_IDS.BASE_CURRENT);

    }

    @SuppressWarnings("unchecked")
    @Test
    @Tag("VER-210")
    public void test_changeService_When_OldPromoNotUsableAfterChange_Then_CancelOldPromo(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has Valid Base Offer.", "There is a grant offer with balances.",
            "Grant offer will not be usable after change."
        };
        td.when = new String[] {
            "Api is called."
        };
        td.then = new String[] {
            "Old Grant offer should be cancelled."
        };
        td.comments = new String[] {
            "MTXVER2-204"
        };

        @SuppressWarnings("rawtypes")
        ThreeParameterTest pTests = (chgReq, oldSvc, oldPromo) -> {
            td.printDescription();
            long oldCiResourceId = 21;
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            VisibleRequestChangeService request = (VisibleRequestChangeService) chgReq;
            Map<String, Object> oldPromoMap = (HashMap<String, Object>) oldPromo;
            String newSvc = request.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId();
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(newSvc.toString()));

            VisibleResponseChangeService response = new VisibleResponseChangeService();

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));
            CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldPromoMap.get("GrantOffer").toString(),
                    BigDecimal.valueOf(5000), BigDecimal.valueOf(5000), BigDecimal.valueOf(10),
                    false);

            String offerChangeType = AppPropertyProvider.getInstance().getString(
                    CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_PREFIX + oldSvc
                            + CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_OFFER_SEPARATOR_TO
                            + newSvc);
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setSubscriptionExternalId(request.getSubscriptionExternalId());
                    advice.setRechargeAmount(BigDecimal.ZERO);
                    advice.setChangeType(offerChangeType);
                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    oldCi.setCatalogItemExternalId(oldSvc.toString());

                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);

                    VisibleNonRedeemableCredit nrc = new VisibleNonRedeemableCredit();
                    nrc.setApplicableCI(oldSvc.toString());
                    nrc.setCreditGrant(BigDecimal.valueOf(500));
                    nrc.setClassCode("TESTCODE");
                    nrc.setPromotionName("TestPromo");
                    nrc.setGrantOfferCI(oldPromoMap.get("GrantOffer").toString());
                    advice.appendNonRedeemableCredits(nrc);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);
            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");

            doReturn(reverseOffers).when(instance).querySubscriptionOneTimeOffer(any(), any());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(
                        testInfo.getDisplayName() + StringUtils.SPACE + "multi.toJson(): "
                                + multi.toJson());
            });

            MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(0);
            MtxRequest req = multiReq.getAtRequestList(0);
            MtxRequestSubscriberCancelOffer cancelReq = CommonTestHelper.parseJsonMessage(
                    MtxRequestSubscriberCancelOffer.class, req.toJson());

            System.out.println(
                    testInfo.getDisplayName() + StringUtils.SPACE + "cancelReq.toJson(): "
                            + cancelReq.getAtResourceIdArray(0));

            assertEquals(
                    CommonTestHelper.getOfferResourceId(
                            oldPromoMap.get("GrantOffer").toString(), 0),
                    cancelReq.getAtResourceIdArray(0).longValue());
        };
        VisibleRequestChangeService request;

        request = new VisibleRequestChangeService();
        request.setSubscriptionExternalId("123");
        VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
        request.setChangeOfferInfo(coi);
        VisibleCatalogItem newCi = new VisibleCatalogItem();
        coi.setNewCatalogItem(newCi);

        // Test1
        newCi.setCatalogItemExternalId(CI_EXTERNAL_IDS.PRO_CURRENT);
        newCi.setDiscountPrice(OFFER_PRICES.PRO_CURRENT);
        Map<String, Object> oldPromo = new HashMap<String, Object>();
        oldPromo.put("GrantOffer", CI_EXTERNAL_IDS.FIRST25_GRANT);
        pTests.test(request, CI_EXTERNAL_IDS.BASE_CURRENT, oldPromo);
    }

    @Test
    @Tag("VER-460")
    public void test_changeService_When_ToAnnual_Then_CycleLengthAnnual(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has base offer."
        };
        td.when = new String[] {
            "Api is called with Annual base offer."
        };
        td.then = new String[] {
            "CycleLength should be annual."
        };

        String subscriptionExternalId = "123";
        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (oldSvc, newSvc) -> {
            td.printDescription();
            long oldCiResourceId = 21;
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);

            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(
                    CommonTestHelper.getOfferPrice(newCi.getCatalogItemExternalId()));
            newCi.setStartDate(TestUtils.getFirstDateTimeOfNextMonth());

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(newSvc.toString())));

            VisibleResponseChangeService response = new VisibleResponseChangeService();
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);

                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    oldCi.setCatalogItemExternalId(oldSvc.toString());
                    oldCi.setEndDate(TestUtils.getFirstDateTimeOfNextMonth());

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);

                    VisiblNextCycle nc = new VisiblNextCycle();
                    nc.setTotalAmount(newCi.getDiscountPrice());
                    nc.setPayableAmount(newCi.getDiscountPrice());
                    nc.setConsumableMainBalance(BigDecimal.ZERO);
                    nc.setTaxDetails("FullTax");
                    advice.setNextCycle(nc);
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");

                    VisibleNextCyclePaymentAdvice ncpa = new VisibleNextCyclePaymentAdvice();
                    ncpa.setConsumableMainBalanceAmount(BigDecimal.ZERO);
                    ncpa.setRechargeAmount(newCi.getDiscountPrice());
                    ncpa.setTotalPayableAmount(newCi.getDiscountPrice());
                    VisibleOfferDetails vod = new VisibleOfferDetails();
                    vod.setCatalogItemExternalId(newCi.getCatalogItemExternalId());
                    vod.setChargeAmount(newCi.getDiscountPrice());
                    vod.setPayableAmount(newCi.getDiscountPrice());
                    vod.setConsumableMainBalanceAmount(BigDecimal.ZERO);
                    vod.setCycleStartTime(TestUtils.getFirstDateTimeOfNextMonth().toString());
                    vod.setCycleEndTime(
                            TestUtils.addOneYear(
                                    TestUtils.getFirstDateTimeOfNextMonth()).toString());
                    vod.setOfferType(OFFER_CONSTANTS.OFFER_TYPE_BASE);
                    ncpa.appendVisibleOfferDetailsList(vod);
                    advice.setNextCyclePaymentAdvice(ncpa);
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);

            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + multi.toJson());
            });

            MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(1);

            long countModifySubRequests = multiReq.getRequestList().stream().filter(
                    req -> MtxRequestSubscriptionModify.class.getSimpleName().equalsIgnoreCase(
                            req.getContainer().getName())).count();

            if (countModifySubRequests > 0) {
                MtxRequestSubscriptionModify sm = ((MtxRequestSubscriptionModify) multiReq.getRequestList().stream().filter(
                        req -> MtxRequestSubscriptionModify.class.getSimpleName().equalsIgnoreCase(
                                req.getContainer().getName())).map(
                                        req -> (MtxRequestSubscriptionModify) req).findFirst().get());
                VisibleSubscriberExtension extn = (VisibleSubscriberExtension) sm.getAttr();
                assertEquals(CYCLE_LENGTHS.YEAR, extn.getCycleLength());
            } else {
                fail("No Subscriber Modify Requests Found.");
            }
            System.out.println(
                    "**************************End of test iteration********************************");
        };

        pTests.test(CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.PLUS3ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.BASE3VIS23, CI_EXTERNAL_IDS.PLUS3ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.BASE3ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.BASE3VIS23, CI_EXTERNAL_IDS.BASE3ANNUAL);
    }

    @Test
    @Tag("VER-460")
    public void test_changeService_When_ToMonthly_Then_CycleLengthMonthly(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has base offer."
        };
        td.when = new String[] {
            "Api is called with Monthly base offer."
        };
        td.then = new String[] {
            "CycleLength should be monthly."
        };

        String subscriptionExternalId = "123";
        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (oldSvc, newSvc) -> {
            td.printDescription();
            long oldCiResourceId = 21;
            BigDecimal aocDelta = BigDecimal.valueOf(5);
            String deltaTax = "DeltaTax";
            VisibleRequestChangeService request = new VisibleRequestChangeService();
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
            request.setChangeOfferInfo(coi);
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            coi.setNewCatalogItem(newCi);

            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(
                    CommonTestHelper.getOfferPrice(newCi.getCatalogItemExternalId()));
            newCi.setStartDate(TestUtils.getFirstDateTimeOfNextMonth());

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));

            VisibleResponseChangeService response = new VisibleResponseChangeService();
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setRechargeAmount(BigDecimal.ZERO);

                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldCiResourceId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    oldCi.setCatalogItemExternalId(oldSvc.toString());
                    oldCi.setEndDate(TestUtils.getFirstDateTimeOfNextMonth());

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails(deltaTax);
                    advice.setChangeCycle(cc);

                    VisiblNextCycle nc = new VisiblNextCycle();
                    nc.setTotalAmount(newCi.getDiscountPrice());
                    nc.setPayableAmount(newCi.getDiscountPrice());
                    nc.setConsumableMainBalance(BigDecimal.ZERO);
                    nc.setTaxDetails("FullTax");
                    advice.setNextCycle(nc);
                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");

                    VisibleNextCyclePaymentAdvice ncpa = new VisibleNextCyclePaymentAdvice();
                    ncpa.setConsumableMainBalanceAmount(BigDecimal.ZERO);
                    ncpa.setRechargeAmount(newCi.getDiscountPrice());
                    ncpa.setTotalPayableAmount(newCi.getDiscountPrice());
                    VisibleOfferDetails vod = new VisibleOfferDetails();
                    vod.setCatalogItemExternalId(newCi.getCatalogItemExternalId());
                    vod.setChargeAmount(newCi.getDiscountPrice());
                    vod.setPayableAmount(newCi.getDiscountPrice());
                    vod.setConsumableMainBalanceAmount(BigDecimal.ZERO);
                    vod.setCycleStartTime(TestUtils.getFirstDateTimeOfNextMonth().toString());
                    vod.setCycleEndTime(
                            TestUtils.addOneMonth(
                                    TestUtils.getFirstDateTimeOfNextMonth()).toString());
                    vod.setOfferType(OFFER_CONSTANTS.OFFER_TYPE_BASE);
                    ncpa.appendVisibleOfferDetailsList(vod);
                    advice.setNextCyclePaymentAdvice(ncpa);
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);

            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + multi.toJson());
            });

            MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(1);

            long countModifySubRequests = multiReq.getRequestList().stream().filter(
                    req -> MtxRequestSubscriptionModify.class.getSimpleName().equalsIgnoreCase(
                            req.getContainer().getName())).count();

            if (countModifySubRequests > 0) {
                MtxRequestSubscriptionModify sm = ((MtxRequestSubscriptionModify) multiReq.getRequestList().stream().filter(
                        req -> MtxRequestSubscriptionModify.class.getSimpleName().equalsIgnoreCase(
                                req.getContainer().getName())).map(
                                        req -> (MtxRequestSubscriptionModify) req).findFirst().get());
                VisibleSubscriberExtension extn = (VisibleSubscriberExtension) sm.getAttr();
                assertEquals(CYCLE_LENGTHS.MONTH, extn.getCycleLength());
            } else {
                fail("No Subscriber Modify Requests Found.");
            }
            System.out.println(
                    "**************************End of test iteration********************************");
        };

        pTests.test(CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.PLUS3ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.BASE3VIS23, CI_EXTERNAL_IDS.PLUS3ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.BASE3ANNUAL);
        pTests.test(CI_EXTERNAL_IDS.BASE3VIS23, CI_EXTERNAL_IDS.BASE3ANNUAL);
    }

    @SuppressWarnings("unchecked")
    @Test
    @Tag("VER-480")
    public void test_changeService_When_DeltaPromos_Then_AdviceInputDeltaPromos(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has Referral Credits"
        };
        td.when = new String[] {
            "Referral Credits is Delta Promotions in input."
        };
        td.then = new String[] {
            "Referral Credits is Delta Promotions in input of ChangeServiceAdviceRequest."
        };

        td.comments = new String[] {
            "VER-480"
        };
        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (chgReq, oldSvc) -> {
            td.printDescription();
            VisibleRequestChangeService request = (VisibleRequestChangeService) chgReq;

            String newSvc = request.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId();
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(newSvc.toString()));
            request.getChangeOfferInfo().setNewCatalogItem(newCi);
            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));

            VisibleResponseChangeService response = new VisibleResponseChangeService();
            ArgumentCaptor<VisibleRequestChangeServiceAdvice> argumentCaptor = ArgumentCaptor.forClass(
                    VisibleRequestChangeServiceAdvice.class);
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(
                    argumentCaptor.capture(), any(), any());
            System.out.println(
                    testInfo.getDisplayName() + StringUtils.SPACE + "request: " + request.toJson());

            // Dummy Exception Assertion. In this test we are not interested in response of advice
            assertThrows(Exception.class, () -> instance.changeBaseOfferService(request, response));
            VisibleRequestChangeServiceAdvice adviceReq = argumentCaptor.getAllValues().get(0);
            System.out.println(
                    testInfo.getDisplayName() + StringUtils.SPACE + "adviceReq: "
                            + adviceReq.toJson());

            assertFalse(adviceReq.getDeltaPromotionList().isEmpty());
            assertEquals(
                    request.getAtDeltaPromotionList(0).getClassCode(),
                    adviceReq.getAtDeltaPromotionList(0).getClassCode());
            assertEquals(
                    request.getAtDeltaPromotionList(0).getDeltaPromotionLimit().doubleValue(),
                    adviceReq.getAtDeltaPromotionList(0).getDeltaPromotionLimit().doubleValue());
        };
        VisibleRequestChangeService request;
        VisibleDeltaPromo dp;
        String subscriptionExternalId = "123";

        request = new VisibleRequestChangeService();
        request.setSubscriptionExternalId(subscriptionExternalId);
        VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
        request.setChangeOfferInfo(coi);
        VisibleCatalogItem newCi = new VisibleCatalogItem();
        coi.setNewCatalogItem(newCi);
        newCi.setCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);

        dp = new VisibleDeltaPromo();
        dp.setClassCode(TAX_CLASS_CODES.REF20);
        dp.setDeltaPromotionLimit(BigDecimal.valueOf(150));
        request.getDeltaPromotionListAppender().add(dp);
        pTests.test(request, CI_EXTERNAL_IDS.BASE3ANNUAL);
    }

    @Test
    @Tag("VER-480")
    public void test_changeService_When_AdviceResponse_Has_DeltaPromos_Then_RedeemDeltaPromos(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has Referral Credits"
        };
        td.when = new String[] {
            "Referral Credits is Delta Promotions of advice response."
        };
        td.then = new String[] {
            "Referral Credits is is redeemed  through purchase request."
        };

        td.comments = new String[] {
            "VER-480"
        };
        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (chgReq, oldSvc) -> {
            td.printDescription();
            String refRedeemOffer = CI_EXTERNAL_IDS.REF20_REDEEM;
            BigDecimal aocDelta = BigDecimal.valueOf(150);
            BigDecimal redeemPromo = BigDecimal.valueOf(150);
            BigDecimal refGrant = BigDecimal.valueOf(200);
            VisibleRequestChangeService request = (VisibleRequestChangeService) chgReq;
            String newSvc = request.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId();
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(newSvc.toString()));
            request.getChangeOfferInfo().setNewCatalogItem(newCi);
            VisibleResponseChangeService response = new VisibleResponseChangeService();

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(oldSvc.toString())));

            String offerChangeType = AppPropertyProvider.getInstance().getString(
                    CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_PREFIX + oldSvc
                            + CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_OFFER_SEPARATOR_TO
                            + newSvc);
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setSubscriptionExternalId(request.getSubscriptionExternalId());
                    advice.setRechargeAmount(BigDecimal.ZERO);
                    advice.setChangeType(offerChangeType);
                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(12l);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    oldCi.setCatalogItemExternalId(oldSvc.toString());

                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails("");

                    VisibleCredits ref20 = new VisibleCredits();
                    ref20.setApplicableCI(newCi.getCatalogItemExternalId());
                    ref20.setPromotionName(TAX_CLASS_CODES.REF20);
                    ref20.setCreditRedeemableOfferCI(refRedeemOffer);
                    ref20.setAvailableCreditsGrant(refGrant);
                    ref20.setEstimatedTransferableCredits(redeemPromo);
                    ref20.setAvailableCredits(refGrant);
                    ref20.setRedeemableCredits(redeemPromo);
                    ref20.setAvailableCreditsConsumable(BigDecimal.ZERO);
                    cc.appendCredits(ref20);

                    advice.setChangeCycle(cc);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);
            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            instance.changeBaseOfferService(request, response);
            argumentCaptor.getAllValues().forEach(multReq -> {
                System.out.println(
                        testInfo.getDisplayName() + StringUtils.SPACE + "multReq.toJson(): "
                                + multReq.toJson());
            });

            MtxRequestMulti mult = argumentCaptor.getAllValues().get(0);
            assertEquals(
                    MtxRequestSubscriberPurchaseOffer.class.getSimpleName(),
                    mult.getAtRequestList(0).getContainer().getName());

            MtxRequestSubscriberPurchaseOffer poReq = CommonTestHelper.parseJsonMessage(
                    MtxRequestSubscriberPurchaseOffer.class, mult.getAtRequestList(0).toJson());
            assertEquals(refRedeemOffer, poReq.getAtOfferRequestArray(0).getExternalId());

            VisiblePurchasedOfferExtension extn = (VisiblePurchasedOfferExtension) poReq.getAtOfferRequestArray(
                    0).getAttr();
            assertEquals(redeemPromo.doubleValue(), extn.getChargeAmount().doubleValue());
        };
        VisibleRequestChangeService request = new VisibleRequestChangeService();
        request.setSubscriptionExternalId("123");
        VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
        request.setChangeOfferInfo(coi);
        VisibleCatalogItem newCi = new VisibleCatalogItem();
        coi.setNewCatalogItem(newCi);
        newCi.setCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        pTests.test(request, CI_EXTERNAL_IDS.BASE3ANNUAL);
    }

    @Tags({
        @Tag("VER-548"), @Tag("MTXVER2TMA-4566"), @Tag("Timezones")
    })
    @ParameterizedTest(
            name = "test_getChangeService_When_SubsciptionTZ_Before_SystemTZ_ChangeNextCycle_Then_OfferEndDates")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active base service.(BASE3VISIBLE23).Base service was purchased few minutes ago.|"
                +"|When  |Change to BASE3VISIBLE23A. Advice is provided with current offer end time as of today.|"
                +"|      |Ignoring timezone enddatetime already occurred. Considering timezone enddatetime is still in future (by minutes or hours)|"
                +"|Then  |Current offer should end date.New offer should be preactive.|"
                +"|Comments |Assume Melbourne is system timezone. Let Subs timezone be any zone towards west of melbourne.|"
                +"|         |Choose Pacific/Midway as this one is eastern most.|"})
    // @formatter:on
    public void test_getChangeService_When_SubsciptionTZ_Before_SystemTZ_ChangeNextCycle_Then_OfferEndDates(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (chgReq, oldSvc) -> {
            td.printDescription();
            String subtimeZoneString = "Pacific/Midway";
            MtxTimestamp nowInMidway = CommonUtils.getCurrentTimeInZone(subtimeZoneString);
            MtxTimestamp laterInMidway = nowInMidway.plusMilli(5 * 60000);

            BigDecimal aocDelta = BigDecimal.valueOf(150);
            VisibleRequestChangeService request = (VisibleRequestChangeService) chgReq;
            String newSvc = request.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId();
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(newSvc.toString()));
            newCi.setStartDate(laterInMidway);
            request.getChangeOfferInfo().setNewCatalogItem(newCi);
            VisibleResponseChangeService response = new VisibleResponseChangeService();

            MtxTimestamp offerStartTime = nowInMidway;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(
                            request.getSubscriptionExternalId(), Arrays.asList(oldSvc.toString())));
            subscription.setTimeZone(subtimeZoneString);
            MtxPurchasedOfferInfo mpoiEnrolled = subscription.getAtPurchasedOfferArray(0);
            mpoiEnrolled.setPurchaseTime(offerStartTime);
            mpoiEnrolled.setStartTime(offerStartTime);
            mpoiEnrolled.setCurrentStatusTransitionTime(offerStartTime);

            String offerChangeType = AppPropertyProvider.getInstance().getString(
                    CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_PREFIX + oldSvc
                            + CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_OFFER_SEPARATOR_TO
                            + newSvc);

            long oldResId = 1234L;
            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    advice.setSubscriptionExternalId(request.getSubscriptionExternalId());
                    advice.setRechargeAmount(BigDecimal.ZERO);
                    advice.setChangeType(offerChangeType);
                    VisibleCatalogItem oldCi = new VisibleCatalogItem();
                    oldCi.setResourceId(oldResId);
                    oldCi.setDiscountPrice(CommonTestHelper.getOfferPrice(oldSvc.toString()));
                    oldCi.setCatalogItemExternalId(oldSvc.toString());
                    oldCi.setEndDate(laterInMidway);

                    advice.setCurrentCatalogItem(oldCi);
                    advice.setNewCatalogItem(newCi);

                    VisibleChangeCycle cc = new VisibleChangeCycle();
                    cc.setTotalAmount(aocDelta);
                    cc.setPayableAmount(aocDelta);
                    cc.setAocAmount(aocDelta);
                    cc.setConsumableMainBalance(BigDecimal.ZERO);
                    cc.setTaxDetails("");

                    advice.setChangeCycle(cc);
                    advice.setResult(RESULT_CODES.MTX_SUCCESS);
                    advice.setResultText("OK");
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);
            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            instance.changeBaseOfferService(request, response);
            argumentCaptor.getAllValues().forEach(multReq -> {
                System.out.println(
                        testInfo.getDisplayName() + StringUtils.SPACE + "multReq.toJson(): "
                                + multReq.toJson());
            });

            MtxRequestMulti mult = argumentCaptor.getAllValues().get(0);

            assertEquals(
                    MtxRequestSubscriberModifyOffer.class.getSimpleName(),
                    mult.getAtRequestList(0).getContainer().getName());
            JsonObject jo_0 = new JsonObject();
            mult.getAtRequestList(0).toJson(jo_0);
            assertEquals(oldResId, jo_0.get("ResourceId"));
            assertEquals(laterInMidway.toString(), jo_0.get("EndTime").toString());

            assertEquals(
                    MtxRequestSubscriberPurchaseOffer.class.getSimpleName(),
                    mult.getAtRequestList(1).getContainer().getName());
            JsonObject jo_1 = new JsonObject();
            mult.getAtRequestList(1).toJson(jo_1);
            JsonObject poData_jo = (JsonObject) jo_1.getArray("OfferRequestArray").get(0);
            assertEquals(true, poData_jo.get("PreActiveState"));
            assertEquals(newCi.getCatalogItemExternalId(), poData_jo.get("ExternalId").toString());
            assertEquals(laterInMidway.toString(), poData_jo.get("AutoActivationTime").toString());
        };
        VisibleRequestChangeService request = new VisibleRequestChangeService();
        request.setSubscriptionExternalId("123");
        VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
        request.setChangeOfferInfo(coi);
        VisibleCatalogItem newCi = new VisibleCatalogItem();
        coi.setNewCatalogItem(newCi);
        newCi.setCatalogItemExternalId(CI_EXTERNAL_IDS.BASE3ANNUAL);
        pTests.test(request, CI_EXTERNAL_IDS.BASE3VIS23);
    }

    @SuppressWarnings({
        "rawtypes", "unchecked"
    })
    @Tag("VER-694")
    @Tag("GlobalPass")
    @ParameterizedTest(name = "test_changeService_When_C2CAnnualUpgrade_Then_GlobalPassUpdate")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription with BASE3VISIBLEA.Service in use for few months.|"
                +"|When  |Call to upgrade to PLUS3VIS23WBA.|"
                +"|Then  |GPCount and GLGP balance should be adjusted for remaining period of service.|"})
    // @formatter:on
    public void test_changeService_When_C2CAnnualUpgrade_Then_GlobalPassUpdate(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String subscriptionExternalId = "123";
        long oldCiResourceId = 21;
        BigDecimal aocDelta = BigDecimal.valueOf(5);
        String deltaTax = "DeltaTax";
        VisibleRequestChangeService request = new VisibleRequestChangeService();
        request.setSubscriptionExternalId(subscriptionExternalId);
        VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
        request.setChangeOfferInfo(coi);
        VisibleCatalogItem newCi = new VisibleCatalogItem();
        coi.setNewCatalogItem(newCi);

        newCi.setCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(newCi.getCatalogItemExternalId()));
        newCi.setStartDate(TestUtils.getFirstDateTimeOfNextMonth());
        VisibleAttribute attr = new VisibleAttribute();
        attr.setName(CHANGE_SERVICE_CONSTANTS.ATTRIBUTE_NAME_FREE_GLOBAL_PASS);
        attr.setValue("7");
        newCi.getAttributesAppender().add(attr);

        MtxResponseSubscription sub = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription(
                        List.of(newCi.getCatalogItemExternalId())));
        sub.getBalanceArray().forEach(bi -> {
            if (bi.getName().equalsIgnoreCase(BALANCE_NAMES.GLOBAL_PASS)) {
                // Set value to max so that adjustments would be required.
                bi.setAmount(BigDecimal.valueOf(12));
            }
        });
        VisibleResponseChangeService response = new VisibleResponseChangeService();
        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                advice.setSubscriptionExternalId(subscriptionExternalId);
                advice.setRechargeAmount(BigDecimal.ZERO);

                VisibleCatalogItem oldCi = new VisibleCatalogItem();
                oldCi.setResourceId(oldCiResourceId);
                oldCi.setCatalogItemExternalId(CI_EXTERNAL_IDS.BASE3ANNUAL);
                oldCi.setDiscountPrice(
                        CommonTestHelper.getOfferPrice(oldCi.getCatalogItemExternalId()));
                oldCi.setEndDate(TestUtils.getFirstDateTimeOfNextMonth());

                VisibleChangeCycle cc = new VisibleChangeCycle();
                cc.setTotalAmount(aocDelta);
                cc.setPayableAmount(aocDelta);
                cc.setAocAmount(aocDelta);
                cc.setConsumableMainBalance(BigDecimal.ZERO);
                cc.setTaxDetails(deltaTax);
                advice.setChangeCycle(cc);

                String offerChangeType = AppPropertyProvider.getInstance().getString(
                        CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_PREFIX
                                + oldCi.getCatalogItemExternalId()
                                + CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_OFFER_SEPARATOR_TO
                                + newCi.getCatalogItemExternalId());
                advice.setChangeType(offerChangeType);

                advice.setCurrentCatalogItem(oldCi);
                advice.setNewCatalogItem(newCi);
                advice.setResult(RESULT_CODES.MTX_SUCCESS);
                advice.setResultText("OK");
                return null;
            }
        }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

        MtxResponseMulti multiResPurchase = new MtxResponseMulti();
        multiResPurchase.setResult(0l);
        multiResPurchase.setResultText("OK");
        MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
        purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                newCi.getCatalogItemExternalId());
        purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(newCi.getCatalogItemExternalId());
        multiResPurchase.appendResponseList(purchaseResponse);

        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResPurchase).when(instance).multiRequest(
                any(), any(), argumentCaptor.capture());

        instance.changeBaseOfferService(request, response);

        argumentCaptor.getAllValues().forEach(multi -> {
            System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + multi.toJson());
        });

        MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(1);
        MtxRequestSubscriberPurchaseOffer po = new MtxRequestSubscriberPurchaseOffer(
                multiReq.getAtRequestList(1));

        System.out.println(
                testInfo.getDisplayName() + StringUtils.SPACE
                        + po.getAtOfferRequestArray(0).toJson());
        assertEquals(
                OFFER_CONSTANTS.GPGL_CURLY_ADJUST_OFFER_NAME,
                po.getAtOfferRequestArray(0).getExternalId());
        VisiblePurchasedOfferExtension gpglExtn = (VisiblePurchasedOfferExtension) po.getAtOfferRequestArray(
                0).getAttr();
        assertEquals(CHANGE_SERVICE_CONSTANTS.GOOD_TYPE_ADJ_GPGL, gpglExtn.getGoodType());
        assertEquals(CHANGE_SERVICE_CONSTANTS.PLAN_ID_ADJ_GPGL, gpglExtn.getPlanID());
    }

    @ParameterizedTest(
            name = "test_changeService_When_NewPromotion_GrantExists_ResetPromo_Then_CancelExistingPromo")
    @Tags(value = {
        @Tag("NewPromo"), @Tag("VER-707")
    })
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has Valid Base and Promo Offers.|"
                +"|When  |Api is called with new promotions. A promo with same grantCI already exists. ResetPrmo parameter is not N|"
                +"|Then  |Grant Offer for existing promo is cancelled.|"})
    // @formatter:on
    public void test_changeService_When_NewPromotion_GrantExists_ResetPromo_Then_CancelExistingPromo(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (chgReq, oldSvc) -> {
            td.printDescription();

            BigDecimal aocDelta = BigDecimal.valueOf(5);
            VisibleRequestChangeService request = (VisibleRequestChangeService) chgReq;
            String newSvc = request.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId();

            VisibleResponseChangeService response = new VisibleResponseChangeService();

            VisibleChangeServicePromo newPromo = request.getAtNewPromotionList(0);

            SubscriptionResponse subResp = CommonTestHelper.getSubscriptionResponse_LastMonth(
                    request.getSubscriptionExternalId(), List.of(oldSvc.toString()));
            MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                    subResp);

            emulateMtxResponseSubscription(api, subscription);

            MtxPurchasedOfferInfo promo = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, newPromo.getGrantOfferCI(), newPromo.getGrantAmount(),
                    newPromo.getGrantAmount(), BigDecimal.ZERO, false);
            long grantResourceId = promo.getResourceId();

            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    CommonTestHelper.updateVisibleResponseChangeServiceAdvice(
                            advice, request, subResp, aocDelta);

                    VisiblNextCycle nc = new VisiblNextCycle();
                    advice.setNextCycle(nc);

                    VisibleChangeServiceCredit csc = CommonTestHelper.getVisibleChangeServiceCredit(
                            request, grantResourceId);
                    advice.appendNewRedeemableCredits(csc);
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(newSvc);
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(newSvc);
            multiResPurchase.appendResponseList(purchaseResponse);
            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");

            doReturn(reverseOffers).when(instance).querySubscriptionOneTimeOffer(any(), any());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(
                        testInfo.getDisplayName() + StringUtils.SPACE + "multi.toJson(): "
                                + multi.toJson());
            });

            MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(0);
            MtxRequestSubscriberCancelOffer cancelReq = multiReq.getRequestList().stream().filter(
                    req1 -> MtxRequestSubscriberCancelOffer.class.getSimpleName().equalsIgnoreCase(
                            req1.getContainer().getName())).map(
                                    req1 -> (MtxRequestSubscriberCancelOffer) req1).findFirst().get();
            System.out.println(
                    testInfo.getDisplayName() + StringUtils.SPACE + "cancelReq.toJson(): "
                            + cancelReq.toJson());
            assertEquals(grantResourceId, cancelReq.getAtResourceIdArray(0).longValue());
        };
        String subscriptionExternalId = "123";

        VisibleRequestChangeService request = CommonTestHelper.getVisibleRequestChangeService(
                subscriptionExternalId, CI_EXTERNAL_IDS.PLUS3VIS23WB);
        CommonTestHelper.addNewGrantToVisibleRequestChangeService(
                request, CI_EXTERNAL_IDS.GENERIC_GRANT, "FIFTEENOFF", GENERIC_CONSTANTS.YES,
                BigDecimal.valueOf(375), BigDecimal.valueOf(15));
        pTests.test(request, CI_EXTERNAL_IDS.BASE3VIS23);
    }

    @ParameterizedTest(
            name = "test_changeService_When_NewPromotion_GrantExists_ResetPromo_Then_PurchaseNewPromo")
    @Tags(value = {
        @Tag("NewPromo"), @Tag("VER-707")
    })
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has Valid Base and Promo Offers.|"
                +"|When  |Api is called with new promotions. A promo with same grantCI already exists. ResetPrmo parameter is not N|"
                +"|Then  |Grant Offer is purchased with new grant amount.|"})
    // @formatter:on
    public void test_changeService_When_NewPromotion_GrantExists_ResetPromo_Then_PurchaseNewPromo(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (chgReq, oldSvc) -> {
            td.printDescription();

            BigDecimal aocDelta = BigDecimal.valueOf(5);
            VisibleRequestChangeService request = (VisibleRequestChangeService) chgReq;
            String newSvc = request.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId();

            VisibleResponseChangeService response = new VisibleResponseChangeService();

            VisibleChangeServicePromo newPromo = request.getAtNewPromotionList(0);

            SubscriptionResponse subResp = CommonTestHelper.getSubscriptionResponse_LastMonth(
                    request.getSubscriptionExternalId(), List.of(oldSvc.toString()));
            MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                    subResp);

            emulateMtxResponseSubscription(api, subscription);

            MtxPurchasedOfferInfo promo = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, newPromo.getGrantOfferCI(), newPromo.getGrantAmount(),
                    newPromo.getGrantAmount(), BigDecimal.ZERO, false);
            long grantResourceId = promo.getResourceId();

            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    CommonTestHelper.updateVisibleResponseChangeServiceAdvice(
                            advice, request, subResp, aocDelta);

                    VisiblNextCycle nc = new VisiblNextCycle();
                    advice.setNextCycle(nc);

                    VisibleChangeServiceCredit csc = CommonTestHelper.getVisibleChangeServiceCredit(
                            request, grantResourceId);
                    advice.appendNewRedeemableCredits(csc);
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(newSvc);
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(newSvc);
            multiResPurchase.appendResponseList(purchaseResponse);
            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");

            doReturn(reverseOffers).when(instance).querySubscriptionOneTimeOffer(any(), any());

            instance.changeBaseOfferService(request, response);

            argumentCaptor.getAllValues().forEach(multi -> {
                System.out.println(
                        testInfo.getDisplayName() + StringUtils.SPACE + "multi.toJson(): "
                                + multi.toJson());
            });

            MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(0);
            MtxRequestSubscriberPurchaseOffer purReq = multiReq.getRequestList().stream().filter(
                    req1 -> MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                            req1.getContainer().getName())).map(
                                    req1 -> (MtxRequestSubscriberPurchaseOffer) req1).findFirst().get();
            System.out.println(
                    testInfo.getDisplayName() + StringUtils.SPACE + "purReq.toJson(): "
                            + purReq.toJson());
            assertEquals(
                    request.getAtNewPromotionList(0).getGrantOfferCI(),
                    purReq.getAtOfferRequestArray(0).getExternalId());
            VisiblePurchasedOfferExtension attr = (VisiblePurchasedOfferExtension) purReq.getAtOfferRequestArray(
                    0).getAttr();
            assertEquals(
                    request.getAtNewPromotionList(0).getGrantAmount().intValue(),
                    attr.getChargeAmount().intValue());
        };
        String subscriptionExternalId = "123";

        VisibleRequestChangeService request = CommonTestHelper.getVisibleRequestChangeService(
                subscriptionExternalId, CI_EXTERNAL_IDS.PLUS3VIS23WB);
        CommonTestHelper.addNewGrantToVisibleRequestChangeService(
                request, CI_EXTERNAL_IDS.GENERIC_GRANT, "FIFTEENOFF", GENERIC_CONSTANTS.YES,
                BigDecimal.valueOf(375), BigDecimal.valueOf(15));
        pTests.test(request, CI_EXTERNAL_IDS.BASE3VIS23);
    }

    @ParameterizedTest(name = "test_changeService_When_RealignCycle_Then_ApiEventData")
    @Tags(value = {
        @Tag("NewPromo"), @Tag("VER-707")
    })
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has Valid Base Offer.|"
                +"|When  |Api is called to upgrade to Plus offer resulting in change of new offers cycle end date.|"
                +"|Then  |AnnualUpgradeCycleEndDate is set and sent in api event data.|"})
    // @formatter:on
    public void test_changeService_When_RealignCycle_Then_ApiEventData(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        @SuppressWarnings("rawtypes")
        TwoParameterTest pTests = (chgReq, oldSvc) -> {
            td.printDescription();
            BigDecimal aocDelta = BigDecimal.valueOf(150);
            VisibleRequestChangeService request = (VisibleRequestChangeService) chgReq;
            String newSvc = request.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId();
            VisibleCatalogItem newCi = new VisibleCatalogItem();
            newCi.setCatalogItemExternalId(newSvc.toString());
            newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(newSvc.toString()));
            request.getChangeOfferInfo().setNewCatalogItem(newCi);
            VisibleResponseChangeService response = new VisibleResponseChangeService();

            SubscriptionResponse subResp = CommonTestHelper.getSubscriptionResponse_LastMonth(
                    request.getSubscriptionExternalId(), List.of(oldSvc.toString()));
            MtxResponseSubscription sub = CommonTestHelper.getMtxResponseSubscription(subResp);

            emulateMtxResponseSubscription(api, sub);
            MtxTimestamp cycleEndDate = TestUtils.getFirstDateTimeOfNextMonth(sub.getTimeZone());

            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                    CommonTestHelper.updateVisibleResponseChangeServiceAdvice(
                            advice, request, subResp, aocDelta);
                    VisibleChangeCycle cc = advice.getChangeCycle();
                    cc.setCycleEndTime(cycleEndDate);

                    advice.setChangeCycle(cc);
                    return null;
                }
            }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

            MtxResponseMulti multiResPurchase = new MtxResponseMulti();
            multiResPurchase.setResult(0l);
            multiResPurchase.setResultText("OK");
            MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
            purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                    newCi.getCatalogItemExternalId());
            purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                    newCi.getCatalogItemExternalId());
            multiResPurchase.appendResponseList(purchaseResponse);
            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiResPurchase).when(instance).multiRequest(
                    any(), any(), argumentCaptor.capture());

            instance.changeBaseOfferService(request, response);

            System.out.println(
                    testInfo.getDisplayName() + StringUtils.SPACE + "multReq.toJson(): "
                            + argumentCaptor.getAllValues().get(0).toJson());
            VisibleApiEventData aed = (VisibleApiEventData) argumentCaptor.getAllValues().get(
                    0).getApiEventData();
            assertEquals(cycleEndDate.getTime(), aed.getAnnualUpgradeCycleEndDate());

        };
        VisibleRequestChangeService request = CommonTestHelper.getVisibleRequestChangeService(
                "123", CI_EXTERNAL_IDS.PLUS3ANNUAL);
        pTests.test(request, CI_EXTERNAL_IDS.BASE3ANNUAL);
        VisibleRequestChangeService request1 = request;
        VisibleApiEventData aed = new VisibleApiEventData();
        aed.setOrderId("O1234");
        request1.setApiEventData(aed);
        pTests.test(request, CI_EXTERNAL_IDS.BASE3ANNUAL);

    }

    @SuppressWarnings({
        "rawtypes"
    })
    @Tag("VER-714")
    @Tag("GlobalPass")
    @ParameterizedTest(
            name = "test_changeService_Given_AnnualGP_When_ImmediateToAnnualGP_Then_AdjustGlobalPass")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription with PLUS3VIS23WBA or PLUS25MIDAnnual.|"
                +"|When  |Call to upgrade to PLUS25HIAnnual. CSA returns correct response.|"
                +"|Then  |GPCount should be adjusted. Sub should get 1 gp instead of 2 per month.|"
                +"|Comments |Plus23Annual to Plus25HiAnnual is effective immediate|"})
    // @formatter:on
    public void test_changeService_Given_AnnualGP_When_ImmediateToAnnualGP_Then_AdjustGlobalPass(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String subscriptionExternalId = "123";
        BigDecimal aocDelta = BigDecimal.valueOf(5);
        VisibleRequestChangeService request = CommonTestHelper.getVisibleRequestChangeService(
                subscriptionExternalId, CI_EXTERNAL_IDS.PRO25ANNUAL);

        BigDecimal oldGp = BigDecimal.valueOf(7); // anything below 12
        SubscriptionResponse subResp = CommonTestHelper.getSubscriptionResponse_LastMonth(
                request.getSubscriptionExternalId(), List.of(CI_EXTERNAL_IDS.PLUS3ANNUAL));
        MtxResponseSubscription subBefore = CommonTestHelper.getMtxResponseSubscription(subResp);

        // MtxResponseSubscription subBefore = CommonTestHelper.getMtxResponseSubscription(
        // List.of(
        // request.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId()));
        subBefore.getBalanceArray().forEach(bi -> {
            if (bi.getName().equalsIgnoreCase(BALANCE_NAMES.GLOBAL_PASS)) {
                bi.setAmount(oldGp);
            }
        });
        BigDecimal unusedGpMonths = BigDecimal.valueOf(9);
        BigDecimal newGpCsa = unusedGpMonths.add(oldGp);
        BigDecimal newGpOOB = BigDecimal.valueOf(24).add(oldGp);
        MtxResponseSubscription subAfter = CommonTestHelper.getMtxResponseSubscription(
                List.of(
                        request.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId()));
        subAfter.getBalanceArray().forEach(bi -> {
            if (bi.getName().equalsIgnoreCase(BALANCE_NAMES.GLOBAL_PASS)) {
                bi.setAmount(newGpOOB);
            }
        });

        VisibleResponseChangeService response = new VisibleResponseChangeService();
        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                CommonTestHelper.updateVisibleResponseChangeServiceAdvice(
                        advice, request, subResp, aocDelta, oldGp, newGpCsa);
                return null;
            }
        }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

        MtxResponseMulti multiResPurchase = new MtxResponseMulti();
        multiResPurchase.setResult(0l);
        multiResPurchase.setResultText("OK");
        MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
        purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                request.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId());
        purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                request.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId());
        multiResPurchase.appendResponseList(purchaseResponse);

        doReturn(subBefore).doReturn(subAfter).when(api).subscriptionQuery(any());

        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResPurchase).when(instance).multiRequest(
                any(), any(), argumentCaptor.capture());

        instance.changeBaseOfferService(request, response);

        argumentCaptor.getAllValues().forEach(multi -> {
            System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + multi.toJson());
        });

        MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(1);
        MtxRequestSubscriberAdjustBalance adjReq = new MtxRequestSubscriberAdjustBalance(
                multiReq.getAtRequestList(0));

        System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + adjReq.toJson());
        assertEquals(MATRIXX_CONSTANTS.BALANCE_ADJUSTMENT_TYPE_CREDIT, adjReq.getAdjustType());
        assertEquals(newGpOOB.subtract(newGpCsa).intValue(), adjReq.getAmount().intValue());
    }

    @SuppressWarnings("rawtypes")
    @Tag("VER-714")
    @Tag("GlobalPass")
    @ParameterizedTest(name = "test_changeService_When_ChangNextMonth_Then_NoGlobalPassAdjust")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription with free global pass.|"
                +"|When  |Change effective next month. CSA returns correct response.|"
                +"|Then  |GPCount should NOT be adjusted|"
                +"|Comments |Plus23Annual to Plus25Hi is effective next cycle|"})
    // @formatter:on
    public void test_changeService_When_ChangNextMonth_Then_NoGlobalPassAdjust(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String subscriptionExternalId = "123";
        BigDecimal aocDelta = BigDecimal.valueOf(5);
        VisibleRequestChangeService request = CommonTestHelper.getVisibleRequestChangeService(
                subscriptionExternalId, CI_EXTERNAL_IDS.PRO25);

        SubscriptionResponse subResp = CommonTestHelper.getSubscriptionResponse(
                request.getSubscriptionExternalId(), List.of(
                        request.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId()));
        MtxResponseSubscription subBefore = CommonTestHelper.getMtxResponseSubscription(subResp);

        BigDecimal oldGp = BigDecimal.valueOf(3);
        // MtxResponseSubscription subBefore = CommonTestHelper.getMtxResponseSubscription(
        // List.of(
        // request.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId()));
        subBefore.getBalanceArray().forEach(bi -> {
            if (bi.getName().equalsIgnoreCase(BALANCE_NAMES.GLOBAL_PASS)) {
                // Set value to max so that adjustments would be required.
                bi.setAmount(oldGp);
            }
        });
        BigDecimal newGpCsa = BigDecimal.valueOf(1).add(oldGp);
        BigDecimal newGpAoc = BigDecimal.valueOf(2).add(oldGp);
        MtxResponseSubscription subAfter = CommonTestHelper.getMtxResponseSubscription(
                List.of(
                        request.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId()));
        subAfter.getBalanceArray().forEach(bi -> {
            if (bi.getName().equalsIgnoreCase(BALANCE_NAMES.GLOBAL_PASS)) {
                // Set value to max so that adjustments would be required.
                bi.setAmount(newGpAoc);
            }
        });

        VisibleResponseChangeService response = new VisibleResponseChangeService();
        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                CommonTestHelper.updateVisibleResponseChangeServiceAdvice(
                        advice, request, subResp, aocDelta, oldGp, newGpCsa);
                return null;
            }
        }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

        MtxResponseMulti multiResPurchase = new MtxResponseMulti();
        multiResPurchase.setResult(0l);
        multiResPurchase.setResultText("OK");
        MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
        purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                request.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId());
        purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                request.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId());
        multiResPurchase.appendResponseList(purchaseResponse);

        doReturn(subBefore).doReturn(subAfter).when(api).subscriptionQuery(any());

        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResPurchase).when(instance).multiRequest(
                any(), any(), argumentCaptor.capture());

        instance.changeBaseOfferService(request, response);

        argumentCaptor.getAllValues().forEach(multi -> {
            System.out.println(testInfo.getDisplayName() + StringUtils.SPACE + multi.toJson());
        });

        MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(1);
        List<String> mdcs = multiReq.getRequestList().stream().map(req -> req.getMdcName()).collect(
                Collectors.toList());
        assertFalse(mdcs.contains(MtxRequestSubscriberAdjustBalance.class.getSimpleName()));
    }

    @SuppressWarnings("rawtypes")
    @ParameterizedTest(name = "test_getChangeService_When_PreactiveInAdvicer_Then_CancelPreactive")
    @Tag("VER-846")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscriber has preactive base offer. Preactive offer will be active on or before next bill cycle.|"
                +"|When |CSA provides preactive offer in response.|"
                +"|Then |ChangeService should cancel preactive offer.|"})
    // @formatter:on
    public void test_getChangeService_When_PreactiveInAdvice_Then_CancelPreactive(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        BigDecimal aocDelta = BigDecimal.ZERO;
        String activeOffer = CI_EXTERNAL_IDS.BASE6MONTH25;
        String preactiveOffer = CI_EXTERNAL_IDS.BASE3VIS23;
        VisibleRequestChangeService request = CommonTestHelper.getVisibleRequestChangeService(
                "12345", CI_EXTERNAL_IDS.PRO25);

        VisibleResponseChangeService response = new VisibleResponseChangeService();
        SubscriptionResponse subResp = CommonTestHelper.getSubscriptionResponse_LastMonth(
                request.getSubscriptionExternalId(), List.of(activeOffer), List.of(preactiveOffer));
        MtxResponseSubscription sub = CommonTestHelper.getMtxResponseSubscription(subResp);

        Map<String, Object> resourceIdMap = new HashMap<String, Object>();
        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponseChangeServiceAdvice advice = (VisibleResponseChangeServiceAdvice) args[1];
                CommonTestHelper.updateVisibleResponseChangeServiceAdvice(
                        advice, request, subResp, aocDelta);
                resourceIdMap.put("CID", advice.getPreactiveCatalogItem().getCatalogItemExternalId());
                resourceIdMap.put("RID", advice.getPreactiveCatalogItem().getResourceId());
                return null;
            }
        }).when(adviceInstance).getAdviceForChangeService(any(), any(), any());

        MtxResponseMulti multiResPurchase = new MtxResponseMulti();
        multiResPurchase.setResult(0l);
        multiResPurchase.setResultText("OK");
        MtxResponsePurchase purchaseResponse = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.CHANGE_SERVICE + "MtxResponsePurchase.json");
        purchaseResponse.getAtPurchaseInfoArray(0).setCatalogItemExternalId(
                request.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId());
        purchaseResponse.getAtPurchaseInfoArray(0).setExternalId(
                request.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId());
        multiResPurchase.appendResponseList(purchaseResponse);

        doReturn(sub).when(api).subscriptionQuery(any());

        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResPurchase).when(instance).multiRequest(
                any(), any(), argumentCaptor.capture());

        instance.changeBaseOfferService(request, response);

        argumentCaptor.getAllValues().forEach(multi -> {
            printUnitTest(" MultiReq: " + multi.toJson());
        });

        MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(0);
        MtxRequestSubscriberCancelOffer canActiveReq = new MtxRequestSubscriberCancelOffer(
                multiReq.getAtRequestList(0));
        MtxRequestSubscriberCancelOffer canPreactiveReq = new MtxRequestSubscriberCancelOffer(
                multiReq.getAtRequestList(1));

        printUnitTest(canActiveReq.toJson());
        printUnitTest(canPreactiveReq.toJson());
        assertEquals(resourceIdMap.get("RID"),canPreactiveReq.getAtResourceIdArray(0));
    }

    @Test
    @Disabled
    @Tag("VER-210")
    public void test_changeService_When_VER210_OpenIssues(TestInfo testInfo) throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Grant offer cancellation from change service is interim solution"
        };
        td.comments = new String[] {
            "If there is a residual (partially used) connsumable balance, it will not be touched.",
            "Consumable balance will be moved to grant only using onetimecancellable offers",
            "Consumable balace will be moved to grant only if next months payment is made."
        };
        fail();
    }

    private void printUnitTest(Object msg) {
        System.out.println(testInfo.getDisplayName() + ":" + msg);
    }
}
