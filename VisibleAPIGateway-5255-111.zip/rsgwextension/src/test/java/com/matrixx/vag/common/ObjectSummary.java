package com.matrixx.vag.common;

import java.util.Map;

@FunctionalInterface  
public interface ObjectSummary {
	 Map<String, Object> get(Object p1) throws Exception; 
}
