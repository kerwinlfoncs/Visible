package com.matrixx.vag.subscriber.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import org.apache.commons.lang3.StringUtils;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;

import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.MtxApiEventDataExtension;
import com.matrixx.datacontainer.mdc.MtxRequestMulti;
import com.matrixx.datacontainer.mdc.MtxRequestPricingQueryStatus;
import com.matrixx.datacontainer.mdc.MtxResponseMulti;
import com.matrixx.datacontainer.mdc.VisibleApiEventData;
import com.matrixx.datacontainer.mdc.VisibleMultiRequest;
import com.matrixx.datacontainer.mdc.VisibleResponseMulti;
import com.matrixx.vag.util.MDCTest;

public class ExecuteMultiRequestTest extends MDCTest {

	@Spy
	@InjectMocks
	private final SubscriberService instance = new SubscriberService();

	@Mock
	private SubscriberManagementApi api;

    @Rule
    public TestName testName = new TestName();
    
    @Rule 
    public MockitoRule rule = MockitoJUnit.rule();
    
	public void setUp() throws Exception {}
	
	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_executeMultiRequest_When_ApiEventData_IsNotEmpty_Then_ApiEventData_SentToEngine() throws Exception {
		System.out.println("Test Case for https://jira.unico.com.au/browse/MTXVER2-77 https://matrixxservices.atlassian.net/browse/VER-56");
		String testLoggingKey = getTestLoggingKey(testName.getMethodName());
		
		VisibleMultiRequest input = new VisibleMultiRequest();
		
		VisibleApiEventData extn = new VisibleApiEventData();
		extn.setOrderId("12345");
		input.setApiEventData(extn);
		
		MtxRequestPricingQueryStatus statusReq = new MtxRequestPricingQueryStatus();
		input.appendRequestList(statusReq);
		
		MtxResponseMulti multiRes = new MtxResponseMulti();
		multiRes.setResult(0l);
		multiRes.setResultText("OK");
		
		VisibleResponseMulti output = new VisibleResponseMulti();
		
		// mocks
		doReturn("").when(instance).getRoute(any());		
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

		// method to test
		instance.executeMultiRequest(input, output);
		System.out.println(testLoggingKey+StringUtils.SPACE+ argumentCaptor.getValue().toJson());
		// Assertions here.
		assertEquals(
				MtxApiEventDataExtension.class.getSimpleName()+" should be present.",
				extn.getMdcName(),
				argumentCaptor.getValue().getApiEventData().getMdcName());
		assertEquals(extn.getOrderId(),
				((VisibleApiEventData)argumentCaptor.getValue().getApiEventData()).getOrderId()	);
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_executeMultiRequest_When_ApiEventData_IsEmpty_Then_ApiEventData_NotSentToEngine() throws Exception {
		System.out.println("Test Case for https://jira.unico.com.au/browse/MTXVER2-77 https://matrixxservices.atlassian.net/browse/VER-56");
		String testLoggingKey = getTestLoggingKey(testName.getMethodName());
		
		VisibleMultiRequest input = new VisibleMultiRequest();
		
		VisibleApiEventData extn = new VisibleApiEventData();
		input.setApiEventData(extn);
		
		MtxRequestPricingQueryStatus statusReq = new MtxRequestPricingQueryStatus();
		input.appendRequestList(statusReq);
		
		MtxResponseMulti multiRes = new MtxResponseMulti();
		multiRes.setResult(0l);
		multiRes.setResultText("OK");
		
		VisibleResponseMulti output = new VisibleResponseMulti();
		
		// mocks
		doReturn("").when(instance).getRoute(any());		
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

		// method to test
		instance.executeMultiRequest(input, output);
		System.out.println(testLoggingKey+StringUtils.SPACE+ argumentCaptor.getValue().toJson());
		// Assertions here.
		assertEquals(
				VisibleApiEventData.class.getSimpleName()+" should be present.",
				VisibleApiEventData.class.getSimpleName(),
				argumentCaptor.getValue().getApiEventData().getMdcName());

		assertEquals(
				VisibleApiEventData.class.getSimpleName()+" should be empty.",
				0,
				argumentCaptor.getValue().getApiEventData().getContainer().getFields()==null?0:argumentCaptor.getValue().getApiEventData().getContainer().getFields().size());
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_executeMultiRequest_When_ApiEventData_IsMissing_Then_ApiEventData_NotSentToEngine() throws Exception {
		System.out.println("Test Case for https://jira.unico.com.au/browse/MTXVER2-77 https://matrixxservices.atlassian.net/browse/VER-56");
		String testLoggingKey = getTestLoggingKey(testName.getMethodName());
		
		VisibleMultiRequest input = new VisibleMultiRequest();
		
		MtxRequestPricingQueryStatus statusReq = new MtxRequestPricingQueryStatus();
		input.appendRequestList(statusReq);
		
		MtxResponseMulti multiRes = new MtxResponseMulti();
		multiRes.setResult(0l);
		multiRes.setResultText("OK");
		
		VisibleResponseMulti output = new VisibleResponseMulti();
		
		// mocks
		doReturn("").when(instance).getRoute(any());		
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

		// method to test
		instance.executeMultiRequest(input, output);
		System.out.println(testLoggingKey+StringUtils.SPACE+ argumentCaptor.getValue().toJson());
		// Assertions here.
		assertEquals(
				MtxApiEventDataExtension.class.getSimpleName()+" should not be present.",
				null,
				argumentCaptor.getValue().getApiEventData());
	}

}
