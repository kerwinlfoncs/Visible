package com.matrixx.vag.sac.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.test.util.ReflectionTestUtils;

import com.matrixx.datacontainer.MtxObjectId;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.MtxMsg;
import com.matrixx.datacontainer.mdc.MtxPaymentMethodInfo;
import com.matrixx.datacontainer.mdc.MtxRequestGroupModify;
import com.matrixx.datacontainer.mdc.MtxRequestMulti;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberAddPaymentMethod;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberModifyPaymentMethod;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriptionModify;
import com.matrixx.datacontainer.mdc.MtxResponse;
import com.matrixx.datacontainer.mdc.MtxResponseAdd;
import com.matrixx.datacontainer.mdc.MtxResponseClientToken;
import com.matrixx.datacontainer.mdc.MtxResponseGroup;
import com.matrixx.datacontainer.mdc.MtxResponseMulti;
import com.matrixx.datacontainer.mdc.MtxResponsePaymentMethodInfo;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.MtxSubscriberSearchData;
import com.matrixx.datacontainer.mdc.SacModifyRequest;
import com.matrixx.datacontainer.mdc.SacModifyResponse;
import com.matrixx.datacontainer.mdc.SacResponse;
import com.matrixx.datacontainer.mdc.VisibleCAGroupExtension;
import com.matrixx.datacontainer.mdc.VisibleRequestCaLink;
import com.matrixx.datacontainer.mdc.VisibleRequestCaUnlink;
import com.matrixx.datacontainer.mdc.VisibleRequestSacSetUpPayment;
import com.matrixx.datacontainer.mdc.VisibleResponseCaLink;
import com.matrixx.datacontainer.mdc.VisibleResponseCaUnlink;
import com.matrixx.datacontainer.mdc.VisibleResponseSacSetUpPayment;
import com.matrixx.datacontainer.mdc.VisibleSubscriberExtension;
import com.matrixx.platform.JsonObject;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.amq.client.ActiveMQClient;
import com.matrixx.vag.common.Constants.GROUP_CONSTANTS;
import com.matrixx.vag.common.Constants.LOG_MESSAGES;
import com.matrixx.vag.common.Constants.MATRIXX_CONSTANTS;
import com.matrixx.vag.common.Constants.NOTIFICATION_CONSTANTS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.TestConstants.DATA_DIR;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.SacServiceException;
import com.matrixx.vag.util.MDCTest;

public class SacServiceTest extends MDCTest {

    @Spy
    @InjectMocks
    private SacService instance = new SacService(true);
    @Mock
    private SubscriberManagementApi api;
    private TestInfo testInfo;

    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        instance = Mockito.spy(new SacService(true));
        MockitoAnnotations.openMocks(this);
        this.testInfo = testInfo;
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_sacDeletePaymentOnResourceId_Success() throws Exception {
        SacService sacServiceSpy = Mockito.spy(new SacService(true));
        String objectId = "0-5-1-219";
        long resourceId = 2;
        SacResponse response = new SacResponse();
        MtxResponsePaymentMethodInfo paymentInfo = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentMethodInfo.class,
                "src/test/resources/data/sacService/MtxResponsePaymentMethodInfo_Current_success.json");

        System.out.println(paymentInfo.toJson());

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, "src/test/resources/data/sacService/MtxResponseSubscription.json");

        MtxResponse deletePayRes = new MtxResponse();
        deletePayRes.setResult(0l);
        deletePayRes.setResultText("OK");

        SacResponse sacRes = new SacResponse();
        sacRes.setResult(0l);
        sacRes.setResultText("OK");

        MtxMsg mtxmsg = new MtxMsg();
        mtxmsg.setResult((long) 200);
        mtxmsg.setResultText("OK");

        doReturn("").when(sacServiceSpy).getRoute(any());
        doReturn(paymentInfo).when(sacServiceSpy).queryPaymentMethodInfo(
                any(), any(), argThat((MtxSubscriberSearchData sd) -> true));
        doReturn(deletePayRes).when(sacServiceSpy).doSubscriberRemovePaymentMethod(
                any(), any(), any());
        doReturn(subscription).when(sacServiceSpy).querySubscriptionDataByObjectId(any(), any());
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.MTX_SUCCESS);
        qResp.setResultText("OK");
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(() -> ActiveMQClient.sendSacMessage(any(), any())).thenReturn(qResp);
            sacServiceSpy.sacDeletePaymentOnResourceId(response, objectId, resourceId);
        }

        assertEquals(sacRes.getResult(), response.getResult());
        assertEquals(sacRes.getResultText(), response.getResultText());

        assertEquals(200, response.getstatusCode().intValue());
        assertEquals("OK", response.getstatus());
    }

    @Test
    public void test_sacDeletePaymentOnResourceId_When_PaymentMethodHasName_Then_PaymentMethodNameInNotification()
            throws Exception {
        SacService sacServiceSpy = Mockito.spy(new SacService(true));
        String objectId = "0-5-1-219";
        long resourceId = 13;
        SacResponse response = new SacResponse();
        MtxResponsePaymentMethodInfo paymentInfo = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentMethodInfo.class,
                "src/test/resources/data/sacService/MtxResponsePaymentMethodInfo_Current_success.json");

        System.out.println(paymentInfo.toJson());

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, "src/test/resources/data/sacService/MtxResponseSubscription.json");

        MtxResponse deletePayRes = new MtxResponse();
        deletePayRes.setResult(0l);
        deletePayRes.setResultText("OK");

        MtxMsg mtxmsg = new MtxMsg();
        mtxmsg.setResult((long) 200);
        mtxmsg.setResultText("OK");

        doReturn("").when(sacServiceSpy).getRoute(any());
        doReturn(paymentInfo).when(sacServiceSpy).queryPaymentMethodInfo(
                any(), any(), argThat((MtxSubscriberSearchData sd) -> true));
        doReturn(deletePayRes).when(sacServiceSpy).doSubscriberRemovePaymentMethod(
                any(), any(), any());
        doReturn(subscription).when(sacServiceSpy).querySubscriptionDataByObjectId(any(), any());

        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.MTX_SUCCESS);
        qResp.setResultText("OK");
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(() -> ActiveMQClient.sendSacMessage(any(), any())).thenReturn(qResp);
            sacServiceSpy.sacDeletePaymentOnResourceId(response, objectId, resourceId);
        }

        String expectedPaymentMenthodName = "";
        for (MtxPaymentMethodInfo pmi : paymentInfo.getPaymentMethodInfoList()) {
            if (pmi.getResourceId().longValue() == resourceId) {
                expectedPaymentMenthodName = pmi.getName();
            }
        }

        @SuppressWarnings("unchecked")
        HashMap<String, Object> notificationMsg = CommonTestHelper.getJsonFromString(
                HashMap.class,
                ReflectionTestUtils.getField(sacServiceSpy, "notificationMsg").toString());
        assertEquals(
                expectedPaymentMenthodName,
                notificationMsg.get(
                        AppPropertyProvider.getInstance().getString(
                                NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_PAYMENT_METHOD_NAME_KEY)));
    }

    @Test
    @SuppressWarnings("unchecked")
    public void test_sacDeletePaymentOnResourceId_When_MissingPaymentMethodName_Then_DefaultStringInNotification()
            throws Exception {
        SacService sacServiceSpy = Mockito.spy(new SacService(true));
        String objectId = "0-5-1-219";
        long resourceId = 13;
        SacResponse response = new SacResponse();

        String paymentInfoString = new String(
                Files.readAllBytes(
                        Paths.get(
                                "src/test/resources/data/sacService/MtxResponsePaymentMethodInfo_Current_success.json")));

        JsonObject paymentInfoJson = new JsonObject();
        paymentInfoJson.parse(paymentInfoString);
        paymentInfoJson.getArray("PaymentMethodInfoList").forEach(pmi -> {
            if (((JsonObject) pmi).getString("ResourceId").equals(resourceId + "")) {
                // Remove name node from payment method
                ((JsonObject) pmi).remove("Name");
            }
        });

        MtxResponsePaymentMethodInfo paymentInfo = CommonTestHelper.parseJsonMessage(
                MtxResponsePaymentMethodInfo.class, paymentInfoJson.toString());

        System.out.println(paymentInfo.toJson());

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, "src/test/resources/data/sacService/MtxResponseSubscription.json");

        MtxResponse deletePayRes = new MtxResponse();
        deletePayRes.setResult(0l);
        deletePayRes.setResultText("OK");

        MtxMsg mtxmsg = new MtxMsg();
        mtxmsg.setResult((long) 200);
        mtxmsg.setResultText("OK");

        doReturn("").when(sacServiceSpy).getRoute(any());
        doReturn(paymentInfo).when(sacServiceSpy).queryPaymentMethodInfo(
                any(), any(), argThat((MtxSubscriberSearchData sd) -> true));
        doReturn(deletePayRes).when(sacServiceSpy).doSubscriberRemovePaymentMethod(
                any(), any(), any());
        doReturn(subscription).when(sacServiceSpy).querySubscriptionDataByObjectId(any(), any());

        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.MTX_SUCCESS);
        qResp.setResultText("OK");
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(() -> ActiveMQClient.sendSacMessage(any(), any())).thenReturn(qResp);
            sacServiceSpy.sacDeletePaymentOnResourceId(response, objectId, resourceId);
        }

        String expectedPaymentMenthodName = "No paymentMethodName";

        HashMap<String, Object> notificationMsg = CommonTestHelper.getJsonFromString(
                HashMap.class,
                ReflectionTestUtils.getField(sacServiceSpy, "notificationMsg").toString());
        assertEquals(
                expectedPaymentMenthodName,
                notificationMsg.get(
                        AppPropertyProvider.getInstance().getString(
                                NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_PAYMENT_METHOD_NAME_KEY)));
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_sacDeletePaymentOnResourceId_Given_SubscriberPresent_When_PaymentMethodAbasent_Then_Exception()
            throws Exception {
        SacService sacServiceSpy = Mockito.spy(new SacService(true));
        String objectId = "0-1-5-521";
        long resourceId = 2;
        SacResponse response = new SacResponse();

        MtxResponsePaymentMethodInfo paymentInfo = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentMethodInfo.class,
                DATA_DIR.SAC + "MtxResponsePaymentMethodInfo_Current_success.json");

        MtxResponseSubscription subscriber = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class, DATA_DIR.SAC + "MtxResponseSubscriber.json");

        MtxResponse deletePayRes = CommonTestHelper.loadJsonMessage(
                MtxResponse.class, DATA_DIR.SAC + "MtxResponse_Remove_PaymentMethodNotExist.json");

        SacResponse sacRes = new SacResponse();
        sacRes.setResult(0l);
        sacRes.setResultText("OK");
        doReturn("").when(sacServiceSpy).getRoute(any());
        doReturn(paymentInfo).when(sacServiceSpy).queryPaymentMethodInfo(
                any(), any(), argThat((MtxSubscriberSearchData sd) -> true));
        doReturn(deletePayRes).when(sacServiceSpy).doSubscriberRemovePaymentMethod(
                any(), any(), any());
        doReturn(subscriber).when(sacServiceSpy).querySubscriptionDataByObjectId(any(), any());

        Exception exception = assertThrows(
                SacServiceException.class,
                () -> sacServiceSpy.sacDeletePaymentOnResourceId(response, objectId, resourceId));
        exception.printStackTrace();
        assertTrue(
                exception.getMessage().contains(
                        "Failed to delete payment  - Payment method specified for removal does not exist."));

        System.out.println(sacRes.toJson());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_sacDeletePaymentOnResourceId_Given_ApiCalled_When_SubscriberNotFound_Then_Exception()
            throws Exception {
        SacService sacServiceSpy = Mockito.spy(new SacService(true));
        String objectId = "0-5-1-219";
        long resourceId = 2;
        SacResponse response = new SacResponse();

        MtxResponsePaymentMethodInfo paymentInfo = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentMethodInfo.class,
                DATA_DIR.SAC + "MtxResponsePaymentMethodInfo_Current_success.json");

        doReturn("").when(sacServiceSpy).getRoute(any());
        // doReturn(paymentInfo).when(sacServiceSpy).queryPaymentMethodInfo(any(), any(), any());
        doReturn(paymentInfo).when(instance).queryPaymentMethodInfo(
                any(), any(), argThat((MtxSubscriberSearchData sd) -> true));

        doReturn(null).when(sacServiceSpy).querySubscriptionDataByObjectId(any(), any());

        doThrow(
                new SacServiceException(
                        21L,
                        "Failed to query subscriber - Incorrect object type for this operation (expected Subscriber)")).when(
                                sacServiceSpy).validateResponse(any(), any(), any());

        Exception exception = assertThrows(
                SacServiceException.class,
                () -> sacServiceSpy.sacDeletePaymentOnResourceId(response, objectId, resourceId));
        exception.printStackTrace();
        assertTrue(
                exception.getMessage().contains(
                        "Failed to query subscriber - Incorrect object type for this operation (expected Subscriber)"));
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_sacDeletePaymentOnResourceId_Fail() throws Exception {
        SacService sacServiceSpy = Mockito.spy(new SacService(true));
        String objectId = "0-5-1-219";
        long resourceId = 2;
        SacResponse response = new SacResponse();
        MtxResponsePaymentMethodInfo paymentInfo = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentMethodInfo.class,
                DATA_DIR.SAC + "MtxResponsePaymentMethodInfo_success.json");
        System.out.println(paymentInfo.toJson());
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, "src/test/resources/data/sacService/MtxResponseSubscription.json");

        MtxResponse deletePayementMultiErrRes = new MtxResponse();
        deletePayementMultiErrRes.setResult(11l);
        deletePayementMultiErrRes.setResultText("NOTOK");

        MtxMsg mtxmsg = new MtxMsg();
        mtxmsg.setResult((long) 200);
        mtxmsg.setResultText("OK");

        doReturn("").when(sacServiceSpy).getRoute(any());
        doReturn(subscription).when(sacServiceSpy).querySubscriptionDataByObjectId(any(), any());
        doReturn(paymentInfo).when(sacServiceSpy).queryPaymentMethodInfo(
                any(), any(), argThat((MtxSubscriberSearchData sd) -> true));
        Mockito.doReturn(deletePayementMultiErrRes).when(
                sacServiceSpy).doSubscriberRemovePaymentMethod(any(), any(), any());

        Exception exception = assertThrows(
                SacServiceException.class,
                () -> sacServiceSpy.sacDeletePaymentOnResourceId(response, objectId, resourceId));
        exception.printStackTrace();
        assertTrue(exception.getMessage().contains("Failed to delete payment"));
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_sacAddPayment_New_Success() throws Exception {
        SacService sacServiceSpy = Mockito.spy(new SacService(true));
        String objectId = "0-5-1-219";
        String customerId = "167474901";
        String nonce = "fake-valid-nonce";
        SacResponse response = new SacResponse();
        MtxMsg mtxmsg = new MtxMsg();
        mtxmsg.setResult((long) 200);
        mtxmsg.setResultText("OK");

        MtxResponseSubscription subscriber = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                "src/test/resources/data/sacService/MtxResponseSubscriber_AddPayment.json");

        MtxResponsePaymentMethodInfo paymentMethodInfo = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentMethodInfo.class,
                "src/test/resources/data/sacService/MtxResponsePaymentMethodInfo_success.json");
        MtxResponseAdd addpaymentResp = CommonTestHelper.loadJsonMessage(
                MtxResponseAdd.class,
                "src/test/resources/data/sacService/MtxResponseAdd_Success.json");

        doReturn(subscriber).when(sacServiceSpy).querySubscriptionDataByObjectId(any(), any());
        doReturn(paymentMethodInfo).when(sacServiceSpy).getPaymentMethodInfo(any(), any(), any());
        ArgumentCaptor<MtxRequestSubscriberAddPaymentMethod> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestSubscriberAddPaymentMethod.class);
        doReturn(addpaymentResp).when(sacServiceSpy).doSubscriberAddPaymentMethod(
                any(), any(), argumentCaptor.capture());
        Mockito.doReturn("").when(sacServiceSpy).getRoute(any());

        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.MTX_SUCCESS);
        qResp.setResultText("OK");
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(() -> ActiveMQClient.sendSacMessage(any(), any())).thenReturn(qResp);
            sacServiceSpy.sacAddPayment(response, objectId, customerId, nonce);
        }

        MtxRequestSubscriberAddPaymentMethod request = argumentCaptor.getValue();
        assertEquals(nonce, request.getPaymentGatewayOneTimeToken());
        assertEquals(customerId, request.getPaymentGatewayUserId());
        assertEquals("0", response.getResult().toString());
        assertEquals("OK", response.getResultText());
        assertEquals("12", response.getresult().getresourceId().toString());
        assertEquals("CreditCard null_Visa_1881_12/2020", response.getresult().getname());

        assertEquals(200, response.getstatusCode().intValue());
        assertEquals("OK", response.getstatus());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_sacAddPayment_New_Error_SubscriberRes() throws Exception {
        SacService sacServiceSpy = Mockito.spy(new SacService());
        String objectId = "0-5-1-219";
        String customerId = "167474901";
        String nonce = "fake-valid-nonce";
        SacResponse response = new SacResponse();
        MtxMsg mtxmsg = new MtxMsg();
        mtxmsg.setResult((long) 200);
        mtxmsg.setResultText("OK");

        MtxResponseSubscription subscriber = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                "src/test/resources/data/sacService/MtxResponseSubscriber_Error.json");

        doReturn("").when(sacServiceSpy).getRoute(any());
        doReturn(subscriber).when(sacServiceSpy).querySubscriptionDataByObjectId(any(), any());

        Exception exception = assertThrows(
                SacServiceException.class,
                () -> sacServiceSpy.sacAddPayment(response, objectId, customerId, nonce));
        exception.printStackTrace();
        assertTrue(exception.getMessage().contains(LOG_MESSAGES.LOG_FAILED_TO_QUERY_SUBSCRIBER));
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_sacAddPayment_New_Error_getPaymentMethodInfo() throws Exception {
        SacService sacServiceSpy = Mockito.spy(new SacService(true));
        String objectId = "0-5-1-219";
        String customerId = "167474901";
        String nonce = "fake-valid-nonce";
        SacResponse response = new SacResponse();
        MtxMsg mtxmsg = new MtxMsg();
        mtxmsg.setResult((long) 200);
        mtxmsg.setResultText("OK");

        MtxResponseSubscription subscriber = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                "src/test/resources/data/sacService/MtxResponseSubscriber_AddPayment.json");

        MtxResponsePaymentMethodInfo paymentMethodInfo = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentMethodInfo.class,
                "src/test/resources/data/sacService/MtxResponsePaymentMethodInfo_Failed.json");
        MtxResponseAdd addpaymentResp = CommonTestHelper.loadJsonMessage(
                MtxResponseAdd.class,
                "src/test/resources/data/sacService/MtxResponseAdd_Success.json");

        doReturn(subscriber).when(sacServiceSpy).querySubscriptionDataByObjectId(any(), any());
        doReturn(paymentMethodInfo).when(sacServiceSpy).getPaymentMethodInfo(any(), any(), any());
        ArgumentCaptor<MtxRequestSubscriberAddPaymentMethod> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestSubscriberAddPaymentMethod.class);
        doReturn(addpaymentResp).when(sacServiceSpy).doSubscriberAddPaymentMethod(
                any(), any(), argumentCaptor.capture());
        Mockito.doReturn("").when(sacServiceSpy).getRoute(any());
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.MTX_SUCCESS);
        qResp.setResultText("OK");
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(() -> ActiveMQClient.sendSacMessage(any(), any())).thenReturn(qResp);
            sacServiceSpy.sacAddPayment(response, objectId, customerId, nonce);
        }
        MtxRequestSubscriberAddPaymentMethod request = argumentCaptor.getValue();
        assertEquals(nonce, request.getPaymentGatewayOneTimeToken());
        assertEquals(customerId, request.getPaymentGatewayUserId());
        assertEquals("0", response.getResult().toString());
        assertEquals("OK", response.getResultText());
        assertEquals("12", response.getresult().getresourceId().toString());
        assertNull(response.getresult().getname());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_sacAddPayment_New_ResourceIdNotFound_getPaymentMethodInfo() throws Exception {
        SacService sacServiceSpy = Mockito.spy(new SacService(true));
        String objectId = "0-5-1-219";
        String customerId = "167474901";
        String nonce = "fake-valid-nonce";
        SacResponse response = new SacResponse();
        MtxMsg mtxmsg = new MtxMsg();
        mtxmsg.setResult((long) 200);
        mtxmsg.setResultText("OK");

        MtxResponseSubscription subscriber = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                "src/test/resources/data/sacService/MtxResponseSubscriber_AddPayment.json");

        MtxResponsePaymentMethodInfo paymentMethodInfo = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentMethodInfo.class,
                "src/test/resources/data/sacService/MtxResponsePaymentMethodInfo_ResIdNotFound.json");
        MtxResponseAdd addpaymentResp = CommonTestHelper.loadJsonMessage(
                MtxResponseAdd.class,
                "src/test/resources/data/sacService/MtxResponseAdd_Success.json");

        doReturn(subscriber).when(sacServiceSpy).querySubscriptionDataByObjectId(any(), any());
        doReturn(paymentMethodInfo).when(sacServiceSpy).getPaymentMethodInfo(any(), any(), any());
        ArgumentCaptor<MtxRequestSubscriberAddPaymentMethod> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestSubscriberAddPaymentMethod.class);
        doReturn(addpaymentResp).when(sacServiceSpy).doSubscriberAddPaymentMethod(
                any(), any(), argumentCaptor.capture());
        Mockito.doReturn("").when(sacServiceSpy).getRoute(any());

        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.MTX_SUCCESS);
        qResp.setResultText("OK");
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(() -> ActiveMQClient.sendSacMessage(any(), any())).thenReturn(qResp);
            sacServiceSpy.sacAddPayment(response, objectId, customerId, nonce);
        }

        MtxRequestSubscriberAddPaymentMethod request = argumentCaptor.getValue();
        assertEquals(nonce, request.getPaymentGatewayOneTimeToken());
        assertEquals(customerId, request.getPaymentGatewayUserId());
        assertEquals("0", response.getResult().toString());
        assertEquals("OK", response.getResultText());
        assertEquals("12", response.getresult().getresourceId().toString());
        assertNull(response.getresult().getname());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_sacCurrentPayment_New_Success() throws Exception {
        SacService sacServiceSpy = Mockito.spy(new SacService(true));
        String objectId = "0-5-1-219";
        long resourceId = 12;
        SacResponse response = new SacResponse();
        MtxMsg mtxmsg = new MtxMsg();
        mtxmsg.setResult((long) 200);
        mtxmsg.setResultText("OK");
        MtxResponse modifyResponse = new MtxResponse();
        modifyResponse.setResult((long) 0);
        modifyResponse.setResultText("OK");

        MtxResponseSubscription subscriber = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                "src/test/resources/data/sacService/MtxResponseSubscriber_AddPayment.json");
        MtxResponsePaymentMethodInfo paymentMethodInfo = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentMethodInfo.class,
                "src/test/resources/data/sacService/MtxResponsePaymentMethodInfo_Current_success.json");

        doReturn(subscriber).when(sacServiceSpy).querySubscriptionDataByObjectId(any(), any());
        ArgumentCaptor<MtxRequestSubscriberModifyPaymentMethod> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestSubscriberModifyPaymentMethod.class);
        doReturn(modifyResponse).when(sacServiceSpy).doSubscriberModifyPaymentMethod(
                any(), any(), argumentCaptor.capture());

        doReturn(paymentMethodInfo).when(sacServiceSpy).getPaymentMethodInfo(any(), any(), any());
        Mockito.doReturn("").when(sacServiceSpy).getRoute(any());

        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.MTX_SUCCESS);
        qResp.setResultText("OK");
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(() -> ActiveMQClient.sendSacMessage(any(), any())).thenReturn(qResp);
            sacServiceSpy.sacCurrentPayment(response, objectId, resourceId);
        }

        MtxRequestSubscriberModifyPaymentMethod request = argumentCaptor.getValue();
        assertEquals(String.valueOf(resourceId), request.getResourceId().toString());
        assertEquals("0", response.getResult().toString());
        assertEquals("OK", response.getResultText());

        assertEquals(200, response.getstatusCode().intValue());
        assertEquals("12", response.getresult().getresourceId().toString());
        assertEquals("CreditCard null_Visa_1881_12/2020", response.getresult().getname());
        assertEquals("OK", response.getstatus());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_sacCurrentPayment_Fail() throws Exception {
        SacService sacServiceSpy = Mockito.spy(new SacService(true));
        String objectId = "0-5-1-219";
        long resourceId = 12;
        SacResponse response = new SacResponse();
        MtxMsg mtxmsg = new MtxMsg();
        mtxmsg.setResult((long) 200);
        mtxmsg.setResultText("OK");
        MtxResponse modifyResponse = new MtxResponse();
        modifyResponse.setResult((long) 11);
        modifyResponse.setResultText("NOTOK");

        MtxResponseSubscription subscriber = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                "src/test/resources/data/sacService/MtxResponseSubscriber_AddPayment.json");

        doReturn(subscriber).when(sacServiceSpy).querySubscriptionDataByObjectId(any(), any());
        ArgumentCaptor<MtxRequestSubscriberModifyPaymentMethod> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestSubscriberModifyPaymentMethod.class);
        doReturn(modifyResponse).when(sacServiceSpy).doSubscriberModifyPaymentMethod(
                any(), any(), argumentCaptor.capture());

        Mockito.doReturn("").when(sacServiceSpy).getRoute(any());

        Exception exception = assertThrows(
                SacServiceException.class,
                () -> sacServiceSpy.sacCurrentPayment(response, objectId, resourceId));
        exception.printStackTrace();
        assertTrue(exception.getMessage().contains(LOG_MESSAGES.LOG_FAILED_TO_CURRENT_PAYMENT));
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_sacCurrentPayment_Fail_TO_Get_CurrentPayment() throws Exception {
        SacService sacServiceSpy = Mockito.spy(new SacService(true));
        String objectId = "0-5-1-219";
        long resourceId = 12;
        SacResponse response = new SacResponse();
        MtxMsg mtxmsg = new MtxMsg();
        mtxmsg.setResult((long) 200);
        mtxmsg.setResultText("OK");
        MtxResponse modifyResponse = new MtxResponse();
        modifyResponse.setResult((long) 10);
        modifyResponse.setResultText("OK");

        MtxResponseSubscription subscriber = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                "src/test/resources/data/sacService/MtxResponseSubscriber_AddPayment.json");
        MtxResponsePaymentMethodInfo paymentMethodInfo = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentMethodInfo.class,
                "src/test/resources/data/sacService/MtxResponsePaymentMethodInfo_Current_Fail.json");

        doReturn(subscriber).when(sacServiceSpy).querySubscriptionDataByObjectId(any(), any());
        ArgumentCaptor<MtxRequestSubscriberModifyPaymentMethod> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestSubscriberModifyPaymentMethod.class);
        Mockito.doReturn(modifyResponse).when(sacServiceSpy).doSubscriberModifyPaymentMethod(
                any(), any(), argumentCaptor.capture());

        doReturn(paymentMethodInfo).when(sacServiceSpy).getPaymentMethodInfo(any(), any(), any());
        doReturn("").when(sacServiceSpy).getRoute(any());

        Exception exception = assertThrows(
                SacServiceException.class,
                () -> sacServiceSpy.sacCurrentPayment(response, objectId, resourceId));
        exception.printStackTrace();
        assertTrue(
                exception.getMessage().contains(
                        LOG_MESSAGES.LOG_FAILED_TO_GET_CURRENT_PAYMENT_METHOD));
    }

    @Test
    public void test_sacModifyPayment_Success() throws Exception {

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, "src/test/resources/data/sacService/MtxResponseSubscription.json");

        MtxResponse deletePayRes = new MtxResponse();
        deletePayRes.setResult(0l);
        deletePayRes.setResultText("OK");

        MtxMsg mtxmsg = new MtxMsg();
        mtxmsg.setResult((long) 200);
        mtxmsg.setResultText("OK");

        SacModifyRequest request = new SacModifyRequest();
        request.setExternalId("1992");
        request.setPaymentPreference("CreditCard null_Visa_1881_12/2020");

        doReturn("").when(instance).getRoute(any());

        MtxResponsePaymentMethodInfo paymentInfo = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentMethodInfo.class,
                DATA_DIR.SAC + "MtxResponsePaymentMethodInfo_success.json");

        doReturn(paymentInfo).when(instance).queryPaymentMethodInfo(
                any(), any(), argThat((MtxSubscriberSearchData sd) -> true));
        doReturn(deletePayRes).when(instance).doSubscriberRemovePaymentMethod(any(), any(), any());

        MtxResponseMulti responseMulti = new MtxResponseMulti();
        responseMulti.setResult(0L);
        responseMulti.setResultText("OK");
        Mockito.when(api.multi(any(MtxRequestMulti.class))).thenReturn(responseMulti);

        doReturn(subscription).when(instance).querySubscriptionDataByObjectId(any(), any());

        SacModifyResponse response = new SacModifyResponse();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.MTX_SUCCESS);
        qResp.setResultText("OK");
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(() -> ActiveMQClient.sendSacMessage(any(), any())).thenReturn(qResp);
            instance.sacModifyPayment(request, response);
        }
        assertEquals(RESULT_CODES.MTX_SUCCESS, response.getResult());
        assertEquals(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS, response.getResultText());
    }

    @Test
    public void test_VisibleRequestSacSetUpPayment_DefaultPayment_Y_Success() throws Exception {
        SacService sacServiceSpy = Mockito.spy(new SacService(true));
        VisibleRequestSacSetUpPayment request = CommonTestHelper.loadJsonMessage(
                VisibleRequestSacSetUpPayment.class,
                "src/test/resources/data/sacService/VisibleRequestSacSetUpPayment_Default_Y.json");
        VisibleResponseSacSetUpPayment response = new VisibleResponseSacSetUpPayment();

        MtxResponseSubscription subscriber = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                "src/test/resources/data/sacService/SacSetUpPayment_Response_Subscriber_.json");

        MtxResponsePaymentMethodInfo paymentMethodInfo_default_N = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentMethodInfo.class,
                "src/test/resources/data/sacService/SacSetUpPayment_GetPaymentMethod_Info_Default_N.json");
        MtxResponseClientToken clientTokenResponse = CommonTestHelper.loadJsonMessage(
                MtxResponseClientToken.class,
                "src/test/resources/data/sacService/SacSetUpPayment_sysClientTokenResp.json");
        MtxResponseAdd addpaymentResp = CommonTestHelper.loadJsonMessage(
                MtxResponseAdd.class,
                "src/test/resources/data/sacService/MtxResponseAdd_Success.json");
        MtxMsg mtxmsg = new MtxMsg();
        mtxmsg.setResult((long) 200);
        mtxmsg.setResultText("OK");
        MtxResponse modifyResponse = new MtxResponse();
        modifyResponse.setResult((long) 0);
        modifyResponse.setResultText("OK");

        MtxResponsePaymentMethodInfo paymentMethodInfo_default_Y = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentMethodInfo.class,
                "src/test/resources/data/sacService/SacSetUpPayment_GetPaymentMethod_Info_Default_Y.json");

        doReturn("").when(sacServiceSpy).getRoute(any());

        doReturn(subscriber).when(sacServiceSpy).querySubscriptionDataByObjectId(any(), any());
        doReturn(subscriber).when(sacServiceSpy).querySubscriptionData(any(), any());
        // doReturn(subscriber).when(sacServiceSpy, "searchSubscriberExternal", any());
        doReturn(paymentMethodInfo_default_N).doReturn(paymentMethodInfo_default_Y).when(
                sacServiceSpy).getPaymentMethodInfo(any(), any(), any());
        ArgumentCaptor<MtxRequestSubscriberAddPaymentMethod> argumentCaptor_add = ArgumentCaptor.forClass(
                MtxRequestSubscriberAddPaymentMethod.class);
        doReturn(addpaymentResp).when(sacServiceSpy).doSubscriberAddPaymentMethod(
                any(), any(), argumentCaptor_add.capture());
        ArgumentCaptor<MtxRequestSubscriberModifyPaymentMethod> argumentCaptor_current = ArgumentCaptor.forClass(
                MtxRequestSubscriberModifyPaymentMethod.class);
        doReturn(modifyResponse).when(sacServiceSpy).doSubscriberModifyPaymentMethod(
                any(), any(), argumentCaptor_current.capture());
        doReturn(clientTokenResponse).when(sacServiceSpy).createClientToken(any());
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.MTX_SUCCESS);
        qResp.setResultText("OK");
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(() -> ActiveMQClient.sendSacMessage(any(), any())).thenReturn(qResp);
            sacServiceSpy.sacSetUpPayment(request, response);
        }

        assertEquals("0", response.getResult().toString());
        assertEquals("OK", response.getResultText());
        assertEquals(
                request.getNonce(), argumentCaptor_add.getValue().getPaymentGatewayOneTimeToken());
        assertEquals(
                request.getCustomerId(), argumentCaptor_add.getValue().getPaymentGatewayUserId());
        assertEquals(
                addpaymentResp.getResourceIdArray().get(0),
                argumentCaptor_current.getValue().getResourceId());
        assertEquals(clientTokenResponse.getPaymentToken(), response.getClientToken());
        assertTrue(
                response.getPaymentMethodInfo().getPaymentMethodInfoList().get(0).getIsDefault());

    }

    @Test
    public void test_VisibleRequestSacSetUpPayment_DefaultPayment_N_Success() throws Exception {
        SacService sacServiceSpy = Mockito.spy(new SacService(true));
        VisibleRequestSacSetUpPayment request = CommonTestHelper.loadJsonMessage(
                VisibleRequestSacSetUpPayment.class,
                "src/test/resources/data/sacService/VisibleRequestSacSetUpPayment_Default_N.json");
        VisibleResponseSacSetUpPayment response = new VisibleResponseSacSetUpPayment();

        MtxResponseSubscription subscriber = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                "src/test/resources/data/sacService/SacSetUpPayment_Response_Subscriber_.json");

        MtxResponsePaymentMethodInfo paymentMethodInfo_default_N = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentMethodInfo.class,
                "src/test/resources/data/sacService/SacSetUpPayment_GetPaymentMethod_Info_Default_N.json");
        MtxResponseClientToken clientTokenResponse = CommonTestHelper.loadJsonMessage(
                MtxResponseClientToken.class,
                "src/test/resources/data/sacService/SacSetUpPayment_sysClientTokenResp.json");
        MtxResponseAdd addpaymentResp = CommonTestHelper.loadJsonMessage(
                MtxResponseAdd.class,
                "src/test/resources/data/sacService/MtxResponseAdd_Success.json");
        MtxMsg mtxmsg = new MtxMsg();
        mtxmsg.setResult((long) 200);
        mtxmsg.setResultText("OK");

        doReturn("").when(sacServiceSpy).getRoute(any());
        doReturn(subscriber).when(sacServiceSpy).querySubscriptionDataByObjectId(any(), any());
        doReturn(subscriber).when(sacServiceSpy).querySubscriptionData(any(), any());
        Mockito.doReturn(paymentMethodInfo_default_N).when(sacServiceSpy).getPaymentMethodInfo(
                any(), any(), any());

        ArgumentCaptor<MtxRequestSubscriberAddPaymentMethod> argumentCaptor_add = ArgumentCaptor.forClass(
                MtxRequestSubscriberAddPaymentMethod.class);
        Mockito.doReturn(addpaymentResp).when(sacServiceSpy).doSubscriberAddPaymentMethod(
                any(), any(), argumentCaptor_add.capture());

        Mockito.doReturn(clientTokenResponse).when(sacServiceSpy).createClientToken(any());
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.MTX_SUCCESS);
        qResp.setResultText("OK");
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(() -> ActiveMQClient.sendSacMessage(any(), any())).thenReturn(qResp);
            sacServiceSpy.sacSetUpPayment(request, response);
        }

        assertEquals("0", response.getResult().toString());
        assertEquals("OK", response.getResultText());
        assertEquals(
                request.getNonce(), argumentCaptor_add.getValue().getPaymentGatewayOneTimeToken());
        assertEquals(
                request.getCustomerId(), argumentCaptor_add.getValue().getPaymentGatewayUserId());

        assertEquals(clientTokenResponse.getPaymentToken(), response.getClientToken());
        assertFalse(
                response.getPaymentMethodInfo().getPaymentMethodInfoList().get(0).getIsDefault());
    }

    @Test
    public void test_VisibleRequestSacSetUpPayment_AddPaymentError() throws Exception {
        SacService sacServiceSpy = Mockito.spy(new SacService(true));
        VisibleRequestSacSetUpPayment request = CommonTestHelper.loadJsonMessage(
                VisibleRequestSacSetUpPayment.class,
                "src/test/resources/data/sacService/VisibleRequestSacSetUpPayment_Default_Y.json");
        VisibleResponseSacSetUpPayment response = new VisibleResponseSacSetUpPayment();

        MtxResponseSubscription subscriber = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                "src/test/resources/data/sacService/SacSetUpPayment_Response_Subscriber_.json");

        MtxResponseAdd addpaymentResp = CommonTestHelper.loadJsonMessage(
                MtxResponseAdd.class,
                "src/test/resources/data/sacService/SacSetUpPaymnet_MtxResponseAdd_Error.json");

        doReturn(subscriber).when(sacServiceSpy).querySubscriptionDataByObjectId(any(), any());
        doReturn(subscriber).when(sacServiceSpy).querySubscriptionData(any(), any());
        Mockito.doReturn("").when(sacServiceSpy).getRoute(any());

        ArgumentCaptor<MtxRequestSubscriberAddPaymentMethod> argumentCaptor_add = ArgumentCaptor.forClass(
                MtxRequestSubscriberAddPaymentMethod.class);
        doReturn(addpaymentResp).when(sacServiceSpy).doSubscriberAddPaymentMethod(
                any(), any(), argumentCaptor_add.capture());

        Exception exception = assertThrows(
                SacServiceException.class, () -> sacServiceSpy.sacSetUpPayment(request, response));
        exception.printStackTrace();
        assertTrue(exception.getMessage().contains(LOG_MESSAGES.LOG_FAILED_TO_ADD_PAYMENT));
    }

    @Test
    public void test_VisibleRequestSacSetUpPayment_CurrentPaymentError() throws Exception {
        SacService sacServiceSpy = Mockito.spy(new SacService(true));
        VisibleRequestSacSetUpPayment request = CommonTestHelper.loadJsonMessage(
                VisibleRequestSacSetUpPayment.class,
                "src/test/resources/data/sacService/VisibleRequestSacSetUpPayment_Default_Y.json");
        VisibleResponseSacSetUpPayment response = new VisibleResponseSacSetUpPayment();

        MtxResponseSubscription subscriber = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                "src/test/resources/data/sacService/SacSetUpPayment_Response_Subscriber_.json");

        MtxResponseAdd addpaymentResp = CommonTestHelper.loadJsonMessage(

                MtxResponseAdd.class,
                "src/test/resources/data/sacService/MtxResponseAdd_Success.json");
        MtxResponsePaymentMethodInfo paymentMethodInfo_default_N = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentMethodInfo.class,
                "src/test/resources/data/sacService/SacSetUpPayment_GetPaymentMethod_Info_Default_N.json");
        MtxMsg mtxmsg = new MtxMsg();
        mtxmsg.setResult((long) 200);
        mtxmsg.setResultText("OK");
        MtxResponse modifyResponse = new MtxResponse();
        modifyResponse.setResult((long) 10);
        modifyResponse.setResultText("NOTOK");
        doReturn(subscriber).when(sacServiceSpy).querySubscriptionDataByObjectId(any(), any());
        doReturn(subscriber).when(sacServiceSpy).querySubscriptionData(any(), any());
        Mockito.doReturn("").when(sacServiceSpy).getRoute(any());
        doReturn(paymentMethodInfo_default_N).when(sacServiceSpy).getPaymentMethodInfo(
                any(), any(), any());
        ArgumentCaptor<MtxRequestSubscriberAddPaymentMethod> argumentCaptor_add = ArgumentCaptor.forClass(
                MtxRequestSubscriberAddPaymentMethod.class);
        doReturn(addpaymentResp).when(sacServiceSpy).doSubscriberAddPaymentMethod(
                any(), any(), argumentCaptor_add.capture());
        Mockito.doReturn(modifyResponse).when(sacServiceSpy).doSubscriberModifyPaymentMethod(
                any(), any(), any());
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.MTX_SUCCESS);
        qResp.setResultText("OK");
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(() -> ActiveMQClient.sendSacMessage(any(), any())).thenReturn(qResp);
            Exception exception = assertThrows(
                    SacServiceException.class,
                    () -> sacServiceSpy.sacSetUpPayment(request, response));
            exception.printStackTrace();
            assertTrue(exception.getMessage().contains(LOG_MESSAGES.LOG_FAILED_TO_CURRENT_PAYMENT));
        }
    }

    @Test
    public void test_VisibleRequestSacSetUpPayment_GenerateToken_Error() throws Exception {
        SacService sacServiceSpy = Mockito.spy(new SacService(true));
        VisibleRequestSacSetUpPayment request = CommonTestHelper.loadJsonMessage(
                VisibleRequestSacSetUpPayment.class,
                "src/test/resources/data/sacService/VisibleRequestSacSetUpPayment_Default_Y.json");
        VisibleResponseSacSetUpPayment response = new VisibleResponseSacSetUpPayment();

        MtxResponseSubscription subscriber = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                "src/test/resources/data/sacService/SacSetUpPayment_Response_Subscriber_.json");

        MtxResponsePaymentMethodInfo paymentMethodInfo_default_N = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentMethodInfo.class,
                "src/test/resources/data/sacService/SacSetUpPayment_GetPaymentMethod_Info_Default_N.json");
        MtxResponseClientToken clientTokenResponse = CommonTestHelper.loadJsonMessage(
                MtxResponseClientToken.class,
                "src/test/resources/data/sacService/SacSetUpPayment_sysClientTokenResp_Error.json");
        MtxResponseAdd addpaymentResp = CommonTestHelper.loadJsonMessage(
                MtxResponseAdd.class,
                "src/test/resources/data/sacService/MtxResponseAdd_Success.json");
        MtxMsg mtxmsg = new MtxMsg();
        mtxmsg.setResult((long) 200);
        mtxmsg.setResultText("OK");
        MtxResponse modifyResponse = new MtxResponse();
        modifyResponse.setResult((long) 0);
        modifyResponse.setResultText("OK");

        MtxResponsePaymentMethodInfo paymentMethodInfo_default_Y = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentMethodInfo.class,
                "src/test/resources/data/sacService/SacSetUpPayment_GetPaymentMethod_Info_Default_Y.json");

        doReturn("").when(sacServiceSpy).getRoute(any());
        doReturn(subscriber).when(sacServiceSpy).querySubscriptionDataByObjectId(any(), any());
        doReturn(subscriber).when(sacServiceSpy).querySubscriptionData(any(), any());
        doReturn(paymentMethodInfo_default_N).doReturn(paymentMethodInfo_default_Y).when(
                sacServiceSpy).getPaymentMethodInfo(any(), any(), any());
        ArgumentCaptor<MtxRequestSubscriberAddPaymentMethod> argumentCaptor_add = ArgumentCaptor.forClass(
                MtxRequestSubscriberAddPaymentMethod.class);
        doReturn(addpaymentResp).when(sacServiceSpy).doSubscriberAddPaymentMethod(
                any(), any(), argumentCaptor_add.capture());
        ArgumentCaptor<MtxRequestSubscriberModifyPaymentMethod> argumentCaptor_current = ArgumentCaptor.forClass(
                MtxRequestSubscriberModifyPaymentMethod.class);
        Mockito.doReturn(modifyResponse).when(sacServiceSpy).doSubscriberModifyPaymentMethod(
                any(), any(), argumentCaptor_current.capture());
        doReturn(clientTokenResponse).when(sacServiceSpy).createClientToken(any());
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.MTX_SUCCESS);
        qResp.setResultText("OK");
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(() -> ActiveMQClient.sendSacMessage(any(), any())).thenReturn(qResp);
            Exception exception = assertThrows(
                    SacServiceException.class,
                    () -> sacServiceSpy.sacSetUpPayment(request, response));
            exception.printStackTrace();
            assertTrue(
                    exception.getMessage().contains(
                            LOG_MESSAGES.LOG_FAILED_TO_GENERATE_CLIENT_TOKEN));
        }
    }

    @SuppressWarnings({
        "unchecked"
    })
    @ParameterizedTest(
            name = "test_sacLinkCa_Given_Payer_Beneficiary_SameGroup_NoLink_When_LinkRequested_Then_CreateLink")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Payer and Beneficiary are in same connected account group. No link exists between two subs|"
                +"|When  |Api called to create link.|"
                +"|Then  |Link created.|"})
    // @formatter:on
    @Tag("CA")
    @Tag("VER-795")
    public void test_sacLinkCa_Given_Payer_Beneficiary_SameGroup_NoLink_When_LinkRequested_Then_CreateLink(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String beneficiaryId = "1234";
        String payerId = "5678";

        VisibleRequestCaLink request = CommonTestHelper.getVisibleRequestCaLink(
                beneficiaryId, payerId);
        VisibleResponseCaLink response = new VisibleResponseCaLink();

        MtxResponseSubscription beneficiary = CommonTestHelper.getMtxResponseSubscription_Autopay(
                beneficiaryId);
        MtxResponseSubscription payer = CommonTestHelper.getMtxResponseSubscription_Autopay(
                payerId);
        MtxResponseGroup respGrp = CommonTestHelper.getMtxResponseGroupCA(
                "CA" + beneficiary.getExternalId(), GROUP_CONSTANTS.GROUP_TIER_CONNECCTED,
                List.of(beneficiary.getObjectId().toString(), payer.getObjectId().toString()),
                null);

        beneficiary.getParentGroupIdArrayAppender().add(respGrp.getObjectId());
        payer.getParentGroupIdArrayAppender().add(respGrp.getObjectId());

        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);

        doReturn(beneficiary).doReturn(payer).when(instance).querySubscriptionData(any(), any());
        doReturn(respGrp).when(instance).querySubscriptionGroup(any(), any());

        MtxResponseMulti multiResp = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResp.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        doReturn(multiResp).when(instance).multiRequest(any(), argumentCaptor.capture());

        instance.sacLinkCa(request, response);
        System.out.println(td.getTestMethod() + ":" + response.toJson());
        System.out.println(td.getTestMethod() + ":" + argumentCaptor.getValue().toJson());

        String expectedLink = "Ben:" + beneficiaryId + "#Pay:" + payerId;
        MtxRequestGroupModify grpReq = new MtxRequestGroupModify(
                argumentCaptor.getValue().getAtRequestList(0));
        assertEquals(
                expectedLink,
                ((VisibleCAGroupExtension) grpReq.getAttr()).getAtRelationshipArray(0));

        MtxRequestSubscriptionModify subReq = new MtxRequestSubscriptionModify(
                argumentCaptor.getValue().getAtRequestList(1));
        assertEquals(payerId, ((VisibleSubscriberExtension) subReq.getAttr()).getPayerExternalId());
    }

    @ParameterizedTest(
            name = "test_sacLinkCa_Given_Payer_Not_On_Autopay_When_LinkRequested_Then_CreateLink")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                "|Given|Payer is not on autopay.|"
               +"|     |Payer and Beneficiary are in same connected account group. No link exists between two subs.|"
               +"|When |Api called to create link.|"
               +"|Then |Link created.|"})
    // @formatter:on
    @Tag("CA")
    @Tag("VER-795")
    public void test_sacLinkCa_Given_Payer_Not_On_Autopay_When_LinkRequested_Then_CreateLink(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String beneficiaryId = "1234";
        String payerId = "5678";

        VisibleRequestCaLink request = CommonTestHelper.getVisibleRequestCaLink(
                beneficiaryId, payerId);
        VisibleResponseCaLink response = new VisibleResponseCaLink();

        MtxResponseSubscription beneficiary = CommonTestHelper.getMtxResponseSubscription_Autopay(
                beneficiaryId);
        MtxResponseSubscription payer = CommonTestHelper.getMtxResponseSubscription_Manualpay(
                payerId);

        doReturn(beneficiary).doReturn(payer).when(instance).querySubscriptionData(any(), any());

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        Exception exception = assertThrows(
                SacServiceException.class, () -> instance.sacLinkCa(request, response));
        exception.printStackTrace();
        assertTrue(exception.getMessage().contains(LOG_MESSAGES.PAYER_NOT_ON_AUTOPAY));
    }

    @ParameterizedTest(
            name = "test_sacLinkCa_Given_Payer_Not_Active_When_LinkRequested_Then_CreateLink")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                "|Given|Payer is not active.|"
               +"|     |Payer and Beneficiary are in same connected account group. No link exists between two subs.|"
               +"|When |Api called to create link.|"
               +"|Then |Link created.|"})
    // @formatter:on
    @Tag("CA")
    @Tag("VER-795")
    public void test_sacLinkCa_Given_Payer_Not_Active_When_LinkRequested_Then_CreateLink(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String beneficiaryId = "1234";
        String payerId = "5678";

        VisibleRequestCaLink request = CommonTestHelper.getVisibleRequestCaLink(
                beneficiaryId, payerId);
        VisibleResponseCaLink response = new VisibleResponseCaLink();

        MtxResponseSubscription beneficiary = CommonTestHelper.getMtxResponseSubscription_Autopay(
                beneficiaryId);
        MtxResponseSubscription payer = CommonTestHelper.getMtxResponseSubscription_Autopay(
                payerId);
        CommonTestHelper.changeToLapse(payer);

        doReturn(beneficiary).doReturn(payer).when(instance).querySubscriptionData(any(), any());

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        Exception exception = assertThrows(
                SacServiceException.class, () -> instance.sacLinkCa(request, response));
        exception.printStackTrace();
        assertTrue(exception.getMessage().contains(LOG_MESSAGES.PAYER_NOT_ACTIVE));
    }

    @ParameterizedTest(
            name = "test_sacLinkCa_Given_Beneficiary_Not_Active_When_LinkRequested_Then_CreateLink")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                "|Given|Beneficiary is not active.|"
               +"|     |Payer and Beneficiary are in same connected account group. No link exists between two subs.|"
               +"|When |Api called to create link.|"
               +"|Then |Link created.|"})
    // @formatter:on
    @Tag("CA")
    @Tag("VER-795")
    public void test_sacLinkCa_Given_Beneficiary_Not_Active_When_LinkRequested_Then_CreateLink(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String beneficiaryId = "1234";
        String payerId = "5678";

        VisibleRequestCaLink request = CommonTestHelper.getVisibleRequestCaLink(
                beneficiaryId, payerId);
        VisibleResponseCaLink response = new VisibleResponseCaLink();

        MtxResponseSubscription beneficiary = CommonTestHelper.getMtxResponseSubscription_Autopay(
                beneficiaryId);
        CommonTestHelper.changeToLapse(beneficiary);
        MtxResponseSubscription payer = CommonTestHelper.getMtxResponseSubscription_Autopay(
                payerId);

        doReturn(beneficiary).doReturn(payer).when(instance).querySubscriptionData(any(), any());

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        Exception exception = assertThrows(
                SacServiceException.class, () -> instance.sacLinkCa(request, response));
        exception.printStackTrace();
        assertTrue(exception.getMessage().contains(LOG_MESSAGES.BENEFICIARY_NOT_ACTIVE));
    }

    @ParameterizedTest(
            name = "test_sacLinkCa_Given_Beneficiary_Not_Active_When_LinkRequested_Then_CreateLink")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                "|Given|Beneficiary is not active.|"
               +"|     |Payer and Beneficiary are in same connected account group. No link exists between two subs.|"
               +"|When |Api called to create link.|"
               +"|Then |Link created.|"})
    // @formatter:on
    @Tag("CA")
    @Tag("VER-795")
    public void test_sacLinkCa_Given_NoCommonGroup_When_LinkRequested_Then_CreateLink(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String beneficiaryId = "1234";
        String payerId = "5678";

        VisibleRequestCaLink request = CommonTestHelper.getVisibleRequestCaLink(
                beneficiaryId, payerId);
        VisibleResponseCaLink response = new VisibleResponseCaLink();

        MtxResponseSubscription beneficiary = CommonTestHelper.getMtxResponseSubscription_Autopay(
                beneficiaryId);
        MtxResponseSubscription payer = CommonTestHelper.getMtxResponseSubscription_Autopay(
                payerId);

        doReturn(beneficiary).doReturn(payer).when(instance).querySubscriptionData(any(), any());

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        Exception exception = assertThrows(
                SacServiceException.class, () -> instance.sacLinkCa(request, response));
        exception.printStackTrace();
        assertTrue(exception.getMessage().contains(LOG_MESSAGES.PAYER_BENEFICIARY_NO_CA_GROUP));
    }

    @SuppressWarnings({
        "unchecked"
    })
    @ParameterizedTest(
            name = "test_sacLinkCa_Given_Beneficiary_Has_CaLink_When_LinkRequested_Then_Error")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Beneficiary has link with another payer|"
                +"|      |Payer and Beneficiary are in same connected account group. No link exists between two subs|"
                +"|When  |Api called to create link.|"
                +"|Then  |Error.|"})
    // @formatter:on
    @Tag("CA")
    @Tag("VER-795")
    public void test_sacLinkCa_Given_Beneficiary_Has_CaLink_When_LinkRequested_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String beneficiaryId = "1234";
        String payerId = "5678";
        String anotherPayerId = "5678";
        String existingLink = String.format(
                GROUP_CONSTANTS.CA_LINK_FORMAT, beneficiaryId, anotherPayerId);

        VisibleRequestCaLink request = CommonTestHelper.getVisibleRequestCaLink(
                beneficiaryId, payerId);
        VisibleResponseCaLink response = new VisibleResponseCaLink();

        MtxResponseSubscription beneficiary = CommonTestHelper.getMtxResponseSubscription_Autopay(
                beneficiaryId);
        MtxResponseSubscription payer = CommonTestHelper.getMtxResponseSubscription_Autopay(
                payerId);
        MtxResponseGroup respGrp = CommonTestHelper.getMtxResponseGroupCA(
                "CA" + beneficiary.getExternalId(), GROUP_CONSTANTS.GROUP_TIER_CONNECCTED,
                List.of(beneficiary.getObjectId().toString(), payer.getObjectId().toString()),
                List.of(existingLink));

        beneficiary.getParentGroupIdArrayAppender().add(respGrp.getObjectId());
        payer.getParentGroupIdArrayAppender().add(respGrp.getObjectId());

        MtxResponse grpModResp = CommonTestHelper.getOkMtxResponse();
        ArgumentCaptor<VisibleCAGroupExtension> argumentCaptor = ArgumentCaptor.forClass(
                VisibleCAGroupExtension.class);

        doReturn(beneficiary).doReturn(payer).when(instance).querySubscriptionData(any(), any());
        doReturn(respGrp).when(instance).querySubscriptionGroup(any(), any());
        doReturn(grpModResp).when(instance).updateSubscriptionGroupAttr(
                any(), any(), argumentCaptor.capture());

        Exception exception = assertThrows(
                SacServiceException.class, () -> instance.sacLinkCa(request, response));
        exception.printStackTrace();
        assertTrue(exception.getMessage().contains(LOG_MESSAGES.BENEFICIARY_HAS_CA_LINK));
    }

    @SuppressWarnings({
        "unchecked"
    })
    @ParameterizedTest(
            name = "test_sacUnlinkCa_Given_MiltipleLinksInGroup_When_UnlinkRequested_Then_OneLinkRemoved")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |CA Group has multiple links.|"
                +"|      |Payer and Beneficiary are in same connected account group. Link exists between two subs|"
                +"|When  |Api called to delete link.|"
                +"|Then  |Link deleted. Other links remain intact.|"})
    // @formatter:on
    @Tag("CA")
    @Tag("VER-795")
    public void test_sacUnlinkCa_Given_MiltipleLinksInGroup_When_UnlinkRequested_Then_OneLinkRemoved(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String beneficiaryId = "1234";
        String aotherBeneficiaryId = "4321";
        String payerId = "5678";
        String dropLink = String.format(GROUP_CONSTANTS.CA_LINK_FORMAT, beneficiaryId, payerId);
        String keepLink = String.format(
                GROUP_CONSTANTS.CA_LINK_FORMAT, aotherBeneficiaryId, payerId);
        VisibleRequestCaUnlink request = CommonTestHelper.getVisibleRequestCaUnlink(beneficiaryId);
        VisibleResponseCaUnlink response = new VisibleResponseCaUnlink();

        MtxResponseSubscription beneficiary = CommonTestHelper.getBeneficiarySubscription_CaGroup(
                beneficiaryId, payerId);
        MtxResponseGroup caGrp = CommonTestHelper.getMtxResponseGroupCA(
                "CA" + beneficiary.getExternalId(), GROUP_CONSTANTS.GROUP_TIER_CONNECCTED,
                List.of(beneficiary.getObjectId().toString(), "5-6-7-8"),
                List.of(dropLink, keepLink));
        doReturn(caGrp).when(instance).querySubscriptionGroup(any(), any());

        beneficiary.getParentGroupIdArrayAppender().add(caGrp.getObjectId());
        doReturn(beneficiary).when(instance).querySubscriptionData(any(), any());

        MtxResponseMulti multiResp = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResp.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), argumentCaptor.capture());

        instance.sacUnlinkCa(request, response);
        System.out.println(td.getTestMethod() + ":" + response.toJson());
        System.out.println(td.getTestMethod() + ":" + argumentCaptor.getValue().toJson());

        MtxRequestGroupModify grpReq = new MtxRequestGroupModify(
                argumentCaptor.getValue().getAtRequestList(0));
        assertFalse(
                ((VisibleCAGroupExtension) grpReq.getAttr()).getAtRelationshipArray(0).contains(
                        dropLink));
        assertTrue(
                ((VisibleCAGroupExtension) grpReq.getAttr()).getAtRelationshipArray(0).contains(
                        keepLink));

        MtxRequestSubscriptionModify subReq = new MtxRequestSubscriptionModify(
                argumentCaptor.getValue().getAtRequestList(1));
        assertTrue(
                StringUtils.isBlank(
                        ((VisibleSubscriberExtension) subReq.getAttr()).getPayerExternalId()));
    }

    @SuppressWarnings({
        "unchecked"
    })
    @ParameterizedTest(name = "test_sacUnlinkCa_Given_NoCaLink_When_UnlinkRequested_Then_Error")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |CA Group has some links.|"
                +"|      |Payer and Beneficiary are in same connected account group. NO Link exists between two subs|"
                +"|When  |Api called to delete link.|"
                +"|Then  |Error.|"})
    // @formatter:on
    @Tag("CA")
    @Tag("VER-843")
    public void test_sacUnlinkCa_Given_NoCaLink_When_UnlinkRequested_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String beneficiaryId = "1234";
        String payerId = "5678";
        String aotherBeneficiaryId = "4321";
        String keepLink = String.format(
                GROUP_CONSTANTS.CA_LINK_FORMAT, aotherBeneficiaryId, payerId);
        VisibleRequestCaUnlink request = CommonTestHelper.getVisibleRequestCaUnlink(beneficiaryId);
        VisibleResponseCaUnlink response = new VisibleResponseCaUnlink();

        MtxResponseSubscription beneficiary = CommonTestHelper.getMtxResponseSubscription_Autopay(
                beneficiaryId);
        MtxResponseGroup caGrp = CommonTestHelper.getMtxResponseGroupCA(
                "CA" + beneficiary.getExternalId(), GROUP_CONSTANTS.GROUP_TIER_CONNECCTED,
                List.of(beneficiary.getObjectId().toString(), "5-6-7-8"), List.of(keepLink));

        beneficiary.getParentGroupIdArrayAppender().add(new MtxObjectId("1-2-3-4"));

        MtxResponse grpModResp = CommonTestHelper.getOkMtxResponse();
        ArgumentCaptor<VisibleCAGroupExtension> argumentCaptor = ArgumentCaptor.forClass(
                VisibleCAGroupExtension.class);

        doReturn(beneficiary).when(instance).querySubscriptionData(any(), any());
        doReturn(caGrp).when(instance).querySubscriptionGroup(any(), any());
        doReturn(grpModResp).when(instance).updateSubscriptionGroupAttr(
                any(), any(), argumentCaptor.capture());

        instance.sacUnlinkCa(request, response);
        printUnitTest(request.toJson());
        printUnitTest(response.toJson());
        assertEquals(RESULT_CODES.MTX_SUCCESS, response.getResult());
        assertEquals(LOG_MESSAGES.NO_CA_LINKS_FOR_BENEFICIARY, response.getResultText());
    }

    @SuppressWarnings({
        "unchecked"
    })
    @ParameterizedTest(
            name = "test_sacUnlinkCa_Given_CaGroup_Has_No_Links_When_UnlinkRequested_Then_Error")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |CA Group has NO Links.|"
                +"|      |Payer and Beneficiary are in same connected account group.|"
                +"|When  |Api called to delete link.|"
                +"|Then  |Error.|"})
    // @formatter:on
    @Tag("CA")
    @Tag("VER-795")
    @Disabled("Move to another test case")
    public void test_sacUnlinkCa_Given_CaGroup_Has_No_Links_When_UnlinkRequested_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String beneficiaryId = "1234";
        String payerId = "5678";
        VisibleRequestCaUnlink request = CommonTestHelper.getVisibleRequestCaUnlink(beneficiaryId);
        VisibleResponseCaUnlink response = new VisibleResponseCaUnlink();

        MtxResponseSubscription beneficiary = CommonTestHelper.getMtxResponseSubscription_Autopay(
                beneficiaryId);
        MtxResponseGroup caGrp = CommonTestHelper.getMtxResponseGroupCA(
                "CA" + beneficiary.getExternalId(), GROUP_CONSTANTS.GROUP_TIER_CONNECCTED,
                List.of(beneficiary.getObjectId().toString(), "5-6-7-8"), null);

        beneficiary.getParentGroupIdArrayAppender().add(new MtxObjectId("1-2-3-4"));

        MtxResponse grpModResp = CommonTestHelper.getOkMtxResponse();
        ArgumentCaptor<VisibleCAGroupExtension> argumentCaptor = ArgumentCaptor.forClass(
                VisibleCAGroupExtension.class);

        doReturn(beneficiary).when(instance).querySubscriptionData(any(), any());
        doReturn(caGrp).when(instance).querySubscriptionGroup(any(), any());
        doReturn(grpModResp).when(instance).updateSubscriptionGroupAttr(
                any(), any(), argumentCaptor.capture());

        Exception exception = assertThrows(
                SacServiceException.class, () -> instance.sacUnlinkCa(request, response));
        exception.printStackTrace();
        assertTrue(exception.getMessage().contains(LOG_MESSAGES.NO_LINKS_IN_CA_GROUP));
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_sacUnlinkCa_Given_PayerInAttr_When_Always_Then_RemovePayerIdFromAttr")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Beneficiary has a payerId in attributes.|"
                +"|When  |Api called to delete link.|"
                +"|Then  |Link removed from beneficiary attributes.|"
                +"|Comments |12 scenarios.|"})
    // @formatter:on
    @Tag("CA")
    @Tag("VER-821")
    public void test_sacUnlinkCa_Given_PayerInAttr_When_Always_Then_RemovePayerIdFromAttr(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String beneficiaryId = "1234";
        String anotherBeneficiaryId = "4321";
        String payerId = "5678";
        String dropLink = String.format(GROUP_CONSTANTS.CA_LINK_FORMAT, beneficiaryId, payerId);
        String keepLink = String.format(
                GROUP_CONSTANTS.CA_LINK_FORMAT, anotherBeneficiaryId, payerId);
        VisibleRequestCaUnlink request = CommonTestHelper.getVisibleRequestCaUnlink(beneficiaryId);
        VisibleResponseCaUnlink response = new VisibleResponseCaUnlink();

        MtxResponseSubscription beneficiary = CommonTestHelper.getBeneficiarySubscription_CaGroup(
                beneficiaryId, payerId);
        MtxResponseGroup caGrp = CommonTestHelper.getMtxResponseGroupCA(
                "CA" + beneficiary.getExternalId(), GROUP_CONSTANTS.GROUP_TIER_CONNECCTED,
                List.of(beneficiary.getObjectId().toString(), "5-6-7-8"),
                List.of(dropLink, keepLink));
        doReturn(caGrp).when(instance).querySubscriptionGroup(any(), any());

        beneficiary.getParentGroupIdArrayAppender().add(caGrp.getObjectId());
        doReturn(beneficiary).when(instance).querySubscriptionData(any(), any());

        MtxResponseMulti multiResp = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResp.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), argumentCaptor.capture());

        instance.sacUnlinkCa(request, response);
        System.out.println(td.getTestMethod() + ":" + response.toJson());
        System.out.println(td.getTestMethod() + ":" + argumentCaptor.getValue().toJson());

        MtxRequestSubscriptionModify cleanAttrReq = new MtxRequestSubscriptionModify(
                argumentCaptor.getValue().getAtRequestList(1));
        System.out.println(td.getTestMethod() + ":" + cleanAttrReq.toJson());
        assertEquals(
                "", ((VisibleSubscriberExtension) cleanAttrReq.getAttr()).getPayerExternalId());
        assertEquals(beneficiaryId, cleanAttrReq.getSubscriptionSearchData().getExternalId());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_sacUnlinkCa_Given_LinkExists_PayerInAttr_When_Always_Then_RemoveLink")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |CA relationship exists in group. Valid payerId exists in beneficiary attributes.|"
                +"|When  |Api called to delete link.|"
                +"|Then  |Link deleted from group.|"
                +"|Comments |6 scenarios.|"})
    // @formatter:on
    @Tag("CA")
    @Tag("VER-821")
    public void test_sacUnlinkCa_Given_LinkExists_PayerInAttr_When_Always_Then_RemoveLink(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String beneficiaryId = "1234";
        String anotherBeneficiaryId = "4321";
        String payerId = "5678";
        String dropLink = String.format(GROUP_CONSTANTS.CA_LINK_FORMAT, beneficiaryId, payerId);
        String keepLink = String.format(
                GROUP_CONSTANTS.CA_LINK_FORMAT, anotherBeneficiaryId, payerId);
        VisibleRequestCaUnlink request = CommonTestHelper.getVisibleRequestCaUnlink(beneficiaryId);
        VisibleResponseCaUnlink response = new VisibleResponseCaUnlink();

        MtxResponseSubscription beneficiary = CommonTestHelper.getBeneficiarySubscription_CaGroup(
                beneficiaryId, payerId);
        MtxResponseGroup caGrp = CommonTestHelper.getMtxResponseGroupCA(
                "CA" + beneficiary.getExternalId(), GROUP_CONSTANTS.GROUP_TIER_CONNECCTED,
                List.of(beneficiary.getObjectId().toString(), "5-6-7-8"),
                List.of(dropLink, keepLink));
        doReturn(caGrp).when(instance).querySubscriptionGroup(any(), any());

        beneficiary.getParentGroupIdArrayAppender().add(caGrp.getObjectId());
        doReturn(beneficiary).when(instance).querySubscriptionData(any(), any());

        MtxResponseMulti multiResp = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResp.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), argumentCaptor.capture());

        instance.sacUnlinkCa(request, response);
        System.out.println(td.getTestMethod() + ":" + response.toJson());
        System.out.println(td.getTestMethod() + ":" + argumentCaptor.getValue().toJson());

        MtxRequestGroupModify grpReq = new MtxRequestGroupModify(
                argumentCaptor.getValue().getAtRequestList(0));
        assertFalse(
                ((VisibleCAGroupExtension) grpReq.getAttr()).getAtRelationshipArray(0).contains(
                        dropLink));
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_sacUnlinkCa_Given_BenNotInGroup_LinkExists_InvalidPayerInAttr_When_RequestPayerId_Then_RemoveLink")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |CA relationship exists in group.|"
                +"|When  |Api called to delete link. PayerId supplied in request is Valid.|"
                +"|Then  |Link deleted from group.|"
                +"|Comments |4 scenarios.|"})
    // @formatter:on
    @Tag("CA")
    @Tag("VER-821")
    public void test_sacUnlinkCa_Given_LinkExists_When_RequestPayerId_Then_RemoveLink(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String beneficiaryId = "1234";
        String anotherBeneficiaryId = "4321";
        String payerId = "5678";
        String dropLink = String.format(GROUP_CONSTANTS.CA_LINK_FORMAT, beneficiaryId, payerId);
        String keepLink = String.format(
                GROUP_CONSTANTS.CA_LINK_FORMAT, anotherBeneficiaryId, payerId);
        VisibleRequestCaUnlink request = CommonTestHelper.getVisibleRequestCaUnlink(
                beneficiaryId, payerId);
        VisibleResponseCaUnlink response = new VisibleResponseCaUnlink();

        MtxResponseSubscription beneficiary = CommonTestHelper.getMtxResponseSubscription_Autopay(
                beneficiaryId);
        MtxResponseGroup caGrp = CommonTestHelper.getMtxResponseGroupCA(
                "CA" + beneficiary.getExternalId(), GROUP_CONSTANTS.GROUP_TIER_CONNECCTED,
                List.of(beneficiary.getObjectId().toString(), "5-6-7-8"),
                List.of(dropLink, keepLink));
        doReturn(caGrp).when(instance).querySubscriptionGroup(any(), any());

        beneficiary.getParentGroupIdArrayAppender().add(caGrp.getObjectId());
        doReturn(beneficiary).when(instance).querySubscriptionData(any(), any());

        MtxResponseMulti multiResp = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResp.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), argumentCaptor.capture());

        instance.sacUnlinkCa(request, response);
        System.out.println(td.getTestMethod() + ":" + response.toJson());
        System.out.println(td.getTestMethod() + ":" + argumentCaptor.getValue().toJson());
        System.out.println(td.getTestMethod() + ":" + caGrp.toJson());
        MtxRequestGroupModify grpReq = new MtxRequestGroupModify(
                argumentCaptor.getValue().getAtRequestList(0));
        assertFalse(
                ((VisibleCAGroupExtension) grpReq.getAttr()).getAtRelationshipArray(0).contains(
                        dropLink));
    }

    @ParameterizedTest(
            name = "test_sacUnlinkCa_Given_BenNotInGroup_NoPayerInAttr_When_NoPayerInRequest_Then_Error")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Beneficiary removed from CA Group.|"
                +"|      |No payerId exists in beneficiary attributes.|"
                +"|When  |Api called to delete link. No PayerId supplied in request.|"
                +"|Then  |Link deleted from group. Beneficiary subscription not modified.|"})
    // @formatter:on
    @Tag("CA")
    @Tag("VER-821")
    public void test_sacUnlinkCa_Given_BenNotInGroup_NoPayerInAttr_When_NoPayerInRequest_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String beneficiaryId = "1234";
        VisibleRequestCaUnlink request = CommonTestHelper.getVisibleRequestCaUnlink(beneficiaryId);
        VisibleResponseCaUnlink response = new VisibleResponseCaUnlink();

        MtxResponseSubscription beneficiary = CommonTestHelper.getMtxResponseSubscription_Autopay(
                beneficiaryId);
        doReturn(beneficiary).when(instance).querySubscriptionData(any(), any());

        System.out.println(td.getTestMethod() + ":" + request.toJson());

        Exception exception = assertThrows(
                SacServiceException.class, () -> instance.sacUnlinkCa(request, response));
        exception.printStackTrace();
        assertTrue(exception.getMessage().contains(LOG_MESSAGES.PAYER_BENEFICIARY_NO_CA_GROUP));
    }

    private void printUnitTest(Object msg) {
        System.out.println(testInfo.getDisplayName() + ":" + msg);
    }
}
