package com.matrixx.vag.subscriber.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.EventQueryEventInfo;
import com.matrixx.datacontainer.mdc.EventQueryResponseEvents;
import com.matrixx.datacontainer.mdc.MtxBalanceInfo;
import com.matrixx.datacontainer.mdc.MtxBalanceInfoSimple;
import com.matrixx.datacontainer.mdc.MtxRecurringEvent;
import com.matrixx.datacontainer.mdc.MtxRequest;
import com.matrixx.datacontainer.mdc.MtxRequestDeviceDeleteSession;
import com.matrixx.datacontainer.mdc.MtxRequestMulti;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberAdjustBalance;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberCancelOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberModifyOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberPurchaseOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberRefundPayment;
import com.matrixx.datacontainer.mdc.MtxResponseCancel;
import com.matrixx.datacontainer.mdc.MtxResponseMulti;
import com.matrixx.datacontainer.mdc.MtxResponsePaymentHistory;
import com.matrixx.datacontainer.mdc.MtxResponsePricingCatalogItem;
import com.matrixx.datacontainer.mdc.MtxResponsePricingOffer;
import com.matrixx.datacontainer.mdc.MtxResponseRefundPayment;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.MtxResponseWallet;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleRequestRefundService;
import com.matrixx.datacontainer.mdc.VisibleResponseRefundService;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.CI_METADATA;
import com.matrixx.vag.common.Constants.OFFER_CONSTANTS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.Constants.TAX_CONSTANTS;
import com.matrixx.vag.common.TestConstants.BALANCE_IDS;
import com.matrixx.vag.common.TestConstants.BALANCE_NAMES;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestConstants.DATA_DIR;
import com.matrixx.vag.common.TestUtils;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.SubscriberServiceException;
import com.matrixx.vag.tax.client.TaxApiClient;
import com.matrixx.vag.tax.model.ServiceTaxRequest;
import com.matrixx.vag.tax.model.ServiceTaxResponse;
import com.matrixx.vag.util.MDCTest;

@ExtendWith(MockitoExtension.class)
public class RefundServiceTest extends MDCTest {

    @Spy
    @InjectMocks
    private final RefundService instance = new RefundService();

    @Mock
    private SubscriberManagementApi api;
   
    private TestInfo testInfo;

    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        MockitoAnnotations.openMocks(this);
        this.testInfo = testInfo;
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceDefaultV2_CancelServicesYes_ReferralCreditsYes_RefundSuccess()
            throws Exception {

        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                DATA_DIR.REFUND_SERVICE + "VisibleRequestRefundService_CancelServicesV2.json");
        input.setCancelServices("1");
        // Match with event file
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(CI_EXTERNAL_IDS.UNLIMITED);

        MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseMulti_Valid_RefundService.json");
        MtxResponseMulti cumulativeReverseMultiRes = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseMulti_CumulativeReversePurchase.json");
        MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseSubscriber_refundService.json");
        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class,
                "src/test/resources/data/refundservice/MtxResponsePaymentHistory_refundService.json");

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(
                EventQueryResponseEvents.class,
                DATA_DIR.REFUND_SERVICE + "EventQueryResponseEvents_EventType2.json");
        MtxRecurringEvent recEvent = (MtxRecurringEvent) subscriberEventInfo.getAtEventList(0).getEventDetails();
        recEvent.getBalanceUpdateArray().forEach(mbu->{
            if(BALANCE_IDS.MAIN_BALANCE == mbu.getBalanceTemplateId().longValue()) {
                mbu.setBalanceResourceId(CommonTestHelper.getBalanceResourceId(BALANCE_NAMES.MAIN_BALANCE));
            }
        });
        
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingOffer.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePricingOffer_Service.json");

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).doReturn(cumulativeReverseMultiRes).when(instance).multiRequest(
                any(), any(), argumentCaptor.capture());

        // method to test
        instance.refundServiceV2(input, output);
        // Assertions here.
        MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(0);
        assertEquals("0", String.valueOf(output.getResult()));
        assertEquals(
                "SubscriberExternalID: " + input.getSubscriberExternalId() + " Response: OK",
                output.getResultText());

        // From file MtxResponseMulti_Valid_RefundService.json
        assertEquals(
                multiRes.getResponseList().stream().filter(
                        resp -> resp.getMdcName().equals(
                                MtxResponseRefundPayment.class.getSimpleName())).map(
                                        resp -> ((MtxResponseRefundPayment) resp).getRefundInfo().getRefundTime().longValue()).findFirst().get().longValue(),
                (new MtxTimestamp(output.getRefundAmountInfo())).longValue());

        MtxRequestSubscriberRefundPayment refundReq = (MtxRequestSubscriberRefundPayment) multiReq.getRequestList().get(
                5);
        MtxRequestMulti cumulativeMultiReq = argumentCaptor.getAllValues().get(1);
        MtxRequestSubscriberPurchaseOffer cumulativeReversePurchaseReq = (MtxRequestSubscriberPurchaseOffer) cumulativeMultiReq.getRequestList().get(
                0);
        assertEquals(
                AppPropertyProvider.getInstance().getString(
                        OFFER_CONSTANTS.OFFER_EXTERNAL_ID_VISIBLE_REVERSE_SERVICE_PAYMENTS),
                cumulativeReversePurchaseReq.getOfferRequestArray().get(0).getExternalId());
        assertEquals(
                refundReq.getAmount(),
                ((VisiblePurchasedOfferExtension) cumulativeReversePurchaseReq.getOfferRequestArray().get(
                        0).getAttr()).getChargeAmount());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceDefaultV2_MultiApiError_RefundFailed() throws Exception {
        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                DATA_DIR.REFUND_SERVICE + "VisibleRequestRefundService_CancelServicesV2.json");
        // Match with event file
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(CI_EXTERNAL_IDS.UNLIMITED);

        MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseMulti_Error_RefundService.json");

        MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseSubscriber_refundService.json");

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePaymentHistory_refundService.json");

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(
                EventQueryResponseEvents.class,
                DATA_DIR.REFUND_SERVICE + "EventQueryResponseEvents_EventType2.json");

//        MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(
//                MtxResponsePricingOffer.class,
//                DATA_DIR.REFUND_SERVICE + "MtxResponsePricingOffer_Service.json");

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
       // doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        //doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(multiRes).when(instance).multiRequest(any(), any(), any());

        // method to test
        instance.refundServiceV2(input, output);
        assertEquals(
                "SubscriberExternalID: " + input.getSubscriberExternalId()
                        + " Error Message: Failed to Refund Service  - NOTOK",
                output.getResultText());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceDefaultv2_MultiApiNullResponse_RefundFailed(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.printDescription();
        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                DATA_DIR.REFUND_SERVICE + "VisibleRequestRefundService_CancelServicesV2.json");

        // Match with event file
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(CI_EXTERNAL_IDS.UNLIMITED);

        MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseSubscriber_refundService.json");

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePaymentHistory_refundService.json");

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(
                EventQueryResponseEvents.class,
                DATA_DIR.REFUND_SERVICE + "EventQueryResponseEvents_EventType2.json");

//        MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(
//                MtxResponsePricingOffer.class,
//                DATA_DIR.REFUND_SERVICE + "MtxResponsePricingOffer_Service.json");

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        //doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        //doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(null).when(instance).multiRequest(any(), any(), any());

        System.out.println(testInfo.getDisplayName() + ": input: " + input.toJson());
        // method to test
        instance.refundServiceV2(input, output);
        assertEquals(
                "SubscriberExternalID: " + input.getSubscriberExternalId()
                        + " Error Message: Failed to Refund Service ",
                output.getResultText());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceDefaultV2_NullQuerySubscriberResponse_RefundFailed()
            throws Exception {
        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                "src/test/resources/data/refundservice/VisibleRequestRefundService_CancelServicesV2.json");

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).querySubscriptionData(any(), any());

        // method to test
        instance.refundServiceV2(input, output);
        assertEquals(
                "SubscriberExternalID: " + input.getSubscriberExternalId()
                        + " Error Message: Failed to query subscriber ",
                output.getResultText());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceDefaultv2_NullQuerySubWalletResponse_RefundFailed()
            throws Exception {
        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                DATA_DIR.REFUND_SERVICE + "VisibleRequestRefundService_CancelServicesV2.json");

        // Match input offer name with EventQueryResponseEvents_EventType2.json
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(CI_EXTERNAL_IDS.UNLIMITED);

        MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseSubscriber_refundService.json");

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(
                EventQueryResponseEvents.class,
                DATA_DIR.REFUND_SERVICE + "EventQueryResponseEvents_EventType2.json");

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePaymentHistory_refundService.json");

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(null).when(instance).querySubscriptionWallet(any(), any(), any());

        // method to test
        instance.refundServiceV2(input, output);
        assertEquals(
                "SubscriberExternalID: " + input.getSubscriberExternalId()
                        + " Error Message: Failed to query subscriber Wallet",
                output.getResultText());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceDefaultV2_NullSubscriberRecurringHistoryResponse_RefundFailed()
            throws Exception {
        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                "src/test/resources/data/refundservice/VisibleRequestRefundService_CancelServicesV2.json");

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                "src/test/resources/data/refundservice/MtxResponseSubscriber_refundService.json");

        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        when(instance.queryEventListByEventIds(any(), any(), any())).thenReturn(null);

        instance.refundServiceV2(input, output);
        assertEquals(
                "SubscriberExternalID: " + input.getSubscriberExternalId()
                        + " Error Message: Failed to query events",
                output.getResultText());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceDefaultV2_NoValidCharges_RefundFailed() throws Exception {
        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                "src/test/resources/data/refundservice/VisibleRequestRefundService_CancelServicesV2.json");

        // Match with event file
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(CI_EXTERNAL_IDS.UNLIMITED);

        MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                "src/test/resources/data/refundservice/MtxResponseSubscriber_refundService.json");

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(
                EventQueryResponseEvents.class,
                "src/test/resources/data/refundservice/EventQueryResponseEvents_EventType2.json");

        // Make all charges as zero so that refundMap will not be populated.
        subscriberEventInfo.getEventList().stream().filter(
                eInfo -> eInfo.getEventDetails().getMdcName().equals(
                        MtxRecurringEvent.class.getSimpleName())).forEach(eInfo -> {
                            eInfo.getEventDetails().getChargeList().forEach(charge -> {
                                charge.setAmount(BigDecimal.ZERO);
                            });
                        });

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());

        // method to test
        instance.refundServiceV2(input, output);
        assertEquals(
                "SubscriberExternalID: " + input.getSubscriberExternalId()
                        + " Error Message: Failed to find valid charges with balance updates",
                output.getResultText());
    }

    @Test
    // With referral credits, it is possible to refund without payment gateway
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceDefaultV2_NoPaymentHistoryResponse_RefundFailed()
            throws Exception {
        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                "src/test/resources/data/refundservice/VisibleRequestRefundService_CancelServicesV2.json");

        // Match with event file
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(CI_EXTERNAL_IDS.UNLIMITED);

        MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                "src/test/resources/data/refundservice/MtxResponseSubscriber_refundService.json");

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(
                EventQueryResponseEvents.class,
                "src/test/resources/data/refundservice/EventQueryResponseEvents_EventType2.json");

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        doReturn(null).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // method to test
        instance.refundServiceV2(input, output);
        assertEquals(
                "SubscriberExternalID: " + input.getSubscriberExternalId()
                        + " Error Message: Failed to query payment history for subscriber",
                output.getResultText());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceDefaultV2_NoPaymentHistory_RefundFailed() throws Exception {
        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                "src/test/resources/data/refundservice/VisibleRequestRefundService_CancelServicesV2.json");

        // Match with event file
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(CI_EXTERNAL_IDS.UNLIMITED);

        MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                "src/test/resources/data/refundservice/MtxResponseSubscriber_refundService.json");

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(
                EventQueryResponseEvents.class,
                "src/test/resources/data/refundservice/EventQueryResponseEvents_EventType2.json");

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        doReturn(null).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // method to test
        instance.refundServiceV2(input, output);
        assertEquals(
                "SubscriberExternalID: " + input.getSubscriberExternalId()
                        + " Error Message: Failed to query payment history for subscriber",
                output.getResultText());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceDefaultV2_CancellServicesYes_ReferralCreditsNo_CorrectMultiRequestOrdering()
            throws Exception {
        // Test case to check that individual requests in Multirequest input are in
        // correct order

        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                DATA_DIR.REFUND_SERVICE + "VisibleRequestRefundService_CancelServicesV2.json");
        // Match with event file
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(CI_EXTERNAL_IDS.UNLIMITED);
        input.setCancelServices("1");

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseSubscriber_refundService.json");

        MtxResponseWallet walletRes = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseWallet_refundService.json");
        // Remove all referal credit balances so that only Mainbalance will be available
        // at runtime
        walletRes.getBalanceArray().clear();

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePaymentHistory_refundService.json");

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingOffer.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePricingOffer_Service.json");

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(
                EventQueryResponseEvents.class,
                DATA_DIR.REFUND_SERVICE + "EventQueryResponseEvents_EventType2.json");
        // Assuming referral balance is first one to be added. Remove referral charge
        // from events.
        Iterator<EventQueryEventInfo> itr = subscriberEventInfo.getEventList().iterator();
        while (itr.hasNext()) {
            EventQueryEventInfo eInfo = itr.next();
            if (eInfo.getEventDetails().getMdcName().equals(
                    MtxRecurringEvent.class.getSimpleName())) {
                if (((MtxRecurringEvent) eInfo.getEventDetails()).getChargeList().size() > 1) {
                    ((MtxRecurringEvent) eInfo.getEventDetails()).getChargeList().get(0).setAmount(
                            BigDecimal.ZERO);
                }
            }
        }

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(walletRes).when(instance).querySubscriptionWallet(any(), any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        instance.refundServiceV2(input, output);

        // Assertions here.
        Iterator<MtxRequest> reqitr = argumentCaptor.getAllValues().get(
                0).getRequestList().iterator();
        assertEquals(
                MtxRequestSubscriberAdjustBalance.class.getSimpleName(),
                reqitr.next().getContainer().getName());
        assertEquals(
                MtxRequestDeviceDeleteSession.class.getSimpleName(),
                reqitr.next().getContainer().getName());
        assertEquals(
                MtxRequestDeviceDeleteSession.class.getSimpleName(),
                reqitr.next().getContainer().getName());
        assertEquals(
                MtxRequestDeviceDeleteSession.class.getSimpleName(),
                reqitr.next().getContainer().getName());
        assertEquals(
                MtxRequestSubscriberCancelOffer.class.getSimpleName(),
                reqitr.next().getContainer().getName());
        assertEquals(
                MtxRequestSubscriberRefundPayment.class.getSimpleName(),
                reqitr.next().getContainer().getName());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceDefaultV2_CancellationNo_ReferralCreditsNo_CorrectMultiRequestOrdering()
            throws Exception {
        // Test case to check that individual requests in Multirequest input are in
        // correct order
        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                DATA_DIR.REFUND_SERVICE + "VisibleRequestRefundService_CancelServicesV2.json");
        // Match with event file
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(CI_EXTERNAL_IDS.UNLIMITED);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseSubscriber_refundService.json");

        MtxResponseWallet walletRes = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseWallet_refundService.json");

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePaymentHistory_refundService.json");

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingOffer.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePricingOffer_Service.json");

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(
                EventQueryResponseEvents.class,
                DATA_DIR.REFUND_SERVICE + "EventQueryResponseEvents_EventType2.json");
        // Assuming referral balance is first one to be added. Remove referral charge
        // from events.
        Iterator<EventQueryEventInfo> itr = subscriberEventInfo.getEventList().iterator();
        while (itr.hasNext()) {
            EventQueryEventInfo eInfo = itr.next();
            if (eInfo.getEventDetails().getMdcName().equals(
                    MtxRecurringEvent.class.getSimpleName())) {
                if (((MtxRecurringEvent) eInfo.getEventDetails()).getChargeList().size() > 1) {
                    ((MtxRecurringEvent) eInfo.getEventDetails()).getChargeList().get(0).setAmount(
                            BigDecimal.ZERO);
                }
            }
        }

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(walletRes).when(instance).querySubscriptionWallet(any(), any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        instance.refundServiceV2(input, output);

        // Assertions here.
        ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();

        assertEquals(
                MtxRequestSubscriberAdjustBalance.class.getSimpleName(),
                reqList.get(0).getMdcName());
        assertEquals(
                MtxRequestSubscriberRefundPayment.class.getSimpleName(),
                reqList.get(reqList.size() - 1).getMdcName());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceDefaultV2_ValidRequestValidMatrixxData_PurchaseServiceEventInAdjReason()
            throws Exception {
        // Test case to check if Purchase Device event is added to adjustment reason
        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                DATA_DIR.REFUND_SERVICE + "VisibleRequestRefundService_CancelServicesV2.json");
        // Match with event file
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(CI_EXTERNAL_IDS.UNLIMITED);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseSubscriber_refundService.json");

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePaymentHistory_refundService.json");

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(
                EventQueryResponseEvents.class,
                DATA_DIR.REFUND_SERVICE + "EventQueryResponseEvents_EventType2.json");
        MtxRecurringEvent recEvent = (MtxRecurringEvent) subscriberEventInfo.getAtEventList(0).getEventDetails();
        recEvent.getBalanceUpdateArray().forEach(mbu->{
            if(BALANCE_IDS.MAIN_BALANCE == mbu.getBalanceTemplateId().longValue()) {
                mbu.setBalanceResourceId(CommonTestHelper.getBalanceResourceId(BALANCE_NAMES.MAIN_BALANCE));
            }
        });
        
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingOffer.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePricingOffer_Service.json");

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        instance.refundServiceV2(input, output);
        // Assertions here.
        ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();

        String adjReason = ((MtxRequestSubscriberAdjustBalance) (reqList.get(0))).getReason();
        assertTrue(adjReason.startsWith(CommonUtils.REVERSAL_PREFIX));
        assertTrue(
                adjReason.contains(
                        subscriberEventInfo.getEventList().stream().map(
                                eInfo -> eInfo.getEventDetails()).filter(
                                        event -> event.getMdcName().equals(
                                                MtxRecurringEvent.class.getSimpleName())).map(
                                                        event -> event.getEventId()).collect(
                                                                Collectors.joining(
                                                                        StringUtils.SPACE))));
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceDefaultV2_ValidRequestValidMatrixxData_PurchaseServiceEventInAdjReasonForPartialReversal()
            throws Exception {
        // Test case to check if Purchase Device event is added to adjustment reason
        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                DATA_DIR.REFUND_SERVICE
                        + "VisibleRequestRefundService_CancelServicesV2_PartialReversal.json");
        // Match with event file
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseSubscriber_refundService.json");
        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePaymentHistory_refundService.json");

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(
                EventQueryResponseEvents.class,
                DATA_DIR.REFUND_SERVICE + "EventQueryResponseEvents_EventType2.json");
        MtxRecurringEvent recEvent = (MtxRecurringEvent) subscriberEventInfo.getAtEventList(0).getEventDetails();
        recEvent.getBalanceUpdateArray().forEach(mbu->{
            if(BALANCE_IDS.MAIN_BALANCE == mbu.getBalanceTemplateId().longValue()) {
                mbu.setBalanceResourceId(CommonTestHelper.getBalanceResourceId(BALANCE_NAMES.MAIN_BALANCE));
            }
        });
        
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingOffer.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePricingOffer_Service.json");

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        instance.refundServiceV2(input, output);
        System.out.println("input: " + input.toJson());
        System.out.println("output: " + output.toJson());
        argumentCaptor.getAllValues().forEach(multiReq->{
            System.out.println("multiReq: " + multiReq.toJson());
        });
        // Assertions here.
        ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();

        String adjReason = ((MtxRequestSubscriberAdjustBalance) (reqList.get(0))).getReason();
        assertTrue(adjReason.startsWith(CommonUtils.PARTIAL_REVERSAL_PREFIX));
        assertTrue(
                adjReason.contains(
                        subscriberEventInfo.getEventList().stream().map(
                                eInfo -> eInfo.getEventDetails()).filter(
                                        event -> event.getMdcName().equals(
                                                MtxRecurringEvent.class.getSimpleName())).map(
                                                        event -> event.getEventId()).collect(
                                                                Collectors.joining(
                                                                        StringUtils.SPACE))));
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceDefaultV2_NoReferralCredits_SingleAdjustment() throws Exception {
        // Test case to check that there is only one adjustment
        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                DATA_DIR.REFUND_SERVICE + "VisibleRequestRefundService_CancelServicesV2.json");
        // Match with event file
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseSubscriber_refundService.json");

        MtxResponseWallet walletRes = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseWallet_refundService.json");
        // Remove all referal credit balances so that only Mainbalance will be available
        // at runtime
        walletRes.getBalanceArray().clear();

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePaymentHistory_refundService.json");

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingOffer.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePricingOffer_Service.json");

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(
                EventQueryResponseEvents.class,
                DATA_DIR.REFUND_SERVICE + "EventQueryResponseEvents_EventType2.json");
        // Assuming referral balance is first one to be added. Remove referral charge
        // from events.
        Iterator<EventQueryEventInfo> itr = subscriberEventInfo.getEventList().iterator();
        while (itr.hasNext()) {
            EventQueryEventInfo eInfo = itr.next();
            if (eInfo.getEventDetails().getMdcName().equals(
                    MtxRecurringEvent.class.getSimpleName())) {
                if (((MtxRecurringEvent) eInfo.getEventDetails()).getChargeList().size() > 1) {
                    ((MtxRecurringEvent) eInfo.getEventDetails()).getChargeList().get(0).setAmount(
                            BigDecimal.ZERO);
                    ;
                }
            }
        }

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(walletRes).when(instance).querySubscriptionWallet(any(), any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        instance.refundServiceV2(input, output);

        // Assertions here.
        ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();

        int adjCount = 0;
        for (MtxRequest req : reqList) {
            if (req.getMdcName().equals(MtxRequestSubscriberAdjustBalance.class.getSimpleName())) {
                adjCount++;
            }
        }

        assertEquals(1, adjCount);
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceDefaultV2_Multiple_PayAuthEventId() throws Exception {
        // Test case to validate values of refund payment when payment is split in multiple autorizations.
        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class, DATA_DIR.REFUND_SERVICE
                        + "VisibleRequestRefundService_CancelServicesV2_Multiple_PayAuth.json");
        MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseMulti_nonRefundV2.json");
        MtxResponseMulti multiRes1 = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseMulti_Refund1_V2.json");
        MtxResponseMulti multiRes2 = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseMulti_Refund2_V2.json");
        MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseSubscriber_refundServiceV2.json");

        MtxResponseWallet walletRes = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseWallet_refundServiceV2.json");
        // Remove all referal credit balances so that only Mainbalance will be available
        // at runtime
        walletRes.getBalanceArray().clear();

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePaymentHistory_refundServiceV2.json");

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingOffer.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePricingOffer_ServiceV2.json");

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(
                EventQueryResponseEvents.class,
                DATA_DIR.REFUND_SERVICE + "EventQueryResponseEventsV2.json");
        // Assuming referral balance is first one to be added. Remove referral charge
        // from events.
        Iterator<EventQueryEventInfo> itr = subscriberEventInfo.getEventList().iterator();
        while (itr.hasNext()) {
            EventQueryEventInfo eInfo = itr.next();
            if (eInfo.getEventDetails().getMdcName().equals(
                    MtxRecurringEvent.class.getSimpleName())) {
                if (((MtxRecurringEvent) eInfo.getEventDetails()).getChargeList().size() > 1) {
                    ((MtxRecurringEvent) eInfo.getEventDetails()).getChargeList().get(0).setAmount(
                            BigDecimal.ZERO);
                }
            }
        }

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(walletRes).when(instance).querySubscriptionWallet(any(), any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes).thenReturn(
                multiRes1).thenReturn(multiRes2);

        // method to test
        instance.refundServiceV2(input, output);

        // Assertions here.
        List<MtxRequestMulti> reqLists = argumentCaptor.getAllValues();
        // ArrayList<MtxRequest> reqList = reqLists.get(0).getRequestList();
        ArrayList<MtxRequest> reqList1 = reqLists.get(1).getRequestList();
        ArrayList<MtxRequest> reqList2 = reqLists.get(2).getRequestList();
        ArrayList<MtxRequest> cumulativeRevereseReqList1 = reqLists.get(3).getRequestList();
        ArrayList<MtxRequest> cumulativeRevereseReqList2 = reqLists.get(4).getRequestList();
        assertTrue(reqList1.size() == 1);
        assertTrue(reqList2.size() == 1);

        double paynowRefundRequestAmount1 = reqList1.stream().filter(
                req -> req.getMdcName().equals(
                        MtxRequestSubscriberRefundPayment.class.getSimpleName())).map(
                                req -> ((MtxRequestSubscriberRefundPayment) req).getAmount()).findFirst().get().doubleValue();
        double paynowRefundRequestAmount2 = reqList2.stream().filter(
                req -> req.getMdcName().equals(
                        MtxRequestSubscriberRefundPayment.class.getSimpleName())).map(
                                req -> ((MtxRequestSubscriberRefundPayment) req).getAmount()).findFirst().get().doubleValue();

        double paynowRefundRequestAmount = paynowRefundRequestAmount1 + paynowRefundRequestAmount2;

        assertEquals(
                String.valueOf(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS),
                String.valueOf(output.getResult()));

        assertEquals("SubscriberExternalID: "+input.getSubscriberExternalId()+" Response: OK", output.getResultText());

        assertEquals(
                subscriberEventInfo.getEventList().stream().map(
                        eInfo -> eInfo.getEventDetails()).filter(
                                event -> event.getMdcName().equals(
                                        MtxRecurringEvent.class.getSimpleName())).map(
                                                event -> ((MtxRecurringEvent) event).getChargeList()).flatMap(
                                                        eventChargeList -> eventChargeList.stream()).map(
                                                                charge -> charge.getAmount()).mapToDouble(
                                                                        d -> d.setScale(
                                                                                2,
                                                                                RoundingMode.HALF_UP).doubleValue()).sum()
                        + "",
                output.getRefundedAmount());
        assertEquals(String.valueOf(paynowRefundRequestAmount), output.getRefundedAmount());
        // From file MtxResponseMulti_Valid_RefundService.json
        assertEquals(
                multiRes2.getResponseList().stream().filter(
                        resp -> resp.getMdcName().equals(
                                MtxResponseRefundPayment.class.getSimpleName())).map(
                                        resp -> ((MtxResponseRefundPayment) resp).getRefundInfo().getRefundTime().longValue()).findFirst().get().longValue(),
                (new MtxTimestamp(output.getRefundAmountInfo())).longValue());

        assertEquals(
                ((MtxRequestSubscriberRefundPayment) reqList1.get(0)).getAmount(),
                ((VisiblePurchasedOfferExtension) (((MtxRequestSubscriberPurchaseOffer) cumulativeRevereseReqList1.get(
                        0)).getOfferRequestArray().get(0).getAttr())).getChargeAmount());
        assertEquals(
                ((MtxRequestSubscriberRefundPayment) reqList2.get(0)).getAmount(),
                ((VisiblePurchasedOfferExtension) (((MtxRequestSubscriberPurchaseOffer) cumulativeRevereseReqList2.get(
                        0)).getOfferRequestArray().get(0).getAttr())).getChargeAmount());

        assertTrue(
                ((MtxRequestSubscriberPurchaseOffer) cumulativeRevereseReqList1.get(
                        0)).getOfferRequestArray().get(0).getExternalId().equals(
                                AppPropertyProvider.getInstance().getString(
                                        OFFER_CONSTANTS.OFFER_EXTERNAL_ID_VISIBLE_REVERSE_SERVICE_PAYMENTS)));
        assertTrue(
                ((MtxRequestSubscriberPurchaseOffer) cumulativeRevereseReqList2.get(
                        0)).getOfferRequestArray().get(0).getExternalId().equals(
                                AppPropertyProvider.getInstance().getString(
                                        OFFER_CONSTANTS.OFFER_EXTERNAL_ID_VISIBLE_REVERSE_SERVICE_PAYMENTS)));
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceDefaultV2_ServiceAndInsuranceRenewed_RefundSuccess()
            throws Exception {

        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                DATA_DIR.REFUND_SERVICE + "VisibleRequestRefundService_CancelServicesV2.json");
        input.setCancelServices("1");

        MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseMulti_Valid_RefundService.json");
        MtxResponseMulti cumulativeReverseMultiRes = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseMulti_CumulativeReversePurchase.json");
        MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseSubscriber_refundService.json");
        MtxResponseWallet walletRes = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseWallet_refundService.json");

        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class,
                "src/test/resources/data/refundservice/MtxResponsePaymentHistory_refundService.json");

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(
                EventQueryResponseEvents.class,
                DATA_DIR.REFUND_SERVICE + "EQRE_EventType2_Renewal_ServiceAndInsurance.json");
        // Match Balance ResourceId in wallet and recurring event
        BigDecimal maxRefund = BigDecimal.ZERO;
        for (MtxBalanceInfo bi : walletRes.getBalanceArray()) {
            if (bi.getContainer().getName().equals(MtxBalanceInfoSimple.class.getSimpleName())) {
                MtxBalanceInfoSimple bis = (MtxBalanceInfoSimple) bi;
                if (bis.getIsMainBalance()) {
                    for (EventQueryEventInfo eqei : subscriberEventInfo.getEventList()) {
                        if (eqei.getEventDetails().getContainer().getName().equals(
                                MtxRecurringEvent.class.getSimpleName())) {
                            MtxRecurringEvent re = (MtxRecurringEvent) eqei.getEventDetails();
                            re.getBalanceUpdateArray().get(0).setBalanceResourceId(
                                    bis.getResourceId());
                            maxRefund = re.getBalanceUpdateArray().get(0).getAmount();
                        }
                    }
                }
            }
        }

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingOffer.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePricingOffer_Service.json");

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(walletRes).when(instance).querySubscriptionWallet(any(), any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).doReturn(cumulativeReverseMultiRes).when(instance).multiRequest(
                any(), any(), argumentCaptor.capture());

        // method to test
        instance.refundServiceV2(input, output);

        // Assertions here.
        MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(0);
        assertEquals("0", String.valueOf(output.getResult()));
        assertEquals("SubscriberExternalID: "+input.getSubscriberExternalId()+" Response: OK", output.getResultText());
        MtxRequestSubscriberRefundPayment refundReq = (MtxRequestSubscriberRefundPayment) multiReq.getRequestList().get(
                5);
        MtxRequestMulti cumulativeMultiReq = argumentCaptor.getAllValues().get(1);
        MtxRequestSubscriberPurchaseOffer cumulativeReversePurchaseReq = (MtxRequestSubscriberPurchaseOffer) cumulativeMultiReq.getRequestList().get(
                0);
        assertEquals(
                AppPropertyProvider.getInstance().getString(
                        OFFER_CONSTANTS.OFFER_EXTERNAL_ID_VISIBLE_REVERSE_SERVICE_PAYMENTS),
                cumulativeReversePurchaseReq.getOfferRequestArray().get(0).getExternalId());
        assertEquals(
                refundReq.getAmount(),
                ((VisiblePurchasedOfferExtension) cumulativeReversePurchaseReq.getOfferRequestArray().get(
                        0).getAttr()).getChargeAmount());

        assertEquals(
                refundReq.getAmount().compareTo(maxRefund), -1,
                "Refund amount should be less than max balance update for mainbalance.");
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceInsuranceV2_RefundType2_OneBillingCycle_RefundSuccess(TestInfo testInfo)
            throws Exception {
        // Test case to check that
        // 1. Full Amount is returned
        // 2. Prorated unused amount is adjusted to main balance

        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                DATA_DIR.REFUND_SERVICE + "VisibleRequestRefundServiceV2_RefundType2.json");
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(CI_EXTERNAL_IDS.INSURANCE);
        MtxResponseWallet walletRes = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseWallet_refundService.json");

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePaymentHistory_refundServiceInsurance.json");

        MtxRecurringEvent event = CommonTestHelper.getMtxRecurringEvent(
                Arrays.asList(CI_EXTERNAL_IDS.INSURANCE));
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getEventQueryResponseEvents();
        subscriberEventInfo.getAtEventList(0).setEventDetails(event);
        System.out.println(
                testInfo.getDisplayName() + ": subscriberEventInfo: "
                        + subscriberEventInfo.toJson());
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(walletRes).when(instance).querySubscriptionWallet(any(), any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguments for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        System.out.println(testInfo.getDisplayName() + ": InputRequest: " + input.toJson());
        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                            taxApiResp2);
            // method to test
            instance.refundServiceV2(input, output);
        }

        // Assertions here.
        long mainBalanceResourceId = walletRes.getBalanceArray().stream().filter(
                balInfo -> balInfo.getName().equals("Mainbalance")).map(
                        balInfo -> balInfo.getResourceId()).collect(Collectors.toList()).get(0);

        // Refund from file EventQueryResponseEvents_EventType2.json and
        // MtxResponseCancel_validResponse.json
        assertEquals(
                subscriberEventInfo.getEventList().stream().map(
                        eInfo -> eInfo.getEventDetails()).filter(
                                event1 -> event.getMdcName().equals(
                                        MtxRecurringEvent.class.getSimpleName())).map(
                                                event1 -> ((MtxRecurringEvent) event).getBalanceUpdateArray()).flatMap(
                                                        bUpList -> bUpList.stream()).filter(
                                                                bUpdate -> bUpdate.getBalanceResourceId() == mainBalanceResourceId).map(
                                                                        fBalUpdate -> fBalUpdate.getAmount()).mapToDouble(
                                                                                d -> d.setScale(
                                                                                        2,
                                                                                        RoundingMode.HALF_UP).doubleValue()).sum(),
                argumentCaptor.getAllValues().get(0).getRequestList().stream().filter(
                        req -> req.getMdcName().equals(
                                MtxRequestSubscriberRefundPayment.class.getSimpleName())).map(
                                        refReq -> ((MtxRequestSubscriberRefundPayment) refReq).getAmount()).mapToDouble(
                                                d -> d.setScale(
                                                        2,
                                                        RoundingMode.HALF_UP).doubleValue()).sum(),
                0.1);
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceInsuranceV2_RefundType2_RefundMultiNullResponse_SubscriberException(TestInfo testInfo)
            throws Exception {

        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                DATA_DIR.REFUND_SERVICE + "VisibleRequestRefundServiceV2_RefundType2.json");
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(CI_EXTERNAL_IDS.INSURANCE);

        MtxResponseWallet walletRes = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseWallet_refundService.json");

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class, DATA_DIR.REFUND_SERVICE
                        + "MtxResponsePaymentHistoryV2_refundServiceInsurance.json");

        MtxRecurringEvent event = CommonTestHelper.getMtxRecurringEvent(
                Arrays.asList(CI_EXTERNAL_IDS.INSURANCE));
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getEventQueryResponseEvents();
        subscriberEventInfo.getAtEventList(0).setEventDetails(event);
        System.out.println(
                testInfo.getDisplayName() + ": subscriberEventInfo: "
                        + subscriberEventInfo.toJson());

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
        multiRes.setResultText("NotOK");
        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(walletRes).when(instance).querySubscriptionWallet(any(), any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguments for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        System.out.println(testInfo.getDisplayName() + ": InputRequest: " + input.toJson());
        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                            taxApiResp2);
            // method to test
            instance.refundServiceV2(input, output);
        }
        assertEquals(
                "SubscriberExternalID: "+input.getSubscriberExternalId()+" Error Message: Failed to Refund Service  - NotOK",
                output.getResultText());
    }

    @SuppressWarnings("unchecked")
    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceInsuranceV2_RefundType2_TwoBillingCycles_RefundSuccess(TestInfo testInfo)
            throws Exception {
        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class, DATA_DIR.REFUND_SERVICE
                        + "VisibleRequestRefundServiceV2_RefundType2_TwoBillCycles.json");
        input.setRefundType("2");
        input.setCancelServices("1");
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(CI_EXTERNAL_IDS.INSURANCE);

        MtxResponseWallet walletRes = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseWallet_refundService.json");

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePaymentHistory_refundServiceInsurance.json");

        MtxRecurringEvent event1 = CommonTestHelper.getMtxRecurringEvent(
                Arrays.asList(CI_EXTERNAL_IDS.INSURANCE));
        MtxRecurringEvent event2 = CommonTestHelper.getMtxRecurringEvent(
                Arrays.asList(CI_EXTERNAL_IDS.INSURANCE));
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getEventQueryResponseEvents();
        subscriberEventInfo.getAtEventList(0).setEventDetails(event1);
        EventQueryEventInfo eqei = new EventQueryEventInfo();
        subscriberEventInfo.getEventListAppender().add(eqei);
        subscriberEventInfo.getAtEventList(1).setEventDetails(event2);

        System.out.println(
                testInfo.getDisplayName() + ": subscriberEventInfo: "
                        + subscriberEventInfo.toJson());
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(walletRes).when(instance).querySubscriptionWallet(any(), any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguments for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        System.out.println(testInfo.getDisplayName() + ": InputRequest: " + input.toJson());
        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                            taxApiResp2);
            // method to test
            instance.refundServiceV2(input, output);
        }

        // Assertions here.
        long mainBalanceResourceId = walletRes.getBalanceArray().stream().filter(
                balInfo -> balInfo.getName().equals("Mainbalance")).map(
                        balInfo -> balInfo.getResourceId()).collect(Collectors.toList()).get(0);

        double refundAmount = 0;
        for (int i = 0; i < argumentCaptor.getAllValues().size(); i++) {
            if (i > 0) {
                refundAmount += argumentCaptor.getAllValues().get(
                        i).getRequestList().stream().filter(
                                req -> req.getMdcName().equals(
                                        MtxRequestSubscriberRefundPayment.class.getSimpleName())).map(
                                                refReq -> ((MtxRequestSubscriberRefundPayment) refReq).getAmount()).mapToDouble(
                                                        d -> d.setScale(
                                                                2,
                                                                RoundingMode.HALF_UP).doubleValue()).sum();
            }
        }
        // Refund from file EventQueryResponseEvents_EventType2.json and
        // MtxResponseCancel_validResponse.json
        assertEquals(
                subscriberEventInfo.getEventList().stream().map(
                        eInfo -> eInfo.getEventDetails()).filter(
                                event -> event.getMdcName().equals(
                                        MtxRecurringEvent.class.getSimpleName())).map(
                                                event -> ((MtxRecurringEvent) event).getBalanceUpdateArray()).flatMap(
                                                        bUpList -> bUpList.stream()).filter(
                                                                bUpdate -> bUpdate.getBalanceResourceId() == mainBalanceResourceId).map(
                                                                        fBalUpdate -> fBalUpdate.getAmount()).mapToDouble(
                                                                                d -> d.setScale(
                                                                                        2,
                                                                                        RoundingMode.HALF_UP).doubleValue()).sum(),
                refundAmount, 0.1);
    }

    @SuppressWarnings("unchecked")
    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceInsuranceV2_RefundType2_ThreeBillingCycles_RefundSuccess(TestInfo testInfo)
            throws Exception {
        // Test case to check that
        // 1. Full Amount is returned
        // 2. Prorated unused amount is adjusted to main balance
        // 3. Individual requests in multirequest are in correct order:
        // AdjustBalance->SubscriberRefund->CancelOffer
        // 4. Adjustment reason has required event ids

        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class, DATA_DIR.REFUND_SERVICE
                        + "VisibleRequestRefundServiceV2_RefundType2_ThreeBillCycles.json");
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(CI_EXTERNAL_IDS.INSURANCE);
        MtxResponseWallet walletRes = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseWallet_refundService.json");

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePaymentHistory_refundServiceInsurance.json");

        MtxRecurringEvent event1 = CommonTestHelper.getMtxRecurringEvent(
                Arrays.asList(CI_EXTERNAL_IDS.INSURANCE));

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getEventQueryResponseEvents();
        subscriberEventInfo.getAtEventList(0).setEventDetails(event1);

        EventQueryEventInfo eqei2 = new EventQueryEventInfo();
        subscriberEventInfo.getEventListAppender().add(eqei2);
        MtxRecurringEvent event2 = CommonTestHelper.getMtxRecurringEvent(
                Arrays.asList(CI_EXTERNAL_IDS.INSURANCE));
        subscriberEventInfo.getAtEventList(1).setEventDetails(event2);

        EventQueryEventInfo eqei3 = new EventQueryEventInfo();
        subscriberEventInfo.getEventListAppender().add(eqei3);
        MtxRecurringEvent event3 = CommonTestHelper.getMtxRecurringEvent(
                Arrays.asList(CI_EXTERNAL_IDS.INSURANCE));
        subscriberEventInfo.getAtEventList(2).setEventDetails(event3);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(walletRes).when(instance).querySubscriptionWallet(any(), any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguments for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        System.out.println(testInfo.getDisplayName() + ": InputRequest: " + input.toJson());
        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                            taxApiResp2);
            // method to test
            instance.refundServiceV2(input, output);
        }

        // Assertions here.
        long mainBalanceResourceId = walletRes.getBalanceArray().stream().filter(
                balInfo -> balInfo.getName().equals("Mainbalance")).map(
                        balInfo -> balInfo.getResourceId()).collect(Collectors.toList()).get(0);

        double refundAmount = 0;
        for (int i = 0; i < argumentCaptor.getAllValues().size(); i++) {
            if (i > 0) {
                refundAmount += argumentCaptor.getAllValues().get(
                        i).getRequestList().stream().filter(
                                req -> req.getMdcName().equals(
                                        MtxRequestSubscriberRefundPayment.class.getSimpleName())).map(
                                                refReq -> ((MtxRequestSubscriberRefundPayment) refReq).getAmount()).mapToDouble(
                                                        d -> d.setScale(
                                                                2,
                                                                RoundingMode.HALF_UP).doubleValue()).sum();
            }
        }

        // Refund from file EventQueryResponseEvents_EventType2.json and
        // MtxResponseCancel_validResponse.json
        assertEquals(
                subscriberEventInfo.getEventList().stream().map(
                        eInfo -> eInfo.getEventDetails()).filter(
                                event -> event.getMdcName().equals(
                                        MtxRecurringEvent.class.getSimpleName())).map(
                                                event -> ((MtxRecurringEvent) event).getBalanceUpdateArray()).flatMap(
                                                        bUpList -> bUpList.stream()).filter(
                                                                bUpdate -> bUpdate.getBalanceResourceId() == mainBalanceResourceId).map(
                                                                        fBalUpdate -> fBalUpdate.getAmount()).mapToDouble(
                                                                                d -> d.setScale(
                                                                                        2,
                                                                                        RoundingMode.HALF_UP).doubleValue()).sum(),
                refundAmount, 0.1);

        assertTrue(
                ((MtxRequestSubscriberAdjustBalance) argumentCaptor.getAllValues().get(
                        0).getRequestList().get(0)).getReason().indexOf(
                                CommonUtils.REVERSAL_PREFIX) > -1);
        // From EventQueryResponseEvents_EventType2_3Cycles.json
        Object[] eArray = subscriberEventInfo.getEventList().stream().map(
                eInfo -> eInfo.getEventDetails()).filter(
                        event -> event.getMdcName().equals(
                                MtxRecurringEvent.class.getSimpleName())).map(
                                        event -> ((MtxRecurringEvent) event).getEventId()).toArray();

        assertTrue(
                ((MtxRequestSubscriberAdjustBalance) argumentCaptor.getAllValues().get(
                        0).getRequestList().get(0)).getReason().contains(eArray[0].toString()));
        assertTrue(
                ((MtxRequestSubscriberAdjustBalance) argumentCaptor.getAllValues().get(
                        0).getRequestList().get(0)).getReason().contains(eArray[1].toString()));
        assertTrue(
                ((MtxRequestSubscriberAdjustBalance) argumentCaptor.getAllValues().get(
                        0).getRequestList().get(0)).getReason().contains(eArray[2].toString()));
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceInsuranceV2_RefundType1_Success(TestInfo testInfo)
            throws Exception {
        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class, DATA_DIR.REFUND_SERVICE
                        + "VisibleRequestRefundServiceV2_RefundTypeProrata_ValidRequest.json");
        // Match with event file
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(
                CI_EXTERNAL_IDS.INSURANCE);

        MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseMulti_Valid_RefundService_Prorata.json");

        MtxRecurringEvent event = CommonTestHelper.getMtxRecurringEvent(
                Arrays.asList(CI_EXTERNAL_IDS.INSURANCE));
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getEventQueryResponseEvents();
        subscriberEventInfo.getAtEventList(0).setEventDetails(event);

        System.out.println(
                testInfo.getDisplayName() + ": subscriberEventInfo: "
                        + subscriberEventInfo.toJson());

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class, DATA_DIR.REFUND_SERVICE
                        + "MtxResponsePaymentHistory_Valid_RefundService_Prorata.json");

        MtxResponseCancel cancelResp = CommonTestHelper.getMtxResponseCancel();
        
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingOffer.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePricingOffer_Insurance.json");

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        when(api.multi(any(), any())).thenReturn(multiRes);

        System.out.println(testInfo.getDisplayName() + ": InputRequest: " + input.toJson());
        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                            taxApiResp2);
            // method to test
            instance.refundServiceV2(input, output);
        }

        // Assertions here.
        assertEquals("0", String.valueOf(output.getResult()));
        assertEquals(
                "SubscriberExternalID: "+input.getSubscriberExternalId()+" Response: OK", output.getResultText());
        assertEquals(
                cancelResp.getCancelInfoArray().get(0).getBalanceImpactGroupList().get(
                        0).getBalanceImpactList().get(0).getImpactAmount().negate().doubleValue(),
                Double.parseDouble(output.getRefundedAmount()), 0.01);
        assertEquals("2018-08-27T13:22:49.702927+10:00", output.getRefundAmountInfo());
    }

    @SuppressWarnings("unchecked")
    @Test
    @Tag("VER-294")
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceInsuranceV2_RefundType1_RecurringEventHasMultipleOffers_Success(TestInfo testInfo)
            throws Exception {
        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class, DATA_DIR.REFUND_SERVICE
                        + "VisibleRequestRefundServiceV2_RefundTypeProrata_ValidRequest.json");
        // Match with event file
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(
                CI_EXTERNAL_IDS.INSURANCE);
        input.getRecurringEventIdsAppender().clear();
        input.getRecurringEventIdsAppender().add("IFR0:1:52:19451");

        MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseMulti_Valid_RefundService_Prorata.json");

        MtxRecurringEvent event = CommonTestHelper.getMtxRecurringEvent(
                Arrays.asList(CI_EXTERNAL_IDS.INSURANCE, CI_EXTERNAL_IDS.PLUS_CURRENT));
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getEventQueryResponseEvents();
        subscriberEventInfo.getAtEventList(0).setEventDetails(event);

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class, DATA_DIR.REFUND_SERVICE
                        + "MtxResponsePaymentHistory_Valid_RefundService_Prorata.json");

        MtxResponseCancel cancelResp = CommonTestHelper.loadJsonMessage(
                MtxResponseCancel.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseCancel_validResponse.json");

//        MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(
//                MtxResponsePricingOffer.class,
//                DATA_DIR.REFUND_SERVICE + "MtxResponsePricingOffer_Insurance.json");

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        //doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        //doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        when(api.multi(any(), any())).thenReturn(multiRes);

        System.out.println(testInfo.getDisplayName() + ": InputRequest: " + input.toJson());
        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                            taxApiResp2);
            // method to test
            instance.refundServiceV2(input, output);
        }

        // Assertions here.
        assertEquals("0", String.valueOf(output.getResult()));
        assertEquals(
                "SubscriberExternalID: "+input.getSubscriberExternalId()+" Response: OK", output.getResultText());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    // Exception {
    public void test_refundServiceInsuranceV2_RefundType1_AocError_SubscriberServiceException(TestInfo testInfo)
            throws Exception {
        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class, DATA_DIR.REFUND_SERVICE
                        + "VisibleRequestRefundServiceV2_RefundTypeProrata_ValidRequest.json");
        // Match with event file
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(
                CI_EXTERNAL_IDS.INSURANCE);

        MtxRecurringEvent event = CommonTestHelper.getMtxRecurringEvent(
                Arrays.asList(CI_EXTERNAL_IDS.INSURANCE));
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getEventQueryResponseEvents();
        subscriberEventInfo.getAtEventList(0).setEventDetails(event);

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class, DATA_DIR.REFUND_SERVICE
                        + "MtxResponsePaymentHistory_Valid_RefundService_Prorata.json");

        MtxResponseCancel cancelErrorResp = CommonTestHelper.loadJsonMessage(
                MtxResponseCancel.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseCancel_Error_Response.json");

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        Mockito.doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(cancelErrorResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());

        System.out.println(testInfo.getDisplayName() + ": InputRequest: " + input.toJson());

        instance.refundServiceV2(input, output);
        assertEquals(
                "SubscriberExternalID: "+input.getSubscriberExternalId()+" Error Message: Failed to get AOC on cancel subscriber offer - NOTOK",
                output.getResultText());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceInsuranceV2_RefundType1_CancellServicesYes_ReferralCreditsYes_CorrectMultiRequestOrdering(TestInfo testInfo)
            throws Exception {
        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                DATA_DIR.REFUND_SERVICE + "VisibleRequestRefundServiceV2_RefundType2.json");
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(CI_EXTERNAL_IDS.INSURANCE);
        input.setRefundType("1");
        input.setCancelServices("1");
        
        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePaymentHistory_refundServiceInsurance.json");

        MtxRecurringEvent event = CommonTestHelper.getMtxRecurringEvent(
                Arrays.asList(CI_EXTERNAL_IDS.INSURANCE));
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getEventQueryResponseEvents();
        subscriberEventInfo.getAtEventList(0).setEventDetails(event);
        System.out.println(
                testInfo.getDisplayName() + ": subscriberEventInfo: "
                        + subscriberEventInfo.toJson());

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseCancel cancelResp = CommonTestHelper.loadJsonMessage(
                MtxResponseCancel.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseCancel_Insurance.json");

//        MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(
//                MtxResponsePricingOffer.class,
//                DATA_DIR.REFUND_SERVICE + "MtxResponsePricingOffer_Insurance.json");

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
//        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
//        doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        System.out.println(testInfo.getDisplayName() + ": InputRequest: " + input.toJson());
        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                            taxApiResp2);
            // method to test
            instance.refundServiceV2(input, output);
        }

        MtxRequestMulti multNonRefund = argumentCaptor.getAllValues().get(0);
        Iterator<MtxRequest> reqitr = multNonRefund.getRequestList().iterator();
        if (multNonRefund.getRequestList().size() > 1) {
            if (multNonRefund.getRequestList().get(0).getMdcName().equals(
                    MtxRequestSubscriberAdjustBalance.class.getSimpleName())) {
                // If there is a rounding adjustment
                assertEquals(
                        MtxRequestSubscriberAdjustBalance.class.getSimpleName(),
                        reqitr.next().getMdcName());
                // Modify tax details
                assertEquals(
                        MtxRequestSubscriberModifyOffer.class.getSimpleName(),
                        reqitr.next().getMdcName());
                // Cancel offer
                assertEquals(
                        MtxRequestSubscriberCancelOffer.class.getSimpleName(),
                        reqitr.next().getMdcName());
            } else {
                // Modify tax details
                assertEquals(
                        MtxRequestSubscriberModifyOffer.class.getSimpleName(),
                        reqitr.next().getMdcName());
                // Cancel offer
                assertEquals(
                        MtxRequestSubscriberCancelOffer.class.getSimpleName(),
                        reqitr.next().getMdcName());
            }
        }
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceInsuranceV2_RefundType2_CancellServicesYes_ReferralCreditsNo_CorrectMultiRequestOrdering(TestInfo testInfo)
            throws Exception {
        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class, DATA_DIR.REFUND_SERVICE
                        + "VisibleRequestRefundServiceV2_RefundTypeProrata_ValidRequest.json");
        input.setRefundType("2");
        input.setCancelServices("1");
        // Match with event file
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(
                CI_EXTERNAL_IDS.INSURANCE);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        MtxRecurringEvent event = CommonTestHelper.getMtxRecurringEvent(
                Arrays.asList(CI_EXTERNAL_IDS.INSURANCE));
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getEventQueryResponseEvents();
        subscriberEventInfo.getAtEventList(0).setEventDetails(event);
        System.out.println(
                testInfo.getDisplayName() + ": subscriberEventInfo: "
                        + subscriberEventInfo.toJson());

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class, DATA_DIR.REFUND_SERVICE
                        + "MtxResponsePaymentHistory_Valid_RefundService_Prorata.json");

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingOffer.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePricingOffer_Insurance.json");

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        System.out.println(testInfo.getDisplayName() + ": InputRequest: " + input.toJson());
        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                            taxApiResp2);
            // method to test
            instance.refundServiceV2(input, output);
        }
        // Assertions here.
        assertEquals(
                MtxRequestSubscriberAdjustBalance.class.getSimpleName(),
                argumentCaptor.getAllValues().get(0).getAtRequestList(0).getContainer().getName());
        assertEquals(
                MtxRequestSubscriberCancelOffer.class.getSimpleName(),
                argumentCaptor.getAllValues().get(0).getAtRequestList(1).getContainer().getName());
        assertEquals(
                MtxRequestSubscriberRefundPayment.class.getSimpleName(),
                argumentCaptor.getAllValues().get(1).getAtRequestList(0).getContainer().getName());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceInsuranceV2_RefundType1_CancellServicesYes_ReferralCreditsNo_RefundSuccess(TestInfo testInfo)
            throws Exception {
        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class, DATA_DIR.REFUND_SERVICE
                        + "VisibleRequestRefundServiceV2_RefundTypeProrata_ValidRequest.json");
        // Match with event file
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(
                CI_EXTERNAL_IDS.INSURANCE);

        MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseMulti_Valid_RefundService_Prorata.json");

        MtxRecurringEvent event = CommonTestHelper.getMtxRecurringEvent(
                Arrays.asList(CI_EXTERNAL_IDS.INSURANCE));
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getEventQueryResponseEvents();
        subscriberEventInfo.getAtEventList(0).setEventDetails(event);
        System.out.println(
                testInfo.getDisplayName() + ": subscriberEventInfo: "
                        + subscriberEventInfo.toJson());

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class, DATA_DIR.REFUND_SERVICE
                        + "MtxResponsePaymentHistory_Valid_RefundService_Prorata.json");

        MtxResponseCancel cancelResp = CommonTestHelper.getMtxResponseCancel();
        
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingOffer.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePricingOffer_Insurance.json");

        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        System.out.println(testInfo.getDisplayName() + ": InputRequest: " + input.toJson());
        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                            taxApiResp2);
            // method to test
            instance.refundServiceV2(input, output);
        }

        ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();
        double paynowRefundRequestAmount = reqList.stream().filter(
                req -> req.getMdcName().equals(
                        MtxRequestSubscriberRefundPayment.class.getSimpleName())).map(
                                req -> ((MtxRequestSubscriberRefundPayment) req).getAmount()).findFirst().get().doubleValue();

        double cancelAOCImpactAmount = cancelResp.getCancelInfoArray().get(
                0).getBalanceImpactGroupList().get(0).getBalanceImpactList().get(
                        0).getImpactAmount().negate().doubleValue();

        // Assertions here.
        assertEquals(cancelAOCImpactAmount, paynowRefundRequestAmount, 0.01);
        assertEquals(
                paynowRefundRequestAmount, Double.parseDouble(output.getRefundedAmount()), 0.01);
        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS, output.getResult().longValue());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceInsurance2_RefundType1_CancellServicesYes_OfferUpdatedWithNewVendorPayable(TestInfo testInfo)
            throws Exception {
        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class, DATA_DIR.REFUND_SERVICE
                        + "VisibleRequestRefundServiceV2_RefundTypeProrata_ValidRequest.json");
        // Match with event file
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(
                CI_EXTERNAL_IDS.INSURANCE);
        input.setCancelServices("1");
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        
        MtxRecurringEvent event = CommonTestHelper.getMtxRecurringEvent(
                Arrays.asList(CI_EXTERNAL_IDS.INSURANCE));
        event.getBalanceUpdateArray().forEach(mbu->{
            if(BALANCE_IDS.MAIN_BALANCE == mbu.getBalanceTemplateId().longValue()) {
                mbu.setBalanceResourceId(CommonTestHelper.getBalanceResourceId(BALANCE_NAMES.MAIN_BALANCE));
            }
        });
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getEventQueryResponseEvents();
        subscriberEventInfo.getAtEventList(0).setEventDetails(event);
        String taxApiResp1 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        ServiceTaxResponse taxApiResp1Json = CommonTestHelper.getServiceTaxResponseFromString(
                taxApiResp1);
        BigDecimal vendorPayableNonProrated = BigDecimal.valueOf(1);
        taxApiResp1Json.setVendorPayableNonProrated(vendorPayableNonProrated);
        VisiblePurchasedOfferExtension eventAttr = (VisiblePurchasedOfferExtension) event.getAtAppliedBundleArray(
                0).getPurchasedBundleAttr();
        eventAttr.setTaxDetails(taxApiResp1Json.toJson());
        System.out.println(
                testInfo.getDisplayName() + ": subscriberEventInfo: "
                        + subscriberEventInfo.toJson());

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class, DATA_DIR.REFUND_SERVICE
                        + "MtxResponsePaymentHistory_Valid_RefundService_Prorata.json");

        MtxResponseCancel cancelResp = CommonTestHelper.getMtxResponseCancel();
        
//        MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(
//                MtxResponsePricingOffer.class,
//                DATA_DIR.REFUND_SERVICE + "MtxResponsePricingOffer_Insurance.json");
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);
        
        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
//        doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());

        BigDecimal expectedVP = cancelResp.getAtCancelInfoArray(0).getAtBalanceImpactGroupList(
                0).getAtBalanceImpactList(0).getImpactAmount().abs().multiply(
                        taxApiResp1Json.getVendorPayableNonProrated()).divide(
                                eventAttr.getChargeAmount(),
                                TAX_CONSTANTS.TAX_API_DISPLAY_PRECISION, RoundingMode.HALF_UP);

        ArgumentCaptor<MtxRequestMulti> argumentCaptorMulti = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptorMulti.capture())).thenReturn(multiRes);

        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        ServiceTaxResponse taxApiResp2Json = CommonTestHelper.getServiceTaxResponseFromString(
                taxApiResp2);

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(
                            any(), argumentCaptor.capture())).thenReturn(taxApiResp2);
            // method to test
            instance.refundServiceV2(input, output);
        }
        System.out.println(testInfo.getDisplayName() + ": InputRequest: " + input.toJson());
        System.out.println(testInfo.getDisplayName() + ": output: " + output.toJson());
        argumentCaptor.getAllValues().forEach(taxReq -> {
            System.out.println(testInfo.getDisplayName() + ": taxReq: " + taxReq);
        });

        ServiceTaxRequest taxReq = CommonTestHelper.getServiceTaxRequestFromString(
                argumentCaptor.getAllValues().get(0));
        assertEquals(expectedVP.doubleValue(), taxReq.getVendorPayable().doubleValue(), 0.01);

        ServiceTaxResponse taxRespModifyReq = CommonTestHelper.getServiceTaxResponseFromString(
                (((VisiblePurchasedOfferExtension) (new MtxRequestSubscriberModifyOffer(
                        argumentCaptorMulti.getAllValues().get(0).getAtRequestList(
                                1).getContainer())).getAttr()).getTaxDetails()));
        assertEquals(
                taxApiResp2Json.getVendorPayable().doubleValue(),
                taxRespModifyReq.getVendorPayable().doubleValue(), 0.001);

    }

    public Map<String, Map<String, Object>> getCreditDataMap() {
        Map<String, Map<String, Object>> creditDataMap = new HashMap<String, Map<String, Object>>();

        ArrayList<String> eligibleOfferList = new ArrayList<String>();
        eligibleOfferList.add(CI_EXTERNAL_IDS.UNLIMITED);
        String creditTaxForReferrals = "Tax for referrals";
        String creditTaxForGroup = "Tax for group";
        Map<String, Object> creditDataReferrals = new HashMap<String, Object>();

        creditDataReferrals.put("EligibleOffersList", eligibleOfferList);
        creditDataReferrals.put("RedeemOfferName", "Visible_Redeem_Referral_Credits");
        creditDataReferrals.put("EstimatedTransferableAmount", new BigDecimal(5));
        creditDataReferrals.put("CreditTaxDetails", creditTaxForReferrals);
        creditDataReferrals.put("RedeemableCredits", new BigDecimal(3));
        creditDataReferrals.put("RedeemOfferIndex", 0);

        creditDataMap.put("referral", creditDataReferrals);

        Map<String, Object> creditDataGroup = new HashMap<String, Object>();
        creditDataGroup.put("EligibleOffersList", eligibleOfferList);
        creditDataGroup.put("RedeemOfferName", "Visible_Redeem_Group_Discounts");
        creditDataGroup.put("EstimatedTransferableAmount", new BigDecimal(5));
        creditDataGroup.put("CreditTaxDetails", creditTaxForGroup);
        creditDataGroup.put("RedeemableCredits", new BigDecimal(3));
        creditDataGroup.put("RedeemOfferIndex", 1);

        creditDataMap.put("groupDiscount", creditDataGroup);

        return creditDataMap;

    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceDefaultV2_CancelServicesYes_GoodwillCreditYes_ReferralCreditYes_RefundSuccess()
            throws Exception {

        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                DATA_DIR.REFUND_SERVICE + "VisibleRequestRefundService_CancelServices_GC_RC.json");
        input.setCancelServices("1");
        
        MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseMulti_Valid_RefundService_GC_RC.json");

        MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseSubscriber_refundService_GC_RC.json");

        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePaymentHistory_refundService_GC_RC.json");

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(
                EventQueryResponseEvents.class,
                DATA_DIR.REFUND_SERVICE + "EventQueryResponseEvents_EventType2_GC_RC.json");
        MtxRecurringEvent recEvent = (MtxRecurringEvent) subscriberEventInfo.getAtEventList(0).getEventDetails();
        recEvent.getBalanceUpdateArray().forEach(mbu->{
            if(BALANCE_IDS.MAIN_BALANCE == mbu.getBalanceTemplateId().longValue()) {
                mbu.setBalanceResourceId(CommonTestHelper.getBalanceResourceId(BALANCE_NAMES.MAIN_BALANCE));
            }
        });
        
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingOffer.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePricingOffer_Service.json");

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        // method to test
        instance.refundServiceV2(input, output);

        // Assertions here.
        assertEquals("0", String.valueOf(output.getResult()));
        assertEquals("SubscriberExternalID: "+input.getSubscriberExternalId()+" Response: OK", output.getResultText());
        BigDecimal refundAmount = subscriberEventInfo.getAtEventList(
                0).getEventDetails().getChargeList().get(2).getAmount().setScale(
                        2, RoundingMode.HALF_UP);
        // From file MtxResponseMulti_Valid_RefundService.json
        assertEquals(
                multiRes.getResponseList().stream().filter(
                        resp -> resp.getMdcName().equals(
                                MtxResponseRefundPayment.class.getSimpleName())).map(
                                        resp -> ((MtxResponseRefundPayment) resp).getRefundInfo().getRefundTime().longValue()).findFirst().get().longValue(),
                (new MtxTimestamp(output.getRefundAmountInfo())).longValue());
        MtxRequestSubscriberRefundPayment refundRequest = (MtxRequestSubscriberRefundPayment) argumentCaptor.getAllValues().get(
                0).getRequestList().get(2);
        assertEquals(refundAmount, refundRequest.getAmount());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceDefault_CancelServicesYes_GroupCreditYes_RefundSuccess()
            throws Exception {

        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                DATA_DIR.REFUND_SERVICE + "VisibleRequestRefundService_CancelServices_GC.json");
        input.setCancelServices("1");
        
        MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseMulti_Valid_RefundService_GC.json");

        MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseSubscriber_refundService_GC.json");

        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePaymentHistory_refundService_GC.json");

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(
                EventQueryResponseEvents.class,
                DATA_DIR.REFUND_SERVICE + "EventQueryResponseEvents_EventType2_GC.json");
        MtxRecurringEvent recEvent = (MtxRecurringEvent) subscriberEventInfo.getAtEventList(0).getEventDetails();
        recEvent.getBalanceUpdateArray().forEach(mbu->{
            if(BALANCE_IDS.MAIN_BALANCE == mbu.getBalanceTemplateId().longValue()) {
                mbu.setBalanceResourceId(CommonTestHelper.getBalanceResourceId(BALANCE_NAMES.MAIN_BALANCE));
            }
        });
        
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingOffer.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePricingOffer_Service.json");

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        // method to test
        instance.refundServiceV2(input, output);
        System.out.println("input: " + input.toJson());
        System.out.println("output: " + output.toJson());
        // Assertions here.
        assertEquals("0", String.valueOf(output.getResult()));
        assertEquals("SubscriberExternalID: "+input.getSubscriberExternalId()+" Response: OK", output.getResultText());

        BigDecimal refundAmount = subscriberEventInfo.getAtEventList(
                0).getEventDetails().getChargeList().get(1).getAmount().setScale(
                        2, RoundingMode.HALF_UP);

        // From file MtxResponseMulti_Valid_RefundService.json
        assertEquals(
                multiRes.getResponseList().stream().filter(
                        resp -> resp.getMdcName().equals(
                                MtxResponseRefundPayment.class.getSimpleName())).map(
                                        resp -> ((MtxResponseRefundPayment) resp).getRefundInfo().getRefundTime().longValue()).findFirst().get().longValue(),
                (new MtxTimestamp(output.getRefundAmountInfo())).longValue());
        MtxRequestSubscriberRefundPayment refundRequest = (MtxRequestSubscriberRefundPayment) argumentCaptor.getAllValues().get(
                0).getRequestList().get(2);
        assertEquals(refundAmount, refundRequest.getAmount());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceDefault_CancelServicesYes_GroupCreditYes_ReferralCreditYes_RefundSuccess()
            throws Exception {

        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                DATA_DIR.REFUND_SERVICE + "VisibleRequestRefundService_CancelServices_GC_RC.json");
        input.setCancelServices("1");
        
        MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseMulti_Valid_RefundService_GC_RC.json");

        MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseSubscriber_refundService_GC_RC.json");

        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePaymentHistory_refundService_GC_RC.json");

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(
                EventQueryResponseEvents.class,
                DATA_DIR.REFUND_SERVICE + "EventQueryResponseEvents_EventType2_GC_RC.json");
        MtxRecurringEvent recEvent = (MtxRecurringEvent) subscriberEventInfo.getAtEventList(0).getEventDetails();
        recEvent.getBalanceUpdateArray().forEach(mbu->{
            if(BALANCE_IDS.MAIN_BALANCE == mbu.getBalanceTemplateId().longValue()) {
                mbu.setBalanceResourceId(CommonTestHelper.getBalanceResourceId(BALANCE_NAMES.MAIN_BALANCE));
            }
        });
        
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingOffer.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePricingOffer_Service.json");

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        // method to test
        instance.refundServiceV2(input, output);

        // Assertions here.
        assertEquals("0", String.valueOf(output.getResult()));
        assertEquals("SubscriberExternalID: "+input.getSubscriberExternalId()+" Response: OK", output.getResultText());
        BigDecimal refundAmount = subscriberEventInfo.getAtEventList(
                0).getEventDetails().getChargeList().get(2).getAmount().setScale(
                        2, RoundingMode.HALF_UP);
        // From file MtxResponseMulti_Valid_RefundService.json
        assertEquals(
                multiRes.getResponseList().stream().filter(
                        resp -> resp.getMdcName().equals(
                                MtxResponseRefundPayment.class.getSimpleName())).map(
                                        resp -> ((MtxResponseRefundPayment) resp).getRefundInfo().getRefundTime().longValue()).findFirst().get().longValue(),
                (new MtxTimestamp(output.getRefundAmountInfo())).longValue());
        MtxRequestSubscriberRefundPayment refundRequest = (MtxRequestSubscriberRefundPayment) argumentCaptor.getAllValues().get(
                0).getRequestList().get(2);
        assertEquals(refundAmount, refundRequest.getAmount());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceDefault_CancelServicesYes_GoodwillCreditYes_GoodwillCreditYes_RefundSuccess()
            throws Exception {

        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                DATA_DIR.REFUND_SERVICE + "VisibleRequestRefundService_CancelServices_GC_RC.json");
        input.setCancelServices("1");
        
        MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseMulti_Valid_RefundService_GC_RC.json");

        MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseSubscriber_refundService_GC_RC.json");

        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePaymentHistory_refundService_GC_RC.json");

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(
                EventQueryResponseEvents.class,
                DATA_DIR.REFUND_SERVICE + "EventQueryResponseEvents_EventType2_GC_RC.json");
        MtxRecurringEvent recEvent = (MtxRecurringEvent) subscriberEventInfo.getAtEventList(0).getEventDetails();
        recEvent.getBalanceUpdateArray().forEach(mbu->{
            if(BALANCE_IDS.MAIN_BALANCE == mbu.getBalanceTemplateId().longValue()) {
                mbu.setBalanceResourceId(CommonTestHelper.getBalanceResourceId(BALANCE_NAMES.MAIN_BALANCE));
            }
        });
        
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingOffer.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePricingOffer_Service.json");

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        // method to test
        instance.refundServiceV2(input, output);

        // Assertions here.
        assertEquals("0", String.valueOf(output.getResult()));
        assertEquals("SubscriberExternalID: "+input.getSubscriberExternalId()+" Response: OK", output.getResultText());
        BigDecimal refundAmount = subscriberEventInfo.getAtEventList(
                0).getEventDetails().getChargeList().get(2).getAmount().setScale(
                        2, RoundingMode.HALF_UP);
        // From file MtxResponseMulti_Valid_RefundService.json
        assertEquals(
                multiRes.getResponseList().stream().filter(
                        resp -> resp.getMdcName().equals(
                                MtxResponseRefundPayment.class.getSimpleName())).map(
                                        resp -> ((MtxResponseRefundPayment) resp).getRefundInfo().getRefundTime().longValue()).findFirst().get().longValue(),
                (new MtxTimestamp(output.getRefundAmountInfo())).longValue());
        MtxRequestSubscriberRefundPayment refundRequest = (MtxRequestSubscriberRefundPayment) argumentCaptor.getAllValues().get(
                0).getRequestList().get(2);
        assertEquals(refundAmount, refundRequest.getAmount());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceDefaultV2_CancelServicesYes_GoodwillCreditYes_RefundSuccess()
            throws Exception {

        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                DATA_DIR.REFUND_SERVICE + "VisibleRequestRefundService_CancelServices_GC.json");
        input.setCancelServices("1");
        
        MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseMulti_Valid_RefundService_GC.json");

        MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseSubscriber_refundService_GwC.json");

        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePaymentHistory_refundService_GC.json");

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(
                EventQueryResponseEvents.class,
                DATA_DIR.REFUND_SERVICE + "EventQueryResponseEvents_EventType2_GwC.json");
        MtxRecurringEvent recEvent = (MtxRecurringEvent) subscriberEventInfo.getAtEventList(0).getEventDetails();
        recEvent.getBalanceUpdateArray().forEach(mbu->{
            if(BALANCE_IDS.MAIN_BALANCE == mbu.getBalanceTemplateId().longValue()) {
                mbu.setBalanceResourceId(CommonTestHelper.getBalanceResourceId(BALANCE_NAMES.MAIN_BALANCE));
            }
        });
        
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingOffer.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePricingOffer_Service.json");

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        // method to test
        instance.refundServiceV2(input, output);
        // Assertions here.
        assertEquals("0", String.valueOf(output.getResult()));
        assertEquals("SubscriberExternalID: "+input.getSubscriberExternalId()+" Response: OK", output.getResultText());

        BigDecimal refundAmount = subscriberEventInfo.getAtEventList(
                0).getEventDetails().getChargeList().get(1).getAmount().setScale(
                        2, RoundingMode.HALF_UP);

        // From file MtxResponseMulti_Valid_RefundService.json
        assertEquals(
                multiRes.getResponseList().stream().filter(
                        resp -> resp.getMdcName().equals(
                                MtxResponseRefundPayment.class.getSimpleName())).map(
                                        resp -> ((MtxResponseRefundPayment) resp).getRefundInfo().getRefundTime().longValue()).findFirst().get().longValue(),
                (new MtxTimestamp(output.getRefundAmountInfo())).longValue());
        MtxRequestSubscriberRefundPayment refundRequest = (MtxRequestSubscriberRefundPayment) argumentCaptor.getAllValues().get(
                0).getRequestList().get(2);
        assertEquals(refundAmount, refundRequest.getAmount());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceDefaultV2_CancellationNo_GoodwillCreditsNo_CorrectMultiRequestOrdering()
            throws Exception {
        // Test case to check that individual requests in Multirequest input are in
        // correct order

        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                DATA_DIR.REFUND_SERVICE + "VisibleRequestRefundService_CancelServicesV2.json");
        input.setCancelServices("0");
        // Match with event file
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(CI_EXTERNAL_IDS.UNLIMITED);

        MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseMulti_Valid_RefundService.json");

        MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseSubscriber_refundService.json");

        MtxResponseWallet walletRes = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseWallet_refundService.json");

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePaymentHistory_refundService.json");

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingOffer.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePricingOffer_Service.json");

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(
                EventQueryResponseEvents.class,
                DATA_DIR.REFUND_SERVICE + "EventQueryResponseEvents_EventType2.json");
        // Assuming referral balance is first one to be added. Remove referral charge
        // from events.
        Iterator<EventQueryEventInfo> itr = subscriberEventInfo.getEventList().iterator();
        while (itr.hasNext()) {
            EventQueryEventInfo eInfo = itr.next();
            if (eInfo.getEventDetails().getMdcName().equals(
                    MtxRecurringEvent.class.getSimpleName())) {
                if (((MtxRecurringEvent) eInfo.getEventDetails()).getChargeList().size() > 1) {
                    ((MtxRecurringEvent) eInfo.getEventDetails()).getChargeList().get(0).setAmount(
                            BigDecimal.ZERO);
                }
            }
        }

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(walletRes).when(instance).querySubscriptionWallet(any(), any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        instance.refundServiceV2(input, output);

        // Assertions here.
        ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();

        assertEquals(MtxRequestSubscriberAdjustBalance.class.getSimpleName(), reqList.get(0).getMdcName());
        assertEquals(
                MtxRequestSubscriberRefundPayment.class.getSimpleName(), reqList.get(reqList.size() - 1).getMdcName());
        assertEquals(
                MtxRequestSubscriberPurchaseOffer.class.getSimpleName(),
                argumentCaptor.getAllValues().get(1).getRequestList().get(0).getMdcName());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_refundServiceV2_CancellationYes_CreditsNo_CorrectMultiRequestOrdering()
            throws Exception {
        // Test case to check that individual requests in Multirequest input are in
        // correct order

        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                DATA_DIR.REFUND_SERVICE + "VisibleRequestRefundService_CancelServicesV2.json");
        input.setCancelServices("1");
        // Match with event file
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(CI_EXTERNAL_IDS.UNLIMITED);

        MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseMulti_Valid_RefundService.json");

        MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseSubscriber_refundService.json");

        MtxResponseWallet walletRes = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponseWallet_refundService.json");

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePaymentHistory_refundService.json");

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingOffer.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePricingOffer_Service.json");

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(
                EventQueryResponseEvents.class,
                DATA_DIR.REFUND_SERVICE + "EventQueryResponseEvents_EventType2.json");
        // Assuming referral balance is first one to be added. Remove referral charge
        // from events.
        Iterator<EventQueryEventInfo> itr = subscriberEventInfo.getEventList().iterator();
        while (itr.hasNext()) {
            EventQueryEventInfo eInfo = itr.next();
            if (eInfo.getEventDetails().getMdcName().equals(
                    MtxRecurringEvent.class.getSimpleName())) {
                if (((MtxRecurringEvent) eInfo.getEventDetails()).getChargeList().size() > 1) {
                    ((MtxRecurringEvent) eInfo.getEventDetails()).getChargeList().get(0).setAmount(
                            BigDecimal.ZERO);
                }
            }
        }

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(walletRes).when(instance).querySubscriptionWallet(any(), any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        instance.refundServiceV2(input, output);

        assertEquals("23.33", output.getRefundedAmount());

        // Assertions here.
        ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();
        assertEquals(6, reqList.size());

        assertEquals(MtxRequestSubscriberAdjustBalance.class.getSimpleName(), reqList.get(0).getMdcName());
        for (int i = 1; i < 4; i++) {
            assertEquals(MtxRequestDeviceDeleteSession.class.getSimpleName(), reqList.get(i).getMdcName());
        }
        assertEquals(MtxRequestSubscriberCancelOffer.class.getSimpleName(), reqList.get(4).getMdcName());
        assertEquals(MtxRequestSubscriberRefundPayment.class.getSimpleName(), reqList.get(5).getMdcName());
    }

    @Test
    public void test_refundServiceV2_CancellationYes_CreditsYes_CorrectMultiRequestOrdering()
            throws Exception {
        // Test case to check that individual requests in Multirequest input are in
        // correct order
        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                DATA_DIR.REFUND_SERVICE + "VisibleRequestRefundService_CancelServicesV2.json");
        input.setCancelServices("1");
        
        // Match with event file
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                DATA_DIR.REFUND_SERVICE + "MtxSubscriberSearchData_RefundService.json");

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class,
                "src/test/resources/data/refundservice/MtxResponsePaymentHistory_refundService.json");

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(
                EventQueryResponseEvents.class,
                DATA_DIR.REFUND_SERVICE + "EventQueryResponseEvents_EventType2.json");
        MtxRecurringEvent recEvent = (MtxRecurringEvent) subscriberEventInfo.getAtEventList(0).getEventDetails();
        recEvent.getBalanceUpdateArray().forEach(mbu->{
            if(BALANCE_IDS.MAIN_BALANCE == mbu.getBalanceTemplateId().longValue()) {
                mbu.setBalanceResourceId(CommonTestHelper.getBalanceResourceId(BALANCE_NAMES.MAIN_BALANCE));
            }
        });
        
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingOffer.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePricingOffer_Service.json");

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        instance.refundServiceV2(input, output);
        System.out.println("InputRequest: " + input.toJson());
        System.out.println("output: " + output.toJson());
        
        // Assertions here.
        ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();
        assertEquals(3, reqList.size());
        assertEquals(MtxRequestSubscriberAdjustBalance.class.getSimpleName(), reqList.get(0).getMdcName());
        assertEquals(MtxRequestSubscriberCancelOffer.class.getSimpleName(), reqList.get(1).getMdcName());
        assertEquals(MtxRequestSubscriberRefundPayment.class.getSimpleName(), reqList.get(2).getMdcName());
    }

    @Test
    public void test_refundServiceV2_RefundType5_Fail() throws Exception {
        // Setup Input
        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class,
                DATA_DIR.REFUND_SERVICE + "VisibleRequestRefundService_Refund_V2.json");
        input.setRefundType("5");

        // Setup output
        VisibleResponseRefundService output = new VisibleResponseRefundService();

        try {
            instance.refundServiceV2(input, output);
            fail("Expecting SubscriberServiceException");
        } catch (SubscriberServiceException ex) {
            System.out.println(ex.getMessage());
        }

    }

    @Test
    @Tag("VER-356")
    public void test_refundServiceInsuranceV2_When_ProratedRefund_Then_CorrectTaxRequest(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active insurance service."
        };
        td.when = new String[] {
            "Api is called for prorated refund."
        };
        td.then = new String[] {
            "tax for cancellation should be calculated with tax template from insurance."
        };
        td.printDescription();

        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class, DATA_DIR.REFUND_SERVICE
                        + "VisibleRequestRefundServiceV2_RefundTypeProrata_ValidRequest.json");
        // Match with event file
        input.getRefundServiceOrderInfo().setServiceOfferExternalId(
                CI_EXTERNAL_IDS.INSURANCE);
        input.setCancelServices("1");
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxRecurringEvent event = CommonTestHelper.getMtxRecurringEvent(
                Arrays.asList(CI_EXTERNAL_IDS.INSURANCE));
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getEventQueryResponseEvents();
        subscriberEventInfo.getAtEventList(0).setEventDetails(event);
        System.out.println(
                testInfo.getDisplayName() + ": subscriberEventInfo: "
                        + subscriberEventInfo.toJson());

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class, DATA_DIR.REFUND_SERVICE
                        + "MtxResponsePaymentHistory_Valid_RefundService_Prorata.json");

        MtxResponseCancel cancelResp = CommonTestHelper.getMtxResponseCancel();
        
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingOffer.class,
                DATA_DIR.REFUND_SERVICE + "MtxResponsePricingOffer_Insurance.json");

        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        MtxResponsePricingCatalogItem pci = emulateMtxResponsePricingCatalogItem(
                instance, input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        doReturn("").when(instance).getRoute(any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        when(api.multi(any(), any())).thenReturn(multiRes);

        System.out.println(testInfo.getDisplayName() + ": InputRequest: " + input.toJson());
        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(
                            any(), argumentCaptor.capture())).thenReturn(taxApiResp2);
            // method to test
            instance.refundServiceV2(input, output);
        }

        ObjectMapper om = TestUtils.getObjectMapper();
        ServiceTaxRequest taxReq = om.readValue(
                argumentCaptor.getAllValues().get(0), ServiceTaxRequest.class);

        StringBuffer taxStringMetadata = new StringBuffer("");
        pci.getCatalogItemInfo().getMetadataList().forEach(pmi -> {
            if (CI_METADATA.TAX_INPUT.equalsIgnoreCase(pmi.getName())) {
                taxStringMetadata.append(pmi.getValue());
            }
        });
        ServiceTaxRequest taxReqMetadata = om.readValue(
                taxStringMetadata.toString(), ServiceTaxRequest.class);

        // Assertions here.
        assertEquals(taxReqMetadata.getPlanID(), taxReq.getPlanID());
    }
    
    @Tag("VER-863")
    @ParameterizedTest(
            name = "test_refundServiceInsuranceV2_When_InuranceNoBundle_Then_ModifyOfferPresent")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Visible_Wearable_Insurance_CI. CI is based on single offer and is not in a bundle.|"
       +"|When  |Refund success.|"
       +"|Then  |Modify offer request withh taxes should run.|"
       +"|Coments|Attributes are read from recurring events. In case of non-bundled ci, it should be read from AppliedOfferArray. Which will then be used in creating modify offer request. |"})
    // @formatter:on
    public void test_refundServiceInsuranceV2_When_InuranceNoBundle_Then_ModifyOfferPresent(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        
        String testdatafolder = "VER_863/";
        VisibleRequestRefundService input = CommonTestHelper.loadJsonMessage(
                VisibleRequestRefundService.class, DATA_DIR.ONSHORE+testdatafolder
                        + "VisibleRequestRefundService.json");
        VisibleResponseRefundService output = new VisibleResponseRefundService();
        
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
               
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(
                EventQueryResponseEvents.class, DATA_DIR.ONSHORE+testdatafolder
                + "EventQueryResponseEvents.json");
        System.out.println(
                testInfo.getDisplayName() + ": subscriberEventInfo: "
                        + subscriberEventInfo.toJson());

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.loadJsonMessage(
                MtxResponsePaymentHistory.class, DATA_DIR.ONSHORE+testdatafolder
                        + "MtxResponsePaymentHistory.json");

        MtxResponseCancel cancelResp = CommonTestHelper.loadJsonMessage(
                MtxResponseCancel.class, DATA_DIR.ONSHORE+testdatafolder
                + "MtxResponseCancel.json");
        
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);

        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.ONSHORE+testdatafolder
                + "MtxResponseWallet.json");

        // mocks
        emulateMtxResponseWallet(instance, wallet);
        
        doReturn("").when(instance).getRoute(any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());

        ArgumentCaptor<MtxRequestMulti> argumentCaptorMulti = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptorMulti.capture())).thenReturn(multiRes);

        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(
                            any(), argumentCaptor.capture())).thenReturn(taxApiResp2);
            // method to test
            instance.refundServiceV2(input, output);
        }
        System.out.println(testInfo.getDisplayName() + ": InputRequest: " + input.toJson());
        System.out.println(testInfo.getDisplayName() + ": output: " + output.toJson());
        MtxRequest req = argumentCaptorMulti.getAllValues().get(0).getAtRequestList(0);
        System.out.println(testInfo.getDisplayName() + ": req: "+req.toJson() );
        MtxRequestSubscriberModifyOffer modReq = new MtxRequestSubscriberModifyOffer(req);
        assertEquals(VisiblePurchasedOfferExtension.class.getSimpleName(), modReq.getAttr().getMdcName());
    }
    
}