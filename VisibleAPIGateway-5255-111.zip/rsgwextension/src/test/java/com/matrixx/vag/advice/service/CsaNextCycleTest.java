package com.matrixx.vag.advice.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doReturn;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixx.datacontainer.MtxDate;
import com.matrixx.datacontainer.MtxObjectId;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.EventQueryEventInfo;
import com.matrixx.datacontainer.mdc.EventQueryResponseEvents;
import com.matrixx.datacontainer.mdc.MtxBalanceImpactInfo;
import com.matrixx.datacontainer.mdc.MtxBalanceInfo;
import com.matrixx.datacontainer.mdc.MtxPricingMetadataInfo;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferData;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.MtxRecurringEvent;
import com.matrixx.datacontainer.mdc.MtxResponseGroup;
import com.matrixx.datacontainer.mdc.MtxResponseMulti;
import com.matrixx.datacontainer.mdc.MtxResponseOneTimeOffer;
import com.matrixx.datacontainer.mdc.MtxResponsePricingCatalogItem;
import com.matrixx.datacontainer.mdc.MtxResponsePurchase;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.PurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.SubscriptionResponse;
import com.matrixx.datacontainer.mdc.VisibleChangeServicePromo;
import com.matrixx.datacontainer.mdc.VisibleCredits;
import com.matrixx.datacontainer.mdc.VisibleOfferDetails;
import com.matrixx.datacontainer.mdc.VisiblePromoExtension;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleRequestChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleResponseChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleReverseCredit;
import com.matrixx.datacontainer.mdc.VisibleSubscriberExtension;
import com.matrixx.datacontainer.mdc.VisibleTemplate;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.advice.model.CreditStage;
import com.matrixx.vag.advice.model.GlobalCreditStage;
import com.matrixx.vag.advice.model.PromoOfferPair;
import com.matrixx.vag.advice.model.ServiceStage;
import com.matrixx.vag.advice.model.SubscriberGroup;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants;
import com.matrixx.vag.common.Constants.CHANGE_SERVICE_CONSTANTS;
import com.matrixx.vag.common.Constants.CI_METADATA;
import com.matrixx.vag.common.Constants.CREDIT_CONSTANTS;
import com.matrixx.vag.common.Constants.GENERIC_CONSTANTS;
import com.matrixx.vag.common.Constants.GROUP_CONSTANTS;
import com.matrixx.vag.common.Constants.LOG_MESSAGES;
import com.matrixx.vag.common.OneParameterTest;
import com.matrixx.vag.common.TestConstants;
import com.matrixx.vag.common.TestConstants.BALANCE_NAMES;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestConstants.DATA_DIR;
import com.matrixx.vag.common.TestConstants.OFFER_PRICES;
import com.matrixx.vag.common.TestConstants.TAX_CLASS_CODES;
import com.matrixx.vag.common.TestUtils;
import com.matrixx.vag.common.ThreeParameterTest;
import com.matrixx.vag.common.TwoParameterTest;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.tax.client.TaxApiClient;
import com.matrixx.vag.tax.model.ServiceTaxRequest;
import com.matrixx.vag.tax.model.ServiceTaxResponse;
import com.matrixx.vag.util.MDCTest;

public class CsaNextCycleTest extends MDCTest {
    // 20240510 - New class created. Existing one too long.
    // Sourcetree is not able to provide comparison of file changes. Reduce size for convenience.

    @Spy
    @InjectMocks
    private PaymentAdviceService instance = new PaymentAdviceService();

    @Mock
    private SubscriberManagementApi api;

    private TestInfo testInfo;

    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        instance = new PaymentAdviceService();
        MockitoAnnotations.openMocks(this);
        doReturn("").when(instance).getRoute(any());
        this.testInfo = testInfo;
    }

    @SuppressWarnings({
        "unchecked"
    })
    @Test
    public void test_getChangeServiceAdvice_When_ChangeAndNextCycle_Then_Exclude_Mainbalance_Of_Other_Offers(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription PaidCycleStartDate after today. This means Manual Pay is already run for next cycle."
        };
        td.when = new String[] {
            "Api is called with valid parameters."
        };
        td.then = new String[] {
            "First exclude mainbalance allocated to other non changeable offers in NextCycle.",
            " Allocate remaining mainbalance to new offer."
        };
        td.printDescription();

        String subscriptionExternalId = "123";
        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        String newCiId = CI_EXTERNAL_IDS.PLUS_CURRENT;
        String oldCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        request.setNewCatalogItemExternalId(newCiId);
        request.setGrossPrice(BigDecimal.valueOf(100));
        request.setDiscountPrice(CommonTestHelper.getOfferPrice(newCiId));
        request.setSubscriptionExternalId(subscriptionExternalId);
        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        BigDecimal mainbalance = CommonTestHelper.getOfferPrice(newCiId);

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance, CommonTestHelper.getEmptySubscriptionResponse(subscriptionExternalId));
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCiId);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(
                new MtxDate(
                        subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime().getTime().split(
                                "T")[0]));

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poUnlimited = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCiId);
        VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poUnlimited.getAttr();
        poExtn.setPaidCycleStartDate(enrolledPoiExtn.getPaidCycleStartDate());
        subscription.getPurchasedOfferArrayAppender().add(poUnlimited);

        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(oldCiId, newCiId));
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

        VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsAfterPayment(
                oldCiId, subscriptionResponse, CommonTestHelper.getOfferPrice(oldCiId));
        BigDecimal mainbalanceUnlimited = CommonTestHelper.getOfferPrice(oldCiId);
        vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsAfterPayment(
                CI_EXTERNAL_IDS.WEARABLE, subscriptionResponse,
                CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.WEARABLE));
        BigDecimal mainbalanceWearables = CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.WEARABLE);
        vodWearable.setConsumableMainBalanceAmount(mainbalanceWearables);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodUnlimited.getCatalogItemExternalId(), Long.valueOf(vodUnlimited.getResourceId()),
                vodUnlimited);
        aopStage.appendVisibleOfferDetailsMap(
                vodWearable.getCatalogItemExternalId(), Long.valueOf(vodWearable.getResourceId()),
                vodWearable);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        aopStage.setAvailableMainBalanceAmount(mainbalanceUnlimited.add(mainbalanceWearables));
        aopStage.setConsumableMainBalanceAmount(mainbalanceUnlimited.add(mainbalanceWearables));

        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                newCiId);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);

        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        String taxApiResp = CommonTestHelper.getTaxApiResp(request.getNewCatalogItemExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp);
            instance.getChangeServiceAdvice(request, response);
        }
        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(
                mainbalanceWearables.intValue(),
                response.getNextCycle().getReservedMainBalanceAmount().intValue());
        assertTrue(
                response.getChangeCycle().getConsumableMainBalance().compareTo(
                        mainbalance.subtract(mainbalanceWearables)) <= 0,
                "Consumable Main Balance for new offer should exclude reservedMainBalance");
    }

    @SuppressWarnings({
        "unchecked"
    })
    @Test
    public void test_getChangeServiceAdvice_When_PromosAllocatedToNextCycle_Then_ReversePromoBlocks(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription PaidCycleStartDate after today. This means Manual Pay is already run for next cycle.",
            "Promotions were allocated for enrolled base offer in manual pay."
        };
        td.when = new String[] {
            "Api is called with new base offer."
        };
        td.then = new String[] {
            "Api response should provide reverse promo blocks for promos that were applied for renewal of current base offer."
        };
        // Run for all 4 combinations
        td.printDescription();

        String subscriptionExternalId = "123";
        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        String newCiId = CI_EXTERNAL_IDS.PLUS_CURRENT;
        String oldCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        request.setNewCatalogItemExternalId(newCiId);
        request.setGrossPrice(BigDecimal.valueOf(100));
        request.setDiscountPrice(BigDecimal.valueOf(45));
        request.setSubscriptionExternalId(subscriptionExternalId);
        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        String randomDate = "4712-12-31";
        BigDecimal mainbalance = BigDecimal.valueOf(40);

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poUnlimited = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCiId);
        VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poUnlimited.getAttr();
        poExtn.setPaidCycleStartDate(new MtxDate(randomDate));
        subscription.getPurchasedOfferArrayAppender().add(poUnlimited);

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCiId);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomDate));

        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(oldCiId, newCiId));

        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

        VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                CI_EXTERNAL_IDS.UNLIMITED);
        BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
        vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        MtxResponsePricingCatalogItem ciRef35Grant = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingCatalogItem.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingCatalogItem_Visible_REF35_Grant.json");
        VisibleTemplate vtRef35 = ((VisibleTemplate) ciRef35Grant.getCatalogItemInfo().getTemplateAttr());

        BigDecimal ref35Credits = BigDecimal.valueOf(35);

        ServiceStage ss = new ServiceStage(oldCiId);

        GlobalCreditStage gcsRef35 = new GlobalCreditStage(CI_EXTERNAL_IDS.GRANT_GOODWILL, vtRef35);
        gcsRef35.setPromotionName(vtRef35.getPromotionName());
        gcsRef35.setAvailableCredits(ref35Credits);
        gcsRef35.setAvailableCreditsConsumable(ref35Credits);
        gcsRef35.setAvailableCreditsGrant(BigDecimal.ZERO);
        gcsRef35.setRedeemOfferCi(vtRef35.getRedeemOffer());
        gcsRef35.setApplicableCiCsv(oldCiId);
        gcsRef35.getApplicableCiOrderMap().put(oldCiId, 2L);

        CreditStage csRef35 = new CreditStage(gcsRef35, oldCiId);
        csRef35.setApplicableServiceStage(ss);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodUnlimited.getCatalogItemExternalId(), Long.valueOf(vodUnlimited.getResourceId()),
                vodUnlimited);
        aopStage.getCreditMap().put(
                new PromoOfferPair(oldCiId, vtRef35.getPromotionName()), csRef35);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                newCiId);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);

        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        String taxApiResp = CommonTestHelper.getTaxApiResp(request.getNewCatalogItemExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp);
            instance.getChangeServiceAdvice(request, response);
        }
        System.out.println(td.getTestMethod() + ":" + response.toJson());
        assertTrue(response.getNextCycle().getReverseCredits() != null);
        assertFalse(response.getNextCycle().getReverseCredits().isEmpty());
        assertEquals(
                vtRef35.getPromotionName(),
                response.getNextCycle().getAtReverseCredits(0).getPromotionName());
        assertEquals(
                ref35Credits.intValue(), response.getNextCycle().getAtReverseCredits(
                        0).getAvailableCreditsConsumable().intValue());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getChangeServiceAdvice_When_ChangeAndNextCycle_Then_FullTaxesForNextCycle")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription with base offer. PaidCycleStartDate is in future.|"
                +"|When |Api is called with new base offer.|"
                +"|Then |Tax Api should be called with full price for new offer in next cycle.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_When_ChangeAndNextCycle_Then_FullTaxesForNextCycle(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String subscriptionExternalId = "123";
        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        String newCiId = CI_EXTERNAL_IDS.PLUS_CURRENT;
        String oldCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        request.setNewCatalogItemExternalId(newCiId);
        request.setGrossPrice(BigDecimal.valueOf(100));
        BigDecimal discountPrice = CommonTestHelper.getOfferPrice(newCiId);
        request.setDiscountPrice(discountPrice);
        request.setSubscriptionExternalId(subscriptionExternalId);
        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        BigDecimal oldPrice = BigDecimal.valueOf(45);
        BigDecimal mainbalance = oldPrice;

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance, CommonTestHelper.getEmptySubscriptionResponse(subscriptionExternalId));
        PurchasedOfferInfo poiPlus = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCiId);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiPlus.getAttr();
        enrolledPoiExtn.setChargeAmount(oldPrice);
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(
                new MtxDate(
                        subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime().getTime().split(
                                "T")[0]));

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poUnlimited = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCiId);
        VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poUnlimited.getAttr();
        poExtn.setPaidCycleStartDate(enrolledPoiExtn.getPaidCycleStartDate());

        MtxResponsePricingCatalogItem pci = emulateMtxResponsePricingCatalogItem(instance, newCiId);
        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(oldCiId, CI_EXTERNAL_IDS.PLUS_2535_GRANT));
        String nextCycleaTaxInputMsgID = "XYZNEXTXYZ";
        String nextCycleTaxInput = "{   \"msgID\":" + "\"" + nextCycleaTaxInputMsgID + "\""
                + ",   \"customerType\": \"99\",   \"planID\": \"BASE001A\",   \"grossPrice\": \"0\",   \"discountPrice\": \"0\",   \"geocode\": \"US\",   \"glDate\": \"2019-09-01\",   \"taxTreatment\": \"inclusive\",   \"classCode\": \"SVC\",   \"offer606RevAdjDailyRecog\": \"0\",   \"promotionCredit\": false,   \"dpcGroupList\": [     {       \"dpcGroup\": \"5018\",       \"dpcItemList\": [         {           \"dpcItem\": \"618\",           \"cP\": \".9719167977\",           \"cycleNSR\": \"0\",           \"glReference\": \"Visible_Unlimited_Data\"         },         {           \"dpcItem\": \"601\",           \"cP\": \".0238925768\",           \"cycleNSR\": \"0\",           \"glReference\": \"Visible_Unlimited_Voice\"         },         {           \"dpcItem\": \"662\",           \"cP\": \".0000041959\",           \"cycleNSR\": \"0\",           \"glReference\": \"Visible_Unlimited_Text\"         },         {           \"dpcItem\": \"629\",           \"cP\": \".0041864296\",           \"cycleNSR\": \"0\",           \"glReference\": \"Visible_Unlimited_MMS\"         }       ]     }   ] }";

        for (MtxPricingMetadataInfo pmi : pci.getCatalogItemInfo().getMetadataList()) {
            if (CI_METADATA.TAX_INPUT.equalsIgnoreCase(pmi.getName())) {
                pmi.setValue(nextCycleTaxInput);
            }
        }

        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(oldPrice));

        EventQueryResponseEvents eqre = new EventQueryResponseEvents();
        emulateEventQueryResponseEvents(instance, eqre);
        VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsAfterPayment(
                oldCiId, subscriptionResponse, CommonTestHelper.getOfferPrice(oldCiId));
        BigDecimal mainbalanceUnlimited = CommonTestHelper.getOfferPrice(oldCiId);
        vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsAfterPayment(
                CI_EXTERNAL_IDS.WEARABLE, subscriptionResponse,
                CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.WEARABLE));
        BigDecimal mainbalanceWearables = CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.WEARABLE);
        vodWearable.setConsumableMainBalanceAmount(mainbalanceWearables);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodUnlimited.getCatalogItemExternalId(), Long.valueOf(vodUnlimited.getResourceId()),
                vodUnlimited);
        aopStage.appendVisibleOfferDetailsMap(
                vodWearable.getCatalogItemExternalId(), Long.valueOf(vodWearable.getResourceId()),
                vodWearable);
        aopStage.setAvailableMainBalanceAmount(mainbalanceUnlimited.add(mainbalanceWearables));
        aopStage.setConsumableMainBalanceAmount(mainbalanceUnlimited.add(mainbalanceWearables));
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        System.out.println(td.getTestMethod() + ":" + aopStage.toJson());
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                newCiId);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);

        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        String taxApiResp = CommonTestHelper.getTaxApiResp(newCiId);
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            instance.getChangeServiceAdvice(request, response);
        }
        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(
                mainbalanceWearables.intValue(),
                response.getNextCycle().getReservedMainBalanceAmount().intValue());
        assertTrue(
                response.getChangeCycle().getConsumableMainBalance().compareTo(
                        mainbalance.subtract(mainbalanceWearables)) <= 0,
                "Consumable Main Balance for new offer should exclude reservedMainBalance");

        boolean foundNextCycleTaxCall = false;
        for (String val : argumentCaptor.getAllValues()) {
            try {
                ServiceTaxRequest taxReq = CommonTestHelper.getJsonFromString(
                        ServiceTaxRequest.class, val);
                System.out.println(td.getTestMethod() + ":" + taxReq.toJson());
                if (nextCycleaTaxInputMsgID.equalsIgnoreCase(taxReq.getMsgID())) {
                    assertEquals(discountPrice.intValue(), taxReq.getDiscountPrice().intValue());
                    foundNextCycleTaxCall = true;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        assertTrue(foundNextCycleTaxCall);
    }

    @SuppressWarnings({
        "unchecked"
    })
    @Test
    public void test_getChangeServiceAdvice_When_ChangeAndNextCycle_Then_TotalAmount_Eq_Sum_Of_TotalAmounts(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription PaidCycleStartDate after today. This means Manual Pay is already run for next cycle."
        };
        td.when = new String[] {
            "Api is called with valid parameters."
        };
        td.then = new String[] {
            "Combined TotalAmount = CurrentCycle TotalAmount + NextCycle TotalAmount"
        };
        td.printDescription();

        // Test for all 4 cases
        String subscriptionExternalId = "123";
        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        String newCiId = CI_EXTERNAL_IDS.PLUS_CURRENT;
        String oldCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        request.setNewCatalogItemExternalId(newCiId);
        request.setGrossPrice(BigDecimal.valueOf(100));
        request.setDiscountPrice(CommonTestHelper.getOfferPrice(newCiId));
        request.setSubscriptionExternalId(subscriptionExternalId);
        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        String randomDate = "4712-12-31";
        BigDecimal mainbalance = BigDecimal.valueOf(40);

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poUnlimited = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCiId);
        VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poUnlimited.getAttr();
        poExtn.setPaidCycleStartDate(new MtxDate(randomDate));

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCiId);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomDate));

        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(oldCiId, CI_EXTERNAL_IDS.PLUS_2535_GRANT));
        MtxResponsePricingCatalogItem pci = emulateMtxResponsePricingCatalogItem(instance, newCiId);
        String nextCycleaTaxInputMsgID = "XYZNEXTXYZ";
        String nextCycleTaxInput = "{   \"msgID\":" + "\"" + nextCycleaTaxInputMsgID + "\""
                + ",   \"customerType\": \"99\",   \"planID\": \"BASE001A\",   \"grossPrice\": \"0\",   \"discountPrice\": \"0\",   \"geocode\": \"US\",   \"glDate\": \"2019-09-01\",   \"taxTreatment\": \"inclusive\",   \"classCode\": \"SVC\",   \"offer606RevAdjDailyRecog\": \"0\",   \"promotionCredit\": false,   \"dpcGroupList\": [     {       \"dpcGroup\": \"5018\",       \"dpcItemList\": [         {           \"dpcItem\": \"618\",           \"cP\": \".9719167977\",           \"cycleNSR\": \"0\",           \"glReference\": \"Visible_Unlimited_Data\"         },         {           \"dpcItem\": \"601\",           \"cP\": \".0238925768\",           \"cycleNSR\": \"0\",           \"glReference\": \"Visible_Unlimited_Voice\"         },         {           \"dpcItem\": \"662\",           \"cP\": \".0000041959\",           \"cycleNSR\": \"0\",           \"glReference\": \"Visible_Unlimited_Text\"         },         {           \"dpcItem\": \"629\",           \"cP\": \".0041864296\",           \"cycleNSR\": \"0\",           \"glReference\": \"Visible_Unlimited_MMS\"         }       ]     }   ] }";

        for (MtxPricingMetadataInfo pmi : pci.getCatalogItemInfo().getMetadataList()) {
            if (CI_METADATA.TAX_INPUT.equalsIgnoreCase(pmi.getName())) {
                pmi.setValue(nextCycleTaxInput);
            }
        }

        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

        VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                oldCiId);
        BigDecimal mainbalanceUnlimited = CommonTestHelper.getOfferPrice(oldCiId);
        vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                CI_EXTERNAL_IDS.WEARABLE);
        BigDecimal mainbalanceWearables = CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.WEARABLE);
        vodWearable.setConsumableMainBalanceAmount(mainbalanceWearables);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodUnlimited.getCatalogItemExternalId(), Long.valueOf(vodUnlimited.getResourceId()),
                vodUnlimited);
        aopStage.appendVisibleOfferDetailsMap(
                vodWearable.getCatalogItemExternalId(), Long.valueOf(vodWearable.getResourceId()),
                vodWearable);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                newCiId);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);

        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        String taxApiResp = CommonTestHelper.getTaxApiResp(newCiId);
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp);
            instance.getChangeServiceAdvice(request, response);
        }
        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(
                response.getChangeCycle().getTotalAmount().add(
                        response.getNextCycle().getTotalAmount()).intValue(),
                response.getTotalAmount().intValue());
    }

    @SuppressWarnings({
        "unchecked"
    })
    @Test
    public void test_getChangeServiceAdvice_When_ChangeAndNextCycle_Then_ConsumableMainBalance_Eq_Sum_Of_ConsumableMainBalance(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription PaidCycleStartDate after today. This means Manual Pay is already run for next cycle."
        };
        td.when = new String[] {
            "Api is called with valid parameters."
        };
        td.then = new String[] {
            "Combined ConsumableMainBalance = CurrentCycle ConsumableMainBalance + NextCycle ConsumableMainBalance"
        };
        td.printDescription();

        String subscriptionExternalId = "123";
        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        String newCiId = CI_EXTERNAL_IDS.PLUS_CURRENT;
        String oldCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        request.setNewCatalogItemExternalId(newCiId);
        request.setGrossPrice(BigDecimal.valueOf(100));
        request.setDiscountPrice(CommonTestHelper.getOfferPrice(newCiId));
        request.setSubscriptionExternalId(subscriptionExternalId);
        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        String randomDate = "4712-12-31";
        BigDecimal mainbalance = BigDecimal.valueOf(40);

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poUnlimited = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCiId);
        VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poUnlimited.getAttr();
        poExtn.setPaidCycleStartDate(new MtxDate(randomDate));

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCiId);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomDate));

        emulateMtxResponsePricingCatalogItem(instance, oldCiId);
        MtxResponsePricingCatalogItem pci = emulateMtxResponsePricingCatalogItem(instance, newCiId);
        String nextCycleaTaxInputMsgID = "XYZNEXTXYZ";
        String nextCycleTaxInput = "{   \"msgID\":" + "\"" + nextCycleaTaxInputMsgID + "\""
                + ",   \"customerType\": \"99\",   \"planID\": \"BASE001A\",   \"grossPrice\": \"0\",   \"discountPrice\": \"0\",   \"geocode\": \"US\",   \"glDate\": \"2019-09-01\",   \"taxTreatment\": \"inclusive\",   \"classCode\": \"SVC\",   \"offer606RevAdjDailyRecog\": \"0\",   \"promotionCredit\": false,   \"dpcGroupList\": [     {       \"dpcGroup\": \"5018\",       \"dpcItemList\": [         {           \"dpcItem\": \"618\",           \"cP\": \".9719167977\",           \"cycleNSR\": \"0\",           \"glReference\": \"Visible_Unlimited_Data\"         },         {           \"dpcItem\": \"601\",           \"cP\": \".0238925768\",           \"cycleNSR\": \"0\",           \"glReference\": \"Visible_Unlimited_Voice\"         },         {           \"dpcItem\": \"662\",           \"cP\": \".0000041959\",           \"cycleNSR\": \"0\",           \"glReference\": \"Visible_Unlimited_Text\"         },         {           \"dpcItem\": \"629\",           \"cP\": \".0041864296\",           \"cycleNSR\": \"0\",           \"glReference\": \"Visible_Unlimited_MMS\"         }       ]     }   ] }";

        for (MtxPricingMetadataInfo pmi : pci.getCatalogItemInfo().getMetadataList()) {
            if (CI_METADATA.TAX_INPUT.equalsIgnoreCase(pmi.getName())) {
                pmi.setValue(nextCycleTaxInput);
            }
        }

        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

        VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                oldCiId);
        BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
        vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                CI_EXTERNAL_IDS.WEARABLE);
        BigDecimal mainbalanceWearables = BigDecimal.valueOf(5);
        vodWearable.setConsumableMainBalanceAmount(mainbalanceWearables);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodUnlimited.getCatalogItemExternalId(), Long.valueOf(vodUnlimited.getResourceId()),
                vodUnlimited);
        aopStage.appendVisibleOfferDetailsMap(
                vodWearable.getCatalogItemExternalId(), Long.valueOf(vodWearable.getResourceId()),
                vodWearable);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                newCiId);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);

        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        String taxApiResp = CommonTestHelper.getTaxApiResp(request.getNewCatalogItemExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp);
            instance.getChangeServiceAdvice(request, response);
        }
        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(
                response.getChangeCycle().getConsumableMainBalance().add(
                        response.getNextCycle().getConsumableMainBalance()).intValue(),
                response.getConsumableMainBalance().intValue());
    }

    @SuppressWarnings({
        "unchecked"
    })
    @Test
    public void test_getChangeServiceAdvice_When_ChangeAndNextCycle_Then_CorrectRechargeAmount(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription PaidCycleStartDate after today. This means Manual Pay is already run for next cycle."
        };
        td.when = new String[] {
            "Api is called with valid parameters."
        };
        td.then = new String[] {
            "RechargeAmount =  CurrentCycle PayabelAmount + NextCycle PayableAmount - ConsumableMainBalance"
        };

        OneParameterTest pTests = (assertion) -> {
            td.printDescription();
            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            String newCiId = CI_EXTERNAL_IDS.PLUS_CURRENT;
            String asIsOFfer = CI_EXTERNAL_IDS.BASE_CURRENT;
            request.setNewCatalogItemExternalId(newCiId);
            request.setGrossPrice(BigDecimal.valueOf(100));
            request.setDiscountPrice(BigDecimal.valueOf(45));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            String randomFutureDate = "4712-12-31";
            BigDecimal mainbalance = BigDecimal.valueOf(40);
            BigDecimal goodwillCredits = BigDecimal.valueOf(35);

            MtxResponseSubscription subscription = null;
            try {
                subscription = emulateMtxResponseSubscription(
                        api, CommonTestHelper.getMtxResponseSubscription());
            } catch (Exception e) {
                e.printStackTrace();
            }

            MtxBalanceInfo biGoodwill = CommonTestHelper.getMtxBalanceInfo(
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Grant.json", 4, 43);
            subscription.getBalanceArrayAppender().add(biGoodwill);
            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poUnlimited = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, asIsOFfer);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poUnlimited.getAttr();
            poExtn.setPaidCycleStartDate(new MtxDate(randomFutureDate));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, asIsOFfer);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(asIsOFfer));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomFutureDate));

            emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(asIsOFfer, newCiId));

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    CI_EXTERNAL_IDS.UNLIMITED);
            BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
            vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

            MtxResponsePricingCatalogItem pciGdw = emulateMtxResponsePricingCatalogItem(
                    instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
            VisibleTemplate vtGdw = (VisibleTemplate) pciGdw.getCatalogItemInfo().getTemplateAttr();

            ServiceStage ss = new ServiceStage(asIsOFfer);

            GlobalCreditStage gcsGoodwill = new GlobalCreditStage(
                    CI_EXTERNAL_IDS.GRANT_GOODWILL, vtGdw);
            gcsGoodwill.setPromotionName(vtGdw.getPromotionName());
            gcsGoodwill.setAvailableCredits(goodwillCredits);
            gcsGoodwill.setAvailableCreditsConsumable(goodwillCredits);
            gcsGoodwill.setAvailableCreditsGrant(BigDecimal.ZERO);
            gcsGoodwill.setRedeemOfferCi(vtGdw.getRedeemOffer());
            gcsGoodwill.setApplicableCiCsv(asIsOFfer);
            gcsGoodwill.getApplicableCiOrderMap().put(asIsOFfer, 2L);

            CreditStage csGoodwill = new CreditStage(gcsGoodwill, asIsOFfer);
            csGoodwill.setApplicableServiceStage(ss);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodUnlimited.getCatalogItemExternalId(),
                    Long.valueOf(vodUnlimited.getResourceId()), vodUnlimited);
            aopStage.getCreditMap().put(
                    new PromoOfferPair(asIsOFfer, vtGdw.getPromotionName()), csGoodwill);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                    newCiId);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            List<String> balPriList = Arrays.asList(BALANCE_NAMES.GOODWILL_GRANT);
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            String taxApiResp = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxApiResp);
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());

            assertEquals(
                    response.getChangeCycle().getPayableAmount().add(
                            response.getNextCycle().getPayableAmount()).subtract(
                                    response.getConsumableMainBalance()),
                    response.getRechargeAmount());
        };

        pTests.test("PromoBlock_Yes");
    }

    @SuppressWarnings({
        "unchecked"
    })
    @Test
    public void test_getChangeServiceAdvice_When_ChangeAndNextCycle_With_Promos_Then_Next_Cycle_Promo_Taxes(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with base offer. PaidCycleStartDate is in future."
        };
        td.when = new String[] {
            "Api is called with valid base offer. Next Cycle has gap. Next Cycle has promos."
        };
        td.then = new String[] {
            "Promo taxes should be correct."
        };

        OneParameterTest pTests = (taxResponseUnchanged) -> {
            td.printDescription();
            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            String newCiId = CI_EXTERNAL_IDS.PLUS_CURRENT;
            String oldCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
            request.setNewCatalogItemExternalId(newCiId);
            request.setGrossPrice(BigDecimal.valueOf(100));
            request.setDiscountPrice(CommonTestHelper.getOfferPrice(newCiId));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            String randomFutureDate = "4712-12-31";
            BigDecimal mainbalance = BigDecimal.valueOf(40);
            BigDecimal goodwillGrant = BigDecimal.valueOf(34);
            BigDecimal goodwillConsumable = BigDecimal.ZERO;
            BigDecimal refConsumable = BigDecimal.valueOf(23);
            MtxResponseSubscription subscription = null;
            try {
                subscription = emulateMtxResponseSubscription(
                        api, CommonTestHelper.getMtxResponseSubscription());
            } catch (Exception e) {
                e.printStackTrace();
            }
            MtxBalanceInfo biGoodwill = CommonTestHelper.getMtxBalanceInfo(
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Grant.json", 4, 43);
            biGoodwill.setAmount(BigDecimal.valueOf(34).negate());
            subscription.getBalanceArrayAppender().add(biGoodwill);
            subscription.getPurchasedOfferArrayAppender().clear();

            MtxPurchasedOfferInfo poUnlimited = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCiId);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poUnlimited.getAttr();
            poExtn.setPaidCycleStartDate(new MtxDate(randomFutureDate));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCiId);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomFutureDate));

            emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(oldCiId, newCiId));
            /**************************** CurrentCyclePromos ********************/
            String refCreditTax = "{\"msgID\":\"EFGH-CR\",\"customerType\":\"99\",\"planID\":\"BASE001A\",\"grossPrice\":\"5.00\",\"discountPrice\":\""
                    + refConsumable
                    + "\",\"promotionCredit\":\"true\",\"offer606RevAdjDailyRecog\":\"0\",\"promotionReason\":\"Referee_Credits\",\"geocode\":\"US0100108296\",\"taxTreatment\":\"inclusive\",\"classCode\":\"REF-CR\",\"glDate\":\"2019-03-07\",\"transactionElement\":[{\"btcTransactionCode\":\"01\",\"totalTaxAmount\":\"0.07389163\",\"totalFeeAmount\":\"0.00000000\",\"totalNetRevenue\":\"4.92610836\",\"modifiedDisplayNetRevenue\":\"4.93\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"618\",\"cP\":\"0.75\",\"glReference\":\"Visible_Unlimited_Data\",\"dpcItemTaxAmount\":\"0.00000000\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"3.69458128\",\"taxItemList\":[]},{\"dpcItem\":\"601\",\"cP\":\"0.12\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.03546798\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.59113300\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.02364532\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.01182266\"}]},{\"dpcItem\":\"662\",\"cP\":\"0.04\",\"glReference\":\"Visible_Unlimited_Text\",\"dpcItemTaxAmount\":\"0.01182266\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.19704433\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.00788177\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.00394089\"}]},{\"dpcItem\":\"629\",\"cP\":\"0.09\",\"glReference\":\"Visible_Unlimited_MMS\",\"dpcItemTaxAmount\":\"0.02660099\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.44334975\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.01773399\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.00886700\"}]}]}]},{\"btcTransactionCode\":\"93\",\"totalTaxAmount\":\"0.03002956\",\"totalFeeAmount\":\"0.00000000\",\"totalNetRevenue\":\"4.92610836\",\"modifiedDisplayNetRevenue\":\"4.93\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"601\",\"cP\":\"0.12\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.03002956\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.59113300\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000000016\",\"tat\":\"0\",\"taxCategory\":\"00\",\"taxType\":\"35\",\"description\":\"Fed Universal Service Charge\",\"rate\":\"0.050800000000\",\"taxAmount\":\"0.03002956\"}]}]}]}]}";
            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension eventPoExtn = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            eventPoExtn.getCreditTaxDetailsArrayAppender().clear();
            eventPoExtn.getCreditTaxDetailsArrayAppender().add(refCreditTax);
            /**************************** CurrentCyclePromos ********************/

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    oldCiId);
            BigDecimal mainbalanceUnlimited = CommonTestHelper.getOfferPrice(oldCiId);
            vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

            MtxResponsePricingCatalogItem pciGdw = emulateMtxResponsePricingCatalogItem(
                    instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
            VisibleTemplate vtGoodwill = (VisibleTemplate) pciGdw.getCatalogItemInfo().getTemplateAttr();
            vtGoodwill.setTaxResponseUnchanged((String) taxResponseUnchanged);

            ServiceStage ss = new ServiceStage(oldCiId);

            GlobalCreditStage gcsGoodwill = new GlobalCreditStage(
                    CI_EXTERNAL_IDS.GRANT_GOODWILL, vtGoodwill);
            gcsGoodwill.setPromotionName(vtGoodwill.getPromotionName());
            gcsGoodwill.setAvailableCredits(goodwillConsumable);
            gcsGoodwill.setAvailableCreditsConsumable(goodwillConsumable);
            gcsGoodwill.setAvailableCreditsGrant(goodwillGrant);
            gcsGoodwill.setRedeemOfferCi(vtGoodwill.getRedeemOffer());
            gcsGoodwill.setApplicableCiCsv(oldCiId);
            gcsGoodwill.getApplicableCiOrderMap().put(oldCiId, 2L);

            CreditStage csGoodwill = new CreditStage(gcsGoodwill, oldCiId);
            csGoodwill.setApplicableServiceStage(ss);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodUnlimited.getCatalogItemExternalId(),
                    Long.valueOf(vodUnlimited.getResourceId()), vodUnlimited);
            aopStage.getCreditMap().put(
                    new PromoOfferPair(oldCiId, vtGoodwill.getPromotionName()), csGoodwill);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                    newCiId);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            List<String> balPriList = Arrays.asList(BALANCE_NAMES.GOODWILL_GRANT);
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);

            String taxApiResp = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(
                                any(), argumentCaptor.capture())).thenReturn(taxApiResp);
                instance.getChangeServiceAdvice(request, response);
            }

            ServiceTaxRequest taxReq = null;
            for (String val : argumentCaptor.getAllValues()) {
                if (val.contains("GOOD-CR")) {
                    try {
                        taxReq = CommonTestHelper.getJsonFromString(ServiceTaxRequest.class, val);
                        System.out.println(td.getTestMethod() + ":" + taxReq.toJson());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());

            if (taxResponseUnchanged.toString().equalsIgnoreCase("Y")) {
                assertEquals(
                        response.getNextCycle().getAtCredits(0).getRedeemableCredits().intValue(),
                        taxReq.getDiscountPrice().intValue());
                System.out.println(td.getTestMethod() + "Test pass with tax unchanged method.");
            } else {
                assertEquals(
                        response.getNewCatalogItem().getDiscountPrice().subtract(
                                response.getNextCycle().getAtCredits(
                                        0).getRedeemableCredits()).intValue(),
                        taxReq.getDiscountPrice().intValue());
                System.out.println(td.getTestMethod() + "Test pass with tax subtraction method.");
            }
        };

        pTests.test("Y");
        pTests.test("N");
    }

    @Test
    public void test_getChangeServiceAdvice_When_ChangeAndNextCycle_GoodwillAvailable_Then_GoodwillForNextCycleOnly(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with base offer. PaidCycleStartDate is in future. Goodwill are available to subscriber.",
            " Goodwill applicable to new offer."
        };
        td.when = new String[] {
            "Api is called with new base offer."
        };
        td.then = new String[] {
            "Api response should NOT provide goodwill blocks for change cycle. Delta amount can not use goodwill.",
            " Goodwill will be present in next cycle."
        };

        String subscriptionExternalId = "123";
        @SuppressWarnings({
            "unchecked"
        })
        TwoParameterTest pTests = (oldCi, newCi) -> {
            td.printDescription();
            String randomFutureDate = "4712-12-31";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(newCi.toString());
            request.setDiscountPrice(CommonTestHelper.getOfferPrice(newCi.toString()));
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            BigDecimal mainbalance = BigDecimal.valueOf(40);
            String oldCiId = oldCi.toString();
            BigDecimal oldPrice = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.setExternalId(subscriptionExternalId);
            subscription.getPurchasedOfferArrayAppender().clear();

            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCiId);
            BigDecimal goodwillCredits = BigDecimal.valueOf(35);
            VisiblePurchasedOfferExtension enrolledExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            enrolledExtn.setChargeAmount(oldPrice);
            enrolledExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtn.setPaidCycleStartDate(new MtxDate(randomFutureDate));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCiId);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomFutureDate));

            MtxResponsePricingCatalogItem goodwillGrant = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class, DATA_DIR.COMMON
                            + "MtxResponsePricingCatalogItem_Visible_Grant_Goodwill_Credits.json");
            VisibleTemplate vtGoodwill = ((VisibleTemplate) goodwillGrant.getCatalogItemInfo().getTemplateAttr());
            emulateMtxResponsePricingCatalogItem(
                    instance, goodwillGrant, CI_EXTERNAL_IDS.GRANT_GOODWILL);

            MtxBalanceInfo biGoodwillGrant = CommonTestHelper.getMtxBalanceInfo(
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Grant.json", 4, 43);
            biGoodwillGrant.setAmount(goodwillCredits.negate());
            biGoodwillGrant.setAvailableAmount(goodwillCredits);
            subscription.getBalanceArrayAppender().add(biGoodwillGrant);

            List<String> balPriList = Arrays.asList(BALANCE_NAMES.GOODWILL_GRANT);
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));
            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(oldCiId, request.getNewCatalogItemExternalId()));
            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtn);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCiId);

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                    newCi.toString());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    CI_EXTERNAL_IDS.UNLIMITED);

            BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
            vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

            ServiceStage ss = new ServiceStage(oldCiId);

            GlobalCreditStage gcsGoodwill = new GlobalCreditStage(
                    CI_EXTERNAL_IDS.GRANT_GOODWILL, vtGoodwill);
            gcsGoodwill.setPromotionName(vtGoodwill.getPromotionName());
            gcsGoodwill.setAvailableCredits(goodwillCredits);
            gcsGoodwill.setAvailableCreditsConsumable(goodwillCredits);
            gcsGoodwill.setAvailableCreditsGrant(BigDecimal.ZERO);
            gcsGoodwill.setRedeemOfferCi(vtGoodwill.getRedeemOffer());
            gcsGoodwill.setApplicableCiCsv(oldCiId);
            gcsGoodwill.getApplicableCiOrderMap().put(oldCiId, 2L);

            CreditStage csGoodwill = new CreditStage(gcsGoodwill, oldCiId);
            csGoodwill.setApplicableServiceStage(ss);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodUnlimited.getCatalogItemExternalId(),
                    Long.valueOf(vodUnlimited.getResourceId()), vodUnlimited);
            aopStage.getCreditMap().put(
                    new PromoOfferPair(oldCiId, vtGoodwill.getPromotionName()), csGoodwill);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            String taxApiResp = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxApiResp);
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertThat(response.getNextCycle()).isNotNull();
            assertThat(response.getNextCycle().getCredits()).isNotNull();

            long goodwillBlocks = response.getNextCycle().getCredits().stream().filter(
                    cs -> CI_EXTERNAL_IDS.GOODWILL_REDEEM.equalsIgnoreCase(
                            cs.getCreditRedeemableOfferCI())).count();
            System.out.println(td.getTestMethod() + ":" + goodwillBlocks);
            assertTrue(goodwillBlocks > 0l);
        };

        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getChangeServiceAdvice_When_ChangeCycleAndNextCycle_ReverseAocPromos_Then_IgnoreOldAocPromos(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription PaidCycleStartDate after today. This means Manual Pay is already run for next cycle.",
            "Aoc Promotions were allocated for enrolled base offer in manual pay."
        };
        td.when = new String[] {
            "Api is called with new base offer."
        };
        td.then = new String[] {
            "Api response should provide AoC promos in reverse promo blocks as well as non redeemable promo blocks."
        };

        td.printDescription();
        String subscriptionExternalId = "123";
        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        String newCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        String oldCiId = CI_EXTERNAL_IDS.PLUS_CURRENT;
        request.setNewCatalogItemExternalId(newCiId);
        request.setGrossPrice(BigDecimal.valueOf(100));
        request.setDiscountPrice(CommonTestHelper.getOfferPrice(oldCiId));
        request.setSubscriptionExternalId(subscriptionExternalId);
        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();
        BigDecimal aocDelta = BigDecimal.TEN;
        String randomFutureDate = "4712-12-31";
        BigDecimal mainbalance = aocDelta; // Let all mainbalance get used by ChangeCycle
        BigDecimal ca5Promos = BigDecimal.valueOf(5);

        String groupTax = "{\"msgID\":\"IJKL-CR\",\"customerType\":\"99\",\"planID\":\"BASE001A\",\"grossPrice\":\"5.00\",\"discountPrice\":\""
                + ca5Promos
                + "\",\"promotionCredit\":\"true\",\"offer606RevAdjDailyRecog\":\"0\",\"promotionReason\":\"Group_Discounts\",\"geocode\":\"US0100108296\",\"taxTreatment\":\"inclusive\",\"classCode\":\"GD-CR\",\"glDate\":\"2019-03-07\",\"transactionElement\":[{\"btcTransactionCode\":\"01\",\"totalTaxAmount\":\"0.07389163\",\"totalFeeAmount\":\"0.00000000\",\"totalNetRevenue\":\"4.92610836\",\"modifiedDisplayNetRevenue\":\"4.93\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"618\",\"cP\":\"0.75\",\"glReference\":\"Visible_Unlimited_Data\",\"dpcItemTaxAmount\":\"0.00000000\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"3.69458128\",\"taxItemList\":[]},{\"dpcItem\":\"601\",\"cP\":\"0.12\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.03546798\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.59113300\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.02364532\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.01182266\"}]},{\"dpcItem\":\"662\",\"cP\":\"0.04\",\"glReference\":\"Visible_Unlimited_Text\",\"dpcItemTaxAmount\":\"0.01182266\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.19704433\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.00788177\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.00394089\"}]},{\"dpcItem\":\"629\",\"cP\":\"0.09\",\"glReference\":\"Visible_Unlimited_MMS\",\"dpcItemTaxAmount\":\"0.02660099\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.44334975\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.01773399\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.00886700\"}]}]}]},{\"btcTransactionCode\":\"93\",\"totalTaxAmount\":\"0.03002956\",\"totalFeeAmount\":\"0.00000000\",\"totalNetRevenue\":\"4.92610836\",\"modifiedDisplayNetRevenue\":\"4.93\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"601\",\"cP\":\"0.12\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.03002956\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.59113300\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000000016\",\"tat\":\"0\",\"taxCategory\":\"00\",\"taxType\":\"35\",\"description\":\"Fed Universal Service Charge\",\"rate\":\"0.050800000000\",\"taxAmount\":\"0.03002956\"}]}]}]}]}";

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance, CommonTestHelper.getSubscriptionResponse(
                        subscriptionExternalId, List.of(oldCiId, CI_EXTERNAL_IDS.CA5_GRANT)));
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) subscriptionResponse.getAtPurchasedOfferArray(
                0).getAttr();
        enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomFutureDate));
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().add(groupTax);

        emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription(subscriptionResponse));

        /**************************** CurrentCyclePromos ********************/
        EventQueryResponseEvents eqre = new EventQueryResponseEvents();
        emulateEventQueryResponseEvents(instance, eqre);
        EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                EventQueryEventInfo.class,
                DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
        eqre.getEventListAppender().add(eqei);
        MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
        recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledPoiExtn);
        /**************************** CurrentCyclePromos ********************/

        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(oldCiId, newCiId));
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

        VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                oldCiId);
        BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
        vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        MtxResponsePricingCatalogItem pciGroup = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.CA5_GRANT);
        VisibleTemplate vtGroup = (VisibleTemplate) pciGroup.getCatalogItemInfo().getTemplateAttr();

        /**************************** NextCyclePromos to be reversed ********************/
        ServiceStage ss = new ServiceStage(oldCiId);

        GlobalCreditStage gcsGroup = new GlobalCreditStage(CI_EXTERNAL_IDS.CA5_GRANT, vtGroup);
        gcsGroup.setPromotionName(vtGroup.getPromotionName());
        gcsGroup.setAvailableCredits(ca5Promos);
        gcsGroup.setAvailableCreditsConsumable(ca5Promos);
        gcsGroup.setAvailableCreditsGrant(ca5Promos);
        gcsGroup.setRedeemOfferCi(vtGroup.getRedeemOffer());
        gcsGroup.setApplicableCiCsv(oldCiId);
        gcsGroup.getApplicableCiOrderMap().put(oldCiId, 1L);

        CreditStage csGroup = new CreditStage(gcsGroup, oldCiId);
        csGroup.setCreditTaxDetails(groupTax);
        csGroup.setApplicableServiceStage(ss);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodUnlimited.getCatalogItemExternalId(), Long.valueOf(vodUnlimited.getResourceId()),
                vodUnlimited);
        aopStage.getCreditMap().put(
                new PromoOfferPair(oldCiId, vtGroup.getPromotionName()), csGroup);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

        /**************************** NextCyclePromos to be reversed ********************/

        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                newCiId);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);
        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        List<String> balPriList = Arrays.asList(BALANCE_NAMES.CA5_GRANT);
        emulateMtxResponseMultiFromObject(
                instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));
        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        String taxApiResp = CommonTestHelper.getTaxApiResp(newCiId);
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp);
            instance.getChangeServiceAdvice(request, response);
        }
        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(CI_EXTERNAL_IDS.CA5_GRANT, response.getAtNonRedeemableCredits(0).getGrantOfferCI(),"CA5 should be listed in non-redeemable");
        assertEquals(CI_EXTERNAL_IDS.CA5_REDEEM, response.getNextCycle().getAtReverseCredits(0).getRedeemableOfferCI(),"CA5 should be listed in reverse credits");
    }

    @Test
    public void test_getChangeServiceAdvice_When_ChangeCycleAndNextCycle_ReverseAocPromos_NoCancellableOffer_Then_IgnoreOldAocPromos(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription PaidCycleStartDate after today. This means Manual Pay is already run for next cycle.",
            "Promotions were allocated for enrolled base offer in manual pay. These promotions are not cancellable"
        };
        td.when = new String[] {
            "Api is called with new base offer."
        };
        td.then = new String[] {
            "Api response should provide reverse promo blocks for promos that were applied for renewal of current base offer.",
            "But non cancellable reverse promotions should be added to grants"
        };

        @SuppressWarnings({
            "unchecked"
        })
        ThreeParameterTest pTests = (reservedPromosParam, usedPromosParam, freePromosParam) -> {
            td.printDescription();
            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            String newCiId = CI_EXTERNAL_IDS.PLUS_CURRENT;
            String oldCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
            request.setNewCatalogItemExternalId(newCiId);
            request.setGrossPrice(BigDecimal.valueOf(100));
            request.setDiscountPrice(OFFER_PRICES.PLUS_CURRENT);
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();
            BigDecimal aocDelta = BigDecimal.TEN;
            String randomFutureDate = "4712-12-31";
            BigDecimal mainbalance = aocDelta; // Let all mainbalance get used by ChangeCycle
            BigDecimal freePromos = BigDecimal.valueOf((int) freePromosParam);
            BigDecimal reservedPromos = BigDecimal.valueOf((int) reservedPromosParam); // BigDecimal.valueOf(34);
            BigDecimal usedPromos = BigDecimal.valueOf((int) usedPromosParam);// BigDecimal.valueOf(23);

            MtxResponseSubscription subscription = null;
            try {
                subscription = emulateMtxResponseSubscription(
                        api, CommonTestHelper.getMtxResponseSubscription());
            } catch (Exception e) {
                e.printStackTrace();
            }

            /****************************
             * Grant Promos that can be used in next cycles
             ********************/
            MtxBalanceInfo biGoodwill = CommonTestHelper.getMtxBalanceInfo(
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Grant.json", 4, 43);
            biGoodwill.setAmount(freePromos.negate());
            biGoodwill.setAvailableAmount(freePromos);
            subscription.getBalanceArrayAppender().add(biGoodwill);
            /****************************
             * Grant Promos that can be used in next cycles
             ********************/

            subscription.getPurchasedOfferArrayAppender().clear();

            MtxPurchasedOfferInfo poUnlimited = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCiId);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poUnlimited.getAttr();
            poExtn.setPaidCycleStartDate(new MtxDate(randomFutureDate));
            subscription.getPurchasedOfferArrayAppender().add(poUnlimited);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCiId);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomFutureDate));

            /**************************** CurrentCyclePromos ********************/
            String refCreditTax = "{\"msgID\":\"EFGH-CR\",\"customerType\":\"99\",\"planID\":\"BASE001A\",\"grossPrice\":\"5.00\",\"discountPrice\":\""
                    + usedPromos
                    + "\",\"promotionCredit\":\"true\",\"offer606RevAdjDailyRecog\":\"0\",\"promotionReason\":\"Referee_Credits\",\"geocode\":\"US0100108296\",\"taxTreatment\":\"inclusive\",\"classCode\":\"REF-CR\",\"glDate\":\"2019-03-07\",\"transactionElement\":[{\"btcTransactionCode\":\"01\",\"totalTaxAmount\":\"0.07389163\",\"totalFeeAmount\":\"0.00000000\",\"totalNetRevenue\":\"4.92610836\",\"modifiedDisplayNetRevenue\":\"4.93\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"618\",\"cP\":\"0.75\",\"glReference\":\"Visible_Unlimited_Data\",\"dpcItemTaxAmount\":\"0.00000000\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"3.69458128\",\"taxItemList\":[]},{\"dpcItem\":\"601\",\"cP\":\"0.12\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.03546798\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.59113300\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.02364532\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.01182266\"}]},{\"dpcItem\":\"662\",\"cP\":\"0.04\",\"glReference\":\"Visible_Unlimited_Text\",\"dpcItemTaxAmount\":\"0.01182266\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.19704433\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.00788177\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.00394089\"}]},{\"dpcItem\":\"629\",\"cP\":\"0.09\",\"glReference\":\"Visible_Unlimited_MMS\",\"dpcItemTaxAmount\":\"0.02660099\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.44334975\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.01773399\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.00886700\"}]}]}]},{\"btcTransactionCode\":\"93\",\"totalTaxAmount\":\"0.03002956\",\"totalFeeAmount\":\"0.00000000\",\"totalNetRevenue\":\"4.92610836\",\"modifiedDisplayNetRevenue\":\"4.93\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"601\",\"cP\":\"0.12\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.03002956\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.59113300\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000000016\",\"tat\":\"0\",\"taxCategory\":\"00\",\"taxType\":\"35\",\"description\":\"Fed Universal Service Charge\",\"rate\":\"0.050800000000\",\"taxAmount\":\"0.03002956\"}]}]}]}]}";
            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension eventPoExtn = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            eventPoExtn.getCreditTaxDetailsArrayAppender().clear();
            eventPoExtn.getCreditTaxDetailsArrayAppender().add(refCreditTax);
            /**************************** CurrentCyclePromos ********************/

            emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(oldCiId, newCiId));
            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    CI_EXTERNAL_IDS.UNLIMITED);
            BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
            vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

            MtxResponsePricingCatalogItem pciGdw = emulateMtxResponsePricingCatalogItem(
                    instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
            VisibleTemplate vtGoodwill = (VisibleTemplate) pciGdw.getCatalogItemInfo().getTemplateAttr();

            /**************************** NextCyclePromos to be reversed ********************/
            String goodwillTax = CommonTestHelper.getPromoTaxResp(
                    CI_EXTERNAL_IDS.GRANT_GOODWILL, oldCiId, reservedPromos);
            poExtn.getCreditTaxDetailsArrayAppender().clear();
            poExtn.getCreditTaxDetailsArrayAppender().add(goodwillTax);

            ServiceStage ss = new ServiceStage(oldCiId);

            GlobalCreditStage gcsGoodwill = new GlobalCreditStage(
                    CI_EXTERNAL_IDS.GRANT_GOODWILL, vtGoodwill);
            gcsGoodwill.setPromotionName(vtGoodwill.getPromotionName());
            gcsGoodwill.setAvailableCredits(reservedPromos.add(freePromos));
            gcsGoodwill.setAvailableCreditsConsumable(reservedPromos);
            gcsGoodwill.setAvailableCreditsGrant(freePromos);
            gcsGoodwill.setRedeemOfferCi(vtGoodwill.getRedeemOffer());
            gcsGoodwill.setApplicableCiCsv(oldCiId);
            gcsGoodwill.getApplicableCiOrderMap().put(oldCiId, 2L);

            CreditStage csGoodwill = new CreditStage(gcsGoodwill, oldCiId);
            csGoodwill.setCreditTaxDetails(goodwillTax);
            csGoodwill.setApplicableServiceStage(ss);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodUnlimited.getCatalogItemExternalId(),
                    Long.valueOf(vodUnlimited.getResourceId()), vodUnlimited);
            aopStage.getCreditMap().put(
                    new PromoOfferPair(oldCiId, vtGoodwill.getPromotionName()), csGoodwill);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            /**************************** NextCyclePromos to be reversed ********************/

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                    newCiId);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            List<String> balPriList = Arrays.asList(BALANCE_NAMES.GOODWILL_GRANT);
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            String taxApiResp = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxApiResp);
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());

            BigDecimal effectiveOldPrice = poExtn.getChargeAmount().subtract(reservedPromos);
            BigDecimal moneyOnlyAmount = request.getDiscountPrice().subtract(effectiveOldPrice);
            System.out.println("moneyOnlyAmount: " + moneyOnlyAmount);
            boolean rcGoowillPresent = false;
            for (VisibleReverseCredit rc : response.getNextCycle().getReverseCredits()) {
                if (CI_EXTERNAL_IDS.GOODWILL_REDEEM.equalsIgnoreCase(rc.getRedeemableOfferCI())) {
                    rcGoowillPresent = true;
                    break;
                }
            }

            assertTrue(rcGoowillPresent);

            boolean promoGoodwillPresent = false;
            if (response.getNextCycle().getCredits() != null) {
                for (VisibleCredits promo : response.getNextCycle().getCredits()) {
                    if (CI_EXTERNAL_IDS.GOODWILL_REDEEM.equalsIgnoreCase(
                            promo.getCreditRedeemableOfferCI())) {
                        promoGoodwillPresent = true;
                        break;
                    }
                }
            }

            assertFalse(promoGoodwillPresent);
        };

        pTests.test(34, 23, 0);
        pTests.test(23, 34, 0);
    }

    @Test
    public void test_getChangeServiceAdvice_When_ChangeCycleAndNextCycle_PromoPresent_Then_NoPromoForFixedFee(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription PaidCycleStartDate after today. This means Manual Pay is already run for next cycle.",
            "Promotions are present"
        };
        td.when = new String[] {
            "Api is called with new base offer. Taxes for next cycle has fixed fee"
        };
        td.then = new String[] {
            "Promo should not be applied to fixed fee amount in next cycle."
        };
        @SuppressWarnings({
            "unchecked"
        })
        TwoParameterTest pTests = (oldCi, newCi) -> {
            td.printDescription();
            String oldOfferId = oldCi.toString();
            String randomFutureDate = "4712-12-31";
            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(newCi.toString());
            request.setDiscountPrice(CommonTestHelper.getOfferPrice(newCi.toString()));
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.valueOf(40);

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            /* Ref35 Promos available in grant balance */
            int freePromos = 60;
            MtxBalanceInfo biRef35 = CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                    CI_EXTERNAL_IDS.REF20_GRANT, BigDecimal.valueOf(freePromos));
            subscription.getBalanceArrayAppender().add(biRef35);

            List<String> balPriList = Arrays.asList(BALANCE_NAMES.REF20_GRANT);
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));

            /* Ref35 Catalog Item / Template Attribute mock */
            MtxResponsePricingCatalogItem ciRef35Grant = emulateMtxResponsePricingCatalogItem(
                    instance, CI_EXTERNAL_IDS.REF20_GRANT);
            VisibleTemplate vt = ((VisibleTemplate) ciRef35Grant.getCatalogItemInfo().getTemplateAttr());
            vt.setMinimumCharge(BigDecimal.ZERO);// This will force to use most of the credits
            vt.setPromotionLimit(BigDecimal.valueOf(100));// This will force to use most of the
                                                          // credits

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldOfferId);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            poExtn.setPaidCycleStartDate(new MtxDate(randomFutureDate));

            if (CI_EXTERNAL_IDS.PLUS_CURRENT.equalsIgnoreCase(newCi.toString())) {
                poExtn.setChargeAmount(BigDecimal.valueOf(44.9999999)); // reduce gap
            }

            poEnrolled.setCatalogItemExternalId(oldOfferId);
            subscription.getPurchasedOfferArrayAppender().add(poEnrolled);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldOfferId);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldOfferId));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomFutureDate));

            emulateMtxResponsePricingCatalogItem(instance, oldOfferId);

            MtxResponsePricingCatalogItem pciNew = emulateMtxResponsePricingCatalogItem(
                    instance, request.getNewCatalogItemExternalId());
            String deltaTaxInputMsgID = "\"XYZDELTAXYZ\"";
            String deltaTaxInput = "{   \"msgID\":" + deltaTaxInputMsgID
                    + ",   \"customerType\": \"99\",   \"planID\": \"BASE001A\",   \"grossPrice\": \"0\",   \"discountPrice\": \"0\",   \"geocode\": \"US\",   \"glDate\": \"2019-09-01\",   \"taxTreatment\": \"inclusive\",   \"classCode\": \"SVC\",   \"offer606RevAdjDailyRecog\": \"0\",   \"promotionCredit\": false,   \"dpcGroupList\": [     {       \"dpcGroup\": \"5018\",       \"dpcItemList\": [         {           \"dpcItem\": \"618\",           \"cP\": \".9719167977\",           \"cycleNSR\": \"0\",           \"glReference\": \"Visible_Unlimited_Data\"         },         {           \"dpcItem\": \"601\",           \"cP\": \".0238925768\",           \"cycleNSR\": \"0\",           \"glReference\": \"Visible_Unlimited_Voice\"         },         {           \"dpcItem\": \"662\",           \"cP\": \".0000041959\",           \"cycleNSR\": \"0\",           \"glReference\": \"Visible_Unlimited_Text\"         },         {           \"dpcItem\": \"629\",           \"cP\": \".0041864296\",           \"cycleNSR\": \"0\",           \"glReference\": \"Visible_Unlimited_MMS\"         }       ]     }   ] }";
            MtxPricingMetadataInfo pmi = new MtxPricingMetadataInfo();
            pmi.setName(CI_METADATA.CHANGE_CYCLE_DELTA_TAX_INPUT);
            pmi.setType("String");
            pmi.setValue(deltaTaxInput);
            pciNew.getCatalogItemInfo().getMetadataListAppender().add(pmi);
            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                    newCi.toString());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    oldOfferId);
            BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
            vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

            BigDecimal fixedFeeNextCycle = BigDecimal.valueOf(1.81);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodUnlimited.getCatalogItemExternalId(),
                    Long.valueOf(vodUnlimited.getResourceId()), vodUnlimited);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespNextCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedFeeNextCycle);
                // if (CI_EXTERNAL_IDS.PLUS2VIS22.equalsIgnoreCase(oldCi.toString())
                // && CI_EXTERNAL_IDS.BASE2VIS22.equalsIgnoreCase(newCi.toString())) {
                // Since new Ci starts next cycle there will be no prorated charge. TaxApi gets
                // called only once.
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespNextCycle.toJson());

                // } else {
                // mockedStatic.when(
                // () -> TaxApiClient.getTaxApiResult(
                // any(), anyString())).thenReturn(
                // taxRespChangeCycle.toJson()).thenReturn(
                // taxRespNextCycle.toJson());
                // }
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());

            assertEquals(
                    response.getNextCycle().getTotalAmount().subtract(fixedFeeNextCycle),
                    response.getNextCycle().getAtCredits(0).getRedeemableCredits());
        };

        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT);
    }

    @Test
    @Disabled("Nib / Visible_Unlimited plans are obsolete.")
    public void test_getChangeServiceAdvice_ChangeAndNextCycle_NibToCoreUpDowngrade_Then_CorrectNextCycleOutput(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with base offer. PaidCycleStartDate is in future."
        };
        td.when = new String[] {
            "Api is called for NibToCoreUpgrade"
        };
        td.then = new String[] {
            "Validate NextCycleFields"
        };
    }

    @Test
    @Disabled("Nib / Visible_Unlimited plans are obsolete.")
    public void test_getChangeServiceAdvice_ChangeAndNextCycle_NibToCoreUpgrade_Then_CorrectNextCycleOutput(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with base offer. PaidCycleStartDate is in future."
        };
        td.when = new String[] {
            "Api is called for NibToCoreUpgrade"
        };
        td.then = new String[] {
            "Validate NextCycleFields"
        };
    }

    @Test
    public void test_getChangeServiceAdvice_ChangeAndNextCycle_With_Aoc_Promos_Then_AocConsumablesNotAddedToGrant(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with base offer. PaidCycleStartDate is in future.There are Aoc consumables present."
        };
        td.when = new String[] {
            "Api is called for NibToCoreUpgrade"
        };
        td.then = new String[] {
            "Aoc consumables will be added to reverse credits block. Aoc consumables will not be assumed to move to grant. They will not considered as part of Aoc grants."
        };

        @SuppressWarnings({
            "unchecked", "rawtypes"
        })
        OneParameterTest pTests = (tCase) -> {
            String subscriptionExternalId = "123";
            TestConditions testCase = (TestConditions) tCase;
            td.printDescription();
            System.out.println(
                    "**************************Executing " + testCase.testNum
                            + "********************************");

            String randomFutureDate = "4712-12-31";
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal goodwillCredits = BigDecimal.valueOf(testCase.otherPromos);

            BigDecimal oldCa5 = (BigDecimal) testCase.promoMap.get("CA5CONS");
            BigDecimal newCa5 = BigDecimal.valueOf(5);

            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setDiscountPrice(CommonTestHelper.getOfferPrice(testCase.newCi));
            request.setNewCatalogItemExternalId(testCase.newCi);

            String oldCiId = testCase.oldCi;

            request.setSubscriptionExternalId(subscriptionExternalId);
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));

            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            String goodwillTax = CommonTestHelper.getPromoTaxResp(
                    CI_EXTERNAL_IDS.GRANT_GOODWILL, oldCiId, goodwillCredits);
            String ca5Tax = CommonTestHelper.getPromoTaxResp(
                    CI_EXTERNAL_IDS.CA5_GRANT, oldCiId, TAX_CLASS_CODES.CA5, oldCa5);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            List.of(oldCiId, CI_EXTERNAL_IDS.CA5_GRANT)));
            MtxPurchasedOfferInfo poiEnrolled = subscriptionResponse.getAtPurchasedOfferArray(0);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().add(goodwillTax);
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().add(ca5Tax);
            enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomFutureDate));

            MtxBalanceInfo biGoodwillGrant = CommonTestHelper.getMtxBalanceInfo(
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Grant.json", 4, 43);
            biGoodwillGrant.setAmount(BigDecimal.ZERO);
            biGoodwillGrant.setAvailableAmount(BigDecimal.ZERO);
            subscriptionResponse.getBalanceArrayAppender().add(biGoodwillGrant);

            MtxBalanceInfo biGoodwillConsumable = CommonTestHelper.getMtxBalanceInfo(
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Consumable.json", 4, 44);
            biGoodwillConsumable.setAmount(goodwillCredits.negate());
            biGoodwillConsumable.setAvailableAmount(goodwillCredits);
            subscriptionResponse.getBalanceArrayAppender().add(biGoodwillConsumable);

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(subscriptionResponse));
            ;
            System.out.println(
                    oldCiId + "**********************************" + testCase.newCi
                            + "******************************");

            MtxResponsePricingCatalogItem pciCa5 = emulateMtxResponsePricingCatalogItem(
                    instance, CI_EXTERNAL_IDS.CA5_GRANT);
            VisibleTemplate vtCa5 = (VisibleTemplate) pciCa5.getCatalogItemInfo().getTemplateAttr();

            emulateMtxResponsePricingCatalogItem(instance, oldCiId);
            MtxResponsePricingCatalogItem pciNewCi = emulateMtxResponsePricingCatalogItem(
                    instance, request.getNewCatalogItemExternalId());

            BigDecimal mainbalance = BigDecimal.ZERO;

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));
            VisibleTemplate vtNewCi = (VisibleTemplate) pciNewCi.getCatalogItemInfo().getTemplateAttr();
            vtNewCi.setIgnoreTax_ForPayableAmount("false");

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();

            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledPoiExtn);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCiId);

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    String redeemOffer = args[1].toString();
                    if (CI_EXTERNAL_IDS.CA5_REDEEM.equalsIgnoreCase(redeemOffer)) {
                        return newCa5.negate();
                    } else {
                        return BigDecimal.ZERO;
                    }
                }
            }).when(instance).getChargeableAmountForPurchaseOffer(any(), any(), any(), any());

            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            List<String> balPriList = Arrays.asList(
                    BALANCE_NAMES.GOODWILL_GRANT, BALANCE_NAMES.CA5_GRANT);
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");

            MtxPurchasedOfferInfo poiGoodwill = CommonTestHelper.loadJsonMessage(
                    MtxPurchasedOfferInfo.class, DATA_DIR.CHANGE_SERVICE
                            + "MtxPurchasedOfferInfo_Visible_Redeem_Goodwill_Credits.json");
            poiGoodwill.setResourceId(55L);

            emulateMtxResponseOneTimeOffer(instance, poiGoodwill);

            MtxResponsePricingCatalogItem goodwillGrant = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class, DATA_DIR.COMMON
                            + "MtxResponsePricingCatalogItem_Visible_Grant_Goodwill_Credits.json");
            VisibleTemplate vtGoodwill = ((VisibleTemplate) goodwillGrant.getCatalogItemInfo().getTemplateAttr());
            emulateMtxResponsePricingCatalogItem(
                    instance, goodwillGrant, CI_EXTERNAL_IDS.GRANT_GOODWILL);

            VisibleOfferDetails vodBase = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    oldCiId);
            BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
            vodBase.setConsumableMainBalanceAmount(mainbalanceUnlimited);

            ServiceStage ss = new ServiceStage(oldCiId);

            GlobalCreditStage gcsGoodwill = new GlobalCreditStage(
                    CI_EXTERNAL_IDS.GRANT_GOODWILL, vtGoodwill);
            gcsGoodwill.setPromotionName(vtGoodwill.getPromotionName());
            gcsGoodwill.setAvailableCredits(goodwillCredits);
            gcsGoodwill.setAvailableCreditsConsumable(goodwillCredits);
            gcsGoodwill.setAvailableCreditsGrant(BigDecimal.ZERO);
            gcsGoodwill.setRedeemOfferCi(vtGoodwill.getRedeemOffer());
            gcsGoodwill.setApplicableCiCsv(oldCiId);
            gcsGoodwill.getApplicableCiOrderMap().put(oldCiId, 2L);

            CreditStage csGoodwill = new CreditStage(gcsGoodwill, oldCiId);
            csGoodwill.setCreditTaxDetails(goodwillTax);
            csGoodwill.setApplicableServiceStage(ss);

            GlobalCreditStage gcsCa5 = new GlobalCreditStage(CI_EXTERNAL_IDS.CA5_GRANT, vtCa5);
            gcsCa5.setPromotionName(vtCa5.getPromotionName());
            gcsCa5.setAvailableCredits(oldCa5);
            gcsCa5.setAvailableCreditsConsumable(oldCa5);
            gcsCa5.setAvailableCreditsGrant(BigDecimal.ZERO);
            gcsCa5.setRedeemOfferCi(vtCa5.getRedeemOffer());
            gcsCa5.setApplicableCiCsv(oldCiId);
            gcsCa5.getApplicableCiOrderMap().put(oldCiId, 2L);

            CreditStage csCa5 = new CreditStage(gcsCa5, oldCiId);
            csCa5.setApplicableServiceStage(ss);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodBase.getCatalogItemExternalId(), Long.valueOf(vodBase.getResourceId()),
                    vodBase);
            if (goodwillCredits.signum() > 0) {
                aopStage.getCreditMap().put(
                        new PromoOfferPair(oldCiId, vtGoodwill.getPromotionName()), csGoodwill);
            }

            aopStage.getCreditMap().put(
                    new PromoOfferPair(oldCiId, vtCa5.getPromotionName()), csCa5);
            MtxResponseGroup respGrp = CommonTestHelper.getMtxResponseGroupCA(
                    subscriptionResponse.getExternalId(), "CAGroup",
                    List.of(subscriptionResponse.getObjectId().toString(), "1-2-3-4", "6-7-8-9"),
                    List.of(
                            String.format(
                                    GROUP_CONSTANTS.CA_LINK_FORMAT,
                                    subscriptionResponse.getExternalId(), "13579")));
            SubscriberGroup sg = new SubscriberGroup(respGrp);
            aopStage.appendSubscriberGroupList(sg);

            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ObjectMapper om = TestUtils.getObjectMapper();
                ServiceTaxResponse resp = om.readValue(taxRespString, ServiceTaxResponse.class);
                resp.getTransactionElement().get(0).setTotalFeeAmount(
                        BigDecimal.valueOf(testCase.fixedFee));
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                resp.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());

            BigDecimal actualCaRC = BigDecimal.ZERO;
            for (VisibleReverseCredit rc : CommonUtils.emptyIfNull(
                    response.getNextCycle().getReverseCredits())) {
                if (rc.getPromotionName().equalsIgnoreCase(vtCa5.getPromotionName())) {
                    actualCaRC = rc.getAvailableCreditsConsumable();
                }
            }

            BigDecimal actualCa = BigDecimal.ZERO;
            for (VisibleCredits promo : CommonUtils.emptyIfNull(
                    response.getNextCycle().getCredits())) {
                if (promo.getPromotionName().equalsIgnoreCase(vtCa5.getPromotionName())) {
                    actualCa = promo.getAvailableCreditsGrant();
                }
            }

            System.out.println(
                    "**************************Assertions of " + testCase.testNum
                            + "********************************");
            assertEquals(oldCa5.doubleValue(), actualCaRC.doubleValue(), 0.001);
            assertEquals(newCa5.doubleValue(), actualCa.doubleValue(), 0.001);

            System.out.println(
                    "**************************End of " + testCase.testNum
                            + "********************************");
        };

        TestConditions tc = new TestConditions();
        SimpleEntry<String, String> change = new SimpleEntry<>(
                CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT);
        tc.oldCi = change.getKey();
        tc.newCi = change.getValue();

        tc.otherPromos = 5;
        tc.aocDelta = 0.33;
        tc.fixedFee = 1.81;
        tc.minimumCharge = 5;
        tc.promoMap.put("CA5CONS", BigDecimal.valueOf(4));
        String testString = "-AocDelta-" + 0.33 + "-OtherPromos-" + 5;
        tc.testNum = "#1" + testString;
        pTests.test(tc);

    }

    @Test
    public void test_getChangeServiceAdvice_ChangeAndNextCycle_With_Onetime_Promos_Then_OnetimeConsumablesAddedToGrant(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with base offer. PaidCycleStartDate is in future. There are Non-Aoc promo consumables present."
        };
        td.when = new String[] {
            "Api is called for NibToCoreUpgrade"
        };
        td.then = new String[] {
            "Non-Aoc consumables will be added to reverse credits block. Non-Aoc consumables will be assumed to move to grant. They will be considered as part of Non-Aoc grants."
        };

        @SuppressWarnings({
            "unchecked"
        })
        OneParameterTest pTests = (tCase) -> {
            String subscriptionExternalId = "123";
            TestConditions testCase = (TestConditions) tCase;
            td.printDescription();
            System.out.println(
                    "**************************Executing " + testCase.testNum
                            + "********************************");

            String randomFutureDate = "4712-12-31";

            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(testCase.newCi);
            request.setDiscountPrice(CommonTestHelper.getOfferPrice(testCase.newCi));
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
            String oldCiId = testCase.oldCi;
            BigDecimal oldPrice = CommonTestHelper.getOfferPrice(testCase.oldCi);

            request.setSubscriptionExternalId(subscriptionExternalId);
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));

            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, CI_EXTERNAL_IDS.UNLIMITED);
            poEnrolled.setCatalogItemExternalId(oldCiId);

            BigDecimal goodwillCredits = BigDecimal.valueOf(testCase.otherPromos);
            String goodwillTax = CommonTestHelper.getPromoTaxResp(
                    CI_EXTERNAL_IDS.GRANT_GOODWILL, oldCiId, goodwillCredits);

            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            enrolledExtnSub.setChargeAmount(oldPrice);
            enrolledExtnSub.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnSub.getCreditTaxDetailsArrayAppender().add(goodwillTax);
            BigDecimal nibCredits = goodwillCredits;
            enrolledExtnSub.setPaidCycleStartDate(new MtxDate(randomFutureDate));
            subscription.getPurchasedOfferArrayAppender().add(poEnrolled);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCiId);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomFutureDate));

            MtxBalanceInfo biGoodwillGrant = CommonTestHelper.getMtxBalanceInfo(
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Grant.json", 4, 43);
            biGoodwillGrant.setAmount(BigDecimal.ZERO);
            biGoodwillGrant.setAvailableAmount(BigDecimal.ZERO);
            subscription.getBalanceArrayAppender().add(biGoodwillGrant);

            MtxBalanceInfo biGoodwillConsumable = CommonTestHelper.getMtxBalanceInfo(
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Consumable.json", 4, 44);
            biGoodwillConsumable.setAmount(goodwillCredits.negate());
            biGoodwillConsumable.setAvailableAmount(goodwillCredits);
            subscription.getBalanceArrayAppender().add(biGoodwillConsumable);

            emulateMtxResponsePricingCatalogItem(instance, oldCiId);

            MtxResponsePricingCatalogItem pciNewCi = emulateMtxResponsePricingCatalogItem(
                    instance, request.getNewCatalogItemExternalId());

            BigDecimal mainbalance = BigDecimal.ZERO;

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));
            VisibleTemplate vtNewCi = (VisibleTemplate) pciNewCi.getCatalogItemInfo().getTemplateAttr();
            vtNewCi.setIgnoreTax_ForPayableAmount("false");

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = new VisiblePurchasedOfferExtension();
            enrolledExtnEvent.setChargeAmount(oldPrice);
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(TestUtils.getLastDateOfCurrentMonth());
            enrolledExtnEvent.setTaxDetails(taxRespString);

            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCiId);

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.valueOf(testCase.aocDelta);

            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            List<String> balPriList = Arrays.asList(BALANCE_NAMES.GOODWILL_GRANT);
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));

            MtxPurchasedOfferInfo poiGoodwill = CommonTestHelper.loadJsonMessage(
                    MtxPurchasedOfferInfo.class, DATA_DIR.CHANGE_SERVICE
                            + "MtxPurchasedOfferInfo_Visible_Redeem_Goodwill_Credits.json");
            poiGoodwill.setResourceId(55L);
            emulateMtxResponseOneTimeOffer(instance, poiGoodwill);

            MtxResponsePricingCatalogItem goodwillGrant = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class, DATA_DIR.COMMON
                            + "MtxResponsePricingCatalogItem_Visible_Grant_Goodwill_Credits.json");
            VisibleTemplate vtGoodwill = ((VisibleTemplate) goodwillGrant.getCatalogItemInfo().getTemplateAttr());
            emulateMtxResponsePricingCatalogItem(
                    instance, goodwillGrant, CI_EXTERNAL_IDS.GRANT_GOODWILL);

            VisibleOfferDetails vodBase = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    oldCiId);
            BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
            vodBase.setConsumableMainBalanceAmount(mainbalanceUnlimited);

            ServiceStage ss = new ServiceStage(oldCiId);

            GlobalCreditStage gcsGoodwill = new GlobalCreditStage(
                    CI_EXTERNAL_IDS.GRANT_GOODWILL, vtGoodwill);
            gcsGoodwill.setPromotionName(vtGoodwill.getPromotionName());
            gcsGoodwill.setAvailableCredits(goodwillCredits);
            gcsGoodwill.setAvailableCreditsConsumable(goodwillCredits);
            gcsGoodwill.setAvailableCreditsGrant(BigDecimal.ZERO);
            gcsGoodwill.setRedeemOfferCi(vtGoodwill.getRedeemOffer());
            gcsGoodwill.setApplicableCiCsv(oldCiId);
            gcsGoodwill.getApplicableCiOrderMap().put(oldCiId, 2L);

            CreditStage csGoodwill = new CreditStage(gcsGoodwill, oldCiId);
            csGoodwill.setCreditTaxDetails(goodwillTax);
            csGoodwill.setApplicableServiceStage(ss);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodBase.getCatalogItemExternalId(), Long.valueOf(vodBase.getResourceId()),
                    vodBase);
            aopStage.getCreditMap().put(
                    new PromoOfferPair(oldCiId, vtGoodwill.getPromotionName()), csGoodwill);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ObjectMapper om = TestUtils.getObjectMapper();
                ServiceTaxResponse resp = om.readValue(taxRespString, ServiceTaxResponse.class);
                resp.getTransactionElement().get(0).setTotalFeeAmount(
                        BigDecimal.valueOf(testCase.fixedFee));
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                resp.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());

            BigDecimal actualGoodwillRC = BigDecimal.ZERO;
            if (response.getNextCycle().getReverseCredits() != null) {
                for (VisibleReverseCredit rc : response.getNextCycle().getReverseCredits()) {
                    if (rc.getPromotionName().equalsIgnoreCase(vtGoodwill.getPromotionName())) {
                        actualGoodwillRC = rc.getAvailableCreditsConsumable();
                    }
                }
            }

            BigDecimal actualGoodwill = BigDecimal.ZERO;
            if (response.getNextCycle().getCredits() != null) {
                for (VisibleCredits promo : response.getNextCycle().getCredits()) {
                    if (promo.getPromotionName().equalsIgnoreCase(vtGoodwill.getPromotionName())) {
                        actualGoodwill = promo.getAvailableCreditsGrant();
                    }
                }
            }

            assertEquals(testCase.otherPromos, actualGoodwillRC.doubleValue(), 0.001);
            assertEquals(testCase.otherPromos, actualGoodwill.doubleValue(), 0.001);

            System.out.println(
                    "**************************End of " + testCase.testNum
                            + "********************************");
        };

        TestConditions tc = new TestConditions();
        SimpleEntry<String, String> change3 = new SimpleEntry<>(
                CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT);
        SimpleEntry<String, String> change4 = new SimpleEntry<>(
                CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT);

        List<SimpleEntry<String, String>> changes = List.of(change3, change4);

        for (SimpleEntry<String, String> change : changes) {
            tc.oldCi = change.getKey();
            tc.newCi = change.getValue();

            tc.vbppEligible = false;
            tc.chimeEligible = false;
            tc.otherPromos = 5;
            tc.aocDelta = 0.33;
            tc.fixedFee = 1.81;
            tc.minimumCharge = 5;
            String testString = "-AocDelta-" + 0.33 + "-OtherPromos-" + 5 + "-partyPayRecEvent-"
                    + tc.partyPayRecEvent + "-partyAoc-" + tc.partyPayAoc + "-tc.vbppEligible-"
                    + tc.vbppEligible + "-tc.vbppRecEvent-" + tc.vbppRecEvent + "-tc.chimeEligible-"
                    + tc.chimeEligible + "-tc.chimeRecEvent-" + tc.chimeRecEvent;
            tc.testNum = "#1" + testString;
            pTests.test(tc);
        }
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getChangeServiceAdvice_ChangeAndNextCycle_With_Aoc_BasePriceImpactPromos_Not_In_Event_Then_UseAoc(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with base offer. PaidCycleStartDate is in future.There are base price impacting credits NOT present in recurring event."
        };
        td.when = new String[] {
            "Api is called for NibToCoreUpgrade"
        };
        td.then = new String[] {
            "Calculate base price with Aoc of promos."
        };

        @SuppressWarnings("rawtypes")
        ThreeParameterTest pTests = (req, tCase, er) -> {
            String subscriptionExternalId = "123";
            TestConditions testCase = (TestConditions) tCase;

            ExpectedResponse eResp = (ExpectedResponse) er;

            td.printDescription();
            System.out.println(
                    "**************************Executing " + testCase.testNum
                            + "********************************");

            String randomFutureDate = "4712-12-31";

            BigDecimal goodwillCredits = BigDecimal.valueOf(testCase.otherPromos);
            BigDecimal ca5Actuals = (BigDecimal) testCase.promoMap.get("CA5");
            BigDecimal newCa5 = BigDecimal.valueOf(5);

            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;

            String oldCiId = testCase.oldCi;

            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            String goodwillTax = CommonTestHelper.getPromoTaxResp(
                    CI_EXTERNAL_IDS.GRANT_GOODWILL, oldCiId, goodwillCredits);
            String ca5Tax = CommonTestHelper.getPromoTaxResp(
                    CI_EXTERNAL_IDS.CA5_GRANT, oldCiId, TAX_CLASS_CODES.CA5, ca5Actuals);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            List.of(testCase.oldCi, CI_EXTERNAL_IDS.CA5_GRANT)));
            MtxPurchasedOfferInfo poiEnrolled = subscriptionResponse.getAtPurchasedOfferArray(0);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().add(goodwillTax);
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().add(ca5Tax);
            enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomFutureDate));

            MtxBalanceInfo biGoodwillGrant = CommonTestHelper.getMtxBalanceInfo(
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Grant.json", 4, 43);
            biGoodwillGrant.setAmount(BigDecimal.ZERO);
            biGoodwillGrant.setAvailableAmount(BigDecimal.ZERO);
            subscriptionResponse.getBalanceArrayAppender().add(biGoodwillGrant);

            MtxBalanceInfo biGoodwillConsumable = CommonTestHelper.getMtxBalanceInfo(
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Consumable.json", 4, 44);
            biGoodwillConsumable.setAmount(goodwillCredits.negate());
            biGoodwillConsumable.setAvailableAmount(goodwillCredits);
            subscriptionResponse.getBalanceArrayAppender().add(biGoodwillConsumable);

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(subscriptionResponse));

            emulateMtxResponsePricingCatalogItem(instance, oldCiId);
            emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.CA5_GRANT);
            MtxResponsePricingCatalogItem pciNewCi = emulateMtxResponsePricingCatalogItem(
                    instance, request.getNewCatalogItemExternalId());

            BigDecimal mainbalance = BigDecimal.ZERO;

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));
            VisibleTemplate vtNewCi = (VisibleTemplate) pciNewCi.getCatalogItemInfo().getTemplateAttr();
            vtNewCi.setIgnoreTax_ForPayableAmount("false");

            String taxRespString = CommonTestHelper.getTaxApiResp(testCase.newCi);

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledPoiExtn);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCiId);

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    String redeemOffer = args[1].toString();
                    if (CI_EXTERNAL_IDS.CA5_REDEEM.equalsIgnoreCase(redeemOffer)) {
                        return newCa5.negate();
                    } else {
                        return BigDecimal.ZERO;
                    }
                }
            }).when(instance).getChargeableAmountForPurchaseOffer(any(), any(), any(), any());

            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            List<String> balPriList = Arrays.asList(
                    BALANCE_NAMES.GOODWILL_GRANT, BALANCE_NAMES.CA5_GRANT);
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");

            MtxPurchasedOfferInfo poiGoodwill = CommonTestHelper.loadJsonMessage(
                    MtxPurchasedOfferInfo.class, DATA_DIR.CHANGE_SERVICE
                            + "MtxPurchasedOfferInfo_Visible_Redeem_Goodwill_Credits.json");
            poiGoodwill.setResourceId(55L);

            emulateMtxResponseOneTimeOffer(instance, poiGoodwill);

            MtxResponsePricingCatalogItem goodwillGrant = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class, DATA_DIR.COMMON
                            + "MtxResponsePricingCatalogItem_Visible_Grant_Goodwill_Credits.json");
            VisibleTemplate vtGoodwill = ((VisibleTemplate) goodwillGrant.getCatalogItemInfo().getTemplateAttr());
            emulateMtxResponsePricingCatalogItem(
                    instance, goodwillGrant, CI_EXTERNAL_IDS.GRANT_GOODWILL);
            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            VisibleOfferDetails vodBase = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    oldCiId);
            BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
            vodBase.setConsumableMainBalanceAmount(mainbalanceUnlimited);

            ServiceStage ss = new ServiceStage(oldCiId);

            GlobalCreditStage gcsGoodwill = new GlobalCreditStage(
                    CI_EXTERNAL_IDS.GRANT_GOODWILL, vtGoodwill);
            gcsGoodwill.setPromotionName(vtGoodwill.getPromotionName());
            gcsGoodwill.setAvailableCredits(goodwillCredits);
            gcsGoodwill.setAvailableCreditsConsumable(goodwillCredits);
            gcsGoodwill.setAvailableCreditsGrant(BigDecimal.ZERO);
            gcsGoodwill.setRedeemOfferCi(vtGoodwill.getRedeemOffer());
            gcsGoodwill.setApplicableCiCsv(oldCiId);
            gcsGoodwill.getApplicableCiOrderMap().put(oldCiId, 2L);

            CreditStage csGoodwill = new CreditStage(gcsGoodwill, oldCiId);
            csGoodwill.setCreditTaxDetails(goodwillTax);
            csGoodwill.setApplicableServiceStage(ss);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodBase.getCatalogItemExternalId(), Long.valueOf(vodBase.getResourceId()),
                    vodBase);
            aopStage.getCreditMap().put(
                    new PromoOfferPair(oldCiId, vtGoodwill.getPromotionName()), csGoodwill);
            MtxResponseGroup respGrp = CommonTestHelper.getMtxResponseGroupCA(
                    subscriptionResponse.getExternalId(), "CAGroup",
                    List.of(subscriptionResponse.getObjectId().toString(), "1-2-3-4", "6-7-8-9"),
                    List.of(
                            String.format(
                                    GROUP_CONSTANTS.CA_LINK_FORMAT,
                                    subscriptionResponse.getExternalId(), "13579")));
            SubscriberGroup sg = new SubscriberGroup(respGrp);
            aopStage.appendSubscriberGroupList(sg);

            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ObjectMapper om = TestUtils.getObjectMapper();
                ServiceTaxResponse resp = om.readValue(taxRespString, ServiceTaxResponse.class);
                resp.getTransactionElement().get(0).setTotalFeeAmount(
                        BigDecimal.valueOf(testCase.fixedFee));
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                resp.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + " newPrice:" + request.getDiscountPrice());
            System.out.println(td.getTestMethod() + " newCa5:" + newCa5);
            System.out.println(td.getTestMethod() + " ca5Actuals:" + ca5Actuals);
            System.out.println(td.getTestMethod() + ":" + response.toJson());

            assertEquals(
                    ((BigDecimal) eResp.resultMap.get("delta")).doubleValue(),
                    response.getChangeCycle().getDelta().doubleValue(), 0.001,
                    eResp.resultMap.get("deltaDescription").toString());

            System.out.println(
                    "**************************End of " + testCase.testNum
                            + "********************************");
        };

        TestConditions tc;
        ExpectedResponse eResp;
        String testString;
        VisibleRequestChangeServiceAdvice request;
        String subscriptionExternalId = "123";

        request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PRO_CURRENT);
        request.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PRO_CURRENT));
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
        request.setSubscriptionExternalId(subscriptionExternalId);

        tc = new TestConditions() {

            {
                oldCi = CI_EXTERNAL_IDS.PLUS_CURRENT;
                newCi = CI_EXTERNAL_IDS.PRO_CURRENT;
                otherPromos = 5;
                aocDelta = 0.33;
                fixedFee = 1.81;
                minimumCharge = 5;
                promoMap.put("CA5", BigDecimal.valueOf(4));
            }
        };
        testString = "-AocDelta-" + 0.33 + "-OtherPromos-" + 5;
        tc.testNum = "#1" + testString;
        eResp = new ExpectedResponse() {

            {
                resultMap.put("delta", BigDecimal.valueOf(9));
                resultMap.put(
                        "deltaDescription",
                        "(Plus-CA5Limit)-(Base-CA5Actuals) =-(35-CA5Limit)-(25-CA5Actuals) = (35-5)-(25-4) = 9");
            }
        };
        pTests.test(request, tc, eResp);

        tc = new TestConditions() {

            {
                oldCi = CI_EXTERNAL_IDS.PLUS_CURRENT;
                newCi = CI_EXTERNAL_IDS.BASE_CURRENT;
                aocDelta = 0.33;
                fixedFee = 1.81;
                minimumCharge = 5;
                promoMap.put("CA5", BigDecimal.valueOf(4));
            }
        };
        testString = "-AocDelta-" + 0.33 + "-OtherPromos-" + 5;
        tc.testNum = "#1" + testString;
        eResp = new ExpectedResponse() {

            {
                resultMap.put("delta", BigDecimal.valueOf(0));
                resultMap.put("deltaDescription", "Zero Delta for NextCycle Change");
            }
        };
        // pTests.test(request, tc, eResp);
    }

    @Test
    @Disabled("CA5 uses promolimit and not AoC in advice. Other AoC promos are obsolete.")
    public void test_getChangeServiceAdvice_When_NextCycle_Then_Info_Field_Not_Passed_to_Aoc_Promo(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with base offer."
        };
        td.when = new String[] {
            "Api is called"
        };
        td.then = new String[] {
            "Info=PurchaseService should NOT be passed to Aoc promo when they are called for NextCycle."
        };
    }

    @Test
    @Disabled("CA5 uses promolimit and not AoC in advice. Other AoC promos are obsolete.")
    public void test_getChangeServiceAdvice_When_NextCycle_VBPP5_ApplicableBothOffers_Then_UseConsumablesAndGrantsToReportPromo(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with base offer (say BASE2VISIBLE22 or PLUS2VIS22WB).Payment is done for next cycle.",
            "https://jira.unico.com.au/browse/MTXVER2-142"
        };
        td.when = new String[] {
            "Api gets Zero as grant from Aoc. e.g. Vbpp5"
        };
        td.then = new String[] {
            "Promo block should be returned based on consumable grants."
        };
    }

    @Test
    @Disabled("We do not compare paid cycle start date with system time. Due to a fix for VER-797. Ignore this test.")
    public void test_getChangeServiceAdvice_ChangeAndNextCycle_NibToCoreUpgrade_Then_IgnoreTimezoneForNextCycle(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with LA timezone. Is enrolled in Visible_Unlimited. Proxy server's default timezone is NYC."
        };
        td.when = new String[] {
            "Api is called for NibToCoreUpgrade between 0 to 3hours after PaidCycleStartDate"
        };
        td.then = new String[] {
            "NextCycte should be present in output."
        };
    }

    @Test
    public void test_getChangeServiceAdvice_When_PromoTaxTemplatesAvailable_Then_Use_Correct_TaxTemplate(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with base offer. PaidCycleStartDate is in future. Promotions are available to subscriber.",
            " Subscription has promotions applicable to new offer."
        };
        td.when = new String[] {
            "Api is called with new base offer. Prmo has a tax template for new base offer."
        };
        td.then = new String[] {
            "Correct tax template will be used to calculate promo taxes."
        };

        @SuppressWarnings({
            "unchecked"
        })
        TwoParameterTest pTests = (oldCi, newCi) -> {
            td.printDescription();
            String subscriptionExternalId = "123";
            String randomFutureDate = "4712-12-31";
            ObjectMapper om = TestUtils.getObjectMapper();
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(newCi.toString());
            request.setDiscountPrice(CommonTestHelper.getOfferPrice(newCi.toString()));
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            BigDecimal mainbalance = BigDecimal.valueOf(40);
            String oldCiId = oldCi.toString();
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.setExternalId(subscriptionExternalId);
            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCiId);
            VisiblePurchasedOfferExtension enrolledExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            enrolledExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtn.setPaidCycleStartDate(new MtxDate(randomFutureDate));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscriptionExternalId));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCiId);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomFutureDate));

            if (CI_EXTERNAL_IDS.BASE_CURRENT.equalsIgnoreCase(newCi.toString())) {
                /********************************
                 * Add Some ref credits to increase gap for Next Cycle
                 **********************/
                BigDecimal refCredits = BigDecimal.valueOf(20);
                String refCreditTax = "{\"msgID\":\"EFGH-CR\",\"customerType\":\"99\",\"planID\":\"BASE001A\",\"grossPrice\":\"5.00\",\"discountPrice\":\""
                        + refCredits
                        + "\",\"promotionCredit\":\"true\",\"offer606RevAdjDailyRecog\":\"0\",\"promotionReason\":\"Referee_Credits\",\"geocode\":\"US0100108296\",\"taxTreatment\":\"inclusive\",\"classCode\":\"REF-CR\",\"glDate\":\"2019-03-07\",\"transactionElement\":[{\"btcTransactionCode\":\"01\",\"totalTaxAmount\":\"0.07389163\",\"totalFeeAmount\":\"0.00000000\",\"totalNetRevenue\":\"4.92610836\",\"modifiedDisplayNetRevenue\":\"4.93\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"618\",\"cP\":\"0.75\",\"glReference\":\"Visible_Unlimited_Data\",\"dpcItemTaxAmount\":\"0.00000000\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"3.69458128\",\"taxItemList\":[]},{\"dpcItem\":\"601\",\"cP\":\"0.12\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.03546798\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.59113300\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.02364532\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.01182266\"}]},{\"dpcItem\":\"662\",\"cP\":\"0.04\",\"glReference\":\"Visible_Unlimited_Text\",\"dpcItemTaxAmount\":\"0.01182266\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.19704433\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.00788177\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.00394089\"}]},{\"dpcItem\":\"629\",\"cP\":\"0.09\",\"glReference\":\"Visible_Unlimited_MMS\",\"dpcItemTaxAmount\":\"0.02660099\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.44334975\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.01773399\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.00886700\"}]}]}]},{\"btcTransactionCode\":\"93\",\"totalTaxAmount\":\"0.03002956\",\"totalFeeAmount\":\"0.00000000\",\"totalNetRevenue\":\"4.92610836\",\"modifiedDisplayNetRevenue\":\"4.93\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"601\",\"cP\":\"0.12\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.03002956\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.59113300\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000000016\",\"tat\":\"0\",\"taxCategory\":\"00\",\"taxType\":\"35\",\"description\":\"Fed Universal Service Charge\",\"rate\":\"0.050800000000\",\"taxAmount\":\"0.03002956\"}]}]}]}]}";
                enrolledExtn.getCreditTaxDetailsArrayAppender().add(refCreditTax);
                enrolledPoiExtn.getCreditTaxDetailsArrayAppender().add(refCreditTax);
            }

            BigDecimal goodwillCredits = BigDecimal.valueOf(35);

            List<String> balPriList = Arrays.asList(BALANCE_NAMES.GOODWILL_GRANT);
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));

            MtxResponsePricingCatalogItem goodwillGrant = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class, DATA_DIR.COMMON
                            + "MtxResponsePricingCatalogItem_Visible_Grant_Goodwill_Credits.json");
            VisibleTemplate vtGoodwill = ((VisibleTemplate) goodwillGrant.getCatalogItemInfo().getTemplateAttr());

            for (MtxPricingMetadataInfo pmi : goodwillGrant.getCatalogItemInfo().getMetadataList()) {
                if (pmi.getName().contains("TaxInput")) {
                    ServiceTaxRequest req = om.readValue(pmi.getValue(), ServiceTaxRequest.class);
                    req.setMsgID(pmi.getName());
                    pmi.setValue(req.toJson());
                }
            }

            emulateMtxResponsePricingCatalogItem(
                    instance, goodwillGrant, CI_EXTERNAL_IDS.GRANT_GOODWILL);

            /******************************** Add Goodwill for Next Cycle **********************/
            MtxBalanceInfo biGoodwillGrant = CommonTestHelper.getMtxBalanceInfo(
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Grant.json", 4, 43);
            biGoodwillGrant.setAmount(goodwillCredits.negate());
            biGoodwillGrant.setAvailableAmount(goodwillCredits);
            subscription.getBalanceArrayAppender().add(biGoodwillGrant);

            emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            oldCiId, request.getNewCatalogItemExternalId(),
                            CI_EXTERNAL_IDS.BASE_2535_GRANT, CI_EXTERNAL_IDS.PLUS_2535_GRANT));
            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtn);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCiId);

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                    newCi.toString());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    CI_EXTERNAL_IDS.UNLIMITED);

            BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
            vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

            VisibleCredits vc = new VisibleCredits();
            vc.setPromotionName(vtGoodwill.getPromotionName());
            vc.setApplicableCI(oldCiId);
            vc.setAvailableCredits(goodwillCredits);
            vc.setAvailableCreditsConsumable(BigDecimal.ZERO);
            vc.setAvailableCreditsGrant(goodwillCredits);
            vc.setCreditRedeemableOfferCI(vtGoodwill.getRedeemOffer());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodUnlimited.getCatalogItemExternalId(),
                    Long.valueOf(vodUnlimited.getResourceId()), vodUnlimited);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            String taxApiResp = CommonTestHelper.getTaxApiResp(newCi.toString());

            ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(
                                any(), argumentCaptor.capture())).thenReturn(taxApiResp);
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            ServiceTaxRequest req = null;
            for (String val : argumentCaptor.getAllValues()) {
                try {
                    ServiceTaxRequest taxReq = CommonTestHelper.getJsonFromString(
                            ServiceTaxRequest.class, val);
                    System.out.println(td.getTestMethod() + ":" + taxReq.toJson());
                    String taxReqString = val;
                    ServiceTaxRequest req1 = om.readValue(taxReqString, ServiceTaxRequest.class);
                    if (req1.getClassCode().trim().equalsIgnoreCase("GOOD-CR")) {
                        req = req1;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            ;

            assertEquals(request.getNewCatalogItemExternalId() + "TaxInput", req.getMsgID().trim());
        };

        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getChangeServiceAdvice_When_AnyFilter_MatchNewOffer_Then_Promo_In_NextCycle()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "VisibleTemplate.CreditIncludeAttributeValues has multiple valid entries.",
            "Promotion is non-zero.", "PaidCycleStartDate is in future."
        };
        td.when = new String[] {
            "Api is called.",
            "At least one of CreditIncludeAttributeValues DOES match with VisiblePurchasedOfferExtension.OfferChangeType of NEW base offer.",
            "Promotion is not blocked by any other rule."
        };
        td.then = new String[] {
            "Promotion is present in for next cycle."
        };
        td.comments = new String[] {
            "MTXVER2-171", "VER-142"
        };
        td.printDescription();

        String subscriptionExternalId = "123";
        String randomFutureDate = "4712-12-31";

        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setSubscriptionExternalId(subscriptionExternalId);
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        request.setDiscountPrice(OFFER_PRICES.PLUS_CURRENT);
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));

        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        String oldCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        BigDecimal oldPrice = OFFER_PRICES.BASE_CURRENT;
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poEnrolledBase22 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCiId);

        VisiblePurchasedOfferExtension enrolledExtn = (VisiblePurchasedOfferExtension) poEnrolledBase22.getAttr();
        enrolledExtn.setChargeAmount(oldPrice);
        enrolledExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledExtn.setPaidCycleStartDate(new MtxDate(randomFutureDate));

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCiId);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomFutureDate));

        BigDecimal first25Credits = BigDecimal.TEN;
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, first25Credits, null);

        List<String> balPriList = Arrays.asList(BALANCE_NAMES.FIRST25_GRANT);
        emulateMtxResponseMultiFromObject(
                instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(oldCiId, request.getNewCatalogItemExternalId()));

        BigDecimal mainbalance = BigDecimal.ZERO;
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

        VisibleOfferDetails vodBase22 = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                oldCiId);
        BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(20);
        vodBase22.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());
        vtF25.setApplicableOfferName(request.getNewCatalogItemExternalId());

        ServiceStage ss = new ServiceStage(oldCiId);

        GlobalCreditStage gcsF25 = new GlobalCreditStage(
                ciF25Grant.getCatalogItemInfo().getExternalId(), vtF25);
        gcsF25.setPromotionName(vtF25.getPromotionName());
        gcsF25.setAvailableCredits(first25Credits);
        gcsF25.setAvailableCreditsConsumable(BigDecimal.ZERO);
        gcsF25.setAvailableCreditsGrant(first25Credits);
        gcsF25.setRedeemOfferCi(vtF25.getRedeemOffer());
        gcsF25.setApplicableCiCsv(oldCiId + "," + request.getNewCatalogItemExternalId());
        gcsF25.getApplicableCiOrderMap().put(oldCiId, 2L);
        gcsF25.getApplicableCiOrderMap().put(request.getNewCatalogItemExternalId(), 3L);
        gcsF25.getCreditIncludeAttributeValues().add("XYZ=ABC");

        String offerChangeType = AppPropertyProvider.getInstance().getString(
                CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_PREFIX + oldCiId
                        + CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_OFFER_SEPARATOR_TO
                        + request.getNewCatalogItemExternalId());
        gcsF25.getCreditIncludeAttributeValues().add(
                VisiblePurchasedOfferExtension.class.getSimpleName() + GENERIC_CONSTANTS.DOT
                        + "OfferChangeType" + GENERIC_CONSTANTS.EQUALS + offerChangeType);

        CreditStage csFirst25 = new CreditStage(gcsF25, oldCiId);
        csFirst25.setApplicableServiceStage(ss);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodBase22.getCatalogItemExternalId(), Long.valueOf(vodBase22.getResourceId()),
                vodBase22);
        aopStage.getCreditMap().put(
                new PromoOfferPair(oldCiId, gcsF25.getGrantOfferCi()), csFirst25);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());
        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                MtxBalanceImpactInfo.class,
                DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
        biiMain.setImpactAmount(BigDecimal.ZERO);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                TestUtils.getFirstDateTimeOfCurrentMonth());
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                TestUtils.getLastDateTimeOfCurrentMonth());
        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(anyString(), anyString())).thenReturn("");
            instance.getChangeServiceAdvice(request, response);
        }

        assertEquals(
                vtF25.getRedeemOffer(),
                response.getNextCycle().getAtCredits(0).getCreditRedeemableOfferCI());
        assertEquals(
                first25Credits.intValue(), response.getNextCycle().getAtCredits(
                        0).getEstimatedTransferableCredits().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getChangeServiceAdvice_When_OnlyFilter_MatchNewOffer_Then_Promo_In_NextCycle()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "VisibleTemplate.CreditIncludeAttributeValues has only one entry, and the entry is valid.",
            "Promotion is non-zero."
        };
        td.when = new String[] {
            "Api is called.",
            "CreditIncludeAttributeValues DOES match with VisiblePurchasedOfferExtension.OfferChangeType of NEW base offer.",
            "Promotion is not blocked by any other rule."
        };
        td.then = new String[] {
            "Promotion is present in for next cycle."
        };
        td.comments = new String[] {
            "MTXVER2-171", "VER-142"
        };
        td.printDescription();

        String subscriptionExternalId = "123";
        String randomFutureDate = "4712-12-31";

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setSubscriptionExternalId(subscriptionExternalId);
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        request.setDiscountPrice(OFFER_PRICES.PLUS_CURRENT);
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));

        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        String oldCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        BigDecimal oldPrice = OFFER_PRICES.BASE_CURRENT;
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poEnrolledBase22 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCiId);

        VisiblePurchasedOfferExtension enrolledExtn = (VisiblePurchasedOfferExtension) poEnrolledBase22.getAttr();
        enrolledExtn.setChargeAmount(oldPrice);
        enrolledExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledExtn.setPaidCycleStartDate(new MtxDate(randomFutureDate));

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCiId);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomFutureDate));

        BigDecimal first25Credits = BigDecimal.TEN;
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, first25Credits, null);

        List<String> balPriList = Arrays.asList(BALANCE_NAMES.FIRST25_GRANT);
        emulateMtxResponseMultiFromObject(
                instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));

        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(oldCiId, request.getNewCatalogItemExternalId()));

        BigDecimal mainbalance = BigDecimal.ZERO;
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

        VisibleOfferDetails vodBase22 = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                oldCiId);
        BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(20);
        vodBase22.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());
        vtF25.setApplicableOfferName(request.getNewCatalogItemExternalId());

        ServiceStage ss = new ServiceStage(oldCiId);

        GlobalCreditStage gcsF25 = new GlobalCreditStage(
                ciF25Grant.getCatalogItemInfo().getExternalId(), vtF25);
        gcsF25.setPromotionName(vtF25.getPromotionName());
        gcsF25.setAvailableCredits(first25Credits);
        gcsF25.setAvailableCreditsConsumable(BigDecimal.ZERO);
        gcsF25.setAvailableCreditsGrant(first25Credits);
        gcsF25.setRedeemOfferCi(vtF25.getRedeemOffer());
        gcsF25.setApplicableCiCsv(oldCiId + "," + request.getNewCatalogItemExternalId());
        gcsF25.getApplicableCiOrderMap().put(oldCiId, 2L);
        gcsF25.getApplicableCiOrderMap().put(request.getNewCatalogItemExternalId(), 3L);

        String offerChangeType = AppPropertyProvider.getInstance().getString(
                CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_PREFIX + oldCiId
                        + CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_OFFER_SEPARATOR_TO
                        + request.getNewCatalogItemExternalId());
        gcsF25.getCreditIncludeAttributeValues().add(
                VisiblePurchasedOfferExtension.class.getSimpleName() + GENERIC_CONSTANTS.DOT
                        + "OfferChangeType" + GENERIC_CONSTANTS.EQUALS + offerChangeType);

        CreditStage csFirst25 = new CreditStage(gcsF25, oldCiId);
        csFirst25.setApplicableServiceStage(ss);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodBase22.getCatalogItemExternalId(), Long.valueOf(vodBase22.getResourceId()),
                vodBase22);
        aopStage.getCreditMap().put(
                new PromoOfferPair(oldCiId, gcsF25.getGrantOfferCi()), csFirst25);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());
        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                MtxBalanceImpactInfo.class,
                DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
        biiMain.setImpactAmount(BigDecimal.ZERO);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                TestUtils.getFirstDateTimeOfCurrentMonth());
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                TestUtils.getLastDateTimeOfCurrentMonth());
        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    "");
            instance.getChangeServiceAdvice(request, response);
        }

        assertEquals(
                vtF25.getRedeemOffer(),
                response.getNextCycle().getAtCredits(0).getCreditRedeemableOfferCI());
        assertEquals(
                first25Credits.intValue(), response.getNextCycle().getAtCredits(
                        0).getEstimatedTransferableCredits().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    @Tag("VER-207")
    public void getChangeServiceAdvice_When_BaseMonthly2PlusMonthly_PromoPurchased_TemplateApplicableBoth_Promo_IN_Request_Then_IgnoreNewGrant(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "PaidCycleStartDate is in future.", "Subscriber has BaseMonthly.",
            "Subscriber has 15OFFN in purchased offer."
        };
        td.when = new String[] {
            "ChangeAdvice is called for PlusMonthly offer. New request does have 15OFFN."
        };
        td.then = new String[] {
            "ChangeAdvice should ignore grant passed in request."
        };
        td.comments = new String[] {
            "MTXVER2-241, VER-207"
        };
        td.testInfo = testInfo;

        @SuppressWarnings({
            "rawtypes"
        })
        ThreeParameterTest pTests = (req, tc, er) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            ExpectedResponse eResp = (ExpectedResponse) er;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            Map<String, MtxResponsePricingCatalogItem> ciMap = emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT, tCase.oldCi,
                            request.getNewCatalogItemExternalId()));
            MtxResponsePricingCatalogItem pci15OffN = ciMap.get(CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT);
            VisibleTemplate vt15OffN = (VisibleTemplate) pci15OffN.getCatalogItemInfo().getTemplateAttr();
            vt15OffN.setApplicableOfferName(
                    tCase.oldCi + "," + request.getNewCatalogItemExternalId());

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            if (tCase.paidCycleStartDate != null) {
                poExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            }

            String promoTax = "{\"msgID\":\"15OFFN\",\"customerType\":\"99\",\"planID\":\"BASE001A\",\"grossPrice\":\"10.00\",\"discountPrice\":\""
                    + tCase.promoMap.get("XOFFNUSED")
                    + "\",\"promotionCredit\":\"true\",\"offer606RevAdjDailyRecog\":\"0\",\"promotionReason\":\"Group_Discounts\",\"geocode\":\"US0100108296\",\"taxTreatment\":\"inclusive\",\"classCode\":\"15OFFN\",\"glDate\":\"2019-03-07\",\"transactionElement\":[{\"btcTransactionCode\":\"01\",\"totalTaxAmount\":\"0.07389163\",\"totalFeeAmount\":\"0.00000000\",\"totalNetRevenue\":\"4.92610836\",\"modifiedDisplayNetRevenue\":\"4.93\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"618\",\"cP\":\"0.75\",\"glReference\":\"Visible_Unlimited_Data\",\"dpcItemTaxAmount\":\"0.00000000\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"3.69458128\",\"taxItemList\":[]},{\"dpcItem\":\"601\",\"cP\":\"0.12\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.03546798\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.59113300\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.02364532\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.01182266\"}]},{\"dpcItem\":\"662\",\"cP\":\"0.04\",\"glReference\":\"Visible_Unlimited_Text\",\"dpcItemTaxAmount\":\"0.01182266\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.19704433\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.00788177\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.00394089\"}]},{\"dpcItem\":\"629\",\"cP\":\"0.09\",\"glReference\":\"Visible_Unlimited_MMS\",\"dpcItemTaxAmount\":\"0.02660099\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.44334975\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.01773399\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.00886700\"}]}]}]},{\"btcTransactionCode\":\"93\",\"totalTaxAmount\":\"0.03002956\",\"totalFeeAmount\":\"0.00000000\",\"totalNetRevenue\":\"4.92610836\",\"modifiedDisplayNetRevenue\":\"4.93\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"601\",\"cP\":\"0.12\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.03002956\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.59113300\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000000016\",\"tat\":\"0\",\"taxCategory\":\"00\",\"taxType\":\"35\",\"description\":\"Fed Universal Service Charge\",\"rate\":\"0.050800000000\",\"taxAmount\":\"0.03002956\"}]}]}]}]}";
            poExtn.getCreditTaxDetailsArrayAppender().clear();
            poExtn.getCreditTaxDetailsArrayAppender().add(promoTax);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT, null,
                    new BigDecimal(tCase.promoMap.get("XOFFNGRANT").toString()), BigDecimal.ZERO,
                    false);
            List<String> grantBalances = new ArrayList();
            subscription.getBalanceArray().forEach(mbi -> {
                if ("Credits".equalsIgnoreCase(mbi.getClassName())) {
                    grantBalances.add(mbi.getName());
                }
            });
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(grantBalances));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().add(promoTax);
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            doReturn("[" + request.getNewCatalogItemExternalId() + "]").when(
                    instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                // if (CI_EXTERNAL_IDS.PLUS2VIS22.equalsIgnoreCase(tCase.oldCi)
                // && CI_EXTERNAL_IDS.BASE2VIS22.equalsIgnoreCase(tCase.newCi)) {
                // Since new Ci starts next cycle there will be no prorated charge. TaxApi gets
                // called only once.
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespNextCycle.toJson());

                // } else {
                // mockedStatic.when(
                // () -> TaxApiClient.getTaxApiResult(
                // any(), anyString())).thenReturn(
                // taxRespChangeCycle.toJson()).thenReturn(
                // taxRespNextCycle.toJson());
                // }
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            if (tCase.paidCycleStartDate != null
                    && tCase.paidCycleStartDate.getTimestamp().getNanos() > System.currentTimeMillis()
                            * 1000) {
                assertEquals(
                        ((BigDecimal) eResp.promoMap.get("XOFFNGRANT")).longValue(),
                        response.getNextCycle().getAtCredits(
                                0).getAvailableCreditsGrant().longValue(),
                        eResp.promoMap.get("XOFFNGRANTDESC").toString());
            }

            assertTrue(
                    response.getResultText().contains(
                            LOG_MESSAGES.FUTURE_GRANT_AMOUNT_IGNORED_1001));
        };

        // BaseMonthly2PlusMonthly
        TestConditions chg;
        ExpectedResponse eResp;
        VisibleRequestChangeServiceAdvice request;
        String subscriptionExternalId = "123";

        request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        request.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS_CURRENT));
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
        request.setSubscriptionExternalId(subscriptionExternalId);
        VisibleChangeServicePromo csp = new VisibleChangeServicePromo();
        csp.setGrantOfferCI(CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT);
        csp.setGrantAmount(BigDecimal.valueOf(9999));
        VisiblePromoExtension pe = new VisiblePromoExtension();
        pe.setPromotionLimit(BigDecimal.valueOf(14));
        csp.setAttr(pe);
        request.getNewPromotionListAppender().add(csp);

        chg = new TestConditions() {

            {
                newCi = request.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE_CURRENT;
                paidCycleStartDate = TestUtils.getFirstDateOfNextMonth();
            }
        };
        chg.promoMap.put("XOFFNGRANT", BigDecimal.valueOf(300));
        chg.promoMap.put("XOFFNUSED", BigDecimal.valueOf(15));
        eResp = new ExpectedResponse() {

            {
                resultMap.put("delta", BigDecimal.valueOf(9));
                resultMap.put("deltaDescription", "(45-14)-(30-8)=(31)-(22) = 9");
            }
        };
        eResp.promoMap.put("XOFFNGRANT", BigDecimal.valueOf(300));
        eResp.promoMap.put("XOFFNGRANTDESC", "New Grant should be ignored.");
        pTests.test(request, chg, eResp);

        // Same test case without next cycle
        chg.paidCycleStartDate = null;
        pTests.test(request, chg, eResp);
    }

    @SuppressWarnings("unchecked")
    @Test
    @Disabled("Nib / Visible_Unlimited plans are obsolete")
    public void getChangeServiceAdvice_When_Nib2CoreMonthly_Then_CorrectRedeemable(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "PaidCycleStartDate is in future.", "Subscriber has Visible_Unlimited.",
            "Eligible for 2535."
        };
        td.when = new String[] {
            "ChangeAdvice is called for PlusMonthly offer."
        };
        td.then = new String[] {
            "ChangeAdvice response should show next cycle.",
            "ChangeAdvice response should show 2535Redeemable = 2535Promolimit"
        };
        td.comments = new String[] {
            "MTXVER2-204, VER-209"
        };
        td.testInfo = testInfo;
    }

    @SuppressWarnings("unchecked")
    @Test
    @Disabled("Nib / Visible_Unlimited plans are obsolete")
    public void getChangeServiceAdvice_When_Nib2CoreMonthly_NoGrantBalance_Then_CorrectGrants(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "PaidCycleStartDate is in future.", "Subscriber has Visible_Unlimited.",
            "Subscriber has NO Grant offer or balance.", "Request supplied with new 2535 promo."
        };
        td.when = new String[] {
            "ChangeAdvice is called for PlusMonthly offer."
        };
        td.then = new String[] {
            "ChangeAdvice response should show next cycle.",
            "ChangeAdvice response should show 2535Redeemable = 2535Promolimit"
        };
        td.comments = new String[] {
            "MTXVER2-204, VER-209"
        };
        td.testInfo = testInfo;
    }

    @SuppressWarnings("unchecked")
    @Test
    @Disabled("Nib / Visible_Unlimited plans are obsolete")
    public void getChangeServiceAdvice_When_Nib2CoreMonthly_LimitInInput_Then_LimitOveride(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "PaidCycleStartDate is in future.", "Subscriber has Visible_Unlimited.",
            "Subscriber has NO Grant offer or balance.",
            "Input supplied with new promotion limit for 2535."
        };
        td.when = new String[] {
            "ChangeAdvice is called for PlusMonthly offer."
        };
        td.then = new String[] {
            "ChangeAdvice response should show next cycle.",
            "ChangeAdvice response should show CreditCap = NewPromotionLimit"
        };
        td.comments = new String[] {
            "MTXVER2-204, VER-209"
        };
        td.testInfo = testInfo;
    }

    @SuppressWarnings("unchecked")
    @Test
    @Disabled("Nib / Visible_Unlimited plans are obsolete."
            + " Grant passed on top of pre-existing grant is ignored. This is as per discussion with Kevin on 26-May-2023")
    public void getChangeServiceAdvice_When_Nib2CoreMonthly_With_GrantBalance_Then_CorrectGrants(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "PaidCycleStartDate is in future.", "Subscriber has Visible_Unlimited.",
            "Subscriber has 2535 offer and balance.", "Request supplied with new 2535 promo."
        };
        td.when = new String[] {
            "ChangeAdvice is called for PlusMonthly offer."
        };
        td.then = new String[] {
            "ChangeAdvice response should show next cycle.",
            "ChangeAdvice response should show 2535Redeemable = 2535Promolimit"
        };
        td.comments = new String[] {
            "MTXVER2-204, VER-209"
        };
        td.testInfo = testInfo;
    }

    @SuppressWarnings("unchecked")
    @Test
    public void getChangeServiceAdvice_When_CoreMonthly2CoreMonthly_With_NO_NewGrantBalance_Then_CorrectGrants()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "PaidCycleStartDate is in future.", "Subscriber has CoreMonthly.",
            "Subscriber has old 2535.", "Subscriber does not have new 2535.",
            "Request supplied with new 2535 promo."
        };
        td.when = new String[] {
            "ChangeAdvice is called for another CoreMonthly offer."
        };
        td.then = new String[] {
            "ChangeAdvice response should show next cycle.",
            "ChangeAdvice response should show new grant as per rsgateway property."
        };
        td.comments = new String[] {
            "MTXVER2-204, VER-209"
        };

        @SuppressWarnings({
            "rawtypes"
        })
        ThreeParameterTest pTests = (req, tc, er) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            ExpectedResponse eResp = (ExpectedResponse) er;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            // emulateMtxResponseMultiFromObject(instance,CommonTestHelper.getMtxResponsePricingBalances(new
            // ArrayList()));
            emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            tCase.oldCi, request.getNewCatalogItemExternalId(),
                            CI_EXTERNAL_IDS.PLUS_2535_GRANT, CI_EXTERNAL_IDS.BASE_2535_GRANT));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            MtxDate paidCycleStartDate = new MtxDate("4712-12-31");
            ((VisiblePurchasedOfferExtension) poEnrolled.getAttr()).setPaidCycleStartDate(
                    paidCycleStartDate);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(paidCycleStartDate);

            String oldGrantOffer = CI_EXTERNAL_IDS.BASE_CURRENT.equalsIgnoreCase(tCase.oldCi)
                    ? CI_EXTERNAL_IDS.BASE_2535_GRANT : CI_EXTERNAL_IDS.PLUS_2535_GRANT;
            CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldGrantOffer, BigDecimal.valueOf(5000), BigDecimal.valueOf(5000),
                    BigDecimal.ZERO);

            List<String> grantBalances = new ArrayList();
            subscription.getBalanceArray().forEach(mbi -> {
                if ("Credits".equalsIgnoreCase(mbi.getClassName())) {
                    grantBalances.add(mbi.getName());
                }
            });
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(grantBalances));

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            doReturn("[" + request.getSubscriptionExternalId() + "]").when(instance).getLoggingKey(
                    any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, paidCycleStartDate);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                // if (CI_EXTERNAL_IDS.PLUS2VIS22.equalsIgnoreCase(tCase.oldCi)
                // && CI_EXTERNAL_IDS.BASE2VIS22.equalsIgnoreCase(tCase.newCi)) {
                // Since new Ci starts next cycle there will be no prorated charge. TaxApi gets
                // called only once.
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespNextCycle.toJson());

                // } else {
                // mockedStatic.when(
                // () -> TaxApiClient.getTaxApiResult(
                // any(), anyString())).thenReturn(
                // taxRespChangeCycle.toJson()).thenReturn(
                // taxRespNextCycle.toJson());
                // }
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertEquals(
                    ((BigDecimal) eResp.resultMap.get("nc2535FutureGrant")).intValue(),
                    response.getNextCycle().getAtCredits(0).getFutureCreditGrant().intValue(),
                    eResp.resultMap.get("nc2535FutureGrantDescription").toString());
            assertEquals(
                    ((BigDecimal) eResp.resultMap.get("nc2535AvailableGrant")).intValue(),
                    response.getNextCycle().getAtCredits(0).getAvailableCreditsGrant().intValue(),
                    eResp.resultMap.get("nc2535AvailableGrantDescription").toString());
        };

        String subscriptionExternalId = "123";
        VisibleRequestChangeServiceAdvice request;
        VisibleChangeServicePromo csp;

        // BaseMonthly2PlusMonthly
        request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PRO_CURRENT);
        request.setDiscountPrice(OFFER_PRICES.PRO_CURRENT);
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
        request.setSubscriptionExternalId(subscriptionExternalId);
        csp = new VisibleChangeServicePromo();
        csp.setGrantOfferCI(CI_EXTERNAL_IDS.PLUS_2535_GRANT);
        csp.setGrantAmount(BigDecimal.valueOf(5000));
        request.getNewPromotionListAppender().add(csp);

        TestConditions chg1 = new TestConditions() {

            {
                newCi = CI_EXTERNAL_IDS.PRO_CURRENT;
                oldCi = CI_EXTERNAL_IDS.BASE_CURRENT;
            }
        };
        ExpectedResponse eResp1 = new ExpectedResponse() {

            {
                resultMap.put("nc2535FutureGrant", BigDecimal.valueOf(5000));
                resultMap.put("nc2535FutureGrantDescription", "As per rsgateway property.");
                resultMap.put("nc2535AvailableGrant", BigDecimal.ZERO);
                resultMap.put(
                        "nc2535AvailableGrantDescription",
                        "Future Grant and Available Grant are mutually exclusive.");
            }
        };
        pTests.test(request, chg1, eResp1);

        // PlusMonthly2BaseMonthly
        request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.BASE_CURRENT);
        request.setDiscountPrice(OFFER_PRICES.BASE_CURRENT);
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
        request.setSubscriptionExternalId(subscriptionExternalId);
        csp = new VisibleChangeServicePromo();
        csp.setGrantOfferCI(CI_EXTERNAL_IDS.BASE_2535_GRANT);
        csp.setGrantAmount(BigDecimal.valueOf(5000));
        request.getNewPromotionListAppender().add(csp);

        TestConditions chg2 = new TestConditions() {

            {
                newCi = CI_EXTERNAL_IDS.BASE_CURRENT;
                oldCi = CI_EXTERNAL_IDS.PRO_CURRENT;
            }
        };
        ExpectedResponse eResp2 = new ExpectedResponse() {

            {
                resultMap.put("nc2535FutureGrant", BigDecimal.valueOf(5000));
                resultMap.put("nc2535FutureGrantDescription", "As per rsgateway property.");
                resultMap.put("nc2535AvailableGrant", BigDecimal.ZERO);
                resultMap.put(
                        "nc2535AvailableGrantDescription",
                        "Future Grant and Available Grant are mutually exclusive.");
            }
        };
        pTests.test(request, chg2, eResp2);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void getChangeServiceAdvice_When_CoreMonthly2CoreMonthly_With_NO_NewGrantBalance_Then_CorrectReeemable()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "PaidCycleStartDate is in future.", "Subscriber has CoreMonthly.",
            "Subscriber has old 2535.", "Subscriber does not have new 2535.",
            "Request supplied with new 2535 promo."
        };
        td.when = new String[] {
            "ChangeAdvice is called for another CoreMonthly offer."
        };
        td.then = new String[] {
            "ChangeAdvice response should show next cycle.",
            "ChangeAdvice response should show 2535Redeemable = 2535Promolimit"
        };
        td.comments = new String[] {
            "MTXVER2-204, VER-209"
        };
        @SuppressWarnings({
            "rawtypes"
        })
        ThreeParameterTest pTests = (req, tc, er) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            ExpectedResponse eResp = (ExpectedResponse) er;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            tCase.oldCi, request.getNewCatalogItemExternalId(),
                            CI_EXTERNAL_IDS.PLUS_2535_GRANT, CI_EXTERNAL_IDS.BASE_2535_GRANT));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            MtxDate paidCycleStartDate = new MtxDate("4712-12-31");
            ((VisiblePurchasedOfferExtension) poEnrolled.getAttr()).setPaidCycleStartDate(
                    paidCycleStartDate);

            String oldGrantOffer = CI_EXTERNAL_IDS.BASE_CURRENT.equalsIgnoreCase(tCase.oldCi)
                    ? CI_EXTERNAL_IDS.BASE_2535_GRANT : CI_EXTERNAL_IDS.PLUS_2535_GRANT;
            CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldGrantOffer, BigDecimal.valueOf(5000), BigDecimal.valueOf(5000),
                    BigDecimal.ZERO);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(paidCycleStartDate);

            List<String> grantBalances = new ArrayList();
            subscription.getBalanceArray().forEach(mbi -> {
                if ("Credits".equalsIgnoreCase(mbi.getClassName())) {
                    grantBalances.add(mbi.getName());
                }
            });
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(grantBalances));

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            doReturn("[" + request.getSubscriptionExternalId() + "]").when(instance).getLoggingKey(
                    any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, paidCycleStartDate);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                // if (CI_EXTERNAL_IDS.PLUS2VIS22.equalsIgnoreCase(tCase.oldCi)
                // && CI_EXTERNAL_IDS.BASE2VIS22.equalsIgnoreCase(tCase.newCi)) {
                // Since new Ci starts next cycle there will be no prorated charge. TaxApi gets
                // called only once.
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespNextCycle.toJson());

                // } else {
                // mockedStatic.when(
                // () -> TaxApiClient.getTaxApiResult(
                // any(), anyString())).thenReturn(
                // taxRespChangeCycle.toJson()).thenReturn(
                // taxRespNextCycle.toJson());
                // }
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertEquals(
                    ((BigDecimal) eResp.resultMap.get("nc2535Redeemable")).intValue(),
                    response.getNextCycle().getAtCredits(0).getRedeemableCredits().intValue(),
                    eResp.resultMap.get("nc2535RedeemableDescription").toString());
            assertEquals(
                    ((BigDecimal) eResp.resultMap.get("nc2535Transferable")).intValue(),
                    response.getNextCycle().getAtCredits(0).getRedeemableCredits().intValue(),
                    eResp.resultMap.get("nc2535TransferableDescription").toString());
        };

        VisibleChangeServicePromo csp;
        VisibleRequestChangeServiceAdvice request;
        String subscriptionExternalId = "123";

        request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.BASE_CURRENT);
        request.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.BASE_CURRENT));
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
        request.setSubscriptionExternalId(subscriptionExternalId);
        csp = new VisibleChangeServicePromo();
        csp.setGrantOfferCI(CI_EXTERNAL_IDS.BASE_2535_GRANT);
        csp.setGrantAmount(BigDecimal.valueOf(5000));
        request.getNewPromotionListAppender().add(csp);
        // PlusMonthly2BaseMonthly
        TestConditions chg1 = new TestConditions() {

            {
                newCi = CI_EXTERNAL_IDS.BASE_CURRENT;
                oldCi = CI_EXTERNAL_IDS.PRO_CURRENT;
            }
        };
        ExpectedResponse eResp1 = new ExpectedResponse() {

            {
                resultMap.put("nc2535Redeemable", BigDecimal.valueOf(5));
                resultMap.put("nc2535RedeemableDescription", "5 is promo limit.");
                resultMap.put("nc2535Transferable", BigDecimal.valueOf(5));
                resultMap.put(
                        "nc2535TransferableDescription",
                        "Future credit tranferable equals redeemable.");
            }
        };
        pTests.test(request, chg1, eResp1);

        request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PRO_CURRENT);
        request.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PRO_CURRENT));
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
        request.setSubscriptionExternalId(subscriptionExternalId);
        csp = new VisibleChangeServicePromo();
        csp.setGrantOfferCI(CI_EXTERNAL_IDS.PLUS_2535_GRANT);
        csp.setGrantAmount(BigDecimal.valueOf(5000));
        request.getNewPromotionListAppender().add(csp);
        // BaseMonthly2PlusMonthly
        TestConditions chg2 = new TestConditions() {

            {
                newCi = CI_EXTERNAL_IDS.PRO_CURRENT;
                oldCi = CI_EXTERNAL_IDS.BASE_CURRENT;
            }
        };
        ExpectedResponse eResp2 = new ExpectedResponse() {

            {
                resultMap.put("nc2535Redeemable", BigDecimal.valueOf(10));
                resultMap.put("nc2535RedeemableDescription", "10 is promo limit.");
                resultMap.put("nc2535Transferable", BigDecimal.valueOf(10));
                resultMap.put(
                        "nc2535TransferableDescription",
                        "Future credit tranferable equals redeemable.");
            }
        };
        pTests.test(request, chg2, eResp2);
    }

    @SuppressWarnings("unchecked")
    @Test
    @Disabled("Grant passed on top of pre-existing grant is ignored. This is as per discussion with Kevin on 26-May-2023")
    public void getChangeServiceAdvice_When_CoreMonthly2CoreMonthly_With_NewGrantBalance_Then_CorrectGrants()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "PaidCycleStartDate is in future.", "Subscriber has CoreMonthly.",
            "Subscriber has old 2535.", "Subscriber has new 2535.",
            "Request supplied with new 2535 promo."
        };
        td.when = new String[] {
            "ChangeAdvice is called for another CoreMonthly offer."
        };
        td.then = new String[] {
            "ChangeAdvice response should show next cycle.",
            "ChangeAdvice response should show new grant as per rsgateway property."
        };
        td.comments = new String[] {
            "MTXVER2-204, VER-209"
        };
        @SuppressWarnings({
            "rawtypes"
        })
        ThreeParameterTest pTests = (req, tc, er) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            ExpectedResponse eResp = (ExpectedResponse) er;

            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(new ArrayList()));
            emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            tCase.oldCi, request.getNewCatalogItemExternalId(),
                            CI_EXTERNAL_IDS.PLUS_2535_GRANT, CI_EXTERNAL_IDS.BASE_2535_GRANT));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            MtxDate paidCycleStartDate = new MtxDate("4712-12-31");
            ((VisiblePurchasedOfferExtension) poEnrolled.getAttr()).setPaidCycleStartDate(
                    paidCycleStartDate);

            String oldGrantOffer = CI_EXTERNAL_IDS.BASE_CURRENT.equalsIgnoreCase(tCase.oldCi)
                    ? CI_EXTERNAL_IDS.BASE_2535_GRANT : CI_EXTERNAL_IDS.PLUS_2535_GRANT;
            CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldGrantOffer, BigDecimal.valueOf(5000), BigDecimal.valueOf(5000),
                    BigDecimal.ZERO);

            String newGrantOffer = CI_EXTERNAL_IDS.BASE_CURRENT.equalsIgnoreCase(tCase.newCi)
                    ? CI_EXTERNAL_IDS.BASE_2535_GRANT : CI_EXTERNAL_IDS.PLUS_2535_GRANT;
            CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, newGrantOffer, BigDecimal.valueOf(5000), BigDecimal.valueOf(5000),
                    BigDecimal.ZERO);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            doReturn("[" + request.getSubscriptionExternalId() + "]").when(instance).getLoggingKey(
                    any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, paidCycleStartDate);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscription, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                // if (CI_EXTERNAL_IDS.PLUS2VIS22.equalsIgnoreCase(tCase.oldCi)
                // && CI_EXTERNAL_IDS.BASE2VIS22.equalsIgnoreCase(tCase.newCi)) {
                // Since new Ci starts next cycle there will be no prorated charge. TaxApi gets
                // called only once.
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespNextCycle.toJson());

                // } else {
                // mockedStatic.when(
                // () -> TaxApiClient.getTaxApiResult(
                // any(), anyString())).thenReturn(
                // taxRespChangeCycle.toJson()).thenReturn(
                // taxRespNextCycle.toJson());
                // }
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            BigDecimal futureGrant = response.getNextCycle().getAtCredits(
                    0).getFutureCreditGrant() != null
                            ? response.getNextCycle().getAtCredits(0).getFutureCreditGrant()
                            : BigDecimal.ZERO;
            assertEquals(
                    ((BigDecimal) eResp.resultMap.get("nc2535FutureGrant")).intValue(),
                    futureGrant.intValue(),
                    eResp.resultMap.get("nc2535FutureGrantDescription").toString());
            assertEquals(
                    ((BigDecimal) eResp.resultMap.get("nc2535AvailableGrant")).intValue(),
                    response.getNextCycle().getAtCredits(0).getAvailableCreditsGrant().intValue(),
                    eResp.resultMap.get("nc2535AvailableGrantDescription").toString());
        };

        VisibleChangeServicePromo csp;
        VisibleRequestChangeServiceAdvice request;
        String subscriptionExternalId = "123";

        // PlusMonthly2BaseMonthly
        request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.BASE_CURRENT);
        request.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.BASE_CURRENT));
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
        request.setSubscriptionExternalId(subscriptionExternalId);
        csp = new VisibleChangeServicePromo();
        csp.setGrantOfferCI(CI_EXTERNAL_IDS.BASE_2535_GRANT);
        csp.setGrantAmount(BigDecimal.valueOf(5000));
        request.getNewPromotionListAppender().add(csp);

        TestConditions chg1 = new TestConditions() {

            {
                newCi = CI_EXTERNAL_IDS.BASE_CURRENT;
                oldCi = CI_EXTERNAL_IDS.PLUS_CURRENT;
            }
        };
        ExpectedResponse eResp1 = new ExpectedResponse() {

            {
                resultMap.put("nc2535FutureGrant", BigDecimal.valueOf(5000));
                resultMap.put(
                        "nc2535FutureGrantDescription",
                        "Future Grant and Available Grant can coexist.");
                resultMap.put("nc2535AvailableGrant", BigDecimal.valueOf(5000));
                resultMap.put("nc2535AvailableGrantDescription", "As per rsgateway property.");
            }
        };
        pTests.test(request, chg1, eResp1);

        // BaseMonthly2PlusMonthly
        request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        request.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS_CURRENT));
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
        request.setSubscriptionExternalId(subscriptionExternalId);
        csp = new VisibleChangeServicePromo();
        csp.setGrantOfferCI(CI_EXTERNAL_IDS.PLUS_2535_GRANT);
        csp.setGrantAmount(BigDecimal.valueOf(5000));
        request.getNewPromotionListAppender().add(csp);

        TestConditions chg2 = new TestConditions() {

            {
                newCi = CI_EXTERNAL_IDS.PLUS_CURRENT;
                oldCi = CI_EXTERNAL_IDS.BASE_CURRENT;
            }
        };
        ExpectedResponse eResp2 = new ExpectedResponse() {

            {
                resultMap.put("nc2535FutureGrant", BigDecimal.valueOf(5000));
                resultMap.put(
                        "nc2535FutureGrantDescription",
                        "Future Grant and Available Grant can coexist.");
                resultMap.put("nc2535AvailableGrant", BigDecimal.valueOf(5000));
                resultMap.put("nc2535AvailableGrantDescription", "As per rsgateway property.");
            }
        };
        pTests.test(request, chg2, eResp2);
    }

    @Test
    public void getChangeServiceAdvice_When_CoreMonthly2CoreMonthly_With_NewGrantBalance_Then_CorrectReeemable()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "PaidCycleStartDate is in future.", "Subscriber has CoreMonthly.",
            "Subscriber has old 2535.", "Subscriber has new 2535."
        };
        td.when = new String[] {
            "ChangeAdvice is called for another CoreMonthly offer."
        };
        td.then = new String[] {
            "ChangeAdvice response should show next cycle.",
            "ChangeAdvice response should show 2535Redeemable = 2535Promolimit"
        };
        td.comments = new String[] {
            "MTXVER2-204, VER-209"
        };

        @SuppressWarnings({
            "unchecked", "rawtypes"
        })
        TwoParameterTest pTests = (tc, er) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            ExpectedResponse eResp = (ExpectedResponse) er;

            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(tCase.newCi);
            request.setDiscountPrice(CommonTestHelper.getOfferPrice(tCase.newCi));
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);

            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            tCase.oldCi, request.getNewCatalogItemExternalId(),
                            CI_EXTERNAL_IDS.PLUS_2535_GRANT, CI_EXTERNAL_IDS.BASE_2535_GRANT));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            MtxDate paidCycleStartDate = new MtxDate("4712-12-31");
            ((VisiblePurchasedOfferExtension) poEnrolled.getAttr()).setPaidCycleStartDate(
                    paidCycleStartDate);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(paidCycleStartDate);

            String oldGrantOffer = CI_EXTERNAL_IDS.BASE_CURRENT.equalsIgnoreCase(tCase.oldCi)
                    ? CI_EXTERNAL_IDS.BASE_2535_GRANT : CI_EXTERNAL_IDS.PLUS_2535_GRANT;
            CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldGrantOffer, BigDecimal.valueOf(5000), BigDecimal.valueOf(5000),
                    BigDecimal.ZERO);

            String newGrantOffer = CI_EXTERNAL_IDS.BASE_CURRENT.equalsIgnoreCase(tCase.newCi)
                    ? CI_EXTERNAL_IDS.BASE_2535_GRANT : CI_EXTERNAL_IDS.PLUS_2535_GRANT;
            CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, newGrantOffer, BigDecimal.valueOf(5000), BigDecimal.valueOf(5000),
                    BigDecimal.ZERO);

            List<String> grantBalances = new ArrayList();
            subscription.getBalanceArray().forEach(mbi -> {
                if ("Credits".equalsIgnoreCase(mbi.getClassName())) {
                    grantBalances.add(mbi.getName());
                }
            });
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(grantBalances));

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, paidCycleStartDate);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                // if (CI_EXTERNAL_IDS.PLUS2VIS22.equalsIgnoreCase(tCase.oldCi)
                // && CI_EXTERNAL_IDS.BASE2VIS22.equalsIgnoreCase(tCase.newCi)) {
                // Since new Ci starts next cycle there will be no prorated charge. TaxApi gets
                // called only once.
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespNextCycle.toJson());

                // } else {
                // mockedStatic.when(
                // () -> TaxApiClient.getTaxApiResult(
                // any(), anyString())).thenReturn(
                // taxRespChangeCycle.toJson()).thenReturn(
                // taxRespNextCycle.toJson());
                // }
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertEquals(
                    ((BigDecimal) eResp.resultMap.get("nc2535Redeemable")).intValue(),
                    response.getNextCycle().getAtCredits(0).getRedeemableCredits().intValue(),
                    eResp.resultMap.get("nc2535RedeemableDescription").toString());
            assertEquals(
                    ((BigDecimal) eResp.resultMap.get("nc2535Transferable")).intValue(),
                    response.getNextCycle().getAtCredits(0).getRedeemableCredits().intValue(),
                    eResp.resultMap.get("nc2535TransferableDescription").toString());
        };

        // PlusMonthly2BaseMonthly
        TestConditions chg1 = new TestConditions() {

            {
                newCi = CI_EXTERNAL_IDS.BASE_CURRENT;
                oldCi = CI_EXTERNAL_IDS.PRO_CURRENT;
            }
        };
        ExpectedResponse eResp1 = new ExpectedResponse() {

            {
                resultMap.put("nc2535Redeemable", BigDecimal.valueOf(5));
                resultMap.put("nc2535RedeemableDescription", "5 is promo limit.");
                resultMap.put("nc2535Transferable", BigDecimal.valueOf(5));
                resultMap.put(
                        "nc2535TransferableDescription",
                        "Future credit tranferable equals redeemable.");
            }
        };
        pTests.test(chg1, eResp1);

        // BaseMonthly2PlusMonthly
        TestConditions chg2 = new TestConditions() {

            {
                newCi = CI_EXTERNAL_IDS.PRO_CURRENT;
                oldCi = CI_EXTERNAL_IDS.BASE_CURRENT;
            }
        };
        ExpectedResponse eResp2 = new ExpectedResponse() {

            {
                resultMap.put("nc2535Redeemable", BigDecimal.valueOf(10));
                resultMap.put("nc2535RedeemableDescription", "10 is promo limit.");
                resultMap.put("nc2535Transferable", BigDecimal.valueOf(10));
                resultMap.put(
                        "nc2535TransferableDescription",
                        "Future credit tranferable equals redeemable.");
            }
        };
        pTests.test(chg2, eResp2);
    }

    @Test
    public void getChangeServiceAdvice_When_CoreMonthly2CoreMonthly_Then_CorrectReverseCredits()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "PaidCycleStartDate is in future.", "Subscriber has CoreeMonthly.",
            "Subscriber has 2535."
        };
        td.when = new String[] {
            "ChangeAdvice is called for PlusMonthly offer."
        };
        td.then = new String[] {
            "ChangeAdvice response should show next cycle.",
            "ChangeAdvice response should show correct 253base5 reverse credits."
        };
        td.comments = new String[] {
            "MTXVER2-204, VER-209"
        };
        @SuppressWarnings({
            "unchecked", "rawtypes"
        })
        OneParameterTest pTests = (tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;

            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(tCase.newCi);
            request.setDiscountPrice(CommonTestHelper.getOfferPrice(tCase.newCi));
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);

            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            Map<String, MtxResponsePricingCatalogItem> pciMap = emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            tCase.oldCi, request.getNewCatalogItemExternalId(),
                            CI_EXTERNAL_IDS.PLUS_2535_GRANT, CI_EXTERNAL_IDS.BASE_2535_GRANT));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            MtxDate paidCycleStartDate = new MtxDate("4712-12-31");
            ((VisiblePurchasedOfferExtension) poEnrolled.getAttr()).setPaidCycleStartDate(
                    paidCycleStartDate);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(paidCycleStartDate);

            String oldGrantOffer = CI_EXTERNAL_IDS.BASE_CURRENT.equalsIgnoreCase(tCase.oldCi)
                    ? CI_EXTERNAL_IDS.BASE_2535_GRANT : CI_EXTERNAL_IDS.PLUS_2535_GRANT;
            CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldGrantOffer, BigDecimal.valueOf(5000), BigDecimal.valueOf(5000),
                    BigDecimal.ZERO);

            List<String> grantBalances = new ArrayList();
            subscription.getBalanceArray().forEach(mbi -> {
                if ("Credits".equalsIgnoreCase(mbi.getClassName())) {
                    grantBalances.add(mbi.getName());
                }
            });
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(grantBalances));

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, paidCycleStartDate);

            ServiceStage ss = new ServiceStage(tCase.oldCi);
            VisibleTemplate vt2535 = (VisibleTemplate) pciMap.get(
                    oldGrantOffer).getCatalogItemInfo().getTemplateAttr();

            GlobalCreditStage gcs2535 = new GlobalCreditStage(oldGrantOffer, vt2535);
            gcs2535.setPromotionName(vt2535.getPromotionName());
            gcs2535.setAvailableCredits(BigDecimal.valueOf(5000));
            gcs2535.setAvailableCreditsConsumable(vt2535.getPromotionLimit());
            gcs2535.setAvailableCreditsGrant(BigDecimal.valueOf(5000));
            gcs2535.setRedeemOfferCi(vt2535.getRedeemOffer());
            gcs2535.setApplicableCiCsv(tCase.oldCi);
            gcs2535.getApplicableCiOrderMap().put(tCase.oldCi, 2L);

            CreditStage cs2535 = new CreditStage(gcs2535, tCase.oldCi);
            cs2535.setApplicableServiceStage(ss);
            cs2535.setRedeemableCredits(vt2535.getPromotionLimit());
            cs2535.setEstimatedTransferableCredits(BigDecimal.ZERO);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.getCreditMap().put(
                    new PromoOfferPair(tCase.oldCi, vt2535.getPromotionName()), cs2535);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                // if (CI_EXTERNAL_IDS.PLUS2VIS22.equalsIgnoreCase(tCase.oldCi)
                // && CI_EXTERNAL_IDS.BASE2VIS22.equalsIgnoreCase(tCase.newCi)) {
                // Since new Ci starts next cycle there will be no prorated charge. TaxApi gets
                // called only once.
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespNextCycle.toJson());

                // } else {
                // mockedStatic.when(
                // () -> TaxApiClient.getTaxApiResult(
                // any(), anyString())).thenReturn(
                // taxRespChangeCycle.toJson()).thenReturn(
                // taxRespNextCycle.toJson());
                // }
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertEquals(
                    1, response.getNextCycle().getReverseCredits().size(),
                    "When there is consumable balance, There should be a reversible credit. ");
            assertEquals(
                    vt2535.getPromotionName(),
                    response.getNextCycle().getAtReverseCredits(0).getPromotionName());
            assertEquals(
                    vt2535.getRedeemOffer(),
                    response.getNextCycle().getAtReverseCredits(0).getRedeemableOfferCI());
            assertEquals(
                    vt2535.getPromotionLimit(),
                    response.getNextCycle().getAtReverseCredits(0).getAvailableCreditsConsumable());
        };

        // PlusMonthly2BaseMonthly
        TestConditions chg1 = new TestConditions() {

            {
                newCi = CI_EXTERNAL_IDS.BASE_CURRENT;
                oldCi = CI_EXTERNAL_IDS.PLUS_CURRENT;
            }
        };
        pTests.test(chg1);

        // BaseMonthly2PlusMonthly
        TestConditions chg2 = new TestConditions() {

            {
                newCi = CI_EXTERNAL_IDS.PLUS_CURRENT;
                oldCi = CI_EXTERNAL_IDS.BASE_CURRENT;
            }
        };
        pTests.test(chg2);
    }

    @SuppressWarnings("unchecked")
    @Test()
    @Tag("VER-143")
    public void test_getChangeServiceAdvice_When_NotApplicable_Promo_In_Request_Then_PromoIgnoredInNextCycle(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscriber is enrolled in BaseMonthly.", "PaidCycleStartDate is in future."
        };
        td.when = new String[] {
            "ChangeServiceAdvice is called to upgrade to PlusMonthly.",
            "A promo that is not applicable to PlusMonthly is in request."
        };
        td.then = new String[] {
            "Promo should not be in response.", "Promo should be ignored for next cycle.",
            "There should be a warning message."
        };
        @SuppressWarnings({
            "rawtypes"
        })
        ThreeParameterTest pTests = (req, tc, er) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            ExpectedResponse eResp = (ExpectedResponse) er;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            Map<String, MtxResponsePricingCatalogItem> ciMap = emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT, tCase.oldCi,
                            request.getNewCatalogItemExternalId()));
            MtxResponsePricingCatalogItem pci15OffN = ciMap.get(CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT);
            VisibleTemplate vt15OffN = (VisibleTemplate) pci15OffN.getCatalogItemInfo().getTemplateAttr();
            vt15OffN.setApplicableOfferName(tCase.oldCi);

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            if (tCase.paidCycleStartDate != null) {
                poExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            }

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            String promoTax = "{\"msgID\":\"15OFFN\",\"customerType\":\"99\",\"planID\":\"BASE001A\",\"grossPrice\":\"10.00\",\"discountPrice\":\""
                    + tCase.promoMap.get("XOFFNUSED")
                    + "\",\"promotionCredit\":\"true\",\"offer606RevAdjDailyRecog\":\"0\",\"promotionReason\":\"Group_Discounts\",\"geocode\":\"US0100108296\",\"taxTreatment\":\"inclusive\",\"classCode\":\"15OFFN\",\"glDate\":\"2019-03-07\",\"transactionElement\":[{\"btcTransactionCode\":\"01\",\"totalTaxAmount\":\"0.07389163\",\"totalFeeAmount\":\"0.00000000\",\"totalNetRevenue\":\"4.92610836\",\"modifiedDisplayNetRevenue\":\"4.93\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"618\",\"cP\":\"0.75\",\"glReference\":\"Visible_Unlimited_Data\",\"dpcItemTaxAmount\":\"0.00000000\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"3.69458128\",\"taxItemList\":[]},{\"dpcItem\":\"601\",\"cP\":\"0.12\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.03546798\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.59113300\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.02364532\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.01182266\"}]},{\"dpcItem\":\"662\",\"cP\":\"0.04\",\"glReference\":\"Visible_Unlimited_Text\",\"dpcItemTaxAmount\":\"0.01182266\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.19704433\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.00788177\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.00394089\"}]},{\"dpcItem\":\"629\",\"cP\":\"0.09\",\"glReference\":\"Visible_Unlimited_MMS\",\"dpcItemTaxAmount\":\"0.02660099\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.44334975\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.01773399\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.00886700\"}]}]}]},{\"btcTransactionCode\":\"93\",\"totalTaxAmount\":\"0.03002956\",\"totalFeeAmount\":\"0.00000000\",\"totalNetRevenue\":\"4.92610836\",\"modifiedDisplayNetRevenue\":\"4.93\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"601\",\"cP\":\"0.12\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.03002956\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.59113300\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000000016\",\"tat\":\"0\",\"taxCategory\":\"00\",\"taxType\":\"35\",\"description\":\"Fed Universal Service Charge\",\"rate\":\"0.050800000000\",\"taxAmount\":\"0.03002956\"}]}]}]}]}";
            poExtn.getCreditTaxDetailsArrayAppender().add(promoTax);

            CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT, null,
                    BigDecimal.valueOf(5000), BigDecimal.ZERO, false);

            List<String> grantBalances = new ArrayList();
            subscription.getBalanceArray().forEach(mbi -> {
                if ("Credits".equalsIgnoreCase(mbi.getClassName())) {
                    grantBalances.add(mbi.getName());
                }
            });
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(grantBalances));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().add(promoTax);
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            doReturn("[" + request.getNewCatalogItemExternalId() + "]").when(
                    instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                // if (CI_EXTERNAL_IDS.PLUS2VIS22.equalsIgnoreCase(tCase.oldCi)
                // && CI_EXTERNAL_IDS.BASE2VIS22.equalsIgnoreCase(tCase.newCi)) {
                // // Since new Ci starts next cycle there will be no prorated charge. TaxApi gets
                // called only once.
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespNextCycle.toJson());

                // } else {
                // mockedStatic.when(
                // () -> TaxApiClient.getTaxApiResult(
                // any(), anyString())).thenReturn(
                // taxRespChangeCycle.toJson()).thenReturn(
                // taxRespNextCycle.toJson());
                // }
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertEquals(
                    ((BigDecimal) eResp.resultMap.get("delta")).intValue(),
                    response.getChangeCycle().getDelta().intValue(),
                    eResp.resultMap.get("deltaDescription").toString());
            assertTrue(response.getNextCycle().getCredits() == null);
        };

        ExpectedResponse eResp;
        String subscriptionExternalId = "123";

        VisibleChangeServicePromo csp = new VisibleChangeServicePromo();
        csp.setGrantOfferCI(CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT);
        csp.setGrantAmount(BigDecimal.valueOf(5000));
        VisiblePromoExtension pe = new VisiblePromoExtension();
        pe.setPromotionLimit(BigDecimal.valueOf(14));
        csp.setAttr(pe);

        // BaseMonthly2PlusMonthly
        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PRO_CURRENT);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PRO_CURRENT));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId(subscriptionExternalId);
        requestUp.getNewPromotionListAppender().add(csp);

        TestConditions chgUp = new TestConditions() {

            {
                newCi = requestUp.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE_CURRENT;
                paidCycleStartDate = TestUtils.getFirstDateOfNextMonth();
            }
        };
        chgUp.promoMap.put("XOFFNUSED", BigDecimal.valueOf(15));
        eResp = new ExpectedResponse() {

            {
                resultMap.put("delta", BigDecimal.valueOf(35));
                resultMap.put(
                        "deltaDescription",
                        "(Pro-0)-(Base-15OFFN)=(45-0)-(25-15OFFN)=(45)-(25-15) = 35");
            }
        };
        pTests.test(requestUp, chgUp, eResp);

        VisibleRequestChangeServiceAdvice requestDown = new VisibleRequestChangeServiceAdvice();
        requestDown.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.BASE_CURRENT);
        requestDown.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.BASE_CURRENT));
        requestDown.setGrossPrice(requestDown.getDiscountPrice().add(BigDecimal.TEN));
        requestDown.setSubscriptionExternalId(subscriptionExternalId);
        requestDown.getNewPromotionListAppender().add(csp);

        TestConditions chgDown = new TestConditions() {

            {
                newCi = requestDown.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.PRO_CURRENT;
                paidCycleStartDate = TestUtils.getFirstDateOfNextMonth();
            }
        };
        chgDown.promoMap.put("XOFFNUSED", BigDecimal.valueOf(15));
        eResp = new ExpectedResponse() {

            {
                resultMap.put("delta", BigDecimal.valueOf(0));
                resultMap.put("deltaDescription", "Zero for downgrade");
            }
        };
        pTests.test(requestDown, chgDown, eResp);
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getChangeServiceAdvice_When_ChangeAndNextCycle_Then_FullTaxesForNextCycle")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription with base offer. PaidCycleStartDate is in future.|"
                +"|     |Not eligible for VBPP or Chime.|"
                +"|When |Api is called for CoreToCoreDowngrade.|"
                +"|Then |Validate NextCycleFields.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_ChangeAndNextCycle_Core2CoreNextCycle_NoVBPP_NoChime_Then_CorrectNextCycleOutput(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        td.testInfo = testInfo;

        OneParameterTest pTests = (tCase) -> {
            String subscriptionExternalId = "1234";
            TestConditions testCase = (TestConditions) tCase;
            td.printDescription();
            System.out.println(
                    "**************************Executing " + testCase.testNum
                            + "********************************");
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setSubscriptionExternalId(subscriptionExternalId);
            request.setNewCatalogItemExternalId(testCase.newCi);
            request.setDiscountPrice(testCase.getNewCiPrice());
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(1000)));
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            String oldCiId = testCase.oldCi;
            BigDecimal oldPrice = testCase.getOldCiPrice();
            BigDecimal goodwillCredits = BigDecimal.valueOf(testCase.otherPromos);
            BigDecimal promoActualsInSub = BigDecimal.ZERO;
            BigDecimal coreCredits = BigDecimal.ZERO;

            AppPropertyProvider.getInstance().setProperty(
                    Constants.CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = CommonTestHelper.getOfferPrice(oldCiId).subtract(
                    goodwillCredits).add(
                            testCase.hasInsurance
                                    ? TestConstants.OFFER_PRICES.INSURANCE : BigDecimal.ZERO).add(
                                            testCase.hasWearable
                                                    ? TestConstants.OFFER_PRICES.WEARABLE
                                                    : BigDecimal.ZERO);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getSubscriptionResponse(subscriptionExternalId, mainbalance));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, testCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(testCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(
                    new MtxDate(
                            subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime().getTime().split(
                                    "T")[0]));
            if (poiEnrolled.getCycleInfo() != null) {
                // So that annual service will be in its last month.
                poiEnrolled.getCycleInfo().setCycleEndTime(
                        TestUtils.getFirstDateTimeOfNextMonth(subscriptionResponse.getTimeZone()));
            }

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCiId);
            if (poEnrolled.getCycleInfo() != null) {
                // So that annual service will be in its last month.
                poEnrolled.getCycleInfo().setCycleEndTime(
                        TestUtils.getFirstDateTimeOfNextMonth(subscription.getLastActivityTime()));
            }

            MtxResponsePricingCatalogItem pciGoodwill = emulateMtxResponsePricingCatalogItem(
                    instance, TestConstants.CI_EXTERNAL_IDS.GRANT_GOODWILL);
            VisibleTemplate vtGoodwill = (VisibleTemplate) pciGoodwill.getCatalogItemInfo().getTemplateAttr();
            vtGoodwill.setIgnoreTax_ForPayableAmount("false");

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(oldCiId, request.getNewCatalogItemExternalId()));
            String goodwillTax = CommonTestHelper.getPromoTaxResp(
                    CI_EXTERNAL_IDS.GRANT_GOODWILL, oldCiId, goodwillCredits);

            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            enrolledExtnSub.setChargeAmount(oldPrice);
            enrolledExtnSub.setPaidCycleStartDate(enrolledPoiExtn.getPaidCycleStartDate());
            enrolledExtnSub.getCreditTaxDetailsArrayAppender().clear();
            if (goodwillCredits.signum() > 0) {
                enrolledExtnSub.getCreditTaxDetailsArrayAppender().add(goodwillTax);
                promoActualsInSub = promoActualsInSub.add(goodwillCredits);
            }

            subscription.getPurchasedOfferArrayAppender().add(poEnrolled);

            MtxBalanceInfo biGoodwillGrant = CommonTestHelper.getMtxBalanceInfo(
                    TestConstants.DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Grant.json", 4,
                    43);
            biGoodwillGrant.setAmount(BigDecimal.ZERO);
            biGoodwillGrant.setAvailableAmount(BigDecimal.ZERO);
            subscription.getBalanceArrayAppender().add(biGoodwillGrant);

            MtxBalanceInfo biGoodwillConsumable = CommonTestHelper.getMtxBalanceInfo(
                    TestConstants.DATA_DIR.PAYMENT_ADVICE
                            + "MtxBalanceInfo_Goodwill_Consumable.json",
                    4, 44);
            biGoodwillConsumable.setAmount(goodwillCredits.negate());
            biGoodwillConsumable.setAvailableAmount(goodwillCredits);
            subscription.getBalanceArrayAppender().add(biGoodwillConsumable);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));
            subscription.getAtBalanceArray(0).setAvailableAmount(mainbalance);
            subscription.getAtBalanceArray(0).setAmount(mainbalance.negate());

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class, TestConstants.DATA_DIR.CHANGE_SERVICE_ADVICE
                            + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(oldPrice);
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().add(goodwillTax);
            enrolledExtnEvent.setPaidCycleStartDate(enrolledPoiExtn.getPaidCycleStartDate());

            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCiId);

            List<String> balPriList = Arrays.asList(TestConstants.BALANCE_NAMES.GOODWILL_GRANT);
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");
            MtxPurchasedOfferInfo poiGoodwill = CommonTestHelper.loadJsonMessage(
                    MtxPurchasedOfferInfo.class, TestConstants.DATA_DIR.CHANGE_SERVICE
                            + "MtxPurchasedOfferInfo_Visible_Redeem_Goodwill_Credits.json");
            poiGoodwill.setResourceId(55L);

            emulateMtxResponseOneTimeOffer(instance, poiGoodwill);

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetailsAfterPayment(
                    oldCiId, subscriptionResponse, CommonTestHelper.getOfferPrice(oldCiId));
            BigDecimal mainbalanceOldCi = BigDecimal.valueOf(35);
            vodOldCi.setConsumableMainBalanceAmount(mainbalanceOldCi);

            VisibleOfferDetails vodInsurance = CommonTestHelper.getVisibleOfferDetailsAfterPayment(
                    CI_EXTERNAL_IDS.INSURANCE, subscriptionResponse,
                    CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.INSURANCE));
            vodInsurance.setConsumableMainBalanceAmount(TestConstants.OFFER_PRICES.INSURANCE);
            vodInsurance.setResourceId("22");
            vodInsurance.setTaxDetails("Insurance Tax");

            VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsAfterPayment(
                    CI_EXTERNAL_IDS.WEARABLE, subscriptionResponse,
                    CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.WEARABLE));
            vodWearable.setConsumableMainBalanceAmount(TestConstants.OFFER_PRICES.WEARABLE);
            vodWearable.setResourceId("32");
            vodWearable.setTaxDetails("Wearable Tax");

            BigDecimal mainbalanceNewCi = BigDecimal.valueOf(35);
            vodOldCi.setConsumableMainBalanceAmount(mainbalanceNewCi);

            ServiceStage ss = new ServiceStage(oldCiId);

            GlobalCreditStage gcsGoodwill = new GlobalCreditStage(
                    TestConstants.CI_EXTERNAL_IDS.GRANT_GOODWILL, vtGoodwill);
            gcsGoodwill.setPromotionName(vtGoodwill.getPromotionName());
            gcsGoodwill.setAvailableCredits(goodwillCredits);
            gcsGoodwill.setAvailableCreditsConsumable(goodwillCredits);
            gcsGoodwill.setAvailableCreditsGrant(BigDecimal.ZERO);
            gcsGoodwill.setRedeemOfferCi(vtGoodwill.getRedeemOffer());
            gcsGoodwill.setApplicableCiCsv(oldCiId);
            gcsGoodwill.getApplicableCiOrderMap().put(oldCiId, 2L);

            CreditStage csGoodwill = new CreditStage(gcsGoodwill, oldCiId);
            csGoodwill.setCreditTaxDetails(goodwillTax);
            csGoodwill.setApplicableServiceStage(ss);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.setAvailableMainBalanceAmount(mainbalance);
            aopStage.setConsumableMainBalanceAmount(mainbalance);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            if (testCase.hasInsurance) {
                aopStage.appendVisibleOfferDetailsMap(
                        vodInsurance.getCatalogItemExternalId(),
                        Long.valueOf(vodInsurance.getResourceId()), vodInsurance);
            }
            if (testCase.hasWearable) {
                aopStage.appendVisibleOfferDetailsMap(
                        vodWearable.getCatalogItemExternalId(),
                        Long.valueOf(vodWearable.getResourceId()), vodWearable);
            }
            if (goodwillCredits.signum() > 0) {
                aopStage.getCreditMap().put(
                        new PromoOfferPair(oldCiId, vtGoodwill.getPromotionName()), csGoodwill);
            }

            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            Map<String, BigDecimal> balImpactMap = Map.of(
                    BALANCE_NAMES.GLOBAL_PASS, BigDecimal.ONE);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ONE, null, balImpactMap,
                    true);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ObjectMapper om = TestUtils.getObjectMapper();
                ServiceTaxResponse resp = om.readValue(taxRespString, ServiceTaxResponse.class);
                resp.getTransactionElement().get(0).setTotalFeeAmount(
                        BigDecimal.valueOf(testCase.fixedFee));
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                resp.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());

            BigDecimal usableCredits = BigDecimal.ZERO;
            if (response.getNextCycle().getCredits() != null) {
                for (VisibleCredits vc : response.getNextCycle().getCredits()) {
                    usableCredits = usableCredits.add(vc.getRedeemableCredits());
                }
            }
            coreCredits = coreCredits.add(usableCredits);

            BigDecimal reverseCredits = BigDecimal.ZERO;
            if (response.getNextCycle().getReverseCredits() != null) {
                for (VisibleReverseCredit rc : response.getNextCycle().getReverseCredits()) {
                    reverseCredits = reverseCredits.add(rc.getAvailableCreditsConsumable());
                }
            }
            System.out.println(
                    "**************************Asserting " + testCase.testNum
                            + "********************************");

            BigDecimal expectedCredits = BigDecimal.ZERO;
            if (vtGoodwill.getApplicableOfferName().contains(testCase.newCi)) {
                expectedCredits = goodwillCredits;
            }
            assertEquals(
                    expectedCredits.min(
                            request.getDiscountPrice().subtract(
                                    BigDecimal.valueOf(testCase.minimumCharge))).doubleValue(),
                    usableCredits.doubleValue(), 0.001);
            assertEquals(promoActualsInSub.doubleValue(), reverseCredits.doubleValue(), 0.001);
            assertEquals(
                    request.getDiscountPrice().subtract(usableCredits).doubleValue(),
                    response.getNextCycle().getPayableAmount().doubleValue(), 0.001);
            assertEquals(
                    response.getNewCatalogItem().getDiscountPrice().subtract(
                            usableCredits).subtract(
                                    response.getCurrentCatalogItem().getDiscountPrice()).add(
                                            promoActualsInSub).max(BigDecimal.ZERO).intValue(),
                    response.getNextCycle().getGap().intValue());
            assertEquals(
                    mainbalance.subtract(TestConstants.OFFER_PRICES.WEARABLE).subtract(
                            TestConstants.OFFER_PRICES.INSURANCE).min(
                                    response.getNextCycle().getPayableAmount()).doubleValue(),
                    response.getNextCycle().getConsumableMainBalance().doubleValue(), 0.001);
            assertEquals(
                    BigDecimal.ZERO.add(
                            testCase.hasInsurance
                                    ? TestConstants.OFFER_PRICES.INSURANCE : BigDecimal.ZERO).add(
                                            testCase.hasWearable
                                                    ? TestConstants.OFFER_PRICES.WEARABLE
                                                    : BigDecimal.ZERO).doubleValue(),
                    response.getNextCycle().getReservedMainBalanceAmount().doubleValue(), 0.001);
            assertEquals(
                    request.getDiscountPrice().doubleValue(),
                    response.getNextCycle().getTotalAmount().doubleValue(), 0.001);
            assertEquals(
                    response.getChangeCycle().getConsumableMainBalance().add(
                            response.getNextCycle().getConsumableMainBalance()).doubleValue(),
                    response.getConsumableMainBalance().doubleValue(), 0.001);
            assertEquals(
                    response.getChangeCycle().getPayableAmount().add(
                            response.getNextCycle().getPayableAmount()).subtract(
                                    response.getConsumableMainBalance()).doubleValue(),
                    response.getRechargeAmount().doubleValue(), 0.001);
            assertEquals(
                    response.getChangeCycle().getTotalAmount().add(
                            response.getNextCycle().getTotalAmount()).doubleValue(),
                    response.getTotalAmount().doubleValue(), 0.001);
            System.out.println(
                    "**************************End of " + testCase.testNum
                            + "********************************");
        };

        TestConditions tc = new TestConditions() {

            {
                vbppEligible = false;
                chimeEligible = false;
                hasInsurance = true;
                hasWearable = true;
                otherPromos = 10;
                fixedFee = 1.81;
            }
        };

        SimpleEntry<String, String> change2 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.BASE3VIS23);
        SimpleEntry<String, String> change3 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.PLUS3VIS23);
        SimpleEntry<String, String> change4 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.BASE3VIS23);
        SimpleEntry<String, String> change5 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.PLUS3VIS23);
        List<SimpleEntry<String, String>> changes = List.of(change2, change3, change4, change5);

        int testnum = 1;
        for (SimpleEntry<String, String> change : changes) {
            tc.oldCi = change.getKey();
            tc.newCi = change.getValue();
            tc.testNum = "#" + testnum++ + "-AsIsCi-" + tc.oldCi + "-ToBeCi-" + tc.newCi;
            pTests.test(tc);
        }
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getChangeServiceAdvice_ChangeAndNextCycle_Core2CoreNextCycle_VbppElig_Then_CorrectNextCycleOutput")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription with base offer. PaidCycleStartDate is in future.|"
                +"|     |Vbpp Eligible.|"
                +"|When |Api is called for CoreToCoreDowngrade.|"
                +"|Then |Validate NextCycleFields.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_ChangeAndNextCycle_Core2CoreNextCycle_VbppElig_Then_CorrectNextCycleOutput(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        OneParameterTest pTests = (tCase) -> {
            String subscriptionExternalId = "123";
            TestConditions testCase = (TestConditions) tCase;
            td.printDescription();
            System.out.println(
                    "**************************Executing " + testCase.testNum
                            + "********************************");

            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setSubscriptionExternalId(subscriptionExternalId);
            request.setNewCatalogItemExternalId(testCase.newCi);
            request.setDiscountPrice(testCase.getNewCiPrice());
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(1000)));
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            String oldCiId = testCase.oldCi;
            BigDecimal oldPrice = testCase.getOldCiPrice();

            String oldVbppClassCode = "VBPP-CORE";

            BigDecimal coreVbpp = BigDecimal.valueOf(5);

            BigDecimal goodwillCredits = BigDecimal.valueOf(testCase.otherPromos);
            BigDecimal vbppActuals = BigDecimal.valueOf(testCase.vbppRecEvent);

            BigDecimal newVbpp = BigDecimal.ZERO;

            BigDecimal promoActualsInSub = BigDecimal.ZERO;
            BigDecimal coreCredits = BigDecimal.ZERO;

            AppPropertyProvider.getInstance().setProperty(
                    Constants.CREDIT_CONSTANTS.AOC_GRANT_OFFERS,
                    TestConstants.CI_EXTERNAL_IDS.VBPP5_AOC_GRANT);

            MtxResponsePricingCatalogItem pciVbpp = emulateMtxResponsePricingCatalogItem(
                    instance, TestConstants.CI_EXTERNAL_IDS.VBPP5_AOC_GRANT);
            VisibleTemplate vtVbpp = (VisibleTemplate) pciVbpp.getCatalogItemInfo().getTemplateAttr();
            vtVbpp.setIgnoreTax_ForPayableAmount("false");

            if (testCase.vbppEligible && vtVbpp.getApplicableOfferName().contains(testCase.newCi)) {
                newVbpp = coreVbpp;
            }

            BigDecimal mainbalance = testCase.getOldCiPrice().subtract(goodwillCredits).add(
                    testCase.hasInsurance
                            ? TestConstants.OFFER_PRICES.INSURANCE : BigDecimal.ZERO).add(
                                    testCase.hasWearable
                                            ? TestConstants.OFFER_PRICES.WEARABLE
                                            : BigDecimal.ZERO);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getSubscriptionResponse(subscriptionExternalId, mainbalance));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCiId);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(
                    new MtxDate(
                            subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime().getTime().split(
                                    "T")[0]));
            if (poiEnrolled.getCycleInfo() != null) {
                // So that annual service will be in its last month.
                poiEnrolled.getCycleInfo().setCycleEndTime(
                        TestUtils.getLastDateTimeOfCurrentMonth(
                                subscriptionResponse.getTimeZone()));
            }

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCiId);
            if (poEnrolled.getCycleInfo() != null) {
                // So that annual service will be in its last month.
                poEnrolled.getCycleInfo().setCycleEndTime(
                        TestUtils.getLastDateTimeOfCurrentMonth(
                                subscriptionResponse.getTimeZone()));
            }

            MtxResponsePricingCatalogItem pciGoodwill = emulateMtxResponsePricingCatalogItem(
                    instance, TestConstants.CI_EXTERNAL_IDS.GRANT_GOODWILL);
            VisibleTemplate vtGoodwill = (VisibleTemplate) pciGoodwill.getCatalogItemInfo().getTemplateAttr();
            vtGoodwill.setIgnoreTax_ForPayableAmount("false");

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(oldCiId, request.getNewCatalogItemExternalId()));
            String goodwillTax = CommonTestHelper.getPromoTaxResp(
                    CI_EXTERNAL_IDS.GRANT_GOODWILL, oldCiId, goodwillCredits);
            String vbppTax = CommonTestHelper.getPromoTaxResp(
                    CI_EXTERNAL_IDS.VBPP25_AOC_GRANT, oldCiId, oldVbppClassCode, vbppActuals);

            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            enrolledExtnSub.setChargeAmount(oldPrice);
            enrolledExtnSub.setPaidCycleStartDate(enrolledPoiExtn.getPaidCycleStartDate());
            enrolledExtnSub.getCreditTaxDetailsArrayAppender().clear();
            if (goodwillCredits.signum() > 0) {
                enrolledExtnSub.getCreditTaxDetailsArrayAppender().add(goodwillTax);
                promoActualsInSub = promoActualsInSub.add(goodwillCredits);
            }
            if (vbppActuals.signum() > 0) {
                enrolledExtnSub.getCreditTaxDetailsArrayAppender().add(vbppTax);
                promoActualsInSub = promoActualsInSub.add(vbppActuals);
            }

            subscription.getPurchasedOfferArrayAppender().add(poEnrolled);

            MtxBalanceInfo biGoodwillGrant = CommonTestHelper.getMtxBalanceInfo(
                    TestConstants.DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Grant.json", 4,
                    43);
            biGoodwillGrant.setAmount(BigDecimal.ZERO);
            biGoodwillGrant.setAvailableAmount(BigDecimal.ZERO);
            subscription.getBalanceArrayAppender().add(biGoodwillGrant);

            MtxBalanceInfo biGoodwillConsumable = CommonTestHelper.getMtxBalanceInfo(
                    TestConstants.DATA_DIR.PAYMENT_ADVICE
                            + "MtxBalanceInfo_Goodwill_Consumable.json",
                    4, 44);
            biGoodwillConsumable.setAmount(goodwillCredits.negate());
            biGoodwillConsumable.setAvailableAmount(goodwillCredits);
            subscription.getBalanceArrayAppender().add(biGoodwillConsumable);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class, TestConstants.DATA_DIR.CHANGE_SERVICE_ADVICE
                            + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(oldPrice);
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().add(goodwillTax);
            enrolledExtnEvent.setPaidCycleStartDate(enrolledPoiExtn.getPaidCycleStartDate());
            if (vbppActuals.signum() > 0) {
                enrolledExtnEvent.getCreditTaxDetailsArrayAppender().add(vbppTax);
            }

            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCiId);

            if (testCase.vbppEligible && vtVbpp.getApplicableOfferName().contains(testCase.newCi)) {
                doReturn(coreVbpp.negate()).when(instance).getChargeableAmountForPurchaseOffer(
                        any(),
                        argThat(
                                (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                        TestConstants.CI_EXTERNAL_IDS.VBPP_CORE_REDEEM)),
                        argThat(
                                (MtxPurchasedOfferData pod) -> vtVbpp.getApplicableOfferName().contains(
                                        ((VisiblePurchasedOfferExtension) pod.getAttr()).getCoreBasePlanCI())),
                        any());
            }

            List<String> balPriList = Arrays.asList(TestConstants.BALANCE_NAMES.GOODWILL_GRANT);
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");
            MtxPurchasedOfferInfo poiGoodwill = CommonTestHelper.loadJsonMessage(
                    MtxPurchasedOfferInfo.class, TestConstants.DATA_DIR.CHANGE_SERVICE
                            + "MtxPurchasedOfferInfo_Visible_Redeem_Goodwill_Credits.json");
            poiGoodwill.setResourceId(55L);

            emulateMtxResponseOneTimeOffer(instance, poiGoodwill);

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetailsAfterPayment(
                    oldCiId, subscriptionResponse, CommonTestHelper.getOfferPrice(oldCiId));
            BigDecimal mainbalanceOldCi = BigDecimal.valueOf(35);
            vodOldCi.setConsumableMainBalanceAmount(mainbalanceOldCi);

            VisibleOfferDetails vodInsurance = CommonTestHelper.getVisibleOfferDetailsAfterPayment(
                    CI_EXTERNAL_IDS.INSURANCE, subscriptionResponse,
                    CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.INSURANCE));
            vodInsurance.setConsumableMainBalanceAmount(TestConstants.OFFER_PRICES.INSURANCE);
            vodInsurance.setResourceId("22");
            vodInsurance.setTaxDetails("Insurance Tax");

            VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsAfterPayment(
                    CI_EXTERNAL_IDS.WEARABLE, subscriptionResponse,
                    CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.WEARABLE));
            vodWearable.setConsumableMainBalanceAmount(TestConstants.OFFER_PRICES.WEARABLE);
            vodWearable.setResourceId("32");
            vodWearable.setTaxDetails("Wearable Tax");

            BigDecimal mainbalanceNewCi = BigDecimal.valueOf(35);
            vodOldCi.setConsumableMainBalanceAmount(mainbalanceNewCi);

            ServiceStage ss = new ServiceStage(oldCiId);

            GlobalCreditStage gcsGoodwill = new GlobalCreditStage(
                    TestConstants.CI_EXTERNAL_IDS.GRANT_GOODWILL, vtGoodwill);
            gcsGoodwill.setPromotionName(vtGoodwill.getPromotionName());
            gcsGoodwill.setAvailableCredits(goodwillCredits);
            gcsGoodwill.setAvailableCreditsConsumable(goodwillCredits);
            gcsGoodwill.setAvailableCreditsGrant(BigDecimal.ZERO);
            gcsGoodwill.setRedeemOfferCi(vtGoodwill.getRedeemOffer());
            gcsGoodwill.setApplicableCiCsv(oldCiId);
            gcsGoodwill.getApplicableCiOrderMap().put(oldCiId, 2L);

            CreditStage csGoodwill = new CreditStage(gcsGoodwill, oldCiId);
            csGoodwill.setCreditTaxDetails(goodwillTax);
            csGoodwill.setApplicableServiceStage(ss);

            GlobalCreditStage gcsVbpp5 = new GlobalCreditStage(
                    TestConstants.CI_EXTERNAL_IDS.VBPP25_AOC_GRANT, vtVbpp);
            gcsVbpp5.setPromotionName(vtVbpp.getPromotionName());
            gcsVbpp5.setAvailableCredits(vbppActuals);
            gcsVbpp5.setAvailableCreditsConsumable(vbppActuals);
            gcsVbpp5.setAvailableCreditsGrant(BigDecimal.ZERO);
            gcsVbpp5.setRedeemOfferCi(vtVbpp.getRedeemOffer());
            gcsVbpp5.setApplicableCiCsv(oldCiId);
            gcsVbpp5.getApplicableCiOrderMap().put(oldCiId, 2L);

            CreditStage csVbpp5 = new CreditStage(gcsVbpp5, oldCiId);
            csVbpp5.setApplicableServiceStage(ss);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            if (testCase.hasInsurance) {
                aopStage.appendVisibleOfferDetailsMap(
                        vodInsurance.getCatalogItemExternalId(),
                        Long.valueOf(vodInsurance.getResourceId()), vodInsurance);
            }
            if (testCase.hasWearable) {
                aopStage.appendVisibleOfferDetailsMap(
                        vodWearable.getCatalogItemExternalId(),
                        Long.valueOf(vodWearable.getResourceId()), vodWearable);
            }
            if (goodwillCredits.signum() > 0) {
                aopStage.getCreditMap().put(
                        new PromoOfferPair(oldCiId, vtGoodwill.getPromotionName()), csGoodwill);
            }

            if (testCase.vbppEligible) {
                MtxResponseGroup respGrp = CommonTestHelper.getMtxResponseGroup(
                        "VBPP-" + subscriptionExternalId, "VBPP", 4L,
                        subscriptionResponse.getObjectId().toString(), "1-2-3-4", "6-7-8-9",
                        "4-3-2-1");
                SubscriberGroup sg = new SubscriberGroup(respGrp);
                aopStage.appendSubscriberGroupList(sg);
                aopStage.getCreditMap().put(
                        new PromoOfferPair(oldCiId, vtVbpp.getPromotionName()), csVbpp5);
            }

            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            Map<String, BigDecimal> balImpactMap = Map.of(
                    BALANCE_NAMES.GLOBAL_PASS, BigDecimal.ONE);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ZERO, null, balImpactMap,
                    true);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ObjectMapper om = TestUtils.getObjectMapper();
                ServiceTaxResponse resp = om.readValue(taxRespString, ServiceTaxResponse.class);
                resp.getTransactionElement().get(0).setTotalFeeAmount(
                        BigDecimal.valueOf(testCase.fixedFee));
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                resp.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());

            BigDecimal usableCredits = BigDecimal.ZERO;
            if (response.getNextCycle().getCredits() != null) {
                for (VisibleCredits vc : response.getNextCycle().getCredits()) {
                    usableCredits = usableCredits.add(vc.getRedeemableCredits());
                }
            }
            coreCredits = coreCredits.add(usableCredits);

            BigDecimal reverseCredits = BigDecimal.ZERO;
            if (response.getNextCycle().getReverseCredits() != null) {
                for (VisibleReverseCredit rc : response.getNextCycle().getReverseCredits()) {
                    reverseCredits = reverseCredits.add(rc.getAvailableCreditsConsumable());
                }
            }
            System.out.println(
                    "**************************Asserting " + testCase.testNum
                            + "********************************");
            BigDecimal expectedCredits = BigDecimal.ZERO;
            if (vtGoodwill.getApplicableOfferName().contains(testCase.newCi)) {
                expectedCredits = goodwillCredits;
            }
            assertEquals(
                    expectedCredits.add(newVbpp).min(
                            request.getDiscountPrice().subtract(
                                    BigDecimal.valueOf(testCase.minimumCharge))).doubleValue(),
                    usableCredits.doubleValue(), 0.001);
            assertEquals(promoActualsInSub.doubleValue(), reverseCredits.doubleValue(), 0.001);
            assertEquals(
                    request.getDiscountPrice().subtract(usableCredits).doubleValue(),
                    response.getNextCycle().getPayableAmount().doubleValue(), 0.001);
            assertEquals(
                    response.getNewCatalogItem().getDiscountPrice().subtract(
                            usableCredits).subtract(
                                    response.getCurrentCatalogItem().getDiscountPrice()).add(
                                            promoActualsInSub).max(BigDecimal.ZERO).intValue(),
                    response.getNextCycle().getGap().intValue());
            assertEquals(
                    mainbalance.subtract(TestConstants.OFFER_PRICES.WEARABLE).subtract(
                            TestConstants.OFFER_PRICES.INSURANCE).min(
                                    response.getNextCycle().getPayableAmount()).doubleValue(),
                    response.getNextCycle().getConsumableMainBalance().doubleValue(), 0.001);
            assertEquals(
                    BigDecimal.ZERO.add(
                            testCase.hasInsurance
                                    ? TestConstants.OFFER_PRICES.INSURANCE : BigDecimal.ZERO).add(
                                            testCase.hasWearable
                                                    ? TestConstants.OFFER_PRICES.WEARABLE
                                                    : BigDecimal.ZERO).doubleValue(),
                    response.getNextCycle().getReservedMainBalanceAmount().doubleValue(), 0.001);
            assertEquals(
                    request.getDiscountPrice().doubleValue(),
                    response.getNextCycle().getTotalAmount().doubleValue(), 0.001);
            assertEquals(
                    response.getChangeCycle().getConsumableMainBalance().add(
                            response.getNextCycle().getConsumableMainBalance()).doubleValue(),
                    response.getConsumableMainBalance().doubleValue(), 0.001);
            assertEquals(
                    response.getChangeCycle().getPayableAmount().add(
                            response.getNextCycle().getPayableAmount()).subtract(
                                    response.getConsumableMainBalance()).doubleValue(),
                    response.getRechargeAmount().doubleValue(), 0.001);
            assertEquals(
                    response.getChangeCycle().getTotalAmount().add(
                            response.getNextCycle().getTotalAmount()).doubleValue(),
                    response.getTotalAmount().doubleValue(), 0.001);
            System.out.println(
                    "**************************End of " + testCase.testNum
                            + "********************************");
        };

        TestConditions tc = new TestConditions() {

            {
                vbppEligible = true;
                chimeEligible = false;
                hasInsurance = true;
                hasWearable = true;
                otherPromos = 10;
                fixedFee = 1.81;
            }
        };

        SimpleEntry<String, String> change2 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.BASE3VIS23);
        SimpleEntry<String, String> change3 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.PLUS3VIS23);
        SimpleEntry<String, String> change4 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.BASE3VIS23);
        SimpleEntry<String, String> change5 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.BASE3VIS23);
        SimpleEntry<String, String> change6 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.PLUS3VIS23);
        List<SimpleEntry<String, String>> changes = List.of(
                change2, change3, change4, change5, change6);

        int testnum = 1;
        for (SimpleEntry<String, String> change : changes) {
            tc.oldCi = change.getKey();
            tc.newCi = change.getValue();
            tc.testNum = "#" + testnum++ + "-AsIsCi-" + tc.oldCi + "-ToBeCi-" + tc.newCi;
            pTests.test(tc);
        }
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getChangeServiceAdvice_ChangeAndNextCycle_Core2CoreNextCycle_ChimeElig_Then_CorrectNextCycleOutput")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription with base offer. PaidCycleStartDate is in future.|"
                +"|     |Chime Eligible.|"
                +"|When |Api is called for CoreToCoreDowngrade.|"
                +"|Then |Validate NextCycleFields.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_ChangeAndNextCycle_Core2CoreNextCycle_ChimeElig_Then_CorrectNextCycleOutput(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        OneParameterTest pTests = (tCase) -> {
            td.printDescription();
            String subscriptionExternalId = "123";
            TestConditions testCase = (TestConditions) tCase;
            td.printDescription();
            System.out.println(
                    "**************************Executing " + testCase.testNum
                            + "********************************");

            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setSubscriptionExternalId(subscriptionExternalId);
            request.setNewCatalogItemExternalId(testCase.newCi);
            request.setDiscountPrice(testCase.getNewCiPrice());
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(1000)));
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            String oldCiId = testCase.oldCi;
            BigDecimal oldPrice = testCase.getOldCiPrice();
            BigDecimal coreChime = BigDecimal.valueOf(5);

            BigDecimal goodwillCredits = BigDecimal.valueOf(testCase.otherPromos);
            BigDecimal chimeActuals = BigDecimal.valueOf(testCase.chimeRecEvent);

            BigDecimal newChime = BigDecimal.ZERO;

            BigDecimal promoActualsInSub = BigDecimal.ZERO;
            BigDecimal coreCredits = BigDecimal.ZERO;

            AppPropertyProvider.getInstance().setProperty(
                    Constants.CREDIT_CONSTANTS.AOC_GRANT_OFFERS,
                    TestConstants.CI_EXTERNAL_IDS.CHIME_AOC_GRANT);

            MtxResponsePricingCatalogItem pciChime = emulateMtxResponsePricingCatalogItem(
                    instance, TestConstants.CI_EXTERNAL_IDS.CHIME_AOC_GRANT);
            VisibleTemplate vtChime = (VisibleTemplate) pciChime.getCatalogItemInfo().getTemplateAttr();
            vtChime.setIgnoreTax_ForPayableAmount("false");

            if (testCase.chimeEligible
                    && vtChime.getApplicableOfferName().contains(testCase.newCi)) {
                newChime = coreChime;
            }

            BigDecimal mainbalance = testCase.getOldCiPrice().subtract(goodwillCredits).add(
                    testCase.hasInsurance
                            ? TestConstants.OFFER_PRICES.INSURANCE : BigDecimal.ZERO).add(
                                    testCase.hasWearable
                                            ? TestConstants.OFFER_PRICES.WEARABLE
                                            : BigDecimal.ZERO);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            request.getSubscriptionExternalId(), mainbalance));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCiId);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(
                    new MtxDate(
                            subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime().getTime().split(
                                    "T")[0]));
            if (poiEnrolled.getCycleInfo() != null) {
                // So that annual service will be in its last month.
                poiEnrolled.getCycleInfo().setCycleEndTime(
                        TestUtils.getLastDateTimeOfCurrentMonth(
                                subscriptionResponse.getTimeZone()));
            }

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCiId);
            if (poEnrolled.getCycleInfo() != null) {
                // So that annual service will be in its last month.
                poEnrolled.getCycleInfo().setCycleEndTime(
                        TestUtils.getLastDateTimeOfCurrentMonth(
                                subscription.getLastActivityTime()));
            }

            MtxResponsePricingCatalogItem pciGoodwill = emulateMtxResponsePricingCatalogItem(
                    instance, TestConstants.CI_EXTERNAL_IDS.GRANT_GOODWILL);
            VisibleTemplate vtGoodwill = (VisibleTemplate) pciGoodwill.getCatalogItemInfo().getTemplateAttr();
            vtGoodwill.setIgnoreTax_ForPayableAmount("false");

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(oldCiId, request.getNewCatalogItemExternalId()));
            String goodwillTax = CommonTestHelper.getPromoTaxResp(
                    CI_EXTERNAL_IDS.GRANT_GOODWILL, oldCiId, goodwillCredits);
            String chimeTax = CommonTestHelper.getPromoTaxResp(
                    CI_EXTERNAL_IDS.CHIME_AOC_GRANT, oldCiId, vtChime.getClassCode(), chimeActuals);

            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            enrolledExtnSub.setChargeAmount(oldPrice);
            enrolledExtnSub.setPaidCycleStartDate(enrolledPoiExtn.getPaidCycleStartDate());
            enrolledExtnSub.getCreditTaxDetailsArrayAppender().clear();
            if (goodwillCredits.signum() > 0) {
                enrolledExtnSub.getCreditTaxDetailsArrayAppender().add(goodwillTax);
                promoActualsInSub = promoActualsInSub.add(goodwillCredits);
            }
            enrolledExtnSub.getCreditTaxDetailsArrayAppender().add(chimeTax);
            promoActualsInSub = promoActualsInSub.add(chimeActuals);

            subscription.getPurchasedOfferArrayAppender().add(poEnrolled);

            MtxBalanceInfo biGoodwillGrant = CommonTestHelper.getMtxBalanceInfo(
                    TestConstants.DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Grant.json", 4,
                    43);
            biGoodwillGrant.setAmount(BigDecimal.ZERO);
            biGoodwillGrant.setAvailableAmount(BigDecimal.ZERO);
            subscription.getBalanceArrayAppender().add(biGoodwillGrant);

            MtxBalanceInfo biGoodwillConsumable = CommonTestHelper.getMtxBalanceInfo(
                    TestConstants.DATA_DIR.PAYMENT_ADVICE
                            + "MtxBalanceInfo_Goodwill_Consumable.json",
                    4, 44);
            biGoodwillConsumable.setAmount(goodwillCredits.negate());
            biGoodwillConsumable.setAvailableAmount(goodwillCredits);
            subscription.getBalanceArrayAppender().add(biGoodwillConsumable);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class, TestConstants.DATA_DIR.CHANGE_SERVICE_ADVICE
                            + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(oldPrice);
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().add(goodwillTax);
            enrolledExtnEvent.setPaidCycleStartDate(enrolledPoiExtn.getPaidCycleStartDate());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().add(chimeTax);

            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCiId);

            if (testCase.chimeEligible
                    && vtChime.getApplicableOfferName().contains(testCase.newCi)) {
                doReturn(coreChime.negate()).when(instance).getChargeableAmountForPurchaseOffer(
                        any(),
                        argThat(
                                (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                        TestConstants.CI_EXTERNAL_IDS.CHIME_AOC_REDEEM)),
                        argThat(
                                (MtxPurchasedOfferData pod) -> vtChime.getApplicableOfferName().contains(
                                        ((VisiblePurchasedOfferExtension) pod.getAttr()).getCoreBasePlanCI())),
                        any());
            }

            List<String> balPriList = Arrays.asList(TestConstants.BALANCE_NAMES.GOODWILL_GRANT);
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");
            MtxPurchasedOfferInfo poiGoodwill = CommonTestHelper.loadJsonMessage(
                    MtxPurchasedOfferInfo.class, TestConstants.DATA_DIR.CHANGE_SERVICE
                            + "MtxPurchasedOfferInfo_Visible_Redeem_Goodwill_Credits.json");
            poiGoodwill.setResourceId(55L);

            emulateMtxResponseOneTimeOffer(instance, poiGoodwill);

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetailsAfterPayment(
                    oldCiId, subscriptionResponse, CommonTestHelper.getOfferPrice(oldCiId));
            BigDecimal mainbalanceOldCi = BigDecimal.valueOf(35);
            vodOldCi.setConsumableMainBalanceAmount(mainbalanceOldCi);

            VisibleOfferDetails vodInsurance = CommonTestHelper.getVisibleOfferDetailsAfterPayment(
                    CI_EXTERNAL_IDS.INSURANCE, subscriptionResponse,
                    CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.INSURANCE));
            vodInsurance.setConsumableMainBalanceAmount(TestConstants.OFFER_PRICES.INSURANCE);
            vodInsurance.setResourceId("22");
            vodInsurance.setTaxDetails("Insurance Tax");

            VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsAfterPayment(
                    CI_EXTERNAL_IDS.WEARABLE, subscriptionResponse,
                    CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.WEARABLE));
            vodWearable.setConsumableMainBalanceAmount(TestConstants.OFFER_PRICES.WEARABLE);
            vodWearable.setResourceId("32");
            vodWearable.setTaxDetails("Wearable Tax");

            BigDecimal mainbalanceNewCi = BigDecimal.valueOf(35);
            vodOldCi.setConsumableMainBalanceAmount(mainbalanceNewCi);

            ServiceStage ss = new ServiceStage(oldCiId);

            GlobalCreditStage gcsGoodwill = new GlobalCreditStage(
                    TestConstants.CI_EXTERNAL_IDS.GRANT_GOODWILL, vtGoodwill);
            gcsGoodwill.setPromotionName(vtGoodwill.getPromotionName());
            gcsGoodwill.setAvailableCredits(goodwillCredits);
            gcsGoodwill.setAvailableCreditsConsumable(goodwillCredits);
            gcsGoodwill.setAvailableCreditsGrant(BigDecimal.ZERO);
            gcsGoodwill.setRedeemOfferCi(vtGoodwill.getRedeemOffer());
            gcsGoodwill.setApplicableCiCsv(oldCiId);
            gcsGoodwill.getApplicableCiOrderMap().put(oldCiId, 2L);

            CreditStage csGoodwill = new CreditStage(gcsGoodwill, oldCiId);
            csGoodwill.setCreditTaxDetails(goodwillTax);
            csGoodwill.setApplicableServiceStage(ss);

            GlobalCreditStage gcsChime = new GlobalCreditStage(
                    TestConstants.CI_EXTERNAL_IDS.CHIME_AOC_GRANT, vtChime);
            gcsChime.setPromotionName(vtChime.getPromotionName());
            gcsChime.setAvailableCredits(chimeActuals);
            gcsChime.setAvailableCreditsConsumable(chimeActuals);
            gcsChime.setAvailableCreditsGrant(BigDecimal.ZERO);
            gcsChime.setRedeemOfferCi(vtChime.getRedeemOffer());
            gcsChime.setApplicableCiCsv(oldCiId);
            gcsChime.getApplicableCiOrderMap().put(oldCiId, 2L);

            CreditStage csChime = new CreditStage(gcsChime, oldCiId);
            csChime.setApplicableServiceStage(ss);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            if (testCase.hasInsurance) {
                aopStage.appendVisibleOfferDetailsMap(
                        vodInsurance.getCatalogItemExternalId(),
                        Long.valueOf(vodInsurance.getResourceId()), vodInsurance);
            }
            if (testCase.hasWearable) {
                aopStage.appendVisibleOfferDetailsMap(
                        vodWearable.getCatalogItemExternalId(),
                        Long.valueOf(vodWearable.getResourceId()), vodWearable);
            }
            if (goodwillCredits.signum() > 0) {
                aopStage.getCreditMap().put(
                        new PromoOfferPair(oldCiId, vtGoodwill.getPromotionName()), csGoodwill);
            }

            VisibleSubscriberExtension subAttr = (VisibleSubscriberExtension) subscription.getAttr();
            subAttr.setRetailChannel("Chime");
            aopStage.getCreditMap().put(
                    new PromoOfferPair(oldCiId, vtChime.getPromotionName()), csChime);

            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            Map<String, BigDecimal> balImpactMap = Map.of(
                    BALANCE_NAMES.GLOBAL_PASS, BigDecimal.ONE);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ZERO, null, balImpactMap,
                    true);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ObjectMapper om = TestUtils.getObjectMapper();
                ServiceTaxResponse resp = om.readValue(taxRespString, ServiceTaxResponse.class);
                resp.getTransactionElement().get(0).setTotalFeeAmount(
                        BigDecimal.valueOf(testCase.fixedFee));
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                resp.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());

            BigDecimal usableCredits = BigDecimal.ZERO;
            if (response.getNextCycle().getCredits() != null) {
                for (VisibleCredits vc : response.getNextCycle().getCredits()) {
                    usableCredits = usableCredits.add(vc.getRedeemableCredits());
                }
            }
            coreCredits = coreCredits.add(usableCredits);

            BigDecimal reverseCredits = BigDecimal.ZERO;
            if (response.getNextCycle().getReverseCredits() != null) {
                for (VisibleReverseCredit rc : response.getNextCycle().getReverseCredits()) {
                    reverseCredits = reverseCredits.add(rc.getAvailableCreditsConsumable());
                }
            }
            System.out.println(
                    "**************************Asserting " + testCase.testNum
                            + "********************************");

            BigDecimal expectedCredits = BigDecimal.ZERO;
            if (vtGoodwill.getApplicableOfferName().contains(testCase.newCi)) {
                expectedCredits = goodwillCredits;
            }
            assertEquals(
                    expectedCredits.add(newChime).min(
                            request.getDiscountPrice().subtract(
                                    BigDecimal.valueOf(testCase.minimumCharge))).doubleValue(),
                    usableCredits.doubleValue(), 0.001);
            assertEquals(promoActualsInSub.doubleValue(), reverseCredits.doubleValue(), 0.001);
            assertEquals(
                    request.getDiscountPrice().subtract(usableCredits).doubleValue(),
                    response.getNextCycle().getPayableAmount().doubleValue(), 0.001);
            assertEquals(
                    response.getNewCatalogItem().getDiscountPrice().subtract(
                            usableCredits).subtract(
                                    response.getCurrentCatalogItem().getDiscountPrice()).add(
                                            promoActualsInSub).max(BigDecimal.ZERO).intValue(),
                    response.getNextCycle().getGap().intValue());
            assertEquals(
                    mainbalance.subtract(TestConstants.OFFER_PRICES.WEARABLE).subtract(
                            TestConstants.OFFER_PRICES.INSURANCE).min(
                                    response.getNextCycle().getPayableAmount()).doubleValue(),
                    response.getNextCycle().getConsumableMainBalance().doubleValue(), 0.001);
            assertEquals(
                    BigDecimal.ZERO.add(
                            testCase.hasInsurance
                                    ? TestConstants.OFFER_PRICES.INSURANCE : BigDecimal.ZERO).add(
                                            testCase.hasWearable
                                                    ? TestConstants.OFFER_PRICES.WEARABLE
                                                    : BigDecimal.ZERO).doubleValue(),
                    response.getNextCycle().getReservedMainBalanceAmount().doubleValue(), 0.001);
            assertEquals(
                    request.getDiscountPrice().doubleValue(),
                    response.getNextCycle().getTotalAmount().doubleValue(), 0.001);
            assertEquals(
                    response.getChangeCycle().getConsumableMainBalance().add(
                            response.getNextCycle().getConsumableMainBalance()).doubleValue(),
                    response.getConsumableMainBalance().doubleValue(), 0.001);
            assertEquals(
                    response.getChangeCycle().getPayableAmount().add(
                            response.getNextCycle().getPayableAmount()).subtract(
                                    response.getConsumableMainBalance()).doubleValue(),
                    response.getRechargeAmount().doubleValue(), 0.001);
            assertEquals(
                    response.getChangeCycle().getTotalAmount().add(
                            response.getNextCycle().getTotalAmount()).doubleValue(),
                    response.getTotalAmount().doubleValue(), 0.001);
            System.out.println(
                    "**************************End of " + testCase.testNum
                            + "********************************");
        };
        TestConditions tc = new TestConditions() {

            {
                vbppEligible = false;
                chimeEligible = true;
                hasInsurance = true;
                hasWearable = true;
                otherPromos = 10;
                fixedFee = 1.81;
            }
        };

        SimpleEntry<String, String> change2 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.BASE3VIS23);
        SimpleEntry<String, String> change3 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.PLUS3VIS23);
        SimpleEntry<String, String> change4 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.BASE3VIS23);
        SimpleEntry<String, String> change5 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.BASE3VIS23);
        SimpleEntry<String, String> change6 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.PLUS3VIS23);
        List<SimpleEntry<String, String>> changes = List.of(
                change2, change3, change4, change5, change6);

        int testnum = 1;
        for (SimpleEntry<String, String> change : changes) {
            tc.oldCi = change.getKey();
            tc.newCi = change.getValue();
            tc.testNum = "#" + testnum++ + "-AsIsCi-" + tc.oldCi + "-ToBeCi-" + tc.newCi;
            pTests.test(tc);
        }
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getChangeServiceAdvice_ChangeAndNextCycle_Core2CoreNextCycle_VbppChimeElig_Then_CorrectNextCycleOutput")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription with base offer. PaidCycleStartDate is in future.|"
                +"|     |Vbpp and Chime Eligible.|"
                +"|When |Api is called for CoreToCoreDowngrade.|"
                +"|Then |Validate NextCycleFields.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_ChangeAndNextCycle_Core2CoreNextCycle_VbppChimeElig_Then_CorrectNextCycleOutput(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        OneParameterTest pTests = (tCase) -> {
            String subscriptionExternalId = "123";
            TestConditions testCase = (TestConditions) tCase;
            td.printDescription();
            System.out.println(
                    "**************************Executing " + testCase.testNum
                            + "********************************");

            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setSubscriptionExternalId(subscriptionExternalId);
            request.setNewCatalogItemExternalId(testCase.newCi);
            request.setDiscountPrice(testCase.getNewCiPrice());
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(1000)));
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            String oldCiId = testCase.oldCi;
            BigDecimal oldPrice = testCase.getOldCiPrice();

            String oldVbppClassCode = "VBPP-CORE";

            BigDecimal coreVbpp = BigDecimal.valueOf(5);
            BigDecimal coreChime = BigDecimal.valueOf(5);
            BigDecimal newVbpp = BigDecimal.valueOf(0);
            BigDecimal newChime = BigDecimal.valueOf(0);

            BigDecimal goodwillCredits = BigDecimal.valueOf(testCase.otherPromos);
            BigDecimal vbppActuals = BigDecimal.valueOf(testCase.vbppRecEvent);
            BigDecimal chimeActuals = BigDecimal.valueOf(testCase.chimeRecEvent);

            BigDecimal promoActualsInSub = BigDecimal.ZERO;
            BigDecimal coreCredits = BigDecimal.ZERO;

            AppPropertyProvider.getInstance().setProperty(
                    Constants.CREDIT_CONSTANTS.AOC_GRANT_OFFERS,
                    TestConstants.CI_EXTERNAL_IDS.VBPP5_AOC_GRANT + ","
                            + TestConstants.CI_EXTERNAL_IDS.CHIME_AOC_GRANT);

            MtxResponsePricingCatalogItem pciVbpp = emulateMtxResponsePricingCatalogItem(
                    instance, TestConstants.CI_EXTERNAL_IDS.VBPP5_AOC_GRANT);
            VisibleTemplate vtVbpp = (VisibleTemplate) pciVbpp.getCatalogItemInfo().getTemplateAttr();
            if (vtVbpp.getApplicableOfferName().contains(request.getNewCatalogItemExternalId())) {
                newVbpp = coreVbpp;
            }

            MtxResponsePricingCatalogItem pciChime = emulateMtxResponsePricingCatalogItem(
                    instance, TestConstants.CI_EXTERNAL_IDS.CHIME_AOC_GRANT);
            VisibleTemplate vtChime = (VisibleTemplate) pciChime.getCatalogItemInfo().getTemplateAttr();
            if (vtChime.getApplicableOfferName().contains(request.getNewCatalogItemExternalId())) {
                newChime = coreChime;
            }

            BigDecimal mainbalance = testCase.getOldCiPrice().subtract(goodwillCredits).add(
                    testCase.hasInsurance
                            ? TestConstants.OFFER_PRICES.INSURANCE : BigDecimal.ZERO).add(
                                    testCase.hasWearable
                                            ? TestConstants.OFFER_PRICES.WEARABLE
                                            : BigDecimal.ZERO);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getSubscriptionResponse(subscriptionExternalId, mainbalance));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCiId);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(
                    new MtxDate(
                            subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime().getTime().split(
                                    "T")[0]));
            if (poiEnrolled.getCycleInfo() != null) {
                // So that annual service will be in its last month.
                poiEnrolled.getCycleInfo().setCycleEndTime(
                        TestUtils.getLastDateTimeOfCurrentMonth(
                                subscriptionResponse.getTimeZone()));
            }

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCiId);
            if (poEnrolled.getCycleInfo() != null) {
                // So that annual service will be in its last month.
                poEnrolled.getCycleInfo().setCycleEndTime(
                        TestUtils.getLastDateTimeOfCurrentMonth(
                                subscriptionResponse.getTimeZone()));
            }

            MtxResponsePricingCatalogItem pciGoodwill = emulateMtxResponsePricingCatalogItem(
                    instance, TestConstants.CI_EXTERNAL_IDS.GRANT_GOODWILL);
            VisibleTemplate vtGoodwill = (VisibleTemplate) pciGoodwill.getCatalogItemInfo().getTemplateAttr();
            vtGoodwill.setIgnoreTax_ForPayableAmount("false");

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(oldCiId, request.getNewCatalogItemExternalId()));

            String goodwillTax = CommonTestHelper.getPromoTaxResp(
                    CI_EXTERNAL_IDS.GRANT_GOODWILL, oldCiId, goodwillCredits);
            String vbppTax = CommonTestHelper.getPromoTaxResp(
                    CI_EXTERNAL_IDS.VBPP25_AOC_GRANT, oldCiId, oldVbppClassCode, vbppActuals);
            String chimeTax = CommonTestHelper.getPromoTaxResp(
                    CI_EXTERNAL_IDS.CHIME_AOC_GRANT, oldCiId, vtChime.getClassCode(), chimeActuals);

            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            enrolledExtnSub.setChargeAmount(oldPrice);
            enrolledExtnSub.setPaidCycleStartDate(enrolledPoiExtn.getPaidCycleStartDate());
            enrolledExtnSub.getCreditTaxDetailsArrayAppender().clear();
            if (goodwillCredits.signum() > 0) {
                enrolledExtnSub.getCreditTaxDetailsArrayAppender().add(goodwillTax);
                promoActualsInSub = promoActualsInSub.add(goodwillCredits);
            }
            if (vbppActuals.signum() > 0) {
                enrolledExtnSub.getCreditTaxDetailsArrayAppender().add(vbppTax);
                promoActualsInSub = promoActualsInSub.add(vbppActuals);
            }
            if (chimeActuals.signum() > 0) {
                enrolledExtnSub.getCreditTaxDetailsArrayAppender().add(chimeTax);
                promoActualsInSub = promoActualsInSub.add(chimeActuals);
            }

            subscription.getPurchasedOfferArrayAppender().add(poEnrolled);

            MtxBalanceInfo biGoodwillGrant = CommonTestHelper.getMtxBalanceInfo(
                    TestConstants.DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Grant.json", 4,
                    43);
            biGoodwillGrant.setAmount(BigDecimal.ZERO);
            biGoodwillGrant.setAvailableAmount(BigDecimal.ZERO);
            subscription.getBalanceArrayAppender().add(biGoodwillGrant);

            MtxBalanceInfo biGoodwillConsumable = CommonTestHelper.getMtxBalanceInfo(
                    TestConstants.DATA_DIR.PAYMENT_ADVICE
                            + "MtxBalanceInfo_Goodwill_Consumable.json",
                    4, 44);
            biGoodwillConsumable.setAmount(goodwillCredits.negate());
            biGoodwillConsumable.setAvailableAmount(goodwillCredits);
            subscription.getBalanceArrayAppender().add(biGoodwillConsumable);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class, TestConstants.DATA_DIR.CHANGE_SERVICE_ADVICE
                            + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(oldPrice);
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().add(goodwillTax);
            enrolledExtnEvent.setPaidCycleStartDate(enrolledPoiExtn.getPaidCycleStartDate());
            if (vbppActuals.signum() > 0) {
                enrolledExtnEvent.getCreditTaxDetailsArrayAppender().add(vbppTax);
            }
            if (chimeActuals.signum() > 0) {
                enrolledExtnEvent.getCreditTaxDetailsArrayAppender().add(chimeTax);
            }

            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCiId);
            doReturn(newVbpp.negate()).when(instance).getChargeableAmountForPurchaseOffer(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    TestConstants.CI_EXTERNAL_IDS.VBPP_CORE_REDEEM)),
                    any(), any());
            doReturn(newChime.negate()).when(instance).getChargeableAmountForPurchaseOffer(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    TestConstants.CI_EXTERNAL_IDS.CHIME_AOC_REDEEM)),
                    any(), any());

            List<String> balPriList = Arrays.asList(TestConstants.BALANCE_NAMES.GOODWILL_GRANT);
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");
            MtxPurchasedOfferInfo poiGoodwill = CommonTestHelper.loadJsonMessage(
                    MtxPurchasedOfferInfo.class, TestConstants.DATA_DIR.CHANGE_SERVICE
                            + "MtxPurchasedOfferInfo_Visible_Redeem_Goodwill_Credits.json");
            poiGoodwill.setResourceId(55L);

            emulateMtxResponseOneTimeOffer(instance, poiGoodwill);

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    oldCiId);
            BigDecimal mainbalanceOldCi = BigDecimal.valueOf(35);
            vodOldCi.setConsumableMainBalanceAmount(mainbalanceOldCi);

            VisibleOfferDetails vodInsurance = CommonTestHelper.getVisibleOfferDetailsAfterPayment(
                    CI_EXTERNAL_IDS.INSURANCE, subscriptionResponse,
                    CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.INSURANCE));
            vodInsurance.setConsumableMainBalanceAmount(TestConstants.OFFER_PRICES.INSURANCE);
            vodInsurance.setResourceId("22");
            vodInsurance.setTaxDetails("Insurance Tax");

            VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsAfterPayment(
                    CI_EXTERNAL_IDS.WEARABLE, subscriptionResponse,
                    CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.WEARABLE));
            vodWearable.setConsumableMainBalanceAmount(TestConstants.OFFER_PRICES.WEARABLE);
            vodWearable.setResourceId("32");
            vodWearable.setTaxDetails("Wearable Tax");

            BigDecimal mainbalanceNewCi = BigDecimal.valueOf(35);
            vodOldCi.setConsumableMainBalanceAmount(mainbalanceNewCi);

            ServiceStage ss = new ServiceStage(oldCiId);

            GlobalCreditStage gcsGoodwill = new GlobalCreditStage(
                    TestConstants.CI_EXTERNAL_IDS.GRANT_GOODWILL, vtGoodwill);
            gcsGoodwill.setPromotionName(vtGoodwill.getPromotionName());
            gcsGoodwill.setAvailableCredits(goodwillCredits);
            gcsGoodwill.setAvailableCreditsConsumable(goodwillCredits);
            gcsGoodwill.setAvailableCreditsGrant(BigDecimal.ZERO);
            gcsGoodwill.setRedeemOfferCi(vtGoodwill.getRedeemOffer());
            gcsGoodwill.setApplicableCiCsv(oldCiId);
            gcsGoodwill.getApplicableCiOrderMap().put(oldCiId, 2L);

            CreditStage csGoodwill = new CreditStage(gcsGoodwill, oldCiId);
            csGoodwill.setCreditTaxDetails(goodwillTax);
            csGoodwill.setApplicableServiceStage(ss);

            GlobalCreditStage gcsVbpp5 = new GlobalCreditStage(
                    TestConstants.CI_EXTERNAL_IDS.VBPP25_AOC_GRANT, vtVbpp);
            gcsVbpp5.setPromotionName(vtVbpp.getPromotionName());
            gcsVbpp5.setAvailableCredits(vbppActuals);
            gcsVbpp5.setAvailableCreditsConsumable(vbppActuals);
            gcsVbpp5.setAvailableCreditsGrant(BigDecimal.ZERO);
            gcsVbpp5.setRedeemOfferCi(vtVbpp.getRedeemOffer());
            gcsVbpp5.setApplicableCiCsv(oldCiId);
            gcsVbpp5.getApplicableCiOrderMap().put(oldCiId, 2L);

            CreditStage csVbpp5 = new CreditStage(gcsVbpp5, oldCiId);
            csVbpp5.setApplicableServiceStage(ss);

            GlobalCreditStage gcsChime = new GlobalCreditStage(
                    TestConstants.CI_EXTERNAL_IDS.CHIME_AOC_GRANT, vtChime);
            gcsChime.setPromotionName(vtChime.getPromotionName());
            gcsChime.setAvailableCredits(chimeActuals);
            gcsChime.setAvailableCreditsConsumable(chimeActuals);
            gcsChime.setAvailableCreditsGrant(BigDecimal.ZERO);
            gcsChime.setRedeemOfferCi(vtChime.getRedeemOffer());
            gcsChime.setApplicableCiCsv(oldCiId);
            gcsChime.getApplicableCiOrderMap().put(oldCiId, 2L);

            CreditStage csChime = new CreditStage(gcsChime, oldCiId);
            csChime.setApplicableServiceStage(ss);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            if (testCase.hasInsurance) {
                aopStage.appendVisibleOfferDetailsMap(
                        vodInsurance.getCatalogItemExternalId(),
                        Long.valueOf(vodInsurance.getResourceId()), vodInsurance);
            }
            if (testCase.hasWearable) {
                aopStage.appendVisibleOfferDetailsMap(
                        vodWearable.getCatalogItemExternalId(),
                        Long.valueOf(vodWearable.getResourceId()), vodWearable);
            }
            if (goodwillCredits.signum() > 0) {
                aopStage.getCreditMap().put(
                        new PromoOfferPair(oldCiId, vtGoodwill.getPromotionName()), csGoodwill);
            }

            MtxResponseGroup respGrp = CommonTestHelper.getMtxResponseGroup(
                    "VBPP-" + subscriptionExternalId, "VBPP", 4L,
                    subscriptionResponse.getObjectId().toString(), "1-2-3-4", "6-7-8-9", "4-3-2-1");
            SubscriberGroup sg = new SubscriberGroup(respGrp);
            aopStage.appendSubscriberGroupList(sg);
            aopStage.getCreditMap().put(
                    new PromoOfferPair(oldCiId, vtVbpp.getPromotionName()), csVbpp5);

            VisibleSubscriberExtension subAttr = (VisibleSubscriberExtension) subscription.getAttr();
            subAttr.setRetailChannel("Chime");
            aopStage.getCreditMap().put(
                    new PromoOfferPair(oldCiId, vtChime.getPromotionName()), csChime);

            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            Map<String, BigDecimal> balImpactMap = Map.of(
                    BALANCE_NAMES.GLOBAL_PASS, BigDecimal.ONE);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ZERO, null, balImpactMap,
                    true);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ObjectMapper om = TestUtils.getObjectMapper();
                ServiceTaxResponse resp = om.readValue(taxRespString, ServiceTaxResponse.class);
                resp.getTransactionElement().get(0).setTotalFeeAmount(
                        BigDecimal.valueOf(testCase.fixedFee));
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                resp.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());

            BigDecimal usableCredits = BigDecimal.ZERO;
            if (response.getNextCycle().getCredits() != null) {
                for (VisibleCredits vc : response.getNextCycle().getCredits()) {
                    usableCredits = usableCredits.add(vc.getRedeemableCredits());
                }
            }
            coreCredits = coreCredits.add(usableCredits);

            BigDecimal reverseCredits = BigDecimal.ZERO;
            if (response.getNextCycle().getReverseCredits() != null) {
                for (VisibleReverseCredit rc : response.getNextCycle().getReverseCredits()) {
                    reverseCredits = reverseCredits.add(rc.getAvailableCreditsConsumable());
                }
            }
            System.out.println(
                    "**************************Asserting " + testCase.testNum
                            + "********************************");

            BigDecimal expectedCredits = BigDecimal.ZERO;
            if (vtGoodwill.getApplicableOfferName().contains(testCase.newCi)) {
                expectedCredits = goodwillCredits;
            }
            assertEquals(
                    expectedCredits.add(newChime).add(newVbpp).doubleValue(),
                    usableCredits.doubleValue(), 0.001);
            System.out.println(reverseCredits);
            assertEquals(promoActualsInSub.doubleValue(), reverseCredits.doubleValue(), 0.001);
            assertEquals(
                    request.getDiscountPrice().subtract(usableCredits).doubleValue(),
                    response.getNextCycle().getPayableAmount().doubleValue(), 0.001);
            assertEquals(
                    response.getNewCatalogItem().getDiscountPrice().subtract(
                            usableCredits).subtract(
                                    response.getCurrentCatalogItem().getDiscountPrice()).add(
                                            promoActualsInSub).max(BigDecimal.ZERO).intValue(),
                    response.getNextCycle().getGap().intValue());
            assertEquals(
                    mainbalance.subtract(TestConstants.OFFER_PRICES.WEARABLE).subtract(
                            TestConstants.OFFER_PRICES.INSURANCE).min(
                                    response.getNextCycle().getPayableAmount()).doubleValue(),
                    response.getNextCycle().getConsumableMainBalance().doubleValue(), 0.001);
            assertEquals(
                    BigDecimal.ZERO.add(
                            testCase.hasInsurance
                                    ? TestConstants.OFFER_PRICES.INSURANCE : BigDecimal.ZERO).add(
                                            testCase.hasWearable
                                                    ? TestConstants.OFFER_PRICES.WEARABLE
                                                    : BigDecimal.ZERO).doubleValue(),
                    response.getNextCycle().getReservedMainBalanceAmount().doubleValue(), 0.001);
            assertEquals(
                    request.getDiscountPrice().doubleValue(),
                    response.getNextCycle().getTotalAmount().doubleValue(), 0.001);
            assertEquals(
                    response.getChangeCycle().getConsumableMainBalance().add(
                            response.getNextCycle().getConsumableMainBalance()).doubleValue(),
                    response.getConsumableMainBalance().doubleValue(), 0.001);
            assertEquals(
                    response.getChangeCycle().getPayableAmount().add(
                            response.getNextCycle().getPayableAmount()).subtract(
                                    response.getConsumableMainBalance()).doubleValue(),
                    response.getRechargeAmount().doubleValue(), 0.001);
            assertEquals(
                    response.getChangeCycle().getTotalAmount().add(
                            response.getNextCycle().getTotalAmount()).doubleValue(),
                    response.getTotalAmount().doubleValue(), 0.001);
            System.out.println(
                    "**************************End of " + testCase.testNum
                            + "********************************");
        };

        TestConditions tc = new TestConditions() {

            {
                hasInsurance = true;
                hasWearable = true;
                otherPromos = 10;
                fixedFee = 1.81;
            }
        };

        SimpleEntry<String, String> change2 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.BASE3VIS23);
        SimpleEntry<String, String> change3 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.PLUS3VIS23);
        SimpleEntry<String, String> change4 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.BASE3VIS23);
        SimpleEntry<String, String> change5 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.BASE3VIS23);
        SimpleEntry<String, String> change6 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.PLUS3VIS23);
        List<SimpleEntry<String, String>> changes = List.of(
                change2, change3, change4, change5, change6);

        int testnum = 1;
        for (SimpleEntry<String, String> change : changes) {
            tc.oldCi = change.getKey();
            tc.newCi = change.getValue();
            tc.testNum = "#" + testnum++ + "-AsIsCi-" + tc.oldCi + "-ToBeCi-" + tc.newCi;
            pTests.test(tc);
        }
    }

    @ParameterizedTest(
            name = "test_getChangeServiceAdvice_Given_HasPayer_When_NextCycle_Then_TaxWithPayerGeoDocde")
    @Tag("Tax")
    @Tag("VER-772")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscriber gets paid by payer for recurring services.|"
                +"|     |Subscriber has BASE3VISIBLE23.|"
                +"|     |Payment for next cycle is already made(ManualPay is run.).|"
                +"|When |CSA called. for upgrade to PLUS4VIS25WB or PLUS4VIS25WBA or PPLUS1VIS25WB or PPLUS1VIS25WBA|"
                +"|Then |CSA should call taxapi with payers geocode, for next cycle.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_Given_HasPayer_When_NextCycle_Then_TaxWithPayerGeoDocde(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        String payerGeoCode = "ELBISIVNOZIREV";
        String payerExternalID = "67890";
        String oldCi = CI_EXTERNAL_IDS.BASE3VIS23;
        @SuppressWarnings("unchecked")
        OneParameterTest pTests = (req) -> {
            td.printDescription();
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxObjectId caGroupId = new MtxObjectId("1-2-3-4");
            SubscriptionResponse benSubResp = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse_afterPayment(
                            request.getSubscriptionExternalId(), List.of(oldCi)));
            benSubResp.getParentGroupIdArrayAppender().add(caGroupId);

            MtxDate paidCycleStartDate = TestUtils.getMtxDateFromMtxTimestamp(
                    benSubResp.getBillingCycle().getCurrentPeriodEndTime());

            MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription(
                    request.getSubscriptionExternalId(), List.of(oldCi));
            benSub.getParentGroupIdArrayAppender().add(caGroupId);

            MtxResponseSubscription paySub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                    payerExternalID);
            paySub.getParentGroupIdArrayAppender().add(caGroupId);
            VisibleSubscriberExtension attr = (VisibleSubscriberExtension) paySub.getAttr();
            attr.setGeoCode(payerGeoCode);
            doReturn(benSub).doReturn(paySub).when(api).subscriptionQuery(any());

            emulateMtxResponsePricingCatalogItems(
                    instance, List.of(oldCi.toString(), request.getNewCatalogItemExternalId()));

            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponseMulti_For_CreditBalances(benSubResp));

            doReturn("[" + request.getSubscriptionExternalId() + "]").when(instance).getLoggingKey(
                    any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), aocAmount, null, null, false);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    oldCi.toString(), paidCycleStartDate);

            AdviceDataStage aopStage = new AdviceDataStage(
                    benSubResp, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(benSubResp));

            MtxResponseGroup respGrp = CommonTestHelper.getMtxResponseGroupCA(
                    benSub.getExternalId(), "CAGroup",
                    List.of(benSub.getObjectId().toString(), "1-2-3-4", "6-7-8-9"),
                    List.of(
                            String.format(
                                    GROUP_CONSTANTS.CA_LINK_FORMAT, benSub.getExternalId(),
                                    payerExternalID)));

            SubscriberGroup sg = new SubscriberGroup(respGrp);
            aopStage.appendSubscriberGroupList(sg);

            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(
                                any(), argumentCaptor.capture())).thenReturn(
                                        taxRespChangeCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            argumentCaptor.getAllValues().forEach(taxReq -> {
                System.out.println(td.getTestMethod() + ":" + taxReq);
            });
            ServiceTaxRequest nextCycleTaxReq = CommonTestHelper.getJsonFromString(
                    ServiceTaxRequest.class, argumentCaptor.getAllValues().get(1));
            assertEquals(payerGeoCode, nextCycleTaxReq.getGeocode());
            assertTrue(nextCycleTaxReq.getMsgID().contains("Payer:" + payerExternalID));

        };
        String subscriptionExternalId = "12345";
        VisibleRequestChangeServiceAdvice request = CommonTestHelper.getVisibleRequestChangeServiceAdvice(
                subscriptionExternalId, CI_EXTERNAL_IDS.PLUS25);
        pTests.test(request);
    }

    @ParameterizedTest(
            name = "test_getChangeServiceAdvice_Given_HasPayer_When_NextCycleWithPromos_Then_TaxWithPayerGeoDocde")
    @Tag("Tax")
    @Tag("VER-772")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscriber gets paid by payer for recurring services.|"
                +"|     |Subscriber has BASE3VISIBLE23.|"
                +"|     |Payment for next cycle is already made(ManualPay is run.).|"
                +"|When |CSA called. for upgrade to PLUS4VIS25WB or PLUS4VIS25WBA or PPLUS1VIS25WB or PPLUS1VIS25WBA|"
                +"|When |New offer is eligible for promos.|"
                +"|Then |CSA should call taxapi with payers geocode,for promos, for next cycle.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_Given_HasPayer_When_NextCycleWithPromos_Then_TaxWithPayerGeoDocde(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        String payerGeoCode = "ELBISIVNOZIREV";
        String payerExternalID = "67890";
        String oldCi = CI_EXTERNAL_IDS.BASE3VIS23;
        String promoGrantOffer = CI_EXTERNAL_IDS.GRANT_GOODWILL;
        BigDecimal promoGrant = BigDecimal.TEN;
        @SuppressWarnings("unchecked")
        OneParameterTest pTests = (req) -> {
            td.printDescription();
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxObjectId caGroupId = new MtxObjectId("1-2-3-4");
            SubscriptionResponse benSubResp = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse_afterPayment(
                            request.getSubscriptionExternalId(), List.of(oldCi)));
            benSubResp.getParentGroupIdArrayAppender().add(caGroupId);
            benSubResp.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoGrant(promoGrantOffer, promoGrant));

            MtxDate paidCycleStartDate = TestUtils.getMtxDateFromMtxTimestamp(
                    benSubResp.getBillingCycle().getCurrentPeriodStartTime());

            MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription(
                    request.getSubscriptionExternalId(), List.of(oldCi));
            benSub.getParentGroupIdArrayAppender().add(caGroupId);
            benSub.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoGrant(promoGrantOffer, promoGrant));

            MtxResponseSubscription paySub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                    payerExternalID);
            paySub.getParentGroupIdArrayAppender().add(caGroupId);
            VisibleSubscriberExtension attr = (VisibleSubscriberExtension) paySub.getAttr();
            attr.setGeoCode(payerGeoCode);
            doReturn(benSub).doReturn(paySub).when(api).subscriptionQuery(any());

            Map<String, MtxResponsePricingCatalogItem> ciPricingMap = emulateMtxResponsePricingCatalogItems(
                    instance,
                    List.of(
                            oldCi.toString(), promoGrantOffer,
                            request.getNewCatalogItemExternalId()));

            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponseMulti_For_CreditBalances(benSubResp));

            doReturn("[" + request.getSubscriptionExternalId() + "]").when(instance).getLoggingKey(
                    any());
            BigDecimal aocAmount = BigDecimal.valueOf(20);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), aocAmount, null, null, false);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            /********************** Mock PaymentAdvice ****************************/
            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    oldCi, paidCycleStartDate);

            AdviceDataStage aopStage = new AdviceDataStage(
                    benSubResp, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(benSubResp));

            ServiceStage ss = new ServiceStage(oldCi.toString());
            VisibleTemplate vtGoodwill = (VisibleTemplate) ciPricingMap.get(
                    promoGrantOffer).getCatalogItemInfo().getTemplateAttr();
            GlobalCreditStage gcsGoodwill = new GlobalCreditStage(promoGrantOffer, vtGoodwill);
            gcsGoodwill.setPromotionName(vtGoodwill.getPromotionName());
            gcsGoodwill.setAvailableCredits(promoGrant);
            gcsGoodwill.setAvailableCreditsConsumable(BigDecimal.ZERO);
            gcsGoodwill.setAvailableCreditsGrant(promoGrant);
            gcsGoodwill.setRedeemOfferCi(vtGoodwill.getRedeemOffer());
            gcsGoodwill.setApplicableCiCsv(vtGoodwill.getApplicableOfferName() + "," + oldCi);
            CreditStage csGoodwill = new CreditStage(gcsGoodwill, oldCi);
            csGoodwill.setApplicableServiceStage(ss);
            aopStage.getCreditMap().put(
                    new PromoOfferPair(oldCi, csGoodwill.getPromotionName()), csGoodwill);

            MtxResponseGroup respGrp = CommonTestHelper.getMtxResponseGroupCA(
                    benSub.getExternalId(), "CAGroup",
                    List.of(benSub.getObjectId().toString(), "1-2-3-4", "6-7-8-9"),
                    List.of(
                            String.format(
                                    GROUP_CONSTANTS.CA_LINK_FORMAT, benSub.getExternalId(),
                                    payerExternalID)));

            SubscriberGroup sg = new SubscriberGroup(respGrp);
            aopStage.appendSubscriberGroupList(sg);
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());
            /********************** Mock PaymentAdvice ****************************/

            ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                String taxRespString = CommonTestHelper.getTaxApiResp(
                        request.getNewCatalogItemExternalId());
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(
                                any(), argumentCaptor.capture())).thenReturn(
                                        taxRespChangeCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            argumentCaptor.getAllValues().forEach(taxReq -> {
                System.out.println(td.getTestMethod() + ":" + taxReq);
            });
            ServiceTaxRequest deltaTaxReq = CommonTestHelper.getJsonFromString(
                    ServiceTaxRequest.class, argumentCaptor.getAllValues().get(2));
            assertEquals(payerGeoCode, deltaTaxReq.getGeocode());
            assertTrue(deltaTaxReq.getMsgID().contains("Payer:" + payerExternalID));

        };
        String subscriptionExternalId = "12345";
        VisibleRequestChangeServiceAdvice request = CommonTestHelper.getVisibleRequestChangeServiceAdvice(
                subscriptionExternalId, CI_EXTERNAL_IDS.PLUS25);
        pTests.test(request);
    }
}
