package com.matrixx.vag.advice.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import com.matrixx.datacontainer.MtxDate;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.MtxBalanceInfo;
import com.matrixx.datacontainer.mdc.MtxResponsePricingCatalogItem;
import com.matrixx.datacontainer.mdc.MtxResponseRecurringChargeInfo;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.SubscriptionResponse;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleRequestPaymentAdviceService;
import com.matrixx.datacontainer.mdc.VisibleResponsePaymentAdviceService;
import com.matrixx.datacontainer.mdc.VisibleTemplate;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.common.Constants.CREDIT_CONSTANTS;
import com.matrixx.vag.common.OneParameterTest;
import com.matrixx.vag.common.TestConstants.BALANCE_NAMES;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.util.MDCTest;

public class AopVer591PocTest extends MDCTest {

	/**
	 *Some test cases will fail. These are cases where we want template attributes modified.
	 *We should explore using @TestInstance annotation for such test cases. 
	 */
	
    @Spy
    @InjectMocks
    private PaymentAdviceService instance;

    @Mock
    private SubscriberManagementApi api;

    @BeforeEach
    public void setUp() throws Exception {
        instance = new PaymentAdviceService();
        MockitoAnnotations.openMocks(this);  
    }

    @Test
    @Tags({@Tag("VER-591"),@Tag("POC")})
    public void test_getAOP_When_Goodwill_For_Werable_Insurance_Then_verify_credits() throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[]
                {"Subscriber is enrolled in annual service that is not due for renewal.Wearable and Insurance are eligible for goodwill."};
        td.when = new String[]{"AOP is called"};
        td.then = new String[]{"Verify that goodwill is used for wearable and insurance."};
        @SuppressWarnings("unchecked")
        OneParameterTest pTests = (tmap) -> {
            Map<String, Object> testMap= (Map<String, Object>)tmap;
        	BigDecimal mainbalance = (BigDecimal) testMap.get("MAINBALANCE");
        	BigDecimal goodwillGrant = (BigDecimal) testMap.get("GOODWILL_GRANT");
        	BigDecimal goodwillConsumable = (BigDecimal) testMap.get("GOODWILL_DOLLAR");

        	AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");        	
        	
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(api, 
            		CommonTestHelper.getMtxResponseSubscription(
            				List.of(CI_EXTERNAL_IDS.BASE3ANNUAL, CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023, CI_EXTERNAL_IDS.INSURANCE)));
            
            subscription.getBalanceArray().forEach(mbi->{
            	if(BALANCE_NAMES.MAIN_BALANCE.equalsIgnoreCase(mbi.getName())) {
            		mbi.setAvailableAmount(mainbalance);
            		mbi.setAmount(mainbalance.negate());
            	}
            });
            MtxBalanceInfo biGoodwillGrant = CommonTestHelper.getMtxBalanceInfoForPromoGrant(CI_EXTERNAL_IDS.GRANT_GOODWILL, goodwillGrant);
            subscription.getBalanceArrayAppender().add(biGoodwillGrant);

            MtxBalanceInfo biGoodwillConsumable = CommonTestHelper.getMtxBalanceInfoForPromoConsumable(CI_EXTERNAL_IDS.GRANT_GOODWILL, goodwillConsumable);
            subscription.getBalanceArrayAppender().add(biGoodwillConsumable);
            
            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(instance,
            		CommonTestHelper.getSubscriptionResponse(
            				List.of(CI_EXTERNAL_IDS.BASE3ANNUAL, CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023, CI_EXTERNAL_IDS.INSURANCE)));
            subscriptionResponse.getPurchasedOfferArray().forEach(poi->{
                VisiblePurchasedOfferExtension enrolledPoiExtn= (VisiblePurchasedOfferExtension)poi.getAttr();
                enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
                MtxDate paidCycleStart = new MtxDate(subscriptionResponse.getBillingCycle().getCurrentPeriodStartTime().getTime().split("T")[0]);
                enrolledPoiExtn.setPaidCycleStartDate(paidCycleStart);            	
            });
            
            List<String> balPriList = List.of(BALANCE_NAMES.GOODWILL_GRANT);
            emulateMtxResponseMultiFromObject(instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));

            doReturn("").when(instance).getRoute(any());
            doReturn(null).when(instance).queryDeviceData(any(), any(), any());    		
    		Map<String, BigDecimal> consImpact = new HashMap<String, BigDecimal>();
    		consImpact.put(BALANCE_NAMES.GOODWILL_CONSUMABLE, goodwillConsumable);
    	    doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(any(), any(), any());
            MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse, consImpact);
            emulateMtxResponseRecurringChargeInfo(api, chargeInfo);            

        	Map<String, MtxResponsePricingCatalogItem> pciMap =emulateMtxResponsePricingCatalogItems(instance, 
        			List.of(CI_EXTERNAL_IDS.BASE3ANNUAL, CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023, CI_EXTERNAL_IDS.INSURANCE, CI_EXTERNAL_IDS.GRANT_GOODWILL));
        	MtxResponsePricingCatalogItem pciGoodwill = pciMap.get(CI_EXTERNAL_IDS.GRANT_GOODWILL);
        	VisibleTemplate vtGoodwill = (VisibleTemplate) pciGoodwill.getCatalogItemInfo().getTemplateAttr();
        	vtGoodwill.setApplicableOfferName(CI_EXTERNAL_IDS.BASE3ANNUAL+","+CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023+","+CI_EXTERNAL_IDS.INSURANCE);
        	
            VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
            input.setIncludeTaxDetails("N");
            input.setSubscriberExternalId(subscriptionResponse.getExternalId());
            VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();
    	    // method to test
    	    instance.getAOP(input, output);
    		
            System.out.println(output.toJson());

        };
        Map<String, Object> testMap = new HashMap<String, Object>();
        testMap.put("MAINBALANCE", BigDecimal.valueOf(0));
        testMap.put("GOODWILL_GRANT", BigDecimal.valueOf(50));
        testMap.put("GOODWILL_DOLLAR", BigDecimal.valueOf(5));
        pTests.test(testMap);
    }

    @Test
    @Tags({@Tag("VER-591"),@Tag("POC")})
    public void test_getAOP_When_Ref20_For_Werable_Insurance_Then_verify_credits() throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[]
                {"Subscriber is enrolled in annual service that is not due for renewal.Wearable and Insurance are eligible for ref20."};
        td.when = new String[]{"AOP is called"};
        td.then = new String[]{"Verify that ref20 is used for wearable and insurance."};
        @SuppressWarnings("unchecked")
        OneParameterTest pTests = (tmap) -> {
        	Map<String, Object> testMap= (Map<String, Object>)tmap;
        	BigDecimal mainbalance = (BigDecimal) testMap.get("MAINBALANCE");
        	BigDecimal goodwillGrant = (BigDecimal) testMap.get("REF20_GRANT");
        	BigDecimal goodwillConsumable = (BigDecimal) testMap.get("REF20_DOLLAR");

        	AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");        	
        	
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(api, 
            		CommonTestHelper.getMtxResponseSubscription(
            				List.of(CI_EXTERNAL_IDS.BASE3ANNUAL, CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023, CI_EXTERNAL_IDS.INSURANCE)));
            
            subscription.getBalanceArray().forEach(mbi->{
            	if(BALANCE_NAMES.MAIN_BALANCE.equalsIgnoreCase(mbi.getName())) {
            		mbi.setAvailableAmount(mainbalance);
            		mbi.setAmount(mainbalance.negate());
            	}
            });
            MtxBalanceInfo biGoodwillGrant = CommonTestHelper.getMtxBalanceInfoForPromoGrant(CI_EXTERNAL_IDS.REF20_GRANT, goodwillGrant);
            subscription.getBalanceArrayAppender().add(biGoodwillGrant);

            MtxBalanceInfo biGoodwillConsumable = CommonTestHelper.getMtxBalanceInfoForPromoConsumable(CI_EXTERNAL_IDS.REF20_GRANT, goodwillConsumable);
            subscription.getBalanceArrayAppender().add(biGoodwillConsumable);
            
            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(instance,
            		CommonTestHelper.getSubscriptionResponse(
            				List.of(CI_EXTERNAL_IDS.BASE3ANNUAL, CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023, CI_EXTERNAL_IDS.INSURANCE)));
            subscriptionResponse.getPurchasedOfferArray().forEach(poi->{
                VisiblePurchasedOfferExtension enrolledPoiExtn= (VisiblePurchasedOfferExtension)poi.getAttr();
                enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
                MtxDate paidCycleStart = new MtxDate(subscriptionResponse.getBillingCycle().getCurrentPeriodStartTime().getTime().split("T")[0]);
                enrolledPoiExtn.setPaidCycleStartDate(paidCycleStart);            	
            });
            
            List<String> balPriList = List.of(BALANCE_NAMES.REF20_GRANT);
            emulateMtxResponseMultiFromObject(instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));

            doReturn("").when(instance).getRoute(any());
            doReturn(null).when(instance).queryDeviceData(any(), any(), any());    		
    		Map<String, BigDecimal> consImpact = new HashMap<String, BigDecimal>();
    		consImpact.put(BALANCE_NAMES.REF20_CONSUMABLE, goodwillConsumable);
    	    doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(any(), any(), any());
    	    MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse, consImpact);
            emulateMtxResponseRecurringChargeInfo(api, chargeInfo);            

        	Map<String, MtxResponsePricingCatalogItem> pciMap =emulateMtxResponsePricingCatalogItems(instance, 
        			List.of(CI_EXTERNAL_IDS.BASE3ANNUAL, CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023, CI_EXTERNAL_IDS.INSURANCE, CI_EXTERNAL_IDS.REF20_GRANT));
        	MtxResponsePricingCatalogItem pciGoodwill = pciMap.get(CI_EXTERNAL_IDS.REF20_GRANT);
        	VisibleTemplate vtGoodwill = (VisibleTemplate) pciGoodwill.getCatalogItemInfo().getTemplateAttr();
        	vtGoodwill.setApplicableOfferName(CI_EXTERNAL_IDS.BASE3ANNUAL+","+CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023+","+CI_EXTERNAL_IDS.INSURANCE);
        	
            VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
            input.setIncludeTaxDetails("N");
            input.setSubscriberExternalId(subscriptionResponse.getExternalId());
            VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();
    	    // method to test
    	    instance.getAOP(input, output);
    		
            System.out.println(output.toJson());

        };
        Map<String, Object> testMap = new HashMap<String, Object>();
        testMap.put("MAINBALANCE", BigDecimal.valueOf(0));
        testMap.put("REF20_GRANT", BigDecimal.valueOf(50));
        testMap.put("REF20_DOLLAR", BigDecimal.valueOf(10));
        pTests.test(testMap);
    }

}
