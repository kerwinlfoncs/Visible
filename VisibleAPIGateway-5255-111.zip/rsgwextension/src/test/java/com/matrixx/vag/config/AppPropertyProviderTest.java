package com.matrixx.vag.config;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import com.matrixx.vag.common.Constants.BRAINTREE_CONSTANTS;
import com.matrixx.vag.util.MDCTest;

public class AppPropertyProviderTest extends MDCTest {
	
    @Test
    public void test_getInstance_When_PropetiesLoadSucess(TestInfo testInfo) {
    	System.out.println(testInfo.getDisplayName()+":");	
        PropertiesConfiguration props;// = AppPropertyProvider.getInstance();
    	try (MockedStatic<AppPropertyParser> mockedStatic = Mockito.mockStatic(AppPropertyParser.class)) {            
 			mockedStatic.when(() -> AppPropertyParser.validateProperties(any())).then(invocationOnMock -> null);     
 			props =AppPropertyProvider.getInstance();
    	}
        assertNotNull(props);
        assertEquals(
                "51,52,81", props.getString(BRAINTREE_CONSTANTS.BRAINTREE_ERROR_CODES_LIST));
    }

    @Test
    public void test_reloadApplicationProperties_When_PropetiesLoadSucess(TestInfo testInfo) {
    	System.out.println(testInfo.getDisplayName()+":");        
    	try (MockedStatic<AppPropertyParser> mockedStatic = Mockito.mockStatic(AppPropertyParser.class)) {            
 			mockedStatic.when(() -> AppPropertyParser.validateProperties(any())).then(invocationOnMock -> null);
 			assertAll(() ->  AppPropertyProvider.reloadApplicationProperties());
    	}
    }
    
    @Test
    public void test_reloadApplicationProperties_When_NewProperties_Then_AddNewProperties(TestInfo testInfo) throws ConfigurationException {
    	System.out.println(testInfo.getDisplayName()+":");        
    	try (MockedStatic<AppPropertyParser> mockedStatic = Mockito.mockStatic(AppPropertyParser.class)) {            
 			mockedStatic.when(() -> AppPropertyParser.validateProperties(any())).then(invocationOnMock -> null);
 			Map<String, String> newProps = new HashMap<String, String>();
 			newProps.put("OneMoreProp", "OK");
 			AppPropertyProvider.reloadApplicationProperties(newProps);
    	}        
    	assertEquals("OK",AppPropertyProvider.getProperty("OneMoreProp"));	
        assertEquals("51,52,81", AppPropertyProvider.getProperty(BRAINTREE_CONSTANTS.BRAINTREE_ERROR_CODES_LIST));
    }
    
    @Test
    @Disabled("Works individually")
    public void test_getInstance_When_PropetiesLoadFail(TestInfo testInfo) {
    	System.out.println(testInfo.getDisplayName()+":");
    	Exception exception;
    	try (MockedStatic<AppPropertyParser> mockedStatic = Mockito.mockStatic(AppPropertyParser.class)) {            
 			mockedStatic.when(() -> AppPropertyParser.validateProperties(any())).thenThrow(new ConfigurationException()); 	     
 			exception = assertThrows(RuntimeException.class, () ->  AppPropertyProvider.getInstance());
 			exception.printStackTrace();
 	        assertEquals("Failed to load application configuration properties",exception.getMessage());
    	}		
    }

}
