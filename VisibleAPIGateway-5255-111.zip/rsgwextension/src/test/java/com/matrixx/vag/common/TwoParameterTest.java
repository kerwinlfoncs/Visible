package com.matrixx.vag.common;
@FunctionalInterface  
public interface TwoParameterTest {
	void test(Object p1, Object p2) throws Exception; 
}
