package com.matrixx.vag.advice.service;

import java.util.HashMap;
import java.util.Map;

public class ExpectedResponse {
	public Map<String, Object> promoMap = new HashMap<String, Object>();
	public Map<String, Object> resultMap = new HashMap<String, Object>();
}
