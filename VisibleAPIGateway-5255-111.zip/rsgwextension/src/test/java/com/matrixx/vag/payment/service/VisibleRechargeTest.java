package com.matrixx.vag.payment.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import com.matrixx.datacontainer.MtxObjectId;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.MtxRequestMulti;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberPurchaseOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberRecharge;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberTransferBalance;
import com.matrixx.datacontainer.mdc.MtxResponseDevice;
import com.matrixx.datacontainer.mdc.MtxResponseMulti;
import com.matrixx.datacontainer.mdc.MtxResponseUser;
import com.matrixx.datacontainer.mdc.SubscriptionResponse;
import com.matrixx.datacontainer.mdc.VisibleDeviceExtension;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleRechargeExtension;
import com.matrixx.datacontainer.mdc.VisibleRequestRecharge;
import com.matrixx.datacontainer.mdc.VisibleResponseRecharge;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.common.Constants.LOG_MESSAGES;
import com.matrixx.vag.common.Constants.PAYMENT_CONSTANTS;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestConstants.PURCHASE_SERVICE_TYPES;
import com.matrixx.vag.exception.IntegrationServiceException;
import com.matrixx.vag.exception.MtxResponseException;
import com.matrixx.vag.exception.SacServiceException;
import com.matrixx.vag.exception.VisibleRechargeException;
import com.matrixx.vag.exception.VisibleUnitTestException;
import com.matrixx.vag.util.MDCTest;

public class VisibleRechargeTest extends MDCTest {

    @Spy
    @InjectMocks
    private VisibleRechargeService instance = new VisibleRechargeService();

    @Mock
    private SubscriberManagementApi api;

    private TestInfo testInfo;

    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        instance = new VisibleRechargeService();
        MockitoAnnotations.openMocks(this);
        this.testInfo = testInfo;
        doReturn("").when(instance).getRoute(any());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_recharge_When_PayerIdExistsWithRecharge_Then_DoTransferBalance")
    @Tag("VER-771")
    @Tag("VER-791")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Both Payer and Beneficiary have mainbalance.|"
                +"|When |Input has payerid & Recharge request.|"
                +"|Then |Recharge event and Transfer Balance event should be created for amount for payer.|"
                +"|Comments |junit can not check events. So check multirequest inputs.|"})
    // @formatter:on
    public void test_recharge_When_PayerIdExistsWithRecharge_Then_DoTransferBalance(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestRecharge request = CommonTestHelper.getVisibleRequestRecharge(
                "12345", "67890", "O-12345", List.of(CI_EXTERNAL_IDS.PLUS25));
        VisibleResponseRecharge response = new VisibleResponseRecharge();
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        SubscriptionResponse payerSub = emulateSubscriptionResponse(
                instance, CommonTestHelper.getEmptySubscriptionResponse());

        payerSub.getDeviceIdArrayAppender().add(new MtxObjectId("1-2-3-4"));
        MtxResponseDevice device = CommonTestHelper.getMtxResponseDevice_Default();
        doReturn(device).when(instance).queryDeviceData(any(), any(), any());

        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        instance.recharge(request, response);

        printUnitTest(response.toJson());
        MtxRequestMulti multi = argumentCaptor.getValue();
        printUnitTest(multi.toJson());
        assertEquals(
                MtxRequestSubscriberRecharge.class.getSimpleName(),
                multi.getAtRequestList(0).getContainer().getName());
        assertEquals(
                MtxRequestSubscriberTransferBalance.class.getSimpleName(),
                multi.getAtRequestList(1).getContainer().getName());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_recharge_When_NoPayerIdWithRecharge_Then_NoTransferBalance")
    @Tag("VER-771")
    @Tag("VER-791")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Both Payer and Beneficiary have mainbalance.|"
                +"|When |Request has NO payerid.|"
                +"|Then |Only Recharge event should be created for amount for payer.|"
                +"|Comments |junit can not check events. So check multirequest inputs.|"})
    // @formatter:on
    public void test_recharge_When_NoPayerIdWithRecharge_Then_NoTransferBalance(ArgumentsAccessor acceptance)
            throws IOException, VisibleUnitTestException, IntegrationServiceException,
            NoSuchMethodException, SecurityException, InstantiationException,
            IllegalAccessException, IllegalArgumentException, InvocationTargetException, MtxResponseException {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestRecharge request = CommonTestHelper.getVisibleRequestRecharge(
                "12345", "", "O-12345", List.of(CI_EXTERNAL_IDS.PLUS25));
        VisibleResponseRecharge response = new VisibleResponseRecharge();
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        SubscriptionResponse benSub = emulateSubscriptionResponse(
                instance, CommonTestHelper.getEmptySubscriptionResponse());

        benSub.getDeviceIdArrayAppender().add(new MtxObjectId("1-2-3-4"));
        MtxResponseDevice device = CommonTestHelper.getMtxResponseDevice_Default();
        doReturn(device).when(instance).queryDeviceData(any(), any(), any());

        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        instance.recharge(request, response);

        printUnitTest(response.toJson());
        MtxRequestMulti multi = argumentCaptor.getValue();
        printUnitTest(multi.toJson());
        assertEquals(1, multi.getRequestList().size());
        assertEquals(
                MtxRequestSubscriberRecharge.class.getSimpleName(),
                multi.getAtRequestList(0).getContainer().getName());
    }

    @SuppressWarnings({
        "unchecked"
    })
    @ParameterizedTest(name = "test_recharge_When_PayerIdWithRecharge_Then_UpdatePayerApiEventData")
    @Tag("VER-771")
    @Tag("VER-791")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Both Payer and Beneficiary have mainbalance.|"
                +"|When |Request has payerid.|"
                +"|Then |Recharge Attribute should have Name from Payer User and MDN from Payer Device.|"})
    // @formatter:on
    public void test_recharge_When_PayerIdWithRecharge_Then_UpdatePayerApiEventData(ArgumentsAccessor acceptance)
            throws VisibleUnitTestException, IOException, IntegrationServiceException,
            NoSuchMethodException, SecurityException, InstantiationException,
            IllegalAccessException, IllegalArgumentException, InvocationTargetException, MtxResponseException {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestRecharge request = CommonTestHelper.getVisibleRequestRecharge(
                "12345", "67890", "O-12345", List.of(CI_EXTERNAL_IDS.PLUS25));
        VisibleResponseRecharge response = new VisibleResponseRecharge();
        MtxResponseUser payerUser = emulateMtxResponseUser(
                instance, CommonTestHelper.getMtxResponseUser());
        printUnitTest(payerUser.toJson());
        SubscriptionResponse payerSub = emulateSubscriptionResponse(
                instance, CommonTestHelper.getEmptySubscriptionResponse());

        payerSub.getDeviceIdArrayAppender().add(new MtxObjectId("1-2-3-4"));
        MtxResponseDevice payerDevice = CommonTestHelper.getMtxResponseDevice_Default();
        printUnitTest(payerDevice.toJson());
        doReturn(payerDevice).when(instance).queryDeviceData(any(), any(), any());

        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        instance.recharge(request, response);

        printUnitTest(response.toJson());
        MtxRequestMulti multi = argumentCaptor.getValue();
        printUnitTest(multi.toJson());

        @SuppressWarnings("unused")
        MtxRequestSubscriberRecharge mtxRecharge = new MtxRequestSubscriberRecharge(
                multi.getAtRequestList(0).getContainer());
        VisibleRechargeExtension attr = (VisibleRechargeExtension) request.getRechargeAttr();
        assertEquals(payerUser.getFirstName(), attr.getPayerFirstName());
        assertEquals(payerUser.getLastName(), attr.getPayerLastName());

        VisibleDeviceExtension vde = (VisibleDeviceExtension) payerDevice.getAttr();
        assertEquals(vde.getAtAccessNumberArray(0).toString(), attr.getPayerMDN());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_recharge_When_Always_Then_UpdateBeneficaryAttributes")
    @Tag("VER-771")
    @Tag("VER-791")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Both Payer and Beneficiary have mainbalance.|"
                +"|When |Always.|"
                +"|Then |RechargeAttribute should have Name from Beneficiary User.|"})
    // @formatter:on
    public void test_recharge_When_Always_Then_UpdateBeneficaryAttributes(ArgumentsAccessor acceptance)
            throws VisibleUnitTestException, IOException, IntegrationServiceException,
            NoSuchMethodException, SecurityException, InstantiationException,
            IllegalAccessException, IllegalArgumentException, InvocationTargetException, MtxResponseException {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestRecharge request = CommonTestHelper.getVisibleRequestRecharge(
                "12345", "67890", "O-12345", List.of(CI_EXTERNAL_IDS.PLUS25));
        VisibleResponseRecharge response = new VisibleResponseRecharge();

        MtxResponseUser benUser = CommonTestHelper.getMtxResponseUser();
        benUser.setFirstName("eiusmod");
        benUser.setLastName("tempor");
        printUnitTest(benUser.toJson());
        MtxResponseUser payerUser = CommonTestHelper.getMtxResponseUser();
        printUnitTest(payerUser.toJson());
        doReturn(benUser).doReturn(payerUser).when(instance).queryUserBySearchData(any(), any());

        SubscriptionResponse benSub = emulateSubscriptionResponse(
                instance, CommonTestHelper.getEmptySubscriptionResponse());

        benSub.getDeviceIdArrayAppender().add(new MtxObjectId("1-2-3-4"));
        MtxResponseDevice payerDevice = CommonTestHelper.getMtxResponseDevice_Default();
        printUnitTest(payerDevice.toJson());
        doReturn(payerDevice).when(instance).queryDeviceData(any(), any(), any());

        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        instance.recharge(request, response);

        printUnitTest(response.toJson());
        MtxRequestMulti multi = argumentCaptor.getValue();
        printUnitTest(multi.toJson());
        MtxRequestSubscriberRecharge mtxRecharge = new MtxRequestSubscriberRecharge(
                multi.getAtRequestList(0).getContainer());
        VisibleRechargeExtension attr = (VisibleRechargeExtension) mtxRecharge.getRechargeAttr();
        assertEquals(benUser.getFirstName(), attr.getBeneficiaryFirstName());
        assertEquals(benUser.getLastName(), attr.getBeneficiaryLastName());
        assertEquals(benSub.getExternalId(), attr.getBeneficiaryExternalId());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_recharge_When_BeneficiaryOnly_Then_DoNotUpdateRechargeRequest")
    @Tag("VER-771")
    @Tag("VER-791")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Beneficiary has mainbalance. No Payer.|"
                +"|When |Always.|"
                +"|Then |Pass Recharge Request to engine without change.|"
                +"|Comments |For integration testing check beneficiary recharge event data.|"})
    // @formatter:on
    public void test_recharge_When_BeneficiaryOnly_Then_DoNotUpdateRechargeRequest(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestRecharge request = CommonTestHelper.getVisibleRequestRecharge(
                "12345", "", "O-12345", List.of(CI_EXTERNAL_IDS.PLUS25));
        VisibleResponseRecharge response = new VisibleResponseRecharge();

        MtxResponseUser benUser = CommonTestHelper.getMtxResponseUser();
        benUser.setFirstName("eiusmod");
        benUser.setLastName("tempor");
        printUnitTest(benUser.toJson());
        doReturn(benUser).when(instance).queryUserBySearchData(any(), any());

        SubscriptionResponse benSub = emulateSubscriptionResponse(
                instance, CommonTestHelper.getEmptySubscriptionResponse());

        benSub.getDeviceIdArrayAppender().add(new MtxObjectId("1-2-3-4"));
        MtxResponseDevice payerDevice = CommonTestHelper.getMtxResponseDevice_Default();
        printUnitTest(payerDevice.toJson());
        doReturn(payerDevice).when(instance).queryDeviceData(any(), any(), any());

        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        instance.recharge(request, response);

        printUnitTest(response.toJson());
        MtxRequestMulti multi = argumentCaptor.getValue();
        printUnitTest(multi.toJson());
        MtxRequestSubscriberRecharge mtxRecharge = new MtxRequestSubscriberRecharge(
                multi.getAtRequestList(0).getContainer());
        VisibleRechargeExtension attr = (VisibleRechargeExtension) mtxRecharge.getRechargeAttr();
        assertEquals(benUser.getFirstName(), attr.getBeneficiaryFirstName());
        assertEquals(benUser.getLastName(), attr.getBeneficiaryLastName());
        assertEquals(
                request.getSubscriberSearchData().getExternalId(),
                mtxRecharge.getSubscriberSearchData().getExternalId());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_recharge_When_RequestHasPayerId_Then_RedirectRechargeRequest")
    @Tag("VER-771")
    @Tag("VER-791")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Payer and Beneficiary have mainbalance.|"
                +"|When |Always.|"
                +"|Then |Pass Recharge Request to payer.|"
                +"|Comments |For integration testing check payer recharge event data.|"})
    // @formatter:on
    public void test_recharge_When_RequestHasPayerId_Then_RedirectRechargeRequest(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestRecharge request = CommonTestHelper.getVisibleRequestRecharge(
                "12345", "67890", "O-12345", List.of(CI_EXTERNAL_IDS.PLUS25));
        VisibleResponseRecharge response = new VisibleResponseRecharge();

        MtxResponseUser benUser = CommonTestHelper.getMtxResponseUser();
        benUser.setFirstName("eiusmod");
        benUser.setLastName("tempor");
        printUnitTest(benUser.toJson());
        MtxResponseUser payerUser = CommonTestHelper.getMtxResponseUser();
        printUnitTest(payerUser.toJson());
        doReturn(benUser).doReturn(payerUser).when(instance).queryUserBySearchData(any(), any());

        SubscriptionResponse payerSub = emulateSubscriptionResponse(
                instance, CommonTestHelper.getEmptySubscriptionResponse());

        payerSub.getDeviceIdArrayAppender().add(new MtxObjectId("1-2-3-4"));
        MtxResponseDevice payerDevice = CommonTestHelper.getMtxResponseDevice_Default();
        printUnitTest(payerDevice.toJson());
        doReturn(payerDevice).when(instance).queryDeviceData(any(), any(), any());

        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        instance.recharge(request, response);

        printUnitTest(response.toJson());
        MtxRequestMulti multi = argumentCaptor.getValue();
        printUnitTest(multi.toJson());
        MtxRequestSubscriberRecharge mtxRecharge = new MtxRequestSubscriberRecharge(
                multi.getAtRequestList(0).getContainer());
        assertEquals(
                request.getPayerExternalId(),
                mtxRecharge.getSubscriberSearchData().getExternalId());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_recharge_When_RequestHasPayerId_Then_TBAmount_EQ_RechargeAmount")
    @Tag("VER-771")
    @Tag("VER-791")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Payer and Beneficiary have mainbalance.|"
                +"|When |Always.|"
                +"|Then |Recharge Amount == Transfer Balance Amount.|"})
    // @formatter:on
    public void test_recharge_When_RequestHasPayerId_Then_TBAmount_EQ_RechargeAmount(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestRecharge request = CommonTestHelper.getVisibleRequestRecharge(
                "12345", "67890", "O-12345", List.of(CI_EXTERNAL_IDS.PLUS25));
        VisibleResponseRecharge response = new VisibleResponseRecharge();

        MtxResponseUser benUser = CommonTestHelper.getMtxResponseUser();
        benUser.setFirstName("eiusmod");
        benUser.setLastName("tempor");
        printUnitTest(benUser.toJson());
        MtxResponseUser payerUser = CommonTestHelper.getMtxResponseUser();
        printUnitTest(payerUser.toJson());
        doReturn(benUser).doReturn(payerUser).when(instance).queryUserBySearchData(any(), any());

        SubscriptionResponse payerSub = emulateSubscriptionResponse(
                instance, CommonTestHelper.getEmptySubscriptionResponse());

        payerSub.getDeviceIdArrayAppender().add(new MtxObjectId("1-2-3-4"));
        MtxResponseDevice payerDevice = CommonTestHelper.getMtxResponseDevice_Default();
        printUnitTest(payerDevice.toJson());
        doReturn(payerDevice).when(instance).queryDeviceData(any(), any(), any());

        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        instance.recharge(request, response);

        printUnitTest(response.toJson());
        MtxRequestMulti multi = argumentCaptor.getValue();
        printUnitTest(multi.toJson());
        MtxRequestSubscriberRecharge mtxRecharge = new MtxRequestSubscriberRecharge(
                multi.getAtRequestList(0).getContainer());
        MtxRequestSubscriberTransferBalance mtxTB = new MtxRequestSubscriberTransferBalance(
                multi.getAtRequestList(1).getContainer());
        assertEquals(mtxRecharge.getAmount().floatValue(), mtxTB.getAmount().floatValue());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_recharge_Given_PayerHasNoMainbalance_When_PayerInRequest_Then_Error")
    @Tag("VER-771")
    @Tag("VER-791")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Payer has no mainbalance.|"
                +"|     |Beneficiary has mainbalance.|"
                +"|When |Payer in request.|"
                +"|Then |Error|"})
    // @formatter:on
    public void test_recharge_Given_PayerHasNoMainbalance_When_PayerInRequest_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestRecharge request = CommonTestHelper.getVisibleRequestRecharge(
                "12345", "67890", "O-12345", List.of(CI_EXTERNAL_IDS.PLUS25));
        VisibleResponseRecharge response = new VisibleResponseRecharge();

        MtxResponseUser benUser = CommonTestHelper.getMtxResponseUser();
        benUser.setFirstName("eiusmod");
        benUser.setLastName("tempor");
        printUnitTest(benUser.toJson());
        MtxResponseUser payerUser = CommonTestHelper.getMtxResponseUser();
        printUnitTest(payerUser.toJson());
        doReturn(benUser).doReturn(payerUser).when(instance).queryUserBySearchData(any(), any());

        SubscriptionResponse payerSub = CommonTestHelper.getEmptySubscriptionResponse_NoMainbalance();
        SubscriptionResponse benSub = CommonTestHelper.getEmptySubscriptionResponse();
        doReturn(benSub).doReturn(payerSub).when(instance).querySubscriptionByRQT(
                any(), any(), any());

        payerSub.getDeviceIdArrayAppender().add(new MtxObjectId("1-2-3-4"));
        MtxResponseDevice payerDevice = CommonTestHelper.getMtxResponseDevice_Default();
        printUnitTest(payerDevice.toJson());
        doReturn(payerDevice).when(instance).queryDeviceData(any(), any(), any());

        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        Exception exception = assertThrows(
                VisibleRechargeException.class, () -> instance.recharge(request, response));
        exception.printStackTrace();
        assertTrue(exception.getMessage().contains(LOG_MESSAGES.PAYER_HAS_NO_MAINBALANCE));
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_recharge_Given_BeneficiaryHasNoMainbalance_When_Always_Then_Error")
    @Tag("VER-771")
    @Tag("VER-791")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Payer has mainbalance.|"
                +"|     |Beneficiary has NO mainbalance.|"
                +"|When |Always.|"
                +"|Then |Error|"})
    // @formatter:on
    public void test_recharge_Given_BeneficiaryHasNoMainbalance_When_Always_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestRecharge request = CommonTestHelper.getVisibleRequestRecharge(
                "12345", "67890", "O-12345", List.of(CI_EXTERNAL_IDS.PLUS25));
        VisibleResponseRecharge response = new VisibleResponseRecharge();

        MtxResponseUser benUser = CommonTestHelper.getMtxResponseUser();
        benUser.setFirstName("eiusmod");
        benUser.setLastName("tempor");
        printUnitTest(benUser.toJson());
        MtxResponseUser payerUser = CommonTestHelper.getMtxResponseUser();
        printUnitTest(payerUser.toJson());
        doReturn(benUser).doReturn(payerUser).when(instance).queryUserBySearchData(any(), any());

        SubscriptionResponse payerSub = CommonTestHelper.getEmptySubscriptionResponse();
        SubscriptionResponse benSub = CommonTestHelper.getEmptySubscriptionResponse_NoMainbalance();
        doReturn(benSub).doReturn(payerSub).when(instance).querySubscriptionByRQT(
                any(), any(), any());

        payerSub.getDeviceIdArrayAppender().add(new MtxObjectId("1-2-3-4"));
        MtxResponseDevice payerDevice = CommonTestHelper.getMtxResponseDevice_Default();
        printUnitTest(payerDevice.toJson());
        doReturn(payerDevice).when(instance).queryDeviceData(any(), any(), any());

        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        Exception exception = assertThrows(
                VisibleRechargeException.class, () -> instance.recharge(request, response));
        exception.printStackTrace();
        assertTrue(exception.getMessage().contains(LOG_MESSAGES.BENEFICIARY_HAS_NO_MAINBALANCE));
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_recharge_When_MidCycle_PurchanseServiceType_Then_PurchasePBLink")
    @Tag("VER-813")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Both Payer and Beneficiary have mainbalance.|"
                +"|When |Input has payerid & midcycle purchaseServiceType.|"
                +"|Then |PBLink offer should be purchased.|"
                +"|Comments |junit can not check events. So check multirequest inputs.|"})
    // @formatter:on
    public void test_recharge_When_MidCycle_PurchanseServiceType_Then_PurchasePBLink(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String benExternalId = "12345";
        String payerExternalId = "67890";
        String orderId = "O-12345";
        VisibleRequestRecharge request = CommonTestHelper.getVisibleRequestRecharge(
                benExternalId, payerExternalId, orderId, PURCHASE_SERVICE_TYPES.MID_CYCLE_CHANGE,
                List.of(CI_EXTERNAL_IDS.PLUS25));
        VisibleResponseRecharge response = new VisibleResponseRecharge();
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());

        SubscriptionResponse payerSub = CommonTestHelper.getEmptySubscriptionResponse(
                payerExternalId);
        SubscriptionResponse benSub = CommonTestHelper.getEmptySubscriptionResponse(benExternalId);
        benSub.getDeviceIdArrayAppender().add(new MtxObjectId("1-2-3-4"));
        doReturn(benSub).doReturn(payerSub).when(instance).querySubscriptionByRQT(
                any(), any(), any());

        MtxResponseDevice device = CommonTestHelper.getMtxResponseDevice_Default();
        doReturn(device).when(instance).queryDeviceData(any(), any(), any());

        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        instance.recharge(request, response);

        printUnitTest(response.toJson());
        MtxRequestMulti multi = argumentCaptor.getValue();
        printUnitTest(multi.toJson());
        assertEquals(
                MtxRequestSubscriberPurchaseOffer.class.getSimpleName(),
                multi.getAtRequestList(2).getContainer().getName());

        MtxRequestSubscriberPurchaseOffer reqPo = new MtxRequestSubscriberPurchaseOffer(
                multi.getAtRequestList(2));
        assertEquals(CI_EXTERNAL_IDS.PBLINK, reqPo.getAtOfferRequestArray(0).getExternalId());

        VisiblePurchasedOfferExtension attr = (VisiblePurchasedOfferExtension) reqPo.getAtOfferRequestArray(
                0).getAttr();
        assertEquals(benExternalId, attr.getBeneficiaryExternalId());
        assertEquals(orderId, attr.getOrderId());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_recharge_When_no_PurchanseServiceType_Then_NoPBLink")
    @Tag("VER-813")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Both Payer and Beneficiary have mainbalance.|"
                +"|When |Input has payerid & NO purchaseServiceType.|"
                +"|Then |PBLink offer should NOT be purchased.|"
                +"|Comments |junit can not check events. So check multirequest inputs.|"})
    // @formatter:on
    public void test_recharge_When_no_PurchanseServiceType_Then_NoPBLink(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String benExternalId = "12345";
        String payerExternalId = "67890";
        String orderId = "O-12345";
        VisibleRequestRecharge request = CommonTestHelper.getVisibleRequestRecharge(
                benExternalId, payerExternalId, orderId, List.of(CI_EXTERNAL_IDS.PLUS25));
        VisibleResponseRecharge response = new VisibleResponseRecharge();
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());

        SubscriptionResponse payerSub = CommonTestHelper.getEmptySubscriptionResponse(
                payerExternalId);
        SubscriptionResponse benSub = CommonTestHelper.getEmptySubscriptionResponse(benExternalId);
        benSub.getDeviceIdArrayAppender().add(new MtxObjectId("1-2-3-4"));
        doReturn(benSub).doReturn(payerSub).when(instance).querySubscriptionByRQT(
                any(), any(), any());

        MtxResponseDevice device = CommonTestHelper.getMtxResponseDevice_Default();
        doReturn(device).when(instance).queryDeviceData(any(), any(), any());

        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        instance.recharge(request, response);

        printUnitTest(response.toJson());
        MtxRequestMulti multi = argumentCaptor.getValue();
        printUnitTest(multi.toJson());
        multi.getRequestList().forEach(req -> {
            assertNotEquals(
                    MtxRequestSubscriberPurchaseOffer.class.getSimpleName(),
                    req.getContainer().getName());
        });

    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_recharge_When_PurchanseServiceType_RENEWAL_Then_NoPBLink")
    @Tag("VER-813")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Both Payer and Beneficiary have mainbalance.|"
                +"|When |Input has payerid & purchaseServiceType==Renewal.|"
                +"|Then |PBLink offer should NOT be purchased.|"
                +"|Comments |junit can not check events. So check multirequest inputs.|"})
    // @formatter:on
    public void test_recharge_When_PurchanseServiceType_RENEWAL_Then_NoPBLink(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String benExternalId = "12345";
        String payerExternalId = "67890";
        String orderId = "O-12345";
        VisibleRequestRecharge request = CommonTestHelper.getVisibleRequestRecharge(
                benExternalId, payerExternalId, orderId,
                PAYMENT_CONSTANTS.PURCHASE_SERVICE_TYPE_RENEWAL,
                List.of(CI_EXTERNAL_IDS.PLUS25));
        VisibleResponseRecharge response = new VisibleResponseRecharge();
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());

        SubscriptionResponse payerSub = CommonTestHelper.getEmptySubscriptionResponse(
                payerExternalId);
        SubscriptionResponse benSub = CommonTestHelper.getEmptySubscriptionResponse(benExternalId);
        benSub.getDeviceIdArrayAppender().add(new MtxObjectId("1-2-3-4"));
        doReturn(benSub).doReturn(payerSub).when(instance).querySubscriptionByRQT(
                any(), any(), any());

        MtxResponseDevice device = CommonTestHelper.getMtxResponseDevice_Default();
        doReturn(device).when(instance).queryDeviceData(any(), any(), any());

        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        instance.recharge(request, response);

        printUnitTest(response.toJson());
        MtxRequestMulti multi = argumentCaptor.getValue();
        printUnitTest(multi.toJson());
        multi.getRequestList().forEach(req -> {
            assertNotEquals(
                    MtxRequestSubscriberPurchaseOffer.class.getSimpleName(),
                    req.getContainer().getName());
        });

    }

    private void printUnitTest(Object msg) {
        System.out.println(testInfo.getDisplayName() + ":" + msg);
    }
}
