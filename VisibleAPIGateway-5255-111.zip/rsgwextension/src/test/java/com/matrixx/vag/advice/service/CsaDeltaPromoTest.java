package com.matrixx.vag.advice.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.doReturn;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import com.matrixx.datacontainer.MtxDate;
import com.matrixx.datacontainer.MtxObjectId;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.EventQueryEventInfo;
import com.matrixx.datacontainer.mdc.EventQueryResponseEvents;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.MtxRecurringEvent;
import com.matrixx.datacontainer.mdc.MtxResponseGroup;
import com.matrixx.datacontainer.mdc.MtxResponseOneTimeOffer;
import com.matrixx.datacontainer.mdc.MtxResponsePricingCatalogItem;
import com.matrixx.datacontainer.mdc.MtxResponsePurchase;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.PurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.SubscriptionResponse;
import com.matrixx.datacontainer.mdc.VisibleDeltaPromo;
import com.matrixx.datacontainer.mdc.VisibleOfferDetails;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleRequestChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleResponseChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleSubscriberExtension;
import com.matrixx.datacontainer.mdc.VisibleTemplate;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.advice.model.CreditStage;
import com.matrixx.vag.advice.model.GlobalCreditStage;
import com.matrixx.vag.advice.model.PromoOfferPair;
import com.matrixx.vag.advice.model.ServiceStage;
import com.matrixx.vag.advice.model.SubscriberGroup;
import com.matrixx.vag.common.Constants.CREDIT_CONSTANTS;
import com.matrixx.vag.common.Constants.GROUP_CONSTANTS;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestConstants.DATA_DIR;
import com.matrixx.vag.common.TestConstants.TAX_CLASS_CODES;
import com.matrixx.vag.common.OneParameterTest;
import com.matrixx.vag.common.TestUtils;
import com.matrixx.vag.common.TwoParameterTest;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.tax.client.TaxApiClient;
import com.matrixx.vag.tax.model.ServiceTaxRequest;
import com.matrixx.vag.tax.model.ServiceTaxResponse;
import com.matrixx.vag.util.MDCTest;

public class CsaDeltaPromoTest extends MDCTest {

    @Spy
    @InjectMocks
    private PaymentAdviceService instance = new PaymentAdviceService();

    @Mock
    private SubscriberManagementApi api;
    
    private TestInfo testInfo;
    
    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        instance = new PaymentAdviceService();
        MockitoAnnotations.openMocks(this);
        doReturn("").when(instance).getRoute(any());
        this.testInfo = testInfo;
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-480")
    @Test
    public void test_getChangeServiceAdvice_When_DeltaCreditsAvailable_As_Consumables_Then_ResponseHasDeltaCredits(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service.", "Referral Credits available",
            "Some referral credits are consumable.", "PaidCycleStartDate is in past.",
        };
        td.when = new String[] {
            "Api is called for annual upgrade.", "Change delta is eligible for referral credits."
        };
        td.then = new String[] {
            "Advice should show referral credits in change cycle.",
            "Grants should assume that consuptions are reversed."
        };
        td.comments = new String[] {
            "VER-480"
        };
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            String promoGrantOffer = tCase.promoMap.get("GRANT_CI").toString();
            BigDecimal promoGrantAmount = (BigDecimal) tCase.promoMap.get("GRANT_AMOUNT");
            BigDecimal promoDollarAmount = (BigDecimal) tCase.promoMap.get("DOLLAR_AMOUNT");

            Map<String, MtxResponsePricingCatalogItem> ciPricingMap = emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(
                            tCase.oldCi, request.getNewCatalogItemExternalId(), promoGrantOffer));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            if (tCase.paidCycleStartDate != null) {
                poExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            }
            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                            promoGrantOffer, promoGrantAmount));
            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoConsumable(
                            promoGrantOffer, promoDollarAmount));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchase(
                    tCase.newCi, aocAmount);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());
            doReturn(deltaAocResp).when(instance).getAocCurrencyBalanceImpactInfo(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            /********************** Mock PaymentAdvice ****************************/
            AdviceDataStage aopStage = new AdviceDataStage(
                    subscription, AdviceDataStage.Advice.PAYMENT, null, false);

            ServiceStage ss = new ServiceStage(tCase.oldCi);

            VisibleTemplate vtRef20 = (VisibleTemplate) ciPricingMap.get(
                    promoGrantOffer).getCatalogItemInfo().getTemplateAttr();
            GlobalCreditStage gcsRef20 = new GlobalCreditStage(promoGrantOffer, vtRef20);
            gcsRef20.setPromotionName(vtRef20.getPromotionName());
            gcsRef20.setAvailableCredits(promoGrantAmount.add(promoDollarAmount));
            gcsRef20.setAvailableCreditsConsumable(promoDollarAmount);
            gcsRef20.setAvailableCreditsGrant(promoGrantAmount);
            gcsRef20.setRedeemOfferCi(vtRef20.getRedeemOffer());
            gcsRef20.setApplicableCiCsv(vtRef20.getApplicableOfferName() + "," + tCase.oldCi); // 20240320-
                                                                                               // As
                                                                                               // per

            CreditStage csRef20 = new CreditStage(gcsRef20, tCase.oldCi);
            csRef20.setApplicableServiceStage(ss);

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.getCreditMap().put(
                    new PromoOfferPair(tCase.oldCi, csRef20.getPromotionName()), csRef20);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());
            /********************** Mock PaymentAdvice ****************************/

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");
            MtxPurchasedOfferInfo poiRef20Redeem = CommonTestHelper.getMtxPurchasedOfferInfo(
                    CI_EXTERNAL_IDS.REF20_REDEEM, promoDollarAmount, true);
            poiRef20Redeem.setResourceId(55L);
            emulateMtxResponseOneTimeOffer(instance, poiRef20Redeem);

            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            assertNotNull(
                    response.getNextCycle(),
                    "Ref-20 is applicable to BASE3VISIBLE23A. Change assertion if assumption is incorrect.");
            assertTrue(response.getNextCycle().getReverseCredits() != null);
            assertEquals(
                    promoDollarAmount.doubleValue(), response.getNextCycle().getAtReverseCredits(
                            0).getAvailableCreditsConsumable().doubleValue());
            assertEquals(
                    response.getChangeCycle().getAtCredits(0).getRedeemableCredits(),
                    response.getChangeCycle().getAtCredits(0).getEstimatedTransferableCredits(),
                    "If redeem equals transferable, all consumptions are reversed and are part of grants.");
        };

        String subscriptionExternalId = "123";

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3ANNUAL));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId(subscriptionExternalId);

        VisibleDeltaPromo csp = new VisibleDeltaPromo();
        csp.setClassCode(TAX_CLASS_CODES.REF20);
        csp.setDeltaPromotionLimit(BigDecimal.valueOf(40));
        requestUp.appendDeltaPromotionList(csp);

        TestConditions chgUp = new TestConditions() {

            {
                newCi = requestUp.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE3ANNUAL;
                paidCycleStartDate = TestUtils.getFirstDateOfCurrentMonth();
            }
        };
        chgUp.promoMap.put("GRANT_CI", CI_EXTERNAL_IDS.REF20_GRANT);
        chgUp.promoMap.put("GRANT_AMOUNT", BigDecimal.valueOf(150));
        chgUp.promoMap.put("DOLLAR_AMOUNT", BigDecimal.valueOf(50));
        pTests.test(requestUp, chgUp);
    }

    @Test
    public void test_getChangeServiceAdvice_When_CreditsApplicable_Delta_And_ASIS_PaidCycleStartDate_In_Future_Then_ResponseHasDeltaCredits(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service.", "Referral Credits available",
            "Some referral credits are consumable.",
            "Referral Credits ARE applicable to Enrolled offer (BASE3VISIBLE23A)",
            "Referral Credits are applicable to Delta", "PaidCycleStartDate is in future.",
        };
        td.when = new String[] {
            "Api is called for annual upgrade.", "Change delta is eligible for referral credits."
        };
        td.then = new String[] {
            "Advice should show referral credits in change cycle.",
            "Grants should assume that consuptions are reversed."
        };
        td.comments = new String[] {
            "VER-480", "Need pricing change to test on server."
        };
        @SuppressWarnings("unchecked")
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            String promoGrantOffer = tCase.promoMap.get("GRANT_CI").toString();
            BigDecimal promoGrantAmount = (BigDecimal) tCase.promoMap.get("GRANT_AMOUNT");
            BigDecimal promoDollarAmount = (BigDecimal) tCase.promoMap.get("DOLLAR_AMOUNT");

            Map<String, MtxResponsePricingCatalogItem> ciPricingMap = emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(
                            tCase.oldCi, request.getNewCatalogItemExternalId(), promoGrantOffer));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            if (tCase.paidCycleStartDate != null) {
                poExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            }
            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                            promoGrantOffer, promoGrantAmount));
            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoConsumable(
                            promoGrantOffer, promoDollarAmount));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchase(
                    tCase.newCi, aocAmount);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());
            doReturn(deltaAocResp).when(instance).getAocCurrencyBalanceImpactInfo(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            /********************** Mock PaymentAdvice ****************************/
            AdviceDataStage aopStage = new AdviceDataStage(
                    subscription, AdviceDataStage.Advice.PAYMENT, null, false);

            ServiceStage ss = new ServiceStage(tCase.oldCi);

            VisibleTemplate vtRef20 = (VisibleTemplate) ciPricingMap.get(
                    promoGrantOffer).getCatalogItemInfo().getTemplateAttr();
            GlobalCreditStage gcsRef20 = new GlobalCreditStage(promoGrantOffer, vtRef20);
            gcsRef20.setPromotionName(vtRef20.getPromotionName());
            gcsRef20.setAvailableCredits(promoGrantAmount.add(promoDollarAmount));
            gcsRef20.setAvailableCreditsConsumable(promoDollarAmount);
            gcsRef20.setAvailableCreditsGrant(promoGrantAmount);
            gcsRef20.setRedeemOfferCi(vtRef20.getRedeemOffer());
            gcsRef20.setApplicableCiCsv(vtRef20.getApplicableOfferName() + "," + tCase.oldCi);
            CreditStage csRef20 = new CreditStage(gcsRef20, tCase.oldCi);
            csRef20.setApplicableServiceStage(ss);

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.getCreditMap().put(
                    new PromoOfferPair(tCase.oldCi, csRef20.getPromotionName()), csRef20);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());
            /********************** Mock PaymentAdvice ****************************/

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");
            MtxPurchasedOfferInfo poiRef20Redeem = CommonTestHelper.getMtxPurchasedOfferInfo(
                    CI_EXTERNAL_IDS.REF20_REDEEM, promoDollarAmount, true);
            poiRef20Redeem.setResourceId(55L);
            emulateMtxResponseOneTimeOffer(instance, poiRef20Redeem);

            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            assertTrue(response.getNextCycle() != null);
            assertTrue(response.getNextCycle().getReverseCredits() != null);
            assertEquals(
                    promoDollarAmount.doubleValue(), response.getNextCycle().getAtReverseCredits(
                            0).getAvailableCreditsConsumable().doubleValue());
            assertEquals(
                    response.getChangeCycle().getAtCredits(0).getRedeemableCredits(),
                    response.getChangeCycle().getAtCredits(0).getEstimatedTransferableCredits(),
                    "If redeem equals transferable, all consumptions are reversed and are part of grants.");
        };

        String subscriptionExternalId = "123";

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3ANNUAL));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId(subscriptionExternalId);

        VisibleDeltaPromo csp = new VisibleDeltaPromo();
        csp.setClassCode(TAX_CLASS_CODES.REF20);
        csp.setDeltaPromotionLimit(BigDecimal.valueOf(40));
        requestUp.appendDeltaPromotionList(csp);

        TestConditions chgUp = new TestConditions() {

            {
                newCi = requestUp.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE3ANNUAL;
                paidCycleStartDate = TestUtils.getFirstDateOfNextMonth();
            }
        };
        chgUp.promoMap.put("GRANT_CI", CI_EXTERNAL_IDS.REF20_GRANT);
        chgUp.promoMap.put("GRANT_AMOUNT", BigDecimal.valueOf(150));
        chgUp.promoMap.put("DOLLAR_AMOUNT", BigDecimal.valueOf(50));
        pTests.test(requestUp, chgUp);
    }
    
    @ParameterizedTest(
            name = "test_getChangeServiceAdvice_Given_HasPayer_When_DeltaWithPromo_Then_PromoTaxWithPayerGeoDocde")
    @Tag("Tax")
    @Tag("VER-772")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscriber gets paid by payer for recurring services.|"
                +"|     |Subscriber has BASE3VISIBLE23.|"
                +"|When |CSA called. for upgrade to PLUS4VIS25WB or PLUS4VIS25WBA or PPLUS1VIS25WB or PPLUS1VIS25WBA|"
                +"|     |Delta eligible for promo|"
                +"|Then |CSA should call taxapi with payers geocode for promos.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_Given_HasPayer_When_DeltaWithPromo_Then_PromoTaxWithPayerGeoDocde(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        String payerGeoCode = "ELBISIVNOZIREV";
        String payerExternalID = "67890";
        String oldCi = CI_EXTERNAL_IDS.BASE3VIS23;
        String promoGrantOffer = CI_EXTERNAL_IDS.GRANT_GOODWILL;
        BigDecimal promoGrant = BigDecimal.TEN;
        @SuppressWarnings("unchecked")
        OneParameterTest pTests = (req) -> {
            td.printDescription();
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxObjectId caGroupId = new MtxObjectId("1-2-3-4");
            SubscriptionResponse benSubResp = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            request.getSubscriptionExternalId(), List.of(oldCi)));
            benSubResp.getParentGroupIdArrayAppender().add(caGroupId);
            benSubResp.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoGrant(promoGrantOffer, promoGrant));

            MtxDate paidCycleStartDate = TestUtils.getMtxDateFromMtxTimestamp(
                    benSubResp.getBillingCycle().getCurrentPeriodStartTime());

            MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription(
                    request.getSubscriptionExternalId(), List.of(oldCi));
            benSub.getParentGroupIdArrayAppender().add(caGroupId);
            benSub.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoGrant(promoGrantOffer, promoGrant));

            MtxResponseSubscription paySub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                    payerExternalID);
            paySub.getParentGroupIdArrayAppender().add(caGroupId);
            VisibleSubscriberExtension attr = (VisibleSubscriberExtension) paySub.getAttr();
            attr.setGeoCode(payerGeoCode);
            doReturn(benSub).doReturn(paySub).when(api).subscriptionQuery(any());

            Map<String, MtxResponsePricingCatalogItem> ciPricingMap = emulateMtxResponsePricingCatalogItems(
                    instance,
                    List.of(
                            oldCi.toString(), promoGrantOffer,
                            request.getNewCatalogItemExternalId()));

            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponseMulti_For_CreditBalances(benSubResp));

            doReturn("[" + request.getSubscriptionExternalId() + "]").when(instance).getLoggingKey(
                    any());
            BigDecimal aocAmount = BigDecimal.valueOf(20);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), aocAmount, null, null, false);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            /********************** Mock PaymentAdvice ****************************/
            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    oldCi, paidCycleStartDate);

            AdviceDataStage aopStage = new AdviceDataStage(
                    benSubResp, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(benSubResp));
            
            ServiceStage ss = new ServiceStage(oldCi.toString());
            VisibleTemplate vtGoodwill = (VisibleTemplate) ciPricingMap.get(
                    promoGrantOffer).getCatalogItemInfo().getTemplateAttr();
            GlobalCreditStage gcsGoodwill = new GlobalCreditStage(promoGrantOffer, vtGoodwill);
            gcsGoodwill.setPromotionName(vtGoodwill.getPromotionName());
            gcsGoodwill.setAvailableCredits(promoGrant);
            gcsGoodwill.setAvailableCreditsConsumable(BigDecimal.ZERO);
            gcsGoodwill.setAvailableCreditsGrant(promoGrant);
            gcsGoodwill.setRedeemOfferCi(vtGoodwill.getRedeemOffer());
            gcsGoodwill.setApplicableCiCsv(vtGoodwill.getApplicableOfferName() + "," + oldCi);
            CreditStage csGoodwill = new CreditStage(gcsGoodwill, oldCi);
            csGoodwill.setApplicableServiceStage(ss);
            aopStage.getCreditMap().put(
                    new PromoOfferPair(oldCi, csGoodwill.getPromotionName()), csGoodwill);
            
            MtxResponseGroup respGrp = CommonTestHelper.getMtxResponseGroupCA(
                    benSub.getExternalId(), "CAGroup",
                    List.of(benSub.getObjectId().toString(), "1-2-3-4", "6-7-8-9"),
                    List.of(
                            String.format(
                                    GROUP_CONSTANTS.CA_LINK_FORMAT, benSub.getExternalId(),
                                    payerExternalID)));

            SubscriberGroup sg = new SubscriberGroup(respGrp);
            aopStage.appendSubscriberGroupList(sg);
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());
            /********************** Mock PaymentAdvice ****************************/
            
            ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                String taxRespString = CommonTestHelper.getTaxApiResp(
                      request.getNewCatalogItemExternalId());
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(
                                any(), argumentCaptor.capture())).thenReturn(
                                        taxRespChangeCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            argumentCaptor.getAllValues().forEach(taxReq -> {
                System.out.println(td.getTestMethod() + ":" + taxReq);
            });
            ServiceTaxRequest deltaTaxReq = CommonTestHelper.getJsonFromString(
                    ServiceTaxRequest.class, argumentCaptor.getAllValues().get(1));
            assertEquals(payerGeoCode, deltaTaxReq.getGeocode());
            assertTrue(deltaTaxReq.getMsgID().contains("Payer:" + payerExternalID));

        };
        String subscriptionExternalId = "12345";
        VisibleRequestChangeServiceAdvice request = CommonTestHelper.getVisibleRequestChangeServiceAdvice(
                subscriptionExternalId, CI_EXTERNAL_IDS.PLUS25);
        VisibleDeltaPromo csp = new VisibleDeltaPromo();
        csp.setClassCode(TAX_CLASS_CODES.GOODWILL);
        csp.setDeltaPromotionLimit(BigDecimal.valueOf(40));
        request.appendDeltaPromotionList(csp);

        pTests.test(request);
    }
}
