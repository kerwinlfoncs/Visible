package com.matrixx.vag.device.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatchers;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.slf4j.event.LoggingEvent;

import com.matrixx.datacontainer.MtxObjectId;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.EventQueryResponseEvents;
import com.matrixx.datacontainer.mdc.MtxPricingAttrInfo;
import com.matrixx.datacontainer.mdc.MtxPurchaseEvent;
import com.matrixx.datacontainer.mdc.MtxRechargeEvent;
import com.matrixx.datacontainer.mdc.MtxRequest;
import com.matrixx.datacontainer.mdc.MtxRequestMulti;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberAdjustBalance;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberModify;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberPurchaseOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberRecharge;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberRefundPayment;
import com.matrixx.datacontainer.mdc.MtxResponseCreate;
import com.matrixx.datacontainer.mdc.MtxResponseDevice;
import com.matrixx.datacontainer.mdc.MtxResponseMulti;
import com.matrixx.datacontainer.mdc.MtxResponsePaymentHistory;
import com.matrixx.datacontainer.mdc.MtxResponsePricingOffer;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.VisibleBraintreeChargeMethodExtension;
import com.matrixx.datacontainer.mdc.VisibleFraudHomeAddress;
import com.matrixx.datacontainer.mdc.VisibleFraudShippingAddress;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleRechargeExtension;
import com.matrixx.datacontainer.mdc.VisibleRequestCancelDeviceSwap;
import com.matrixx.datacontainer.mdc.VisibleRequestChargeNrf;
import com.matrixx.datacontainer.mdc.VisibleRequestDeviceSwap;
import com.matrixx.datacontainer.mdc.VisibleRequestPurchaseDevice;
import com.matrixx.datacontainer.mdc.VisibleRequestReturnFinancedDevice;
import com.matrixx.datacontainer.mdc.VisibleRequestReturnPurchasedDevice;
import com.matrixx.datacontainer.mdc.VisibleRequestReverseNrf;
import com.matrixx.datacontainer.mdc.VisibleResponseCancelDeviceSwap;
import com.matrixx.datacontainer.mdc.VisibleResponseChargeNrf;
import com.matrixx.datacontainer.mdc.VisibleResponseDeviceSwap;
import com.matrixx.datacontainer.mdc.VisibleResponsePurchaseDevice;
import com.matrixx.datacontainer.mdc.VisibleResponseReturnFinancedDevice;
import com.matrixx.datacontainer.mdc.VisibleResponseReturnPurchasedDevice;
import com.matrixx.datacontainer.mdc.VisibleResponseReverseNrf;
import com.matrixx.datacontainer.mdc.VisibleSubscriberExtension;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.DEVICE_CONSTANTS;
import com.matrixx.vag.common.TestConstants.DATA_DIR;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.DeviceServiceException;
import com.matrixx.vag.exception.IntegrationServiceException;
import com.matrixx.vag.exception.InvalidRequestParameterException;
import com.matrixx.vag.exception.VisibleUnitTestException;
import com.matrixx.vag.util.MDCTest;

public class DeviceServiceTest extends MDCTest {

	@Spy
	@InjectMocks
	private DeviceService instance = new DeviceService();

	@Mock
	private SubscriberManagementApi api;

	@Captor
	private ArgumentCaptor<LoggingEvent> captorLoggingEvent;

	@Before
	public void setUp() throws Exception {
		instance = new DeviceService();
		 MockitoAnnotations.openMocks(this); 

		AppPropertyProvider.getInstance();
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_purchaseDevice_ValidRequestValidMatrixxData_PurchaseSuccess() throws Exception {
		VisibleRequestPurchaseDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestPurchaseDevice.class,
				DATA_DIR.PURCHASED_DEVICE + "VisibleRequestPurchaseDevice_ValidSimpleRequest.json");

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.PURCHASED_DEVICE + "MtxResponseMulti.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.PURCHASED_DEVICE + "MtxResponseSubscriber.json");
		VisibleResponsePurchaseDevice deviceOut = new VisibleResponsePurchaseDevice();
		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
		// method to test
		deviceIn.getPurchaseOrderInfo().setDeferredSettlement("Y");
		instance.purchaseDevice(deviceIn, deviceOut);
		// Assertions here.
		assertEquals("0", String.valueOf(deviceOut.getResult()));
		assertEquals("OK", deviceOut.getResultText());
		assertEquals(
				ZonedDateTime.now()
						.plusDays(AppPropertyProvider.getInstance()
								.getLong(DEVICE_CONSTANTS.DEVICE_DIRECT_PURCHASE_PAY_AUTH_EXPIRY))
						.format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssZ")),
				deviceOut.getPaymentAuthorizationExpiryTime());
		assertEquals(
				multiRes.getResponseList().stream()
						.filter(resp -> resp.getMdcName().equals(MtxResponseCreate.class.getSimpleName()))
						.map(resp -> ((MtxResponseCreate) resp).getObjectId()).toArray()[0].toString(),
				deviceOut.getDeviceInstanceId().toString());
		MtxRequestMulti request = argumentCaptor.getAllValues().get(0);
		MtxRequestSubscriberPurchaseOffer purchaseOffer = (MtxRequestSubscriberPurchaseOffer) request.getRequestList()
				.get(4);
		VisibleBraintreeChargeMethodExtension braintreeChargeMethodExtension = (VisibleBraintreeChargeMethodExtension) purchaseOffer
				.getChargeMethodData().getChargeMethodAttr();
		assertEquals(deviceIn.getPurchaseFraudInfo().getPaymentGatewayAttributes().get(0).getValue(),
				braintreeChargeMethodExtension.getSiteId());
		assertEquals(deviceIn.getPurchaseFraudInfo().getTransactionType(),
				braintreeChargeMethodExtension.getTransactionType());

	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_purchaseDevice_NullMultiResponse_DeviceServiceException() throws Exception {

		VisibleRequestPurchaseDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestPurchaseDevice.class,
				DATA_DIR.PURCHASED_DEVICE + "VisibleRequestPurchaseDevice_ValidSimpleRequest.json");
		VisibleResponsePurchaseDevice deviceOut = new VisibleResponsePurchaseDevice();

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.PURCHASED_DEVICE + "MtxResponseSubscriber.json");

		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		doReturn(null).when(instance).multiRequest(any(), any(), any());
		
        Exception exception = assertThrows(DeviceServiceException.class, () -> instance.purchaseDevice(deviceIn, deviceOut));
        exception.printStackTrace();
        assertEquals("Failed to purchase device",exception.getMessage().trim());
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_purchaseDevice_ErrorMultiResponse_DeviceServiceException() throws Exception {

		VisibleRequestPurchaseDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestPurchaseDevice.class,
				DATA_DIR.PURCHASED_DEVICE + "VisibleRequestPurchaseDevice_ValidSimpleRequest.json");
		VisibleResponsePurchaseDevice deviceOut = new VisibleResponsePurchaseDevice();

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.PURCHASED_DEVICE + "MtxResponseMultiErrorResponse.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.PURCHASED_DEVICE + "MtxResponseSubscriber.json");

		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		doReturn(multiRes).when(instance).multiRequest(any(), any(), any());
		
	    Exception exception = assertThrows(DeviceServiceException.class, () -> instance.purchaseDevice(deviceIn, deviceOut));
	    exception.printStackTrace();
	    assertThat(exception.getMessage()).contains("Failed to purchase device");
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_purchaseDevice_NoSubscriberData_DeviceServiceException() throws Exception {
		VisibleRequestPurchaseDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestPurchaseDevice.class,
				DATA_DIR.PURCHASED_DEVICE + "VisibleRequestPurchaseDevice_ValidSimpleRequest.json");
		VisibleResponsePurchaseDevice deviceOut = new VisibleResponsePurchaseDevice();

		doReturn("").when(instance).getRoute(any());
		doReturn(null).when(instance).querySubscriptionData(any(), any());
		
	    Exception exception = assertThrows(DeviceServiceException.class, () -> instance.purchaseDevice(deviceIn, deviceOut));
	    exception.printStackTrace();
	    assertThat(exception.getMessage()).contains("Failed to query subscriber");
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_PurchaseDevice_ValidRequestValidMatrixxData_DistinctTimestamps() throws Exception {
		// Test case to check that 3 info timestamps are different
		VisibleRequestPurchaseDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestPurchaseDevice.class,
				DATA_DIR.PURCHASED_DEVICE + "VisibleRequestPurchaseDevice_ValidSimpleRequest.json");

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.PURCHASED_DEVICE + "MtxResponseMulti.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.PURCHASED_DEVICE + "MtxResponseSubscriber.json");
		VisibleResponsePurchaseDevice deviceOut = new VisibleResponsePurchaseDevice();
		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
		// method to test
		instance.purchaseDevice(deviceIn, deviceOut);

		// Assertions here.
		ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();

		String deviceTimestamp;
		String shippingTimestamp;

		deviceTimestamp = reqList.stream().filter(req -> req.getMdcName().equals("MtxRequestSubscriberPurchaseOffer"))
				.map(req -> ((VisiblePurchasedOfferExtension) ((MtxRequestSubscriberPurchaseOffer) req)
						.getOfferRequestArray().get(0).getAttr()))
				.filter(vpoXtn -> vpoXtn.getGoodType() != null && vpoXtn.getGoodType().equals("purchase_device"))
				.map(vpoXtn -> vpoXtn.getInfo()).findFirst().get();
		shippingTimestamp = reqList.stream().filter(req -> req.getMdcName().equals("MtxRequestSubscriberPurchaseOffer"))
				.map(req -> ((VisiblePurchasedOfferExtension) ((MtxRequestSubscriberPurchaseOffer) req)
						.getOfferRequestArray().get(0).getAttr()))
				.filter(vpoXtn -> vpoXtn.getGoodType() != null && vpoXtn.getGoodType().equals("purchase_shipping"))
				.map(vpoXtn -> vpoXtn.getInfo()).findFirst().get();
		assertNotEquals(deviceTimestamp, shippingTimestamp);
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_PurchaseDevice_CorrectRSGatewayProperties_GoodTypesAsExpected() throws Exception {
		// Test case to check that GoodTypes are populated correctly
		VisibleRequestPurchaseDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestPurchaseDevice.class,
				DATA_DIR.PURCHASED_DEVICE + "VisibleRequestPurchaseDevice_ValidSimpleRequest.json");

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.PURCHASED_DEVICE + "MtxResponseMulti.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.PURCHASED_DEVICE + "MtxResponseSubscriber.json");
		VisibleResponsePurchaseDevice deviceOut = new VisibleResponsePurchaseDevice();
		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
		// method to test
		instance.purchaseDevice(deviceIn, deviceOut);

		// Assertions here.
		ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();

		String deviceGoodtype;
		String shippingGoodtype;

		deviceGoodtype = reqList.stream().filter(req -> req.getMdcName().equals("MtxRequestSubscriberPurchaseOffer"))
				.map(req -> ((VisiblePurchasedOfferExtension) ((MtxRequestSubscriberPurchaseOffer) req)
						.getOfferRequestArray().get(0).getAttr()))
				.filter(vpoXtn -> vpoXtn.getGoodType() != null && vpoXtn.getGoodType().equals("purchase_device"))
				.map(vpoXtn -> vpoXtn.getGoodType()).findFirst().get();
		shippingGoodtype = reqList.stream().filter(req -> req.getMdcName().equals("MtxRequestSubscriberPurchaseOffer"))
				.map(req -> ((VisiblePurchasedOfferExtension) ((MtxRequestSubscriberPurchaseOffer) req)
						.getOfferRequestArray().get(0).getAttr()))
				.filter(vpoXtn -> vpoXtn.getGoodType() != null && vpoXtn.getGoodType().equals("purchase_shipping"))
				.map(vpoXtn -> vpoXtn.getGoodType()).findFirst().get();

		assertNotNull(deviceGoodtype);
		assertEquals("purchase_device", deviceGoodtype);
		assertNotNull(shippingGoodtype);
		assertEquals("purchase_shipping", shippingGoodtype);
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_PurchaseDevice_ValidRequestValidMatrixxData_AmountPrecisionBraintree() throws Exception {
		// Test case to check that Reasons are populated correctly
		VisibleRequestPurchaseDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestPurchaseDevice.class,
				DATA_DIR.PURCHASED_DEVICE + "VisibleRequestPurchaseDevice_ValidSimpleRequest.json");

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.PURCHASED_DEVICE + "MtxResponseMulti.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.PURCHASED_DEVICE + "MtxResponseSubscriber.json");

		VisibleResponsePurchaseDevice deviceOut = new VisibleResponsePurchaseDevice();
		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
		// method to test
		instance.purchaseDevice(deviceIn, deviceOut);

		// Assertions here.
		ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();

		int deviceAmountScale, shippingAmountScale, deviceIndex, shippingIndex;

		if (reqList.get(reqList.size() - 1).getMdcName().equals(MtxRequestSubscriberModify.class.getSimpleName())) {
			deviceIndex = reqList.size() - 3;
			shippingIndex = reqList.size() - 2;
		} else {
			deviceIndex = reqList.size() - 2;
			shippingIndex = reqList.size() - 1;
		}

		deviceAmountScale = ((VisiblePurchasedOfferExtension) (((MtxRequestSubscriberPurchaseOffer) reqList
				.get(deviceIndex)).getAtOfferRequestArray(0).getAttr())).getChargeAmount().scale();
		shippingAmountScale = ((VisiblePurchasedOfferExtension) (((MtxRequestSubscriberPurchaseOffer) reqList
				.get(shippingIndex)).getAtOfferRequestArray(0).getAttr())).getChargeAmount().scale();

		assertEquals(2, deviceAmountScale);
		assertEquals(2, shippingAmountScale);
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_PurchaseDevice_BraintreeCalled_VisibleRecurringOverrideEqTrue() throws Exception {

		VisibleRequestPurchaseDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestPurchaseDevice.class,
				DATA_DIR.PURCHASED_DEVICE + "VisibleRequestPurchaseDevice_ValidSimpleRequest.json");

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.PURCHASED_DEVICE + "MtxResponseMulti.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.PURCHASED_DEVICE + "MtxResponseSubscriber.json");
		VisibleResponsePurchaseDevice deviceOut = new VisibleResponsePurchaseDevice();
		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
		// method to test
		instance.purchaseDevice(deviceIn, deviceOut);

		// Assertions here.
		ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();

		VisibleBraintreeChargeMethodExtension shippingXtn = reqList.stream()
				.filter(req -> req.getMdcName().equals(MtxRequestSubscriberPurchaseOffer.class.getSimpleName()))
				.map(req -> ((MtxRequestSubscriberPurchaseOffer) req))
				.filter(purReq -> ((VisiblePurchasedOfferExtension) purReq.getAtOfferRequestArray(0).getAttr())
						.getGoodType() != null)
				.filter(purReq -> ((VisiblePurchasedOfferExtension) purReq.getAtOfferRequestArray(0).getAttr())
						.getGoodType().equals("purchase_shipping"))
				.map(purReq -> ((VisibleBraintreeChargeMethodExtension) purReq.getChargeMethodData()
						.getChargeMethodAttr()))
				.findFirst().get();

		VisibleBraintreeChargeMethodExtension deviceXtn = reqList.stream()
				.filter(req -> req.getMdcName().equals(MtxRequestSubscriberPurchaseOffer.class.getSimpleName()))
				.map(req -> ((MtxRequestSubscriberPurchaseOffer) req))
				.filter(purReq -> ((VisiblePurchasedOfferExtension) purReq.getAtOfferRequestArray(0).getAttr())
						.getGoodType() != null)
				.filter(purReq -> ((VisiblePurchasedOfferExtension) purReq.getAtOfferRequestArray(0).getAttr())
						.getGoodType().equals("purchase_device"))
				.map(purReq -> ((VisibleBraintreeChargeMethodExtension) purReq.getChargeMethodData()
						.getChargeMethodAttr()))
				.findFirst().get();

		assertEquals(
				StringUtils.isEmpty(deviceIn.getPurchaseOrderInfo().getVisibleRecurringOverride()) ? false
						: deviceIn.getPurchaseOrderInfo().getVisibleRecurringOverride().equalsIgnoreCase("Y"),
				deviceXtn.getVisibleRecurringOverride());
		assertEquals(
				StringUtils.isEmpty(deviceIn.getPurchaseOrderInfo().getVisibleRecurringOverride()) ? false
						: deviceIn.getPurchaseOrderInfo().getVisibleRecurringOverride().equalsIgnoreCase("Y"),
				shippingXtn.getVisibleRecurringOverride());
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnPurchasedDevice_ValidRequestValidMatrixxData_ReturnSuccess() throws Exception {

		VisibleRequestReturnPurchasedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnPurchasedDevice.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json");
		VisibleResponseReturnPurchasedDevice deviceOut = new VisibleResponseReturnPurchasedDevice();
		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponseMulti_ReturnPurchasedDevice.json");
		MtxResponsePricingOffer pricingOfferDevice = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Device.json");
		MtxResponsePricingOffer pricingOfferShipping = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Shipping.json");
		MtxResponsePaymentHistory subPayHistory = CommonTestHelper.loadJsonMessage(MtxResponsePaymentHistory.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePaymentHistory.json");
		MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "EventQueryResponseEvents_SimpleValid.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponseSubscriber_refundService.json");

		doReturn("").when(instance).getRoute(any());

		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());

		doReturn(pricingOfferDevice).doReturn(pricingOfferShipping).when(instance).queryPricingOffer(any(), any(),
				any());

		doReturn(subPayHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());
		doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);

		when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);
			instance.returnPurchasedDevice(deviceIn, deviceOut);

			MtxRequestMulti capturedRequest = argumentCaptor.getValue();
			MtxRequestSubscriberRefundPayment refundPaymentRequest = null;
			for (MtxRequest mtxRequest : capturedRequest.getRequestList()) {
				if (mtxRequest instanceof MtxRequestSubscriberRefundPayment) {
					refundPaymentRequest = (MtxRequestSubscriberRefundPayment) mtxRequest;
				}
			}
			assertNotNull(refundPaymentRequest);
			assertEquals("$Reversal GUW0:1:52:2795", refundPaymentRequest.getInfo());

			assertEquals("0", String.valueOf(deviceOut.getResult()));
			assertEquals("OK", String.valueOf(deviceOut.getResultText()));
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnPurchasedDevice_ErrorMultiResponse_DeviceServiceException() throws Exception {

		VisibleRequestReturnPurchasedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnPurchasedDevice.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json");
		VisibleResponseReturnPurchasedDevice deviceOut = new VisibleResponseReturnPurchasedDevice();
		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponseMulti_ReturnPurchasedDeviceError.json");

		MtxResponsePricingOffer pricingOfferDevice = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Device.json");
		MtxResponsePricingOffer pricingOfferShipping = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Shipping.json");
		MtxResponsePaymentHistory subPayHistory = CommonTestHelper.loadJsonMessage(MtxResponsePaymentHistory.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePaymentHistory.json");
		MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "EventQueryResponseEvents_SimpleValid.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponseSubscriber_refundService.json");

		doReturn("").when(instance).getRoute(any());

		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		when(mockConfig.getBoolean(any(), any())).thenReturn(true);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferDevice).doReturn(pricingOfferShipping).when(instance).queryPricingOffer(any(), any(),
				any());
		doReturn(subPayHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());
		doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
		when(api.multi(any(), any())).thenReturn(multiRes);
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			
		    Exception exception = assertThrows(DeviceServiceException.class, () -> instance.returnPurchasedDevice(deviceIn, deviceOut));
		    exception.printStackTrace();
		    assertThat(exception.getMessage()).contains("Failed to return purchased device");
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnPurchasedDevice_NullMultiResponse_DeviceServiceException() throws Exception {

		VisibleRequestReturnPurchasedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnPurchasedDevice.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json");
		VisibleResponseReturnPurchasedDevice deviceOut = new VisibleResponseReturnPurchasedDevice();
		MtxResponsePricingOffer pricingOfferDevice = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Device.json");
		MtxResponsePricingOffer pricingOfferShipping = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Shipping.json");
		MtxResponsePaymentHistory subPayHistory = CommonTestHelper.loadJsonMessage(MtxResponsePaymentHistory.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePaymentHistory.json");
		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "EventQueryResponseEvents_SimpleValid.json");
		MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponseSubscriber_refundService.json");

		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferDevice).doReturn(pricingOfferShipping).when(instance).queryPricingOffer(any(), any(),
				any());
		doReturn(subPayHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());
		doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
		doReturn(null).when(instance).multiRequest(any(), any(), any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);

		    Exception exception = assertThrows(DeviceServiceException.class, () -> instance.returnPurchasedDevice(deviceIn, deviceOut));
		    exception.printStackTrace();
		    assertThat(exception.getMessage()).contains("Failed to return purchased device");	
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnPurchasedDevice_OrderIdMissMatch_DeviceServiceException() throws Exception {

		VisibleRequestReturnPurchasedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnPurchasedDevice.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json");
		VisibleResponseReturnPurchasedDevice deviceOut = new VisibleResponseReturnPurchasedDevice();
		MtxResponsePricingOffer pricingOfferDevice = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Device.json");
		MtxResponsePricingOffer pricingOfferShipping = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Shipping.json");

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "EventQueryResponseEvents_IncorrectOrderId.json");

		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		when(api.pricingQueryOffer(any(), any())).thenReturn(pricingOfferDevice).thenReturn(pricingOfferShipping);

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);

		    Exception exception = assertThrows(DeviceServiceException.class, () -> instance.returnPurchasedDevice(deviceIn, deviceOut));
		    exception.printStackTrace();
		    assertThat(exception.getMessage()).contains("Failed to find original order").contains("for subscriber");	
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnPurchasedDevice_NoAuthEventDeviceServiceException() throws Exception {

		VisibleRequestReturnPurchasedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnPurchasedDevice.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json");
		VisibleResponseReturnPurchasedDevice deviceOut = new VisibleResponseReturnPurchasedDevice();

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "EventQueryResponseEvents_NoAuthEvent.json");

		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		Mockito.doReturn(true).when(instance).isRefundableOffer(any(), any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);

		    Exception exception = assertThrows(DeviceServiceException.class, () -> instance.returnPurchasedDevice(deviceIn, deviceOut));
		    exception.printStackTrace();
		    assertThat(exception.getMessage()).contains("Failed to determine original payment authorization event ID for subscriber");
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnPurchasedDevice_NullResourceID_DeviceServiceException() throws Exception {
		VisibleRequestReturnPurchasedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnPurchasedDevice.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json");
		VisibleResponseReturnPurchasedDevice deviceOut = new VisibleResponseReturnPurchasedDevice();

		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "EventQueryResponseEvents_NoResourceId.json");
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		Mockito.doReturn(true).when(instance).isRefundableOffer(any(), any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);

		    Exception exception = assertThrows(DeviceServiceException.class, () -> instance.returnPurchasedDevice(deviceIn, deviceOut));
		    exception.printStackTrace();
		    assertThat(exception.getMessage()).contains("Failed to determine refund balance resource ID for subscriber");	
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnPurchasedDevice_NoSubPaymentHistory_DeviceServiceException() throws Exception {
		VisibleRequestReturnPurchasedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnPurchasedDevice.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json");
		VisibleResponseReturnPurchasedDevice deviceOut = new VisibleResponseReturnPurchasedDevice();

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "EventQueryResponseEvents_SimpleValid.json");

		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		Mockito.doReturn(true).when(instance).isRefundableOffer(any(), any(), any());
		doReturn(null).when(instance).querySubscriberPaymentHistory(any(), any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);

		    Exception exception = assertThrows(DeviceServiceException.class, () -> instance.returnPurchasedDevice(deviceIn, deviceOut));
		    exception.printStackTrace();
		    assertThat(exception.getMessage()).contains("Failed to query payment history for subscriber");			
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnPurchasedDevice_NoPaymentResourceId_DeviceServiceException() throws Exception {
		VisibleRequestReturnPurchasedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnPurchasedDevice.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json");
		VisibleResponseReturnPurchasedDevice deviceOut = new VisibleResponseReturnPurchasedDevice();
		MtxResponsePaymentHistory subPayHistory = CommonTestHelper.loadJsonMessage(MtxResponsePaymentHistory.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePaymentHistory_NoResourceId.json");
		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "EventQueryResponseEvents_SimpleValid.json");

		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		Mockito.doReturn(true).when(instance).isRefundableOffer(any(), any(), any());
		doReturn(subPayHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);

		    Exception exception = assertThrows(DeviceServiceException.class, () -> instance.returnPurchasedDevice(deviceIn, deviceOut));
		    exception.printStackTrace();
		    assertThat(exception.getMessage()).contains("Failed to determine payment resource ID for subscriber");
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnPurchasedDevice_ValidRequestValidMatrixxData_PurchaseDeviceEventInAdjReason()
			throws Exception {
		// Test case to check if Purchase Device event is added to adjustment reason
		VisibleRequestReturnPurchasedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnPurchasedDevice.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json");
		VisibleResponseReturnPurchasedDevice deviceOut = new VisibleResponseReturnPurchasedDevice();
		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponseMulti_ReturnPurchasedDevice.json");
		MtxResponsePricingOffer pricingOfferDevice = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Device.json");
		MtxResponsePricingOffer pricingOfferShipping = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Shipping.json");
		MtxResponsePaymentHistory subPayHistory = CommonTestHelper.loadJsonMessage(MtxResponsePaymentHistory.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePaymentHistory.json");
		MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "EventQueryResponseEvents_SimpleValid.json");
		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponseSubscriber_refundService.json");

		doReturn("").when(instance).getRoute(any());
		// First mock PropertiesConfiguration. Then using the same mock

		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferDevice).when(instance).queryPricingOffer(any(), any(),
				ArgumentMatchers.eq("Visible_Device"));
		doReturn(pricingOfferShipping).when(instance).queryPricingOffer(any(), any(),
				ArgumentMatchers.eq("Visible_Device_Shipping"));
		doReturn(subPayHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());
		doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());

		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);
			instance.returnPurchasedDevice(deviceIn, deviceOut);

			// Assertions here.
			ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();
			String adjReason = ((MtxRequestSubscriberAdjustBalance) (reqList.get(1))).getReason();
			assertTrue(adjReason.startsWith(CommonUtils.REVERSAL_PREFIX));
			assertTrue(
					adjReason.contains(subscriberEventInfo.getEventList().stream().map(eInfo -> eInfo.getEventDetails())
							.filter(event -> event.getMdcName().equals("MtxPurchaseEvent"))
							.map(event -> (MtxPurchaseEvent) event)
							.filter(event -> event.getAppliedCatalogItemArray() != null)
							.filter(event -> event.getAppliedCatalogItemArray().get(0).getCatalogItemExternalId()
									.equals("Visible_Device"))
							.map(event -> event.getEventId()).toArray()[0].toString()));
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnPurchasedDevice_ValidRequestValidMatrixxData_SingleAdjustment() throws Exception {
		// Test case to check that there is only one adjustment
		VisibleRequestReturnPurchasedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnPurchasedDevice.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json");
		VisibleResponseReturnPurchasedDevice deviceOut = new VisibleResponseReturnPurchasedDevice();
		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponseMulti_ReturnPurchasedDevice.json");
		MtxResponsePricingOffer pricingOfferDevice = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Device.json");
		MtxResponsePricingOffer pricingOfferShipping = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Shipping.json");
		MtxResponsePaymentHistory subPayHistory = CommonTestHelper.loadJsonMessage(MtxResponsePaymentHistory.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePaymentHistory.json");
		MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "EventQueryResponseEvents_SimpleValid.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponseSubscriber_refundService.json");

		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferDevice).when(instance).queryPricingOffer(any(), any(),
				ArgumentMatchers.eq("Visible_Device"));
		doReturn(pricingOfferShipping).when(instance).queryPricingOffer(any(), any(),
				ArgumentMatchers.eq("Visible_Device_Shipping"));
		doReturn(subPayHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());
		doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());

		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);
			instance.returnPurchasedDevice(deviceIn, deviceOut);
			// Assertions here.
			ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();
			assertEquals(1, reqList.stream().filter(req -> req.getMdcName().equals("MtxRequestSubscriberAdjustBalance"))
					.count());
		}

	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnPurchasedDevice_ValidRequestSameShipToBillTo_MultiRequestOrderingAsExpected()
			throws Exception {
		// Test case to check that individual requests in Multirequest input are in
		// correct order
		
        String returnDeviceInstance = "0:1:5:557";
		VisibleRequestReturnPurchasedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnPurchasedDevice.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json");
        deviceIn.getReturnPurchaseOrderInfo().getDeviceInstanceIds().clear();
        deviceIn.getReturnPurchaseOrderInfo().getDeviceInstanceIds().add(returnDeviceInstance);

        VisibleResponseReturnPurchasedDevice deviceOut = new VisibleResponseReturnPurchasedDevice();
		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponseMulti_ReturnPurchasedDevice.json");
		MtxResponsePricingOffer pricingOfferDevice = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Device.json");
		MtxResponsePricingOffer pricingOfferShipping = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Shipping.json");
		MtxResponsePaymentHistory subPayHistory = CommonTestHelper.loadJsonMessage(MtxResponsePaymentHistory.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePaymentHistory.json");
		MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "EventQueryResponseEvents_SimpleValid.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponseSubscriber_refundService.json");
        subRes.getDeviceIdArray().clear();
        subRes.getDeviceIdArray().add(new MtxObjectId(returnDeviceInstance));
        
		// make homeBID 5678. Same value is present in
		// EventQueryResponseEvents_SimpleValid.json
		subRes.setGlCenter("5678");
		((VisibleSubscriberExtension) subRes.getAttr()).sethomeBID("5678");

		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferDevice).when(instance).queryPricingOffer(any(), any(),
				ArgumentMatchers.eq("Visible_Device"));
		doReturn(pricingOfferShipping).when(instance).queryPricingOffer(any(), any(),
				ArgumentMatchers.eq("Visible_Device_Shipping"));
		doReturn(subPayHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());
		doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());

		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);
			instance.returnPurchasedDevice(deviceIn, deviceOut);
			// Assertions here.
			ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();

			assertEquals("MtxRequestSubscriberAdjustBalance", reqList.get(0).getMdcName());
			assertEquals("MtxRequestSubscriberRefundPayment", reqList.get(1).getMdcName());
			//assertEquals("MtxRequestSubscriberRemoveDevice", reqList.get(2).getMdcName());
			//assertEquals("MtxRequestDeviceModify", reqList.get(3).getMdcName());
			//assertEquals("MtxRequestDeviceDelete", reqList.get(4).getMdcName());
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnPurchasedDevice_DifferentShipToBillTo_MultiRequestOrderingAsExpected() throws Exception {
		// Test case to check that individual requests in Multirequest input are in
		// correct order
		
		String returnDeviceInstance = "0:1:5:557";
		VisibleRequestReturnPurchasedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnPurchasedDevice.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json");
        deviceIn.getReturnPurchaseOrderInfo().getDeviceInstanceIds().clear();
        deviceIn.getReturnPurchaseOrderInfo().getDeviceInstanceIds().add(returnDeviceInstance);
        
		VisibleResponseReturnPurchasedDevice deviceOut = new VisibleResponseReturnPurchasedDevice();
		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponseMulti_ReturnPurchasedDevice.json");
		MtxResponsePricingOffer pricingOfferDevice = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Device.json");
		MtxResponsePricingOffer pricingOfferShipping = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Shipping.json");
		MtxResponsePaymentHistory subPayHistory = CommonTestHelper.loadJsonMessage(MtxResponsePaymentHistory.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePaymentHistory.json");
		MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "EventQueryResponseEvents_SimpleValid.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponseSubscriber_refundService.json");
        subRes.getDeviceIdArray().clear();
        subRes.getDeviceIdArray().add(new MtxObjectId(returnDeviceInstance));
        
		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferDevice).when(instance).queryPricingOffer(any(), any(),
				ArgumentMatchers.eq("Visible_Device"));
		doReturn(pricingOfferShipping).when(instance).queryPricingOffer(any(), any(),
				ArgumentMatchers.eq("Visible_Device_Shipping"));
		doReturn(subPayHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());
		doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());

		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);
			instance.returnPurchasedDevice(deviceIn, deviceOut);
			// Assertions here.
			ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();
			Iterator<MtxRequest> reqItr = reqList.iterator();
			assertEquals("MtxRequestSubscriberModify", reqItr.next().getMdcName());
			assertEquals("MtxRequestSubscriberAdjustBalance", reqItr.next().getMdcName());
			assertEquals("MtxRequestSubscriberRefundPayment", reqItr.next().getMdcName());
			
			MtxRequest req = reqItr.next();
			assertEquals("MtxRequestSubscriberModify", req.getMdcName());
			MtxRequestSubscriberModify revertGLCenter = (MtxRequestSubscriberModify) req;
			
			//assertEquals("MtxRequestSubscriberRemoveDevice", reqItr.next().getMdcName());
			//assertEquals("MtxRequestDeviceModify", reqItr.next().getMdcName());
			//assertEquals("MtxRequestDeviceDelete", reqItr.next().getMdcName());
			assertEquals(reqList.size(), 4);
			
			assertEquals(
					subscriberEventInfo.getEventList().stream().map(eInfo -> eInfo.getEventDetails())
							.filter(event -> event.getMdcName().equals("MtxPurchaseEvent"))
							.map(event -> (MtxPurchaseEvent) event)
							.filter(event -> event.getAppliedCatalogItemArray() != null)
							.filter(event -> event.getAppliedCatalogItemArray().get(0).getCatalogItemExternalId()
									.equals("Visible_Device"))
							.map(event -> event.getGlCenter()).toArray()[0],
					((MtxRequestSubscriberModify) reqList.get(0)).getGlCenter());
			assertEquals(subRes.getGlCenter(), revertGLCenter.getGlCenter());

		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnPurchasedDevice_MultiplePaymentAutorizations_Exception() throws Exception {
		// Test case to check that individual requests in Multirequest input are in
		// correct order
		
		String returnDeviceInstance = "0:1:5:557";
		VisibleRequestReturnPurchasedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnPurchasedDevice.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json");
        deviceIn.getReturnPurchaseOrderInfo().getDeviceInstanceIds().clear();
        deviceIn.getReturnPurchaseOrderInfo().getDeviceInstanceIds().add(returnDeviceInstance);
        
		VisibleResponseReturnPurchasedDevice deviceOut = new VisibleResponseReturnPurchasedDevice();
		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponseMulti_ReturnPurchasedDevice.json");
		MtxResponsePricingOffer pricingOfferDevice = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Device.json");
		MtxResponsePricingOffer pricingOfferShipping = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Shipping.json");
		MtxResponsePaymentHistory subPayHistory = CommonTestHelper.loadJsonMessage(MtxResponsePaymentHistory.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePaymentHistory.json");
		MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "EventQueryResponseEvents_SimpleValid.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponseSubscriber_refundService.json");
        subRes.getDeviceIdArray().clear();
        subRes.getDeviceIdArray().add(new MtxObjectId(returnDeviceInstance));
        
		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferDevice).when(instance).queryPricingOffer(any(), any(),
				ArgumentMatchers.eq("Visible_Device"));
		doReturn(pricingOfferShipping).when(instance).queryPricingOffer(any(), any(),
				ArgumentMatchers.eq("Visible_Device_Shipping"));
		doReturn(subPayHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());
		doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());

		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);
			instance.returnPurchasedDevice(deviceIn, deviceOut);
			// Assertions here.
			ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();
			Iterator<MtxRequest> reqItr = reqList.iterator();
			assertEquals("MtxRequestSubscriberModify", reqItr.next().getMdcName());
			assertEquals("MtxRequestSubscriberAdjustBalance", reqItr.next().getMdcName());
			assertEquals("MtxRequestSubscriberRefundPayment", reqItr.next().getMdcName());
			
			MtxRequest req = reqItr.next();
			assertEquals("MtxRequestSubscriberModify", req.getMdcName());
			MtxRequestSubscriberModify revertGLCenter = (MtxRequestSubscriberModify) req;
			
			//assertEquals("MtxRequestSubscriberRemoveDevice", reqItr.next().getMdcName());
			//assertEquals("MtxRequestDeviceModify", reqItr.next().getMdcName());
			//assertEquals("MtxRequestDeviceDelete", reqItr.next().getMdcName());
			assertEquals(reqList.size(), 4);
			
			assertEquals(
					subscriberEventInfo.getEventList().stream().map(eInfo -> eInfo.getEventDetails())
							.filter(event -> event.getMdcName().equals("MtxPurchaseEvent"))
							.map(event -> (MtxPurchaseEvent) event)
							.filter(event -> event.getAppliedCatalogItemArray() != null)
							.filter(event -> event.getAppliedCatalogItemArray().get(0).getCatalogItemExternalId()
									.equals("Visible_Device"))
							.map(event -> event.getGlCenter()).toArray()[0],
					((MtxRequestSubscriberModify) reqList.get(0)).getGlCenter());
			assertEquals(subRes.getGlCenter(), revertGLCenter.getGlCenter());
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnPurchasedDevice_MultipleParentOrders_Exception() throws Exception {
		// If orders to be returned have different parent orders then there should be an exception		
		VisibleRequestReturnPurchasedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnPurchasedDevice.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json");              
		VisibleResponseReturnPurchasedDevice deviceOut = new VisibleResponseReturnPurchasedDevice();

		MtxResponsePricingOffer pricingOfferDevice = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Device.json");
		MtxResponsePricingOffer pricingOfferShipping = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Shipping.json");

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "EventQueryResponseEvents_MultiDevice_DeferredPay_BIDChange.json");
		List<MtxPurchaseEvent> purchaseEqei = subscriberEventInfo.getEventList().stream()
				.filter(eqei -> eqei.getEventDetails().getMdcName().equals(MtxPurchaseEvent.class.getSimpleName()))
				.map(eqei -> (MtxPurchaseEvent)eqei.getEventDetails())
				.collect(Collectors.toList());
		Set<String> origOrders = new HashSet<String>();
		purchaseEqei.forEach(eqei->{
			if(eqei.getAppliedOfferArray()!=null) {
				eqei.getAppliedOfferArray().forEach(peoi->{
					VisiblePurchasedOfferExtension extn = (VisiblePurchasedOfferExtension)peoi.getPurchasedOfferAttr();
					//just make all parent orders diferent using a random string 
					extn.setParentOrderId((new Random()).nextInt(1000000000)+"P");
					origOrders.add(extn.getOrderId());
				});				
			}
		});
		
		//set input orders same as in events
		deviceIn.getReturnPurchaseOrderInfo().getOriginalOrderIds().clear();
        for(String oo:origOrders) {
        	deviceIn.getReturnPurchaseOrderInfo().getOriginalOrderIds().add(oo);	
        }
		     
		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferDevice).when(instance).queryPricingOffer(any(), any(),	ArgumentMatchers.eq("Visible_Device"));
		doReturn(pricingOfferShipping).when(instance).queryPricingOffer(any(), any(),ArgumentMatchers.eq("Visible_Device_Shipping"));

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);

		    Exception exception = assertThrows(DeviceServiceException.class, () -> instance.returnPurchasedDevice(deviceIn, deviceOut));
		    exception.printStackTrace();
		    assertThat(exception.getMessage()).contains("All individual orders should belong to same parent order");
		}		
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnPurchasedDevice_NotSettled_PartialRefund_Exception() throws Exception {
		// If payment is not settled all individual orders should be present in input. Otherwise Error.		
		VisibleRequestReturnPurchasedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnPurchasedDevice.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json");              
		VisibleResponseReturnPurchasedDevice deviceOut = new VisibleResponseReturnPurchasedDevice();

		MtxResponsePricingOffer pricingOfferDevice = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Device.json");
		MtxResponsePricingOffer pricingOfferShipping = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Shipping.json");
		MtxResponsePaymentHistory subPayHistory = CommonTestHelper.loadJsonMessage(MtxResponsePaymentHistory.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePaymentHistory_NoSettlement.json");		
		
		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "EventQueryResponseEvents_MultiDevice_DeferredPay_BIDChange.json");
		List<MtxPurchaseEvent> purchaseEqei = subscriberEventInfo.getEventList().stream()
				.filter(eqei -> eqei.getEventDetails().getMdcName().equals(MtxPurchaseEvent.class.getSimpleName()))
				.map(eqei -> (MtxPurchaseEvent)eqei.getEventDetails())
				.collect(Collectors.toList());
		Set<String> origOrders = new HashSet<String>();
		Set<String> payAuthId = new HashSet<String>();
		purchaseEqei.forEach(eqei->{
			if(eqei.getAppliedOfferArray()!=null) {
				payAuthId.add(eqei.getPaymentAuthEventId());
				eqei.getAppliedOfferArray().forEach(peoi->{
					VisiblePurchasedOfferExtension extn = (VisiblePurchasedOfferExtension)peoi.getPurchasedOfferAttr();
					origOrders.add(extn.getOrderId());
				});				
			}
		});

		assertTrue("Ensure that event file has events for multiple order purchase.", origOrders.size()>1);
		assertEquals("Ensure that all payments are thru one authorization.", payAuthId.size(),1);
		
		//set input orders same as in events
		deviceIn.getReturnPurchaseOrderInfo().getOriginalOrderIds().clear();
        for(String oo:origOrders) {
        	deviceIn.getReturnPurchaseOrderInfo().getOriginalOrderIds().add(oo);	
        }
		
        //set payment authorization event id same as in events
        subPayHistory.getPaymentInfoList().forEach(pi->{
        	pi.setAuthorizationEventId((String)payAuthId.toArray()[0]);
        	pi.setAuthorizationAmount(new BigDecimal(100000000)); //some large amount to avoid insufficient fund error
        });
        
		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferDevice).when(instance).queryPricingOffer(any(), any(),	ArgumentMatchers.eq("Visible_Device"));
		doReturn(pricingOfferShipping).when(instance).queryPricingOffer(any(), any(),ArgumentMatchers.eq("Visible_Device_Shipping"));
		doReturn(subPayHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);

		    Exception exception = assertThrows(DeviceServiceException.class, () -> instance.returnPurchasedDevice(deviceIn, deviceOut));
		    exception.printStackTrace();
		    assertThat(exception.getMessage()).contains("Partial refund is not possible for deferred / not-settled payments.");	
		}
	}
	
	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnPurchasedDevice_AuthorizationAmountLessThanRefundAmount_Exception() throws Exception {
		VisibleRequestReturnPurchasedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnPurchasedDevice.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json");              
		VisibleResponseReturnPurchasedDevice deviceOut = new VisibleResponseReturnPurchasedDevice();

		MtxResponsePricingOffer pricingOfferDevice = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Device.json");
		MtxResponsePricingOffer pricingOfferShipping = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Shipping.json");
		MtxResponsePaymentHistory subPayHistory = CommonTestHelper.loadJsonMessage(MtxResponsePaymentHistory.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePaymentHistory_NoSettlement.json");		
		
		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "EventQueryResponseEvents_MultiDevice_DeferredPay_BIDChange.json");
		List<MtxPurchaseEvent> purchaseEqei = subscriberEventInfo.getEventList().stream()
				.filter(eqei -> eqei.getEventDetails().getMdcName().equals(MtxPurchaseEvent.class.getSimpleName()))
				.map(eqei -> (MtxPurchaseEvent)eqei.getEventDetails())
				.collect(Collectors.toList());
		Set<String> origOrders = new HashSet<String>();
		Set<String> payAuthId = new HashSet<String>();
		purchaseEqei.forEach(eqei->{
			if(eqei.getAppliedOfferArray()!=null) {
				payAuthId.add(eqei.getPaymentAuthEventId());
				eqei.getAppliedOfferArray().forEach(peoi->{
					VisiblePurchasedOfferExtension extn = (VisiblePurchasedOfferExtension)peoi.getPurchasedOfferAttr();
					origOrders.add(extn.getOrderId());
				});				
			}
		});

		assertTrue("Ensure that event file has events for multiple order purchase.", origOrders.size()>1);
		assertEquals("Ensure that all payments are thru one authorization.", payAuthId.size(),1);
		
		//set input orders same as in events
		deviceIn.getReturnPurchaseOrderInfo().getOriginalOrderIds().clear();
        for(String oo:origOrders) {
        	deviceIn.getReturnPurchaseOrderInfo().getOriginalOrderIds().add(oo);	
        }
		
        //set payment authorization event id same as in events
        subPayHistory.getPaymentInfoList().forEach(pi->{
        	pi.setAuthorizationEventId((String)payAuthId.toArray()[0]);
        	pi.setAuthorizationAmount(BigDecimal.ONE); //some large amount to avoid insufficient fund error
        });
        
		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferDevice).when(instance).queryPricingOffer(any(), any(),	ArgumentMatchers.eq("Visible_Device"));
		doReturn(pricingOfferShipping).when(instance).queryPricingOffer(any(), any(),ArgumentMatchers.eq("Visible_Device_Shipping"));
		doReturn(subPayHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);

		    Exception exception = assertThrows(DeviceServiceException.class, () -> instance.returnPurchasedDevice(deviceIn, deviceOut));
		    exception.printStackTrace();
		    assertThat(exception.getMessage()).contains("Refund amount more than authorization amount to return orders / devices for subscriber");
		}		
	}
	
	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnPurchasedDevice_MultiDevice_NotSettled_FullRefund_CorrectRequestList() throws Exception {
		VisibleRequestReturnPurchasedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnPurchasedDevice.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json");              
		VisibleResponseReturnPurchasedDevice deviceOut = new VisibleResponseReturnPurchasedDevice();

		MtxResponsePricingOffer pricingOfferDevice = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Device.json");
		MtxResponsePricingOffer pricingOfferShipping = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Shipping.json");
		MtxResponsePaymentHistory subPayHistory = CommonTestHelper.loadJsonMessage(MtxResponsePaymentHistory.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePaymentHistory_NoSettlement.json");		
		MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponseMulti_ReturnPurchasedDevice.json");
		
		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "EventQueryResponseEvents_MultiDevice_DeferredPay_BIDChange.json");
		List<MtxPurchaseEvent> purchaseEqei = subscriberEventInfo.getEventList().stream()
				.filter(eqei -> eqei.getEventDetails().getMdcName().equals(MtxPurchaseEvent.class.getSimpleName()))
				.map(eqei -> (MtxPurchaseEvent)eqei.getEventDetails())
				.collect(Collectors.toList());
		Set<String> origOrders = new HashSet<String>();
		Set<String> payAuthId = new HashSet<String>();
		List<BigDecimal> refundAmounts = new ArrayList<BigDecimal>();
		
		purchaseEqei.forEach(eqei->{
			if(eqei.getAppliedOfferArray()!=null) {
				payAuthId.add(eqei.getPaymentAuthEventId());
				eqei.getAppliedOfferArray().forEach(peoi->{
					VisiblePurchasedOfferExtension extn = (VisiblePurchasedOfferExtension)peoi.getPurchasedOfferAttr();
					origOrders.add(extn.getOrderId());
					refundAmounts.add(extn.getChargeAmount());
				});				
			}
		});

		assertTrue("Ensure that event file has events for multiple order purchase.", origOrders.size()>1);
		assertEquals("Ensure that all payments are thru one authorization.", payAuthId.size(),1);
		
		//set input orders same as in events
		deviceIn.getReturnPurchaseOrderInfo().getOriginalOrderIds().clear();
        for(String oo:origOrders) {
        	deviceIn.getReturnPurchaseOrderInfo().getOriginalOrderIds().add(oo);	
        }
                
        //set payment authorization event id same as in events
        subPayHistory.getPaymentInfoList().forEach(pi->{
        	pi.setAuthorizationEventId((String)payAuthId.toArray()[0]);
        	pi.setAuthorizationAmount(refundAmounts.stream().reduce(BigDecimal::add).get()); //Make authorization and refund amounts same
        });

        
		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponseSubscriber_refundService.json");		
		
		String[] retDevices = {"0-1-5-557", "0:1:5:558"};
		subRes.getDeviceIdArray().clear();        
        deviceIn.getReturnPurchaseOrderInfo().getDeviceInstanceIds().clear();  
        for(String rd:retDevices) {
        	deviceIn.getReturnPurchaseOrderInfo().getDeviceInstanceIds().add(rd);	
			//Input devices should match with subscriber devices
			subRes.getDeviceIdArray().add(new MtxObjectId(rd));
        }
		
		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferDevice).when(instance).queryPricingOffer(any(), any(),	ArgumentMatchers.eq("Visible_Device"));
		doReturn(pricingOfferShipping).when(instance).queryPricingOffer(any(), any(),ArgumentMatchers.eq("Visible_Device_Shipping"));
		doReturn(subPayHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());

		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);
			instance.returnPurchasedDevice(deviceIn, deviceOut);
			// Assertions here.
			ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();
			Iterator<MtxRequest> reqItr = reqList.iterator();
			assertEquals("Below assertions will fail if device to be returned is more than two. Adjust test case as per need.", subRes.getDeviceIdArray().size(), 2);
			assertEquals(MtxRequestSubscriberAdjustBalance.class.getSimpleName(), reqItr.next().getMdcName());
			assertEquals(MtxRequestSubscriberRefundPayment.class.getSimpleName(), reqItr.next().getMdcName());
			
			//assertEquals(MtxRequestSubscriberRemoveDevice.class.getSimpleName(), reqItr.next().getMdcName());
			//assertEquals(MtxRequestDeviceModify.class.getSimpleName(), reqItr.next().getMdcName());
			//assertEquals(MtxRequestDeviceDelete.class.getSimpleName(), reqItr.next().getMdcName());

			//assertEquals(MtxRequestSubscriberRemoveDevice.class.getSimpleName(), reqItr.next().getMdcName());
			//assertEquals(MtxRequestDeviceModify.class.getSimpleName(), reqItr.next().getMdcName());
			//assertEquals(MtxRequestDeviceDelete.class.getSimpleName(), reqItr.next().getMdcName());
			
			assertEquals(reqList.size(), 2);
		}
	}	

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnPurchasedDevice_SingleDevice_NotSettled_FullRefund_CorrectRequestList() throws Exception {	
		VisibleRequestReturnPurchasedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnPurchasedDevice.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json");              
		VisibleResponseReturnPurchasedDevice deviceOut = new VisibleResponseReturnPurchasedDevice();

		MtxResponsePricingOffer pricingOfferDevice = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Device.json");
		MtxResponsePricingOffer pricingOfferShipping = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Shipping.json");
		MtxResponsePaymentHistory subPayHistory = CommonTestHelper.loadJsonMessage(MtxResponsePaymentHistory.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePaymentHistory_NoSettlement.json");		
		MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponseMulti_ReturnPurchasedDevice.json");
		
		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "EventQueryResponseEvents_MultiDevice_DeferredPay_BIDChange.json");
		List<MtxPurchaseEvent> purchaseEqei = subscriberEventInfo.getEventList().stream()
				.filter(eqei -> eqei.getEventDetails().getMdcName().equals(MtxPurchaseEvent.class.getSimpleName()))
				.map(eqei -> (MtxPurchaseEvent)eqei.getEventDetails())
				.collect(Collectors.toList());
		Set<String> origOrders = new HashSet<String>();
		Set<String> payAuthId = new HashSet<String>();
		List<BigDecimal> refundAmounts = new ArrayList<BigDecimal>();
		
		purchaseEqei.forEach(eqei->{
			if(eqei.getAppliedOfferArray()!=null) {
				payAuthId.add(eqei.getPaymentAuthEventId());
				eqei.getAppliedOfferArray().forEach(peoi->{
					VisiblePurchasedOfferExtension extn = (VisiblePurchasedOfferExtension)peoi.getPurchasedOfferAttr();
					origOrders.add(extn.getOrderId());
					refundAmounts.add(extn.getChargeAmount());
				});				
			}
		});

		assertTrue("Ensure that event file has events for multiple order purchase.", origOrders.size()>1);
		assertEquals("Ensure that all payments are thru one authorization.", payAuthId.size(),1);
		
		//set input orders same as in events
		deviceIn.getReturnPurchaseOrderInfo().getOriginalOrderIds().clear();
        for(String oo:origOrders) {
        	deviceIn.getReturnPurchaseOrderInfo().getOriginalOrderIds().add(oo);	
        }
                
        //set payment authorization event id same as in events
        subPayHistory.getPaymentInfoList().forEach(pi->{
        	pi.setAuthorizationEventId((String)payAuthId.toArray()[0]);
        	pi.setAuthorizationAmount(refundAmounts.stream().reduce(BigDecimal::add).get()); //Make authorization and refund amounts same
        });

        
		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponseSubscriber_refundService.json");		
	
		String[] retDevices = {"0-1-5-557"};
		subRes.getDeviceIdArray().clear();        
        deviceIn.getReturnPurchaseOrderInfo().getDeviceInstanceIds().clear();  
        for(String rd:retDevices) {
        	deviceIn.getReturnPurchaseOrderInfo().getDeviceInstanceIds().add(rd);	
			//Input devices should match with subscriber devices
			subRes.getDeviceIdArray().add(new MtxObjectId(rd));
        }
		
		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferDevice).when(instance).queryPricingOffer(any(), any(),	ArgumentMatchers.eq("Visible_Device"));
		doReturn(pricingOfferShipping).when(instance).queryPricingOffer(any(), any(),ArgumentMatchers.eq("Visible_Device_Shipping"));
		doReturn(subPayHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());

		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);
			instance.returnPurchasedDevice(deviceIn, deviceOut);
			// Assertions here.
			ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();
			Iterator<MtxRequest> reqItr = reqList.iterator();
			assertEquals("Below assertions will fail if device to be returned is more than one. Adjust test case as per need.", subRes.getDeviceIdArray().size(), 1);
			assertEquals(MtxRequestSubscriberAdjustBalance.class.getSimpleName(), reqItr.next().getMdcName());
			assertEquals(MtxRequestSubscriberRefundPayment.class.getSimpleName(), reqItr.next().getMdcName());
			
			//assertEquals(MtxRequestSubscriberRemoveDevice.class.getSimpleName(), reqItr.next().getMdcName());
			//assertEquals(MtxRequestDeviceModify.class.getSimpleName(), reqItr.next().getMdcName());
			//assertEquals(MtxRequestDeviceDelete.class.getSimpleName(), reqItr.next().getMdcName());
		
			assertEquals(reqList.size(), 2);
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnPurchasedDevice_MultiDevice_Settled_PartialRefund_CorrectRequestList() throws Exception {
		VisibleRequestReturnPurchasedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnPurchasedDevice.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json");              
		VisibleResponseReturnPurchasedDevice deviceOut = new VisibleResponseReturnPurchasedDevice();

		MtxResponsePricingOffer pricingOfferDevice = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Device.json");
		MtxResponsePricingOffer pricingOfferShipping = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Shipping.json");
		MtxResponsePaymentHistory subPayHistory = CommonTestHelper.loadJsonMessage(MtxResponsePaymentHistory.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePaymentHistory_Settled.json");		
		subPayHistory.getPaymentInfoList().forEach(pi->{
			//Clear refunds for this test	
			pi.getRefundInfoListAppender().clear();
		});
		
		MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponseMulti_ReturnPurchasedDevice.json");
		
		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "EventQueryResponseEvents_MultiDevice_SettledPay_BIDChange.json");
		List<MtxPurchaseEvent> purchaseEqei = subscriberEventInfo.getEventList().stream()
				.filter(eqei -> eqei.getEventDetails().getMdcName().equals(MtxPurchaseEvent.class.getSimpleName()))
				.map(eqei -> (MtxPurchaseEvent)eqei.getEventDetails())
				.collect(Collectors.toList());
		Set<String> origOrders = new HashSet<String>();
		Set<String> payAuthId = new HashSet<String>();
		List<BigDecimal> refundAmounts = new ArrayList<BigDecimal>();
		
		purchaseEqei.forEach(eqei->{
			if(eqei.getAppliedOfferArray()!=null) {
				payAuthId.add(eqei.getPaymentAuthEventId());
				eqei.getAppliedOfferArray().forEach(peoi->{
					VisiblePurchasedOfferExtension extn = (VisiblePurchasedOfferExtension)peoi.getPurchasedOfferAttr();
					origOrders.add(extn.getOrderId());
					refundAmounts.add(extn.getChargeAmount());
				});				
			}
		});

		assertTrue("Ensure that event file has events for multiple order purchase.", origOrders.size()>1);
		assertEquals("Ensure that all payments are thru one authorization.", payAuthId.size(),1);
		
		//set input orders same as in events
		deviceIn.getReturnPurchaseOrderInfo().getOriginalOrderIds().clear();
        for(String oo:origOrders) {
        	deviceIn.getReturnPurchaseOrderInfo().getOriginalOrderIds().add(oo);
        	break; //Keep it partial refund
        }
                
        //set payment authorization event id same as in events
        subPayHistory.getPaymentInfoList().forEach(pi->{
        	pi.setAuthorizationEventId((String)payAuthId.toArray()[0]);
        	pi.setAuthorizationAmount(refundAmounts.stream().reduce(BigDecimal::add).get()); //Make authorization and refund amounts same
        });

        
		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponseSubscriber_refundService.json");		
	
		String[] retDevices = {"0-1-5-3533"};
		subRes.getDeviceIdArray().clear();        
        deviceIn.getReturnPurchaseOrderInfo().getDeviceInstanceIds().clear();  
        for(String rd:retDevices) {
        	deviceIn.getReturnPurchaseOrderInfo().getDeviceInstanceIds().add(rd);	
			//Input devices should match with subscriber devices
			subRes.getDeviceIdArray().add(new MtxObjectId(rd));
        }
		
		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferDevice).when(instance).queryPricingOffer(any(), any(),	ArgumentMatchers.eq("Visible_Device"));
		doReturn(pricingOfferShipping).when(instance).queryPricingOffer(any(), any(),ArgumentMatchers.eq("Visible_Device_Shipping"));
		doReturn(subPayHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());

		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);
			instance.returnPurchasedDevice(deviceIn, deviceOut);
			// Assertions here.
			ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();
			Iterator<MtxRequest> reqItr = reqList.iterator();
			assertEquals("Below assertions will fail if device to be returned is more than one. Adjust test case as per need.", subRes.getDeviceIdArray().size(), 1);
			assertEquals(MtxRequestSubscriberModify.class.getSimpleName(), reqItr.next().getMdcName());
			assertEquals(MtxRequestSubscriberAdjustBalance.class.getSimpleName(), reqItr.next().getMdcName());
			assertEquals(MtxRequestSubscriberRefundPayment.class.getSimpleName(), reqItr.next().getMdcName());
			assertEquals(MtxRequestSubscriberModify.class.getSimpleName(), reqItr.next().getMdcName());
			//assertEquals(MtxRequestSubscriberRemoveDevice.class.getSimpleName(), reqItr.next().getMdcName());
			//assertEquals(MtxRequestDeviceModify.class.getSimpleName(), reqItr.next().getMdcName());
			//assertEquals(MtxRequestDeviceDelete.class.getSimpleName(), reqItr.next().getMdcName());
		
			assertEquals(reqList.size(), 4);
		}		
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnPurchasedDevice_MultiDevice_Settled_FullRefund_CorrectRequestList() throws Exception {
		VisibleRequestReturnPurchasedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnPurchasedDevice.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json");              
		VisibleResponseReturnPurchasedDevice deviceOut = new VisibleResponseReturnPurchasedDevice();

		MtxResponsePricingOffer pricingOfferDevice = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Device.json");
		MtxResponsePricingOffer pricingOfferShipping = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Shipping.json");
		MtxResponsePaymentHistory subPayHistory = CommonTestHelper.loadJsonMessage(MtxResponsePaymentHistory.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePaymentHistory_Settled.json");		
		subPayHistory.getPaymentInfoList().forEach(pi->{
			//Clear refunds for this test	
			pi.getRefundInfoListAppender().clear();
		});
		
		MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponseMulti_ReturnPurchasedDevice.json");
		
		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "EventQueryResponseEvents_MultiDevice_SettledPay_BIDChange.json");
		List<MtxPurchaseEvent> purchaseEqei = subscriberEventInfo.getEventList().stream()
				.filter(eqei -> eqei.getEventDetails().getMdcName().equals(MtxPurchaseEvent.class.getSimpleName()))
				.map(eqei -> (MtxPurchaseEvent)eqei.getEventDetails())
				.collect(Collectors.toList());
		Set<String> origOrders = new HashSet<String>();
		Set<String> payAuthId = new HashSet<String>();
		List<BigDecimal> refundAmounts = new ArrayList<BigDecimal>();
		
		purchaseEqei.forEach(eqei->{
			if(eqei.getAppliedOfferArray()!=null) {
				payAuthId.add(eqei.getPaymentAuthEventId());
				eqei.getAppliedOfferArray().forEach(peoi->{
					VisiblePurchasedOfferExtension extn = (VisiblePurchasedOfferExtension)peoi.getPurchasedOfferAttr();
					origOrders.add(extn.getOrderId());
					refundAmounts.add(extn.getChargeAmount());
				});				
			}
		});

		assertTrue("Ensure that event file has events for multiple order purchase.", origOrders.size()>1);
		assertEquals("Ensure that all payments are thru one authorization.", payAuthId.size(),1);
		
		//set input orders same as in events
		deviceIn.getReturnPurchaseOrderInfo().getOriginalOrderIds().clear();
        for(String oo:origOrders) {
        	deviceIn.getReturnPurchaseOrderInfo().getOriginalOrderIds().add(oo);
        	break; //Keep it partial refund
        }
                
        //set payment authorization event id same as in events
        subPayHistory.getPaymentInfoList().forEach(pi->{
        	pi.setAuthorizationEventId((String)payAuthId.toArray()[0]);
        	pi.setAuthorizationAmount(refundAmounts.stream().reduce(BigDecimal::add).get()); //Make authorization and refund amounts same
        });

        
		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponseSubscriber_refundService.json");		
	
		String[] retDevices = {"0-1-5-3533", "0-1-5-3535"};
		subRes.getDeviceIdArray().clear();        
        deviceIn.getReturnPurchaseOrderInfo().getDeviceInstanceIds().clear();  
        for(String rd:retDevices) {
        	deviceIn.getReturnPurchaseOrderInfo().getDeviceInstanceIds().add(rd);	
			//Input devices should match with subscriber devices
			subRes.getDeviceIdArray().add(new MtxObjectId(rd));
        }
		
		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferDevice).when(instance).queryPricingOffer(any(), any(),	ArgumentMatchers.eq("Visible_Device"));
		doReturn(pricingOfferShipping).when(instance).queryPricingOffer(any(), any(),ArgumentMatchers.eq("Visible_Device_Shipping"));
		doReturn(subPayHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());

		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);
			instance.returnPurchasedDevice(deviceIn, deviceOut);
			// Assertions here.
			ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();
			Iterator<MtxRequest> reqItr = reqList.iterator();
			assertEquals("Below assertions will fail if device to be returned is more than two. Adjust test case as per need.", subRes.getDeviceIdArray().size(), 2);
			assertEquals(MtxRequestSubscriberModify.class.getSimpleName(), reqItr.next().getMdcName());
			assertEquals(MtxRequestSubscriberAdjustBalance.class.getSimpleName(), reqItr.next().getMdcName());
			assertEquals(MtxRequestSubscriberRefundPayment.class.getSimpleName(), reqItr.next().getMdcName());
			assertEquals(MtxRequestSubscriberModify.class.getSimpleName(), reqItr.next().getMdcName());
			//assertEquals(MtxRequestSubscriberRemoveDevice.class.getSimpleName(), reqItr.next().getMdcName());
			//assertEquals(MtxRequestDeviceModify.class.getSimpleName(), reqItr.next().getMdcName());
			//assertEquals(MtxRequestDeviceDelete.class.getSimpleName(), reqItr.next().getMdcName());
			//assertEquals(MtxRequestSubscriberRemoveDevice.class.getSimpleName(), reqItr.next().getMdcName());
			//assertEquals(MtxRequestDeviceModify.class.getSimpleName(), reqItr.next().getMdcName());
			//assertEquals(MtxRequestDeviceDelete.class.getSimpleName(), reqItr.next().getMdcName());
			assertEquals(reqList.size(), 4);
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnFinancedDevice_NoPaymentResourceId_DeviceServiceException() throws Exception {
		VisibleRequestReturnFinancedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnFinancedDevice.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "VisibleRequestReturnFinancedDevice_ValidRequest.json");
		VisibleResponseReturnFinancedDevice deviceOut = new VisibleResponseReturnFinancedDevice();

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "EventQueryResponseEvents_NoResourceId.json");

		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		Mockito.doReturn(true).when(instance).isRefundableOffer(any(), any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);
			
		    Exception exception = assertThrows(DeviceServiceException.class, () -> instance.returnFinancedDevice(deviceIn, deviceOut));
		    exception.printStackTrace();
		    assertThat(exception.getMessage()).contains("Failed to determine refund balance resource ID for subscriber");
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_cancelDeviceSwap_NoBalanceResourceId_DeviceServiceException() throws Exception {
		VisibleRequestCancelDeviceSwap swapIn = CommonTestHelper.loadJsonMessage(VisibleRequestCancelDeviceSwap.class,
				DATA_DIR.CANCEL_SWAP + "VisibleRequestCancelDeviceSwap.json");
		VisibleResponseCancelDeviceSwap swapOut = new VisibleResponseCancelDeviceSwap();
		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.CANCEL_SWAP + "EventQueryResponseEvents.json", "BalanceResourceId");
		// Make balanceResourceId as null

		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any());
		Mockito.doReturn(true).when(instance).isRefundableOffer(any(), any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);

	        Exception exception = assertThrows(DeviceServiceException.class, () -> instance.cancelDeviceSwap(swapIn, swapOut));
	        exception.printStackTrace();
	        assertEquals("Failed to determine refund balance resource ID for subscriber",exception.getMessage().trim());
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnFinancedDevice_NoQueryDeviceData_DeviceServiceException() throws Exception {
		VisibleRequestReturnFinancedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnFinancedDevice.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "VisibleRequestReturnFinancedDevice_ValidRequest.json");
		VisibleResponseReturnFinancedDevice deviceOut = new VisibleResponseReturnFinancedDevice();

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "EventQueryResponseEvents_SimpleValid.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponseSubscriber_refundService.json");

		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		Mockito.doReturn(true).when(instance).isRefundableOffer(any(), any(), any());
		doReturn(null).when(instance).queryDeviceData(any(), any(), any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);

		    Exception exception = assertThrows(DeviceServiceException.class, () -> instance.returnFinancedDevice(deviceIn, deviceOut));
		    exception.printStackTrace();
		    assertThat(exception.getMessage()).contains("Failed to query subscriber");
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnFinancedDevice_OrderIdMissMatch_DeviceServiceException() throws Exception {
		VisibleRequestReturnFinancedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnFinancedDevice.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "VisibleRequestReturnFinancedDevice_ValidRequest.json");
		VisibleResponseReturnFinancedDevice deviceOut = new VisibleResponseReturnFinancedDevice();

		MtxResponsePricingOffer pricingOfferDevice = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponsePricingOffer_Device.json");

		MtxResponsePricingOffer pricingOfferShipping = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponsePricingOffer_Shipping.json");

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "EventQueryResponseEvents_IncorrectOrderId.json");

		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferDevice).when(instance).queryPricingOffer(any(), any(),
				ArgumentMatchers.eq("Visible_Device"));
		doReturn(pricingOfferShipping).when(instance).queryPricingOffer(any(), any(),
				ArgumentMatchers.eq("Visible_Device_Shipping"));

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);

		    Exception exception = assertThrows(DeviceServiceException.class, () -> instance.returnFinancedDevice(deviceIn, deviceOut));
		    exception.printStackTrace();
		    assertThat(exception.getMessage()).contains("Failed to find original order for subscriber");
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_cancelDeviceSwap_OrderIdMissMatch_DeviceServiceException() throws Exception {
		VisibleRequestCancelDeviceSwap swapIn = CommonTestHelper.loadJsonMessage(VisibleRequestCancelDeviceSwap.class,
				DATA_DIR.CANCEL_SWAP + "VisibleRequestCancelDeviceSwap.json");
		VisibleResponseCancelDeviceSwap swapOut = new VisibleResponseCancelDeviceSwap();
		MtxResponsePricingOffer pricingOfferSwap = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.CANCEL_SWAP + "MtxResponsePricingOffer.json");

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.CANCEL_SWAP + "EventQueryResponseEvents.json");

		// Change order id to some thing different from one in input
		subscriberEventInfo.getEventList().forEach(eqei -> {
			if (eqei.getEventDetails().getMdcName().equals("MtxPurchaseEvent")) {
				MtxPurchaseEvent details = (MtxPurchaseEvent) eqei.getEventDetails();
				if (details.getAppliedOfferArray() != null) {
					details.getAppliedOfferArray().forEach(offer -> {
						if (offer.getPurchasedOfferAttr() != null) {
							VisiblePurchasedOfferExtension attr = (VisiblePurchasedOfferExtension) offer
									.getPurchasedOfferAttr();
							attr.setOrderId("9999999");
						}
					});
				}

			}
		});

		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any());
		doReturn(pricingOfferSwap).when(instance).queryPricingOffer(any(), any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);

	        Exception exception = assertThrows(DeviceServiceException.class, () -> instance.cancelDeviceSwap(swapIn, swapOut));
	        exception.printStackTrace();
	        assertEquals("Failed to find original order for subscriber",exception.getMessage().trim());
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnFinancedDevice_ValidRequestValidMatrixxData_ReturnSuccess() throws Exception {
		VisibleRequestReturnFinancedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnFinancedDevice.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "VisibleRequestReturnFinancedDevice_ValidRequest.json");
		VisibleResponseReturnFinancedDevice deviceOut = new VisibleResponseReturnFinancedDevice();

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponseMulti_ReturnPurchasedDevice.json");

		MtxResponsePricingOffer pricingOfferDevice = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponsePricingOffer_Device.json");

		MtxResponsePricingOffer pricingOfferShipping = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponsePricingOffer_Shipping.json");

		MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "EventQueryResponseEvents_SimpleValid.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponseSubscriber_refundService.json");

		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferDevice).doReturn(pricingOfferShipping).when(instance).queryPricingOffer(any(), any(),
				any());
		doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
		when(api.multi(any(), any())).thenReturn(multiRes);
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);
			instance.returnFinancedDevice(deviceIn, deviceOut);
			assertEquals("0", String.valueOf(deviceOut.getResult()));
			assertEquals("OK", String.valueOf(deviceOut.getResultText()));
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_cancelDeviceSwap_ValidMultiResponse_ReturnSuccess() throws Exception {
		VisibleRequestCancelDeviceSwap swapIn = CommonTestHelper.loadJsonMessage(VisibleRequestCancelDeviceSwap.class,
				DATA_DIR.CANCEL_SWAP + "VisibleRequestCancelDeviceSwap.json");
		VisibleResponseCancelDeviceSwap swapOut = new VisibleResponseCancelDeviceSwap();
		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.CANCEL_SWAP + "EventQueryResponseEvents.json");
		MtxResponsePricingOffer pricingOfferSwap = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.CANCEL_SWAP + "MtxResponsePricingOffer.json");
		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.CANCEL_SWAP + "MtxResponseSubscriber.json");
		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.CANCEL_SWAP + "MtxResponseMulti.json");

		doReturn("").when(instance).getRoute(any());

		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any());

		doReturn(pricingOfferSwap).when(instance).queryPricingOffer(any(), any(), any());

		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		when(api.multi(any(), any())).thenReturn(multiRes);
		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

		instance.cancelDeviceSwap(swapIn, swapOut);

		// Assertions here.
		assertEquals("0", String.valueOf(swapOut.getResult()));
		assertEquals("OK", String.valueOf(swapOut.getResultText()));
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnFinancedDevice_NullMultiResponse_DeviceServiceException() throws Exception {
		VisibleRequestReturnFinancedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnFinancedDevice.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "VisibleRequestReturnFinancedDevice_ValidRequest.json");
		VisibleResponseReturnFinancedDevice deviceOut = new VisibleResponseReturnFinancedDevice();

		MtxResponsePricingOffer pricingOfferDevice = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponsePricingOffer_Device.json");

		MtxResponsePricingOffer pricingOfferShipping = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponsePricingOffer_Shipping.json");

		MtxResponsePaymentHistory subPayHistory = CommonTestHelper.loadJsonMessage(MtxResponsePaymentHistory.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponsePaymentHistory.json");

		MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "EventQueryResponseEvents_SimpleValid.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponseSubscriber_refundService.json");

		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferDevice).doReturn(pricingOfferShipping).when(instance).queryPricingOffer(any(), any(),
				any());
		doReturn(subPayHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());
		doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
		doReturn(null).when(instance).multiRequest(any(), any(), any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);

		    Exception exception = assertThrows(DeviceServiceException.class, () -> instance.returnFinancedDevice(deviceIn, deviceOut));
		    exception.printStackTrace();
		    assertThat(exception.getMessage()).contains("Failed to return financed device");
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_cancelDeviceSwap_NullMultiResponse_GLCenterChangeAndUndo() throws Exception {
		VisibleRequestCancelDeviceSwap swapIn = CommonTestHelper.loadJsonMessage(VisibleRequestCancelDeviceSwap.class,
				DATA_DIR.CANCEL_SWAP + "VisibleRequestCancelDeviceSwap.json");
		VisibleResponseCancelDeviceSwap swapOut = new VisibleResponseCancelDeviceSwap();
		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.CANCEL_SWAP + "EventQueryResponseEvents.json");
		MtxResponsePricingOffer pricingOfferSwap = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.CANCEL_SWAP + "MtxResponsePricingOffer.json");
		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.CANCEL_SWAP + "MtxResponseSubscriber.json");

		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any());
		doReturn(pricingOfferSwap).when(instance).queryPricingOffer(any(), any(), any());
		doReturn(null).when(instance).multiRequest(any(), any(), any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);

	        Exception exception = assertThrows(DeviceServiceException.class, () -> instance.cancelDeviceSwap(swapIn, swapOut));
	        exception.printStackTrace();
	        assertEquals(DeviceService.LOG_FAILED_MULTI,exception.getMessage().trim());
		}
	}

	@Test
	@Ignore("Issue with mocking props fixed. Check Assertions")
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnFinancedDevice_ValidRequestValidMatrixxData_AllEventsAddedToAdjReason() throws Exception {
		// Test case to check if all events are added to adjustment reason
		VisibleRequestReturnFinancedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnFinancedDevice.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "VisibleRequestReturnFinancedDevice_ValidRequest.json");
		VisibleResponseReturnFinancedDevice deviceOut = new VisibleResponseReturnFinancedDevice();

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponseMulti_ReturnPurchasedDevice.json");

		MtxResponsePricingOffer pricingOfferDevice = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponsePricingOffer_Device.json");

		MtxResponsePricingOffer pricingOfferShipping = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponsePricingOffer_Shipping.json");

		MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "EventQueryResponseEvents_SimpleValid.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponseSubscriber_refundService.json");

		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferDevice).when(instance).queryPricingOffer(any(), any(), eq("Visible_Device"));
		doReturn(pricingOfferShipping).when(instance).queryPricingOffer(any(), any(), eq("Visible_Device_Shipping"));
		doReturn(pricingOfferDevice).when(instance).queryPricingOffer(any(), any(), eq("Visible_Device_Finance_Fee"));
		doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());

		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);
			instance.returnFinancedDevice(deviceIn, deviceOut);
			// Assertions here.
			ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();

			String adjReason = ((MtxRequestSubscriberAdjustBalance) (reqList.get(1))).getReason();
			assertTrue(adjReason.startsWith(CommonUtils.REVERSAL_PREFIX));
			assertTrue(adjReason.contains(subscriberEventInfo.getEventList().stream()
					.map(eInfo -> eInfo.getEventDetails())
					.filter(event -> event.getMdcName().equals("MtxPurchaseEvent"))
					.map(event -> (MtxPurchaseEvent) event).filter(event -> event.getAppliedCatalogItemArray() != null)
					.filter(event -> event.getAppliedCatalogItemArray().get(0).getCatalogItemExternalId()
							.equals("Visible_Device_Finance_Fee"))
					.map(event -> event.getEventId()).toArray()[0].toString()));

			assertTrue(
					adjReason.contains(subscriberEventInfo.getEventList().stream().map(eInfo -> eInfo.getEventDetails())
							.filter(event -> event.getMdcName().equals("MtxPurchaseEvent"))
							.map(event -> (MtxPurchaseEvent) event)
							.filter(event -> event.getAppliedCatalogItemArray() != null)
							.filter(event -> event.getAppliedCatalogItemArray().get(0).getCatalogItemExternalId()
									.equals("Visible_Device"))
							.map(event -> event.getEventId()).toArray()[0].toString()));

			assertTrue(adjReason.contains(subscriberEventInfo.getEventList().stream()
					.map(eInfo -> eInfo.getEventDetails())
					.filter(event -> event.getMdcName().equals("MtxRechargeEvent"))
					.map(event -> (MtxRechargeEvent) event).filter(event -> event.getReason().equals("finance_device"))
					.map(event -> event.getEventId()).toArray()[0].toString()));

		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_cancelDeviceSwap_ValidMultiResponse_AdjReasonHasEventId() throws Exception {
		VisibleRequestCancelDeviceSwap swapIn = CommonTestHelper.loadJsonMessage(VisibleRequestCancelDeviceSwap.class,
				DATA_DIR.CANCEL_SWAP + "VisibleRequestCancelDeviceSwap.json");
		VisibleResponseCancelDeviceSwap swapOut = new VisibleResponseCancelDeviceSwap();
		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.CANCEL_SWAP + "EventQueryResponseEvents.json");
		MtxResponsePricingOffer pricingOfferSwap = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.CANCEL_SWAP + "MtxResponsePricingOffer.json");
		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.CANCEL_SWAP + "MtxResponseSubscriber.json");
		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.CANCEL_SWAP + "MtxResponseMulti.json");

		doReturn("").when(instance).getRoute(any());

		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any());

		doReturn(pricingOfferSwap).when(instance).queryPricingOffer(any(), any(), any());

		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		when(api.multi(any(), any())).thenReturn(multiRes);
		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

		instance.cancelDeviceSwap(swapIn, swapOut);

		// Assertions here.
		ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();

		assertEquals("MtxRequestSubscriberAdjustBalance", reqList.get(0).getMdcName());

		int reversalEvents = subscriberEventInfo.getEventList().stream().map(eInfo -> eInfo.getEventDetails())
				.filter(event -> event.getMdcName().equals("MtxPurchaseEvent")).map(event -> (MtxPurchaseEvent) event)
				.filter(event -> event.getAppliedCatalogItemArray() != null)
				.filter(event -> event.getAppliedCatalogItemArray().get(0).getCatalogItemExternalId()
						.equals(swapIn.getCancelDeviceSwapOrderInfo().getDeviceSwapOfferExternalId()))
				.map(event -> event.getEventId()).toArray().length;

		for (int i = 0; i < reversalEvents; i++) {
			assertTrue(((MtxRequestSubscriberAdjustBalance) reqList.get(0)).getReason()
					.contains(subscriberEventInfo.getEventList().stream().map(eInfo -> eInfo.getEventDetails())
							.filter(event -> event.getMdcName().equals("MtxPurchaseEvent"))
							.map(event -> (MtxPurchaseEvent) event)
							.filter(event -> event.getAppliedCatalogItemArray() != null)
							.filter(event -> event.getAppliedCatalogItemArray().get(0).getCatalogItemExternalId()
									.equals(swapIn.getCancelDeviceSwapOrderInfo().getDeviceSwapOfferExternalId()))
							.map(event -> event.getEventId()).toArray()[i].toString()));
		}
		assertTrue(
				((MtxRequestSubscriberAdjustBalance) reqList.get(0)).getReason().contains(CommonUtils.REVERSAL_PREFIX));
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnFinancedDevice_ValidRequestValidMatrixxData_SingleAdjustment() throws Exception {
		// Test case to check that there is only one adjustment
		VisibleRequestReturnFinancedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnFinancedDevice.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "VisibleRequestReturnFinancedDevice_ValidRequest.json");
		VisibleResponseReturnFinancedDevice deviceOut = new VisibleResponseReturnFinancedDevice();

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponseMulti_ReturnPurchasedDevice.json");

		MtxResponsePricingOffer pricingOfferDevice = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponsePricingOffer_Device.json");

		MtxResponsePricingOffer pricingOfferShipping = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponsePricingOffer_Shipping.json");

		MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "EventQueryResponseEvents_SimpleValid.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponseSubscriber_refundService.json");

		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferDevice).doReturn(pricingOfferShipping).when(instance).queryPricingOffer(any(), any(),
				any());
		doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());

		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);
			instance.returnFinancedDevice(deviceIn, deviceOut);

			// Assertions here.
			ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();
			assertEquals(1, reqList.stream().filter(req -> req.getMdcName().equals("MtxRequestSubscriberAdjustBalance"))
					.count());
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnFinancedDevice_SameShipToBillTo_MultiRequestOrderingAsExpected() throws Exception {
		// Test case to check that individual requests in Multirequest input are in
		// correct order
		VisibleRequestReturnFinancedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnFinancedDevice.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "VisibleRequestReturnFinancedDevice_ValidRequest.json");
		VisibleResponseReturnFinancedDevice deviceOut = new VisibleResponseReturnFinancedDevice();

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponseMulti_ReturnPurchasedDevice.json");

		MtxResponsePricingOffer pricingOfferDevice = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponsePricingOffer_Device.json");

		MtxResponsePricingOffer pricingOfferShipping = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponsePricingOffer_Shipping.json");

		MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "EventQueryResponseEvents_SimpleValid.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponseSubscriber_refundService.json");
		// make homeBID 5678. Same value is present in
		// EventQueryResponseEvents_SimpleValid.json
		subRes.setGlCenter("5678");
		((VisibleSubscriberExtension) subRes.getAttr()).sethomeBID("5678");

		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferDevice).doReturn(pricingOfferShipping).when(instance).queryPricingOffer(any(), any(),
				any());
		doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());

		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);
			instance.returnFinancedDevice(deviceIn, deviceOut);
			// Assertions here.
			ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();

			assertEquals("MtxRequestSubscriberAdjustBalance", reqList.get(0).getMdcName());
			assertEquals("MtxRequestSubscriberRemoveDevice", reqList.get(1).getMdcName());
			assertEquals("MtxRequestDeviceModify", reqList.get(2).getMdcName());
			assertEquals("MtxRequestDeviceDelete", reqList.get(3).getMdcName());
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_cancelDeviceSwapDevice_SameShipToBillTo_MultiRequestOrderingAsExpected() throws Exception {
		VisibleRequestCancelDeviceSwap swapIn = CommonTestHelper.loadJsonMessage(VisibleRequestCancelDeviceSwap.class,
				DATA_DIR.CANCEL_SWAP + "VisibleRequestCancelDeviceSwap.json");
		VisibleResponseCancelDeviceSwap swapOut = new VisibleResponseCancelDeviceSwap();

		MtxResponsePricingOffer pricingOfferSwap = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.CANCEL_SWAP + "MtxResponsePricingOffer.json");
		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.CANCEL_SWAP + "MtxResponseSubscriber.json");

		// Make GLCenter and homeBID same
		((VisibleSubscriberExtension) subRes.getAttr()).sethomeBID(subRes.getGlCenter());
		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.CANCEL_SWAP + "MtxResponseMulti.json");

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.CANCEL_SWAP + "EventQueryResponseEvents.json");

		// Make shiptobid same as GLCenter
		subscriberEventInfo.getEventList().forEach(eqei -> {
			if (eqei.getEventDetails().getMdcName().equals("MtxPurchaseEvent")) {
				MtxPurchaseEvent details = (MtxPurchaseEvent) eqei.getEventDetails();
				details.setGlCenter(subRes.getGlCenter());
			}
		});

		doReturn("").when(instance).getRoute(any());

		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any());

		doReturn(pricingOfferSwap).when(instance).queryPricingOffer(any(), any(), any());

		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		when(api.multi(any(), any())).thenReturn(multiRes);
		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

		instance.cancelDeviceSwap(swapIn, swapOut);

		// Assertions here.
		ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();

		assertEquals("MtxRequestSubscriberAdjustBalance", reqList.get(0).getMdcName());
		assertEquals(1, reqList.size());
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnFinancedDevice_DifferentShipToBillTo_MultiRequestOrderingAsExpected() throws Exception {
		// Test case to check that individual requests in Multirequest input are in
		// correct order
		VisibleRequestReturnFinancedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnFinancedDevice.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "VisibleRequestReturnFinancedDevice_ValidRequest.json");
		VisibleResponseReturnFinancedDevice deviceOut = new VisibleResponseReturnFinancedDevice();

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponseMulti_ReturnPurchasedDevice.json");

		MtxResponsePricingOffer pricingOfferDevice = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponsePricingOffer_Device.json");

		MtxResponsePricingOffer pricingOfferShipping = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponsePricingOffer_Shipping.json");

		MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "EventQueryResponseEvents_SimpleValid.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponseSubscriber_refundService.json");

		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferDevice).doReturn(pricingOfferShipping).when(instance).queryPricingOffer(any(), any(),
				any());
		doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());

		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);
			instance.returnFinancedDevice(deviceIn, deviceOut);
			// Assertions here.
			ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();

			assertEquals("MtxRequestSubscriberModify", reqList.get(0).getMdcName());
			assertEquals("MtxRequestSubscriberAdjustBalance", reqList.get(1).getMdcName());
			assertEquals("MtxRequestSubscriberRemoveDevice", reqList.get(2).getMdcName());
			assertEquals("MtxRequestDeviceModify", reqList.get(3).getMdcName());
			assertEquals("MtxRequestDeviceDelete", reqList.get(4).getMdcName());
			assertEquals("MtxRequestSubscriberModify", reqList.get(5).getMdcName());
			assertEquals("5678", ((MtxRequestSubscriberModify) reqList.get(0)).getGlCenter());
			assertEquals(subRes.getGlCenter(), ((MtxRequestSubscriberModify) reqList.get(5)).getGlCenter());
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_cancelDeviceSwapDevice_DifferentShipToBillTo_MultiRequestOrderingAsExpected() throws Exception {
		VisibleRequestCancelDeviceSwap swapIn = CommonTestHelper.loadJsonMessage(VisibleRequestCancelDeviceSwap.class,
				DATA_DIR.CANCEL_SWAP + "VisibleRequestCancelDeviceSwap.json");
		VisibleResponseCancelDeviceSwap swapOut = new VisibleResponseCancelDeviceSwap();

		MtxResponsePricingOffer pricingOfferSwap = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.CANCEL_SWAP + "MtxResponsePricingOffer.json");
		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.CANCEL_SWAP + "MtxResponseSubscriber.json");

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.CANCEL_SWAP + "EventQueryResponseEvents.json");
		subscriberEventInfo.getEventList().forEach(eqei -> {
			// ChangeGLCenter
			eqei.getEventDetails().setGlCenter("9999999999999999");
		});

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.CANCEL_SWAP + "MtxResponseMulti.json");

		doReturn("").when(instance).getRoute(any());

		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any());

		doReturn(pricingOfferSwap).when(instance).queryPricingOffer(any(), any(), any());

		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		when(api.multi(any(), any())).thenReturn(multiRes);
		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

		instance.cancelDeviceSwap(swapIn, swapOut);

		// Assertions here.
		ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();

		assertEquals("MtxRequestSubscriberModify", reqList.get(0).getMdcName());
		assertEquals("MtxRequestSubscriberAdjustBalance", reqList.get(1).getMdcName());
		assertEquals("MtxRequestSubscriberModify", reqList.get(reqList.size() - 1).getMdcName());
		assertEquals(subRes.getGlCenter(),
				((MtxRequestSubscriberModify) reqList.get(reqList.size() - 1)).getGlCenter());
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_purchaseDevice_ValidRequestValidMatrixxData_KountPassedToSubman() throws Exception {
		// Test case to check that Reasons are populated correctly
		VisibleRequestPurchaseDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestPurchaseDevice.class,
				DATA_DIR.PURCHASED_DEVICE + "VisibleRequestPurchaseDevice_ValidSimpleRequest.json");

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.PURCHASED_DEVICE + "MtxResponseMulti.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.PURCHASED_DEVICE + "MtxResponseSubscriber.json");
		VisibleResponsePurchaseDevice deviceOut = new VisibleResponsePurchaseDevice();
		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
		// method to test
		instance.purchaseDevice(deviceIn, deviceOut);

		// Assertions here.
		ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();

		VisibleBraintreeChargeMethodExtension shippingXtn = reqList.stream()
				.filter(req -> req.getMdcName().equals(MtxRequestSubscriberPurchaseOffer.class.getSimpleName()))
				.map(req -> ((MtxRequestSubscriberPurchaseOffer) req))
				.filter(purReq -> ((VisiblePurchasedOfferExtension) purReq.getAtOfferRequestArray(0).getAttr())
						.getGoodType() != null)
				.filter(purReq -> ((VisiblePurchasedOfferExtension) purReq.getAtOfferRequestArray(0).getAttr())
						.getGoodType().equals("purchase_shipping"))
				.map(purReq -> ((VisibleBraintreeChargeMethodExtension) purReq.getChargeMethodData()
						.getChargeMethodAttr()))
				.findFirst().get();

		VisibleBraintreeChargeMethodExtension deviceXtn = reqList.stream()
				.filter(req -> req.getMdcName().equals(MtxRequestSubscriberPurchaseOffer.class.getSimpleName()))
				.map(req -> ((MtxRequestSubscriberPurchaseOffer) req))
				.filter(purReq -> ((VisiblePurchasedOfferExtension) purReq.getAtOfferRequestArray(0).getAttr())
						.getGoodType() != null)
				.filter(purReq -> ((VisiblePurchasedOfferExtension) purReq.getAtOfferRequestArray(0).getAttr())
						.getGoodType().equals("purchase_device"))
				.map(purReq -> ((VisibleBraintreeChargeMethodExtension) purReq.getChargeMethodData()
						.getChargeMethodAttr()))
				.findFirst().get();

		VisibleFraudHomeAddress fraudHomeAddress = deviceIn.getPurchaseFraudInfo().getFraudHomeAddress();

		VisibleFraudShippingAddress fraudShipAddress = deviceIn.getPurchaseFraudInfo().getFraudShippingAddress();

		assertEquals(fraudHomeAddress.getCompany(), shippingXtn.getBillingAddress().getCompany() == null ? ""
				: shippingXtn.getBillingAddress().getCompany());

		assertEquals(fraudHomeAddress.getCountryCode(), shippingXtn.getBillingAddress().getCountryCode());

		assertEquals(fraudHomeAddress.getExtendedAddress(),
				shippingXtn.getBillingAddress().getExtendedAddress() == null ? ""
						: shippingXtn.getBillingAddress().getExtendedAddress());

		assertEquals(fraudHomeAddress.getFirstName(), shippingXtn.getBillingAddress().getFirstName());

		assertEquals(fraudHomeAddress.getLastName(), shippingXtn.getBillingAddress().getLastName());

		assertEquals(fraudHomeAddress.getLocality(), shippingXtn.getBillingAddress().getLocality());

		assertEquals(fraudHomeAddress.getPostalCode(), shippingXtn.getBillingAddress().getPostalCode());

		assertEquals(fraudHomeAddress.getRegion(), shippingXtn.getBillingAddress().getRegion());

		assertEquals(fraudHomeAddress.getStreetAddress(), shippingXtn.getBillingAddress().getStreetAddress());

		assertEquals(fraudShipAddress.getCompany(), shippingXtn.getShippingAddress().getCompany() == null ? ""
				: shippingXtn.getShippingAddress().getCompany());

		assertEquals(fraudShipAddress.getCountryCode(), shippingXtn.getShippingAddress().getCountryCode());

		assertEquals(fraudShipAddress.getExtendedAddress(),
				shippingXtn.getShippingAddress().getExtendedAddress() == null ? ""
						: shippingXtn.getShippingAddress().getExtendedAddress());

		assertEquals(fraudShipAddress.getFirstName(), shippingXtn.getShippingAddress().getFirstName());

		assertEquals(fraudShipAddress.getLastName(), shippingXtn.getShippingAddress().getLastName());

		assertEquals(fraudShipAddress.getLocality(), shippingXtn.getShippingAddress().getLocality());

		assertEquals(fraudShipAddress.getPostalCode(), shippingXtn.getShippingAddress().getPostalCode());

		assertEquals(fraudShipAddress.getRegion(), shippingXtn.getShippingAddress().getRegion());

		assertEquals(fraudShipAddress.getStreetAddress(), shippingXtn.getShippingAddress().getStreetAddress());

		assertEquals(deviceIn.getPurchaseFraudInfo().getTransactionType(), shippingXtn.getTransactionType());

		assertEquals(fraudHomeAddress.getCompany(),
				deviceXtn.getBillingAddress().getCompany() == null ? "" : deviceXtn.getBillingAddress().getCompany());

		assertEquals(fraudHomeAddress.getCountryCode(), deviceXtn.getBillingAddress().getCountryCode());

		assertEquals(fraudHomeAddress.getExtendedAddress(),
				deviceXtn.getBillingAddress().getExtendedAddress() == null ? ""
						: deviceXtn.getBillingAddress().getExtendedAddress());

		assertEquals(fraudHomeAddress.getFirstName(), deviceXtn.getBillingAddress().getFirstName());

		assertEquals(fraudHomeAddress.getLastName(), deviceXtn.getBillingAddress().getLastName());

		assertEquals(fraudHomeAddress.getLocality(), deviceXtn.getBillingAddress().getLocality());

		assertEquals(fraudHomeAddress.getPostalCode(), deviceXtn.getBillingAddress().getPostalCode());

		assertEquals(fraudHomeAddress.getRegion(), deviceXtn.getBillingAddress().getRegion());

		assertEquals(fraudHomeAddress.getStreetAddress(), deviceXtn.getBillingAddress().getStreetAddress());

		assertEquals(fraudShipAddress.getCompany(),
				deviceXtn.getShippingAddress().getCompany() == null ? "" : deviceXtn.getShippingAddress().getCompany());

		assertEquals(fraudShipAddress.getCountryCode(), deviceXtn.getShippingAddress().getCountryCode());

		assertEquals(fraudShipAddress.getExtendedAddress(),
				deviceXtn.getShippingAddress().getExtendedAddress() == null ? ""
						: deviceXtn.getShippingAddress().getExtendedAddress());

		assertEquals(fraudShipAddress.getFirstName(), deviceXtn.getShippingAddress().getFirstName());

		assertEquals(fraudShipAddress.getLastName(), deviceXtn.getShippingAddress().getLastName());

		assertEquals(fraudShipAddress.getLocality(), deviceXtn.getShippingAddress().getLocality());

		assertEquals(fraudShipAddress.getPostalCode(), deviceXtn.getShippingAddress().getPostalCode());

		assertEquals(fraudShipAddress.getRegion(), deviceXtn.getShippingAddress().getRegion());

		assertEquals(fraudShipAddress.getStreetAddress(), deviceXtn.getShippingAddress().getStreetAddress());

		assertEquals(deviceIn.getPurchaseFraudInfo().getTransactionType(), deviceXtn.getTransactionType());
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_PurchaseDevice_NullKountInfo_Success() throws Exception {

		VisibleRequestPurchaseDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestPurchaseDevice.class,
				DATA_DIR.PURCHASED_DEVICE + "VisibleRequestPurchaseDevice_ValidSimpleRequest.json", "PurchaseFraudInfo");

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.PURCHASED_DEVICE + "MtxResponseMulti.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.PURCHASED_DEVICE + "MtxResponseSubscriber.json");
		VisibleResponsePurchaseDevice deviceOut = new VisibleResponsePurchaseDevice();
		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		doReturn(multiRes).when(instance).multiRequest(any(), any(), any());
		// method to test
		instance.purchaseDevice(deviceIn, deviceOut);

		// Assertions here.
		assertEquals("0", String.valueOf(deviceOut.getResult()));
		assertEquals("OK", String.valueOf(deviceOut.getResultText()));
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_PurchaseDevice_HomeBidDifferentShipToBid_HomeBidDifferentGLCenter_GLCenterChangeAndUndo()
			throws Exception {
		// Test case to check that GoodTypes are populated correctly
		VisibleRequestPurchaseDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestPurchaseDevice.class,
				DATA_DIR.PURCHASED_DEVICE + "VisibleRequestPurchaseDevice_ValidSimpleRequest.json");

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.PURCHASED_DEVICE + "MtxResponseMulti.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.PURCHASED_DEVICE + "MtxResponseSubscriber.json");
		VisibleResponsePurchaseDevice deviceOut = new VisibleResponsePurchaseDevice();
		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
		// method to test
		instance.purchaseDevice(deviceIn, deviceOut);

		// Assertions here.
		ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();

		// First Modify request should change GLCenter as per ShipToBID
		assertEquals(deviceIn.getPurchaseShippingInfo().getShipToBid(),
				((MtxRequestSubscriberModify) reqList.get(1)).getGlCenter());

		// Last Modify request should restore original GLCenter
		assertEquals(subRes.getGlCenter(),
				((MtxRequestSubscriberModify) reqList.get(reqList.size() - 1)).getGlCenter());

	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnFinancedDevice_HomeBidDifferentShipToBid_HomeBidDifferentGLCenter_GLCenterChangeAndUndo()
			throws Exception {
		// Test case to check if all events are added to adjustment reason
		VisibleRequestReturnFinancedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnFinancedDevice.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "VisibleRequestReturnFinancedDevice_ValidRequest.json");
		VisibleResponseReturnFinancedDevice deviceOut = new VisibleResponseReturnFinancedDevice();

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponseMulti_ReturnPurchasedDevice.json");

		MtxResponsePricingOffer pricingOfferDevice = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponsePricingOffer_Device.json");

		MtxResponsePricingOffer pricingOfferShipping = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponsePricingOffer_Shipping.json");

		MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "EventQueryResponseEvents_SimpleValid.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.RETURN_FINANCED_DEVICE + "MtxResponseSubscriber_refundService.json");

		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferDevice).doReturn(pricingOfferShipping).when(instance).queryPricingOffer(any(), any(),
				any());
		doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());

		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);
			instance.returnFinancedDevice(deviceIn, deviceOut);
			// Assertions here.
			ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();

			// First Modify request should change GLCenter as per ShipToBID
			assertEquals(subscriberEventInfo.getAtEventList(0).getEventDetails().getGlCenter(),
					((MtxRequestSubscriberModify) reqList.get(0)).getGlCenter());

			// Last Modify request should restore original GLCenter
			assertEquals(subRes.getGlCenter(),
					((MtxRequestSubscriberModify) reqList.get(reqList.size() - 1)).getGlCenter());
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_returnPurcasedDevice_HomeBidDifferentShipToBid_HomeBidDifferentGLCenter_GLCenterChangeAndUndo()
			throws Exception {

		VisibleRequestReturnPurchasedDevice deviceIn = CommonTestHelper.loadJsonMessage(
				VisibleRequestReturnPurchasedDevice.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "VisibleRequestReturnPurchasedDevice_ValidSimpleRequest.json");
		VisibleResponseReturnPurchasedDevice deviceOut = new VisibleResponseReturnPurchasedDevice();
		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponseMulti_ReturnPurchasedDevice.json");
		MtxResponsePricingOffer pricingOfferDevice = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Device.json");
		MtxResponsePricingOffer pricingOfferShipping = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePricingOffer_Shipping.json");
		MtxResponsePaymentHistory subPayHistory = CommonTestHelper.loadJsonMessage(MtxResponsePaymentHistory.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponsePaymentHistory.json");
		MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
	        
		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "EventQueryResponseEvents_SimpleValid.json");
		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.RETURN_PURCHASED_DEVICE + "MtxResponseSubscriber_refundService.json");

		doReturn("").when(instance).getRoute(any());
		PropertiesConfiguration mockConfig = mock(PropertiesConfiguration.class);
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());

		doReturn(pricingOfferDevice).doReturn(pricingOfferShipping).when(instance).queryPricingOffer(any(), any(),
				any());

		doReturn(subPayHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());
		doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		when(api.multi(any(), any())).thenReturn(multiRes);
		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

		try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(AppPropertyProvider.class)) {
			mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
			when(mockConfig.getBoolean(any(), any())).thenReturn(true);
			instance.returnPurchasedDevice(deviceIn, deviceOut);
			// Assertions here.
			ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();

			// First Modify request should change GLCenter as per ShipToBID
			assertEquals(subscriberEventInfo.getAtEventList(0).getEventDetails().getGlCenter(),
					((MtxRequestSubscriberModify) reqList.get(0)).getGlCenter());

			// Last Modify request should restore original GLCenter
			assertEquals(subRes.getGlCenter(),
					((MtxRequestSubscriberModify) reqList.get(reqList.size() - 1)).getGlCenter());
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_cancelDeviceSwap_HomeBidDifferentGLCenter_GLCenterChangeAndUndo() throws Exception {
		VisibleRequestCancelDeviceSwap swapIn = CommonTestHelper.loadJsonMessage(VisibleRequestCancelDeviceSwap.class,
				DATA_DIR.CANCEL_SWAP + "VisibleRequestCancelDeviceSwap.json");
		VisibleResponseCancelDeviceSwap swapOut = new VisibleResponseCancelDeviceSwap();
		MtxResponsePricingOffer pricingOfferSwap = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.CANCEL_SWAP + "MtxResponsePricingOffer.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.CANCEL_SWAP + "MtxResponseSubscriber.json");
		subRes.setGlCenter("9999999999999999999999");

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.CANCEL_SWAP + "EventQueryResponseEvents.json");
		subscriberEventInfo.getEventList().forEach(eqei -> {
			// ChangeGLCenter
			eqei.getEventDetails().setGlCenter("9999999999999999");
		});

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.CANCEL_SWAP + "MtxResponseMulti.json");

		doReturn("").when(instance).getRoute(any());

		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());

		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any());

		doReturn(pricingOfferSwap).when(instance).queryPricingOffer(any(), any(), any());

		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		when(api.multi(any(), any())).thenReturn(multiRes);
		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

		instance.cancelDeviceSwap(swapIn, swapOut);

		// Assertions here.
		ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();

		// First Modify request should change GLCenter as per ShipToBID
		assertEquals(subscriberEventInfo.getAtEventList(0).getEventDetails().getGlCenter(),
				((MtxRequestSubscriberModify) reqList.get(0)).getGlCenter());

		// Last Modify request should restore original GLCenter
		assertEquals(subRes.getGlCenter(),
				((MtxRequestSubscriberModify) reqList.get(reqList.size() - 1)).getGlCenter());
	}

	/**
	 * Loads a template pricing offer JSON data file and sets the attributes with
	 * the test attributes
	 *
	 * @param templateFilePath
	 * @param testAtrrValues   the test attributes
	 * @return pricing offer
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws IOException
	 * @throws VisibleUnitTestException 
	 */
	protected MtxResponsePricingOffer preparePricingOfferData(String templateFilePath,
			Map<String, String> testAtrrValues) throws IOException, VisibleUnitTestException {

		MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				templateFilePath);
		for (MtxPricingAttrInfo attrInfo : pricingOffer.getOfferInfo().getAttrList()) {
			String propertyName = attrInfo.getName();
			String expectedValue = testAtrrValues.get(propertyName);
			// overwrite with the expected value.
			if (expectedValue != null) {
				attrInfo.setValue(expectedValue);
				testAtrrValues.remove(propertyName);
			}
		}

		// For the remianing attributes, add to the pricing offer
		for (Entry<String, String> entrySet : testAtrrValues.entrySet()) {
			MtxPricingAttrInfo attrInfo = new MtxPricingAttrInfo();
			attrInfo.setName(entrySet.getKey());
			attrInfo.setValue(entrySet.getValue());
			pricingOffer.getOfferInfo().appendAttrList(attrInfo);
		}
		return pricingOffer;
	}

	@Test
	public void test_deviceSwap_Success() throws Exception {
		VisibleRequestDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(VisibleRequestDeviceSwap.class,
				DATA_DIR.DEVICE_SWAP + "SampleDeviceSwapRequest.json");

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.FINANCED_DEVICE + "MTXResponseMulti_PurchaseFinanceDevice.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.FINANCED_DEVICE + "MtxResponseSubscriber.json");

		final String DEVICE_SWAP_EQUIPMENT_DELTA_REASON = "sample_equip_delta";
		final String DEVICE_SWAP_EQUIPMENT_REASON = "purchase_device_swap";
		Map<String, String> testAtrrValues = new HashMap<>();
		testAtrrValues.put(DeviceService.OFFER_ATTR_FOR_DEVICE_SWAP_EQUIPMENT_REASON, DEVICE_SWAP_EQUIPMENT_REASON);
		testAtrrValues.put(DeviceService.OFFER_ATTR_DEVICE_SWAP_EQUIPMENT_DELTA_REASON,
				DEVICE_SWAP_EQUIPMENT_DELTA_REASON);
		MtxResponsePricingOffer pricingOffer = preparePricingOfferData(
				DATA_DIR.DEVICE_SWAP + "MtxResponsePricingOffer_DeviceSwap.json", testAtrrValues);

		VisibleResponseDeviceSwap deviceSwapResponse = new VisibleResponseDeviceSwap();

		deviceSwapRequest.getDeviceSwapInfo()
				.setDeviceSwapOfferExternalId(pricingOffer.getOfferInfo().getOfferId().toString());

		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		// getOfferAttributes:
		doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
		doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
		// multiRequest:
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
		doReturn("ServiceDeltaTaxDetails").when(instance).getServiceTaxDetails(any(), any(), any(), any(), any(), any(),
				any(), any(), any());

		// method to test
		instance.deviceSwap(deviceSwapRequest, deviceSwapResponse);

		MtxRequestMulti multiRequest = argumentCaptor.getValue();

		// Assert the MtxRequestMulti:
		assertEquals(7, multiRequest.getRequestList().size());
		// 1. Shipping GL modify requests:
		assertTrue(multiRequest.getRequestList().get(1) instanceof MtxRequestSubscriberModify);
		MtxRequestSubscriberModify initialGlCenterChange = (MtxRequestSubscriberModify) multiRequest.getRequestList()
				.get(1);
		assertEquals(deviceSwapRequest.getDeviceSwapShippingInfo().getShipToBid(), initialGlCenterChange.getGlCenter());

		assertTrue(multiRequest.getRequestList()
				.get(multiRequest.getRequestList().size() - 1) instanceof MtxRequestSubscriberModify);
		MtxRequestSubscriberModify revertingGlCenterChange = (MtxRequestSubscriberModify) multiRequest.getRequestList()
				.get(multiRequest.getRequestList().size() - 1);
		assertEquals(subRes.getGlCenter(), revertingGlCenterChange.getGlCenter());

		// 2. Recharge for Equipment Transaction Price
		assertTrue(multiRequest.getRequestList().get(2) instanceof MtxRequestSubscriberRecharge);
		MtxRequestSubscriberRecharge rechargeRequest = (MtxRequestSubscriberRecharge) multiRequest.getRequestList()
				.get(2);
		assertEquals(DEVICE_SWAP_EQUIPMENT_REASON, rechargeRequest.getReason());

		// 3. Purchase Device Swap Offer
		assertTrue(multiRequest.getRequestList().get(3) instanceof MtxRequestSubscriberPurchaseOffer);
		MtxRequestSubscriberPurchaseOffer purchaseRequest = (MtxRequestSubscriberPurchaseOffer) multiRequest
				.getRequestList().get(3);
		assertEquals(1, purchaseRequest.getOfferRequestArray().size());
		VisiblePurchasedOfferExtension offerExtension = (VisiblePurchasedOfferExtension) purchaseRequest
				.getAtOfferRequestArray(0).getAttr();
		assertEquals(DEVICE_SWAP_EQUIPMENT_REASON, offerExtension.getGoodType());
		assertEquals(deviceSwapRequest.getDeviceSwapInfo().getNewDeviceSku(), offerExtension.getSku());

		// 4. Recharge & purchase for the equipment delta:
		final BigDecimal EQUIPMENT_DELTA_AMOUNT = new BigDecimal("26.65");
		assertTrue(multiRequest.getRequestList().get(4) instanceof MtxRequestSubscriberRecharge);
		MtxRequestSubscriberRecharge equipRecharge = (MtxRequestSubscriberRecharge) multiRequest.getRequestList()
				.get(4);
		assertEquals(DEVICE_SWAP_EQUIPMENT_DELTA_REASON, equipRecharge.getReason());
		assertEquals(0, equipRecharge.getAmount().compareTo(EQUIPMENT_DELTA_AMOUNT));

		assertTrue(multiRequest.getRequestList().get(5) instanceof MtxRequestSubscriberPurchaseOffer);
		purchaseRequest = (MtxRequestSubscriberPurchaseOffer) multiRequest.getRequestList().get(5);
		assertEquals(1, purchaseRequest.getOfferRequestArray().size());
		offerExtension = (VisiblePurchasedOfferExtension) purchaseRequest.getAtOfferRequestArray(0).getAttr();
		assertEquals(DEVICE_SWAP_EQUIPMENT_DELTA_REASON, offerExtension.getGoodType());
		assertEquals(deviceSwapRequest.getDeviceSwapInfo().getNewDeviceSku(), offerExtension.getSku());
		assertEquals(0, offerExtension.getChargeAmount().compareTo(EQUIPMENT_DELTA_AMOUNT));
		assertEquals(equipRecharge.getInfo(), offerExtension.getInfo());

		assertEquals("0", String.valueOf(deviceSwapResponse.getResult()));
		assertEquals("OK", deviceSwapResponse.getResultText());

		assertNull(equipRecharge.getRechargeAttr());
	}

	@Test
	public void test_deviceSwap_Success_WithoutShipping() throws Exception {
		VisibleRequestDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(VisibleRequestDeviceSwap.class,
				DATA_DIR.DEVICE_SWAP + "SampleDeviceSwapRequest.json");

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.FINANCED_DEVICE + "MTXResponseMulti_PurchaseFinanceDevice.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.FINANCED_DEVICE + "MtxResponseSubscriber.json");

		final String DEVICE_SWAP_EQUIPMENT_DELTA_REASON = "sample_equip_delta";
		final String DEVICE_SWAP_EQUIPMENT_REASON = "purchase_device_swap";
		Map<String, String> testAtrrValues = new HashMap<>();
		testAtrrValues.put(DeviceService.OFFER_ATTR_FOR_DEVICE_SWAP_EQUIPMENT_REASON, DEVICE_SWAP_EQUIPMENT_REASON);
		testAtrrValues.put(DeviceService.OFFER_ATTR_DEVICE_SWAP_EQUIPMENT_DELTA_REASON,
				DEVICE_SWAP_EQUIPMENT_DELTA_REASON);
		MtxResponsePricingOffer pricingOffer = preparePricingOfferData(
				DATA_DIR.DEVICE_SWAP + "MtxResponsePricingOffer_DeviceSwap.json", testAtrrValues);

		VisibleResponseDeviceSwap deviceSwapResponse = new VisibleResponseDeviceSwap();

		deviceSwapRequest.getDeviceSwapInfo()
				.setDeviceSwapOfferExternalId(pricingOffer.getOfferInfo().getOfferId().toString());
		deviceSwapRequest.getDeviceSwapShippingInfo()
				.setShipToBid(((VisibleSubscriberExtension) subRes.getAttr()).gethomeBID());

		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		// getOfferAttributes:
		doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
		doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
		// multiRequest:
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
		doReturn("ServiceDeltaTaxDetails").when(instance).getServiceTaxDetails(any(), any(), any(), any(), any(), any(),
				any(), any(), any());

		// method to test
		instance.deviceSwap(deviceSwapRequest, deviceSwapResponse);

		MtxRequestMulti multiRequest = argumentCaptor.getValue();

		// Assert the MtxRequestMulti:
		assertEquals(5, multiRequest.getRequestList().size());

		// Recharge for Equipment Transaction Price
		assertTrue(multiRequest.getRequestList().get(1) instanceof MtxRequestSubscriberRecharge);

		assertEquals("0", String.valueOf(deviceSwapResponse.getResult()));
		assertEquals("OK", deviceSwapResponse.getResultText());
		assertNull(((MtxRequestSubscriberRecharge) multiRequest.getRequestList().get(1)).getRechargeAttr());
	}

	@Test
	@Ignore
	public void test_deviceSwap_585() throws Exception {
		VisibleRequestDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(VisibleRequestDeviceSwap.class,
				DATA_DIR.DEVICE_SWAP + "MTXTAX-585_DeviceSwapRequest.json");

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.FINANCED_DEVICE + "MTXResponseMulti_PurchaseFinanceDevice.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.FINANCED_DEVICE + "MtxResponseSubscriber.json");

		final String DEVICE_SWAP_EQUIPMENT_DELTA_REASON = "sample_equip_delta";
		final String DEVICE_SWAP_EQUIPMENT_REASON = "purchase_device_swap";
		Map<String, String> testAtrrValues = new HashMap<>();
		testAtrrValues.put(DeviceService.OFFER_ATTR_FOR_DEVICE_SWAP_EQUIPMENT_REASON, DEVICE_SWAP_EQUIPMENT_REASON);
		testAtrrValues.put(DeviceService.OFFER_ATTR_DEVICE_SWAP_EQUIPMENT_DELTA_REASON,
				DEVICE_SWAP_EQUIPMENT_DELTA_REASON);
		MtxResponsePricingOffer pricingOffer = preparePricingOfferData(
				DATA_DIR.DEVICE_SWAP + "MtxResponsePricingOffer_DeviceSwap.json", testAtrrValues);

		VisibleResponseDeviceSwap deviceSwapResponse = new VisibleResponseDeviceSwap();

		deviceSwapRequest.getDeviceSwapInfo()
				.setDeviceSwapOfferExternalId(pricingOffer.getOfferInfo().getOfferId().toString());

		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		// getOfferAttributes:
		doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());

		// multiRequest:
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

		// method to test
		instance.deviceSwap(deviceSwapRequest, deviceSwapResponse);

		MtxRequestMulti multiRequest = argumentCaptor.getValue();

		// Assert the MtxRequestMulti:
		assertEquals(4, multiRequest.getRequestList().size());
		// 1. Shipping GL modify requests:
		assertTrue(multiRequest.getRequestList().get(1) instanceof MtxRequestSubscriberModify);
		MtxRequestSubscriberModify initialGlCenterChange = (MtxRequestSubscriberModify) multiRequest.getRequestList()
				.get(1);
		assertEquals(deviceSwapRequest.getDeviceSwapShippingInfo().getShipToBid(), initialGlCenterChange.getGlCenter());

		assertTrue(multiRequest.getRequestList()
				.get(multiRequest.getRequestList().size() - 1) instanceof MtxRequestSubscriberModify);
		MtxRequestSubscriberModify revertingGlCenterChange = (MtxRequestSubscriberModify) multiRequest.getRequestList()
				.get(multiRequest.getRequestList().size() - 1);
		assertEquals(subRes.getGlCenter(), revertingGlCenterChange.getGlCenter());

		// 3. Purchase Device Swap Offer
		assertTrue(multiRequest.getRequestList().get(0) instanceof MtxRequestSubscriberPurchaseOffer);
		MtxRequestSubscriberPurchaseOffer purchaseRequest = (MtxRequestSubscriberPurchaseOffer) multiRequest
				.getRequestList().get(0);
		assertEquals(1, purchaseRequest.getOfferRequestArray().size());
		VisiblePurchasedOfferExtension offerExtension = (VisiblePurchasedOfferExtension) purchaseRequest
				.getAtOfferRequestArray(0).getAttr();
		assertEquals(DEVICE_SWAP_EQUIPMENT_REASON, offerExtension.getGoodType());
		assertEquals(deviceSwapRequest.getDeviceSwapInfo().getNewDeviceSku(), offerExtension.getSku());

		assertEquals("0", String.valueOf(deviceSwapResponse.getResult()));
		assertEquals("OK", deviceSwapResponse.getResultText());
		MtxRequestSubscriberRecharge rechargeReq = (MtxRequestSubscriberRecharge) multiRequest.get(3);
		VisibleRechargeExtension extn = (VisibleRechargeExtension) rechargeReq.getRechargeAttr();
		assertEquals("0000000001", extn.getOrderId());
	}

	@Test
	public void test_deviceSwap_errorHandling() throws Exception {
		VisibleRequestDeviceSwap deviceSwapRequest = CommonTestHelper.loadJsonMessage(VisibleRequestDeviceSwap.class,
				DATA_DIR.DEVICE_SWAP + "SampleDeviceSwapRequest.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.FINANCED_DEVICE + "MtxResponseSubscriber.json");

		final String DEVICE_SWAP_EQUIPMENT_DELTA_REASON = "sample_equip_delta";
		final String DEVICE_SWAP_EQUIPMENT_REASON = "purchase_device_swap";
		Map<String, String> testAtrrValues = new HashMap<>();
		testAtrrValues.put(DeviceService.OFFER_ATTR_FOR_DEVICE_SWAP_EQUIPMENT_REASON, DEVICE_SWAP_EQUIPMENT_REASON);
		testAtrrValues.put(DeviceService.OFFER_ATTR_DEVICE_SWAP_EQUIPMENT_DELTA_REASON,
				DEVICE_SWAP_EQUIPMENT_DELTA_REASON);
		MtxResponsePricingOffer pricingOffer = preparePricingOfferData(
				DATA_DIR.DEVICE_SWAP + "MtxResponsePricingOffer_DeviceSwap.json", testAtrrValues);

		VisibleResponseDeviceSwap deviceSwapResponse = new VisibleResponseDeviceSwap();

		deviceSwapRequest.getDeviceSwapInfo()
				.setDeviceSwapOfferExternalId(pricingOffer.getOfferInfo().getOfferId().toString());

		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		// getOfferAttributes:
		doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
		doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
		// multiRequest:
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);

		// 1. MultiRequest failed:
		doReturn(null).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
		doReturn("ServiceDeltaTaxDetails").when(instance).getServiceTaxDetails(any(), any(), any(), any(), any(), any(),
				any(), any(), any());
		try {
			instance.deviceSwap(deviceSwapRequest, deviceSwapResponse);
			fail("Expecting DeviceServiceException");
		} catch (DeviceServiceException ex) {
			assertTrue(ex.getMessage().indexOf(DeviceService.LOG_FAILED_TO_FINANCE_DEVICE) > -1);
		}

		MtxRequestMulti multiRequest = argumentCaptor.getValue();

		// Assert the MtxRequestMulti:
		assertEquals(7, multiRequest.getRequestList().size());
		// 1. Shipping GL modify requests:
		assertTrue(multiRequest.getRequestList().get(1) instanceof MtxRequestSubscriberModify);

		// 2. Offer not found
		doReturn(null).when(instance).queryPricingOffer(any(), any(), any());
		doReturn(null).when(instance).queryPricingProductOffer(any(), any(), any());
		try {
			instance.deviceSwap(deviceSwapRequest, deviceSwapResponse);
			fail("Expecting IntegrationServiceException");
		} catch (IntegrationServiceException ex) {
			System.out.println("IntegrationServiceException: " + ex.getMessage());
		}

		// 3. Validation error
		deviceSwapRequest.getDeviceSwapInfo().setRecurringServiceCharge("Fail");
		try {
			instance.deviceSwap(deviceSwapRequest, deviceSwapResponse);
			fail("Expecting InvalidRequestParameterException");
		} catch (InvalidRequestParameterException ex) {
			System.out.println("InvalidRequestParameterException: " + ex.getMessage());
		}
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_chargeNonReturnFee_ValidRequest_ChargeNrfSuccess() throws Exception {
		VisibleRequestChargeNrf chargeIn = CommonTestHelper.loadJsonMessage(VisibleRequestChargeNrf.class,
				DATA_DIR.CHARGE_NRF + "VisibleRequestChargeNrf_ValidSimpleRequest.json");

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.CHARGE_NRF + "MtxResponseMulti.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.CHARGE_NRF + "MtxResponseSubscriber.json");
		MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.CHARGE_NRF + "MtxResponsePricingOffer_Service.json");

		VisibleResponseChargeNrf chargeOut = new VisibleResponseChargeNrf();
		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
		doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
		// doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(),
		// any());
		// method to test
		instance.chargeNonReturnFee(chargeIn, chargeOut);
		// Assertions here.
		ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();
		assertTrue(reqList.size() == 4);
		assertEquals("0", String.valueOf(chargeOut.getResult()));
		assertEquals("OK", chargeOut.getResultText());
		assertTrue(chargeOut.getRiskData() != null);

	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_chargeNonReturnFee_ValidRequest_ChargeNrfSuccess_HomeBidEqShipBid() throws Exception {
		VisibleRequestChargeNrf chargeIn = CommonTestHelper.loadJsonMessage(VisibleRequestChargeNrf.class,
				DATA_DIR.CHARGE_NRF + "VisibleRequestChargeNrf_ValidSimpleRequest_SameShipBid.json");

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.CHARGE_NRF + "MtxResponseMulti_NoGlChange.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.CHARGE_NRF + "MtxResponseSubscriber.json");
		MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.CHARGE_NRF + "MtxResponsePricingOffer_Service.json");

		VisibleResponseChargeNrf chargeOut = new VisibleResponseChargeNrf();
		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
		doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
		// doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(),
		// any());
		// method to test
		instance.chargeNonReturnFee(chargeIn, chargeOut);
		// Assertions here.
		ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();
		assertTrue(reqList.size() == 2);
		assertEquals("0", String.valueOf(chargeOut.getResult()));
		assertEquals("OK", chargeOut.getResultText());
		assertTrue(chargeOut.getRiskData() != null);
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_chargeNrf_HasUdf_UdfInBTRequest() throws Exception {
		// Test case to check that GoodTypes are populated correctly

		VisibleRequestChargeNrf input = CommonTestHelper.loadJsonMessage(VisibleRequestChargeNrf.class,
				DATA_DIR.CHARGE_NRF + "VisibleRequestChargeNrf_ValidSimpleRequest.json");
		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.CHARGE_NRF + "MtxResponseMulti.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.CHARGE_NRF + "MtxResponseSubscriber.json");

		MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.CHARGE_NRF + "MtxResponsePricingOffer_Service.json");

		VisibleResponseChargeNrf output = new VisibleResponseChargeNrf();
		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
		doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

		// method to test
		instance.chargeNonReturnFee(input, output);

		// Assertions here.
		ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();
		reqList.forEach(req -> {
			System.out.println(req.toJson());
		});
		String siteIdActual = reqList.stream()
				.filter(req -> req.getMdcName().equals(MtxRequestSubscriberRecharge.class.getSimpleName()))
				.filter(req -> ((MtxRequestSubscriberRecharge) req).getReason().equals("charge_non_return_fee"))
				.map(req -> ((MtxRequestSubscriberRecharge) req).getChargeMethodData())
				.map(cmd -> ((VisibleBraintreeChargeMethodExtension) cmd.getChargeMethodAttr()).getSiteId()).findFirst()
				.get();

		String siteIdExpected = input.getNrfFraudInfo().getPaymentGatewayAttributes().stream()
				.filter(va -> va.getName().equals("SiteId")).findFirst().get().getValue();

		assertEquals(siteIdExpected, siteIdActual);
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_chargeNonReturnFee_ValidRequest_ChargeNrfFail() throws Exception {
		VisibleRequestChargeNrf chargeIn = CommonTestHelper.loadJsonMessage(VisibleRequestChargeNrf.class,
				DATA_DIR.CHARGE_NRF + "VisibleRequestChargeNrf_ValidSimpleRequest.json");

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.CHARGE_NRF + "MtxResponseMultiErrorResponse.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.CHARGE_NRF + "MtxResponseSubscriber.json");
		MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.CHARGE_NRF + "MtxResponsePricingOffer_Service.json");

		VisibleResponseChargeNrf chargeOut = new VisibleResponseChargeNrf();
		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		doReturn(multiRes).when(instance).multiRequest(any(), any(), any());
		doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
		
	    Exception exception = assertThrows(DeviceServiceException.class, () -> instance.chargeNonReturnFee(chargeIn, chargeOut));
	    exception.printStackTrace();
	    assertThat(exception.getMessage()).contains(DeviceService.FAILED_TO_CHARGE_NON_RETURN_FEE);
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_chargeNonReturnFee_NrfRechargeFail_new_Recharge_Req_Success() throws Exception {
		VisibleRequestChargeNrf chargeIn = CommonTestHelper.loadJsonMessage(VisibleRequestChargeNrf.class,
				DATA_DIR.CHARGE_NRF + "VisibleRequestChargeNrf_ValidSimpleRequest.json");

		MtxResponseMulti multiResRecharge = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.CHARGE_NRF + "MtxResponseMultiErrorResponse_RechargeFail.json");

		MtxResponseMulti multiResModRecharge = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.CHARGE_NRF + "MtxResponseMulti_new_Recharge_Success.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.CHARGE_NRF + "MtxResponseSubscriber.json");
		MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.CHARGE_NRF + "MtxResponsePricingOffer_Service.json");

		VisibleResponseChargeNrf chargeOut = new VisibleResponseChargeNrf();
		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiResRecharge).thenReturn(multiResModRecharge);

		instance.chargeNonReturnFee(chargeIn, chargeOut);
		// Assertions

		ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();
		MtxRequestSubscriberRecharge rechargeReq = (MtxRequestSubscriberRecharge) reqList.get(1);
		assertTrue(reqList.size() == 4);
		assertTrue(reqList.get(1) instanceof MtxRequestSubscriberRecharge);
		assertTrue(rechargeReq.getChargeMethodData().getChargeMethod() == 1);
		assertTrue(rechargeReq.getReason().equals("recharge_bad_debt"));
		assertEquals("0", String.valueOf(chargeOut.getResult()));
		assertEquals("OK", chargeOut.getResultText());
		assertTrue(chargeOut.getRiskData() != null);
	}

	@Test
	public void test_chargeNonReturnFee_NrfRechargeFail_new_recharge_Req_fail() throws Exception {
		VisibleRequestChargeNrf chargeIn = CommonTestHelper.loadJsonMessage(VisibleRequestChargeNrf.class,
				DATA_DIR.CHARGE_NRF + "VisibleRequestChargeNrf_ValidSimpleRequest.json");

		MtxResponseMulti multiResRecharge = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.CHARGE_NRF + "MtxResponseMultiErrorResponse_RechargeFail.json");

		MtxResponseMulti multiResAdjust = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.CHARGE_NRF + "MtxResponseMulti_new_Recharge_Fail.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.CHARGE_NRF + "MtxResponseSubscriber.json");
		MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.CHARGE_NRF + "MtxResponsePricingOffer_Service.json");

		VisibleResponseChargeNrf chargeOut = new VisibleResponseChargeNrf();
		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());

		when(api.multi(any(), any())).thenReturn(multiResRecharge).thenReturn(multiResAdjust);

        Exception exception = assertThrows(DeviceServiceException.class, () -> instance.chargeNonReturnFee(chargeIn, chargeOut));
        exception.printStackTrace();
        assertThat(exception.getMessage()).contains(DeviceService.FAILED_TO_CHARGE_NON_RETURN_FEE);
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_chargeNonReturnFee_NrfRechargeFail_No_ResponseList_Success() throws Exception {
		VisibleRequestChargeNrf chargeIn = CommonTestHelper.loadJsonMessage(VisibleRequestChargeNrf.class,
				DATA_DIR.CHARGE_NRF + "VisibleRequestChargeNrf_ValidSimpleRequest.json");

		MtxResponseMulti multiResRecharge = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.CHARGE_NRF + "MtxResponseMultiErrorResp_RechargeFail_No_ResponseList.json");

		MtxResponseMulti multiResNewRecharge = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.CHARGE_NRF + "MtxResponseMulti_new_Recharge_Success.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.CHARGE_NRF + "MtxResponseSubscriber.json");
		MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.CHARGE_NRF + "MtxResponsePricingOffer_Service.json");

		VisibleResponseChargeNrf chargeOut = new VisibleResponseChargeNrf();
		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiResRecharge).thenReturn(multiResNewRecharge);
		instance.chargeNonReturnFee(chargeIn, chargeOut);

		ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();

		MtxRequestSubscriberRecharge rechargeReq = (MtxRequestSubscriberRecharge) reqList.get(1);
		assertTrue(reqList.size() == 4);
		assertTrue(reqList.get(1) instanceof MtxRequestSubscriberRecharge);
		assertTrue(rechargeReq.getChargeMethodData().getChargeMethod() == 1);
		assertTrue(rechargeReq.getReason().equals("recharge_bad_debt"));
		assertEquals("0", String.valueOf(chargeOut.getResult()));
		assertEquals("OK", chargeOut.getResultText());
		assertTrue(chargeOut.getRiskData() != null);
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_chargeNonReturnFee_NrfRechargeFail_No_ResponseList_NotBraintreeError() throws Exception {
		VisibleRequestChargeNrf chargeIn = CommonTestHelper.loadJsonMessage(VisibleRequestChargeNrf.class,
				DATA_DIR.CHARGE_NRF + "VisibleRequestChargeNrf_ValidSimpleRequest.json");

		MtxResponseMulti multiResRecharge = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.CHARGE_NRF + "MtxResponseMultiErrorResp_RechargeFail_No_ResponseList_NotBraintreeError.json");

		MtxResponseMulti multiResNewRecharge = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.CHARGE_NRF + "MtxResponseMulti_new_Recharge_Success.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.CHARGE_NRF + "MtxResponseSubscriber.json");
		MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.CHARGE_NRF + "MtxResponsePricingOffer_Service.json");

		VisibleResponseChargeNrf chargeOut = new VisibleResponseChargeNrf();
		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiResRecharge).thenReturn(multiResNewRecharge);
	
	    Exception exception = assertThrows(DeviceServiceException.class, () -> instance.chargeNonReturnFee(chargeIn, chargeOut));
	    exception.printStackTrace();
	    assertThat(exception.getMessage()).contains(DeviceService.FAILED_TO_CHARGE_NON_RETURN_FEE);
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_chargeNonReturnFee_NrfRechargeFail_ResponseList_NotBraintreeError() throws Exception {
		VisibleRequestChargeNrf chargeIn = CommonTestHelper.loadJsonMessage(VisibleRequestChargeNrf.class,
				DATA_DIR.CHARGE_NRF + "VisibleRequestChargeNrf_ValidSimpleRequest.json");

		MtxResponseMulti multiResRecharge = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.CHARGE_NRF + "MtxResponseMultiErrorResponse_RechargeFail_responseList_notBraintreeError.json");

		MtxResponseMulti multiResNewRecharge = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.CHARGE_NRF + "MtxResponseMulti_new_Recharge_Success.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.CHARGE_NRF + "MtxResponseSubscriber.json");
		MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.CHARGE_NRF + "MtxResponsePricingOffer_Service.json");

		VisibleResponseChargeNrf chargeOut = new VisibleResponseChargeNrf();
		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiResRecharge).thenReturn(multiResNewRecharge);

	    Exception exception = assertThrows(DeviceServiceException.class, () -> instance.chargeNonReturnFee(chargeIn, chargeOut));
	    exception.printStackTrace();
	    assertThat(exception.getMessage()).contains(DeviceService.FAILED_TO_CHARGE_NON_RETURN_FEE);
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_reverseNonReturnFee_PayNowFail_SuccessWithBadDebt() throws Exception {

		VisibleResponseReverseNrf output = new VisibleResponseReverseNrf();
		VisibleRequestReverseNrf input = CommonTestHelper.loadJsonMessage(VisibleRequestReverseNrf.class,
				DATA_DIR.REVERSE_NRF + "VisibleRequestReverseNrf.json");
		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.REVERSE_NRF + "MtxResponseSubscriber.json");
		MtxResponsePricingOffer pricingOfferNrf = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.REVERSE_NRF + "MtxResponsePricingCatalogItem_NrfOffer.json");
		MtxResponseMulti multiResp = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.REVERSE_NRF + "MtxResponseMulti.json");
		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.REVERSE_NRF + "EventQueryResponseEvents.json");

		subscriberEventInfo.getEventList().stream()
				.filter(eInfo -> eInfo.getEventDetails().getMdcName().equals("MtxRechargeEvent")).forEach(eInfo -> {
					((MtxRechargeEvent) eInfo.getEventDetails()).setReason("recharge_bad_debt");
				});

		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferNrf).when(instance).queryPricingOffer(any(), any(), any());

		// Capture multi input and assert
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

		instance.reverseNonReturnFee(input, output);

		String adjReason = (new MtxRequestSubscriberAdjustBalance(argumentCaptor.getValue().getRequestList().stream()
				.filter(req -> req.getMdcName().equals("MtxRequestSubscriberAdjustBalance")).findFirst().get()))
						.getReason();

		String purchaseEventIds = subscriberEventInfo.getEventList().stream().map(eInfo -> eInfo.getEventDetails())
				.filter(event -> event.getMdcName().equals("MtxPurchaseEvent"))
				.filter(event -> ((MtxPurchaseEvent) event).getAppliedCatalogItemArray() != null)
				.filter(event -> ((MtxPurchaseEvent) event).getAtAppliedCatalogItemArray(0).getCatalogItemExternalId()
						.equals(input.getCancelNrfOrderInfo().getOfferExternalId()))
				.map(event -> event.getEventId()).collect(Collectors.joining(StringUtils.SPACE));
		String rechargeEventIds = subscriberEventInfo.getEventList().stream().map(eInfo -> eInfo.getEventDetails())
				.filter(event -> event.getMdcName().equals("MtxRechargeEvent"))
				.filter(event -> ((MtxRechargeEvent) event).getReason().equals("charge_non_return_fee"))
				.map(event -> event.getEventId()).collect(Collectors.joining(StringUtils.SPACE));

		// Adjust reason has $Reversal
		assertTrue(adjReason.contains("$Reversal"));
		// Adjust reason has purchase event ids
		assertTrue(adjReason.contains(purchaseEventIds));
		// Adjust reason has recharge event ids
		assertTrue(adjReason.contains(rechargeEventIds));
		// Check adjusted amount is same as charge amount
		System.out.println(output.toJson());
		assertEquals(0,
				(new MtxRequestSubscriberAdjustBalance(argumentCaptor.getValue().getRequestList().stream()
						.filter(req -> req.getMdcName().equals("MtxRequestSubscriberAdjustBalance")).findFirst().get()))
								.getAmount().doubleValue(),
				0.001);
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_reverseNonReturnFee_PayNowSuccess_SuccessNormal() throws Exception {

		VisibleResponseReverseNrf output = new VisibleResponseReverseNrf();
		VisibleRequestReverseNrf input = CommonTestHelper.loadJsonMessage(VisibleRequestReverseNrf.class,
				DATA_DIR.REVERSE_NRF + "VisibleRequestReverseNrf.json");
		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.REVERSE_NRF + "MtxResponseSubscriber.json");

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.REVERSE_NRF + "EventQueryResponseEvents.json");

		MtxResponsePricingOffer pricingOfferNrf = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.REVERSE_NRF + "MtxResponsePricingCatalogItem_NrfOffer.json");

		MtxResponsePaymentHistory paymentHistory = CommonTestHelper.loadJsonMessage(MtxResponsePaymentHistory.class,
				DATA_DIR.REVERSE_NRF + "MtxResponsePaymentHistory.json");

		MtxResponseMulti multiResp = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.REVERSE_NRF + "MtxResponseMulti.json");

		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferNrf).when(instance).queryPricingOffer(any(), any(), any());
		doReturn(paymentHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());

		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

		// Capture multi input and assert
		instance.reverseNonReturnFee(input, output);

		System.out.println(output.toJson());

		String adjReason = (new MtxRequestSubscriberAdjustBalance(argumentCaptor.getValue().getRequestList().stream()
				.filter(req -> req.getMdcName().equals("MtxRequestSubscriberAdjustBalance")).findFirst().get()))
						.getReason();

		String purchaseEventIds = subscriberEventInfo.getEventList().stream().map(eInfo -> eInfo.getEventDetails())
				.filter(event -> event.getMdcName().equals("MtxPurchaseEvent"))
				.filter(event -> ((MtxPurchaseEvent) event).getAppliedCatalogItemArray() != null)
				.filter(event -> ((MtxPurchaseEvent) event).getAtAppliedCatalogItemArray(0).getCatalogItemExternalId()
						.equals(input.getCancelNrfOrderInfo().getOfferExternalId()))
				.map(event -> event.getEventId()).collect(Collectors.joining(StringUtils.SPACE));
		String rechargeEventIds = subscriberEventInfo.getEventList().stream().map(eInfo -> eInfo.getEventDetails())
				.filter(event -> event.getMdcName().equals("MtxRechargeEvent"))
				.filter(event -> ((MtxRechargeEvent) event).getReason().equals("charge_non_return_fee"))
				.map(event -> event.getEventId()).collect(Collectors.joining(StringUtils.SPACE));
		double chargeAmount = subscriberEventInfo.getEventList().stream().map(eInfo -> eInfo.getEventDetails())
				.filter(event -> event.getMdcName().equals("MtxPurchaseEvent"))
				.filter(event -> ((MtxPurchaseEvent) event).getAppliedCatalogItemArray() != null)
				.filter(event -> ((MtxPurchaseEvent) event).getAtAppliedCatalogItemArray(0).getCatalogItemExternalId()
						.equals(input.getCancelNrfOrderInfo().getOfferExternalId()))
				.map(event -> ((MtxPurchaseEvent) event).getAtAppliedOfferArray(0).getPurchasedOfferAttr())
				.map(poe -> ((VisiblePurchasedOfferExtension) poe).getChargeAmount()).mapToDouble(d -> d.doubleValue())
				.sum();
		// Adjust reason has $Reversal
		assertTrue(adjReason.contains("$Reversal"));
		// Adjust reason has purchase event ids
		assertTrue(adjReason.contains(purchaseEventIds));
		// Adjust reason has recharge event ids
		assertTrue(adjReason.contains(rechargeEventIds));
		// Check adjusted amount is same as charge amount
		assertEquals(chargeAmount,
				(new MtxRequestSubscriberAdjustBalance(argumentCaptor.getValue().getRequestList().stream()
						.filter(req -> req.getMdcName().equals("MtxRequestSubscriberAdjustBalance")).findFirst().get()))
								.getAmount().doubleValue(),
				0.001);

		// Check refund amount is same as charge amount
		assertEquals(chargeAmount,
				(new MtxRequestSubscriberRefundPayment(argumentCaptor.getValue().getRequestList().stream()
						.filter(req -> req.getMdcName().equals("MtxRequestSubscriberRefundPayment")).findFirst().get()))
								.getAmount().doubleValue(),
				0.01);
		String refundInfo = (new MtxRequestSubscriberRefundPayment(argumentCaptor.getValue().getRequestList().stream()
				.filter(req -> req.getMdcName().equals("MtxRequestSubscriberRefundPayment")).findFirst().get()))
						.getInfo();

		// refundInfo has $Reversal
		assertTrue(refundInfo.contains("$Reversal"));
		// refundInfo has purchase event ids
		assertTrue(refundInfo.contains(purchaseEventIds));
		// refundInfo has recharge event ids
		assertTrue(refundInfo.contains(rechargeEventIds));
		// Refund reason should be as per configured offer attribute
		assertEquals(pricingOfferNrf.getOfferInfo().getAttrList().stream()
				.filter(pai -> pai.getName().equals("refund_reason")).map(pai -> pai.getValue()).findFirst().get(),
				(new MtxRequestSubscriberRefundPayment(argumentCaptor.getValue().getRequestList().stream()
						.filter(req -> req.getMdcName().equals("MtxRequestSubscriberRefundPayment")).findFirst().get()))
								.getReason());

		if (argumentCaptor.getValue().getRequestList().stream()
				.filter(req -> req.getMdcName().equals("MtxRequestSubscriberModify")).count() > 0) {
			// Make sure that original gl center is restored
			assertEquals(subRes.getGlCenter(),
					(new MtxRequestSubscriberModify(argumentCaptor.getValue().getRequestList().stream()
							.filter(req -> req.getMdcName().equals("MtxRequestSubscriberModify")).skip(1).findFirst()
							.get())).getGlCenter());
		}

	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_reverseNonReturnFee_NoAuth_DeviceServiceException() throws Exception {

		VisibleResponseReverseNrf output = new VisibleResponseReverseNrf();
		VisibleRequestReverseNrf input = CommonTestHelper.loadJsonMessage(VisibleRequestReverseNrf.class,
				DATA_DIR.REVERSE_NRF + "VisibleRequestReverseNrf.json");
		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.REVERSE_NRF + "MtxResponseSubscriber.json");
		MtxResponsePricingOffer pricingOfferNrf = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.REVERSE_NRF + "MtxResponsePricingCatalogItem_NrfOffer.json");

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.REVERSE_NRF + "EventQueryResponseEvents.json");

		subscriberEventInfo.getEventList().stream().map(eqei -> eqei.getEventDetails())
				.filter(event -> event.getMdcName().equals("MtxPurchaseEvent"))
				.filter(event -> ((MtxPurchaseEvent) event).getAppliedCatalogItemArray() != null)
				.filter(event -> ((MtxPurchaseEvent) event).getAtAppliedCatalogItemArray(0).getCatalogItemExternalId()
						.equals(input.getCancelNrfOrderInfo().getOfferExternalId()))
				.map(event -> (MtxPurchaseEvent) event).forEach(pe -> {
					pe.setPaymentAuthEventId(null);
				});
		subscriberEventInfo.getEventList().stream()
				.filter(eInfo -> eInfo.getEventDetails().getMdcName().equals("MtxRechargeEvent"))
				.map(eqei -> (MtxRechargeEvent) eqei.getEventDetails())
				.filter(re -> re.getReason().equals("charge_non_return_fee")).forEach(re -> {
					re.setPaymentAuthEventId(null);
				});
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferNrf).when(instance).queryPricingOffer(any(), any(), any());

		// Capture multi input and assert
	    Exception exception = assertThrows(DeviceServiceException.class, () -> instance.reverseNonReturnFee(input, output));
	    exception.printStackTrace();
	    assertThat(exception.getMessage()).contains(DeviceService.LOG_PAYAUTH_NOT_FOUND);	
		System.out.println(output.toJson());
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_reverseNonReturnFee_PaymentResourceIdNotFound_DeviceServiceException() throws Exception {

		VisibleResponseReverseNrf output = new VisibleResponseReverseNrf();
		VisibleRequestReverseNrf input = CommonTestHelper.loadJsonMessage(VisibleRequestReverseNrf.class,
				DATA_DIR.REVERSE_NRF + "VisibleRequestReverseNrf.json");
		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.REVERSE_NRF + "MtxResponseSubscriber.json");

		MtxResponsePricingOffer pricingOfferNrf = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				DATA_DIR.REVERSE_NRF + "MtxResponsePricingCatalogItem_NrfOffer.json");

		MtxResponsePaymentHistory paymentHistory = CommonTestHelper.loadJsonMessage(MtxResponsePaymentHistory.class,
				DATA_DIR.REVERSE_NRF + "MtxResponsePaymentHistory.json");

		EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.loadJsonMessage(EventQueryResponseEvents.class,
				DATA_DIR.REVERSE_NRF + "EventQueryResponseEvents.json");

		subscriberEventInfo.getEventList().stream().map(eqei -> eqei.getEventDetails())
				.filter(event -> event.getMdcName().equals("MtxPurchaseEvent"))
				.filter(event -> ((MtxPurchaseEvent) event).getAppliedCatalogItemArray() != null)
				.filter(event -> ((MtxPurchaseEvent) event).getAtAppliedCatalogItemArray(0).getCatalogItemExternalId()
						.equals(input.getCancelNrfOrderInfo().getOfferExternalId()))
				.map(event -> (MtxPurchaseEvent) event).forEach(pe -> {
					pe.setPaymentAuthEventId("miXLs9cNXAd1eEp");
				});

		subscriberEventInfo.getEventList().stream()
				.filter(eInfo -> eInfo.getEventDetails().getMdcName().equals("MtxRechargeEvent"))
				.map(eqei -> (MtxRechargeEvent) eqei.getEventDetails())
				.filter(re -> re.getReason().equals("recharge_bad_debt")).forEach(re -> {
					re.setPaymentAuthEventId("miXLs9cNXAd1eEp");
				});

		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		doReturn(subscriberEventInfo).when(instance).querySubscriberEventList(any(), any(), any(), any());
		doReturn(pricingOfferNrf).when(instance).queryPricingOffer(any(), any(), any());
		doReturn(paymentHistory).when(instance).querySubscriberPaymentHistory(any(), any(), any());

	    Exception exception = assertThrows(DeviceServiceException.class, () -> instance.reverseNonReturnFee(input, output));
	    exception.printStackTrace();
	    assertThat(exception.getMessage()).contains(DeviceService.LOG_PAYMENT_RESOURCE_ID_NOT_FOUND);
		System.out.println(output.toJson());
	}
}
