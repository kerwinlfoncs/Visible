package com.matrixx.vag.advice.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixx.datacontainer.MtxDate;
import com.matrixx.datacontainer.MtxObjectId;
import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.*;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.ObjectSummary;
import com.matrixx.vag.common.Constants.CREDIT_CONSTANTS;
import com.matrixx.vag.common.Constants.GENERIC_CONSTANTS;
import com.matrixx.vag.common.Constants.GROUP_CONSTANTS;
import com.matrixx.vag.common.Constants.OFFER_CONSTANTS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.Constants.TAX_CONSTANTS;
import com.matrixx.vag.common.OneParameterTest;
import com.matrixx.vag.common.TestConstants.*;
import com.matrixx.vag.common.TestUtils;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.IntegrationServiceException;
import com.matrixx.vag.exception.PaymentAdviceException;
import com.matrixx.vag.exception.TaxApiException;
import com.matrixx.vag.exception.VisibleUnitTestException;
import com.matrixx.vag.tax.client.TaxApiClient;
import com.matrixx.vag.tax.model.ServiceTaxRequest;
import com.matrixx.vag.tax.model.ServiceTaxResponse;
import com.matrixx.vag.util.MDCTest;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.*;
import wiremock.org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.doReturn;

public class QuoteAdviceServiceTest extends MDCTest {

    @Spy
    @InjectMocks
    private PaymentAdviceService instance = new PaymentAdviceService();

    @Mock
    private SubscriberManagementApi api;

    private TestInfo testInfo;

    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        instance = new PaymentAdviceService();
        MockitoAnnotations.openMocks(this);
        this.testInfo = testInfo;
        doReturn("").when(instance).getRoute(any());
    }

    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_GeoCodeInRequest_Then_CorrectGeoCodeInServiceTaxRequest")
    @Tag("Tax")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Active user.|"
                +"|When |QuoteAdvice Api is called with geocode in request.|"
                +"|Then |taxapi should be called with geocode in parameter|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_GeoCodeInRequest_Then_CorrectGeoCodeInServiceTaxRequest(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String testGeoCode = "ELBISIVNOZIREV";
        intiateAopQuoteTaxTest();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.INSURANCE);
        input.setTaxGeoCode(testGeoCode);
        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        String taxApiResp = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.INSURANCE);
        emulateMtxResponseMulti(instance, DATA_DIR.QUOTE_ADVICE + "MtxResponseMultiAoc.json");
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            // method to test
            instance.getQuoteAdvice(input, output);
            System.out.println(output.toJson());
            argumentCaptor.getAllValues().forEach(taxReq -> {
                System.out.println(taxReq);
            });

            String serviceTaxGeoCode = argumentCaptor.getAllValues().stream().map(taxString -> {
                try {
                    return CommonTestHelper.getJsonFromString(ServiceTaxRequest.class, taxString);
                } catch (IOException e) {
                    e.printStackTrace();
                    return null;
                }
            }).filter(taxReq -> taxReq.getClassCode().equals("SVC")).map(
                    taxReq -> taxReq.getGeocode()).findFirst().get();

            String insuranceTaxGeoCode = argumentCaptor.getAllValues().stream().map(taxString -> {
                try {
                    return CommonTestHelper.getJsonFromString(ServiceTaxRequest.class, taxString);
                } catch (IOException e) {
                    e.printStackTrace();
                    return null;
                }
            }).filter(taxReq -> taxReq.getClassCode().equals("FEA")).map(
                    taxReq -> taxReq.getGeocode()).findFirst().get();

            assertEquals(testGeoCode, serviceTaxGeoCode);
            assertEquals(testGeoCode, insuranceTaxGeoCode);
        }
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_FeeMoreThanServiceamount_Then_FeeIsPayableamount")
    @Tag("Tax")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Active user.|"
                +"|When |Taxapi returns fee that is larger that actual service amount for remaining of current billcycle.|"
                +"|Then |Pay entire fee as payable|"
                +"|Comments |This can happen when quote advive is requested in last 1-2 days of bill cycle.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_FeeMoreThanServiceamount_Then_FeeIsPayableamount(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        BigDecimal largeFeeAmount = BigDecimal.valueOf(80);
        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", CI_EXTERNAL_IDS.PLUS_CURRENT);

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        subscription.getBalanceArrayAppender().clear();
        System.out.println(testInfo.getDisplayName() + ": " + subscription.toJson());

        MtxResponseMulti aocResponseMulti = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase aocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfo(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                BALANCE_NAMES.MAIN_BALANCE, input.getAtCatalogItemList(0).getDiscountPrice());
        aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);

        aocResponseMulti.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        aocResponseMulti.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        aocResponseMulti.getResponseListAppender().add(aocResp);

        MtxResponseMulti grantBalances = CommonTestHelper.getEmptyMtxResponseMulti();

        List<MtxResponseMulti> multiResponses = new ArrayList<MtxResponseMulti>();
        multiResponses.add(aocResponseMulti);
        multiResponses.add(grantBalances);

        emulate2MtxResponseMultiFromObjects(instance, multiResponses);
        emulateMtxResponsePricingCatalogItem(
                instance, input.getAtCatalogItemList(0).getCatalogItemExternalId());
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponseSubscription(instance, subscription);
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        String taxRespString = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId());

        // method to test
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            ObjectMapper om = TestUtils.getObjectMapper();
            ServiceTaxResponse resp = om.readValue(taxRespString, ServiceTaxResponse.class);
            resp.getTransactionElement().get(0).setTotalFeeAmount(largeFeeAmount);
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    resp.toJson());
            // method to test
            instance.getQuoteAdvice(input, output);
        }

        System.out.println(testInfo.getDisplayName() + ": " + output.toJson());
        BigDecimal payableAmount = output.getVisibleOfferDetailsList().get(0).getPayableAmount();
        assertEquals(largeFeeAmount.doubleValue(), payableAmount.doubleValue(), 0.001);
    }

    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_IncludeTaxDetails_N_Then_Advice_With_No_Tax")
    @Tag("Tax")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Active user.|"
                +"|When |Quote Advice requested with NO tax.|"
                +"|Then |Response with no tax|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_IncludeTaxDetails_N_Then_Advice_With_No_Tax(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        intiateQuoteAdviceTaxTest();
        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.INSURANCE);

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.INSURANCE);
        emulateMtxResponseMulti(instance, DATA_DIR.QUOTE_ADVICE + "MtxResponseMultiAoc.json");

        // method to test
        instance.getQuoteAdvice(input, output);
        System.out.println(output.toJson());

        assertEquals(RESULT_CODES.MTX_SUCCESS, output.getResult());
        assertNull(output.getAtVisibleOfferDetailsList(0).getTaxDetails());
    }

    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_GeoCodeInRequest_Then_CorrectGeoCodeInCreditTaxRequest")
    @Tag("Tax")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Active user.|"
       +"|When |QuoteAdvice Api is called with geocode in request.|"
       +"|Then |credit taxapi should be called with geocode in parameter|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_GeoCodeInRequest_Then_CorrectGeoCodeInCreditTaxRequest(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String testGeoCode = "ELBISIVNOZIREV";
        intiateAopQuoteTaxTest();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.INSURANCE);
        input.setTaxGeoCode(testGeoCode);
        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        String taxApiResp = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId());

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.INSURANCE);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);
        emulateMtxResponseMulti(instance, DATA_DIR.QUOTE_ADVICE + "MtxResponseMultiAoc.json");
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            // method to test
            instance.getQuoteAdvice(input, output);
            System.out.println(output.toJson());
            argumentCaptor.getAllValues().forEach(taxReq -> {
                System.out.println(taxReq);
            });

            argumentCaptor.getAllValues().stream().map(taxString -> {
                try {
                    return CommonTestHelper.getJsonFromString(ServiceTaxRequest.class, taxString);
                } catch (IOException e) {
                    e.printStackTrace();
                    return null;
                }
            }).map(taxReq -> taxReq.getGeocode()).forEach(creditTaxGeoCode -> {
                assertEquals(testGeoCode, creditTaxGeoCode);
            });

            assertTrue(argumentCaptor.getAllValues().size() > 0);
        }
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_Given_FIRST25Credit_Then_ValidateCreditTaxRequest")
    @Tag("Tax")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Active user with First25. First25 taxes should be calculated by subtraction method.|"
       +"|When |QuoteAdvice Api is called for Visible_Unlimited that is applicable to First25.|"
       +"|Then |Validate discount price of credit tax call|"})
    // @formatter:on    
    public void test_getQuoteAdvice_Given_FIRST25Credit_Then_ValidateCreditTaxRequest(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        intiateAopQuoteTaxTest();
        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", CI_EXTERNAL_IDS.UNLIMITED);

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        String taxApiResp = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.FIRST25_GRANT);

        MtxResponseSubscription subscriber = CommonTestHelper.getMtxResponseSubscription();
        subscriber.getBalanceArrayAppender().clear();
        MtxBalanceInfo mbiMainbalance = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.MAIN_BALANCE, null, null, null);
        subscriber.getBalanceArrayAppender().add(mbiMainbalance);

        BigDecimal f25Grant = BigDecimal.valueOf(15);
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscriber, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);

        List<MtxResponseMulti> multiRespList = new ArrayList<MtxResponseMulti>();

        MtxResponsePurchase aocResp = CommonTestHelper.getMtxResponsePurchase(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                input.getAtCatalogItemList(0).getDiscountPrice());
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        multiResponse0.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        multiResponse0.getResponseListAppender().add(aocResp);
        multiRespList.add(multiResponse0);

        MtxResponseMulti multiResponse1 = CommonTestHelper.getMtxResponseMulti_For_CreditBalances(
                subscriber);
        multiRespList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, multiRespList);

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscriber.getExternalId() + "]").when(instance).getLoggingKey(any());
        emulateMtxResponseSubscription(instance, subscriber);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            // method to test
            instance.getQuoteAdvice(input, output);
        }
        System.out.println(output.toJson());
        argumentCaptor.getAllValues().forEach(taxReq -> {
            System.out.println(taxReq);
        });
        ObjectMapper om = TestUtils.getObjectMapper();
        ServiceTaxRequest creditTaxReq = om.readValue(
                argumentCaptor.getAllValues().get(1), ServiceTaxRequest.class);

        assertEquals(
                input.getAtCatalogItemList(0).getDiscountPrice().subtract(f25Grant).intValue(),
                creditTaxReq.getDiscountPrice().intValue());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_Given_FIRST25Credit_Then_ValidateCreditTaxRequest")
    @Tag("Tax")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Active user with REF35. REF35 taxes should be calculated by subtraction method.|"
       +"|When |QuoteAdvice Api is called for Visible_Unlimited that is applicable to REF35.|"
       +"|Then |Validate discount price of credit tax call|"})
    // @formatter:on    
    public void test_getQuoteAdvice_Given_REF35Credit_Then_ValidateCreditTaxRequest(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        intiateAopQuoteTaxTest();
        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", CI_EXTERNAL_IDS.UNLIMITED);

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        String taxApiResp = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);

        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.REF35_GRANT);

        MtxResponseSubscription subscriber = CommonTestHelper.getMtxResponseSubscription();
        BigDecimal ref35Grant = BigDecimal.valueOf(35);
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscriber, CI_EXTERNAL_IDS.REF35_GRANT, null, ref35Grant, null);

        List<MtxResponseMulti> multiRespList = new ArrayList<MtxResponseMulti>();

        MtxResponsePurchase aocResp = CommonTestHelper.getMtxResponsePurchase(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                input.getAtCatalogItemList(0).getDiscountPrice());
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        multiResponse0.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        multiResponse0.getResponseListAppender().add(aocResp);
        multiRespList.add(multiResponse0);

        MtxResponseMulti multiResponse1 = CommonTestHelper.getMtxResponseMulti_For_CreditBalances(
                subscriber);
        multiRespList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, multiRespList);

        // mocks
        doReturn("[" + subscriber.getExternalId() + "]").when(instance).getLoggingKey(any());
        emulateMtxResponseSubscription(instance, subscriber);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            // method to test
            instance.getQuoteAdvice(input, output);
        }
        System.out.println(output.toJson());
        argumentCaptor.getAllValues().forEach(taxReq -> {
            System.out.println(taxReq);
        });
        ObjectMapper om = TestUtils.getObjectMapper();
        ServiceTaxRequest creditTaxReq = om.readValue(
                argumentCaptor.getAllValues().get(1), ServiceTaxRequest.class);

        assertEquals(
                input.getAtCatalogItemList(0).getDiscountPrice().subtract(ref35Grant).intValue(),
                creditTaxReq.getDiscountPrice().intValue());
    }

    @SuppressWarnings({
        "unchecked"
    })
    @ParameterizedTest(name = "test_getQuoteAdvice_Given_First25Credit_Then_ValidateCreditObject")
    @Tag("Credits")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Active user with First25.|"
       +"|When |QuoteAdvice Api is called for Visible_Unlimited that is applicable to First25.|"
       +"|Then |Validate feilds in credit block of response|"})
    // @formatter:on    
    public void test_getQuoteAdvice_Given_First25Credit_Then_ValidateCreditObject(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String testGeoCode = "ELBISIVNOZIREV";
        intiateAopQuoteTaxTest();
        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", CI_EXTERNAL_IDS.UNLIMITED);
        input.setTaxGeoCode(testGeoCode);
        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        String taxApiResp = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);

        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();

        BigDecimal f25Grant = BigDecimal.valueOf(15);
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);

        List<MtxResponseMulti> multiRespList = new ArrayList<MtxResponseMulti>();

        MtxResponsePurchase aocResp = CommonTestHelper.getMtxResponsePurchase(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                input.getAtCatalogItemList(0).getDiscountPrice());
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        multiResponse0.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        multiResponse0.getResponseListAppender().add(aocResp);
        multiRespList.add(multiResponse0);

        MtxResponseMulti multiResponse1 = CommonTestHelper.getMtxResponseMulti_For_CreditBalances(
                subscription);
        multiRespList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, multiRespList);

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        emulateMtxResponseSubscription(instance, subscription);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            // method to test
            instance.getQuoteAdvice(input, output);
            System.out.println(output.toJson());
        }

        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());
        assertEquals(f25Grant.intValue(), output.getAtCredits(0).getRedeemableCredits().intValue());
        assertEquals(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                output.getAtCredits(0).getApplicableCI());
        assertEquals(vtF25.getRedeemOffer(), output.getAtCredits(0).getCreditRedeemableOfferCI());
        assertEquals(
                vtF25.getDiscountCalculationMethod(),
                output.getAtCredits(0).getDiscountCalculationMethod());
    }

    @SuppressWarnings({
        "unchecked"
    })
    @ParameterizedTest(name = "test_getQuoteAdvice_Given_SubIsInGroup_Then_ResponseHasGroup")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Active user in a group.|"
       +"|When |QuoteAdvice Api is called.|"
       +"|Then |Group details are in quote advice response.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_Given_SubIsInGroup_Then_ResponseHasGroup(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.INSURANCE);

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        String taxApiResp = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.INSURANCE);

        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();

        subscription.setParentGroupCount(1L);
        subscription.getParentGroupIdArrayAppender().clear();
        subscription.getParentGroupIdArrayAppender().add(new MtxObjectId("1-2-3-4"));

        List<MtxResponseMulti> multiRespList = new ArrayList<MtxResponseMulti>();

        MtxResponsePurchase aocResp = CommonTestHelper.getMtxResponsePurchase(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                input.getAtCatalogItemList(0).getDiscountPrice());
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        multiResponse0.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        multiResponse0.getResponseListAppender().add(aocResp);
        multiRespList.add(multiResponse0);

        MtxResponseMulti multiResponse1 = CommonTestHelper.getMtxResponseMulti_For_CreditBalances(
                subscription);
        multiRespList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, multiRespList);

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        emulateMtxResponseSubscription(instance, subscription);
        Map<String, String> groupParams = Map.of("GroupTier", "GT99", "GroupName", "GN19");
        emulateSubscriptionGroup(instance, groupParams);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            // method to test
            instance.getQuoteAdvice(input, output);
        }

        System.out.println(output.toJson());
        assertEquals(groupParams.get("GroupTier"), output.getAtSubscriberGroups(0).getGroupTier());
        assertEquals(groupParams.get("GroupName"), output.getAtSubscriberGroups(0).getGroupName());
    }

    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_AttributesInOfferInstance_Then_OfferInstanceAttributes_Override_GrantCiAttributes")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber is NOT enrolled in Visible_Unlimited. Has some First25 consumables or First25 grants.|"
       +"|     |Purchased grant offer for First25 is present in subscriber object.|"
       +"|     |First25 grant balance is present in subscriber object.|"
       +"|When |getQuoteAdvice is called for Visible_Unlimited.|"
       +"|Then |First25 credit is reported in quote advice output.|"
       +"|     |Metadata passed in purchased grant offer's PurchasedOfferExtension will|"
       +"|     |override metadata configured in grant offer's template attributes.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_AttributesInOfferInstance_Then_OfferInstanceAttributes_Override_GrantCiAttributes(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        intiateAopQuoteTaxTest();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.INSURANCE);

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.INSURANCE);

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());

        BigDecimal f25Grant = BigDecimal.TEN;
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();
        MtxPurchasedOfferInfo poF25 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setRedeemGoodType("XXX_YYY_ZZZ");
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setDiscountCalculationMethod(
                CREDIT_CONSTANTS.CALCULATION_METHOD_READ_OFFER_INSTANCE);

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        List<MtxResponseMulti> multiRespList = new ArrayList<MtxResponseMulti>();
        MtxResponseMulti multiResponse0 = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.QUOTE_ADVICE + "MtxResponseMultiAoc.json");
        multiRespList.add(multiResponse0);
        MtxResponseMulti multiResponse1 = CommonTestHelper.getMtxResponseMulti_For_CreditBalances(
                subscription);
        multiRespList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, multiRespList);

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        BigDecimal groupGrant = BigDecimal.ZERO;
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        emulateMtxResponseSubscription(instance, subscription);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getQuoteAdvice(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                "XXX_YYY_ZZZ",
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getRedeemableGoodType());
    }

    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_AttributesNotInOfferInstance_Then_Default_To_GrantCiAttributes")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber is NOT enrolled in Visible_Unlimited. Has some REF35 consumables or REF35 grants.|"
       +"|     |Purchased grant offer for REF35 is present in subscriber object.|"
       +"|     |REF35 grant balance is present in subscriber object.|"
       +"|When |getQuoteAdvice is called for Visible_Unlimited.|"
       +"|Then |REF35 credit is reported in quote advice output.|"
       +"|     |If metadata is not passed in purchased grant offer's PurchasedOfferExtension,|"
       +"|     |metadata configured in grant offer's template attributes will be used by default.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_AttributesNotInOfferInstance_Then_Default_To_GrantCiAttributes(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        intiateAopQuoteTaxTest();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.UNLIMITED);

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.INSURANCE);

        emulateAocServicePurchase(instance);

        MtxResponsePricingCatalogItem ciRef35Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.REF35_GRANT);
        VisibleTemplate vtRef35 = ((VisibleTemplate) ciRef35Grant.getCatalogItemInfo().getTemplateAttr());

        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.REF35_GRANT, null, BigDecimal.valueOf(35), null);

        List<MtxResponseMulti> multiRespList = new ArrayList<MtxResponseMulti>();
        MtxResponseMulti multiResponse0 = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.QUOTE_ADVICE + "MtxResponseMultiAoc.json");
        multiRespList.add(multiResponse0);
        MtxResponseMulti multiResponse1 = CommonTestHelper.getMtxResponseMulti_For_CreditBalances(
                subscription);
        multiRespList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, multiRespList);

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        emulateMtxResponseSubscription(instance, subscription);

        // method to test
        instance.getQuoteAdvice(input, output);
        System.out.println(output.toJson());

        String actualVal = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(
                        vtRef35.getPromotionName())).findFirst().get().getApplicableCI();
        assertEquals(CI_EXTERNAL_IDS.UNLIMITED, actualVal);
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_getQuoteAdvice_When_Two_ApplicableCi_Then_Two_Promo_Blocks")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber is NOT enrolled in Visible_Unlimited and Visible_Wearables.|"
       +"|     |Goodwill grant balance is present in subscriber object.|"
       +"|     |Goodwill Grant Template attributes has two appliocable offers.|"
       +"|When |QuoteAdvice is called for Visible_Unlimited and Visible_Wearables.|"
       +"|Then |Goodwill credit is reported twice quote advice output.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_Two_ApplicableCi_Then_Two_Promo_Blocks(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        intiateAopQuoteTaxTest();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.WEARABLE);
        System.out.println(td.getTestMethod() + " : " + input.toJson());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.WEARABLE);

        MtxResponsePricingCatalogItem pciGdw = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        VisibleTemplate vtGdw = (VisibleTemplate) pciGdw.getCatalogItemInfo().getTemplateAttr();
        vtGdw.setMinimumCharge(BigDecimal.valueOf(5));
        vtGdw.setApplicableOfferName(CI_EXTERNAL_IDS.UNLIMITED + "," + CI_EXTERNAL_IDS.WEARABLE);

        List<MtxResponseMulti> respList = new ArrayList<MtxResponseMulti>();

        // For Aoc Response for service offers
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase purResponse = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_Unlimited_Wearable.json");
        MtxResponse emptyResp = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(purResponse);

        // For Pricing query from updateStartWithGrantBalanceCredits
        MtxResponseMulti multiResponse1 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingBalance gdwGrantPricing = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingBalance.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_GoodwillGrant.json");
        multiResponse1.getResponseListAppender().add(gdwGrantPricing);
        respList.add(multiResponse0);
        respList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, respList);

        // Keep only goodwill credit for subscriber
        MtxResponseSubscription subscriber = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscriber.getBalanceArrayAppender().clear();
        subscriber.getBalanceArrayAppender().add(
                CommonTestHelper.getMtxBalanceInfo(BALANCE_NAMES.MAIN_BALANCE, null, null, null));

        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.GOODWILL_GRANT, null, null, BigDecimal.valueOf(40));
        subscriber.getBalanceArrayAppender().add(mbiGoodGrant);

        // Simple Quote Advice brand new subscriber does not have any services
        subscriber.getPurchasedOfferArrayAppender().clear();

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscriber.getExternalId() + "]").when(instance).getLoggingKey(any());
        emulateMtxResponseSubscription(instance, subscriber);

        // method to test
        instance.getQuoteAdvice(input, output);
        System.out.println(output.toJson());

        assertEquals(2, output.getCredits().size());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_1_getQuoteAdvice_When_Two_ApplicableCi_Then_RedeemOrder_As_Per_Csv")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber is NOT enrolled in Visible_Unlimited and Visible_Wearables.|"
       +"|     |Goodwill grant balance is present in subscriber object.|"
       +"|     |Goodwill Grant Template attributes has two appliocable offers.|"
       +"|When |QuoteAdvice is called for Visible_Unlimited and Visible_Wearables.|"
       +"|Then |Credits are redeemed as per order of ApplicableCi.|"})
    // @formatter:on    
    public void test_1_getQuoteAdvice_When_Two_ApplicableCi_Then_RedeemOrder_As_Per_Csv(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        intiateAopQuoteTaxTest();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.WEARABLE);
        System.out.println(td.getTestMethod() + " : " + input.toJson());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.WEARABLE);

        MtxResponsePricingCatalogItem pciGdw = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        VisibleTemplate vtGdw = (VisibleTemplate) pciGdw.getCatalogItemInfo().getTemplateAttr();
        vtGdw.setMinimumCharge(BigDecimal.valueOf(5));
        vtGdw.setApplicableOfferName(CI_EXTERNAL_IDS.UNLIMITED + "," + CI_EXTERNAL_IDS.WEARABLE);

        List<MtxResponseMulti> respList = new ArrayList<MtxResponseMulti>();

        // For Aoc Response for service offers
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase purResponse = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_Unlimited_Wearable.json");
        MtxResponse emptyResp = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(purResponse);

        // For Pricing query from updateStartWithGrantBalanceCredits
        MtxResponseMulti multiResponse1 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingBalance gdwGrantPricing = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingBalance.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_GoodwillGrant.json");
        multiResponse1.getResponseListAppender().add(gdwGrantPricing);
        respList.add(multiResponse0);
        respList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, respList);

        MtxResponseSubscription subscriber = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());

        // Keep only goodwill credit for subscriber
        subscriber.getBalanceArrayAppender().clear();
        MtxBalanceInfo mbiMainbalance = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.MAIN_BALANCE, null, null, null);
        subscriber.getBalanceArrayAppender().add(mbiMainbalance);

        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfo(
                DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Grant.json");
        mbiGoodGrant.setAvailableAmount(BigDecimal.valueOf(40));
        mbiGoodGrant.setAmount(BigDecimal.valueOf(40).negate());
        subscriber.getBalanceArrayAppender().add(mbiGoodGrant);

        // Simple Quote Advice brand new subscriber does not have any services
        subscriber.getPurchasedOfferArrayAppender().clear();

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscriber.getExternalId() + "]").when(instance).getLoggingKey(any());
        emulateMtxResponseSubscription(instance, subscriber);

        // method to test
        instance.getQuoteAdvice(input, output);
        System.out.println(td.getTestMethod() + " : " + output.toJson());

        BigDecimal unlimitedRedeemable = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(vtGdw.getPromotionName())
                        && vc.getApplicableCI().equalsIgnoreCase(
                                CI_EXTERNAL_IDS.UNLIMITED)).findFirst().get().getRedeemableCredits();
        BigDecimal unlimitedTransferable = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(vtGdw.getPromotionName())
                        && vc.getApplicableCI().equalsIgnoreCase(
                                CI_EXTERNAL_IDS.UNLIMITED)).findFirst().get().getEstimatedTransferableCredits();

        BigDecimal wearableRedeemable = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(vtGdw.getPromotionName())
                        && vc.getApplicableCI().equalsIgnoreCase(
                                CI_EXTERNAL_IDS.WEARABLE)).findFirst().get().getRedeemableCredits();
        BigDecimal wearableTransferable = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(vtGdw.getPromotionName())
                        && vc.getApplicableCI().equalsIgnoreCase(
                                CI_EXTERNAL_IDS.WEARABLE)).findFirst().get().getEstimatedTransferableCredits();

        assertEquals(35, unlimitedRedeemable.intValue());
        assertEquals(35, unlimitedTransferable.intValue());
        assertEquals(5, wearableRedeemable.intValue());
        assertEquals(5, wearableTransferable.intValue());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_2_getQuoteAdvice_When_Two_ApplicableCi_Then_RedeemOrder_As_Per_Csv")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber is NOT enrolled in Visible_Unlimited and Visible_Wearables.|"
       +"|     |Goodwill grant balance is present in subscriber object.|"
       +"|     |Goodwill Grant Template attributes has two appliocable offers.|"
       +"|When |QuoteAdvice is called for Visible_Unlimited and Visible_Wearables.|"
       +"|Then |Credits are redeemed as per order of ApplicableCi.|"})
    // @formatter:on    
    public void test_2_getQuoteAdvice_When_Two_ApplicableCi_Then_RedeemOrder_As_Per_Csv(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        intiateAopQuoteTaxTest();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.WEARABLE);
        System.out.println(td.getTestMethod() + " : " + input.toJson());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.WEARABLE);

        MtxResponsePricingCatalogItem pciGdw = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        VisibleTemplate vtGdw = (VisibleTemplate) pciGdw.getCatalogItemInfo().getTemplateAttr();
        vtGdw.setMinimumCharge(BigDecimal.valueOf(5));
        vtGdw.setApplicableOfferName(CI_EXTERNAL_IDS.UNLIMITED + "," + CI_EXTERNAL_IDS.WEARABLE);

        List<MtxResponseMulti> respList = new ArrayList<MtxResponseMulti>();

        // For Aoc Response for service offers
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase purResponse = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_Unlimited_Wearable.json");
        MtxResponse emptyResp = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(purResponse);

        // For Pricing query from updateStartWithGrantBalanceCredits
        MtxResponseMulti multiResponse1 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingBalance gdwGrantPricing = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingBalance.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_GoodwillGrant.json");
        multiResponse1.getResponseListAppender().add(gdwGrantPricing);
        respList.add(multiResponse0);
        respList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, respList);
        MtxResponseSubscription subscriber = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());

        // Keep only goodwill credit for subscriber
        subscriber.getBalanceArrayAppender().clear();
        subscriber.getBalanceArrayAppender().add(
                CommonTestHelper.getMtxBalanceInfo(BALANCE_NAMES.MAIN_BALANCE, null, null, null));

        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfo(
                DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Grant.json");
        mbiGoodGrant.setAvailableAmount(BigDecimal.valueOf(40));
        BigDecimal groupGrantAmount = BigDecimal.valueOf(40).negate();
        mbiGoodGrant.setAmount(groupGrantAmount);
        subscriber.getBalanceArrayAppender().add(mbiGoodGrant);

        // Simple Quote Advice brand new subscriber does not have any services
        subscriber.getPurchasedOfferArrayAppender().clear();

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscriber.getExternalId() + "]").when(instance).getLoggingKey(any());
        emulateMtxResponseSubscription(instance, subscriber);

        // method to test
        instance.getQuoteAdvice(input, output);
        System.out.println(td.getTestMethod() + " : " + output.toJson());

        BigDecimal unlimitedRedeemable = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(vtGdw.getPromotionName())
                        && vc.getApplicableCI().equalsIgnoreCase(
                                CI_EXTERNAL_IDS.UNLIMITED)).findFirst().get().getRedeemableCredits();
        BigDecimal unlimitedTransferable = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(vtGdw.getPromotionName())
                        && vc.getApplicableCI().equalsIgnoreCase(
                                CI_EXTERNAL_IDS.UNLIMITED)).findFirst().get().getEstimatedTransferableCredits();

        BigDecimal wearableRedeemable = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(vtGdw.getPromotionName())
                        && vc.getApplicableCI().equalsIgnoreCase(
                                CI_EXTERNAL_IDS.WEARABLE)).findFirst().get().getRedeemableCredits();
        BigDecimal wearableTransferable = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(vtGdw.getPromotionName())
                        && vc.getApplicableCI().equalsIgnoreCase(
                                CI_EXTERNAL_IDS.WEARABLE)).findFirst().get().getEstimatedTransferableCredits();

        assertEquals(35, unlimitedRedeemable.intValue());
        assertEquals(35, unlimitedTransferable.intValue());
        assertEquals(5, wearableRedeemable.intValue());
        assertEquals(5, wearableTransferable.intValue());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_Two_ApplicableCi_Then_MinCharge_Applied_For_Each_Offer")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber is NOT enrolled in Visible_Unlimited and Visible_Wearables.|"
       +"|     |Goodwill grant balance is present in subscriber object.|"
       +"|     |Goodwill Grant Template attributes has two appliocable offers.|"
       +"|When |QuoteAdvice is called for Visible_Unlimited and Visible_Wearables.|"
       +"|Then |Minimum Charge is applied to both offers.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_Two_ApplicableCi_Then_MinCharge_Applied_For_Each_Offer(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        intiateAopQuoteTaxTest();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.WEARABLE);
        System.out.println(td.getTestMethod() + " : " + input.toJson());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.WEARABLE);

        MtxResponsePricingCatalogItem pciGdw = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        VisibleTemplate vtGdw = (VisibleTemplate) pciGdw.getCatalogItemInfo().getTemplateAttr();
        vtGdw.setMinimumCharge(BigDecimal.valueOf(5));
        vtGdw.setApplicableOfferName(CI_EXTERNAL_IDS.UNLIMITED + "," + CI_EXTERNAL_IDS.WEARABLE);

        List<MtxResponseMulti> respList = new ArrayList<MtxResponseMulti>();

        // For Aoc Response for service offers
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase purResponse = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_Unlimited_Wearable.json");
        MtxResponse emptyResp = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(purResponse);

        // For Pricing query from updateStartWithGrantBalanceCredits
        MtxResponseMulti multiResponse1 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingBalance gdwGrantPricing = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingBalance.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_GoodwillGrant.json");
        multiResponse1.getResponseListAppender().add(gdwGrantPricing);
        respList.add(multiResponse0);
        respList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, respList);

        // Keep only goodwill credit for subscriber
        MtxResponseSubscription subscriber = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscriber.getBalanceArrayAppender().clear();
        subscriber.getBalanceArrayAppender().add(
                CommonTestHelper.getMtxBalanceInfo(BALANCE_NAMES.MAIN_BALANCE, null, null, null));

        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfo(
                DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Grant.json");
        mbiGoodGrant.setAvailableAmount(BigDecimal.valueOf(60));
        BigDecimal groupGrantAmount = BigDecimal.valueOf(60).negate();
        mbiGoodGrant.setAmount(groupGrantAmount);
        subscriber.getBalanceArrayAppender().add(mbiGoodGrant);

        // Simple Quote Advice brand new subscriber does not have any services
        subscriber.getPurchasedOfferArrayAppender().clear();

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscriber.getExternalId() + "]").when(instance).getLoggingKey(any());
        emulateMtxResponseSubscription(instance, subscriber);

        // method to test
        instance.getQuoteAdvice(input, output);
        System.out.println(td.getTestMethod() + " : " + output.toJson());
        BigDecimal unlimitedRedeemable = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(vtGdw.getPromotionName())
                        && vc.getApplicableCI().equalsIgnoreCase(
                                CI_EXTERNAL_IDS.UNLIMITED)).findFirst().get().getRedeemableCredits();
        BigDecimal unlimitedTransferable = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(vtGdw.getPromotionName())
                        && vc.getApplicableCI().equalsIgnoreCase(
                                CI_EXTERNAL_IDS.UNLIMITED)).findFirst().get().getEstimatedTransferableCredits();

        BigDecimal wearableRedeemable = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(vtGdw.getPromotionName())
                        && vc.getApplicableCI().equalsIgnoreCase(
                                CI_EXTERNAL_IDS.WEARABLE)).findFirst().get().getRedeemableCredits();
        BigDecimal wearableTransferable = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(vtGdw.getPromotionName())
                        && vc.getApplicableCI().equalsIgnoreCase(
                                CI_EXTERNAL_IDS.WEARABLE)).findFirst().get().getEstimatedTransferableCredits();

        assertEquals(35, unlimitedRedeemable.intValue());
        assertEquals(35, unlimitedTransferable.intValue());
        assertEquals(10, wearableRedeemable.intValue());
        assertEquals(10, wearableTransferable.intValue());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_Two_ApplicableCi_Then_MinCharge_Applied_For_Each_Offer")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber is NOT enrolled in Visible_Unlimited and Visible_Wearables.|"
       +"|     |Goodwill grant balance is present in subscriber object.|"
       +"|     |Goodwill consumable balance is present in subscriber object.|"
       +"|     |Goodwill consumable balance is more than charge amount for both of the applicable offers.|"
       +"|     |Goodwill Grant Template attributes has two appliocable offers.|"
       +"|When |QuoteAdvice is called for Visible_Unlimited and Visible_Wearables.|"
       +"|Then |There will be no transferables.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_Two_ApplicableCi_Consumable_MoreThanToalCharges_Then_Zero_Transferables(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        intiateAopQuoteTaxTest();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.WEARABLE);
        System.out.println(td.getTestMethod() + " : " + input.toJson());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.WEARABLE);

        MtxResponsePricingCatalogItem pciGdw = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        VisibleTemplate vtGdw = (VisibleTemplate) pciGdw.getCatalogItemInfo().getTemplateAttr();
        vtGdw.setApplicableOfferName("Visible_Unlimited,CDVISIBLE2022");
        vtGdw.setMinimumCharge(BigDecimal.ZERO);
        vtGdw.setPromotionLimit(BigDecimal.valueOf(20));

        List<MtxResponseMulti> respList = new ArrayList<MtxResponseMulti>();

        // For Aoc Response for service offers
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase purResponse = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_Unlimited_Wearable.json");
        purResponse.getPurchaseInfoArray().forEach(mpi -> {
            mpi.getAtBalanceImpactGroupList(0).getBalanceImpactList().forEach(bii -> {
                if ("United States dollar".equalsIgnoreCase(bii.getBalanceClassName())) {
                    bii.getBalanceImpactOfferList().forEach(offer -> {
                        if ("CDVISIBLE2022".equalsIgnoreCase(offer.getCatalogItemExternalId())) {
                            // Make AocAmount for Wearable same as input discount price
                            bii.setImpactAmount(OFFER_PRICES.WEARABLE);
                            offer.getAtBalanceImpactUpdateList(0).setAmount(OFFER_PRICES.WEARABLE);
                        }
                    });
                }
                ;
            });
        });

        MtxResponse emptyResp = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(purResponse);

        // For Pricing query from updateStartWithGrantBalanceCredits
        MtxResponseMulti multiResponse1 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingBalance gdwGrantPricing = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingBalance.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_GoodwillGrant.json");
        multiResponse1.getResponseListAppender().add(gdwGrantPricing);
        respList.add(multiResponse0);
        respList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, respList);
        System.out.println(td.getTestMethod() + " : " + multiResponse0.toJson());
        // Keep only goodwill credit for subscriber

        MtxResponseSubscription subscriber = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());

        subscriber.getBalanceArrayAppender().clear();
        subscriber.getBalanceArrayAppender().add(
                CommonTestHelper.getMtxBalanceInfo(BALANCE_NAMES.MAIN_BALANCE, null, null, null));

        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfo(
                DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Grant.json");
        mbiGoodGrant.setAvailableAmount(BigDecimal.valueOf(20));
        BigDecimal groupGrantAmount = BigDecimal.valueOf(20).negate();
        mbiGoodGrant.setAmount(groupGrantAmount);
        subscriber.getBalanceArrayAppender().add(mbiGoodGrant);

        MtxBalanceInfo mbiGoodConsump = CommonTestHelper.getMtxBalanceInfo(
                DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Consumable.json");
        mbiGoodConsump.setAvailableAmount(BigDecimal.valueOf(50));
        mbiGoodConsump.setAmount(BigDecimal.valueOf(50).negate());
        subscriber.getBalanceArrayAppender().add(mbiGoodConsump);

        // Simple Quote Advice brand new subscriber does not have any services
        subscriber.getPurchasedOfferArrayAppender().clear();

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscriber.getExternalId() + "]").when(instance).getLoggingKey(any());
        emulateMtxResponseSubscription(instance, subscriber);

        // method to test
        instance.getQuoteAdvice(input, output);
        System.out.println(td.getTestMethod() + " : " + output.toJson());
        BigDecimal unlimitedTransferable = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(vtGdw.getPromotionName())
                        && vc.getApplicableCI().equalsIgnoreCase(
                                CI_EXTERNAL_IDS.UNLIMITED)).findFirst().get().getEstimatedTransferableCredits();

        BigDecimal wearableTransferable = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(vtGdw.getPromotionName())
                        && vc.getApplicableCI().equalsIgnoreCase(
                                CI_EXTERNAL_IDS.WEARABLE)).findFirst().get().getEstimatedTransferableCredits();

        assertEquals(0, unlimitedTransferable.intValue());
        assertEquals(0, wearableTransferable.intValue());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_Two_ApplicableCi_Consumable_MoreThanOneCharge_Less_Than_Toal_Charges_Then_Both_Blocks_Have_Redeemables")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber is NOT enrolled in Visible_Unlimited and Visible_Wearables.|"
       +"|     |Goodwill grant balance is present in subscriber object.|"
       +"|     |Goodwill consumable balance is present in subscriber object.|"
       +"|     |Goodwill consumable balance is more than charge amount for both of the applicable offers.|"
       +"|     |Goodwill Grant Template attributes has two appliocable offers.|"
       +"|When |QuoteAdvice is called for Visible_Unlimited and Visible_Wearables.|"
       +"|Then |Both credit blocks will have redeemables.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_Two_ApplicableCi_Consumable_MoreThanOneCharge_Less_Than_Toal_Charges_Then_Both_Blocks_Have_Redeemables(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        intiateAopQuoteTaxTest();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.UNLIMITED);
        VisibleCatalogItem ciWearable = new VisibleCatalogItem();
        ciWearable.setCatalogItemExternalId(CI_EXTERNAL_IDS.WEARABLE);
        BigDecimal wearablePrice = BigDecimal.TEN;
        ciWearable.setDiscountPrice(wearablePrice);
        ciWearable.setGrossPrice(new BigDecimal(100));
        input.getCatalogItemListAppender().add(ciWearable);

        System.out.println(td.getTestMethod() + " : " + input.toJson());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.WEARABLE);

        MtxResponsePricingCatalogItem pciGdw = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        VisibleTemplate vtGdw = (VisibleTemplate) pciGdw.getCatalogItemInfo().getTemplateAttr();
        vtGdw.setMinimumCharge(BigDecimal.valueOf(5));
        vtGdw.setPromotionLimit(BigDecimal.valueOf(20));
        vtGdw.setApplicableOfferName(CI_EXTERNAL_IDS.UNLIMITED + "," + CI_EXTERNAL_IDS.WEARABLE);

        List<MtxResponseMulti> respList = new ArrayList<MtxResponseMulti>();

        // For Aoc Response for service offers
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase purResponse = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_Unlimited_Wearable.json");
        purResponse.getPurchaseInfoArray().forEach(mpi -> {
            mpi.getAtBalanceImpactGroupList(0).getBalanceImpactList().forEach(bii -> {
                if ("United States dollar".equalsIgnoreCase(bii.getBalanceClassName())) {
                    bii.getBalanceImpactOfferList().forEach(offer -> {
                        if (CI_EXTERNAL_IDS.WEARABLE.equalsIgnoreCase(
                                offer.getCatalogItemExternalId())) {
                            // Make AocAmount for Wearable same as input discount price
                            bii.setImpactAmount(wearablePrice);
                            offer.getAtBalanceImpactUpdateList(0).setAmount(wearablePrice);
                        }
                    });
                }
                ;
            });
        });

        MtxResponse emptyResp = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(purResponse);

        // For Pricing query from updateStartWithGrantBalanceCredits
        MtxResponseMulti multiResponse1 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingBalance gdwGrantPricing = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingBalance.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_GoodwillGrant.json");
        multiResponse1.getResponseListAppender().add(gdwGrantPricing);
        respList.add(multiResponse0);
        respList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, respList);
        System.out.println(td.getTestMethod() + " : " + multiResponse0.toJson());
        MtxResponseSubscription subscriber = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        // Keep only goodwill credit for subscriber
        subscriber.getBalanceArrayAppender().clear();
        subscriber.getBalanceArrayAppender().add(
                CommonTestHelper.getMtxBalanceInfo(BALANCE_NAMES.MAIN_BALANCE, null, null, null));

        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfo(
                DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Grant.json");
        mbiGoodGrant.setAvailableAmount(BigDecimal.valueOf(20));
        BigDecimal groupGrantAmount = BigDecimal.valueOf(20).negate();
        mbiGoodGrant.setAmount(groupGrantAmount);
        subscriber.getBalanceArrayAppender().add(mbiGoodGrant);

        MtxBalanceInfo mbiGoodConsump = CommonTestHelper.getMtxBalanceInfo(
                DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Consumable.json");
        mbiGoodConsump.setAvailableAmount(BigDecimal.valueOf(10));
        mbiGoodConsump.setAmount(BigDecimal.valueOf(10).negate());
        subscriber.getBalanceArrayAppender().add(mbiGoodConsump);

        // Simple Quote Advice brand new subscriber does not have any services
        subscriber.getPurchasedOfferArrayAppender().clear();

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscriber.getExternalId() + "]").when(instance).getLoggingKey(any());
        emulateMtxResponseSubscription(instance, subscriber);

        // method to test
        instance.getQuoteAdvice(input, output);
        System.out.println(td.getTestMethod() + " : " + output.toJson());
        BigDecimal unlimitedRedeemable = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(vtGdw.getPromotionName())
                        && vc.getApplicableCI().equalsIgnoreCase(
                                CI_EXTERNAL_IDS.UNLIMITED)).findFirst().get().getRedeemableCredits();
        BigDecimal wearableRedeemable = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(vtGdw.getPromotionName())
                        && vc.getApplicableCI().equalsIgnoreCase(
                                CI_EXTERNAL_IDS.WEARABLE)).findFirst().get().getRedeemableCredits();

        assertEquals(20, unlimitedRedeemable.intValue());
        assertEquals(5, wearableRedeemable.intValue());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_1_getQuoteAdvice_When_Two_ApplicableCi_Consumables_Present_Then_First_Offer_Has_Priority_For_Consumables")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber is NOT enrolled in Visible_Unlimited and Visible_Wearables.|"
       +"|     |Goodwill grant balance is present in subscriber object.|"
       +"|     |Goodwill consumable balance is present in subscriber object.|"       
       +"|     |Goodwill Grant Template attributes has two appliocable offers.|"
       +"|When |QuoteAdvice is called for Visible_Unlimited and Visible_Wearables.|"
       +"|Then |First_Offer_Has_Priority_For_Consumables|"})
    // @formatter:on    
    public void test_1_getQuoteAdvice_When_Two_ApplicableCi_Consumables_Present_Then_First_Offer_Has_Priority_For_Consumables(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        intiateAopQuoteTaxTest();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.UNLIMITED);
        VisibleCatalogItem ciWearable = new VisibleCatalogItem();
        ciWearable.setCatalogItemExternalId(CI_EXTERNAL_IDS.WEARABLE);
        ciWearable.setDiscountPrice(new BigDecimal(15));
        ciWearable.setGrossPrice(new BigDecimal(100));
        input.getCatalogItemListAppender().add(ciWearable);

        System.out.println(td.getTestMethod() + " : " + input.toJson());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.WEARABLE);

        MtxResponsePricingCatalogItem pciGdw = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        VisibleTemplate vtGdw = (VisibleTemplate) pciGdw.getCatalogItemInfo().getTemplateAttr();
        vtGdw.setMinimumCharge(BigDecimal.valueOf(5));
        vtGdw.setApplicableOfferName(CI_EXTERNAL_IDS.UNLIMITED + "," + CI_EXTERNAL_IDS.WEARABLE);

        List<MtxResponseMulti> respList = new ArrayList<MtxResponseMulti>();

        // For Aoc Response for service offers
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase purResponse = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_Unlimited_Wearable.json");
        MtxResponse emptyResp = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(purResponse);

        // For Pricing query from updateStartWithGrantBalanceCredits
        MtxResponseMulti multiResponse1 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingBalance gdwGrantPricing = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingBalance.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_GoodwillGrant.json");
        multiResponse1.getResponseListAppender().add(gdwGrantPricing);
        respList.add(multiResponse0);
        respList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, respList);

        MtxResponseSubscription subscriber = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());

        // Keep only goodwill credit for subscriber
        subscriber.getBalanceArrayAppender().clear();
        MtxBalanceInfo mbiMainbalance = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.MAIN_BALANCE, null, null, null);
        subscriber.getBalanceArrayAppender().add(mbiMainbalance);

        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfo(
                DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Grant.json");
        mbiGoodGrant.setAvailableAmount(BigDecimal.valueOf(40));
        mbiGoodGrant.setAmount(BigDecimal.valueOf(40).negate());
        subscriber.getBalanceArrayAppender().add(mbiGoodGrant);

        MtxBalanceInfo mbiGoodConsump = CommonTestHelper.getMtxBalanceInfo(
                DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Consumable.json");
        mbiGoodConsump.setAvailableAmount(BigDecimal.valueOf(10));
        mbiGoodConsump.setAmount(BigDecimal.valueOf(10).negate());
        subscriber.getBalanceArrayAppender().add(mbiGoodConsump);

        // Simple Quote Advice brand new subscriber does not have any services
        subscriber.getPurchasedOfferArrayAppender().clear();

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscriber.getExternalId() + "]").when(instance).getLoggingKey(any());
        emulateMtxResponseSubscription(instance, subscriber);

        // method to test
        instance.getQuoteAdvice(input, output);
        System.out.println(td.getTestMethod() + " : " + output.toJson());
        BigDecimal unlimitedRedeemable = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(vtGdw.getPromotionName())
                        && vc.getApplicableCI().equalsIgnoreCase(
                                CI_EXTERNAL_IDS.UNLIMITED)).findFirst().get().getRedeemableCredits();
        BigDecimal unlimitedTransferable = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(vtGdw.getPromotionName())
                        && vc.getApplicableCI().equalsIgnoreCase(
                                CI_EXTERNAL_IDS.UNLIMITED)).findFirst().get().getEstimatedTransferableCredits();
        int unlimitedConsumable = unlimitedRedeemable.intValue() - unlimitedTransferable.intValue();

        BigDecimal wearableRedeemable = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(vtGdw.getPromotionName())
                        && vc.getApplicableCI().equalsIgnoreCase(
                                CI_EXTERNAL_IDS.WEARABLE)).findFirst().get().getRedeemableCredits();
        BigDecimal wearableTransferable = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(vtGdw.getPromotionName())
                        && vc.getApplicableCI().equalsIgnoreCase(
                                CI_EXTERNAL_IDS.WEARABLE)).findFirst().get().getEstimatedTransferableCredits();
        int wearableConsumable = wearableRedeemable.intValue() - wearableTransferable.intValue();

        assertEquals(10, unlimitedConsumable);
        assertEquals(0, wearableConsumable);
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_Two_ApplicableCi_Then_Taxes_As_Per_ApplicableOffers")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber is NOT enrolled in Visible_Unlimited and Visible_Wearables.|"
       +"|     |Goodwill grant balance is present in subscriber object.|"   
       +"|     |Goodwill Grant Template attributes has two appliocable offers.|"
       +"|When |QuoteAdvice is called for Visible_Unlimited and Visible_Wearables.|"
       +"|Then |Tax Api is called twice for Goodwill credits with two different redeemables.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_Two_ApplicableCi_Then_Taxes_As_Per_ApplicableOffers(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        intiateAopQuoteTaxTest();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", CI_EXTERNAL_IDS.UNLIMITED);
        VisibleCatalogItem ciWearable = new VisibleCatalogItem();
        ciWearable.setCatalogItemExternalId(CI_EXTERNAL_IDS.WEARABLE);
        ciWearable.setDiscountPrice(new BigDecimal(15));
        ciWearable.setGrossPrice(new BigDecimal(100));
        input.getCatalogItemListAppender().add(ciWearable);

        System.out.println(td.getTestMethod() + " : " + input.toJson());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.WEARABLE);

        MtxResponsePricingCatalogItem pciGdw = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        VisibleTemplate vtGdw = (VisibleTemplate) pciGdw.getCatalogItemInfo().getTemplateAttr();
        vtGdw.setMinimumCharge(BigDecimal.valueOf(5));
        vtGdw.setTaxResponseUnchanged("N");
        vtGdw.setApplicableOfferName(CI_EXTERNAL_IDS.UNLIMITED + "," + CI_EXTERNAL_IDS.WEARABLE);
        List<MtxResponseMulti> respList = new ArrayList<MtxResponseMulti>();

        // For Aoc Response for service offers
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase purResponse = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_Unlimited_Wearable.json");
        MtxResponse emptyResp = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(purResponse);

        // For Pricing query from updateStartWithGrantBalanceCredits
        MtxResponseMulti multiResponse1 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingBalance gdwGrantPricing = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingBalance.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_GoodwillGrant.json");
        multiResponse1.getResponseListAppender().add(gdwGrantPricing);
        respList.add(multiResponse0);
        respList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, respList);

        MtxResponseSubscription subscriber = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());

        // Keep only goodwill credit for subscriber
        subscriber.getBalanceArrayAppender().clear();
        subscriber.getBalanceArrayAppender().add(
                CommonTestHelper.getMtxBalanceInfo(BALANCE_NAMES.MAIN_BALANCE, null, null, null));

        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.GOODWILL_GRANT, null, null, BigDecimal.valueOf(40));
        subscriber.getBalanceArrayAppender().add(mbiGoodGrant);

        // Simple Quote Advice brand new subscriber does not have any services
        subscriber.getPurchasedOfferArrayAppender().clear();

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscriber.getExternalId() + "]").when(instance).getLoggingKey(any());
        emulateMtxResponseSubscription(instance, subscriber);

        String taxApiRespService = new String(
                Files.readAllBytes(Paths.get(DATA_DIR.QUOTE_ADVICE + "TaxResponseService.json")));
        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiRespService);
            instance.getQuoteAdvice(input, output);
        }
        // method to test

        System.out.println(td.getTestMethod() + " : " + output.toJson());
        List<ServiceTaxRequest> goodwillTaxRequests = new ArrayList<ServiceTaxRequest>();
        argumentCaptor.getAllValues().forEach(val -> {
            try {
                ServiceTaxRequest taxResp = CommonTestHelper.getJsonFromString(
                        ServiceTaxRequest.class, val);
                if (taxResp.getClassCode().equalsIgnoreCase("GOOD-CR")) {
                    goodwillTaxRequests.add(taxResp);

                }
            } catch (Exception e) {
                // Auto-generated catch block
                e.printStackTrace();
            }
        });

        assertEquals(2, goodwillTaxRequests.size());

        BigDecimal discountPriceUnlimited = input.getCatalogItemList().stream().filter(
                vci -> vci.getCatalogItemExternalId().equals(
                        CI_EXTERNAL_IDS.UNLIMITED)).findFirst().get().getDiscountPrice();

        BigDecimal discountPriceWearable = input.getCatalogItemList().stream().filter(
                vci -> vci.getCatalogItemExternalId().equals(
                        CI_EXTERNAL_IDS.WEARABLE)).findFirst().get().getDiscountPrice();

        BigDecimal taxApiDiscPriceUnlimited = goodwillTaxRequests.stream().filter(
                req -> req.getGrossPrice().compareTo(
                        discountPriceUnlimited) == 0).findFirst().get().getDiscountPrice();

        BigDecimal taxApiDiscPriceWearable = goodwillTaxRequests.stream().filter(
                req -> req.getGrossPrice().compareTo(
                        discountPriceWearable) == 0).findFirst().get().getDiscountPrice();

        BigDecimal unlimitedRedeemable = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(vtGdw.getPromotionName())
                        && vc.getApplicableCI().equalsIgnoreCase(
                                CI_EXTERNAL_IDS.UNLIMITED)).findFirst().get().getRedeemableCredits();

        BigDecimal wearableRedeemable = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(vtGdw.getPromotionName())
                        && vc.getApplicableCI().equalsIgnoreCase(
                                CI_EXTERNAL_IDS.WEARABLE)).findFirst().get().getRedeemableCredits();

        // Tax for goodwills is calculated by subtraction method.
        BigDecimal expectedGdwDiscPriceUnlimited = discountPriceUnlimited.subtract(
                unlimitedRedeemable);
        BigDecimal expectedGdwDiscPriceWearable = discountPriceWearable.subtract(
                wearableRedeemable);

        assertEquals(expectedGdwDiscPriceUnlimited.intValue(), taxApiDiscPriceUnlimited.intValue());
        assertEquals(expectedGdwDiscPriceWearable.intValue(), taxApiDiscPriceWearable.intValue());

    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_PaidCycleStartDate_Present_Then_Match_PaidCycleStartDate")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber is NOT enrolled in Visible_Unlimited. Subscriber is not enrolled in Visible_Wearable.May or May not have promotions.|"
       +"|When |QuoteAdvice is called for Visible_Wearable.|"
       +"|Then |QuoteAdvice should provide paid cycle start date that is same as one present in Subscribers Purchased Offer Records.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_PaidCycleStartDate_Present_Then_Match_PaidCycleStartDate(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        OneParameterTest pTests = (setUpServiceFirst) -> {
            td.printDescription();
            VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                    "N", CI_EXTERNAL_IDS.WEARABLE);

            System.out.println(td.getTestMethod() + " : " + input.toJson());
            MtxDate someDate = new MtxDate(DateUtils.addDays(new Date(), -30).getTime());

            MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();
            subscription.getPurchasedOfferArrayAppender().clear();

            MtxPurchasedOfferInfo po_SetUp = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, CI_EXTERNAL_IDS.SETUP_SERVICES);

            MtxPurchasedOfferInfo po_Unlimited = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, CI_EXTERNAL_IDS.UNLIMITED);
            VisiblePurchasedOfferExtension attr = (VisiblePurchasedOfferExtension) po_Unlimited.getAttr();
            attr.setPaidCycleStartDate(someDate);

            if ((boolean) setUpServiceFirst) {
                subscription.getPurchasedOfferArrayAppender().add(po_SetUp);
                po_Unlimited.setAttr(attr);
            } else {
                po_Unlimited.setAttr(attr);
                subscription.getPurchasedOfferArrayAppender().add(po_SetUp);
            }

            subscription.getPurchasedOfferArrayAppender().add(po_Unlimited);

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
            emulateMtxResponseWalletMinimal(
                    instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
            emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);

            List<MtxResponseMulti> respList = new ArrayList<MtxResponseMulti>();

            // For Aoc Response for service offers
            MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
            MtxResponsePurchase purResponse = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_VisibleUnlimited.json");
            MtxResponse emptyResp = CommonTestHelper.getEmptyMtxResponseMulti();
            multiResponse0.getResponseListAppender().add(emptyResp);
            multiResponse0.getResponseListAppender().add(emptyResp);
            multiResponse0.getResponseListAppender().add(purResponse);

            // For Pricing query from updateStartWithGrantBalanceCredits
            MtxResponseMulti multiResponse1 = CommonTestHelper.getEmptyMtxResponseMulti();
            MtxResponsePricingBalance ref35GrantPricing = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingBalance.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_REF35Grant.json");
            multiResponse1.getResponseListAppender().add(ref35GrantPricing);
            respList.add(multiResponse0);
            respList.add(multiResponse1);
            emulate2MtxResponseMultiFromObjects(instance, respList);

            // Keep only mainbalance.
            subscription.getBalanceArrayAppender().clear();
            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfo(
                            BALANCE_NAMES.MAIN_BALANCE, null, null, null));
            emulateMtxResponseSubscription(instance, subscription);

            VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

            // mocks
            doReturn("").when(instance).getRoute(any());
            doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

            // method to test
            instance.getQuoteAdvice(input, output);
            System.out.println(output.toJson());

            assertEquals(someDate.getTime(), output.getPaidCycleStartDate().getTime());
        };

        pTests.test(false);
        pTests.test(true);
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_PaidCycleStartDate_Present_Then_Match_PaidCycleStartDate")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber is NOT enrolled in Visible_Unlimited.|"
       +"|     |Subscriber is not enrolled in Visible_Wearable.|"
       +"|     |Paid Cycle Start Date is missing in purchased offers.|"
       +"|     |May or May not have promotions.|"
       +"|When |QuoteAdvice is called for Visible_Wearable.|"
       +"|Then |QuoteAdvice should provide paid cycle start date that is same as today.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_PaidCycleStartDate_Missing_Then_Default_PaidCycleStartDate(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.WEARABLE);

        System.out.println(td.getTestMethod() + " : " + input.toJson());
        MtxDate today = new MtxDate((new Date()).getTime());
        MtxResponseSubscription subscriber = emulateMtxResponseSubscription(
                api, DATA_DIR.PAYMENT_ADVICE + "MtxResponseSubscriber_Only_VisibleUnlimited.json");
        subscriber.setTimeZone(ZoneId.systemDefault().toString());
        CommonTestHelper.clearPaidCycleStartDateInMtxResponseSubscription(subscriber);
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);

        List<MtxResponseMulti> respList = new ArrayList<MtxResponseMulti>();

        // For Aoc Response for service offers
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase purResponse = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_VisibleUnlimited.json");
        MtxResponse emptyResp = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(purResponse);

        // For Pricing query from updateStartWithGrantBalanceCredits
        MtxResponseMulti multiResponse1 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingBalance ref35GrantPricing = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingBalance.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_REF35Grant.json");
        multiResponse1.getResponseListAppender().add(ref35GrantPricing);
        respList.add(multiResponse0);
        respList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, respList);

        // Keep only mainbalance.
        subscriber.getBalanceArrayAppender().clear();
        subscriber.getBalanceArrayAppender().add(
                CommonTestHelper.getMtxBalanceInfo(BALANCE_NAMES.MAIN_BALANCE, null, null, null));
        emulateMtxResponseSubscription(instance, subscriber);

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscriber.getExternalId() + "]").when(instance).getLoggingKey(any());

        // method to test
        instance.getQuoteAdvice(input, output);
        System.out.println(output.toJson());

        assertEquals(today.getTime(), output.getPaidCycleStartDate().getTime());
    }

    @SuppressWarnings({
        "unchecked"
    })
    @ParameterizedTest(
            name = "test_getQuoteAdvice_Given_PaidForRenewal_When_QuoteSuccessful_Then_Match_TotalEstimatedAmount")
    @Tag("NextCycle")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscriber is NOT enrolled in Insurance or Addon. Base offer is paid for renewal.|"
                +"|     |QuoteAdvice is called for insurance and addon.|"
                +"|When |QuoteAdvice Api is called.|"
                +"|Then |TotalEstimatedAmount : This will be the sum of all the individual CI PayableAmount's.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_Given_PaidForRenewal_When_QuoteSuccessful_Then_Match_TotalEstimatedAmount(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.WEARABLE, CI_EXTERNAL_IDS.INSURANCE);

        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.TEN));

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance, CommonTestHelper.getSubscriptionResponse_afterPayment(
                        input.getSubscriberExternalId(), List.of(CI_EXTERNAL_IDS.UNLIMITED)));

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription(subscriptionResponse));

        emulateMtxResponsePricingCatalogItems(
                instance, List.of(CI_EXTERNAL_IDS.WEARABLE, CI_EXTERNAL_IDS.INSURANCE));

        // For Aoc Response for service offers
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(CommonTestHelper.getEmptyMtxResponseMulti());
        multiResponse0.getResponseListAppender().add(CommonTestHelper.getEmptyMtxResponseMulti());
        Map<String, BigDecimal> svcAocMap = Map.of(
                CI_EXTERNAL_IDS.WEARABLE, BigDecimal.valueOf(3), CI_EXTERNAL_IDS.INSURANCE,
                BigDecimal.valueOf(7));
        MtxResponsePurchase purResponse = CommonTestHelper.getMtxResponsePurchase(
                svcAocMap, subscriptionResponse);
        multiResponse0.getResponseListAppender().add(purResponse);

        // For Pricing query from updateStartWithGrantBalanceCredits
        MtxResponseMulti multiResponse1 = CommonTestHelper.getEmptyMtxResponseMulti();
        emulate2MtxResponseMultiFromObjects(instance, List.of(multiResponse0, multiResponse1));

        // Keep only REF35 credit for subscriber. And keep mainbalance.
        subscription.getBalanceArrayAppender().clear();
        subscription.getBalanceArrayAppender().add(
                CommonTestHelper.getMtxBalanceInfo(BALANCE_NAMES.MAIN_BALANCE, null, null, null));

        emulateMtxResponseSubscription(instance, subscription);

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        // method to test
        instance.getQuoteAdvice(input, output);
        printUnitTest(" input: " + input.toJson());
        printUnitTest(" output: " + output.toJson());

        BigDecimal expectedTotalEstimatedAmount = output.getNextCycle().getVisibleOfferDetailsList().stream().map(
                vod -> vod.getPayableAmount()).reduce(BigDecimal.ZERO, BigDecimal::add);

        assertEquals(
                expectedTotalEstimatedAmount.doubleValue(),
                output.getNextCycle().getEstimatedPayableAmount().doubleValue(), 0.01);
    }

    @SuppressWarnings("unchecked")
    @Tag("NextCycle")
    @Tag("Taxes")
    @ParameterizedTest(name = "test_getQuoteAdvice_When_Then_Match_NextCycle_Taxes")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber is enrolled in Visible_Unlimited. Subscriber is NOT enrolled in Visible_Wearable. PaidCycleStartDate is after today. May have promotions.|"
       +"|When |QuoteAdvice is called for Visible_Unlimited.|"
       +"|Then |TotalEstimatedAmount : This will be the sum of all the individual CI PayableAmount's|"
       +"|     |TotalEstimatedAmount for this test case: Sum(AocAmount - RedeemableCredit)|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_Then_Match_NextCycle_Taxes(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", CI_EXTERNAL_IDS.UNLIMITED);
        System.out.println(td.getTestMethod() + " : " + input.toJson());

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.REF35_GRANT);

        List<MtxResponseMulti> respList = new ArrayList<MtxResponseMulti>();

        // For Aoc Response for service offers
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase purResponse = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_VisibleUnlimited.json");
        MtxResponse emptyResp = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(purResponse);

        // For Pricing query from updateStartWithGrantBalanceCredits
        MtxResponseMulti multiResponse1 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingBalance ref35GrantPricing = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingBalance.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_REF35Grant.json");
        multiResponse1.getResponseListAppender().add(ref35GrantPricing);
        respList.add(multiResponse0);
        respList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, respList);

        // Keep only REF35 credit for subscriber. And keep mainbalance.
        subscription.getBalanceArrayAppender().clear();
        subscription.getBalanceArrayAppender().add(
                CommonTestHelper.getMtxBalanceInfo(BALANCE_NAMES.MAIN_BALANCE, null, null, null));

        // Keep only REF35 grant offer
        subscription.getPurchasedOfferArrayAppender().clear();
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.REF35_GRANT, null, BigDecimal.valueOf(35), null);

        CommonTestHelper.updatePaidCycleStartDateInMtxResponseSubscription(
                subscription, new MtxDate(DateUtils.addDays(new Date(), 30).getTime()));

        emulateMtxResponseSubscription(api, subscription);

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        String taxApiResp = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId());

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            // method to test
            instance.getQuoteAdvice(input, output);
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println(output.toJson());
        List<String> taxReqList = argumentCaptor.getAllValues().stream().collect(
                Collectors.toList());
        // 1st Req -> Request for current cycle Service tax
        // 2nd Req -> Request for current cycle Promotion tax
        // 3rd Req -> Request for next cycle Service tax
        // 4th Req -> Request for next cycle Promotion tax

        ServiceTaxRequest taxReq = null;
        try {
            taxReq = CommonTestHelper.getJsonFromString(ServiceTaxRequest.class, taxReqList.get(2));
        } catch (IOException e) {
            e.printStackTrace();
        }

        assertEquals(
                input.getAtCatalogItemList(0).getDiscountPrice().intValue(),
                taxReq.getDiscountPrice().intValue());
    }

    @SuppressWarnings("unchecked")
    @Tag("NextCycle")
    @ParameterizedTest(name = "test_getQuoteAdvice_When_Then_Match_NextCycle_Taxes")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber is enrolled in Visible_Unlimited. Subscriber is NOT enrolled in Visible_Wearable. PaidCycleStartDate is after today. May have promotions.|"
       +"|When |QuoteAdvice is called for Visible_Unlimited.|"
       +"|Then |AocAmount for VisibleUnlimited in next cycle equals to discount price.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_Then_Match_NextCycle_AocAmount(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.UNLIMITED);
        System.out.println(td.getTestMethod() + " : " + input.toJson());

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.WEARABLE);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.REF35_GRANT);

        List<MtxResponseMulti> respList = new ArrayList<MtxResponseMulti>();

        // For Aoc Response for service offers
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase purResponse = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_VisibleUnlimited.json");
        MtxResponse emptyResp = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(purResponse);

        // For Pricing query from updateStartWithGrantBalanceCredits
        MtxResponseMulti multiResponse1 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingBalance ref35GrantPricing = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingBalance.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_REF35Grant.json");
        multiResponse1.getResponseListAppender().add(ref35GrantPricing);
        respList.add(multiResponse0);
        respList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, respList);

        // Keep only REF35 credit for subscriber. And keep mainbalance.
        subscription.getBalanceArrayAppender().clear();
        subscription.getBalanceArrayAppender().add(
                CommonTestHelper.getMtxBalanceInfo(BALANCE_NAMES.MAIN_BALANCE, null, null, null));
        subscription.getBalanceArrayAppender().add(
                CommonTestHelper.getMtxBalanceInfo(BALANCE_NAMES.MAIN_BALANCE, 4L, 43L, null));

        // Keep only REF35 grant offer and Wearable
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo pgoWearable = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.WEARABLE);
        subscription.getPurchasedOfferArrayAppender().add(pgoWearable);

        CommonTestHelper.updatePaidCycleStartDateInMtxResponseSubscription(
                subscription, new MtxDate(DateUtils.addDays(new Date(), 30).getTime()));
        emulateMtxResponseSubscription(instance, subscription);

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        // method to test
        instance.getQuoteAdvice(input, output);
        System.out.println(output.toJson());

        assertEquals(
                OFFER_PRICES.UNLIMITED.floatValue(),
                output.getNextCycle().getAtVisibleOfferDetailsList(0).getAocAmount().floatValue(),
                0.01);
    }

    @SuppressWarnings("unchecked")
    @Tag("NextCycle")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_PayableAmount_Present_Then_Match_NextCycle_PayableAmount")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber is enrolled in Visible_Unlimited. Subscriber is NOT enrolled in Visible_Wearable. PaidCycleStartDate is after today. Have promotions.|"
       +"|When |QuoteAdvice is called for Visible_Unlimited.|"
       +"|Then |PayableAmount : Greater of (AocAmount, Fixed Fee) - Any credits for the offer. As per CIM4699.|"
       +"|     |NextCycle VisibleUnlimted PayableAmount for this test case: AocAmount - RedeemableCredits.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_PayableAmount_Present_Then_Match_NextCycle_PayableAmount(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.UNLIMITED);

        System.out.println(td.getTestMethod() + " : " + input.toJson());

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.WEARABLE);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.REF35_GRANT);

        List<MtxResponseMulti> respList = new ArrayList<MtxResponseMulti>();

        // For Aoc Response for service offers
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase purResponse = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_VisibleUnlimited.json");
        MtxResponse emptyResp = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(purResponse);

        // For Pricing query from updateStartWithGrantBalanceCredits
        MtxResponseMulti multiResponse1 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingBalance ref35GrantPricing = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingBalance.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_REF35Grant.json");
        multiResponse1.getResponseListAppender().add(ref35GrantPricing);
        respList.add(multiResponse0);
        respList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, respList);

        // Keep only REF35 credit for subscriber. And keep mainbalance.
        subscription.getBalanceArrayAppender().clear();
        subscription.getBalanceArrayAppender().add(
                CommonTestHelper.getMtxBalanceInfo(BALANCE_NAMES.MAIN_BALANCE, null, null, null));

        // Keep only REF35 grant offer and Wearable
        subscription.getPurchasedOfferArrayAppender().clear();
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.REF35_GRANT, null, BigDecimal.valueOf(35), null);
        CommonTestHelper.getMtxPurchasedOfferInfo(subscription, CI_EXTERNAL_IDS.WEARABLE);

        CommonTestHelper.updatePaidCycleStartDateInMtxResponseSubscription(
                subscription, new MtxDate(DateUtils.addDays(new Date(), 30).getTime()));
        emulateMtxResponseSubscription(instance, subscription);

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        // method to test
        instance.getQuoteAdvice(input, output);
        System.out.println(output.toJson());

        assertEquals(
                output.getNextCycle().getAtVisibleOfferDetailsList(0).getAocAmount().subtract(
                        output.getNextCycle().getAtVisibleOfferDetailsList(0).getAtCredits(
                                0).getRedeemableCredits()).floatValue(),
                output.getNextCycle().getAtVisibleOfferDetailsList(
                        0).getPayableAmount().floatValue(),
                0.01);
    }

    @SuppressWarnings("unchecked")
    @Tag("NextCycle")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_PayableAmount_Present_Then_Match_NextCycle_EstimatedPayableAmount")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber is enrolled in Visible_Unlimited. Subscriber is NOT enrolled in Visible_Wearable. PaidCycleStartDate is after today. May or May not have promotions.|"
       +"|When |QuoteAdvice is called for Visible_Unlimited.|"
       +"|Then |EstimatedPayableAmount : Amount that would be recharged via Paynow or Cash Payments. As per CIM4699.|"
       +"|     |NextCycle EstimatedPayableAmount for this test case: AocAmount - RedeemableCredits - consumable mainbalance.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_PayableAmount_Present_Then_Match_NextCycle_EstimatedPayableAmount(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.WEARABLE);
        System.out.println(td.getTestMethod() + " : " + input.toJson());

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.WEARABLE);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.INSURANCE);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.REF35_GRANT);

        List<MtxResponseMulti> respList = new ArrayList<MtxResponseMulti>();

        // For Aoc Response for service offers
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase purResponse = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_Unlimited_Wearable.json");
        MtxResponse emptyResp = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(purResponse);

        // For Pricing query from updateStartWithGrantBalanceCredits
        MtxResponseMulti multiResponse1 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingBalance ref35GrantPricing = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingBalance.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_REF35Grant.json");
        multiResponse1.getResponseListAppender().add(ref35GrantPricing);
        respList.add(multiResponse0);
        respList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, respList);

        // Keep only REF35 credit for subscriber. And keep mainbalance.
        subscription.getBalanceArrayAppender().clear();
        subscription.getBalanceArrayAppender().add(
                CommonTestHelper.getMtxBalanceInfo(BALANCE_NAMES.MAIN_BALANCE, null, null, null));

        // Keep only REF35 grant offer and Insurance (Insurance isjust a holder for
        // paidcyclestartdate)
        subscription.getPurchasedOfferArrayAppender().clear();
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.REF35_GRANT, null, BigDecimal.valueOf(35), null);
        CommonTestHelper.getMtxPurchasedOfferInfo(subscription, CI_EXTERNAL_IDS.INSURANCE);

        CommonTestHelper.updatePaidCycleStartDateInMtxResponseSubscription(
                subscription, new MtxDate(DateUtils.addDays(new Date(), 30).getTime()));
        emulateMtxResponseSubscription(instance, subscription);

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        // method to test
        instance.getQuoteAdvice(input, output);
        System.out.println(output.toJson());
        BigDecimal expectedPayableAmountAmount = BigDecimal.ZERO;

        for (VisibleOfferDetails offer : output.getNextCycle().getVisibleOfferDetailsList()) {
            expectedPayableAmountAmount = expectedPayableAmountAmount.add(offer.getAocAmount());
            if (offer.getCredits() != null) { // Assumption : only one credit
                expectedPayableAmountAmount = expectedPayableAmountAmount.subtract(
                        offer.getAtCredits(0).getRedeemableCredits());
            }
        }
        expectedPayableAmountAmount.subtract(
                output.getNextCycle().getConsumableMainBalanceAmount());

        assertEquals(
                expectedPayableAmountAmount.doubleValue(),
                output.getNextCycle().getEstimatedPayableAmount().floatValue(), 0.01);
    }

    @SuppressWarnings("unchecked")
    @Tag("NextCycle")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_AvaialableMainbalance_Present_Then_Match_NextCycle_AvailableMainbalance")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber is enrolled in Visible_Unlimited. Subscriber is NOT enrolled in Visible_Wearable. PaidCycleStartDate is after today. May or May not have promotions.|"
       +"|When |QuoteAdvice is called for Visible_Unlimited.|"
       +"|Then |AvailableMainbalance for next cycle = Total AvailableMainbalance - ConsumableMainBalance of Current cycle.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_AvaialableMainbalance_Present_Then_Match_NextCycle_AvailableMainbalance(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.WEARABLE);
        System.out.println(td.getTestMethod() + " : " + input.toJson());
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.REF35_GRANT);

        List<MtxResponseMulti> respList = new ArrayList<MtxResponseMulti>();

        // For Aoc Response for service offers
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase purResponse = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_VisibleUnlimited.json");
        MtxResponse emptyResp = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(purResponse);

        // For Pricing query from updateStartWithGrantBalanceCredits
        MtxResponseMulti multiResponse1 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingBalance ref35GrantPricing = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingBalance.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_REF35Grant.json");
        multiResponse1.getResponseListAppender().add(ref35GrantPricing);
        respList.add(multiResponse0);
        respList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, respList);

        // Keep only mainbalance.
        subscription.getBalanceArrayAppender().clear();
        subscription.getBalanceArrayAppender().add(
                CommonTestHelper.getMtxBalanceInfo(BALANCE_NAMES.MAIN_BALANCE, null, null, null));

        // Keep only Visible_Unlimited offer
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo pgo = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.UNLIMITED);
        subscription.getPurchasedOfferArrayAppender().add(pgo);

        CommonTestHelper.updatePaidCycleStartDateInMtxResponseSubscription(
                subscription, new MtxDate(DateUtils.addDays(new Date(), 30).getTime()));
        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        emulateMtxResponseSubscription(instance, subscription);
        // method to test
        instance.getQuoteAdvice(input, output);
        System.out.println(output.toJson());
        assertEquals(
                output.getAvailableMainBalanceAmount().subtract(
                        output.getConsumableMainBalanceAmount()).doubleValue(),
                output.getNextCycle().getAvailableMainBalanceAmount().doubleValue(), 0.01);
    }

    @SuppressWarnings("unchecked")
    @Tag("NextCycle")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_ConsumableMainbalance_Present_Then_Match_NextCycle_ConsumableMainbalance")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber is NOT enrolled in Visible_Unlimited. Subscriber is enrolled in Visible_Wearable. PaidCycleStartDate is after today. May or May not have promotions.|"
       +"|When |QuoteAdvice is called for Visible_Unlimited.|"
       +"|Then |ConsumableMainbalance for next cycle should be from availablemainbalance for next cycle.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_ConsumableMainbalance_Present_Then_Match_NextCycle_ConsumableMainbalance(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.UNLIMITED);
        System.out.println(td.getTestMethod() + " : " + input.toJson());
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.WEARABLE);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.REF35_GRANT);

        List<MtxResponseMulti> respList = new ArrayList<MtxResponseMulti>();

        // For Aoc Response for service offers
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase purResponse = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_VisibleUnlimited.json");
        MtxResponse emptyResp = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(purResponse);

        // For Pricing query from updateStartWithGrantBalanceCredits
        MtxResponseMulti multiResponse1 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingBalance ref35GrantPricing = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingBalance.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_REF35Grant.json");
        multiResponse1.getResponseListAppender().add(ref35GrantPricing);
        respList.add(multiResponse0);
        respList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, respList);

        // Keep only REF35 credit for subscriber. And keep mainbalance.
        subscription.getBalanceArrayAppender().clear();
        subscription.getBalanceArrayAppender().add(
                CommonTestHelper.getMtxBalanceInfo(BALANCE_NAMES.MAIN_BALANCE, null, null, null));

        // Keep only REF35 grant offer and Wearable
        subscription.getPurchasedOfferArrayAppender().clear();
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.REF35_GRANT, null, BigDecimal.valueOf(35), null);
        CommonTestHelper.getMtxPurchasedOfferInfo(subscription, CI_EXTERNAL_IDS.WEARABLE);

        CommonTestHelper.updatePaidCycleStartDateInMtxResponseSubscription(
                subscription, new MtxDate(DateUtils.addDays(new Date(), 30).getTime()));
        emulateMtxResponseSubscription(instance, subscription);

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        // method to test
        instance.getQuoteAdvice(input, output);
        System.out.println(output.toJson());

        assertEquals(
                Math.min(
                        output.getAvailableMainBalanceAmount().subtract(
                                output.getConsumableMainBalanceAmount()).doubleValue(),
                        output.getNextCycle().getAtVisibleOfferDetailsList(
                                0).getAocAmount().subtract(
                                        output.getNextCycle().getAtVisibleOfferDetailsList(
                                                0).getAtCredits(
                                                        0).getRedeemableCredits()).doubleValue()),
                output.getNextCycle().getConsumableMainBalanceAmount().doubleValue(), 0.01);
    }

    @SuppressWarnings("unchecked")
    @Tag("NextCycle")
    @Tag("Credits")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_Promotions_Present_Then_Match_NextCycle_AvailableCredits")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber is NOT enrolled in Visible_Unlimited. Subscriber is enrolled in Visible_Wearable. PaidCycleStartDate is after today. Have promotions.|"
       +"|When |QuoteAdvice is called for Visible_Unlimited.|"
       +"|Then |AvailableCredits for next cycle = Total AvailableCredits - RedeemableCredits of Current cycle.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_Promotions_Present_Then_Match_NextCycle_AvailableCredits(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.UNLIMITED);
        System.out.println(td.getTestMethod() + " : " + input.toJson());
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.WEARABLE);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.REF35_GRANT);

        List<MtxResponseMulti> respList = new ArrayList<MtxResponseMulti>();

        // For Aoc Response for service offers
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase purResponse = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_VisibleUnlimited.json");
        MtxResponse emptyResp = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(purResponse);

        // For Pricing query from updateStartWithGrantBalanceCredits
        MtxResponseMulti multiResponse1 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingBalance ref35GrantPricing = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingBalance.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_REF35Grant.json");
        multiResponse1.getResponseListAppender().add(ref35GrantPricing);
        respList.add(multiResponse0);
        respList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, respList);

        // Keep only REF35 credit for subscriber. And keep mainbalance.
        subscription.getBalanceArrayAppender().clear();
        subscription.getBalanceArrayAppender().add(
                CommonTestHelper.getMtxBalanceInfo(BALANCE_NAMES.MAIN_BALANCE, null, null, null));

        // Keep only REF35 grant offer and Wearable
        subscription.getPurchasedOfferArrayAppender().clear();
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.REF35_GRANT, null, BigDecimal.valueOf(35), null);
        CommonTestHelper.getMtxPurchasedOfferInfo(subscription, CI_EXTERNAL_IDS.WEARABLE);

        CommonTestHelper.updatePaidCycleStartDateInMtxResponseSubscription(
                subscription, new MtxDate(DateUtils.addDays(new Date(), 30).getTime()));
        emulateMtxResponseSubscription(instance, subscription);

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        // method to test
        instance.getQuoteAdvice(input, output);
        System.out.println(output.toJson());

        assertEquals(
                output.getAtCredits(0).getAvailableCredits().subtract(
                        output.getAtCredits(0).getRedeemableCredits()).doubleValue(),
                output.getNextCycle().getAtCredits(0).getAvailableCredits().doubleValue(), 0.01);
    }

    @SuppressWarnings("unchecked")
    @Tag("NextCycle")
    @Tag("Credits")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_ConsumablePromotions_Present_Then_Match_NextCycle_AvailableCreditsConsumable")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber is NOT enrolled in Visible_Unlimited. Subscriber is enrolled in Visible_Wearable. PaidCycleStartDate is after today. Have promotions.|"
       +"|When |QuoteAdvice is called for Visible_Unlimited.|"
       +"|Then |AvailableCreditsConsumables for next cycle = Total AvailableCreditsConsumables - (Redeemables - Transferables) Current cycle.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_ConsumablePromotions_Present_Then_Match_NextCycle_AvailableCreditsConsumable(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.UNLIMITED);
        System.out.println(td.getTestMethod() + " : " + input.toJson());
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getBalanceArrayAppender().clear();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.WEARABLE);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.REF35_GRANT);

        List<MtxResponseMulti> respList = new ArrayList<MtxResponseMulti>();

        // For Aoc Response for service offers
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase purResponse = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_VisibleUnlimited.json");
        MtxResponse emptyResp = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(purResponse);

        // For Pricing query from updateStartWithGrantBalanceCredits
        MtxResponseMulti multiResponse1 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingBalance ref35GrantPricing = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingBalance.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_REF35Grant.json");
        multiResponse1.getResponseListAppender().add(ref35GrantPricing);
        respList.add(multiResponse0);
        respList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, respList);

        // Keep only REF35 credit for subscriber. And keep mainbalance.
        subscription.getBalanceArrayAppender().add(
                CommonTestHelper.getMtxBalanceInfo(BALANCE_NAMES.MAIN_BALANCE, null, null, null));

        // Keep only REF35 grant offer and Wearable
        subscription.getPurchasedOfferArrayAppender().clear();
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.REF35_GRANT, null, BigDecimal.TEN,
                BigDecimal.valueOf(35));
        CommonTestHelper.getMtxPurchasedOfferInfo(subscription, CI_EXTERNAL_IDS.WEARABLE);

        CommonTestHelper.updatePaidCycleStartDateInMtxResponseSubscription(
                subscription, new MtxDate(DateUtils.addDays(new Date(), 30).getTime()));
        emulateMtxResponseSubscription(instance, subscription);

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        // method to test
        instance.getQuoteAdvice(input, output);
        System.out.println(output.toJson());

        assertEquals(
                output.getAtCredits(0).getAvailableCreditsConsumable().subtract(
                        output.getAtCredits(0).getRedeemableCredits().subtract(
                                output.getAtCredits(
                                        0).getEstimatedTransferableCredits())).doubleValue(),
                output.getNextCycle().getAtCredits(0).getAvailableCreditsConsumable().doubleValue(),
                0.01);
    }

    @SuppressWarnings("unchecked")
    @Tag("NextCycle")
    @Tag("Credits")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_ConsumablePromotions_Present_Then_Match_NextCycle_AvailableCreditsConsumable")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber is NOT enrolled in Visible_Unlimited. Subscriber is enrolled in Visible_Wearable. PaidCycleStartDate is after today. Have promotion grants and consumables.|"
       +"|When |QuoteAdvice is called for Visible_Unlimited.|"
       +"|Then |AvailableCreditsGrant for next cycle = Total AvailableCreditsGrant - TransferableCredits of Current cycle.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_GrantPromotions_Present_Then_Match_NextCycle_AvailableCreditsGrant(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.UNLIMITED);
        System.out.println(td.getTestMethod() + " : " + input.toJson());
        BigDecimal mainbalanceAmount = BigDecimal.TEN;
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(mainbalanceAmount));
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.WEARABLE);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.REF35_GRANT);

        List<MtxResponseMulti> respList = new ArrayList<MtxResponseMulti>();

        // For Aoc Response for service offers
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase purResponse = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_VisibleUnlimited.json");
        MtxResponse emptyResp = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(purResponse);

        // For Pricing query from updateStartWithGrantBalanceCredits
        MtxResponseMulti multiResponse1 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingBalance ref35GrantPricing = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingBalance.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_REF35Grant.json");
        multiResponse1.getResponseListAppender().add(ref35GrantPricing);
        respList.add(multiResponse0);
        respList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, respList);

        // Keep only REF35 credit for subscriber. And keep mainbalance.
        subscription.getBalanceArrayAppender().clear();
        subscription.getBalanceArrayAppender().add(
                CommonTestHelper.getMtxBalanceInfo(BALANCE_NAMES.MAIN_BALANCE, null, null, null));

        // Keep only REF35 grant offer and Wearable
        subscription.getPurchasedOfferArrayAppender().clear();
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.REF35_GRANT, null, BigDecimal.TEN, BigDecimal.ONE);
        CommonTestHelper.getMtxPurchasedOfferInfo(subscription, CI_EXTERNAL_IDS.WEARABLE);

        CommonTestHelper.updatePaidCycleStartDateInMtxResponseSubscription(
                subscription, new MtxDate(DateUtils.addDays(new Date(), 30).getTime()));
        emulateMtxResponseSubscription(instance, subscription);

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        // method to test
        instance.getQuoteAdvice(input, output);
        System.out.println(output.toJson());

        assertEquals(
                output.getAtCredits(0).getAvailableCreditsGrant().subtract(
                        output.getAtCredits(0).getEstimatedTransferableCredits()).doubleValue(),
                output.getNextCycle().getAtCredits(0).getAvailableCreditsGrant().doubleValue(),
                0.01);
    }

    @SuppressWarnings("unchecked")
    @Tag("NextCycle")
    @Tag("Credits")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_RedeemablePromotions_Present_Then_Match_NextCycle_RedeemableCredits")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber is NOT enrolled in Visible_Unlimited. Subscriber is enrolled in Visible_Wearable. PaidCycleStartDate is after today. Have promotion grants and consumables.|"
       +"|When |QuoteAdvice is called for Visible_Unlimited.|"
       +"|Then |Sum Redeemables for next cycle and Redeemables for current cycle should not exceed current available credits.|"
       +"|     |Redeemables of next cycle should less than Available credits of next cycles.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_RedeemablePromotions_Present_Then_Match_NextCycle_RedeemableCredits(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.UNLIMITED);
        System.out.println(td.getTestMethod() + " : " + input.toJson());
        BigDecimal mainbalanceAmount = BigDecimal.TEN;
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(mainbalanceAmount));
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.WEARABLE);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.REF35_GRANT);

        List<MtxResponseMulti> respList = new ArrayList<MtxResponseMulti>();

        // For Aoc Response for service offers
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase purResponse = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_VisibleUnlimited.json");
        MtxResponse emptyResp = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(purResponse);

        // For Pricing query from updateStartWithGrantBalanceCredits
        MtxResponseMulti multiResponse1 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingBalance ref35GrantPricing = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingBalance.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_REF35Grant.json");
        multiResponse1.getResponseListAppender().add(ref35GrantPricing);
        respList.add(multiResponse0);
        respList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, respList);

        // Keep only REF35 credit for subscriber. And keep mainbalance.
        subscription.getBalanceArrayAppender().clear();
        subscription.getBalanceArrayAppender().add(
                CommonTestHelper.getMtxBalanceInfo(BALANCE_NAMES.MAIN_BALANCE, null, null, null));
        // Keep only REF35 grant offer and Wearable
        subscription.getPurchasedOfferArrayAppender().clear();
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.REF35_GRANT, null, BigDecimal.TEN, BigDecimal.ONE);
        CommonTestHelper.getMtxPurchasedOfferInfo(subscription, CI_EXTERNAL_IDS.WEARABLE);

        CommonTestHelper.updatePaidCycleStartDateInMtxResponseSubscription(
                subscription, new MtxDate(DateUtils.addDays(new Date(), 30).getTime()));
        emulateMtxResponseSubscription(instance, subscription);

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        // method to test
        instance.getQuoteAdvice(input, output);
        System.out.println(output.toJson());

        assertNotEquals(
                (long) output.getNextCycle().getAtCredits(0).getRedeemableCredits().compareTo(
                        output.getNextCycle().getAtCredits(0).getAvailableCredits()),
                1L);
        assertNotEquals(
                (long) output.getNextCycle().getAtCredits(0).getRedeemableCredits().add(
                        output.getAtCredits(0).getRedeemableCredits()).compareTo(
                                output.getAtCredits(0).getAvailableCredits()),
                1L);
    }

    @SuppressWarnings("unchecked")
    @Tag("NextCycle")
    @Tag("Credits")
    @Tag("Tax")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_TaxableRedeemablePromotions_Present_Then_Match_NextCycle_CreditTaxes")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber is NOT enrolled in Visible_Unlimited. Subscriber is enrolled in Visible_Wearable. PaidCycleStartDate is after today. Have promotions.|"
       +"|When |QuoteAdvice is called for Visible_Unlimited.|"
       +"|Then |Match credit taxes.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_TaxableRedeemablePromotions_Present_Then_Match_NextCycle_CreditTaxes(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", CI_EXTERNAL_IDS.UNLIMITED);
        System.out.println(td.getTestMethod() + " : " + input.toJson());

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.WEARABLE);
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.REF35_GRANT);

        List<MtxResponseMulti> respList = new ArrayList<MtxResponseMulti>();

        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase purResponse = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_VisibleUnlimited.json");
        MtxResponse emptyResp = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(emptyResp);
        multiResponse0.getResponseListAppender().add(purResponse);

        // For Pricing query from updateStartWithGrantBalanceCredits
        MtxResponseMulti multiResponse1 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingBalance ref35GrantPricing = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingBalance.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_REF35Grant.json");
        multiResponse1.getResponseListAppender().add(ref35GrantPricing);
        respList.add(multiResponse0);
        respList.add(multiResponse1);
        emulate2MtxResponseMultiFromObjects(instance, respList);

        // Keep only REF35 credit for subscriber. And keep mainbalance.
        subscription.getBalanceArrayAppender().clear();
        subscription.getBalanceArrayAppender().add(
                CommonTestHelper.getMtxBalanceInfo(BALANCE_NAMES.MAIN_BALANCE, null, null, null));

        // Keep only REF35 grant offer and Wearable
        subscription.getPurchasedOfferArrayAppender().clear();
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.REF35_GRANT, null, BigDecimal.valueOf(35), null);
        CommonTestHelper.getMtxPurchasedOfferInfo(subscription, CI_EXTERNAL_IDS.WEARABLE);

        CommonTestHelper.updatePaidCycleStartDateInMtxResponseSubscription(
                subscription, new MtxDate(DateUtils.addDays(new Date(), 30).getTime()));

        emulateMtxResponseSubscription(api, subscription);

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        String taxApiResp = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId());

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            // method to test
            instance.getQuoteAdvice(input, output);
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println(output.toJson());
        List<String> taxReqList = argumentCaptor.getAllValues().stream().collect(
                Collectors.toList());
        // 1st Req -> Request for current cycle Service tax
        // 2bd Req -> Request for current cycle Promotion tax
        // 3rd Req -> Request for next cycle Service tax
        // 4th Req -> Request for next cycle Promotion tax
        taxReqList.forEach(req -> {
            System.out.println(req);
        });

        ServiceTaxRequest taxReq = null;
        try {
            taxReq = CommonTestHelper.getJsonFromString(ServiceTaxRequest.class, taxReqList.get(3));
        } catch (IOException e) {
            e.printStackTrace();
        }

        assertEquals("REF-35", taxReq.getClassCode());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_Given_PaidRenewal_When_QuoteSuccessful_Then_AllMainbalanceReserved")
    @Tag("NextCycle")
    @Tag("VER-831")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Base offer is paid for renewal.|"
                +"|     |QuoteAdvice is called for insurance and addon.|"
                +"|When |QuoteAdvice Api is called.|"
                +"|Then |AvailableMainbalance == ReservedMainbalance|"})
    // @formatter:on    
    public void test_getQuoteAdvice_Given_PaidRenewal_When_QuoteSuccessful_Then_AllMainbalanceReserved(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.INSURANCE);

        BigDecimal mainbalanceAmount = BigDecimal.TEN;
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(mainbalanceAmount));

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance, CommonTestHelper.getSubscriptionResponse_afterPayment(
                        input.getSubscriberExternalId(), List.of(CI_EXTERNAL_IDS.UNLIMITED)));

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription(subscriptionResponse));

        emulateMtxResponsePricingCatalogItems(instance, List.of(CI_EXTERNAL_IDS.INSURANCE));

        // For Aoc Response for service offers
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(CommonTestHelper.getEmptyMtxResponseMulti());
        multiResponse0.getResponseListAppender().add(CommonTestHelper.getEmptyMtxResponseMulti());
        Map<String, BigDecimal> svcAocMap = Map.of(
                CI_EXTERNAL_IDS.INSURANCE, BigDecimal.valueOf(7));
        MtxResponsePurchase purResponse = CommonTestHelper.getMtxResponsePurchase(
                svcAocMap, subscriptionResponse);
        multiResponse0.getResponseListAppender().add(purResponse);

        // For Pricing query from updateStartWithGrantBalanceCredits
        MtxResponseMulti multiResponse1 = CommonTestHelper.getEmptyMtxResponseMulti();
        emulate2MtxResponseMultiFromObjects(instance, List.of(multiResponse0, multiResponse1));

        // Keep only REF35 credit for subscriber. And keep mainbalance.
        subscription.getBalanceArrayAppender().clear();
        subscription.getBalanceArrayAppender().add(
                CommonTestHelper.getMtxBalanceInfo(BALANCE_NAMES.MAIN_BALANCE, null, null, null));

        emulateMtxResponseSubscription(instance, subscription);

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        // method to test
        instance.getQuoteAdvice(input, output);
        printUnitTest(" input: " + input.toJson());
        printUnitTest(" output: " + output.toJson());

        assertEquals(
                mainbalanceAmount.doubleValue(),
                output.getReservedMainBalanceAmount().doubleValue(), 0.01);
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_Given_UnpaidRenewal_When_QuoteSuccessful_Then_NoNextCycle")
    @Tag("NextCycle")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Base offer is NOT paid for renewal.|"
                +"|     |QuoteAdvice is called for insurance and addon.|"
                +"|When |QuoteAdvice Api is called.|"
                +"|Then |No Next cycle|"})
    // @formatter:on    
    public void test_getQuoteAdvice_Given_UnpaidRenewal_When_QuoteSuccessful_Then_NoNextCycle(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.INSURANCE);

        BigDecimal mainbalanceAmount = BigDecimal.TEN;
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(mainbalanceAmount));

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance, CommonTestHelper.getSubscriptionResponse_BeforePayment(
                        input.getSubscriberExternalId(), List.of(CI_EXTERNAL_IDS.UNLIMITED)));

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription(subscriptionResponse));

        emulateMtxResponsePricingCatalogItems(instance, List.of(CI_EXTERNAL_IDS.INSURANCE));

        // For Aoc Response for service offers
        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        multiResponse0.getResponseListAppender().add(CommonTestHelper.getEmptyMtxResponseMulti());
        multiResponse0.getResponseListAppender().add(CommonTestHelper.getEmptyMtxResponseMulti());
        Map<String, BigDecimal> svcAocMap = Map.of(
                CI_EXTERNAL_IDS.INSURANCE, BigDecimal.valueOf(7));
        MtxResponsePurchase purResponse = CommonTestHelper.getMtxResponsePurchase(
                svcAocMap, subscriptionResponse);
        multiResponse0.getResponseListAppender().add(purResponse);

        // For Pricing query from updateStartWithGrantBalanceCredits
        MtxResponseMulti multiResponse1 = CommonTestHelper.getEmptyMtxResponseMulti();
        emulate2MtxResponseMultiFromObjects(instance, List.of(multiResponse0, multiResponse1));

        // Keep only REF35 credit for subscriber. And keep mainbalance.
        subscription.getBalanceArrayAppender().clear();
        subscription.getBalanceArrayAppender().add(
                CommonTestHelper.getMtxBalanceInfo(BALANCE_NAMES.MAIN_BALANCE, null, null, null));

        emulateMtxResponseSubscription(instance, subscription);

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        // method to test
        instance.getQuoteAdvice(input, output);
        printUnitTest(" input: " + input.toJson());
        printUnitTest(" output: " + output.toJson());

        assertNull(output.getNextCycle());
    }

    @SuppressWarnings("unchecked")
    @Tag("Tax")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_Subscription_HasGift_Then_FixedFeeNotPayable")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber has gift amount.\", \"Subscribers tax geocode is subject to fixed fee.|"
       +"|When |QuoteAdvice is called. Taxapi provides fixedfee.|"
       +"|Then |QuoteAdvice response should show no payable amount.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_Subscription_HasGift_Then_FixedFeeNotPayable(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        String requestedBaseCi = CI_EXTERNAL_IDS.BASE2ANNUAL;
        BigDecimal discountPrice = OFFER_PRICES.BASE2ANNUAL;

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", requestedBaseCi);
        String giftGrantCi = CI_EXTERNAL_IDS.GIFT_GRANT;
        emulateMtxResponsePricingCatalogItem(instance, requestedBaseCi);
        emulateMtxResponsePricingCatalogItem(instance, giftGrantCi);

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getBalanceArrayAppender().clear();
        MtxTimestamp walletCycleStartDate = TestUtils.getFirstDateTimeOfCurrentMonth();

        subscription.getPurchasedOfferArrayAppender().clear();

        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, giftGrantCi, null, BigDecimal.valueOf(150), BigDecimal.valueOf(300));

        MtxBalanceInfo biMainBalance = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.MAIN_BALANCE, 1L, 2L, null);
        subscription.getBalanceArrayAppender().add(biMainBalance);

        System.out.println(td.getTestMethod() + ": " + subscription.toJson());

        MtxResponseMulti aocResponseMulti = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase aocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfo(
                requestedBaseCi, BALANCE_NAMES.MAIN_BALANCE, discountPrice);
        aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);
        // For Aoc cycle dates will be today to nne year plus

        MtxTimestamp tsNow = CommonUtils.getMtxTimestampTodayZeroHours(
                walletCycleStartDate, subscription.getTimeZone());
        aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(tsNow);
        aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                TestUtils.addOneYear(tsNow));
        aocResponseMulti.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        aocResponseMulti.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        aocResponseMulti.getResponseListAppender().add(aocResp);

        MtxResponseMulti grantBalances = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingBalance giftBalancePricing = CommonTestHelper.getMtxResponsePricingBalance(
                BALANCE_NAMES.GIFT_GRANT);
        grantBalances.getResponseListAppender().add(giftBalancePricing);

        List<MtxResponseMulti> multiResponses = new ArrayList<MtxResponseMulti>();
        multiResponses.add(aocResponseMulti);
        multiResponses.add(grantBalances);

        emulate2MtxResponseMultiFromObjects(instance, multiResponses);
        emulateMtxResponseSubscription(instance, subscription);
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        String taxRespString = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId());

        // method to test
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            ObjectMapper om = TestUtils.getObjectMapper();
            ServiceTaxResponse resp = om.readValue(taxRespString, ServiceTaxResponse.class);
            resp.getTransactionElement().get(0).setTotalFeeAmount(BigDecimal.valueOf(1.81));
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    resp.toJson());
            // method to test
            instance.getQuoteAdvice(input, output);
        }
        System.out.println(td.getTestMethod() + ": " + output.toJson());
        assertEquals(0, output.getEstimatedPayableAmount().doubleValue(), 0.001);
        assertEquals(0, output.getTotalEstimatedAmount().doubleValue(), 0.001);
        assertEquals(
                0, output.getAtVisibleOfferDetailsList(0).getPayableAmount().doubleValue(), 0.001);
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-143")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_ApplicableCi_Override_Then_CorrectPromoAssociate")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber is enrolled in PlusMonthly.|"
       +"|     |Subscription based promo has ApplicableCi overwritten.|"
       +"|When |QuoteAdvice is called for PlusMonthly.|"
       +"|Then |Response should show promo only if PlusMonthly is final ApplicableCi.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_ApplicableCi_Override_Then_CorrectPromoAssociate(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        OneParameterTest pTests = (tCase) -> {
            td.printDescription();
            TestCase testCase = (TestCase) tCase;
            String stars = "***************************************";
            System.out.println(
                    MessageFormat.format(
                            "{0}Executing Test {1}{2}", stars, testCase.testNum, stars));

            VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                    "N", testCase.baseOffer);
            System.out.println(input.toJson());
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxResponseWallet wallet = emulateMtxResponseWalletMinimal(
                    instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
            wallet.getBillingCycle().setCurrentPeriodStartTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            wallet.getBillingCycle().setCurrentPeriodEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth().plusMilli(
                            DATE_TIME_CONSTANTS.MILLISECONDS_IN_A_DAY * 30));
            wallet.getBalanceArrayAppender().clear();
            MtxBalanceInfoSimple mainBalanceWallet = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfoSimple.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfoSimple_Mainbalance.json");
            mainBalanceWallet.setAmount(testCase.mainBalance.negate());
            mainBalanceWallet.setAvailableAmount(testCase.mainBalance);
            wallet.getBalanceArrayAppender().add(mainBalanceWallet);

            emulateAocServicePurchase(instance);
            emulateMtxResponsePricingCatalogItem(instance, testCase.baseOffer);
            MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                    testCase.baseOffer, CommonTestHelper.getOfferPrice(testCase.baseOffer));

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getBalanceArrayAppender().clear();
            CommonTestHelper.getMtxPurchasedOfferInfo(subscription, testCase.baseOffer);

            MtxResponseMulti multiGrantBalance = CommonTestHelper.getEmptyMtxResponseMulti();
            MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
            MtxResponse okayResponse = new MtxResponse();
            okayResponse.setResult(1l);
            okayResponse.setResultText("OK");
            multiAocBase.getResponseListAppender().add(okayResponse);
            multiAocBase.getResponseListAppender().add(okayResponse);
            multiAocBase.getResponseListAppender().add(purResponseBase);

            TestCasePromo promo = testCase.promoList.get(0);
            MtxResponsePricingCatalogItem ciGrantOffer = emulateMtxResponsePricingCatalogItem(
                    instance, promo.grantOffer);
            VisibleTemplate vtGrant = (VisibleTemplate) ciGrantOffer.getCatalogItemInfo().getTemplateAttr();
            vtGrant.setIncompatiblePromotions(""); // Write a separate test case for
                                                   // incompatibilities.
            promo.redeemOffer = vtGrant.getRedeemOffer();
            MtxPurchasedOfferInfo promoOffer = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, promo.grantOffer, BigDecimal.valueOf(50), promo.grant,
                    promo.consumable);
            VisiblePurchasedOfferExtension promoAttr = (VisiblePurchasedOfferExtension) promoOffer.getAttr();
            promoAttr.setApplicableOfferName(promo.applicableCi);
            MtxResponsePricingBalance grantPricing = CommonTestHelper.getMtxResponsePricingBalance(
                    CommonTestHelper.getGrantBalanceName(promo.grantOffer));
            multiGrantBalance.getResponseListAppender().add(grantPricing);

            VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

            // mocks
            doReturn("").when(instance).getRoute(any());
            doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
            doReturn(multiAocBase).doReturn(multiGrantBalance).when(instance).multiRequest(
                    any(), any(), any());
            emulateMtxResponseSubscription(instance, subscription);
            System.out.println(subscription.toJson());
            // method to test
            instance.getQuoteAdvice(input, output);
            System.out.println(output.toJson());
            System.out.println(
                    MessageFormat.format(
                            "{0}Asserting Test {1}{2}", stars, testCase.testNum, stars));
            if (testCase.baseOffer.equalsIgnoreCase(promo.applicableCi)) {
                assertNotNull(output.getCredits());
                assertNotNull(output.getCredits().get(0));
                assertNotNull(output.getCredits().get(0).getRedeemableCredits());
            } else {
                assertNull(output.getCredits());
            }
        };

        TestCase tc;

        tc = new TestCase();
        tc.testNum = (new Exception()).getStackTrace()[0].getLineNumber() + "";
        tc.baseOffer = CI_EXTERNAL_IDS.PLUS_CURRENT;
        tc.minimumCharge = BigDecimal.valueOf(5);
        tc.mainBalance = BigDecimal.ZERO;
        TestCasePromo tcp = getNewTestCasePromo(
                CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT, BigDecimal.valueOf(300), BigDecimal.ZERO);
        tcp.applicableCi = CI_EXTERNAL_IDS.PLUS_CURRENT;
        tc.promoList.add(tcp);
        pTests.test(tc);

        tcp.applicableCi = CI_EXTERNAL_IDS.BASE_CURRENT;
        pTests.test(tc);
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-367")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_IncludePaymentAdvice_And_ChangeToMonthly_MailbalanceAvailable_Then_CorrectMainBalanceAmounts")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber has some mainbalance.|"
       +"|When |Api is called with with target monthly service., IncludePaymentAdvice = Y|"
       +"|Then |Advice should include PaymentAdvice for next service with mainbalance that is not used by current quote cycle.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_IncludePaymentAdvice_And_ChangeToMonthly_MailbalanceAvailable_Then_CorrectMainBalanceAmounts(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        OneParameterTest pTests = (tCase) -> {
            td.printDescription();
            TestCase testCase = (TestCase) tCase;
            String stars = "***************************************";
            System.out.println(
                    MessageFormat.format(
                            "{0}Executing Test {1}{2}", stars, testCase.testNum, stars));

            VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                    "N", testCase.baseOffer);
            input.setIncludePaymentAdvice("Y");
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxResponseWallet wallet = emulateMtxResponseWalletMinimal(
                    instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
            wallet.getBillingCycle().setCurrentPeriodStartTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            wallet.getBillingCycle().setCurrentPeriodEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth().plusMilli(
                            DATE_TIME_CONSTANTS.MILLISECONDS_IN_A_DAY * 30));
            wallet.getBalanceArrayAppender().clear();
            MtxBalanceInfoSimple mainBalanceWallet = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfoSimple.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfoSimple_Mainbalance.json");
            mainBalanceWallet.setAmount(testCase.mainBalance.negate());
            mainBalanceWallet.setAvailableAmount(testCase.mainBalance);
            wallet.getBalanceArrayAppender().add(mainBalanceWallet);

            emulateAocServicePurchase(instance);
            MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                    testCase.baseOffer, CommonTestHelper.getOfferPrice(testCase.baseOffer));

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            BalanceInfo mainBalance = CommonTestHelper.getBalanceInfo(
                    BALANCE_NAMES.MAIN_BALANCE, 101L, 201L, testCase.mainBalance);
            subscriptionResponse.appendWalletBalances(mainBalance);

            MtxResponseMulti multiGrantBalance = CommonTestHelper.getEmptyMtxResponseMulti();
            MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
            MtxResponse okayResponse = new MtxResponse();
            okayResponse.setResult(1l);
            okayResponse.setResultText("OK");
            multiAocBase.getResponseListAppender().add(okayResponse);
            multiAocBase.getResponseListAppender().add(okayResponse);
            multiAocBase.getResponseListAppender().add(purResponseBase);

            emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(testCase.baseOffer));

            VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

            // mocks
            doReturn("").when(instance).getRoute(any());
            doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
            doReturn(multiAocBase).doReturn(multiGrantBalance).when(instance).multiRequest(
                    any(), any(), any());

            emulateMtxResponseSubscription(instance, subscription);
            System.out.println(subscription.toJson());
            // method to test
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn("");
                instance.getQuoteAdvice(input, output);
            }

            System.out.println(
                    MessageFormat.format(
                            "{0}Asserting Test {1}{2}", stars, testCase.testNum, stars));
            assertEquals(
                    ((BigDecimal) testCase.expectedResultMap.get("QUOTEAMOUNT")).intValue(),
                    output.getConsumableMainBalanceAmount().intValue());

            assertNotNull(output.getNextCyclePaymentAdvice());
            assertEquals(
                    ((BigDecimal) testCase.expectedResultMap.get("AOPAMOUNT")).intValue(),
                    output.getNextCyclePaymentAdvice().getConsumableMainBalanceAmount().intValue());
        };

        TestCase tc;

        tc = new TestCase();
        tc.testNum = (new Exception()).getStackTrace()[0].getLineNumber() + "";
        tc.baseOffer = CI_EXTERNAL_IDS.PLUS_CURRENT;
        tc.minimumCharge = BigDecimal.valueOf(5);
        tc.mainBalance = BigDecimal.valueOf(55);
        tc.expectedResultMap.put("QUOTEAMOUNT", CommonTestHelper.getOfferPrice(tc.baseOffer));
        tc.expectedResultMap.put(
                "AOPAMOUNT", tc.mainBalance.subtract(CommonTestHelper.getOfferPrice(tc.baseOffer)));
        pTests.test(tc);
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-367")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_IncludePaymentAdvice_And_ChangeToMonthly_BalacePromoAvailable_Then_CorrectPromos")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber has some balance based promos like goodwill.|"
       +"|When |Api is called with with target monthly service., IncludePaymentAdvice = Y|"
       +"|Then |Advice should include PaymentAdvice for next service.|"
       +"|     |Quote Cycle should use promos first. Remaining promos should be used by Next PaymentAdvice Cycle.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_IncludePaymentAdvice_And_ChangeToMonthly_BalacePromoAvailable_Then_CorrectPromos(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        OneParameterTest pTests = (tCase) -> {
            td.printDescription();
            TestCase testCase = (TestCase) tCase;
            String stars = "***************************************";
            System.out.println(
                    MessageFormat.format(
                            "{0}Executing Test {1}{2}", stars, testCase.testNum, stars));

            VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                    "N", testCase.baseOffer);
            input.setIncludePaymentAdvice("Y");
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxResponseWallet wallet = emulateMtxResponseWalletMinimal(
                    instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
            wallet.getBillingCycle().setCurrentPeriodStartTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            wallet.getBillingCycle().setCurrentPeriodEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth().plusMilli(
                            DATE_TIME_CONSTANTS.MILLISECONDS_IN_A_DAY * 30));
            wallet.getBalanceArrayAppender().clear();
            MtxBalanceInfoSimple mainBalanceWallet = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfoSimple.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfoSimple_Mainbalance.json");
            mainBalanceWallet.setAmount(testCase.mainBalance.negate());
            mainBalanceWallet.setAvailableAmount(testCase.mainBalance);
            wallet.getBalanceArrayAppender().add(mainBalanceWallet);

            emulateAocServicePurchase(instance);
            MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                    testCase.baseOffer, CommonTestHelper.getOfferPrice(testCase.baseOffer));

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));

            MtxResponseMulti multiGrantBalance = CommonTestHelper.getEmptyMtxResponseMulti();
            MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
            MtxResponse okayResponse = new MtxResponse();
            okayResponse.setResult(1l);
            okayResponse.setResultText("OK");
            multiAocBase.getResponseListAppender().add(okayResponse);
            multiAocBase.getResponseListAppender().add(okayResponse);
            multiAocBase.getResponseListAppender().add(purResponseBase);

            TestCasePromo promo = testCase.promoList.get(0);
            MtxResponsePricingCatalogItem ciGrantOffer = emulateMtxResponsePricingCatalogItem(
                    instance, promo.grantOffer);
            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(testCase.baseOffer, promo.grantOffer));
            VisibleTemplate vtGrant = (VisibleTemplate) ciGrantOffer.getCatalogItemInfo().getTemplateAttr();
            vtGrant.setIncompatiblePromotions(""); // Write a separate test case for
                                                   // incompatibilities.
            promo.redeemOffer = vtGrant.getRedeemOffer();
            MtxBalanceInfo biGoodwill = CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                    promo.grantOffer, promo.grant);
            subscription.getBalanceArrayAppender().add(biGoodwill);

            MtxResponsePricingBalance grantPricing = CommonTestHelper.getMtxResponsePricingBalance(
                    CommonTestHelper.getGrantBalanceName(promo.grantOffer));
            multiGrantBalance.getResponseListAppender().add(grantPricing);

            VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

            // mocks
            doReturn("").when(instance).getRoute(any());
            doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
            doReturn(multiAocBase).doReturn(multiGrantBalance).when(instance).multiRequest(
                    any(), any(), any());
            emulateMtxResponseSubscription(instance, subscription);
            System.out.println(subscription.toJson());
            // method to test
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn("");
                instance.getQuoteAdvice(input, output);
            }

            System.out.println(
                    MessageFormat.format(
                            "{0}Asserting Test {1}{2}", stars, testCase.testNum, stars));
            assertNotNull(output.getCredits());
            assertEquals(
                    ((BigDecimal) testCase.expectedResultMap.get("QUOTEREDEEM")).intValue(),
                    output.getCredits().get(0).getRedeemableCredits().intValue());

            assertNotNull(output.getNextCyclePaymentAdvice());
            assertNotNull(output.getNextCyclePaymentAdvice().getCredits());
            assertEquals(
                    ((BigDecimal) testCase.expectedResultMap.get("AOPREDEEM")).intValue(),
                    output.getNextCyclePaymentAdvice().getCredits().get(
                            0).getRedeemableCredits().intValue());
        };

        TestCase tc;

        tc = new TestCase();
        tc.testNum = (new Exception()).getStackTrace()[0].getLineNumber() + "";
        tc.baseOffer = CI_EXTERNAL_IDS.PLUS_CURRENT;
        tc.minimumCharge = BigDecimal.valueOf(5);
        tc.mainBalance = BigDecimal.ZERO;
        TestCasePromo tcp = getNewTestCasePromo(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.valueOf(55), BigDecimal.ZERO);
        tcp.applicableCi = CI_EXTERNAL_IDS.PLUS_CURRENT;
        tc.promoList.add(tcp);
        tc.expectedResultMap.put(
                "QUOTEREDEEM",
                CommonTestHelper.getOfferPrice(tc.baseOffer).subtract(tc.minimumCharge));
        tc.expectedResultMap.put(
                "AOPREDEEM", BigDecimal.valueOf(55).subtract(
                        CommonTestHelper.getOfferPrice(tc.baseOffer).subtract(tc.minimumCharge)));
        pTests.test(tc);
    }

    @Tag("VER-390")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_Success_Then_PlanIDClassCode_Should_Populate_In_DpcGroupList")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber active.|"
       +"|When |Api is called for Plus23|"
       +"|Then |PlanIDClassCode_Should_Populate_In_DpcGroupList.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_Success_Then_PlanIDClassCode_Should_Populate_In_DpcGroupList(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String testGeoCode = "ELBISIVNOZIREV";
        String planIdExpect = "GP00045";
        final String[] planIdActual = {
            null
        };
        String classCodeExpect = "SVC-TP";
        final String[] classCodeActual = {
            null
        };

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", CI_EXTERNAL_IDS.PLUS3VIS23WB);
        input.setTaxGeoCode(testGeoCode);
        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateAocServicePurchase(instance);
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));

        MtxResponsePurchase aocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_PLUS3VIS23WB.json");
        aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactList().forEach(bi -> {
                    // Set all amounts to zero
                    bi.setImpactAmount(BigDecimal.ZERO);
                    bi.getBalanceImpactOfferList().forEach(bioi -> {
                        bioi.getBalanceImpactUpdateList().forEach(biui -> {
                            biui.setAmount(BigDecimal.ZERO);
                        });
                    });
                });
        doReturn("").when(instance).getRoute(any());
        for (MtxBalanceImpactInfo bi : aocResp.getAtPurchaseInfoArray(
                0).getAtBalanceImpactGroupList(0).getBalanceImpactList()) {
            // Set only one amount to 40
            bi.setImpactAmount(new BigDecimal(40.0));
            break;
        }

        MtxResponseSubscription subscription = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class,
                DATA_DIR.COMMON + "MtxResponseSubscription_PLUS3VIS23WB.json");

        System.out.println(": " + subscription.toJson());

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        String taxApiResp = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId());

        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.PLUS3VIS23WB);
        emulateMtxResponseMulti(
                instance, DATA_DIR.QUOTE_ADVICE + "MtxResponseMultiAocPLUS3VIS23WB.json");
        emulateMtxResponseSubscription(instance, subscription);
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            // method to test
            instance.getQuoteAdvice(input, output);
            System.out.println(output.toJson());
            argumentCaptor.getAllValues().forEach(taxReq -> {
                System.out.println(taxReq);
            });

            argumentCaptor.getAllValues().stream().map(taxString -> {
                try {
                    return CommonTestHelper.getJsonFromString(ServiceTaxRequest.class, taxString);
                } catch (IOException e) {
                    e.printStackTrace();
                    return null;
                }
            }).map(taxReq -> taxReq.getDpcGroupList()).forEach(dpcGroup -> {
                if (!dpcGroup.isEmpty()) {
                    dpcGroup.forEach(dpcGroup1 -> {
                        if (dpcGroup1.getPlanID() != null) {
                            planIdActual[0] = dpcGroup1.getPlanID();
                        }
                        if (dpcGroup1.getClassCode() != null) {
                            classCodeActual[0] = dpcGroup1.getClassCode();
                        }
                    });
                }

            });

            assertEquals(planIdExpect, planIdActual[0]);
            assertEquals(classCodeExpect, classCodeActual[0]);
        }
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-367")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_IncludePaymentAdvice_And_ChangeToMonthly_PurchaseOfferPromoAvailable_Then_CorrectPromos")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber has some purchase offer based promos like 15OFFN.|"
       +"|When |Api is called with with target monthly service. IncludePaymentAdvice = Y|"
       +"|Then |Advice should include PaymentAdvice for next service.|"
       +"|     |Quote Cycle should use promos first. Remaining promos should be used by Next PaymentAdvice Cycle.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_IncludePaymentAdvice_And_ChangeToMonthly_PurchaseOfferPromoAvailable_Then_CorrectPromos(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        OneParameterTest pTests = (tCase) -> {
            td.printDescription();
            TestCase testCase = (TestCase) tCase;
            String stars = "***************************************";
            System.out.println(
                    MessageFormat.format(
                            "{0}Executing Test {1}{2}", stars, testCase.testNum, stars));

            VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                    "N", testCase.baseOffer);
            input.setIncludePaymentAdvice("Y");
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxResponseWallet wallet = emulateMtxResponseWalletMinimal(
                    instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
            wallet.getBillingCycle().setCurrentPeriodStartTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            wallet.getBillingCycle().setCurrentPeriodEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth().plusMilli(
                            DATE_TIME_CONSTANTS.MILLISECONDS_IN_A_DAY * 30));
            wallet.getBalanceArrayAppender().clear();
            MtxBalanceInfoSimple mainBalanceWallet = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfoSimple.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfoSimple_Mainbalance.json");
            mainBalanceWallet.setAmount(testCase.mainBalance.negate());
            mainBalanceWallet.setAvailableAmount(testCase.mainBalance);
            wallet.getBalanceArrayAppender().add(mainBalanceWallet);

            emulateAocServicePurchase(instance);
            MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                    testCase.baseOffer, CommonTestHelper.getOfferPrice(testCase.baseOffer));

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));

            MtxResponseMulti multiGrantBalance = CommonTestHelper.getEmptyMtxResponseMulti();
            MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
            MtxResponse okayResponse = new MtxResponse();
            okayResponse.setResult(1l);
            okayResponse.setResultText("OK");
            multiAocBase.getResponseListAppender().add(okayResponse);
            multiAocBase.getResponseListAppender().add(okayResponse);
            multiAocBase.getResponseListAppender().add(purResponseBase);

            TestCasePromo promo = testCase.promoList.get(0);
            MtxResponsePricingCatalogItem ciGrantOffer = emulateMtxResponsePricingCatalogItem(
                    instance, promo.grantOffer);
            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(testCase.baseOffer, promo.grantOffer));
            VisibleTemplate vtGrant = (VisibleTemplate) ciGrantOffer.getCatalogItemInfo().getTemplateAttr();
            vtGrant.setIncompatiblePromotions(""); // Write a separate test case for
                                                   // incompatibilities.
            promo.redeemOffer = vtGrant.getRedeemOffer();
            MtxPurchasedOfferInfo promoOffer = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, promo.grantOffer, BigDecimal.valueOf(50), promo.grant,
                    promo.consumable);
            VisiblePurchasedOfferExtension promoAttr = (VisiblePurchasedOfferExtension) promoOffer.getAttr();
            promoAttr.setApplicableOfferName(promo.applicableCi);
            MtxResponsePricingBalance grantPricing = CommonTestHelper.getMtxResponsePricingBalance(
                    CommonTestHelper.getGrantBalanceName(promo.grantOffer));
            multiGrantBalance.getResponseListAppender().add(grantPricing);

            VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

            // mocks
            doReturn("").when(instance).getRoute(any());
            doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
            doReturn(multiAocBase).doReturn(multiGrantBalance).when(instance).multiRequest(
                    any(), any(), any());
            emulateMtxResponseSubscription(instance, subscription);
            System.out.println(subscription.toJson());
            // method to test
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn("");
                instance.getQuoteAdvice(input, output);
            }

            System.out.println(
                    MessageFormat.format(
                            "{0}Asserting Test {1}{2}", stars, testCase.testNum, stars));
            assertNotNull(output.getCredits());
            assertEquals(
                    ((BigDecimal) testCase.expectedResultMap.get("QUOTEREDEEM")).intValue(),
                    output.getCredits().get(0).getRedeemableCredits().intValue());

            assertNotNull(output.getNextCyclePaymentAdvice());
            assertNotNull(output.getNextCyclePaymentAdvice().getCredits());
            assertEquals(
                    ((BigDecimal) testCase.expectedResultMap.get("AOPREDEEM")).intValue(),
                    output.getNextCyclePaymentAdvice().getCredits().get(
                            0).getRedeemableCredits().intValue());
        };

        TestCase tc;

        tc = new TestCase();
        tc.testNum = (new Exception()).getStackTrace()[0].getLineNumber() + "";
        tc.baseOffer = CI_EXTERNAL_IDS.PLUS_CURRENT;
        tc.minimumCharge = BigDecimal.valueOf(5);
        tc.mainBalance = BigDecimal.ZERO;
        TestCasePromo tcp = getNewTestCasePromo(
                CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT, BigDecimal.valueOf(25), BigDecimal.ZERO);
        tcp.applicableCi = CI_EXTERNAL_IDS.PLUS_CURRENT;
        tc.promoList.add(tcp);
        tc.expectedResultMap.put("QUOTEREDEEM", BigDecimal.valueOf(15));
        tc.expectedResultMap.put("AOPREDEEM", BigDecimal.valueOf(10));
        pTests.test(tc);
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-367")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_IncludePaymentAdvice_And_ChangeToMonthly_PercentagePromoAvailable_Then_CorrectPromos")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber has some percentage based promos like xxx.|"
       +"|When |Api is called with with target monthly service. IncludePaymentAdvice = Y|"
       +"|Then |Advice should include PaymentAdvice for next service.|"
       +"|     |Quote Cycle and Next PaymentAdvice Cycle should be independent in getting promos.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_IncludePaymentAdvice_And_ChangeToMonthly_PercentagePromoAvailable_Then_CorrectPromos(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        OneParameterTest pTests = (tCase) -> {
            td.printDescription();
            TestCase testCase = (TestCase) tCase;
            String stars = "***************************************";
            System.out.println(
                    MessageFormat.format(
                            "{0}Executing Test {1}{2}", stars, testCase.testNum, stars));

            VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                    "N", testCase.baseOffer);
            input.setIncludePaymentAdvice("Y");
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxResponseWallet wallet = emulateMtxResponseWalletMinimal(
                    instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
            wallet.getBillingCycle().setCurrentPeriodStartTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            wallet.getBillingCycle().setCurrentPeriodEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth().plusMilli(
                            DATE_TIME_CONSTANTS.MILLISECONDS_IN_A_DAY * 30));
            wallet.getBalanceArrayAppender().clear();
            MtxBalanceInfoSimple mainBalanceWallet = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfoSimple.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfoSimple_Mainbalance.json");
            mainBalanceWallet.setAmount(testCase.mainBalance.negate());
            mainBalanceWallet.setAvailableAmount(testCase.mainBalance);
            wallet.getBalanceArrayAppender().add(mainBalanceWallet);

            emulateAocServicePurchase(instance);
            MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                    testCase.baseOffer, CommonTestHelper.getOfferPrice(testCase.baseOffer));

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));

            MtxResponseMulti multiGrantBalance = CommonTestHelper.getEmptyMtxResponseMulti();
            MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
            MtxResponse okayResponse = new MtxResponse();
            okayResponse.setResult(1l);
            okayResponse.setResultText("OK");
            multiAocBase.getResponseListAppender().add(okayResponse);
            multiAocBase.getResponseListAppender().add(okayResponse);
            multiAocBase.getResponseListAppender().add(purResponseBase);

            TestCasePromo promo = testCase.promoList.get(0);
            BigDecimal percentageGrant = new BigDecimal("20");

            Map<String, MtxResponsePricingCatalogItem> pricingMap = emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(testCase.baseOffer, promo.grantOffer));
            VisibleTemplate vt = (VisibleTemplate) pricingMap.get(
                    promo.grantOffer).getCatalogItemInfo().getTemplateAttr();
            vt.setApplicableOfferName(testCase.baseOffer);
            vt.setDiscountCalculationMethod(
                    CREDIT_CONSTANTS.CALCULATION_METHOD_READ_OFFER_INSTANCE);
            MtxPurchasedOfferInfo promoOffer = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, promo.grantOffer, BigDecimal.valueOf(50), promo.grant,
                    promo.consumable);
            ((VisiblePurchasedOfferExtension) promoOffer.getAttr()).setApplicableOfferName(
                    testCase.baseOffer);
            ((VisiblePurchasedOfferExtension) promoOffer.getAttr()).setCreditGrantType(
                    CREDIT_CONSTANTS.GRANT_TYPE_PERCENTAGE);
            ((VisiblePurchasedOfferExtension) promoOffer.getAttr()).setChargeAmount(
                    percentageGrant);
            ((VisiblePurchasedOfferExtension) promoOffer.getAttr()).setMinimumCharge(
                    testCase.minimumCharge);
            ((VisiblePurchasedOfferExtension) promoOffer.getAttr()).setDiscountCalculationMethod(
                    CREDIT_CONSTANTS.CALCULATION_METHOD_READ_OFFER_INSTANCE);

            MtxResponsePricingBalance grantPricing = CommonTestHelper.getMtxResponsePricingBalance(
                    CommonTestHelper.getGrantBalanceName(promo.grantOffer));
            multiGrantBalance.getResponseListAppender().add(grantPricing);

            VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

            // mocks
            doReturn("").when(instance).getRoute(any());
            doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
            doReturn(multiAocBase).doReturn(multiGrantBalance).when(instance).multiRequest(
                    any(), any(), any());

            emulateMtxResponseSubscription(instance, subscription);
            System.out.println(subscription.toJson());
            // method to test
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn("");
                instance.getQuoteAdvice(input, output);
            }
            System.out.println(
                    MessageFormat.format(
                            "{0}Asserting Test {1}{2}", stars, testCase.testNum, stars));
            assertNotNull(output.getCredits());
            assertEquals(
                    ((BigDecimal) testCase.expectedResultMap.get("QUOTEREDEEM")).intValue(),
                    output.getCredits().get(0).getRedeemableCredits().intValue());

            assertNotNull(output.getNextCyclePaymentAdvice());
            assertNotNull(output.getNextCyclePaymentAdvice().getCredits());
            assertEquals(
                    ((BigDecimal) testCase.expectedResultMap.get("AOPREDEEM")).intValue(),
                    output.getNextCyclePaymentAdvice().getCredits().get(
                            0).getRedeemableCredits().intValue());
        };

        TestCase tc;

        tc = new TestCase();
        tc.testNum = (new Exception()).getStackTrace()[0].getLineNumber() + "";
        tc.baseOffer = CI_EXTERNAL_IDS.PLUS_CURRENT;
        tc.minimumCharge = BigDecimal.valueOf(5);
        tc.mainBalance = BigDecimal.ZERO;
        TestCasePromo tcp = getNewTestCasePromoPercentage(
                CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT, BigDecimal.valueOf(20), BigDecimal.ZERO);
        // tcp.applicableCi = CI_EXTERNAL_IDS.PLUS2VIS22;
        tc.promoList.add(tcp);
        // 35*20/100=7
        tc.expectedResultMap.put("QUOTEREDEEM", BigDecimal.valueOf(7));
        tc.expectedResultMap.put("AOPREDEEM", BigDecimal.valueOf(7));
        pTests.test(tc);
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-367")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_IncludePaymentAdvice_And_ChangeToMonthly_AocPromoAvailable_Then_CorrectPromos")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber has some aoc based promos like vbpp.|"
       +"|When |Api is called with with target monthly service. IncludePaymentAdvice = Y|"
       +"|Then |Advice should include PaymentAdvice for next service.|"
       +"|     |Quote Cycle and Next PaymentAdvice Cycle should be independent in getting promos.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_IncludePaymentAdvice_And_ChangeToMonthly_AocPromoAvailable_Then_CorrectPromos(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        OneParameterTest pTests = (tCase) -> {
            td.printDescription();
            TestCase testCase = (TestCase) tCase;
            String stars = "***************************************";
            System.out.println(
                    MessageFormat.format(
                            "{0}Executing Test {1}{2}", stars, testCase.testNum, stars));

            VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                    "N", testCase.baseOffer);
            input.setIncludePaymentAdvice("Y");

            TestCasePromo promo = testCase.promoList.get(0);
            String grantOffer = promo.grantOffer;
            AppPropertyProvider.getInstance().setProperty(
                    CREDIT_CONSTANTS.AOC_GRANT_OFFERS, grantOffer);

            MtxResponseWallet wallet = emulateMtxResponseWalletMinimal(
                    instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
            wallet.getBillingCycle().setCurrentPeriodStartTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            wallet.getBillingCycle().setCurrentPeriodEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth().plusMilli(
                            DATE_TIME_CONSTANTS.MILLISECONDS_IN_A_DAY * 30));
            wallet.getBalanceArrayAppender().clear();
            MtxBalanceInfoSimple mainBalanceWallet = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfoSimple.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfoSimple_Mainbalance.json");
            mainBalanceWallet.setAmount(testCase.mainBalance.negate());
            mainBalanceWallet.setAvailableAmount(testCase.mainBalance);
            wallet.getBalanceArrayAppender().add(mainBalanceWallet);

            emulateAocServicePurchase(instance);
            MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                    testCase.baseOffer, CommonTestHelper.getOfferPrice(testCase.baseOffer));

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));

            subscription.setParentGroupCount(1L);
            subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
            subscriptionResponse.setParentGroupCount(1L);
            subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));

            MtxResponseMulti responseGroupMulti = new MtxResponseMulti();
            responseGroupMulti.setResult(RESULT_CODES.MTX_SUCCESS);
            responseGroupMulti.setResultText("OK");
            MtxResponseGroup respGrp = new MtxResponseGroup();
            respGrp.setTier("VBPP");
            responseGroupMulti.appendResponseList(respGrp);

            System.out.println(responseGroupMulti.toJson());
            doReturn(responseGroupMulti).when(instance).querySubscriptionGroups(
                    any(), any(), any());

            MtxResponseMulti multiGrantBalance = CommonTestHelper.getEmptyMtxResponseMulti();
            MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
            MtxResponse okayResponse = new MtxResponse();
            okayResponse.setResult(1l);
            okayResponse.setResultText("OK");
            multiAocBase.getResponseListAppender().add(okayResponse);
            multiAocBase.getResponseListAppender().add(okayResponse);
            multiAocBase.getResponseListAppender().add(purResponseBase);

            Map<String, MtxResponsePricingCatalogItem> pricingMap = emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(testCase.baseOffer, grantOffer));
            VisibleTemplate vtAoc = (VisibleTemplate) pricingMap.get(
                    grantOffer).getCatalogItemInfo().getTemplateAttr();
            vtAoc.setApplicableOfferName(testCase.baseOffer);

            doReturn(((BigDecimal) promo.grant).negate()).when(
                    instance).getChargeableAmountForPurchaseOffer(
                            any(),
                            argThat(
                                    (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                            vtAoc.getRedeemOffer())),
                            any(), any(MtxSubscriberSearchData.class));

            VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

            // mocks
            doReturn("").when(instance).getRoute(any());
            doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
            doReturn(multiAocBase).doReturn(multiGrantBalance).when(instance).multiRequest(
                    any(), any(), any());
            emulateMtxResponseSubscription(instance, subscription);
            System.out.println(subscription.toJson());
            // method to test
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn("");
                instance.getQuoteAdvice(input, output);
            }

            System.out.println(
                    MessageFormat.format(
                            "{0}Asserting Test {1}{2}", stars, testCase.testNum, stars));
            assertNotNull(output.getCredits());
            assertEquals(
                    ((BigDecimal) testCase.expectedResultMap.get("QUOTEREDEEM")).intValue(),
                    output.getCredits().get(0).getRedeemableCredits().intValue());

            assertNotNull(output.getNextCyclePaymentAdvice());
            assertNotNull(output.getNextCyclePaymentAdvice().getCredits());
            assertEquals(
                    ((BigDecimal) testCase.expectedResultMap.get("AOPREDEEM")).intValue(),
                    output.getNextCyclePaymentAdvice().getCredits().get(
                            0).getRedeemableCredits().intValue());
        };

        TestCase tc;

        tc = new TestCase();
        tc.testNum = (new Exception()).getStackTrace()[0].getLineNumber() + "";
        tc.baseOffer = CI_EXTERNAL_IDS.PLUS_CURRENT;
        tc.minimumCharge = BigDecimal.valueOf(5);
        tc.mainBalance = BigDecimal.ZERO;
        TestCasePromo tcp = getNewTestCasePromo(
                CI_EXTERNAL_IDS.VBPP5_AOC_GRANT, BigDecimal.valueOf(5), BigDecimal.ZERO);
        tc.promoList.add(tcp);
        tc.expectedResultMap.put("QUOTEREDEEM", BigDecimal.valueOf(5));
        tc.expectedResultMap.put("AOPREDEEM", BigDecimal.valueOf(5));
        pTests.test(tc);
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-449")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_zeroDollarOfferInRequest_Then_ZeroDollarOfferInResponse")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber active.|"
       +"|When |Quote advice called for zero dollar offer.|"
       +"|Then |zero dollar offer in response.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_zeroDollarOfferInRequest_Then_ZeroDollarOfferInResponse(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.TRIAL22);

        System.out.println(td.getTestMethod() + " : " + input.toJson());

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, CI_EXTERNAL_IDS.BONUS_MONEY_REDEEM);
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(CI_EXTERNAL_IDS.TRIAL22, CI_EXTERNAL_IDS.BONUS_MONEY_REDEEM));

        // For Aoc Response for service offers
        MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                CI_EXTERNAL_IDS.TRIAL22, BigDecimal.ZERO);

        MtxResponseMulti multiGrantBalance = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponse okayResponse = new MtxResponse();
        okayResponse.setResult(1l);
        okayResponse.setResultText("OK");
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(purResponseBase);
        doReturn(multiAocBase).doReturn(multiGrantBalance).when(instance).multiRequest(
                any(), any(), any());
        doReturn(BigDecimal.valueOf(0.1)).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(CI_EXTERNAL_IDS.BONUS_MONEY_REDEEM), any(),
                any(MtxSubscriberSearchData.class));

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        // method to test
        instance.getQuoteAdvice(input, output);
        System.out.println(output.toJson());
        assertEquals(
                CI_EXTERNAL_IDS.TRIAL22,
                output.getVisibleOfferDetailsList().get(0).getCatalogItemExternalId());
        assertEquals(
                BigDecimal.ZERO.doubleValue(), output.getTotalEstimatedAmount().doubleValue(),
                0.0001);
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-449")
    @ParameterizedTest(name = "test_getQuoteAdvice_When_aocWithNoBalanceDetails_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber active.|"
       +"|When |Quote advice called. AoC for input offer does not have balance update details with cycle datails and impact amount.|"
       +"|Then |Exception.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_aocWithNoBalanceDetails_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION);

        System.out.println(td.getTestMethod() + " : " + input.toJson());

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION));

        // For Aoc Response for service offers
        MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase_NoBalanceImpact(
                CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION, BigDecimal.ZERO);

        MtxResponseMulti multiGrantBalance = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponse okayResponse = new MtxResponse();
        okayResponse.setResult(1l);
        okayResponse.setResultText("OK");
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(purResponseBase);
        doReturn(multiAocBase).doReturn(multiGrantBalance).when(instance).multiRequest(
                any(), any(), any());

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        // method to test
        Exception exception = assertThrows(
                PaymentAdviceException.class, () -> instance.getQuoteAdvice(input, output));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertEquals(
                "Advice of Charge not available for non-zero offer: CD2VISIBLE2023",
                exception.getMessage());
    }

    @SuppressWarnings({
        "unchecked", "serial"
    })
    @Tags({
        @Tag("VER-449"), @Tag("MTXVER2TMA-4523")
    })
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_promoConsumableMoreThanPrice_Then_NoTaxError")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given|Subscriber active.|"
       +"|When |Quote advice called. Mainbalance impact is zero. All impact goes to consumable balance.|"
       +"|Then |No Tax Exception.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_promoConsumableMoreThanPrice_Then_NoTaxError(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", CI_EXTERNAL_IDS.BASE3VIS23);
        System.out.println(td.getTestMethod() + " : " + input.toJson());

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.GOODWILL_GRANT,
                CommonTestHelper.getGrantBalanceResourceId(CI_EXTERNAL_IDS.GRANT_GOODWILL),
                CommonTestHelper.getGrantBalanceTemplateId(CI_EXTERNAL_IDS.GRANT_GOODWILL),
                BigDecimal.valueOf(10));
        subscription.getBalanceArrayAppender().add(mbiGoodGrant);
        MtxBalanceInfo mbiGoodCons = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.GOODWILL_CONSUMABLE,
                CommonTestHelper.getConsumableBalanceResourceId(CI_EXTERNAL_IDS.GRANT_GOODWILL),
                CommonTestHelper.getConsumableBalanceTemplateId(CI_EXTERNAL_IDS.GRANT_GOODWILL),
                input.getAtCatalogItemList(0).getDiscountPrice());
        subscription.getBalanceArrayAppender().add(mbiGoodCons);

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                        CI_EXTERNAL_IDS.GRANT_GOODWILL));

        // For Aoc Response for service offers
        Map<String, BigDecimal> impactMap = new HashMap<String, BigDecimal>() {

            {
                put(
                        CI_EXTERNAL_IDS.GRANT_GOODWILL,
                        input.getAtCatalogItemList(0).getDiscountPrice());
            }
        };
        MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(), BigDecimal.ZERO,
                impactMap);

        MtxResponseMulti multiGrantBalance = CommonTestHelper.getMtxResponseMulti_For_CreditBalances(
                subscription);

        MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponse okayResponse = new MtxResponse();
        okayResponse.setResult(1l);
        okayResponse.setResultText("OK");
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(purResponseBase);
        doReturn(multiAocBase).doReturn(multiGrantBalance).when(instance).multiRequest(
                any(), any(), any());

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        // method to test
        String taxRespString = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId());

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxRespString);
            // method to test
            instance.getQuoteAdvice(input, output);
        }

        // instance.getQuoteAdvice(input, output);
        System.out.println(td.getTestMethod() + ":" + output.toJson());
        assertTrue(StringUtils.isNotBlank(output.getAtCredits(0).getTaxDetails()));
        assertFalse(output.getAtCredits(0).getTaxDetails().toUpperCase().contains("ERROR"));
        assertEquals(
                input.getAtCatalogItemList(0).getDiscountPrice().intValue(),
                output.getAtCredits(0).getRedeemableCredits().intValue());
        // Do not assert payable amount. Fixed greater than payable scenario is evaluated after
        // calculating all credits.
        // In real world scenario fixed fee is always less than minimum charge.
        // In real world scenario consumable credits are never more than price of base offer (only
        // base offer)
    }

    @SuppressWarnings("unchecked")
    @Tags({
        @Tag("VER-502"), @Tag("VER-515"), @Tag("CreditTaxSubtraction"), @Tag("Tax")
    })
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_CreditTaxBySubtract_Then_Correct_TotalNetRevenue")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber with REF20.|"
                +"|When  |Quote advice called for PLU3ANNUAL|"
                +"|Then  |Correct net revenue in credit taxes.|"})
    // @formatter:on
    public void test_getQuoteAdvice_When_CreditTaxBySubtract_Then_Correct_TotalNetRevenue(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", CI_EXTERNAL_IDS.PLUS3ANNUAL);

        System.out.println(td.getTestMethod() + " : " + input.toJson());

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        MtxBalanceInfo mbiRef20Grant = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.REF20_GRANT,
                CommonTestHelper.getGrantBalanceResourceId(CI_EXTERNAL_IDS.REF20_GRANT),
                CommonTestHelper.getGrantBalanceTemplateId(CI_EXTERNAL_IDS.REF20_GRANT),
                BigDecimal.valueOf(100));
        subscription.getBalanceArrayAppender().add(mbiRef20Grant);

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                        CI_EXTERNAL_IDS.REF20_GRANT));

        MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                input.getAtCatalogItemList(0).getDiscountPrice());

        MtxResponseMulti multiGrantBalance = CommonTestHelper.getMtxResponseMulti_For_CreditBalances(
                subscription);

        MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponse okayResponse = new MtxResponse();
        okayResponse.setResult(1l);
        okayResponse.setResultText("OK");
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(purResponseBase);
        doReturn(multiAocBase).doReturn(multiGrantBalance).when(instance).multiRequest(
                any(), any(), any());

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        // method to test
        String taxRespString = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId());
        String taxCreditSubString = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(), 20, "REF-20");

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), contains("SVC"))).thenReturn(
                            taxRespString);
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), contains("REF-20"))).thenReturn(
                            taxCreditSubString);
            // method to test
            instance.getQuoteAdvice(input, output);
        }

        System.out.println(td.getTestMethod() + " : " + output.toJson());
        ServiceTaxResponse promoTaxResp = CommonTestHelper.getJsonFromString(
                ServiceTaxResponse.class,
                output.getCredits().stream().filter(
                        vc -> vc.getCreditRedeemableOfferCI().equals(
                                CI_EXTERNAL_IDS.REF20_REDEEM)).findAny().get().getTaxDetails());

        System.out.println(td.getTestMethod() + " : Final Credit Tax: " + promoTaxResp.toJson());

        ServiceTaxResponse taxRespServiceAsPromoJson = CommonTestHelper.getJsonFromString(
                ServiceTaxResponse.class, taxRespString);
        ServiceTaxResponse taxRespSansRefCreditJson = CommonTestHelper.getJsonFromString(
                ServiceTaxResponse.class, taxCreditSubString);

        ObjectSummary summary = (str) -> {
            Map<String, Object> taxMap = new HashMap<String, Object>();
            Map<String, String> msgMap = new HashMap<String, String>();
            ServiceTaxResponse taxResp = (ServiceTaxResponse) str;
            taxResp.getTransactionElement().forEach(te -> {
                String btcPrefix = "BTC" + te.getBtcTransactionCode() + "-";
                taxMap.put(btcPrefix + "TotalNetRevenue", te.getTotalNetRevenue());
                msgMap.put(btcPrefix + "TotalNetRevenue", te.getTotalNetRevenue() + "");
                taxMap.forEach((k, v) -> {
                    System.out.println(k + "--> " + msgMap.get(k) + "=" + v);
                });

            });
            return taxMap;
        };
        System.out.println(
                "---------------------------Service Tax Summary---------------------------");
        Map<String, Object> svcTaxMap = summary.get(taxRespServiceAsPromoJson);
        System.out.println(
                "---------------------------Difference Tax Summary---------------------------");
        Map<String, Object> promoLessTaxMap = summary.get(taxRespSansRefCreditJson);
        System.out.println(
                "---------------------------Credit Tax Summary---------------------------");
        Map<String, Object> promoTaxMap = summary.get(promoTaxResp);

        System.out.println("---------------------------Comparison---------------------------");
        svcTaxMap.forEach((k, v) -> {
            System.out.println(
                    k + "--> " + v + " - " + promoLessTaxMap.get(k) + " = "
                            + ((BigDecimal) svcTaxMap.get(k)).subtract(
                                    (BigDecimal) promoLessTaxMap.get(k))
                            + " <=> " + promoTaxMap.get(k));
            assertEquals(
                    ((BigDecimal) svcTaxMap.get(k)).subtract(
                            (BigDecimal) promoLessTaxMap.get(k)).doubleValue(),
                    ((BigDecimal) promoTaxMap.get(k)).doubleValue(), 0.0001);
            System.out.println("pass");
        });
    }

    @SuppressWarnings("unchecked")
    @Tags({
        @Tag("VER-515"), @Tag("CreditTaxSubtraction"), @Tag("Tax")
    })
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_CreditTaxBySubtract_Then_Correct_DPCItemNetRevenue")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber with REF20.|"
                +"|When  |Quote advice called for PLU3ANNUAL|"
                +"|Then  |Correct match of dpc groups for subtraction. Correct DpcItemNetRevenue.|"
                +"|Comments|DPC group matching can be verified by validating tax amount at dpc group level.|"})
    // @formatter:on
    public void test_getQuoteAdvice_When_CreditTaxBySubtract_Then_Correct_DPCItemNetRevenue(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", CI_EXTERNAL_IDS.PLUS3ANNUAL);
        System.out.println(td.getTestMethod() + " : " + input.toJson());

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        MtxBalanceInfo mbiRef20Grant = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.REF20_GRANT,
                CommonTestHelper.getGrantBalanceResourceId(CI_EXTERNAL_IDS.REF20_GRANT),
                CommonTestHelper.getGrantBalanceTemplateId(CI_EXTERNAL_IDS.REF20_GRANT),
                BigDecimal.valueOf(100));
        subscription.getBalanceArrayAppender().add(mbiRef20Grant);

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                        CI_EXTERNAL_IDS.REF20_GRANT));

        MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                input.getAtCatalogItemList(0).getDiscountPrice());

        MtxResponseMulti multiGrantBalance = CommonTestHelper.getMtxResponseMulti_For_CreditBalances(
                subscription);

        MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponse okayResponse = new MtxResponse();
        okayResponse.setResult(1l);
        okayResponse.setResultText("OK");
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(purResponseBase);
        doReturn(multiAocBase).doReturn(multiGrantBalance).when(instance).multiRequest(
                any(), any(), any());

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        // method to test
        String taxRespString = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId());
        String taxCreditSubString = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(), 20, "REF-20");

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), contains("SVC"))).thenReturn(
                            taxRespString);
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), contains("REF-20"))).thenReturn(
                            taxCreditSubString);
            // method to test
            instance.getQuoteAdvice(input, output);
        }

        System.out.println(td.getTestMethod() + " : " + output.toJson());
        ServiceTaxResponse promoTaxResp = CommonTestHelper.getJsonFromString(
                ServiceTaxResponse.class,
                output.getCredits().stream().filter(
                        vc -> vc.getCreditRedeemableOfferCI().equals(
                                CI_EXTERNAL_IDS.REF20_REDEEM)).findAny().get().getTaxDetails());

        System.out.println(td.getTestMethod() + " : Final Credit Tax: " + promoTaxResp.toJson());

        ServiceTaxResponse taxRespServiceAsPromoJson = CommonTestHelper.getJsonFromString(
                ServiceTaxResponse.class, taxRespString);
        ServiceTaxResponse taxRespSansRefCreditJson = CommonTestHelper.getJsonFromString(
                ServiceTaxResponse.class, taxCreditSubString);

        ObjectSummary summary = (str) -> {
            Map<String, Object> taxMap = new HashMap<String, Object>();
            Map<String, String> msgMap = new HashMap<String, String>();
            ServiceTaxResponse taxResp = (ServiceTaxResponse) str;
            taxResp.getTransactionElement().forEach(te -> {
                String btcPrefix = "BTC" + te.getBtcTransactionCode() + "-";
                taxMap.put(btcPrefix + "TotalNetRevenue", te.getTotalNetRevenue());
                msgMap.put(btcPrefix + "TotalNetRevenue", te.getTotalNetRevenue() + "");
                te.getDpcGroupList().forEach(dgt -> {
                    dgt.getDpcItemList().forEach(dit -> {
                        String itemPrefix = btcPrefix + "ITEM" + dit.getDpcItem() + "-";
                        String dpcNetPrefix = itemPrefix + "DpcItemNetRevenue";
                        if (taxMap.get(dpcNetPrefix) != null) {
                            msgMap.put(
                                    dpcNetPrefix,
                                    msgMap.get(dpcNetPrefix) + "+" + dit.getDpcItemNetRevenue());
                            taxMap.put(
                                    dpcNetPrefix, ((BigDecimal) taxMap.get(dpcNetPrefix)).add(
                                            dit.getDpcItemNetRevenue()));
                        } else {
                            msgMap.put(dpcNetPrefix, "" + dit.getDpcItemNetRevenue());
                            taxMap.put(dpcNetPrefix, dit.getDpcItemNetRevenue());
                        }
                    });
                });
                taxMap.forEach((k, v) -> {
                    System.out.println(k + "--> " + msgMap.get(k) + "=" + v);
                });

            });
            return taxMap;
        };
        System.out.println(
                "---------------------------Service Tax Summary---------------------------");
        Map<String, Object> svcTaxMap = summary.get(taxRespServiceAsPromoJson);
        System.out.println(
                "---------------------------Difference Tax Summary---------------------------");
        Map<String, Object> promoLessTaxMap = summary.get(taxRespSansRefCreditJson);
        System.out.println(
                "---------------------------Credit Tax Summary---------------------------");
        Map<String, Object> promoTaxMap = summary.get(promoTaxResp);

        System.out.println("---------------------------Comparison---------------------------");
        svcTaxMap.forEach((k, v) -> {
            System.out.println(
                    k + "--> " + v + " - " + promoLessTaxMap.get(k) + " = "
                            + ((BigDecimal) svcTaxMap.get(k)).subtract(
                                    (BigDecimal) promoLessTaxMap.get(k))
                            + " <=> " + promoTaxMap.get(k));
            assertEquals(
                    ((BigDecimal) svcTaxMap.get(k)).subtract(
                            (BigDecimal) promoLessTaxMap.get(k)).doubleValue(),
                    ((BigDecimal) promoTaxMap.get(k)).doubleValue(), 0.0001);
            System.out.println("pass");
        });
    }

    @SuppressWarnings("unchecked")
    @Tags({
        @Tag("VER-515"), @Tag("CreditTaxSubtraction"), @Tag("Tax")
    })
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_CreditTaxBySubtract_Then_Correct_DPCItemTaxAmount")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber with REF20.|"
                +"|When  |Quote advice called for PLU3ANNUAL|"
                +"|Then  |Correct match of dpc groups for subtraction. Correct DpcItemTaxAmount.|"
                +"|Comments|DPC group matching can be verified by validating tax amount at dpc group level.|"})
    // @formatter:on
    public void test_getQuoteAdvice_When_CreditTaxBySubtract_Then_Correct_DPCItemTaxAmount(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", CI_EXTERNAL_IDS.PLUS3ANNUAL);
        System.out.println(td.getTestMethod() + " : " + input.toJson());

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        MtxBalanceInfo mbiRef20Grant = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.REF20_GRANT,
                CommonTestHelper.getGrantBalanceResourceId(CI_EXTERNAL_IDS.REF20_GRANT),
                CommonTestHelper.getGrantBalanceTemplateId(CI_EXTERNAL_IDS.REF20_GRANT),
                BigDecimal.valueOf(100));
        subscription.getBalanceArrayAppender().add(mbiRef20Grant);

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                        CI_EXTERNAL_IDS.REF20_GRANT));

        MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                input.getAtCatalogItemList(0).getDiscountPrice());

        MtxResponseMulti multiGrantBalance = CommonTestHelper.getMtxResponseMulti_For_CreditBalances(
                subscription);

        MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponse okayResponse = new MtxResponse();
        okayResponse.setResult(1l);
        okayResponse.setResultText("OK");
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(purResponseBase);
        doReturn(multiAocBase).doReturn(multiGrantBalance).when(instance).multiRequest(
                any(), any(), any());

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        // method to test
        String taxRespString = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId());
        String taxCreditSubString = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(), 20, "REF-20");

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), contains("SVC"))).thenReturn(
                            taxRespString);
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), contains("REF-20"))).thenReturn(
                            taxCreditSubString);
            // method to test
            instance.getQuoteAdvice(input, output);
        }

        System.out.println(td.getTestMethod() + " : " + output.toJson());
        ServiceTaxResponse promoTaxResp = CommonTestHelper.getJsonFromString(
                ServiceTaxResponse.class,
                output.getCredits().stream().filter(
                        vc -> vc.getCreditRedeemableOfferCI().equals(
                                CI_EXTERNAL_IDS.REF20_REDEEM)).findAny().get().getTaxDetails());

        System.out.println(td.getTestMethod() + " : Final Credit Tax: " + promoTaxResp.toJson());

        ServiceTaxResponse taxRespServiceAsPromoJson = CommonTestHelper.getJsonFromString(
                ServiceTaxResponse.class, taxRespString);
        ServiceTaxResponse taxRespSansRefCreditJson = CommonTestHelper.getJsonFromString(
                ServiceTaxResponse.class, taxCreditSubString);

        ObjectSummary summary = (str) -> {
            Map<String, Object> taxMap = new HashMap<String, Object>();
            Map<String, String> msgMap = new HashMap<String, String>();
            ServiceTaxResponse taxResp = (ServiceTaxResponse) str;
            taxResp.getTransactionElement().forEach(te -> {
                String btcPrefix = "BTC" + te.getBtcTransactionCode() + "-";
                te.getDpcGroupList().forEach(dgt -> {
                    dgt.getDpcItemList().forEach(dit -> {
                        String itemPrefix = btcPrefix + "ITEM" + dit.getDpcItem() + "-";
                        String dpcNetPrefix = itemPrefix + "DpcItemTaxAmount";
                        if (taxMap.get(dpcNetPrefix) != null) {
                            msgMap.put(
                                    dpcNetPrefix,
                                    msgMap.get(dpcNetPrefix) + "+" + dit.getDpcItemTaxAmount());
                            taxMap.put(
                                    dpcNetPrefix, ((BigDecimal) taxMap.get(dpcNetPrefix)).add(
                                            dit.getDpcItemTaxAmount()));
                        } else {
                            msgMap.put(dpcNetPrefix, "" + dit.getDpcItemTaxAmount());
                            taxMap.put(dpcNetPrefix, dit.getDpcItemTaxAmount());
                        }
                    });
                });
                taxMap.forEach((k, v) -> {
                    System.out.println(k + "--> " + msgMap.get(k) + "=" + v);
                });

            });
            return taxMap;
        };
        System.out.println(
                "---------------------------Service Tax Summary---------------------------");
        Map<String, Object> svcTaxMap = summary.get(taxRespServiceAsPromoJson);
        System.out.println(
                "---------------------------Difference Tax Summary---------------------------");
        Map<String, Object> promoLessTaxMap = summary.get(taxRespSansRefCreditJson);
        System.out.println(
                "---------------------------Credit Tax Summary---------------------------");
        Map<String, Object> promoTaxMap = summary.get(promoTaxResp);

        System.out.println("---------------------------Comparison---------------------------");
        svcTaxMap.forEach((k, v) -> {
            System.out.println(
                    k + "--> " + v + " - " + promoLessTaxMap.get(k) + " = "
                            + ((BigDecimal) svcTaxMap.get(k)).subtract(
                                    (BigDecimal) promoLessTaxMap.get(k))
                            + " <=> " + promoTaxMap.get(k));
            assertEquals(
                    ((BigDecimal) svcTaxMap.get(k)).subtract(
                            (BigDecimal) promoLessTaxMap.get(k)).doubleValue(),
                    ((BigDecimal) promoTaxMap.get(k)).doubleValue(), 0.0001);
            System.out.println("pass");
        });
    }

    @SuppressWarnings("unchecked")
    @Tags({
        @Tag("VER-515"), @Tag("CreditTaxSubtraction"), @Tag("Tax")
    })
    @ParameterizedTest(name = "test_getQuoteAdvice_When_CreditTaxBySubtract_Then_Correct_DPCItemCP")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber with REF20.|"
                +"|When  |Quote advice called for PLU3ANNUAL|"
                +"|Then  |Correct match of dpc groups for subtraction. Correct DpcItem Contribution Percentage.|"
                +"|Comments|TAI Tax Amount is at most granular level.|"})
    // @formatter:on
    public void test_getQuoteAdvice_When_CreditTaxBySubtract_Then_Correct_DPCItemCP(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", CI_EXTERNAL_IDS.PLUS3ANNUAL);
        System.out.println(td.getTestMethod() + " : " + input.toJson());

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        MtxBalanceInfo mbiRef20Grant = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.REF20_GRANT,
                CommonTestHelper.getGrantBalanceResourceId(CI_EXTERNAL_IDS.REF20_GRANT),
                CommonTestHelper.getGrantBalanceTemplateId(CI_EXTERNAL_IDS.REF20_GRANT),
                BigDecimal.valueOf(100));
        subscription.getBalanceArrayAppender().add(mbiRef20Grant);

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                        CI_EXTERNAL_IDS.REF20_GRANT));

        MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                input.getAtCatalogItemList(0).getDiscountPrice());

        MtxResponseMulti multiGrantBalance = CommonTestHelper.getMtxResponseMulti_For_CreditBalances(
                subscription);

        MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponse okayResponse = new MtxResponse();
        okayResponse.setResult(1l);
        okayResponse.setResultText("OK");
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(purResponseBase);
        doReturn(multiAocBase).doReturn(multiGrantBalance).when(instance).multiRequest(
                any(), any(), any());

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        // method to test
        String taxRespString = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId());
        String taxCreditSubString = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(), 20, "REF-20");

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), contains("SVC"))).thenReturn(
                            taxRespString);
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), contains("REF-20"))).thenReturn(
                            taxCreditSubString);
            // method to test
            instance.getQuoteAdvice(input, output);
        }

        System.out.println(td.getTestMethod() + " : " + output.toJson());
        ServiceTaxResponse promoTaxResp = CommonTestHelper.getJsonFromString(
                ServiceTaxResponse.class,
                output.getCredits().stream().filter(
                        vc -> vc.getCreditRedeemableOfferCI().equals(
                                CI_EXTERNAL_IDS.REF20_REDEEM)).findAny().get().getTaxDetails());

        System.out.println(td.getTestMethod() + " : Final Credit Tax: " + promoTaxResp.toJson());

        ServiceTaxResponse taxRespServiceAsPromoJson = CommonTestHelper.getJsonFromString(
                ServiceTaxResponse.class, taxRespString);
        final DecimalFormat numFormat = new DecimalFormat("#.########");
        numFormat.setMinimumFractionDigits(0);
        numFormat.setMaximumFractionDigits(TAX_CONSTANTS.TAX_API_PRECISION);
        numFormat.setMinimumIntegerDigits(1);

        ObjectSummary summary = (str) -> {
            Map<String, Object> taxMap = new HashMap<String, Object>();
            Map<String, String> msgMap = new HashMap<String, String>();
            ServiceTaxResponse taxResp = (ServiceTaxResponse) str;
            taxResp.getTransactionElement().forEach(te -> {
                String btcPrefix = "BTC" + te.getBtcTransactionCode() + "-";
                te.getDpcGroupList().forEach(dgt -> {
                    dgt.getDpcItemList().forEach(dit -> {
                        String itemPrefix = btcPrefix + "ITEM" + dit.getDpcItem() + "-";
                        String dpcCpPrefix = itemPrefix + "CP";
                        if (taxMap.get(dpcCpPrefix) != null) {
                            msgMap.put(
                                    dpcCpPrefix,
                                    msgMap.get(dpcCpPrefix) + "+" + numFormat.format(dit.getcP()));
                            taxMap.put(
                                    dpcCpPrefix,
                                    ((BigDecimal) taxMap.get(dpcCpPrefix)).add(dit.getcP()));
                        } else {
                            msgMap.put(dpcCpPrefix, "" + numFormat.format(dit.getcP()));
                            taxMap.put(dpcCpPrefix, dit.getcP());
                        }
                    });
                });
                taxMap.forEach((k, v) -> {
                    System.out.println(k + "--> " + msgMap.get(k) + "=" + numFormat.format(v));
                });
            });
            return taxMap;
        };
        System.out.println(
                "---------------------------Service Tax Summary---------------------------");
        Map<String, Object> svcTaxMap = summary.get(taxRespServiceAsPromoJson);
        System.out.println(
                "---------------------------Credit Tax Summary---------------------------");
        Map<String, Object> promoTaxMap = summary.get(promoTaxResp);
        System.out.println("---------------------------Comparison---------------------------");
        svcTaxMap.forEach((k, v) -> {
            System.out.println(
                    k + "--> " + numFormat.format(v) + " <=> "
                            + numFormat.format(promoTaxMap.get(k)));
            assertEquals(
                    ((BigDecimal) svcTaxMap.get(k)).doubleValue(),
                    ((BigDecimal) promoTaxMap.get(k)).doubleValue(), 0.0001);
            System.out.println("pass");
        });
    }

    @SuppressWarnings("unchecked")
    @Tags({
        @Tag("VER-515"), @Tag("CreditTaxSubtraction"), @Tag("Tax")
    })
    @ParameterizedTest(name = "test_getQuoteAdvice_When_CreditTaxBySubtract_Then_Correct_TAIAmount")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber with REF20.|"
                +"|When  |Quote advice called for PLU3ANNUAL|"
                +"|Then  |Correct match of dpc groups for subtraction., Correct TaxAmount at each TAI.|"
                +"|Comments|TAI Tax Amount is at most granular level.|"})
    // @formatter:on
    public void test_getQuoteAdvice_When_CreditTaxBySubtract_Then_Correct_TAIAmount(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", CI_EXTERNAL_IDS.PLUS3ANNUAL);
        System.out.println(td.getTestMethod() + " : " + input.toJson());

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        MtxBalanceInfo mbiRef20Grant = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.REF20_GRANT,
                CommonTestHelper.getGrantBalanceResourceId(CI_EXTERNAL_IDS.REF20_GRANT),
                CommonTestHelper.getGrantBalanceTemplateId(CI_EXTERNAL_IDS.REF20_GRANT),
                BigDecimal.valueOf(100));
        subscription.getBalanceArrayAppender().add(mbiRef20Grant);

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                        CI_EXTERNAL_IDS.REF20_GRANT));

        MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                input.getAtCatalogItemList(0).getDiscountPrice());

        MtxResponseMulti multiGrantBalance = CommonTestHelper.getMtxResponseMulti_For_CreditBalances(
                subscription);

        MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponse okayResponse = new MtxResponse();
        okayResponse.setResult(1l);
        okayResponse.setResultText("OK");
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(purResponseBase);
        doReturn(multiAocBase).doReturn(multiGrantBalance).when(instance).multiRequest(
                any(), any(), any());

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        // method to test
        String taxRespString = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId());
        String taxCreditSubString = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(), 20, "REF-20");

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), contains("SVC"))).thenReturn(
                            taxRespString);
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), contains("REF-20"))).thenReturn(
                            taxCreditSubString);
            // method to test
            instance.getQuoteAdvice(input, output);
        }

        System.out.println(td.getTestMethod() + " : " + output.toJson());
        ServiceTaxResponse promoTaxResp = CommonTestHelper.getJsonFromString(
                ServiceTaxResponse.class,
                output.getCredits().stream().filter(
                        vc -> vc.getCreditRedeemableOfferCI().equals(
                                CI_EXTERNAL_IDS.REF20_REDEEM)).findAny().get().getTaxDetails());

        System.out.println(td.getTestMethod() + " : Final Credit Tax: " + promoTaxResp.toJson());

        ServiceTaxResponse taxRespServiceAsPromoJson = CommonTestHelper.getJsonFromString(
                ServiceTaxResponse.class, taxRespString);
        ServiceTaxResponse taxRespSansRefCreditJson = CommonTestHelper.getJsonFromString(
                ServiceTaxResponse.class, taxCreditSubString);

        ObjectSummary summary = (str) -> {
            Map<String, Object> taxMap = new HashMap<String, Object>();
            Map<String, String> msgMap = new HashMap<String, String>();
            ServiceTaxResponse taxResp = (ServiceTaxResponse) str;
            taxResp.getTransactionElement().forEach(te -> {
                String btcPrefix = "BTC" + te.getBtcTransactionCode() + "-";
                te.getDpcGroupList().forEach(dgt -> {
                    dgt.getDpcItemList().forEach(dit -> {
                        String itemPrefix = btcPrefix + "ITEM" + dit.getDpcItem() + "-";
                        dit.getTaxItemList().forEach(ti -> {
                            String taiPrefix = itemPrefix + ti.getTaxItemType() + "-" + ti.getTai()
                                    + "-" + ti.getTat() + "-" + ti.getTaxCategory() + "-"
                                    + ti.getTaxType() + "-";
                            if (taxMap.get(taiPrefix) != null) {
                                msgMap.put(
                                        taiPrefix, msgMap.get(taiPrefix) + "+" + ti.getTaxAmount());
                                taxMap.put(
                                        taiPrefix, ((BigDecimal) taxMap.get(taiPrefix)).add(
                                                ti.getTaxAmount()));
                            } else {
                                msgMap.put(taiPrefix, "" + ti.getTaxAmount());
                                taxMap.put(taiPrefix, ti.getTaxAmount());
                            }
                        });
                    });
                });
                taxMap.forEach((k, v) -> {
                    System.out.println(k + "--> " + msgMap.get(k) + "=" + v);
                });

            });
            return taxMap;
        };
        System.out.println(
                "---------------------------Service Tax Summary---------------------------");
        Map<String, Object> svcTaxMap = summary.get(taxRespServiceAsPromoJson);
        System.out.println(
                "---------------------------Difference Tax Summary---------------------------");
        Map<String, Object> promoLessTaxMap = summary.get(taxRespSansRefCreditJson);
        System.out.println(
                "---------------------------Credit Tax Summary---------------------------");
        Map<String, Object> promoTaxMap = summary.get(promoTaxResp);

        System.out.println("---------------------------Comparison---------------------------");
        svcTaxMap.forEach((k, v) -> {
            System.out.println(
                    k + "--> " + v + " - " + promoLessTaxMap.get(k) + " = "
                            + ((BigDecimal) svcTaxMap.get(k)).subtract(
                                    (BigDecimal) promoLessTaxMap.get(k))
                            + " <=> " + promoTaxMap.get(k));
            assertEquals(
                    ((BigDecimal) svcTaxMap.get(k)).subtract(
                            (BigDecimal) promoLessTaxMap.get(k)).doubleValue(),
                    ((BigDecimal) promoTaxMap.get(k)).doubleValue(), 0.0001);
            System.out.println("pass");
        });
    }

    @ParameterizedTest(name = "When_IncludePaymentAdvice_Then_CorrectCycleDates")
    @Tags({
        @Tag("VER-367"), @Tag("MTXVER2TMA-4527")
    })
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given | Subscriber has some mainbalance.|"
                +"|When  | Api is called with with target monthly service.|IncludePaymentAdvice = Y|"
                +"|Then  | Advice should show correct cycle dates in payment advice.|"})
    // @formatter:on
    @SuppressWarnings({
        "unchecked"
    })
    public void test_getQuoteAdvice_When_IncludePaymentAdvice_Then_CorrectCycleDates(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        OneParameterTest pTests = (tCase) -> {
            td.printDescription();
            TestCase testCase = (TestCase) tCase;
            String stars = "***************************************";
            System.out.println(
                    MessageFormat.format(
                            "{0}Executing Test {1}{2}", stars, testCase.testNum, stars));

            VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                    "N", testCase.baseOffer);
            input.setIncludePaymentAdvice("Y");
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            emulateAocServicePurchase(instance);

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(input.getSubscriberExternalId()));
            BalanceInfo mainBalance = CommonTestHelper.getBalanceInfo(
                    BALANCE_NAMES.MAIN_BALANCE, 101L, 201L, testCase.mainBalance);
            subscriptionResponse.appendWalletBalances(mainBalance);
            subscriptionResponse.getBillingCycle().setCurrentPeriodStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth(subscriptionResponse.getTimeZone()));
            subscriptionResponse.getBillingCycle().setCurrentPeriodEndTime(
                    TestUtils.getFirstDateTimeOfNextMonth(subscriptionResponse.getTimeZone()));
            subscriptionResponse.getBillingCycle().setDateOffset(1L);
            MtxResponseMulti multiGrantBalance = CommonTestHelper.getEmptyMtxResponseMulti();
            MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
            MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                    testCase.baseOffer, CommonTestHelper.getOfferPrice(testCase.baseOffer),
                    subscriptionResponse);

            MtxResponse okayResponse = new MtxResponse();
            okayResponse.setResult(1l);
            okayResponse.setResultText("OK");
            multiAocBase.getResponseListAppender().add(okayResponse);
            multiAocBase.getResponseListAppender().add(okayResponse);
            multiAocBase.getResponseListAppender().add(purResponseBase);

            MtxResponseWallet wallet = emulateMtxResponseWalletMinimal(
                    instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
            wallet.getBillingCycle().setCurrentPeriodStartTime(
                    subscriptionResponse.getBillingCycle().getCurrentPeriodStartTime());
            wallet.getBillingCycle().setCurrentPeriodEndTime(
                    subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime());
            wallet.getBalanceArrayAppender().clear();
            MtxBalanceInfoSimple mainBalanceWallet = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfoSimple.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfoSimple_Mainbalance.json");
            mainBalanceWallet.setAmount(testCase.mainBalance.negate());
            mainBalanceWallet.setAvailableAmount(testCase.mainBalance);
            wallet.getBalanceArrayAppender().add(mainBalanceWallet);

            emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(testCase.baseOffer));

            VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

            // mocks
            doReturn("").when(instance).getRoute(any());
            doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
            doReturn(multiAocBase).doReturn(multiGrantBalance).when(instance).multiRequest(
                    any(), any(), any());
            emulateMtxResponseSubscription(instance, subscription);
            System.out.println(subscriptionResponse.toJson());
            // method to test
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn("");
                instance.getQuoteAdvice(input, output);
            }

            System.out.println(
                    MessageFormat.format(
                            "{0}Asserting Test at line num # {1}{2}", stars, testCase.testNum,
                            stars));
            assertEquals(
                    subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime().getTime(),
                    output.getNextCyclePaymentAdvice().getAtVisibleOfferDetailsList(
                            0).getCycleStartTime());
            assertEquals(
                    TestUtils.addOneMonth(
                            subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime(),
                            subscriptionResponse.getTimeZone()).getTime(),
                    output.getNextCyclePaymentAdvice().getAtVisibleOfferDetailsList(
                            0).getCycleEndTime());
        };

        TestCase tc;

        tc = new TestCase();
        tc.testNum = (new Exception()).getStackTrace()[0].getLineNumber() + "";
        tc.baseOffer = CI_EXTERNAL_IDS.PLUS_CURRENT;
        pTests.test(tc);
    }

    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_IncludePaymentAdvice_WithFreeWearable_Then_CorrectCycleDates")
    // @formatter:off
    @SuppressWarnings("unchecked")
    @CsvSource(delimiter = '|', value={
                 "|Given | Subscriber has some mainbalance.|"
                +"|When  | Api is called with Paid Annual Services and a Free Monthly Addon.|"
                +"|      | IncludePaymentAdvice = Y|"
                +"|Then  | Advice should show correct cycle dates in payment advice for both services.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_IncludePaymentAdvice_WithFreeWearable_Then_CorrectCycleDates(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String baseOffer = CI_EXTERNAL_IDS.PLUS3ANNUAL;
        String addonOffer = CI_EXTERNAL_IDS.WEARABLE_ANNUAL_2023;
        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", baseOffer, addonOffer);
        input.setIncludePaymentAdvice("Y");
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        emulateAocServicePurchase(instance);
        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(input.getSubscriberExternalId()));

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription(subscriptionResponse));

        MtxResponseMulti multiGrantBalance = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();

        Map<String, BigDecimal> offerAocMap = new HashMap<String, BigDecimal>();
        offerAocMap.put(baseOffer, CommonTestHelper.getOfferPrice(baseOffer));
        offerAocMap.put(addonOffer, CommonTestHelper.getOfferPrice(addonOffer));
        MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                offerAocMap, subscriptionResponse);

        MtxResponse okayResponse = new MtxResponse();
        okayResponse.setResult(1l);
        okayResponse.setResultText("OK");
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(purResponseBase);

        MtxResponseWallet wallet = emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        wallet.getBillingCycle().setCurrentPeriodStartTime(
                subscriptionResponse.getBillingCycle().getCurrentPeriodStartTime());
        wallet.getBillingCycle().setCurrentPeriodEndTime(
                subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime());
        wallet.getBalanceArrayAppender().clear();
        MtxBalanceInfoSimple mainBalanceWallet = CommonTestHelper.loadJsonMessage(
                MtxBalanceInfoSimple.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfoSimple_Mainbalance.json");
        mainBalanceWallet.setAmount(BigDecimal.ZERO);
        mainBalanceWallet.setAvailableAmount(BigDecimal.ZERO);
        wallet.getBalanceArrayAppender().add(mainBalanceWallet);

        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(baseOffer, addonOffer));

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(multiAocBase).doReturn(multiGrantBalance).when(instance).multiRequest(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        System.out.println(subscriptionResponse.toJson());
        // method to test
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    "");
            instance.getQuoteAdvice(input, output);
        }

        printUnitTest(input.toJson());
        printUnitTest(output.toJson());
        printUnitTest(purResponseBase.toJson());

        VisibleOfferDetails vodAddon = null;
        for (VisibleOfferDetails vod : output.getNextCyclePaymentAdvice().getVisibleOfferDetailsList()) {
            if (OFFER_CONSTANTS.OFFER_TYPE_ADDON.equalsIgnoreCase(vod.getOfferType())) {
                vodAddon = vod;
            }
        }
        assertEquals(
                subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime().getTime(),
                vodAddon.getCycleStartTime());
        assertEquals(
                TestUtils.addOneMonth(
                        subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime(),
                        subscriptionResponse.getTimeZone()).getTime(),
                vodAddon.getCycleEndTime());
    }

    @ParameterizedTest(name = "When_IncludePaymentAdvice_Daylight_Savings_Then_CorrectCycleDates")
    @Tags({
        @Tag("VER-626"), @Tag("Timezone")
    })
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given | Subscriber has some mainbalance.|"
                +"|When  | Api is called with with target monthly service.|"
                +"|IncludePaymentAdvice = Y|"
                +"|Timezone will change before end date of next cycle due to daylight savings|"
                +"|Then  | Payment Advice should show correct cycle end date.|"})
    // @formatter:on
    @SuppressWarnings({
        "unchecked"
    })
    public void test_getQuoteAdvice_When_IncludePaymentAdvice_Daylight_Savings_Then_CorrectCycleDates(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        OneParameterTest pTests = (tCase) -> {
            td.printDescription();
            TestCase testCase = (TestCase) tCase;
            String stars = "***************************************";
            System.out.println(
                    MessageFormat.format(
                            "{0}Executing Test {1}{2}", stars, testCase.testNum, stars));

            VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                    "N", testCase.baseOffer);
            input.setIncludePaymentAdvice("Y");
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxResponseWallet wallet = emulateMtxResponseWalletMinimal(
                    instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
            wallet.getBillingCycle().setCurrentPeriodStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            wallet.getBillingCycle().setCurrentPeriodEndTime(
                    TestUtils.getFirstDateTimeOfNextMonth());
            wallet.getBalanceArrayAppender().clear();
            MtxBalanceInfoSimple mainBalanceWallet = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfoSimple.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfoSimple_Mainbalance.json");
            mainBalanceWallet.setAmount(testCase.mainBalance.negate());
            mainBalanceWallet.setAvailableAmount(testCase.mainBalance);
            wallet.getBalanceArrayAppender().add(mainBalanceWallet);
            emulateAocServicePurchase(instance);

            String timezone = "Australia/Melbourne";
            // Daylight savings in first week of October AoP cycle starts mid of September ends mid
            // of October
            long offset = 15;
            MtxTimestamp currentCycleStart = new MtxTimestamp(
                    "2024-08-" + offset + "T00:00:00.000000+10:00");
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.setTimeZone(timezone);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            subscriptionResponse.setTimeZone(timezone);
            BalanceInfo mainBalance = CommonTestHelper.getBalanceInfo(
                    BALANCE_NAMES.MAIN_BALANCE, 101L, 201L, testCase.mainBalance);
            subscriptionResponse.appendWalletBalances(mainBalance);
            subscriptionResponse.getBillingCycle().setCurrentPeriodStartTime(currentCycleStart);
            subscriptionResponse.getBillingCycle().setCurrentPeriodEndTime(
                    TestUtils.addOneMonth(currentCycleStart, timezone));
            subscriptionResponse.getBillingCycle().setDateOffset(offset);

            MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                    testCase.baseOffer, CommonTestHelper.getOfferPrice(testCase.baseOffer),
                    subscriptionResponse);

            MtxResponseMulti multiGrantBalance = CommonTestHelper.getEmptyMtxResponseMulti();
            MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
            MtxResponse okayResponse = new MtxResponse();
            okayResponse.setResult(1l);
            okayResponse.setResultText("OK");
            multiAocBase.getResponseListAppender().add(okayResponse);
            multiAocBase.getResponseListAppender().add(okayResponse);
            multiAocBase.getResponseListAppender().add(purResponseBase);

            emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(testCase.baseOffer));

            VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

            // mocks
            doReturn("").when(instance).getRoute(any());
            doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
            doReturn(multiAocBase).doReturn(multiGrantBalance).when(instance).multiRequest(
                    any(), any(), any());
            emulateMtxResponseSubscription(instance, subscription);
            System.out.println(subscriptionResponse.toJson());
            // method to test
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn("");
                instance.getQuoteAdvice(input, output);
            }

            System.out.println(
                    MessageFormat.format(
                            "{0}Asserting Test at line num # {1}{2}", stars, testCase.testNum,
                            stars));

            String expectedDate = TestUtils.addOneMonth(
                    subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime(),
                    subscriptionResponse.getTimeZone()).getTime();
            String actualEndDate = output.getNextCyclePaymentAdvice().getAtVisibleOfferDetailsList(
                    0).getCycleEndTime();
            String actualStartDate = output.getNextCyclePaymentAdvice().getAtVisibleOfferDetailsList(
                    0).getCycleStartTime();

            String endDateTimezone = actualEndDate.substring(actualEndDate.lastIndexOf("+") + 1);
            String startDateTimezone = actualStartDate.substring(
                    actualStartDate.lastIndexOf("+") + 1);

            assertNotEquals(startDateTimezone, endDateTimezone);
            assertEquals(expectedDate, actualEndDate);

        };

        TestCase tc;

        tc = new TestCase();
        tc.testNum = (new Exception()).getStackTrace()[0].getLineNumber() + "";
        tc.baseOffer = CI_EXTERNAL_IDS.PLUS3VIS23;
        pTests.test(tc);
    }

    @ParameterizedTest(
            name = "When_IncludePaymentAdvice_Daylight_Savings_Savings_Missing_Hour_Then_CorrectCycleDates")
    @Tags({
        @Tag("VER-626"), @Tag("Timezone")
    })
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber's cycletime is between 2-00AM to 3-00AM in Melbourne timezone.|"                        
                +"|When  |Api is called with with target monthly service.|"
                +"|      |IncludePaymentAdvice = Y|"
                +"|      |Timezone will change before end date of next cycle due to daylight savings|"
                +"|Then  |Payment Advice should show correct cycle end date.|"
                +"|Comments  |Normally all cycle times are aligned to 00:00:00. This is a hypothetical test case|"})
    // @formatter:on
    @SuppressWarnings({
        "unchecked"
    })
    public void test_getQuoteAdvice_When_IncludePaymentAdvice_Daylight_Savings_Missing_Hour_Then_CorrectCycleDates(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        OneParameterTest pTests = (tCase) -> {
            td.printDescription();
            TestCase testCase = (TestCase) tCase;
            String stars = "***************************************";
            System.out.println(
                    MessageFormat.format(
                            "{0}Executing Test {1}{2}", stars, testCase.testNum, stars));

            VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                    "N", testCase.baseOffer);
            input.setIncludePaymentAdvice("Y");
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxResponseWallet wallet = emulateMtxResponseWalletMinimal(
                    instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
            wallet.getBillingCycle().setCurrentPeriodStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            wallet.getBillingCycle().setCurrentPeriodEndTime(
                    TestUtils.getFirstDateTimeOfNextMonth());
            wallet.getBalanceArrayAppender().clear();
            MtxBalanceInfoSimple mainBalanceWallet = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfoSimple.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfoSimple_Mainbalance.json");
            mainBalanceWallet.setAmount(testCase.mainBalance.negate());
            mainBalanceWallet.setAvailableAmount(testCase.mainBalance);
            wallet.getBalanceArrayAppender().add(mainBalanceWallet);
            emulateAocServicePurchase(instance);

            String timezone = "Australia/Melbourne";
            // Daylight savings in first week of October AoP cycle starts mid of September ends mid
            // of October
            long offset = 15;
            MtxTimestamp currentCycleStart = new MtxTimestamp(
                    "2024-08-" + offset + "T02:15:45.000000+10:00");
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.setTimeZone(timezone);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            subscriptionResponse.setTimeZone(timezone);
            BalanceInfo mainBalance = CommonTestHelper.getBalanceInfo(
                    BALANCE_NAMES.MAIN_BALANCE, 101L, 201L, testCase.mainBalance);
            subscriptionResponse.appendWalletBalances(mainBalance);
            subscriptionResponse.getBillingCycle().setCurrentPeriodStartTime(currentCycleStart);
            subscriptionResponse.getBillingCycle().setCurrentPeriodEndTime(
                    TestUtils.addOneMonth(currentCycleStart, timezone));
            subscriptionResponse.getBillingCycle().setDateOffset(offset);

            MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                    testCase.baseOffer, CommonTestHelper.getOfferPrice(testCase.baseOffer),
                    subscriptionResponse);

            MtxResponseMulti multiGrantBalance = CommonTestHelper.getEmptyMtxResponseMulti();
            MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
            MtxResponse okayResponse = new MtxResponse();
            okayResponse.setResult(1l);
            okayResponse.setResultText("OK");
            multiAocBase.getResponseListAppender().add(okayResponse);
            multiAocBase.getResponseListAppender().add(okayResponse);
            multiAocBase.getResponseListAppender().add(purResponseBase);

            emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(testCase.baseOffer));

            VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

            // mocks
            doReturn("").when(instance).getRoute(any());
            doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
            doReturn(multiAocBase).doReturn(multiGrantBalance).when(instance).multiRequest(
                    any(), any(), any());
            emulateMtxResponseSubscription(instance, subscription);
            System.out.println(subscriptionResponse.toJson());
            // method to test
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn("");
                instance.getQuoteAdvice(input, output);
            }

            System.out.println(
                    MessageFormat.format(
                            "{0}Asserting Test at line num # {1}{2}", stars, testCase.testNum,
                            stars));

            String expectedDate = TestUtils.addOneMonth(
                    subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime(),
                    subscriptionResponse.getTimeZone()).getTime();
            String actualEndDate = output.getNextCyclePaymentAdvice().getAtVisibleOfferDetailsList(
                    0).getCycleEndTime();
            String actualStartDate = output.getNextCyclePaymentAdvice().getAtVisibleOfferDetailsList(
                    0).getCycleStartTime();

            String endDateTimezone = actualEndDate.substring(actualEndDate.lastIndexOf("+") + 1);
            String startDateTimezone = actualStartDate.substring(
                    actualStartDate.lastIndexOf("+") + 1);

            assertNotEquals(startDateTimezone, endDateTimezone);
            assertEquals(expectedDate, actualEndDate);

        };

        TestCase tc;

        tc = new TestCase();
        tc.testNum = (new Exception()).getStackTrace()[0].getLineNumber() + "";
        tc.baseOffer = CI_EXTERNAL_IDS.PLUS3VIS23;
        pTests.test(tc);
    }

    @SuppressWarnings({
        "unchecked"
    })
    @Tag("VER-549")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_IncludePaymentAdvice_Then_CorrectZeroTaxResponse")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscriber has some mainbalance.|"
                +"|When |Api is called with with zero priced service. IncludePaymentAdvice = Y|"
                +"|Then |Advice should include PaymentAdvice for next service. ZeroTaxResponse should be returned.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_IncludePaymentAdvice_Then_CorrectZeroTaxResponse(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        OneParameterTest pTests = (tCase) -> {
            td.printDescription();
            TestCase testCase = (TestCase) tCase;
            String stars = "***************************************";
            System.out.println(
                    MessageFormat.format(
                            "{0}Executing Test {1}{2}", stars, testCase.testNum, stars));

            VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                    "N", testCase.baseOffer);
            input.setIncludePaymentAdvice("Y");
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxResponseWallet wallet = emulateMtxResponseWalletMinimal(
                    instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
            wallet.getBillingCycle().setCurrentPeriodStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            wallet.getBillingCycle().setCurrentPeriodEndTime(
                    TestUtils.getFirstDateTimeOfNextMonth());
            wallet.getBalanceArrayAppender().clear();
            MtxBalanceInfoSimple mainBalanceWallet = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfoSimple.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfoSimple_Mainbalance.json");
            mainBalanceWallet.setAmount(testCase.mainBalance.negate());
            mainBalanceWallet.setAvailableAmount(testCase.mainBalance);
            wallet.getBalanceArrayAppender().add(mainBalanceWallet);
            emulateAocServicePurchase(instance);
            MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                    testCase.baseOffer, CommonTestHelper.getOfferPrice(testCase.baseOffer));

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            BalanceInfo mainBalance = CommonTestHelper.getBalanceInfo(
                    BALANCE_NAMES.MAIN_BALANCE, 101L, 201L, testCase.mainBalance);
            subscriptionResponse.appendWalletBalances(mainBalance);
            subscriptionResponse.getBillingCycle().setCurrentPeriodStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            subscriptionResponse.getBillingCycle().setCurrentPeriodEndTime(
                    TestUtils.getFirstDateTimeOfNextMonth());
            MtxResponseMulti multiGrantBalance = CommonTestHelper.getEmptyMtxResponseMulti();
            MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
            MtxResponse okayResponse = new MtxResponse();
            okayResponse.setResult(1l);
            okayResponse.setResultText("OK");
            multiAocBase.getResponseListAppender().add(okayResponse);
            multiAocBase.getResponseListAppender().add(okayResponse);
            multiAocBase.getResponseListAppender().add(purResponseBase);

            emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(testCase.baseOffer));

            VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

            // mocks
            doReturn("").when(instance).getRoute(any());
            doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
            doReturn(multiAocBase).doReturn(multiGrantBalance).when(instance).multiRequest(
                    any(), any(), any());
            emulateMtxResponseSubscription(instance, subscription);
            System.out.println(subscriptionResponse.toJson());
            // method to test
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn("");
                instance.getQuoteAdvice(input, output);
            }

            System.out.println(
                    MessageFormat.format(
                            "{0}Asserting Test {1}{2}", stars, testCase.testNum, stars));
            assertNotNull(
                    output.getNextCyclePaymentAdvice().getAtVisibleOfferDetailsList(
                            0).getTaxDetails());
            assertTrue(
                    StringUtils.isNotBlank(
                            output.getNextCyclePaymentAdvice().getAtVisibleOfferDetailsList(
                                    0).getTaxDetails()));
        };

        TestCase tc;

        tc = new TestCase();
        tc.testNum = (new Exception()).getStackTrace()[0].getLineNumber() + "";
        tc.baseOffer = CI_EXTERNAL_IDS.WEARABLE_ANNUAL_2023;
        ;
        tc.mainBalance = BigDecimal.ZERO;
        pTests.test(tc);
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_getQuoteAdvice_When_FuturePromos_Then_CorrectPromoAmounts")
    @Tags({
        @Tag("VER-646"), @Tag("FuturePromo")
    })
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber.|"                        
                +"|When  |Api is called with with a service and future promos.|"
                +"|Then  |Quote Advice should show correct promo amounts. Grant,Redeemable,Transferable, |"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_FuturePromos_Then_CorrectPromoAmounts(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.PLUS3ANNUAL);

        BigDecimal grantAmount = BigDecimal.valueOf(50);
        VisibleFuturePromo fp = new VisibleFuturePromo();
        fp.setGrantOfferCI(CI_EXTERNAL_IDS.GENERIC_GRANT);
        fp.setGrantAmount(grantAmount);
        VisiblePromoExtension pe = new VisiblePromoExtension();
        pe.setPromotionLimit(grantAmount);
        fp.setAttr(pe);
        input.getAdditionalPromoListAppender().add(fp);

        System.out.println(td.getTestMethod() + " : " + input.toJson());

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                        fp.getGrantOfferCI()));

        MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                input.getAtCatalogItemList(0).getDiscountPrice());

        MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponse okayResponse = new MtxResponse();
        okayResponse.setResult(1l);
        okayResponse.setResultText("OK");
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(purResponseBase);
        doReturn(multiAocBase).when(instance).multiRequest(any(), any(), any());

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));

        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        // method to test
        instance.getQuoteAdvice(input, output);

        System.out.println(td.getTestMethod() + " : " + output.toJson());
        assertEquals(
                grantAmount.intValue(), output.getAtCredits(0).getAvailableCredits().intValue());
        assertEquals(
                grantAmount.intValue(),
                output.getAtCredits(0).getAvailableCreditsGrant().intValue());
        assertEquals(
                grantAmount.intValue(), output.getAtCredits(0).getRedeemableCredits().intValue());
        assertEquals(
                grantAmount.intValue(),
                output.getAtCredits(0).getEstimatedTransferableCredits().intValue());
        assertEquals(
                grantAmount.intValue(),
                output.getAtCredits(0).getEstimatedTransferableCredits().intValue());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_getQuoteAdvice_When_FuturePromos_Then_CorrectPromoAttributes")
    @Tags({
        @Tag("VER-646"), @Tag("FuturePromo")
    })
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber.|"                        
                +"|When  |Api is called with with a service and future promos.|"
                +"|Then  |Quote Advice should show correct promo attributes. Cap,ClassCode,applicable ci etc |"})
    // @formatter:on
    public void test_getQuoteAdvice_When_FuturePromos_Then_CorrectPromoAttributes(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.PLUS3ANNUAL);
        BigDecimal grantAmount = BigDecimal.valueOf(50);
        VisibleFuturePromo fp = new VisibleFuturePromo();
        fp.setGrantOfferCI(CI_EXTERNAL_IDS.GENERIC_GRANT);
        fp.setGrantAmount(grantAmount);
        VisiblePromoExtension pe = new VisiblePromoExtension();
        pe.setPromotionLimit(grantAmount);
        fp.setAttr(pe);
        input.getAdditionalPromoListAppender().add(fp);

        System.out.println(td.getTestMethod() + " : " + input.toJson());

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                        fp.getGrantOfferCI()));

        MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                input.getAtCatalogItemList(0).getDiscountPrice());

        MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponse okayResponse = new MtxResponse();
        okayResponse.setResult(1l);
        okayResponse.setResultText("OK");
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(purResponseBase);
        doReturn(multiAocBase).when(instance).multiRequest(any(), any(), any());

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        // method to test
        instance.getQuoteAdvice(input, output);

        System.out.println(td.getTestMethod() + " : " + output.toJson());
        assertEquals(grantAmount.intValue(), output.getAtCredits(0).getCreditCap().intValue());
        assertEquals(CI_EXTERNAL_IDS.PLUS3ANNUAL, output.getAtCredits(0).getApplicableCI());
        assertEquals(TAX_CLASS_CODES.GENRIC, output.getAtCredits(0).getClassCode());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_getQuoteAdvice_When_FuturePromos_Then_CorrectRechargeAmounts")
    @Tags({
        @Tag("VER-646"), @Tag("FuturePromo")
    })
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber.|"                        
                +"|When  |Api is called with with a service and future promos.|"
                +"|Then  |Quote Advice should show correct promo attributes. EstimatedPayableAmount etc |"})
    // @formatter:on
    public void test_getQuoteAdvice_When_FuturePromos_Then_CorrectRechargeAmounts(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.PLUS3ANNUAL);
        BigDecimal grantAmount = BigDecimal.valueOf(50);
        VisibleFuturePromo fp = new VisibleFuturePromo();
        fp.setGrantOfferCI(CI_EXTERNAL_IDS.GENERIC_GRANT);
        fp.setGrantAmount(grantAmount);
        VisiblePromoExtension pe = new VisiblePromoExtension();
        pe.setPromotionLimit(grantAmount);
        fp.setAttr(pe);
        input.getAdditionalPromoListAppender().add(fp);

        System.out.println(td.getTestMethod() + " : " + input.toJson());

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                        fp.getGrantOfferCI()));

        MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                input.getAtCatalogItemList(0).getDiscountPrice());

        MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponse okayResponse = new MtxResponse();
        okayResponse.setResult(1l);
        okayResponse.setResultText("OK");
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(purResponseBase);
        doReturn(multiAocBase).when(instance).multiRequest(any(), any(), any());

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        // method to test
        instance.getQuoteAdvice(input, output);

        System.out.println(td.getTestMethod() + " : " + output.toJson());
        BigDecimal basePayableAmount = input.getAtCatalogItemList(0).getDiscountPrice().subtract(
                grantAmount);
        assertEquals(
                input.getAtCatalogItemList(0).getDiscountPrice().intValue(),
                output.getAtVisibleOfferDetailsList(0).getChargeAmount().intValue());
        assertEquals(
                basePayableAmount.intValue(),
                output.getAtVisibleOfferDetailsList(0).getPayableAmount().intValue());
        assertEquals(basePayableAmount.intValue(), output.getEstimatedPayableAmount().intValue());
        assertEquals(basePayableAmount.intValue(), output.getTotalEstimatedAmount().intValue());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_getQuoteAdvice_When_FuturePromos_Then_ReturnTaxes")
    @Tags({
        @Tag("VER-646"), @Tag("FuturePromo")
    })
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber.|"                        
                +"|When  |Api is called with with a service and future promos.|"
                +"|Then  |Quote Advice should return offer taxes and credit taxes.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_FuturePromos_Then_ReturnTaxes(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", CI_EXTERNAL_IDS.PLUS3ANNUAL);
        BigDecimal grantAmount = BigDecimal.valueOf(50);
        VisibleFuturePromo fp = new VisibleFuturePromo();
        fp.setGrantOfferCI(CI_EXTERNAL_IDS.GENERIC_GRANT);
        fp.setGrantAmount(grantAmount);
        VisiblePromoExtension pe = new VisiblePromoExtension();
        pe.setPromotionLimit(grantAmount);
        fp.setAttr(pe);
        input.getAdditionalPromoListAppender().add(fp);

        System.out.println(td.getTestMethod() + " : " + input.toJson());

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                        fp.getGrantOfferCI()));

        MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                input.getAtCatalogItemList(0).getDiscountPrice());

        MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponse okayResponse = new MtxResponse();
        okayResponse.setResult(1l);
        okayResponse.setResultText("OK");
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(purResponseBase);
        doReturn(multiAocBase).when(instance).multiRequest(any(), any(), any());

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        String taxApiResp = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), any())).thenReturn(
                    taxApiResp);
            // method to test
            instance.getQuoteAdvice(input, output);
        }

        System.out.println(td.getTestMethod() + " : " + output.toJson());
        assertFalse(output.getAtCredits(0).getTaxDetails().isBlank());
        assertFalse(output.getAtVisibleOfferDetailsList(0).getTaxDetails().isBlank());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_getQuoteAdvice_When_TaxError_Then_Error")
    @Tag("Tax")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber.|"                        
                +"|When  |Api is called with with a service. Taxapi returns error.|"
                +"|Then  |Quote Advice should return error.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_TaxError_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", CI_EXTERNAL_IDS.PLUS3VIS23WB);

        System.out.println(td.getTestMethod() + " : " + input.toJson());

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(input.getAtCatalogItemList(0).getCatalogItemExternalId()));

        MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                input.getAtCatalogItemList(0).getDiscountPrice());

        MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponse okayResponse = new MtxResponse();
        okayResponse.setResult(1l);
        okayResponse.setResultText("OK");
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(purResponseBase);
        doReturn(multiAocBase).when(instance).multiRequest(any(), any(), any());

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), any())).thenThrow(
                    new TaxApiException(123L, "xyz"));
            // method to test
            instance.getQuoteAdvice(input, output);
        }

        System.out.println(td.getTestMethod() + " : " + output.toJson());
        assertTrue(output.getResultText().contains("ERROR"));
        assertTrue(output.getResultText().contains("xyz"));
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_getQuoteAdvice_When_NoGeocode_Then_Error")
    @Tag("Tax")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber.Subscriber has no geocode.|"                        
                +"|When  |Api is called with a service and with no geocode.|"
                +"|Then  |Quote Advice should return error.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_NoGeocode_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", CI_EXTERNAL_IDS.PLUS3VIS23WB);

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        ((VisibleSubscriberExtension) subscription.getAttr()).setGeoCode(null);

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(input.getAtCatalogItemList(0).getCatalogItemExternalId()));

        MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                input.getAtCatalogItemList(0).getDiscountPrice());

        MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponse okayResponse = new MtxResponse();
        okayResponse.setResult(1l);
        okayResponse.setResultText("OK");
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(purResponseBase);
        doReturn(multiAocBase).when(instance).multiRequest(any(), any(), any());

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        String taxApiResp = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), any())).thenReturn(
                    taxApiResp);
            // method to test
            instance.getQuoteAdvice(input, output);
        }
        System.out.println(td.getTestMethod() + " : " + input.toJson());
        System.out.println(td.getTestMethod() + " : " + output.toJson());
        assertTrue(output.getResultText().contains("ERROR"));
        assertTrue(output.getResultText().contains("No valid geocode passed for tax calculation"));
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_getQuoteAdvice_When_NoGeocode_Then_Error")
    @Tag("Tax")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber.Subscriber has no geocode.|"                        
                +"|When  |Taxapi error.|"
                +"|Then  |Quote Advice should return error.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_TaxApiError_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", CI_EXTERNAL_IDS.PLUS3VIS23WB);

        System.out.println(td.getTestMethod() + " : " + input.toJson());

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(input.getAtCatalogItemList(0).getCatalogItemExternalId()));

        MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                input.getAtCatalogItemList(0).getDiscountPrice());

        MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponse okayResponse = new MtxResponse();
        okayResponse.setResult(1l);
        okayResponse.setResultText("OK");
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(okayResponse);
        multiAocBase.getResponseListAppender().add(purResponseBase);
        doReturn(multiAocBase).when(instance).multiRequest(any(), any(), any());

        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), any())).thenReturn("xyz");
            // method to test
            instance.getQuoteAdvice(input, output);
        }
        System.out.println(td.getTestMethod() + " : " + output.toJson());
        assertTrue(output.getResultText().contains("Error while calculating service tax"));
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_PurchasedGrant_AocRedeem_Then_PromoResponse")
    @Tag("VER-745")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber.Subscriber has Grant offer for Aoc promo.|"                        
                +"|When  |Request with applicable offer.|"
                +"|Then  |Advice should provide AoC promo.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_PurchasedGrant_AocRedeem_Then_PromoResponse(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        intiateAopQuoteTaxTest();
        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.PLUS25);
        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        Map<String, MtxResponsePricingCatalogItem> ciMap = emulateMtxResponsePricingCatalogItems(
                instance, List.of(CI_EXTERNAL_IDS.PLUS25, CI_EXTERNAL_IDS.CA5_GRANT));

        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();
        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscription.getBalanceArrayAppender().clear();
        MtxBalanceInfo mbiMainbalance = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.MAIN_BALANCE, null, null, null);
        subscription.getBalanceArrayAppender().add(mbiMainbalance);
        BigDecimal grantAmount = BigDecimal.valueOf(2000);
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.CA5_GRANT, null, grantAmount, null);

        MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                input.getAtCatalogItemList(0).getDiscountPrice());

        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponse okayResponse = new MtxResponse();
        multiResponse0.getResponseListAppender().add(okayResponse);
        multiResponse0.getResponseListAppender().add(okayResponse);
        multiResponse0.getResponseListAppender().add(purResponseBase);
        List<MtxResponseMulti> multiRespList = new ArrayList<MtxResponseMulti>();
        multiRespList.add(multiResponse0);
        MtxResponseMulti multiResponse1 = CommonTestHelper.getMtxResponseMulti_For_CreditBalances(
                subscription);
        multiRespList.add(multiResponse1);

        // mocks
        emulate2MtxResponseMultiFromObjects(instance, multiRespList);

        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        emulateMtxResponseSubscription(instance, subscription);

        MtxResponseMulti responseMulti = CommonTestHelper.getEmptyMtxResponseMulti();

        MtxResponseGroup grp = CommonTestHelper.getMtxResponseGroup(
                "CA-" + subscription.getExternalId(), "Account", 2L, "1-0-0-0", "1-0-0-1");
        responseMulti.appendResponseList(grp);
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        VisibleTemplate vt = (VisibleTemplate) ciMap.get(
                CI_EXTERNAL_IDS.CA5_GRANT).getCatalogItemInfo().getTemplateAttr();
        doReturn(BigDecimal.valueOf(-5)).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(vt.getRedeemOffer()), any(), any(MtxSubscriberSearchData.class));

        System.out.println(td.getTestMethod() + " : " + subscription.toJson());

        // method to test
        instance.getQuoteAdvice(input, output);
        System.out.println(output.toJson());
        assertEquals(
                grantAmount.intValue(),
                output.getAtCredits(0).getAvailableCreditsGrant().intValue());
        assertEquals(
                vt.getPromotionLimit().intValue(),
                output.getAtCredits(0).getRedeemableCredits().intValue());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_PurchasedGrantAttr_AocRedeem_Then_OverridePromoValues")
    @Tag("VER-745")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber.Subscriber has Grant offer for Aoc promo. Grant offer has attribute with new promo name|"                        
                +"|When  |Request with applicable offer.|"
                +"|Then  |Advice should provide AoC promo with new promo name.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_PurchasedGrantAttr_AocRedeem_Then_OverridePromoValues(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        intiateAopQuoteTaxTest();
        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.PLUS25);
        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        Map<String, MtxResponsePricingCatalogItem> ciMap = emulateMtxResponsePricingCatalogItems(
                instance, List.of(CI_EXTERNAL_IDS.PLUS25, CI_EXTERNAL_IDS.CA5_GRANT));

        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();
        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscription.getBalanceArrayAppender().clear();
        MtxBalanceInfo mbiMainbalance = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.MAIN_BALANCE, null, null, null);
        subscription.getBalanceArrayAppender().add(mbiMainbalance);
        BigDecimal grantAmount = BigDecimal.valueOf(2000);
        MtxPurchasedOfferInfo poi = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.CA5_GRANT, null, grantAmount, null);
        VisiblePurchasedOfferExtension poe = (VisiblePurchasedOfferExtension) poi.getAttr();
        String newPromoName = "NewCA5Promo";
        poe.setPromotionName(newPromoName);

        MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchase(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                input.getAtCatalogItemList(0).getDiscountPrice());

        MtxResponseMulti multiResponse0 = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponse okayResponse = new MtxResponse();
        multiResponse0.getResponseListAppender().add(okayResponse);
        multiResponse0.getResponseListAppender().add(okayResponse);
        multiResponse0.getResponseListAppender().add(purResponseBase);
        List<MtxResponseMulti> multiRespList = new ArrayList<MtxResponseMulti>();
        multiRespList.add(multiResponse0);
        MtxResponseMulti multiResponse1 = CommonTestHelper.getMtxResponseMulti_For_CreditBalances(
                subscription);
        multiRespList.add(multiResponse1);

        // mocks
        emulate2MtxResponseMultiFromObjects(instance, multiRespList);

        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        emulateMtxResponseSubscription(instance, subscription);

        MtxResponseMulti responseMulti = CommonTestHelper.getEmptyMtxResponseMulti();

        MtxResponseGroup grp = CommonTestHelper.getMtxResponseGroup(
                "CA-" + subscription.getExternalId(), "Account", 2L, "1-0-0-0", "1-0-0-1");
        responseMulti.appendResponseList(grp);
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        VisibleTemplate vt = (VisibleTemplate) ciMap.get(
                CI_EXTERNAL_IDS.CA5_GRANT).getCatalogItemInfo().getTemplateAttr();
        doReturn(BigDecimal.valueOf(-5)).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(vt.getRedeemOffer()), any(), any(MtxSubscriberSearchData.class));

        System.out.println(td.getTestMethod() + " : " + subscription.toJson());

        // method to test
        instance.getQuoteAdvice(input, output);
        System.out.println(output.toJson());
        assertEquals(newPromoName, output.getAtCredits(0).getPromotionName());
    }

    @SuppressWarnings({
        "unchecked"
    })
    @ParameterizedTest(name = "test_getQuoteAdvice_Given_HasPayer_Then_TaxWithPayerGeoDocde")
    @Tag("Tax")
    @Tag("VER-773")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber gets paid by payer for recurring services.|"                        
                +"|When  |QuoteAdvice is called.|"
                +"|Then  |QuoteAdvice should call taxapi with payers geocode.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_Given_HasPayer_Then_TaxWithPayerGeoDocde(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String payerGeoCode = "ELBISIVNOZIREV";
        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", CI_EXTERNAL_IDS.PRO25);
        input.setSubscriberExternalId("12345");
        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        String payerExternalID = "67890";

        MtxObjectId caGroupId = new MtxObjectId("1-2-3-4");
        MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());
        benSub.getParentGroupIdArrayAppender().add(caGroupId);
        MtxResponseSubscription paySub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                payerExternalID);
        paySub.getParentGroupIdArrayAppender().add(caGroupId);
        VisibleSubscriberExtension attr = (VisibleSubscriberExtension) paySub.getAttr();
        attr.setGeoCode(payerGeoCode);
        doReturn(benSub).doReturn(paySub).when(api).subscriptionQuery(any());

        MtxResponseMulti responseGroupMulti = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseGroup respGrp = CommonTestHelper.getMtxResponseGroupCA(
                benSub.getExternalId(), "CAGroup",
                List.of(benSub.getObjectId().toString(), "1-2-3-4", "6-7-8-9"),
                List.of(
                        String.format(
                                GROUP_CONSTANTS.CA_LINK_FORMAT, benSub.getExternalId(),
                                payerExternalID)));
        responseGroupMulti.appendResponseList(respGrp);
        doReturn(responseGroupMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        MtxResponseMulti aocResponseMulti = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseMulti multiGrantBalance = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase aocResp = CommonTestHelper.getMtxResponsePurchase(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                input.getAtCatalogItemList(0).getDiscountPrice());
        aocResponseMulti.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        aocResponseMulti.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        aocResponseMulti.getResponseListAppender().add(aocResp);
        doReturn(aocResponseMulti).doReturn(multiGrantBalance).when(instance).multiRequest(
                any(), any(), any());

        emulateMtxResponsePricingCatalogItem(
                instance, input.getAtCatalogItemList(0).getCatalogItemExternalId());

        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        String taxApiResp = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId());

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            // method to test
            instance.getQuoteAdvice(input, output);
        }
        System.out.println(output.toJson());
        argumentCaptor.getAllValues().forEach(taxReq -> {
            System.out.println(taxReq);
        });
        ServiceTaxRequest req = CommonTestHelper.getJsonFromString(
                ServiceTaxRequest.class, argumentCaptor.getAllValues().get(0));
        assertEquals(payerGeoCode, req.getGeocode());
        assertTrue(req.getMsgID().contains("Payer:" + payerExternalID));
    }

    @SuppressWarnings({
        "unchecked"
    })
    @ParameterizedTest(
            name = "test_getQuoteAdvice_Given_HasPayer_When_IgnorePayer_Then_TaxWithBeneficiaryGeoDocde")
    @Tag("Tax")
    @Tag("VER-862")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber gets paid by payer for recurring services.|"
                +"|When  |QuoteAdvice is called to ignore payer.|"
                +"|Then  |QuoteAdvice should call taxapi with beneficiaries geocode.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_Given_HasPayer_When_IgnorePayer_Then_TaxWithBeneficiaryGeoDocde(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String payerGeoCode = "ELBISIVNOZIREV";
        String benGeoCode = "BXLYAZHBXLYAZH";
        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", CI_EXTERNAL_IDS.PRO25);
        input.setSubscriberExternalId("12345");
        input.setIgnorePayer(GENERIC_CONSTANTS.YES);
        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        String payerExternalID = "67890";

        MtxObjectId caGroupId = new MtxObjectId("1-2-3-4");
        MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());
        benSub.getParentGroupIdArrayAppender().add(caGroupId);
        VisibleSubscriberExtension benAttr = (VisibleSubscriberExtension) benSub.getAttr();
        benAttr.setGeoCode(benGeoCode);
        // benSub.setGeoCode(benGeoCode);

        MtxResponseSubscription paySub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                payerExternalID);
        paySub.getParentGroupIdArrayAppender().add(caGroupId);
        VisibleSubscriberExtension payAttr = (VisibleSubscriberExtension) paySub.getAttr();
        payAttr.setGeoCode(payerGeoCode);
        doReturn(benSub).doReturn(paySub).when(api).subscriptionQuery(any());

        MtxResponseMulti responseGroupMulti = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseGroup respGrp = CommonTestHelper.getMtxResponseGroupCA(
                benSub.getExternalId(), "CAGroup",
                List.of(benSub.getObjectId().toString(), "1-2-3-4", "6-7-8-9"),
                List.of(
                        String.format(
                                GROUP_CONSTANTS.CA_LINK_FORMAT, benSub.getExternalId(),
                                payerExternalID)));
        responseGroupMulti.appendResponseList(respGrp);
        doReturn(responseGroupMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        MtxResponseMulti aocResponseMulti = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseMulti multiGrantBalance = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase aocResp = CommonTestHelper.getMtxResponsePurchase(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                input.getAtCatalogItemList(0).getDiscountPrice());
        aocResponseMulti.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        aocResponseMulti.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        aocResponseMulti.getResponseListAppender().add(aocResp);
        doReturn(aocResponseMulti).doReturn(multiGrantBalance).when(instance).multiRequest(
                any(), any(), any());

        emulateMtxResponsePricingCatalogItem(
                instance, input.getAtCatalogItemList(0).getCatalogItemExternalId());

        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        String taxApiResp = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId());

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            // method to test
            instance.getQuoteAdvice(input, output);
        }
        System.out.println(output.toJson());
        argumentCaptor.getAllValues().forEach(taxReq -> {
            System.out.println(taxReq);
        });
        ServiceTaxRequest req = CommonTestHelper.getJsonFromString(
                ServiceTaxRequest.class, argumentCaptor.getAllValues().get(0));
        assertEquals(benGeoCode, req.getGeocode());
        assertFalse(req.getMsgID().contains("Payer:" + payerExternalID));
    }

    @SuppressWarnings({
        "unchecked"
    })
    @ParameterizedTest(
            name = "test_getQuoteAdvice_Given_HasPayer_Then_NextCycleTaxWithPayerGeoDocde")
    @Tag("Tax")
    @Tag("VER-773")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber gets paid by payer for recurring services. NextCyclePayment is already made for existing offers.|"                        
                +"|When  |QuoteAdvice is called.|"
                +"|Then  |QuoteAdvice should call taxapi with payers geocode.|"})
    // @formatter:on
    public void test_getQuoteAdvice_Given_HasPayer_Then_NextCycleTaxWithPayerGeoDocde(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String payerGeoCode = "ELBISIVNOZIREV";
        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023);
        input.setSubscriberExternalId("12345");
        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        String payerExternalID = "67890";

        MtxObjectId caGroupId = new MtxObjectId("1-2-3-4");
        MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId(), List.of(CI_EXTERNAL_IDS.PRO25));
        benSub.getParentGroupIdArrayAppender().add(caGroupId);
        MtxResponseSubscription paySub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                payerExternalID);
        paySub.getParentGroupIdArrayAppender().add(caGroupId);
        VisibleSubscriberExtension attr = (VisibleSubscriberExtension) paySub.getAttr();
        attr.setGeoCode(payerGeoCode);
        doReturn(benSub).doReturn(paySub).when(api).subscriptionQuery(any());

        MtxResponseMulti responseGroupMulti = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseGroup respGrp = CommonTestHelper.getMtxResponseGroupCA(
                benSub.getExternalId(), "CAGroup",
                List.of(benSub.getObjectId().toString(), "1-2-3-4", "6-7-8-9"),
                List.of(
                        String.format(
                                GROUP_CONSTANTS.CA_LINK_FORMAT, benSub.getExternalId(),
                                payerExternalID)));
        responseGroupMulti.appendResponseList(respGrp);
        doReturn(responseGroupMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        MtxResponseMulti aocResponseMulti = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseMulti multiGrantBalance = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase aocResp = CommonTestHelper.getMtxResponsePurchase(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                input.getAtCatalogItemList(0).getDiscountPrice());
        aocResponseMulti.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        aocResponseMulti.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        aocResponseMulti.getResponseListAppender().add(aocResp);
        doReturn(aocResponseMulti).doReturn(multiGrantBalance).when(instance).multiRequest(
                any(), any(), any());

        emulateMtxResponsePricingCatalogItem(
                instance, input.getAtCatalogItemList(0).getCatalogItemExternalId());
        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        String taxApiResp = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId());

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            // method to test
            instance.getQuoteAdvice(input, output);
        }
        System.out.println(output.toJson());
        argumentCaptor.getAllValues().forEach(taxReq -> {
            System.out.println(taxReq);
        });
        ServiceTaxRequest req = CommonTestHelper.getJsonFromString(
                ServiceTaxRequest.class, argumentCaptor.getAllValues().get(0));
        assertEquals(payerGeoCode, req.getGeocode());
        assertTrue(req.getMsgID().contains("Payer:" + payerExternalID));
    }

    @SuppressWarnings({
        "unchecked"
    })
    @ParameterizedTest(
            name = "test_getQuoteAdvice_Given_HasPayer_Has_Promos_Then_TaxWithPayerGeoDocde")
    @Tag("Tax")
    @Tag("VER-773")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscriber has promos.|"
                +"|     |Subscriber gets paid by payer for recurring services.|"
                +"|When |Api is called.|"
                +"|Then |AoP should call taxapi with payers geocode, for promos.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_Given_HasPayer_Has_Promos_Then_TaxWithPayerGeoDocde(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String payerGeoCode = "ELBISIVNOZIREV";
        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", CI_EXTERNAL_IDS.PRO25);
        input.setSubscriberExternalId("12345");
        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        String payerExternalID = "67890";
        String promoGrantOffer = CI_EXTERNAL_IDS.GRANT_GOODWILL;

        MtxObjectId caGroupId = new MtxObjectId("1-2-3-4");
        MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());
        benSub.getParentGroupIdArrayAppender().add(caGroupId);
        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.GOODWILL_GRANT, null, null, BigDecimal.valueOf(40));
        benSub.getBalanceArrayAppender().add(mbiGoodGrant);

        MtxResponseSubscription paySub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                payerExternalID);
        paySub.getParentGroupIdArrayAppender().add(caGroupId);
        VisibleSubscriberExtension attr = (VisibleSubscriberExtension) paySub.getAttr();
        attr.setGeoCode(payerGeoCode);
        doReturn(benSub).doReturn(paySub).when(api).subscriptionQuery(any());

        MtxResponseMulti responseGroupMulti = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseGroup respGrp = CommonTestHelper.getMtxResponseGroupCA(
                benSub.getExternalId(), "CAGroup",
                List.of(benSub.getObjectId().toString(), "1-2-3-4", "6-7-8-9"),
                List.of(
                        String.format(
                                GROUP_CONSTANTS.CA_LINK_FORMAT, benSub.getExternalId(),
                                payerExternalID)));
        responseGroupMulti.appendResponseList(respGrp);
        doReturn(responseGroupMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        MtxResponseMulti aocResponseMulti = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseMulti multiGrantBalance = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase aocResp = CommonTestHelper.getMtxResponsePurchase(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                input.getAtCatalogItemList(0).getDiscountPrice());
        aocResponseMulti.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        aocResponseMulti.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        aocResponseMulti.getResponseListAppender().add(aocResp);
        MtxResponsePricingBalance grantPricing = CommonTestHelper.getMtxResponsePricingBalance(
                CommonTestHelper.getGrantBalanceName(promoGrantOffer));
        multiGrantBalance.getResponseListAppender().add(grantPricing);
        doReturn(aocResponseMulti).doReturn(multiGrantBalance).when(instance).multiRequest(
                any(), any(), any());

        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItems(
                instance,
                List.of(input.getAtCatalogItemList(0).getCatalogItemExternalId(), promoGrantOffer));

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        String taxApiResp = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId());

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            // method to test
            instance.getQuoteAdvice(input, output);
        }
        System.out.println(output.toJson());
        argumentCaptor.getAllValues().forEach(taxReq -> {
            System.out.println(taxReq);
        });
        ServiceTaxRequest promoTaxReq = CommonTestHelper.getJsonFromString(
                ServiceTaxRequest.class, argumentCaptor.getAllValues().get(1));
        assertEquals(payerGeoCode, promoTaxReq.getGeocode());
        assertTrue(promoTaxReq.getMsgID().contains("Payer:" + payerExternalID));
    }

    @SuppressWarnings({
        "unchecked"
    })
    @ParameterizedTest(
            name = "test_getQuoteAdvice_Given_HasPayer_Has_Promos__When_IgnorePayer_Then_TaxWithBeneficiaryGeoDocde")
    @Tag("Tax")
    @Tag("VER-862")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber gets paid by payer for recurring services.|"
                +"|When  |QuoteAdvice is called to ignore payer.|"
                +"|Then  |QuoteAdvice should call taxapi with beneficiaries geocode for promos.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_Given_HasPayer_Has_Promos__When_IgnorePayer_Then_TaxWithBeneficiaryGeoDocde(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String payerGeoCode = "ELBISIVNOZIREV";
        String benGeoCode = "BXLYAZHBXLYAZH";
        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", CI_EXTERNAL_IDS.PRO25);
        input.setSubscriberExternalId("12345");
        input.setIgnorePayer("Y");
        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        String payerExternalID = "67890";
        String promoGrantOffer = CI_EXTERNAL_IDS.GRANT_GOODWILL;

        MtxObjectId caGroupId = new MtxObjectId("1-2-3-4");
        MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());
        benSub.getParentGroupIdArrayAppender().add(caGroupId);
        VisibleSubscriberExtension benAttr = (VisibleSubscriberExtension) benSub.getAttr();
        benAttr.setGeoCode(benGeoCode);

        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.GOODWILL_GRANT, null, null, BigDecimal.valueOf(40));
        benSub.getBalanceArrayAppender().add(mbiGoodGrant);

        MtxResponseSubscription paySub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                payerExternalID);
        paySub.getParentGroupIdArrayAppender().add(caGroupId);
        VisibleSubscriberExtension payAttr = (VisibleSubscriberExtension) paySub.getAttr();
        payAttr.setGeoCode(payerGeoCode);
        doReturn(benSub).doReturn(paySub).when(api).subscriptionQuery(any());

        MtxResponseMulti responseGroupMulti = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseGroup respGrp = CommonTestHelper.getMtxResponseGroupCA(
                benSub.getExternalId(), "CAGroup",
                List.of(benSub.getObjectId().toString(), "1-2-3-4", "6-7-8-9"),
                List.of(
                        String.format(
                                GROUP_CONSTANTS.CA_LINK_FORMAT, benSub.getExternalId(),
                                payerExternalID)));
        responseGroupMulti.appendResponseList(respGrp);
        doReturn(responseGroupMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        MtxResponseMulti aocResponseMulti = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseMulti multiGrantBalance = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase aocResp = CommonTestHelper.getMtxResponsePurchase(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                input.getAtCatalogItemList(0).getDiscountPrice());
        aocResponseMulti.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        aocResponseMulti.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        aocResponseMulti.getResponseListAppender().add(aocResp);
        MtxResponsePricingBalance grantPricing = CommonTestHelper.getMtxResponsePricingBalance(
                CommonTestHelper.getGrantBalanceName(promoGrantOffer));
        multiGrantBalance.getResponseListAppender().add(grantPricing);
        doReturn(aocResponseMulti).doReturn(multiGrantBalance).when(instance).multiRequest(
                any(), any(), any());

        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItems(
                instance,
                List.of(input.getAtCatalogItemList(0).getCatalogItemExternalId(), promoGrantOffer));

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        String taxApiResp = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId());

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            // method to test
            instance.getQuoteAdvice(input, output);
        }
        System.out.println(output.toJson());
        argumentCaptor.getAllValues().forEach(taxReq -> {
            System.out.println(taxReq);
        });
        ServiceTaxRequest promoTaxReq = CommonTestHelper.getJsonFromString(
                ServiceTaxRequest.class, argumentCaptor.getAllValues().get(1));
        assertEquals(benGeoCode, promoTaxReq.getGeocode());
        assertFalse(promoTaxReq.getMsgID().contains("Payer:" + payerExternalID));
    }

    @SuppressWarnings({
        "unchecked"
    })
    @ParameterizedTest(
            name = "test_getQuoteAdvice_Given_SingleTermOffer_When_Request_Aop_Then_No_Aop")
    @Tag("Tax")
    @Tag("VER-884")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber requests quote for single tem offer like PLUS6VIS25WB.|"
                +"|When  |QuoteAdvice is called to include payment advice.|"
                +"|Then  |No payment advice as there would be no next term for PLUS6VIS25WB.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_Given_SingleTermOffer_When_Request_Aop_Then_No_Aop(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "N", CI_EXTERNAL_IDS.PLUS6MONTH25);
        input.setSubscriberExternalId("12345");
        input.setIncludePaymentAdvice("Y");
        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(input.getSubscriberExternalId()));

        MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription(
                subscriptionResponse);

        doReturn(benSub).when(api).subscriptionQuery(any());

        MtxResponseMulti responseGroupMulti = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(responseGroupMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        MtxResponseMulti aocResponseMulti = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase aocResp = CommonTestHelper.getMtxResponsePurchase(
                input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                input.getAtCatalogItemList(0).getDiscountPrice(), subscriptionResponse);
        aocResponseMulti.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        aocResponseMulti.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        aocResponseMulti.getResponseListAppender().add(aocResp);
        doReturn(aocResponseMulti).when(instance).multiRequest(any(), any(), any());

        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItems(
                instance, List.of(input.getAtCatalogItemList(0).getCatalogItemExternalId()));

        // method to test
        instance.getQuoteAdvice(input, output);

        printUnitTest(input.toJson());
        printUnitTest(output.toJson());
        assertNull(output.getNextCyclePaymentAdvice());
        assertTrue(output.getResultText().contains("NextCyclePaymentAdvice can not be created"));
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getQuoteAdvice_Given_MultipleOffers_When_Request_Aop_Then_No_SingleTermOffer_In_Aop")
    @Tag("Tax")
    @Tag("VER-884")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber requests quote for single tem offer like BASE6VISIBLE25 along with recurring offer like Wearable.|"
                +"|When  |QuoteAdvice is called to include payment advice.|"
                +"|Then  |Payment advice should not have single term offer like BASE6VISIBLE25.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_Given_MultipleOffers_When_Request_Aop_Then_No_SingleTermOffer_In_Aop(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String singleTermOffer = CI_EXTERNAL_IDS.PLUS6MONTH25;
        String recurringOffer = CI_EXTERNAL_IDS.INSURANCE;
        VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                "Y", singleTermOffer, recurringOffer);
        input.setSubscriberExternalId("12345");
        input.setIncludePaymentAdvice("Y");
        VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(input.getSubscriberExternalId()));

        MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription(
                subscriptionResponse);

        doReturn(benSub).when(api).subscriptionQuery(any());

        MtxResponseMulti responseGroupMulti = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(responseGroupMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        MtxResponseMulti aocResponseMulti = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePurchase aocResp = CommonTestHelper.getMtxResponsePurchase(
                Map.of(
                        input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                        input.getAtCatalogItemList(0).getDiscountPrice(),
                        input.getAtCatalogItemList(1).getCatalogItemExternalId(),
                        input.getAtCatalogItemList(1).getDiscountPrice()),
                subscriptionResponse);
        aocResponseMulti.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        aocResponseMulti.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        aocResponseMulti.getResponseListAppender().add(aocResp);
        doReturn(aocResponseMulti).when(instance).multiRequest(any(), any(), any());

        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItems(
                instance,
                List.of(
                        input.getAtCatalogItemList(0).getCatalogItemExternalId(),
                        input.getAtCatalogItemList(1).getCatalogItemExternalId()));

        String taxApiResp = CommonTestHelper.getTaxApiResp(
                input.getAtCatalogItemList(0).getCatalogItemExternalId());

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), any())).thenReturn(
                    taxApiResp);
            // method to test
            instance.getQuoteAdvice(input, output);
        }
        printUnitTest(input.toJson());
        printUnitTest(output.toJson());

        assertNotNull(output.getNextCyclePaymentAdvice());
        assertEquals(
                input.getCatalogItemList().size() - 1,
                output.getNextCyclePaymentAdvice().getVisibleOfferDetailsList().size());
        assertEquals(
                recurringOffer, output.getNextCyclePaymentAdvice().getAtVisibleOfferDetailsList(
                        0).getCatalogItemExternalId());
    }

    /******************************************************
     * Bulk Test
     ***********************************************/
    @ParameterizedTest(
            name = "test_getQuoteAdvice_When_PromotionsPresent_Then_AdviceShouldBeCorrect")
    @Tag("Bulk Test")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscriber is enrolled in offers.|"
                +"|When |QuoteAdvice is called.|"
                +"|Then |QuoteAdviceResponse should have correct promotion values. Check correct mainbalance and payable values.|"})
    // @formatter:on    
    public void test_getQuoteAdvice_When_PromotionsPresent_Then_AdviceShouldBeCorrect(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        @SuppressWarnings("unchecked")
        OneParameterTest pTests = (tCase) -> {
            td.printDescription();
            TestCase testCase = (TestCase) tCase;
            String stars = "***************************************";
            System.out.println(
                    MessageFormat.format(
                            "{0}Executing Test {1}{2}", stars, testCase.testNum, stars));

            VisibleRequestQuoteAdviceService input = CommonTestHelper.getVisibleRequestQuoteAdviceService(
                    "N", testCase.baseOffer);
            AppPropertyProvider.getInstance().setProperty(
                    CREDIT_CONSTANTS.AOC_GRANT_OFFERS, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

            emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);

            MtxResponseWallet wallet = emulateMtxResponseWalletMinimal(
                    instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
            wallet.getBillingCycle().setCurrentPeriodStartTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            wallet.getBillingCycle().setCurrentPeriodEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth().plusMilli(
                            DATE_TIME_CONSTANTS.MILLISECONDS_IN_A_DAY * 30));
            wallet.getBalanceArrayAppender().clear();
            MtxBalanceInfoSimple mainBalanceWallet = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfoSimple.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfoSimple_Mainbalance.json");
            mainBalanceWallet.setAmount(testCase.mainBalance.negate());
            mainBalanceWallet.setAvailableAmount(testCase.mainBalance);
            wallet.getBalanceArrayAppender().add(mainBalanceWallet);
            emulateAocServicePurchase(instance);

            MtxResponsePurchase purResponseBase = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase_VisibleUnlimited.json");

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
            subscription.getBalanceArrayAppender().clear();
            MtxBalanceInfo biMainBalance = CommonTestHelper.getMtxBalanceInfo(
                    BALANCE_NAMES.MAIN_BALANCE, null, null, testCase.mainBalance);
            subscription.getBalanceArrayAppender().add(biMainBalance);

            CommonTestHelper.getMtxPurchasedOfferInfo(subscription, testCase.baseOffer);

            MtxResponseMulti multiGrantBalance = CommonTestHelper.getEmptyMtxResponseMulti();
            MtxResponseMulti multiAocBase = CommonTestHelper.getEmptyMtxResponseMulti();
            MtxResponse okayResponse = new MtxResponse();
            okayResponse.setResult(1l);
            okayResponse.setResultText("OK");
            multiAocBase.getResponseListAppender().add(okayResponse);
            multiAocBase.getResponseListAppender().add(okayResponse);
            purResponseBase.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getAtBalanceImpactList(0).getAtBalanceImpactOfferList(
                            0).getAtBalanceImpactUpdateList(0).setAmount(testCase.aocAmountBase);
            multiAocBase.getResponseListAppender().add(purResponseBase);

            for (TestCasePromo promo : testCase.promoList) {
                MtxResponsePricingCatalogItem ciGrantOffer = emulateMtxResponsePricingCatalogItem(
                        instance, promo.grantOffer);
                VisibleTemplate vtGrant = (VisibleTemplate) ciGrantOffer.getCatalogItemInfo().getTemplateAttr();
                vtGrant.setIncompatiblePromotions("");
                promo.redeemOffer = vtGrant.getRedeemOffer();

                if (promo.priority == -1) {
                    promo.priority = vtGrant.getPromotionPriority();
                }

                if (promo.limit == -1 && vtGrant.getPromotionLimit() != null) {
                    promo.limit = vtGrant.getPromotionLimit().intValue();
                }

                if (CREDIT_CONSTANTS.CALCULATION_METHOD_AOC.equalsIgnoreCase(
                        vtGrant.getDiscountCalculationMethod())) {
                    BigDecimal grantAmount = promo.grant.signum() > 0
                            ? promo.grant : BigDecimal.ZERO;
                    doReturn(grantAmount.negate()).when(
                            instance).getChargeableAmountForPurchaseOffer(
                                    any(),
                                    argThat(
                                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                                    vtGrant.getRedeemOffer())),
                                    any(), any());
                } else {
                    CommonTestHelper.getMtxPurchasedOfferInfo(
                            subscription, promo.grantOffer, BigDecimal.valueOf(50), promo.grant,
                            promo.consumable);
                    MtxResponsePricingBalance grantPricing = CommonTestHelper.getMtxResponsePricingBalance(
                            CommonTestHelper.getGrantBalanceName(promo.grantOffer));
                    multiGrantBalance.getResponseListAppender().add(grantPricing);
                }

                if (promo.consumable.signum() > 0) {
                    MtxBalanceInfo biConsume = CommonTestHelper.getMtxBalanceInfoForPromoConsumable(
                            promo.grantOffer, promo.consumable);
                    subscription.getBalanceArrayAppender().add(biConsume);
                }
            }

            VisibleResponseQuoteAdviceService output = new VisibleResponseQuoteAdviceService();

            MtxResponseMulti responseMulti = new MtxResponseMulti();
            responseMulti.setResult(RESULT_CODES.MTX_SUCCESS);
            responseMulti.setResultText("OK");
            MtxResponseGroup grp = new MtxResponseGroup();
            grp.setExternalId("PP-" + subscription.getExternalId());
            grp.setTier("Account");
            grp.setSubscriberMemberCount(4L);
            responseMulti.appendResponseList(grp);
            doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());
            System.out.println(multiGrantBalance.toJson());
            // mocks
            doReturn("").when(instance).getRoute(any());
            doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
            doReturn(multiAocBase).doReturn(multiGrantBalance).when(instance).multiRequest(
                    any(), any(), any());
            emulateMtxResponseSubscription(instance, subscription);
            System.out.println(subscription.toJson());
            // method to test
            instance.getQuoteAdvice(input, output);
            System.out.println(output.toJson());

            System.out.println(
                    MessageFormat.format(
                            "{0}Asserting Test {1}{2}", stars, testCase.testNum, stars));

            // Sort in descending order. Higher priority number is earlier in queue.
            Collections.sort(
                    testCase.promoList,
                    (TestCasePromo p1, TestCasePromo p2) -> p2.priority.intValue()
                            - p1.priority.intValue());

            BigDecimal totalConsumablePromo = BigDecimal.ZERO;
            BigDecimal totalAvailable = BigDecimal.ZERO;
            for (TestCasePromo promo : testCase.promoList) {
                System.out.println("Asserting promo: " + promo.redeemOffer);
                totalConsumablePromo = promo.consumable;
                totalAvailable = totalAvailable.add(promo.consumable).add(promo.grant);
                System.out.println();
                VisibleCredits outputPromo = output.getCredits().stream().filter(
                        vc -> vc.getCreditRedeemableOfferCI().equalsIgnoreCase(
                                promo.redeemOffer)).findFirst().get();
                assertEquals(
                        promo.grant.intValue(), outputPromo.getAvailableCreditsGrant().intValue());
                assertEquals(
                        promo.consumable.intValue(),
                        outputPromo.getAvailableCreditsConsumable().intValue());
                assertEquals(
                        promo.grant.add(promo.consumable).intValue(),
                        outputPromo.getAvailableCreditsGrant().add(
                                outputPromo.getAvailableCreditsConsumable()).intValue());
            }

            BigDecimal totalRedeemable = BigDecimal.ZERO;
            BigDecimal totalTransferable = BigDecimal.ZERO;
            BigDecimal actualTotalPayables = output.getEstimatedPayableAmount().add(
                    output.getConsumableMainBalanceAmount());
            BigDecimal expectedTotalPayables = testCase.aocAmountBase;

            if (output.getCredits() != null) {
                for (VisibleCredits promo : output.getCredits()) {
                    totalRedeemable = totalRedeemable.add(promo.getRedeemableCredits());
                    totalTransferable = totalTransferable.add(
                            promo.getEstimatedTransferableCredits());
                    actualTotalPayables = actualTotalPayables.add(promo.getRedeemableCredits());
                }
            }
            if (totalConsumablePromo.compareTo(
                    CommonTestHelper.getOfferPrice(testCase.baseOffer)) >= 0) {

            }
            if (totalConsumablePromo.compareTo(testCase.aocAmountBase) >= 0) {
                assertEquals(
                        testCase.aocAmountBase.doubleValue(), totalRedeemable.doubleValue(), 0.001,
                        "Redeemables should be only consumables. Min. Charge ignore.");
                assertEquals(
                        0, totalTransferable.doubleValue(), 0.001, "Grants should not be useable.");
            } else if (totalConsumablePromo.compareTo(
                    testCase.aocAmountBase.subtract(testCase.minimumCharge)) >= 0) {
                assertTrue(
                        totalRedeemable.compareTo(
                                testCase.aocAmountBase.subtract(testCase.minimumCharge)) >= 0,
                        "Redeemables should be only consumables. Min. Charge ignore.");
                assertEquals(
                        0, totalTransferable.doubleValue(), 0.001, "Grants should not be useable.");
            } else if (totalConsumablePromo.compareTo(
                    CommonTestHelper.getOfferPrice(testCase.baseOffer)) >= 0) {
                assertEquals(
                        testCase.aocAmountBase.subtract(testCase.minimumCharge).intValue(),
                        totalRedeemable.intValue(),
                        "Redeemables should be subject to minimum charge.");
            } else {
                assertTrue(
                        totalRedeemable.compareTo(totalAvailable) <= 0,
                        "Redeemables should not be more than available.");
            }

            assertEquals(
                    expectedTotalPayables.doubleValue(), actualTotalPayables.doubleValue(), 1.0);
            assertEquals(
                    testCase.mainBalance.doubleValue(),
                    output.getAvailableMainBalanceAmount().doubleValue(), 1.0);

            BigDecimal cashAmount = expectedTotalPayables.subtract(totalRedeemable);
            if (cashAmount.compareTo(output.getAvailableMainBalanceAmount()) > 0) {
                assertEquals(
                        output.getAvailableMainBalanceAmount().doubleValue(),
                        output.getConsumableMainBalanceAmount().doubleValue(), 0.001,
                        "All mainbalance should be used.");
            } else {
                assertEquals(
                        cashAmount.doubleValue(),
                        output.getConsumableMainBalanceAmount().doubleValue(), 0.001,
                        "All cash should be paid using mainbalanced.");
            }

        };

        TestCase tc;

        tc = new TestCase();
        tc.testNum = (new Exception()).getStackTrace()[0].getLineNumber() + "";
        tc.baseOffer = CI_EXTERNAL_IDS.UNLIMITED;
        tc.aocAmountBase = BigDecimal.valueOf(12);
        tc.minimumCharge = BigDecimal.valueOf(5);
        tc.mainBalance = BigDecimal.ZERO;
        tc.promoList.add(
                getNewTestCasePromo(
                        CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.valueOf(20),
                        BigDecimal.valueOf(7)));
        tc.promoList.add(
                getNewTestCasePromo(
                        CI_EXTERNAL_IDS.PARTY_PAY_GRANT, BigDecimal.valueOf(5), BigDecimal.ZERO));
        tc.promoList.add(
                getNewTestCasePromo(
                        CI_EXTERNAL_IDS.FIRST25_GRANT, BigDecimal.valueOf(20),
                        BigDecimal.valueOf(5)));
        pTests.test(tc);

        tc = new TestCase();
        tc.testNum = (new Exception()).getStackTrace()[0].getLineNumber() + "";
        tc.baseOffer = CI_EXTERNAL_IDS.UNLIMITED;
        tc.aocAmountBase = BigDecimal.valueOf(34);
        tc.minimumCharge = BigDecimal.valueOf(5);
        tc.mainBalance = BigDecimal.valueOf(15);
        tc.promoList.add(
                getNewTestCasePromo(
                        CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.valueOf(40), BigDecimal.ZERO));
        tc.promoList.add(
                getNewTestCasePromo(
                        CI_EXTERNAL_IDS.PARTY_PAY_GRANT, BigDecimal.valueOf(15), BigDecimal.ZERO));
        tc.promoList.add(
                getNewTestCasePromo(
                        CI_EXTERNAL_IDS.FIRST25_GRANT, BigDecimal.valueOf(5),
                        BigDecimal.valueOf(15)));
        pTests.test(tc);

        tc = new TestCase();
        tc.testNum = (new Exception()).getStackTrace()[0].getLineNumber() + "";
        tc.baseOffer = CI_EXTERNAL_IDS.UNLIMITED;
        tc.aocAmountBase = BigDecimal.valueOf(34);
        tc.minimumCharge = BigDecimal.valueOf(5);
        tc.mainBalance = BigDecimal.ZERO;
        tc.promoList.add(
                getNewTestCasePromo(
                        CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.valueOf(10), BigDecimal.ZERO));
        tc.promoList.add(
                getNewTestCasePromo(
                        CI_EXTERNAL_IDS.PARTY_PAY_GRANT, BigDecimal.valueOf(5), BigDecimal.ZERO));
        tc.promoList.add(
                getNewTestCasePromo(
                        CI_EXTERNAL_IDS.FIRST25_GRANT, BigDecimal.valueOf(50),
                        BigDecimal.valueOf(10)));
        pTests.test(tc);

        tc = new TestCase();
        tc.testNum = (new Exception()).getStackTrace()[0].getLineNumber() + "";
        tc.baseOffer = CI_EXTERNAL_IDS.UNLIMITED;
        tc.aocAmountBase = BigDecimal.valueOf(12.59);
        tc.minimumCharge = BigDecimal.valueOf(5);
        tc.mainBalance = BigDecimal.ZERO;
        tc.promoList.add(
                getNewTestCasePromo(
                        CI_EXTERNAL_IDS.PARTY_PAY_GRANT, BigDecimal.ZERO, BigDecimal.valueOf(10)));
        tc.promoList.add(
                getNewTestCasePromo(
                        CI_EXTERNAL_IDS.FIRST25_GRANT, BigDecimal.valueOf(20), BigDecimal.ZERO));
        pTests.test(tc);
    }

    @Test
    @Tag("VER-261")
    @Disabled
    public void test_getQuoteAdvice_When_MultiMonth_And_Monthly_Without_BillCycle_Then_CorrectCycleDates(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscriber is NOT enrolled in Multimonth and Visible_Wearables.",
            "Subscriber has NO bill cycle in wallet."
        };
        td.when = new String[] {
            "QuoteAdvice is called for MoultiMonth service  and Visible_Wearables."
        };
        td.then = new String[] {
            "Response should show multimonth dates for multimonth service.",
            "Response should show monthly dates for Visible_Wearables.",
            "Top level dates should match with dates as per advice of charge.",
            "Response should show monthly dates for at the top level if blling cycle does not exist at wallet.",
        };
    }

    @Test
    @Tag("VER-261")
    @Disabled
    public void test_getQuoteAdvice_When_MultiMonth_And_Monthly_With_BillCycle_Then_CorrectCycleDates(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscriber is NOT enrolled in Multimonth and Visible_Wearables.",
            "Subscriber HAS bill cycle in wallet."
        };
        td.when = new String[] {
            "QuoteAdvice is called for MoultiMonth service  and Visible_Wearables."
        };
        td.then = new String[] {
            "Response should show multimonth dates for multimonth service.",
            "Response should show monthly dates for Visible_Wearables.",
            "Response should show dates as per billing cycle at the top.",
        };
    }

    @Test
    @Tag("VER-261")
    @Disabled
    public void test_getQuoteAdvice_When_MultiMonthOnly_With_BillCycle_Then_CorrectCycleDates(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscriber is NOT enrolled in Multimonth.", "Subscriber HAS bill cycle in wallet."
        };
        td.when = new String[] {
            "QuoteAdvice is called for MoultiMonth service  and Visible_Wearables."
        };
        td.then = new String[] {
            "Response should show multimonth dates for multimonth service.",
            "Response should show dates as per billing cycle at the top.",
        };
    }

    /******************************************************
     * Private Methods
     *************************************/
    private void intiateQuoteAdviceTaxTest()
            throws IOException, IntegrationServiceException, VisibleUnitTestException {
        MtxResponseMulti aoc = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.QUOTE_ADVICE + "MtxResponseMultiAoc.json");
        doReturn(aoc).when(instance).multiRequest(any(), any(), any());
        intiateAopQuoteTaxTest();

    }

    private void intiateAopQuoteTaxTest()
            throws IOException, IntegrationServiceException, VisibleUnitTestException {

        emulateAocServicePurchase(instance);

        emulateMtxResponseWalletMinimal(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));

        MtxResponsePurchase aocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase.json");
        aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactList().forEach(bi -> {
                    // Set all amounts to zero
                    bi.setImpactAmount(BigDecimal.ZERO);
                    bi.getBalanceImpactOfferList().forEach(bioi -> {
                        bioi.getBalanceImpactUpdateList().forEach(biui -> {
                            biui.setAmount(BigDecimal.ZERO);
                        });
                    });
                });

        for (MtxBalanceImpactInfo bi : aocResp.getAtPurchaseInfoArray(
                0).getAtBalanceImpactGroupList(0).getBalanceImpactList()) {
            // Set only one amount to 40
            bi.setImpactAmount(new BigDecimal(40.0));
            break;
        }

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        CommonTestHelper.getMtxPurchasedOfferInfo(subscription, CI_EXTERNAL_IDS.UNLIMITED);
        subscription.getBalanceArrayAppender().clear();

        // mocks
        Map<String, String> goodwillattr = new HashMap<String, String>();
        goodwillattr.put("good_type", "purchase_service");
        doReturn(goodwillattr).when(instance).getOfferAttributes(
                any(), any(), eq("Visible_Redeem_Goodwill_Credits"));
        Map<String, String> groupattr = new HashMap<String, String>();
        groupattr.put("good_type", "purchase_service");
        doReturn(groupattr).when(instance).getOfferAttributes(
                any(), any(), eq("Visible_Redeem_Group_Discounts"));

        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(BigDecimal.ZERO).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(CI_EXTERNAL_IDS.PARTY_PAY_REDEEM), any(),
                any(MtxSubscriberSearchData.class));
        doReturn(aocResp).when(instance).doSubscriberPurchaseOfferAOC(
                any(), eq("Visible_Unlimited"), any(), any());
    }

    private void printUnitTest(Object msg) {
        System.out.println(testInfo.getDisplayName() + ":" + msg);
    }

    private TestCasePromo getNewTestCasePromo(String grantOffer,
                                              BigDecimal grant,
                                              BigDecimal consumable) {
        TestCasePromo tcp = new TestCasePromo();
        tcp.grantOffer = grantOffer;
        tcp.grant = grant;
        tcp.consumable = consumable;
        return tcp;
    }

    private TestCasePromo getNewTestCasePromoPercentage(String grantOffer,
                                                        BigDecimal grantPercentage,
                                                        BigDecimal consumable) {
        TestCasePromo tcp = new TestCasePromo();
        tcp.grantOffer = grantOffer;
        tcp.grantPercentage = grantPercentage;
        tcp.consumable = consumable;
        return tcp;
    }

    private class TestCasePromo {

        String grantOffer;
        String redeemOffer;
        String applicableCi;
        public BigDecimal grant = BigDecimal.ZERO;
        @SuppressWarnings("unused")
        public BigDecimal grantPercentage = BigDecimal.ZERO;
        public BigDecimal consumable = BigDecimal.ZERO;
        public Long priority = -1L;
        public int limit = -1;
    }

    private class TestCase {

        public String testNum;
        public final List<TestCasePromo> promoList = new ArrayList<TestCasePromo>();
        public final Map<String, Object> expectedResultMap = new HashMap<String, Object>();
        public BigDecimal minimumCharge = BigDecimal.valueOf(-1);
        String baseOffer;
        public BigDecimal aocAmountBase = BigDecimal.ZERO;
        public BigDecimal mainBalance = BigDecimal.ZERO;
    }

}
