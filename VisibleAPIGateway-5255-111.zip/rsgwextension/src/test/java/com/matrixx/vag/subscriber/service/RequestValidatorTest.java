package com.matrixx.vag.subscriber.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;

import com.matrixx.datacontainer.DataContainer;
import com.matrixx.datacontainer.mdc.VisibleCatalogItem;
import com.matrixx.datacontainer.mdc.VisibleChangeOfferInfo;
import com.matrixx.datacontainer.mdc.VisibleDeltaPromo;
import com.matrixx.datacontainer.mdc.VisibleMultiRequest;
import com.matrixx.datacontainer.mdc.VisibleMultiRequestPurchaseService;
import com.matrixx.datacontainer.mdc.VisiblePurchaseFraudInfo;
import com.matrixx.datacontainer.mdc.VisibleRequestChangeService;
import com.matrixx.datacontainer.mdc.VisibleRequestPurchaseService;
import com.matrixx.datacontainer.mdc.VisibleRequestRefundService;
import com.matrixx.platform.JsonObject;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.EXCEPTION_MESSAGES;
import com.matrixx.vag.common.Constants.LOG_MESSAGES;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestConstants.TAX_CLASS_CODES;
import com.matrixx.vag.exception.InvalidRequestException;
import com.matrixx.vag.tax.model.ServiceTaxResponse;
import com.matrixx.vag.util.MDCTest;

public class RequestValidatorTest extends MDCTest {

    private RequestValidator instance;

    private String purchaseServiceDir = "src/test/resources/data/purchaseservice/";
    private String subscriberServiceDir = "src/test/resources/data/subscriberService/";
    private TestInfo testInfo;

    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        instance = new RequestValidator();
        this.testInfo = testInfo;
    }

    @Test
    public void test_validateRefundRequest_Valid() throws Exception {
        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestRefundService requestRefundService = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);
        assertDoesNotThrow(() -> {
            instance.validateRefundRequestV3("requestRefundService", requestRefundService);
        });
    }

    @Test
    public void test_validateRefundRequest_SubscriberExternalIdMissing() throws Exception {
        String benExternalId = null;
        String ciExternalId = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestRefundService requestRefundService = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);
        try {
            instance.validateRefundRequestV3("requestRefundService", requestRefundService);
            fail("Expected InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.toString().contains("SubscriberExternalId"));
        }

    }

    @Test
    public void test_validateRefundRequest_RecurringEventIdsMissing() throws Exception {
        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestRefundService requestRefundService = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);
        requestRefundService.getAtEventGroupList(0).setRecurringEventId(null);
        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRefundRequestV3("requestRefundService", requestRefundService));
        System.out.println(exception.getMessage());
        assertTrue(exception.getMessage().startsWith("Invalid recurring event Id"));
    }

    @Test
    public void test_validateRefundRequest_RecurringEventIdsEmpty() throws Exception {
        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestRefundService requestRefundService = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);
        requestRefundService.getAtEventGroupList(0).setRecurringEventId("  ");
        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRefundRequestV3("requestRefundService", requestRefundService));
        System.out.println(exception.getMessage());
        assertTrue(exception.getMessage().startsWith("Invalid recurring event Id"));
    }

    @Test
    public void test_validateRefundRequest_PaymentAuthEventIdsMissing() throws Exception {
        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestRefundService requestRefundService = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);
        requestRefundService.getAtEventGroupList(
                0).getPaymentAuthorizationEventIdsAppender().clear();

        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRefundRequestV3("requestRefundService", requestRefundService));
        System.out.println(exception.getMessage());
        assertEquals(
                "Payment Authorization Event Id should be present with Recurring Event Id.",
                exception.getMessage());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_validateRefundRequest_PaymentAuthEventIdsEmpty() throws Exception {
        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestRefundService requestRefundService = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);
        requestRefundService.getAtEventGroupList(
                0).getPaymentAuthorizationEventIdsAppender().clear();
        requestRefundService.getAtEventGroupList(0).getPaymentAuthorizationEventIdsAppender().add(
                "  ");

        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRefundRequestV3("requestRefundService", requestRefundService));
        System.out.println(exception.getMessage());
        assertTrue(
                exception.getMessage().startsWith("Invalid payment authorization event event Id"));
    }

    @Test
    public void test_validateRefundRequest_RefundServiceOrderInfoMissing() throws Exception {
        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestRefundService requestRefundService = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);

        requestRefundService.setRefundServiceOrderInfo((VisibleRequestRefundService) null);
        try {
            instance.validateRefundRequestV3("requestRefundService", requestRefundService);
            fail("Expected InvalidRequestException");
        } catch (InvalidRequestException ex) {
            assertTrue(ex.toString().contains("RefundServiceOrderInfo"));
        }
    }

    @Test
    public void test_validateRefundRequest_RefundServiceOrderInfo_ReturnOrderIdMissing()
            throws Exception {
        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestRefundService requestRefundService = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);

        requestRefundService.getRefundServiceOrderInfo().setReturnOrderId(null);

        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRefundRequestV3("requestRefundService", requestRefundService));
        System.out.println(exception.getMessage());
        assertEquals(
                "Missing mandatory parameter: RefundServiceOrderInfo.ReturnOrderId",
                exception.getMessage());
    }

    @ParameterizedTest(
            name = "test_validateRefundRequest_When_MultipleRecurEvents_For_Gift_Then_Error")
    @Tag("VER-689")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Request has more than one recurring events.|"
                +"|When  |Validation called to validate request for gift service refund.|"
                +"|Then  |Too Many Parameters Error|"})
    // @formatter:on
    public void test_validateRefundRequest_When_MultipleRecurEvents_For_Gift_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.PRO25;
        VisibleRequestRefundService request = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "3", 2);
        printUnitTest(request.toJson());
        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRefundRequestV3(request.getSubscriberExternalId(), request));
        exception.printStackTrace();
        assertEquals(LOG_MESSAGES.GIFT_REFUND_SINGLE_RECUR_EVENT, exception.getMessage());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_validateRefundRequest_When_MultiplePayAuthEvents_For_Gift_Then_Error")
    @Tag("VER-689")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Request has more than one payment authorization events.|"
                +"|When  |Validation called to validate request for gift service refund.|"
                +"|Then  |Too Many Parameters Error|"})
    // @formatter:on
    public void test_validateRefundRequest_When_MultiplePayAuthEvents_For_Gift_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.PRO25;
        VisibleRequestRefundService request = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "3");
        request.getAtEventGroupList(0).getPaymentAuthorizationEventIdsAppender().add(
                "I4A0:1:52:517146");

        printUnitTest(request.toJson());
        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.validateRefundRequestV3(request.getSubscriberExternalId(), request));
        exception.printStackTrace();
        assertEquals(LOG_MESSAGES.GIFT_REFUND_SINGLE_PAYAUTH_EVENT, exception.getMessage());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_requestPurchaseService_MissingFields() throws IOException {

        ArrayList<String> testFields = new ArrayList<String>(
                Arrays.asList(
                        "SubscriberExternalId", //
                        "OrderId", //
                        "ServiceSku", //
                        "ServiceOfferExternalId", //
                        "ServiceDiscountPrice", //
                        "TransactionType", //
                        "FraudHomeAddress", //
                        "FraudShippingAddress"));

        String msgInput = new String(
                Files.readAllBytes(
                        Paths.get(
                                purchaseServiceDir
                                        + "VisibleRequestPurchaseService_ValidSimpleRequest.json")));
        for (String removeField : testFields) {
            Exception respException = null;
            try {
                VisibleRequestPurchaseService input = transform_Json_To_VisibleRequestPurchaseService(
                        remove_From_VisibleRequestPurchaseService(msgInput, removeField));
                instance.validateRequest("", input);
                System.out.println("XXX");
            } catch (Exception e) {
                respException = e;
            }
            assertEquals(InvalidRequestException.class, respException.getClass());
        }

    }

    @Test
    public void test_requestPurchaseService_PurchaseFraudInfoMissing() throws Exception {
        VisibleRequestPurchaseService requestPurchaseService = CommonTestHelper.loadJsonMessage(
                VisibleRequestPurchaseService.class,
                purchaseServiceDir + "VisibleRequestPurchaseService_ValidSimpleRequest.json");

        requestPurchaseService.setPurchaseFraudInfo((VisibleRequestPurchaseService) null);

        try {
            instance.validateRequest("requestRefundService", requestPurchaseService);
        } catch (Exception ex) {
            fail("Expected Valid Request");
        }
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_requestPurchaseService_InvalidValues() throws IOException {
        String msgInput = new String(
                Files.readAllBytes(
                        Paths.get(
                                purchaseServiceDir
                                        + "VisibleRequestPurchaseService_ValidSimpleRequest.json")));

        Exception respException = null;
        try {
            VisibleRequestPurchaseService input = transform_Json_To_VisibleRequestPurchaseService(
                    replace_From_VisibleRequestPurchaseService(msgInput, "ServiceDiscountPrice"));

            instance.validateRequest("", input);
        } catch (Exception e) {
            respException = e;
        }
        assertEquals(InvalidRequestException.class, respException.getClass());
    }

    @Test
    public void test_requestMulti_Valid() throws Exception {

        VisibleMultiRequest requestMulti = CommonTestHelper.loadJsonMessage(
                VisibleMultiRequest.class, subscriberServiceDir + "Multi_Valid.json");

        try {
            instance.validateRequest("requestMulti", requestMulti);
        } catch (Exception ex) {
            fail("Expecting Valid Request");
        }
    }

    @Test
    public void test_requestMulti_ToManyMultiRequest() throws Exception {

        VisibleMultiRequest requestMulti = CommonTestHelper.loadJsonMessage(
                VisibleMultiRequest.class, subscriberServiceDir + "To_Many_Multi_Requests.json");

        try {
            instance.validateRequest("requestMulti", requestMulti);
            fail("Expecting InvalidRequestException");
        } catch (Exception ex) {
            assertTrue(ex.toString().contains("exceeds the max allowed number of requests"));
        }
    }

    @Test
    public void test_requestMultiPurchaseService_Valid() throws Exception {
        List<String> svcList = List.of(CI_EXTERNAL_IDS.UNLIMITED);
        VisibleMultiRequestPurchaseService purchaseServiceMulti = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", svcList);

        try {
            instance.validateRequest("purchaseServiceMulti", purchaseServiceMulti);
        } catch (Exception ex) {
            fail("Expected Valid Request");
        }
    }

    @Test
    public void test_requestMultiPurchaseService_SubscriberExternalIdMissing() throws Exception {
        List<String> svcList = List.of(CI_EXTERNAL_IDS.UNLIMITED);
        VisibleMultiRequestPurchaseService purchaseServiceMulti = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", svcList);

        purchaseServiceMulti.setSubscriberExternalId(null);

        try {
            instance.validateRequest("purchaseServiceMulti", purchaseServiceMulti);
            fail("Expected InvalidRequestException");
        } catch (Exception ex) {
            assertTrue(ex.toString().contains("SubscriberExternalId"));
        }
    }

    @Test
    public void test_requestMultiPurchaseService_PurchaseOrderInfo_OrderIdMissing()
            throws Exception {
        List<String> svcList = List.of(CI_EXTERNAL_IDS.UNLIMITED);
        VisibleMultiRequestPurchaseService purchaseServiceMulti = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", svcList);

        purchaseServiceMulti.getPurchaseInfo().get(0).getPurchaseServiceOrderInfo().setOrderId(
                null);

        try {
            instance.validateRequest("purchaseServiceMulti", purchaseServiceMulti);
            fail("Expected InvalidRequestException");
        } catch (Exception ex) {
            assertTrue(ex.toString().contains("PurchaseServiceOrderInfo.OrderId"));
        }
    }

    @Test
    public void test_requestMultiPurchaseService_PurchaseServiceInfo_ServiceExternalIdMissing()
            throws Exception {
        List<String> svcList = List.of(CI_EXTERNAL_IDS.UNLIMITED);
        VisibleMultiRequestPurchaseService purchaseServiceMulti = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", svcList);

        purchaseServiceMulti.getPurchaseInfo().get(
                0).getPurchaseServiceInfo().setServiceOfferExternalId(null);

        try {
            instance.validateRequest("purchaseServiceMulti", purchaseServiceMulti);
            fail("Expected InvalidRequestException");
        } catch (Exception ex) {
            assertTrue(ex.toString().contains("PurchaseServiceInfo.ServiceOfferExternalId"));
        }
    }

    @Test
    public void test_requestMultiPurchaseService_PurchaseServiceInfo_ServiceDiscountPriceMissing()
            throws Exception {
        List<String> svcList = List.of(CI_EXTERNAL_IDS.UNLIMITED);
        VisibleMultiRequestPurchaseService purchaseServiceMulti = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", svcList);

        purchaseServiceMulti.getPurchaseInfo().get(
                0).getPurchaseServiceInfo().setServiceDiscountPrice(null);

        try {
            instance.validateRequest("purchaseServiceMulti", purchaseServiceMulti);
            fail("Expected InvalidRequestException");
        } catch (Exception ex) {
            assertTrue(ex.toString().contains("PurchaseServiceInfo.ServiceDiscountPrice"));
        }
    }

    @Test
    public void test_requestMultiPurchaseService_PurchaseServiceInfo_ServiceDiscountPriceInvalid()
            throws Exception {
        List<String> svcList = List.of(CI_EXTERNAL_IDS.UNLIMITED);
        VisibleMultiRequestPurchaseService purchaseServiceMulti = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", svcList);

        purchaseServiceMulti.getPurchaseInfo().get(
                0).getPurchaseServiceInfo().setServiceDiscountPrice("test");

        try {
            instance.validateRequest("purchaseServiceMulti", purchaseServiceMulti);
            fail("Expected InvalidRequestException");
        } catch (Exception ex) {
            assertTrue(ex.toString().contains("PurchaseServiceInfo.ServiceDiscountPrice"));
        }
    }

    @Test
    public void test_requestMultiPurchaseService_PurchaseServiceInfo_ServiceSkuMissing()
            throws Exception {
        List<String> svcList = List.of(CI_EXTERNAL_IDS.UNLIMITED);
        VisibleMultiRequestPurchaseService purchaseServiceMulti = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", svcList);

        purchaseServiceMulti.getPurchaseInfo().get(0).getPurchaseServiceInfo().setServiceSku(null);

        try {
            instance.validateRequest("purchaseServiceMulti", purchaseServiceMulti);
            fail("Expected InvalidRequestException");
        } catch (Exception ex) {
            assertTrue(ex.toString().contains("PurchaseServiceInfo.ServiceSku"));
        }
    }

    @Test
    public void test_requestMultiPurchaseService_When_ServiceTax_Present_But_PlanId_Missing_Then_Exception()
            throws Exception {
        List<String> svcList = List.of(CI_EXTERNAL_IDS.UNLIMITED);
        VisibleMultiRequestPurchaseService purchaseServiceMulti = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", svcList);
        String taxString = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.UNLIMITED);
        ServiceTaxResponse serviceTaxResp = CommonUtils.getObjectMapper().readValue(
                taxString, ServiceTaxResponse.class);
        serviceTaxResp.setPlanID("");
        purchaseServiceMulti.getPurchaseInfo().forEach(vpi -> {
            vpi.getPurchaseServiceInfo().setServiceTaxDetails(serviceTaxResp.toJson());
        });

        try {
            instance.validateRequest("purchaseServiceMulti", purchaseServiceMulti);
            fail("Expected InvalidRequestException");
        } catch (Exception ex) {
            ex.printStackTrace();
            assertTrue(ex.toString().contains("PurchaseServiceInfo.ServiceTaxDetails.PlanID"));
        }
    }

    @Test
    public void test_requestMultiPurchaseService_When_ServiceTax_Present_But_ClassCode_Missing_Then_Exception()
            throws Exception {
        List<String> svcList = List.of(CI_EXTERNAL_IDS.UNLIMITED);
        VisibleMultiRequestPurchaseService purchaseServiceMulti = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", svcList);
        String taxString = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.UNLIMITED);
        ServiceTaxResponse serviceTaxResp = CommonUtils.getObjectMapper().readValue(
                taxString, ServiceTaxResponse.class);
        serviceTaxResp.setClassCode("");
        purchaseServiceMulti.getPurchaseInfo().forEach(vpi -> {
            vpi.getPurchaseServiceInfo().setServiceTaxDetails(serviceTaxResp.toJson());
        });

        try {
            instance.validateRequest("purchaseServiceMulti", purchaseServiceMulti);
            fail("Expected InvalidRequestException");
        } catch (Exception ex) {
            ex.printStackTrace();
            assertTrue(ex.toString().contains("PurchaseServiceInfo.ServiceTaxDetails.ClassCode"));
        }
    }

    @Test
    public void test_requestMultiPurchaseService_When_ServiceTax_Is_Blank_Then_NoException()
            throws Exception {
        List<String> svcList = List.of(CI_EXTERNAL_IDS.UNLIMITED);
        VisibleMultiRequestPurchaseService purchaseServiceMulti = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", svcList);
        purchaseServiceMulti.getPurchaseInfo().forEach(vpi -> {
            vpi.getPurchaseServiceInfo().setServiceTaxDetails("");
        });

        String message = "";
        try {
            instance.validateRequest("purchaseServiceMulti", purchaseServiceMulti);
            message = "SUCCESS";
        } catch (Exception ex) {
            message = "FAILURE";
        }

        assertEquals("SUCCESS", message);
    }

    @Test
    public void test_requestMultiPurchaseService_When_ServiceTax_Is_Null_Then_NoException()
            throws Exception {
        List<String> svcList = List.of(CI_EXTERNAL_IDS.UNLIMITED);
        VisibleMultiRequestPurchaseService purchaseServiceMulti = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", svcList);
        purchaseServiceMulti.getAtPurchaseInfo(0).getPurchaseServiceInfo().setServiceTaxDetails("");
        System.out.println(purchaseServiceMulti.toJson());
        String message = "";
        try {
            instance.validateRequest("purchaseServiceMulti", purchaseServiceMulti);
            message = "SUCCESS";
        } catch (Exception ex) {
            message = "FAILURE";
        }

        assertEquals("SUCCESS", message);
    }

    @Test
    public void test_requestMultiPurchaseService_PurchaseFraudInfoMissing() throws Exception {
        List<String> svcList = List.of(CI_EXTERNAL_IDS.UNLIMITED);
        VisibleMultiRequestPurchaseService purchaseServiceMulti = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", svcList);

        purchaseServiceMulti.getPurchaseInfo().get(0).setPurchaseFraudInfo(
                (VisiblePurchaseFraudInfo) null);

        try {
            instance.validateRequest("purchaseServiceMulti", purchaseServiceMulti);
        } catch (Exception ex) {
            fail("Expected Valid Request");
        }
    }

    @Tags({
        @Tag("VER-480"), @Tag("MTXVER2TMA-4555")
    })
    @Test
    public void test_validateRequest_ChangeAdvice_When_DeltaCredits_NoLimit_Then_Exception(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service.", "Referral Credits available"
        };
        td.when = new String[] {
            "Api is called for annual upgrade.", "No promo limit passed in input request."
        };
        td.then = new String[] {
            "Exception."
        };
        td.printDescription();

        VisibleRequestChangeService requestUp = new VisibleRequestChangeService();
        VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
        requestUp.setSubscriptionExternalId("1234");
        requestUp.setChangeOfferInfo(coi);
        VisibleCatalogItem newCi = new VisibleCatalogItem();
        coi.setNewCatalogItem(newCi);
        newCi.setCatalogItemExternalId((String) CI_EXTERNAL_IDS.PLUS3ANNUAL);
        newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3ANNUAL));
        newCi.setGrossPrice(newCi.getDiscountPrice().add(BigDecimal.TEN));

        VisibleDeltaPromo csp = new VisibleDeltaPromo();
        csp.setClassCode(TAX_CLASS_CODES.REF20);
        requestUp.appendDeltaPromotionList(csp);

        Exception exception = assertThrows(
                InvalidRequestException.class, () -> instance.validateRequest("", requestUp));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertEquals(EXCEPTION_MESSAGES.DELTA_PROMO_NO_LIMIT, exception.getMessage());
    }

    private String remove_From_VisibleRequestPurchaseService(String messageText,
                                                             String feildToRemove) {

        JsonObject jsonInput = new JsonObject();
        jsonInput.parse(messageText);
        switch (feildToRemove) {
            case "SubscriberExternalId":
                jsonInput.remove(feildToRemove);
                break;

            case "OrderId":
            case "PaymentGatewayId":
                ((JsonObject) jsonInput.get("PurchaseServiceOrderInfo")).remove(feildToRemove);
                break;

            case "ServiceSku":
            case "ServiceOfferExternalId":
            case "ServiceTaxDetails":
            case "ServiceDiscountPrice":
                ((JsonObject) jsonInput.get("PurchaseServiceInfo")).remove(feildToRemove);
                break;

            case "TransactionType":
            case "FraudHomeAddress":
            case "FraudShippingAddress":

                ((JsonObject) jsonInput.get("PurchaseFraudInfo")).remove(feildToRemove);
                break;

            default:
                break;
        }

        return jsonInput.toString();
    }

    private String replace_From_VisibleRequestPurchaseService(String messageText,
                                                              String replaceValue) {
        // Auto-generated method stub
        String replaceString = "replaceString";
        JsonObject jsonInput = new JsonObject();
        JsonObject jsonPurchase = new JsonObject();
        jsonInput.parse(messageText);
        /*
         * // if (replaceValue.equals("ServiceGrossPrice") ||
         * replaceValue.equals("ServiceDiscountPrice") || replaceValue.equals("ServiceTotalTax")) {
         */
        jsonPurchase = ((JsonObject) jsonInput.get("PurchaseServiceInfo"));
        jsonPurchase.attribute(replaceValue, replaceString);

        return jsonInput.toString();

    }

    private VisibleRequestPurchaseService transform_Json_To_VisibleRequestPurchaseService(String messageText) {
        try {

            DataContainer dc = new DataContainer(dcf);

            JsonObject jsonInput = new JsonObject();
            jsonInput.parse(messageText);
            dc.readFrom(jsonInput);

            return new VisibleRequestPurchaseService(dc);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private void printUnitTest(Object msg) {
        System.out.println(testInfo.getDisplayName() + ":" + msg);
    }
}
