package com.matrixx.vag.payment.service;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import com.matrixx.datacontainer.BaseContainer;
import com.matrixx.datacontainer.MtxDate;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.ManualPayRequest;
import com.matrixx.datacontainer.mdc.ManualPayResponse;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferData;
import com.matrixx.datacontainer.mdc.MtxRequest;
import com.matrixx.datacontainer.mdc.MtxRequestMulti;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberModify;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberModifyOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberPurchaseOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberRecharge;
import com.matrixx.datacontainer.mdc.MtxResponseDevice;
import com.matrixx.datacontainer.mdc.MtxResponseMulti;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.MtxResponseWallet;
import com.matrixx.datacontainer.mdc.VisibleBraintreeChargeMethodExtension;
import com.matrixx.datacontainer.mdc.VisibleCredits;
import com.matrixx.datacontainer.mdc.VisibleCreditsManualPay;
import com.matrixx.datacontainer.mdc.VisibleDeviceExtension;
import com.matrixx.datacontainer.mdc.VisibleOfferDetails;
import com.matrixx.datacontainer.mdc.VisiblePayNow;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleRechargeExtension;
import com.matrixx.datacontainer.mdc.VisibleResponsePaymentAdviceService;
import com.matrixx.datacontainer.mdc.VisibleServiceDetails;
import com.matrixx.datacontainer.mdc.VisibleSubscriberExtension;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.CREDIT_CONSTANTS;
import com.matrixx.vag.common.Constants.PAYMENT_CONSTANTS;
import com.matrixx.vag.common.OneParameterTest;
import com.matrixx.vag.common.TestConstants;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestConstants.DATA_DIR;
import com.matrixx.vag.exception.IntegrationServiceException;
import com.matrixx.vag.exception.ManualPayException;
import com.matrixx.vag.exception.VisibleUnitTestException;
import com.matrixx.vag.util.MDCTest;

public class ManualPayServiceTest extends MDCTest {

    @Spy
    @InjectMocks
    private ManualPayService instance = new ManualPayService();

    @Mock
    private SubscriberManagementApi api;
    private TestInfo testInfo;

    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        instance = new ManualPayService();
        MockitoAnnotations.openMocks(this);
        doReturn("").when(instance).getRoute(any());
        this.testInfo = testInfo;
    }

    @Test
    public void test_manualPay_BT_AMOUNT_PRECISIONEq2_AmountPrecisionBraintree() throws Exception {
        ManualPayService manualPayTest = instance;

        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class, DATA_DIR.MANUAL_PAY + "ManualPayRequest_Valid.json");

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MultiResponse.json");

        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");
        ManualPayResponse output = new ManualPayResponse();
        MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
        // mocks
        doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
        MtxResponseSubscription subscriber = emulateMtxResponseSubscription(
                api,
                CommonTestHelper.getMtxResponseSubscription(List.of(CI_EXTERNAL_IDS.UNLIMITED)));
        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.UNLIMITED);
        doReturn(subscriber).when(instance).querySubscriptionData(any(), any());
        doReturn("").when(manualPayTest).getRoute(any());

        doReturn(wallet).when(manualPayTest).querySubscriptionWallet(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiManualPay).when(manualPayTest).multiRequest(
                any(), any(), argumentCaptor.capture());

        // method to test
        manualPayTest.manualPay(input, output, null);

        ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();
        int amountScale = ((MtxRequestSubscriberRecharge) reqList.get(0)).getAmount().scale();
        assertEquals(2, amountScale);
    }

    @Test
    public void test_manualPay_BraintreeCalled_VisibleRecurringOverrideEqTrue() throws Exception {

        OneParameterTest pTests = (vro) -> {
            ManualPayService manualPayTest = instance;

            ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                    ManualPayRequest.class, DATA_DIR.MANUAL_PAY + "ManualPayRequest_Valid.json");

            MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                    MtxResponseMulti.class,
                    DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MultiResponse.json");

            MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                    MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");
            ManualPayResponse output = new ManualPayResponse();
            MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
            // mocks
            doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
            MtxResponseSubscription subscriber = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(
                            List.of(CI_EXTERNAL_IDS.UNLIMITED)));
            emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.UNLIMITED);
            doReturn(subscriber).when(instance).querySubscriptionData(any(), any());
            doReturn("").when(manualPayTest).getRoute(any());

            // Capture Arguements for multirequest
            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiManualPay).when(manualPayTest).multiRequest(
                    any(), any(), argumentCaptor.capture());
            doReturn(wallet).when(manualPayTest).querySubscriptionWallet(any(), any(), any());

            boolean expectedVRO = false;
            if (vro != null) {
                input.setVisibleRecurringOverride(vro.toString());
                if (StringUtils.isNotBlank(vro.toString())
                        && "Y".equalsIgnoreCase(vro.toString())) {
                    expectedVRO = true;
                }
            }

            // method to test
            manualPayTest.manualPay(input, output, null);

            // Assertions here.
            ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();

            assertEquals(
                    expectedVRO,
                    ((VisibleBraintreeChargeMethodExtension) ((MtxRequestSubscriberRecharge) reqList.get(
                            0)).getChargeMethodData().getChargeMethodAttr()).getVisibleRecurringOverride());

        };
        pTests.test("Y");
        pTests.test("N");
        pTests.test("blah");
        pTests.test("");
        pTests.test(null);
    }

    @Test
    public void chargeAmountWithVisibleOfferDetailsTest(TestInfo testInfo) throws Exception {

        ManualPayService manualPayTest = instance;

        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class, DATA_DIR.MANUAL_PAY + "ManualPayRequest.json");

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MTXTAX_400.json");

        ManualPayResponse output = new ManualPayResponse();
        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");
        input.getCredits().get(0).setApprovedTransferableCredits(null);
        input.getCredits().get(0).setTaxDetails(null);
        MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
        // mocks
        doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
        doReturn("").when(manualPayTest).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> mtxRequestMultiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiManualPay).when(manualPayTest).multiRequest(
                any(), any(), mtxRequestMultiArgumentCaptor.capture());
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        MtxResponseSubscription subscriber = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription(
                        Arrays.asList(TestConstants.CI_EXTERNAL_IDS.UNLIMITED)));

        String origOrderId = "1551671132641";
        subscriber.getPurchasedOfferArray().forEach(poi -> {
            if (StringUtils.isNotBlank(poi.getCatalogItemExternalId()) && poi.getAttr() != null) {
                VisiblePurchasedOfferExtension poe = (VisiblePurchasedOfferExtension) poi.getAttr();
                poe.setOrderId(origOrderId);
            }
        });
        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.UNLIMITED);

        manualPayTest.manualPay(input, output, null);

        // 1. Assert the result:
        System.out.println(
                testInfo.getDisplayName() + ":output:" + StringUtils.LF + output.toJson());
        assertEquals(Long.valueOf(0), output.getResult());
        assertEquals("1", output.getRiskData().getRiskDataDeviceDataCaptured());

        // 2. Asserting the MtxRequestMultis
        assertEquals(1, mtxRequestMultiArgumentCaptor.getAllValues().size());
        MtxRequestMulti mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);
        // Initial request should contain the subscriber and pricing offers queries

        // We're expecting a recharge & subscriber modify offer
        mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);
        // assertEquals(3, mtxRequestMulti.getRequestList().size());
        assertTrue(mtxRequestMulti.getRequestList().get(0) instanceof MtxRequestSubscriberRecharge);
        assertTrue(
                mtxRequestMulti.getRequestList().get(
                        1) instanceof MtxRequestSubscriberPurchaseOffer);
        MtxRequestSubscriberPurchaseOffer puchaseOffer = (MtxRequestSubscriberPurchaseOffer) mtxRequestMulti.getRequestList().get(
                1);
        assertTrue(puchaseOffer.getOfferRequestArray().size() == 1);
        MtxPurchasedOfferData purchaseOfferForRecharge = puchaseOffer.getOfferRequestArray().get(0);
        assertEquals(purchaseOfferForRecharge.getExternalId(), "Visible_Update_Service_Payments");
        MtxRequestSubscriberRecharge rechargeReq = (MtxRequestSubscriberRecharge) mtxRequestMulti.getRequestList().get(
                0);
        VisibleRechargeExtension extn = (VisibleRechargeExtension) rechargeReq.getRechargeAttr();
        String yyMMddDate = CommonUtils.getDateYYMMDDString();
        assertEquals(yyMMddDate + "-" + origOrderId, extn.getOrderId());
        assertEquals(
                input.getVisibleOfferDetailsList().get(0).getPayableAmount(),
                ((VisiblePurchasedOfferExtension) purchaseOfferForRecharge.getAttr()).getChargeAmount());

        assertTrue(
                mtxRequestMulti.getRequestList().get(2) instanceof MtxRequestSubscriberModifyOffer);
        MtxRequestSubscriberModifyOffer subscriberModifyOffer = (MtxRequestSubscriberModifyOffer) mtxRequestMulti.getRequestList().get(
                2);
        assertEquals(
                Long.valueOf(input.getVisibleOfferDetailsList().get(0).getResourceId()),
                subscriberModifyOffer.getResourceId());
        assertTrue(subscriberModifyOffer.getAttr() instanceof VisiblePurchasedOfferExtension);
        VisiblePurchasedOfferExtension offer = (VisiblePurchasedOfferExtension) subscriberModifyOffer.getAttr();
        assertEquals(
                input.getVisibleOfferDetailsList().get(0).getTaxDetails(), offer.getTaxDetails());
    }

    @Test
    public void manualPayWithOrderIdAndPaymentReasonIncludedInMultiReq(TestInfo testInfo)
            throws Exception {

        ManualPayService manualPayTest = instance;

        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class, DATA_DIR.MANUAL_PAY + "ManualPayRequest.json");

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MTXTAX_400.json");

        ManualPayResponse output = new ManualPayResponse();
        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");
        input.getCredits().get(0).setApprovedTransferableCredits(null);
        input.getCredits().get(0).setTaxDetails(null);
        MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
        // mocks
        doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
        doReturn("").when(manualPayTest).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> mtxRequestMultiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiManualPay).when(manualPayTest).multiRequest(
                any(), any(), mtxRequestMultiArgumentCaptor.capture());
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        MtxResponseSubscription subscriber = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription(
                        Arrays.asList(TestConstants.CI_EXTERNAL_IDS.UNLIMITED)));
        String origOrderId = "1551671132641";
        subscriber.getPurchasedOfferArray().forEach(poi -> {
            if (StringUtils.isNotBlank(poi.getCatalogItemExternalId()) && poi.getAttr() != null) {
                VisiblePurchasedOfferExtension poe = (VisiblePurchasedOfferExtension) poi.getAttr();
                poe.setOrderId(origOrderId);
            }
        });

        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.UNLIMITED);

        manualPayTest.manualPay(input, output, null);

        // 1. Assert the result:
        System.out.println(
                testInfo.getDisplayName() + ": output:" + StringUtils.LF + output.toJson());
        assertEquals(Long.valueOf(0), output.getResult());
        assertEquals("1", output.getRiskData().getRiskDataDeviceDataCaptured());

        // 2. Asserting the MtxRequestMultis
        assertEquals(1, mtxRequestMultiArgumentCaptor.getAllValues().size());
        MtxRequestMulti mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);
        // Initial request should contain the subscriber and pricing offers queries

        // We're expecting a recharge & subscriber modify offer
        mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);
        assertTrue(mtxRequestMulti.getRequestList().get(0) instanceof MtxRequestSubscriberRecharge);
        assertTrue(
                mtxRequestMulti.getRequestList().get(
                        1) instanceof MtxRequestSubscriberPurchaseOffer);
        MtxRequestSubscriberPurchaseOffer puchaseOffer = (MtxRequestSubscriberPurchaseOffer) mtxRequestMulti.getRequestList().get(
                1);
        assertTrue(puchaseOffer.getOfferRequestArray().size() == 1);
        MtxPurchasedOfferData purchaseOfferForRecharge = puchaseOffer.getOfferRequestArray().get(0);
        assertEquals(purchaseOfferForRecharge.getExternalId(), "Visible_Update_Service_Payments");

        MtxRequestSubscriberRecharge rechargeReq = (MtxRequestSubscriberRecharge) mtxRequestMulti.getRequestList().get(
                0);

        String yyMMddDate = CommonUtils.getDateYYMMDDString();

        VisibleBraintreeChargeMethodExtension vbcme = (VisibleBraintreeChargeMethodExtension) rechargeReq.getChargeMethodData().getChargeMethodAttr();

        System.out.println(rechargeReq.toJson());

        // Checking that OrderId and PaymentReason are included in ChargeMethodData
        assertEquals(yyMMddDate + "-" + origOrderId, vbcme.getOrderId());
        assertEquals("purchase_service", vbcme.getPaymentReason());

        VisibleRechargeExtension extn = (VisibleRechargeExtension) rechargeReq.getRechargeAttr();
        // Checking that OiderId is in the format yymmdd-12345
        assertEquals(yyMMddDate + "-" + origOrderId, extn.getOrderId());
    }

    @Test
    public void chargeAmountWithVisibleOfferDetailsMultipleCredits() throws Exception {

        ManualPayService manualPayTest = instance;

        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class,
                DATA_DIR.MANUAL_PAY + "ManualPayRequestMultipleCredits.json");

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MultiResponse.json");
        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");
        ManualPayResponse output = new ManualPayResponse();
        MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
        // mocks
        doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
        doReturn("").when(manualPayTest).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> mtxRequestMultiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiManualPay).when(manualPayTest).multiRequest(
                any(), any(), mtxRequestMultiArgumentCaptor.capture());
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        MtxResponseSubscription subscriber = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription(
                        Arrays.asList(TestConstants.CI_EXTERNAL_IDS.UNLIMITED)));
        String origOrderId = "1551671132641";
        subscriber.getPurchasedOfferArray().forEach(poi -> {
            if (StringUtils.isNotBlank(poi.getCatalogItemExternalId()) && poi.getAttr() != null) {
                VisiblePurchasedOfferExtension poe = (VisiblePurchasedOfferExtension) poi.getAttr();
                poe.setOrderId(origOrderId);
            }
        });
        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.UNLIMITED);

        manualPayTest.manualPay(input, output, null);

        // 1. Assert the result:
        System.out.println("output:\n" + output.toJson());
        assertEquals(Long.valueOf(0), output.getResult());
        assertEquals("1", output.getRiskData().getRiskDataDeviceDataCaptured());

        // 2. Asserting the MtxRequestMultis
        assertEquals(1, mtxRequestMultiArgumentCaptor.getAllValues().size());
        MtxRequestMulti mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);
        // Initial request should contain the subscriber and pricing offers queries

        // We're expecting a recharge & subscriber modify offer
        mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);
        // assertEquals(3, mtxRequestMulti.getRequestList().size());
        assertTrue(
                mtxRequestMulti.getRequestList().get(
                        0) instanceof MtxRequestSubscriberPurchaseOffer);
        assertTrue(
                mtxRequestMulti.getRequestList().get(
                        1) instanceof MtxRequestSubscriberPurchaseOffer);
        assertTrue(
                mtxRequestMulti.getRequestList().get(
                        2) instanceof MtxRequestSubscriberPurchaseOffer);
        assertTrue(mtxRequestMulti.getRequestList().get(3) instanceof MtxRequestSubscriberRecharge);
        assertTrue(
                mtxRequestMulti.getRequestList().get(
                        4) instanceof MtxRequestSubscriberPurchaseOffer);
        assertTrue(
                mtxRequestMulti.getRequestList().get(5) instanceof MtxRequestSubscriberModifyOffer);
        MtxRequestSubscriberModifyOffer subscriberModifyOffer = (MtxRequestSubscriberModifyOffer) mtxRequestMulti.getRequestList().get(
                5);
        assertEquals(
                Long.valueOf(input.getVisibleOfferDetailsList().get(0).getResourceId()),
                subscriberModifyOffer.getResourceId());
        assertTrue(subscriberModifyOffer.getAttr() instanceof VisiblePurchasedOfferExtension);
        VisiblePurchasedOfferExtension offer = (VisiblePurchasedOfferExtension) subscriberModifyOffer.getAttr();
        assertEquals(
                input.getVisibleOfferDetailsList().get(0).getTaxDetails(), offer.getTaxDetails());
        assertTrue(mtxRequestMulti.getRequestList().get(6) instanceof MtxRequestSubscriberModify);
        MtxRequestSubscriberModify subscriberModify = (MtxRequestSubscriberModify) mtxRequestMulti.getRequestList().get(
                6);
        assertEquals(
                wallet.getBillingCycle().getCurrentPeriodEndTime(),
                ((VisibleSubscriberExtension) subscriberModify.getAttr()).getPaymentDate());
        MtxRequestSubscriberRecharge rechargeReq = (MtxRequestSubscriberRecharge) mtxRequestMulti.getRequestList().get(
                3);
        VisibleRechargeExtension extn = (VisibleRechargeExtension) rechargeReq.getRechargeAttr();
        String yyMMddDate = CommonUtils.getDateYYMMDDString();
        assertEquals(yyMMddDate + "-" + origOrderId, extn.getOrderId());
    }

    @Test
    public void testManualPayInvalidSubscriberState() throws Exception {

        ManualPayService manualPayTest = instance;

        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class, DATA_DIR.MANUAL_PAY + "ManualPayRequest.json");

        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MTXTAX_400.json");

        ManualPayResponse output = new ManualPayResponse();

        input.getCredits().get(0).setApprovedTransferableCredits(null);
        input.getCredits().get(0).setTaxDetails(null);
        input.getVisibleOfferDetailsListAppender().clear();

        MtxResponseSubscription subscriber = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscriber.setStatusDescription("Terminated");

        // mocks
        doReturn("").when(manualPayTest).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> mtxRequestMultiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiManualPay).
        when(
                manualPayTest).multiRequest(any(), any(), mtxRequestMultiArgumentCaptor.capture());
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        // method to test
        Exception exception = assertThrows(
                IntegrationServiceException.class,
                () -> manualPayTest.manualPay(input, output, null));
        exception.printStackTrace();
    }

    @Test
    public void chargeAmountOnlyAndReferralTest() throws Exception {

        ManualPayService manualPayTest = instance;

        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class, DATA_DIR.MANUAL_PAY + "ManualPayRequest.json");

        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MTXTAX_400.json");

        input.getCredits().get(0).setApprovedTransferableCredits(new BigDecimal("10"));
        ManualPayResponse output = new ManualPayResponse();
        MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
        // mocks
        doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
        doReturn("").when(manualPayTest).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> mtxRequestMultiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiManualPay).when(manualPayTest).multiRequest(
                any(), any(), mtxRequestMultiArgumentCaptor.capture());

        emulateMtxResponseSubscription(
                api,
                CommonTestHelper.getMtxResponseSubscription(List.of(CI_EXTERNAL_IDS.UNLIMITED)));
        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.UNLIMITED);
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());
        // method to test
        manualPayTest.manualPay(input, output, null);

        // 1. Assert the result:
        System.out.println("output:\n" + output.toJson());
        assertEquals(Long.valueOf(0), output.getResult());
        assertEquals("1", output.getRiskData().getRiskDataDeviceDataCaptured());

        // 2. Asserting the MtxRequestMultis
        assertEquals(1, mtxRequestMultiArgumentCaptor.getAllValues().size());
        MtxRequestMulti mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);
        // Initial request should contain the subscriber and pricing offers queries
        // We're expecting three requests
        mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);
        assertEquals(5, mtxRequestMulti.getRequestList().size());
        assertTrue(
                mtxRequestMulti.getRequestList().get(
                        0) instanceof MtxRequestSubscriberPurchaseOffer);
        assertTrue(mtxRequestMulti.getRequestList().get(1) instanceof MtxRequestSubscriberRecharge);
        assertTrue(
                mtxRequestMulti.getRequestList().get(
                        2) instanceof MtxRequestSubscriberPurchaseOffer);
        assertTrue(
                mtxRequestMulti.getRequestList().get(3) instanceof MtxRequestSubscriberModifyOffer);
        assertTrue(
                mtxRequestMulti.getRequestList().get(
                        0) instanceof MtxRequestSubscriberPurchaseOffer);
        // Ensure the timestamps are the same
        MtxRequestSubscriberRecharge rechargeRequest = (MtxRequestSubscriberRecharge) mtxRequestMulti.getRequestList().get(
                1);
        MtxRequestSubscriberPurchaseOffer purchaseOfferRequest = (MtxRequestSubscriberPurchaseOffer) mtxRequestMulti.getRequestList().get(
                0);

        VisiblePurchasedOfferExtension visiblePurchasedOffer = (VisiblePurchasedOfferExtension) purchaseOfferRequest.getOfferRequestArray().get(
                0).getAttr();
        assertEquals(rechargeRequest.getInfo(), visiblePurchasedOffer.getInfo());
        assertNull(visiblePurchasedOffer.getTaxDetails());
        assertNull(visiblePurchasedOffer.getTaxDetailsForCredit());

        MtxRequestSubscriberModifyOffer subscriberModifyOffer = (MtxRequestSubscriberModifyOffer) mtxRequestMulti.getRequestList().get(
                3);
        visiblePurchasedOffer = (VisiblePurchasedOfferExtension) subscriberModifyOffer.getAttr();
        assertNotNull(visiblePurchasedOffer.getCreditTaxDetailsArray().get(0));
        assertEquals(
                visiblePurchasedOffer.getCreditTaxDetailsArray().get(0),
                input.getCredits().get(0).getTaxDetails());
    }

    @Test
    public void referralOnlyTest() throws Exception {

        ManualPayService manualPayTest = instance;

        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class, DATA_DIR.MANUAL_PAY + "ManualPayRequest.json");

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MTXTAX_400.json");
        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");
        input.getCredits().get(0).setApprovedTransferableCredits(new BigDecimal("10"));
        input.getPayNow().setChargeAmount(BigDecimal.ZERO);
        ManualPayResponse output = new ManualPayResponse();

        // mocks
        doReturn("").when(manualPayTest).getRoute(any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> mtxRequestMultiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiManualPay).when(manualPayTest).multiRequest(
                any(), any(), mtxRequestMultiArgumentCaptor.capture());
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        emulateMtxResponseSubscription(api, CommonTestHelper.getMtxResponseSubscription());

        // method to test
        manualPayTest.manualPay(input, output, null);

        // 1. Assert the result:
        System.out.println("output:\n" + output.toJson());
        assertEquals(Long.valueOf(0), output.getResult());
        assertEquals(
                PAYMENT_CONSTANTS.DEFAULT_RISK_DATA,
                output.getRiskData().getRiskDataDeviceDataCaptured());

        // 2. Asserting the MtxRequestMultis
        assertEquals(1, mtxRequestMultiArgumentCaptor.getAllValues().size());
        MtxRequestMulti mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);
        // Initial request should contain the subscriber and pricing offers queries
        assertEquals(3, mtxRequestMulti.getRequestList().size());

        // We're expecting one request for MtxRequestSubscriberPurchaseOffer
        mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);
        assertEquals(3, mtxRequestMulti.getRequestList().size());
        assertTrue(
                mtxRequestMulti.getRequestList().get(
                        0) instanceof MtxRequestSubscriberPurchaseOffer);
        assertTrue(
                mtxRequestMulti.getRequestList().get(1) instanceof MtxRequestSubscriberModifyOffer);
        // Ensure the timestamps are the same
        MtxRequestSubscriberPurchaseOffer purchaseOfferRequest = (MtxRequestSubscriberPurchaseOffer) mtxRequestMulti.getRequestList().get(
                0);

        VisiblePurchasedOfferExtension visiblePurchasedOffer = (VisiblePurchasedOfferExtension) purchaseOfferRequest.getOfferRequestArray().get(
                0).getAttr();
        assertNotNull(visiblePurchasedOffer.getInfo());
        assertNull(visiblePurchasedOffer.getTaxDetails());
        assertNull(visiblePurchasedOffer.getTaxDetailsForCredit());

        MtxRequestSubscriberModifyOffer subscriberModifyOffer = (MtxRequestSubscriberModifyOffer) mtxRequestMulti.getRequestList().get(
                1);
        visiblePurchasedOffer = (VisiblePurchasedOfferExtension) subscriberModifyOffer.getAttr();
        assertEquals(
                input.getCredits().get(0).getTaxDetails(),
                visiblePurchasedOffer.getCreditTaxDetailsArray().get(0));
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_manualPay_EmptyRefCreditTax_RefCreditTaxFiltered() throws Exception {
        ManualPayService manualPayTest = instance;

        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class,
                DATA_DIR.MANUAL_PAY + "ManualPayRequest_EmptyRefCreditTax.json");

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MultiResponse.json");

        ManualPayResponse output = new ManualPayResponse();
        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());
        // mocks
        doReturn("").when(manualPayTest).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> mtxRequestMultiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiManualPay).when(manualPayTest).multiRequest(
                any(), any(), mtxRequestMultiArgumentCaptor.capture());

        MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
        // mocks
        doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
        emulateMtxResponseSubscription(
                api,
                CommonTestHelper.getMtxResponseSubscription(List.of(CI_EXTERNAL_IDS.UNLIMITED)));
        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.UNLIMITED);

        // method to test
        manualPayTest.manualPay(input, output, null);

        MtxRequestMulti multiReq = mtxRequestMultiArgumentCaptor.getAllValues().stream().filter(
                multReq -> multReq.getRequestList().size() > 1).findFirst().get();
        MtxRequestSubscriberModifyOffer subMod = (MtxRequestSubscriberModifyOffer) multiReq.getRequestList().stream().filter(
                req -> req.getMdcName().equals(
                        MtxRequestSubscriberModifyOffer.class.getSimpleName())).findFirst().get();

        ((VisiblePurchasedOfferExtension) subMod.getAttr()).getCreditTaxDetailsArray().forEach(
                taxString -> {
                    // There should be no empty tax strings.
                    assertTrue(StringUtils.isNotBlank(taxString));
                });
    }

    @SuppressWarnings("unchecked")
    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_manualPay_CreditTaxPresentInRequest_OverwriteCreditTaxes_CreditTaxUpdated(TestInfo testInfo)
            throws Exception {
        ManualPayService manualPayTest = instance;

        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class,
                DATA_DIR.MANUAL_PAY + "ManualPayRequestMultipleCredits.json");
        // Remove 2 credits and keep only one
        VisibleOfferDetails vod = input.getVisibleOfferDetailsList().stream().filter(
                od -> od.getCredits() != null && od.getCredits().size() > 0).findFirst().get();
        VisibleCredits group = vod.getCredits().stream().filter(
                cr -> cr.getPromotionName().equalsIgnoreCase("group")).findFirst().get();
        vod.getCreditsAppender().clear();
        vod.getCreditsAppender().add(group);
        input.getVisibleOfferDetailsListAppender().clear();
        input.getVisibleOfferDetailsListAppender().add(vod);

        VisibleCreditsManualPay vcmpgropup = input.getCredits().stream().filter(
                cr -> cr.getPromotionName().equalsIgnoreCase("group")).findFirst().get();
        input.getCreditsAppender().clear();
        input.getCreditsAppender().add(vcmpgropup);

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MultiResponse.json");

        ManualPayResponse output = new ManualPayResponse();
        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());
        MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
        // mocks
        doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
        doReturn("").when(manualPayTest).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> mtxRequestMultiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiManualPay).when(manualPayTest).multiRequest(
                any(), any(), mtxRequestMultiArgumentCaptor.capture());

        emulateMtxResponseSubscription(
                api,
                CommonTestHelper.getMtxResponseSubscription(List.of(CI_EXTERNAL_IDS.UNLIMITED)));
        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.UNLIMITED);
        // method to test
        manualPayTest.manualPay(input, output, null);
        System.out.println(testInfo.getDisplayName() + ":" + output.toJson());
        MtxRequestMulti multiReq = mtxRequestMultiArgumentCaptor.getAllValues().stream().filter(
                multReq -> multReq.getRequestList().size() > 1).findFirst().get();
        MtxRequestSubscriberModifyOffer subMod = (MtxRequestSubscriberModifyOffer) multiReq.getRequestList().stream().filter(
                req -> req.getMdcName().equals(
                        MtxRequestSubscriberModifyOffer.class.getSimpleName())).findFirst().get();

        assertTrue(
                ((VisiblePurchasedOfferExtension) subMod.getAttr()).getCreditTaxDetailsArray().size() > 0);

        ((VisiblePurchasedOfferExtension) subMod.getAttr()).getCreditTaxDetailsArray().forEach(
                taxString -> {
                    // There should be no empty tax strings.
                    assertTrue(StringUtils.isNotBlank(taxString));
                    assertTrue(taxString.contains("\"classCode\":\"GRPD-CR\""));
                });
    }

    @SuppressWarnings("unchecked")
    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_manualPay_NoCreditTaxInRequest_OverwriteCreditTaxes_CreditTaxRemoved(TestInfo testInfo)
            throws Exception {
        ManualPayService manualPayTest = instance;

        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class,
                DATA_DIR.MANUAL_PAY + "ManualPayRequestMultipleCredits.json");
        // Remove all credits and keep only one
        VisibleOfferDetails vod = input.getVisibleOfferDetailsList().stream().filter(
                od -> od.getCredits() != null && od.getCredits().size() > 0).findFirst().get();
        vod.getCreditsAppender().clear();
        input.getVisibleOfferDetailsListAppender().clear();
        input.getVisibleOfferDetailsListAppender().add(vod);
        input.getCreditsAppender().clear();

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MultiResponse.json");

        ManualPayResponse output = new ManualPayResponse();
        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());
        MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
        // mocks
        doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
        doReturn("").when(manualPayTest).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> mtxRequestMultiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiManualPay).when(manualPayTest).multiRequest(
                any(), any(), mtxRequestMultiArgumentCaptor.capture());

        emulateMtxResponseSubscription(
                api,
                CommonTestHelper.getMtxResponseSubscription(List.of(CI_EXTERNAL_IDS.UNLIMITED)));
        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.UNLIMITED);
        // method to test
        manualPayTest.manualPay(input, output, null);
        System.out.println(testInfo.getDisplayName() + "--" + output.toJson());
        MtxRequestMulti multiReq = mtxRequestMultiArgumentCaptor.getAllValues().stream().filter(
                multReq -> multReq.getRequestList().size() > 1).findFirst().get();
        MtxRequestSubscriberModifyOffer subMod = (MtxRequestSubscriberModifyOffer) multiReq.getRequestList().stream().filter(
                req -> req.getMdcName().equals(
                        MtxRequestSubscriberModifyOffer.class.getSimpleName())).findFirst().get();

        assertEquals(
                "",
                ((VisiblePurchasedOfferExtension) subMod.getAttr()).getCreditTaxDetailsArray().get(
                        0));
        assertTrue(
                StringUtils.isBlank(
                        ((VisiblePurchasedOfferExtension) subMod.getAttr()).getCreditTaxDetailsArray().get(
                                0)));
    }

    @SuppressWarnings("unchecked")
    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_manualPay_PaidCylcleStartDate_AfterManualPay(TestInfo testInfo)
            throws Exception {
        ManualPayService manualPayTest = instance;

        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class,
                DATA_DIR.MANUAL_PAY + "ManualPayRequestMultipleCredits.json");
        // Remove all credits and keep only one
        VisibleOfferDetails vod = input.getVisibleOfferDetailsList().stream().filter(
                od -> od.getCredits() != null && od.getCredits().size() > 0).findFirst().get();
        vod.getCreditsAppender().clear();
        input.getVisibleOfferDetailsListAppender().clear();
        input.getVisibleOfferDetailsListAppender().add(vod);
        input.getCreditsAppender().clear();

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MultiResponse.json");

        ManualPayResponse output = new ManualPayResponse();
        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
        // mocks
        doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
        doReturn("").when(manualPayTest).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> mtxRequestMultiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiManualPay).when(manualPayTest).multiRequest(
                any(), any(), mtxRequestMultiArgumentCaptor.capture());

        emulateMtxResponseSubscription(
                api,
                CommonTestHelper.getMtxResponseSubscription(List.of(CI_EXTERNAL_IDS.UNLIMITED)));
        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.UNLIMITED);
        // method to test
        manualPayTest.manualPay(input, output, null);
        System.out.println(testInfo.getDisplayName() + "--" + output.toJson());
        MtxRequestMulti multiReq = mtxRequestMultiArgumentCaptor.getAllValues().stream().filter(
                multReq -> multReq.getRequestList().size() > 1).findFirst().get();
        MtxRequestSubscriberModifyOffer subMod = (MtxRequestSubscriberModifyOffer) multiReq.getRequestList().stream().filter(
                req -> req.getMdcName().equals(
                        MtxRequestSubscriberModifyOffer.class.getSimpleName())).findFirst().get();

        assertTrue(
                ((VisiblePurchasedOfferExtension) subMod.getAttr()).getPaidCycleStartDate() instanceof MtxDate);
        assertNotNull(
                ((VisiblePurchasedOfferExtension) subMod.getAttr()).getPaidCycleStartDate().getTime());
    }

    @ParameterizedTest(name = "test_manualPay_When_SingleCredit_Then_FourRequests_in_Multi")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Manualpay request has a (say goodwill) credit block."
                +"|When  |Api is called.|"
                +"|Then  |Multirequest has 4 individual requests in specific order.|"})
    // @formatter:on
    public void test_manualPay_When_SingleCredit_Then_FourRequests_in_Multi(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        ManualPayService manualPayTest = instance;

        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class, DATA_DIR.MANUAL_PAY + "ManualPayRequestGoodwill.json");

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MultiResponse.json");
        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");
        ManualPayResponse output = new ManualPayResponse();
        MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
        // mocks
        doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());

        // mocks
        doReturn("").when(manualPayTest).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> mtxRequestMultiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiManualPay).when(manualPayTest).multiRequest(
                any(), any(), mtxRequestMultiArgumentCaptor.capture());

        emulateMtxResponseSubscription(
                api,
                CommonTestHelper.getMtxResponseSubscription(List.of(CI_EXTERNAL_IDS.UNLIMITED)));
        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.UNLIMITED);
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        manualPayTest.manualPay(input, output, null);

        // 1. Assert the result:
        assertEquals(Long.valueOf(0), output.getResult());
        assertEquals("1", output.getRiskData().getRiskDataDeviceDataCaptured());

        // 2. Asserting the MtxRequestMultis
        assertEquals(1, mtxRequestMultiArgumentCaptor.getAllValues().size());
        MtxRequestMulti mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);
        // Initial request should contain the subscriber and pricing offers queries

        // We're expecting a recharge & subscriber modify offer
        mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);
        Iterator<MtxRequest> itr = mtxRequestMulti.getRequestList().iterator();
        assertEquals(
                MtxRequestSubscriberPurchaseOffer.class.getSimpleName(), itr.next().getMdcName());
        assertEquals(MtxRequestSubscriberRecharge.class.getSimpleName(), itr.next().getMdcName());
        assertEquals(
                MtxRequestSubscriberPurchaseOffer.class.getSimpleName(), itr.next().getMdcName());
        assertEquals(
                MtxRequestSubscriberModifyOffer.class.getSimpleName(), itr.next().getMdcName());
    }

    @ParameterizedTest(name = "test_manualPay_When_SingleCredit_Then_UpdateOfferWithCreditTax")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Manualpay request has a (say goodwill) credit block."
                +"|When  |Api is called.|"
                +"|Then  |Applicable offer will be updated with credit tax|"})
    // @formatter:on
    public void test_manualPay_When_SingleCredit_Then_UpdateOfferWithCreditTax(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        ManualPayService manualPayTest = instance;

        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class, DATA_DIR.MANUAL_PAY + "ManualPayRequestGoodwill.json");

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MultiResponse.json");
        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");
        ManualPayResponse output = new ManualPayResponse();
        MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
        // mocks
        doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());

        // mocks
        doReturn("").when(manualPayTest).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> mtxRequestMultiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiManualPay).when(manualPayTest).multiRequest(
                any(), any(), mtxRequestMultiArgumentCaptor.capture());

        emulateMtxResponseSubscription(
                api,
                CommonTestHelper.getMtxResponseSubscription(List.of(CI_EXTERNAL_IDS.UNLIMITED)));
        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.UNLIMITED);
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        manualPayTest.manualPay(input, output, null);

        // 1. Assert the result:
        assertEquals(Long.valueOf(0), output.getResult());
        assertEquals("1", output.getRiskData().getRiskDataDeviceDataCaptured());

        // 2. Asserting the MtxRequestMultis
        assertEquals(1, mtxRequestMultiArgumentCaptor.getAllValues().size());
        MtxRequestMulti mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);
        // Initial request should contain the subscriber and pricing offers queries

        // We're expecting a recharge & subscriber modify offer
        mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);
        MtxRequestSubscriberModifyOffer modOffer = new MtxRequestSubscriberModifyOffer(
                mtxRequestMulti.getRequestList().get(3));

        assertEquals(
                Long.valueOf(input.getVisibleOfferDetailsList().get(0).getResourceId()),
                modOffer.getResourceId());
        VisiblePurchasedOfferExtension offer = (VisiblePurchasedOfferExtension) modOffer.getAttr();
        assertEquals(
                input.getVisibleOfferDetailsList().get(0).getTaxDetails(), offer.getTaxDetails());
    }

    @Test
    public void chargeAmountWithVisibleOfferDetailsAllCreditsStaleEstimateTest() throws Exception {

        ManualPayService manualPayTest = instance;

        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class,
                DATA_DIR.MANUAL_PAY + "ManualPayRequestMultipleCredits.json");
        input.setValidatePayment("Y");

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MultiResponse.json");
        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");
        ManualPayResponse output = new ManualPayResponse();
        MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
        // mocks
        doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
        doReturn("").when(manualPayTest).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> mtxRequestMultiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiManualPay).when(manualPayTest).multiRequest(
                any(), any(), mtxRequestMultiArgumentCaptor.capture());

        emulateMtxResponseSubscription(
                api,
                CommonTestHelper.getMtxResponseSubscription(List.of(CI_EXTERNAL_IDS.UNLIMITED)));
        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.UNLIMITED);
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());
        VisibleResponsePaymentAdviceService aopExpectedOutput = CommonTestHelper.loadJsonMessage(
                VisibleResponsePaymentAdviceService.class,
                DATA_DIR.MANUAL_PAY + "ManualPay_AOP_RevalidatedOutput.json");
        manualPayTest.manualPay(input, output, aopExpectedOutput);

        // 1. Assert the result:
        assertEquals(Long.valueOf(0), output.getResult());
        assertEquals("1", output.getRiskData().getRiskDataDeviceDataCaptured());

        // 2. Asserting the MtxRequestMultis
        assertEquals(1, mtxRequestMultiArgumentCaptor.getAllValues().size());
        MtxRequestMulti mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);
        // Initial request should contain the subscriber and pricing offers queries

        // We're expecting a recharge & subscriber modify offer
        mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);
        // assertEquals(3, mtxRequestMulti.getRequestList().size());
        assertTrue(
                mtxRequestMulti.getRequestList().get(
                        0) instanceof MtxRequestSubscriberPurchaseOffer);
    }

    @Test
    public void chargeAmountWithVisibleOfferDetailsAllCreditsStaleEstimateTestExpectedError()
            throws Exception {

        ManualPayService manualPayTest = instance;

        BigDecimal chargeAmount = BigDecimal.TEN;

        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class,
                DATA_DIR.MANUAL_PAY + "ManualPayRequestMultipleCredits.json");
        input.setValidatePayment("Y");
        input.getPayNow().setChargeAmount(chargeAmount);

        BigDecimal estimatedPayableAmount = BigDecimal.ONE;
        VisibleResponsePaymentAdviceService aopExpectedOutput = CommonTestHelper.loadJsonMessage(
                VisibleResponsePaymentAdviceService.class,
                DATA_DIR.MANUAL_PAY + "ManualPay_AOP_RevalidatedOutput.json");
        aopExpectedOutput.setEstimatedPayableAmount(estimatedPayableAmount);

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MultiResponse.json");

        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");

        ManualPayResponse output = new ManualPayResponse();

        // mocks
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());
        doReturn("").when(manualPayTest).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> mtxRequestMultiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiManualPay).when(manualPayTest).multiRequest(
                any(), any(), mtxRequestMultiArgumentCaptor.capture());

        emulateMtxResponseSubscription(api, CommonTestHelper.getMtxResponseSubscription());
        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.UNLIMITED);
        Exception exception = assertThrows(
                ManualPayException.class,
                () -> manualPayTest.manualPay(input, output, aopExpectedOutput));
        exception.printStackTrace();

        // // 1. Assert the result:
        // assertEquals(Long.valueOf(0), output.getResult());
        // assertEquals("1", output.getRiskData().getRiskDataDeviceDataCaptured());
        //
        // // 2. Asserting the MtxRequestMultis
        // assertEquals(2, mtxRequestMultiArgumentCaptor.getAllValues().size());
        // MtxRequestMulti mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);
        // // Initial request should contain the subscriber and pricing offers queries
        //
        // // We're expecting a recharge & subscriber modify offer
        // mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(1);
        //
        // assertTrue(
        // mtxRequestMulti.getRequestList().get(
        // 0) instanceof MtxRequestSubscriberPurchaseOffer);
    }

    @Test
    public void testCashPaymentInfoDetails() throws Exception {

        ManualPayService manualPayTest = instance;

        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class,
                DATA_DIR.MANUAL_PAY + "ManualPayRequestWithCashPayment.json");

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MultiResponse.json");
        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");
        ManualPayResponse output = new ManualPayResponse();
        MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
        // mocks
        doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
        doReturn("").when(manualPayTest).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> mtxRequestMultiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiManualPay).when(manualPayTest).multiRequest(
                any(), any(), mtxRequestMultiArgumentCaptor.capture());
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        emulateMtxResponseSubscription(
                api,
                CommonTestHelper.getMtxResponseSubscription(List.of(CI_EXTERNAL_IDS.UNLIMITED)));
        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.UNLIMITED);
        manualPayTest.manualPay(input, output, null);
        // 1. Assert the result:
        assertEquals(Long.valueOf(0), output.getResult());
        assertEquals("1", output.getRiskData().getRiskDataDeviceDataCaptured());

        // 2. Asserting the MtxRequestMultis
        assertEquals(1, mtxRequestMultiArgumentCaptor.getAllValues().size());
        MtxRequestMulti mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);
        // Initial request should contain the subscriber and pricing offers queries

        // We're expecting a recharge & subscriber modify offer
        mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);

        MtxRequest request = mtxRequestMulti.getRequestList().get(1);
        assertTrue(
                request instanceof MtxRequestSubscriberRecharge,
                "MtxRequestSubscriberRecharge expected at index 1 of multirequest input to Matrixx");
        MtxRequestSubscriberRecharge rechargeReq = (MtxRequestSubscriberRecharge) request;
        MtxRequestSubscriberPurchaseOffer purchaseReq = (MtxRequestSubscriberPurchaseOffer) mtxRequestMulti.getRequestList().get(
                2);
        String outputWithoutTimeStamp = rechargeReq.getInfo().replaceAll(
                "\\\"TimeStamp\\\":\\d*", "");

        assertThat(
                outputWithoutTimeStamp, equalTo(
                        "{\"$\":\"VisibleInfo\",,\"atm_id\":\"1234P\",\"atm_postal_code\":\"12345-1234\",\"atm_transaction_datetime\":\"2019-03-10T12:02:00-8000\",\"atm_transaction_local_datetime\":\"2019-03-10T12:00:00-6000\",\"atm_transaction_number\":123,\"bank_reference\":\"012300009999\",\"bill_reference_id\":\"12345678\",\"event_category\":\"ATMReceivables\",\"event_description\":\"NotificationofsuccessfulacceptanceofpaymentatWellsFargoATM\",\"event_name\":\"atm-receivables.payment.accepted.v1\",\"payer_reference_id\":\"87654321\",\"payment_amount\":35.0,\"payment_instruction_id\":\"033681ff-f105-4f15-b56c-521bbca23e98\",\"posting_date\":\"2019-03-10\",\"transaction_amount\":35.0}"));
        assertEquals(
                input.getVisibleOfferDetailsList().get(0).getPayableAmount(),
                ((VisiblePurchasedOfferExtension) purchaseReq.getOfferRequestArray().get(
                        0).getAttr()).getChargeAmount());
    }

    @Test
    public void testSubscriberMemberCount() throws Exception {

        ManualPayService manualPayTest = instance;

        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class,
                DATA_DIR.MANUAL_PAY + "ManualPayRequestMultipleCredits.json");

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MultiResponse.json");

        ManualPayResponse output = new ManualPayResponse();
        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");
        MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
        // mocks
        doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
        doReturn("").when(manualPayTest).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> mtxRequestMultiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiManualPay).when(manualPayTest).multiRequest(
                any(), any(), mtxRequestMultiArgumentCaptor.capture());

        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        emulateMtxResponseSubscription(
                api,
                CommonTestHelper.getMtxResponseSubscription(List.of(CI_EXTERNAL_IDS.UNLIMITED)));
        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.UNLIMITED);
        manualPayTest.manualPay(input, output, null);

        // 1. Assert the result:
        assertEquals(Long.valueOf(0), output.getResult());
        assertEquals("1", output.getRiskData().getRiskDataDeviceDataCaptured());

        // 2. Asserting the MtxRequestMultis
        assertEquals(1, mtxRequestMultiArgumentCaptor.getAllValues().size());
        MtxRequestMulti mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);
        // Initial request should contain the subscriber and pricing offers queries

        // Expecting 4 request elements in the requests list
        assertEquals(7, mtxRequestMulti.getRequestList().size());
        // We're expecting a recharge & subscriber modify offer
        mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);
        MtxRequest request = mtxRequestMulti.getRequestList().get(5);
        assertTrue(
                request instanceof MtxRequestSubscriberModifyOffer,
                "MtxRequestSubscriberModifyOffer expected at index 1 of multirequest input to Matrixx");
        MtxRequestSubscriberModifyOffer subscriberModifyReq = (MtxRequestSubscriberModifyOffer) request;

        BaseContainer attrib = subscriberModifyReq.getAttr();
        assertTrue(
                attrib instanceof VisiblePurchasedOfferExtension,
                "VisiblePurchasedOfferExtension expected as attribute in the subscriber modifiy offer");
        VisiblePurchasedOfferExtension offerExt = (VisiblePurchasedOfferExtension) attrib;

        assertTrue(offerExt.getGroupMemberCount() == 4L);
    }

    @Test
    public void test_subscriberNotFound() throws Exception {
        ManualPayService manualPayTest = instance;
        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class, DATA_DIR.MANUAL_PAY + "ManualPayRequest_Valid.json");

        MtxResponseMulti emptySubscriber = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_EmptySubscriber.json");

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MultiResponse.json");

        ManualPayResponse output = new ManualPayResponse();
        // mocks
        doReturn("").when(manualPayTest).getRoute(any());

        doReturn(null).when(api).subscriberQuery(any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(emptySubscriber).doReturn(multiManualPay).when(manualPayTest).multiRequest(
                any(), any(), argumentCaptor.capture());

        // method to test
        // manualPayTest.manualPay(input, output, null);
        Exception exception = assertThrows(
                ManualPayException.class, () -> manualPayTest.manualPay(input, output, null));
        exception.printStackTrace();

        // ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();
        // int amountScale = ((MtxRequestSubscriberRecharge) reqList.get(0)).getAmount().scale();
        // assertEquals(2, amountScale);
    }

    @Test
    public void testCashPaymentInfoDetails_Lapsed_NoVisibleOfferDetailsList() throws Exception {

        ManualPayService manualPayTest = instance;

        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class,
                DATA_DIR.MANUAL_PAY + "ManualPayRequestWithCashPayment.json");
        input.setPayNow(new VisiblePayNow());
        input.getVisibleOfferDetailsListAppender().clear();

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MultiResponse.json");
        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");
        ManualPayResponse output = new ManualPayResponse();
        MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
        // mocks
        doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
        doReturn("").when(manualPayTest).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> mtxRequestMultiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiManualPay).when(manualPayTest).multiRequest(
                any(), any(), mtxRequestMultiArgumentCaptor.capture());
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription(
                        Arrays.asList(TestConstants.CI_EXTERNAL_IDS.UNLIMITED)));
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.SETUP_SERVICES);        
        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.UNLIMITED);
        manualPayTest.manualPay(input, output, null);
        // 1. Assert the result:
        assertEquals(Long.valueOf(0), output.getResult());
        assertEquals("1", output.getRiskData().getRiskDataDeviceDataCaptured());

        // 2. Asserting the MtxRequestMultis
        assertEquals(1, mtxRequestMultiArgumentCaptor.getAllValues().size());
        MtxRequestMulti mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);
        // Initial request should contain the subscriber and pricing offers queries

        // We're expecting a recharge & subscriber modify offer
        mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);

        MtxRequest request = mtxRequestMulti.getRequestList().get(1);
        assertTrue(
                request instanceof MtxRequestSubscriberRecharge,
                "MtxRequestSubscriberRecharge expected at index 1 of multirequest input to Matrixx");
        MtxRequestSubscriberRecharge rechargeReq = (MtxRequestSubscriberRecharge) request;
        MtxRequestSubscriberPurchaseOffer purchaseReq = (MtxRequestSubscriberPurchaseOffer) mtxRequestMulti.getRequestList().get(
                2);
        System.out.println(rechargeReq.toJson());
        String outputWithoutTimeStamp = rechargeReq.getInfo().replaceAll(
                "\\\"TimeStamp\\\":\\d*", "");

        assertThat(
                outputWithoutTimeStamp, equalTo(
                        "{\"$\":\"VisibleInfo\",,\"atm_id\":\"1234P\",\"atm_postal_code\":\"12345-1234\",\"atm_transaction_datetime\":\"2019-03-10T12:02:00-8000\",\"atm_transaction_local_datetime\":\"2019-03-10T12:00:00-6000\",\"atm_transaction_number\":123,\"bank_reference\":\"012300009999\",\"bill_reference_id\":\"12345678\",\"event_category\":\"ATMReceivables\",\"event_description\":\"NotificationofsuccessfulacceptanceofpaymentatWellsFargoATM\",\"event_name\":\"atm-receivables.payment.accepted.v1\",\"payer_reference_id\":\"87654321\",\"payment_amount\":35.0,\"payment_instruction_id\":\"033681ff-f105-4f15-b56c-521bbca23e98\",\"posting_date\":\"2019-03-10\",\"transaction_amount\":35.0}"));
        assertEquals(
                input.getCashPaymentDetails().getrecharge_amount().setScale(
                        2, RoundingMode.HALF_UP),
                ((VisiblePurchasedOfferExtension) purchaseReq.getOfferRequestArray().get(
                        0).getAttr()).getChargeAmount());
    }

    @Test
    public void testCashPaymentZeroRecharge_NoSubscriberModify() throws Exception {

        ManualPayService manualPayTest = instance;

        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class,
                DATA_DIR.MANUAL_PAY + "ManualPayRequestWithCashPayment.json");
        input.setPayNow(new VisiblePayNow());

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MultiResponse.json");
        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");
        ManualPayResponse output = new ManualPayResponse();

        MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
        // mocks
        doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
        doReturn("").when(manualPayTest).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> mtxRequestMultiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiManualPay).when(manualPayTest).multiRequest(
                any(), any(), mtxRequestMultiArgumentCaptor.capture());
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        emulateMtxResponseSubscription(
                api,
                CommonTestHelper.getMtxResponseSubscription(List.of(CI_EXTERNAL_IDS.UNLIMITED)));
        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.UNLIMITED);
        manualPayTest.manualPay(input, output, null);
        MtxRequestMulti manualPayReq = mtxRequestMultiArgumentCaptor.getAllValues().get(0);

        assertEquals(5, manualPayReq.getRequestList().size());
        Iterator<MtxRequest> itr = manualPayReq.getRequestList().iterator();

        assertEquals(
                MtxRequestSubscriberPurchaseOffer.class.getSimpleName(),
                itr.next().getClass().getSimpleName());
        MtxRequest req = itr.next();
        assertEquals(
                MtxRequestSubscriberRecharge.class.getSimpleName(), req.getClass().getSimpleName());
        assertTrue(((MtxRequestSubscriberRecharge) req).getInfo().contains("atm_postal_code"));
        assertEquals(
                MtxRequestSubscriberPurchaseOffer.class.getSimpleName(),
                itr.next().getClass().getSimpleName());
        assertEquals(
                MtxRequestSubscriberModifyOffer.class.getSimpleName(),
                itr.next().getClass().getSimpleName());
        assertEquals(
                MtxRequestSubscriberModify.class.getSimpleName(),
                itr.next().getClass().getSimpleName());
    }

    @Test
    public void test_manualPay_When_PercentagePromo_Then_RedeemOfferIsPercentage()
            throws Exception {

        ManualPayService manualPayTest = instance;

        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class, DATA_DIR.MANUAL_PAY + "ManualPayRequestGoodwill.json");
        input.getCredits().get(0).setApplicableCreditsPercentage(BigDecimal.TEN);

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MultiResponse.json");
        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");
        ManualPayResponse output = new ManualPayResponse();
        MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
        // mocks
        doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
        doReturn("").when(manualPayTest).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> mtxRequestMultiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiManualPay).when(manualPayTest).multiRequest(
                any(), any(), mtxRequestMultiArgumentCaptor.capture());

        emulateMtxResponseSubscription(
                api,
                CommonTestHelper.getMtxResponseSubscription(List.of(CI_EXTERNAL_IDS.UNLIMITED)));
        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.UNLIMITED);
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        manualPayTest.manualPay(input, output, null);

        // 1. Assert the result:
        assertEquals(Long.valueOf(0), output.getResult());
        assertEquals("1", output.getRiskData().getRiskDataDeviceDataCaptured());

        // 2. Asserting the MtxRequestMultis
        assertEquals(1, mtxRequestMultiArgumentCaptor.getAllValues().size());
        MtxRequestMulti mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);
        // Initial request should contain the subscriber and pricing offers queries

        // We're expecting a recharge & subscriber modify offer
        mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);

        assertTrue(
                mtxRequestMulti.getRequestList().get(
                        0) instanceof MtxRequestSubscriberPurchaseOffer);
        MtxRequestSubscriberPurchaseOffer creditRedeemReq = (MtxRequestSubscriberPurchaseOffer) mtxRequestMulti.getRequestList().get(
                0);
        VisiblePurchasedOfferExtension poe = (VisiblePurchasedOfferExtension) creditRedeemReq.getOfferRequestArray().get(
                0).getAttr();
        assertEquals(
                "Visible_Redeem_Goodwill_Credits",
                creditRedeemReq.getOfferRequestArray().get(0).getExternalId());
        assertEquals(CREDIT_CONSTANTS.GRANT_TYPE_PERCENTAGE, poe.getCreditGrantType());
        System.out.println(creditRedeemReq.toJson());
    }

    @ParameterizedTest(name = "test_manualPay_When_InputRechargeAttr_Then_Attr_Copied_ToRecharge")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Manualpay request has recharge attributes."
                +"|When  |Api is called.|"
                +"|Then  |Recharge attributes are copied to final recharge request to engine..|"})
    // @formatter:on
    public void test_manualPay_When_InputRechargeAttr_Then_Attr_Copied_ToRecharge(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        ManualPayService manualPayTest = instance;
        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class, DATA_DIR.MANUAL_PAY + "ManualPayRequest.json");

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MTXTAX_400.json");

        ManualPayResponse output = new ManualPayResponse();
        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");
        input.getCredits().get(0).setApprovedTransferableCredits(null);
        input.getCredits().get(0).setTaxDetails(null);
        MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
        // mocks
        doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
        doReturn("").when(manualPayTest).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> mtxRequestMultiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiManualPay).when(manualPayTest).multiRequest(
                any(), any(), mtxRequestMultiArgumentCaptor.capture());
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        MtxResponseSubscription subscriber = emulateMtxResponseSubscription(
                api,
                CommonTestHelper.getMtxResponseSubscription(List.of(CI_EXTERNAL_IDS.UNLIMITED)));
        String origOrderId = "1551671132641";
        subscriber.getPurchasedOfferArray().forEach(poi -> {
            if (StringUtils.isNotBlank(poi.getCatalogItemExternalId()) && poi.getAttr() != null) {
                VisiblePurchasedOfferExtension poe = (VisiblePurchasedOfferExtension) poi.getAttr();
                poe.setOrderId(origOrderId);
            }
        });
        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.UNLIMITED);
        doReturn(subscriber).when(instance).querySubscriptionData(any(), any());

        manualPayTest.manualPay(input, output, null);

        // 1. Assert the result:
        System.out.println(
                testInfo.getDisplayName() + ":output:" + StringUtils.LF + output.toJson());

        MtxRequestMulti mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);

        // We're expecting a recharge & subscriber modify offer
        mtxRequestMultiArgumentCaptor.getAllValues().forEach(mtxRequestMulti1 -> {
            System.out.println("MtxRequestValues" + mtxRequestMulti1.toJson());
        });
        assertTrue(mtxRequestMulti.getRequestList().get(0) instanceof MtxRequestSubscriberRecharge);
        MtxRequestSubscriberRecharge rechargeReq = (MtxRequestSubscriberRecharge) mtxRequestMulti.getRequestList().get(
                0);
        VisibleRechargeExtension extn = (VisibleRechargeExtension) rechargeReq.getRechargeAttr();

        VisibleServiceDetails rechSD = (VisibleServiceDetails) extn.getAtVisibleServiceInfoArray(0);

        VisibleServiceDetails inputSD = input.getRechargeAttr().getAtVisibleServiceInfoArray(0);

        assertEquals(inputSD.getServiceMDN(), rechSD.getServiceMDN());
        assertEquals(inputSD.getServiceType(), rechSD.getServiceType());
        assertEquals(inputSD.getServiceChargeType(), rechSD.getServiceChargeType());
        assertEquals(inputSD.getServiceChargeAmount(), rechSD.getServiceChargeAmount());
        assertEquals(inputSD.getServiceStartDate(), rechSD.getServiceStartDate());
    }

    @Test
    public void testVisiblePurchaseOfferAttributesForManualPay(TestInfo testInfo) throws Exception {

        ManualPayService manualPayTest = instance;
        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class, DATA_DIR.MANUAL_PAY + "ManualPayRequest.json");

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MTXTAX_400.json");

        ManualPayResponse output = new ManualPayResponse();
        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");
        input.getCredits().get(0).setApprovedTransferableCredits(null);
        input.getCredits().get(0).setTaxDetails(null);
        MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
        // mocks
        doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
        doReturn("").when(manualPayTest).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> mtxRequestMultiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiManualPay).when(manualPayTest).multiRequest(
                any(), any(), mtxRequestMultiArgumentCaptor.capture());
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        MtxResponseSubscription subscriber = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription(
                        List.of(TestConstants.CI_EXTERNAL_IDS.UNLIMITED)));
        String origOrderId = "1551671132641";
        subscriber.getPurchasedOfferArray().forEach(poi -> {
            if (StringUtils.isNotBlank(poi.getCatalogItemExternalId()) && poi.getAttr() != null) {
                VisiblePurchasedOfferExtension poe = (VisiblePurchasedOfferExtension) poi.getAttr();
                poe.setOrderId(origOrderId);
            }
        });
        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.UNLIMITED);

        manualPayTest.manualPay(input, output, null);

        // 1. Assert the result:
        System.out.println(
                testInfo.getDisplayName() + ":output:" + StringUtils.LF + output.toJson());
        assertEquals(Long.valueOf(0), output.getResult());
        assertEquals("1", output.getRiskData().getRiskDataDeviceDataCaptured());

        // 2. Asserting the MtxRequestMultis
        assertEquals(1, mtxRequestMultiArgumentCaptor.getAllValues().size());
        MtxRequestMulti mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);
        // Initial request should contain the subscriber and pricing offers queries

        // We're expecting a recharge & subscriber modify offer
        mtxRequestMultiArgumentCaptor.getAllValues().forEach(mtxRequestMulti1 -> {
            System.out.println("MtxRequestValues" + mtxRequestMulti1.toJson());
        });
        assertTrue(mtxRequestMulti.getRequestList().get(0) instanceof MtxRequestSubscriberRecharge);
        assertTrue(
                mtxRequestMulti.getRequestList().get(
                        1) instanceof MtxRequestSubscriberPurchaseOffer);
        MtxRequestSubscriberPurchaseOffer puchaseOffer = (MtxRequestSubscriberPurchaseOffer) mtxRequestMulti.getRequestList().get(
                1);
        assertTrue(puchaseOffer.getOfferRequestArray().size() == 1);
        MtxPurchasedOfferData purchaseOfferForRecharge = puchaseOffer.getOfferRequestArray().get(0);
        assertEquals(purchaseOfferForRecharge.getExternalId(), "Visible_Update_Service_Payments");

        VisiblePurchasedOfferExtension purchasedOfferExtension = (VisiblePurchasedOfferExtension) input.getAttrData();

        assertEquals("ABC", purchasedOfferExtension.getBrand());
        assertEquals("DEFAULT", purchasedOfferExtension.getChannel());
        assertEquals("TEST", purchasedOfferExtension.getChargeId());
        assertEquals("XYZ", purchasedOfferExtension.getClassCode());
    }

    @ParameterizedTest(name = "test_manualPay_When_NoWearableInput_NoWearableMDN")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Manualpay request has no wearable."
                +"|When  |Api is called.|"
                +"|Then  |No info for wearable device should be updated to recharge|"})
    // @formatter:on
    public void test_manualPay_When_NoWearableInput_NoWearableMDN_In_Recharge(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        ManualPayService manualPayTest = instance;
        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class, DATA_DIR.MANUAL_PAY + "ManualPayRequest.json");

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MTXTAX_400.json");

        ManualPayResponse output = new ManualPayResponse();
        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");
        input.getCredits().get(0).setApprovedTransferableCredits(null);
        input.getCredits().get(0).setTaxDetails(null);
        MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Wearable();
        // mocks
        doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
        doReturn("").when(manualPayTest).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> mtxRequestMultiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiManualPay).when(manualPayTest).multiRequest(
                any(), any(), mtxRequestMultiArgumentCaptor.capture());
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        MtxResponseSubscription subscriber = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription(
                        List.of(TestConstants.CI_EXTERNAL_IDS.UNLIMITED)));
        String origOrderId = "1551671132641";

        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.UNLIMITED);

        doReturn(subscriber).when(instance).querySubscriptionData(any(), any());

        manualPayTest.manualPay(input, output, null);

        subscriber.getPurchasedOfferArray().forEach(poi -> {
            if (StringUtils.isNotBlank(poi.getCatalogItemExternalId()) && poi.getAttr() != null) {
                VisiblePurchasedOfferExtension poe = (VisiblePurchasedOfferExtension) poi.getAttr();
                poe.setOrderId(origOrderId);
            }
        });
        MtxRequestMulti mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);
        // Initial request should contain the subscriber and pricing offers queries

        // We're expecting a recharge & subscriber modify offer
        mtxRequestMultiArgumentCaptor.getAllValues().forEach(mtxRequestMulti1 -> {
            System.out.println("MtxRequestValues" + mtxRequestMulti1.toJson());
        });
        assertTrue(mtxRequestMulti.getRequestList().get(0) instanceof MtxRequestSubscriberRecharge);
        assertTrue(
                mtxRequestMulti.getRequestList().get(
                        1) instanceof MtxRequestSubscriberPurchaseOffer);
        MtxRequestSubscriberPurchaseOffer puchaseOffer = (MtxRequestSubscriberPurchaseOffer) mtxRequestMulti.getRequestList().get(
                1);
        assertTrue(puchaseOffer.getOfferRequestArray().size() == 1);
        MtxPurchasedOfferData purchaseOfferForRecharge = puchaseOffer.getOfferRequestArray().get(0);
        assertEquals(purchaseOfferForRecharge.getExternalId(), "Visible_Update_Service_Payments");
        MtxRequestSubscriberRecharge rechargeReq = (MtxRequestSubscriberRecharge) mtxRequestMulti.getRequestList().get(
                0);
        VisibleRechargeExtension extn = (VisibleRechargeExtension) rechargeReq.getRechargeAttr();

        assertNull(extn.getPlanAmount());
        assertNull(extn.getWearableRatePlan());
        assertNull(extn.getWearableMDN());
    }

    @ParameterizedTest(name = "test_manualPay_When_Recharge_Then_UpdateServicePayments")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Manualpay request has recharge amount in input."
                +"|When  |Api is called.|"
                +"|Then  |UpdateServicePayment should be purchased with recharge amount.|"})
    // @formatter:on
    public void test_manualPay_When_Recharge_Then_UpdateServicePayments(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        ManualPayService manualPayTest = instance;
        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class, DATA_DIR.MANUAL_PAY + "ManualPayRequest.json");

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                DATA_DIR.MANUAL_PAY + "MtxResponseMulti_ManualPay_MTXTAX_400.json");

        ManualPayResponse output = new ManualPayResponse();
        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");
        input.getCredits().get(0).setApprovedTransferableCredits(null);
        input.getCredits().get(0).setTaxDetails(null);
        MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Wearable();
        // mocks
        doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
        doReturn("").when(manualPayTest).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> mtxRequestMultiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiManualPay).when(manualPayTest).multiRequest(
                any(), any(), mtxRequestMultiArgumentCaptor.capture());
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());

        MtxResponseSubscription subscriber = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription(
                        List.of(TestConstants.CI_EXTERNAL_IDS.UNLIMITED)));
        String origOrderId = "1551671132641";

        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.UNLIMITED);

        doReturn(subscriber).when(instance).querySubscriptionData(any(), any());

        manualPayTest.manualPay(input, output, null);

        subscriber.getPurchasedOfferArray().forEach(poi -> {
            if (StringUtils.isNotBlank(poi.getCatalogItemExternalId()) && poi.getAttr() != null) {
                VisiblePurchasedOfferExtension poe = (VisiblePurchasedOfferExtension) poi.getAttr();
                poe.setOrderId(origOrderId);
            }
        });
        MtxRequestMulti mtxRequestMulti = mtxRequestMultiArgumentCaptor.getAllValues().get(0);
        // Initial request should contain the subscriber and pricing offers queries

        // We're expecting a recharge & subscriber modify offer
        mtxRequestMultiArgumentCaptor.getAllValues().forEach(mtxRequestMulti1 -> {
            System.out.println("MtxRequestValues" + mtxRequestMulti1.toJson());
        });
        MtxRequestSubscriberPurchaseOffer puchaseOffer = (MtxRequestSubscriberPurchaseOffer) mtxRequestMulti.getRequestList().get(
                1);
        assertTrue(puchaseOffer.getOfferRequestArray().size() == 1);
        MtxPurchasedOfferData purchaseOfferForRecharge = puchaseOffer.getOfferRequestArray().get(0);
        assertEquals(
                CI_EXTERNAL_IDS.UPDATE_SERVICE_PAYMENTS, purchaseOfferForRecharge.getExternalId());
        VisiblePurchasedOfferExtension extn = (VisiblePurchasedOfferExtension) purchaseOfferForRecharge.getAttr();
        assertEquals(
                input.getPayNow().getChargeAmount().floatValue(),
                extn.getChargeAmount().floatValue());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_manualPay_CIM4976_When_CreditTaxPresent_MultipleOffers_AttributesInRequest_Then_CreditTaxUpdated_To_CorrectOffer(TestInfo testInfo)
            throws Exception {
        ManualPayService manualPayTest = instance;

        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class, DATA_DIR.MANUAL_PAY + "ManualPayRequest_CIM4976.json");

        ManualPayResponse output = new ManualPayResponse();
        MtxResponseWallet wallet = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.MANUAL_PAY + "MtxResponseWallet.json");
        doReturn(wallet).when(instance).querySubscriptionWallet(any(), any(), any());
        MtxResponseDevice deviceQuery = CommonTestHelper.getMtxResponseDevice_Default();
        // mocks
        doReturn(deviceQuery).when(instance).queryDeviceData(any(), any(), any());
        doReturn("").when(manualPayTest).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> mtxRequestMultiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti multiManualPay = new MtxResponseMulti();
        multiManualPay.setResultText("OK");
        multiManualPay.setResult(0L);
        doReturn(multiManualPay).when(manualPayTest).multiRequest(
                any(), any(), mtxRequestMultiArgumentCaptor.capture());

        MtxResponseSubscription subscriber = emulateMtxResponseSubscription(
                DATA_DIR.MANUAL_PAY + "MtxResponseSubscription_CIM4976.json");
        long insuranceResourceId = subscriber.getPurchasedOfferArray().stream().filter(
                poi -> StringUtils.isNotBlank(poi.getCatalogItemExternalId())).filter(
                        poi -> CI_EXTERNAL_IDS.INSURANCE.equalsIgnoreCase(
                                poi.getCatalogItemExternalId())).findFirst().get().getResourceId();

        long unlimitedResourceId = subscriber.getPurchasedOfferArray().stream().filter(
                poi -> StringUtils.isNotBlank(poi.getCatalogItemExternalId())).filter(
                        poi -> CI_EXTERNAL_IDS.UNLIMITED.equalsIgnoreCase(
                                poi.getCatalogItemExternalId())).findFirst().get().getResourceId();

        emulateMtxResponsePricingCatalogItems(instance, List.of(CI_EXTERNAL_IDS.UNLIMITED,CI_EXTERNAL_IDS.INSURANCE));

        doReturn(subscriber).when(instance).querySubscriptionData(any(), any());

        // method to test
        manualPayTest.manualPay(input, output, null);
        System.out.println(testInfo.getDisplayName() + ":" + output.toJson());
        MtxRequestMulti multiReq = mtxRequestMultiArgumentCaptor.getAllValues().stream().filter(
                multReq -> multReq.getRequestList().size() > 1).findFirst().get();

        System.out.println(testInfo.getDisplayName() + ":" + multiReq.toJson());
        VisiblePurchasedOfferExtension insuranceModOffer = (VisiblePurchasedOfferExtension) multiReq.getRequestList().stream().filter(
                req -> MtxRequestSubscriberModifyOffer.class.getSimpleName().equalsIgnoreCase(
                        req.getContainer().getName())).map(
                                req -> (MtxRequestSubscriberModifyOffer) req).filter(
                                        mOffer -> mOffer.getResourceId().longValue() == insuranceResourceId).findFirst().get().getAttr();

        VisiblePurchasedOfferExtension unlimitedModOffer = (VisiblePurchasedOfferExtension) multiReq.getRequestList().stream().filter(
                req -> MtxRequestSubscriberModifyOffer.class.getSimpleName().equalsIgnoreCase(
                        req.getContainer().getName())).map(
                                req -> (MtxRequestSubscriberModifyOffer) req).filter(
                                        mOffer -> mOffer.getResourceId().longValue() == unlimitedResourceId).findFirst().get().getAttr();

        assertTrue(StringUtils.isBlank(insuranceModOffer.getAtCreditTaxDetailsArray(0)));
        assertTrue(StringUtils.isNotBlank(unlimitedModOffer.getAtCreditTaxDetailsArray(0)));
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_manualPay_When_FreeAddon_NoInsurance_NoRecharge_Then_No_MDN_in_RechargeReq")
    @Tag("VER-655")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription has service and wearable device. Enrolled in plusannual with free addon.|"
                +"|     |Has no insurance. In first 11 months of service.|"
                +"|When |Api called betwen 1st to 11th month to pay.|"
                +"|Then |Multirequest has no recharge request.|"})
    // @formatter:on
    public void test_manualPay_When_FreeAddon_NoInsurance_NoRecharge_Then_No_MDN_in_RechargeReq(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        ManualPayResponse output = new ManualPayResponse();
        String subExternalId = "1234";
        MtxResponseWallet wallet = emulateMtxResponseWallet(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        ManualPayRequest input = CommonTestHelper.getManualPayRequest(
                subExternalId, BigDecimal.ZERO);
        VisibleOfferDetails vod = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.PLUS3ANNUAL, wallet.getBillingCycle(), false);
        input.getVisibleOfferDetailsListAppender().add(vod);
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                instance, CommonTestHelper.getMtxResponseSubscription(
                        subExternalId, List.of(CI_EXTERNAL_IDS.PLUS3ANNUAL,CI_EXTERNAL_IDS.WEARABLE_ANNUAL_2023), 2));

        ArgumentCaptor<MtxRequestMulti> multiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti multiManualPay = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(multiManualPay).when(instance).multiRequest(
                any(), any(), multiArgumentCaptor.capture());

        MtxResponseDevice serviceDevice = CommonTestHelper.getMtxResponseDevice_Default();
        MtxResponseDevice wearableDevice = CommonTestHelper.getMtxResponseDevice_Wearable();
        doReturn(serviceDevice).doReturn(wearableDevice).when(instance).queryDeviceData(
                any(), any(), any());

        printUnitTest(subscription.toJson());

        instance.manualPay(input, output, null);
        MtxRequestMulti multiReq = multiArgumentCaptor.getValue();
        List<String> requests = new ArrayList<String>();
        multiReq.getRequestList().forEach(req -> {
            requests.add(req.getMdcName());
        });
        printUnitTest(multiReq.toJson());
        assertFalse(requests.contains(MtxRequestSubscriberRecharge.class.getSimpleName()));
    }
    
    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_manualPay_When_FreeAddon_ChargeInsuranceOnly_Then_No_MDN_In_RechargeAttr")
    @Tag("VER-655")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription  has wearable device. Enrolled in plusannual with free addon.|"
                +"|     |HAS insurance. In first 11 months of service.|"
                +"|When |Api called betwen 1st to 11th month to pay.|"
                +"|Then |recharge request has no recharge attributes with device details(Neither Service Nor Wearable).|"
                +"|     |Has order id.|"})
    // @formatter:on
    public void test_manualPay_When_FreeAddon_ChargeInsuranceOnly_Then_No_MDN_In_RechargeAttr(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        ManualPayResponse output = new ManualPayResponse();
        String subExternalId = "1234";
        MtxResponseWallet wallet = emulateMtxResponseWallet(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        printUnitTest(wallet.toJson());
        
        VisibleOfferDetails vodSvc = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.PLUS3ANNUAL, wallet.getBillingCycle(), false);
        VisibleOfferDetails vodIns = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.INSURANCE, wallet.getBillingCycle());        
        ManualPayRequest input = CommonTestHelper.getManualPayRequest(
                subExternalId, vodSvc.getPayableAmount().add(vodIns.getPayableAmount()));
        input.getVisibleOfferDetailsListAppender().add(vodSvc);
        input.getVisibleOfferDetailsListAppender().add(vodIns);

        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.INSURANCE);

        emulateMtxResponseSubscription(
                instance, CommonTestHelper.getMtxResponseSubscription(
                        subExternalId, List.of(CI_EXTERNAL_IDS.PLUS3ANNUAL,CI_EXTERNAL_IDS.INSURANCE), 2));

        ArgumentCaptor<MtxRequestMulti> multiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti multiManualPay = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(multiManualPay).when(instance).multiRequest(
                any(), any(), multiArgumentCaptor.capture());

        MtxResponseDevice serviceDevice = CommonTestHelper.getMtxResponseDevice_Default();
        MtxResponseDevice wearableDevice = CommonTestHelper.getMtxResponseDevice_Wearable();
        doReturn(serviceDevice).doReturn(wearableDevice).when(instance).queryDeviceData(
                any(), any(), any());

        instance.manualPay(input, output, null);
        MtxRequestMulti multiReq = multiArgumentCaptor.getValue();        
        MtxRequestSubscriberRecharge subRech =(MtxRequestSubscriberRecharge) multiReq.getRequestList().get(0);
        printUnitTest(subRech.toJson());
        VisibleRechargeExtension extn = (VisibleRechargeExtension) subRech.getRechargeAttr();
        assertNull(extn.getRatePlan());
        assertNull(extn.getPlanAmount());        
        assertNull(extn.getServiceMDN());
        
        assertNull(extn.getWearableRatePlan());
        assertNull(extn.getWearablePlanAmount());
        assertNull(extn.getWearableMDN());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_manualPay_When_ServiceWithFreeAddon_No_WearableDevice_ChargeAll_Then_ServiceMDN_In_RechargeAttr")
    @Tag("VER-655")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription  has service device. No wearable device. Enrolled in plusannual with free addon.|"
                +"|     |In 12th month, need to pay for renewal of next year.|"
                +"|When |Api called to renew for next year.|"
                +"|Then |Recharge request has recharge attributes with service device details.|"})
    // @formatter:on
    public void test_manualPay_When_ServiceWithFreeAddon_No_WearableDevice_ChargeAll_Then_ServiceMDN_In_RechargeAttr(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        ManualPayResponse output = new ManualPayResponse();
        String subExternalId = "1234";
        MtxResponseWallet wallet = emulateMtxResponseWallet(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        VisibleOfferDetails vod = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.PLUS3ANNUAL, wallet.getBillingCycle());

        ManualPayRequest input = CommonTestHelper.getManualPayRequest(
                subExternalId, vod.getPayableAmount());
        input.getVisibleOfferDetailsListAppender().add(vod);
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                instance, CommonTestHelper.getMtxResponseSubscription(
                        subExternalId, List.of(CI_EXTERNAL_IDS.PLUS3ANNUAL), 1));
        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.PLUS3ANNUAL);
        
        ArgumentCaptor<MtxRequestMulti> multiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti multiManualPay = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(multiManualPay).when(instance).multiRequest(
                any(), any(), multiArgumentCaptor.capture());

        MtxResponseDevice serviceDevice = CommonTestHelper.getMtxResponseDevice_Default();

        doReturn(serviceDevice).when(instance).queryDeviceData(any(), any(), any());

        printUnitTest(subscription.toJson());

        instance.manualPay(input, output, null);
        MtxRequestMulti multiReq = multiArgumentCaptor.getValue();        
        MtxRequestSubscriberRecharge subRech =(MtxRequestSubscriberRecharge) multiReq.getRequestList().get(0);
        printUnitTest(subRech.toJson());
        VisibleRechargeExtension extn = (VisibleRechargeExtension) subRech.getRechargeAttr();
        assertEquals(vod.getCatalogItemExternalId(), extn.getRatePlan());
        assertEquals(vod.getChargeAmount().intValue()+"", extn.getPlanAmount());
        VisibleDeviceExtension devExtn =(VisibleDeviceExtension)serviceDevice.getAttr();        
        assertEquals(devExtn.getAtAccessNumberArray(0).toString(), extn.getServiceMDN());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_manualPay_When_ServiceWithFreeAddon_Has_Wearable_Device_ChargeAll_Then_BothMDN_In_RechargeAttr")
    @Tag("VER-655")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription  has service and wearable device. Enrolled in plusannual with free addon.|"
                +"|     |In 12th month, need to pay for renewal of next year.|"
                +"|When |Api called to renew for next year.|"
                +"|Then |Recharge request has recharge attributes with service and wearable device details.|"})
    // @formatter:on
    public void test_manualPay_When_ServiceWithFreeAddon_Has_Wearable_Device_ChargeAll_Then_BothMDN_In_RechargeAttr(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        ManualPayResponse output = new ManualPayResponse();
        String subExternalId = "1234";
        MtxResponseWallet wallet = emulateMtxResponseWallet(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        VisibleOfferDetails vodSvc = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.PLUS3ANNUAL, wallet.getBillingCycle());
        VisibleOfferDetails vodAddon = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.WEARABLE_ANNUAL_2023, wallet.getBillingCycle());

        ManualPayRequest input = CommonTestHelper.getManualPayRequest(
                subExternalId, vodSvc.getPayableAmount());
        input.getVisibleOfferDetailsListAppender().add(vodSvc);
        input.getVisibleOfferDetailsListAppender().add(vodAddon);
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                instance, CommonTestHelper.getMtxResponseSubscription(
                        subExternalId, List.of(CI_EXTERNAL_IDS.PLUS3ANNUAL,CI_EXTERNAL_IDS.WEARABLE_ANNUAL_2023), 2));
        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.PLUS3ANNUAL);
        
        ArgumentCaptor<MtxRequestMulti> multiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti multiManualPay = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(multiManualPay).when(instance).multiRequest(
                any(), any(), multiArgumentCaptor.capture());

        MtxResponseDevice serviceDevice = CommonTestHelper.getMtxResponseDevice_Default();
        MtxResponseDevice wearableDevice = CommonTestHelper.getMtxResponseDevice_Wearable();
        doReturn(serviceDevice).doReturn(wearableDevice).when(instance).queryDeviceData(
                any(), any(), any());

        printUnitTest(subscription.toJson());

        instance.manualPay(input, output, null);
        MtxRequestMulti multiReq = multiArgumentCaptor.getValue();        
        MtxRequestSubscriberRecharge subRech =(MtxRequestSubscriberRecharge) multiReq.getRequestList().get(0);
        printUnitTest(subRech.toJson());
        VisibleRechargeExtension extn = (VisibleRechargeExtension) subRech.getRechargeAttr();
        assertEquals(vodSvc.getCatalogItemExternalId(), extn.getRatePlan());
        assertEquals(vodSvc.getChargeAmount().intValue()+"", extn.getPlanAmount());
        VisibleDeviceExtension svcExtn =(VisibleDeviceExtension)serviceDevice.getAttr();        
        assertEquals(svcExtn.getAtAccessNumberArray(0).toString(), extn.getServiceMDN());
        
        assertEquals(vodAddon.getCatalogItemExternalId(), extn.getWearableRatePlan());
        assertEquals(vodAddon.getChargeAmount().intValue()+"", extn.getWearablePlanAmount());
        VisibleDeviceExtension addonExtn =(VisibleDeviceExtension)wearableDevice.getAttr();        
        assertEquals(addonExtn.getAtAccessNumberArray(0).toString(), extn.getWearableMDN());
    }

    @SuppressWarnings({
        "unchecked"
    })
    @ParameterizedTest(name = "test_manualPay_When_PaidAddon_ChargeAddon_Then_Wearable_MDN_In_RechargeReq")
    @Tag("VER-655")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription  has service and wearable device. Enrolled in baseannual with paid addon.|"
                +"|     |In first 11 months of service.|"
                +"|When |Api called betwen 1st to 11th month to pay.|"
                +"|Then |Recharge request has recharge attributes with wearable device details.|"})
    // @formatter:on
    public void test_manualPay_When_PaidAddon_ChargeAddon_Then_Wearable_MDN_In_RechargeReq(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        ManualPayResponse output = new ManualPayResponse();
        String subExternalId = "1234";
        MtxResponseWallet wallet = emulateMtxResponseWallet(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        VisibleOfferDetails vodSvc = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.BASE3ANNUAL, wallet.getBillingCycle(),false);
        VisibleOfferDetails vodAddon = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023,wallet.getBillingCycle());

        ManualPayRequest input = CommonTestHelper.getManualPayRequest(
                subExternalId, vodAddon.getPayableAmount());
        input.getVisibleOfferDetailsListAppender().add(vodSvc);
        input.getVisibleOfferDetailsListAppender().add(vodAddon);
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                instance, CommonTestHelper.getMtxResponseSubscription(
                        subExternalId, List.of(CI_EXTERNAL_IDS.BASE3ANNUAL,CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023), 2));
        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023);
        
        ArgumentCaptor<MtxRequestMulti> multiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti multiManualPay = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(multiManualPay).when(instance).multiRequest(
                any(), any(), multiArgumentCaptor.capture());

        MtxResponseDevice serviceDevice = CommonTestHelper.getMtxResponseDevice_Default();
        MtxResponseDevice wearableDevice = CommonTestHelper.getMtxResponseDevice_Wearable();
        doReturn(serviceDevice).doReturn(wearableDevice).when(instance).queryDeviceData(
                any(), any(), any());

        printUnitTest(subscription.toJson());

        instance.manualPay(input, output, null);
        MtxRequestMulti multiReq = multiArgumentCaptor.getValue();        
        MtxRequestSubscriberRecharge subRech =(MtxRequestSubscriberRecharge) multiReq.getRequestList().get(0);
        printUnitTest(subRech.toJson());
        VisibleRechargeExtension extn = (VisibleRechargeExtension) subRech.getRechargeAttr();
        
        assertEquals(vodAddon.getCatalogItemExternalId(), extn.getWearableRatePlan());
        assertEquals(vodAddon.getChargeAmount().intValue()+"", extn.getWearablePlanAmount());
        VisibleDeviceExtension addonExtn =(VisibleDeviceExtension)wearableDevice.getAttr();        
        assertEquals(addonExtn.getAtAccessNumberArray(0).toString(), extn.getWearableMDN());
    }
    
    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_manualPay_When_ServiceWithPaidAddon_ChargeAll_Then_BothMDN_In_RechargeAttr")
    @Tag("VER-655")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription  has service and wearable device. Enrolled in baseannual with paid addon.|"
                +"|     |In 12th month, need to pay for renewal of next year.|"
                +"|When |Api called to renew for next year.|"
                +"|Then |Recharge request has recharge attributes with both service and wearable device details.|"})
    // @formatter:on
    public void test_manualPay_When_ServiceWithPaidAddon_ChargeAll_Then_BothMDN_In_RechargeAttr(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        ManualPayResponse output = new ManualPayResponse();
        String subExternalId = "1234";
        MtxResponseWallet wallet = emulateMtxResponseWallet(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        VisibleOfferDetails vodSvc = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.BASE3ANNUAL, wallet.getBillingCycle());
        VisibleOfferDetails vodAddon = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023,wallet.getBillingCycle());

        ManualPayRequest input = CommonTestHelper.getManualPayRequest(
                subExternalId, vodAddon.getPayableAmount().add(vodSvc.getPayableAmount()));
        input.getVisibleOfferDetailsListAppender().add(vodSvc);
        input.getVisibleOfferDetailsListAppender().add(vodAddon);
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                instance, CommonTestHelper.getMtxResponseSubscription(
                        subExternalId, List.of(CI_EXTERNAL_IDS.BASE3ANNUAL,CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023), 2));
        emulateMtxResponsePricingCatalogItems(instance,List.of(CI_EXTERNAL_IDS.BASE3ANNUAL,CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023));
        
        ArgumentCaptor<MtxRequestMulti> multiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti multiManualPay = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(multiManualPay).when(instance).multiRequest(
                any(), any(), multiArgumentCaptor.capture());

        MtxResponseDevice serviceDevice = CommonTestHelper.getMtxResponseDevice_Default();
        MtxResponseDevice wearableDevice = CommonTestHelper.getMtxResponseDevice_Wearable();
        doReturn(serviceDevice).doReturn(wearableDevice).when(instance).queryDeviceData(
                any(), any(), any());

        printUnitTest(subscription.toJson());

        instance.manualPay(input, output, null);
        MtxRequestMulti multiReq = multiArgumentCaptor.getValue();        
        MtxRequestSubscriberRecharge subRech =(MtxRequestSubscriberRecharge) multiReq.getRequestList().get(0);
        printUnitTest(subRech.toJson());
        VisibleRechargeExtension extn = (VisibleRechargeExtension) subRech.getRechargeAttr();
        assertEquals(vodSvc.getCatalogItemExternalId(), extn.getRatePlan());
        assertEquals(vodSvc.getChargeAmount().intValue()+"", extn.getPlanAmount());
        VisibleDeviceExtension svcExtn =(VisibleDeviceExtension)serviceDevice.getAttr();        
        assertEquals(svcExtn.getAtAccessNumberArray(0).toString(), extn.getServiceMDN());
        
        assertEquals(vodAddon.getCatalogItemExternalId(), extn.getWearableRatePlan());
        assertEquals(vodAddon.getChargeAmount().intValue()+"", extn.getWearablePlanAmount());
        VisibleDeviceExtension addonExtn =(VisibleDeviceExtension)wearableDevice.getAttr();        
        assertEquals(addonExtn.getAtAccessNumberArray(0).toString(), extn.getWearableMDN());    
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_manualPay_When_MonthlyServiceWithFreeAddon_No_WearableDevice_ChargeAll_Then_ServiceMDN_In_RechargeAttr")
    @Tag("VER-655")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription  has service device. Has no wearable device. Enrolled in plus monthly with free addon.|"     
                +"|When |Api called to renew.|"
                +"|Then |Recharge request has recharge attributes with service device details.|"})
    // @formatter:on
    public void test_manualPay_When_MonthlyServiceWithFreeAddon_No_WearableDevice_ChargeAll_Then_ServiceMDN_In_RechargeAttr(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        ManualPayResponse output = new ManualPayResponse();
        String subExternalId = "1234";
        MtxResponseWallet wallet = emulateMtxResponseWallet(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        VisibleOfferDetails vodSvc = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.PLUS3VIS23WB, wallet.getBillingCycle());
        VisibleOfferDetails vodAddon = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION,wallet.getBillingCycle());

        ManualPayRequest input = CommonTestHelper.getManualPayRequest(
                subExternalId, vodAddon.getPayableAmount().add(vodSvc.getPayableAmount()));
        input.getVisibleOfferDetailsListAppender().add(vodSvc);
        input.getVisibleOfferDetailsListAppender().add(vodAddon);
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                instance, CommonTestHelper.getMtxResponseSubscription(
                        subExternalId, List.of(CI_EXTERNAL_IDS.PLUS3VIS23WB,CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION), 1));
        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.PLUS3VIS23WB);
        
        ArgumentCaptor<MtxRequestMulti> multiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti multiManualPay = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(multiManualPay).when(instance).multiRequest(
                any(), any(), multiArgumentCaptor.capture());

        MtxResponseDevice serviceDevice = CommonTestHelper.getMtxResponseDevice_Default();
        doReturn(serviceDevice).when(instance).queryDeviceData(
                any(), any(), any());

        printUnitTest(subscription.toJson());

        instance.manualPay(input, output, null);
        MtxRequestMulti multiReq = multiArgumentCaptor.getValue();        
        MtxRequestSubscriberRecharge subRech =(MtxRequestSubscriberRecharge) multiReq.getRequestList().get(0);
        printUnitTest(subRech.toJson());
        VisibleRechargeExtension extn = (VisibleRechargeExtension) subRech.getRechargeAttr();
        assertEquals(vodSvc.getCatalogItemExternalId(), extn.getRatePlan());
        assertEquals(vodSvc.getChargeAmount().intValue()+"", extn.getPlanAmount());
        VisibleDeviceExtension svcExtn =(VisibleDeviceExtension)serviceDevice.getAttr();        
        assertEquals(svcExtn.getAtAccessNumberArray(0).toString(), extn.getServiceMDN());
        
        assertNull(extn.getWearableRatePlan());  
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_manualPay_When_MonthlyServiceWithFreeAddon_Has_WearableDevice_ChargeAll_Then_BothMDN_In_RechargeAttr")
    @Tag("VER-655")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription  has service and wearable device. Enrolled in plus monthly with free addon.|"     
                +"|When |Api called to renew.|"
                +"|Then |Recharge request has recharge attributes with service and wearable device details.|"})
    // @formatter:on
    public void test_manualPay_When_MonthlyServiceWithFreeAddon_Has_WearableDevice_ChargeAll_Then_BothMDN_In_RechargeAttr(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        ManualPayResponse output = new ManualPayResponse();
        String subExternalId = "1234";
        MtxResponseWallet wallet = emulateMtxResponseWallet(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        VisibleOfferDetails vodSvc = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.PLUS3VIS23WB, wallet.getBillingCycle());
        VisibleOfferDetails vodAddon = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION,wallet.getBillingCycle());

        ManualPayRequest input = CommonTestHelper.getManualPayRequest(
                subExternalId, vodAddon.getPayableAmount().add(vodSvc.getPayableAmount()));
        input.getVisibleOfferDetailsListAppender().add(vodSvc);
        input.getVisibleOfferDetailsListAppender().add(vodAddon);
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                instance, CommonTestHelper.getMtxResponseSubscription(
                        subExternalId, List.of(CI_EXTERNAL_IDS.PLUS3VIS23WB,CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION), 2));
        emulateMtxResponsePricingCatalogItem(instance,CI_EXTERNAL_IDS.PLUS3VIS23WB);
        
        ArgumentCaptor<MtxRequestMulti> multiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti multiManualPay = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(multiManualPay).when(instance).multiRequest(
                any(), any(), multiArgumentCaptor.capture());

        MtxResponseDevice serviceDevice = CommonTestHelper.getMtxResponseDevice_Default();
        MtxResponseDevice wearableDevice = CommonTestHelper.getMtxResponseDevice_Wearable();
        doReturn(serviceDevice).doReturn(wearableDevice).when(instance).queryDeviceData(
                any(), any(), any());

        printUnitTest(subscription.toJson());

        instance.manualPay(input, output, null);
        MtxRequestMulti multiReq = multiArgumentCaptor.getValue();        
        MtxRequestSubscriberRecharge subRech =(MtxRequestSubscriberRecharge) multiReq.getRequestList().get(0);
        printUnitTest(subRech.toJson());
        VisibleRechargeExtension extn = (VisibleRechargeExtension) subRech.getRechargeAttr();
        assertEquals(vodSvc.getCatalogItemExternalId(), extn.getRatePlan());
        assertEquals(vodSvc.getChargeAmount().intValue()+"", extn.getPlanAmount());
        VisibleDeviceExtension svcExtn =(VisibleDeviceExtension)serviceDevice.getAttr();        
        assertEquals(svcExtn.getAtAccessNumberArray(0).toString(), extn.getServiceMDN());
        
        assertEquals(vodAddon.getCatalogItemExternalId(), extn.getWearableRatePlan());
        assertEquals(vodAddon.getChargeAmount().intValue()+"", extn.getWearablePlanAmount());
        VisibleDeviceExtension addonExtn =(VisibleDeviceExtension)wearableDevice.getAttr();        
        assertEquals(addonExtn.getAtAccessNumberArray(0).toString(), extn.getWearableMDN());  
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_manualPay_When_MonthlyServiceWithPaidAddon_Has_WearableDevice_ChargeAll_Then_BothMDN_In_RechargeAttr")
    @Tag("VER-655")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription  has service and wearable device. Enrolled in base monthly with paid addon.|"     
                +"|When |Api called to renew.|"
                +"|Then |Recharge request has recharge attributes with service and wearable device details.|"})
    // @formatter:on
    public void test_manualPay_When_MonthlyServiceWithPaidAddon_Has_WearableDevice_ChargeAll_Then_BothMDN_In_RechargeAttr(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        ManualPayResponse output = new ManualPayResponse();
        String subExternalId = "1234";
        MtxResponseWallet wallet = emulateMtxResponseWallet(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        VisibleOfferDetails vodSvc = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.BASE3VIS23, wallet.getBillingCycle());
        VisibleOfferDetails vodAddon = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023,wallet.getBillingCycle());

        ManualPayRequest input = CommonTestHelper.getManualPayRequest(
                subExternalId, vodAddon.getPayableAmount().add(vodSvc.getPayableAmount()));
        input.getVisibleOfferDetailsListAppender().add(vodSvc);
        input.getVisibleOfferDetailsListAppender().add(vodAddon);
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                instance, CommonTestHelper.getMtxResponseSubscription(
                        subExternalId, List.of(CI_EXTERNAL_IDS.BASE3VIS23,CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023), 2));
        emulateMtxResponsePricingCatalogItems(instance, List.of(CI_EXTERNAL_IDS.BASE3VIS23,CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023));
        
        ArgumentCaptor<MtxRequestMulti> multiArgumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        MtxResponseMulti multiManualPay = CommonTestHelper.getEmptyMtxResponseMulti();
        doReturn(multiManualPay).when(instance).multiRequest(
                any(), any(), multiArgumentCaptor.capture());

        MtxResponseDevice serviceDevice = CommonTestHelper.getMtxResponseDevice_Default();
        MtxResponseDevice wearableDevice = CommonTestHelper.getMtxResponseDevice_Wearable();
        doReturn(serviceDevice).doReturn(wearableDevice).when(instance).queryDeviceData(
                any(), any(), any());

        printUnitTest(subscription.toJson());

        instance.manualPay(input, output, null);
        MtxRequestMulti multiReq = multiArgumentCaptor.getValue();        
        MtxRequestSubscriberRecharge subRech =(MtxRequestSubscriberRecharge) multiReq.getRequestList().get(0);
        printUnitTest(subRech.toJson());
        VisibleRechargeExtension extn = (VisibleRechargeExtension) subRech.getRechargeAttr();
        assertEquals(vodSvc.getCatalogItemExternalId(), extn.getRatePlan());
        assertEquals(vodSvc.getChargeAmount().intValue()+"", extn.getPlanAmount());
        VisibleDeviceExtension svcExtn =(VisibleDeviceExtension)serviceDevice.getAttr();        
        assertEquals(svcExtn.getAtAccessNumberArray(0).toString(), extn.getServiceMDN());
        
        assertEquals(vodAddon.getCatalogItemExternalId(), extn.getWearableRatePlan());
        assertEquals(vodAddon.getChargeAmount().intValue()+"", extn.getWearablePlanAmount());
        VisibleDeviceExtension addonExtn =(VisibleDeviceExtension)wearableDevice.getAttr();        
        assertEquals(addonExtn.getAtAccessNumberArray(0).toString(), extn.getWearableMDN());  
    }
    
    /************************************************
     * Private Methods
     * 
     * @throws VisibleUnitTestException
     **************************************/
    private void printUnitTest(Object msg) {
        System.out.println(testInfo.getDisplayName() + ":" +msg);
    }

    private MtxResponseSubscription emulateMtxResponseSubscription(String filePath)
            throws IOException, VisibleUnitTestException {
        MtxResponseSubscription subscriber = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class, filePath);
        doReturn(subscriber).when(api).subscriptionQuery(any(), any());
        return subscriber;
    }
}
