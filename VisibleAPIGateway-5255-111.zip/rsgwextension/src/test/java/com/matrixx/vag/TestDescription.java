package com.matrixx.vag;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;

public class TestDescription {
    
    public String[] given;
    public String[] when;
    public String[] then;
    public String[] comments;
    public TestInfo testInfo;

    public TestDescription(){ }
    
    public TestDescription(TestInfo testInfo, ArgumentsAccessor argumentsAccessor){
        this.testInfo = testInfo;
        setAcceptance(argumentsAccessor);
    }
    public void printDescription() {
        System.out.println();
        String header;
        String testMethod = testInfo != null ? testInfo.getDisplayName() : "";
        header = "--------------" + testMethod + "--------------";
        System.out.println(header);

        if (given != null && given.length > 0) {
            for (int i = 0; i < given.length; i++) {
                if (i == 0) {
                    System.out.println("Given: " + given[i]);
                } else {
                    System.out.println("     : " + given[i]);
                }
            }
        }
        if (when != null && when.length > 0) {
            for (int i = 0; i < when.length; i++) {
                if (i == 0) {
                    System.out.println("When: " + when[i]);
                } else {
                    System.out.println("    : " + when[i]);
                }
            }
        }
        if (then != null && then.length > 0) {
            for (int i = 0; i < then.length; i++) {
                if (i == 0) {
                    System.out.println("Then: " + then[i]);
                } else {
                    System.out.println("    : " + then[i]);
                }
            }
        }

        if (comments != null && comments.length > 0) {
            System.out.println("Comments: " + String.join("|", comments));
        }

        if (testInfo != null && testInfo.getTags() != null) {
            System.out.println("Tags: " + testInfo.getTags());
        }

        System.out.println(StringUtils.repeat("-", header.length()));
    }

    public String getTestMethod() {
        return testInfo != null ? testInfo.getDisplayName() : "";
    };

    private void setAcceptance(ArgumentsAccessor argumentsAccessor) {
        String argType = "";
        List<String> givenList = new ArrayList<String>();
        List<String> whenList = new ArrayList<String>();
        List<String> thenList = new ArrayList<String>();
        List<String> commentList = new ArrayList<String>();
        for (Object arg : argumentsAccessor.toArray()) {
            if(arg==null || StringUtils.isBlank(arg.toString())) {
                continue;
            }
            if (arg.toString().trim().equalsIgnoreCase("given")) {
                argType = "given";
                continue;
            }

            if (arg.toString().trim().equalsIgnoreCase("when")) {
                argType = "when";
                continue;
            }

            if (arg.toString().trim().equalsIgnoreCase("then")) {
                argType = "then";
                continue;
            }

            if (arg.toString().trim().equalsIgnoreCase("comments")) {
                argType = "comments";
                continue;
            }

            if (argType.equalsIgnoreCase("given")) {
                givenList.add(arg.toString());
            }

            if (argType.equalsIgnoreCase("when")) {
                whenList.add(arg.toString());
            }

            if (argType.equalsIgnoreCase("then")) {
                thenList.add(arg.toString());
            }
            
            if (argType.equalsIgnoreCase("comments")) {
                thenList.add(arg.toString());
            }

        }

        given = givenList.toArray(new String[givenList.size()]);
        when = whenList.toArray(new String[whenList.size()]);
        then = thenList.toArray(new String[thenList.size()]);
        comments = thenList.toArray(new String[commentList.size()]);
    }
}
