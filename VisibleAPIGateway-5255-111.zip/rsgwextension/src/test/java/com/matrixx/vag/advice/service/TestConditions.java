package com.matrixx.vag.advice.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.matrixx.datacontainer.MtxDate;
import com.matrixx.vag.CommonTestHelper;

public class TestConditions {
	public String testNum;
	public String oldCi;
	public String newCi;
	public boolean hasWearable = false;
	public boolean hasInsurance = false;
	public MtxDate paidCycleStartDate = null;
	public double aocDelta = 0;
	public double fixedFee = 0;
	public int minimumCharge = 5;

	public boolean vbppEligible = false;
	public double vbppRecEvent = 0;
	public boolean chimeEligible = false;
	public double chimeRecEvent = 0;
	public double otherPromos = 0;
	public double partyPayRecEvent = 0;
	public double partyPayAoc = 0;

	// Try to use below maps for most of the conditions.
	// Get rid / Phase out above specific variables.
	public Map<String, Object> promoMap = new HashMap<String, Object>();
	public Map<String, Object> conditionMap = new HashMap<String, Object>();
	public List<String> addOfferList = new ArrayList<String>();
	public List<String> cancelOfferList = new ArrayList<String>();
	public Map<String, Object> expResultsMap = new HashMap<String, Object>();
	
	public BigDecimal getOldCiPrice() {
		return CommonTestHelper.getOfferPrice(oldCi);
	}

	public BigDecimal getNewCiPrice() {
		return CommonTestHelper.getOfferPrice(newCi);
	}
	TestConditions(){}
	TestConditions(String asisCi,String tobeCi){
	    this.oldCi = asisCi;
	    this.newCi = tobeCi;
	}
}

