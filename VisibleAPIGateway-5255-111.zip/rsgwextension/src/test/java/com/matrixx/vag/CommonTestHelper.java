
/**
 *
 */
package com.matrixx.vag;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.runner.notification.StoppedByUserException;
import org.mockito.invocation.InvocationOnMock;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixx.datacontainer.BaseContainer;
import com.matrixx.datacontainer.DataContainer;
import com.matrixx.datacontainer.DataContainerFactory;
import com.matrixx.datacontainer.MtxDate;
import com.matrixx.datacontainer.MtxObjectId;
import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.mdc.BalanceInfo;
import com.matrixx.datacontainer.mdc.EventQueryEventInfo;
import com.matrixx.datacontainer.mdc.EventQueryResponseEvents;
import com.matrixx.datacontainer.mdc.ManualPayRequest;
import com.matrixx.datacontainer.mdc.MtxBalanceImpactInfo;
import com.matrixx.datacontainer.mdc.MtxBalanceImpactInfoGroup;
import com.matrixx.datacontainer.mdc.MtxBalanceImpactOfferInfo;
import com.matrixx.datacontainer.mdc.MtxBalanceInfo;
import com.matrixx.datacontainer.mdc.MtxBalanceInfoSimple;
import com.matrixx.datacontainer.mdc.MtxBalanceTransferEvent;
import com.matrixx.datacontainer.mdc.MtxBalanceUpdate;
import com.matrixx.datacontainer.mdc.MtxBillingCycleInfo;
import com.matrixx.datacontainer.mdc.MtxEventAppliedBundle;
import com.matrixx.datacontainer.mdc.MtxEventAppliedCatalogItem;
import com.matrixx.datacontainer.mdc.MtxEventAppliedOffer;
import com.matrixx.datacontainer.mdc.MtxEventCharge;
import com.matrixx.datacontainer.mdc.MtxPaymentAuthorizationEvent;
import com.matrixx.datacontainer.mdc.MtxPaymentInfo;
import com.matrixx.datacontainer.mdc.MtxPaymentMethodInfo;
import com.matrixx.datacontainer.mdc.MtxPaymentRefundInfo;
import com.matrixx.datacontainer.mdc.MtxPricingBundleDetailInfo;
import com.matrixx.datacontainer.mdc.MtxPricingCatalogItemDetailInfo;
import com.matrixx.datacontainer.mdc.MtxPricingOfferDetailInfo;
import com.matrixx.datacontainer.mdc.MtxPurchaseInfo;
import com.matrixx.datacontainer.mdc.MtxPurchasedItemCycleInfo;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.MtxRechargeEvent;
import com.matrixx.datacontainer.mdc.MtxRecurringEvent;
import com.matrixx.datacontainer.mdc.MtxRequiredBalanceInfo;
import com.matrixx.datacontainer.mdc.MtxResponse;
import com.matrixx.datacontainer.mdc.MtxResponseCancel;
import com.matrixx.datacontainer.mdc.MtxResponseDevice;
import com.matrixx.datacontainer.mdc.MtxResponseGroup;
import com.matrixx.datacontainer.mdc.MtxResponseMulti;
import com.matrixx.datacontainer.mdc.MtxResponsePaymentHistory;
import com.matrixx.datacontainer.mdc.MtxResponsePricingBalance;
import com.matrixx.datacontainer.mdc.MtxResponsePricingCatalogItem;
import com.matrixx.datacontainer.mdc.MtxResponsePricingOffer;
import com.matrixx.datacontainer.mdc.MtxResponsePurchase;
import com.matrixx.datacontainer.mdc.MtxResponseRecurringChargeInfo;
import com.matrixx.datacontainer.mdc.MtxResponseRefundPayment;
import com.matrixx.datacontainer.mdc.MtxResponseSubscriber;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.MtxResponseUser;
import com.matrixx.datacontainer.mdc.MtxResponseWallet;
import com.matrixx.datacontainer.mdc.MtxSecondaryEvent;
import com.matrixx.datacontainer.mdc.MtxSubscriberExtension;
import com.matrixx.datacontainer.mdc.MtxSubscriberSearchData;
import com.matrixx.datacontainer.mdc.PricingBalanceDetailInfo;
import com.matrixx.datacontainer.mdc.PurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.RefundServiceEventGroup;
import com.matrixx.datacontainer.mdc.SubscriptionResponse;
import com.matrixx.datacontainer.mdc.VisibleApiEventData;
import com.matrixx.datacontainer.mdc.VisibleAttribute;
import com.matrixx.datacontainer.mdc.VisibleCAGroupExtension;
import com.matrixx.datacontainer.mdc.VisibleCatalogItem;
import com.matrixx.datacontainer.mdc.VisibleChangeCycle;
import com.matrixx.datacontainer.mdc.VisibleChangeOfferInfo;
import com.matrixx.datacontainer.mdc.VisibleChangeServiceCredit;
import com.matrixx.datacontainer.mdc.VisibleChangeServicePromo;
import com.matrixx.datacontainer.mdc.VisibleCredits;
import com.matrixx.datacontainer.mdc.VisibleDeviceExtension;
import com.matrixx.datacontainer.mdc.VisibleGiftingServiceInfo;
import com.matrixx.datacontainer.mdc.VisibleMultiRequestPurchaseService;
import com.matrixx.datacontainer.mdc.VisibleOfferDetails;
import com.matrixx.datacontainer.mdc.VisiblePromoExtension;
import com.matrixx.datacontainer.mdc.VisiblePurchaseInfo;
import com.matrixx.datacontainer.mdc.VisiblePurchaseServiceInfo;
import com.matrixx.datacontainer.mdc.VisiblePurchaseServiceOrderInfo;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleRechargeExtension;
import com.matrixx.datacontainer.mdc.VisibleRefundServiceOrderInfo;
import com.matrixx.datacontainer.mdc.VisibleRequestCaLink;
import com.matrixx.datacontainer.mdc.VisibleRequestCaUnlink;
import com.matrixx.datacontainer.mdc.VisibleRequestChangeService;
import com.matrixx.datacontainer.mdc.VisibleRequestChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleRequestChargeNrf;
import com.matrixx.datacontainer.mdc.VisibleRequestGiftService;
import com.matrixx.datacontainer.mdc.VisibleRequestPurchaseDevice;
import com.matrixx.datacontainer.mdc.VisibleRequestPurchaseService;
import com.matrixx.datacontainer.mdc.VisibleRequestQuoteAdviceService;
import com.matrixx.datacontainer.mdc.VisibleRequestRecharge;
import com.matrixx.datacontainer.mdc.VisibleRequestRefundService;
import com.matrixx.datacontainer.mdc.VisibleRequestReverseNrf;
import com.matrixx.datacontainer.mdc.VisibleResponseChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleResponsePaymentAdviceService;
import com.matrixx.datacontainer.mdc.VisibleSubscriberDevice;
import com.matrixx.datacontainer.mdc.VisibleSubscriberExtension;
import com.matrixx.datacontainer.mdc.VisibleTemplate;
import com.matrixx.platform.JsonObject;
import com.matrixx.platform.XmlNode;
import com.matrixx.platform.XmlParser;
import com.matrixx.vag.advice.model.CreditStage;
import com.matrixx.vag.advice.model.GlobalCreditStage;
import com.matrixx.vag.advice.model.ServiceStage;
import com.matrixx.vag.advice.model.VisibleOfferDetailsInternal;
import com.matrixx.vag.advice.model.VisibleResponsePurchaseAdvice;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.CHANGE_SERVICE_CONSTANTS;
import com.matrixx.vag.common.Constants.CREDIT_CONSTANTS;
import com.matrixx.vag.common.Constants.CYCLE_PERIODS;
import com.matrixx.vag.common.Constants.DEVICE_CONSTANTS;
import com.matrixx.vag.common.Constants.MATRIXX_CONSTANTS;
import com.matrixx.vag.common.Constants.OFFER_CONSTANTS;
import com.matrixx.vag.common.Constants.PAYMENT_CONSTANTS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.Constants.SUBSCRIPTION_CONSTANTS;
import com.matrixx.vag.common.TestConstants;
import com.matrixx.vag.common.TestConstants.BALANCE_IDS;
import com.matrixx.vag.common.TestConstants.BALANCE_NAMES;
import com.matrixx.vag.common.TestConstants.CI_BUNDLES;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestConstants.DATA_DIR;
import com.matrixx.vag.common.TestConstants.OFFER_PRICES;
import com.matrixx.vag.common.TestConstants.OFFER_STATUS;
import com.matrixx.vag.common.TestConstants.OFFER_STATUS_INTEGER;
import com.matrixx.vag.common.TestConstants.SUBSCRIPTION_STATUS_INTEGER;
import com.matrixx.vag.common.TestConstants.TAX_CLASS_CODES;
import com.matrixx.vag.common.TestUtils;
import com.matrixx.vag.common.coverage.Generated;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.VisibleUnitTestException;
import com.matrixx.vag.tax.model.ServiceTaxRequest;
import com.matrixx.vag.tax.model.ServiceTaxResponse;
import com.matrixx.vag.util.MDCTest;

/**
 * @author CGI
 */
public class CommonTestHelper extends MDCTest {

    /**
     * Static only helper class
     */
    @Generated
    private CommonTestHelper() {
    }

    /**
     * Parses the JSON message text as the Mtx Message type.
     *
     * @param aClass
     * @param messageText
     * @return the Mtx Message
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    @SuppressWarnings("unchecked")
    public static <T extends BaseContainer> T parseJsonMessage(Class<T> aClass, String messageText)
            throws VisibleUnitTestException {
        DataContainer dc = new DataContainer(dcf);
        JsonObject jsonInput = new JsonObject();
        jsonInput.parse(messageText.replaceAll("\\\\t", ""));

        if (jsonInput.getString("$").equals("EventQueryResponseEvents")) {
            // This is workaround till mtx_config.xml and other updates are done. So that event
            // details can be loaded as-is from logs.
            jsonInput.getArray("EventList").forEach(eqei -> {
                JsonObject eventInfo = (JsonObject) eqei;
                eventInfo.remove("BalanceImpactList");
            });
        }
        jsonInput.remove("_testerComments");
        jsonInput.remove("_resultCode");
        jsonInput.remove("_resultText");
        jsonInput.remove("_resultType");
        dc.readFrom(jsonInput);
        T message;
        try {
            message = aClass.getDeclaredConstructor().newInstance();
            message.readFrom(dc);
        } catch (Exception ex) {
            throw new VisibleUnitTestException(ex);
        }

        return message;
    }

    @SuppressWarnings("unchecked")
    public static <T extends BaseContainer> T cloneContainer(T container)
            throws VisibleUnitTestException {
        DataContainer dc = new DataContainer(dcf);
        JsonObject jsonInput = new JsonObject();
        jsonInput.parse(container.toJson());
        dc.readFrom(jsonInput);
        T message;
        try {
            message = (T) container.getClass().getDeclaredConstructor().newInstance();
            message.readFrom(dc);
        } catch (Exception ex) {
            throw new VisibleUnitTestException(ex);
        }

        return message;
    }

    public static <T extends BaseContainer> T parseXmlMessage(Class<T> aClass, String messageText)
            throws Exception {
        XmlParser xmlParser = new XmlParser();
        XmlNode node = XmlNode.parse(xmlParser.parse(messageText));
        DataContainer dc = new DataContainer(dcf);
        dc.readFrom(node);
        T message = aClass.getDeclaredConstructor().newInstance();
        message.readFrom(dc);
        return message;
    }

    /**
     * Loads a JSON message file as the Mtx Message type.
     *
     * @param aClass
     *            The mtx message class
     * @param filePath
     *            path of the JSON file
     * @return the Mtx Message
     * @throws IOException
     * @throws InstantiationException
     * @throws IllegalAccessException
     * @throws VisibleUnitTestException
     */
    public static <T extends BaseContainer> T loadJsonMessage(Class<T> aClass, String filePath)
            throws VisibleUnitTestException, IOException {
        String messageText = new String(Files.readAllBytes(Paths.get(filePath)));
        return parseJsonMessage(aClass, messageText);
    }

    public static <T> T getJsonFromString(Class<T> aClass, String data)
            throws JsonParseException, JsonMappingException, IOException {
        return (new ObjectMapper()).readValue(data, aClass);
    }

    /**
     * Loads a JSON message file as the Mtx Message type. Removes a specified field if applicable
     *
     * @param aClass
     * @param filePath
     * @param removeField
     * @return
     * @throws IOException
     * @throws IllegalAccessException
     * @throws InstantiationException
     * @throws VisibleUnitTestException
     * @throws Exception
     */
    public static <T extends BaseContainer> T loadJsonMessage(Class<T> aClass,
                                                              String filePath,
                                                              String feildToRemove)
            throws VisibleUnitTestException, IOException {
        String messageText = new String(Files.readAllBytes(Paths.get(filePath)));

        if (StringUtils.strip(
                StringUtils.substringBetween(messageText, "\"$\":", ",").trim(), "\"").equals(
                        MtxResponseSubscriber.class.getSimpleName())) {
            messageText = remove_From_MtxResponseSubscriber(messageText, feildToRemove);
        } else if (StringUtils.strip(
                StringUtils.substringBetween(messageText, "\"$\":", ",").trim(), "\"").equals(
                        VisibleRequestChargeNrf.class.getSimpleName())) {
            messageText = remove_From_VisibleRequestChargeNrf(messageText, feildToRemove);
        } else if (StringUtils.strip(
                StringUtils.substringBetween(messageText, "\"$\":", ",").trim(), "\"").equals(
                        VisibleRequestReverseNrf.class.getSimpleName())) {
            messageText = remove_From_VisibleRequestReverseNrf(messageText, feildToRemove);
        } else if (StringUtils.strip(
                StringUtils.substringBetween(messageText, "\"$\":", ",").trim(), "\"").equals(
                        VisibleRequestRefundService.class.getSimpleName())) {
            messageText = remove_From_VisibleRequestRefundService(messageText, feildToRemove);
        } else if (StringUtils.strip(
                StringUtils.substringBetween(messageText, "\"$\":", ",").trim(), "\"").equals(
                        VisibleRequestPurchaseDevice.class.getSimpleName())) {
            messageText = remove_From_VisibleRequestPurchaseDevice(messageText, feildToRemove);
        } else if (StringUtils.strip(
                StringUtils.substringBetween(messageText, "\"$\":", ",").trim(), "\"").equals(
                        EventQueryResponseEvents.class.getSimpleName())) {
            messageText = remove_From_EventQueryResponseEvents(messageText, feildToRemove);
        } else {
            System.out.println("There is no code to remove requested field");
            throw new StoppedByUserException();
        }

        return parseJsonMessage(aClass, messageText);
    }

    /**
     * @param messageText
     * @param feildToRemove
     * @return
     */
    @SuppressWarnings("unchecked")
    private static String remove_From_EventQueryResponseEvents(String messageText,
                                                               String feildToRemove) {
        JsonObject jsonInput = new JsonObject();
        jsonInput.parse(messageText);

        switch (feildToRemove) {
            case "BalanceResourceId":
                jsonInput.getArray("EventList").forEach(eqei -> {
                    JsonObject eventInfo = (JsonObject) eqei;
                    JsonObject evenDetails = (JsonObject) eventInfo.get("EventDetails");
                    if (evenDetails.getArray("BalanceUpdateArray") != null) {
                        evenDetails.getArray("BalanceUpdateArray").forEach(bu -> {
                            JsonObject balUpdate = (JsonObject) bu;
                            balUpdate.remove("BalanceResourceId");
                            ;
                        });
                    }
                });
                break;
            default:
                break;
        }

        return jsonInput.toString();
    }

    @SuppressWarnings("rawtypes")
    public static String remove_UnusedFields(Object obj) {
        if (obj.getClass().getSimpleName().equals("JsonObject")) {
            for (String attribute : ((JsonObject) obj).getAttributeNames()) {
                if (((JsonObject) obj).get(attribute).getClass().getSimpleName().equals(
                        "ArrayList")) {
                    // JsonObjects
                    remove_UnusedFields(((JsonObject) obj).get(attribute));
                } else if (((JsonObject) obj).get(attribute).getClass().getSimpleName().equals(
                        "JsonObject")) {
                    if (attribute.equals("SysData")) {
                        ((JsonObject) obj).remove("SysData");
                    } else {
                        // JsonObjects
                        remove_UnusedFields(((JsonObject) obj).get(attribute));
                    }
                } else {
                    // non JsonObjects
                    if (attribute.equals("UpgradeRev")) {
                        ((JsonObject) obj).remove("UpgradeRev");
                    } else if (attribute.equals("ObjectId")) {
                        ((JsonObject) obj).remove("ObjectId");
                    } else if (attribute.equals("ExternalId")) {
                        ((JsonObject) obj).remove("ExternalId");
                    } else if (attribute.equals("RouteId")) {
                        ((JsonObject) obj).remove("RouteId");
                    } else if (attribute.equals("ClientSessionId")) {
                        ((JsonObject) obj).remove("ClientSessionId");
                    } else if (attribute.equals("EventTime")) {
                        ((JsonObject) obj).remove("EventTime");
                    } else if (attribute.equals("ExecuteMode")) {
                        ((JsonObject) obj).remove("ExecuteMode");
                    } else if (attribute.equals("Flags")) {
                        ((JsonObject) obj).remove("Flags");
                    } else if (attribute.equals("Version")) {
                        ((JsonObject) obj).remove("Version");
                    }
                }
            }
        } else if (obj.getClass().getSimpleName().equals("ArrayList")) {
            for (Object obj1 : (ArrayList) obj) {
                // List of JsonObjects
                if (obj1.getClass().getSimpleName().equals("JsonObject")
                        || obj1.getClass().getSimpleName().equals("ArrayList")) {
                    remove_UnusedFields(obj1);
                }
            }
        } else {
            System.out.println("dead code");
        }
        return obj.toString();
    }

    /**
     * @param messageText
     * @param feildToRemove
     * @return
     */
    private static String remove_From_VisibleRequestPurchaseDevice(String messageText,
                                                                   String feildToRemove) {
        JsonObject jsonInput = new JsonObject();
        jsonInput.parse(messageText);
        switch (feildToRemove) {
            case "PurchaseFraudInfo":
                jsonInput.remove(feildToRemove);
                break;
            default:
                break;
        }

        return jsonInput.toString();
    }

    /**
     * Remove node from subscriber
     *
     * @param messageText
     * @param feildToRemove
     * @return
     * @throws Exception
     */
    private static String remove_From_MtxResponseSubscriber(String messageText,
                                                            String feildToRemove)
            throws StoppedByUserException {
        JsonObject jsonInput = new JsonObject();
        jsonInput.parse(messageText);

        switch (feildToRemove) {
            case "Attr":
                jsonInput.remove("Attr");
                break;
            case "GeoCode":
                ((JsonObject) jsonInput.get("Attr")).remove("GeoCode");
                break;
            default:
                System.out.println("There is no code to remove requested field");
                throw new StoppedByUserException();
        }

        return jsonInput.toString();
    }

    /**
     * Remove node from Charge NFR
     *
     * @param messageText
     * @param feildToRemove
     * @return
     * @throws StoppedByUserException
     */
    public static String remove_From_VisibleRequestChargeNrf(String messageText,
                                                             String feildToRemove)
            throws StoppedByUserException {

        JsonObject jsonInput = new JsonObject();
        jsonInput.parse(messageText);
        switch (feildToRemove) {
            case "SubscriberExternalId":
                jsonInput.remove(feildToRemove);
                break;
            case "OrderId":
            case "PaymentMethod":
                ((JsonObject) jsonInput.get("NrfOrderInfo")).remove(feildToRemove);
                break;

            case "OfferSku":
            case "OfferExternalId":
            case "OfferGrossPrice":
            case "OfferDiscountPrice":
            case "OfferTaxDetails":
            case "OfferTotalTax":
            case "OfferDetails":
                ((JsonObject) jsonInput.get("NrfOfferInfo")).remove(feildToRemove);
                break;

            case "ShipToBid":
                ((JsonObject) jsonInput.get("NrfShippingInfo")).remove(feildToRemove);
                break;

            case "TransactionType":
            case "FraudHomeAddress":
            case "FraudShippingAddress":

                ((JsonObject) jsonInput.get("NrfFraudInfo")).remove(feildToRemove);
                break;

            default:
                System.out.println("There is no code to remove requested field");
                throw new StoppedByUserException();
        }

        return jsonInput.toString();
    }

    @SuppressWarnings("unchecked")
    public static String remove_From_VisibleMultiRequestPurchaseService(String messageText,
                                                                        String feildToRemove)
            throws StoppedByUserException {
        JsonObject jsonInput = new JsonObject();
        jsonInput.parse(messageText);
        switch (feildToRemove) {
            case "ServiceTaxDetails":
                jsonInput.getArray("PurchaseInfo").forEach(jo -> {
                    ((JsonObject) ((JsonObject) jo).get("PurchaseServiceInfo")).remove(
                            feildToRemove);
                });
                break;
            default:
                System.out.println("There is no code to remove requested field");
                throw new StoppedByUserException();
        }

        return jsonInput.toString();

    }

    /**
     * Remove node from Reverse NFR
     *
     * @param messageText
     * @param feildToRemove
     * @return
     * @throws StoppedByUserException
     */
    public static String remove_From_VisibleRequestReverseNrf(String messageText,
                                                              String feildToRemove)
            throws StoppedByUserException {

        JsonObject jsonInput = new JsonObject();
        jsonInput.parse(messageText);
        switch (feildToRemove) {
            case "SubscriberExternalId":
                jsonInput.remove(feildToRemove);
                break;
            case "OfferExternalId":
            case "OriginalOrderDate":
            case "OriginalOrderId":
            case "ReturnOrderId":
                ((JsonObject) jsonInput.get("CancelNrfOrderInfo")).remove(feildToRemove);
                break;
            default:
                System.out.println("There is no code to remove requested field");
                throw new StoppedByUserException();
        }

        return jsonInput.toString();
    }

    /**
     * * Remove node from Reverse VisibleRequestRefundService
     *
     * @param messageText
     * @param feildToRemove
     * @return
     */
    private static String remove_From_VisibleRequestRefundService(String messageText,
                                                                  String feildToRemove) {
        JsonObject jsonInput = new JsonObject();
        jsonInput.parse(messageText);
        switch (feildToRemove) {
            case "RefundType":
                jsonInput.remove(feildToRemove);
                break;

            case "CancelServices":
                ((JsonObject) jsonInput.get("RefundServiceOrderInfo")).remove(feildToRemove);
                break;

            default:
                break;
        }

        return jsonInput.toString();
    }

    public static MtxResponseSubscriber getSubscriberResponse(MtxResponseMulti multiResPricing) {
        for (MtxResponse response : multiResPricing.getResponseList()) {
            if (response instanceof MtxResponseSubscriber) {
                return (MtxResponseSubscriber) response;
            }
        }
        return null;
    }

    public static JsonObject parseStringToJson(String messageText)
            throws InstantiationException, IllegalAccessException {
        JsonObject jsonInput = new JsonObject();
        jsonInput.parse(messageText);
        return jsonInput;
    }

    public static MtxResponseSubscriber removeCiInSubscriber(List<String> ciList,
                                                             MtxResponseSubscriber subscriber) {
        List<Integer> indice = new ArrayList<Integer>();

        for (int i = 0; i < subscriber.getPurchasedOfferArray().size(); i++) {
            MtxPurchasedOfferInfo poi = subscriber.getPurchasedOfferArray().get(i);
            if (poi.getCatalogItemExternalId() != null
                    && ciList.contains(poi.getCatalogItemExternalId())) {
                indice.add(i);
            }
        }

        indice.forEach(i -> {
            subscriber.getPurchasedOfferArrayAppender().removeAt(i);
        });

        return subscriber;
    }

    public static MtxResponseRecurringChargeInfo removeCiInMtxResponseRecurringChargeInfo(List<String> ciList,
                                                                                          MtxResponseRecurringChargeInfo chargeInfo) {
        chargeInfo.getBalanceImpactGroupList().forEach(big -> {
            big.getBalanceImpactList().forEach(bi -> {
                List<Integer> indice = new ArrayList<Integer>();
                for (int i = 0; i < bi.getBalanceImpactOfferList().size(); i++) {
                    MtxBalanceImpactOfferInfo bioi = bi.getBalanceImpactOfferList().get(i);
                    if (ciList.contains(bioi.getCatalogItemExternalId())) {
                        indice.add(i);
                    }
                }

                indice.forEach(i -> {
                    bi.getBalanceImpactOfferListAppender().removeAt(i);
                });
            });
        });

        return chargeInfo;
    }

    public static boolean isJSONValid(String jsonString) {
        try {
            new JSONObject(jsonString);
        } catch (JSONException ex) {
            try {
                new JSONArray(jsonString);
            } catch (JSONException ex1) {
                return false;
            }
        }
        return true;
    }

    public static MtxResponseRecurringChargeInfo resetImpactAmountInMtxResponseRecurringChargeInfo(BigDecimal iAmount,
                                                                                                   MtxResponseRecurringChargeInfo chargeInfo) {
        chargeInfo.getAtBalanceImpactGroupList(0).getBalanceImpactList().forEach(bi -> {
            // Set all amounts to zero
            bi.setImpactAmount(BigDecimal.ZERO);
            bi.getBalanceImpactOfferList().forEach(bioi -> {
                bioi.getBalanceImpactUpdateList().forEach(biui -> {
                    biui.setAmount(BigDecimal.ZERO);
                });
            });
        });

        for (MtxBalanceImpactInfo bi : chargeInfo.getAtBalanceImpactGroupList(
                0).getBalanceImpactList()) {
            // Set only one amount to 40
            bi.getAtBalanceImpactOfferList(0).getAtBalanceImpactUpdateList(0).setAmount(iAmount);
            bi.setImpactAmount(iAmount);
            break;
        }
        return chargeInfo;
    }

    @Deprecated
    public static MtxResponseSubscriber updatePaidCycleStartDateInMtxResponseSubscriber(MtxResponseSubscriber subscriber,
                                                                                        MtxDate paidcycleStartDate)
            throws IOException {
        subscriber.getPurchasedOfferArray().forEach(poi -> {
            if (poi.getCatalogItemExternalId() != null) {
                ((VisiblePurchasedOfferExtension) poi.getAttr()).setPaidCycleStartDate(
                        paidcycleStartDate);
            }
        });
        return subscriber;
    }

    public static MtxResponseSubscription updatePaidCycleStartDateInMtxResponseSubscription(MtxResponseSubscription subscription,
                                                                                            MtxDate paidcycleStartDate)
            throws IOException {
        subscription.getPurchasedOfferArray().forEach(poi -> {
            if (poi.getCatalogItemExternalId() != null) {
                ((VisiblePurchasedOfferExtension) poi.getAttr()).setPaidCycleStartDate(
                        paidcycleStartDate);
            }
        });
        return subscription;
    }

    public static MtxResponseSubscriber clearPaidCycleStartDateInMtxResponseSubscriber(MtxResponseSubscriber subscriber)
            throws IOException {
        subscriber.getPurchasedOfferArray().forEach(poi -> {
            if (poi.getCatalogItemExternalId() != null) {
                ((VisiblePurchasedOfferExtension) poi.getAttr()).setPaidCycleStartDate(null);
            }
        });
        return subscriber;
    }

    public static MtxResponseSubscription clearPaidCycleStartDateInMtxResponseSubscription(MtxResponseSubscription subscriber)
            throws IOException {
        subscriber.getPurchasedOfferArray().forEach(poi -> {
            if (poi.getCatalogItemExternalId() != null) {
                ((VisiblePurchasedOfferExtension) poi.getAttr()).setPaidCycleStartDate(null);
            }
        });
        return subscriber;
    }

    public static MtxBalanceInfo getMtxBalanceInfo(String filePath, long resourceId, int templateId)
            throws IOException, VisibleUnitTestException {
        MtxBalanceInfo resp = CommonTestHelper.loadJsonMessage(MtxBalanceInfo.class, filePath);
        resp.setResourceId(resourceId);
        resp.setTemplateId(BigInteger.valueOf(templateId));
        return resp;
    }

    public static MtxBalanceInfo getMtxBalanceInfo(String filePath)
            throws IOException, VisibleUnitTestException {
        MtxBalanceInfo resp = CommonTestHelper.loadJsonMessage(MtxBalanceInfo.class, filePath);
        return resp;
    }

    public static MtxPurchasedOfferInfo getMtxPurchasedOfferInfo(String filePath,
                                                                 long balanceResourceId,
                                                                 int balanceTemplateId)
            throws IOException, VisibleUnitTestException {
        MtxPurchasedOfferInfo resp = CommonTestHelper.loadJsonMessage(
                MtxPurchasedOfferInfo.class, filePath);
        resp.getRequiredBalanceArray().get(0).setResourceId(balanceResourceId);
        resp.getRequiredBalanceArray().get(0).setTemplateId(BigInteger.valueOf(balanceTemplateId));
        return resp;
    }

    public static MtxPurchasedOfferInfo getMtxPurchasedOfferInfo(String filePath)
            throws IOException, VisibleUnitTestException {
        MtxPurchasedOfferInfo resp = CommonTestHelper.loadJsonMessage(
                MtxPurchasedOfferInfo.class, filePath);
        return resp;
    }

    public static SubscriptionResponse getEmptySubscriptionResponse_NoAttributes()
            throws IOException, VisibleUnitTestException {
        SubscriptionResponse sub = getEmptySubscriptionResponse("");
        sub.setAttr((MtxSubscriberExtension) null);
        return sub;
    }

    public static SubscriptionResponse getEmptySubscriptionResponse_NoMainbalance()
            throws IOException, VisibleUnitTestException {
        SubscriptionResponse sub = getEmptySubscriptionResponse("");
        sub.getBalanceArrayAppender().clear();
        sub.getWalletBalancesAppender().clear();
        return sub;
    }

    public static SubscriptionResponse getEmptySubscriptionResponse()
            throws IOException, VisibleUnitTestException {
        return getSubscriptionResponse("", BigDecimal.ZERO);
    }

    public static SubscriptionResponse getEmptySubscriptionResponse(String subExternalId)
            throws IOException, VisibleUnitTestException {
        return getSubscriptionResponse(subExternalId, BigDecimal.ZERO);
    }

    public static SubscriptionResponse getSubscriptionResponse(String subExternalId,
                                                               BigDecimal mainbalanceamount)
            throws IOException, VisibleUnitTestException {
        return getSubscriptionResponse(subExternalId, null, mainbalanceamount);

    }

    @SuppressWarnings("unchecked")
    public static SubscriptionResponse getSubscriptionResponse(String subExternalId,
                                                               String timeZone,
                                                               BigDecimal mainbalanceamount)
            throws IOException, VisibleUnitTestException {
        SubscriptionResponse subscription = CommonTestHelper.loadJsonMessage(
                SubscriptionResponse.class, DATA_DIR.COMMON + "SubscriptionResponse.json");
        subscription.getDeviceIdArrayAppender().clear();
        if (StringUtils.isNotBlank(subExternalId)) {
            subscription.setExternalId(subExternalId);
        }
        String tz = timeZone;
        if (StringUtils.isBlank(tz)) {
            tz = ZoneId.systemDefault().toString();
        }
        subscription.setTimeZone(tz);
        subscription.setBillingCycle(
                getMonthlyMtxBillingCycleInfo(LocalDate.now().withDayOfMonth(1), tz));
        MtxBalanceInfo mbiMainbalance = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.MAIN_BALANCE, mainbalanceamount);
        subscription.getBalanceArrayAppender().add(mbiMainbalance);

        BalanceInfo biMainbalance = CommonTestHelper.getBalanceInfo(
                BALANCE_NAMES.MAIN_BALANCE, mainbalanceamount);
        subscription.getWalletBalancesAppender().add(biMainbalance);
        return subscription;
    }

    public static SubscriptionResponse getSubscriptionResponseAutopay(List<String> activeCiExternalIds,
                                                                      String timeZone)
            throws IOException, VisibleUnitTestException {
        SubscriptionResponse sub = getSubscriptionResponse(
                null, null, false, activeCiExternalIds, null, null, null);
        String tz = timeZone;
        if (StringUtils.isBlank(tz)) {
            tz = ZoneId.systemDefault().toString();
        }
        sub.setBillingCycle(getMonthlyBillingCycleWithEndDate(LocalDate.now(), tz));
        sub.getPurchasedOfferArray().forEach(mpoi -> {
            PurchasedOfferInfo poi = (PurchasedOfferInfo) mpoi;
            if (poi.getCycleInfo() != null && poi.getCycleInfo().getIntervalId() == 1
                    && poi.getCycleInfo().getPeriod() == 4) {
                poi.getCycleInfo().setCycleStartTime(
                        sub.getBillingCycle().getCurrentPeriodStartTime());
                poi.getCycleInfo().setCycleEndTime(sub.getBillingCycle().getCurrentPeriodEndTime());
                poi.getCycleInfo().setCycleOffset(sub.getBillingCycle().getCurrentPeriodOffset());
            }
        });
        return sub;
    }

    public static SubscriptionResponse getSubscriptionResponse(List<String> activeCiExternalIds)
            throws IOException, VisibleUnitTestException {
        return getSubscriptionResponse(null, null, false, activeCiExternalIds, null, null, null);
    }

    public static SubscriptionResponse getSubscriptionResponse_afterPayment(String subExternalId,
                                                                            List<String> activeCiExternalIds)
            throws IOException, VisibleUnitTestException {
        return getSubscriptionResponse(
                subExternalId, null, true, activeCiExternalIds, null, null, null);
    }

    public static SubscriptionResponse getSubscriptionResponse_BeforePayment(String subExternalId,
                                                                             List<String> activeCiExternalIds)
            throws IOException, VisibleUnitTestException {
        return getSubscriptionResponse(
                subExternalId, null, false, activeCiExternalIds, null, null, null);
    }

    public static SubscriptionResponse getSubscriptionResponse_LastMonth(String subExternalId,
                                                                         List<String> activeCiExternalIds)
            throws IOException, VisibleUnitTestException {
        return getSubscriptionResponse(
                subExternalId, null, false, activeCiExternalIds, null, null, null, true);
    }

    public static SubscriptionResponse getSubscriptionResponse(String subExternalId,
                                                               List<String> activeCiExternalIds)
            throws IOException, VisibleUnitTestException {
        return getSubscriptionResponse(
                subExternalId, null, false, activeCiExternalIds, null, null, null);
    }

    public static SubscriptionResponse getSubscriptionResponse_LastMonth(String subExternalId,
                                                                         List<String> activeCiExternalIds,
                                                                         List<String> preactiveCiExternalIds)
            throws IOException, VisibleUnitTestException {
        return getSubscriptionResponse(
                subExternalId, null, false, activeCiExternalIds, preactiveCiExternalIds, null, null,
                true);
    }

    public static SubscriptionResponse getSubscriptionResponse(String subExternalId,
                                                               List<String> activeCiExternalIds,
                                                               List<String> preactiveCiExternalIds)
            throws IOException, VisibleUnitTestException {
        return getSubscriptionResponse(
                subExternalId, null, false, activeCiExternalIds, preactiveCiExternalIds, null,
                null);
    }

    public static SubscriptionResponse getSubscriptionResponse(String subExternalId,
                                                               List<String> activeCiExternalIds,
                                                               List<String> preactiveCiExternalIds,
                                                               List<String> inactiveCiExternalIds,
                                                               List<String> enddatedCiExternalIds)
            throws IOException, VisibleUnitTestException {
        return getSubscriptionResponse(
                subExternalId, null, false, activeCiExternalIds, preactiveCiExternalIds,
                inactiveCiExternalIds, enddatedCiExternalIds);
    }

    public static SubscriptionResponse getSubscriptionResponse(String subExternalId,
                                                               String timeZone,
                                                               boolean paidNextCycle,
                                                               List<String> activeCiExternalIds,
                                                               List<String> preactiveCiExternalIds,
                                                               List<String> inactiveCiExternalIds,
                                                               List<String> enddatedCiExternalIds)
            throws IOException, VisibleUnitTestException {
        return getSubscriptionResponse(
                subExternalId, timeZone, paidNextCycle, activeCiExternalIds, preactiveCiExternalIds,
                inactiveCiExternalIds, enddatedCiExternalIds, false);
    }

    @SuppressWarnings("unchecked")
    public static SubscriptionResponse getSubscriptionResponse(String subExternalId,
                                                               String timeZone,
                                                               boolean paidNextCycle,
                                                               List<String> activeCiExternalIds,
                                                               List<String> preactiveCiExternalIds,
                                                               List<String> inactiveCiExternalIds,
                                                               List<String> enddatedCiExternalIds,
                                                               boolean isLastMonth)
            throws IOException, VisibleUnitTestException {

        List<String> monthlyBaseOfferList = Arrays.asList(
                CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.BASE2VIS22, CI_EXTERNAL_IDS.BASE3VIS23,
                CI_EXTERNAL_IDS.PLUS2VIS22, CI_EXTERNAL_IDS.PLUS3VIS23WB, CI_EXTERNAL_IDS.PLUS25,
                CI_EXTERNAL_IDS.PRO25);
        List<String> annualBaseOfferList = Arrays.asList(
                CI_EXTERNAL_IDS.BASE2ANNUAL, CI_EXTERNAL_IDS.BASE3ANNUAL,
                CI_EXTERNAL_IDS.PLUS2ANNUAL, CI_EXTERNAL_IDS.PLUS3ANNUAL,
                CI_EXTERNAL_IDS.PLUS25ANNUAL, CI_EXTERNAL_IDS.PRO25ANNUAL);
        List<String> sixMonthBaseOfferList = Arrays.asList(
                CI_EXTERNAL_IDS.BASE6MONTH25, CI_EXTERNAL_IDS.PLUS6MONTH25,
                CI_EXTERNAL_IDS.PRO6MONTH25);

        SubscriptionResponse subscription = CommonTestHelper.loadJsonMessage(
                SubscriptionResponse.class, DATA_DIR.COMMON + "SubscriptionResponse.json");

        String tz = timeZone;
        if (StringUtils.isBlank(tz)) {
            tz = ZoneId.systemDefault().toString();
        }
        subscription.setTimeZone(tz);
        subscription.setBillingCycle(getMonthlyMtxBillingCycleInfo(LocalDate.now(), tz));

        subscription.getDeviceIdArrayAppender().clear();
        subscription.getPurchasedOfferArrayAppender().clear();

        int lastBit = 1;
        if (StringUtils.isNotBlank(subExternalId)) {
            subscription.setExternalId(subExternalId);
        }

        if (inactiveCiExternalIds != null) {
            for (String ciExternalId : inactiveCiExternalIds) {
                if (StringUtils.isNotBlank(ciExternalId)) {
                    PurchasedOfferInfo poi = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                            subscription, ciExternalId);
                    poi.setNextOfferStatusDescription(OFFER_STATUS.INACTIVE);
                    poi.setCancelTime(
                            TestUtils.getFirstDateTimeOfCurrentMonth(subscription.getTimeZone()));
                }
            }
        }

        PurchasedOfferInfo activeBasePo = null;
        if (activeCiExternalIds != null) {
            for (String ciExternalId : activeCiExternalIds) {
                PurchasedOfferInfo po = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                        subscription, ciExternalId, paidNextCycle);
                if (po.getCatalogItemDetails().getTemplateAttr() != null
                        && po.getCatalogItemDetails().getTemplateAttr() instanceof VisibleTemplate) {
                    VisibleTemplate vt = (VisibleTemplate) po.getCatalogItemDetails().getTemplateAttr();
                    if (OFFER_CONSTANTS.OFFER_TYPE_BASE.equalsIgnoreCase(vt.getOfferType())
                            || OFFER_CONSTANTS.OFFER_TYPE_ADDON.equalsIgnoreCase(
                                    vt.getOfferType())) {
                        subscription.getDeviceIdArrayAppender().add(
                                new MtxObjectId("1-2-3-" + lastBit++));
                    }
                    if (OFFER_CONSTANTS.OFFER_TYPE_BASE.equalsIgnoreCase(vt.getOfferType())) {
                        activeBasePo = po;
                    }

                }
                if (po.getCycleInfo() != null && monthlyBaseOfferList.contains(ciExternalId)) {
                    po.getCycleInfo().setCycleEndTime(
                            subscription.getBillingCycle().getCurrentPeriodEndTime());
                    po.getCycleInfo().setCycleStartTime(
                            subscription.getBillingCycle().getCurrentPeriodStartTime());
                }
                if (po.getCycleInfo() != null && annualBaseOfferList.contains(ciExternalId)) {
                    if (isLastMonth) {
                        po.getCycleInfo().setCycleEndTime(
                                subscription.getBillingCycle().getCurrentPeriodEndTime());
                        po.getCycleInfo().setCycleStartTime(
                                TestUtils.subtractOneYear(
                                        po.getCycleInfo().getCycleEndTime(),
                                        subscription.getTimeZone()));
                    } else {
                        po.getCycleInfo().setCycleStartTime(
                                subscription.getBillingCycle().getCurrentPeriodStartTime());
                        po.getCycleInfo().setCycleEndTime(
                                TestUtils.addOneYear(
                                        po.getCycleInfo().getCycleStartTime(),
                                        subscription.getTimeZone()));
                    }
                }
                if (po.getCycleInfo() != null && sixMonthBaseOfferList.contains(ciExternalId)) {
                    if (isLastMonth) {
                        po.getCycleInfo().setCycleEndTime(
                                subscription.getBillingCycle().getCurrentPeriodEndTime());
                        po.getCycleInfo().setCycleStartTime(
                                TestUtils.subtractMonths(
                                        po.getCycleInfo().getCycleEndTime(), 6,
                                        subscription.getTimeZone()));
                    } else {
                        po.getCycleInfo().setCycleStartTime(
                                subscription.getBillingCycle().getCurrentPeriodStartTime());
                        po.getCycleInfo().setCycleEndTime(
                                TestUtils.addMonths(
                                        po.getCycleInfo().getCycleStartTime(), 6,
                                        subscription.getTimeZone()));
                    }
                }
                if (po.getCycleInfo() != null) {
                    po.getCycleInfo().setCycleOffset(
                            subscription.getBillingCycle().getDateOffset());
                }
            }
        }

        if (preactiveCiExternalIds != null) {
            for (String ciExternalId : preactiveCiExternalIds) {
                if (StringUtils.isNotBlank(ciExternalId)) {
                    PurchasedOfferInfo poi = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                            subscription, ciExternalId);
                    poi.setOfferStatusDescription(OFFER_CONSTANTS.OFFER_STATUS_PRE_ACTIVE);
                    if (activeBasePo != null && activeBasePo.getCycleInfo() != null) {
                        poi.setAutoActivationTime(activeBasePo.getCycleInfo().getCycleEndTime());
                    } else {
                        poi.setAutoActivationTime(
                                subscription.getBillingCycle().getCurrentPeriodEndTime());
                    }
                    if (poi.getCycleInfo() != null) {
                        // Preactiveoffers do not have cycle info
                        poi.setCycleInfo((MtxPurchasedItemCycleInfo) null);
                    }
                }
            }
        }
        if (enddatedCiExternalIds != null) {
            for (String ciExternalId : enddatedCiExternalIds) {
                if (StringUtils.isNotBlank(ciExternalId)) {
                    PurchasedOfferInfo poi = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                            subscription, ciExternalId);
                    poi.setEndTime(
                            TestUtils.getFirstDateTimeOfNextMonth(subscription.getTimeZone()));
                }
            }
        }

        MtxBalanceInfo mbiMainbalance = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.MAIN_BALANCE, BigDecimal.ZERO);
        subscription.getBalanceArrayAppender().add(mbiMainbalance);

        BalanceInfo biMainbalance = CommonTestHelper.getBalanceInfo(
                BALANCE_NAMES.MAIN_BALANCE, BigDecimal.ZERO);
        subscription.getWalletBalancesAppender().add(biMainbalance);

        return subscription;
    }

    public static MtxResponseSubscription getBeneficiarySubscription_CaGroup(String benExternalId,
                                                                             String payExternalId)
            throws IOException, VisibleUnitTestException {
        MtxResponseSubscription sub = getMtxResponseSubscription_Autopay(benExternalId, null);
        VisibleSubscriberExtension attr = (VisibleSubscriberExtension) sub.getAttr();
        attr.setPayerExternalId(payExternalId);
        return sub;
    }

    public static MtxResponseSubscription getMtxResponseSubscription_Autopay(String subExternalId)
            throws IOException, VisibleUnitTestException {
        return getMtxResponseSubscription_Autopay(subExternalId, null);
    }

    public static MtxResponseSubscription getMtxResponseSubscription_Autopay(String subExternalId,
                                                                             List<String> activeCiExternalIds)
            throws IOException, VisibleUnitTestException {
        MtxResponseSubscription sub = getMtxResponseSubscription(
                subExternalId, activeCiExternalIds, null);
        VisibleSubscriberExtension attr = (VisibleSubscriberExtension) sub.getAttr();
        attr.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        return sub;
    }

    public static MtxResponseSubscription getMtxResponseSubscription_Manualpay(String subExternalId)
            throws IOException, VisibleUnitTestException {
        MtxResponseSubscription sub = getMtxResponseSubscription(subExternalId, null, null);
        VisibleSubscriberExtension attr = (VisibleSubscriberExtension) sub.getAttr();
        attr.setPaymentPreference(PAYMENT_CONSTANTS.MANUALPAY);
        return sub;
    }

    public static MtxResponseSubscription getMtxResponseSubscription()
            throws IOException, VisibleUnitTestException {
        return getMtxResponseSubscription(null, null, null);
    }

    public static MtxResponseSubscription getMtxResponseSubscription(List<String> activeCiExternalIds)
            throws IOException, VisibleUnitTestException {
        return getMtxResponseSubscription(null, activeCiExternalIds, null);
    }

    public static MtxResponseSubscription getMtxResponseSubscription(String subExternalId,
                                                                     List<String> activeCiExternalIds)
            throws IOException, VisibleUnitTestException {
        return getMtxResponseSubscription(subExternalId, activeCiExternalIds, null);
    }

    public static MtxResponseSubscription getMtxResponseSubscription(String subExternalId,
                                                                     List<String> activeCiExternalIds,
                                                                     int numOfDevices)
            throws IOException, VisibleUnitTestException {
        return getMtxResponseSubscription(
                subExternalId, activeCiExternalIds, null, null, null, false, numOfDevices);
    }

    public static MtxResponseSubscription getMtxResponseSubscription(String subExternalId,
                                                                     List<String> activeCiExternalIds,
                                                                     List<String> preactiveCiExternalIds)
            throws VisibleUnitTestException, IOException {
        return getMtxResponseSubscription(
                subExternalId, activeCiExternalIds, preactiveCiExternalIds, null);
    }

    public static MtxResponseSubscription getMtxResponseSubscription(String subExternalId,
                                                                     List<String> activeCiExternalIds,
                                                                     List<String> preactiveCiExternalIds,
                                                                     List<String> inactiveCiExternalIds)
            throws IOException, VisibleUnitTestException {
        return getMtxResponseSubscription(
                subExternalId, activeCiExternalIds, preactiveCiExternalIds, inactiveCiExternalIds,
                null);
    }

    public static MtxResponseSubscription getMtxResponseSubscription(String subExternalId,
                                                                     List<String> activeCiExternalIds,
                                                                     List<String> preactiveCiExternalIds,
                                                                     List<String> inactiveCiExternalIds,
                                                                     List<String> enddatedCiExternalIds)
            throws IOException, VisibleUnitTestException {
        return getMtxResponseSubscription(
                subExternalId, activeCiExternalIds, preactiveCiExternalIds, inactiveCiExternalIds,
                null, false, 1);
    }

    public static MtxResponseSubscription getMtxResponseSubscription(String subExternalId,
                                                                     List<String> activeCiExternalIds,
                                                                     List<String> preactiveCiExternalIds,
                                                                     List<String> inactiveCiExternalIds,
                                                                     List<String> enddatedCiExternalIds,
                                                                     boolean allOffers)
            throws IOException, VisibleUnitTestException {
        return getMtxResponseSubscription(
                subExternalId, activeCiExternalIds, preactiveCiExternalIds, inactiveCiExternalIds,
                enddatedCiExternalIds, allOffers, 1);
    }

    @SuppressWarnings("unchecked")
    public static MtxResponseSubscription getMtxResponseSubscription(String subExternalId,
                                                                     List<String> activeCiExternalIds,
                                                                     List<String> preactiveCiExternalIds,
                                                                     List<String> inactiveCiExternalIds,
                                                                     List<String> enddatedCiExternalIds,
                                                                     boolean allOffers,
                                                                     int numOfDevices)
            throws IOException, VisibleUnitTestException {
        MtxResponseSubscription subscription = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class, DATA_DIR.COMMON + "MtxResponseSubscription.json");
        subscription.setLastActivityTime(TestUtils.getFirstDateTimeOfCurrentMonth());
        subscription.setTimeZone(TestUtils.getSystemTimezoneOffset());

        if (StringUtils.isNotBlank(subExternalId)) {
            subscription.setExternalId(subExternalId);
        }

        if (numOfDevices > 0) {
            subscription.getDeviceIdArrayAppender().add(new MtxObjectId("1-2-3-4"));
        }
        if (numOfDevices > 1) {
            subscription.getDeviceIdArrayAppender().add(new MtxObjectId("5-6-7-8"));
        }
        for (String ciExternalId : CommonUtils.emptyIfNull(inactiveCiExternalIds)) {
            if (StringUtils.isNotBlank(ciExternalId)) {
                MtxPurchasedOfferInfo poi = CommonTestHelper.getMtxPurchasedOfferInfo(
                        subscription, ciExternalId);
                poi.setOfferStatusDescription(OFFER_STATUS.INACTIVE);
                poi.setStatus(OFFER_STATUS_INTEGER.INACTIVE);
                poi.setCancelTime(
                        TestUtils.getFirstDateTimeOfCurrentMonth(
                                subscription.getLastActivityTime()));
                if (allOffers) {
                    addBundledOffers(subscription, poi);
                }
            }
        }

        for (String ciExternalId : CommonUtils.emptyIfNull(activeCiExternalIds)) {
            if (StringUtils.isNotBlank(ciExternalId)) {
                MtxPurchasedOfferInfo poi = CommonTestHelper.getMtxPurchasedOfferInfo(
                        subscription, ciExternalId);
                if (allOffers) {
                    addBundledOffers(subscription, poi);
                }
            }
        }

        for (String ciExternalId : CommonUtils.emptyIfNull(preactiveCiExternalIds)) {
            if (StringUtils.isNotBlank(ciExternalId)) {
                MtxPurchasedOfferInfo poi = CommonTestHelper.getMtxPurchasedOfferInfo(
                        subscription, ciExternalId);
                poi.setOfferStatusDescription(OFFER_CONSTANTS.OFFER_STATUS_PRE_ACTIVE);
                poi.setStatus(OFFER_STATUS_INTEGER.PREACTIVE);
                poi.setAutoActivationTime(
                        TestUtils.getFirstDateTimeOfNextMonth(subscription.getLastActivityTime()));
                if (poi.getCycleInfo() != null) {
                    // Preactiveoffers do not have cycle info
                    poi.setCycleInfo((MtxPurchasedItemCycleInfo) null);
                    if (allOffers) {
                        addBundledOffers(subscription, poi);
                    }
                }
            }
        }

        for (String ciExternalId : CommonUtils.emptyIfNull(enddatedCiExternalIds)) {
            if (StringUtils.isNotBlank(ciExternalId)) {
                MtxPurchasedOfferInfo poi = CommonTestHelper.getMtxPurchasedOfferInfo(
                        subscription, ciExternalId);
                poi.setEndTime(
                        TestUtils.getFirstDateTimeOfNextMonth(subscription.getLastActivityTime()));
                if (allOffers) {
                    addBundledOffers(subscription, poi);
                }
            }
        }

        return subscription;
    }

    @SuppressWarnings("unchecked")
    public static MtxResponseSubscription getMtxResponseSubscription(SubscriptionResponse inputSub)
            throws IOException, VisibleUnitTestException {
        MtxResponseSubscription subscription = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class, DATA_DIR.COMMON + "MtxResponseSubscription.json");
        subscription.setTimeZone(inputSub.getTimeZone());
        subscription.setExternalId(inputSub.getExternalId());
        subscription.setAttr(inputSub.getAttr());

        for (MtxObjectId dev : CommonUtils.emptyIfNull(inputSub.getDeviceIdArray())) {
            subscription.getDeviceIdArrayAppender().add(dev);
        }
        for (MtxPurchasedOfferInfo po : CommonUtils.emptyIfNull(
                inputSub.getPurchasedOfferArray())) {
            subscription.getPurchasedOfferArrayAppender().add(
                    getMtxPurchasedOfferInfo((PurchasedOfferInfo) po));
        }
        subscription.getBalanceArrayAppender().clear();
        for (MtxBalanceInfo bal : CommonUtils.emptyIfNull(inputSub.getBalanceArray())) {
            subscription.getBalanceArrayAppender().add(bal);
        }

        return subscription;
    }

    public static MtxResponseRecurringChargeInfo getEmptyMtxResponseRecurringChargeInfo(SubscriptionResponse subResp)
            throws IOException, VisibleUnitTestException {
        return getMtxResponseRecurringChargeInfo(subResp);
    }

    public static MtxResponseRecurringChargeInfo getMtxResponseRecurringChargeInfo(SubscriptionResponse subResp)
            throws IOException, VisibleUnitTestException {
        return getMtxResponseRecurringChargeInfo(subResp, null);
    }

    @SuppressWarnings("unchecked")
    public static MtxResponseRecurringChargeInfo getMtxResponseRecurringChargeInfo(SubscriptionResponse subResp,
                                                                                   Map<String, BigDecimal> baseConsumableMap)
            throws IOException, VisibleUnitTestException {
        MtxResponseRecurringChargeInfo chargeInfo = new MtxResponseRecurringChargeInfo();
        chargeInfo.setResult(RESULT_CODES.MTX_SUCCESS);
        chargeInfo.setResultText("OK");
        List<String> monthlyBaseOfferList = Arrays.asList(
                CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.BASE2VIS22, CI_EXTERNAL_IDS.BASE3VIS23,
                CI_EXTERNAL_IDS.PLUS2VIS22, CI_EXTERNAL_IDS.PLUS3VIS23WB, CI_EXTERNAL_IDS.PLUS25,
                CI_EXTERNAL_IDS.PRO25);
        List<String> annualBaseOfferList = Arrays.asList(
                CI_EXTERNAL_IDS.BASE2ANNUAL, CI_EXTERNAL_IDS.BASE3ANNUAL,
                CI_EXTERNAL_IDS.PLUS2ANNUAL, CI_EXTERNAL_IDS.PLUS3ANNUAL,
                CI_EXTERNAL_IDS.PLUS25ANNUAL, CI_EXTERNAL_IDS.PRO25ANNUAL);
        List<String> sixMonthBaseOfferList = Arrays.asList(
                CI_EXTERNAL_IDS.BASE6MONTH25, CI_EXTERNAL_IDS.PLUS6MONTH25,
                CI_EXTERNAL_IDS.PRO6MONTH25);

        List<MtxBalanceImpactInfo> consImpactMonthlyList = new ArrayList<MtxBalanceImpactInfo>();
        List<MtxBalanceImpactInfo> consImpactAnnualList = new ArrayList<MtxBalanceImpactInfo>();
        if (subResp.getPurchasedOfferArray() == null) {
            System.out.println("chargeInfo: " + chargeInfo.toJson());
            return chargeInfo;
        }
        // if (subResp.getPurchasedOfferArray() != null) {
        MtxBalanceImpactInfoGroup monthlyGroup = new MtxBalanceImpactInfoGroup();
        MtxBalanceImpactInfo biiMultiMonthCounter = null;
        MtxBalanceImpactInfo biiMainBalanceMonthly = CommonTestHelper.loadJsonMessage(
                MtxBalanceImpactInfo.class,
                DATA_DIR.COMMON + "MtxBalanceImpactInfo_Mainbalance.json");
        MtxBalanceImpactInfo biiMainBalanceAnnual = CommonTestHelper.loadJsonMessage(
                MtxBalanceImpactInfo.class,
                DATA_DIR.COMMON + "MtxBalanceImpactInfo_Mainbalance.json");
        MtxBalanceImpactInfo biiBuyXGetX6Month = CommonTestHelper.loadJsonMessage(
                MtxBalanceImpactInfo.class, DATA_DIR.COMMON + "MtxBalanceImpactInfo_BuyXGetX.json");

        MtxTimestamp monthlyStartDate = subResp.getBillingCycle().getCurrentPeriodEndTime();
        MtxTimestamp annualStartDate = TestUtils.addOneYear(
                subResp.getBillingCycle().getCurrentPeriodStartTime(), subResp.getTimeZone());
        MtxTimestamp sixMonthStartDate = TestUtils.addMonths(
                subResp.getBillingCycle().getCurrentPeriodStartTime(), 6, subResp.getTimeZone());

        if (subResp != null) {
            biiMainBalanceMonthly.setBalanceOwnerExternalId(subResp.getExternalId());
            biiMainBalanceAnnual.setBalanceOwnerExternalId(subResp.getExternalId());
            biiBuyXGetX6Month.setBalanceOwnerExternalId(subResp.getExternalId());
        }

        monthlyGroup.setCycleStartTime(monthlyStartDate);
        MtxTimestamp monthlyEndDate = CommonUtils.getNextCycleEndTime(
                subResp.getBillingCycle(), subResp.getTimeZone());
        monthlyGroup.setCycleEndTime(monthlyEndDate);

        BigDecimal monthlyImpact = BigDecimal.ZERO;

        MtxBalanceImpactInfoGroup annualGroup = new MtxBalanceImpactInfoGroup();

        annualGroup.setCycleStartTime(annualStartDate);
        MtxTimestamp annualEndDate = TestUtils.addOneYear(annualStartDate, subResp.getTimeZone());
        annualGroup.setCycleEndTime(annualEndDate);
        BigDecimal annualImpact = BigDecimal.ZERO;

        for (MtxPurchasedOfferInfo mpoi : CommonUtils.emptyIfNull(
                subResp.getPurchasedOfferArray())) {
            if (!mpoi.getOfferStatusDescription().equalsIgnoreCase(
                    OFFER_CONSTANTS.OFFER_STATUS_ACTIVE)) {
                System.out.println(mpoi.getCatalogItemExternalId() + " Not Active.");
                continue;
            }

            if (mpoi.getEndTime() != null
                    && mpoi.getEndTime().longValue() <= monthlyStartDate.longValue()) {
                System.out.println(mpoi.getCatalogItemExternalId() + " End Dated.");
                continue;
            }

            String ciExternalId = mpoi.getCatalogItemExternalId();
            MtxBalanceImpactOfferInfo bioiMonthly = null;
            MtxBalanceImpactOfferInfo bioiAnnual = null;
            MtxBalanceImpactOfferInfo bioiBuyXGetXMonth = null;

            if (CI_EXTERNAL_IDS.UNLIMITED.equalsIgnoreCase(ciExternalId)) {
                bioiMonthly = CommonTestHelper.loadJsonMessage(
                        MtxBalanceImpactOfferInfo.class,
                        DATA_DIR.PAYMENT_ADVICE + "MtxBalanceImpactOfferInfo_Unlimited.json");
                biiMainBalanceMonthly.getBalanceImpactOfferListAppender().add(bioiMonthly);
                monthlyImpact = monthlyImpact.add(getOfferPrice(CI_EXTERNAL_IDS.UNLIMITED));
            } else if (CI_EXTERNAL_IDS.BASE2VIS22.equalsIgnoreCase(ciExternalId)) {
                bioiMonthly = CommonTestHelper.loadJsonMessage(
                        MtxBalanceImpactOfferInfo.class,
                        DATA_DIR.PAYMENT_ADVICE + "MtxBalanceImpactOfferInfo_BASE2VISIBLE22.json");
                biiMainBalanceMonthly.getBalanceImpactOfferListAppender().add(bioiMonthly);
                monthlyImpact = monthlyImpact.add(getOfferPrice(CI_EXTERNAL_IDS.BASE2VIS22));
            } else if (CI_EXTERNAL_IDS.BASE3VIS23.equalsIgnoreCase(ciExternalId)) {
                bioiMonthly = CommonTestHelper.loadJsonMessage(
                        MtxBalanceImpactOfferInfo.class,
                        DATA_DIR.COMMON + "MtxBalanceImpactOfferInfo_BASE3VISIBLE23.json");
                biiMainBalanceMonthly.getBalanceImpactOfferListAppender().add(bioiMonthly);
                monthlyImpact = monthlyImpact.add(getOfferPrice(CI_EXTERNAL_IDS.BASE3VIS23));
            } else if (CI_EXTERNAL_IDS.PLUS2VIS22.equalsIgnoreCase(ciExternalId)) {
                bioiMonthly = CommonTestHelper.loadJsonMessage(
                        MtxBalanceImpactOfferInfo.class,
                        DATA_DIR.PAYMENT_ADVICE + "MtxBalanceImpactOfferInfo_PLUS2VIS22WB.json");
                biiMainBalanceMonthly.getBalanceImpactOfferListAppender().add(bioiMonthly);
                monthlyImpact = monthlyImpact.add(getOfferPrice(CI_EXTERNAL_IDS.PLUS2VIS22));
            } else if (CI_EXTERNAL_IDS.PLUS3VIS23WB.equalsIgnoreCase(ciExternalId)) {
                bioiMonthly = CommonTestHelper.loadJsonMessage(
                        MtxBalanceImpactOfferInfo.class,
                        DATA_DIR.COMMON + "MtxBalanceImpactOfferInfo_PLUS3VIS23WB.json");
                biiMainBalanceMonthly.getBalanceImpactOfferListAppender().add(bioiMonthly);
                monthlyImpact = monthlyImpact.add(getOfferPrice(CI_EXTERNAL_IDS.PLUS3VIS23));
            } else if (CI_EXTERNAL_IDS.PLUS25.equalsIgnoreCase(ciExternalId)) {
                bioiMonthly = CommonTestHelper.loadJsonMessage(
                        MtxBalanceImpactOfferInfo.class,
                        DATA_DIR.COMMON + "MtxBalanceImpactOfferInfo_PLUS4VIS25WB.json");
                biiMainBalanceMonthly.getBalanceImpactOfferListAppender().add(bioiMonthly);
                monthlyImpact = monthlyImpact.add(getOfferPrice(CI_EXTERNAL_IDS.PLUS25));
            } else if (CI_EXTERNAL_IDS.PRO25.equalsIgnoreCase(ciExternalId)) {
                bioiMonthly = CommonTestHelper.loadJsonMessage(
                        MtxBalanceImpactOfferInfo.class,
                        DATA_DIR.COMMON + "MtxBalanceImpactOfferInfo_PPLUS1VIS25WB.json");
                biiMainBalanceMonthly.getBalanceImpactOfferListAppender().add(bioiMonthly);
                monthlyImpact = monthlyImpact.add(getOfferPrice(CI_EXTERNAL_IDS.PLUS3VIS23));
            } else if (CI_EXTERNAL_IDS.INSURANCE.equalsIgnoreCase(ciExternalId)) {
                bioiMonthly = CommonTestHelper.loadJsonMessage(
                        MtxBalanceImpactOfferInfo.class,
                        DATA_DIR.PAYMENT_ADVICE + "MtxBalanceImpactOfferInfo_Insurance.json");
                biiMainBalanceMonthly.getBalanceImpactOfferListAppender().add(bioiMonthly);
                monthlyImpact = monthlyImpact.add(getOfferPrice(CI_EXTERNAL_IDS.INSURANCE));
            } else if (CI_EXTERNAL_IDS.WEARABLE.equalsIgnoreCase(ciExternalId)) {
                bioiMonthly = CommonTestHelper.loadJsonMessage(
                        MtxBalanceImpactOfferInfo.class,
                        DATA_DIR.PAYMENT_ADVICE + "MtxBalanceImpactOfferInfo_Wearable.json");
                biiMainBalanceMonthly.getBalanceImpactOfferListAppender().add(bioiMonthly);
                monthlyImpact = monthlyImpact.add(getOfferPrice(CI_EXTERNAL_IDS.WEARABLE));
            } else if (CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023.equalsIgnoreCase(ciExternalId)) {
                bioiMonthly = CommonTestHelper.loadJsonMessage(
                        MtxBalanceImpactOfferInfo.class,
                        DATA_DIR.COMMON + "MtxBalanceImpactOfferInfo_CD3VISIBLE2023.json");
                biiMainBalanceMonthly.getBalanceImpactOfferListAppender().add(bioiMonthly);
                monthlyImpact = monthlyImpact.add(
                        getOfferPrice(CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023));
            } else if (CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION.equalsIgnoreCase(
                    ciExternalId)) {
                bioiMonthly = CommonTestHelper.loadJsonMessage(
                        MtxBalanceImpactOfferInfo.class,
                        DATA_DIR.COMMON + "MtxBalanceImpactOfferInfo_CD2VISIBLE2023.json");
                biiMainBalanceMonthly.getBalanceImpactOfferListAppender().add(bioiMonthly);
                monthlyImpact = monthlyImpact.add(
                        getOfferPrice(CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION));
            } else if (CI_EXTERNAL_IDS.BASE2ANNUAL.equalsIgnoreCase(ciExternalId)) {
                bioiAnnual = CommonTestHelper.loadJsonMessage(
                        MtxBalanceImpactOfferInfo.class,
                        DATA_DIR.COMMON + "MtxBalanceImpactOfferInfo_BASE2VISANNUAL22.json");
                biiMainBalanceAnnual.getBalanceImpactOfferListAppender().add(bioiAnnual);
                annualImpact = annualImpact.add(getOfferPrice(CI_EXTERNAL_IDS.BASE2ANNUAL));
            } else if (CI_EXTERNAL_IDS.BASE3ANNUAL.equalsIgnoreCase(ciExternalId)) {
                bioiAnnual = CommonTestHelper.loadJsonMessage(
                        MtxBalanceImpactOfferInfo.class,
                        DATA_DIR.COMMON + "MtxBalanceImpactOfferInfo_BASE3VISIBLE23A.json");
                biiMainBalanceAnnual.getBalanceImpactOfferListAppender().add(bioiAnnual);
                annualImpact = annualImpact.add(getOfferPrice(CI_EXTERNAL_IDS.BASE3ANNUAL));
                biiMultiMonthCounter = CommonTestHelper.loadJsonMessage(
                        MtxBalanceImpactInfo.class,
                        DATA_DIR.COMMON + "MtxBalanceImpactInfo_SingleItem_MultimonthCounter.json");
            } else if (CI_EXTERNAL_IDS.PLUS2ANNUAL.equalsIgnoreCase(ciExternalId)) {
                bioiAnnual = CommonTestHelper.loadJsonMessage(
                        MtxBalanceImpactOfferInfo.class,
                        DATA_DIR.COMMON + "MtxBalanceImpactOfferInfo_PLUS2VISANNUAL22json");
                biiMainBalanceAnnual.getBalanceImpactOfferListAppender().add(bioiAnnual);
                annualImpact = annualImpact.add(getOfferPrice(CI_EXTERNAL_IDS.PLUS2ANNUAL));
            } else if (CI_EXTERNAL_IDS.PLUS3ANNUAL.equalsIgnoreCase(ciExternalId)) {
                bioiAnnual = CommonTestHelper.loadJsonMessage(
                        MtxBalanceImpactOfferInfo.class,
                        DATA_DIR.COMMON + "MtxBalanceImpactOfferInfo_PLUS3VIS23WBA.json");
                biiMainBalanceAnnual.getBalanceImpactOfferListAppender().add(bioiAnnual);
                annualImpact = annualImpact.add(getOfferPrice(CI_EXTERNAL_IDS.PLUS3ANNUAL));
            } else if (CI_EXTERNAL_IDS.BASE6MONTH25.equalsIgnoreCase(ciExternalId)) {
                bioiBuyXGetXMonth = CommonTestHelper.loadJsonMessage(
                        MtxBalanceImpactOfferInfo.class,
                        DATA_DIR.COMMON + "MtxBalanceImpactOfferInfo_BASE6VISIBLE25.json");
                biiBuyXGetX6Month.getBalanceImpactOfferListAppender().add(bioiBuyXGetXMonth);
                System.out.println("biiBuyXGetX6Month: " + biiBuyXGetX6Month.toJson());
            } else if (CI_EXTERNAL_IDS.PLUS6MONTH25.equalsIgnoreCase(ciExternalId)) {
                bioiBuyXGetXMonth = CommonTestHelper.loadJsonMessage(
                        MtxBalanceImpactOfferInfo.class,
                        DATA_DIR.COMMON + "MtxBalanceImpactOfferInfo_PLUS6VIS25WB.json");
                biiBuyXGetX6Month.getBalanceImpactOfferListAppender().add(bioiBuyXGetXMonth);
            } else if (CI_EXTERNAL_IDS.PRO6MONTH25.equalsIgnoreCase(ciExternalId)) {
                bioiBuyXGetXMonth = CommonTestHelper.loadJsonMessage(
                        MtxBalanceImpactOfferInfo.class,
                        DATA_DIR.COMMON + "MtxBalanceImpactOfferInfo_PPLUS6VIS25WB.json");
                biiBuyXGetX6Month.getBalanceImpactOfferListAppender().add(bioiBuyXGetXMonth);
            }

            if (bioiMonthly != null) {
                bioiMonthly.setOfferResourceId(mpoi.getResourceId());
            }
            if (bioiAnnual != null) {
                bioiAnnual.setOfferResourceId(mpoi.getResourceId());
            }
            if (bioiBuyXGetXMonth != null) {
                bioiBuyXGetXMonth.setOfferResourceId(mpoi.getResourceId());
            }

            if (baseConsumableMap != null && monthlyBaseOfferList.contains(ciExternalId)) {
                for (Map.Entry<String, BigDecimal> entry : baseConsumableMap.entrySet()) {
                    System.out.println(entry.getKey() + ":" + entry.getValue());
                    MtxBalanceImpactInfo bii = getMtxBalanceImpactInfo(
                            ciExternalId, mpoi.getResourceId(), entry.getKey(), entry.getValue());
                    consImpactMonthlyList.add(bii);
                    monthlyImpact = monthlyImpact.subtract(entry.getValue());
                }
            }
            if (biiMultiMonthCounter != null) {
                consImpactMonthlyList.add(biiMultiMonthCounter);
                biiMultiMonthCounter = null;
            }
            if (baseConsumableMap != null && annualBaseOfferList.contains(ciExternalId)) {
                for (Map.Entry<String, BigDecimal> entry : baseConsumableMap.entrySet()) {
                    System.out.println(entry.getKey() + ":" + entry.getValue());
                    MtxBalanceImpactInfo bii = getMtxBalanceImpactInfo(
                            ciExternalId, mpoi.getResourceId(), entry.getKey(), entry.getValue());
                    consImpactAnnualList.add(bii);
                    annualImpact = annualImpact.subtract(entry.getValue());
                }
            }
        }

        if (biiMainBalanceMonthly.getBalanceImpactOfferList() != null
                && !biiMainBalanceMonthly.getBalanceImpactOfferList().isEmpty()) {
            monthlyGroup.getBalanceImpactListAppender().add(biiMainBalanceMonthly);
            biiMainBalanceMonthly.setImpactAmount(monthlyImpact);
            consImpactMonthlyList.forEach(bii -> {
                monthlyGroup.getBalanceImpactListAppender().add(bii);
            });
        }

        if (biiBuyXGetX6Month.getBalanceImpactOfferList() != null
                && !biiBuyXGetX6Month.getBalanceImpactOfferList().isEmpty()) {
            monthlyGroup.getBalanceImpactListAppender().add(biiBuyXGetX6Month);
            biiBuyXGetX6Month.setImpactAmount(BigDecimal.ONE.negate());
        }

        if (monthlyGroup.getBalanceImpactList() != null
                && !monthlyGroup.getBalanceImpactList().isEmpty()) {
            chargeInfo.getBalanceImpactGroupListAppender().add(monthlyGroup);
        }

        if (biiMainBalanceAnnual.getBalanceImpactOfferList() != null
                && !biiMainBalanceAnnual.getBalanceImpactOfferList().isEmpty()) {
            annualGroup.getBalanceImpactListAppender().add(biiMainBalanceAnnual);
            biiMainBalanceAnnual.setImpactAmount(annualImpact);
            consImpactAnnualList.forEach(bii -> {
                annualGroup.getBalanceImpactListAppender().add(bii);
            });
        }

        if (annualGroup.getBalanceImpactList() != null
                && !annualGroup.getBalanceImpactList().isEmpty()) {
            chargeInfo.getBalanceImpactGroupListAppender().add(annualGroup);
        }

        return chargeInfo;
    }

    public static MtxPurchasedOfferInfo getMtxPurchasedOfferInfo(PurchasedOfferInfo po)
            throws VisibleUnitTestException {

        PurchasedOfferInfo poClone = (PurchasedOfferInfo) cloneContainer(po);
        poClone.setBundleDetails((MtxPricingBundleDetailInfo) null);
        poClone.setOfferDetails((MtxPricingOfferDetailInfo) null);
        poClone.setCatalogItemDetails((MtxPricingCatalogItemDetailInfo) null);
        poClone.getMetadataListAppender().clear();

        JsonObject jsonObj = new JsonObject();
        poClone.toJson(jsonObj);
        jsonObj.attribute("$", MtxPurchasedOfferInfo.class.getSimpleName());
        jsonObj.remove("Description");
        jsonObj.remove("ExternalId");
        jsonObj.remove("Id");
        jsonObj.remove("IsBundle");
        jsonObj.remove("IsGlobal");
        jsonObj.remove("IsHidden");
        jsonObj.remove("Name");
        jsonObj.remove("Version");
        DataContainerFactory dcf = DataContainerFactory.getInstance();
        DataContainer dc = new DataContainer(dcf);
        dc.readFrom(jsonObj);
        MtxPurchasedOfferInfo retVal = new MtxPurchasedOfferInfo(dc);

        return retVal;
    }

    public static MtxPurchasedOfferInfo getMtxPurchasedOfferInfo(MtxResponseSubscription subscription,
                                                                 String ciExternalId)
            throws IOException, VisibleUnitTestException {
        return getMtxPurchasedOfferInfo(
                subscription, ciExternalId, null, BigDecimal.ZERO, BigDecimal.ZERO);
    }

    public static MtxPurchasedOfferInfo getMtxPurchasedOfferInfo_PaidNextCycle(MtxResponseSubscription subscription,
                                                                               String ciExternalId)
            throws IOException, VisibleUnitTestException {
        return getMtxPurchasedOfferInfo(
                subscription, ciExternalId, null, BigDecimal.ZERO, BigDecimal.ZERO, true);
    }

    public static MtxPurchasedOfferInfo getMtxPurchasedOfferInfo_PaidCurrentCycle(MtxResponseSubscription subscription,
                                                                                  String ciExternalId)
            throws IOException, VisibleUnitTestException {
        return getMtxPurchasedOfferInfo(
                subscription, ciExternalId, null, BigDecimal.ZERO, BigDecimal.ZERO, false);
    }

    public static MtxPurchasedOfferInfo getMtxPurchasedOfferInfo(MtxResponseSubscription subscription,
                                                                 String ciExternalId,
                                                                 BigDecimal chargeAmount,
                                                                 BigDecimal grantAmount,
                                                                 BigDecimal consumableAmount)
            throws IOException, VisibleUnitTestException {
        return getMtxPurchasedOfferInfo(
                subscription, ciExternalId, chargeAmount, grantAmount, consumableAmount, null);
    }

    @SuppressWarnings("unchecked")
    public static MtxPurchasedOfferInfo getMtxPurchasedOfferInfo(MtxResponseSubscription subscription,
                                                                 String ciExternalId,
                                                                 BigDecimal chargeAmount,
                                                                 BigDecimal grantAmount,
                                                                 BigDecimal consumableAmount,
                                                                 Boolean paidNextCycle)
            throws IOException, VisibleUnitTestException {
        MtxPurchasedOfferInfo resp;
        List<String> annualServices = List.of(
                CI_EXTERNAL_IDS.BASE2ANNUAL, CI_EXTERNAL_IDS.PLUS2ANNUAL,
                CI_EXTERNAL_IDS.BASE3ANNUAL, CI_EXTERNAL_IDS.PLUS3ANNUAL,
                CI_EXTERNAL_IDS.WEARABLE_ANNUAL_2023, CI_EXTERNAL_IDS.PLUS25ANNUAL,
                CI_EXTERNAL_IDS.PRO25ANNUAL);
        List<String> sixMonthServices = List.of(
                CI_EXTERNAL_IDS.BASE6MONTH25, CI_EXTERNAL_IDS.PLUS6MONTH25,
                CI_EXTERNAL_IDS.PRO6MONTH25);
        List<String> gpServices = List.of(
                CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.PLUS3ANNUAL, CI_EXTERNAL_IDS.PLUS25,
                CI_EXTERNAL_IDS.PRO25, CI_EXTERNAL_IDS.BASE2ANNUAL, CI_EXTERNAL_IDS.PLUS2ANNUAL,
                CI_EXTERNAL_IDS.PLUS25ANNUAL, CI_EXTERNAL_IDS.PRO25ANNUAL);
        List<String> monthlyServices = List.of(
                CI_EXTERNAL_IDS.PLUS25, CI_EXTERNAL_IDS.PRO25, CI_EXTERNAL_IDS.BASE2VIS22,
                CI_EXTERNAL_IDS.PLUS2VIS22, CI_EXTERNAL_IDS.BASE3VIS23,
                CI_EXTERNAL_IDS.PLUS3VIS23WB, CI_EXTERNAL_IDS.WEARABLE,
                CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023,
                CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION, CI_EXTERNAL_IDS.INSURANCE,
                CI_EXTERNAL_IDS.SETUP_SERVICES, CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.TRIAL22);
        if (annualServices.contains(ciExternalId) || sixMonthServices.contains(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxPurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "MtxPurchasedOfferInfo_CycleInfo_NO_CI.json");
        } else if (monthlyServices.contains(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxPurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "MtxPurchasedOfferInfo_NO_CI.json");
        } else {
            // Promotion and Gift Grants
            resp = CommonTestHelper.loadJsonMessage(
                    MtxPurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "MtxPurchasedOfferInfo_RequiredBalanceArray_NO_CI.json");
            resp.getRequiredBalanceArray().get(0).setResourceId(
                    getGrantBalanceResourceId(ciExternalId));
            resp.getRequiredBalanceArray().get(0).setTemplateId(
                    BigInteger.valueOf(getGrantBalanceTemplateId(ciExternalId)));

            resp.setEndTime(TestUtils.getFirstDateTimeOfNextYear());
            if (chargeAmount != null) {
                VisiblePurchasedOfferExtension attr = (VisiblePurchasedOfferExtension) resp.getAttr();
                attr.setChargeAmount(chargeAmount);
            }
            MtxBalanceInfo grantBalance;
            if (grantAmount != null) {
                grantBalance = getMtxBalanceInfoForPromoGrant(ciExternalId, grantAmount);
            } else {
                grantBalance = getMtxBalanceInfoForPromoGrant(ciExternalId, BigDecimal.ZERO);
            }
            if (grantBalance != null) {
                subscription.getBalanceArrayAppender().add(grantBalance);
            }

            MtxBalanceInfo consBalance;
            if (consumableAmount != null) {
                consBalance = getMtxBalanceInfoForPromoConsumable(ciExternalId, consumableAmount);
            } else {
                consBalance = getMtxBalanceInfoForPromoConsumable(ciExternalId, BigDecimal.ZERO);
            }
            subscription.getBalanceArrayAppender().add(consBalance);
        }
        if (gpServices.contains(ciExternalId)) {
            MtxBalanceInfo gpBalance = getMtxBalanceInfo(
                    BALANCE_NAMES.GLOBAL_PASS, null, null, BigDecimal.valueOf(10000000000000D),
                    BigDecimal.ONE);
            subscription.getBalanceArrayAppender().add(gpBalance);
            MtxBalanceInfo gpglBalance = getMtxBalanceInfo(
                    BALANCE_NAMES.GP_GL, null, null, BigDecimal.valueOf(10000000000000D),
                    BigDecimal.ONE);
            subscription.getBalanceArrayAppender().add(gpglBalance);
        }

        resp.setCatalogItemExternalId(ciExternalId);
        long instanceCount = 0;
        if (subscription.getPurchasedOfferArray() != null) {
            for (MtxPurchasedOfferInfo mpoi : subscription.getPurchasedOfferArray()) {
                if (ciExternalId.equalsIgnoreCase(mpoi.getCatalogItemExternalId())) {
                    ++instanceCount;
                }
            }
        }

        resp.setResourceId(getOfferResourceId(ciExternalId, instanceCount));
        resp.setProductOfferExternalId(ciExternalId);
        resp.setCatalogItemExternalId(ciExternalId);

        VisiblePurchasedOfferExtension attr = (VisiblePurchasedOfferExtension) resp.getAttr();
        if (paidNextCycle != null) {
            if (paidNextCycle) {
                attr.setPaidCycleStartDate(TestUtils.getFirstDateOfNextMonth());
            } else {
                attr.setPaidCycleStartDate(TestUtils.getFirstDateOfCurrentMonth());
            }
        }
        if (CI_EXTERNAL_IDS.BASE2ANNUAL.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.BASE2ANNUAL);
        } else if (CI_EXTERNAL_IDS.BASE3ANNUAL.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.BASE3ANNUAL);
        } else if (CI_EXTERNAL_IDS.BASE2VIS22.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.BASE2VIS22);
        } else if (CI_EXTERNAL_IDS.BASE3VIS23.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.BASE3VIS23);
        } else if (CI_EXTERNAL_IDS.INSURANCE.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.INSURANCE);
        } else if (CI_EXTERNAL_IDS.PLUS2ANNUAL.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.PLUS2ANNUAL);
        } else if (CI_EXTERNAL_IDS.PLUS3ANNUAL.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.PLUS3ANNUAL);
        } else if (CI_EXTERNAL_IDS.PLUS2VIS22.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.PLUS2VIS22);
        } else if (CI_EXTERNAL_IDS.PLUS3VIS23.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.PLUS3VIS23);
        } else if (CI_EXTERNAL_IDS.PLUS25.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.PLUS25);
        } else if (CI_EXTERNAL_IDS.PRO25.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.PRO25);
        } else if (CI_EXTERNAL_IDS.BASE6MONTH25.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.BASE6MONTH25);
        } else if (CI_EXTERNAL_IDS.PLUS6MONTH25.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.PLUS6MONTH25);
        } else if (CI_EXTERNAL_IDS.PRO6MONTH25.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.PRO6MONTH25);
        } else if (CI_EXTERNAL_IDS.TRIAL22.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.TRIAL22);
        } else if (CI_EXTERNAL_IDS.UNLIMITED.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.UNLIMITED);
        } else if (CI_EXTERNAL_IDS.WEARABLE.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.WEARABLE);
        } else if (CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.WEARABLE_MONTHLY_2023);
        } else if (CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION.equalsIgnoreCase(
                ciExternalId)) {
            attr.setChargeAmount(BigDecimal.ZERO);
        } else if (CI_EXTERNAL_IDS.WEARABLE_ANNUAL_2023.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(BigDecimal.ZERO);
        } else if (CI_EXTERNAL_IDS.SETUP_SERVICES.equalsIgnoreCase(ciExternalId)) {
            resp.setAttr((VisiblePurchasedOfferExtension) null);
        }

        if (resp.getCycleInfo() != null) {
            resp.getCycleInfo().setCycleStartTime(
                    TestUtils.getDateTimeOfMidnightToday(subscription.getTimeZone()));
            if (annualServices.contains(ciExternalId)) {
                resp.getCycleInfo().setCycleEndTime(
                        TestUtils.addOneYear(
                                resp.getCycleInfo().getCycleStartTime(),
                                subscription.getTimeZone()));
            } else if (sixMonthServices.contains(ciExternalId)) {
                resp.getCycleInfo().setCycleEndTime(
                        TestUtils.addMonths(
                                resp.getCycleInfo().getCycleStartTime(), 6,
                                subscription.getTimeZone()));
            } else {
                resp.getCycleInfo().setCycleEndTime(
                        TestUtils.addMonths(
                                resp.getCycleInfo().getCycleStartTime(), 1,
                                subscription.getTimeZone()));
            }
        }

        if (resp.getEndTime() != null) {
            resp.setEndTime(TestUtils.getFirstDateTimeOfYearAfterNextYear());
        }

        subscription.getPurchasedOfferArrayAppender().add(resp);
        return resp;
    }

    public static MtxPurchasedOfferInfo getMtxPurchasedOfferInfo(String ciExternalId,
                                                                 BigDecimal chargeAmount,
                                                                 Boolean paidNextCycle)
            throws IOException, VisibleUnitTestException {
        MtxPurchasedOfferInfo resp;
        Stream<String> annualServices = Stream.of(
                CI_EXTERNAL_IDS.BASE2ANNUAL, CI_EXTERNAL_IDS.PLUS2ANNUAL,
                CI_EXTERNAL_IDS.BASE3ANNUAL, CI_EXTERNAL_IDS.PLUS3ANNUAL);
        Stream<String> monthlyServices = Stream.of(
                CI_EXTERNAL_IDS.BASE2VIS22, CI_EXTERNAL_IDS.PLUS2VIS22, CI_EXTERNAL_IDS.BASE3VIS23,
                CI_EXTERNAL_IDS.PLUS3VIS23WB, CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.TRIAL22,
                CI_EXTERNAL_IDS.WEARABLE, CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023,
                CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION, CI_EXTERNAL_IDS.INSURANCE,
                CI_EXTERNAL_IDS.SETUP_SERVICES);
        if (annualServices.anyMatch(ciExternalId::equalsIgnoreCase)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxPurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "MtxPurchasedOfferInfo_CycleInfo_NO_CI.json");
        } else if (monthlyServices.anyMatch(ciExternalId::equalsIgnoreCase)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxPurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "MtxPurchasedOfferInfo_NO_CI.json");
        } else {
            // Promotion and Gift Grants
            resp = CommonTestHelper.loadJsonMessage(
                    MtxPurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "MtxPurchasedOfferInfo_RequiredBalanceArray_NO_CI.json");
            resp.getRequiredBalanceArray().get(0).setResourceId(
                    getGrantBalanceResourceId(ciExternalId));
            resp.getRequiredBalanceArray().get(0).setTemplateId(
                    BigInteger.valueOf(getGrantBalanceTemplateId(ciExternalId)));

            resp.setEndTime(TestUtils.getFirstDateTimeOfNextYear());
            if (chargeAmount != null) {
                VisiblePurchasedOfferExtension attr = (VisiblePurchasedOfferExtension) resp.getAttr();
                attr.setChargeAmount(chargeAmount);
            }
        }
        resp.setCatalogItemExternalId(ciExternalId);
        long intanceCount = 0;
        resp.setResourceId(getOfferResourceId(ciExternalId, intanceCount));
        resp.setProductOfferExternalId(ciExternalId);
        resp.setCatalogItemExternalId(ciExternalId);
        try {
            System.out.println(resp.getAttr());
        } catch (Exception e) {
            e.printStackTrace();
        }

        VisiblePurchasedOfferExtension attr = (VisiblePurchasedOfferExtension) resp.getAttr();
        if (paidNextCycle != null) {
            if (paidNextCycle) {
                attr.setPaidCycleStartDate(TestUtils.getFirstDateOfNextMonth());
            } else {
                attr.setPaidCycleStartDate(TestUtils.getFirstDateOfCurrentMonth());
            }
        }
        if (CI_EXTERNAL_IDS.BASE2ANNUAL.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.BASE2ANNUAL);
        } else if (CI_EXTERNAL_IDS.BASE3ANNUAL.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.BASE2ANNUAL);
        } else if (CI_EXTERNAL_IDS.BASE2VIS22.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.BASE2VIS22);
        } else if (CI_EXTERNAL_IDS.BASE3VIS23.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.BASE3VIS23);
        } else if (CI_EXTERNAL_IDS.INSURANCE.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.INSURANCE);
        } else if (CI_EXTERNAL_IDS.PLUS2ANNUAL.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.PLUS2ANNUAL);
        } else if (CI_EXTERNAL_IDS.PLUS3ANNUAL.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.PLUS2ANNUAL);
        } else if (CI_EXTERNAL_IDS.PLUS2VIS22.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.PLUS2VIS22);
        } else if (CI_EXTERNAL_IDS.PLUS3VIS23.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.PLUS3VIS23);
        } else if (CI_EXTERNAL_IDS.TRIAL22.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.TRIAL22);
        } else if (CI_EXTERNAL_IDS.UNLIMITED.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.UNLIMITED);
        } else if (CI_EXTERNAL_IDS.WEARABLE.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.WEARABLE);
        } else if (CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023.equalsIgnoreCase(ciExternalId)) {
            attr.setChargeAmount(OFFER_PRICES.WEARABLE_MONTHLY_2023);
        } else if (CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION.equalsIgnoreCase(
                ciExternalId)) {
            attr.setChargeAmount(BigDecimal.ZERO);
        } else if (CI_EXTERNAL_IDS.SETUP_SERVICES.equalsIgnoreCase(ciExternalId)) {
            resp.setAttr((VisiblePurchasedOfferExtension) null);
        }

        if (resp.getCycleInfo() != null) {
            resp.getCycleInfo().setCycleStartTime(TestUtils.getFirstDateTimeOfCurrentMonth());
            resp.getCycleInfo().setCycleEndTime(
                    TestUtils.addOneYear(resp.getCycleInfo().getCycleStartTime()));
        }

        if (resp.getEndTime() != null) {
            resp.setEndTime(TestUtils.getFirstDateTimeOfYearAfterNextYear());
        }

        return resp;
    }

    public static long getBalanceResourceId(String balanceName) {
        if (BALANCE_NAMES.MAIN_BALANCE.equalsIgnoreCase(balanceName)) {
            return 101;
        } else if (BALANCE_NAMES.LONGEVITY_COUNTER.equalsIgnoreCase(balanceName)) {
            return 102;
        } else if (BALANCE_NAMES.COUNTER_MULTIMONTH.equalsIgnoreCase(balanceName)) {
            return 103;
        } else if (BALANCE_NAMES.COUNTER_FREE_TP.equalsIgnoreCase(balanceName)) {
            return 104;
        } else if (BALANCE_NAMES.REF20_GRANT.equalsIgnoreCase(balanceName)) {
            return 105;
        } else if (BALANCE_NAMES.REF20_CONSUMABLE.equalsIgnoreCase(balanceName)) {
            return 106;
        } else if (BALANCE_NAMES.REF35_GRANT.equalsIgnoreCase(balanceName)) {
            return 107;
        } else if (BALANCE_NAMES.REF35_CONSUMABLE.equalsIgnoreCase(balanceName)) {
            return 108;
        } else if (BALANCE_NAMES.FIRST25_GRANT.equalsIgnoreCase(balanceName)) {
            return 109;
        } else if (BALANCE_NAMES.FIRST25_CONSUMABLE.equalsIgnoreCase(balanceName)) {
            return 110;
        } else if (BALANCE_NAMES.THIRTY_FOR_TWO_GRANT.equalsIgnoreCase(balanceName)) {
            return 111;
        } else if (BALANCE_NAMES.THIRTY_FOR_TWO_CONSUMABLE.equalsIgnoreCase(balanceName)) {
            return 112;
        } else if (BALANCE_NAMES.GIFT_GRANT.equalsIgnoreCase(balanceName)) {
            return 113;
        } else if (BALANCE_NAMES.GIFT_CONSUMABLE.equalsIgnoreCase(balanceName)) {
            return 114;
        } else if (BALANCE_NAMES.GOODWILL_GRANT.equalsIgnoreCase(balanceName)) {
            return 115;
        } else if (BALANCE_NAMES.GOODWILL_CONSUMABLE.equalsIgnoreCase(balanceName)) {
            return 116;
        } else if (BALANCE_NAMES.PLUS2535_GRANT.equalsIgnoreCase(balanceName)) {
            return 117;
        } else if (BALANCE_NAMES.PLUS2535_CONSUMABLE.equalsIgnoreCase(balanceName)) {
            return 118;
        } else if (BALANCE_NAMES.BASE2535_GRANT.equalsIgnoreCase(balanceName)) {
            return 119;
        } else if (BALANCE_NAMES.BASE2535_CONSUMABLE.equalsIgnoreCase(balanceName)) {
            return 120;
        } else if (BALANCE_NAMES.FIFTEEN_OFFN_GRANT.equalsIgnoreCase(balanceName)) {
            return 121;
        } else if (BALANCE_NAMES.FIFTEEN_OFFN_CONSUMABLE.equalsIgnoreCase(balanceName)) {
            return 122;
        } else if (BALANCE_NAMES.CA5_GRANT.equalsIgnoreCase(balanceName)) {
            return 123;
        }
        return 199;
    }

    @SuppressWarnings("unchecked")
    public static void addBundledOffers(MtxResponseSubscription subscription,
                                        MtxPurchasedOfferInfo mpoi)
            throws IOException, VisibleUnitTestException {
        String[] offers = null;
        if (CI_EXTERNAL_IDS.SETUP_SERVICES.equalsIgnoreCase(mpoi.getCatalogItemExternalId())) {
            offers = CI_BUNDLES.SETUP_SERVICES.split(",");
        } else if (CI_EXTERNAL_IDS.PLUS3VIS23.equalsIgnoreCase(mpoi.getCatalogItemExternalId())) {
            offers = CI_BUNDLES.PLUS3VIS23.split(",");
        } else if (CI_EXTERNAL_IDS.BASE3VIS23.equalsIgnoreCase(mpoi.getCatalogItemExternalId())) {
            offers = CI_BUNDLES.BASE3VIS23.split(",");
        } else if (CI_EXTERNAL_IDS.UNLIMITED.equalsIgnoreCase(mpoi.getCatalogItemExternalId())) {
            offers = CI_BUNDLES.UNLIMITED.split(",");
        }

        if (offers == null) {
            return;
        }

        for (String offer : offers) {
            MtxPurchasedOfferInfo offerObj = null;
            if (CI_EXTERNAL_IDS.UNLIMITED_VOICE.equalsIgnoreCase(offer)) {
                offerObj = CommonTestHelper.loadJsonMessage(
                        MtxPurchasedOfferInfo.class,
                        DATA_DIR.COMMON + "MtxPurchasedOfferInfo_Visible_Unlimited_Voice.json");
            } else if (CI_EXTERNAL_IDS.UNLIMITED_DATA.equalsIgnoreCase(offer)) {
                offerObj = CommonTestHelper.loadJsonMessage(
                        MtxPurchasedOfferInfo.class,
                        DATA_DIR.COMMON + "MtxPurchasedOfferInfo_Visible_Unlimited_Data.json");
            } else if (CI_EXTERNAL_IDS.UNLIMITED_TEXT.equalsIgnoreCase(offer)) {
                offerObj = CommonTestHelper.loadJsonMessage(
                        MtxPurchasedOfferInfo.class,
                        DATA_DIR.COMMON + "MtxPurchasedOfferInfo_Visible_Unlimited_Text.json");
            } else if (CI_EXTERNAL_IDS.UNLIMITED_MMS.equalsIgnoreCase(offer)) {
                offerObj = CommonTestHelper.loadJsonMessage(
                        MtxPurchasedOfferInfo.class,
                        DATA_DIR.COMMON + "MtxPurchasedOfferInfo_Visible_Unlimited_Text.json");
            } else if (CI_EXTERNAL_IDS.WEARABLE_FREE.equalsIgnoreCase(offer)) {
                offerObj = CommonTestHelper.loadJsonMessage(
                        MtxPurchasedOfferInfo.class,
                        DATA_DIR.COMMON + "MtxPurchasedOfferInfo_Visible_Wearable_Offer_Free.json");
            } else if (CI_EXTERNAL_IDS.TRAVEL_FREE.equalsIgnoreCase(offer)) {
                offerObj = CommonTestHelper.loadJsonMessage(
                        MtxPurchasedOfferInfo.class,
                        DATA_DIR.COMMON + "MtxPurchasedOfferInfo_Visible_TravelPass_Free.json");
            } else if (CI_EXTERNAL_IDS.SETUP_VOICE.equalsIgnoreCase(offer)) {
                offerObj = CommonTestHelper.loadJsonMessage(
                        MtxPurchasedOfferInfo.class,
                        DATA_DIR.COMMON + "MtxPurchasedOfferInfo_Setup_Voice.json");
            } else if (CI_EXTERNAL_IDS.SETUP_DATA.equalsIgnoreCase(offer)) {
                offerObj = CommonTestHelper.loadJsonMessage(
                        MtxPurchasedOfferInfo.class,
                        DATA_DIR.COMMON + "MtxPurchasedOfferInfo_Setup_Data.json");
            } else if (CI_EXTERNAL_IDS.SETUP_TEXT.equalsIgnoreCase(offer)) {
                offerObj = CommonTestHelper.loadJsonMessage(
                        MtxPurchasedOfferInfo.class,
                        DATA_DIR.COMMON + "MtxPurchasedOfferInfo_Setup_Text.json");
            } else if (CI_EXTERNAL_IDS.SETUP_MMS.equalsIgnoreCase(offer)) {
                offerObj = CommonTestHelper.loadJsonMessage(
                        MtxPurchasedOfferInfo.class,
                        DATA_DIR.COMMON + "MtxPurchasedOfferInfo_Setup_MMS.json");
            }
            if (offerObj != null) {
                offerObj.setParentResourceId(mpoi.getResourceId());
                offerObj.setStatus(mpoi.getStatus());
                offerObj.setOfferStatusValue(mpoi.getOfferStatusValue());
                offerObj.setOfferStatusClass(mpoi.getOfferStatusClass());
                offerObj.setOfferStatusDescription(mpoi.getOfferStatusDescription());
                if (OFFER_CONSTANTS.OFFER_STATUS_PRE_ACTIVE.equalsIgnoreCase(
                        mpoi.getOfferStatusDescription())) {
                    offerObj.getRequiredBalanceArrayAppender().clear();
                }

                long instanceCount = 0;
                if (subscription.getPurchasedOfferArray() != null) {
                    for (MtxPurchasedOfferInfo mpoi1 : subscription.getPurchasedOfferArray()) {
                        if (offerObj.getProductOfferExternalId().equalsIgnoreCase(
                                mpoi1.getProductOfferExternalId())) {
                            ++instanceCount;
                        }
                    }
                }
                offerObj.setResourceId(
                        getOfferResourceId(offerObj.getProductOfferExternalId(), instanceCount));

                subscription.getPurchasedOfferArrayAppender().add(offerObj);
            }
        }
    }

    public static long getGrantBalanceResourceId(String grantCiExternalId) {
        if (CI_EXTERNAL_IDS.REF35_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceResourceId(BALANCE_NAMES.REF35_GRANT);
        } else if (CI_EXTERNAL_IDS.FIRST25_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceResourceId(BALANCE_NAMES.FIRST25_GRANT);
        } else if (CI_EXTERNAL_IDS.THIRTY_FOR_TWO_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceResourceId(BALANCE_NAMES.THIRTY_FOR_TWO_GRANT);
        } else if (CI_EXTERNAL_IDS.GIFT_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceResourceId(BALANCE_NAMES.GIFT_GRANT);
        } else if (CI_EXTERNAL_IDS.PLUS_2535_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceResourceId(BALANCE_NAMES.PLUS2535_GRANT);
        } else if (CI_EXTERNAL_IDS.BASE_2535_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceResourceId(BALANCE_NAMES.BASE2535_GRANT);
        } else if (CI_EXTERNAL_IDS.REF20_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceResourceId(BALANCE_NAMES.REF20_GRANT);
        } else if (CI_EXTERNAL_IDS.GRANT_GOODWILL.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceResourceId(BALANCE_NAMES.GOODWILL_GRANT);
        } else if (CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceResourceId(BALANCE_NAMES.FIFTEEN_OFFN_GRANT);
        } else if (CI_EXTERNAL_IDS.CA5_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceResourceId(BALANCE_NAMES.CA5_GRANT);
        }
        return 199;
    }

    public static long getConsumableBalanceResourceId(String grantCiExternalId) {
        if (CI_EXTERNAL_IDS.REF35_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceResourceId(BALANCE_NAMES.REF35_CONSUMABLE);
        } else if (CI_EXTERNAL_IDS.FIRST25_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceResourceId(BALANCE_NAMES.FIRST25_CONSUMABLE);
        } else if (CI_EXTERNAL_IDS.THIRTY_FOR_TWO_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceResourceId(BALANCE_NAMES.THIRTY_FOR_TWO_CONSUMABLE);
        } else if (CI_EXTERNAL_IDS.GIFT_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceResourceId(BALANCE_NAMES.GIFT_CONSUMABLE);
        } else if (CI_EXTERNAL_IDS.PLUS_2535_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceResourceId(BALANCE_NAMES.PLUS2535_CONSUMABLE);
        } else if (CI_EXTERNAL_IDS.BASE_2535_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceResourceId(BALANCE_NAMES.BASE2535_CONSUMABLE);
        } else if (CI_EXTERNAL_IDS.GRANT_GOODWILL.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceResourceId(BALANCE_NAMES.GOODWILL_CONSUMABLE);
        } else if (CI_EXTERNAL_IDS.REF20_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceResourceId(BALANCE_NAMES.REF20_CONSUMABLE);
        } else if (CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceResourceId(BALANCE_NAMES.FIFTEEN_OFFN_CONSUMABLE);
        }
        return 399;
    }

    public static long getBalanceTemplateId(String balanceName) {
        if (BALANCE_NAMES.MAIN_BALANCE.equalsIgnoreCase(balanceName)) {
            return 201;
        } else if (BALANCE_NAMES.LONGEVITY_COUNTER.equalsIgnoreCase(balanceName)) {
            return 202;
        } else if (BALANCE_NAMES.COUNTER_MULTIMONTH.equalsIgnoreCase(balanceName)) {
            return 203;
        } else if (BALANCE_NAMES.COUNTER_FREE_TP.equalsIgnoreCase(balanceName)) {
            return 204;
        } else if (BALANCE_NAMES.REF20_GRANT.equalsIgnoreCase(balanceName)) {
            return 205;
        } else if (BALANCE_NAMES.REF20_CONSUMABLE.equalsIgnoreCase(balanceName)) {
            return 206;
        } else if (BALANCE_NAMES.REF35_GRANT.equalsIgnoreCase(balanceName)) {
            return 207;
        } else if (BALANCE_NAMES.REF35_CONSUMABLE.equalsIgnoreCase(balanceName)) {
            return 208;
        } else if (BALANCE_NAMES.FIRST25_GRANT.equalsIgnoreCase(balanceName)) {
            return 209;
        } else if (BALANCE_NAMES.FIRST25_CONSUMABLE.equalsIgnoreCase(balanceName)) {
            return 210;
        } else if (BALANCE_NAMES.THIRTY_FOR_TWO_GRANT.equalsIgnoreCase(balanceName)) {
            return 211;
        } else if (BALANCE_NAMES.THIRTY_FOR_TWO_CONSUMABLE.equalsIgnoreCase(balanceName)) {
            return 212;
        } else if (BALANCE_NAMES.GIFT_GRANT.equalsIgnoreCase(balanceName)) {
            return 213;
        } else if (BALANCE_NAMES.GIFT_CONSUMABLE.equalsIgnoreCase(balanceName)) {
            return 214;
        } else if (BALANCE_NAMES.GOODWILL_GRANT.equalsIgnoreCase(balanceName)) {
            return 215;
        } else if (BALANCE_NAMES.GOODWILL_CONSUMABLE.equalsIgnoreCase(balanceName)) {
            return 216;
        } else if (BALANCE_NAMES.PLUS2535_GRANT.equalsIgnoreCase(balanceName)) {
            return 217;
        } else if (BALANCE_NAMES.PLUS2535_CONSUMABLE.equalsIgnoreCase(balanceName)) {
            return 218;
        } else if (BALANCE_NAMES.BASE2535_GRANT.equalsIgnoreCase(balanceName)) {
            return 219;
        } else if (BALANCE_NAMES.BASE2535_CONSUMABLE.equalsIgnoreCase(balanceName)) {
            return 220;
        } else if (BALANCE_NAMES.FIFTEEN_OFFN_GRANT.equalsIgnoreCase(balanceName)) {
            return 221;
        } else if (BALANCE_NAMES.FIFTEEN_OFFN_CONSUMABLE.equalsIgnoreCase(balanceName)) {
            return 222;
        } else if (BALANCE_NAMES.CA5_GRANT.equalsIgnoreCase(balanceName)) {
            return 223;
        } else if (BALANCE_NAMES.CA5_CONSUMABLE.equalsIgnoreCase(balanceName)) {
            return 224;
        }
        return 299;
    }

    public static long getGrantBalanceTemplateId(String grantCiExternalId) {
        if (CI_EXTERNAL_IDS.REF35_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceTemplateId(BALANCE_NAMES.REF35_GRANT);
        } else if (CI_EXTERNAL_IDS.FIRST25_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceTemplateId(BALANCE_NAMES.FIRST25_GRANT);
        } else if (CI_EXTERNAL_IDS.THIRTY_FOR_TWO_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceTemplateId(BALANCE_NAMES.THIRTY_FOR_TWO_GRANT);
        } else if (CI_EXTERNAL_IDS.GIFT_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceTemplateId(BALANCE_NAMES.GIFT_GRANT);
        } else if (CI_EXTERNAL_IDS.PLUS_2535_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceTemplateId(BALANCE_NAMES.PLUS2535_GRANT);
        } else if (CI_EXTERNAL_IDS.BASE_2535_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceTemplateId(BALANCE_NAMES.BASE2535_GRANT);
        } else if (CI_EXTERNAL_IDS.REF20_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceTemplateId(BALANCE_NAMES.REF20_GRANT);
        } else if (CI_EXTERNAL_IDS.GRANT_GOODWILL.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceTemplateId(BALANCE_NAMES.GOODWILL_GRANT);
        } else if (CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceTemplateId(BALANCE_NAMES.FIFTEEN_OFFN_GRANT);
        } else if (CI_EXTERNAL_IDS.CA5_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceTemplateId(BALANCE_NAMES.CA5_GRANT);
        }
        return 299;
    }

    public static long getConsumableBalanceTemplateId(String grantCiExternalId) {
        if (CI_EXTERNAL_IDS.REF35_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceTemplateId(BALANCE_NAMES.REF35_CONSUMABLE);
        } else if (CI_EXTERNAL_IDS.FIRST25_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceTemplateId(BALANCE_NAMES.FIRST25_CONSUMABLE);
        } else if (CI_EXTERNAL_IDS.THIRTY_FOR_TWO_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceTemplateId(BALANCE_NAMES.THIRTY_FOR_TWO_CONSUMABLE);
        } else if (CI_EXTERNAL_IDS.GIFT_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceTemplateId(BALANCE_NAMES.GIFT_CONSUMABLE);
        } else if (CI_EXTERNAL_IDS.PLUS_2535_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceTemplateId(BALANCE_NAMES.PLUS2535_CONSUMABLE);
        } else if (CI_EXTERNAL_IDS.BASE_2535_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceTemplateId(BALANCE_NAMES.BASE2535_CONSUMABLE);
        } else if (CI_EXTERNAL_IDS.GRANT_GOODWILL.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceTemplateId(BALANCE_NAMES.GOODWILL_CONSUMABLE);
        } else if (CI_EXTERNAL_IDS.REF20_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceTemplateId(BALANCE_NAMES.REF20_CONSUMABLE);
        } else if (CI_EXTERNAL_IDS.CA5_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return getBalanceTemplateId(BALANCE_NAMES.CA5_CONSUMABLE);
        }
        return 499;
    }

    public static String getGrantBalanceName(String grantCiExternalId) {
        if (CI_EXTERNAL_IDS.REF35_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return BALANCE_NAMES.REF35_GRANT;
        } else if (CI_EXTERNAL_IDS.REF20_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return BALANCE_NAMES.REF20_GRANT;
        } else if (CI_EXTERNAL_IDS.FIRST25_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return BALANCE_NAMES.FIRST25_GRANT;
        } else if (CI_EXTERNAL_IDS.THIRTY_FOR_TWO_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return BALANCE_NAMES.THIRTY_FOR_TWO_GRANT;
        } else if (CI_EXTERNAL_IDS.GIFT_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return BALANCE_NAMES.GIFT_GRANT;
        } else if (CI_EXTERNAL_IDS.PLUS_2535_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return BALANCE_NAMES.PLUS2535_GRANT;
        } else if (CI_EXTERNAL_IDS.BASE_2535_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return BALANCE_NAMES.BASE2535_GRANT;
        } else if (CI_EXTERNAL_IDS.GRANT_GOODWILL.equalsIgnoreCase(grantCiExternalId)) {
            return BALANCE_NAMES.GOODWILL_GRANT;
        } else if (CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return BALANCE_NAMES.FIFTEEN_OFFN_GRANT;
        }

        return "";
    }

    public static String getConsumableBalanceName(String grantCiExternalId) {
        if (CI_EXTERNAL_IDS.GRANT_GOODWILL.equalsIgnoreCase(grantCiExternalId)) {
            return BALANCE_NAMES.GOODWILL_CONSUMABLE;
        } else if (CI_EXTERNAL_IDS.REF20_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return BALANCE_NAMES.REF20_CONSUMABLE;
        }

        return "";
    }

    public static MtxBalanceInfo getMtxBalanceInfo(BalanceInfo bi) throws VisibleUnitTestException {
        BalanceInfo biClone = (BalanceInfo) cloneContainer(bi);
        biClone.getThresholdArrayAppender().clear();
        biClone.getAttrListAppender().clear();
        biClone.setBalanceTemplateDetails((PricingBalanceDetailInfo) null);
        JsonObject jsonObj = new JsonObject();
        biClone.toJson(jsonObj);
        jsonObj.attribute("$", MtxBalanceInfo.class.getSimpleName());
        jsonObj.remove("DisplayPrecision");
        jsonObj.remove("DisplayQuantityUnit");
        jsonObj.remove("EndTimeAdjustType");
        jsonObj.remove("IsActualCurrency");
        jsonObj.remove("IsDeviceSpecific");
        jsonObj.remove("IsHidden");
        jsonObj.remove("IsMainBalance");
        jsonObj.remove("IsMeter");
        DataContainerFactory dcf = DataContainerFactory.getInstance();
        DataContainer dc = new DataContainer(dcf);
        dc.readFrom(jsonObj);
        MtxBalanceInfo retVal = new MtxBalanceInfo(dc);

        return retVal;
    }

    public static MtxBalanceInfo getMtxBalanceInfoForPromoGrant(String ciExternalId,
                                                                BigDecimal availableAmount)
            throws IOException, VisibleUnitTestException {
        MtxBalanceInfo resp = null;

        if (CI_EXTERNAL_IDS.GIFT_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceInfo_AnnualPlanGift_Grant.json");
        } else if (CI_EXTERNAL_IDS.REF35_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_REF35_Grant.json");
        } else if (CI_EXTERNAL_IDS.REF20_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class, DATA_DIR.COMMON + "MtxBalanceInfo_REF20_Grant.json");
        } else if (CI_EXTERNAL_IDS.FIRST25_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Promo_Discount_Grant_FIRST25.json");
        } else if (CI_EXTERNAL_IDS.THIRTY_FOR_TWO_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class, DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_30FOR2.json");
        } else if (CI_EXTERNAL_IDS.GRANT_GOODWILL.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Grant.json");
        } else if (CI_EXTERNAL_IDS.PLUS_2535_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class, DATA_DIR.COMMON + "MtxBalanceInfo_2535PLUS_Grant.json");
        } else if (CI_EXTERNAL_IDS.BASE_2535_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class, DATA_DIR.COMMON + "MtxBalanceInfo_2535BASE_Grant.json");
        } else if (CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class, DATA_DIR.COMMON + "MtxBalanceInfo_15OFFN_Grant.json");
        } else if (CI_EXTERNAL_IDS.GENERIC_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceInfo_GENRICPROMO_Grant.json");
        } else if (CI_EXTERNAL_IDS.CA5_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class, DATA_DIR.COMMON + "MtxBalanceInfo_CA5_Grant.json");
        }

        resp.setResourceId(getGrantBalanceResourceId(ciExternalId));
        resp.setTemplateId(BigInteger.valueOf(getGrantBalanceTemplateId(ciExternalId)));

        if (availableAmount != null) {
            resp.setAmount(availableAmount.negate());
            resp.setAvailableAmount(availableAmount);
        } else {
            resp.setAmount(BigDecimal.ZERO);
            resp.setAvailableAmount(BigDecimal.ZERO);
        }

        resp.setStartTime(TestUtils.getFirstDateTimeOfLastMonth());
        resp.setEndTime(TestUtils.getFirstDateTimeOfYearAfterNextYear());

        return resp;
    }

    public static MtxBalanceInfo getMtxBalanceInfoForPromoConsumable(String ciExternalId,
                                                                     BigDecimal availableAmount)
            throws IOException, VisibleUnitTestException {
        MtxBalanceInfo resp = null;
        if (CI_EXTERNAL_IDS.GIFT_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceInfo_AnnualPlanGift_Consumable.json");
        } else if (CI_EXTERNAL_IDS.REF35_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_REF35_Consumable.json");
        } else if (CI_EXTERNAL_IDS.REF20_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class, DATA_DIR.COMMON + "MtxBalanceInfo_REF20_Consumable.json");
        } else if (CI_EXTERNAL_IDS.FIRST25_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class, DATA_DIR.PAYMENT_ADVICE
                            + "MtxBalanceInfo_Promo_Discount_Consumable_FIRST25.json");
        } else if (CI_EXTERNAL_IDS.THIRTY_FOR_TWO_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_30FOR2_Consumable.json");
        } else if (CI_EXTERNAL_IDS.PARTY_PAY_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_PartyPay_Consumable.json");
        } else if (CI_EXTERNAL_IDS.GRANT_GOODWILL.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Consumable.json");
        } else if (CI_EXTERNAL_IDS.PLUS_2535_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceInfo_2535PLUS_Consumable.json");
        } else if (CI_EXTERNAL_IDS.BASE_2535_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceInfo_2535BASE_Consumable.json");
        } else if (CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceInfo_15OFFN_Consumable.json");
        } else if (CI_EXTERNAL_IDS.GENERIC_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceInfo_GENRICPROMO_Consumable.json");
        } else if (CI_EXTERNAL_IDS.VBPP5_AOC_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceInfo_VBPP-CORE_Consumable.json");
        } else if (CI_EXTERNAL_IDS.CA5_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class, DATA_DIR.COMMON + "MtxBalanceInfo_CA5_Consumable.json");
        }
        resp.setResourceId(getConsumableBalanceResourceId(ciExternalId));
        resp.setTemplateId(BigInteger.valueOf(getConsumableBalanceTemplateId(ciExternalId)));

        if (availableAmount != null) {
            resp.setAmount(availableAmount.negate());
            resp.setAvailableAmount(availableAmount);
        } else {
            resp.setAmount(BigDecimal.ZERO);
            resp.setAvailableAmount(BigDecimal.ZERO);
        }

        resp.setStartTime(TestUtils.getFirstDateTimeOfLastMonth());
        resp.setEndTime(TestUtils.getFirstDateTimeOfYearAfterNextYear());

        return resp;
    }

    public static BalanceInfo getBalanceInfoForPromoGrant(String ciExternalId,
                                                          BigDecimal availableAmount)
            throws IOException, VisibleUnitTestException {
        BalanceInfo resp = null;

        if (CI_EXTERNAL_IDS.GIFT_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    BalanceInfo.class, DATA_DIR.COMMON + "BalanceInfo_AnnualPlanGift_Grant.json");
        } else if (CI_EXTERNAL_IDS.FIRST25_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    BalanceInfo.class, DATA_DIR.COMMON + "BalanceInfo_FIRST25_Grant.json");
        } else if (CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    BalanceInfo.class, DATA_DIR.COMMON + "BalanceInfo_15OFFN_Grant.json");
        } else if (CI_EXTERNAL_IDS.REF20_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    BalanceInfo.class, DATA_DIR.COMMON + "BalanceInfo_REF20_Grant.json");
        } else if (CI_EXTERNAL_IDS.GENERIC_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    BalanceInfo.class, DATA_DIR.COMMON + "BalanceInfo_GENERIC_Grant.json");
        } else if (CI_EXTERNAL_IDS.CA5_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    BalanceInfo.class, DATA_DIR.COMMON + "BalanceInfo_CA5_Grant.json");
        }

        resp.setResourceId(getGrantBalanceResourceId(ciExternalId));
        resp.setTemplateId(BigInteger.valueOf(getGrantBalanceTemplateId(ciExternalId)));

        if (availableAmount != null) {
            resp.setAmount(availableAmount.negate());
            resp.setAvailableAmount(availableAmount);
        } else {
            resp.setAmount(BigDecimal.ZERO);
            resp.setAvailableAmount(BigDecimal.ZERO);
        }

        resp.setStartTime(TestUtils.getFirstDateTimeOfCurrentMonth());
        resp.setEndTime(TestUtils.getFirstDateTimeOfYearAfterNextYear());

        return resp;
    }

    public static BalanceInfo getBalanceInfoForPromoConsumable(String ciExternalId,
                                                               BigDecimal availableAmount)
            throws IOException, VisibleUnitTestException {
        BalanceInfo resp = null;
        if (CI_EXTERNAL_IDS.GIFT_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    BalanceInfo.class,
                    DATA_DIR.COMMON + "BanaceInfo_AnnualPlanGift_Consumable.json");
        } else if (CI_EXTERNAL_IDS.FIRST25_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    BalanceInfo.class, DATA_DIR.COMMON + "BanaceInfo_FIRST25_Consumable.json");
        } else if (CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    BalanceInfo.class, DATA_DIR.COMMON + "BanaceInfo_15OFFN_Consumable.json");
        } else if (CI_EXTERNAL_IDS.REF20_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    BalanceInfo.class, DATA_DIR.COMMON + "BanaceInfo_REF20_Consumable.json");
        } else if (CI_EXTERNAL_IDS.GENERIC_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    BalanceInfo.class, DATA_DIR.COMMON + "BanaceInfo_GENERIC_Consumable.json");
        } else if (CI_EXTERNAL_IDS.CA5_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    BalanceInfo.class, DATA_DIR.COMMON + "BalanceInfo_CA5_Consumable.json");
        }

        resp.setResourceId(getConsumableBalanceResourceId(ciExternalId));
        resp.setTemplateId(BigInteger.valueOf(getConsumableBalanceTemplateId(ciExternalId)));

        if (availableAmount != null) {
            resp.setAmount(availableAmount.negate());
            resp.setAvailableAmount(availableAmount);
        } else {
            resp.setAmount(BigDecimal.ZERO);
            resp.setAvailableAmount(BigDecimal.ZERO);
        }

        resp.setStartTime(TestUtils.getFirstDateTimeOfCurrentMonth());
        resp.setEndTime(TestUtils.getFirstDateTimeOfYearAfterNextYear());

        return resp;
    }

    public static PurchasedOfferInfo getPreactivePurchasedOfferInfoForServicOffer(SubscriptionResponse subResp,
                                                                                  String ciExternalId)
            throws IOException, VisibleUnitTestException {
        PurchasedOfferInfo poi = getPurchasedOfferInfoForServicOffer(subResp, ciExternalId);
        poi.setCycleInfo((MtxPurchasedItemCycleInfo) null);
        poi.setAutoActivationTime(TestUtils.getFirstDateTimeOfNextMonth());
        poi.setOfferStatusDescription(OFFER_CONSTANTS.OFFER_STATUS_PRE_ACTIVE);
        return poi;
    }

    public static PurchasedOfferInfo getPurchasedOfferInfoForServicOffer(SubscriptionResponse subResp,
                                                                         String ciExternalId)
            throws IOException, VisibleUnitTestException {
        return getPurchasedOfferInfoForServicOffer(subResp, ciExternalId, null, null, false);
    }

    public static PurchasedOfferInfo getPurchasedOfferInfoForServicOffer(SubscriptionResponse subResp,
                                                                         String ciExternalId,
                                                                         Boolean paidNextCycle)
            throws IOException, VisibleUnitTestException {
        return getPurchasedOfferInfoForServicOffer(
                subResp, ciExternalId, null, null, paidNextCycle);
    }

    @SuppressWarnings({
        "unchecked"
    })
    public static PurchasedOfferInfo getPurchasedOfferInfoForServicOffer(SubscriptionResponse subResp,
                                                                         String ciExternalId,
                                                                         BigDecimal grantAmount,
                                                                         BigDecimal consumableAmount,
                                                                         Boolean paidNextCycle)
            throws IOException, VisibleUnitTestException {

        Stream<String> gpServices = Stream.of(
                CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.PLUS3ANNUAL, CI_EXTERNAL_IDS.PLUS25,
                CI_EXTERNAL_IDS.PLUS25ANNUAL, CI_EXTERNAL_IDS.PRO25, CI_EXTERNAL_IDS.PRO25ANNUAL);

        PurchasedOfferInfo resp = null;
        boolean serviceOffer = true;
        if (CI_EXTERNAL_IDS.SETUP_SERVICES.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_Setup_Services.json");
        } else if (CI_EXTERNAL_IDS.BASE2ANNUAL.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_BASE2VISANNUAL22.json");
        } else if (CI_EXTERNAL_IDS.BASE3ANNUAL.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_BASE3VISIBLE23A.json");
        } else if (CI_EXTERNAL_IDS.BASE2VIS22.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_BASE2VISIBLE22.json");
        } else if (CI_EXTERNAL_IDS.BASE3VIS23.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_BASE3VISIBLE23.json");
        } else if (CI_EXTERNAL_IDS.BASE3ANNUAL.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_BASE3VISIBLE23A.json");
        } else if (CI_EXTERNAL_IDS.TRIAL22.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_VISIBLETRIAL.json");
        } else if (CI_EXTERNAL_IDS.PLUS2ANNUAL.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_PLUS2VISANNUAL22.json");
        } else if (CI_EXTERNAL_IDS.PLUS2VIS22.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_PLUS2VIS22WB.json");
        } else if (CI_EXTERNAL_IDS.PLUS3VIS23.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_PLUS3VIS23WB.json");
        } else if (CI_EXTERNAL_IDS.PLUS3ANNUAL.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_PLUS3VIS23WBA.json");
        } else if (CI_EXTERNAL_IDS.PLUS25.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_PLUS4VIS25WB.json");
        } else if (CI_EXTERNAL_IDS.PLUS25ANNUAL.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_PLUS4VIS25WBA.json");
        } else if (CI_EXTERNAL_IDS.PRO25.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_PPLUS1VIS25WB.json");
        } else if (CI_EXTERNAL_IDS.PRO25ANNUAL.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_PPLUS1VIS25WBA.json");
        } else if (CI_EXTERNAL_IDS.BASE6MONTH25.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_BASE6VISIBLE25.json");
        } else if (CI_EXTERNAL_IDS.PLUS6MONTH25.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_PLUS6VIS25WB.json");
        } else if (CI_EXTERNAL_IDS.PRO6MONTH25.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_PPLUS6VIS25WB.json");
        } else if (CI_EXTERNAL_IDS.UNLIMITED.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_Visible_Unlimited.json");
        } else if (CI_EXTERNAL_IDS.INSURANCE.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_Insurance.json");
        } else if (CI_EXTERNAL_IDS.WEARABLE.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_CDVISIBLE2022.json");
        } else if (CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION.equalsIgnoreCase(
                ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_CD2VISIBLE2023.json");
        } else if (CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_CD3VISIBLE2023.json");
        } else if (CI_EXTERNAL_IDS.GIFT_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_GrantGift.json");
            serviceOffer = false;
        } else if (CI_EXTERNAL_IDS.FIRST25_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_First25Grant.json");
            serviceOffer = false;
        } else if (CI_EXTERNAL_IDS.GENERIC_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_GenericGrant.json");
            serviceOffer = false;
        } else if (CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_15OFFN_Grant.json");
            serviceOffer = false;
        } else if (CI_EXTERNAL_IDS.CA5_GRANT.equalsIgnoreCase(ciExternalId)) {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_CA5_Grant.json");
            serviceOffer = false;
        } else {
            resp = CommonTestHelper.loadJsonMessage(
                    PurchasedOfferInfo.class,
                    DATA_DIR.COMMON + "PurchasedOfferInfo_Visible_Unlimited.json");
            resp.setCatalogItemExternalId(ciExternalId);
        }
        resp.setAutoActivationTime((MtxTimestamp) null);
        resp.setOfferStatusDescription(OFFER_STATUS.ACTIVE);
        if (resp.getCycleInfo() != null) {
            MtxTimestamp startTime = TestUtils.getFirstDateTimeOfCurrentMonth(
                    subResp.getTimeZone());
            MtxTimestamp endTime = CommonUtils.getCycleEndDate(
                    startTime, subResp.getTimeZone(), resp.getCycleInfo().getPeriod(),
                    resp.getCycleInfo().getPeriodInterval(), subResp.getBillingCycle());
            resp.getCycleInfo().setCycleStartTime(startTime);
            resp.getCycleInfo().setCycleEndTime(endTime);
        }

        long intanceCount = 0;
        if (subResp.getPurchasedOfferArray() != null) {
            intanceCount = subResp.getPurchasedOfferArray().stream().filter(
                    mpoi -> mpoi.getCatalogItemExternalId().equalsIgnoreCase(ciExternalId)).count();
        }
        resp.setResourceId(getOfferResourceId(ciExternalId, intanceCount));
        resp.setProductOfferExternalId(ciExternalId);
        VisiblePurchasedOfferExtension attr = (VisiblePurchasedOfferExtension) resp.getAttr();
        BigDecimal offerPrice = getOfferPrice(ciExternalId);

        if (CI_EXTERNAL_IDS.SETUP_SERVICES.equalsIgnoreCase(ciExternalId)) {
            resp.setAttr((VisiblePurchasedOfferExtension) null);
        }
        if (attr != null && attr instanceof VisiblePurchasedOfferExtension) {
            if (serviceOffer) {
                attr.setChargeAmount(offerPrice);
                if (paidNextCycle) {
                    attr.setPaidCycleStartDate(
                            TestUtils.getMtxDateFromMtxTimestamp(
                                    subResp.getBillingCycle().getCurrentPeriodEndTime()));
                } else {
                    attr.setPaidCycleStartDate(
                            TestUtils.getMtxDateFromMtxTimestamp(
                                    subResp.getBillingCycle().getCurrentPeriodStartTime()));
                }
            } else {
                // add balances for promos
                BalanceInfo grantBalance;
                if (grantAmount != null) {
                    grantBalance = getBalanceInfoForPromoGrant(ciExternalId, grantAmount);
                } else {
                    grantBalance = getBalanceInfoForPromoGrant(ciExternalId, BigDecimal.ZERO);
                }
                if (grantBalance != null) {
                    if (CI_EXTERNAL_IDS.CA5_GRANT.equalsIgnoreCase(ciExternalId)) {
                        grantBalance.setAvailableAmount(BigDecimal.valueOf(1000));
                        grantBalance.setAmount(grantBalance.getAvailableAmount().negate());
                    }
                    subResp.getWalletBalancesAppender().add(grantBalance);
                    MtxBalanceInfo grantBalanceClone = getMtxBalanceInfo(grantBalance);
                    subResp.getBalanceArrayAppender().add(grantBalanceClone);
                }

                BalanceInfo consBalance;
                if (consumableAmount != null) {
                    consBalance = getBalanceInfoForPromoConsumable(ciExternalId, consumableAmount);
                } else {
                    consBalance = getBalanceInfoForPromoConsumable(ciExternalId, BigDecimal.ZERO);
                }
                subResp.getWalletBalancesAppender().add(consBalance);
                MtxBalanceInfo consBalanceClone = getMtxBalanceInfo(consBalance);
                subResp.getBalanceArrayAppender().add(consBalanceClone);
            }
        }

        subResp.getPurchasedOfferArrayAppender().add(resp);

        if (gpServices.anyMatch(ciExternalId::equalsIgnoreCase)) {
            BalanceInfo gpBalance = getBalanceInfo(BALANCE_NAMES.GLOBAL_PASS, null, null, null);
            subResp.getWalletBalancesAppender().add(gpBalance);
        }
        return resp;
    }

    public static VisibleOfferDetails getVisibleOfferDetailsForServicOffer(String ciExternalId)
            throws IOException, VisibleUnitTestException {
        VisibleOfferDetails resp = CommonTestHelper.loadJsonMessage(
                VisibleOfferDetails.class,
                DATA_DIR.CHANGE_SERVICE_ADVICE + "VisibleOfferDetails_NO_CI.json");
        resp.setCatalogItemExternalId(ciExternalId);
        resp.setChargeAmount(getOfferPrice(ciExternalId));
        Stream<String> baseStream = Stream.of(
                CI_EXTERNAL_IDS.BASE2ANNUAL, CI_EXTERNAL_IDS.PLUS2ANNUAL,
                CI_EXTERNAL_IDS.BASE2VIS22, CI_EXTERNAL_IDS.PLUS2VIS22, CI_EXTERNAL_IDS.UNLIMITED);
        if (baseStream.anyMatch(ciExternalId::equalsIgnoreCase)) {
            resp.setOfferType(OFFER_CONSTANTS.OFFER_TYPE_BASE);
        } else if (CI_EXTERNAL_IDS.INSURANCE.equalsIgnoreCase(ciExternalId)) {
            resp.setOfferType(OFFER_CONSTANTS.OFFER_TYPE_INSURANCE);
        } else if (CI_EXTERNAL_IDS.WEARABLE.equalsIgnoreCase(ciExternalId)) {
            resp.setOfferType(OFFER_CONSTANTS.OFFER_TYPE_ADDON);
        }
        resp.setOfferType(ciExternalId);
        resp.setConsumableMainBalanceAmount(BigDecimal.ZERO);
        resp.setPayableAmount(resp.getChargeAmount());
        resp.setResourceId("1");
        return resp;
    }

    public static VisibleOfferDetailsInternal getVisibleOfferDetailsInternalForServicOffer(String ciExternalId,
                                                                                           MtxBillingCycleInfo billCycle) {
        List<String> annualList = List.of(
                CI_EXTERNAL_IDS.BASE2ANNUAL, CI_EXTERNAL_IDS.BASE3ANNUAL,
                CI_EXTERNAL_IDS.PLUS2ANNUAL, CI_EXTERNAL_IDS.PLUS3ANNUAL,
                CI_EXTERNAL_IDS.PLUS25ANNUAL, CI_EXTERNAL_IDS.PRO25ANNUAL);
        List<String> sixMonthList = List.of(
                CI_EXTERNAL_IDS.BASE6MONTH25, CI_EXTERNAL_IDS.PLUS6MONTH25,
                CI_EXTERNAL_IDS.PRO6MONTH25);
        VisibleOfferDetailsInternal vod = new VisibleOfferDetailsInternal();
        List<String> baseList = new ArrayList<>(
                Arrays.asList(
                        CI_EXTERNAL_IDS.BASE2VIS22, CI_EXTERNAL_IDS.PLUS2VIS22,
                        CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.BASE3VIS23,
                        CI_EXTERNAL_IDS.PLUS3VIS23WB, CI_EXTERNAL_IDS.PLUS25,
                        CI_EXTERNAL_IDS.PRO25));
        baseList.addAll(annualList);
        baseList.addAll(sixMonthList);
        List<String> addonList = List.of(
                CI_EXTERNAL_IDS.WEARABLE, CI_EXTERNAL_IDS.WEARABLE_ANNUAL_2023,
                CI_EXTERNAL_IDS.WEARABLE_FREE, CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023,
                CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION);
        if (baseList.contains(ciExternalId)) {
            vod.setOfferType(OFFER_CONSTANTS.OFFER_TYPE_BASE);
        } else if (CI_EXTERNAL_IDS.INSURANCE.equalsIgnoreCase(ciExternalId)) {
            vod.setOfferType(OFFER_CONSTANTS.OFFER_TYPE_INSURANCE);
        } else if (addonList.contains(ciExternalId)) {
            vod.setOfferType(OFFER_CONSTANTS.OFFER_TYPE_ADDON);
        }

        vod.setCatalogItemExternalId(ciExternalId);
        vod.setChargeAmount(getOfferPrice(ciExternalId));
        vod.setPayableAmount(getOfferPrice(ciExternalId));
        vod.setCycleStartTime(billCycle.getCurrentPeriodStartTime().getTime());
        vod.setCycleEndTime(billCycle.getCurrentPeriodEndTime().getTime());
        if (annualList.contains(ciExternalId)) {
            vod.setCycleEndTime(
                    TestUtils.addOneYear(billCycle.getCurrentPeriodStartTime()).getTime());
        } else if (sixMonthList.contains(ciExternalId)) {
            vod.setCycleEndTime(
                    TestUtils.addMonths(billCycle.getCurrentPeriodStartTime(), 6).getTime());
        }
        return vod;
    }

    public static MtxBalanceImpactInfo getMtxBalanceImpactInfoForSingleItemMainBalance(String ciExternalId)
            throws IOException, VisibleUnitTestException {
        MtxBalanceImpactInfo resp = CommonTestHelper.loadJsonMessage(
                MtxBalanceImpactInfo.class,
                DATA_DIR.COMMON + "MtxBalanceImpactInfo_SingleItem_Mainbalance.json");
        resp.getAtBalanceImpactOfferList(0).setCatalogItemExternalId(ciExternalId);
        resp.getAtBalanceImpactOfferList(0).setOfferExternalId(ciExternalId);
        resp.getAtBalanceImpactOfferList(0).getAtBalanceImpactUpdateList(0).setNonProratedAmount(
                getOfferPrice(ciExternalId));
        return resp;
    }

    public static MtxResponseWallet modifyWalletMainBalance(MtxResponseWallet wallet,
                                                            BigDecimal mainbalance) {
        wallet.getBalanceArray().forEach(bi -> {
            if (bi instanceof MtxBalanceInfoSimple) {
                if (((MtxBalanceInfoSimple) bi).getIsMainBalance()) {
                    bi.setAmount(mainbalance.negate());
                    bi.setAvailableAmount(mainbalance);
                    bi.setResourceId(getBalanceResourceId(BALANCE_NAMES.MAIN_BALANCE));
                }
            }
        });
        return wallet;
    }

    public static MtxResponseWallet getMtxResponseWallet(BigDecimal mainbalance)
            throws IOException, VisibleUnitTestException {
        MtxResponseWallet resp = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.COMMON + "MtxResponseWallet.json");
        resp.getBillingCycle().setCurrentPeriodStartTime(
                TestUtils.getFirstDateTimeOfCurrentMonth());
        resp.getBillingCycle().setCurrentPeriodOffset(1L);
        resp.getBillingCycle().setCurrentPeriodEndTime(TestUtils.getFirstDateTimeOfNextMonth());
        return modifyWalletMainBalance(resp, mainbalance);
    }

    public static MtxResponseWallet getMtxResponseWallet(String timeZone, BigDecimal mainbalance)
            throws IOException, VisibleUnitTestException {
        MtxResponseWallet resp = CommonTestHelper.loadJsonMessage(
                MtxResponseWallet.class, DATA_DIR.COMMON + "MtxResponseWallet.json");
        resp.getBillingCycle().setCurrentPeriodStartTime(
                TestUtils.getDateTimeOfMidnightToday(timeZone));
        resp.getBillingCycle().setCurrentPeriodOffset(
                TestUtils.getDayOfMonthFromMtxTimestamp(
                        resp.getBillingCycle().getCurrentPeriodStartTime()));
        resp.getBillingCycle().setCurrentPeriodEndTime(
                TestUtils.addMonths(
                        resp.getBillingCycle().getCurrentPeriodStartTime(), 1, timeZone));
        return modifyWalletMainBalance(resp, mainbalance);
    }

    public static BigDecimal getOfferPrice(String ci) {

        if (CI_EXTERNAL_IDS.BASE3VIS23.equalsIgnoreCase(ci))
            return OFFER_PRICES.BASE3VIS23;
        else if (CI_EXTERNAL_IDS.BASE6MONTH25.equalsIgnoreCase(ci))
            return OFFER_PRICES.BASE6MONTH25;
        else if (CI_EXTERNAL_IDS.BASE3ANNUAL.equalsIgnoreCase(ci))
            return OFFER_PRICES.BASE3ANNUAL;

        else if (CI_EXTERNAL_IDS.PLUS25.equalsIgnoreCase(ci))
            return OFFER_PRICES.PLUS25;
        else if (CI_EXTERNAL_IDS.PLUS6MONTH25.equalsIgnoreCase(ci))
            return OFFER_PRICES.PLUS6MONTH25;
        else if (CI_EXTERNAL_IDS.PLUS25ANNUAL.equalsIgnoreCase(ci))
            return OFFER_PRICES.PLUS25ANNUAL;
        else if (CI_EXTERNAL_IDS.PRO25.equalsIgnoreCase(ci))
            return OFFER_PRICES.PRO25;
        else if (CI_EXTERNAL_IDS.PRO6MONTH25.equalsIgnoreCase(ci))
            return OFFER_PRICES.PRO6MONTH25;
        else if (CI_EXTERNAL_IDS.PRO25ANNUAL.equalsIgnoreCase(ci))
            return OFFER_PRICES.PRO25ANNUAL;

        else if (CI_EXTERNAL_IDS.INSURANCE.equalsIgnoreCase(ci))
            return OFFER_PRICES.INSURANCE;
        else if (CI_EXTERNAL_IDS.WEARABLE_INSURANCE.equalsIgnoreCase(ci))
            return OFFER_PRICES.WEARABLE_INSURANCE;
        else if (CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION.equalsIgnoreCase(ci))
            return OFFER_PRICES.FREE_WEARABLE_MONTHLY_ACTIVATION;
        else if (CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023.equalsIgnoreCase(ci))
            return OFFER_PRICES.WEARABLE_MONTHLY_2023;

        /*********** Gradfatherd Services *******************/
        else if (CI_EXTERNAL_IDS.BASE2VIS22.equalsIgnoreCase(ci))
            return OFFER_PRICES.BASE2VIS22;
        else if (CI_EXTERNAL_IDS.BASE2ANNUAL.equalsIgnoreCase(ci))
            return OFFER_PRICES.BASE2ANNUAL;

        else if (CI_EXTERNAL_IDS.PLUS2VIS22.equalsIgnoreCase(ci))
            return OFFER_PRICES.PLUS2VIS22;
        else if (CI_EXTERNAL_IDS.PLUS2ANNUAL.equalsIgnoreCase(ci))
            return OFFER_PRICES.PLUS2ANNUAL;

        else if (CI_EXTERNAL_IDS.PLUS3VIS23.equalsIgnoreCase(ci))
            return OFFER_PRICES.PLUS3VIS23;
        else if (CI_EXTERNAL_IDS.PLUS3ANNUAL.equalsIgnoreCase(ci))
            return OFFER_PRICES.PLUS3ANNUAL;

        else if (CI_EXTERNAL_IDS.UNLIMITED.equalsIgnoreCase(ci))
            return OFFER_PRICES.UNLIMITED;
        else if (CI_EXTERNAL_IDS.WEARABLE.equalsIgnoreCase(ci))
            return OFFER_PRICES.WEARABLE;
        else
            return BigDecimal.ZERO;
    }

    public static MtxResponsePricingCatalogItem getMtxResponsePricingCatalogItem(String ci)
            throws IOException, VisibleUnitTestException {
        MtxResponsePricingCatalogItem resp = null;

        // In market Services
        if (CI_EXTERNAL_IDS.BASE3VIS23.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_BASE3VISIBLE23.json");
        else if (CI_EXTERNAL_IDS.BASE6MONTH25.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_BASE6VISIBLE25.json");
        else if (CI_EXTERNAL_IDS.BASE3ANNUAL.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_BASE3VISIBLE23A.json");

        else if (CI_EXTERNAL_IDS.PLUS25.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_PLUS4VIS25WB.json");
        else if (CI_EXTERNAL_IDS.PLUS6MONTH25.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_PLUS6VIS25WB.json");
        else if (CI_EXTERNAL_IDS.PLUS25ANNUAL.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_PLUS4VIS25WBA.json");

        else if (CI_EXTERNAL_IDS.PRO25.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_PPLUS1VIS25WB.json");
        else if (CI_EXTERNAL_IDS.PRO25ANNUAL.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_PPLUS1VIS25WBA.json");

        else if (CI_EXTERNAL_IDS.INSURANCE.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class, DATA_DIR.PAYMENT_ADVICE
                            + "MtxResponsePricingCatalogItem_Visible_Insurance.json");

        else if (CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_CD3VISIBLE2023.json");
        else if (CI_EXTERNAL_IDS.WEARABLE_ANNUAL_2023.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_CD2VISIBLE2023A.json");
        else if (CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_CD2VISIBLE2023.json");
        else if (CI_EXTERNAL_IDS.TRIAL22.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_VISIBLETRIAL22.json");

        // GrandFathered Services
        else if (CI_EXTERNAL_IDS.UNLIMITED.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class, DATA_DIR.PAYMENT_ADVICE
                            + "MtxResponsePricingCatalogItem_Visible_Unlimited.json");

        else if (CI_EXTERNAL_IDS.BASE2VIS22.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_BASE2VISIBLE22.json");
        else if (CI_EXTERNAL_IDS.BASE2ANNUAL.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_BASE2VISANNUAL22.json");

        else if (CI_EXTERNAL_IDS.PLUS2VIS22.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_PLUS2VIS22WB.json");
        else if (CI_EXTERNAL_IDS.PLUS2ANNUAL.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_PLUS2VISANNUAL22.json");

        else if (CI_EXTERNAL_IDS.PLUS3VIS23WB.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_PLUS3VIS23WB.json");
        else if (CI_EXTERNAL_IDS.PLUS3ANNUAL.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_PLUS3VIS23WBA.json");

        else if (CI_EXTERNAL_IDS.WEARABLE.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class, DATA_DIR.PAYMENT_ADVICE
                            + "MtxResponsePricingCatalogItem_Visible_Wearable.json");

        // Credits
        else if (CI_EXTERNAL_IDS.PARTY_PAY_GRANT.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class, DATA_DIR.PAYMENT_ADVICE
                            + "MtxResponsePricingCatalogItem_Visible_Group_Grant.json");
        else if (CI_EXTERNAL_IDS.PARTY_PAY_REDEEM.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class, DATA_DIR.PAYMENT_ADVICE
                            + "MtxResponsePricingCatalogItem_Visible_Redeem_Group_Discount.json");
        else if (CI_EXTERNAL_IDS.VBPP5_AOC_GRANT.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_Visible_VBPP5_AOC_Grant.json");
        else if (CI_EXTERNAL_IDS.VBPP25_AOC_GRANT.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class, DATA_DIR.PAYMENT_ADVICE
                            + "MtxResponsePricingCatalogItem_Visible_VBPP25_AOC_Grant.json");
        else if (CI_EXTERNAL_IDS.CHIME_AOC_GRANT.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class, DATA_DIR.PAYMENT_ADVICE
                            + "MtxResponsePricingCatalogItem_Visible_CHIME_AOC_CI.json");
        else if (CI_EXTERNAL_IDS.BONUS_MONEY_REDEEM.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_BONUS_REDEEM.json");
        else if (CI_EXTERNAL_IDS.CA5_GRANT.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_Visible_CA5_Grant.json");

        else if (CI_EXTERNAL_IDS.GRANT_GOODWILL.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class, DATA_DIR.COMMON
                            + "MtxResponsePricingCatalogItem_Visible_Grant_Goodwill_Credits.json");
        else if (CI_EXTERNAL_IDS.GOODWILL_REDEEM.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class, DATA_DIR.PAYMENT_ADVICE
                            + "MtxResponsePricingCatalogItem_Visible_Redeem_Goodwill_Credits.json");
        else if (CI_EXTERNAL_IDS.REF35_GRANT.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class, DATA_DIR.PAYMENT_ADVICE
                            + "MtxResponsePricingCatalogItem_Visible_REF35_Grant.json");
        else if (CI_EXTERNAL_IDS.REF20_GRANT.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_Visible_REF20_Grant.json");
        else if (CI_EXTERNAL_IDS.REF_REDEEM.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class, DATA_DIR.PAYMENT_ADVICE
                            + "MtxResponsePricingCatalogItem_Visible_REF35_Redeem.json");

        else if (CI_EXTERNAL_IDS.GIFT_GRANT.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_GIFT_Grant.json");
        else if (CI_EXTERNAL_IDS.FIRST25_GRANT.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_Visible_FIRST25_Grant.json");
        else if (CI_EXTERNAL_IDS.AMAZON_REDEEM.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class, DATA_DIR.PAYMENT_ADVICE
                            + "MtxResponsePricingCatalogItem_Visible_Redeem_Amazon_PrePay_Discount.json");
        else if (CI_EXTERNAL_IDS.THIRTY_FOR_TWO_GRANT.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class, DATA_DIR.PAYMENT_ADVICE
                            + "MtxResponsePricingCatalogItem_Visible_30FOR2_Grant.json");
        else if (CI_EXTERNAL_IDS.PLUS_2535_GRANT.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_Visible_2535PLUS_Grant.json");
        else if (CI_EXTERNAL_IDS.BASE_2535_GRANT.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_Visible_2535BASE_Grant.json");
        else if (CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_Visible_15OFFN_Grant.json");
        else if (CI_EXTERNAL_IDS.FIRST25_GRANT.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class,
                    DATA_DIR.COMMON + "MtxResponsePricingCatalogItem_Visible_FIRST25_Grant.json");
        else if (CI_EXTERNAL_IDS.GENERIC_GRANT.equalsIgnoreCase(ci))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class, DATA_DIR.COMMON
                            + "MtxResponsePricingCatalogItem_Visible_GENRICPROMO_Grant.json");

        return resp;
    }

    public static MtxResponsePricingOffer getMtxResponsePricingOffer(String offerExternalId)
            throws VisibleUnitTestException, IOException {
        MtxResponsePricingOffer resp = null;
        if (CI_EXTERNAL_IDS.UNLIMITED_DATA.equalsIgnoreCase(offerExternalId))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingOffer.class,
                    DATA_DIR.COMMON + "MtxResponsePricingOffer_UnlimitedData.json");
        else if (CI_EXTERNAL_IDS.DEVICE_INSURANCE.equalsIgnoreCase(offerExternalId))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingOffer.class,
                    DATA_DIR.COMMON + "MtxResponsePricingOffer_DeviceInsurance.json");
        return resp;
    }

    public static MtxBalanceInfo getMtxBalanceInfoFromSubscriber(MtxResponseSubscription subscription,
                                                                 String balanceName)
            throws IOException {
        if (subscription.getBalanceArray() != null) {
            for (MtxBalanceInfo bal : subscription.getBalanceArray()) {
                if (balanceName.equalsIgnoreCase(bal.getName()))
                    return bal;
            }
        }
        return null;
    }

    public static MtxBalanceInfo setSubscriberBalanceAmount(MtxResponseSubscription subscription,
                                                            String balanceName,
                                                            BigDecimal availableAmount)
            throws IOException {
        return setSubscriberBalanceAmount(
                subscription, balanceName, availableAmount, availableAmount.negate());

    }

    public static MtxBalanceInfo setSubscriberBalanceAmount(MtxResponseSubscription subscription,
                                                            String balanceName,
                                                            BigDecimal availableAmount,
                                                            BigDecimal amount)
            throws IOException {
        if (subscription.getBalanceArray() != null) {
            for (MtxBalanceInfo bal : subscription.getBalanceArray()) {
                if (balanceName.equalsIgnoreCase(bal.getName()))
                    bal.setAvailableAmount(availableAmount);
                bal.setAmount(amount);
            }
        }
        return null;
    }

    public static MtxBalanceInfo getMtxBalanceInfo(String balanceName, BigDecimal availableAmount)
            throws IOException, VisibleUnitTestException {
        return getMtxBalanceInfo(balanceName, null, null, availableAmount);
    }

    public static MtxBalanceInfo getMtxBalanceInfo(String balanceName,
                                                   Long resourceId,
                                                   Long templateId,
                                                   BigDecimal availableAmount)
            throws IOException, VisibleUnitTestException {
        return getMtxBalanceInfo(balanceName, resourceId, templateId, availableAmount, null);
    }

    public static MtxBalanceInfo getMtxBalanceInfo(String balanceName,
                                                   Long resourceId,
                                                   Long templateId,
                                                   BigDecimal availableAmount,
                                                   BigDecimal amount)
            throws IOException, VisibleUnitTestException {
        MtxBalanceInfo resp = null;
        if (BALANCE_NAMES.MAIN_BALANCE.equalsIgnoreCase(balanceName))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class, DATA_DIR.COMMON + "MtxBalanceInfo_Mainbalance.json");
        else if (BALANCE_NAMES.GOODWILL_GRANT.equalsIgnoreCase(balanceName))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Grant.json");
        else if (BALANCE_NAMES.GOODWILL_CONSUMABLE.equalsIgnoreCase(balanceName))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceInfo_Goodwill_Consumable.json");
        else if (BALANCE_NAMES.REF20_GRANT.equalsIgnoreCase(balanceName))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class, DATA_DIR.COMMON + "MtxBalanceInfo_REF20_Grant.json");
        else if (BALANCE_NAMES.GLOBAL_PASS.equalsIgnoreCase(balanceName))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class, DATA_DIR.COMMON + "MtxBalanceInfo_Free_GP_Bank.json");
        else if (BALANCE_NAMES.GP_GL.equalsIgnoreCase(balanceName))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceInfo.class, DATA_DIR.COMMON + "MtxBalanceInfo_GPGLBalance.json");

        if (resourceId != null) {
            resp.setResourceId(resourceId);
        }

        if (templateId != null) {
            resp.setTemplateId(BigInteger.valueOf(templateId));
        }

        if (availableAmount != null) {
            resp.setAvailableAmount(availableAmount);
        } else {
            resp.setAvailableAmount(BigDecimal.ZERO);
        }

        if (amount != null) {
            resp.setAmount(amount);
        } else if (availableAmount != null) {
            resp.setAmount(availableAmount.negate());
        }

        if (resp.getStartTime() != null) {
            resp.setStartTime(TestUtils.getFirstDateTimeOfCurrentMonth());
        }
        return resp;
    }

    public static BalanceInfo getBalanceInfo(String balanceName, BigDecimal availableAmount)
            throws IOException, VisibleUnitTestException {
        return getBalanceInfo(balanceName, null, null, availableAmount);
    }

    public static BalanceInfo getBalanceInfo(String balanceName,
                                             Long resourceId,
                                             Long templateId,
                                             BigDecimal availableAmount)
            throws IOException, VisibleUnitTestException {
        BalanceInfo resp = null;
        if (BALANCE_NAMES.MAIN_BALANCE.equalsIgnoreCase(balanceName))
            resp = CommonTestHelper.loadJsonMessage(
                    BalanceInfo.class, DATA_DIR.COMMON + "BalanceInfo_Mainbalance.json");
        else if (BALANCE_NAMES.GIFT_GRANT.equalsIgnoreCase(balanceName))
            resp = CommonTestHelper.loadJsonMessage(
                    BalanceInfo.class, DATA_DIR.COMMON + "BalanceInfo_AnnualPlanGift_Grant.json");
        else if (BALANCE_NAMES.GIFT_CONSUMABLE.equalsIgnoreCase(balanceName))
            resp = CommonTestHelper.loadJsonMessage(
                    BalanceInfo.class,
                    DATA_DIR.COMMON + "BanaceInfo_AnnualPlanGift_Consumable.json");
        else if (BALANCE_NAMES.GLOBAL_PASS.equalsIgnoreCase(balanceName))
            resp = CommonTestHelper.loadJsonMessage(
                    BalanceInfo.class, DATA_DIR.COMMON + "BalanceInfo_GlobalPass.json");
        if (resourceId != null) {
            resp.setResourceId(resourceId);
        }

        if (templateId != null) {
            resp.setTemplateId(BigInteger.valueOf(templateId));
        }

        if (availableAmount != null) {
            resp.setAmount(availableAmount.negate());
            resp.setAvailableAmount(availableAmount);
        } else {
            resp.setAmount(BigDecimal.ZERO);
            resp.setAvailableAmount(BigDecimal.ZERO);
        }

        if (resp.getStartTime() != null) {
            resp.setStartTime(TestUtils.getFirstDateTimeOfCurrentMonth());
        }
        return resp;
    }

    public static MtxBalanceImpactInfo getMtxBalanceImpactInfo(String serviceCi,
                                                               String balanceName,
                                                               BigDecimal impactAmount)
            throws IOException, VisibleUnitTestException {
        return getMtxBalanceImpactInfo(serviceCi, null, balanceName, impactAmount);
    }

    public static MtxBalanceImpactInfo getMtxBalanceImpactInfo(String serviceCi,
                                                               Long serviceResourceId,
                                                               String balanceName,
                                                               BigDecimal impactAmount)
            throws IOException, VisibleUnitTestException {
        MtxBalanceImpactInfo resp = null;

        if (BALANCE_NAMES.MAIN_BALANCE.equalsIgnoreCase(balanceName)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_SingleItem_Mainbalance.json");
            resp.getAtBalanceImpactOfferList(0).setCatalogItemExternalId(serviceCi);
            resp.getAtBalanceImpactOfferList(0).setOfferExternalId(serviceCi);
            if (serviceResourceId != null) {
                resp.getAtBalanceImpactOfferList(0).setOfferResourceId(serviceResourceId);
            }
            resp.getAtBalanceImpactOfferList(0).getAtBalanceImpactUpdateList(
                    0).setNonProratedAmount(getOfferPrice(serviceCi));
            resp.getAtBalanceImpactOfferList(0).getAtBalanceImpactUpdateList(0).setAmount(
                    impactAmount);
            resp.setBalanceTemplateName(balanceName);
            resp.setImpactAmount(impactAmount);
        } else if (getConsumableBalanceName(CI_EXTERNAL_IDS.GRANT_GOODWILL).equalsIgnoreCase(
                balanceName)
                || getConsumableBalanceName(CI_EXTERNAL_IDS.REF20_GRANT).equalsIgnoreCase(
                        balanceName)) {

            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_SingleItem_Mainbalance.json");
            resp.getAtBalanceImpactOfferList(0).setCatalogItemExternalId(serviceCi);
            resp.getAtBalanceImpactOfferList(0).setOfferExternalId(serviceCi);
            if (serviceResourceId != null) {
                resp.getAtBalanceImpactOfferList(0).setOfferResourceId(serviceResourceId);
            }
            resp.getAtBalanceImpactOfferList(0).getAtBalanceImpactUpdateList(
                    0).setNonProratedAmount(getOfferPrice(serviceCi));
            resp.getAtBalanceImpactOfferList(0).getAtBalanceImpactUpdateList(0).setAmount(
                    impactAmount);
            resp.setImpactAmount(impactAmount);
            resp.setIsMainBalance(false);
            resp.setIsActualCurrency(false);
            if (getConsumableBalanceName(CI_EXTERNAL_IDS.GRANT_GOODWILL).equalsIgnoreCase(
                    balanceName)) {
                resp.setBalanceResourceId(
                        getConsumableBalanceResourceId(CI_EXTERNAL_IDS.GRANT_GOODWILL));
                resp.setBalanceTemplateId(
                        BigInteger.valueOf(
                                getConsumableBalanceTemplateId(CI_EXTERNAL_IDS.GRANT_GOODWILL)));
            } else if (getConsumableBalanceName(CI_EXTERNAL_IDS.REF20_GRANT).equalsIgnoreCase(
                    balanceName)) {
                resp.setBalanceResourceId(
                        getConsumableBalanceResourceId(CI_EXTERNAL_IDS.REF20_GRANT));
                resp.setBalanceTemplateId(
                        BigInteger.valueOf(
                                getConsumableBalanceTemplateId(CI_EXTERNAL_IDS.REF20_GRANT)));
            }
            resp.setBalanceTemplateName(balanceName);
        } else if (BALANCE_NAMES.COUNTER_MULTIMONTH.equalsIgnoreCase(balanceName)
                || BALANCE_NAMES.COUNTER_FREE_TP.equalsIgnoreCase(balanceName)
                || BALANCE_NAMES.LONGEVITY_COUNTER.equalsIgnoreCase(balanceName)
                || BALANCE_NAMES.GLOBAL_PASS.equalsIgnoreCase(balanceName)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_SingleItem_Mainbalance.json");
            resp.getAtBalanceImpactOfferList(0).setCatalogItemExternalId(serviceCi);
            resp.getAtBalanceImpactOfferList(0).setOfferExternalId(serviceCi);
            resp.getAtBalanceImpactOfferList(0).getAtBalanceImpactUpdateList(
                    0).setNonProratedAmount(impactAmount.negate());
            resp.getAtBalanceImpactOfferList(0).getAtBalanceImpactUpdateList(0).setAmount(
                    impactAmount);
            resp.setImpactAmount(impactAmount);
            resp.setCurrentBalanceAmount(impactAmount);
            resp.setIsMainBalance(false);
            resp.setIsActualCurrency(false);
            resp.setBalanceResourceId(getBalanceResourceId(balanceName));
            resp.setBalanceTemplateId(BigInteger.valueOf(getBalanceTemplateId(balanceName)));
            resp.setBalanceClassId(1003L);
            resp.setBalanceClassName("Flag");
            resp.setBalanceTemplateName(balanceName);
        }
        return resp;
    }

    public static MtxResponsePurchase getMtxResponsePurchase(String serviceCi, BigDecimal aocAmount)
            throws IOException, VisibleUnitTestException, InstantiationException, IllegalAccessException {
        return getMtxResponsePurchase(serviceCi, aocAmount, null);
    }

    public static MtxResponsePurchase getMtxResponsePurchase_NoBalanceImpact(String serviceCi,
                                                                             BigDecimal aocAmount)
            throws VisibleUnitTestException, IOException {
        MtxResponsePurchase aocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class,
                DATA_DIR.COMMON + "MtxResponsePurchase_NoBalanceImpact.json");
        aocResp.getAtPurchaseInfoArray(0).setCatalogItemExternalId(serviceCi);
        aocResp.getAtPurchaseInfoArray(0).setExternalId(serviceCi);
        return aocResp;
    }

    @SuppressWarnings("unchecked")
    public static MtxResponsePurchase getMtxResponsePurchase(String serviceCi,
                                                             BigDecimal aocAmount,
                                                             SubscriptionResponse subResp)
            throws IOException, VisibleUnitTestException, InstantiationException, IllegalAccessException {
        MtxResponsePurchase aocResp =  getMtxResponsePurchase(Map.of(serviceCi,aocAmount),
                                                   subResp);
        return aocResp;
    }

    public static MtxResponsePurchase getMtxResponsePurchaseMultiBalance(String serviceCi,
                                                                         BigDecimal mainBalanceAmount,
                                                                         Map<String, BigDecimal> promoImpactMap)
            throws IOException, VisibleUnitTestException {
        return getMtxResponsePurchaseMultiBalance(
                serviceCi, mainBalanceAmount, promoImpactMap, null, null);
    }

    public static MtxResponsePurchase getMtxResponsePurchaseMultiBalance(String serviceCi,
                                                                         BigDecimal mainBalanceAmount,
                                                                         Map<String, BigDecimal> promoImpactMap,
                                                                         Map<String, BigDecimal> balImpactMap,
                                                                         Boolean noMain)
            throws IOException, VisibleUnitTestException {
        return getMtxResponsePurchaseMultiBalance(
                serviceCi, mainBalanceAmount, promoImpactMap, balImpactMap, null, noMain);
    }

    @SuppressWarnings("unchecked")
    public static MtxResponsePurchase getMtxResponsePurchaseMultiBalance(String serviceCi,
                                                                         BigDecimal mainBalanceAmount,
                                                                         Map<String, BigDecimal> promoImpactMap,
                                                                         Map<String, BigDecimal> balImpactMap,
                                                                         List<MtxRequiredBalanceInfo> reqBalList,
                                                                         Boolean noMain)
            throws IOException, VisibleUnitTestException {
        MtxResponsePurchase aocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        aocResp.getAtPurchaseInfoArray(0).setCatalogItemExternalId(serviceCi);
        aocResp.getAtPurchaseInfoArray(0).setExternalId(serviceCi);

        if (noMain == null || !noMain) {
            MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfo(
                    serviceCi, BALANCE_NAMES.MAIN_BALANCE, mainBalanceAmount);
            biiMain.setImpactAmount(mainBalanceAmount);
            aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
        }

        if (promoImpactMap != null && !promoImpactMap.isEmpty()) {
            for (String grantName : promoImpactMap.keySet()) {
                String consBalName = getConsumableBalanceName(grantName);
                MtxBalanceImpactInfo biiCons = CommonTestHelper.getMtxBalanceImpactInfo(
                        serviceCi, consBalName, promoImpactMap.get(grantName));
                aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                        0).getBalanceImpactListAppender().add(biiCons);
            }
        }

        if (balImpactMap != null && !balImpactMap.isEmpty()) {
            for (String balName : balImpactMap.keySet()) {
                MtxBalanceImpactInfo biiCons = CommonTestHelper.getMtxBalanceImpactInfo(
                        serviceCi, balName, balImpactMap.get(balName));
                aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                        0).getBalanceImpactListAppender().add(biiCons);
            }
        }

        Stream<String> annualServices = Stream.of(
                CI_EXTERNAL_IDS.BASE2ANNUAL, CI_EXTERNAL_IDS.PLUS2ANNUAL,
                CI_EXTERNAL_IDS.BASE3ANNUAL, CI_EXTERNAL_IDS.PLUS3ANNUAL,
                CI_EXTERNAL_IDS.PLUS25ANNUAL, CI_EXTERNAL_IDS.PRO25ANNUAL);
        if (annualServices.anyMatch(serviceCi::equalsIgnoreCase)) {
            MtxTimestamp today = TestUtils.getDateTimeOfMidnightToday();
            aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    today);
            aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.addOneYear(today));
        } else {
            aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getFirstDateTimeOfNextMonth());
        }

        if (reqBalList != null && !reqBalList.isEmpty()) {
            reqBalList.forEach(rbi -> {
                aocResp.getAtPurchaseInfoArray(0).getRequiredBalanceArrayAppender().add(rbi);
            });
        }
        return aocResp;
    }

    @SuppressWarnings("unchecked")
    public static MtxResponsePurchase getMtxResponsePurchase(Map<String, BigDecimal> offerAocMap,
                                                             SubscriptionResponse subResp)
            throws InstantiationException, IllegalAccessException, IOException,
            VisibleUnitTestException {
        List<String> annualServices = List.of(
                CI_EXTERNAL_IDS.BASE2ANNUAL, CI_EXTERNAL_IDS.PLUS2ANNUAL,
                CI_EXTERNAL_IDS.BASE3ANNUAL, CI_EXTERNAL_IDS.PLUS3ANNUAL,
                CI_EXTERNAL_IDS.PLUS25ANNUAL, CI_EXTERNAL_IDS.PRO25ANNUAL);

        List<String> sixMonthServices = List.of(
                CI_EXTERNAL_IDS.BASE6MONTH25, CI_EXTERNAL_IDS.PLUS6MONTH25,
                CI_EXTERNAL_IDS.PRO6MONTH25);

        MtxTimestamp monthlyStartDate;
        MtxTimestamp monthlyEndDate;
        String timezone = "";
        if (subResp == null) {
            monthlyStartDate = TestUtils.getFirstDateTimeOfCurrentMonth();
            monthlyEndDate = TestUtils.addOneMonth(monthlyStartDate);
        } else {
            timezone = subResp.getTimeZone();
            monthlyStartDate = subResp.getBillingCycle().getCurrentPeriodStartTime();
            monthlyEndDate = subResp.getBillingCycle().getCurrentPeriodEndTime();
        }

        MtxTimestamp yearlyStartDate = TestUtils.getDateTimeOfMidnightToday(timezone);
        MtxTimestamp yearlyEndDate = TestUtils.addOneYear(yearlyStartDate, timezone);
        MtxTimestamp sixMonthStartDate = yearlyStartDate;
        MtxTimestamp sixMonthEndDate = TestUtils.addMonths(sixMonthStartDate, 6, timezone);

        MtxResponsePurchase aocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        aocResp.getPurchaseInfoArrayAppender().clear();
        for (String offerCiId : offerAocMap.keySet()) {
            MtxPurchaseInfo purInfo = CommonTestHelper.loadJsonMessage(
                    MtxPurchaseInfo.class, DATA_DIR.COMMON + "MtxPurchaseInfo.json");
            purInfo.setCatalogItemExternalId(offerCiId);
            purInfo.setExternalId(offerCiId);
            MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfo(
                    offerCiId, BALANCE_NAMES.MAIN_BALANCE, offerAocMap.get(offerCiId));
            purInfo.getAtBalanceImpactGroupList(0).getBalanceImpactListAppender().add(biiMain);
            if (annualServices.contains(offerCiId)) {
                purInfo.getAtBalanceImpactGroupList(0).setCycleStartTime(yearlyStartDate);
                purInfo.getAtBalanceImpactGroupList(0).setCycleEndTime(yearlyEndDate);
            } else if (sixMonthServices.contains(offerCiId)) {
                purInfo.getAtBalanceImpactGroupList(0).setCycleStartTime(sixMonthStartDate);
                purInfo.getAtBalanceImpactGroupList(0).setCycleEndTime(sixMonthEndDate);
                purInfo.setStartTime(sixMonthStartDate);
                purInfo.setEndTime(sixMonthEndDate);
            } else {
                purInfo.getAtBalanceImpactGroupList(0).setCycleStartTime(monthlyStartDate);
                purInfo.getAtBalanceImpactGroupList(0).setCycleEndTime(monthlyEndDate);
            }
            aocResp.getPurchaseInfoArrayAppender().add(purInfo);
        }

        return aocResp;

    }

    public static VisiblePurchaseInfo getVisiblePurchaseInfo(String serviceCi)
            throws IOException, VisibleUnitTestException {
        VisiblePurchaseInfo resp = CommonTestHelper.loadJsonMessage(
                VisiblePurchaseInfo.class, DATA_DIR.PAYMENT_ADVICE + "VisiblePurchaseInfo.json");
        ;
        resp.getPurchaseServiceInfo().setServiceOfferExternalId(serviceCi);
        resp.getPurchaseServiceInfo().setServiceDiscountPrice(
                getOfferPrice(serviceCi).toPlainString());
        resp.getPurchaseServiceInfo().setServiceGrossPrice(
                getOfferPrice(serviceCi).toPlainString());
        return resp;
    }

    @SuppressWarnings("unchecked")
    public static MtxResponseMulti getMtxResponsePricingBalances(List<String> balanceList)
            throws IOException, VisibleUnitTestException {
        MtxResponseMulti resp = getEmptyMtxResponseMulti();
        if (balanceList != null) {
            for (String balanceName : balanceList) {
                resp.getResponseListAppender().add(getMtxResponsePricingBalance(balanceName));
            }
        }
        return resp;
    }

    public static MtxResponsePricingBalance getMtxResponsePricingBalance(String banalceName)
            throws IOException, VisibleUnitTestException {
        MtxResponsePricingBalance resp = null;
        if (BALANCE_NAMES.GIFT_GRANT.equalsIgnoreCase(banalceName))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingBalance.class,
                    DATA_DIR.COMMON + "MtxResponsePricingBalance_GiftGrant.json");
        else if (BALANCE_NAMES.GOODWILL_GRANT.equalsIgnoreCase(banalceName))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingBalance.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_GoodwillGrant.json");
        else if (BALANCE_NAMES.REF35_GRANT.equalsIgnoreCase(banalceName))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingBalance.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_REF35Grant.json");
        else if (BALANCE_NAMES.REF20_GRANT.equalsIgnoreCase(banalceName))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingBalance.class,
                    DATA_DIR.COMMON + "MtxResponsePricingBalance_REF20.json");
        else if (BALANCE_NAMES.FIRST25_GRANT.equalsIgnoreCase(banalceName))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingBalance.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_First25Grant.json");
        else if (BALANCE_NAMES.AMZN_GRANT.equalsIgnoreCase(banalceName))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingBalance.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_AMZN.json");
        else if (BALANCE_NAMES.THIRTY_FOR_TWO_GRANT.equalsIgnoreCase(banalceName))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingBalance.class,
                    DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_30FOR2.json");
        else if (BALANCE_NAMES.FIFTEEN_OFFN_GRANT.equalsIgnoreCase(banalceName))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingBalance.class,
                    DATA_DIR.COMMON + "MtxResponsePricingBalance_15OFFN_Grant.json");
        else if (BALANCE_NAMES.PLUS2535_GRANT.equalsIgnoreCase(banalceName))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingBalance.class,
                    DATA_DIR.COMMON + "MtxResponsePricingBalance_2535PLUS_Grant.json");
        else if (BALANCE_NAMES.BASE2535_GRANT.equalsIgnoreCase(banalceName))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingBalance.class,
                    DATA_DIR.COMMON + "MtxResponsePricingBalance_2535BASE_Grant.json");
        else if (BALANCE_NAMES.GENERIC_GRANT.equalsIgnoreCase(banalceName))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingBalance.class,
                    DATA_DIR.COMMON + "MtxResponsePricingBalance_GENRICPROMO_Grant.json");
        else if (BALANCE_NAMES.CA5_GRANT.equalsIgnoreCase(banalceName))
            resp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingBalance.class,
                    DATA_DIR.COMMON + "MtxResponsePricingBalance_CA5_Grant.json");

        return resp;
    }

    public static MtxResponseMulti getMtxResponseMulti_For_CreditBalances(MtxResponseSubscription subscription)
            throws IOException, VisibleUnitTestException {
        List<String> balPriList = new ArrayList<String>();
        if (subscription.getBalanceArray() != null) {
            for (MtxBalanceInfo bal : subscription.getBalanceArray()) {
                if ("Credits".equalsIgnoreCase(bal.getClassName())) {
                    balPriList.add(bal.getName());
                }
            }
        }

        MtxResponseMulti multiResponse = CommonTestHelper.getMtxResponsePricingBalances(balPriList);
        return multiResponse;
    }

    public static MtxResponseRefundPayment getOkMtxResponseRefundPayment() {
        MtxResponseRefundPayment resp = new MtxResponseRefundPayment();
        MtxPaymentRefundInfo pri = new MtxPaymentRefundInfo();
        pri.setIsVoid(false);
        pri.setRefundAmount(BigDecimal.ZERO);
        pri.setRefundTime(TestUtils.getFirstDateTimeOfNextMonth());
        resp.setRefundInfo(pri);
        resp.setResult(RESULT_CODES.MTX_SUCCESS);
        resp.setResultText(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS);
        return resp;
    }

    public static MtxResponse getOkMtxResponse() {
        MtxResponse resp = new MtxResponse();
        resp.setResult(RESULT_CODES.MTX_SUCCESS);
        resp.setResultText(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS);
        return resp;
    }

    public static MtxResponseMulti getEmptyMtxResponseMulti() {
        MtxResponseMulti resp = new MtxResponseMulti();
        resp.setResult(RESULT_CODES.MTX_SUCCESS);
        resp.setResultText(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS);
        return resp;
    }

    public static MtxPaymentMethodInfo getDefaultMtxPaymentMethodInfo()
            throws IOException, VisibleUnitTestException {
        MtxPaymentMethodInfo pmi = loadJsonMessage(
                MtxPaymentMethodInfo.class, DATA_DIR.AUTOPAY + "MtxPaymentMethodInfo.json");
        pmi.setIsDefault(true);
        return pmi;
    }

    public static MtxPaymentMethodInfo getNonDefaultMtxPaymentMethodInfo()
            throws IOException, VisibleUnitTestException {
        MtxPaymentMethodInfo pmi = loadJsonMessage(
                MtxPaymentMethodInfo.class, DATA_DIR.AUTOPAY + "MtxPaymentMethodInfo.json");
        pmi.setIsDefault(false);
        return pmi;
    }

    public static MtxResponseRefundPayment getMtxResponseRefundPayment()
            throws IOException, VisibleUnitTestException {
        MtxResponseRefundPayment rp = loadJsonMessage(
                MtxResponseRefundPayment.class, DATA_DIR.COMMON + "MtxResponseRefundPayment.json");
        return rp;
    }

    public static MtxResponseUser getMtxResponseUser()
            throws IOException, VisibleUnitTestException {
        MtxResponseUser user = CommonTestHelper.loadJsonMessage(
                MtxResponseUser.class, DATA_DIR.COMMON + "MtxResponseUser.json");
        return user;
    }

    public static String getDiscountCalculationMethod(String grantCiExternalId) {
        if (List.of(
                CI_EXTERNAL_IDS.PARTY_PAY_GRANT, CI_EXTERNAL_IDS.CA5_GRANT,
                CI_EXTERNAL_IDS.VBPP25_AOC_GRANT, CI_EXTERNAL_IDS.VBPP5_AOC_GRANT,
                CI_EXTERNAL_IDS.CHIME_AOC_GRANT).contains(grantCiExternalId)) {
            return CREDIT_CONSTANTS.CALCULATION_METHOD_AOC;
        } else {
            return CREDIT_CONSTANTS.CALCULATION_METHOD_READ_OFFER_INSTANCE;
        }
    }

    public static String getGoodType(String grantCiExternalId) {
        if (CI_EXTERNAL_IDS.PARTY_PAY_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return TAX_CLASS_CODES.PARTY_PAY;
        } else if (CI_EXTERNAL_IDS.GRANT_GOODWILL.equalsIgnoreCase(grantCiExternalId)) {
            return TAX_CLASS_CODES.GOODWILL;
        } else {
            return "";
        }
    }

    public static String getPromotionName(String grantCiExternalId) {
        if (CI_EXTERNAL_IDS.GRANT_GOODWILL.equalsIgnoreCase(grantCiExternalId)) {
            return "goodwill";
        } else if (CI_EXTERNAL_IDS.REF35_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return "REF35";
        } else if (CI_EXTERNAL_IDS.FIRST25_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return "FIRST25";
        } else if (CI_EXTERNAL_IDS.THIRTY_FOR_TWO_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return "Summer";
        } else if (CI_EXTERNAL_IDS.GIFT_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return "AnnualPlanGift";
        } else if (CI_EXTERNAL_IDS.PARTY_PAY_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return "PartyPay";
        }
        return "";
    }

    public static String getRedeemOfferName(String grantCiExternalId) {
        if (CI_EXTERNAL_IDS.GRANT_GOODWILL.equalsIgnoreCase(grantCiExternalId)) {
            return CI_EXTERNAL_IDS.GOODWILL_REDEEM;
        } else if (CI_EXTERNAL_IDS.REF35_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return CI_EXTERNAL_IDS.REF35_REDEEM;
        } else if (CI_EXTERNAL_IDS.REF20_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return CI_EXTERNAL_IDS.REF20_REDEEM;
        } else if (CI_EXTERNAL_IDS.FIRST25_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return CI_EXTERNAL_IDS.FIRST25_REDEEM;
        } else if (CI_EXTERNAL_IDS.THIRTY_FOR_TWO_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return CI_EXTERNAL_IDS.THIRTY_FOR_TWO_REDEEM;
        } else if (CI_EXTERNAL_IDS.GIFT_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return CI_EXTERNAL_IDS.GIFT_REDEEM;
        } else if (CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return CI_EXTERNAL_IDS.FIFTEEN_OFFN_REDEEM;
        } else if (CI_EXTERNAL_IDS.VBPP5_AOC_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return CI_EXTERNAL_IDS.VBPP_CORE_REDEEM;
        } else if (CI_EXTERNAL_IDS.PARTY_PAY_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return CI_EXTERNAL_IDS.PARTY_PAY_REDEEM;
        } else if (CI_EXTERNAL_IDS.CA5_GRANT.equalsIgnoreCase(grantCiExternalId)) {
            return CI_EXTERNAL_IDS.CA5_REDEEM;
        }

        return "";
    }

    public static VisibleCredits getVisibleCredits(String grantCiExternalId,
                                                   String applicableCiExternalId,
                                                   BigDecimal grant,
                                                   BigDecimal redeemable)
            throws IOException {
        return getVisibleCredits(
                grantCiExternalId, applicableCiExternalId, grant, null, redeemable, null);
    }

    public static VisibleCredits getVisibleCredits(String grantCiExternalId,
                                                   String applicableCiExternalId,
                                                   BigDecimal redeemable)
            throws IOException {
        return getVisibleCredits(
                grantCiExternalId, applicableCiExternalId, null, null, redeemable, null);
    }

    public static VisibleCredits getVisibleCredits(String grantCiExternalId,
                                                   String applicableCiExternalId,
                                                   BigDecimal grant,
                                                   BigDecimal consumable,
                                                   BigDecimal redeemable,
                                                   BigDecimal transferable)
            throws IOException {
        VisibleCredits vc = new VisibleCredits();
        vc.setApplicableCI(applicableCiExternalId);
        vc.setTaxDetails(getPromoTaxResp(grantCiExternalId, applicableCiExternalId, redeemable));
        vc.setPromotionName(getPromotionName(grantCiExternalId));
        vc.setCreditRedeemableOfferCI(getRedeemOfferName(grantCiExternalId));
        vc.setDiscountCalculationMethod(getDiscountCalculationMethod(grantCiExternalId));
        vc.setRedeemableGoodType(getGoodType(grantCiExternalId));
        if (redeemable != null) {
            vc.setRedeemableCredits(redeemable);
        } else {
            vc.setRedeemableCredits(BigDecimal.ZERO);
        }

        if (grant != null) {
            vc.setAvailableCreditsGrant(grant);
        } else {
            vc.setAvailableCreditsGrant(vc.getRedeemableCredits());
        }

        if (transferable != null) {
            vc.setEstimatedTransferableCredits(transferable);
        } else {
            if (vc.getAvailableCreditsGrant().signum() == 0) {
                vc.setEstimatedTransferableCredits(BigDecimal.ZERO);
            } else {
                vc.setEstimatedTransferableCredits(vc.getRedeemableCredits());
            }
        }

        if (consumable != null) {
            vc.setAvailableCreditsConsumable(consumable);
        } else {
            vc.setAvailableCreditsConsumable(
                    vc.getRedeemableCredits().subtract(vc.getEstimatedTransferableCredits()));
        }

        vc.setAvailableCredits(
                vc.getAvailableCreditsGrant().add(vc.getAvailableCreditsConsumable()));

        return vc;
    }

    public static long getOfferResourceId(String ciExternalId, long instanceNo) {
        if (CI_EXTERNAL_IDS.SETUP_SERVICES.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 50 + 1;
        } else if (CI_EXTERNAL_IDS.UNLIMITED.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 2;
        } else if (CI_EXTERNAL_IDS.BASE2VIS22.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 3;
        } else if (CI_EXTERNAL_IDS.BASE3VIS23.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 4;
        } else if (CI_EXTERNAL_IDS.PLUS2VIS22.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 5;
        } else if (CI_EXTERNAL_IDS.PLUS3VIS23.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 6;
        } else if (CI_EXTERNAL_IDS.PLUS25.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 7;
        } else if (CI_EXTERNAL_IDS.PRO25.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 8;
        } else if (CI_EXTERNAL_IDS.BASE2ANNUAL.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 9;
        } else if (CI_EXTERNAL_IDS.BASE3ANNUAL.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 10;
        } else if (CI_EXTERNAL_IDS.PLUS2ANNUAL.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 11;
        } else if (CI_EXTERNAL_IDS.PLUS3ANNUAL.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 12;
        } else if (CI_EXTERNAL_IDS.PLUS25ANNUAL.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 13;
        } else if (CI_EXTERNAL_IDS.PRO25ANNUAL.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 14;
        } else if (CI_EXTERNAL_IDS.BASE6MONTH25.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 15;
        } else if (CI_EXTERNAL_IDS.PLUS6MONTH25.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 16;
        } else if (CI_EXTERNAL_IDS.PRO6MONTH25.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 17;
        } else if (CI_EXTERNAL_IDS.WEARABLE.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 18;
        } else if (CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 19;
        } else if (CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION.equalsIgnoreCase(
                ciExternalId)) {
            return instanceNo * 20 + 20;
        } else if (CI_EXTERNAL_IDS.WEARABLE_FREE.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 21;
        } else if (CI_EXTERNAL_IDS.TRAVEL_FREE.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 22;
        } else if (CI_EXTERNAL_IDS.FREEGP_HI.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 23;
        } else if (CI_EXTERNAL_IDS.INSURANCE.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 24;
        } else if (CI_EXTERNAL_IDS.SETUP_VOICE.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 25;
        } else if (CI_EXTERNAL_IDS.SETUP_DATA.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 26;
        } else if (CI_EXTERNAL_IDS.SETUP_TEXT.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 27;
        } else if (CI_EXTERNAL_IDS.SETUP_MMS.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 28;
        } else if (CI_EXTERNAL_IDS.UNLIMITED_VOICE.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 29;
        } else if (CI_EXTERNAL_IDS.UNLIMITED_DATA.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 30;
        } else if (CI_EXTERNAL_IDS.UNLIMITED_TEXT.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 31;
        } else if (CI_EXTERNAL_IDS.UNLIMITED_MMS.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 32;
        } else if (CI_EXTERNAL_IDS.UNLIMITED_VOICE_ANNUAL.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 33;
        } else if (CI_EXTERNAL_IDS.UNLIMITED_DATA_ANNUAL.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 34;
        } else if (CI_EXTERNAL_IDS.UNLIMITED_TEXT_ANNUAL.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 35;
        } else if (CI_EXTERNAL_IDS.UNLIMITED_MMS_ANNUAL.equalsIgnoreCase(ciExternalId)) {
            return instanceNo * 20 + 36;
        }
        return 99;
    }

    public static VisibleOfferDetails getVisibleOfferDetails(String ciExternalId,
                                                             MtxBillingCycleInfo billingCycle) {
        return getVisibleOfferDetails(
                ciExternalId,
                new MtxDate(billingCycle.getCurrentPeriodStartTime().getTime().split("T")[0]));
    }

    public static VisibleOfferDetails getVisibleOfferDetails(String ciExternalId,
                                                             MtxBillingCycleInfo billingCycle,
                                                             boolean renewalDue) {
        if (renewalDue) {
            return getVisibleOfferDetails(
                    ciExternalId,
                    new MtxDate(billingCycle.getCurrentPeriodStartTime().getTime().split("T")[0]));
        } else {
            return getVisibleOfferDetails(
                    ciExternalId,
                    new MtxDate(billingCycle.getCurrentPeriodStartTime().getTime().split("T")[0]),
                    BigDecimal.ZERO);
        }
    }

    public static VisibleOfferDetails getVisibleOfferDetails(String ciExternalId,
                                                             MtxDate paidCycleStartDate) {
        return getVisibleOfferDetails(ciExternalId, paidCycleStartDate, null);
    }

    public static VisibleOfferDetails getVisibleOfferDetailsBeforePayment(String ciExternalId,
                                                                          SubscriptionResponse subscription,
                                                                          BigDecimal payableAmount) {
        VisibleOfferDetails vod = getVisibleOfferDetailsNoPayment(
                ciExternalId, subscription, payableAmount);
        vod.setPaidCycleStartDate(
                new MtxDate(
                        subscription.getBillingCycle().getCurrentPeriodStartTime().getTime().split(
                                "T")[0]));
        return vod;
    }

    public static VisibleOfferDetails getVisibleOfferDetailsAfterPayment(String ciExternalId,
                                                                         SubscriptionResponse subscription,
                                                                         BigDecimal payableAmount) {
        VisibleOfferDetails vod = getVisibleOfferDetailsNoPayment(
                ciExternalId, subscription, payableAmount);
        vod.setPaidCycleStartDate(
                new MtxDate(
                        subscription.getBillingCycle().getCurrentPeriodEndTime().getTime().split(
                                "T")[0]));
        return vod;
    }

    public static VisibleOfferDetails getVisibleOfferDetailsNoPayment(String ciExternalId,
                                                                      SubscriptionResponse subscription,
                                                                      BigDecimal payableAmount) {
        VisibleOfferDetails vod = getVisibleOfferDetails(ciExternalId, payableAmount);
        vod.setCycleStartTime(subscription.getBillingCycle().getCurrentPeriodEndTime().getTime());
        vod.setCycleEndTime(
                TestUtils.addMonths(
                        subscription.getBillingCycle().getCurrentPeriodEndTime(), 1).getTime());
        return vod;
    }

    public static VisibleOfferDetails getVisibleOfferDetails(String ciExternalId,
                                                             BigDecimal payableAmount) {
        VisibleOfferDetails vod = new VisibleOfferDetails();
        vod.setCatalogItemExternalId(ciExternalId);
        vod.setResourceId(getOfferResourceId(ciExternalId, 1) + "");
        vod.setTaxDetails(ciExternalId + " Taxes");
        vod.setChargeAmount(getOfferPrice(ciExternalId));
        if (payableAmount != null) {
            vod.setPayableAmount(payableAmount);
        } else {
            vod.setPayableAmount(vod.getChargeAmount());
        }

        if (CI_EXTERNAL_IDS.BASE_LIST.contains(ciExternalId)) {
            vod.setOfferType(OFFER_CONSTANTS.OFFER_TYPE_BASE);
        } else if (CI_EXTERNAL_IDS.ADDON_LIST.contains(ciExternalId)) {
            vod.setOfferType(OFFER_CONSTANTS.OFFER_TYPE_ADDON);
        } else if (CI_EXTERNAL_IDS.INSURANCE_LIST.contains(ciExternalId)) {
            vod.setOfferType(OFFER_CONSTANTS.OFFER_TYPE_INSURANCE);
        }

        return vod;
    }

    public static VisibleOfferDetails getVisibleOfferDetails(String ciExternalId,
                                                             MtxDate paidCycleStartDate,
                                                             BigDecimal payableAmount) {
        return getVisibleOfferDetails(ciExternalId, paidCycleStartDate, payableAmount, null);
    }

    public static VisibleOfferDetails getVisibleOfferDetails(String ciExternalId,
                                                             MtxDate paidCycleStartDate,
                                                             BigDecimal payableAmount,
                                                             SubscriptionResponse subResp) {
        VisibleOfferDetails vod = new VisibleOfferDetails();
        vod.setCatalogItemExternalId(ciExternalId);
        vod.setResourceId(getOfferResourceId(ciExternalId, 1) + "");
        vod.setTaxDetails(ciExternalId + " Taxes");
        vod.setChargeAmount(getOfferPrice(ciExternalId));
        if (paidCycleStartDate != null) {
            vod.setPaidCycleStartDate(paidCycleStartDate);
        } else {
            vod.setPaidCycleStartDate(TestUtils.getFirstDateOfCurrentMonth());
        }

        if (payableAmount != null) {
            vod.setPayableAmount(payableAmount);
        } else {
            vod.setPayableAmount(vod.getChargeAmount());
        }

        if (subResp != null && subResp.getBillingCycle() != null) {
            vod.setCycleStartTime(subResp.getBillingCycle().getCurrentPeriodEndTime().getTime());
            vod.setCycleEndTime(
                    TestUtils.addMonths(
                            subResp.getBillingCycle().getCurrentPeriodEndTime(), 1,
                            subResp.getTimeZone()).getTime());
        }

        if (CI_EXTERNAL_IDS.BASE_LIST.contains(ciExternalId)) {
            vod.setOfferType(OFFER_CONSTANTS.OFFER_TYPE_BASE);
        } else if (CI_EXTERNAL_IDS.ADDON_LIST.contains(ciExternalId)) {
            vod.setOfferType(OFFER_CONSTANTS.OFFER_TYPE_ADDON);
        } else if (CI_EXTERNAL_IDS.INSURANCE_LIST.contains(ciExternalId)) {
            vod.setOfferType(OFFER_CONSTANTS.OFFER_TYPE_INSURANCE);
        }

        return vod;
    }

    @SuppressWarnings("unchecked")
    public static VisibleResponsePaymentAdviceService getPaymentAdviceResponse(InvocationOnMock invocation,
                                                                               SubscriptionResponse subscription) {
        Object[] args = invocation.getArguments();
        VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
        aop.setSubscriberExternalId(subscription.getExternalId());
        aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        aop.setResultText("OK");
        BigDecimal estPayable = BigDecimal.ZERO;
        int lastBit = 1;
        int numOfDevices = CommonUtils.emptyIfNull(subscription.getDeviceIdArray()).size();
        for (MtxPurchasedOfferInfo po : CommonUtils.emptyIfNull(
                subscription.getPurchasedOfferArray())) {
            VisibleOfferDetails vod;
            if (po.getCycleInfo() != null
                    && po.getCycleInfo().getCycleEndTime().longValue() > subscription.getBillingCycle().getCurrentPeriodEndTime().longValue()) {
                vod = CommonTestHelper.getVisibleOfferDetails(
                        po.getCatalogItemExternalId(), TestUtils.getFirstDateOfCurrentMonth(),
                        BigDecimal.ZERO);
            } else {
                vod = CommonTestHelper.getVisibleOfferDetails(
                        po.getCatalogItemExternalId(), TestUtils.getFirstDateOfCurrentMonth());
            }
            aop.getVisibleOfferDetailsListAppender().add(vod);
            estPayable = estPayable.add(vod.getPayableAmount());

            if (OFFER_CONSTANTS.OFFER_TYPE_BASE.equalsIgnoreCase(vod.getOfferType())
                    && (numOfDevices >= 1)) {
                VisibleSubscriberDevice vsd = new VisibleSubscriberDevice();
                vsd.setAccessNumber("1-2-3-" + lastBit++);
                aop.getSubscriberDevicesAppender().add(vsd);
            }
        }

        aop.setEstimatedPayableAmount(estPayable);
        if (numOfDevices == 0) {
            return aop;
        }

        long remainingDevices = numOfDevices
                - CommonUtils.emptyIfNull(aop.getSubscriberDevices()).size();

        for (long numWbl = 0; numWbl < remainingDevices; numWbl++) {
            // If num of device is passed add all devices except service sevice are wearables
            VisibleSubscriberDevice vsd = new VisibleSubscriberDevice();
            vsd.setAccessNumber("1-2-3-" + lastBit++);
            vsd.setDeviceType(DEVICE_CONSTANTS.DEVICE_TYPE_WEARABLE);
            aop.getSubscriberDevicesAppender().add(vsd);
        }
        aop.setEstimatedPayableAmount(estPayable);
        return aop;
    }

    @SuppressWarnings("unchecked")
    public static VisibleResponsePurchaseAdvice getPurchaseAdvice(String baseService,
                                                                  String addonService,
                                                                  String insuranceService,
                                                                  Map<String, BigDecimal> promoGrantCiRedeemMap,
                                                                  MtxResponseWallet wallet)
            throws IOException {
        VisibleResponsePurchaseAdvice aop = new VisibleResponsePurchaseAdvice();

        if (StringUtils.isNotBlank(baseService)) {
            aop.appendToVodList(
                    CommonTestHelper.getVisibleOfferDetailsInternalForServicOffer(
                            baseService, wallet.getBillingCycle()));
        }
        if (StringUtils.isNotBlank(addonService)) {
            aop.appendToVodList(
                    CommonTestHelper.getVisibleOfferDetailsInternalForServicOffer(
                            addonService, wallet.getBillingCycle()));
        }
        if (StringUtils.isNotBlank(insuranceService)) {
            aop.appendToVodList(
                    CommonTestHelper.getVisibleOfferDetailsInternalForServicOffer(
                            insuranceService, wallet.getBillingCycle()));
        }

        aop.setTotalEstimatedAmount(BigDecimal.ZERO);
        aop.getVodList().forEach(vod -> {
            aop.setTotalEstimatedAmount(aop.getTotalEstimatedAmount().add(vod.getPayableAmount()));
        });
        aop.setAvailableMainBalanceAmount(aop.getTotalEstimatedAmount());
        for (Entry<String, BigDecimal> entry : CommonUtils.emptyIfNull(
                promoGrantCiRedeemMap).entrySet()) {
            aop.getCreditsAppender().add(
                    CommonTestHelper.getVisibleCredits(
                            entry.getKey(), baseService, entry.getValue()));
        }

        for (VisibleCredits vc : CommonUtils.emptyIfNull(aop.getCredits())) {
            for (VisibleOfferDetailsInternal vod : CommonUtils.emptyIfNull(aop.getVodList())) {

                if (baseService.equalsIgnoreCase(vod.getCatalogItemExternalId())) {
                    vod.setPayableAmount(
                            vod.getPayableAmount().subtract(vc.getRedeemableCredits()));
                    aop.setAvailableMainBalanceAmount(
                            aop.getAvailableMainBalanceAmount().subtract(
                                    vc.getRedeemableCredits()));
                }
            }
        }

        aop.setConsumableMainBalanceAmount(aop.getTotalEstimatedAmount());
        aop.setEstimatedPayableAmount(BigDecimal.ZERO);
        aop.setCycleStartTime(wallet.getBillingCycle().getCurrentPeriodStartTime().getTime());
        aop.setCycleEndTime(wallet.getBillingCycle().getCurrentPeriodEndTime().getTime());

        return aop;
    }

    public static CreditStage getCreditStage(MtxResponsePricingCatalogItem pci,
                                             ServiceStage ss,
                                             BigDecimal grantAmount,
                                             BigDecimal dollarAmount) {
        VisibleTemplate vt = (VisibleTemplate) pci.getCatalogItemInfo().getTemplateAttr();
        GlobalCreditStage gcs = new GlobalCreditStage(pci.getCatalogItemInfo().getExternalId(), vt);
        gcs.setPromotionName(vt.getPromotionName());
        gcs.setAvailableCredits(dollarAmount.add(grantAmount));
        gcs.setAvailableCreditsConsumable(dollarAmount);
        gcs.setAvailableCreditsGrant(grantAmount);
        gcs.setRedeemOfferCi(vt.getRedeemOffer());
        gcs.setApplicableCiCsv(ss.getCatalogItemExternalId());
        gcs.getApplicableCiOrderMap().put(ss.getCatalogItemExternalId(), 2L);

        CreditStage cs = new CreditStage(gcs, ss.getCatalogItemExternalId());
        cs.setApplicableServiceStage(ss);
        return cs;
    }

    public static String getTaxApiResp(String ciExternalId) throws IOException {
        return getTaxApiResp(ciExternalId, 0, "");
    }

    public static String getTaxApiResp(String ciExternalId, int reducePriceBy) throws IOException {
        return getTaxApiResp(ciExternalId, reducePriceBy, "");
    }

    public static String getTaxApiResp(String ciExternalId, int reducePriceBy, String classCode)
            throws IOException {
        String taxResp = "";

        if (CI_EXTERNAL_IDS.UNLIMITED.equalsIgnoreCase(ciExternalId) && reducePriceBy == 0) {
            taxResp = new String(
                    Files.readAllBytes(Paths.get(DATA_DIR.COMMON + "TaxResponse_UNLIMITED.json")));
        } else if (CI_EXTERNAL_IDS.BASE2VIS22.equalsIgnoreCase(ciExternalId)
                && reducePriceBy == 0) {
            taxResp = new String(
                    Files.readAllBytes(
                            Paths.get(DATA_DIR.COMMON + "TaxResponse_BASE2VISIBLE22.json")));
        } else if (CI_EXTERNAL_IDS.BASE2ANNUAL.equalsIgnoreCase(ciExternalId)
                && reducePriceBy == 0) {
            taxResp = new String(
                    Files.readAllBytes(
                            Paths.get(DATA_DIR.COMMON + "TaxResponse_BASE2VISANNUAL22.json")));
        } else if (CI_EXTERNAL_IDS.BASE3ANNUAL.equalsIgnoreCase(ciExternalId)
                && reducePriceBy == 0) {
            taxResp = new String(
                    Files.readAllBytes(
                            Paths.get(DATA_DIR.COMMON + "TaxResponse_BASE2VISANNUAL22.json")));
        } else if (CI_EXTERNAL_IDS.PLUS2VIS22.equalsIgnoreCase(ciExternalId)
                && reducePriceBy == 0) {
            taxResp = new String(
                    Files.readAllBytes(
                            Paths.get(DATA_DIR.COMMON + "TaxResponse_PLUS2VIS22WB.json")));
        } else if (CI_EXTERNAL_IDS.PLUS2ANNUAL.equalsIgnoreCase(ciExternalId)
                && reducePriceBy == 0) {
            taxResp = new String(
                    Files.readAllBytes(
                            Paths.get(DATA_DIR.COMMON + "TaxResponse_PLUS2VISANNUAL22.json")));
        } else if (List.of(CI_EXTERNAL_IDS.PLUS2VIS22, CI_EXTERNAL_IDS.PLUS3VIS23WB).contains(
                ciExternalId) && reducePriceBy == 20) {
            taxResp = new String(
                    Files.readAllBytes(
                            Paths.get(
                                    DATA_DIR.COMMON + "TaxResponse_PLUS2VIS22WB2_Minus_20.json")));
        } else if (CI_EXTERNAL_IDS.PLUS25.equalsIgnoreCase(ciExternalId) && reducePriceBy == 0) {
            taxResp = new String(
                    Files.readAllBytes(
                            Paths.get(DATA_DIR.COMMON + "TaxResponse_PLUS4VIS25WB.json")));
        } else if (List.of(CI_EXTERNAL_IDS.PLUS25).contains(ciExternalId) && reducePriceBy == 20) {
            taxResp = new String(
                    Files.readAllBytes(
                            Paths.get(DATA_DIR.COMMON + "TaxResponse_PLUS4VIS25WB_Minus_20.json")));
        } else if (CI_EXTERNAL_IDS.BASE3VIS23.equalsIgnoreCase(ciExternalId)
                && reducePriceBy == 0) {
            taxResp = new String(
                    Files.readAllBytes(
                            Paths.get(DATA_DIR.COMMON + "TaxResponse_BASE3VISIBLE23.json")));
        } else if (CI_EXTERNAL_IDS.BASE3ANNUAL.equalsIgnoreCase(ciExternalId)
                && reducePriceBy == 0) {
            taxResp = new String(
                    Files.readAllBytes(
                            Paths.get(DATA_DIR.COMMON + "TaxResponse_BASE3VISIBLE23A.json")));
        } else if (CI_EXTERNAL_IDS.PLUS3VIS23WB.equalsIgnoreCase(ciExternalId)
                && reducePriceBy == 0) {
            taxResp = new String(
                    Files.readAllBytes(
                            Paths.get(DATA_DIR.COMMON + "TaxResponse_PLUS3VIS23WB.json")));
        } else if (CI_EXTERNAL_IDS.PLUS3ANNUAL.equalsIgnoreCase(ciExternalId)
                && reducePriceBy == 0) {
            taxResp = new String(
                    Files.readAllBytes(
                            Paths.get(DATA_DIR.COMMON + "TaxResponse_PLUS3VIS23WBA.json")));
        } else if (CI_EXTERNAL_IDS.PLUS3ANNUAL.equalsIgnoreCase(ciExternalId)
                && reducePriceBy == 20) {
            taxResp = new String(
                    Files.readAllBytes(
                            Paths.get(
                                    DATA_DIR.COMMON + "TaxResponse_PLUS3VIS23WBA_Minus_20.json")));
        } else if (CI_EXTERNAL_IDS.PLUS6MONTH25.equalsIgnoreCase(ciExternalId)
                && reducePriceBy == 0) {
            taxResp = new String(
                    Files.readAllBytes(
                            Paths.get(DATA_DIR.COMMON + "TaxResponse_PLUS6VIS25WB.json")));
        } else if (CI_EXTERNAL_IDS.PLUS25ANNUAL.equalsIgnoreCase(ciExternalId)
                && reducePriceBy == 0) {
            taxResp = new String(
                    Files.readAllBytes(
                            Paths.get(DATA_DIR.COMMON + "TaxResponse_PLUS4VIS25WBA.json")));
        } else if (CI_EXTERNAL_IDS.PRO25.equalsIgnoreCase(ciExternalId) && reducePriceBy == 0) {
            taxResp = new String(
                    Files.readAllBytes(
                            Paths.get(
                                    DATA_DIR.COMMON + "TaxResponse_PLUS3VIS23WBA_Minus_20.json")));
        } else if (CI_EXTERNAL_IDS.PRO25ANNUAL.equalsIgnoreCase(ciExternalId)
                && reducePriceBy == 0) {
            taxResp = new String(
                    Files.readAllBytes(
                            Paths.get(DATA_DIR.COMMON + "TaxResponse_PPLUS1VIS25WBA.json")));
        } else if ((CI_EXTERNAL_IDS.INSURANCE.equalsIgnoreCase(ciExternalId)
                || CI_EXTERNAL_IDS.WEARABLE_INSURANCE.equalsIgnoreCase(ciExternalId))
                && reducePriceBy == 0) {
            taxResp = new String(
                    Files.readAllBytes(Paths.get(DATA_DIR.COMMON + "TaxResponse_INSURANCE.json")));
        } else if (List.of(
                CI_EXTERNAL_IDS.WEARABLE, CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023).contains(
                        ciExternalId)
                && reducePriceBy == 0) {
            taxResp = new String(
                    Files.readAllBytes(
                            Paths.get(DATA_DIR.COMMON + "TaxResponse_CDVISIBLE2022.json")));
        } else {
            throw new IOException("No file for given parameters.");
        }

        ObjectMapper om = CommonUtils.getObjectMapper();
        ServiceTaxResponse str = om.readValue(taxResp, ServiceTaxResponse.class);
        str.setGrossPrice(getOfferPrice(ciExternalId));
        if (reducePriceBy == 0) {
            str.setDiscountPrice(getOfferPrice(ciExternalId));
        }
        if (StringUtils.isNotBlank(classCode)) {
            str.setClassCode(classCode);
        }
        taxResp = str.toJson();
        return taxResp;
    }

    public static String getPromoTaxResp(String promoGrantExternalId,
                                         String applicableServiceExternalId,
                                         BigDecimal promoAmount)
            throws IOException {
        return getPromoTaxResp(
                promoGrantExternalId, applicableServiceExternalId, null, promoAmount);
    }

    public static String getPromoTaxResp(String promoGrantExternalId,
                                         String applicableServiceExternalId,
                                         String promoClassCode,
                                         BigDecimal promoAmount)
            throws IOException {
        String taxRespString = "";
        if (Arrays.asList(
                CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.BASE2VIS22, CI_EXTERNAL_IDS.PLUS2VIS22,
                CI_EXTERNAL_IDS.BASE3VIS23, CI_EXTERNAL_IDS.PLUS25, CI_EXTERNAL_IDS.PRO25,
                CI_EXTERNAL_IDS.WEARABLE, CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.BASE3ANNUAL,
                CI_EXTERNAL_IDS.PLUS2ANNUAL, CI_EXTERNAL_IDS.PLUS3ANNUAL).contains(
                        applicableServiceExternalId)
                && CI_EXTERNAL_IDS.GRANT_GOODWILL.equalsIgnoreCase(promoGrantExternalId)) {
            taxRespString = new String(
                    Files.readAllBytes(
                            Paths.get(DATA_DIR.COMMON + "TaxResponse_GOODWILL_UNLIMITED.json")));
        } else if (CI_EXTERNAL_IDS.CA5_GRANT.equalsIgnoreCase(promoGrantExternalId)) {
            taxRespString = new String(
                    Files.readAllBytes(Paths.get(DATA_DIR.COMMON + "TaxResponse_CA5_PLUS25.json")));
        } else if (CI_EXTERNAL_IDS.PARTY_PAY_GRANT.equalsIgnoreCase(promoGrantExternalId)) {
            taxRespString = new String(
                    Files.readAllBytes(
                            Paths.get(DATA_DIR.COMMON + "TaxResponse_PARTYPAY_UNLIMITED.json")));
        } else if (Arrays.asList(
                CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.BASE2VIS22, CI_EXTERNAL_IDS.PLUS2VIS22,
                CI_EXTERNAL_IDS.BASE3ANNUAL, CI_EXTERNAL_IDS.PLUS3ANNUAL).contains(
                        applicableServiceExternalId)
                && CI_EXTERNAL_IDS.VBPP25_AOC_GRANT.equalsIgnoreCase(promoGrantExternalId)) {
            taxRespString = new String(
                    Files.readAllBytes(
                            Paths.get(DATA_DIR.COMMON + "TaxResponse_VBPP_UNLIMITED.json")));
        } else if (Arrays.asList(
                CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.BASE2VIS22, CI_EXTERNAL_IDS.PLUS2VIS22,
                CI_EXTERNAL_IDS.BASE3ANNUAL, CI_EXTERNAL_IDS.PLUS3ANNUAL).contains(
                        applicableServiceExternalId)
                && CI_EXTERNAL_IDS.CHIME_AOC_GRANT.equalsIgnoreCase(promoGrantExternalId)) {
            taxRespString = new String(
                    Files.readAllBytes(
                            Paths.get(DATA_DIR.COMMON + "TaxResponse_CHIME_UNLIMITED.json")));
        } else if (Arrays.asList(
                CI_EXTERNAL_IDS.BASE2VIS22, CI_EXTERNAL_IDS.PLUS2VIS22, CI_EXTERNAL_IDS.BASE3VIS23,
                CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.BASE3ANNUAL,
                CI_EXTERNAL_IDS.PLUS3ANNUAL).contains(applicableServiceExternalId)
                && CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT.equalsIgnoreCase(promoGrantExternalId)) {
            taxRespString = new String(
                    Files.readAllBytes(
                            Paths.get(DATA_DIR.COMMON + "TaxResponse_15OFFN_BASE2VISIBLE22.json")));
        } else if (Arrays.asList(CI_EXTERNAL_IDS.PLUS2ANNUAL).contains(applicableServiceExternalId)
                && CI_EXTERNAL_IDS.GIFT_GRANT.equalsIgnoreCase(promoGrantExternalId)) {
            taxRespString = new String(
                    Files.readAllBytes(
                            Paths.get(DATA_DIR.COMMON + "TaxResponse_GOODWILL_UNLIMITED.json")));
        }

        ServiceTaxResponse taxResp = getServiceTaxResponseFromString(taxRespString);
        if (promoAmount != null) {
            taxResp.setDiscountPrice(promoAmount);
            taxResp.setGrossPrice(promoAmount);
        }
        if (StringUtils.isNotBlank(promoClassCode)) {
            taxResp.setClassCode(promoClassCode);
        }
        taxRespString = taxResp.toJson();

        return taxRespString;
    }

    public static ServiceTaxResponse getServiceTaxResponseFromString(String data)
            throws JsonParseException, JsonMappingException, IOException {
        return (new ObjectMapper()).readValue(data, ServiceTaxResponse.class);
    }

    public static ServiceTaxRequest getServiceTaxRequestFromString(String data)
            throws JsonParseException, JsonMappingException, IOException {
        return (new ObjectMapper()).readValue(data, ServiceTaxRequest.class);
    }

    public static EventQueryResponseEvents getRefundServiceEvents(VisibleRequestRefundService input)
            throws IOException, VisibleUnitTestException {
        return getRefundServiceEvents(input, input.getSubscriberExternalId());
    }

    @SuppressWarnings({
        "unchecked",
    })
    public static EventQueryResponseEvents getRefundServiceEvents(VisibleRequestRefundService input,
                                                                  String payerExternalId)
            throws IOException, VisibleUnitTestException {

        EventQueryResponseEvents resp = new EventQueryResponseEvents();
        for (RefundServiceEventGroup rseg : input.getEventGroupList()) {
            EventQueryEventInfo eqei = new EventQueryEventInfo();
            MtxRecurringEvent recEvent = getMtxRecurringEvent(
                    List.of(input.getRefundServiceOrderInfo().getServiceOfferExternalId()));
            int index = -1;
            for (MtxBalanceUpdate mbu : recEvent.getBalanceUpdateArray()) {
                index++;
                if (BALANCE_IDS.MAIN_BALANCE == mbu.getBalanceTemplateId().longValue()) {
                    mbu.setAmount(
                            getOfferPrice(
                                    input.getRefundServiceOrderInfo().getServiceOfferExternalId()));
                    break;
                }
            }
            recEvent.getAtChargeList(index).setAmount(
                    getOfferPrice(input.getRefundServiceOrderInfo().getServiceOfferExternalId()));
            recEvent.setEventId(rseg.getRecurringEventId());
            recEvent.setInitiatorExternalId(input.getSubscriberExternalId());
            recEvent.setWalletOwnerExternalId(input.getSubscriberExternalId());
            eqei.setEventDetails(recEvent);
            resp.getEventListAppender().add(eqei);

            for (String payEventId : rseg.getPaymentAuthorizationEventIds()) {
                EventQueryEventInfo eqeipa = new EventQueryEventInfo();
                eqeipa.setEventDetails(
                        getMtxPaymentAuthorizationEvent(
                                payEventId, payerExternalId, getOfferPrice(
                                        input.getRefundServiceOrderInfo().getServiceOfferExternalId())));
                resp.getEventListAppender().add(eqeipa);
            }
        }

        resp.setResult(RESULT_CODES.MTX_SUCCESS);
        resp.setResultText(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS);
        return resp;
    }

    @SuppressWarnings("unchecked")
    public static EventQueryResponseEvents getRefundServiceEvents(VisibleRequestRefundService input,
                                                                  List<String> promosClassCodeList)
            throws IOException, VisibleUnitTestException {
        EventQueryResponseEvents resp = new EventQueryResponseEvents();
        for (RefundServiceEventGroup rseg : input.getEventGroupList()) {
            EventQueryEventInfo eqei = new EventQueryEventInfo();
            MtxRecurringEvent recEvent = getMtxRecurringEvent(
                    List.of(input.getRefundServiceOrderInfo().getServiceOfferExternalId()),
                    promosClassCodeList);
            recEvent.setEventId(rseg.getRecurringEventId());
            eqei.setEventDetails(recEvent);
            resp.getEventListAppender().add(eqei);
            for (String payEventId : rseg.getPaymentAuthorizationEventIds()) {
                EventQueryEventInfo eqeipa = new EventQueryEventInfo();
                eqeipa.setEventDetails(
                        getMtxPaymentAuthorizationEvent(
                                payEventId, input.getSubscriberExternalId(), getOfferPrice(
                                        input.getRefundServiceOrderInfo().getServiceOfferExternalId())));
                resp.getEventListAppender().add(eqeipa);
            }

        }

        resp.setResult(RESULT_CODES.MTX_SUCCESS);
        resp.setResultText(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS);
        return resp;
    }

    public static MtxPaymentAuthorizationEvent getMtxPaymentAuthorizationEvent(String eventId,
                                                                               String initiatorExternalId,
                                                                               BigDecimal amount)
            throws IOException, VisibleUnitTestException {
        MtxPaymentAuthorizationEvent resp = null;
        if (StringUtils.isBlank(eventId)) {
            return resp;
        } else {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxPaymentAuthorizationEvent.class,
                    DATA_DIR.COMMON + "MtxPaymentAuthorizationEvent.json");
            resp.setEventId(eventId);
            if (StringUtils.isNotBlank(initiatorExternalId)) {
                resp.setInitiatorExternalId(initiatorExternalId);
                resp.setWalletOwnerExternalId(initiatorExternalId);
            }
            if (amount != null) {
                resp.setAmount(amount);
            } else {
                resp.setAmount(BigDecimal.ZERO);
            }
        }

        return resp;
    }

    public static MtxRecurringEvent getMtxRecurringEvent(List<String> ciExternalIds,
                                                         List<String> promosClassCodeList)
            throws IOException, VisibleUnitTestException {

        MtxRecurringEvent recEvent = new MtxRecurringEvent();
        if (promosClassCodeList == null || promosClassCodeList.isEmpty()) {
            recEvent = getMtxRecurringEvent(ciExternalIds);
        } else if (promosClassCodeList.size() == 1
                && promosClassCodeList.contains(TAX_CLASS_CODES.PARTY_PAY)) {
            recEvent = CommonTestHelper.loadJsonMessage(
                    MtxRecurringEvent.class,
                    DATA_DIR.COMMON + "MtxRecurringEvent_VisibleUnlimited_PartyPay.json");
        } else if (promosClassCodeList.size() == 1
                && promosClassCodeList.contains(TAX_CLASS_CODES.GOODWILL)) {
            recEvent = CommonTestHelper.loadJsonMessage(
                    MtxRecurringEvent.class,
                    DATA_DIR.COMMON + "MtxRecurringEvent_VisibleUnlimited_Goodwill.json");
        } else if (promosClassCodeList.size() == 1
                && promosClassCodeList.contains(TAX_CLASS_CODES.REFERRAL)) {
            recEvent = CommonTestHelper.loadJsonMessage(
                    MtxRecurringEvent.class,
                    DATA_DIR.COMMON + "MtxRecurringEvent_VisibleUnlimited_Referral.json");
        } else if (promosClassCodeList.size() == 2
                && promosClassCodeList.contains(TAX_CLASS_CODES.PARTY_PAY)
                && promosClassCodeList.contains(TAX_CLASS_CODES.REFERRAL)) {
            recEvent = CommonTestHelper.loadJsonMessage(
                    MtxRecurringEvent.class,
                    DATA_DIR.COMMON + "MtxRecurringEvent_VisibleUnlimited_PartyPay_Referral.json");
        }
        recEvent.getBalanceUpdateArray().forEach(mbu -> {
            if (BALANCE_IDS.MAIN_BALANCE == mbu.getBalanceTemplateId().longValue()) {
                mbu.setBalanceResourceId(getBalanceResourceId(BALANCE_NAMES.MAIN_BALANCE));
            }
        });
        return recEvent;
    }

    public static MtxRecurringEvent getMtxRecurringEvent(List<String> ciExternalIds)
            throws IOException, VisibleUnitTestException {
        MtxRecurringEvent resp = null;
        if (ciExternalIds == null) {
            return resp;
        } else if (ciExternalIds.size() == 1
                && CI_EXTERNAL_IDS.INSURANCE.equalsIgnoreCase(ciExternalIds.get(0))) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxRecurringEvent.class, DATA_DIR.COMMON + "MtxRecurringEvent_Insurance.json");
        } else if (ciExternalIds.size() == 1
                && CI_EXTERNAL_IDS.WEARABLE_INSURANCE.equalsIgnoreCase(ciExternalIds.get(0))) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxRecurringEvent.class,
                    DATA_DIR.COMMON + "MtxRecurringEvent_WearableInsurance.json");
        } else if (ciExternalIds.size() == 1
                && CI_EXTERNAL_IDS.UNLIMITED.equalsIgnoreCase(ciExternalIds.get(0))) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxRecurringEvent.class,
                    DATA_DIR.COMMON + "MtxRecurringEvent_VisibleUnlimited.json");
        } else if (ciExternalIds.size() == 1
                && CI_EXTERNAL_IDS.PRO25.equalsIgnoreCase(ciExternalIds.get(0))) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxRecurringEvent.class,
                    DATA_DIR.COMMON + "MtxRecurringEvent_PPLUS1VIS25WB.json");
        } else if (ciExternalIds.size() == 2 && ciExternalIds.contains(CI_EXTERNAL_IDS.INSURANCE)
                && ciExternalIds.contains(CI_EXTERNAL_IDS.UNLIMITED)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxRecurringEvent.class,
                    DATA_DIR.COMMON + "MtxRecurringEvent_VisibleUnlimited_Insurance.json");
        } else if (ciExternalIds.size() == 2 && ciExternalIds.contains(CI_EXTERNAL_IDS.INSURANCE)
                && ciExternalIds.contains(CI_EXTERNAL_IDS.PLUS2VIS22)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxRecurringEvent.class,
                    DATA_DIR.COMMON + "MtxRecurringEvent_Plus22_Insurance.json");
        } else if (ciExternalIds.size() == 2 && ciExternalIds.contains(CI_EXTERNAL_IDS.INSURANCE)
                && ciExternalIds.contains(CI_EXTERNAL_IDS.PLUS25)) {
            resp = CommonTestHelper.loadJsonMessage(
                    MtxRecurringEvent.class,
                    DATA_DIR.COMMON + "MtxRecurringEvent_PLUS4VIS25WB_Insurance.json");
        }

        resp.getBalanceUpdateArray().forEach(mbu -> {
            if (BALANCE_IDS.MAIN_BALANCE == mbu.getBalanceTemplateId().longValue()) {
                mbu.setBalanceResourceId(getBalanceResourceId(BALANCE_NAMES.MAIN_BALANCE));
            }
        });

        return resp;
    }

    public static EventQueryEventInfo getRecurringEventQueryEventInfo(List<String> ciExternalIds,
                                                                      String eventId,
                                                                      boolean noMainbalance)
            throws IOException, VisibleUnitTestException {
        EventQueryEventInfo resp = null;
        if (ciExternalIds == null) {
            return resp;
        } else if (ciExternalIds.size() == 1 && noMainbalance
                && CI_EXTERNAL_IDS.PLUS3ANNUAL.equalsIgnoreCase(ciExternalIds.get(0))) {
            resp = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class, DATA_DIR.COMMON
                            + "EventQueryEventInfo_Recurring_NoMainBalance_PLUS3VIS23WBA.json");
        } else if (ciExternalIds.size() == 1 && noMainbalance
                && CI_EXTERNAL_IDS.BASE3ANNUAL.equalsIgnoreCase(ciExternalIds.get(0))) {
            resp = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class, DATA_DIR.COMMON
                            + "EventQueryEventInfo_Recurring_NoMainBalance_BASE3VISIBLE23A.json");
        }

        resp.getEventDetails().setEventId(eventId);
        return resp;
    }

    public static EventQueryEventInfo getBalanceTransferEventQueryEventInfo(String gifterExternalId)
            throws IOException, VisibleUnitTestException {
        return getBalanceTransferEventQueryEventInfo(gifterExternalId, null);
    }

    public static EventQueryEventInfo getBalanceTransferEventQueryEventInfo(String gifterExternalId,
                                                                            BigDecimal balanceImpact)
            throws IOException, VisibleUnitTestException {
        EventQueryEventInfo resp = CommonTestHelper.loadJsonMessage(
                EventQueryEventInfo.class,
                DATA_DIR.COMMON + "EventQueryEventInfo_Transfer_MainBalance.json");

        resp.getEventDetails().setInitiatorExternalId(gifterExternalId);
        resp.getEventDetails().setWalletOwnerExternalId(gifterExternalId);

        ((VisibleApiEventData) ((MtxBalanceTransferEvent) resp.getEventDetails()).getApiEventData()).setGifterGlobalKey(
                gifterExternalId);

        resp.getBalanceImpactList().forEach(bii -> {
            bii.setBalanceOwnerExternalId(gifterExternalId);
            if (balanceImpact != null && bii.getIsMainBalance()) {
                bii.setImpactAmount(balanceImpact);
            }
        });

        return resp;
    }

    public static EventQueryEventInfo getSecondaryEventQueryEventInfo(String gifterExternalId,
                                                                      String gifteeExternalId,
                                                                      String primaryEventId)
            throws IOException, VisibleUnitTestException {
        EventQueryEventInfo resp = CommonTestHelper.loadJsonMessage(
                EventQueryEventInfo.class, DATA_DIR.COMMON + "EventQueryEventInfo_Secondary.json");
        resp.getEventDetails().setInitiatorExternalId(gifterExternalId);
        resp.getEventDetails().setWalletOwnerExternalId(gifteeExternalId);
        ((MtxSecondaryEvent) resp.getEventDetails()).setPrimaryEventId(primaryEventId);
        return resp;
    }

    @SuppressWarnings("unchecked")
    public static EventQueryResponseEvents getEventQueryResponseEvents() throws IOException {
        EventQueryResponseEvents resp = new EventQueryResponseEvents();
        EventQueryEventInfo eqei = new EventQueryEventInfo();
        resp.getEventListAppender().add(eqei);
        resp.setResult(RESULT_CODES.MTX_SUCCESS);
        resp.setResultText(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS);
        return resp;
    }

    @SuppressWarnings("unchecked")
    public static EventQueryResponseEvents getEventQueryResponseEvents(int numberOfEvents)
            throws IOException {
        EventQueryResponseEvents resp = new EventQueryResponseEvents();
        for (int i = 0; i < numberOfEvents; i++) {
            EventQueryEventInfo eqei = new EventQueryEventInfo();
            resp.getEventListAppender().add(eqei);
        }
        resp.setResult(RESULT_CODES.MTX_SUCCESS);
        resp.setResultText(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS);
        return resp;
    }

    public static EventQueryResponseEvents getEmptyEventQueryResponseEvents() throws IOException {
        EventQueryResponseEvents resp = new EventQueryResponseEvents();
        resp.setResult(RESULT_CODES.MTX_SUCCESS);
        resp.setResultText(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS);
        return resp;
    }

    public static MtxResponsePaymentHistory getMtxResponsePaymentHistory() throws IOException {
        MtxResponsePaymentHistory resp = new MtxResponsePaymentHistory();
        resp.setResult(RESULT_CODES.MTX_SUCCESS);
        resp.setResultText(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS);
        return resp;
    }

    @SuppressWarnings("unchecked")
    public static MtxResponsePaymentHistory getMtxResponsePaymentHistory(Map<String, BigDecimal> eventAmountMap)
            throws IOException, VisibleUnitTestException {
        MtxResponsePaymentHistory resp = new MtxResponsePaymentHistory();
        resp.setResult(RESULT_CODES.MTX_SUCCESS);
        resp.setResultText(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS);
        for (Entry<String, BigDecimal> entry : eventAmountMap.entrySet()) {
            resp.getPaymentInfoListAppender().add(
                    getMtxPaymentInfo(entry.getKey(), entry.getValue()));
        }
        return resp;
    }

    @SuppressWarnings("unchecked")
    public static MtxResponsePaymentHistory getMtxResponsePaymentHistory(EventQueryResponseEvents subEventInfo)
            throws IOException, VisibleUnitTestException {
        MtxResponsePaymentHistory resp = new MtxResponsePaymentHistory();
        resp.setResult(RESULT_CODES.MTX_SUCCESS);
        resp.setResultText(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS);
        for (EventQueryEventInfo eqei : subEventInfo.getEventList()) {
            if (MtxPaymentAuthorizationEvent.class.getSimpleName().equalsIgnoreCase(
                    eqei.getEventDetails().getMdcName())) {
                MtxPaymentAuthorizationEvent payAuthEvent = (MtxPaymentAuthorizationEvent) eqei.getEventDetails();
                resp.getPaymentInfoListAppender().add(
                        getMtxPaymentInfo(payAuthEvent.getEventId(), payAuthEvent.getAmount()));
            } else if (MtxBalanceTransferEvent.class.getSimpleName().equalsIgnoreCase(
                    eqei.getEventDetails().getMdcName())) {
                resp.getPaymentInfoListAppender().add(
                        getMtxPaymentInfo(null, eqei.getAtBalanceImpactList(0).getImpactAmount()));
            }
        }
        return resp;
    }

    @SuppressWarnings("unchecked")
    public static MtxResponsePaymentHistory getMtxResponsePaymentHistory(MtxPaymentAuthorizationEvent payAuthEvent)
            throws IOException, VisibleUnitTestException {
        MtxResponsePaymentHistory resp = new MtxResponsePaymentHistory();
        resp.setResult(RESULT_CODES.MTX_SUCCESS);
        resp.setResultText(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS);
        resp.getPaymentInfoListAppender().add(
                getMtxPaymentInfo(payAuthEvent.getEventId(), payAuthEvent.getAmount()));
        return resp;
    }

    public static MtxPaymentInfo getMtxPaymentInfo(String authEventId, BigDecimal authAmount)
            throws IOException, VisibleUnitTestException {
        MtxPaymentInfo resp = CommonTestHelper.loadJsonMessage(
                MtxPaymentInfo.class, DATA_DIR.COMMON + "MtxPaymentInfo.json");
        if (StringUtils.isNotBlank(authEventId)) {
            resp.setAuthorizationEventId(authEventId);
        }
        resp.setAuthorizationAmount(authAmount);
        return resp;
    }

    public static MtxRechargeEvent getGifterRechargeEvent(String gifterExternalId,
                                                          String giftOfferExternalId)
            throws VisibleUnitTestException, IOException {
        MtxRechargeEvent event = getRechargeEvent(gifterExternalId);
        VisibleRechargeExtension extn = (VisibleRechargeExtension) event.getRechargeAttr();
        extn.setGiftTaxDetails(getTaxApiResp(giftOfferExternalId));
        return event;
    }

    public static MtxRechargeEvent getGifterRechargeEvent(String gifterExternalId,
                                                          String giftOfferExternalId,
                                                          String gifterPromoExternalId,
                                                          BigDecimal gifterPromoAmount)
            throws VisibleUnitTestException, IOException {
        MtxRechargeEvent event = getRechargeEvent(gifterExternalId);
        VisibleRechargeExtension extn = (VisibleRechargeExtension) event.getRechargeAttr();
        extn.setGiftTaxDetails(getTaxApiResp(giftOfferExternalId));
        extn.setGiftCreditTaxDetails(
                getPromoTaxResp(gifterPromoExternalId, giftOfferExternalId, gifterPromoAmount));
        return event;
    }

    public static MtxRechargeEvent getRechargeEvent(String subscriptionExternalId)
            throws VisibleUnitTestException, IOException {
        MtxRechargeEvent event = CommonTestHelper.loadJsonMessage(
                MtxRechargeEvent.class,
                TestConstants.DATA_DIR.GIFT_SERVICE + "MtxRechargeEvent.json");
        event.setWalletOwnerExternalId(subscriptionExternalId);
        event.setInitiatorExternalId(subscriptionExternalId);
        return event;
    }

    public static MtxResponseCancel getMtxResponseCancel_Precesion6()
            throws VisibleUnitTestException, IOException {
        return getMtxResponseCancel(6);
    }

    public static MtxResponseCancel getMtxResponseCancel_Precesion6(BigDecimal impactAmount)
            throws VisibleUnitTestException, IOException {
        return getMtxResponseCancel(impactAmount, 6);
    }

    public static MtxResponseCancel getMtxResponseCancel_Precesion2()
            throws VisibleUnitTestException, IOException {
        return getMtxResponseCancel(2);
    }

    public static MtxResponseCancel getMtxResponseCancel_Precesion2(BigDecimal impactAmount)
            throws VisibleUnitTestException, IOException {
        return getMtxResponseCancel(impactAmount, 2);
    }

    public static MtxResponseCancel getMtxResponseCancel()
            throws VisibleUnitTestException, IOException {
        return getMtxResponseCancel(null);
    }

    public static MtxResponseCancel getMtxResponseCancel(Integer precision)
            throws VisibleUnitTestException, IOException {
        return getMtxResponseCancel(null, precision);
    }

    public static MtxResponseCancel getMtxResponseCancel(BigDecimal impactAmount, Integer precision)
            throws VisibleUnitTestException, IOException {
        MtxResponseCancel cancelResp = CommonTestHelper.loadJsonMessage(
                MtxResponseCancel.class, DATA_DIR.COMMON + "MtxResponseCancel_validResponse.json");
        MtxBalanceImpactInfo bi = cancelResp.getAtCancelInfoArray(0).getAtBalanceImpactGroupList(
                0).getAtBalanceImpactList(0);

        if (bi.getIsMainBalance()) {
            bi.setBalanceResourceId(getBalanceResourceId(BALANCE_NAMES.MAIN_BALANCE));
            if (impactAmount != null) {
                bi.setImpactAmount(impactAmount);
            }
            if (precision != null) {
                bi.setImpactAmount(bi.getImpactAmount().setScale(precision, RoundingMode.HALF_UP));
            }
        }
        return cancelResp;
    }

    public static MtxResponseCancel getMtxResponseCancel_NoBalanceImact()
            throws VisibleUnitTestException, IOException {
        MtxResponseCancel cancelResp = CommonTestHelper.loadJsonMessage(
                MtxResponseCancel.class, DATA_DIR.COMMON + "MtxResponseCancel_validResponse.json");
        cancelResp.getAtCancelInfoArray(0).getBalanceImpactGroupListAppender().clear();

        return cancelResp;
    }

    public static MtxResponseDevice getMtxResponseDevice_Default()
            throws VisibleUnitTestException, IOException {
        MtxResponseDevice device = CommonTestHelper.loadJsonMessage(
                MtxResponseDevice.class, DATA_DIR.MANUAL_PAY + "MtxResponseDevice.json");
        ((VisibleDeviceExtension) device.getAttr()).setDeviceType(null);
        return device;
    }

    public static MtxResponseDevice getMtxResponseDevice_Wearable()
            throws VisibleUnitTestException, IOException {
        MtxResponseDevice device = CommonTestHelper.loadJsonMessage(
                MtxResponseDevice.class, DATA_DIR.MANUAL_PAY + "MtxResponseDeviceWearable.json");
        return device;
    }

    public static MtxResponseDevice getMtxResponseDevice_NoAccessArray()
            throws VisibleUnitTestException, IOException {
        MtxResponseDevice device = CommonTestHelper.loadJsonMessage(
                MtxResponseDevice.class, DATA_DIR.COMMON + "MtxResponseDevice_NoAccessArray.json");
        return device;
    }

    public static MtxBillingCycleInfo getMonthlyBillingCycleWithEndDate(LocalDate endDate,
                                                                        String timeZone) {
        MtxBillingCycleInfo retVal = new MtxBillingCycleInfo();
        retVal.setBillingCycleId(BigInteger.valueOf(300));
        retVal.setPeriod((long) CYCLE_PERIODS.MONTHLY);
        retVal.setDatePolicy(2L);
        retVal.setPeriodInterval(1L);
        retVal.setBillingIntervalId(1L);

        retVal.setCurrentPeriodOffset((long) endDate.getDayOfMonth());

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(
                MATRIXX_CONSTANTS.MTX_DATE_TIME_FORMAT);
        ZoneId zoneId = ZoneId.of(timeZone);

        LocalDateTime endLdt = endDate.atStartOfDay().plusDays(1);
        ZonedDateTime endZdt = endLdt.atZone(zoneId);
        retVal.setCurrentPeriodEndTime(new MtxTimestamp(endZdt.format(formatter)));

        LocalDateTime startLdt = endLdt.minusMonths(1);
        ZonedDateTime startZdt = startLdt.atZone(zoneId);
        retVal.setCurrentPeriodStartTime(new MtxTimestamp(startZdt.format(formatter)));

        retVal.setCurrentPeriodDuration(ChronoUnit.DAYS.between(startZdt, endZdt));
        return retVal;
    }

    public static MtxBillingCycleInfo getMonthlyMtxBillingCycleInfo(LocalDate startDate,
                                                                    String timeZone) {
        MtxBillingCycleInfo retVal = new MtxBillingCycleInfo();
        retVal.setBillingCycleId(BigInteger.valueOf(300));
        retVal.setPeriod((long) CYCLE_PERIODS.MONTHLY);
        retVal.setDatePolicy(2L);
        retVal.setPeriodInterval(1L);
        retVal.setBillingIntervalId(1L);

        retVal.setCurrentPeriodOffset((long) startDate.getDayOfMonth());

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(
                MATRIXX_CONSTANTS.MTX_DATE_TIME_FORMAT);
        ZoneId zoneId = ZoneId.of(timeZone);

        LocalDateTime startLdt = startDate.atStartOfDay();
        ZonedDateTime startZdt = startLdt.atZone(zoneId);
        retVal.setCurrentPeriodStartTime(new MtxTimestamp(startZdt.format(formatter)));

        LocalDateTime endLdt = startLdt.plusMonths(1L);
        ZonedDateTime endZdt = endLdt.atZone(zoneId);
        retVal.setCurrentPeriodEndTime(new MtxTimestamp(endZdt.format(formatter)));

        retVal.setCurrentPeriodDuration(ChronoUnit.DAYS.between(startZdt, endZdt));
        return retVal;
    }

    public static MtxResponseGroup getMtxResponseGroup(String grpExternalId,
                                                       String tier,
                                                       Long subCount,
                                                       String... subObjectIds) {
        MtxResponseGroup grp = new MtxResponseGroup();
        grp.setExternalId(grpExternalId);
        grp.setTier(tier);
        grp.setName(tier);
        grp.setSubscriberMemberCount(subCount);
        for (String oid : subObjectIds) {
            grp.appendSubscriberMemberIdArray(new MtxObjectId(oid));
        }
        return grp;
    }

    @SuppressWarnings("unchecked")
    public static MtxResponseGroup getMtxResponseGroupCA(String grpExternalId,
                                                         String tier,
                                                         List<String> subObjectIds,
                                                         List<String> relations) {
        MtxResponseGroup grp = new MtxResponseGroup();
        grp.setExternalId(grpExternalId);
        grp.setTier(tier);
        grp.setSubscriberMemberCount((long) subObjectIds.size());
        grp.setObjectId(new MtxObjectId("1-2-3-4"));
        for (String oid : subObjectIds) {
            grp.appendSubscriberMemberIdArray(new MtxObjectId(oid));
        }
        if (relations != null) {
            VisibleCAGroupExtension attr = new VisibleCAGroupExtension();
            grp.setAttr(attr);
            for (String rel : CommonUtils.emptyIfNull(relations)) {
                attr.getRelationshipArrayAppender().add(rel);
            }
        }
        grp.setResult(RESULT_CODES.MTX_SUCCESS);
        grp.setResultText(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS);
        return grp;
    }

    public static VisibleMultiRequestPurchaseService getVisibleMultiRequestPurchaseService(String subscriberExternalId,
                                                                                           List<String> ciExternalIds)
            throws IOException {
        VisibleMultiRequestPurchaseService resp = new VisibleMultiRequestPurchaseService();
        if (ciExternalIds == null) {
            return null;
        }
        resp.setSubscriberExternalId(subscriberExternalId);

        ciExternalIds.forEach(ciExternalId -> {
            VisiblePurchaseInfo pi = new VisiblePurchaseInfo();
            resp.appendPurchaseInfo(pi);

            VisiblePurchaseServiceOrderInfo psoi = new VisiblePurchaseServiceOrderInfo();
            psoi.setOrderId(TestUtils.getYYYYMMDDToday());
            pi.setPurchaseServiceOrderInfo(psoi);

            VisiblePurchaseServiceInfo psi = new VisiblePurchaseServiceInfo();
            psi.setServiceOfferExternalId(ciExternalId);
            psi.setServiceDetails("ServiceDetails");
            psi.setServiceSku("6001");
            psi.setServiceDiscountPrice(getOfferPrice(ciExternalId).toPlainString());
            psi.setServiceGrossPrice(psi.getServiceDiscountPrice());
            try {
                psi.setServiceTaxDetails(getTaxApiResp(ciExternalId));
            } catch (IOException e) {
                e.printStackTrace();
            }
            pi.setPurchaseServiceInfo(psi);
        });

        return resp;
    }

    public static VisibleRequestPurchaseService getVisibleMultiRequestPurchaseService(String subscriberExternalId,
                                                                                      String ciExternalId)
            throws IOException {
        VisibleRequestPurchaseService resp = new VisibleRequestPurchaseService();
        if (StringUtils.isBlank(ciExternalId)) {
            return null;
        }
        resp.setSubscriberExternalId(subscriberExternalId);

        VisiblePurchaseServiceOrderInfo psoi = new VisiblePurchaseServiceOrderInfo();
        psoi.setOrderId(TestUtils.getYYYYMMDDToday());
        resp.setPurchaseServiceOrderInfo(psoi);

        VisiblePurchaseServiceInfo psi = new VisiblePurchaseServiceInfo();
        psi.setServiceOfferExternalId(ciExternalId);
        psi.setServiceDetails("ServiceDetails");
        psi.setServiceSku("6001");
        psi.setServiceDiscountPrice(getOfferPrice(ciExternalId).toPlainString());
        psi.setServiceGrossPrice(psi.getServiceDiscountPrice());
        try {
            psi.setServiceTaxDetails(getTaxApiResp(ciExternalId));
        } catch (IOException e) {
            e.printStackTrace();
        }
        resp.setPurchaseServiceInfo(psi);

        return resp;
    }

    @SuppressWarnings("unchecked")
    public static VisibleRequestQuoteAdviceService getVisibleRequestQuoteAdviceService(String taxable,
                                                                                       String... ciExternalIds) {
        VisibleRequestQuoteAdviceService request = new VisibleRequestQuoteAdviceService();
        request.setIncludeTaxDetails(taxable);
        request.setBillingCycleId(301);
        request.setSubscriberExternalId("123");
        request.getCatalogItemListAppender().clear();
        for (String cieid : ciExternalIds) {
            VisibleCatalogItem ci = new VisibleCatalogItem();
            ci.setCatalogItemExternalId(cieid);
            ci.setDiscountPrice(CommonTestHelper.getOfferPrice(cieid));
            ci.setGrossPrice(new BigDecimal(1000));
            request.getCatalogItemListAppender().add(ci);

        }
        return request;
    }

    public static VisibleRequestGiftService getVisibleRequestGiftService(String gifterExternalId,
                                                                         String gifterName,
                                                                         String gifterEmail,
                                                                         String gifteeExternalId,
                                                                         String giftOfferExternalId,
                                                                         String orderId)
            throws IOException {
        VisibleRequestGiftService request = new VisibleRequestGiftService();
        request.setGifterExternalId(gifterExternalId);
        request.setGifteeExternalId(gifteeExternalId);
        VisibleGiftingServiceInfo gsi = new VisibleGiftingServiceInfo();
        gsi.setCatalogItemExternalId(giftOfferExternalId);
        gsi.setServiceGrossPrice(getOfferPrice(giftOfferExternalId));
        request.setGiftingServiceInfo(gsi);
        VisiblePurchasedOfferExtension vpoe = new VisiblePurchasedOfferExtension();
        vpoe.setOrderId(orderId);
        request.setAttrData(vpoe);
        VisibleApiEventData eData = new VisibleApiEventData();
        eData.setRefereeName(gifterName);
        eData.setRefereeEMail(gifterEmail);
        request.setApiEventData(eData);
        return request;
    }

    public static ManualPayRequest getManualPayRequest(String subscriptionExternalId,
                                                       BigDecimal rechargeAmount)
            throws VisibleUnitTestException, IOException {
        ManualPayRequest request = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class, DATA_DIR.MANUAL_PAY + "ManualPayRequest_Valid.json");
        request.setSubscriberSearchDataExternalId(subscriptionExternalId);
        request.getPayNow().setChargeAmount(rechargeAmount);
        return request;
    }

    public static VisibleRequestRecharge getVisibleRequestRecharge(String subscriptionExternalId,
                                                                   String payerExternalId,
                                                                   String orderId,
                                                                   List<String> ciList)
            throws VisibleUnitTestException, IOException {
        return getVisibleRequestRecharge(
                subscriptionExternalId, payerExternalId, orderId, null, ciList, false);
    }

    public static VisibleRequestRecharge getVisibleRequestRecharge(String subscriptionExternalId,
                                                                   String payerExternalId,
                                                                   String orderId,
                                                                   List<String> ciList,
                                                                   boolean noBeneficiaryMDN)
            throws VisibleUnitTestException, IOException {
        return getVisibleRequestRecharge(
                subscriptionExternalId, payerExternalId, orderId, null, ciList, noBeneficiaryMDN);
    }

    public static VisibleRequestRecharge getVisibleRequestRecharge(String subscriptionExternalId,
                                                                   String payerExternalId,
                                                                   String orderId,
                                                                   String purchaseServiceType,
                                                                   List<String> ciList)
            throws VisibleUnitTestException, IOException {
        return getVisibleRequestRecharge(
                subscriptionExternalId, payerExternalId, orderId, purchaseServiceType, ciList,
                false);
    }

    public static VisibleRequestRecharge getVisibleRequestRecharge(String subscriptionExternalId,
                                                                   String payerExternalId,
                                                                   String orderId,
                                                                   String purchaseServiceType,
                                                                   List<String> ciList,
                                                                   boolean noBeneficiaryMDN)
            throws VisibleUnitTestException, IOException {
        VisibleRequestRecharge request = new VisibleRequestRecharge();

        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(subscriptionExternalId);
        request.setSubscriberSearchData(searchData);

        VisibleApiEventData aed = new VisibleApiEventData();
        aed.setOrderId(orderId);

        if (StringUtils.isNotBlank(payerExternalId)) {
            request.setPayerExternalId(payerExternalId);
            VisibleRechargeExtension extn = new VisibleRechargeExtension();
            extn.setBeneficiaryFirstName("Lorem");
            extn.setBeneficiaryLastName("Ipsum");
            extn.setPayerFirstName("Dolor");
            extn.setPayerLastName("Amet");
            extn.setPayerMDN("MDN-" + payerExternalId);
            request.setRechargeAttr(extn);
        }

        if (StringUtils.isNotBlank(purchaseServiceType)) {
            request.setPurchaseServiceType(purchaseServiceType);
        }
        request.setApiEventData(aed);

        BigDecimal rechargeAmount = BigDecimal.ZERO;
        for (String ciExternalId : CommonUtils.emptyIfNull(ciList)) {
            rechargeAmount = rechargeAmount.add(getOfferPrice(ciExternalId));
        }
        request.setAmount(rechargeAmount);

        VisibleRechargeExtension attr = new VisibleRechargeExtension();
        attr.setOrderId(orderId);
        if (!noBeneficiaryMDN) {
            attr.setServiceMDN("MDN-" + subscriptionExternalId);
        }
        request.setRechargeAttr(attr);
        return request;
    }

    public static VisibleRequestCaLink getVisibleRequestCaLink(String beneficiaryExternalId,
                                                               String payerExternalId)
            throws VisibleUnitTestException, IOException {
        VisibleRequestCaLink request = new VisibleRequestCaLink();
        request.setBeneficiaryExternalId(beneficiaryExternalId);
        request.setPayerExternalId(payerExternalId);
        return request;
    }

    public static VisibleRequestCaUnlink getVisibleRequestCaUnlink(String beneficiaryExternalId)
            throws VisibleUnitTestException, IOException {
        return getVisibleRequestCaUnlink(beneficiaryExternalId, null);
    }

    public static VisibleRequestCaUnlink getVisibleRequestCaUnlink(String beneficiaryExternalId,
                                                                   String payerExternalId)
            throws VisibleUnitTestException, IOException {
        VisibleRequestCaUnlink request = new VisibleRequestCaUnlink();
        request.setBeneficiaryExternalId(beneficiaryExternalId);
        if (StringUtils.isNotBlank(payerExternalId)) {
            request.setPayerExternalId(payerExternalId);
        }

        return request;
    }

    public static VisibleRequestRefundService getRefundGiftRequest(String subscriptionExternalId,
                                                                   String ciExternalId,
                                                                   String recurEventId,
                                                                   String payAuthEventId)
            throws VisibleUnitTestException, IOException {
        VisibleRequestRefundService request = new VisibleRequestRefundService();
        request.setSubscriberExternalId(subscriptionExternalId);
        request.setRefundType("3");
        request.getPaymentAuthEventIdsAppender().add(payAuthEventId);
        request.getRecurringEventIdsAppender().add(recurEventId);

        VisibleRefundServiceOrderInfo rsoi = new VisibleRefundServiceOrderInfo();
        rsoi.setServiceOfferExternalId(ciExternalId);
        rsoi.setReturnOrderId("R" + subscriptionExternalId);

        request.setRefundServiceOrderInfo(rsoi);
        return request;
    }

    public static VisibleRequestRefundService getRefundGiftRequestV3(String subscriptionExternalId,
                                                                     String ciExternalId,
                                                                     String recurEventId,
                                                                     String payAuthEventId)
            throws VisibleUnitTestException, IOException {
        return getRefundServiceRequest(subscriptionExternalId, ciExternalId, "3");
    }

    public static VisibleRequestRefundService getRefundServiceRequest(String subscriptionExternalId,
                                                                      String ciExternalId)
            throws VisibleUnitTestException, IOException {
        return getRefundServiceRequest(subscriptionExternalId, ciExternalId, null, 1);
    }

    public static VisibleRequestRefundService getRefundServiceRequest(String subscriptionExternalId,
                                                                      String ciExternalId,
                                                                      String refundType)
            throws VisibleUnitTestException, IOException {
        return getRefundServiceRequest(subscriptionExternalId, ciExternalId, refundType, 1);
    }

    @SuppressWarnings("unchecked")
    public static VisibleRequestRefundService getRefundServiceRequest(String subscriptionExternalId,
                                                                      String ciExternalId,
                                                                      String refundType,
                                                                      int numOfRecEvents)
            throws VisibleUnitTestException, IOException {
        VisibleRequestRefundService request = new VisibleRequestRefundService();
        request.setSubscriberExternalId(subscriptionExternalId);
        if (StringUtils.isNotBlank(refundType)) {
            request.setRefundType(refundType);
        }
        for (int i = 0; i < numOfRecEvents; i++) {
            RefundServiceEventGroup rseg = new RefundServiceEventGroup();
            rseg.setRecurringEventId("GVT0:1:52:45" + String.format("%0" + 2 + "d", i));
            rseg.getPaymentAuthorizationEventIdsAppender().add(
                    "G3J0:1:52:43" + String.format("%0" + 2 + "d", i));
            request.getEventGroupListAppender().add(rseg);
        }
        request.setCancelServices("1");
        VisibleRefundServiceOrderInfo rsoi = new VisibleRefundServiceOrderInfo();
        rsoi.setServiceOfferExternalId(ciExternalId);
        rsoi.setReturnOrderId("R" + subscriptionExternalId);
        request.setRefundServiceOrderInfo(rsoi);

        return request;
    }

    public static VisibleRequestChangeService getVisibleRequestChangeService(String subscriptionExternalId,
                                                                             String newCIID) {
        VisibleRequestChangeService request = new VisibleRequestChangeService();
        request.setSubscriptionExternalId(subscriptionExternalId);
        VisibleChangeOfferInfo coi = new VisibleChangeOfferInfo();
        request.setChangeOfferInfo(coi);
        VisibleCatalogItem newCi = new VisibleCatalogItem();
        coi.setNewCatalogItem(newCi);
        newCi.setCatalogItemExternalId(newCIID);
        newCi.setDiscountPrice(getOfferPrice(newCIID));
        return request;
    }

    @SuppressWarnings("unchecked")
    public static VisibleChangeServicePromo addNewGrantToVisibleRequestChangeService(VisibleRequestChangeService request,
                                                                                     String newGrantCIID,
                                                                                     String promoName,
                                                                                     String resetPromo,
                                                                                     BigDecimal grantAmount,
                                                                                     BigDecimal promoLimit) {
        VisibleChangeServicePromo csp = new VisibleChangeServicePromo();
        csp.setResetExistingPromo(resetPromo);
        csp.setGrantOfferCI(newGrantCIID);
        csp.setGrantAmount(grantAmount);
        VisiblePromoExtension attr = new VisiblePromoExtension();
        attr.setPromotionLimit(promoLimit);
        attr.setPromotionName(promoName);
        csp.setAttr(attr);
        request.getNewPromotionListAppender().add(csp);
        return csp;
    }

    public static VisibleChangeServiceCredit getVisibleChangeServiceCredit(VisibleRequestChangeService request,
                                                                           Long grantResourceId) {
        VisiblePromoExtension pe = request.getAtNewPromotionList(0).getAttr();
        VisibleChangeServiceCredit csc = new VisibleChangeServiceCredit();
        csc.setClassCode(pe.getClassCode());
        csc.setGrantOfferCI(request.getAtNewPromotionList(0).getGrantOfferCI());
        csc.setPromotionName(pe.getPromotionName());
        csc.setPromotionLimit(pe.getPromotionLimit());
        csc.setApplicableCI(
                request.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId());
        csc.setGrantAmount(request.getAtNewPromotionList(0).getGrantAmount());
        csc.setResourceId(grantResourceId);
        return csc;
    }

    public static void updateVisibleResponseChangeServiceAdvice(VisibleResponseChangeServiceAdvice advice,
                                                                VisibleRequestChangeService request,
                                                                SubscriptionResponse subResp,
                                                                BigDecimal aocDelta) {
        updateVisibleResponseChangeServiceAdvice(advice, request, subResp, aocDelta, null, null);
    }

    @SuppressWarnings("unchecked")
    public static void updateVisibleResponseChangeServiceAdvice(VisibleResponseChangeServiceAdvice advice,
                                                                VisibleRequestChangeService request,
                                                                SubscriptionResponse subResp,
                                                                BigDecimal aocDelta,
                                                                BigDecimal oldGp,
                                                                BigDecimal newGp) {
        advice.setSubscriptionExternalId(request.getSubscriptionExternalId());
        advice.setRechargeAmount(BigDecimal.ZERO);

        VisibleCatalogItem oldCi = new VisibleCatalogItem();
        for (MtxPurchasedOfferInfo mpoi : subResp.getPurchasedOfferArray()) {
            PurchasedOfferInfo poi = (PurchasedOfferInfo) mpoi;
            VisibleTemplate vt = (VisibleTemplate) poi.getCatalogItemDetails().getTemplateAttr();
            if (OFFER_CONSTANTS.OFFER_TYPE_BASE.equalsIgnoreCase(vt.getOfferType())) {
                if (OFFER_CONSTANTS.OFFER_STATUS_ACTIVE.equalsIgnoreCase(
                        poi.getOfferStatusDescription())) {
                    oldCi.setCatalogItemExternalId(poi.getCatalogItemExternalId());
                    oldCi.setResourceId(poi.getResourceId());
                    oldCi.setDiscountPrice(
                            CommonTestHelper.getOfferPrice(poi.getCatalogItemExternalId()));
                    String offerChangeType = AppPropertyProvider.getInstance().getString(
                            CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_PREFIX
                                    + poi.getCatalogItemExternalId()
                                    + CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_OFFER_SEPARATOR_TO
                                    + request.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId());

                    advice.setChangeType(offerChangeType);
                } else if (OFFER_CONSTANTS.OFFER_STATUS_PRE_ACTIVE.equalsIgnoreCase(
                        poi.getOfferStatusDescription())) {
                    VisibleCatalogItem vciAddon = new VisibleCatalogItem();
                    vciAddon.setCatalogItemExternalId(poi.getCatalogItemExternalId());
                    vciAddon.setResourceId(poi.getResourceId());
                    advice.setPreactiveCatalogItem(vciAddon);
                }
            }
        }

        if (oldGp != null) {
            VisibleAttribute attr = new VisibleAttribute();
            attr.setName(CHANGE_SERVICE_CONSTANTS.ATTRIBUTE_NAME_FREE_GLOBAL_PASS);
            attr.setValue(oldGp.toPlainString());
            oldCi.getAttributesAppender().add(attr);
        }
        advice.setCurrentCatalogItem(oldCi);

        String newSvc = request.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId();
        VisibleCatalogItem newCi = new VisibleCatalogItem();
        newCi.setCatalogItemExternalId(newSvc.toString());
        newCi.setDiscountPrice(CommonTestHelper.getOfferPrice(newSvc.toString()));
        if (newGp != null) {
            VisibleAttribute attr = new VisibleAttribute();
            attr.setName(CHANGE_SERVICE_CONSTANTS.ATTRIBUTE_NAME_FREE_GLOBAL_PASS);
            attr.setValue(newGp.toPlainString());
            newCi.getAttributesAppender().add(attr);
        }
        advice.setNewCatalogItem(newCi);

        VisibleChangeCycle cc = new VisibleChangeCycle();
        cc.setTotalAmount(aocDelta);
        cc.setPayableAmount(aocDelta);
        cc.setAocAmount(aocDelta);
        cc.setConsumableMainBalance(BigDecimal.ZERO);
        cc.setTaxDetails("deltaTax");
        advice.setChangeCycle(cc);

        advice.setResult(RESULT_CODES.MTX_SUCCESS);
        advice.setResultText("OK");
    }

    public static VisibleRequestChangeServiceAdvice getVisibleRequestChangeServiceAdvice(String subscriptionExternalId,
                                                                                         String ciExternalId) {
        // VisibleChangeServicePromo csp;
        VisibleRequestChangeServiceAdvice request;

        request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(ciExternalId);
        request.setDiscountPrice(CommonTestHelper.getOfferPrice(ciExternalId));
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
        request.setSubscriptionExternalId(subscriptionExternalId);
        return request;
    }

    @SuppressWarnings("unchecked")
    public static VisibleChangeServicePromo addNewGrantToVisibleRequestChangeServiceAdvice(VisibleRequestChangeServiceAdvice request,
                                                                                           String newGrantCIID,
                                                                                           String promoName,
                                                                                           String resetPromo,
                                                                                           BigDecimal grantAmount,
                                                                                           BigDecimal promoLimit) {
        VisibleChangeServicePromo csp = new VisibleChangeServicePromo();
        csp.setResetExistingPromo(resetPromo);
        csp.setGrantOfferCI(newGrantCIID);
        csp.setGrantAmount(grantAmount);
        VisiblePromoExtension attr = new VisiblePromoExtension();
        attr.setPromotionLimit(promoLimit);
        attr.setPromotionName(promoName);
        csp.setAttr(attr);
        request.getNewPromotionListAppender().add(csp);
        return csp;
    }

    public static MtxResponseSubscription changeToLapse(MtxResponseSubscription subscription) {
        subscription.setStatus(SUBSCRIPTION_STATUS_INTEGER.LAPSE);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_LAPSE);
        return subscription;
    }

    public static HashMap<String, BigDecimal> getCiChargeMapFromRecurringEvent(MtxRecurringEvent recEvent) {
        HashMap<String, BigDecimal> ciChargeMap = new HashMap<String, BigDecimal>();
        long ciIndex = -1;
        for (MtxEventAppliedCatalogItem aci : recEvent.getAppliedCatalogItemArray()) {
            ciIndex++;
            long bundleIndex = -1;
            for (MtxEventAppliedBundle ab : recEvent.getAppliedBundleArray()) {
                bundleIndex++;
                if (ciIndex != ab.getAppliedCatalogItemIndex()) {
                    continue;
                }
                long offerIndex = -1;
                for (MtxEventAppliedOffer ao : recEvent.getAppliedOfferArray()) {
                    offerIndex++;
                    if (bundleIndex != ao.getAppliedBundleIndex()) {
                        continue;
                    }
                    for (MtxEventCharge charge : recEvent.getChargeList()) {
                        if (offerIndex != charge.getAppliedOfferIndex()) {
                            continue;
                        }
                        long balanceIndex = -1;
                        for (MtxBalanceUpdate bu : recEvent.getBalanceUpdateArray()) {
                            balanceIndex++;
                            if (balanceIndex != charge.getBalanceUpdateIndex()
                                    || BALANCE_IDS.MAIN_BALANCE != bu.getBalanceTemplateId().longValue()) {
                                continue;
                            }
                            if (ciChargeMap.get(aci.getCatalogItemExternalId()) != null) {
                                if (charge.getAmount().signum() > 0) {
                                    ciChargeMap.put(
                                            aci.getCatalogItemExternalId(),
                                            charge.getAmount().add(
                                                    ciChargeMap.get(
                                                            aci.getCatalogItemExternalId())));
                                }
                            } else {
                                ciChargeMap.put(aci.getCatalogItemExternalId(), charge.getAmount());
                            }
                        }
                    }
                }
            }
        }
        return ciChargeMap;
    }
}
