
package com.matrixx.vag.util;

import org.gradle.testkit.runner.BuildResult;
import org.gradle.testkit.runner.GradleRunner;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import com.matrixx.vag.common.TestConstants.DATA_DIR;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import static org.gradle.testkit.runner.TaskOutcome.SUCCESS;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class GradleUnitTest{

    @TempDir File testProjectDir;
    private File settingsFile;
    private File buildFile;

    private String actualBuild = DATA_DIR.VISIBLEAPIGATEWAY+"build.gradle";
    
    @BeforeEach
    public void setup() {
        settingsFile = new File(testProjectDir, "settings.gradle");
        buildFile = new File(testProjectDir, "build.gradle");
    }

	@Test
	@Disabled
	public void testHelloWorldTask() throws IOException {
		StringBuilder sb = new StringBuilder();
		String taskName = "testTask";
		try {
			BufferedReader br1 = new BufferedReader(new FileReader(actualBuild));
			String line1 = null;
			boolean taskStarted = false;
			while ((line1 = br1.readLine()) != null) {
				if ("/*****END TASK testTask *****/".equalsIgnoreCase(line1)) {
					break;
				}
				if (taskStarted) {
					sb.append(line1);
					sb.append("\n");
				}
				if ("/*****START TASK testTask *****/".equalsIgnoreCase(line1)) {
					taskStarted = true;
				}
			}
			br1.close();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

		writeFile(settingsFile, "rootProject.name = 'hello-world'");
		String buildFileContent = sb.toString();
		System.out.println(buildFileContent);
		writeFile(buildFile, buildFileContent);
		BuildResult result = GradleRunner.create().withProjectDir(testProjectDir).withArguments(taskName).build();

		System.out.println("Tasks: "+result.getTasks());
		System.out.println("Output: "+result.getOutput());
		
        assertTrue(result.getOutput().contains("Hello world!"));
        assertEquals(SUCCESS, result.task(":"+taskName).getOutcome());
	}

    private void writeFile(File destination, String content) throws IOException {
        BufferedWriter output = null;
        try {
            output = new BufferedWriter(new FileWriter(destination));
            output.write(content);
        } finally {
            if (output != null) {
                output.close();
            }
        }
    }
    
    void showDir(String path) throws IOException {
    	File file = new File(path);
        for (int i = 0; i < 2; i++) System.out.print('-');
        System.out.println(file.getName());
     }
}