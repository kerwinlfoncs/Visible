package com.matrixx.vag.subscriber.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.EventQueryResponseEvents;
import com.matrixx.datacontainer.mdc.MtxBalanceUpdate;
import com.matrixx.datacontainer.mdc.MtxPaymentAuthorizationEvent;
import com.matrixx.datacontainer.mdc.MtxRecurringEvent;
import com.matrixx.datacontainer.mdc.MtxRequest;
import com.matrixx.datacontainer.mdc.MtxRequestDeviceDeleteSession;
import com.matrixx.datacontainer.mdc.MtxRequestMulti;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberAdjustBalance;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberCancelOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberModifyOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberPurchaseOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberRefundPayment;
import com.matrixx.datacontainer.mdc.MtxResponseCancel;
import com.matrixx.datacontainer.mdc.MtxResponseMulti;
import com.matrixx.datacontainer.mdc.MtxResponsePaymentHistory;
import com.matrixx.datacontainer.mdc.MtxResponsePricingOffer;
import com.matrixx.datacontainer.mdc.MtxResponseRefundPayment;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.MtxResponseWallet;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleRequestRefundService;
import com.matrixx.datacontainer.mdc.VisibleResponseRefundService;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.OFFER_CONSTANTS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.TestConstants.BALANCE_IDS;
import com.matrixx.vag.common.TestConstants.BALANCE_NAMES;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestConstants.DATA_DIR;
import com.matrixx.vag.common.TestConstants.TAX_CLASS_CODES;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.RefundServiceException;
import com.matrixx.vag.tax.client.TaxApiClient;
import com.matrixx.vag.util.MDCTest;

@ExtendWith(MockitoExtension.class)
public class RefundServiceV3Test extends MDCTest {

    @Spy
    @InjectMocks
    private final RefundServiceV3 instance = new RefundServiceV3();

    @Mock
    private SubscriberManagementApi api;

    private TestInfo testInfo;

    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        MockitoAnnotations.openMocks(this);
        this.testInfo = testInfo;
    }

    @SuppressWarnings("unchecked")
    @Tag("ReversePayment")
    @ParameterizedTest(
            name = "test_refundServiceDefaultV2_Given_ServiceOnly_When_RefundSuccess_Then_ReversePayments")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Visible_Unlimited.|"
       +"|When  |Refund success.|"
       +"|Then  |Visible_Reverse_Service_Payments offer purchased.|"})
    // @formatter:on
    public void test_refundServiceDefaultV2_Given_ServiceOnly_When_RefundSuccess_Then_ReversePayments(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getMtxResponseRefundPayment());

        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription(
                benExternalId, List.of(ciExternalId));

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input, List.of(TAX_CLASS_CODES.REFERRAL));

        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        // method to test
        instance.refundService(input, output);
        argumentCaptor.getAllValues().forEach(multiReq -> {
            printUnitTest("multiReq:" + multiReq.toJson());
        });
        // Assertions here.

        MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(0);

        assertEquals("0", String.valueOf(output.getResult()));
        assertEquals(
                "SubscriberExternalID: " + input.getSubscriberExternalId() + " Response: OK",
                output.getResultText());

        // From file MtxResponseMulti_Valid_RefundService.json
        assertEquals(
                multiRes.getResponseList().stream().filter(
                        resp -> resp.getMdcName().equals(
                                MtxResponseRefundPayment.class.getSimpleName())).map(
                                        resp -> ((MtxResponseRefundPayment) resp).getRefundInfo().getRefundTime().longValue()).findFirst().get().longValue(),
                (new MtxTimestamp(output.getRefundAmountInfo())).longValue());

        MtxRequestSubscriberRefundPayment refundReq = (MtxRequestSubscriberRefundPayment) multiReq.getRequestList().get(
                multiReq.getRequestList().size() - 1);
        MtxRequestMulti cumulativeMultiReq = argumentCaptor.getAllValues().get(1);
        MtxRequestSubscriberPurchaseOffer cumulativeReversePurchaseReq = (MtxRequestSubscriberPurchaseOffer) cumulativeMultiReq.getRequestList().get(
                0);
        assertEquals(
                AppPropertyProvider.getInstance().getString(
                        OFFER_CONSTANTS.OFFER_EXTERNAL_ID_VISIBLE_REVERSE_SERVICE_PAYMENTS),
                cumulativeReversePurchaseReq.getOfferRequestArray().get(0).getExternalId());
        assertEquals(
                refundReq.getAmount(),
                ((VisiblePurchasedOfferExtension) cumulativeReversePurchaseReq.getOfferRequestArray().get(
                        0).getAttr()).getChargeAmount());
    }

    @SuppressWarnings("unchecked")
    @Tag("Exception")
    @ParameterizedTest(name = "test_refundServiceDefaultV2_When_MultiApiError_Then_RefundFailed")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Visible_Unlimited.|"
       +"|When  |Multirequest inside api fails.|"
       +"|Then  |Refund service fails.|"})
    // @formatter:on
    public void test_refundServiceDefaultV2_When_MultiApiError_Then_RefundFailed(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseRefundPayment refPay = CommonTestHelper.getMtxResponseRefundPayment();
        refPay.setResult(11L);
        refPay.setResultText("NOTOK");
        multiRes.getResponseListAppender().add(refPay);
        multiRes.setResult(11L);
        multiRes.setResultText("NOTOK");

        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription(
                benExternalId, List.of(ciExternalId));

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);
        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(multiRes).when(instance).multiRequest(any(), any(), any());

        // method to test
        instance.refundService(input, output);
        printUnitTest("input: " + input.toJson());
        printUnitTest("output: " + output.toJson());
        assertEquals(
                "SubscriberExternalID: " + input.getSubscriberExternalId()
                        + " Error Message: Failed to Refund Service  - NOTOK",
                output.getResultText());
    }

    @Tag("Exception")
    @ParameterizedTest(
            name = "test_refundServiceDefaultv2_When_MultiApiNullResponse_Then_RefundFailed")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Visible_Unlimited.|"
       +"|When  |Multirequest inside api returns null.|"
       +"|Then  |Refund service fails.|"})
    // @formatter:on
    public void test_refundServiceDefaultv2_When_MultiApiNullResponse_Then_RefundFailed(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);

        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription(
                benExternalId, List.of(ciExternalId));

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);
        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(null).when(instance).multiRequest(any(), any(), any());

        System.out.println(testInfo.getDisplayName() + ": input: " + input.toJson());
        // method to test
        instance.refundService(input, output);
        assertEquals(
                "SubscriberExternalID: " + input.getSubscriberExternalId()
                        + " Error Message: Failed to Refund Service ",
                output.getResultText());
    }

    @Tag("Exception")
    @ParameterizedTest(
            name = "test_refundServiceDefaultV2_When_NullQuerySubscriberResponse_Then_RefundFailed")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Visible_Unlimited.|"
       +"|When  |Subscriber query returns null.|"
       +"|Then  |Refund service fails.|"})
    // @formatter:on
    public void test_refundServiceDefaultV2_When_NullQuerySubscriberResponse_Then_RefundFailed(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).querySubscriptionData(any(), any());

        // method to test
        instance.refundService(input, output);
        assertEquals(
                "SubscriberExternalID: " + input.getSubscriberExternalId()
                        + " Error Message: Failed to query subscriber ",
                output.getResultText());
    }

    @Tag("Exception")
    @ParameterizedTest(
            name = "test_refundServiceDefaultV2_When_NullQuerySubWalletResponse_Then_RefundFailed")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Visible_Unlimited.|"
       +"|When  |Subscriber wallet query returns null.|"
       +"|Then  |Refund service fails.|"})
    // @formatter:on
    public void test_refundServiceDefaultV2_When_NullQuerySubWalletResponse_Then_RefundFailed(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);
        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription(
                benExternalId, List.of(ciExternalId));

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(null).when(instance).querySubscriptionWallet(any(), any(), any());

        // method to test
        instance.refundService(input, output);
        assertEquals(
                "SubscriberExternalID: " + input.getSubscriberExternalId()
                        + " Error Message: Failed to query subscriber Wallet",
                output.getResultText());
    }

    @Tag("Exception")
    @ParameterizedTest(
            name = "test_refundServiceDefaultV2_When_NullQRecurringHistory_Then_RefundFailed")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Visible_Unlimited.|"
       +"|When  |Recurring event query returns null.|"
       +"|Then  |Refund service fails.|"})
    // @formatter:on
    public void test_refundServiceDefaultV2_When_NullQRecurringHistory_Then_RefundFailed(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription(
                benExternalId, List.of(ciExternalId));

        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        when(instance.queryEventListByEventIds(any(), any(), any())).thenReturn(null);

        instance.refundService(input, output);
        assertEquals(
                "SubscriberExternalID: " + input.getSubscriberExternalId()
                        + " Error Message: Failed to query events",
                output.getResultText());
    }

    @Tag("Exception")
    @ParameterizedTest(
            name = "test_refundServiceDefaultV2_When_NullQRecurringHistory_Then_RefundFailed")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Visible_Unlimited.|"
       +"|When  |Recurring event is found. But there are no non-zero positive mainbalance charges.|"
       +"|Then  |Refund service fails.|"})
    // @formatter:on
    public void test_refundServiceDefaultV2_When_NoValidCharges_Then_RefundFailed(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);

        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription(
                benExternalId, List.of(ciExternalId));

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);
        // // Make all charges as zero so that refundMap will not be populated.
        subscriberEventInfo.getEventList().stream().filter(
                eInfo -> eInfo.getEventDetails().getMdcName().equals(
                        MtxRecurringEvent.class.getSimpleName())).forEach(eInfo -> {
                            eInfo.getEventDetails().getChargeList().forEach(charge -> {
                                charge.setAmount(BigDecimal.ZERO);
                            });
                        });

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));

        // method to test
        instance.refundService(input, output);
        assertEquals(
                "SubscriberExternalID: " + input.getSubscriberExternalId()
                        + " Error Message: Failed to find valid charges with balance updates",
                output.getResultText());
    }

    @Tag("Exception")
    @ParameterizedTest(
            name = "test_refundServiceDefaultV2_When_NullQRecurringHistory_Then_RefundFailed")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Visible_Unlimited.|"
       +"|When  |No payment history found(May be always paid by a payer).|"
       +"|Then  |Refund service fails.|"})
    // @formatter:on
    public void test_refundServiceDefaultV2_When_NoPaymentHistorys_Then_RefundFailed(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);

        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription(
                benExternalId, List.of(ciExternalId));

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(null).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));

        // method to test
        instance.refundService(input, output);
        assertEquals(
                "SubscriberExternalID: " + input.getSubscriberExternalId()
                        + " Error Message: Failed to query payment history for subscriber",
                output.getResultText());
    }

    @Tag("Multirequest")
    @ParameterizedTest(
            name = "test_refundServiceDefaultV2_When_CancelServices_Then_CorrectMultiRequestOrder")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Visible_Unlimited.|"
       +"|When  |Request to refund with service cancellation (Default refund).|"
       +"|Then  |Order of requests in multirequest should be correct.|"})
    // @formatter:on
    public void test_refundServiceDefaultV2_When_CancelServices_Then_CorrectMultiRequestOrder(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        // Test case to check that individual requests in Multirequest input are in
        // correct order
        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId(), List.of(ciExternalId));

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);
        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(benSub).when(instance).querySubscriptionData(any(), any());
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        instance.refundService(input, output);

        // Assertions here.
        Iterator<MtxRequest> reqitr = argumentCaptor.getAllValues().get(
                0).getRequestList().iterator();
        assertEquals(
                MtxRequestSubscriberAdjustBalance.class.getSimpleName(),
                reqitr.next().getContainer().getName());
        for (int i = 0; i < benSub.getDeviceIdArray().size(); i++) {
            assertEquals(
                    MtxRequestDeviceDeleteSession.class.getSimpleName(),
                    reqitr.next().getContainer().getName());
        }
        assertEquals(
                MtxRequestSubscriberCancelOffer.class.getSimpleName(),
                reqitr.next().getContainer().getName());
        assertEquals(
                MtxRequestSubscriberRefundPayment.class.getSimpleName(),
                reqitr.next().getContainer().getName());
    }

    @Tag("Multirequest")
    @ParameterizedTest(
            name = "test_refundServiceDefaultV2_When_KeepServices_Then_CorrectMultiRequestOrder")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Visible_Unlimited.|"
       +"|When  |Request to refund without service cancellation.|"
       +"|Then  |Order of requests in multirequest should be correct.|"})
    // @formatter:on
    public void test_refundServiceDefaultV2_When_KeepServices_Then_CorrectMultiRequestOrder(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        // Test case to check that individual requests in Multirequest input are in
        // correct order
        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);
        input.setCancelServices("N");

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId(), List.of(ciExternalId));

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);
        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(benSub).when(instance).querySubscriptionData(any(), any());
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        instance.refundService(input, output);

        // Assertions here.
        Iterator<MtxRequest> reqitr = argumentCaptor.getAllValues().get(
                0).getRequestList().iterator();
        assertEquals(
                MtxRequestSubscriberAdjustBalance.class.getSimpleName(),
                reqitr.next().getContainer().getName());
        assertEquals(
                MtxRequestSubscriberRefundPayment.class.getSimpleName(),
                reqitr.next().getContainer().getName());
    }

    @Tag("VER-814")
    @Tag("Adjustment")
    @ParameterizedTest(
            name = "test_refundServiceDefaultV3_Given_PaidByBeneficiary_Then_AdjustBeneficiaryMainBalance")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with PlusHi. Paid by Beneficiary(self).|"
       +"|When  |Request for ServiceRefund.|"
       +"|Then  |Adjustment should be done to beneficiary's mainbalance.|"
       +"|      |Mainbalance resource id should match with  mainbalance resource id in beneficiary's wallet.|"})
    // @formatter:on
    public void test_refundServiceDefaultV3_Given_PaidByBeneficiary_Then_AdjustBeneficiaryMainBalance(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.PRO25;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId(), List.of(ciExternalId));

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);
        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        MtxResponseWallet wallet = emulateMtxResponseWallet(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(benSub).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        instance.refundService(input, output);
        printUnitTest("input: " + input.toJson());
        printUnitTest("output: " + output.toJson());

        long mainbalanceResourceId = wallet.getBalanceArray().stream().filter(
                mbi -> BALANCE_NAMES.MAIN_BALANCE.equalsIgnoreCase(
                        mbi.getName())).findAny().get().getResourceId();
        MtxRequestSubscriberAdjustBalance adjBalReq = new MtxRequestSubscriberAdjustBalance(
                argumentCaptor.getAllValues().get(0).getAtRequestList(0));
        // Assertions here.
        assertEquals(mainbalanceResourceId, adjBalReq.getBalanceResourceId());
        assertEquals(benExternalId, adjBalReq.getSubscriberSearchData().getExternalId());
    }

    @Tag("VER-814")
    @Tag("Adjustment")
    @ParameterizedTest(
            name = "test_refundServiceDefaultV2_Given_PaidByPayer_Then_AdjustPayerMainBalance")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with PlusHi. Paid by payer.|"
       +"|When  |Request for ServiceRefund.|"
       +"|Then  |Adjustment should be done to payer's mainbalance.|"
       +"|      |Mainbalance resource id should match with  mainbalance resource id in payer's wallet.|"})
    // @formatter:on
    public void test_refundServiceDefaultV2_Given_PaidByPayer_Then_AdjustPayerMainBalance(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String payExternalId = "67890";
        Long payMainbalanceResourceId = 13579L;
        String ciExternalId = CI_EXTERNAL_IDS.PRO25;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId(), List.of(ciExternalId));

        MtxResponseWallet walletBen = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);
        MtxResponseWallet walletPay = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);
        walletPay.getBalanceArray().stream().filter(
                mbi -> BALANCE_NAMES.MAIN_BALANCE.equalsIgnoreCase(
                        mbi.getName())).findAny().get().setResourceId(payMainbalanceResourceId);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);
        subscriberEventInfo.getAtEventList(1).getEventDetails().setInitiatorExternalId(
                payExternalId);

        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);
        purHistoryRes.getAtPaymentInfoList(0).setPaymentMethodResourceId(payMainbalanceResourceId);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(benSub).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(walletBen).doReturn(walletPay).when(instance).querySubscriptionWallet(
                any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        instance.refundService(input, output);
        printUnitTest("input: " + input.toJson());
        printUnitTest("output: " + output.toJson());

        MtxRequestSubscriberAdjustBalance adjBalReq = new MtxRequestSubscriberAdjustBalance(
                argumentCaptor.getAllValues().get(0).getAtRequestList(0));
        // Assertions here.
        assertEquals(payMainbalanceResourceId, adjBalReq.getBalanceResourceId());
        assertEquals(payExternalId, adjBalReq.getSubscriberSearchData().getExternalId());
    }

    @Tag("VER-814")
    @Tag("RefundRequest")
    @ParameterizedTest(
            name = "test_refundServiceDefaultV2_Given_PaidByBeneficiary_Then_RefundToBeneficiary")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with PlusHi. Paid by Beneficiary(self).|"
       +"|When  |Request for ServiceRefund.|"
       +"|Then  |Final refund should be done to beneficiary's payment method.|"})
    // @formatter:on
    public void test_refundServiceDefaultV2_Given_PaidByBeneficiary_Then_RefundToBeneficiary(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        Long benPaymentInfoResourceId = 54321L;
        String ciExternalId = CI_EXTERNAL_IDS.PRO25;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId(), List.of(ciExternalId));

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);
        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);
        purHistoryRes.getAtPaymentInfoList(0).setResourceId(benPaymentInfoResourceId);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(benSub).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        instance.refundService(input, output);
        printUnitTest("input: " + input.toJson());
        printUnitTest("output: " + output.toJson());

        MtxRequestSubscriberRefundPayment refReq = new MtxRequestSubscriberRefundPayment(
                argumentCaptor.getAllValues().get(0).getAtRequestList(
                        argumentCaptor.getAllValues().get(0).getRequestList().size() - 1));
        // Assertions here.
        assertEquals(benPaymentInfoResourceId, refReq.getResourceId());
        assertEquals(benExternalId, refReq.getSubscriberSearchData().getExternalId());
    }

    @Tag("VER-814")
    @Tag("RefundRequest")
    @ParameterizedTest(name = "test_refundServiceDefaultV2_Given_PaidByPayer_Then_RefundToPayer")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with PlusHi. Paid by Payer.|"
       +"|When  |Request for ServiceRefund.|"
       +"|Then  |Final refund should be done to payer's payment method.|"})
    // @formatter:on
    public void test_refundServiceDefaultV2_Given_PaidByPayer_Then_RefundToPayer(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String payExternalId = "67890";
        Long payPaymentInfoResourceId = 54321L;
        String ciExternalId = CI_EXTERNAL_IDS.PRO25;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId(), List.of(ciExternalId));

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);
        subscriberEventInfo.getAtEventList(1).getEventDetails().setInitiatorExternalId(
                payExternalId);

        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);
        purHistoryRes.getAtPaymentInfoList(0).setResourceId(payPaymentInfoResourceId);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(benSub).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        instance.refundService(input, output);
        printUnitTest("input: " + input.toJson());
        printUnitTest("output: " + output.toJson());

        MtxRequestSubscriberRefundPayment refReq = new MtxRequestSubscriberRefundPayment(
                argumentCaptor.getAllValues().get(0).getAtRequestList(
                        argumentCaptor.getAllValues().get(0).getRequestList().size() - 1));
        // Assertions here.
        assertEquals(payPaymentInfoResourceId, refReq.getResourceId());
        assertEquals(payExternalId, refReq.getSubscriberSearchData().getExternalId());
    }

    @Tag("Adjustment")
    @ParameterizedTest(
            name = "test_refundServiceDefaultV2_When_Success_Then_AdjustmentReason_Has_RecurringEventId")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with PlusHi.|"
       +"|When  |Request for ServiceRefund.|"
       +"|Then  |Adjustment reason should have recurring event id in it.|"})
    // @formatter:on
    public void test_refundServiceDefaultV2_When_Success_Then_AdjustmentReason_Has_RecurringEventId(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.PRO25;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId(), List.of(ciExternalId));
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);
        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(benSub).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        instance.refundService(input, output);
        // Assertions here.
        ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();

        String adjReason = ((MtxRequestSubscriberAdjustBalance) (reqList.get(0))).getReason();
        assertTrue(adjReason.startsWith(CommonUtils.REVERSAL_PREFIX));
        String recurringEventId = subscriberEventInfo.getAtEventList(
                0).getEventDetails().getEventId();
        assertTrue(adjReason.contains(recurringEventId));
    }

    @Tag("RefundRequest")
    @ParameterizedTest(
            name = "test_refundServiceDefaultV2_When_Success_Then_RefundInfo_Has_RecurringEventId")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Visible_Unlimited.|"
       +"|When  |Request for ServiceRefund.|"
       +"|Then  |Refund info should have recurring event id in it.|"})
    // @formatter:on
    public void test_refundServiceDefaultV2_When_Success_Then_RefundInfo_Has_RecurringEventId(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.PRO25;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId(), List.of(ciExternalId));
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);
        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(benSub).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        instance.refundService(input, output);
        printUnitTest("input: " + input.toJson());
        printUnitTest("output: " + output.toJson());

        // Assertions here.
        ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();
        MtxRequestSubscriberRefundPayment refReq = new MtxRequestSubscriberRefundPayment(reqList.get(reqList.size()-1));
        assertTrue(refReq.getInfo().startsWith(CommonUtils.REVERSAL_PREFIX));
        
        String recurringEventId = subscriberEventInfo.getAtEventList(
                0).getEventDetails().getEventId();
        assertTrue(refReq.getInfo().contains(recurringEventId));
    }

    @Tag("Adjustment")
    @ParameterizedTest(
            name = "test_refundServiceDefaultV2_When_ReverseTax_id_N_Then_ParialAdjustmentReason")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Visible_Unlimited.|"
       +"|When  |Request for ServiceRefund with ReverseTax=N.|"
       +"|Then  |Adjustment reason should be of ParialReversal.|"})
    // @formatter:on
    public void test_refundServiceDefaultV2_When_ReverseTax_id_N_Then_ParialAdjustmentReason(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);
        input.getRefundServiceOrderInfo().setReverseTax("N");

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId(), List.of(ciExternalId));

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);

        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(benSub).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        System.out.println(input.toJson());
        // method to test
        instance.refundService(input, output);
        System.out.println(output.toJson());
        System.out.println(argumentCaptor.getAllValues().size());

        // Assertions here.
        ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();

        String adjReason = ((MtxRequestSubscriberAdjustBalance) (reqList.get(0))).getReason();
        assertTrue(adjReason.startsWith(CommonUtils.PARTIAL_REVERSAL_PREFIX));
        String recurringEventId = subscriberEventInfo.getAtEventList(
                0).getEventDetails().getEventId();
        assertTrue(adjReason.contains(recurringEventId));
    }

    @Tag("Adjustment")
    @ParameterizedTest(
            name = "test_refundServiceDefaultV2_When_ReverseTax_id_N_Then_ParialAdjustmentReason")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Visible_Unlimited.|"
       +"|When  |Request for ServiceRefund.|"
       +"|Then  |Number of Adjustments should be same as number of refunds.|"})
    // @formatter:on
    public void test_refundServiceDefaultV2_When_RefundDone_Then_AdjustmentCountMatch(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);
        input.getRefundServiceOrderInfo().setReverseTax("N");

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId(), List.of(ciExternalId));

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);

        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(benSub).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        System.out.println(input.toJson());
        // method to test
        instance.refundService(input, output);
        System.out.println(output.toJson());
        System.out.println(argumentCaptor.getAllValues().size());

        ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();
        MtxRequestSubscriberRefundPayment refReq = new MtxRequestSubscriberRefundPayment(reqList.get(reqList.size()-1));
        assertTrue(refReq.getInfo().startsWith(CommonUtils.PARTIAL_REVERSAL_PREFIX));
        
        String recurringEventId = subscriberEventInfo.getAtEventList(
                0).getEventDetails().getEventId();
        assertTrue(refReq.getInfo().contains(recurringEventId));        
    }

    @SuppressWarnings("unchecked")
    @Tag("RefundRequest")
    @ParameterizedTest(
            name = "test_refundServiceDefaultV2_Given_Multiple_PayAuth_Then_MatchingRefundPayments")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Visible_Unlimited. Paid by multiple payments.|"
       +"|When  |Request for ServiceRefund. Payauth Events in request.|"
       +"|Then  |Refund payments should be split based on Payment Authorizations.|"})
    // @formatter:on
    public void test_refundServiceDefaultV2_Given_Multiple_PayAuth_Then_MatchingRefundPayments(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);
        String secondPayAuthId = "G3J0:1:52:4399";
        input.getAtEventGroupList(0).getPaymentAuthorizationEventIdsAppender().add(secondPayAuthId);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());

        MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId(), List.of(ciExternalId));

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);
        BigDecimal amount1 = BigDecimal.valueOf(15);
        BigDecimal amount2 = BigDecimal.valueOf(25);
        ((MtxPaymentAuthorizationEvent) subscriberEventInfo.getAtEventList(
                1).getEventDetails()).setAmount(amount1);
        ((MtxPaymentAuthorizationEvent) subscriberEventInfo.getAtEventList(
                2).getEventDetails()).setAmount(amount2);

        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn(benSub).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        instance.refundService(input, output);
        System.out.println("input: " + input.toJson());
        System.out.println("output: " + output.toJson());

        // Assertions here.
        List<MtxRequestMulti> reqLists = argumentCaptor.getAllValues();
        reqLists.forEach(mr -> {
            System.out.println("MultiRequest: " + mr.toJson());
        });

        ArrayList<MtxRequest> reqList1 = reqLists.get(1).getRequestList();
        ArrayList<MtxRequest> reqList2 = reqLists.get(2).getRequestList();
        assertEquals(1, reqList1.size());
        assertEquals(1, reqList2.size());

        BigDecimal refundAmount1 = ((MtxRequestSubscriberRefundPayment) reqList1.get(
                0)).getAmount();
        BigDecimal refundAmount2 = ((MtxRequestSubscriberRefundPayment) reqList2.get(
                0)).getAmount();

        double refundRequestAmount = refundAmount1.add(refundAmount2).doubleValue();

        MtxRecurringEvent recEvent = (MtxRecurringEvent) subscriberEventInfo.getAtEventList(
                0).getEventDetails();
        BigDecimal expRefundAmount = BigDecimal.ZERO;
        for (MtxBalanceUpdate bu : recEvent.getBalanceUpdateArray()) {
            if (BALANCE_IDS.MAIN_BALANCE == bu.getBalanceTemplateId().longValue()) {
                expRefundAmount = expRefundAmount.add(bu.getAmount());
            }
        }
        assertEquals(
                expRefundAmount.setScale(2, RoundingMode.HALF_UP).toPlainString(),
                output.getRefundedAmount());
        assertEquals(refundRequestAmount, Double.valueOf(output.getRefundedAmount()));
    }

    @SuppressWarnings("unchecked")
    @Tag("ReversePayment")
    @ParameterizedTest(
            name = "test_refundServiceDefaultV2_Given_Multiple_PayAuth_Then_MatchingReversePayments")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Visible_Unlimited. Paid by multiple payments.|"
       +"|When  |Request for ServiceRefund. Payauth Events in request.|"
       +"|Then  |Reverse payments should match refund events and split based on Payment Authorizations.|"})
    // @formatter:on
    public void test_refundServiceDefaultV2_Given_Multiple_PayAuth_Then_MatchingReversePayments(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);
        String secondPayAuthId = "G3J0:1:52:4399";
        input.getAtEventGroupList(0).getPaymentAuthorizationEventIdsAppender().add(secondPayAuthId);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());

        MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId(), List.of(ciExternalId));

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);
        BigDecimal amount1 = BigDecimal.valueOf(15);
        BigDecimal amount2 = BigDecimal.valueOf(25);
        ((MtxPaymentAuthorizationEvent) subscriberEventInfo.getAtEventList(
                1).getEventDetails()).setAmount(amount1);
        ((MtxPaymentAuthorizationEvent) subscriberEventInfo.getAtEventList(
                2).getEventDetails()).setAmount(amount2);

        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn(benSub).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        instance.refundService(input, output);
        printUnitTest("input: " + input.toJson());
        printUnitTest("output: " + output.toJson());

        // Assertions here.
        List<MtxRequestMulti> reqLists = argumentCaptor.getAllValues();
        reqLists.forEach(mr -> {
            printUnitTest("MultiRequest: " + mr.toJson());
        });

        // ArrayList<MtxRequest> reqList = reqLists.get(0).getRequestList();
        ArrayList<MtxRequest> refundReqList1 = reqLists.get(1).getRequestList();
        ArrayList<MtxRequest> refundReqList2 = reqLists.get(2).getRequestList();
        ArrayList<MtxRequest> cumulativeRevereseReqList1 = reqLists.get(3).getRequestList();
        ArrayList<MtxRequest> cumulativeRevereseReqList2 = reqLists.get(4).getRequestList();
        assertTrue(refundReqList1.size() == 1);
        assertTrue(refundReqList2.size() == 1);

        BigDecimal refundAmount1 = ((MtxRequestSubscriberRefundPayment) refundReqList1.get(
                0)).getAmount();
        BigDecimal refundAmount2 = ((MtxRequestSubscriberRefundPayment) refundReqList2.get(
                0)).getAmount();

        assertEquals(
                refundAmount1.doubleValue(),
                ((VisiblePurchasedOfferExtension) (((MtxRequestSubscriberPurchaseOffer) cumulativeRevereseReqList1.get(
                        0)).getOfferRequestArray().get(
                                0).getAttr())).getChargeAmount().doubleValue());
        assertEquals(
                refundAmount2.doubleValue(),
                ((VisiblePurchasedOfferExtension) (((MtxRequestSubscriberPurchaseOffer) cumulativeRevereseReqList2.get(
                        0)).getOfferRequestArray().get(
                                0).getAttr())).getChargeAmount().doubleValue());

        assertEquals(
                AppPropertyProvider.getInstance().getString(
                        OFFER_CONSTANTS.OFFER_EXTERNAL_ID_VISIBLE_REVERSE_SERVICE_PAYMENTS),
                ((MtxRequestSubscriberPurchaseOffer) cumulativeRevereseReqList1.get(
                        0)).getOfferRequestArray().get(0).getExternalId());
        assertEquals(
                AppPropertyProvider.getInstance().getString(
                        OFFER_CONSTANTS.OFFER_EXTERNAL_ID_VISIBLE_REVERSE_SERVICE_PAYMENTS),
                ((MtxRequestSubscriberPurchaseOffer) cumulativeRevereseReqList2.get(
                        0)).getOfferRequestArray().get(0).getExternalId());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_refundServiceDefaultV2_Given_ServiceAndInsuranceRenewed_Then_RefundSuccess")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Visible_Unlimited and Insurance. Recurring event has both base service and insurance.|"
       +"|When  |Request for ServiceRefund (Visible_Unlimited).|"
       +"|Then  |Refund should complete normally.|"})
    // @formatter:on
    public void test_refundServiceDefaultV2_Given_ServiceAndInsuranceRenewed_Then_RefundSuccess(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());

        MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId(), List.of(ciExternalId));

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);
        MtxRecurringEvent recEvent = CommonTestHelper.getMtxRecurringEvent(
                List.of(CI_EXTERNAL_IDS.INSURANCE, ciExternalId));
        recEvent.setEventId(input.getAtEventGroupList(0).getRecurringEventId());
        subscriberEventInfo.getAtEventList(0).setEventDetails(recEvent);

        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn(benSub).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(multiRes).when(instance).multiRequest(any(), any(), any());

        // method to test
        instance.refundService(input, output);
        printUnitTest("input: " + input.toJson());
        printUnitTest("output: " + output.toJson());

        // Assertions here.
        HashMap<String, BigDecimal> chargeMap = CommonTestHelper.getCiChargeMapFromRecurringEvent(
                recEvent);

        assertEquals(RESULT_CODES.MTX_SUCCESS, output.getResult());
        assertEquals(
                "SubscriberExternalID: " + input.getSubscriberExternalId() + " Response: OK",
                output.getResultText());
        assertEquals(
                chargeMap.get(ciExternalId).doubleValue(),
                (new BigDecimal(output.getRefundedAmount())).doubleValue());
    }

    @ParameterizedTest(
            name = "test_refundServiceDefaultV2_CancellationYes_CreditsYes_CorrectMultiRequestOrdering")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active service.|"
                +"|When  |Api is called for refund with default refund type.|"
                +"|Then  |Order of final multi request should be Adjust, Cancel, Refund.|"})
    // @formatter:on
    public void test_refundServiceDefaultV2_CancellationYes_CreditsYes_CorrectMultiRequestOrdering(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        // Test case to check that individual requests in Multirequest input are in
        // correct order
        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription(
                benExternalId, List.of(ciExternalId));

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);
        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        instance.refundService(input, output);

        argumentCaptor.getAllValues().forEach(multiReq -> {
            printUnitTest("multiReq:" + multiReq.toJson());
        });
        // Assertions here.
        ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();
        assertEquals(
                MtxRequestSubscriberAdjustBalance.class.getSimpleName(),
                reqList.get(0).getMdcName());
        assertEquals(
                MtxRequestSubscriberCancelOffer.class.getSimpleName(),
                reqList.get(reqList.size() - 2).getMdcName());
        assertEquals(
                MtxRequestSubscriberRefundPayment.class.getSimpleName(),
                reqList.get(reqList.size() - 1).getMdcName());
    }

    @ParameterizedTest(name = "test_refundServiceV2_RefundType5_Fail")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active service/insurance.|"
                +"|When  |Api is called for refund with incorrect refund type.|"
                +"|Then  |Error.|"})
    // @formatter:on
    public void test_refundServiceV2_RefundType5_Fail(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);
        input.setRefundType("5");

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        doReturn("").when(instance).getRoute(any());

        Exception exception = assertThrows(
                RefundServiceException.class, () -> instance.refundService(input, output));
        System.out.println(exception.getMessage());
        assertTrue(exception.getMessage().contains("Unknown refund type"));
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-814")
    @Tag("ConnectedAccounts")
    @ParameterizedTest(name = "test_refundDefault_Given_PaidByPayer_Then_RefundToPayer")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription with a payer. Paid by payer.|"
                +"|When  |Request for refund.|"
                +"|Then  |Pay to payer.|"})
    // @formatter:on
    public void test_refundDefault_Given_PaidByPayer_Then_RefundToPayer(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String payExternalId = "67890";
        String ciExternalId = CI_EXTERNAL_IDS.PRO25;

        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription(
                benExternalId, List.of(ciExternalId));
        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                Map.of(
                        input.getAtEventGroupList(0).getAtPaymentAuthorizationEventIds(0),
                        CommonTestHelper.getOfferPrice(ciExternalId)));
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input, payExternalId);
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);
        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        // doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        instance.refundService(input, output);
        printUnitTest(input.toJson());
        printUnitTest(output.toJson());
        argumentCaptor.getAllValues().forEach(multiReq -> {
            printUnitTest(multiReq.toJson());
        });
        // Assertions here.
        ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();

        assertEquals(
                MtxRequestSubscriberRefundPayment.class.getSimpleName(),
                reqList.get(reqList.size() - 1).getMdcName());
        MtxRequestSubscriberRefundPayment refundReq = (MtxRequestSubscriberRefundPayment) reqList.get(
                reqList.size() - 1);
        assertEquals(payExternalId, refundReq.getSubscriberSearchData().getExternalId());
    }

    private void printUnitTest(Object msg) {
        System.out.println(testInfo.getDisplayName() + ":" + msg);
    }

}
