package com.matrixx.vag.subscriber.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.test.util.ReflectionTestUtils;

import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferData;
import com.matrixx.datacontainer.mdc.MtxRequest;
import com.matrixx.datacontainer.mdc.MtxRequestMulti;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberPurchaseOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberRecharge;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriptionModify;
import com.matrixx.datacontainer.mdc.MtxResponseMulti;
import com.matrixx.datacontainer.mdc.MtxResponsePricingOffer;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.MtxResponseWallet;
import com.matrixx.datacontainer.mdc.VisibleApiEventData;
import com.matrixx.datacontainer.mdc.VisibleBraintreeChargeMethodExtension;
import com.matrixx.datacontainer.mdc.VisibleCredits;
import com.matrixx.datacontainer.mdc.VisibleMultiRequestPurchaseService;
import com.matrixx.datacontainer.mdc.VisibleMultiResponsePurchaseService;
import com.matrixx.datacontainer.mdc.VisiblePurchaseInfo;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleSubscriberExtension;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.advice.model.VisibleResponsePurchaseAdvice;
import com.matrixx.vag.advice.service.PaymentAdviceService;
import com.matrixx.vag.common.Constants.BRAINTREE_CONSTANTS;
import com.matrixx.vag.common.Constants.CREDIT_CONSTANTS;
import com.matrixx.vag.common.Constants.CYCLE_LENGTHS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestConstants.TAX_CLASS_CODES;
import com.matrixx.vag.common.TestUtils;
import com.matrixx.vag.common.TwoParameterTest;
import com.matrixx.vag.exception.MtxResponseException;
import com.matrixx.vag.exception.SubscriberServiceException;
import com.matrixx.vag.util.MDCTest;

public class PurchaseMultiServiceTest extends MDCTest {

    @Spy
    @InjectMocks
    private final SubscriberService instance = new SubscriberService();

    @Mock
    private SubscriberManagementApi api;

    PaymentAdviceService aopInstance = null;
    private TestInfo testInfo;

    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        MockitoAnnotations.openMocks(this);
        this.testInfo = testInfo;
        aopInstance = Mockito.spy(new PaymentAdviceService());
        ReflectionTestUtils.setField(instance, "paymentAdviceService", aopInstance);
    }

    @SuppressWarnings("unchecked")
    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_purchaseMultiService_InsuranceFirstServiceNext_Success() throws Exception {

        String baseService = CI_EXTERNAL_IDS.UNLIMITED;
        String insuranceService = CI_EXTERNAL_IDS.INSURANCE;
        List<String> svcList = List.of(insuranceService, baseService);
        VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", svcList);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());

        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());

        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);

        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                baseService, "", "", null, wallet);

        MtxResponsePricingOffer pricingOfferService = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        MtxResponsePricingOffer pricingOfferInsurance = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);

        VisibleMultiResponsePurchaseService output = new VisibleMultiResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, svcList);
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
        doReturn(pricingOfferService).when(instance).queryPricingOffer(
                any(), any(), eq(CI_EXTERNAL_IDS.UNLIMITED));
        doReturn(pricingOfferInsurance).when(instance).queryPricingOffer(
                any(), any(), eq(CI_EXTERNAL_IDS.INSURANCE));
        // method to test
        instance.purchaseMultiService(input, output);
        ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();
        for (VisiblePurchaseInfo pi : input.getPurchaseInfo()) {
            if (pi.getPurchaseServiceInfo().getServiceOfferExternalId().equals(
                    CI_EXTERNAL_IDS.UNLIMITED)) {
            }
        }
        // Assertions here.
        assertEquals(RESULT_CODES.MTX_SUCCESS, output.getResult());

        reqList.forEach(req -> {
            if (req.getMdcName().equals(MtxRequestSubscriberRecharge.class.getSimpleName())) {
                // Test Visible Override Flag
                MtxRequestSubscriberRecharge rechargeRequest = (MtxRequestSubscriberRecharge) req;
                if (rechargeRequest.getReason().equals("purchase_service")) {
                    assertEquals(
                            false,
                            ((VisibleBraintreeChargeMethodExtension) rechargeRequest.getChargeMethodData().getChargeMethodAttr()).getVisibleRecurringOverride());
                    assertEquals(
                            pricingOfferService.getOfferInfo().getAttrList().stream().filter(
                                    attr -> attr.getName().equals("recharge_reason")).map(
                                            attr -> attr.getValue()).findFirst().get(),
                            rechargeRequest.getReason(),
                            "!!! Recharge reason in pricing offer attributes should be same as recharge request reason");

                } else if (rechargeRequest.getReason().equals("purchase_insurance")) {
                    assertEquals(
                            false,
                            ((VisibleBraintreeChargeMethodExtension) rechargeRequest.getChargeMethodData().getChargeMethodAttr()).getVisibleRecurringOverride());
                    assertEquals(
                            pricingOfferInsurance.getOfferInfo().getAttrList().stream().filter(
                                    attr -> attr.getName().equals("recharge_reason")).map(
                                            attr -> attr.getValue()).findFirst().get(),
                            rechargeRequest.getReason(),
                            "!!! Recharge reason in pricing offer attributes should be same as recharge request reason");
                }

                assertEquals(
                        BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION,
                        rechargeRequest.getAmount().scale());

            }
            if (req.getMdcName().equals(MtxRequestSubscriberPurchaseOffer.class.getSimpleName())) {
                MtxRequestSubscriberPurchaseOffer purchaseRequest = (MtxRequestSubscriberPurchaseOffer) req;

                String goodtype = ((VisiblePurchasedOfferExtension) purchaseRequest.getOfferRequestArray().get(
                        0).getAttr()).getGoodType();
                if (("purchase_service").equals(goodtype)) {
                    assertEquals(
                            pricingOfferService.getOfferInfo().getAttrList().stream().filter(
                                    attr -> attr.getName().equals("good_type")).map(
                                            attr -> attr.getValue()).findFirst().get(),
                            goodtype,
                            "!!! GoodType in pricing offer attributes should be same as recharge request GoodType");
                } else if (("purchase_insurance").equals(goodtype)) {
                    assertEquals(
                            pricingOfferInsurance.getOfferInfo().getAttrList().stream().filter(
                                    attr -> attr.getName().equals("good_type")).map(
                                            attr -> attr.getValue()).findFirst().get(),
                            goodtype);
                }
            }
        });
    }

    @SuppressWarnings("unchecked")
    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_purchaseMultiService_InsuranceOnly_Success() throws Exception {

        String service = CI_EXTERNAL_IDS.INSURANCE;
        VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", List.of(service));

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());

        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);

        VisibleMultiResponsePurchaseService output = new VisibleMultiResponsePurchaseService();

        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                service, "", "", null, wallet);
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, List.of(service));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        doReturn(multiRes).when(instance).multiRequest(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(
                any(), any(), eq("Visible_Device_Insurance_Bundle_CI"));
        // method to test
        instance.purchaseMultiService(input, output);

        // Assertions here.
        assertEquals(RESULT_CODES.MTX_SUCCESS, output.getResult());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    // Add mocks till multi call
    public void test_purchaseMultiService_MultiApiError_PurchaseFail() throws Exception {
        String service = CI_EXTERNAL_IDS.UNLIMITED;
        List<String> svcList = List.of(service);
        VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", svcList);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.setResult(11L);
        multiRes.setResultText("NOTOK");

        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());
        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                service, "", "", null, wallet);
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleMultiResponsePurchaseService output = new VisibleMultiResponsePurchaseService();

        // mocks
        emulateMtxResponsePricingCatalogItems(instance, svcList);
        doReturn("").when(instance).getRoute(any());
        doReturn(multiRes).when(instance).multiRequest(any(), any(), any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(
                any(), any(), eq(CI_EXTERNAL_IDS.UNLIMITED));

        Exception exception = assertThrows(
                MtxResponseException.class, () -> instance.purchaseMultiService(input, output));
        exception.printStackTrace();
        assertThat(exception.getMessage()).contains("Failed to purchase service");
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    // Add mocks till multi call
    public void test_purchaseMultiService_MultiApiNullResponse_PurchaseFail() throws Exception {

        List<String> svcList = List.of(CI_EXTERNAL_IDS.UNLIMITED);
        VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", svcList);

        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());
        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                CI_EXTERNAL_IDS.UNLIMITED, "", "", null, wallet);
        MtxResponsePricingOffer pricingOfferService = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        MtxResponseMulti multiRes = null;

        VisibleMultiResponsePurchaseService output = new VisibleMultiResponsePurchaseService();

        // mocks
        emulateMtxResponsePricingCatalogItems(instance, svcList);
        doReturn("").when(instance).getRoute(any());
        doReturn(multiRes).when(instance).multiRequest(any(), any(), any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(pricingOfferService).when(instance).queryPricingOffer(
                any(), any(), eq(CI_EXTERNAL_IDS.UNLIMITED));
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());

        Exception exception = assertThrows(
                MtxResponseException.class, () -> instance.purchaseMultiService(input, output));
        exception.printStackTrace();
        assertThat(exception.getMessage()).contains("Failed to purchase service");
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_purchaseMultiService_ServiceOnly_Success() throws Exception {
        String service = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", List.of(service));

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());
        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                service, "", "", null, wallet);
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleMultiResponsePurchaseService output = new VisibleMultiResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, List.of(service));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        doReturn(multiRes).when(instance).multiRequest(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), eq(service));
        // method to test
        instance.purchaseMultiService(input, output);

        // Assertions here.
        assertEquals(RESULT_CODES.MTX_SUCCESS, output.getResult());
    }

    @Test
    public void test_purchaseMultiService_When_PercentagePromo_Then_RedeemOfferIsPercentage()
            throws Exception {

        String service = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", List.of(service));

        // MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        // MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(
        // MtxResponseSubscription.class,
        // DATA_DIR.MULTIPURCHASE_SERVICE + "MtxResponseSubscriber.json");
        //
        // VisibleResponsePaymentAdviceService aop = CommonTestHelper.loadJsonMessage(
        // VisibleResponsePaymentAdviceService.class, DATA_DIR.MULTIPURCHASE_SERVICE
        // + "VisibleResponsePaymentAdviceService_Service_Insurance.json");

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());

        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);

        Map<String, BigDecimal> promoGrantCiRedeemMap = Map.of(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.valueOf(10));

        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                service, "", "", promoGrantCiRedeemMap, wallet);
        aop.getCredits().get(0).setApplicableCreditsPercentage(BigDecimal.TEN);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleMultiResponsePurchaseService output = new VisibleMultiResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, List.of(service));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        doReturn(multiRes).when(instance).multiRequest(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), eq(service));
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        // method to test
        instance.purchaseMultiService(input, output);

        MtxRequestMulti multi = argumentCaptor.getAllValues().get(0);
        // Assertions here.
        assertEquals(
                MtxRequestSubscriberPurchaseOffer.class.getSimpleName(),
                multi.getRequestList().get(0).getMdcName());
        MtxPurchasedOfferData pod = (MtxPurchasedOfferData) ((MtxRequestSubscriberPurchaseOffer) multi.getRequestList().get(
                0)).getOfferRequestArray().get(0);
        assertEquals(
                CREDIT_CONSTANTS.GRANT_TYPE_PERCENTAGE,
                ((VisiblePurchasedOfferExtension) pod.getAttr()).getCreditGrantType());
    }

    @SuppressWarnings("unchecked")
    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_purchaseMultiService_ServiceFirstInsuranceNext_Success_refactoring()
            throws Exception {
        String baseService = CI_EXTERNAL_IDS.UNLIMITED;
        String insuranceService = CI_EXTERNAL_IDS.UNLIMITED;
        List<String> svcList = List.of(baseService, insuranceService);
        VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", svcList);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());

        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());

        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                baseService, "", "", null, wallet);

        MtxResponsePricingOffer pricingOfferService = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);
        MtxResponsePricingOffer pricingOfferInsurance = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);

        VisibleMultiResponsePurchaseService output = new VisibleMultiResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, svcList);
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
        doReturn(pricingOfferService).when(instance).queryPricingOffer(
                any(), any(), eq(CI_EXTERNAL_IDS.UNLIMITED));
        doReturn(pricingOfferInsurance).when(instance).queryPricingOffer(
                any(), any(), eq("Visible_Device_Insurance_Bundle_CI"));

        // method to test
        instance.purchaseMultiService(input, output);
        // Assertions here.
        assertEquals(RESULT_CODES.MTX_SUCCESS, output.getResult());

        ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();
        reqList.forEach(req -> {
            if (req.getMdcName().equals(MtxRequestSubscriberRecharge.class.getSimpleName())) {
                // Test Visible Override Flag
                MtxRequestSubscriberRecharge rechargeRequest = (MtxRequestSubscriberRecharge) req;
                if (rechargeRequest.getReason().equals("purchase_service")) {
                    assertEquals(
                            false,
                            ((VisibleBraintreeChargeMethodExtension) rechargeRequest.getChargeMethodData().getChargeMethodAttr()).getVisibleRecurringOverride());

                    assertEquals(
                            pricingOfferService.getOfferInfo().getAttrList().stream().filter(
                                    attr -> attr.getName().equals(
                                            ReflectionTestUtils.getField(
                                                    instance,
                                                    "ATTR_NAME_RECHARGE_REASON").toString())).map(
                                                            attr -> attr.getValue()).findFirst().get(),
                            rechargeRequest.getReason());
                } else if (rechargeRequest.getReason().equals("purchase_insurance")) {
                    assertEquals(
                            false,
                            ((VisibleBraintreeChargeMethodExtension) rechargeRequest.getChargeMethodData().getChargeMethodAttr()).getVisibleRecurringOverride());
                    assertEquals(
                            pricingOfferInsurance.getOfferInfo().getAttrList().stream().filter(
                                    attr -> attr.getName().equals(
                                            ReflectionTestUtils.getField(
                                                    instance,
                                                    "ATTR_NAME_RECHARGE_REASON").toString())).map(
                                                            attr -> attr.getValue()).findFirst().get(),
                            rechargeRequest.getReason());
                }

                assertEquals(
                        BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION,
                        rechargeRequest.getAmount().scale());

            }
            if (req.getMdcName().equals(MtxRequestSubscriberPurchaseOffer.class.getSimpleName())) {
                MtxRequestSubscriberPurchaseOffer purchaseRequest = (MtxRequestSubscriberPurchaseOffer) req;

                String goodtype = ((VisiblePurchasedOfferExtension) purchaseRequest.getOfferRequestArray().get(
                        0).getAttr()).getGoodType();
                if (("purchase_service").equals(goodtype)) {
                    assertEquals(
                            pricingOfferService.getOfferInfo().getAttrList().stream().filter(
                                    attr -> attr.getName().equals(
                                            ReflectionTestUtils.getField(
                                                    instance,
                                                    "ATTR_NAME_GOOD_TYPE").toString())).map(
                                                            attr -> attr.getValue()).findFirst().get(),
                            goodtype);
                } else if (("purchase_insurance").equals(goodtype)) {
                    assertEquals(
                            pricingOfferInsurance.getOfferInfo().getAttrList().stream().filter(
                                    attr -> attr.getName().equals(
                                            ReflectionTestUtils.getField(
                                                    instance,
                                                    "ATTR_NAME_GOOD_TYPE").toString())).map(
                                                            attr -> attr.getValue()).findFirst().get(),
                            goodtype);
                }
            }
        });
    }

    @SuppressWarnings("unchecked")
    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_purchaseMultiService_ServiceFirstInsuranceNext_WithReferralAndGroupCredits_Success(TestInfo testInfo)
            throws Exception {
        String baseService = CI_EXTERNAL_IDS.UNLIMITED;
        String insuranceService = CI_EXTERNAL_IDS.UNLIMITED;
        List<String> svcList = List.of(baseService, insuranceService);
        VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", svcList);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());

        MtxResponseMulti multiResMainBal = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());

        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());

        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);

        Map<String, BigDecimal> promoGrantCiRedeemMap = Map.of(
                CI_EXTERNAL_IDS.PARTY_PAY_GRANT, BigDecimal.valueOf(5),
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.valueOf(10));

        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                baseService, "", "", promoGrantCiRedeemMap, wallet);

        MtxResponsePricingOffer pricingOfferService = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        MtxResponsePricingOffer pricingOfferInsurance = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);

        VisibleMultiResponsePurchaseService output = new VisibleMultiResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(
                instance, List.of(CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.INSURANCE));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResMainBal).doReturn(multiRes).when(instance).multiRequest(
                any(), any(), argumentCaptor.capture());
        doReturn(pricingOfferService).when(instance).queryPricingOffer(
                any(), any(), eq(CI_EXTERNAL_IDS.UNLIMITED));
        doReturn(pricingOfferInsurance).when(instance).queryPricingOffer(
                any(), any(), eq("Visible_Device_Insurance_Bundle_CI"));

        // method to test
        instance.purchaseMultiService(input, output);
        List<MtxRequestMulti> multiReqList = argumentCaptor.getAllValues();

        MtxRequestMulti multReq = (MtxRequestMulti) multiReqList.get(0);
        System.out.println(testInfo.getDisplayName() + ":" + multReq.toJson());
        MtxRequestSubscriberPurchaseOffer referralRedeempurchase = getMtxRequestSubscriberPurchaseOfferFromMultiRequest(
                multReq, CI_EXTERNAL_IDS.GOODWILL_REDEEM);
        VisiblePurchasedOfferExtension referralRedeempurchaseExtn = (VisiblePurchasedOfferExtension) referralRedeempurchase.getOfferRequestArray().get(
                0).getAttr();

        MtxRequestSubscriberPurchaseOffer groupRedeemPurchase = getMtxRequestSubscriberPurchaseOfferFromMultiRequest(
                multReq, CI_EXTERNAL_IDS.PARTY_PAY_REDEEM);
        VisiblePurchasedOfferExtension groupRedeemPurchaseExtn = (VisiblePurchasedOfferExtension) groupRedeemPurchase.getOfferRequestArray().get(
                0).getAttr();

        VisibleCredits vcRef = aop.getCredits().stream().filter(
                vc -> vc.getCreditRedeemableOfferCI().equalsIgnoreCase(
                        CI_EXTERNAL_IDS.GOODWILL_REDEEM)).findFirst().get();
        assertEquals(
                vcRef.getEstimatedTransferableCredits(),
                referralRedeempurchaseExtn.getChargeAmount());
        MtxRequestSubscriberPurchaseOffer mainOfferPurchase = getMtxRequestSubscriberPurchaseOfferFromMultiRequest(
                multReq, CI_EXTERNAL_IDS.UNLIMITED);
        VisiblePurchasedOfferExtension mainOfferPurchaseExtn = (VisiblePurchasedOfferExtension) mainOfferPurchase.getOfferRequestArray().get(
                0).getAttr();

        assertTrue(mainOfferPurchaseExtn.getCreditTaxDetailsArray().size() == 2);
        assertEquals(TAX_CLASS_CODES.PARTY_PAY, groupRedeemPurchaseExtn.getCreditReason());
    }

    @SuppressWarnings("unchecked")
    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_purchaseMultiService_ServiceFirstInsuranceNext_OnlyGroupCredits_Success(TestInfo testInfo)
            throws Exception {
        String baseService = CI_EXTERNAL_IDS.UNLIMITED;
        String insuranceService = CI_EXTERNAL_IDS.INSURANCE;
        List<String> svcList = List.of(baseService, insuranceService);
        VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", svcList);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());

        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());
        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);
        Map<String, BigDecimal> promoGrantCiRedeemMap = Map.of(
                CI_EXTERNAL_IDS.PARTY_PAY_GRANT, BigDecimal.valueOf(5));
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                baseService, "", "", promoGrantCiRedeemMap, wallet);

        MtxResponsePricingOffer pricingOfferService = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);
        MtxResponsePricingOffer pricingOfferInsurance = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);

        VisibleMultiResponsePurchaseService output = new VisibleMultiResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, svcList);
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        // Capture Arguments for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
        doReturn(pricingOfferService).when(instance).queryPricingOffer(
                any(), any(), eq(baseService));
        doReturn(pricingOfferInsurance).when(instance).queryPricingOffer(
                any(), any(), eq(insuranceService));

        // method to test
        instance.purchaseMultiService(input, output);
        // Assertions here.
        assertEquals(RESULT_CODES.MTX_SUCCESS, output.getResult());
        MtxRequestMulti multReq = argumentCaptor.getAllValues().get(0);
        System.out.println(testInfo.getDisplayName() + " : " + multReq.toJson());

        MtxRequestSubscriberPurchaseOffer groupRedeemPurchase = getMtxRequestSubscriberPurchaseOfferFromMultiRequest(
                multReq, CI_EXTERNAL_IDS.PARTY_PAY_REDEEM);
        assertTrue(groupRedeemPurchase != null);

        MtxRequestSubscriberPurchaseOffer mainOfferPurchase = getMtxRequestSubscriberPurchaseOfferFromMultiRequest(
                multReq, CI_EXTERNAL_IDS.UNLIMITED);
        VisiblePurchasedOfferExtension mainOfferPurchaseExtn = (VisiblePurchasedOfferExtension) mainOfferPurchase.getOfferRequestArray().get(
                0).getAttr();
        assertTrue(mainOfferPurchaseExtn.getCreditTaxDetailsArray().size() == 1);
    }

    @Test
    public void test_purchaseMultiService_method_getOrderIdForEligibleOffer() throws Exception {
        List<String> svcList = List.of(CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.INSURANCE);
        VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", svcList);
        ArrayList<String> eligibleOfferList = new ArrayList<String>();
        eligibleOfferList.add("Visible_Unlimited");

        String orderId = ReflectionTestUtils.invokeMethod(
                instance, "getOrderIdForEligibleOffer", input, "Visible_Unlimited");

        assertEquals(TestUtils.getYYYYMMDDToday(), orderId);
    }

    // @formatter:off
    @SuppressWarnings("unchecked")
    @CsvSource(delimiter = '|', value={
                 "|Given|Active Subscription. Subscriber has applicable credits.|"                
                +"|When |Api is called. PurchaseAdvice returns all credits.|"
                +"|Then |All credits are redeemed.|"})
    // @formatter:on
    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_purchaseMultiService_When_AdviceHasCredits_Then_CreditsRedeemed()
            throws Exception {

        String baseService = CI_EXTERNAL_IDS.UNLIMITED;

        List<String> svcList = List.of(baseService);
        VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", svcList);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());

        MtxResponseMulti multiResMainBal = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());
        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);

        Map<String, BigDecimal> promoGrantCiRedeemMap = Map.of(
                CI_EXTERNAL_IDS.PARTY_PAY_GRANT, BigDecimal.valueOf(5),
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.valueOf(10));

        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                baseService, "", "", promoGrantCiRedeemMap, wallet);
        MtxResponsePricingOffer pricingOfferService = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);
        emulateMtxResponsePricingCatalogItems(instance, svcList);

        VisibleMultiResponsePurchaseService output = new VisibleMultiResponsePurchaseService();
        // mocks
        // First mock PropertiesConfiguration. Then using the same mock
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
        doReturn(multiResMainBal).doReturn(multiRes).when(instance).multiRequest(
                any(), any(), argumentCaptor.capture());
        doReturn(pricingOfferService).when(instance).queryPricingOffer(
                any(), any(), eq(CI_EXTERNAL_IDS.UNLIMITED));

        // method to test
        instance.purchaseMultiService(input, output);
        List<MtxRequestMulti> multiReqList = argumentCaptor.getAllValues();
        multiReqList.forEach(req -> {
            System.out.println(req.toJson());
        });

        MtxRequestMulti multReq = (MtxRequestMulti) multiReqList.get(0);

        MtxRequestSubscriberPurchaseOffer goodwillRedeemPurchase = getMtxRequestSubscriberPurchaseOfferFromMultiRequest(
                multReq, CI_EXTERNAL_IDS.GOODWILL_REDEEM);
        VisiblePurchasedOfferExtension goodwillPurchaseExtn = (VisiblePurchasedOfferExtension) goodwillRedeemPurchase.getOfferRequestArray().get(
                0).getAttr();
        VisibleCredits goodWill = aop.getCredits().stream().filter(
                cr -> cr.getCreditRedeemableOfferCI().equalsIgnoreCase(
                        CI_EXTERNAL_IDS.GOODWILL_REDEEM)).findAny().get();

        assertEquals(
                goodWill.getEstimatedTransferableCredits(), goodwillPurchaseExtn.getChargeAmount());

        MtxRequestSubscriberPurchaseOffer partyRedeemPurchase = getMtxRequestSubscriberPurchaseOfferFromMultiRequest(
                multReq, CI_EXTERNAL_IDS.PARTY_PAY_REDEEM);
        VisiblePurchasedOfferExtension partyPurchaseExtn = (VisiblePurchasedOfferExtension) partyRedeemPurchase.getOfferRequestArray().get(
                0).getAttr();
        VisibleCredits party = aop.getCredits().stream().filter(
                cr -> cr.getCreditRedeemableOfferCI().equalsIgnoreCase(
                        CI_EXTERNAL_IDS.PARTY_PAY_REDEEM)).findAny().get();

        assertEquals(party.getEstimatedTransferableCredits(), partyPurchaseExtn.getChargeAmount());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_purchaseMultiService_ServiceFirstInsuranceNext_only_GoodWill_withconsumableBal_NoTransBalAmt()
            throws Exception {
        List<String> svcList = List.of(CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.INSURANCE);
        VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", svcList);

        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseMulti multiResMainBal = CommonTestHelper.getEmptyMtxResponseMulti();

        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);
        Map<String, BigDecimal> promoGrantCiRedeemMap = Map.of(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.valueOf(10));
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                CI_EXTERNAL_IDS.UNLIMITED, "", "", promoGrantCiRedeemMap, wallet);
        aop.getAtCredits(0).setAvailableCreditsConsumable(
                aop.getAtCredits(0).getRedeemableCredits());
        aop.getAtCredits(0).setAvailableCreditsGrant(BigDecimal.ZERO);

        MtxResponsePricingOffer pricingOfferService = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);
        MtxResponsePricingOffer pricingOfferInsurance = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);

        VisibleMultiResponsePurchaseService output = new VisibleMultiResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, svcList);
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
        doReturn(multiResMainBal).doReturn(multiRes).when(instance).multiRequest(
                any(), any(), argumentCaptor.capture());
        doReturn(pricingOfferService).when(instance).queryPricingOffer(
                any(), any(), eq(CI_EXTERNAL_IDS.UNLIMITED));
        doReturn(pricingOfferInsurance).when(instance).queryPricingOffer(
                any(), any(), eq("Visible_Device_Insurance_Bundle_CI"));

        // method to test
        instance.purchaseMultiService(input, output);
        List<MtxRequestMulti> multiReqList = argumentCaptor.getAllValues();
        MtxRequestMulti multReq = multiReqList.get(0);

        System.out.println(multReq.toJson());

        MtxRequestSubscriberPurchaseOffer mainOfferPurchase = getMtxRequestSubscriberPurchaseOfferFromMultiRequest(
                multReq, CI_EXTERNAL_IDS.UNLIMITED);
        VisiblePurchasedOfferExtension mainOfferPurchaseExtn = (VisiblePurchasedOfferExtension) mainOfferPurchase.getOfferRequestArray().get(
                0).getAttr();

        assertTrue(mainOfferPurchaseExtn.getCreditTaxDetailsArray().size() == 1);
        assertNull(mainOfferPurchaseExtn.getGroupMemberCount());
    }

    @Test
    @Tag("VER-37")
    public void test_purchaseMultiService_When_InputHasChannel_Then_ServicePurchaseHasChannel()
            throws Exception {
        System.out.println(
                "Test Case for https://jira.unico.com.au/browse/MTXVER2-32 https://matrixxservices.atlassian.net/browse/VER-37");
        String service = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", List.of(service));

        String expectedChannel = "ChannelXYZ";
        VisiblePurchasedOfferExtension attr = new VisiblePurchasedOfferExtension();
        attr.setChannel(expectedChannel);

        input.getAtPurchaseInfo(0).setAttrData(attr);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());
        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                service, "", "", null, wallet);
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleMultiResponsePurchaseService output = new VisibleMultiResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, List.of(service));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), eq(service));
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        // method to test
        instance.purchaseMultiService(input, output);
        System.out.println(argumentCaptor.getValue().toJson());

        MtxRequestSubscriberPurchaseOffer mainOfferPurchase = getMtxRequestSubscriberPurchaseOfferFromMultiRequest(
                argumentCaptor.getValue(), CI_EXTERNAL_IDS.UNLIMITED);
        VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) mainOfferPurchase.getOfferRequestArray().get(
                0).getAttr();

        // Assertions here.
        assertEquals(RESULT_CODES.MTX_SUCCESS, output.getResult());
        assertEquals(expectedChannel, poExtn.getChannel());
    }

    @Test
    @Tag("VER-37")
    public void test_purchaseMultiService_When_InputHasDuration_Then_ServicePurchaseHasDuration()
            throws Exception {
        System.out.println(
                "Test Case for https://jira.unico.com.au/browse/MTXVER2-32 https://matrixxservices.atlassian.net/browse/VER-37");
        String service = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", List.of(service));

        String expectedDuration = 123456 + "";
        VisiblePurchasedOfferExtension attr = new VisiblePurchasedOfferExtension();
        attr.setDuration(expectedDuration);

        input.getAtPurchaseInfo(0).setAttrData(attr);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());
        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                service, "", "", null, wallet);
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleMultiResponsePurchaseService output = new VisibleMultiResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, List.of(service));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), eq(service));
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        // method to test
        instance.purchaseMultiService(input, output);
        MtxRequestSubscriberPurchaseOffer mainOfferPurchase = getMtxRequestSubscriberPurchaseOfferFromMultiRequest(
                argumentCaptor.getValue(), CI_EXTERNAL_IDS.UNLIMITED);
        VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) mainOfferPurchase.getOfferRequestArray().get(
                0).getAttr();

        // Assertions here.
        assertEquals(RESULT_CODES.MTX_SUCCESS, output.getResult());
        assertEquals(expectedDuration, poExtn.getDuration());
    }

    @Test
    public void test_purchaseMultiService_When_InputHasChannel_Then_AocPromoRedeemHasChannel()
            throws Exception {
        System.out.println(
                "Test Case for https://jira.unico.com.au/browse/MTXVER2-32 https://matrixxservices.atlassian.net/browse/VER-37");
        String service = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", List.of(service));

        String expectedChannel = "ChannelXYZ";
        VisiblePurchasedOfferExtension attr = new VisiblePurchasedOfferExtension();
        attr.setChannel(expectedChannel);

        input.getAtPurchaseInfo(0).setAttrData(attr);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);
        Map<String, BigDecimal> promoGrantCiRedeemMap = Map.of(
                CI_EXTERNAL_IDS.PARTY_PAY_GRANT, BigDecimal.valueOf(5));
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                service, "", "", promoGrantCiRedeemMap, wallet);
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);
        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());
        VisibleMultiResponsePurchaseService output = new VisibleMultiResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, List.of(service));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), eq(service));
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        // method to test
        instance.purchaseMultiService(input, output);
        System.out.println(argumentCaptor.getValue().toJson());

        MtxRequestSubscriberPurchaseOffer groupRedeem = getMtxRequestSubscriberPurchaseOfferFromMultiRequest(
                argumentCaptor.getValue(), CI_EXTERNAL_IDS.PARTY_PAY_REDEEM);
        VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) groupRedeem.getOfferRequestArray().get(
                0).getAttr();

        // Assertions here.
        assertEquals(RESULT_CODES.MTX_SUCCESS, output.getResult());
        assertEquals(expectedChannel, poExtn.getChannel());
    }

    @Test
    @Tag("VER-37")
    public void test_purchaseMultiService_When_InputHasChannel_Then_AocPromoRedeemHasDuration()
            throws Exception {
        System.out.println(
                "Test Case for https://jira.unico.com.au/browse/MTXVER2-32 https://matrixxservices.atlassian.net/browse/VER-37");
        String service = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", List.of(service));

        String expectedDuration = 123456 + "";
        VisiblePurchasedOfferExtension attr = new VisiblePurchasedOfferExtension();
        attr.setDuration(expectedDuration);

        input.getAtPurchaseInfo(0).setAttrData(attr);
        System.out.println(input.toJson());

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());

        Map<String, BigDecimal> promoGrantCiRedeemMap = Map.of(
                CI_EXTERNAL_IDS.PARTY_PAY_GRANT, BigDecimal.valueOf(5));

        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                service, "", "", promoGrantCiRedeemMap, wallet);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);
        VisibleMultiResponsePurchaseService output = new VisibleMultiResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, List.of(service));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), eq(service));
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        // method to test
        instance.purchaseMultiService(input, output);
        System.out.println(argumentCaptor.getValue().toJson());

        MtxRequestSubscriberPurchaseOffer groupRedeem = getMtxRequestSubscriberPurchaseOfferFromMultiRequest(
                argumentCaptor.getValue(), CI_EXTERNAL_IDS.PARTY_PAY_REDEEM);
        VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) groupRedeem.getOfferRequestArray().get(
                0).getAttr();

        // Assertions here.
        assertEquals(RESULT_CODES.MTX_SUCCESS, output.getResult());
        assertEquals(expectedDuration, poExtn.getDuration());
    }

    @Test
    @Tag("VER-41")
    public void test_purchaseMultiService_When_ApiEventData_IsNotEmpty_Then_ApiEventData_SentToEngine(TestInfo testInfo)
            throws Exception {
        System.out.println(
                "Test Case for https://jira.unico.com.au/browse/MTXVER2-76 https://matrixxservices.atlassian.net/browse/VER-41");
        String testLoggingKey = getTestLoggingKey(testInfo.getDisplayName());
        String service = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", List.of(service));

        VisibleApiEventData extn = new VisibleApiEventData();
        extn.setOrderId("12345");
        input.setApiEventData(extn);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());
        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                service, "", "", null, wallet);
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleMultiResponsePurchaseService output = new VisibleMultiResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, List.of(service));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), eq(service));
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        // method to test
        instance.purchaseMultiService(input, output);
        MtxRequestSubscriberPurchaseOffer mainOfferPurchase = getMtxRequestSubscriberPurchaseOfferFromMultiRequest(
                argumentCaptor.getValue(), CI_EXTERNAL_IDS.UNLIMITED);
        mainOfferPurchase.getOfferRequestArray().get(0).getAttr();

        // Assertions here.
        System.out.println(testLoggingKey + StringUtils.SPACE + argumentCaptor.getValue().toJson());
        // Assertions here.
        assertEquals(
                extn.getMdcName(), argumentCaptor.getValue().getApiEventData().getMdcName(),
                VisibleApiEventData.class.getSimpleName() + " should be present.");
        assertEquals(
                extn.getOrderId(),
                ((VisibleApiEventData) argumentCaptor.getValue().getApiEventData()).getOrderId());
    }

    @Test
    @Tag("VER-41")
    public void test_purchaseMultiService_When_ApiEventData_IsMissing_Then_ApiEventData_NotSentToEngine(TestInfo testInfo)
            throws Exception {
        System.out.println(
                "Test Case for https://jira.unico.com.au/browse/MTXVER2-76 https://matrixxservices.atlassian.net/browse/VER-41");
        String testLoggingKey = getTestLoggingKey(testInfo.getDisplayName());
        String service = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", List.of(service));

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());

        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                service, "", "", null, wallet);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleMultiResponsePurchaseService output = new VisibleMultiResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, List.of(service));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(
                any(), any(), eq(CI_EXTERNAL_IDS.UNLIMITED));
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        // method to test
        instance.purchaseMultiService(input, output);
        MtxRequestSubscriberPurchaseOffer mainOfferPurchase = getMtxRequestSubscriberPurchaseOfferFromMultiRequest(
                argumentCaptor.getValue(), CI_EXTERNAL_IDS.UNLIMITED);
        mainOfferPurchase.getOfferRequestArray().get(0).getAttr();

        // Assertions here.
        System.out.println(testLoggingKey + StringUtils.SPACE + argumentCaptor.getValue().toJson());
        // Assertions here.
        assertEquals(
                null, argumentCaptor.getValue().getApiEventData(),
                VisibleApiEventData.class.getSimpleName() + " should not be present.");
    }

    @Test
    @Tag("VER-41")
    public void test_purchaseMultiService_When_ApiEventData_IsEmpty_Then_ApiEventData_NotSentToEngine(TestInfo testInfo)
            throws Exception {
        System.out.println(
                "Test Case for https://jira.unico.com.au/browse/MTXVER2-76 https://matrixxservices.atlassian.net/browse/VER-41");
        String testLoggingKey = getTestLoggingKey(testInfo.getDisplayName());
        String service = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", List.of(service));
        VisibleApiEventData extn = new VisibleApiEventData();
        input.setApiEventData(extn);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());
        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                service, "", "", null, wallet);
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleMultiResponsePurchaseService output = new VisibleMultiResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, List.of(service));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(
                any(), any(), eq(CI_EXTERNAL_IDS.UNLIMITED));
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        // method to test
        instance.purchaseMultiService(input, output);
        MtxRequestSubscriberPurchaseOffer mainOfferPurchase = getMtxRequestSubscriberPurchaseOfferFromMultiRequest(
                argumentCaptor.getValue(), CI_EXTERNAL_IDS.UNLIMITED);
        mainOfferPurchase.getOfferRequestArray().get(0).getAttr();

        // Assertions here.
        System.out.println(testLoggingKey + StringUtils.SPACE + argumentCaptor.getValue().toJson());
        // Assertions here.
        assertEquals(
                VisibleApiEventData.class.getSimpleName(),
                argumentCaptor.getValue().getApiEventData().getMdcName(),
                VisibleApiEventData.class.getSimpleName() + " should be present.");

        assertEquals(
                0,
                argumentCaptor.getValue().getApiEventData().getContainer().getFields() == null
                        ? 0
                        : argumentCaptor.getValue().getApiEventData().getContainer().getFields().size(),
                VisibleApiEventData.class.getSimpleName() + " should be empty.");
    }

    @Test
    @Tag("VER-461")
    @CsvSource(delimiter = '|', value = {
        "|Given|Active Subscription.|"
                + "|When |Api is called. PurchaseAdvice returns cycle dates.|"
                + "|Then |Api should update cycle length.|"
    })
    // @formatter:on
    public void test_purchaseMultiService_When_CycleDatesAvailable_Then_UpdateCycleLength(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.printDescription();

        String testLoggingKey = getTestLoggingKey(testInfo.getDisplayName());
        TwoParameterTest pTests = (svc, cLength) -> {
            String service = svc.toString();
            VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                    "1234", List.of(service));

            VisibleApiEventData aed = new VisibleApiEventData();
            input.setApiEventData(aed);

            MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
            MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                    CI_EXTERNAL_IDS.UNLIMITED_DATA);

            MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);
            VisibleResponsePurchaseAdvice advice = CommonTestHelper.getPurchaseAdvice(
                    service, "", "", null, wallet);

            VisibleMultiResponsePurchaseService output = new VisibleMultiResponsePurchaseService();

            // mocks
            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(List.of(service)));
            emulateMtxResponsePricingCatalogItems(instance, List.of(service));
            doReturn("").when(instance).getRoute(any());
            doReturn(advice).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
            doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), eq(service));

            // Capture Arguements for multirequest
            ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                    MtxRequestMulti.class);
            doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

            // method to test
            instance.purchaseMultiService(input, output);

            argumentCaptor.getAllValues().forEach(mult -> {
                System.out.println(
                        testLoggingKey + StringUtils.SPACE + "MultiRequest:" + mult.toJson());
            });

            // Assertions here.
            MtxRequestMulti multiReq = argumentCaptor.getAllValues().get(0);
            long countModifySubRequests = multiReq.getRequestList().stream().filter(
                    req -> MtxRequestSubscriptionModify.class.getSimpleName().equalsIgnoreCase(
                            req.getContainer().getName())).count();

            if (countModifySubRequests > 0) {
                MtxRequestSubscriptionModify sm = ((MtxRequestSubscriptionModify) multiReq.getRequestList().stream().filter(
                        req -> MtxRequestSubscriptionModify.class.getSimpleName().equalsIgnoreCase(
                                req.getContainer().getName())).map(
                                        req -> (MtxRequestSubscriptionModify) req).findFirst().get());
                VisibleSubscriberExtension extn = (VisibleSubscriberExtension) sm.getAttr();
                assertEquals(cLength.toString(), extn.getCycleLength());
            } else {
                fail("No Subscriber Modify Requests Found.");
            }
        };
        pTests.test(CI_EXTERNAL_IDS.PLUS3VIS23, CYCLE_LENGTHS.MONTH);
        pTests.test(CI_EXTERNAL_IDS.PLUS3ANNUAL, CYCLE_LENGTHS.YEAR);
    }

    @Test
    @Tag("VER-597")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Active Subscription. PurchaseService called for a service.|"                
                +"|When |Credit tax error in purchase advice.|"
                +"|Then |Api should provide tax error message.|"})
    // @formatter:on
    public void test_purchaseMultiService_When_AdviceWithCreditsTaxError_Then_ErrorInTaxResponse(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();

        String service = CI_EXTERNAL_IDS.PLUS3VIS23;

        VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", List.of(service));

        VisibleApiEventData aed = new VisibleApiEventData();
        input.setApiEventData(aed);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        String crediTaxError = "xyz-TaxException-xyz";
        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);

        Map<String, BigDecimal> promoGrantCiRedeemMap = Map.of(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.valueOf(10));

        VisibleResponsePurchaseAdvice advice = CommonTestHelper.getPurchaseAdvice(
                service, "", "", promoGrantCiRedeemMap, wallet);
        advice.getAtCredits(0).setTaxDetails(crediTaxError);

        VisibleMultiResponsePurchaseService output = new VisibleMultiResponsePurchaseService();

        // mocks
        emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription(List.of(service)));
        emulateMtxResponsePricingCatalogItems(instance, List.of(service));
        doReturn("").when(instance).getRoute(any());
        doReturn(advice).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), eq(service));
        doReturn(multiRes).when(instance).multiRequest(any(), any(), any());

        // method to test
        Exception exception = assertThrows(
                SubscriberServiceException.class,
                () -> instance.purchaseMultiService(input, output));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().contains(crediTaxError));
    }
    @ParameterizedTest(
            name = "test_purchaseMultiService_When_MultimonthCycle_Then_MultimonthCycleLength")
    @Tag("VER-845")@Tag("VER-850")
    @Tag("Multimonth")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Active subscription. Request has Multimonth offer.|"
                +"|When  |As per PurchaseAdvice, Cycle length is more than a month less than a year..|"
                +"|Then  |Modify cycle length to MultiMonth.|"})
    // @formatter:on
    public void test_purchaseMultiService_When_MultimonthCycle_Then_MultimonthCycleLength(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String service = CI_EXTERNAL_IDS.BASE6MONTH25;
        VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", List.of(service));
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());

        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(subRes.getTimeZone(), BigDecimal.ZERO);
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                service, "", "", null, wallet);
        aop.getVodList().get(0).setPurchaseOfferEndTime(TestUtils.addMonths(wallet.getBillingCycle().getCurrentPeriodStartTime(), 6, subRes.getTimeZone()));

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleMultiResponsePurchaseService output = new VisibleMultiResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, List.of(service));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), eq(service));
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        // method to test
        instance.purchaseMultiService(input, output);
        argumentCaptor.getAllValues().forEach(multi->{
            System.out.println("multi:"+multi.toJson());
        });
        
        MtxRequestSubscriptionModify modReq = new MtxRequestSubscriptionModify(argumentCaptor.getAllValues().get(0).getAtRequestList(1));
        VisibleSubscriberExtension attr = (VisibleSubscriberExtension)modReq.getAttr();
        // Assertions here.
        assertEquals(CYCLE_LENGTHS.MULTI_MONTH, attr.getCycleLength());
    }
    
    @ParameterizedTest(
            name = "test_purchaseMultiService_Given_MMFallbackOffer_When_MainOfferEnds_Then_Purchase_MMFallback")
    @Tag("VER-845")
    @Tag("Multimonth")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Active subscription. Request has Multimonth fallback offer.|"
                +"|When  |PurchaseAdvice has end date for main offer.|"
                +"|Then  |Purchase fallback offer.|"})
    // @formatter:on
    public void test_purchaseMultiService_Given_MMFallbackOffer_When_MainOfferEnds_Then_Purchase_MMFallback(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String service = CI_EXTERNAL_IDS.BASE6MONTH25;
        VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", List.of(service));
        input.getAtPurchaseInfo(0).getPurchaseServiceInfo().setNextPlanId(CI_EXTERNAL_IDS.PRO25);
        input.getAtPurchaseInfo(0).getPurchaseServiceInfo().setNextPlanAmount("45");
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());

        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(subRes.getTimeZone(), BigDecimal.ZERO);
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                service, "", "", null, wallet);
        aop.getVodList().get(0).setPurchaseOfferEndTime(TestUtils.addMonths(wallet.getBillingCycle().getCurrentPeriodStartTime(), 6, subRes.getTimeZone()));

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleMultiResponsePurchaseService output = new VisibleMultiResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, List.of(service));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), eq(service));
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        // method to test
        instance.purchaseMultiService(input, output);
        argumentCaptor.getAllValues().forEach(multi->{
            System.out.println("multi:"+multi.toJson());
        });
        
        MtxRequestMulti multiRequest = argumentCaptor.getAllValues().get(0);
        boolean fallbackPurchased = false;
        for(MtxRequest req:multiRequest.getRequestList()) {
            if(MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(req.getContainer().getName())) {
                MtxRequestSubscriberPurchaseOffer po = new MtxRequestSubscriberPurchaseOffer(req);
                if(input.getAtPurchaseInfo(0).getPurchaseServiceInfo().getNextPlanId().equalsIgnoreCase(po.getAtOfferRequestArray(0).getExternalId())) {
                    fallbackPurchased=true;
                    break;
                }
            }
        }
        // Assertions here.
        System.out.println("fallbackPurchased:"+fallbackPurchased);
        assertTrue(fallbackPurchased);
    }

    @ParameterizedTest(
            name = "test_purchaseMultiService_Given_MMFallbackOffer_When_MainOffer_Has_No_End_Then_No_MMFallback")
    @Tag("VER-845")
    @Tag("Multimonth")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Active subscription. Request has Multimonth fallback offer.|"
                +"|When  |PurchaseAdvice has NO end date for main offer.|"
                +"|Then  |do NOT Purchase fallback offer. Return warning message.|"})
    // @formatter:on
    public void test_purchaseMultiService_Given_MMFallbackOffer_When_MainOffer_Has_No_End_Then_No_MMFallback(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String service = CI_EXTERNAL_IDS.BASE6MONTH25;
        VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", List.of(service));
        input.getAtPurchaseInfo(0).getPurchaseServiceInfo().setNextPlanId(CI_EXTERNAL_IDS.PRO25);
        input.getAtPurchaseInfo(0).getPurchaseServiceInfo().setNextPlanAmount("45");
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());

        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(subRes.getTimeZone(), BigDecimal.ZERO);
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                service, "", "", null, wallet);
        aop.getVodList().get(0).setPurchaseOfferEndTime(null);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleMultiResponsePurchaseService output = new VisibleMultiResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, List.of(service));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), eq(service));
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        // method to test
        instance.purchaseMultiService(input, output);
        System.out.println("output:"+output.toJson());
        argumentCaptor.getAllValues().forEach(multi->{
            System.out.println("multi:"+multi.toJson());
        });
        
        MtxRequestMulti multiRequest = argumentCaptor.getAllValues().get(0);
        boolean fallbackPurchased = false;
        for(MtxRequest req:multiRequest.getRequestList()) {
            if(MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(req.getContainer().getName())) {
                MtxRequestSubscriberPurchaseOffer po = new MtxRequestSubscriberPurchaseOffer(req);
                if(input.getAtPurchaseInfo(0).getPurchaseServiceInfo().getNextPlanId().equalsIgnoreCase(po.getAtOfferRequestArray(0).getExternalId())) {
                    fallbackPurchased=true;
                    break;
                }
            }
        }
        // Assertions here.
        System.out.println("fallbackPurchased:"+fallbackPurchased);
        assertFalse(fallbackPurchased);
    }
    @ParameterizedTest(
            name = "test_purchaseMultiService_Given_MMFallbackOffer_When_MainOfferEnds_Then_Preactive_MMFallback")
    @Tag("VER-845")
    @Tag("Multimonth")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Active subscription.|"
                +"|When  |Api request has fallback request.|"
                +"|Then  |Purchase fallback offer should be purchased as preactive.|"})
    // @formatter:on
    public void test_purchaseMultiService_Given_MMFallbackOffer_When_MainOfferEnds_Then_Preactive_MMFallback(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String service = CI_EXTERNAL_IDS.BASE6MONTH25;
        VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", List.of(service));
        input.getAtPurchaseInfo(0).getPurchaseServiceInfo().setNextPlanId(CI_EXTERNAL_IDS.PRO25);
        input.getAtPurchaseInfo(0).getPurchaseServiceInfo().setNextPlanAmount("45");
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());

        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(subRes.getTimeZone(), BigDecimal.ZERO);
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                service, "", "", null, wallet);
        aop.getVodList().get(0).setPurchaseOfferEndTime(TestUtils.addMonths(wallet.getBillingCycle().getCurrentPeriodStartTime(), 6, subRes.getTimeZone()));

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleMultiResponsePurchaseService output = new VisibleMultiResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, List.of(service));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), eq(service));
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        // method to test
        instance.purchaseMultiService(input, output);
        argumentCaptor.getAllValues().forEach(multi->{
            System.out.println("multi:"+multi.toJson());
        });
        
        MtxRequestMulti multiRequest = argumentCaptor.getAllValues().get(0);
        MtxRequestSubscriberPurchaseOffer po = null;
        for(MtxRequest req:multiRequest.getRequestList()) {
            if(MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(req.getContainer().getName())) {
                 po = new MtxRequestSubscriberPurchaseOffer(req);
                if(input.getAtPurchaseInfo(0).getPurchaseServiceInfo().getNextPlanId().equalsIgnoreCase(po.getAtOfferRequestArray(0).getExternalId())) {                
                    break;
                }else {
                    po = null;
                }
            }
        }
        // Assertions here.
        assertTrue(po!=null);
        assertTrue(po.getAtOfferRequestArray(0).getPreActiveState());
    }

    @ParameterizedTest(
            name = "test_purchaseMultiService_When_Input_Has_MMFallbackOffer_Then_MMFallback_Starts_After_Main_Offer")
    @Tag("VER-845")
    @Tag("Multimonth")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Active subscription.|"
                +"|When  |Api request has fallback request. Main offer ends after 6 months.|"
                +"|Then  |Purchase fallback offer should start on the day main multimonth offer ends.|"})
    // @formatter:on
    public void test_purchaseMultiService_Given_MMFallbackOffer_When_MainOfferEnds_Then_MMFallback_Starts_After_Main_Offer(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String service = CI_EXTERNAL_IDS.BASE6MONTH25;
        VisibleMultiRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", List.of(service));
        input.getAtPurchaseInfo(0).getPurchaseServiceInfo().setNextPlanId(CI_EXTERNAL_IDS.PRO25);
        input.getAtPurchaseInfo(0).getPurchaseServiceInfo().setNextPlanAmount("45");
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());

        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(subRes.getTimeZone(), BigDecimal.ZERO);
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                service, "", "", null, wallet);
        aop.getVodList().get(0).setPurchaseOfferEndTime(TestUtils.addMonths(wallet.getBillingCycle().getCurrentPeriodStartTime(), 6, subRes.getTimeZone()));

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleMultiResponsePurchaseService output = new VisibleMultiResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, List.of(service));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), eq(service));
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        // method to test
        instance.purchaseMultiService(input, output);
        argumentCaptor.getAllValues().forEach(multi->{
            System.out.println("multi:"+multi.toJson());
        });
        
        MtxRequestMulti multiRequest = argumentCaptor.getAllValues().get(0);
        MtxRequestSubscriberPurchaseOffer po = null;
        for(MtxRequest req:multiRequest.getRequestList()) {
            if(MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(req.getContainer().getName())) {
                 po = new MtxRequestSubscriberPurchaseOffer(req);
                if(input.getAtPurchaseInfo(0).getPurchaseServiceInfo().getNextPlanId().equalsIgnoreCase(po.getAtOfferRequestArray(0).getExternalId())) {                
                    break;
                }else {
                    po = null;
                }
            }
        }
        // Assertions here.
        assertTrue(po!=null);
        assertEquals(aop.getVodList().get(0).getPurchaseOfferEndTime().getTime(),po.getAtOfferRequestArray(0).getAutoActivationTime().getTime());
    }

    private MtxRequestSubscriberPurchaseOffer getMtxRequestSubscriberPurchaseOfferFromMultiRequest(MtxRequestMulti multi,
                                                                                                   String ci) {
        MtxRequestSubscriberPurchaseOffer po = null;
        for (MtxRequest req : multi.getRequestList()) {
            if (req instanceof MtxRequestSubscriberPurchaseOffer) {
                MtxRequestSubscriberPurchaseOffer poReq = (MtxRequestSubscriberPurchaseOffer) req;
                if (ci.equalsIgnoreCase(poReq.getOfferRequestArray().get(0).getExternalId())) {
                    return poReq;
                }
            }
        }
        return po;
    }

}
