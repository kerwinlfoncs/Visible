package com.matrixx.vag.advice.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.doReturn;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixx.datacontainer.MtxDate;
import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.EventQueryEventInfo;
import com.matrixx.datacontainer.mdc.EventQueryResponseEvents;
import com.matrixx.datacontainer.mdc.MtxBalanceInfo;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.MtxRecurringEvent;
import com.matrixx.datacontainer.mdc.MtxResponseOneTimeOffer;
import com.matrixx.datacontainer.mdc.MtxResponsePricingCatalogItem;
import com.matrixx.datacontainer.mdc.MtxResponsePurchase;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.PurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.SubscriptionResponse;
import com.matrixx.datacontainer.mdc.VisibleChangeServiceAddItem;
import com.matrixx.datacontainer.mdc.VisibleChangeServiceCancelItem;
import com.matrixx.datacontainer.mdc.VisibleCredits;
import com.matrixx.datacontainer.mdc.VisibleDeltaPromo;
import com.matrixx.datacontainer.mdc.VisibleOfferDetails;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleRequestChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleResponseChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleTemplate;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.advice.model.CreditStage;
import com.matrixx.vag.advice.model.GlobalCreditStage;
import com.matrixx.vag.advice.model.PromoOfferPair;
import com.matrixx.vag.advice.model.ServiceStage;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants;
import com.matrixx.vag.common.Constants.CREDIT_CONSTANTS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.OneParameterTest;
import com.matrixx.vag.common.TestConstants;
import com.matrixx.vag.common.TestConstants.BALANCE_NAMES;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestConstants.DATA_DIR;
import com.matrixx.vag.common.TestConstants.TAX_CLASS_CODES;
import com.matrixx.vag.common.TestUtils;
import com.matrixx.vag.common.TwoParameterTest;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.InvalidRequestException;
import com.matrixx.vag.tax.client.TaxApiClient;
import com.matrixx.vag.tax.model.ServiceTaxResponse;
import com.matrixx.vag.util.MDCTest;

@ExtendWith(MockitoExtension.class)
public class ChangeServiceAnnualOfferTest extends MDCTest {

    @Spy
    @InjectMocks
    private PaymentAdviceService instance = new PaymentAdviceService();

    @Mock
    private SubscriberManagementApi api;

    private TestInfo testInfo;

    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        instance = new PaymentAdviceService();
        MockitoAnnotations.openMocks(this);
        doReturn("").when(instance).getRoute(any());
        this.testInfo = testInfo;
    }

    @Test
    public void test_getChangeServiceAdvice_EnrolledInMonthly_ChangeNextCycle_Then_CycleDatesFromWallet(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with monthly base offer. PaidCycleStartDate is in past."
        };
        td.when = new String[] {
            "Api is called for CoreToCore change that affects next month"
        };
        td.then = new String[] {
            "CurrentBillCycle Dates should be from wallet."
        };

        @SuppressWarnings("unchecked")
        OneParameterTest pTests = (tCase) -> {
            String subscriptionExternalId = "123";
            TestConditions testCase = (TestConditions) tCase;
            td.printDescription();
            System.out.println(
                    "**************************Executing " + testCase.testNum
                            + "********************************");

            AppPropertyProvider.getInstance().setProperty(
                    Constants.CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");// No aoc promos

            String randomPastDate = "1900-01-01";

            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setSubscriptionExternalId(subscriptionExternalId);
            request.setNewCatalogItemExternalId(testCase.newCi);
            request.setDiscountPrice(testCase.getNewCiPrice());
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));

            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            String oldCiId = testCase.oldCi;
            BigDecimal oldPrice = testCase.getOldCiPrice();
            System.out.println(api.getClass());
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getPurchasedOfferArrayAppender().clear();

            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCiId);

            VisiblePurchasedOfferExtension enrolledExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            enrolledExtn.setChargeAmount(oldPrice);
            enrolledExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            MtxTimestamp expectedStart = subscriptionResponse.getBillingCycle().getCurrentPeriodStartTime();
            MtxTimestamp expectedEnd = subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime();

            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCiId);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));
            if (poiEnrolled.getCycleInfo() != null) {
                poiEnrolled.getCycleInfo().setCycleStartTime(expectedStart);
                poiEnrolled.getCycleInfo().setCycleEndTime(expectedEnd);
            }
            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(oldCiId, request.getNewCatalogItemExternalId()));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class, TestConstants.DATA_DIR.CHANGE_SERVICE_ADVICE
                            + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtn);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCiId);

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    oldCiId);
            BigDecimal mainbalanceOldCi = BigDecimal.valueOf(35);
            vodOldCi.setConsumableMainBalanceAmount(mainbalanceOldCi);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            Map<String, BigDecimal> balImpactMap = Map.of(
                    BALANCE_NAMES.GLOBAL_PASS, BigDecimal.ONE);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ONE, null, balImpactMap,
                    true);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            MtxTimestamp newCiStartTime = new MtxTimestamp(
                    LocalDateTime.now().toEpochSecond(ZoneOffset.UTC) * 1000);

            String taxRespString = CommonTestHelper.getTaxApiResp(testCase.newCi);
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ObjectMapper om = TestUtils.getObjectMapper();
                ServiceTaxResponse resp = om.readValue(taxRespString, ServiceTaxResponse.class);
                resp.getTransactionElement().get(0).setTotalFeeAmount(
                        BigDecimal.valueOf(testCase.fixedFee));
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                resp.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            System.out.println(newCiStartTime);
            assertEquals(
                    expectedStart.longValue(),
                    response.getChangeCycle().getCycleStartTime().longValue(),
                    "Cycle Start Time should be from Billing Cycle");
            System.out.println(expectedEnd + "<-->" + response.getChangeCycle().getCycleEndTime());
            assertEquals(
                    expectedEnd.longValue(),
                    response.getChangeCycle().getCycleEndTime().longValue(),
                    "Cycle End Time should be from Billing Cycle");
            System.out.println(
                    "**************************End of " + testCase.testNum
                            + "********************************");
        };

        TestConditions tc = new TestConditions();
        SimpleEntry<String, String> change1 = new SimpleEntry<>(
                CI_EXTERNAL_IDS.BASE3VIS23, CI_EXTERNAL_IDS.BASE3ANNUAL);
        SimpleEntry<String, String> change2 = new SimpleEntry<>(
                CI_EXTERNAL_IDS.BASE3VIS23, CI_EXTERNAL_IDS.PLUS3ANNUAL);
        SimpleEntry<String, String> change3 = new SimpleEntry<>(
                CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.BASE3VIS23);
        SimpleEntry<String, String> change4 = new SimpleEntry<>(
                CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.BASE3ANNUAL);
        SimpleEntry<String, String> change5 = new SimpleEntry<>(
                CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.PLUS3ANNUAL);
        List<SimpleEntry<String, String>> changes = List.of(
                change1, change2, change3, change4, change5);

        for (SimpleEntry<String, String> change : changes) {
            tc.oldCi = change.getKey();
            tc.newCi = change.getValue();
            tc.testNum = "#" + "oldCi:" + tc.oldCi + "-" + "newCi:" + tc.newCi;
            pTests.test(tc);
        }
    }

    @Test
    public void test_getChangeServiceAdvice_ChangeCycleOnly_BaseAnnual2PlusAnnual_Then_CorrectChangeCycleOutput(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with base offer. PaidCycleStartDate is in past."
        };
        td.when = new String[] {
            "Api is called for CoreToCore change that takes affect immidiately"
        };
        td.then = new String[] {
            "Validate ChangeCycleFields"
        };

        @SuppressWarnings("unchecked")
        OneParameterTest pTests = (tCase) -> {
            String subscriptionExternalId = "123";
            TestConditions testCase = (TestConditions) tCase;
            td.printDescription();
            System.out.println(
                    "**************************Executing " + testCase.testNum
                            + "********************************");

            AppPropertyProvider.getInstance().setProperty(
                    Constants.CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
            String randomPastDate = "1900-01-01";

            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setSubscriptionExternalId(subscriptionExternalId);
            request.setNewCatalogItemExternalId(testCase.newCi);
            request.setDiscountPrice(testCase.getNewCiPrice());
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));

            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            String oldCiId = testCase.oldCi;
            BigDecimal oldPrice = testCase.getOldCiPrice();
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.setTimeZone(ZoneId.systemDefault().toString());
            subscription.getPurchasedOfferArrayAppender().clear();

            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCiId);

            BigDecimal goodwillCredits = BigDecimal.valueOf(testCase.otherPromos);
            String goodwillTax = "{\"msgID\":\"IJKL-CR\",\"customerType\":\"99\",\"planID\":\"BASE001A\",\"grossPrice\":\"5.00\",\"discountPrice\":\""
                    + goodwillCredits
                    + "\",\"promotionCredit\":\"true\",\"offer606RevAdjDailyRecog\":\"0\",\"promotionReason\":\"Group_Discounts\",\"geocode\":\"US0100108296\",\"taxTreatment\":\"inclusive\",\"classCode\":\"GD-CR\",\"glDate\":\"2019-03-07\",\"transactionElement\":[{\"btcTransactionCode\":\"01\",\"totalTaxAmount\":\"0.07389163\",\"totalFeeAmount\":\"0.00000000\",\"totalNetRevenue\":\"4.92610836\",\"modifiedDisplayNetRevenue\":\"4.93\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"618\",\"cP\":\"0.75\",\"glReference\":\"Visible_Unlimited_Data\",\"dpcItemTaxAmount\":\"0.00000000\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"3.69458128\",\"taxItemList\":[]},{\"dpcItem\":\"601\",\"cP\":\"0.12\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.03546798\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.59113300\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.02364532\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.01182266\"}]},{\"dpcItem\":\"662\",\"cP\":\"0.04\",\"glReference\":\"Visible_Unlimited_Text\",\"dpcItemTaxAmount\":\"0.01182266\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.19704433\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.00788177\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.00394089\"}]},{\"dpcItem\":\"629\",\"cP\":\"0.09\",\"glReference\":\"Visible_Unlimited_MMS\",\"dpcItemTaxAmount\":\"0.02660099\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.44334975\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.01773399\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.00886700\"}]}]}]},{\"btcTransactionCode\":\"93\",\"totalTaxAmount\":\"0.03002956\",\"totalFeeAmount\":\"0.00000000\",\"totalNetRevenue\":\"4.92610836\",\"modifiedDisplayNetRevenue\":\"4.93\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"601\",\"cP\":\"0.12\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.03002956\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.59113300\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000000016\",\"tat\":\"0\",\"taxCategory\":\"00\",\"taxType\":\"35\",\"description\":\"Fed Universal Service Charge\",\"rate\":\"0.050800000000\",\"taxAmount\":\"0.03002956\"}]}]}]}]}";
            VisiblePurchasedOfferExtension enrolledExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            enrolledExtn.setChargeAmount(oldPrice);
            enrolledExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtn.getCreditTaxDetailsArrayAppender().add(goodwillTax);
            enrolledExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));
            subscription.getPurchasedOfferArrayAppender().add(poEnrolled);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            subscriptionResponse.setTimeZone(ZoneId.systemDefault().toString());
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCiId);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(oldCiId, request.getNewCatalogItemExternalId()));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class, TestConstants.DATA_DIR.CHANGE_SERVICE_ADVICE
                            + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtn);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCiId);

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    oldCiId);
            BigDecimal mainbalanceOldCi = BigDecimal.valueOf(35);
            vodOldCi.setConsumableMainBalanceAmount(mainbalanceOldCi);

            VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    TestConstants.CI_EXTERNAL_IDS.WEARABLE);
            BigDecimal mainbalanceWearables = BigDecimal.valueOf(5);
            vodWearable.setConsumableMainBalanceAmount(mainbalanceWearables);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.appendVisibleOfferDetailsMap(
                    vodWearable.getCatalogItemExternalId(),
                    Long.valueOf(vodWearable.getResourceId()), vodWearable);
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            BigDecimal aocAmount = BigDecimal.valueOf(testCase.aocDelta);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchase(
                    request.getNewCatalogItemExternalId(), aocAmount);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            String taxRespString = CommonTestHelper.getTaxApiResp(testCase.newCi);
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ObjectMapper om = TestUtils.getObjectMapper();
                ServiceTaxResponse resp = om.readValue(taxRespString, ServiceTaxResponse.class);
                resp.getTransactionElement().get(0).setTotalFeeAmount(
                        BigDecimal.valueOf(testCase.fixedFee));
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                resp.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());

            assertEquals(
                    response.getNewCatalogItem().getDiscountPrice().subtract(
                            response.getCurrentCatalogItem().getDiscountPrice()).max(
                                    BigDecimal.ZERO).intValue(),
                    response.getChangeCycle().getDelta().intValue(), "Check Delta");
            System.out.println(poEnrolled.toJson());
            BigDecimal remainingdDaysWithToday = BigDecimal.valueOf(
                    CommonUtils.getDaysRemainingInCycle(
                            poiEnrolled.getCycleInfo().getCycleEndTime(),
                            subscriptionResponse.getTimeZone()));

            LocalDate endDate = poiEnrolled.getCycleInfo().getCycleEndTime().getTimestamp().toInstant().atZone(
                    ZoneId.systemDefault()).toLocalDate();
            LocalDate startDate = poiEnrolled.getCycleInfo().getCycleEndTime().getTimestamp().toInstant().atZone(
                    ZoneId.systemDefault()).toLocalDate().minusYears(1);
            BigDecimal daysInYear = BigDecimal.valueOf(ChronoUnit.DAYS.between(startDate, endDate));

            BigDecimal proCoeff = remainingdDaysWithToday.divide(
                    daysInYear, Constants.MATRIXX_CONSTANTS.DECIMAL_PRECISION,
                    RoundingMode.CEILING);

            BigDecimal proratedDiscountPrice = response.getChangeCycle().getDelta().multiply(
                    proCoeff).setScale(
                            Constants.BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION,
                            RoundingMode.CEILING);

            assertEquals(
                    proratedDiscountPrice.doubleValue(),
                    response.getChangeCycle().getAocAmount().doubleValue(), 0.001);

            assertEquals(
                    proratedDiscountPrice.max(BigDecimal.valueOf(testCase.fixedFee)).doubleValue(),
                    response.getChangeCycle().getPayableAmount().doubleValue(), 0.001);
            assertEquals(
                    proratedDiscountPrice.max(BigDecimal.valueOf(testCase.fixedFee)).doubleValue(),
                    response.getChangeCycle().getTotalAmount().doubleValue(), 0.001);

            System.out.println(
                    "**************************End of " + testCase.testNum
                            + "********************************");
        };

        TestConditions tc = new TestConditions();
        double otherPromos = 10;
        tc.vbppEligible = true;
        tc.chimeEligible = true;
        tc.otherPromos = otherPromos;
        tc.fixedFee = 1.81;
        tc.oldCi = TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL;
        tc.newCi = TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL;
        tc.testNum = "#6" + "-AocDelta-" + tc.aocDelta + "-OtherPromos-" + otherPromos;
        pTests.test(tc);
    }

    @Test
    public void test_getChangeServiceAdvice_ChangeCycleOnly_Core2CoreNextCycle_Then_CorrectChangeCycleOutput(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with monthly base offer. PaidCycleStartDate is in past."
        };
        td.when = new String[] {
            "Api is called to change to an offer that starts in next cycle"
        };
        td.then = new String[] {
            "Validate ChangeCycleFields, zero delta"
        };
        AppPropertyProvider.getInstance().setProperty(
                Constants.CREDIT_CONSTANTS.AOC_GRANT_OFFERS, CI_EXTERNAL_IDS.AOC_CORE_ONLY);
        @SuppressWarnings("unchecked")
        OneParameterTest pTests = (tCase) -> {
            String subscriptionExternalId = "123";
            TestConditions testCase = (TestConditions) tCase;
            td.printDescription();
            System.out.println(
                    "**************************Executing " + testCase.testNum
                            + "********************************");

            String randomPastDate = "1900-01-01";

            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setSubscriptionExternalId(subscriptionExternalId);
            request.setNewCatalogItemExternalId(testCase.newCi);
            request.setDiscountPrice(testCase.getNewCiPrice());
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));

            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            String oldCiId = testCase.oldCi;
            BigDecimal oldPrice = testCase.getOldCiPrice();
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCiId);

            VisiblePurchasedOfferExtension enrolledExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            enrolledExtn.setChargeAmount(oldPrice);
            enrolledExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCiId);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(oldCiId, request.getNewCatalogItemExternalId()));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class, TestConstants.DATA_DIR.CHANGE_SERVICE_ADVICE
                            + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtn);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCiId);

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    oldCiId);
            BigDecimal mainbalanceOldCi = BigDecimal.valueOf(35);
            vodOldCi.setConsumableMainBalanceAmount(mainbalanceOldCi);
            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            BigDecimal aocAmount = BigDecimal.ZERO;
            Map<String, BigDecimal> balImpactMap = Map.of(
                    BALANCE_NAMES.GLOBAL_PASS, BigDecimal.ONE);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), aocAmount, null, balImpactMap, true);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            String taxRespString = CommonTestHelper.getTaxApiResp(testCase.newCi);
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ObjectMapper om = TestUtils.getObjectMapper();
                ServiceTaxResponse resp = om.readValue(taxRespString, ServiceTaxResponse.class);
                resp.getTransactionElement().get(0).setTotalFeeAmount(
                        BigDecimal.valueOf(testCase.fixedFee));
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                resp.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertEquals(0, response.getChangeCycle().getDelta().intValue(), "Check Delta");
            assertEquals(
                    testCase.aocDelta, response.getChangeCycle().getAocAmount().doubleValue(),
                    0.001);
            assertEquals(
                    BigDecimal.valueOf(testCase.aocDelta).doubleValue(),
                    response.getChangeCycle().getPayableAmount().doubleValue(), 0.001);
            assertEquals(
                    BigDecimal.valueOf(testCase.aocDelta).doubleValue(),
                    response.getChangeCycle().getTotalAmount().doubleValue(), 0.001);

            System.out.println(
                    "**************************End of " + testCase.testNum
                            + "********************************");
        };
        TestConditions tc = new TestConditions();
        tc.testNum = "#1";
        tc.oldCi = TestConstants.CI_EXTERNAL_IDS.BASE3VIS23;
        tc.newCi = TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL;
        pTests.test(tc);

        tc.testNum = "#2";
        tc.oldCi = TestConstants.CI_EXTERNAL_IDS.PLUS3VIS23;
        tc.newCi = TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL;
        pTests.test(tc);

        tc.testNum = "#3";
        tc.oldCi = TestConstants.CI_EXTERNAL_IDS.BASE3VIS23;
        tc.newCi = TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL;
        pTests.test(tc);

        tc.testNum = "#4";
        tc.oldCi = TestConstants.CI_EXTERNAL_IDS.PLUS3VIS23;
        tc.newCi = TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL;
        pTests.test(tc);

        tc.testNum = "#5";
        tc.oldCi = TestConstants.CI_EXTERNAL_IDS.PLUS3VIS23;
        tc.newCi = TestConstants.CI_EXTERNAL_IDS.BASE3VIS23;
        pTests.test(tc);
    }

    @Test
    public void test_getChangeServiceAdvice_When_PlusAnnualToBaseAnnual_Before_PaidCycleStartDate_Then_NoNextCycle(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has PlusAnnual service."
        };
        td.when = new String[] {
            "Api is called with baseannual offer.",
            " Enrolled PlusAnnual offer's purchase billCycle is in last month.",
            " Today is before PaiCycleStartDate."
        };
        td.then = new String[] {
            "Response has current cycle only."
        };

        String subscriptionExternalId = "123";
        @SuppressWarnings("unchecked")
        TwoParameterTest pTests = (oldCi, newCi) -> {
            td.printDescription();
            MtxDate randomDateInPast = new MtxDate("1900-01-01");
            td.printDescription();
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(newCi.toString());
            BigDecimal newDiscountPrice = CommonTestHelper.getOfferPrice(newCi.toString());
            request.setDiscountPrice(newDiscountPrice);
            request.setGrossPrice(newDiscountPrice);
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getPurchasedOfferArrayAppender().clear();

            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL);
            VisibleOfferDetails vodEnrolled = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL);
            MtxTimestamp tsToday = MtxTimestamp.ofEpochMilli(
                    CommonUtils.getCurrentTimeMillis(),
                    poEnrolled.getCycleInfo().getCycleStartTime());
            MtxTimestamp tsEnd = TestUtils.addDays(tsToday, 27); // ideally get number days in month
                                                                 // work out from there.
            poEnrolled.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
            poEnrolled.getCycleInfo().setCycleEndTime(tsEnd);

            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            poExtn.setPaidCycleStartDate(randomDateInPast);
            subscription.getPurchasedOfferArrayAppender().add(poEnrolled);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(
                    CommonTestHelper.getOfferPrice(TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(randomDateInPast);
            poiEnrolled.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
            poiEnrolled.getCycleInfo().setCycleEndTime(tsEnd);

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(oldCi.toString(), newCi.toString()));

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodEnrolled.getCatalogItemExternalId(),
                    Long.valueOf(vodEnrolled.getResourceId()), vodEnrolled);
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchase(
                    request.getNewCatalogItemExternalId(), BigDecimal.ZERO);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            instance.getChangeServiceAdvice(request, response);

            System.out.println(td.getTestMethod() + ":" + response.toJson());

            assertThat(response.getNextCycle()).isNull();
        };

        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL);
    }

    @Test
    public void test_getChangeServiceAdvice_When_ChangeStartsNextCycle_Then_StartNextBillcycle(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has any monthly or annual offer."
        };
        td.when = new String[] {
            "Api is called with an annual plan."
        };
        td.then = new String[] {
            "ChangeCycle should show EndDate = End of Current BillCycle."
        };
        String subscriptionExternalId = "123";

        TwoParameterTest pTests = (oldCi, newCi) -> {
            td.printDescription();
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(newCi.toString());
            request.setGrossPrice(BigDecimal.valueOf(100));
            BigDecimal newDiscountPrice = BigDecimal.valueOf(30);
            request.setDiscountPrice(newDiscountPrice);
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();
            AppPropertyProvider.getInstance().setProperty(
                    Constants.CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getPurchasedOfferArrayAppender().clear();

            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCi.toString());
            VisibleOfferDetails vodEnrolled = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    oldCi.toString());

            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            poExtn.setPaidCycleStartDate(null);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            MtxTimestamp expectedEndDate = subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime();
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCi.toString());
            if (poiEnrolled.getCycleInfo() != null) {
                poiEnrolled.getCycleInfo().setCycleEndTime(expectedEndDate);
            }
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCi.toString()));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(null);

            emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(oldCi.toString(), request.getNewCatalogItemExternalId()));

            BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
            vodEnrolled.setConsumableMainBalanceAmount(mainbalanceUnlimited);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodEnrolled.getCatalogItemExternalId(),
                    Long.valueOf(vodEnrolled.getResourceId()), vodEnrolled);
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            Map<String, BigDecimal> balImpactMap = Map.of(
                    BALANCE_NAMES.GLOBAL_PASS, BigDecimal.ONE);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ZERO, null, balImpactMap,
                    true);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            instance.getChangeServiceAdvice(request, response);
            System.out.println(td.getTestMethod() + ":" + response.toJson());

            assertEquals(
                    expectedEndDate.longValue(),
                    response.getCurrentCatalogItem().getEndDate().longValue());
        };

        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.BASE3VIS23,
                TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL);
        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.PLUS3VIS23,
                TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL);
        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.BASE3VIS23,
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL);
        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.PLUS3VIS23,
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL);
        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.PLUS3VIS23, TestConstants.CI_EXTERNAL_IDS.BASE3VIS23);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void getChangeServiceAdvice_When_BaseAnnual2PlusAnnual_Subscription_HasLessGiftAsGrant_Then_GiftNotUsedToPayDelta(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber has gift amount.", "Gift amount is less than Delta."
        };
        td.when = new String[] {
            "ChangeAdvice is called."
        };
        td.then = new String[] {
            "ChangeAdvice response should show gift NOT to be used to Delta.",
            "Requirement to use Gift for Delta is never discussed.",
            "As per discussions with Kevin, Gift is meant to buy new annual offer."
        };
        td.testInfo = testInfo;

        OneParameterTest pTests = (tCase) -> {
            td.printDescription();
            String subscriptionExternalId = "123";
            TestConditions testCase = (TestConditions) tCase;
            td.printDescription();
            System.out.println(
                    "**************************Executing " + testCase.testNum
                            + "********************************");

            AppPropertyProvider.getInstance().setProperty(
                    Constants.CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
            MtxDate randomPastDate = new MtxDate("1900-01-01");

            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setSubscriptionExternalId(subscriptionExternalId);
            request.setNewCatalogItemExternalId(testCase.newCi);
            request.setDiscountPrice(testCase.getNewCiPrice());
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));

            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            String oldCiId = testCase.oldCi;
            BigDecimal oldPrice = testCase.getOldCiPrice();

            BigDecimal giftConsumable = BigDecimal.valueOf(0);
            BigDecimal giftGrant = BigDecimal.valueOf(5);
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getPurchasedOfferArrayAppender().clear();

            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCiId);

            VisiblePurchasedOfferExtension enrolledExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            enrolledExtn.setChargeAmount(oldPrice);
            enrolledExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtn.setPaidCycleStartDate(randomPastDate);
            subscription.getPurchasedOfferArrayAppender().add(poEnrolled);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCiId);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(randomPastDate);

            CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, TestConstants.CI_EXTERNAL_IDS.FIRST25_GRANT, null, giftGrant,
                    giftConsumable);

            subscription.getBalanceArrayAppender().clear();
            MtxBalanceInfo biMainBalance = CommonTestHelper.getMtxBalanceInfo(
                    TestConstants.BALANCE_NAMES.MAIN_BALANCE, 1L, 2L, null);
            subscription.getBalanceArrayAppender().add(biMainBalance);

            emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            oldCiId, request.getNewCatalogItemExternalId(),
                            TestConstants.CI_EXTERNAL_IDS.FIRST25_GRANT));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class, TestConstants.DATA_DIR.CHANGE_SERVICE_ADVICE
                            + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtn);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCiId);

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    oldCiId);
            BigDecimal mainbalanceOldCi = BigDecimal.valueOf(35);
            vodOldCi.setConsumableMainBalanceAmount(mainbalanceOldCi);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchase(
                    request.getNewCatalogItemExternalId(), aocAmount);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ObjectMapper om = TestUtils.getObjectMapper();
                ServiceTaxResponse resp = om.readValue(taxRespString, ServiceTaxResponse.class);
                resp.getTransactionElement().get(0).setTotalFeeAmount(
                        BigDecimal.valueOf(testCase.fixedFee));
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                resp.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(testInfo.getDisplayName() + ":" + response.toJson());

            assertEquals(
                    response.getChangeCycle().getAocAmount().doubleValue(),
                    response.getChangeCycle().getPayableAmount().doubleValue(), 0.000001);
            System.out.println(
                    "**************************End of " + testCase.testNum
                            + "********************************");
        };
        TestConditions tc = new TestConditions();
        tc.oldCi = TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL;
        tc.newCi = TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL;
        tc.aocDelta = 150;
        tc.fixedFee = 0;
        tc.testNum = "#6" + "-AocDelta-" + tc.aocDelta;
        pTests.test(tc);
    }

    @Test
    public void test_getChangeServiceAdvice_When_Valid_Offer_Then_Valid_ChangeType(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has base offer."
        };
        td.when = new String[] {
            "Api is called with valid new offer."
        };
        td.then = new String[] {
            "ChangeType is returned in response"
        };

        AppPropertyProvider.getInstance().setProperty(
                Constants.CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        @SuppressWarnings({
            "unchecked"
        })
        TwoParameterTest pTests = (oldOffer, newOffer) -> {
            td.printDescription();
            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            String newCiId = newOffer.toString();
            BigDecimal newPrice = BigDecimal.ZERO;
            BigDecimal oldPrice = BigDecimal.ZERO;
            request.setNewCatalogItemExternalId((String) newCiId);
            request.setGrossPrice(BigDecimal.valueOf(100));
            request.setDiscountPrice((BigDecimal) newPrice);
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            MtxResponseSubscription subscription = null;
            subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poOld = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldOffer.toString());

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));

            MtxTimestamp tsToday = null;
            if (poOld.getCycleInfo() != null) {
                tsToday = MtxTimestamp.ofEpochMilli(
                        CommonUtils.getCurrentTimeMillis(),
                        poOld.getCycleInfo().getCycleStartTime());
            } else {
                tsToday = MtxTimestamp.ofEpochMilli(
                        CommonUtils.getCurrentTimeMillis(),
                        subscriptionResponse.getBillingCycle().getCurrentPeriodStartTime());
            }

            MtxTimestamp tsEnd = TestUtils.addDays(tsToday, 27);
            if (poOld.getCycleInfo() != null) {
                // Annual Plans
                poOld.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
                poOld.getCycleInfo().setCycleEndTime(tsEnd);
            }

            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poOld.getAttr();
            poExtn.setChargeAmount((BigDecimal) oldPrice);
            subscription.getPurchasedOfferArrayAppender().add(poOld);

            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldOffer.toString());
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldOffer.toString()));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            if (poiEnrolled.getCycleInfo() != null) {
                // Annual Plans
                poiEnrolled.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
                poiEnrolled.getCycleInfo().setCycleEndTime(tsEnd);
            }

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(oldOffer.toString(), newOffer.toString()));

            VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    TestConstants.CI_EXTERNAL_IDS.UNLIMITED);
            BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
            vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

            VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    TestConstants.CI_EXTERNAL_IDS.WEARABLE);
            BigDecimal mainbalanceWearables = BigDecimal.valueOf(5);
            vodWearable.setConsumableMainBalanceAmount(mainbalanceWearables);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodUnlimited.getCatalogItemExternalId(),
                    Long.valueOf(vodUnlimited.getResourceId()), vodUnlimited);
            aopStage.appendVisibleOfferDetailsMap(
                    vodWearable.getCatalogItemExternalId(),
                    Long.valueOf(vodWearable.getResourceId()), vodWearable);
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            String expectedChangeType = (String) AppPropertyProvider.getInstance().getProperty(
                    Constants.CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_PREFIX
                            + oldOffer.toString()
                            + Constants.CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_OFFER_SEPARATOR_TO
                            + newCiId);
            Map<String, BigDecimal> balImpactMap = Map.of(
                    BALANCE_NAMES.GLOBAL_PASS, BigDecimal.ONE);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ZERO, null, balImpactMap,
                    true);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            instance.getChangeServiceAdvice(request, response);
            System.out.println(td.getTestMethod() + ":" + response.toJson());

            assertEquals(expectedChangeType, response.getChangeType());
        };

        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.PLUS_CURRENT, TestConstants.CI_EXTERNAL_IDS.BASE_CURRENT);
        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.BASE_CURRENT, TestConstants.CI_EXTERNAL_IDS.PLUS_CURRENT);
        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.BASE3VIS23,
                TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL);
        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.PLUS3VIS23,
                TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL);
        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.BASE3VIS23,
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL);
        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.PLUS3VIS23,
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL);
        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL);
        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL);
    }

    @Test
    public void test_getChangeServiceAdvice_EnrolledInAnnual_ChangeNextCycle_Then_CycleDatesOfCurrentService(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with annual base offer. PaidCycleStartDate is in past."
        };
        td.when = new String[] {
            "Api is called for CoreToCore change that affects next month"
        };
        td.then = new String[] {
            "CurrentBillCycle Dates should be from enrolled offer."
        };

        @SuppressWarnings("unchecked")
        OneParameterTest pTests = (tCase) -> {
            String subscriptionExternalId = "123";
            TestConditions testCase = (TestConditions) tCase;
            td.printDescription();
            System.out.println(
                    "**************************Executing " + testCase.testNum
                            + "********************************");

            AppPropertyProvider.getInstance().setProperty(
                    Constants.CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");// No aoc promos

            String randomPastDate = "1900-01-01";

            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setSubscriptionExternalId(subscriptionExternalId);
            request.setNewCatalogItemExternalId(testCase.newCi);
            request.setDiscountPrice(testCase.getNewCiPrice());
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));

            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            String oldCiId = testCase.oldCi;
            BigDecimal oldPrice = testCase.getOldCiPrice();
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getPurchasedOfferArrayAppender().clear();

            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCiId);
            MtxTimestamp expectedEnd = TestUtils.getFirstDateTimeOfCurrentMonth();
            MtxTimestamp expectedStart = TestUtils.subtractOneYear(expectedEnd);

            if (poEnrolled.getCycleInfo() != null) {
                // So that annual service will be in its last month.
                poEnrolled.getCycleInfo().setCycleStartTime(expectedStart);
                poEnrolled.getCycleInfo().setCycleEndTime(expectedEnd);
            }

            VisiblePurchasedOfferExtension enrolledExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            enrolledExtn.setChargeAmount(oldPrice);
            enrolledExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCiId);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));
            if (poiEnrolled.getCycleInfo() != null) {
                // So that annual service will be in its last month.
                poiEnrolled.getCycleInfo().setCycleStartTime(expectedStart);
                poiEnrolled.getCycleInfo().setCycleEndTime(expectedEnd);
            }

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(oldCiId, request.getNewCatalogItemExternalId()));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class, TestConstants.DATA_DIR.CHANGE_SERVICE_ADVICE
                            + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtn);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCiId);

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    oldCiId);
            BigDecimal mainbalanceOldCi = BigDecimal.valueOf(35);
            vodOldCi.setConsumableMainBalanceAmount(mainbalanceOldCi);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            Map<String, BigDecimal> balImpactMap = Map.of(
                    BALANCE_NAMES.GLOBAL_PASS, BigDecimal.ONE);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ZERO, null, balImpactMap,
                    true);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ObjectMapper om = TestUtils.getObjectMapper();
                ServiceTaxResponse resp = om.readValue(taxRespString, ServiceTaxResponse.class);
                resp.getTransactionElement().get(0).setTotalFeeAmount(
                        BigDecimal.valueOf(testCase.fixedFee));
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                resp.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            System.out.println(expectedStart);
            System.out.println(response.getChangeCycle().getCycleStartTime());
            assertEquals(
                    expectedStart.longValue(),
                    response.getChangeCycle().getCycleStartTime().longValue(),
                    "Cycle Start Time should be from Old offer");
            assertEquals(
                    expectedEnd.longValue(),
                    response.getChangeCycle().getCycleEndTime().longValue(),
                    "Cycle End Time should be from old offer");
            System.out.println(
                    "**************************End of " + testCase.testNum
                            + "********************************");
        };

        TestConditions tc = new TestConditions();
        SimpleEntry<String, String> change1 = new SimpleEntry<>(
                CI_EXTERNAL_IDS.BASE3ANNUAL, CI_EXTERNAL_IDS.BASE3VIS23);
        SimpleEntry<String, String> change2 = new SimpleEntry<>(
                CI_EXTERNAL_IDS.BASE3ANNUAL, CI_EXTERNAL_IDS.PLUS3VIS23);
        SimpleEntry<String, String> change3 = new SimpleEntry<>(
                CI_EXTERNAL_IDS.PLUS3ANNUAL, CI_EXTERNAL_IDS.BASE3VIS23);
        SimpleEntry<String, String> change4 = new SimpleEntry<>(
                CI_EXTERNAL_IDS.PLUS3ANNUAL, CI_EXTERNAL_IDS.PLUS3VIS23);
        SimpleEntry<String, String> change5 = new SimpleEntry<>(
                CI_EXTERNAL_IDS.PLUS3ANNUAL, CI_EXTERNAL_IDS.BASE3ANNUAL);
        List<SimpleEntry<String, String>> changes = List.of(
                change1, change2, change3, change4, change5);

        for (SimpleEntry<String, String> change : changes) {
            tc.oldCi = change.getKey();
            tc.newCi = change.getValue();
            tc.testNum = "#" + "oldCi:" + tc.oldCi + "-" + "newCi:" + tc.newCi;
            pTests.test(tc);
        }
    }

    @Test
    @SuppressWarnings("unchecked")
    public void test_getChangeServiceAdvice_When_AnnualToMonthly_After_PaidCycleStartDate_Then_NextCycle(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has Annual service."
        };
        td.when = new String[] {
            "Api is called with new monthly offer.",
            " Enrolled Annual offers purchase billCycle is in last month.",
            " Today is after PaiCycleStartDate."
        };
        td.then = new String[] {
            "Response has current cycle and next cycle."
        };
        AppPropertyProvider.getInstance().setProperty(
                Constants.CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        String subscriptionExternalId = "123";
        TwoParameterTest pTests = (oldCi, newCi) -> {
            td.printDescription();
            MtxDate randomDateInFuture = new MtxDate("4712-12-31");
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(newCi.toString());
            BigDecimal newDiscountPrice = CommonTestHelper.getOfferPrice(newCi.toString());
            request.setDiscountPrice(newDiscountPrice);
            request.setGrossPrice(newDiscountPrice);
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getPurchasedOfferArrayAppender().clear();

            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCi.toString());
            VisibleOfferDetails vodEnrolled = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    oldCi.toString());

            MtxTimestamp tsToday = MtxTimestamp.ofEpochMilli(
                    CommonUtils.getCurrentTimeMillis(),
                    poEnrolled.getCycleInfo().getCycleStartTime());
            MtxTimestamp tsEnd = TestUtils.addDays(tsToday, 27); // ideally get number days in month
                                                                 // work out from there.
            poEnrolled.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
            poEnrolled.getCycleInfo().setCycleEndTime(tsEnd);

            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            poExtn.setPaidCycleStartDate(randomDateInFuture);
            subscription.getPurchasedOfferArrayAppender().add(poEnrolled);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCi.toString());
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCi.toString()));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(randomDateInFuture);
            poiEnrolled.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
            poiEnrolled.getCycleInfo().setCycleEndTime(tsEnd);

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(oldCi.toString(), newCi.toString()));

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodEnrolled.getCatalogItemExternalId(),
                    Long.valueOf(vodEnrolled.getResourceId()), vodEnrolled);
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            Map<String, BigDecimal> balImpactMap = Map.of(
                    BALANCE_NAMES.GLOBAL_PASS, BigDecimal.ONE);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ZERO, null, balImpactMap,
                    true);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            instance.getChangeServiceAdvice(request, response);
            System.out.println(td.getTestMethod() + ":" + response.toJson());

            assertThat(response.getNextCycle()).isNotNull();
        };
        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.BASE3VIS23);
        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.PLUS3VIS23);
        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.BASE3VIS23);
        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.PLUS3VIS23);
    }

    @Test
    public void test_getChangeServiceAdvice_CoreToCore_OldOfferHasNoCycleInfo_Then_CycleDatesFromOldOffer(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with annual base offer. PaidCycleStartDate is in past. Enrolled offer does not have cycle info."
        };
        td.when = new String[] {
            "Api is called for CoreToCore change that affects immidiately"
        };
        td.then = new String[] {
            "CurrentBillCycle Start Date should be from wallet bill cycle."
        };

        @SuppressWarnings("unchecked")
        OneParameterTest pTests = (tCase) -> {
            String subscriptionExternalId = "123";
            TestConditions testCase = (TestConditions) tCase;
            td.printDescription();
            System.out.println(
                    "**************************Executing " + testCase.testNum
                            + "********************************");

            AppPropertyProvider.getInstance().setProperty(
                    Constants.CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            String randomPastDate = "1900-01-01";

            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setSubscriptionExternalId(subscriptionExternalId);
            request.setNewCatalogItemExternalId(testCase.newCi);
            request.setDiscountPrice(testCase.getNewCiPrice());
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));

            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            String oldCiId = testCase.oldCi;
            BigDecimal oldPrice = testCase.getOldCiPrice();
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getPurchasedOfferArrayAppender().clear();

            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCiId);
            poEnrolled.setCycleInfo((MtxPurchasedOfferInfo) null);

            VisiblePurchasedOfferExtension enrolledExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            enrolledExtn.setChargeAmount(oldPrice);
            enrolledExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCiId);
            MtxTimestamp walletCycleStartTime = subscriptionResponse.getBillingCycle().getCurrentPeriodStartTime();
            MtxTimestamp walletCycleEndTime = subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime();
            if (poiEnrolled.getCycleInfo() != null) {
                poiEnrolled.getCycleInfo().setCycleEndTime(walletCycleEndTime);
            }
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(oldCiId, request.getNewCatalogItemExternalId()));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class, TestConstants.DATA_DIR.CHANGE_SERVICE_ADVICE
                            + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtn);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCiId);

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    oldCiId);
            BigDecimal mainbalanceOldCi = BigDecimal.valueOf(35);
            vodOldCi.setConsumableMainBalanceAmount(mainbalanceOldCi);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            Map<String, BigDecimal> balImpactMap = Map.of(
                    BALANCE_NAMES.GLOBAL_PASS, BigDecimal.ONE);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ZERO, null, balImpactMap,
                    true);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ObjectMapper om = TestUtils.getObjectMapper();
                ServiceTaxResponse resp = om.readValue(taxRespString, ServiceTaxResponse.class);
                resp.getTransactionElement().get(0).setTotalFeeAmount(
                        BigDecimal.valueOf(testCase.fixedFee));
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                resp.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertEquals(
                    walletCycleStartTime.longValue(),
                    response.getChangeCycle().getCycleStartTime().longValue(),
                    "Cycle Start Time should be from Billing Cycle");
            assertEquals(
                    walletCycleEndTime.longValue(),
                    response.getChangeCycle().getCycleEndTime().longValue(),
                    "Cycle End Time should be from Billing Cycle");
            assertEquals(
                    walletCycleEndTime.longValue(),
                    response.getCurrentCatalogItem().getEndDate().longValue(),
                    "Current Catalog Item should End be from Billing Cycle");
            assertEquals(
                    walletCycleEndTime.longValue(),
                    response.getNewCatalogItem().getStartDate().longValue(),
                    "New Catalog Item should start be from Billing Cycle");

            System.out.println(
                    "**************************End of " + testCase.testNum
                            + "********************************");
        };

        TestConditions tc = new TestConditions();
        SimpleEntry<String, String> change1 = new SimpleEntry<>(
                CI_EXTERNAL_IDS.BASE3VIS23, CI_EXTERNAL_IDS.PLUS3ANNUAL);
        SimpleEntry<String, String> change2 = new SimpleEntry<>(
                CI_EXTERNAL_IDS.BASE3VIS23, CI_EXTERNAL_IDS.BASE3ANNUAL);
        SimpleEntry<String, String> change3 = new SimpleEntry<>(
                CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.PLUS3ANNUAL);
        SimpleEntry<String, String> change4 = new SimpleEntry<>(
                CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.BASE3ANNUAL);
        SimpleEntry<String, String> change5 = new SimpleEntry<>(
                CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT);
        List<SimpleEntry<String, String>> changes = List.of(
                change1, change2, change3, change4, change5);

        for (SimpleEntry<String, String> change : changes) {
            tc.oldCi = change.getKey();
            tc.newCi = change.getValue();
            tc.testNum = "#" + "oldCi:" + tc.oldCi + "-" + "newCi:" + tc.newCi;
            pTests.test(tc);
        }
    }

    @Test
    @SuppressWarnings("unchecked")
    public void test_getChangeServiceAdvice_When_AnnualToMonthly_Before_PaidCycleStartDate_Then_NoNextCycle(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has Annual service."
        };
        td.when = new String[] {
            "Api is called with new monthly offer.",
            " Enrolled Annual offers purchase billCycle is in last month.",
            " Today is before PaiCycleStartDate."
        };
        td.then = new String[] {
            "Response has current cycle only."
        };
        AppPropertyProvider.getInstance().setProperty(
                Constants.CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        String subscriptionExternalId = "123";
        TwoParameterTest pTests = (oldCi, newCi) -> {
            td.printDescription();
            MtxDate randomDateInPast = new MtxDate("1900-01-01");
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(newCi.toString());
            BigDecimal newDiscountPrice = CommonTestHelper.getOfferPrice(newCi.toString());
            request.setDiscountPrice(newDiscountPrice);
            request.setGrossPrice(newDiscountPrice);
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getPurchasedOfferArrayAppender().clear();

            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCi.toString());
            VisibleOfferDetails vodEnrolled = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    oldCi.toString());

            MtxTimestamp tsToday = MtxTimestamp.ofEpochMilli(
                    CommonUtils.getCurrentTimeMillis(),
                    poEnrolled.getCycleInfo().getCycleStartTime());
            MtxTimestamp tsEnd = TestUtils.addDays(tsToday, 27);// ideally get number days in month
                                                                // work out from there.
            poEnrolled.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
            poEnrolled.getCycleInfo().setCycleEndTime(tsEnd);

            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            poExtn.setPaidCycleStartDate(randomDateInPast);
            subscription.getPurchasedOfferArrayAppender().add(poEnrolled);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCi.toString());
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCi.toString()));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(randomDateInPast);
            poiEnrolled.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
            poiEnrolled.getCycleInfo().setCycleEndTime(tsEnd);

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(oldCi.toString(), newCi.toString()));

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodEnrolled.getCatalogItemExternalId(),
                    Long.valueOf(vodEnrolled.getResourceId()), vodEnrolled);
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            Map<String, BigDecimal> balImpactMap = Map.of(
                    BALANCE_NAMES.GLOBAL_PASS, BigDecimal.ONE);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ZERO, null, balImpactMap,
                    true);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            instance.getChangeServiceAdvice(request, response);
            System.out.println(td.getTestMethod() + ":" + response.toJson());

            assertThat(response.getNextCycle()).isNull();
        };
        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.BASE3VIS23);
        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.PLUS3VIS23);
        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.BASE3VIS23);
        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.PLUS3VIS23);
    }

    @Test
    @SuppressWarnings("unchecked")
    @Disabled("AnnualPlans 23 do not have any gift. Ignore test till gift promo is available.")
    public void getChangeServiceAdvice_When_BaseAnnual2PlusAnnual_Subscription_HasGiftAsGrant_NextCycleAlso_Then_GiftUsedToPayNextCycle(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "PaidCycleStartDate is in future.", "Subscriber has gift amount.",
            "Subscribers tax geocode is subject to fixed fee.",
            "Gift amount is more than fixedfee.", "Gift amount equals to new offer price."
        };
        td.when = new String[] {
            "ChangeAdvice is called. Taxapi provides fixedfee."
        };
        td.then = new String[] {
            "ChangeAdvice response should show NO payable amount in NEXTCYCLE."
        };
        td.testInfo = testInfo;

        OneParameterTest pTests = (tCase) -> {
            String subscriptionExternalId = "123";
            TestConditions testCase = (TestConditions) tCase;
            System.out.println(
                    "**************************Executing " + testCase.testNum
                            + "********************************");
            td.printDescription();
            String randomFutureDate = "4712-12-31";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setSubscriptionExternalId(subscriptionExternalId);
            request.setNewCatalogItemExternalId(testCase.newCi);
            request.setDiscountPrice(testCase.getNewCiPrice());
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            String oldCiId = testCase.oldCi;
            BigDecimal oldPrice = testCase.getOldCiPrice();

            AppPropertyProvider.getInstance().setProperty(
                    Constants.CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
            BigDecimal giftConsumable = BigDecimal.valueOf(0);
            BigDecimal giftGrant = TestConstants.OFFER_PRICES.PLUS2ANNUAL; // Make gift equal to
                                                                           // price of new offer
            BigDecimal giftAmount = giftGrant.add(giftConsumable);

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getBalanceArrayAppender().clear();
            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCiId);
            if (poEnrolled.getCycleInfo() != null) {
                // So that annual service will be in its last month.
                poEnrolled.getCycleInfo().setCycleEndTime(
                        TestUtils.getLastDateTimeOfCurrentMonth());
            }

            MtxBalanceInfo biMainBalance = CommonTestHelper.getMtxBalanceInfo(
                    TestConstants.BALANCE_NAMES.MAIN_BALANCE, 1L, 2L, null);
            subscription.getBalanceArrayAppender().add(biMainBalance);

            emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            oldCiId, request.getNewCatalogItemExternalId(),
                            TestConstants.CI_EXTERNAL_IDS.GIFT_GRANT));

            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            enrolledExtnSub.setChargeAmount(oldPrice);
            enrolledExtnSub.setPaidCycleStartDate(new MtxDate(randomFutureDate));
            enrolledExtnSub.getCreditTaxDetailsArrayAppender().clear();

            CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, TestConstants.CI_EXTERNAL_IDS.GIFT_GRANT, null, giftGrant,
                    giftConsumable);

            BigDecimal mainbalance = BigDecimal.ZERO;
            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class, TestConstants.DATA_DIR.CHANGE_SERVICE_ADVICE
                            + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(oldPrice);
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(new MtxDate(randomFutureDate));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCiId);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomFutureDate));

            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCiId);

            List<String> balPriList = Arrays.asList(TestConstants.BALANCE_NAMES.GIFT_GRANT);
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    oldCiId);
            BigDecimal mainbalanceOldCi = BigDecimal.valueOf(35);
            vodOldCi.setConsumableMainBalanceAmount(mainbalanceOldCi);

            BigDecimal mainbalanceBase = BigDecimal.ZERO;
            vodOldCi.setConsumableMainBalanceAmount(mainbalanceBase);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ObjectMapper om = TestUtils.getObjectMapper();
                ServiceTaxResponse resp = om.readValue(taxRespString, ServiceTaxResponse.class);
                resp.getTransactionElement().get(0).setTotalFeeAmount(BigDecimal.ZERO);
                String deltaNoFixedFee = resp.toJson();

                resp.getTransactionElement().get(0).setTotalFeeAmount(
                        BigDecimal.valueOf(testCase.fixedFee));
                String nextCycleWithFixedFee = resp.toJson();

                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                deltaNoFixedFee).thenReturn(nextCycleWithFixedFee);
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(testInfo.getDisplayName() + ":" + response.toJson());

            System.out.println(
                    "**************************Asserting " + testCase.testNum
                            + "********************************");

            assertEquals(0.0, response.getNextCycle().getPayableAmount().doubleValue(), 0.001);
            assertEquals(
                    giftAmount.doubleValue(),
                    response.getNextCycle().getAtCredits(0).getRedeemableCredits().doubleValue(),
                    0.001);

            System.out.println(
                    "**************************End of " + testCase.testNum
                            + "********************************");
        };

        TestConditions tc = new TestConditions();
        SimpleEntry<String, String> change1 = new SimpleEntry<>(
                CI_EXTERNAL_IDS.BASE3ANNUAL, CI_EXTERNAL_IDS.PLUS3ANNUAL);
        List<SimpleEntry<String, String>> changes = List.of(change1);

        double[] aocScale = {
            0.5
        };

        for (SimpleEntry<String, String> change : changes) {
            for (double scale : aocScale) {
                tc.oldCi = change.getKey();
                tc.newCi = change.getValue();
                double delta = tc.getNewCiPrice().subtract(tc.getOldCiPrice()).doubleValue();
                tc.fixedFee = 15;
                tc.minimumCharge = 0;

                tc.aocDelta = delta > 0 ? delta * scale + 0.33 : 0.0;

                String title = "-AocDelta-" + tc.aocDelta;
                tc.testNum = "#1" + title;
                tc.vbppEligible = false;
                tc.chimeEligible = true;
                pTests.test(tc);
            }
        }
    }

    @Test
    public void test_getChangeServiceAdvice_BaseAnnual2PlusAnnual_Then_CycleDatesOfNewOffer(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with BaseAannual. PaidCycleStartDate is in past."
        };
        td.when = new String[] {
            "Api is called for BaseAnnual2PlusAnnual change"
        };
        td.then = new String[] {
            "Cycle should start today. EndDate should be same as end date of old service."
        };

        @SuppressWarnings("unchecked")
        OneParameterTest pTests = (tCase) -> {
            String subscriptionExternalId = "123";
            TestConditions testCase = (TestConditions) tCase;
            td.printDescription();
            System.out.println(
                    "**************************Executing " + testCase.testNum
                            + "********************************");

            AppPropertyProvider.getInstance().setProperty(
                    Constants.CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");// No aoc promos

            String randomPastDate = "1900-01-01";

            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setSubscriptionExternalId(subscriptionExternalId);
            request.setNewCatalogItemExternalId(testCase.newCi);
            request.setDiscountPrice(testCase.getNewCiPrice());
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));

            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            String oldCiId = testCase.oldCi;
            BigDecimal oldPrice = testCase.getOldCiPrice();

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscriptionExternalId));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCiId);
            
            System.out.println(subscriptionResponse.toJson());
            
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getPurchasedOfferArrayAppender().clear();
            subscription.setTimeZone(subscriptionResponse.getTimeZone());
            
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCiId);

            VisiblePurchasedOfferExtension enrolledExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            enrolledExtn.setChargeAmount(oldPrice);
            enrolledExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));
            subscription.getPurchasedOfferArrayAppender().add(poEnrolled);

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(oldCiId, request.getNewCatalogItemExternalId()));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class, TestConstants.DATA_DIR.CHANGE_SERVICE_ADVICE
                            + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtn);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCiId);

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    oldCiId);
            BigDecimal mainbalanceOldCi = BigDecimal.valueOf(35);
            vodOldCi.setConsumableMainBalanceAmount(mainbalanceOldCi);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchase(
                    request.getNewCatalogItemExternalId(), aocAmount);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ObjectMapper om = TestUtils.getObjectMapper();
                ServiceTaxResponse resp = om.readValue(taxRespString, ServiceTaxResponse.class);
                resp.getTransactionElement().get(0).setTotalFeeAmount(
                        BigDecimal.valueOf(testCase.fixedFee));
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                resp.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            // "Cycle Start Time should be today",
            assertEquals(
                    CommonUtils.getMtxTimestampTodayZeroHours(
                            poiEnrolled.getCycleInfo().getCycleStartTime(),
                            subscriptionResponse.getTimeZone()).getTime(),
                    response.getChangeCycle().getCycleStartTime().getTime(),
                    "Cycle Start Time should be today");
            assertEquals(
                    poiEnrolled.getCycleInfo().getCycleEndTime().longValue(),
                    response.getChangeCycle().getCycleEndTime().longValue(),
                    "Cycle End Time should be from Current Service");
            System.out.println(
                    "**************************End of " + testCase.testNum
                            + "********************************");
        };

        TestConditions tc = new TestConditions();
        SimpleEntry<String, String> change1 = new SimpleEntry<>(
                CI_EXTERNAL_IDS.BASE3ANNUAL, CI_EXTERNAL_IDS.PLUS3ANNUAL);
        List<SimpleEntry<String, String>> changes = List.of(change1);

        for (SimpleEntry<String, String> change : changes) {
            tc.oldCi = change.getKey();
            tc.newCi = change.getValue();
            tc.testNum = "#" + "oldCi:" + tc.oldCi + "-" + "newCi:" + tc.newCi;
            pTests.test(tc);
        }
    }

    @Test
    @SuppressWarnings("unchecked")
    public void test_getChangeServiceAdvice_When_PlusAnnualToBaseAnnual_Before_Last_Month_Then_Exception(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has PlusAnnual service."
        };
        td.when = new String[] {
            "Api is called with BaseAnnual offer. Enrolled PlusAnnual offers purchase billCycle has more than a month left."
        };
        td.then = new String[] {
            "Throw Exception"
        };

        String subscriptionExternalId = "123";
        TwoParameterTest pTests = (oldCi, newCi) -> {
            td.printDescription();
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(newCi.toString());
            BigDecimal newDiscountPrice = CommonTestHelper.getOfferPrice(newCi.toString());
            request.setDiscountPrice(newDiscountPrice);
            request.setGrossPrice(newDiscountPrice);
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCi.toString());
            VisibleOfferDetails vodEnrolled = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    oldCi.toString());

            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            poExtn.setPaidCycleStartDate(null);
            subscription.getPurchasedOfferArrayAppender().add(poEnrolled);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCi.toString());
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCi.toString()));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(oldCi.toString(), newCi.toString()));

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscription, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodEnrolled.getCatalogItemExternalId(),
                    Long.valueOf(vodEnrolled.getResourceId()), vodEnrolled);

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            Exception exception = assertThrows(
                    InvalidRequestException.class,
                    () -> instance.getChangeServiceAdvice(request, response));
            System.out.println(td.getTestMethod() + ":");
            exception.printStackTrace();
            assertThat(exception.getMessage()).contains(Constants.LOG_MESSAGES.NO_CHANGE_NOW);
            assertThat(exception.getMessage()).contains(Constants.LOG_MESSAGES.TRY_AFTER);
        };

        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL);
    }

    @Test
    public void test_getChangeServiceAdvice_When_AnnualToMonthly_Before_Last_Month_Then_Exception(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has Annual service."
        };
        td.when = new String[] {
            "Api is called with new monthly offer. Enrolled Annual offers purchase billCycle has more than a month left."
        };
        td.then = new String[] {
            "Throw Exception"
        };

        String subscriptionExternalId = "123";
        TwoParameterTest pTests = (oldCi, newCi) -> {
            td.printDescription();
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(newCi.toString());
            BigDecimal newDiscountPrice = CommonTestHelper.getOfferPrice(newCi.toString());
            request.setDiscountPrice(newDiscountPrice);
            request.setGrossPrice(newDiscountPrice);
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCi.toString());
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            poExtn.setPaidCycleStartDate(null);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCi.toString());
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCi.toString()));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(oldCi.toString(), newCi.toString()));

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");
            MtxPurchasedOfferInfo poiGoodwill = CommonTestHelper.loadJsonMessage(
                    MtxPurchasedOfferInfo.class, DATA_DIR.CHANGE_SERVICE
                            + "MtxPurchasedOfferInfo_Visible_Redeem_Goodwill_Credits.json");
            poiGoodwill.setResourceId(55L);

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            Exception exception = assertThrows(
                    InvalidRequestException.class,
                    () -> instance.getChangeServiceAdvice(request, response));
            System.out.println(td.getTestMethod() + ":");
            exception.printStackTrace();
            assertThat(exception.getMessage()).contains(Constants.LOG_MESSAGES.NO_CHANGE_NOW);
            assertThat(exception.getMessage()).contains(Constants.LOG_MESSAGES.TRY_AFTER);
        };
        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.BASE3VIS23);
        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.BASE3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.PLUS3VIS23);
        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.BASE3VIS23);
        pTests.test(
                TestConstants.CI_EXTERNAL_IDS.PLUS3ANNUAL,
                TestConstants.CI_EXTERNAL_IDS.PLUS3VIS23);
    }

    @Test
    @Tag("VER-480")
    public void test_getChangeServiceAdvice_When_DeltaCreditsAvailableAsGrant_Then_ResponseHasDeltaCredits(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service.", "Referral Credits available",
        };
        td.when = new String[] {
            "Api is called for annual upgrade.", "Change delta is eligible for referral credits."
        };
        td.then = new String[] {
            "Advice should show referral credits in change cycle."
        };
        td.comments = new String[] {
            "VER-480"
        };
        @SuppressWarnings("unchecked")
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            String promoGrantOffer = tCase.promoMap.get("GRANT_CI").toString();
            BigDecimal promoGrantAmount = (BigDecimal) tCase.promoMap.get("GRANT_AMOUNT");

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(
                            tCase.oldCi, request.getNewCatalogItemExternalId(), promoGrantOffer));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            if (tCase.paidCycleStartDate != null) {
                poExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            }
            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                            promoGrantOffer, promoGrantAmount));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchase(
                    request.getNewCatalogItemExternalId(), aocAmount);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            assertFalse(response.getChangeCycle().getCredits().isEmpty());
            assertEquals(
                    response.getChangeCycle().getAocAmount().subtract(
                            response.getChangeCycle().getAtCredits(
                                    0).getRedeemableCredits()).doubleValue(),
                    response.getChangeCycle().getPayableAmount().doubleValue(), 0.001);
        };

        String subscriptionExternalId = "123";

        VisibleDeltaPromo csp = new VisibleDeltaPromo();
        csp.setClassCode(TAX_CLASS_CODES.REF20);
        csp.setDeltaPromotionLimit(BigDecimal.valueOf(40));

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3ANNUAL));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId(subscriptionExternalId);
        requestUp.appendDeltaPromotionList(csp);

        TestConditions chgUp = new TestConditions() {

            {
                newCi = requestUp.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE3ANNUAL;
                paidCycleStartDate = TestUtils.getFirstDateOfCurrentMonth();
            }
        };
        chgUp.promoMap.put("GRANT_CI", CI_EXTERNAL_IDS.REF20_GRANT);
        chgUp.promoMap.put("GRANT_AMOUNT", BigDecimal.valueOf(150));
        pTests.test(requestUp, chgUp);
    }

    @Test
    @Tag("VER-480")
    public void test_getChangeServiceAdvice_When_MultipleDeltaCreditsAsGrant_Then_ResponseHasDeltaCredits(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service.", "Referral Credits available as Delta Credit",
            "Goodwill Credits availableas Delta Credit"
        };
        td.when = new String[] {
            "Api is called for annual upgrade."
        };
        td.then = new String[] {
            "Advice should show referral & Goodwill credits in change cycle."
        };
        td.comments = new String[] {
            "VER-480"
        };
        @SuppressWarnings("unchecked")
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            String promoGrantOffer_1 = tCase.promoMap.get("GRANT_CI_1").toString();
            BigDecimal promoGrantAmount_1 = (BigDecimal) tCase.promoMap.get("GRANT_AMOUNT_1");
            String promoGrantOffer_2 = tCase.promoMap.get("GRANT_CI_2").toString();
            BigDecimal promoGrantAmount_2 = (BigDecimal) tCase.promoMap.get("GRANT_AMOUNT_2");

            Map<String, MtxResponsePricingCatalogItem> pricingMap = emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            tCase.oldCi, request.getNewCatalogItemExternalId(), promoGrantOffer_1,
                            promoGrantOffer_2));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            if (tCase.paidCycleStartDate != null) {
                poExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            }
            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                            promoGrantOffer_1, promoGrantAmount_1));
            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                            promoGrantOffer_2, promoGrantAmount_2));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchase(
                    request.getNewCatalogItemExternalId(), aocAmount);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            assertFalse(response.getChangeCycle().getCredits().isEmpty());
            boolean promo1Present = false;
            boolean promo2Present = false;
            VisibleTemplate vt1 = (VisibleTemplate) pricingMap.get(
                    promoGrantOffer_1).getCatalogItemInfo().getTemplateAttr();
            VisibleTemplate vt2 = (VisibleTemplate) pricingMap.get(
                    promoGrantOffer_2).getCatalogItemInfo().getTemplateAttr();
            for (VisibleCredits vc : response.getChangeCycle().getCredits()) {
                if (vt1.getRedeemOffer().equalsIgnoreCase(vc.getCreditRedeemableOfferCI())) {
                    promo1Present = true;
                }
                if (vt2.getRedeemOffer().equalsIgnoreCase(vc.getCreditRedeemableOfferCI())) {
                    promo2Present = true;
                }
            }
            assertTrue(promo1Present);
            assertTrue(promo2Present);
        };

        String subscriptionExternalId = "123";

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3ANNUAL));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId(subscriptionExternalId);

        VisibleDeltaPromo csp1 = new VisibleDeltaPromo();
        csp1.setClassCode(TAX_CLASS_CODES.REF20);
        csp1.setDeltaPromotionLimit(BigDecimal.valueOf(40));
        requestUp.appendDeltaPromotionList(csp1);

        VisibleDeltaPromo csp2 = new VisibleDeltaPromo();
        csp2.setClassCode(TAX_CLASS_CODES.GOODWILL);
        csp2.setDeltaPromotionLimit(BigDecimal.valueOf(50));
        requestUp.appendDeltaPromotionList(csp2);

        TestConditions chgUp = new TestConditions() {

            {
                newCi = requestUp.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE3ANNUAL;
                paidCycleStartDate = TestUtils.getFirstDateOfCurrentMonth();
            }
        };
        chgUp.promoMap.put("GRANT_CI_1", CI_EXTERNAL_IDS.REF20_GRANT);
        chgUp.promoMap.put("GRANT_AMOUNT_1", BigDecimal.valueOf(150));
        chgUp.promoMap.put("GRANT_CI_2", CI_EXTERNAL_IDS.GRANT_GOODWILL);
        chgUp.promoMap.put("GRANT_AMOUNT_2", BigDecimal.valueOf(100));
        pTests.test(requestUp, chgUp);
    }

    @Test
    @Tags({
        @Tag("VER-448"), @Tag("VER-535"), @Tag("addon")
    })
    public void test_getChangeServiceAdvice_When_AddItems_Then_AoP_Has_NewItems(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service.", "Service could be BASE3VISIBLE23A"
        };
        td.when = new String[] {
            "Change to PLUS3VIS23WB", "New addons to be added.",
            "Addon could be CD2VISIBLE2023 or CD2VISIBLE2023A.", "IncludePaymentAdvice = Y",
        };
        td.then = new String[] {
            "Advice shows PaymentAdvice with new addon."
        };

        @SuppressWarnings("unchecked")
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            List<String> pciList = new ArrayList<String>();
            request.setDiscountPrice(
                    CommonTestHelper.getOfferPrice(request.getNewCatalogItemExternalId()));
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
            BigDecimal expectedRecharge = request.getDiscountPrice();
            for (String offerName : tCase.addOfferList) {
                VisibleChangeServiceAddItem csai = new VisibleChangeServiceAddItem();
                csai.setCatalogItemExternalId(offerName);
                csai.setDiscountPrice(
                        CommonTestHelper.getOfferPrice(csai.getCatalogItemExternalId()));
                csai.setGrossPrice(csai.getDiscountPrice().add(BigDecimal.TEN));
                request.getAddItemsAppender().add(csai);
                pciList.add(offerName);
                expectedRecharge = expectedRecharge.add(csai.getDiscountPrice());
            }
            ;
            pciList.add(tCase.oldCi);
            pciList.add(request.getNewCatalogItemExternalId());

            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            emulateMtxResponsePricingCatalogItems(instance, pciList);

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            System.out.println(
                    td.getTestMethod() + ":" + subscriptionResponse.getBillingCycle().toJson());
            subscriptionResponse.getBillingCycle().setCurrentPeriodStartTime(
                    TestUtils.getLastDateTimeOfLastMonth(subscriptionResponse.getTimeZone()));
            subscriptionResponse.getBillingCycle().setCurrentPeriodEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth(subscriptionResponse.getTimeZone()));
            subscriptionResponse.getBillingCycle().setDateOffset(31L);
            System.out.println(
                    td.getTestMethod() + ":" + subscriptionResponse.getBillingCycle().toJson());
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());
            // emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    tCase.addOfferList.get(0), BigDecimal.ZERO, null);
            purResponseBase.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).setCycleStartTime(
                            subscriptionResponse.getBillingCycle().getCurrentPeriodStartTime());
            purResponseBase.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).setCycleEndTime(
                            subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime());
            doReturn(purResponseBase).when(instance).getAocCurrencyBalanceImpactInfo(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    tCase.addOfferList.get(0))),
                    any(), any());

            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchase(
                    request.getNewCatalogItemExternalId(), aocAmount);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());
            System.out.println(
                    td.getTestMethod() + ":" + aopStage.getRecurringChargeInfo().toJson());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            List<String> actualOfferList = new ArrayList<String>();
            for (VisibleOfferDetails vod : response.getNextCyclePaymentAdvice().getVisibleOfferDetailsList()) {
                actualOfferList.add(vod.getCatalogItemExternalId());
            }
            assertTrue(response.getNextCyclePaymentAdvice() != null);
            assertTrue(
                    actualOfferList.contains(request.getAtAddItems(0).getCatalogItemExternalId()));
        };

        String subscriptionExternalId = "123";

        VisibleRequestChangeServiceAdvice request01 = new VisibleRequestChangeServiceAdvice();
        request01.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        request01.setSubscriptionExternalId(subscriptionExternalId);
        request01.setIncludePaymentAdvice("Y");
        TestConditions tc01 = new TestConditions() {

            {
                newCi = request01.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE3ANNUAL;
            }
        };
        tc01.addOfferList.add(CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION);
        pTests.test(request01, tc01);

        VisibleRequestChangeServiceAdvice request02 = new VisibleRequestChangeServiceAdvice();
        request02.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        request02.setSubscriptionExternalId(subscriptionExternalId);
        request02.setIncludePaymentAdvice("Y");
        TestConditions tc02 = new TestConditions() {

            {
                newCi = request02.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE3ANNUAL;
            }
        };
        tc02.addOfferList.add(CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023);
        pTests.test(request02, tc02);
    }

    @Test
    @Tags({
        @Tag("MTXVER2TMA-4569"), @Tag("addon")
    })
    public void test_getChangeServiceAdvice_When_AddItems_DateOffset31_Then_AoP_AddonDates_Shoulld_Be_Correct(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service.", "base offer could be BASE3VISIBLE23A.",
            "Subscribers bill cycle offset is 31."
        };
        td.when = new String[] {
            "Change to PLUS3VIS23WB", "New monthly addons to be added.",
            "Addon could be CD2VISIBLE2023.", "IncludePaymentAdvice = Y",
        };
        td.then = new String[] {
            "Advice shows PaymentAdvice with new addon.",
            "Cycle end date of new addon should be correct"
        };

        @SuppressWarnings("unchecked")
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            List<String> pciList = new ArrayList<String>();
            request.setDiscountPrice(
                    CommonTestHelper.getOfferPrice(request.getNewCatalogItemExternalId()));
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
            BigDecimal expectedRecharge = request.getDiscountPrice();
            for (String offerName : tCase.addOfferList) {
                VisibleChangeServiceAddItem csai = new VisibleChangeServiceAddItem();
                csai.setCatalogItemExternalId(offerName);
                csai.setDiscountPrice(
                        CommonTestHelper.getOfferPrice(csai.getCatalogItemExternalId()));
                csai.setGrossPrice(csai.getDiscountPrice().add(BigDecimal.TEN));
                request.getAddItemsAppender().add(csai);
                pciList.add(offerName);
                expectedRecharge = expectedRecharge.add(csai.getDiscountPrice());
            }
            ;
            pciList.add(tCase.oldCi);
            pciList.add(request.getNewCatalogItemExternalId());

            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            emulateMtxResponsePricingCatalogItems(instance, pciList);

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            System.out.println(
                    td.getTestMethod() + ":" + subscriptionResponse.getBillingCycle().toJson());
            subscriptionResponse.getBillingCycle().setCurrentPeriodStartTime(
                    TestUtils.getLastDateTimeOfLastMonth(subscriptionResponse.getTimeZone()));
            subscriptionResponse.getBillingCycle().setCurrentPeriodEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth(subscriptionResponse.getTimeZone()));
            subscriptionResponse.getBillingCycle().setDateOffset(31L);
            System.out.println(
                    td.getTestMethod() + ":" + subscriptionResponse.getBillingCycle().toJson());
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());
            // emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    tCase.addOfferList.get(0), BigDecimal.ZERO, null);
            purResponseBase.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).setCycleStartTime(
                            subscriptionResponse.getBillingCycle().getCurrentPeriodStartTime());
            purResponseBase.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).setCycleEndTime(
                            subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime());
            doReturn(purResponseBase).when(instance).getAocCurrencyBalanceImpactInfo(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    tCase.addOfferList.get(0))),
                    any(), any());

            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchase(
                    request.getNewCatalogItemExternalId(), aocAmount);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());
            System.out.println(
                    td.getTestMethod() + ":" + aopStage.getRecurringChargeInfo().toJson());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            VisibleOfferDetails addonVod = null;
            for (VisibleOfferDetails vod : response.getNextCyclePaymentAdvice().getVisibleOfferDetailsList()) {
                if (request.getAtAddItems(0).getCatalogItemExternalId().equalsIgnoreCase(
                        vod.getCatalogItemExternalId())) {
                    addonVod = vod;
                    break;
                }
            }
            assertNotNull(addonVod);
            assertEquals(
                    CommonUtils.getNextCycleEndTime(
                            subscriptionResponse.getBillingCycle(),
                            subscriptionResponse.getTimeZone()).toString(),
                    addonVod.getCycleEndTime());
        };

        String subscriptionExternalId = "123";

        VisibleRequestChangeServiceAdvice request02 = new VisibleRequestChangeServiceAdvice();
        request02.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        request02.setSubscriptionExternalId(subscriptionExternalId);
        request02.setIncludePaymentAdvice("Y");
        TestConditions tc02 = new TestConditions() {

            {
                newCi = request02.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE3ANNUAL;
            }
        };
        tc02.addOfferList.add(CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023);
        pTests.test(request02, tc02);
    }

    @Test
    @Tags({
        @Tag("VER-448"), @Tag("VER-535")
    })
    public void test_getChangeServiceAdvice_When_CancelItems_No_Then_AoP_Has_Items_Not_In_AoP(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service.",
            "Service could be BASE3VISIBLE23A or PLUS3VIS23WBA"
        };
        td.when = new String[] {
            "Change to another annual plan", "Existing addons to be cancelled.",
            "Addon could be CD3VISIBLE2023 or CD2VISIBLE2023 or CD3VISIBLE2023A.",
            "IncludePaymentAdvice = Y",
        };
        td.then = new String[] {
            "Advice shows PaymentAdvice with new addon."
        };

        @SuppressWarnings("unchecked")
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();

            List<String> pciList = new ArrayList<String>();
            request.setDiscountPrice(
                    CommonTestHelper.getOfferPrice(request.getNewCatalogItemExternalId()));
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
            for (String offerName : tCase.cancelOfferList) {
                VisibleChangeServiceCancelItem csci = new VisibleChangeServiceCancelItem();
                csci.setCatalogItemExternalId(offerName);
                request.getCancelItemsAppender().add(csci);
                pciList.add(offerName);
                PurchasedOfferInfo poiAddon = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                        subscriptionResponse, offerName);
                CommonTestHelper.getMtxPurchasedOfferInfo(subscription, offerName);
                if (tCase.conditionMap.get("RESOURCEID") != null
                        && "Y".equalsIgnoreCase((String) tCase.conditionMap.get("RESOURCEID"))) {
                    csci.setResourceId(poiAddon.getResourceId());
                }
            }
            ;
            pciList.add(tCase.oldCi);
            pciList.add(request.getNewCatalogItemExternalId());

            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
            emulateMtxResponsePricingCatalogItems(instance, pciList);

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();

            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());

            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchase(
                    request.getNewCatalogItemExternalId(), aocAmount);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            // emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());
            System.out.println(
                    td.getTestMethod() + ":" + aopStage.getRecurringChargeInfo().toJson());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            List<String> actualOfferList = new ArrayList<String>();
            for (VisibleOfferDetails vod : response.getNextCyclePaymentAdvice().getVisibleOfferDetailsList()) {
                actualOfferList.add(vod.getCatalogItemExternalId());
            }
            assertTrue(response.getNextCyclePaymentAdvice() != null);
            assertFalse(
                    actualOfferList.contains(
                            request.getAtCancelItems(0).getCatalogItemExternalId()));
        };

        String subscriptionExternalId = "123";

        VisibleRequestChangeServiceAdvice request01 = new VisibleRequestChangeServiceAdvice();
        request01.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        request01.setSubscriptionExternalId(subscriptionExternalId);
        request01.setIncludePaymentAdvice("Y");
        TestConditions tc01 = new TestConditions() {

            {
                newCi = request01.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE3ANNUAL;
            }
        };
        tc01.cancelOfferList.add(CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION);
        tc01.conditionMap.put("RESOURCEID", "N");
        pTests.test(request01, tc01);

        VisibleRequestChangeServiceAdvice request02 = new VisibleRequestChangeServiceAdvice();
        request02.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        request02.setSubscriptionExternalId(subscriptionExternalId);
        request02.setIncludePaymentAdvice("Y");
        TestConditions tc02 = new TestConditions() {

            {
                newCi = request02.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE3ANNUAL;
            }
        };
        tc02.cancelOfferList.add(CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION);
        tc02.conditionMap.put("RESOURCEID", "Y");
        pTests.test(request02, tc02);
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-480")
    @Test
    public void test_getChangeServiceAdvice_When_DeltaCreditsAvailable_As_Consumables_Then_ResponseHasDeltaCredits(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service.", "Referral Credits available",
            "Some referral credits are consumable.", "PaidCycleStartDate is in past.",
        };
        td.when = new String[] {
            "Api is called for annual upgrade.", "Change delta is eligible for referral credits."
        };
        td.then = new String[] {
            "Advice should show referral credits in change cycle.",
            "Grants should assume that consuptions are reversed."
        };
        td.comments = new String[] {
            "VER-480"
        };
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            String promoGrantOffer = tCase.promoMap.get("GRANT_CI").toString();
            BigDecimal promoGrantAmount = (BigDecimal) tCase.promoMap.get("GRANT_AMOUNT");
            BigDecimal promoDollarAmount = (BigDecimal) tCase.promoMap.get("DOLLAR_AMOUNT");

            Map<String, MtxResponsePricingCatalogItem> ciPricingMap = emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(
                            tCase.oldCi, request.getNewCatalogItemExternalId(), promoGrantOffer));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            if (tCase.paidCycleStartDate != null) {
                poExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            }
            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                            promoGrantOffer, promoGrantAmount));
            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoConsumable(
                            promoGrantOffer, promoDollarAmount));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchase(
                    request.getNewCatalogItemExternalId(), aocAmount);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            /********************** Mock PaymentAdvice ****************************/
            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);

            ServiceStage ss = new ServiceStage(tCase.oldCi);

            VisibleTemplate vtRef20 = (VisibleTemplate) ciPricingMap.get(
                    promoGrantOffer).getCatalogItemInfo().getTemplateAttr();
            GlobalCreditStage gcsRef20 = new GlobalCreditStage(promoGrantOffer, vtRef20);
            gcsRef20.setPromotionName(vtRef20.getPromotionName());
            gcsRef20.setAvailableCredits(promoGrantAmount.add(promoDollarAmount));
            gcsRef20.setAvailableCreditsConsumable(promoDollarAmount);
            gcsRef20.setAvailableCreditsGrant(promoGrantAmount);
            gcsRef20.setRedeemOfferCi(vtRef20.getRedeemOffer());
            gcsRef20.setApplicableCiCsv(vtRef20.getApplicableOfferName() + "," + tCase.oldCi);
            // 20240320- As per pricing Ref20 is not applicable to BASE3VISIBLE23A
            CreditStage csRef20 = new CreditStage(gcsRef20, tCase.oldCi);
            csRef20.setApplicableServiceStage(ss);

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.getCreditMap().put(
                    new PromoOfferPair(tCase.oldCi, csRef20.getPromotionName()), csRef20);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());
            /********************** Mock PaymentAdvice ****************************/

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");
            MtxPurchasedOfferInfo poiRef20Redeem = CommonTestHelper.getMtxPurchasedOfferInfo(
                    CI_EXTERNAL_IDS.REF20_REDEEM, promoDollarAmount, true);
            poiRef20Redeem.setResourceId(55L);
            emulateMtxResponseOneTimeOffer(instance, poiRef20Redeem);

            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            assertTrue(response.getNextCycle() != null);
            assertTrue(response.getNextCycle().getReverseCredits() != null);
            System.out.println(response.getNextCycle().toJson());
            assertEquals(
                    promoDollarAmount.doubleValue(), response.getNextCycle().getAtReverseCredits(
                            0).getAvailableCreditsConsumable().doubleValue());
            assertEquals(
                    response.getChangeCycle().getAtCredits(0).getRedeemableCredits(),
                    response.getChangeCycle().getAtCredits(0).getEstimatedTransferableCredits(),
                    "If redeem equals transferable, all consumptions are reversed and are part of grants.");
        };

        String subscriptionExternalId = "123";

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3ANNUAL));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId(subscriptionExternalId);

        VisibleDeltaPromo csp = new VisibleDeltaPromo();
        csp.setClassCode(TAX_CLASS_CODES.REF20);
        csp.setDeltaPromotionLimit(BigDecimal.valueOf(40));
        requestUp.appendDeltaPromotionList(csp);

        TestConditions chgUp = new TestConditions() {

            {
                newCi = requestUp.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE3ANNUAL;
                paidCycleStartDate = TestUtils.getFirstDateOfCurrentMonth();
            }
        };
        chgUp.promoMap.put("GRANT_CI", CI_EXTERNAL_IDS.REF20_GRANT);
        chgUp.promoMap.put("GRANT_AMOUNT", BigDecimal.valueOf(150));
        chgUp.promoMap.put("DOLLAR_AMOUNT", BigDecimal.valueOf(50));
        pTests.test(requestUp, chgUp);
    }

    @Tag("VER-480")
    @Test
    public void test_getChangeServiceAdvice_When_DeltaCreditsAvailable_And_PaidCycleStartDate_In_Future_Then_ResponseHasDeltaCredits(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service.", "Referral Credits available",
            "Some referral credits are consumable.",
            "Referral Credits are NOT applicable to Enrolled offer (BASE3VISIBLE23A)",
            "Referral Credits are applicable to Delta", "PaidCycleStartDate is in future.",
        };
        td.when = new String[] {
            "Api is called for annual upgrade."
        };
        td.then = new String[] {
            "Advice should show referral credits in change cycle.",
            "Consumptions shoult not be reversed.",
            "Credits for new service should be transferred from grant."
        };
        td.comments = new String[] {
            "Consumptions amount applicable for old service can be reversed. "
                    + "If consumptions are not applicable to old offer, api does not know about the real purpose of consumptions.",
            "In such scenarios there should be a manual intervention."
        };
        td.comments = new String[] {
            "VER-480"
        };
        @SuppressWarnings("unchecked")
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            String promoGrantOffer = tCase.promoMap.get("GRANT_CI").toString();
            BigDecimal promoGrantAmount = (BigDecimal) tCase.promoMap.get("GRANT_AMOUNT");
            BigDecimal promoDollarAmount = (BigDecimal) tCase.promoMap.get("DOLLAR_AMOUNT");

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(
                            tCase.oldCi, request.getNewCatalogItemExternalId(), promoGrantOffer));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            if (tCase.paidCycleStartDate != null) {
                poExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            }
            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                            promoGrantOffer, promoGrantAmount));
            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoConsumable(
                            promoGrantOffer, promoDollarAmount));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchase(
                    request.getNewCatalogItemExternalId(), aocAmount);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            /********************** Mock PaymentAdvice ****************************/
            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());
            /********************** Mock PaymentAdvice ****************************/

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");
            MtxPurchasedOfferInfo poiRef20Redeem = CommonTestHelper.getMtxPurchasedOfferInfo(
                    CI_EXTERNAL_IDS.REF20_REDEEM, promoDollarAmount, true);
            poiRef20Redeem.setResourceId(55L);
            emulateMtxResponseOneTimeOffer(instance, poiRef20Redeem);

            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            assertTrue(
                    response.getNextCycle() == null
                            || response.getNextCycle().getReverseCredits() == null);
            assertEquals(
                    response.getChangeCycle().getAtCredits(0).getRedeemableCredits(),
                    response.getChangeCycle().getAtCredits(0).getEstimatedTransferableCredits(),
                    "If transferables equals redeemables, all redeemables comes from grant.");
        };

        String subscriptionExternalId = "123";

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3ANNUAL));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId(subscriptionExternalId);

        VisibleDeltaPromo csp = new VisibleDeltaPromo();
        csp.setClassCode(TAX_CLASS_CODES.REF20);
        csp.setDeltaPromotionLimit(BigDecimal.valueOf(40));
        requestUp.appendDeltaPromotionList(csp);

        TestConditions chgUp = new TestConditions() {

            {
                newCi = requestUp.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE3ANNUAL;
                paidCycleStartDate = TestUtils.getFirstDateOfNextMonth();
            }
        };
        chgUp.promoMap.put("GRANT_CI", CI_EXTERNAL_IDS.REF20_GRANT);
        chgUp.promoMap.put("GRANT_AMOUNT", BigDecimal.valueOf(150));
        chgUp.promoMap.put("DOLLAR_AMOUNT", BigDecimal.valueOf(50));
        pTests.test(requestUp, chgUp);
    }

    @Tag("VER-480")
    @Test
    public void test_getChangeServiceAdvice_When_Consumptions_NA_ASIS_Then_ConsumptionUnavailable(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service.", "Referral Consumptions are available.",
            "Referral Consumptions are not applicable to old offer that will be replaced with new one."
        };
        td.when = new String[] {
            "Api is called for annual upgrade.", "Change delta is eligible for referral credits."
        };
        td.then = new String[] {
            "Advice should show referral credits in change cycle.",
            "Consumptions that not applicable to old offer should be unavailable to new offer."
        };
        td.comments = new String[] {
            "VER-480",
            "Promo is consumption because it is put for renewal or purchase of an offer.",
            "If consumption is not applicable to old base offer, it may be reserved for another offer, say wearables.",
            "Do not touch consumption whose purpose we do not know."
        };
        @SuppressWarnings("unchecked")
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            String promoGrantOffer = tCase.promoMap.get("GRANT_CI").toString();
            BigDecimal promoGrantAmount = (BigDecimal) tCase.promoMap.get("GRANT_AMOUNT");
            BigDecimal promoDollarAmount = (BigDecimal) tCase.promoMap.get("DOLLAR_AMOUNT");

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(
                            tCase.oldCi, request.getNewCatalogItemExternalId(), promoGrantOffer));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            if (tCase.paidCycleStartDate != null) {
                poExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            }
            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                            promoGrantOffer, promoGrantAmount));
            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoConsumable(
                            promoGrantOffer, promoDollarAmount));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchase(
                    request.getNewCatalogItemExternalId(), aocAmount);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            /********************** Mock PaymentAdvice ****************************/
            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());
            /********************** Mock PaymentAdvice ****************************/

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");
            MtxPurchasedOfferInfo poiRef20Redeem = CommonTestHelper.getMtxPurchasedOfferInfo(
                    CI_EXTERNAL_IDS.REF20_REDEEM, promoDollarAmount, true);
            poiRef20Redeem.setResourceId(55L);
            emulateMtxResponseOneTimeOffer(instance, poiRef20Redeem);

            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            assertTrue(
                    response.getNextCycle() == null
                            || response.getNextCycle().getReverseCredits() == null);
            assertEquals(
                    promoDollarAmount.doubleValue(), response.getChangeCycle().getAtCredits(
                            0).getConsumablesUnavailableToChangeService().doubleValue());
        };

        String subscriptionExternalId = "123";

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3ANNUAL));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId(subscriptionExternalId);

        VisibleDeltaPromo csp = new VisibleDeltaPromo();
        csp.setClassCode(TAX_CLASS_CODES.REF20);
        csp.setDeltaPromotionLimit(BigDecimal.valueOf(40));
        requestUp.appendDeltaPromotionList(csp);

        TestConditions chgUp = new TestConditions() {

            {
                newCi = requestUp.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE3ANNUAL;
                paidCycleStartDate = TestUtils.getFirstDateOfCurrentMonth();
            }
        };
        chgUp.promoMap.put("GRANT_CI", CI_EXTERNAL_IDS.REF20_GRANT);
        chgUp.promoMap.put("GRANT_AMOUNT", BigDecimal.valueOf(150));
        chgUp.promoMap.put("DOLLAR_AMOUNT", BigDecimal.valueOf(50));
        pTests.test(requestUp, chgUp);
    }

    @Tag("VER-480")
    @Test
    public void test_getChangeServiceAdvice_When_DeltaCreditsAvailable_Then_DeltaCreditsAsPerPromoLimit(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service.", "Referral Credits available"
        };
        td.when = new String[] {
            "Api is called for annual upgrade.", "Change delta is eligible for referral credits.",
            "Custom promo limit passed in input request."
        };
        td.then = new String[] {
            "Advice should show referral credits in change cycle. As per new promo limit."
        };
        td.comments = new String[] {
            "VER-480"
        };
        @SuppressWarnings("unchecked")
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            String promoGrantOffer = tCase.promoMap.get("GRANT_CI").toString();
            BigDecimal promoGrantAmount = (BigDecimal) tCase.promoMap.get("GRANT_AMOUNT");
            BigDecimal promoDollarAmount = (BigDecimal) tCase.promoMap.get("DOLLAR_AMOUNT");

            Map<String, MtxResponsePricingCatalogItem> ciPricingMap = emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(
                            tCase.oldCi, request.getNewCatalogItemExternalId(), promoGrantOffer));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            if (tCase.paidCycleStartDate != null) {
                poExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            }
            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                            promoGrantOffer, promoGrantAmount));
            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoConsumable(
                            promoGrantOffer, promoDollarAmount));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchase(
                    request.getNewCatalogItemExternalId(), aocAmount);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            /********************** Mock PaymentAdvice ****************************/
            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);

            ServiceStage ss = new ServiceStage(tCase.oldCi);

            VisibleTemplate vtRef20 = (VisibleTemplate) ciPricingMap.get(
                    promoGrantOffer).getCatalogItemInfo().getTemplateAttr();
            GlobalCreditStage gcsRef20 = new GlobalCreditStage(promoGrantOffer, vtRef20);
            gcsRef20.setPromotionName(vtRef20.getPromotionName());
            gcsRef20.setAvailableCredits(promoGrantAmount.add(promoDollarAmount));
            gcsRef20.setAvailableCreditsConsumable(promoDollarAmount);
            gcsRef20.setAvailableCreditsGrant(promoGrantAmount);
            gcsRef20.setRedeemOfferCi(vtRef20.getRedeemOffer());
            gcsRef20.setApplicableCiCsv(vtRef20.getApplicableOfferName() + "," + tCase.oldCi); // 20240320-
                                                                                               // As
                                                                                               // per
            // pricing Ref20 is not applicable to BASE3VISIBLE23A

            CreditStage csRef20 = new CreditStage(gcsRef20, tCase.oldCi);
            csRef20.setApplicableServiceStage(ss);

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.getCreditMap().put(
                    new PromoOfferPair(tCase.oldCi, csRef20.getPromotionName()), csRef20);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());
            /********************** Mock PaymentAdvice ****************************/

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");
            MtxPurchasedOfferInfo poiRef20Redeem = CommonTestHelper.getMtxPurchasedOfferInfo(
                    CI_EXTERNAL_IDS.REF20_REDEEM, promoDollarAmount, true);
            poiRef20Redeem.setResourceId(55L);
            emulateMtxResponseOneTimeOffer(instance, poiRef20Redeem);

            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            assertEquals(
                    request.getAtDeltaPromotionList(0).getDeltaPromotionLimit().doubleValue(),
                    response.getChangeCycle().getAtCredits(0).getCreditCap().doubleValue(),
                    "Promo limit should be as per request.");
            assertEquals(
                    request.getAtDeltaPromotionList(0).getDeltaPromotionLimit().doubleValue(),
                    response.getChangeCycle().getAtCredits(0).getRedeemableCredits().doubleValue());
        };

        String subscriptionExternalId = "123";

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3ANNUAL));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId(subscriptionExternalId);

        VisibleDeltaPromo csp = new VisibleDeltaPromo();
        csp.setClassCode(TAX_CLASS_CODES.REF20);
        csp.setDeltaPromotionLimit(BigDecimal.valueOf(55));
        requestUp.appendDeltaPromotionList(csp);

        TestConditions chgUp = new TestConditions() {

            {
                newCi = requestUp.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE3ANNUAL;
                paidCycleStartDate = TestUtils.getFirstDateOfCurrentMonth();
            }
        };
        chgUp.promoMap.put("GRANT_CI", CI_EXTERNAL_IDS.REF20_GRANT);
        chgUp.promoMap.put("GRANT_AMOUNT", BigDecimal.valueOf(150));
        chgUp.promoMap.put("DOLLAR_AMOUNT", BigDecimal.valueOf(50));
        pTests.test(requestUp, chgUp);
    }

    @Test
    @Tag("VER-480")
    public void test_getChangeServiceAdvice_When_DeltaCreditLimit_RequestParameter_Then_RenewalPromoAsPerPricingLimit(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service.", "Referral Credits available",
            "PaidCycleStartDate is in past.", "Change delta is eligible for referral credits.",
            "Annual plan in last month of annual cycle."
        };
        td.when = new String[] {
            "Api is called for annual upgrade.", "Request parameter overrides promo limit.",
            "NextMonthPaymentAdvice is requested"
        };
        td.then = new String[] {
            "PaymentAdviceResponse should provide promo as per limit in template attributes."
        };
        td.comments = new String[] {
            "VER-480",
            "Promo limit override is for delta only. For subsequent transactions, we should fallback limits as per pricing.",
            "Keep less than a month in BaseAnnual so that payment advice will show non-zero amount."
        };
        @SuppressWarnings("unchecked")
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            String promoGrantOffer = tCase.promoMap.get("GRANT_CI").toString();
            BigDecimal promoGrantAmount = (BigDecimal) tCase.promoMap.get("GRANT_AMOUNT");
            BigDecimal promoDollarAmount = (BigDecimal) tCase.promoMap.get("DOLLAR_AMOUNT");

            Map<String, MtxResponsePricingCatalogItem> ciPricingMap = emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(
                            tCase.oldCi, request.getNewCatalogItemExternalId(), promoGrantOffer));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);

            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            if (tCase.paidCycleStartDate != null) {
                poExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            }
            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                            promoGrantOffer, promoGrantAmount));
            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoConsumable(
                            promoGrantOffer, promoDollarAmount));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            subscriptionResponse.getBillingCycle().setCurrentPeriodStartTime(
                    TestUtils.getLastDateTimeOfLastMonth(subscriptionResponse.getTimeZone()));
            subscriptionResponse.getBillingCycle().setCurrentPeriodEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth(subscriptionResponse.getTimeZone()));
            subscriptionResponse.getBillingCycle().setDateOffset(31L);
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);

            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            poiEnrolled.getCycleInfo().setCycleEndTime(
                    TestUtils.addOneWeek(poEnrolled.getCycleInfo().getCycleStartTime()));
            poEnrolled.getCycleInfo().setCycleEndTime(
                    TestUtils.addOneWeek(poEnrolled.getCycleInfo().getCycleStartTime()));

            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            BigDecimal aocAmount = BigDecimal.valueOf(tCase.aocDelta);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchase(
                    request.getNewCatalogItemExternalId(), aocAmount);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            /********************** Mock PaymentAdvice ****************************/
            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            ServiceStage ss = new ServiceStage(tCase.oldCi);

            VisibleTemplate vtRef20 = (VisibleTemplate) ciPricingMap.get(
                    promoGrantOffer).getCatalogItemInfo().getTemplateAttr();
            GlobalCreditStage gcsRef20 = new GlobalCreditStage(promoGrantOffer, vtRef20);
            gcsRef20.setPromotionName(vtRef20.getPromotionName());
            gcsRef20.setAvailableCredits(promoGrantAmount.add(promoDollarAmount));
            gcsRef20.setAvailableCreditsConsumable(promoDollarAmount);
            gcsRef20.setAvailableCreditsGrant(promoGrantAmount);
            gcsRef20.setRedeemOfferCi(vtRef20.getRedeemOffer());
            gcsRef20.setApplicableCiCsv(vtRef20.getApplicableOfferName() + "," + tCase.oldCi);
            // 20240320- As per pricing Ref20 is not applicable to BASE3VISIBLE23A

            CreditStage csRef20 = new CreditStage(gcsRef20, tCase.oldCi);
            csRef20.setApplicableServiceStage(ss);

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.getCreditMap().put(
                    new PromoOfferPair(tCase.oldCi, csRef20.getPromotionName()), csRef20);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());
            /********************** Mock PaymentAdvice ****************************/

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");
            MtxPurchasedOfferInfo poiRef20Redeem = CommonTestHelper.getMtxPurchasedOfferInfo(
                    CI_EXTERNAL_IDS.REF20_REDEEM, promoDollarAmount, true);
            poiRef20Redeem.setResourceId(55L);
            emulateMtxResponseOneTimeOffer(instance, poiRef20Redeem);

            System.out.println(
                    td.getTestMethod() + ":" + aopStage.getRecurringChargeInfo().toJson());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            assertEquals(
                    vtRef20.getPromotionLimit().doubleValue(),
                    response.getNextCyclePaymentAdvice().getAtCredits(
                            0).getCreditCap().doubleValue(),
                    "Normal Promo limit should be as per pricing or purchased offer extension.");
        };

        String subscriptionExternalId = "123";

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3ANNUAL));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId(subscriptionExternalId);
        requestUp.setIncludePaymentAdvice("Y");
        VisibleDeltaPromo csp = new VisibleDeltaPromo();
        csp.setClassCode(TAX_CLASS_CODES.REF20);
        csp.setDeltaPromotionLimit(BigDecimal.valueOf(55));
        requestUp.appendDeltaPromotionList(csp);

        TestConditions chgUp = new TestConditions() {

            {
                newCi = requestUp.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE3ANNUAL;
                paidCycleStartDate = TestUtils.getFirstDateOfCurrentMonth();
                aocDelta = 150;
            }
        };
        chgUp.promoMap.put("GRANT_CI", CI_EXTERNAL_IDS.REF20_GRANT);
        chgUp.promoMap.put("GRANT_AMOUNT", BigDecimal.valueOf(150));
        chgUp.promoMap.put("DOLLAR_AMOUNT", BigDecimal.valueOf(50));
        pTests.test(requestUp, chgUp);
    }

    @Test
    @Tag("VER-480")
    public void test_getChangeServiceAdvice_When_DeltaCreditsAvailable_Then_OtherCreditsShouldNotBeUsed(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service.", "Referral Credits available",
            "Other credits applicable to target PLUS3VIS23WBA (e.g goodwill) are also available."
        };
        td.when = new String[] {
            "Api is called for annual upgrade.", "Change delta is eligible for referral credits."
        };
        td.then = new String[] {
            "Only referral credits are used for delta.",
            "Other credits like goodwill are NOT used for delta."
        };
        td.comments = new String[] {
            "VER-480",
            "PaidCycleStartDate in future will help in getting a response with next cycle.",
            "Then we can see change cycle with one credit and next cycle with two."
        };
        @SuppressWarnings("unchecked")
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            String promoGrantOffer_1 = tCase.promoMap.get("GRANT_CI_1").toString();
            BigDecimal promoGrantAmount_1 = (BigDecimal) tCase.promoMap.get("GRANT_AMOUNT_1");
            String promoGrantOffer_2 = tCase.promoMap.get("GRANT_CI_2").toString();
            BigDecimal promoGrantAmount_2 = (BigDecimal) tCase.promoMap.get("GRANT_AMOUNT_2");

            Map<String, MtxResponsePricingCatalogItem> pricingMap = emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            tCase.oldCi, request.getNewCatalogItemExternalId(), promoGrantOffer_1,
                            promoGrantOffer_2));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            if (tCase.paidCycleStartDate != null) {
                poExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            }
            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                            promoGrantOffer_1, promoGrantAmount_1));
            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                            promoGrantOffer_2, promoGrantAmount_2));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchase(
                    request.getNewCatalogItemExternalId(), aocAmount);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            assertFalse(response.getChangeCycle().getCredits().isEmpty());
            boolean promo1Present = false;
            boolean promo2Present = false;
            VisibleTemplate vt1 = (VisibleTemplate) pricingMap.get(
                    promoGrantOffer_1).getCatalogItemInfo().getTemplateAttr();
            VisibleTemplate vt2 = (VisibleTemplate) pricingMap.get(
                    promoGrantOffer_2).getCatalogItemInfo().getTemplateAttr();
            for (VisibleCredits vc : response.getChangeCycle().getCredits()) {
                if (vt1.getRedeemOffer().equalsIgnoreCase(vc.getCreditRedeemableOfferCI())) {
                    promo1Present = true;
                }
                if (vt2.getRedeemOffer().equalsIgnoreCase(vc.getCreditRedeemableOfferCI())) {
                    promo2Present = true;
                }
            }
            assertTrue(promo1Present);
            assertFalse(promo2Present);
        };

        String subscriptionExternalId = "123";

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3ANNUAL));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId(subscriptionExternalId);

        VisibleDeltaPromo csp = new VisibleDeltaPromo();
        csp.setClassCode(TAX_CLASS_CODES.REF20);
        csp.setDeltaPromotionLimit(BigDecimal.valueOf(40));
        requestUp.appendDeltaPromotionList(csp);

        TestConditions chgUp = new TestConditions() {

            {
                newCi = requestUp.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE3ANNUAL;
                paidCycleStartDate = TestUtils.getFirstDateOfNextMonth();
            }
        };
        chgUp.promoMap.put("GRANT_CI_1", CI_EXTERNAL_IDS.REF20_GRANT);
        chgUp.promoMap.put("GRANT_AMOUNT_1", BigDecimal.valueOf(150));
        chgUp.promoMap.put("GRANT_CI_2", CI_EXTERNAL_IDS.GRANT_GOODWILL);
        chgUp.promoMap.put("GRANT_AMOUNT_2", BigDecimal.valueOf(100));
        pTests.test(requestUp, chgUp);
    }

    @Test
    @SuppressWarnings("unchecked")
    @Tag("VER-480")
    public void test_getChangeServiceAdvice_When_DeltaCredit_is_REF20_Then_DeltaCreditShouldNotImpactDeltaValue(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service.", "Referral Credits available",
            "PaidCycleStartDate is in past.", "Change delta is eligible for referral credits."
        };
        td.when = new String[] {
            "Api is called for annual upgrade.",
        };
        td.then = new String[] {
            "Delta value should not be impacted by REF20."
        };
        td.comments = new String[] {
            "VER-480", "Referrals and Goodwill should not impact delta as per rsgateway property."
        };
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            String promoGrantOffer_1 = tCase.promoMap.get("GRANT_CI").toString();
            BigDecimal promoGrantAmount_1 = (BigDecimal) tCase.promoMap.get("GRANT_AMOUNT");

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(
                            tCase.oldCi, request.getNewCatalogItemExternalId(), promoGrantOffer_1));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            if (tCase.paidCycleStartDate != null) {
                poExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            }
            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                            promoGrantOffer_1, promoGrantAmount_1));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchase(
                    request.getNewCatalogItemExternalId(), aocAmount);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            assertFalse(response.getChangeCycle().getCredits().isEmpty());
            assertEquals(
                    ((BigDecimal) tCase.expResultsMap.get("EXP_DELTA")).doubleValue(),
                    response.getChangeCycle().getDelta().doubleValue());
        };

        String subscriptionExternalId = "123";

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3ANNUAL));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId(subscriptionExternalId);

        VisibleDeltaPromo csp = new VisibleDeltaPromo();
        csp.setClassCode(TAX_CLASS_CODES.REF20);
        csp.setDeltaPromotionLimit(BigDecimal.valueOf(40));
        requestUp.appendDeltaPromotionList(csp);

        TestConditions chgUp = new TestConditions() {

            {
                newCi = requestUp.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE3ANNUAL;
                paidCycleStartDate = TestUtils.getFirstDateOfCurrentMonth();
            }
        };
        chgUp.promoMap.put("GRANT_CI", CI_EXTERNAL_IDS.REF20_GRANT);
        chgUp.promoMap.put("GRANT_AMOUNT", BigDecimal.valueOf(150));
        chgUp.expResultsMap.put(
                "EXP_DELTA", CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3ANNUAL).subtract(
                        CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.BASE3ANNUAL)));
        pTests.test(requestUp, chgUp);
    }

    @Test
    @SuppressWarnings("unchecked")
    @Tag("VER-480")
    public void test_getChangeServiceAdvice_When_DeltaCreditsAvailable_And_Taxable_Then_DeltaCreditsWithTaxes(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service.", "Referral Credits available"
        };
        td.when = new String[] {
            "Api is called for annual upgrade.", "Change delta is eligible for referral credits."
        };
        td.then = new String[] {
            "Advice should show credits with taxes, if credit is taxable."
        };
        td.comments = new String[] {
            "VER-480"
        };
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            String promoGrantOffer_1 = tCase.promoMap.get("GRANT_CI").toString();
            BigDecimal promoGrantAmount_1 = (BigDecimal) tCase.promoMap.get("GRANT_AMOUNT");

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(
                            tCase.oldCi, request.getNewCatalogItemExternalId(), promoGrantOffer_1));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            if (tCase.paidCycleStartDate != null) {
                poExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            }
            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                            promoGrantOffer_1, promoGrantAmount_1));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchase(
                    request.getNewCatalogItemExternalId(), aocAmount);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            assertFalse(response.getChangeCycle().getCredits().isEmpty());
            assertTrue(
                    StringUtils.isNotBlank(
                            (response.getChangeCycle().getAtCredits(0).getTaxDetails())));
        };

        String subscriptionExternalId = "123";

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3ANNUAL));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId(subscriptionExternalId);

        VisibleDeltaPromo csp = new VisibleDeltaPromo();
        csp.setClassCode(TAX_CLASS_CODES.REF20);
        csp.setDeltaPromotionLimit(BigDecimal.valueOf(40));
        requestUp.appendDeltaPromotionList(csp);

        TestConditions chgUp = new TestConditions() {

            {
                newCi = requestUp.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE3ANNUAL;
                paidCycleStartDate = TestUtils.getFirstDateOfCurrentMonth();
            }
        };
        chgUp.promoMap.put("GRANT_CI", CI_EXTERNAL_IDS.REF20_GRANT);
        chgUp.promoMap.put("GRANT_AMOUNT", BigDecimal.valueOf(150));
        chgUp.expResultsMap.put("EXP_DELTA", BigDecimal.valueOf(150));
        pTests.test(requestUp, chgUp);
    }

    @Test
    @SuppressWarnings("unchecked")
    @Tag("VER-480")
    public void test_getChangeServiceAdvice_When_CreditsAvailable_For_AllDelta_Then_PayableSubjectToFixedFee(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service.", "Referral Credits available.",
            "Credits are enough to pay complete delta."
        };
        td.when = new String[] {
            "Api is called for annual upgrade.", "Change delta is eligible for referral credits."
        };
        td.then = new String[] {
            "Advice should be subject to fixedfee."
        };
        td.comments = new String[] {
            "VER-480",
            "This condition is just a retest of existing condition. It is not specific to VER-480."
        };
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            String promoGrantOffer_1 = tCase.promoMap.get("GRANT_CI").toString();
            BigDecimal promoGrantAmount_1 = (BigDecimal) tCase.promoMap.get("GRANT_AMOUNT");

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(
                            tCase.oldCi, request.getNewCatalogItemExternalId(), promoGrantOffer_1));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            poEnrolled.getCycleInfo().setCycleStartTime(TestUtils.getDateTimeOfMidnightToday());
            poEnrolled.getCycleInfo().setCycleEndTime(
                    TestUtils.addOneYear(poEnrolled.getCycleInfo().getCycleStartTime()));

            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                            promoGrantOffer_1, promoGrantAmount_1));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            poEnrolled.getCycleInfo().setCycleStartTime(TestUtils.getDateTimeOfMidnightToday());
            poEnrolled.getCycleInfo().setCycleEndTime(
                    TestUtils.addOneYear(poEnrolled.getCycleInfo().getCycleStartTime()));

            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchase(
                    request.getNewCatalogItemExternalId(), aocAmount);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.valueOf(18.66);

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            assertEquals(
                    fixedfeeChangeCycle.doubleValue(),
                    response.getChangeCycle().getPayableAmount().doubleValue());
        };

        String subscriptionExternalId = "123";

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3ANNUAL));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId(subscriptionExternalId);

        VisibleDeltaPromo csp = new VisibleDeltaPromo();
        csp.setClassCode(TAX_CLASS_CODES.REF20);
        csp.setDeltaPromotionLimit(BigDecimal.valueOf(150));
        requestUp.appendDeltaPromotionList(csp);

        TestConditions chgUp = new TestConditions() {

            {
                newCi = requestUp.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE3ANNUAL;
                paidCycleStartDate = TestUtils.getFirstDateOfCurrentMonth();
            }
        };
        chgUp.promoMap.put("GRANT_CI", CI_EXTERNAL_IDS.REF20_GRANT);
        chgUp.promoMap.put("GRANT_AMOUNT", BigDecimal.valueOf(150));
        chgUp.expResultsMap.put("EXP_DELTA", BigDecimal.valueOf(150));
        pTests.test(requestUp, chgUp);
    }

    @SuppressWarnings("unchecked")
    @Test
    @Tags({
        @Tag("VER-480"), @Tag("VER-557"), @Tag("MTXVER2TMA-4562"), @Tag("DeltaPromo")
    })
    public void test_getChangeServiceAdvice_When_PromoNotEligibleForDelta_PaymentNotMade_Then_PromoNotReversible(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service.(BASE3VISIBLE23A)", "Has goodwill consumables.",
            "Payment is not made for next cycle. PaidCycleStartDate is in past."
        };
        td.when = new String[] {
            "Change to PLUS3VIS23WBA.", "Delta not applicable for Goodwill"
        };
        td.then = new String[] {
            "Goodwill should not be reversed."
        };
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            String promoGrantOffer_1 = tCase.promoMap.get("GRANT_CI_1").toString();
            BigDecimal promoGrantAmount_1 = (BigDecimal) tCase.promoMap.get("GRANT_AMOUNT_1");
            BigDecimal promoDollarAmount_1 = (BigDecimal) tCase.promoMap.get("DOLLAR_AMOUNT_1");

            String promoGrantOffer_2 = tCase.promoMap.get("GRANT_CI_2").toString();
            BigDecimal promoGrantAmount_2 = (BigDecimal) tCase.promoMap.get("GRANT_AMOUNT_2");
            emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            tCase.oldCi, request.getNewCatalogItemExternalId(), promoGrantOffer_1,
                            promoGrantOffer_2));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            poEnrolled.getCycleInfo().setCycleStartTime(TestUtils.getDateTimeOfMidnightToday());
            poEnrolled.getCycleInfo().setCycleEndTime(
                    TestUtils.addOneYear(poEnrolled.getCycleInfo().getCycleStartTime()));

            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                            promoGrantOffer_1, promoGrantAmount_1));
            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoConsumable(
                            promoGrantOffer_1, promoDollarAmount_1));
            subscription.getBalanceArrayAppender().add(
                    CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                            promoGrantOffer_2, promoGrantAmount_2));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            poEnrolled.getCycleInfo().setCycleStartTime(TestUtils.getDateTimeOfMidnightToday());
            poEnrolled.getCycleInfo().setCycleEndTime(
                    TestUtils.addOneYear(poEnrolled.getCycleInfo().getCycleStartTime()));

            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchase(
                    request.getNewCatalogItemExternalId(), aocAmount);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.valueOf(18.66);

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);

            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            MtxPurchasedOfferInfo poiGoodwill = CommonTestHelper.loadJsonMessage(
                    MtxPurchasedOfferInfo.class, TestConstants.DATA_DIR.CHANGE_SERVICE
                            + "MtxPurchasedOfferInfo_Visible_Redeem_Goodwill_Credits.json");
            poiGoodwill.setResourceId(55L);

            emulateMtxResponseOneTimeOffer(instance, poiGoodwill);

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ": Final output: " + response.toJson());
            assertTrue(
                    response.getNextCycle() == null
                            || response.getNextCycle().getReverseCredits() == null
                            || response.getNextCycle().getReverseCredits().isEmpty());
        };

        String subscriptionExternalId = "123";

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3ANNUAL));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId(subscriptionExternalId);
        VisibleDeltaPromo csp = new VisibleDeltaPromo();
        csp.setClassCode(TAX_CLASS_CODES.REF20);
        csp.setDeltaPromotionLimit(BigDecimal.valueOf(150));
        requestUp.appendDeltaPromotionList(csp);

        TestConditions chgUp = new TestConditions() {

            {
                newCi = requestUp.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE3ANNUAL;
                paidCycleStartDate = TestUtils.getFirstDateOfCurrentMonth();
            }
        };
        chgUp.promoMap.put("GRANT_CI_1", CI_EXTERNAL_IDS.GRANT_GOODWILL);
        chgUp.promoMap.put("GRANT_AMOUNT_1", BigDecimal.valueOf(50));
        chgUp.promoMap.put("DOLLAR_AMOUNT_1", BigDecimal.valueOf(50));
        chgUp.promoMap.put("GRANT_CI_2", CI_EXTERNAL_IDS.REF20_GRANT);
        chgUp.promoMap.put("GRANT_AMOUNT_2", BigDecimal.valueOf(50));

        pTests.test(requestUp, chgUp);

    }

    @Tag("VER-480")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription has active base service.Referral Credits available.|"
                +"|When |Api is called for annual upgrade.|"
                +"|     |Change delta is eligible for referral credits.|"
                +"|Then |Advice should show credits with NO taxes, if credit is NOT taxable.|"
                +"|Comments|To test this we need a onetimeoffer credit that is not taxable.|"
                +"|        |Rightnow we do not have one.|"
                })
    // @formatter:on
    public void test_getChangeServiceAdvice_When_DeltaCreditsAvailable_And_Not_Taxable_Then_DeltaCreditsNoTaxes(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
    }

    @Tag("VER-480")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription has active base service.Referral Credits available.|"
                +"|When |Api is called for annual upgrade.|"
                +"|     |Change delta is eligible for referral credits.|"
                +"|     |Referral Credits are provided as future grants in input parameters.|"
                +"|Then |Advice should show futue referral credits in change cycle.|"
                +"|Comments|Existing system does not work to provide future promotions through onetimeoffer grants.|"
                +"|        |As per VER-480 no new code is added to make subscription based grants impact delta.|"
                +"|        |Hence this scenario will remain as open issue. It can not be tested.|"
                })
    // @formatter:on
    public void test_getChangeServiceAdvice_When_DeltaCreditsAvailableAsFutureGrant_Then_CreditsInChangeCycle(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getChangeServiceAdvice_Given_MultipleChangesOnSameDay_When_IncludeAoP_Then_NoError")
    @Tag("VER-704")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription has gone thru mulitple monthly to annual changes on same day.|"
                +"|When |Api was called for change to PLUS3VIS23WBA. AoP requested to be included.|"
                +"|Then |Provide response with no error.|"
                +"|Comments|Issue was due to future service not having resource id. More generic issue than VER-704|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_Given_MultipleChangesOnSameDay_When_IncludeAoP_Then_NoError(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String oldCi = CI_EXTERNAL_IDS.PLUS3VIS23WB;
        String newCi = CI_EXTERNAL_IDS.PLUS3ANNUAL;
        AppPropertyProvider.getInstance().setProperty(
                Constants.CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");// No aoc promos

        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setSubscriptionExternalId("1234");
        request.setNewCatalogItemExternalId(newCi);
        request.setDiscountPrice(CommonTestHelper.getOfferPrice(newCi));
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));
        request.setIncludePaymentAdvice("Y");

        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        BigDecimal oldPrice = CommonTestHelper.getOfferPrice(oldCi);
        System.out.println(api.getClass());
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api,
                CommonTestHelper.getMtxResponseSubscription(
                        request.getSubscriptionExternalId(),
                        List.of(CI_EXTERNAL_IDS.SETUP_SERVICES, oldCi), null, List.of(newCi)));

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCi);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(oldPrice);
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(TestUtils.getDateYesterday());

        emulateMtxResponsePricingCatalogItems(
                instance, List.of(oldCi, request.getNewCatalogItemExternalId()));// ,CI_EXTERNAL_IDS.SETUP_SERVICES

        EventQueryResponseEvents eqre = new EventQueryResponseEvents();
        emulateEventQueryResponseEvents(instance, eqre);
        EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                EventQueryEventInfo.class, TestConstants.DATA_DIR.CHANGE_SERVICE_ADVICE
                        + "EventQueryEventInfo_MtxRecurringEvent.json");
        eqre.getEventListAppender().add(eqei);
        MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
        recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledPoiExtn);
        recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCi);

        /********************** Mock PaymentAdvice ****************************/
        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                oldCi, TestUtils.getDateYesterday());
        aopStage.appendVisibleOfferDetailsMap(
                vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                vodOldCi);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());
        /********************** Mock PaymentAdvice ****************************/
        Map<String, BigDecimal> balImpactMap = Map.of(BALANCE_NAMES.GLOBAL_PASS, BigDecimal.ONE);
        MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                request.getNewCatalogItemExternalId(), BigDecimal.ONE, null, balImpactMap, true);

        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        MtxTimestamp newCiStartTime = new MtxTimestamp(
                LocalDateTime.now().toEpochSecond(ZoneOffset.UTC) * 1000);

        String taxRespString = CommonTestHelper.getTaxApiResp(newCi);
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            ObjectMapper om = TestUtils.getObjectMapper();
            ServiceTaxResponse resp = om.readValue(taxRespString, ServiceTaxResponse.class);
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                            resp.toJson());
            instance.getChangeServiceAdvice(request, response);
        }
        System.out.println(td.getTestMethod() + ":" + response.toJson());
        System.out.println(newCiStartTime);
        assertEquals(RESULT_CODES.MTX_SUCCESS, response.getResult());
        assertNotNull(response.getNextCyclePaymentAdvice());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getChangeServiceAdvice_Given_RenewalFarFarAway_PaidCycleStartDateNextMonth_When_UpgradeWithAoP_Then_PayDeltaOnly")
    @Tags({
        @Tag("VER-797"), @Tag("PaidCycleStartDate"), @Tag("addon")
    })
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription BASE3VISIBLE23A that is not due for renewal next month. Renewal due far far away.PaidCycleStartDate is in future.|"
                +"|When |Api was called for change to PLUS3VIS23WBA. AoP requested to be included.|"
                +"|Then |Only delta should be payable.|"
                +"|Comments|Main cause of the issue was creation of unecessary Nextcycle. |"})
    // @formatter:on
    public void test_getChangeServiceAdvice_Given_RenewalFarFarAway_PaidCycleStartDateNextMonth_When_UpgradeWithAoP_Then_PayDeltaOnly(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        request.setSubscriptionExternalId("1234");
        request.setIncludePaymentAdvice("Y");

        String oldCi = CI_EXTERNAL_IDS.BASE3ANNUAL;
        MtxDate paidCycleStartDate = TestUtils.getFirstDateOfNextMonth();

        List<String> pciList = new ArrayList<String>();
        request.setDiscountPrice(
                CommonTestHelper.getOfferPrice(request.getNewCatalogItemExternalId()));
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
        pciList.add(oldCi);
        pciList.add(request.getNewCatalogItemExternalId());

        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());

        emulateMtxResponsePricingCatalogItems(instance, pciList);

        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                subscription, oldCi);
        VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
        poExtn.setPaidCycleStartDate(paidCycleStartDate);

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
        subscriptionResponse.getBillingCycle().setCurrentPeriodStartTime(
                TestUtils.getLastDateTimeOfLastMonth(subscriptionResponse.getTimeZone()));
        subscriptionResponse.getBillingCycle().setCurrentPeriodEndTime(
                TestUtils.getLastDateTimeOfCurrentMonth(subscriptionResponse.getTimeZone()));
        subscriptionResponse.getBillingCycle().setDateOffset(31L);
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCi);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCi));
        enrolledPoiExtn.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        System.out.println(
                td.getTestMethod() + ":" + subscriptionResponse.getBillingCycle().toJson());

        EventQueryResponseEvents eqre = new EventQueryResponseEvents();
        emulateEventQueryResponseEvents(instance, eqre);
        EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                EventQueryEventInfo.class,
                DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
        eqre.getEventListAppender().add(eqei);
        MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
        VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                0).getPurchasedBundleAttr();
        enrolledExtnEvent.setChargeAmount(CommonTestHelper.getOfferPrice(oldCi));
        enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
        enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
        VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
        recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
        recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCi);

        String taxRespString = CommonTestHelper.getTaxApiResp(
                request.getNewCatalogItemExternalId());
        BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

        VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                oldCi, poExtn.getPaidCycleStartDate());

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                vodOldCi);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

        BigDecimal aocAmount = BigDecimal.valueOf(4);
        MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchase(
                request.getNewCatalogItemExternalId(), aocAmount);
        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());
        
        System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());
        System.out.println(td.getTestMethod() + ":" + aopStage.getRecurringChargeInfo().toJson());

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                    ServiceTaxResponse.class, taxRespString);
            taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                    fixedfeeChangeCycle);
            ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                    ServiceTaxResponse.class, taxRespString);
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                            taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
        }
        instance.getChangeServiceAdvice(request, response);
        assertNull(response.getNextCycle());
        assertEquals(response.getChangeCycle().getPayableAmount().floatValue(), response.getRechargeAmount().floatValue());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getChangeServiceAdvice_Given_ReservedMainBalanceAvailable_When_UpgradeWithAoP_Then_PayDeltaOnly")
    @Tags({
        @Tag("VER-797"), @Tag("PaidCycleStartDate"), @Tag("addon")
    })
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription BASE3VISIBLE23A that is not due for renewal next month. Renewal due far far away.PaidCycleStartDate is in future.|"
                +"|When |Api was called for change to PLUS3VIS23WBA.|"
                +"|Then |Only delta should be payable.|"
                +"|Comments|Main cause of the issue was creation of unecessary Nextcycle. |"})
    // @formatter:on
    public void test_getChangeServiceAdvice_Given_ReservedMainBalanceAvailable_When_UpgradeWithAoP_Then_PayDeltaOnly(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        request.setSubscriptionExternalId("1234");

        String oldCi = CI_EXTERNAL_IDS.BASE3ANNUAL;
        MtxDate paidCycleStartDate = TestUtils.getFirstDateOfNextMonth();

        List<String> pciList = new ArrayList<String>();
        request.setDiscountPrice(
                CommonTestHelper.getOfferPrice(request.getNewCatalogItemExternalId()));
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
        pciList.add(oldCi);
        pciList.add(request.getNewCatalogItemExternalId());

        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());

        emulateMtxResponsePricingCatalogItems(instance, pciList);

        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                subscription, oldCi);
        VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
        poExtn.setPaidCycleStartDate(paidCycleStartDate);
        
        BigDecimal mainbalanceWearables = CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.WEARABLE);
        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(subscription.getExternalId(),mainbalanceWearables));
        subscriptionResponse.getBillingCycle().setCurrentPeriodStartTime(
                TestUtils.getLastDateTimeOfLastMonth(subscriptionResponse.getTimeZone()));
        subscriptionResponse.getBillingCycle().setCurrentPeriodEndTime(
                TestUtils.getLastDateTimeOfCurrentMonth(subscriptionResponse.getTimeZone()));
        subscriptionResponse.getBillingCycle().setDateOffset(31L);
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCi);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCi));
        enrolledPoiExtn.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        System.out.println(
                td.getTestMethod() + ":" + subscriptionResponse.getBillingCycle().toJson());

        EventQueryResponseEvents eqre = new EventQueryResponseEvents();
        emulateEventQueryResponseEvents(instance, eqre);
        EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                EventQueryEventInfo.class,
                DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
        eqre.getEventListAppender().add(eqei);
        MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
        VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                0).getPurchasedBundleAttr();
        enrolledExtnEvent.setChargeAmount(CommonTestHelper.getOfferPrice(oldCi));
        enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
        enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
        VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
        recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
        recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCi);

        String taxRespString = CommonTestHelper.getTaxApiResp(
                request.getNewCatalogItemExternalId());
        BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

        VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                oldCi, poExtn.getPaidCycleStartDate());
        
        VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsAfterPayment(CI_EXTERNAL_IDS.WEARABLE, subscriptionResponse,
                CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.WEARABLE));        
        vodWearable.setConsumableMainBalanceAmount(mainbalanceWearables);
        
        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                vodOldCi);
        aopStage.appendVisibleOfferDetailsMap(
                vodWearable.getCatalogItemExternalId(), Long.valueOf(vodWearable.getResourceId()),
                vodWearable);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        aopStage.setAvailableMainBalanceAmount(mainbalanceWearables);
        aopStage.setConsumableMainBalanceAmount(mainbalanceWearables);
        
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

        BigDecimal aocAmount = BigDecimal.valueOf(4);
        MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchase(
                request.getNewCatalogItemExternalId(), aocAmount);
        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());
        
        System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());
        System.out.println(td.getTestMethod() + ":" + aopStage.getRecurringChargeInfo().toJson());

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                    ServiceTaxResponse.class, taxRespString);
            taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                    fixedfeeChangeCycle);
            ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                    ServiceTaxResponse.class, taxRespString);
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                            taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
        }
        instance.getChangeServiceAdvice(request, response);
        assertNotNull(response.getNextCycle());
        assertEquals(mainbalanceWearables.floatValue(), response.getNextCycle().getReservedMainBalanceAmount().floatValue());
        assertEquals(response.getChangeCycle().getPayableAmount().floatValue(), response.getRechargeAmount().floatValue());
    }

}
