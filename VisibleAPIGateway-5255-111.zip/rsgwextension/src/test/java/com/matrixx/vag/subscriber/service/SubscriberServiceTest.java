package com.matrixx.vag.subscriber.service;

import static org.junit.Assert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.hamcrest.core.IsEqual;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import com.matrixx.datacontainer.mdc.MtxResponseMulti;
import com.matrixx.datacontainer.mdc.VisibleMultiRequest;
import com.matrixx.datacontainer.mdc.VisibleResponseMulti;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.common.TestConstants.DATA_DIR;
import com.matrixx.vag.exception.InvalidRequestException;
import com.matrixx.vag.util.MDCTest;

public class SubscriberServiceTest extends MDCTest {

	@Spy
	@InjectMocks
	private final SubscriberService instance = new SubscriberService();

	@Before
	public void setUp() throws Exception {
		// instance = new SubscriberService();
		 MockitoAnnotations.openMocks(this); 
	}

	@Test
	public void test_visibleMultiRequest() throws Exception {
		VisibleMultiRequest input = CommonTestHelper.loadJsonMessage(VisibleMultiRequest.class,
				DATA_DIR.SUBSCRIBER_SERVICE + "Subscriber_Create_And_Balance_Setting-Request.json");

		MtxResponseMulti response = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.SUBSCRIBER_SERVICE + "Subscriber_create_With_Main_Balance_Response.json");

		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(response).when(instance).multiRequest(any(), any(), any());

		// method to test
		VisibleResponseMulti output = new VisibleResponseMulti();
		instance.executeMultiRequest(input, output);
		assertThat("Expected success", output.getResult(), IsEqual.equalTo(0L));
		assertThat("Expected success", output.getResultText(), IsEqual.equalTo("OK"));
		assertThat("Expected 2 responses in the list", output.getResponseList().size(), IsEqual.equalTo(2));
		assertThat("Expected that Balance setting is successful", output.getResponseList().get(0).getResult(),
				IsEqual.equalTo(0L));
		assertThat("Expected that Subcriber create is successful", output.getResponseList().get(1).getResult(),
				IsEqual.equalTo(0L));
	}

	@Test(expected = InvalidRequestException.class)
	@Ignore("Find out why there is exception.")
	public void test_visibleMultiRequest_Exceeding_The_Limit() throws Exception {
		VisibleMultiRequest input = CommonTestHelper.loadJsonMessage(VisibleMultiRequest.class,
				DATA_DIR.SUBSCRIBER_SERVICE + "Subscriber_Create_And_Balance_Setting-Request_More Requests.json");

		MtxResponseMulti response = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.SUBSCRIBER_SERVICE + "Subscriber_create_With_Main_Balance_Response_More.json");

		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(response).when(instance).multiRequest(any(), any(), any());

		// method to test
		VisibleResponseMulti output = new VisibleResponseMulti();
		instance.executeMultiRequest(input, output);
	}

	public Map<String, Map<String, Object>> getCreditDataMap() {
		Map<String, Map<String, Object>> creditDataMap = new HashMap<String, Map<String, Object>>();

		ArrayList<String> eligibleOfferList = new ArrayList<String>();
		eligibleOfferList.add("Visible_Unlimited");
		String creditTaxForReferrals = "Tax for referrals";
		String creditTaxForGroup = "Tax for group";
		Map<String, Object> creditDataReferrals = new HashMap<String, Object>();

		creditDataReferrals.put("EligibleOffersList", eligibleOfferList);
		creditDataReferrals.put("RedeemOfferName", "Visible_Redeem_Referral_Credits");
		creditDataReferrals.put("EstimatedTransferableAmount", new BigDecimal(5));
		creditDataReferrals.put("CreditTaxDetails", creditTaxForReferrals);
		creditDataReferrals.put("RedeemableCredits", new BigDecimal(3));
		creditDataReferrals.put("RedeemOfferIndex", 0);

		creditDataMap.put("referral", creditDataReferrals);

		Map<String, Object> creditDataGroup = new HashMap<String, Object>();
		creditDataGroup.put("EligibleOffersList", eligibleOfferList);
		creditDataGroup.put("RedeemOfferName", "Visible_Redeem_Group_Discounts");
		creditDataGroup.put("EstimatedTransferableAmount", new BigDecimal(5));
		creditDataGroup.put("CreditTaxDetails", creditTaxForGroup);
		creditDataGroup.put("RedeemableCredits", new BigDecimal(3));
		creditDataGroup.put("RedeemOfferIndex", 1);

		creditDataMap.put("groupDiscount", creditDataGroup);

		return creditDataMap;

	}

}