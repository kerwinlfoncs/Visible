package com.matrixx.vag.device.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import com.google.gson.JsonObject;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.MtxApiEventDataExtension;
import com.matrixx.datacontainer.mdc.MtxPricingAttrInfo;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferData;
import com.matrixx.datacontainer.mdc.MtxRequest;
import com.matrixx.datacontainer.mdc.MtxRequestMulti;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberModify;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberPurchaseOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberRecharge;
import com.matrixx.datacontainer.mdc.MtxResponseCreate;
import com.matrixx.datacontainer.mdc.MtxResponseMulti;
import com.matrixx.datacontainer.mdc.MtxResponsePricingOffer;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.VisibleApiEventData;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleRechargeExtension;
import com.matrixx.datacontainer.mdc.VisibleRequestFinanceDevice;
import com.matrixx.datacontainer.mdc.VisibleResponseFinanceDevice;
// import com.matrixx.platform.JsonObject;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.common.Constants.DEVICE_CONSTANTS;
import com.matrixx.vag.common.TestConstants.DATA_DIR;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.DeviceServiceException;
import com.matrixx.vag.exception.VisibleUnitTestException;
import com.matrixx.vag.util.MDCTest;

public class FinanceDeviceServiceTest extends MDCTest {

	@Spy
	@InjectMocks
	private DeviceService instance = new DeviceService();

	@Mock
	private SubscriberManagementApi api;

    @Rule
    public TestName testName = new TestName();

	@Before
	public void setUp() throws Exception {
		instance = new DeviceService();
		 MockitoAnnotations.openMocks(this); 

		AppPropertyProvider.getInstance();
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_financeDevice_NoSubscriberData_DeviceServiceException() throws Exception {

		VisibleRequestFinanceDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestFinanceDevice.class,
				DATA_DIR.FINANCED_DEVICE + "VisibleRequestFinanceDevice_ValidRequest.json");
		VisibleResponseFinanceDevice deviceOut = new VisibleResponseFinanceDevice();

		doReturn("").when(instance).getRoute(any());
		doReturn(null).when(instance).querySubscriptionData(any(), any());

        Exception exception = assertThrows(DeviceServiceException.class, () -> instance.financeDevice(deviceIn, deviceOut));
        exception.printStackTrace();
        assertThat(exception.getMessage()).contains("Failed to query subscriber");
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_financeDevice_ErrorMultiResponse_DeviceServiceException() throws Exception {

		VisibleRequestFinanceDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestFinanceDevice.class,
				DATA_DIR.FINANCED_DEVICE + "VisibleRequestFinanceDevice_ValidRequest.json");
		VisibleResponseFinanceDevice deviceOut = new VisibleResponseFinanceDevice();

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.FINANCED_DEVICE + "MtxResponseMulti_ErrorResponse.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.FINANCED_DEVICE + "MtxResponseSubscriber.json");

		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		doReturn(multiRes).when(instance).multiRequest(any(), any(), any());
		
        Exception exception = assertThrows(DeviceServiceException.class, () -> instance.financeDevice(deviceIn, deviceOut));
        exception.printStackTrace();
        assertThat(exception.getMessage()).contains("Failed to finance device");
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_financeDevice_NullMultiResponse_DeviceServiceException() throws Exception {
		VisibleRequestFinanceDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestFinanceDevice.class,
				DATA_DIR.FINANCED_DEVICE + "VisibleRequestFinanceDevice_ValidRequest.json");
		VisibleResponseFinanceDevice deviceOut = new VisibleResponseFinanceDevice();

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.FINANCED_DEVICE + "MtxResponseSubscriber.json");
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		doReturn(null).when(instance).multiRequest(any(), any(), any());

        Exception exception = assertThrows(DeviceServiceException.class, () -> instance.financeDevice(deviceIn, deviceOut));
        exception.printStackTrace();
        assertThat(exception.getMessage()).contains("Failed to finance device");
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_financeDevice_ValidRequestValidMatrixxData_PurchaseSuccess() throws Exception {
		VisibleRequestFinanceDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestFinanceDevice.class,
				DATA_DIR.FINANCED_DEVICE + "VisibleRequestFinanceDevice_ValidRequest.json");

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.FINANCED_DEVICE + "MTXResponseMulti_PurchaseFinanceDevice.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.FINANCED_DEVICE + "MtxResponseSubscriber.json");
		VisibleResponseFinanceDevice deviceOut = new VisibleResponseFinanceDevice();
		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

		// method to test
		instance.financeDevice(deviceIn, deviceOut);
		// Assertions here.
		ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();
		String geoCodeAsTaxString = ((VisiblePurchasedOfferExtension) ((MtxRequestSubscriberPurchaseOffer) reqList
				.get(2)).getOfferRequestArray().get(0).getAttr()).getTaxDetails();
		JsonObject geoCode = new JsonObject();
		geoCode.addProperty(
				AppPropertyProvider.getInstance()
						.getString(DEVICE_CONSTANTS.DEVICE_FINANCE_PURCHASE_SHIPPING_GEOCODE_KEY),
				deviceIn.getFinanceShippingInfo().getShippingGeocode());
		assertEquals(geoCode.toString(), geoCodeAsTaxString);
		assertEquals("0", String.valueOf(deviceOut.getResult()));
		assertEquals("SubscriberExternalID: 12114006001 Matrix Response: OK", deviceOut.getResultText());
		assertEquals(
				multiRes.getResponseList().stream().filter(resp -> resp.getMdcName().equals("MtxResponseCreate"))
						.map(resp -> ((MtxResponseCreate) resp).getObjectId()).toArray()[0].toString(),
				deviceOut.getDeviceInstanceId().toString());
		MtxRequestSubscriberRecharge rechargeReq = (MtxRequestSubscriberRecharge) reqList.get(3);
		VisibleRechargeExtension extn = (VisibleRechargeExtension) rechargeReq.getRechargeAttr();
		assertEquals("0000000001", extn.getOrderId());
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_financeDevice_ValidRequestValidMatrixxData_DistinctTimestamps() throws Exception {
		// Test case to check that 3 info timestamps are different
		VisibleRequestFinanceDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestFinanceDevice.class,
				DATA_DIR.FINANCED_DEVICE + "VisibleRequestFinanceDevice_NSP.json");

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.FINANCED_DEVICE + "MTXResponseMulti_PurchaseFinanceDevice.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.FINANCED_DEVICE + "MtxResponseSubscriber.json");
		VisibleResponseFinanceDevice deviceOut = new VisibleResponseFinanceDevice();

		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
		// method to test
		instance.financeDevice(deviceIn, deviceOut);

		// Assertions here.
		ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();
		String feeTimestamp;
		String deviceTimestamp;
		String shippingTimestamp;
		if (reqList.get(1).getMdcName().equals("MtxRequestSubscriberModify")) {
			feeTimestamp = ((VisiblePurchasedOfferExtension) ((MtxRequestSubscriberPurchaseOffer) reqList.get(2))
					.getOfferRequestArray().get(0).getAttr()).getInfo();
			deviceTimestamp = ((VisiblePurchasedOfferExtension) ((MtxRequestSubscriberPurchaseOffer) reqList.get(4))
					.getOfferRequestArray().get(0).getAttr()).getInfo();
			shippingTimestamp = ((VisiblePurchasedOfferExtension) ((MtxRequestSubscriberPurchaseOffer) reqList.get(6))
					.getOfferRequestArray().get(0).getAttr()).getInfo();
		} else {
			feeTimestamp = ((VisiblePurchasedOfferExtension) ((MtxRequestSubscriberPurchaseOffer) reqList.get(1))
					.getOfferRequestArray().get(0).getAttr()).getInfo();
			deviceTimestamp = ((VisiblePurchasedOfferExtension) ((MtxRequestSubscriberPurchaseOffer) reqList.get(3))
					.getOfferRequestArray().get(0).getAttr()).getInfo();
			shippingTimestamp = ((VisiblePurchasedOfferExtension) ((MtxRequestSubscriberPurchaseOffer) reqList.get(5))
					.getOfferRequestArray().get(0).getAttr()).getInfo();
		}

		assertNotEquals(feeTimestamp, deviceTimestamp);
		assertNotEquals(feeTimestamp, shippingTimestamp);
		assertNotEquals(shippingTimestamp, deviceTimestamp);
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_financeDevice_CorrectRsGatewayProperties_GoodTypesAsExpected() throws Exception {
		// Test case to check that GoodTypes are populated correctly
		VisibleRequestFinanceDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestFinanceDevice.class,
				DATA_DIR.FINANCED_DEVICE + "VisibleRequestFinanceDevice_NSP.json");

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.FINANCED_DEVICE + "MTXResponseMulti_PurchaseFinanceDevice.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.FINANCED_DEVICE + "MtxResponseSubscriber.json");
		VisibleResponseFinanceDevice deviceOut = new VisibleResponseFinanceDevice();

		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
		// method to test
		instance.financeDevice(deviceIn, deviceOut);

		// Assertions here.
		ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();

		String feeGoodtype;
		String deviceGoodtype;
		String shippingGoodtype;

		feeGoodtype = reqList.stream().filter(req -> req.getMdcName().equals("MtxRequestSubscriberPurchaseOffer"))
				.map(req -> ((VisiblePurchasedOfferExtension) ((MtxRequestSubscriberPurchaseOffer) req)
						.getOfferRequestArray().get(0).getAttr()))
				.filter(vpoXtn -> vpoXtn.getGoodType() != null && vpoXtn.getGoodType().equals("affirm_fee"))
				.map(vpoXtn -> vpoXtn.getGoodType()).findFirst().get();

		deviceGoodtype = reqList.stream().filter(req -> req.getMdcName().equals("MtxRequestSubscriberPurchaseOffer"))
				.map(req -> ((VisiblePurchasedOfferExtension) ((MtxRequestSubscriberPurchaseOffer) req)
						.getOfferRequestArray().get(0).getAttr()))
				.filter(vpoXtn -> vpoXtn.getGoodType() != null && vpoXtn.getGoodType().equals("finance_device"))
				.map(vpoXtn -> vpoXtn.getGoodType()).findFirst().get();
		shippingGoodtype = reqList.stream().filter(req -> req.getMdcName().equals("MtxRequestSubscriberPurchaseOffer"))
				.map(req -> ((VisiblePurchasedOfferExtension) ((MtxRequestSubscriberPurchaseOffer) req)
						.getOfferRequestArray().get(0).getAttr()))
				.filter(vpoXtn -> vpoXtn.getGoodType() != null && vpoXtn.getGoodType().equals("finance_shipping"))
				.map(vpoXtn -> vpoXtn.getGoodType()).findFirst().get();

		assertNotNull("Goodtype affirm_fee not found", feeGoodtype);
		assertEquals("affirm_fee", feeGoodtype);

		assertNotNull("Goodtype finance_device not found", deviceGoodtype);
		assertEquals("finance_device", deviceGoodtype);

		assertNotNull("Goodtype finance_shipping not found", shippingGoodtype);
		assertEquals("finance_shipping", shippingGoodtype);
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_financeDevice_CorrectRsGatewayProperties_ReasonsAsExpected() throws Exception {
		// Test case to check that Reasons are populated correctly
		VisibleRequestFinanceDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestFinanceDevice.class,
				DATA_DIR.FINANCED_DEVICE + "VisibleRequestFinanceDevice_NSP.json");

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.FINANCED_DEVICE + "MTXResponseMulti_PurchaseFinanceDevice.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.FINANCED_DEVICE + "MtxResponseSubscriber.json");
		VisibleResponseFinanceDevice deviceOut = new VisibleResponseFinanceDevice();

		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
		// method to test
		instance.financeDevice(deviceIn, deviceOut);

		// Assertions here.
		ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();

		String deviceReason;
		String shippingReason;

		if (reqList.get(1).getMdcName().equals("MtxRequestSubscriberModify")) {
			deviceReason = ((MtxRequestSubscriberRecharge) reqList.get(3)).getReason();
			shippingReason = ((MtxRequestSubscriberRecharge) reqList.get(5)).getReason();

		} else {
			deviceReason = ((MtxRequestSubscriberRecharge) reqList.get(2)).getReason();
			shippingReason = ((MtxRequestSubscriberRecharge) reqList.get(4)).getReason();
		}

		assertEquals("finance_device", deviceReason);
		assertEquals("finance_shipping", shippingReason);
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_financeDevice_CorrectRsGatewayProperties_RechargePurchaseCorrelationAsExpected() throws Exception {
		// Test case to check that info fields of purchase and recharge are paired up
		// correctly
		VisibleRequestFinanceDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestFinanceDevice.class,
				DATA_DIR.FINANCED_DEVICE + "VisibleRequestFinanceDevice_NSP.json");

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.FINANCED_DEVICE + "MTXResponseMulti_PurchaseFinanceDevice.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.FINANCED_DEVICE + "MtxResponseSubscriber.json");
		VisibleResponseFinanceDevice deviceOut = new VisibleResponseFinanceDevice();

		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
		// method to test
		instance.financeDevice(deviceIn, deviceOut);

		// Assertions here.
		ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();
		String deviceGoodtype;
		String shippingGoodtype;
		String devicePurchaseInfo;
		String shippingPurchaseInfo;

		String deviceReason;
		String shippingReason;
		String deviceRechargeInfoTimestamp;
		String shippingRechargeInfoTimestamp;

		if (reqList.get(1).getMdcName().equals("MtxRequestSubscriberModify")) {

			deviceGoodtype = ((VisiblePurchasedOfferExtension) ((MtxRequestSubscriberPurchaseOffer) reqList.get(4))
					.getOfferRequestArray().get(0).getAttr()).getGoodType();
			shippingGoodtype = ((VisiblePurchasedOfferExtension) ((MtxRequestSubscriberPurchaseOffer) reqList.get(6))
					.getOfferRequestArray().get(0).getAttr()).getGoodType();
			devicePurchaseInfo = ((VisiblePurchasedOfferExtension) ((MtxRequestSubscriberPurchaseOffer) reqList.get(4))
					.getOfferRequestArray().get(0).getAttr()).getInfo();
			shippingPurchaseInfo = ((VisiblePurchasedOfferExtension) ((MtxRequestSubscriberPurchaseOffer) reqList
					.get(6)).getOfferRequestArray().get(0).getAttr()).getInfo();

			deviceReason = ((MtxRequestSubscriberRecharge) reqList.get(3)).getReason();
			shippingReason = ((MtxRequestSubscriberRecharge) reqList.get(5)).getReason();

			deviceRechargeInfoTimestamp = ((MtxRequestSubscriberRecharge) reqList.get(3)).getInfo();

			shippingRechargeInfoTimestamp = ((MtxRequestSubscriberRecharge) reqList.get(5)).getInfo();

		} else {

			deviceGoodtype = ((VisiblePurchasedOfferExtension) ((MtxRequestSubscriberPurchaseOffer) reqList.get(3))
					.getOfferRequestArray().get(0).getAttr()).getGoodType();
			shippingGoodtype = ((VisiblePurchasedOfferExtension) ((MtxRequestSubscriberPurchaseOffer) reqList.get(5))
					.getOfferRequestArray().get(0).getAttr()).getGoodType();
			devicePurchaseInfo = ((VisiblePurchasedOfferExtension) ((MtxRequestSubscriberPurchaseOffer) reqList.get(3))
					.getOfferRequestArray().get(0).getAttr()).getInfo();
			shippingPurchaseInfo = ((VisiblePurchasedOfferExtension) ((MtxRequestSubscriberPurchaseOffer) reqList
					.get(5)).getOfferRequestArray().get(0).getAttr()).getInfo();

			deviceReason = ((MtxRequestSubscriberRecharge) reqList.get(2)).getReason();
			shippingReason = ((MtxRequestSubscriberRecharge) reqList.get(4)).getReason();

			deviceRechargeInfoTimestamp = ((MtxRequestSubscriberRecharge) reqList.get(2)).getInfo();

			shippingRechargeInfoTimestamp = ((MtxRequestSubscriberRecharge) reqList.get(4)).getInfo();
		}

		assertEquals(deviceReason, deviceGoodtype);
		assertEquals(shippingReason, shippingGoodtype);
		assertEquals(devicePurchaseInfo, deviceRechargeInfoTimestamp);
		assertEquals(shippingPurchaseInfo, shippingRechargeInfoTimestamp);
	}

	@Test // MethodName_StateUnderTest_ExpectedBehavior
	public void test_financeDevice_OrderIdInRequest_RechargeInfoOrderIdInInfo() throws Exception {
		// Test case to check that info fields of purchase and recharge are paired up
		// correctly
		String testLoggingKey = getTestLoggingKey(testName.getMethodName());
		
		VisibleRequestFinanceDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestFinanceDevice.class,
				DATA_DIR.FINANCED_DEVICE + "VisibleRequestFinanceDevice_NSP.json");
		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.FINANCED_DEVICE + "MTXResponseMulti_PurchaseFinanceDevice.json");
		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.FINANCED_DEVICE + "MtxResponseSubscriber.json");
		VisibleResponseFinanceDevice deviceOut = new VisibleResponseFinanceDevice();
		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
		// method to test
		instance.financeDevice(deviceIn, deviceOut);
		// Assertions here.
		ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();

		System.out.println(testLoggingKey+StringUtils.SPACE+ argumentCaptor.getValue());

		String deviceRechargeInfoOrderId = argumentCaptor.getValue().getRequestList().stream()
				.filter(req->req.getMdcName().equals(MtxRequestSubscriberRecharge.class.getSimpleName()))
				.map(req->(MtxRequestSubscriberRecharge)req)
				.filter(recharge->recharge.getReason().equals("finance_device"))
				.map(recharge-> (VisibleRechargeExtension)recharge.getRechargeAttr())
				.findAny().get().getOrderId();
		
		String shippingRechargeInfoOrderId= argumentCaptor.getValue().getRequestList().stream()
				.filter(req->req.getMdcName().equals(MtxRequestSubscriberRecharge.class.getSimpleName()))
				.map(req->(MtxRequestSubscriberRecharge)req)
				.filter(recharge->recharge.getReason().equals("finance_shipping"))
				.map(recharge-> (VisibleRechargeExtension)recharge.getRechargeAttr())
				.findAny().get().getOrderId();
		assertEquals(deviceIn.getFinanceOrderInfo().getOrderId(), deviceRechargeInfoOrderId);
		assertEquals(deviceIn.getFinanceOrderInfo().getOrderId(), shippingRechargeInfoOrderId);
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_financeDevice_HomeBidDifferentShipToBid_HomeBidDifferentGLCenter_GLCenterChangeAndUndo()
			throws Exception {
		// Test case to check that GoodTypes are populated correctly
		VisibleRequestFinanceDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestFinanceDevice.class,
				DATA_DIR.FINANCED_DEVICE + "VisibleRequestFinanceDevice_NSP.json");

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.FINANCED_DEVICE + "MTXResponseMulti_PurchaseFinanceDevice.json");

		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.FINANCED_DEVICE + "MtxResponseSubscriber.json");

		VisibleResponseFinanceDevice deviceOut = new VisibleResponseFinanceDevice();

		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());

		// Capture Arguements for multirequest
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
		// method to test
		instance.financeDevice(deviceIn, deviceOut);

		// Assertions here.
		ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();

		// First Modify request should change GLCenter as per ShipToBID
		assertEquals(deviceIn.getFinanceShippingInfo().getShipToBid(),
				((MtxRequestSubscriberModify) reqList.get(1)).getGlCenter());

		// Last Modify request should restore original GLCenter
		assertEquals(subRes.getGlCenter(), ((MtxRequestSubscriberModify) reqList.get(7)).getGlCenter());
	}

	/**
	 * Loads a template pricing offer JSON data file and sets the attributes with
	 * the test attributes
	 *
	 * @param templateFilePath
	 * @param testAtrrValues   the test attributes
	 * @return pricing offer
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws IOException
	 * @throws VisibleUnitTestException 
	 */
	protected MtxResponsePricingOffer preparePricingOfferData(String templateFilePath,
			Map<String, String> testAtrrValues) throws IOException, VisibleUnitTestException {

		MtxResponsePricingOffer pricingOffer = CommonTestHelper.loadJsonMessage(MtxResponsePricingOffer.class,
				templateFilePath);
		for (MtxPricingAttrInfo attrInfo : pricingOffer.getOfferInfo().getAttrList()) {
			String propertyName = attrInfo.getName();
			String expectedValue = testAtrrValues.get(propertyName);
			// overwrite with the expected value.
			if (expectedValue != null) {
				attrInfo.setValue(expectedValue);
				testAtrrValues.remove(propertyName);
			}
		}

		// For the remianing attributes, add to the pricing offer
		for (Entry<String, String> entrySet : testAtrrValues.entrySet()) {
			MtxPricingAttrInfo attrInfo = new MtxPricingAttrInfo();
			attrInfo.setName(entrySet.getKey());
			attrInfo.setValue(entrySet.getValue());
			pricingOffer.getOfferInfo().appendAttrList(attrInfo);
		}
		return pricingOffer;
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_financeDevice_NoShippingGeoCode_PurchaseSuccess() throws Exception {
		VisibleRequestFinanceDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestFinanceDevice.class,
				DATA_DIR.FINANCED_DEVICE + "VisibleRequestFinanceDevice_No_shippingGeoCode.json");

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.FINANCED_DEVICE + "MTXResponseMulti_PurchaseFinanceDevice.json");
		deviceIn.getFinanceShippingInfo().setShippingGeocode("");
		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.FINANCED_DEVICE + "MtxResponseSubscriber.json");
		VisibleResponseFinanceDevice deviceOut = new VisibleResponseFinanceDevice();
		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

		// method to test
		instance.financeDevice(deviceIn, deviceOut);
		// Assertions here.
		ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();
		assertNull(((VisiblePurchasedOfferExtension) ((MtxRequestSubscriberPurchaseOffer) reqList.get(2))
				.getOfferRequestArray().get(0).getAttr()).getTaxDetails());
		assertEquals("0", String.valueOf(deviceOut.getResult()));
		assertEquals("SubscriberExternalID: 12114006001 Matrix Response: OK", deviceOut.getResultText());
	}
	
	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_financeDevice_DeviceAttributesPassed_AttributesSentToPurchaseOffer() throws Exception {
		System.out.println("Test Case for https://jira.unico.com.au/browse/MTXTAX-1551 https://matrixxservices.atlassian.net/browse/VER-18");
		VisibleRequestFinanceDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestFinanceDevice.class,
				DATA_DIR.FINANCED_DEVICE + "VisibleRequestFinanceDevice_ValidRequest.json");

		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.FINANCED_DEVICE + "MTXResponseMulti_PurchaseFinanceDevice.json");
		deviceIn.getFinanceShippingInfo().setShippingGeocode("");
		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.FINANCED_DEVICE + "MtxResponseSubscriber.json");
		VisibleResponseFinanceDevice deviceOut = new VisibleResponseFinanceDevice();
		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

		// method to test
		instance.financeDevice(deviceIn, deviceOut);
		assertTrue(	argumentCaptor.getValue().getRequestList().stream()
						.filter(req->req.getContainer().getName().equals(MtxRequestSubscriberPurchaseOffer.class.getSimpleName()))
						.filter(req->((MtxRequestSubscriberPurchaseOffer)req).getAtOfferRequestArray(0).getExternalId().equals("Visible_Device"))
						.count()>0);
		
		// Assertions here.
		ArrayList<MtxRequest> reqList = argumentCaptor.getValue().getRequestList();
		reqList.forEach(req ->{
			if(req.getContainer().getName().equals(MtxRequestSubscriberPurchaseOffer.class.getSimpleName())) {
				if(((MtxRequestSubscriberPurchaseOffer)req).getAtOfferRequestArray(0).getExternalId().equals("Visible_Device")) {
					MtxPurchasedOfferData offer = ((MtxRequestSubscriberPurchaseOffer)req).getAtOfferRequestArray(0);
					VisiblePurchasedOfferExtension xtn = (VisiblePurchasedOfferExtension)offer.getAttr();
					assertEquals(deviceIn.getFinanceOrderInfo().getOrderId(), xtn.getOrderId());
					assertEquals(deviceIn.getFinanceOrderInfo().getParentOrderId(),xtn.getParentOrderId());
					assertEquals(deviceIn.getFinanceOrderInfo().getChargeId(), xtn.getChargeId());
					assertEquals(deviceIn.getFinanceOrderInfo().getLoanId(), xtn.getLoanId());
					assertEquals(deviceIn.getFinanceOrderInfo().getPOSLocationCode(),xtn.getPOSLocationCode());
					assertEquals(deviceIn.getFinanceDeviceInfo().getDeviceAttr1(), xtn.getDeviceAttr1());
					assertEquals(deviceIn.getFinanceDeviceInfo().getDeviceAttr2(), xtn.getDeviceAttr2());		
					assertEquals(deviceIn.getFinanceDeviceInfo().getDeviceDetails(), xtn.getDeviceDetails());
					assertEquals(deviceIn.getFinanceDeviceInfo().getDeviceSku(), xtn.getSku());
					assertEquals(deviceIn.getFinanceDeviceInfo().getDeviceTaxDetails(), xtn.getTaxDetails());
				}	
			};			
		});
	}
	
	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_financeDevice_When_ApiEventData_IsNotEmpty_Then_ApiEventData_SentToEngine() throws Exception {
		System.out.println("Test Case for https://jira.unico.com.au/browse/MTXVER2-56 https://matrixxservices.atlassian.net/browse/VER-35");
		String testLoggingKey = getTestLoggingKey(testName.getMethodName());
		VisibleRequestFinanceDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestFinanceDevice.class,
				DATA_DIR.FINANCED_DEVICE + "VisibleRequestFinanceDevice_ValidRequest.json");
		VisibleApiEventData extn = new VisibleApiEventData();
		extn.setOrderId("12345");
		deviceIn.setApiEventData(extn);
		
		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.FINANCED_DEVICE + "MTXResponseMulti_PurchaseFinanceDevice.json");
		deviceIn.getFinanceShippingInfo().setShippingGeocode("");
		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.FINANCED_DEVICE + "MtxResponseSubscriber.json");
		VisibleResponseFinanceDevice deviceOut = new VisibleResponseFinanceDevice();
		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

		// method to test
		instance.financeDevice(deviceIn, deviceOut);
		System.out.println(testLoggingKey+StringUtils.SPACE+ argumentCaptor.getValue().toJson());
		// Assertions here.
		assertEquals(
				MtxApiEventDataExtension.class.getSimpleName()+" should be present.",
				extn.getMdcName(),
				argumentCaptor.getValue().getApiEventData().getMdcName());
		assertEquals(extn.getOrderId(),
				((VisibleApiEventData)argumentCaptor.getValue().getApiEventData()).getOrderId()	);
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_financeDevice_When_ApiEventData_IsEmpty_Then_ApiEventData_NotSentToEngine() throws Exception {
		System.out.println("Test Case for https://jira.unico.com.au/browse/MTXVER2-56 https://matrixxservices.atlassian.net/browse/VER-35");
		String testLoggingKey = getTestLoggingKey(testName.getMethodName());
		VisibleRequestFinanceDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestFinanceDevice.class,
				DATA_DIR.FINANCED_DEVICE + "VisibleRequestFinanceDevice_ValidRequest.json");
		MtxApiEventDataExtension extn = new MtxApiEventDataExtension();
		deviceIn.setApiEventData(extn);
		
		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.FINANCED_DEVICE + "MTXResponseMulti_PurchaseFinanceDevice.json");
		deviceIn.getFinanceShippingInfo().setShippingGeocode("");
		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.FINANCED_DEVICE + "MtxResponseSubscriber.json");
		VisibleResponseFinanceDevice deviceOut = new VisibleResponseFinanceDevice();
		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

		// method to test
		instance.financeDevice(deviceIn, deviceOut);
		System.out.println(testLoggingKey+StringUtils.SPACE+ argumentCaptor.getValue().toJson());
		System.out.println(testLoggingKey+StringUtils.SPACE+ argumentCaptor.getValue().getApiEventData().getContainer().getFields());
		System.out.println(testLoggingKey+StringUtils.SPACE+ argumentCaptor.getValue().getApiEventData().getContainer().getName());
		// Assertions here.
		assertEquals(
				MtxApiEventDataExtension.class.getSimpleName()+" should be present.",
				MtxApiEventDataExtension.class.getSimpleName(),
				argumentCaptor.getValue().getApiEventData().getMdcName());

		assertEquals(
				MtxApiEventDataExtension.class.getSimpleName()+" should be empty.",
				0,
				argumentCaptor.getValue().getApiEventData().getContainer().getFields()==null?0:argumentCaptor.getValue().getApiEventData().getContainer().getFields().size());
	}

	@Test
	// MethodName_StateUnderTest_ExpectedBehavior
	public void test_financeDevice_When_ApiEventData_IsMissing_Then_ApiEventData_NotSentToEngine() throws Exception {
		System.out.println("Test Case for https://jira.unico.com.au/browse/MTXVER2-56 https://matrixxservices.atlassian.net/browse/VER-35");
		String testLoggingKey = getTestLoggingKey(testName.getMethodName());
		VisibleRequestFinanceDevice deviceIn = CommonTestHelper.loadJsonMessage(VisibleRequestFinanceDevice.class,
				DATA_DIR.FINANCED_DEVICE + "VisibleRequestFinanceDevice_ValidRequest.json");
		
		MtxResponseMulti multiRes = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class,
				DATA_DIR.FINANCED_DEVICE + "MTXResponseMulti_PurchaseFinanceDevice.json");
		deviceIn.getFinanceShippingInfo().setShippingGeocode("");
		MtxResponseSubscription subRes = CommonTestHelper.loadJsonMessage(MtxResponseSubscription.class,
				DATA_DIR.FINANCED_DEVICE + "MtxResponseSubscriber.json");
		VisibleResponseFinanceDevice deviceOut = new VisibleResponseFinanceDevice();
		// mocks
		doReturn("").when(instance).getRoute(any());
		doReturn(subRes).when(instance).querySubscriptionData(any(), any());
		ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(MtxRequestMulti.class);
		doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

		// method to test
		instance.financeDevice(deviceIn, deviceOut);
		System.out.println(testLoggingKey+StringUtils.SPACE+ argumentCaptor.getValue().toJson());
		// Assertions here.
		assertEquals(
				MtxApiEventDataExtension.class.getSimpleName()+" should not be present.",
				null,
				argumentCaptor.getValue().getApiEventData());
	}

}
