package com.matrixx.vag.advice.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.doReturn;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.MtxBalanceImpactInfo;
import com.matrixx.datacontainer.mdc.MtxBalanceInfo;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.MtxRequiredBalanceInfo;
import com.matrixx.datacontainer.mdc.MtxResponsePurchase;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.PurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.SubscriptionResponse;
import com.matrixx.datacontainer.mdc.VisibleOfferDetails;
import com.matrixx.datacontainer.mdc.VisibleRequestChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleResponseChangeServiceAdvice;
import com.matrixx.vag.CommonTestHelper;

import com.matrixx.vag.TestDescription;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.CREDIT_CONSTANTS;
import com.matrixx.vag.common.OneParameterTest;
import com.matrixx.vag.common.TestConstants.BALANCE_NAMES;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestConstants.DATA_DIR;
import com.matrixx.vag.common.TestUtils;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.tax.client.TaxApiClient;
import com.matrixx.vag.util.MDCTest;

public class CsaGlobalPassTest extends MDCTest {

    @Spy
    @InjectMocks
    private PaymentAdviceService instance = new PaymentAdviceService();

    @Mock
    private SubscriberManagementApi api;

    private TestInfo testInfo;

    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        instance = new PaymentAdviceService();
        MockitoAnnotations.openMocks(this);
        doReturn("").when(instance).getRoute(any());
        this.testInfo = testInfo;
    }

    @ParameterizedTest(name = "test_getChangeServiceAdvice_When_GPs_Not_Exist_Then_AsIs_Has_No_GPs")
    @Tag("VER-621")
    @Tag("2023/2.0")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has base monthly. Has no global passes.|"
                +"|When  |Api is called to change offer.|"
                +"|Then  |AS-IS offer should NOT show existing global passes.|"})
    // @formatter:on           
    public void test_getChangeServiceAdvice_When_GPs_Not_Exist_Then_AsIs_Has_No_GPs(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        @SuppressWarnings("unchecked")
        OneParameterTest pTests = (tc) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions) tc;
            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(tCon.newCi);
            request.setDiscountPrice(tCon.getNewCiPrice());
            request.setGrossPrice(tCon.getNewCiPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(Arrays.asList(tCon.oldCi)));
            MtxBalanceInfo gpBalance = CommonTestHelper.getMtxBalanceInfo(
                    BALANCE_NAMES.GLOBAL_PASS, null, null, BigDecimal.valueOf(10000000000000D),
                    BigDecimal.ZERO);
            subscription.getBalanceArrayAppender().add(gpBalance);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            subscription.getExternalId(), Arrays.asList(tCon.oldCi)));

            emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(tCon.oldCi, tCon.newCi));

            VisibleOfferDetails vodAsIs = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    tCon.oldCi);
            vodAsIs.setConsumableMainBalanceAmount(tCon.getOldCiPrice());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscription, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodAsIs.getCatalogItemExternalId(), Long.valueOf(vodAsIs.getResourceId()),
                    vodAsIs);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            Map<String, BigDecimal> balImpactMap = new HashMap<String, BigDecimal>();
            balImpactMap.put("Visible_MultiMonth_Counter", BigDecimal.ONE);
            balImpactMap.put(BALANCE_NAMES.GLOBAL_PASS, BigDecimal.valueOf(1));

            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ONE, null, balImpactMap,
                    true);
            System.out.println(td.getTestMethod() + ":" + deltaAocResp.toJson());

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            String taxApiResp = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxApiResp);
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());

            assertNull(response.getCurrentCatalogItem().getAttributes());
        };

        TestConditions tc1 = new TestConditions(CI_EXTERNAL_IDS.BASE3VIS23, CI_EXTERNAL_IDS.PLUS3VIS23);
        pTests.test(tc1);
    }

    @ParameterizedTest(name = "test_getChangeServiceAdvice_When_GPs_Exist_Then_AsIs_Has_GPs")
    @Tag("VER-621")
    @Tag("2023/2.0")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has plus monthly. Has some global passes.|"
                +"|When  |Api is called to change offer.|"
                +"|Then  |AS-IS offer should show existing global passes.|"})
    // @formatter:on           
    public void test_getChangeServiceAdvice_When_GPs_Exist_Then_AsIs_Has_GPs(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        @SuppressWarnings("unchecked")
        OneParameterTest pTests = (tc) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions) tc;
            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(tCon.newCi);
            request.setDiscountPrice(tCon.getNewCiPrice());
            request.setGrossPrice(tCon.getNewCiPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(Arrays.asList(tCon.oldCi)));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            subscription.getExternalId(), Arrays.asList(tCon.oldCi)));
            subscriptionResponse.getWalletBalances().stream().filter(
                    bi -> bi.getName().equalsIgnoreCase(
                            BALANCE_NAMES.GLOBAL_PASS)).findFirst().get().setAmount(BigDecimal.TEN);

            emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(tCon.oldCi, tCon.newCi));

            VisibleOfferDetails vodAsIs = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    tCon.oldCi);
            vodAsIs.setConsumableMainBalanceAmount(tCon.getOldCiPrice());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscription, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodAsIs.getCatalogItemExternalId(), Long.valueOf(vodAsIs.getResourceId()),
                    vodAsIs);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                    tCon.newCi);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());
            String taxApiResp = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxApiResp);
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            String expectedGP = subscriptionResponse.getWalletBalances().stream().filter(
                    bi -> bi.getName().equalsIgnoreCase(
                            BALANCE_NAMES.GLOBAL_PASS)).findFirst().get().getAmount().toPlainString();
            assertEquals(
                    expectedGP, response.getCurrentCatalogItem().getAtAttributes(0).getValue());
        };
        TestConditions tc1 = new TestConditions(CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.BASE3VIS23);
        pTests.test(tc1);
    }

    @ParameterizedTest(name = "test_getChangeServiceAdvice_When_ToBe_gives_GPs_Then_ToBe_Has_GPs")
    @Tag("VER-621")
    @Tag("2023/2.0")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has NO glabal passes. Plus offers provide global pass on purchase.|"
                +"|When  |Api is called to change to plus offer.|"
                +"|Then  |TO-BE offer should show new global passes.|"})
    // @formatter:on           
    public void test_getChangeServiceAdvice_When_ToBe_gives_GPs_Then_ToBe_Has_GPs(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        OneParameterTest pTests = (tc) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions) tc;
            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(tCon.newCi);
            request.setDiscountPrice(tCon.getNewCiPrice());
            request.setGrossPrice(tCon.getNewCiPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(Arrays.asList(tCon.oldCi)));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            subscription.getExternalId(), Arrays.asList(tCon.oldCi)));

            emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(tCon.oldCi, tCon.newCi));

            VisibleOfferDetails vodAsIs = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    tCon.oldCi);
            vodAsIs.setConsumableMainBalanceAmount(tCon.getOldCiPrice());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscription, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodAsIs.getCatalogItemExternalId(), Long.valueOf(vodAsIs.getResourceId()),
                    vodAsIs);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            Map<String, BigDecimal> balImpactMap = new HashMap<String, BigDecimal>();
            balImpactMap.put(BALANCE_NAMES.MAIN_BALANCE, request.getDiscountPrice());
            balImpactMap.put(BALANCE_NAMES.COUNTER_MULTIMONTH, BigDecimal.ONE);
            balImpactMap.put(BALANCE_NAMES.GLOBAL_PASS, BigDecimal.valueOf(12));

            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ONE, null, balImpactMap,
                    true);
            System.out.println(td.getTestMethod() + ":" + deltaAocResp.toJson());

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            String taxApiResp = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxApiResp);
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            String expectedGP = deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactList().stream().filter(
                            bii -> bii.getBalanceTemplateName().equalsIgnoreCase(
                                    BALANCE_NAMES.GLOBAL_PASS)).findFirst().get().getImpactAmount()
                    + "";
            assertEquals(expectedGP, response.getNewCatalogItem().getAtAttributes(0).getValue());
        };
        TestConditions tc1 = new TestConditions(CI_EXTERNAL_IDS.BASE3VIS23, CI_EXTERNAL_IDS.PLUS3ANNUAL);
        pTests.test(tc1);

    }

    @ParameterizedTest(
            name = "test_getChangeServiceAdvice_When_C2CAnnualUpgrade_Then_ToBe_Prorated_GPs")
    @Tag("VER-621")
    @Tag("2023/2.0")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has NO glabal passes. Has BaseAnnual offer. PlusAnnual offers provide global pass on purchase.|"
                +"|When  |Api is called to change to plus annual offer.|"
                +"|Then  |TO-BE offer should show prorated global passes.|"})
    // @formatter:on           
    public void test_getChangeServiceAdvice_When_C2CAnnualUpgrade_Then_ToBe_Prorated_GPs(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        OneParameterTest pTests = (tc) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions) tc;
            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(tCon.newCi);
            request.setDiscountPrice(tCon.getNewCiPrice());
            request.setGrossPrice(tCon.getNewCiPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(Arrays.asList(tCon.oldCi)));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            subscription.getExternalId(), Arrays.asList(tCon.oldCi)));

            emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(tCon.oldCi, tCon.newCi));

            VisibleOfferDetails vodAsIs = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    tCon.oldCi);
            vodAsIs.setConsumableMainBalanceAmount(tCon.getOldCiPrice());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscription, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodAsIs.getCatalogItemExternalId(), Long.valueOf(vodAsIs.getResourceId()),
                    vodAsIs);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            Map<String, BigDecimal> balImpactMap = new HashMap<String, BigDecimal>();
            balImpactMap.put("Visible_MultiMonth_Counter", BigDecimal.ONE);
            balImpactMap.put(BALANCE_NAMES.GLOBAL_PASS, BigDecimal.valueOf(12));

            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ONE, null, balImpactMap,
                    true);
            System.out.println(td.getTestMethod() + ":" + deltaAocResp.toJson());

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            String taxApiResp = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxApiResp);
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            String expectedGP = 12 + "";
            assertEquals(expectedGP, response.getNewCatalogItem().getAtAttributes(0).getValue());
        };
        TestConditions tc1 = new TestConditions(CI_EXTERNAL_IDS.BASE3ANNUAL, CI_EXTERNAL_IDS.PLUS3ANNUAL);
        pTests.test(tc1);
    }

    @ParameterizedTest(
            name = "test_getChangeServiceAdvice_When_C2CAnnualUpgrade_PartialMonth_Then_Prorate_Ceil_GPs")
    @Tag("VER-621")
    @Tag("2023/2.0")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has NO glabal passes. Has BaseAnnual offer. PlusAnnual offers provide global pass on purchase.|"
                +"|When  |Api is called to change to plus annual offer.|"
                +"|Then  |TO-BE offer should show prorated global passes.,Partial month should be considered as full month for global pass.|"})
    // @formatter:on           
    public void test_getChangeServiceAdvice_When_C2CAnnualUpgrade_PartialMonth_Then_Prorate_Ceil_GPs(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        OneParameterTest pTests = (tc) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions) tc;
            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(tCon.newCi);
            request.setDiscountPrice(tCon.getNewCiPrice());
            request.setGrossPrice(tCon.getNewCiPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(Arrays.asList(tCon.oldCi)));
            MtxPurchasedOfferInfo poEnrolled = subscription.getAtPurchasedOfferArray(0);
            MtxTimestamp tsToday = MtxTimestamp.ofEpochMilli(
                    CommonUtils.getCurrentTimeMillis(),
                    poEnrolled.getCycleInfo().getCycleStartTime());
            // ideally get number days in month work out from there.
            MtxTimestamp tsEnd = TestUtils.addMonths(tsToday, 2);
            tsEnd = TestUtils.addDays(tsEnd, 2);
            poEnrolled.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
            poEnrolled.getCycleInfo().setCycleEndTime(tsEnd);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            subscription.getExternalId(), Arrays.asList(tCon.oldCi)));
            subscriptionResponse.setTimeZone("Australia/Melbourne");
            MtxPurchasedOfferInfo poiEnrolled = subscriptionResponse.getAtPurchasedOfferArray(0);
            // ideally get number days in month work out from there.
            poiEnrolled.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
            poiEnrolled.getCycleInfo().setCycleEndTime(tsEnd);

            System.out.println(subscriptionResponse.toJson());

            emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(tCon.oldCi, tCon.newCi));

            VisibleOfferDetails vodAsIs = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    tCon.oldCi);
            vodAsIs.setConsumableMainBalanceAmount(tCon.getOldCiPrice());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscription, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodAsIs.getCatalogItemExternalId(), Long.valueOf(vodAsIs.getResourceId()),
                    vodAsIs);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            Map<String, BigDecimal> balImpactMap = new HashMap<String, BigDecimal>();
            balImpactMap.put("Visible_MultiMonth_Counter", BigDecimal.ONE);
            balImpactMap.put(BALANCE_NAMES.GLOBAL_PASS, BigDecimal.valueOf(12));

            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ONE, null, balImpactMap,
                    true);
            System.out.println(td.getTestMethod() + ":" + deltaAocResp.toJson());

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            String taxApiResp = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxApiResp);
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            String expectedGP = 3 + "";
            assertEquals(expectedGP, response.getNewCatalogItem().getAtAttributes(0).getValue());
        };
        TestConditions tc1 = new TestConditions(CI_EXTERNAL_IDS.BASE3ANNUAL, CI_EXTERNAL_IDS.PLUS3ANNUAL);
        pTests.test(tc1);
    }

    @Disabled("With Curly offers now pricing decides on final GPs and Bapi does not add old and new gps when change is effective next month.")
    @ParameterizedTest(
            name = "test_getChangeServiceAdvice_When_Gps_Exist_and_ToBe_gives_GPs_Then_ToBe_Has_GPs")
    @Tag("VER-621")
    @Tag("2023/2.0")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription HAS global passes., PLUS offer provides global pass on purchase.|"
                +"|When  |Api is called to change to plus offer.|"
                +"|Then  |TO-BE offer should show existing+new global passes.|"})
    // @formatter:on           
    public void test_getChangeServiceAdvice_When_Gps_Exist_and_ToBe_gives_GPs_Then_ToBe_Has_GPs(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        OneParameterTest pTests = (tc) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions) tc;
            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(tCon.newCi);
            request.setDiscountPrice(tCon.getNewCiPrice());
            request.setGrossPrice(tCon.getNewCiPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            BigDecimal currentGP = BigDecimal.valueOf(5);
            BigDecimal newGP = BigDecimal.ONE;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(Arrays.asList(tCon.oldCi)));
            subscription.getBalanceArray().stream().filter(
                    bi -> bi.getName().equalsIgnoreCase(
                            BALANCE_NAMES.GLOBAL_PASS)).findFirst().get().setAmount(currentGP);

            MtxPurchasedOfferInfo poEnrolled = subscription.getAtPurchasedOfferArray(0);
            MtxTimestamp tsToday = MtxTimestamp.ofEpochMilli(
                    CommonUtils.getCurrentTimeMillis(),
                    poEnrolled.getCycleInfo().getCycleStartTime());
            // ideally get number days in month work out from there.
            MtxTimestamp tsEnd = TestUtils.addDays(tsToday, 27);
            poEnrolled.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
            poEnrolled.getCycleInfo().setCycleEndTime(tsEnd);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            subscription.getExternalId(), Arrays.asList(tCon.oldCi)));
            subscriptionResponse.getWalletBalances().stream().filter(
                    bi -> bi.getName().equalsIgnoreCase(
                            BALANCE_NAMES.GLOBAL_PASS)).findFirst().get().setAmount(currentGP);

            MtxPurchasedOfferInfo poiEnrolled = subscriptionResponse.getAtPurchasedOfferArray(0);
            poiEnrolled.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
            poiEnrolled.getCycleInfo().setCycleEndTime(tsEnd);

            emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(tCon.oldCi, tCon.newCi));

            VisibleOfferDetails vodAsIs = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    tCon.oldCi);
            vodAsIs.setConsumableMainBalanceAmount(tCon.getOldCiPrice());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscription, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodAsIs.getCatalogItemExternalId(), Long.valueOf(vodAsIs.getResourceId()),
                    vodAsIs);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            Map<String, BigDecimal> balImpactMap = new HashMap<String, BigDecimal>();
            balImpactMap.put(BALANCE_NAMES.COUNTER_MULTIMONTH, BigDecimal.ONE);
            balImpactMap.put(BALANCE_NAMES.GLOBAL_PASS, newGP);

            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ONE, null, balImpactMap,
                    true);
            System.out.println(td.getTestMethod() + ":" + deltaAocResp.toJson());

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            String taxApiResp = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxApiResp);
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            BigDecimal expectedGP = currentGP.add(newGP);
            assertEquals(
                    expectedGP.toPlainString(),
                    response.getNewCatalogItem().getAtAttributes(0).getValue());
        };
        TestConditions tc1 = new TestConditions(CI_EXTERNAL_IDS.PLUS3ANNUAL, CI_EXTERNAL_IDS.PLUS3VIS23WB);
        pTests.test(tc1);

    }

    @Disabled("With Curly offers now pricing decides on final GPs and Bapi does not apply cap when change is effective next month.")
    @ParameterizedTest(
            name = "test_getChangeServiceAdvice_When_12_Gps_Exist_and_ToBe_gives_GPs_Then_ToBe_Has_12_GPs")
    @Tag("VER-621")
    @Tag("2023/2.0")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has 12 global passes. 12 is max global passes a sub can have. Plus offers provide global pass on purchase.|"
                +"|When  |Api is called to change to plus offer.|"
                +"|Then  |TO-BE offer should show 12 global passes.|"})
    // @formatter:on           
    public void test_getChangeServiceAdvice_When_12_Gps_Exist_and_ToBe_gives_GPs_Then_ToBe_Has_12_GPs(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        OneParameterTest pTests = (tc) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions) tc;
            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(tCon.newCi);
            request.setDiscountPrice(tCon.getNewCiPrice());
            request.setGrossPrice(tCon.getNewCiPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            BigDecimal currentGP = BigDecimal.valueOf(12);
            BigDecimal newGP = BigDecimal.ONE;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(Arrays.asList(tCon.oldCi)));
            subscription.getBalanceArray().stream().filter(
                    bi -> bi.getName().equalsIgnoreCase(
                            BALANCE_NAMES.GLOBAL_PASS)).findFirst().get().setAmount(currentGP);

            MtxPurchasedOfferInfo poEnrolled = subscription.getAtPurchasedOfferArray(0);
            MtxTimestamp tsToday = MtxTimestamp.ofEpochMilli(
                    CommonUtils.getCurrentTimeMillis(),
                    poEnrolled.getCycleInfo().getCycleStartTime());
            // ideally get number days in month work out from there.
            MtxTimestamp tsEnd = TestUtils.addDays(tsToday, 27);
            poEnrolled.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
            poEnrolled.getCycleInfo().setCycleEndTime(tsEnd);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            subscription.getExternalId(), Arrays.asList(tCon.oldCi)));
            subscriptionResponse.getWalletBalances().stream().filter(
                    bi -> bi.getName().equalsIgnoreCase(
                            BALANCE_NAMES.GLOBAL_PASS)).findFirst().get().setAmount(currentGP);
            MtxPurchasedOfferInfo poiEnrolled = subscriptionResponse.getAtPurchasedOfferArray(0);
            poiEnrolled.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
            poiEnrolled.getCycleInfo().setCycleEndTime(tsEnd);

            emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(tCon.oldCi, tCon.newCi));

            VisibleOfferDetails vodAsIs = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    tCon.oldCi);
            vodAsIs.setConsumableMainBalanceAmount(tCon.getOldCiPrice());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscription, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodAsIs.getCatalogItemExternalId(), Long.valueOf(vodAsIs.getResourceId()),
                    vodAsIs);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            Map<String, BigDecimal> balImpactMap = new HashMap<String, BigDecimal>();
            balImpactMap.put(BALANCE_NAMES.COUNTER_MULTIMONTH, BigDecimal.ONE);
            balImpactMap.put(BALANCE_NAMES.GLOBAL_PASS, newGP);

            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ONE, null, balImpactMap,
                    true);
            System.out.println(td.getTestMethod() + ":" + deltaAocResp.toJson());

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            String taxApiResp = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxApiResp);
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            BigDecimal expectedGP = BigDecimal.valueOf(12);
            assertEquals(
                    expectedGP.toPlainString(),
                    response.getNewCatalogItem().getAtAttributes(0).getValue());
        };
        TestConditions tc1 = new TestConditions(CI_EXTERNAL_IDS.PLUS3ANNUAL, CI_EXTERNAL_IDS.PLUS3VIS23WB);
        pTests.test(tc1);
    }

    @Disabled("With Curly offers now pricing decides on final GPs and Bapi does not apply cap when change is effective next month.")
    @ParameterizedTest(name = "When_12_Gps_Exist_and_ToBe_gives_no_GPs_Then_ToBe_Has_12_GPs")
    @Tag("VER-621")
    @Tag("2023/2.0")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given | Subscription has 12 global passes.| 12 is max global passes a sub can have.|"
                +"|      | Plus offers provide global pass on purchase|"
                +"|When  | Api is called to change to plus offer.|"
                +"|Then  | TO-BE offer should show 12 global passes.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_When_12_Gps_Exist_and_ToBe_gives_no_GPs_Then_ToBe_Has_12_GPs(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        OneParameterTest pTests = (tc) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions) tc;
            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(tCon.newCi);
            request.setDiscountPrice(tCon.getNewCiPrice());
            request.setGrossPrice(tCon.getNewCiPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            BigDecimal currentGP = BigDecimal.valueOf(12);
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(Arrays.asList(tCon.oldCi)));
            subscription.getBalanceArray().stream().filter(
                    bi -> bi.getName().equalsIgnoreCase(
                            BALANCE_NAMES.GLOBAL_PASS)).findFirst().get().setAmount(currentGP);

            MtxPurchasedOfferInfo poEnrolled = subscription.getAtPurchasedOfferArray(0);
            MtxTimestamp tsToday = MtxTimestamp.ofEpochMilli(
                    CommonUtils.getCurrentTimeMillis(),
                    poEnrolled.getCycleInfo().getCycleStartTime());
            // ideally get number days in month work out from there.
            MtxTimestamp tsEnd = TestUtils.addDays(tsToday, 27);
            poEnrolled.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
            poEnrolled.getCycleInfo().setCycleEndTime(tsEnd);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            subscription.getExternalId(), Arrays.asList(tCon.oldCi)));
            MtxPurchasedOfferInfo poiEnrolled = subscriptionResponse.getAtPurchasedOfferArray(0);
            poiEnrolled.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
            poiEnrolled.getCycleInfo().setCycleEndTime(tsEnd);
            subscriptionResponse.getWalletBalances().stream().filter(
                    bi -> bi.getName().equalsIgnoreCase(
                            BALANCE_NAMES.GLOBAL_PASS)).findFirst().get().setAmount(currentGP);

            emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(tCon.oldCi, tCon.newCi));

            VisibleOfferDetails vodAsIs = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    tCon.oldCi);
            vodAsIs.setConsumableMainBalanceAmount(tCon.getOldCiPrice());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscription, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodAsIs.getCatalogItemExternalId(), Long.valueOf(vodAsIs.getResourceId()),
                    vodAsIs);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            Map<String, BigDecimal> balImpactMap = Map.of(
                    BALANCE_NAMES.GLOBAL_PASS, BigDecimal.ONE);
            List<MtxRequiredBalanceInfo> reqBalList = new ArrayList<MtxRequiredBalanceInfo>();
            subscription.getBalanceArray().forEach(bi -> {
                if (BALANCE_NAMES.GLOBAL_PASS.equalsIgnoreCase(bi.getName())) {
                    MtxRequiredBalanceInfo rbi = new MtxRequiredBalanceInfo();
                    rbi.setClassId(bi.getClassId());
                    rbi.setResourceId(bi.getResourceId());
                    rbi.setTemplateId(bi.getTemplateId());
                    rbi.setIsPrivate(bi.getIsPrivate());
                    reqBalList.add(rbi);
                }
            });

            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ONE, null, balImpactMap,
                    reqBalList, true);
            System.out.println(td.getTestMethod() + ":" + deltaAocResp.toJson());

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());
            String taxApiResp = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxApiResp);
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            BigDecimal expectedGP = BigDecimal.valueOf(12);
            assertEquals(
                    expectedGP.toPlainString(),
                    response.getNewCatalogItem().getAtAttributes(0).getValue());
        };

        TestConditions tc1 = new TestConditions(CI_EXTERNAL_IDS.PLUS3ANNUAL, CI_EXTERNAL_IDS.PLUS3VIS23);
        pTests.test(tc1);
    }
    
    @ParameterizedTest(name = "test_getChangeServiceAdvice_Given_AnnualFreeGPOffer_When_AocToMonthly_HasGPImpact_Then_AsPerAoc")
    @Tag("VER-714") @Tag("VER-718") @Tag("VER-621")
    @Tag("2025/3.0")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription HAS annual free GPs.Less than 12|"
                +"|When  |Api is called to change to Monthly free GP offer. Aoc shows GP impact|"
                +"|Then  |TO-BE offer should show GP as per AoC.|"
                +"|Comments |Pricing controls cap and new values next month. Hence Bapi should not doo any calculation here.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_Given_AnnualFreeGPOffer_When_AocToMonthly_HasGPImpact_Then_AsPerAoc(ArgumentsAccessor acceptance) throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        String subscriptionExternalId = "123";
        OneParameterTest pTests = (tc) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(tCon.newCi);
            request.setDiscountPrice(tCon.getNewCiPrice());
            request.setGrossPrice(tCon.getNewCiPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            BigDecimal targetPerMonthGP = BigDecimal.valueOf(1);
            BigDecimal currentGP = BigDecimal.valueOf(5);            
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(Arrays.asList(tCon.oldCi)));

            MtxPurchasedOfferInfo poEnrolled = subscription.getAtPurchasedOfferArray(0);
            MtxTimestamp tsToday = MtxTimestamp.ofEpochMilli(
                    CommonUtils.getCurrentTimeMillis(),
                    poEnrolled.getCycleInfo().getCycleStartTime());
            // ideally get number days in month work out from there.
            MtxTimestamp tsEnd = TestUtils.addDays(tsToday, 27);
            poEnrolled.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
            poEnrolled.getCycleInfo().setCycleEndTime(tsEnd);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            subscription.getExternalId(), Arrays.asList(tCon.oldCi)));
            MtxPurchasedOfferInfo poiEnrolled = subscriptionResponse.getAtPurchasedOfferArray(0);
            poiEnrolled.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
            poiEnrolled.getCycleInfo().setCycleEndTime(tsEnd);
            subscriptionResponse.getWalletBalances().stream().filter(
                    bi -> bi.getName().equalsIgnoreCase(
                            BALANCE_NAMES.GLOBAL_PASS)).findFirst().get().setAmount(currentGP);            
            subscriptionResponse.getPurchasedOfferArrayAppender().add(poiEnrolled);

            emulateMtxResponsePricingCatalogItems(instance, List.of(tCon.oldCi, tCon.newCi));

            VisibleOfferDetails vodAsIs = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    tCon.oldCi);
            vodAsIs.setConsumableMainBalanceAmount(tCon.getOldCiPrice());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscription, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodAsIs.getCatalogItemExternalId(), Long.valueOf(vodAsIs.getResourceId()),
                    vodAsIs);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            Map<String, BigDecimal> balImpactMap = Map.of(
                    BALANCE_NAMES.GLOBAL_PASS, targetPerMonthGP);
            List<MtxRequiredBalanceInfo> reqBalList = new ArrayList<MtxRequiredBalanceInfo>();
            subscription.getBalanceArray().forEach(bi -> {
                if (BALANCE_NAMES.GLOBAL_PASS.equalsIgnoreCase(bi.getName())) {
                    MtxRequiredBalanceInfo rbi = new MtxRequiredBalanceInfo();
                    rbi.setClassId(bi.getClassId());
                    rbi.setResourceId(bi.getResourceId());
                    rbi.setTemplateId(bi.getTemplateId());
                    rbi.setIsPrivate(bi.getIsPrivate());
                    reqBalList.add(rbi);
                }
            });

            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ONE, null, balImpactMap,
                    reqBalList, true);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());
            String taxApiResp = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxApiResp);
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            BigDecimal expectedGP = targetPerMonthGP;
            assertEquals(
                    expectedGP.toPlainString(),
                    response.getNewCatalogItem().getAtAttributes(0).getValue());
        };

        TestConditions tc1 = new TestConditions(CI_EXTERNAL_IDS.PRO25ANNUAL, CI_EXTERNAL_IDS.PLUS25);
        pTests.test(tc1);
        TestConditions tc2 = new TestConditions(CI_EXTERNAL_IDS.PRO25ANNUAL, CI_EXTERNAL_IDS.PRO25);
        pTests.test(tc2);        
    }
    @ParameterizedTest(name = "test_getChangeServiceAdvice_Given_AnnualFreeGPOffer_When_AocToMonthly_HasGPRequiredBalance_Then_SameAsIs")
    @Tag("VER-714") @Tag("VER-718") @Tag("VER-621")
    @Tag("2025/3.0")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription HAS annual free GPs.Equal to 12|"
                +"|When  |Api is called to change to Monthly free GP offer. Aoc shows no GP impact. But Aoc shows GP in required balance.|"
                +"|Then  |TO-BE offer should show GP as 12. That is same as current GP.|"
                +"|Comments |Pricing may not show zero impact in aoc response. Hence Bapi should copy as-is as to-be.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_Given_AnnualFreeGPOffer_When_AocToMonthly_HasGPRequiredBalance_Then_GpEq12(ArgumentsAccessor acceptance) throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        String subscriptionExternalId = "123";
        OneParameterTest pTests = (tc) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(tCon.newCi);
            request.setDiscountPrice(tCon.getNewCiPrice());
            request.setGrossPrice(tCon.getNewCiPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            BigDecimal currentGP = BigDecimal.valueOf(12);            
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(Arrays.asList(tCon.oldCi)));
            MtxPurchasedOfferInfo poEnrolled = subscription.getAtPurchasedOfferArray(0);
            MtxTimestamp tsToday = MtxTimestamp.ofEpochMilli(
                    CommonUtils.getCurrentTimeMillis(),
                    poEnrolled.getCycleInfo().getCycleStartTime());
            // ideally get number days in month work out from there.
            MtxTimestamp tsEnd = TestUtils.addDays(tsToday, 27);
            poEnrolled.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
            poEnrolled.getCycleInfo().setCycleEndTime(tsEnd);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            subscription.getExternalId(), Arrays.asList(tCon.oldCi)));
            MtxPurchasedOfferInfo poiEnrolled = subscriptionResponse.getAtPurchasedOfferArray(0);
            poiEnrolled.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
            poiEnrolled.getCycleInfo().setCycleEndTime(tsEnd);
            subscriptionResponse.getWalletBalances().stream().filter(
                    bi -> bi.getName().equalsIgnoreCase(
                            BALANCE_NAMES.GLOBAL_PASS)).findFirst().get().setAmount(currentGP);

            emulateMtxResponsePricingCatalogItems(instance, List.of(tCon.oldCi, tCon.newCi));

            VisibleOfferDetails vodAsIs = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    tCon.oldCi);
            vodAsIs.setConsumableMainBalanceAmount(tCon.getOldCiPrice());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscription, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodAsIs.getCatalogItemExternalId(), Long.valueOf(vodAsIs.getResourceId()),
                    vodAsIs);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            List<MtxRequiredBalanceInfo> reqBalList = new ArrayList<MtxRequiredBalanceInfo>();
            subscription.getBalanceArray().forEach(bi -> {
                if (BALANCE_NAMES.GLOBAL_PASS.equalsIgnoreCase(bi.getName())) {
                    MtxRequiredBalanceInfo rbi = new MtxRequiredBalanceInfo();
                    rbi.setClassId(bi.getClassId());
                    rbi.setResourceId(bi.getResourceId());
                    rbi.setTemplateId(bi.getTemplateId());
                    rbi.setIsPrivate(bi.getIsPrivate());
                    reqBalList.add(rbi);
                }
            });

            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ONE, null, null,
                    reqBalList, true);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());
            String taxApiResp = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxApiResp);
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());            
            assertEquals(
                    currentGP.toPlainString(),
                    response.getNewCatalogItem().getAtAttributes(0).getValue());
        };

        TestConditions tc1 = new TestConditions(CI_EXTERNAL_IDS.PRO25ANNUAL, CI_EXTERNAL_IDS.PLUS25);
        pTests.test(tc1);
        TestConditions tc2 = new TestConditions(CI_EXTERNAL_IDS.PRO25ANNUAL, CI_EXTERNAL_IDS.PRO25);
        pTests.test(tc2);          
    }    
    @ParameterizedTest(name = "test_getChangeServiceAdvice_Given_NoFreeGPOffer_When_ChangeTo_MidMonthly_Then_Add1Gps")
    @Tag("VER-714") @Tag("VER-718") @Tag("VER-621")
    @Tag("2025/3.0")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has enrolled monthly service that is NOT eligible for free GPs.|"
                +"|When  |Api is called to change to Mid Monthly offer or PLUS3VIS23WB.|"
                +"|Then  |TO-BE offer should add 1 GP.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_Given_NoFreeGPOffer_When_ChangeTo_MidMonthly_Then_Add1Gps(ArgumentsAccessor acceptance) throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        String subscriptionExternalId = "123";
        OneParameterTest pTests = (tc) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(tCon.newCi);
            request.setDiscountPrice(tCon.getNewCiPrice());
            request.setGrossPrice(tCon.getNewCiPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            BigDecimal targetPerMonthGP = BigDecimal.valueOf(1);
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(Arrays.asList(tCon.oldCi)));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            subscription.getExternalId(), Arrays.asList(tCon.oldCi)));

            emulateMtxResponsePricingCatalogItems(instance, List.of(tCon.oldCi, tCon.newCi));

            VisibleOfferDetails vodAsIs = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    tCon.oldCi);
            vodAsIs.setConsumableMainBalanceAmount(tCon.getOldCiPrice());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscription, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodAsIs.getCatalogItemExternalId(), Long.valueOf(vodAsIs.getResourceId()),
                    vodAsIs);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            Map<String, BigDecimal> balImpactMap = Map.of(
                    BALANCE_NAMES.GLOBAL_PASS, targetPerMonthGP);
            List<MtxRequiredBalanceInfo> reqBalList = new ArrayList<MtxRequiredBalanceInfo>();
            subscription.getBalanceArray().forEach(bi -> {
                if (BALANCE_NAMES.GLOBAL_PASS.equalsIgnoreCase(bi.getName())) {
                    MtxRequiredBalanceInfo rbi = new MtxRequiredBalanceInfo();
                    rbi.setClassId(bi.getClassId());
                    rbi.setResourceId(bi.getResourceId());
                    rbi.setTemplateId(bi.getTemplateId());
                    rbi.setIsPrivate(bi.getIsPrivate());
                    reqBalList.add(rbi);
                }
            });

            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ONE, null, balImpactMap,
                    reqBalList, true);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());
            String taxApiResp = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxApiResp);
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            BigDecimal expectedGP = targetPerMonthGP;
            assertEquals(
                    expectedGP.toPlainString(),
                    response.getNewCatalogItem().getAtAttributes(0).getValue());
        };

        TestConditions tc1 = new TestConditions(CI_EXTERNAL_IDS.BASE3VIS23, CI_EXTERNAL_IDS.PLUS25);
        pTests.test(tc1);
        TestConditions tc2 = new TestConditions(CI_EXTERNAL_IDS.BASE3VIS23, CI_EXTERNAL_IDS.PLUS3VIS23WB);
        pTests.test(tc2);
    }

    @ParameterizedTest(name = "test_getChangeServiceAdvice_Given_NoAsIsFreeGPOffer_When_ChangeTo_HiMonthly_Then_Add2Gps")
    @Tag("VER-714") @Tag("VER-718")
    @Tag("2025/3.0")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has enrolled monthly service that is NOT eligible for free GPs.|"
                +"|When  |Api is called to change to High Monthly offer.|"
                +"|Then  |TO-BE offer should add 2 GP.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_Given_NoAsIsMonthlyFreeGPOffer_When_ChangeTo_HiMonthly_Then_Add2Gps(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        String subscriptionExternalId = "123";
        OneParameterTest pTests = (tc) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(tCon.newCi);
            request.setDiscountPrice(tCon.getNewCiPrice());
            request.setGrossPrice(tCon.getNewCiPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            BigDecimal targetPerMonthGP = BigDecimal.valueOf(2);
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(Arrays.asList(tCon.oldCi)));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            subscription.getExternalId(), Arrays.asList(tCon.oldCi)));

            emulateMtxResponsePricingCatalogItems(instance, List.of(tCon.oldCi, tCon.newCi));

            VisibleOfferDetails vodAsIs = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    tCon.oldCi);
            vodAsIs.setConsumableMainBalanceAmount(tCon.getOldCiPrice());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscription, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodAsIs.getCatalogItemExternalId(), Long.valueOf(vodAsIs.getResourceId()),
                    vodAsIs);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            Map<String, BigDecimal> balImpactMap = Map.of(
                    BALANCE_NAMES.GLOBAL_PASS, targetPerMonthGP);
            List<MtxRequiredBalanceInfo> reqBalList = new ArrayList<MtxRequiredBalanceInfo>();
            subscription.getBalanceArray().forEach(bi -> {
                if (BALANCE_NAMES.GLOBAL_PASS.equalsIgnoreCase(bi.getName())) {
                    MtxRequiredBalanceInfo rbi = new MtxRequiredBalanceInfo();
                    rbi.setClassId(bi.getClassId());
                    rbi.setResourceId(bi.getResourceId());
                    rbi.setTemplateId(bi.getTemplateId());
                    rbi.setIsPrivate(bi.getIsPrivate());
                    reqBalList.add(rbi);
                }
            });

            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ONE, null, balImpactMap,
                    reqBalList, true);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());
            String taxApiResp = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxApiResp);
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            BigDecimal expectedGP = targetPerMonthGP;
            assertEquals(
                    expectedGP.toPlainString(),
                    response.getNewCatalogItem().getAtAttributes(0).getValue());
        };

        TestConditions tc1 = new TestConditions(CI_EXTERNAL_IDS.BASE3VIS23, CI_EXTERNAL_IDS.PRO25);
        pTests.test(tc1);
    }

    @ParameterizedTest(name = "test_getChangeServiceAdvice_Given_AsIsMonthlyFreeGPOffer_When_ChangeTo_HiMonthly_Then_AddOneGP")
    @Tag("VER-714") @Tag("VER-718")
    @Tag("2025/3.0")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has some GPs due to a monthly service.|"                
                +"|When  |Api is called to change to High Monthly offer.|"
                +"|Then  |TO-BE offer should add only 1 GP instead of 2.|"
                +"|      |There should be an adjustment request to reduce GP by 1.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_Given_AsIsMonthlyFreeGPOffer_When_ChangeTo_HiMonthly_Then_AddOneGP(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        OneParameterTest pTests = (tc) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions) tc;
            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(tCon.newCi);
            request.setDiscountPrice(tCon.getNewCiPrice());
            request.setGrossPrice(tCon.getNewCiPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            BigDecimal currentGP = BigDecimal.valueOf(9);
            BigDecimal balImpactGP = BigDecimal.valueOf(1);
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(Arrays.asList(tCon.oldCi)));
            subscription.getBalanceArray().stream().filter(
                    bi -> bi.getName().equalsIgnoreCase(
                            BALANCE_NAMES.GLOBAL_PASS)).findFirst().get().setAmount(currentGP);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            subscription.getExternalId(), Arrays.asList(tCon.oldCi)));

            subscriptionResponse.getWalletBalances().stream().filter(
                    bi -> bi.getName().equalsIgnoreCase(
                            BALANCE_NAMES.GLOBAL_PASS)).findFirst().get().setAmount(currentGP);

            emulateMtxResponsePricingCatalogItems(instance, List.of(tCon.oldCi, tCon.newCi));

            VisibleOfferDetails vodAsIs = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    tCon.oldCi);
            vodAsIs.setConsumableMainBalanceAmount(tCon.getOldCiPrice());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscription, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodAsIs.getCatalogItemExternalId(), Long.valueOf(vodAsIs.getResourceId()),
                    vodAsIs);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            Map<String, BigDecimal> balImpactMap = Map.of(
                    BALANCE_NAMES.GLOBAL_PASS, balImpactGP);
            List<MtxRequiredBalanceInfo> reqBalList = new ArrayList<MtxRequiredBalanceInfo>();
            subscription.getBalanceArray().forEach(bi -> {
                if (BALANCE_NAMES.GLOBAL_PASS.equalsIgnoreCase(bi.getName())) {
                    MtxRequiredBalanceInfo rbi = new MtxRequiredBalanceInfo();
                    rbi.setClassId(bi.getClassId());
                    rbi.setResourceId(bi.getResourceId());
                    rbi.setTemplateId(bi.getTemplateId());
                    rbi.setIsPrivate(bi.getIsPrivate());
                    reqBalList.add(rbi);
                }
            });

            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ONE, null, balImpactMap,
                    reqBalList, true);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());
            String taxApiResp = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxApiResp);
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            BigDecimal expectedGP = balImpactGP.add(currentGP);
            assertEquals(
                    expectedGP.toPlainString(),
                    response.getNewCatalogItem().getAtAttributes(0).getValue());
        };

        TestConditions tc1 = new TestConditions(CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.PRO25);
        pTests.test(tc1);
        TestConditions tc2 = new TestConditions(CI_EXTERNAL_IDS.PLUS25, CI_EXTERNAL_IDS.PRO25);
        pTests.test(tc2);
    }
    
    @ParameterizedTest(
            name = "test_getChangeServiceAdvice_Given_NoAsIsAnnualFreeGPOffer_When_ChangeTo_HiAnnual_Then_AddTwoGpPerMonth")
    @Tag("VER-714") @Tag("VER-718")
    @Tag("2025/3.0")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has no as-is Gps due to an annual service.|"
                +"|When  |Api is called to change to High Annual offer.|"
                +"|Then  |TO-BE offer should add only two Gps per month.|" })
    // @formatter:on
    public void test_getChangeServiceAdvice_Given_NoAsIsAnnualFreeGPOffer_When_ChangeTo_HiAnnual_Then_AddTwoGpPerMonth(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        OneParameterTest pTests = (tc) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions) tc;
            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(tCon.newCi);
            request.setDiscountPrice(tCon.getNewCiPrice());
            request.setGrossPrice(tCon.getNewCiPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            int targetPerMonthGP = 2;
            BigDecimal targetPerYearGP = BigDecimal.valueOf(24);
            int unusedMonthFull = 7;
            int unusedMonthPartial = 1;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(Arrays.asList(tCon.oldCi)));
            MtxPurchasedOfferInfo poEnrolled = subscription.getAtPurchasedOfferArray(0);
            MtxTimestamp tsToday = MtxTimestamp.ofEpochMilli(
                    CommonUtils.getCurrentTimeMillis(),
                    poEnrolled.getCycleInfo().getCycleStartTime());
            // ideally get number days in month work out from there.
            MtxTimestamp tsEnd = TestUtils.addMonths(tsToday, unusedMonthFull);
            tsEnd = TestUtils.addDays(tsEnd, 2);//For unused partial month
            poEnrolled.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
            poEnrolled.getCycleInfo().setCycleEndTime(tsEnd);
            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            subscription.getExternalId(), Arrays.asList(tCon.oldCi)));
            MtxPurchasedOfferInfo poiEnrolled = subscriptionResponse.getAtPurchasedOfferArray(0);
            poiEnrolled.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
            poiEnrolled.getCycleInfo().setCycleEndTime(tsEnd);
            emulateMtxResponsePricingCatalogItems(instance, List.of(tCon.oldCi, tCon.newCi));

            VisibleOfferDetails vodAsIs = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    tCon.oldCi);
            vodAsIs.setConsumableMainBalanceAmount(tCon.getOldCiPrice());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscription, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodAsIs.getCatalogItemExternalId(), Long.valueOf(vodAsIs.getResourceId()),
                    vodAsIs);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            Map<String, BigDecimal> balImpactMap = Map.of(
                    BALANCE_NAMES.GLOBAL_PASS, targetPerYearGP);
            List<MtxRequiredBalanceInfo> reqBalList = new ArrayList<MtxRequiredBalanceInfo>();
            subscription.getBalanceArray().forEach(bi -> {
                if (BALANCE_NAMES.GLOBAL_PASS.equalsIgnoreCase(bi.getName())) {
                    MtxRequiredBalanceInfo rbi = new MtxRequiredBalanceInfo();
                    rbi.setClassId(bi.getClassId());
                    rbi.setResourceId(bi.getResourceId());
                    rbi.setTemplateId(bi.getTemplateId());
                    rbi.setIsPrivate(bi.getIsPrivate());
                    reqBalList.add(rbi);
                }
            });

            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ONE, null, balImpactMap,
                    reqBalList, true);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());
            String taxApiResp = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxApiResp);
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            BigDecimal expectedGP = BigDecimal.valueOf((unusedMonthFull+unusedMonthPartial)*targetPerMonthGP);
            assertEquals(
                    expectedGP.toPlainString(),
                    response.getNewCatalogItem().getAtAttributes(0).getValue());
        };

        TestConditions tc1 = new TestConditions(CI_EXTERNAL_IDS.BASE3ANNUAL, CI_EXTERNAL_IDS.PRO25ANNUAL);
        pTests.test(tc1);
    }

    @ParameterizedTest(name = "test_getChangeServiceAdvice_Given_AsIsAnnualFreeGPOffer_When_ChangeTo_HiAnnual_Then_AddOneGpPerMonth")
    @Tag("VER-714") @Tag("VER-718")
    @Tag("2025/3.0")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has some GPs due to an annual service.|"
                +"|When  |Api is called to change to High Annual offer.|"
                +"|Then  |TO-BE offer should add only 1 GP instead of 2 per month.|"
                +"|Comments|Later in Change Service there should be an adjustment request to reduce GP by 1 per month.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_Given_AsIsAnnualFreeGPOffer_When_ChangeTo_HiAnnual_Then_AddOneGpPerMonth(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        OneParameterTest pTests = (tc) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions) tc;
            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(tCon.newCi);
            request.setDiscountPrice(tCon.getNewCiPrice());
            request.setGrossPrice(tCon.getNewCiPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            //int targetPerMonthGP = 1;
            BigDecimal balImpactGP = BigDecimal.valueOf(12);
             
            int unusedMonthFull = 7;
            int unusedMonthPartial = 1;
            BigDecimal currentGps = BigDecimal.ONE;
            
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(Arrays.asList(tCon.oldCi)));
            MtxPurchasedOfferInfo poEnrolled = subscription.getAtPurchasedOfferArray(0);
            MtxTimestamp tsToday = MtxTimestamp.ofEpochMilli(
                    CommonUtils.getCurrentTimeMillis(),
                    poEnrolled.getCycleInfo().getCycleStartTime());
            // ideally get number days in month work out from there.
            MtxTimestamp tsEnd = TestUtils.addMonths(tsToday, unusedMonthFull);
            tsEnd = TestUtils.addDays(tsEnd, 2);//For unused partial month
            poEnrolled.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
            poEnrolled.getCycleInfo().setCycleEndTime(tsEnd);
            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            subscription.getExternalId(), Arrays.asList(tCon.oldCi)));
            MtxPurchasedOfferInfo poiEnrolled = subscriptionResponse.getAtPurchasedOfferArray(0);
            poiEnrolled.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
            poiEnrolled.getCycleInfo().setCycleEndTime(tsEnd);
            emulateMtxResponsePricingCatalogItems(instance, List.of(tCon.oldCi, tCon.newCi));

            VisibleOfferDetails vodAsIs = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    tCon.oldCi);
            vodAsIs.setConsumableMainBalanceAmount(tCon.getOldCiPrice());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscription, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodAsIs.getCatalogItemExternalId(), Long.valueOf(vodAsIs.getResourceId()),
                    vodAsIs);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            Map<String, BigDecimal> balImpactMap = Map.of(
                    BALANCE_NAMES.GLOBAL_PASS, balImpactGP);
            List<MtxRequiredBalanceInfo> reqBalList = new ArrayList<MtxRequiredBalanceInfo>();
            subscriptionResponse.getWalletBalances().forEach(bi -> {
                if (BALANCE_NAMES.GLOBAL_PASS.equalsIgnoreCase(bi.getName())) {
                    bi.setAvailableAmount(currentGps);
                    bi.setAmount(currentGps.negate());
                    MtxRequiredBalanceInfo rbi = new MtxRequiredBalanceInfo();
                    rbi.setClassId(bi.getClassId());
                    rbi.setResourceId(bi.getResourceId());
                    rbi.setTemplateId(bi.getTemplateId());
                    rbi.setIsPrivate(bi.getIsPrivate());
                    reqBalList.add(rbi);
                }
            });

            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ONE, null, balImpactMap,
                    reqBalList, true);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());
            String taxApiResp = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxApiResp);
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            //BigDecimal expectedGP = BigDecimal.valueOf((unusedMonthFull+unusedMonthPartial)*targetPerMonthGP);
            BigDecimal expectedGP = BigDecimal.valueOf(unusedMonthFull+unusedMonthPartial);
            assertEquals(
                    expectedGP.toPlainString(),
                    response.getNewCatalogItem().getAtAttributes(0).getValue());
        };

        TestConditions tc1 = new TestConditions(CI_EXTERNAL_IDS.PLUS3ANNUAL, CI_EXTERNAL_IDS.PRO25ANNUAL);
        pTests.test(tc1);
        TestConditions tc2 = new TestConditions(CI_EXTERNAL_IDS.PLUS25ANNUAL, CI_EXTERNAL_IDS.PRO25ANNUAL);
        pTests.test(tc2);
    } 
    
    @ParameterizedTest(name = "test_getChangeServiceAdvice_Given_AsIsAnnualFreeGpOffer_But_Zero_FreeGp_When_ChangeTo_HiAnnual_Then_AddOneGpPerMonth")
    @Tag("VER-714") @Tag("VER-718")
    @Tag("2025/3.0")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has enrolled annual service that is ELIGIBLE for free GPs.|"
                +"|      |Zero unused Gps in balance.|"
                +"|When  |Api is called to change to High Annual offer.|"
                +"|Then  |TO-BE offer should add 2 GP per month.|"
                +"|Comments|Later in Change Service there should be an adjustment request to reduce GP by 1 per month.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_Given_AsIsAnnualFreeGpOffer_But_Zero_FreeGp_When_ChangeTo_HiAnnual_Then_AddOneGpPerMonth(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        OneParameterTest pTests = (tc) -> {
            td.printDescription();
            TestConditions tCon = (TestConditions) tc;
            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(tCon.newCi);
            request.setDiscountPrice(tCon.getNewCiPrice());
            request.setGrossPrice(tCon.getNewCiPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            //int targetPerMonthGP = 1;
            BigDecimal balImpactGP = BigDecimal.valueOf(12);
             
            int unusedMonthFull = 7;
            int unusedMonthPartial = 1;
            BigDecimal currentGps = BigDecimal.ZERO;
            
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(Arrays.asList(tCon.oldCi)));
            MtxPurchasedOfferInfo poEnrolled = subscription.getAtPurchasedOfferArray(0);
            MtxTimestamp tsToday = MtxTimestamp.ofEpochMilli(
                    CommonUtils.getCurrentTimeMillis(),
                    poEnrolled.getCycleInfo().getCycleStartTime());
            // ideally get number days in month work out from there.
            MtxTimestamp tsEnd = TestUtils.addMonths(tsToday, unusedMonthFull);
            tsEnd = TestUtils.addDays(tsEnd, 2);//For unused partial month
            poEnrolled.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
            poEnrolled.getCycleInfo().setCycleEndTime(tsEnd);
            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            subscription.getExternalId(), Arrays.asList(tCon.oldCi)));
            MtxPurchasedOfferInfo poiEnrolled = subscriptionResponse.getAtPurchasedOfferArray(0);
            poiEnrolled.getCycleInfo().setCycleStartTime(TestUtils.subtractOneYear(tsEnd));
            poiEnrolled.getCycleInfo().setCycleEndTime(tsEnd);
            emulateMtxResponsePricingCatalogItems(instance, List.of(tCon.oldCi, tCon.newCi));

            VisibleOfferDetails vodAsIs = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    tCon.oldCi);
            vodAsIs.setConsumableMainBalanceAmount(tCon.getOldCiPrice());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscription, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodAsIs.getCatalogItemExternalId(), Long.valueOf(vodAsIs.getResourceId()),
                    vodAsIs);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            Map<String, BigDecimal> balImpactMap = Map.of(
                    BALANCE_NAMES.GLOBAL_PASS, balImpactGP);
            List<MtxRequiredBalanceInfo> reqBalList = new ArrayList<MtxRequiredBalanceInfo>();
            subscriptionResponse.getWalletBalances().forEach(bi -> {
                if (BALANCE_NAMES.GLOBAL_PASS.equalsIgnoreCase(bi.getName())) {
                    bi.setAvailableAmount(currentGps);
                    bi.setAmount(currentGps.negate());
                    MtxRequiredBalanceInfo rbi = new MtxRequiredBalanceInfo();
                    rbi.setClassId(bi.getClassId());
                    rbi.setResourceId(bi.getResourceId());
                    rbi.setTemplateId(bi.getTemplateId());
                    rbi.setIsPrivate(bi.getIsPrivate());
                    reqBalList.add(rbi);
                }
            });

            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), BigDecimal.ONE, null, balImpactMap,
                    reqBalList, true);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());
            String taxApiResp = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxApiResp);
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            //BigDecimal expectedGP = BigDecimal.valueOf((unusedMonthFull+unusedMonthPartial)*targetPerMonthGP);
            BigDecimal expectedGP = BigDecimal.valueOf(unusedMonthFull+unusedMonthPartial);
            assertEquals(
                    expectedGP.toPlainString(),
                    response.getNewCatalogItem().getAtAttributes(0).getValue());
        };

        TestConditions tc1 = new TestConditions(CI_EXTERNAL_IDS.PLUS3ANNUAL, CI_EXTERNAL_IDS.PRO25ANNUAL);
        pTests.test(tc1);
        TestConditions tc2 = new TestConditions(CI_EXTERNAL_IDS.PLUS25ANNUAL, CI_EXTERNAL_IDS.PRO25ANNUAL);
        pTests.test(tc2);

    }
   
    @ParameterizedTest(
            name = "test_getChangeServiceAdvice_When_ChangeTo_LowOffer_Then_ResetGPToZero")
    @Tag("VER-714") @Tag("VER-718")
    @Tag("2025/3.0")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has some GPs due to a monthly service.|"                
                +"|When  |Api is called to change to Low Monthly or Yearly offer.|"
                +"|Then  |GP Should be set to zero.|"
                +"|Comment|This can not be unit tested. Test on proxy server.|"})
    // @formatter:on
    public void test_getChangeServiceAdvice_When_ChangeTo_LowOffer_Then_ResetGPToZero(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
    }

}
