package com.matrixx.vag.config.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import com.matrixx.datacontainer.mdc.VisibleRequestGetConfig;
import com.matrixx.datacontainer.mdc.VisibleResponseGetConfig;
import com.matrixx.vag.exception.ConfigServiceException;
import com.matrixx.vag.util.MDCTest;

public class ConfigServiceTest extends MDCTest {

    @Spy
    @InjectMocks
    private ConfigService instance = new ConfigService();

    @BeforeEach
    public void setUp() throws Exception {
        instance = new ConfigService();
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void test_getConfig_When_Always_Then_PropetiesAsPerFile(TestInfo testInfo)
            throws ConfigServiceException, IOException {
        System.out.println(testInfo.getDisplayName() + ":");
        VisibleRequestGetConfig request = new VisibleRequestGetConfig();
        VisibleResponseGetConfig response = new VisibleResponseGetConfig();
        instance.getConfig(request, response);
        Map<String, String> actualMap = new HashMap<String, String>();
        response.getVisiblePropertyList().forEach(prop -> {
            actualMap.put(prop.getName(), prop.getValue());
        });

        MapUtils.debugPrint(System.out, "ConfigMap", actualMap);

        BufferedReader br1 = new BufferedReader(
                new FileReader("src/test/resources/rsgateway.properties"));
        String line1 = null;
        List<String> ignoreList = List.of(
                "mongodb.serverAddress", "tax.on.services.api.endpoint",
                "credit.grant.calculation.method.aoc.catalog.items");
        while ((line1 = br1.readLine()) != null) {
            if (line1.startsWith("#")) {
                continue;
            } else if (StringUtils.isNotBlank(line1)) {
                String[] propSplit = line1.split("=");
                String prop = propSplit[0].trim();
                String expectedValue = propSplit[1].trim();
                if (ignoreList.contains(prop)) {
                    continue;
                }
                assertEquals(expectedValue, actualMap.get(prop), prop);
            }
        }
    }
}
