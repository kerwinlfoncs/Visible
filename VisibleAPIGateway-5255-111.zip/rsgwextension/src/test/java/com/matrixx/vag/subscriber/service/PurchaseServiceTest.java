package com.matrixx.vag.subscriber.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.test.util.ReflectionTestUtils;

import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.MtxRequestMulti;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberPurchaseOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriptionModify;
import com.matrixx.datacontainer.mdc.MtxResponseMulti;
import com.matrixx.datacontainer.mdc.MtxResponsePricingOffer;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.MtxResponseWallet;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleRequestPurchaseService;
import com.matrixx.datacontainer.mdc.VisibleResponsePaymentAdviceService;
import com.matrixx.datacontainer.mdc.VisibleResponsePurchaseService;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.advice.model.VisibleResponsePurchaseAdvice;
import com.matrixx.vag.advice.service.PaymentAdviceService;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestConstants.DATA_DIR;
import com.matrixx.vag.exception.MtxResponseException;
import com.matrixx.vag.util.MDCTest;

public class PurchaseServiceTest extends MDCTest {

    @Spy
    @InjectMocks
    private final SubscriberService instance = new SubscriberService();

    @Mock
    private SubscriberManagementApi api;

    PaymentAdviceService aopInstance = null;

    @BeforeEach
    public void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
        aopInstance = Mockito.spy(new PaymentAdviceService());
        ReflectionTestUtils.setField(instance, "paymentAdviceService", aopInstance);
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_purchaseService_isPaymentRechargeEqTrue_PurchaseSuccess() throws Exception {
        String service = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", service);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());
        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                service, "", "", null, wallet);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleResponsePurchaseService output = new VisibleResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, List.of(service));
        doReturn("").when(instance).getRoute(any());
        doReturn(multiRes).when(instance).multiRequest(any(), any(), any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());

        // method to test
        instance.purchaseService(input, output);
        // Assertions here.
        assertEquals(RESULT_CODES.MTX_SUCCESS, output.getResult());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_purchaseService_isPaymentRechargeEqFalse_PurchaseSuccess() throws Exception {
        String service = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", service);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());

        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                service, "", "", null, wallet);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleResponsePurchaseService output = new VisibleResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, List.of(service));
        doReturn("").when(instance).getRoute(any());
        doReturn(multiRes).when(instance).multiRequest(any(), any(), any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());

        // method to test
        instance.purchaseService(input, output);
        // Assertions here.
        assertEquals(RESULT_CODES.MTX_SUCCESS, output.getResult());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    // Add mocks till multi call
    public void test_PurchaseService_MultiApiError_PurchaseFail() throws Exception {
        String service = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", service);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.setResult(11L);
        multiRes.setResultText("NOTOK");

        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());
        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                service, "", "", null, wallet);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleResponsePurchaseService output = new VisibleResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, List.of(CI_EXTERNAL_IDS.UNLIMITED));
        doReturn("").when(instance).getRoute(any());
        doReturn(multiRes).when(instance).multiRequest(any(), any(), any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(
                any(), any(), eq(CI_EXTERNAL_IDS.UNLIMITED));

        Exception exception = assertThrows(
                MtxResponseException.class, () -> instance.purchaseService(input, output));
        exception.printStackTrace();
        assertThat(exception.getMessage()).contains(
                ReflectionTestUtils.getField(instance, "FAILED_TO_PURCHASE_SERVICE").toString());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_purchaseService_MultiApiNullResponse_PurchaseFail() throws Exception {
        String service = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", service);

        MtxResponseMulti multiRes = null;

        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());

        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                service, "", "", null, wallet);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleResponsePurchaseService output = new VisibleResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, List.of(service));
        doReturn("").when(instance).getRoute(any());
        doReturn(multiRes).when(instance).multiRequest(any(), any(), any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), eq(service));

        Exception exception = assertThrows(
                MtxResponseException.class, () -> instance.purchaseService(input, output));
        exception.printStackTrace();
        assertThat(exception.getMessage()).contains(
                ReflectionTestUtils.getField(instance, "FAILED_TO_PURCHASE_SERVICE").toString());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_purchaseService_PricingOfferAttributesHasGoodType_GoodTypesAsExpected(TestInfo testInfo)
            throws Exception {

        String testLoggingKey = getTestLoggingKey(testInfo.getDisplayName());

        // Test case to check that GoodTypes are populated correctly
        String service = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", service);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());
        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                service, "", "", null, wallet);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);
        VisibleResponsePurchaseService output = new VisibleResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, List.of(service));
        doReturn("").when(instance).getRoute(any());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
        // method to test
        instance.purchaseService(input, output);
        System.out.println(testLoggingKey + StringUtils.SPACE + argumentCaptor.getValue().toJson());

        // Assertions here.
        String expectedGoodType = pricingOffer.getOfferInfo().getAttrList().stream().filter(
                attr -> attr.getName().equals("good_type")).map(
                        attr -> attr.getValue()).findFirst().get();
        String ActualGoodType = argumentCaptor.getValue().getRequestList().stream().filter(
                req -> req.getContainer().getName().equals(
                        MtxRequestSubscriberPurchaseOffer.class.getSimpleName())).map(
                                req -> (MtxRequestSubscriberPurchaseOffer) req).filter(
                                        poReq -> poReq.getOfferRequestArray().get(
                                                0).getExternalId().equals("Visible_Unlimited")).map(
                                                        poReq -> ((VisiblePurchasedOfferExtension) poReq.getOfferRequestArray().get(
                                                                0).getAttr()).getGoodType()).findAny().get();

        assertEquals(expectedGoodType, ActualGoodType);
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_purchaseService_referral_credit_PurchaseSuccess(TestInfo testInfo)
            throws Exception {

        String testLoggingKey = getTestLoggingKey(testInfo.getDisplayName());
        String service = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", service);

        MtxResponseMulti multiResMainBal = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());

        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);
        Map<String, BigDecimal> promoGrantCiRedeemMap = Map.of(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.valueOf(10));
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                service, "", "", promoGrantCiRedeemMap, wallet);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleResponsePurchaseService output = new VisibleResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, List.of(CI_EXTERNAL_IDS.UNLIMITED));
        doReturn("").when(instance).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResMainBal).doReturn(multiRes).when(instance).multiRequest(
                any(), any(), argumentCaptor.capture());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());

        // method to test
        instance.purchaseService(input, output);
        // Assertions here.
        System.out.println(testLoggingKey + StringUtils.SPACE + argumentCaptor.getValue().toJson());
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        assertTrue(multiReq.getRequestList().get(0) instanceof MtxRequestSubscriberPurchaseOffer);
        assertTrue(multiReq.getRequestList().get(1) instanceof MtxRequestSubscriberPurchaseOffer);
        MtxRequestSubscriberPurchaseOffer referralPurchaseReq = (MtxRequestSubscriberPurchaseOffer) multiReq.getRequestList().get(
                0);
        assertEquals(
                aop.getAtCredits(0).getCreditRedeemableOfferCI(),
                referralPurchaseReq.getOfferRequestArray().get(0).getExternalId());

        assertEquals(RESULT_CODES.MTX_SUCCESS, output.getResult());

        VisiblePurchasedOfferExtension visibleOffer = (VisiblePurchasedOfferExtension) referralPurchaseReq.getOfferRequestArray().get(
                0).getAttr();
        assertEquals(
                0, visibleOffer.getChargeAmount().compareTo(
                        aop.getCredits().get(0).getEstimatedTransferableCredits()));

        assertNull(visibleOffer.getTaxDetails());

        MtxRequestSubscriberPurchaseOffer purchaseReq = (MtxRequestSubscriberPurchaseOffer) multiReq.getRequestList().get(
                1);
        visibleOffer = (VisiblePurchasedOfferExtension) purchaseReq.getOfferRequestArray().get(
                0).getAttr();

        assertNotNull(visibleOffer.getCreditTaxDetailsArray());

    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_purchaseService_referral_credit_AOP_NoBalAmt(TestInfo testInfo)
            throws Exception {

        String testLoggingKey = getTestLoggingKey(testInfo.getDisplayName());

        String service = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", service);

        MtxResponseMulti multiResMainBal = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());

        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);
        Map<String, BigDecimal> promoGrantCiRedeemMap = Map.of(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.TEN);
        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                service, "", "", promoGrantCiRedeemMap, wallet);
        aop.setAvailableMainBalanceAmount(
                CommonTestHelper.getOfferPrice(service).subtract(BigDecimal.TEN));
        aop.setConsumableMainBalanceAmount(aop.getAvailableMainBalanceAmount());
        aop.getAtCredits(0).setAvailableCreditsConsumable(
                aop.getAtCredits(0).getRedeemableCredits());
        aop.getAtCredits(0).setAvailableCreditsGrant(BigDecimal.ZERO);
        aop.getAtCredits(0).setEstimatedTransferableCredits(BigDecimal.ZERO);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleResponsePurchaseService output = new VisibleResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, List.of(service));
        doReturn("").when(instance).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResMainBal).doReturn(multiRes).when(instance).multiRequest(
                any(), any(), argumentCaptor.capture());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());

        // method to test
        instance.purchaseService(input, output);
        // Assertions here.
        System.out.println(testLoggingKey + StringUtils.SPACE + argumentCaptor.getValue().toJson());
        MtxRequestMulti multiReq = argumentCaptor.getValue();

        assertTrue(multiReq.getRequestList().get(0) instanceof MtxRequestSubscriberPurchaseOffer);
        assertEquals(2, multiReq.getRequestList().size());
        assertEquals(RESULT_CODES.MTX_SUCCESS, output.getResult());
    }

    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_purchaseService_referral_credit_AOP_NoTaxDetails(TestInfo testInfo)
            throws Exception {

        String testLoggingKey = getTestLoggingKey(testInfo.getDisplayName());
        String service = CI_EXTERNAL_IDS.UNLIMITED;
        VisibleRequestPurchaseService input = CommonTestHelper.getVisibleMultiRequestPurchaseService(
                "1234", service);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        MtxResponseMulti multiResMainBal = CommonTestHelper.getEmptyMtxResponseMulti();

        MtxResponseSubscription subRes = CommonTestHelper.getMtxResponseSubscription_Autopay(
                input.getSubscriberExternalId());

        MtxResponseWallet wallet = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);

        Map<String, BigDecimal> promoGrantCiRedeemMap = Map.of(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.valueOf(10));

        VisibleResponsePurchaseAdvice aop = CommonTestHelper.getPurchaseAdvice(
                service, "", "", promoGrantCiRedeemMap, wallet);
        aop.getAtCredits(0).setTaxDetails(null);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.UNLIMITED_DATA);

        VisibleResponsePurchaseService output = new VisibleResponsePurchaseService();
        // mocks
        emulateMtxResponsePricingCatalogItems(instance, List.of(service));
        doReturn("").when(instance).getRoute(any());
        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResMainBal).doReturn(multiRes).when(instance).multiRequest(
                any(), any(), argumentCaptor.capture());
        doReturn(subRes).when(instance).querySubscriptionData(any(), any());
        doReturn(aop).when(aopInstance).getPurchaseAdvice(any(), any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());

        // method to test
        instance.purchaseService(input, output);

        // Assertions here.
        System.out.println(testLoggingKey + StringUtils.SPACE + argumentCaptor.getValue().toJson());
        MtxRequestMulti multiReq = argumentCaptor.getValue();

        assertEquals(3, multiReq.getRequestList().size());
        assertTrue(multiReq.getRequestList().get(0) instanceof MtxRequestSubscriberPurchaseOffer);
        assertTrue(multiReq.getRequestList().get(1) instanceof MtxRequestSubscriberPurchaseOffer);
        assertTrue(multiReq.getRequestList().get(2) instanceof MtxRequestSubscriptionModify);
        assertEquals(RESULT_CODES.MTX_SUCCESS, output.getResult());

        MtxRequestSubscriberPurchaseOffer referralPurchaseReq = (MtxRequestSubscriberPurchaseOffer) multiReq.getRequestList().get(
                1);
        VisiblePurchasedOfferExtension visibleOffer = (VisiblePurchasedOfferExtension) referralPurchaseReq.getOfferRequestArray().get(
                0).getAttr();
        assertNull(visibleOffer.getCreditTaxDetailsArray());
    }

}
