package com.matrixx.vag.advice.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doReturn;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixx.datacontainer.MtxDate;
import com.matrixx.datacontainer.MtxObjectId;
import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.EventQueryEventInfo;
import com.matrixx.datacontainer.mdc.EventQueryResponseEvents;
import com.matrixx.datacontainer.mdc.MtxBalanceImpactInfo;
import com.matrixx.datacontainer.mdc.MtxBalanceInfo;
import com.matrixx.datacontainer.mdc.MtxPricingMetadataInfo;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferData;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.MtxRecurringEvent;
import com.matrixx.datacontainer.mdc.MtxResponseGroup;
import com.matrixx.datacontainer.mdc.MtxResponseOneTimeOffer;
import com.matrixx.datacontainer.mdc.MtxResponsePricingCatalogItem;
import com.matrixx.datacontainer.mdc.MtxResponsePurchase;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.MtxResponseWallet;
import com.matrixx.datacontainer.mdc.PurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.SubscriptionResponse;
import com.matrixx.datacontainer.mdc.VisibleChangeServiceAddItem;
import com.matrixx.datacontainer.mdc.VisibleChangeServiceCancelItem;
import com.matrixx.datacontainer.mdc.VisibleChangeServicePromo;
import com.matrixx.datacontainer.mdc.VisibleOfferDetails;
import com.matrixx.datacontainer.mdc.VisiblePromoExtension;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleRequestChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleResponseChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleSubscriberExtension;
import com.matrixx.datacontainer.mdc.VisibleTemplate;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.advice.model.CreditStage;
import com.matrixx.vag.advice.model.GlobalCreditStage;
import com.matrixx.vag.advice.model.PromoOfferPair;
import com.matrixx.vag.advice.model.ServiceStage;
import com.matrixx.vag.advice.model.SubscriberGroup;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.CHANGE_SERVICE_CONSTANTS;
import com.matrixx.vag.common.Constants.CI_METADATA;
import com.matrixx.vag.common.Constants.CREDIT_CONSTANTS;
import com.matrixx.vag.common.Constants.EXCEPTION_MESSAGES;
import com.matrixx.vag.common.Constants.GENERIC_CONSTANTS;
import com.matrixx.vag.common.Constants.GROUP_CONSTANTS;
import com.matrixx.vag.common.Constants.OFFER_CONSTANTS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.OneParameterTest;
import com.matrixx.vag.common.TestConstants;
import com.matrixx.vag.common.TestConstants.BALANCE_NAMES;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestConstants.DATA_DIR;
import com.matrixx.vag.common.TestConstants.DATE_TIME_CONSTANTS;
import com.matrixx.vag.common.TestConstants.OFFER_PRICES;
import com.matrixx.vag.common.TestConstants.TAX_CLASS_CODES;
import com.matrixx.vag.common.TestUtils;
import com.matrixx.vag.common.ThreeParameterTest;
import com.matrixx.vag.common.TwoParameterTest;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.InvalidRequestException;
import com.matrixx.vag.tax.client.TaxApiClient;
import com.matrixx.vag.tax.model.ServiceTaxRequest;
import com.matrixx.vag.tax.model.ServiceTaxResponse;
import com.matrixx.vag.util.MDCTest;

public class ChangeServiceAdviceTest extends MDCTest {

    @Spy
    @InjectMocks
    private PaymentAdviceService instance = new PaymentAdviceService();

    @Mock
    private SubscriberManagementApi api;

    private TestInfo testInfo;

    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        instance = new PaymentAdviceService();
        MockitoAnnotations.openMocks(this);
        this.testInfo = testInfo;
        doReturn("").when(instance).getRoute(any());
    }

    @Test
    public void test_getChangeServiceAdvice_When_NewOffer_SameAs_EnrolledOffer_Then_Exception(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has base offer."
        };
        td.when = new String[] {
            "Api is called with same offer."
        };
        td.then = new String[] {
            "Throw Exception"
        };
        td.printDescription();

        String subscriptionExternalId = "123";
        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        String ciExternalId = "XYZ123";
        request.setNewCatalogItemExternalId(ciExternalId);
        request.setGrossPrice(BigDecimal.valueOf(100));
        request.setDiscountPrice(BigDecimal.valueOf(40));
        request.setSubscriptionExternalId(subscriptionExternalId);
        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poUnlimited = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.UNLIMITED);
        poUnlimited.setCatalogItemExternalId(ciExternalId);

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, ciExternalId);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();

        // get a random pci and change ciId
        MtxResponsePricingCatalogItem pci = CommonTestHelper.getMtxResponsePricingCatalogItem(
                CI_EXTERNAL_IDS.UNLIMITED);
        pci.getCatalogItemInfo().setExternalId(ciExternalId);
        emulateMtxResponsePricingCatalogItem(instance, pci, ciExternalId);
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.getChangeServiceAdvice(request, response));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertEquals(ciExternalId + " is already an active offer.", exception.getMessage().trim());
    }

    @Test
    public void test_getChangeServiceAdvice_When_NewOffer_Not_Enrollable_Then_Exception(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has base offer."
        };
        td.when = new String[] {
            "Api is called with new offer. New offer is not enrollable"
        };
        td.then = new String[] {
            "Throw Exception"
        };
        td.printDescription();

        String subscriptionExternalId = "123";
        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.UNLIMITED);
        request.setGrossPrice(BigDecimal.valueOf(100));
        request.setDiscountPrice(BigDecimal.valueOf(40));
        request.setSubscriptionExternalId(subscriptionExternalId);
        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        CommonTestHelper.getMtxPurchasedOfferInfo(subscription, CI_EXTERNAL_IDS.UNLIMITED);

        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.UNLIMITED);
        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.getChangeServiceAdvice(request, response));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertEquals(
                EXCEPTION_MESSAGES.CAN_NOT_ENROLL_WITH_CHANGE_SERVICE.trim(),
                exception.getMessage().trim());
    }

    @Test
    public void test_getChangeServiceAdvice_When_Subscription_Has_NoActiveBaseOffer_Then_Exception(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has no enrolled base offer."
        };
        td.when = new String[] {
            "Api is called with valid parameters."
        };
        td.then = new String[] {
            "Exception."
        };
        td.printDescription();

        String subscriptionExternalId = "123";
        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        String newCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        request.setNewCatalogItemExternalId(newCiId);
        request.setGrossPrice(BigDecimal.valueOf(100));
        BigDecimal newDiscountPrice = BigDecimal.valueOf(30);
        request.setDiscountPrice(newDiscountPrice);
        request.setSubscriptionExternalId(subscriptionExternalId);
        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        CommonTestHelper.getMtxPurchasedOfferInfo(subscription, CI_EXTERNAL_IDS.WEARABLE);

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, CI_EXTERNAL_IDS.WEARABLE);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.WEARABLE));
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();

        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(CI_EXTERNAL_IDS.WEARABLE, newCiId));

        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));

        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.getChangeServiceAdvice(request, response));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertEquals(
                "Subscription does not have active enrolled offer that is of the same type as "
                        + newCiId,
                exception.getMessage().trim());
    }

    @SuppressWarnings({
        "unchecked"
    })
    @Test
    public void test_getChangeServiceAdvice_When_Subscription_Has_PaidCycleStartDate_Then_Return_As_Per_Subscription(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has PaidCycleStartDate in one of the enrolled offers."
        };
        td.when = new String[] {
            "Api is called with valid parameters."
        };
        td.then = new String[] {
            "PaidCycleStartDate from subscription is returned."
        };
        td.printDescription();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        String subscriptionExternalId = "123";
        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        String newCiId = CI_EXTERNAL_IDS.PLUS_CURRENT;
        String oldCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        request.setNewCatalogItemExternalId(newCiId);
        request.setGrossPrice(BigDecimal.valueOf(100));
        BigDecimal discountPrice = BigDecimal.valueOf(30);
        request.setDiscountPrice(discountPrice);
        request.setSubscriptionExternalId(subscriptionExternalId);
        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        String randomDateInPast = "1900-01-01";
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poUnlimited = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCiId);
        VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poUnlimited.getAttr();
        poExtn.setPaidCycleStartDate(new MtxDate(randomDateInPast));
        subscription.getPurchasedOfferArrayAppender().add(poUnlimited);

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCiId);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomDateInPast));

        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(oldCiId, newCiId, CI_EXTERNAL_IDS.BASE_2535_GRANT));

        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                oldCiId);
        BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
        vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                CI_EXTERNAL_IDS.WEARABLE);
        BigDecimal mainbalanceWearables = BigDecimal.valueOf(5);
        vodWearable.setConsumableMainBalanceAmount(mainbalanceWearables);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodUnlimited.getCatalogItemExternalId(), Long.valueOf(vodUnlimited.getResourceId()),
                vodUnlimited);
        aopStage.appendVisibleOfferDetailsMap(
                vodWearable.getCatalogItemExternalId(), Long.valueOf(vodWearable.getResourceId()),
                vodWearable);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                newCiId);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);

        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    "");
            instance.getChangeServiceAdvice(request, response);
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        assertEquals(randomDateInPast, response.getPaidCycleStartDate().toString());
    }

    @SuppressWarnings({
        "unchecked"
    })
    @Test
    public void test_getChangeServiceAdvice_When_Subscription_Has_No_PaidCycleStartDate_Then_Return_NoPaidCycleStartDate(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription does not have PaidCycleStartDate in any of enrolled offers."
        };
        td.when = new String[] {
            "Api is called with valid parameters."
        };
        td.then = new String[] {
            "PaidCycleStartDate is defaulted to yesterday."
        };
        td.printDescription();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        String subscriptionExternalId = "123";
        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        String newCiId = CI_EXTERNAL_IDS.PLUS_CURRENT;
        String oldCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        request.setNewCatalogItemExternalId(newCiId);
        request.setGrossPrice(BigDecimal.valueOf(100));
        BigDecimal discountPrice = BigDecimal.valueOf(30);
        request.setDiscountPrice(discountPrice);
        request.setSubscriptionExternalId(subscriptionExternalId);
        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poUnlimited = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCiId);
        VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poUnlimited.getAttr();
        poExtn.setPaidCycleStartDate(null);
        subscription.getPurchasedOfferArrayAppender().add(poUnlimited);

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCiId);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(null);

        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(oldCiId, newCiId));

        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));

        VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                oldCiId);
        BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
        vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                CI_EXTERNAL_IDS.WEARABLE);
        BigDecimal mainbalanceWearables = BigDecimal.valueOf(5);
        vodWearable.setConsumableMainBalanceAmount(mainbalanceWearables);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodUnlimited.getCatalogItemExternalId(), Long.valueOf(vodUnlimited.getResourceId()),
                vodUnlimited);
        aopStage.appendVisibleOfferDetailsMap(
                vodWearable.getCatalogItemExternalId(), Long.valueOf(vodWearable.getResourceId()),
                vodWearable);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                newCiId);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);

        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    "");
            instance.getChangeServiceAdvice(request, response);
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        assertNull(response.getPaidCycleStartDate());
    }

    @SuppressWarnings({
        "unchecked"
    })
    @Test
    public void test_getChangeServiceAdvice_When_ValidNewOffer_Then_NewOfferInResponse(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has valid offer."
        };
        td.when = new String[] {
            "Api is called with valid new offer."
        };
        td.then = new String[] {
            "New offer present in response with CatalogItemExternalId, DiscountPrice and GrossPrice."
        };
        td.printDescription();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        String subscriptionExternalId = "123";
        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        String newCiId = CI_EXTERNAL_IDS.PLUS_CURRENT;
        String oldCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        request.setNewCatalogItemExternalId(newCiId);
        BigDecimal newGrossPrice = BigDecimal.valueOf(100);
        request.setGrossPrice(newGrossPrice);
        BigDecimal newDiscountPrice = BigDecimal.valueOf(30);
        request.setDiscountPrice(newDiscountPrice);
        request.setSubscriptionExternalId(subscriptionExternalId);
        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poUnlimited = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCiId);
        VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poUnlimited.getAttr();
        poExtn.setPaidCycleStartDate(null);
        subscription.getPurchasedOfferArrayAppender().add(poUnlimited);

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCiId);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(null);

        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(oldCiId, newCiId, CI_EXTERNAL_IDS.BASE_2535_GRANT));

        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));

        VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                oldCiId);
        BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
        vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                CI_EXTERNAL_IDS.WEARABLE);
        BigDecimal mainbalanceWearables = BigDecimal.valueOf(5);
        vodWearable.setConsumableMainBalanceAmount(mainbalanceWearables);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodUnlimited.getCatalogItemExternalId(), Long.valueOf(vodUnlimited.getResourceId()),
                vodUnlimited);
        aopStage.appendVisibleOfferDetailsMap(
                vodWearable.getCatalogItemExternalId(), Long.valueOf(vodWearable.getResourceId()),
                vodWearable);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                newCiId);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);

        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    "");
            instance.getChangeServiceAdvice(request, response);
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        assertEquals(newCiId, response.getNewCatalogItem().getCatalogItemExternalId());
        assertEquals(
                newGrossPrice.intValue(), response.getNewCatalogItem().getGrossPrice().intValue());
        assertEquals(
                newDiscountPrice.intValue(),
                response.getNewCatalogItem().getDiscountPrice().intValue());
    }

    @SuppressWarnings({
        "unchecked"
    })
    @Test
    public void test_getChangeServiceAdvice_When_ValidNewOffer_Then_OldOfferInResponse(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has valid offer."
        };
        td.when = new String[] {
            "Api is called with valid new offer."
        };
        td.then = new String[] {
            "Enrolled offer present in response with CatalogItemExternalId, ResourceId, DiscountPrice, GrossPrice."
        };
        td.printDescription();

        String subscriptionExternalId = "123";
        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        String newCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        String oldCiId = CI_EXTERNAL_IDS.PLUS_CURRENT;
        request.setNewCatalogItemExternalId(newCiId);
        request.setGrossPrice(BigDecimal.valueOf(100));
        request.setDiscountPrice(CommonTestHelper.getOfferPrice(newCiId));
        request.setSubscriptionExternalId(subscriptionExternalId);
        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poPlus = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCiId);
        VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poPlus.getAttr();
        poExtn.setPaidCycleStartDate(null);
        subscription.getPurchasedOfferArrayAppender().add(poPlus);

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCiId);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(null);

        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(oldCiId, newCiId));

        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));

        VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                oldCiId);
        BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
        vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                CI_EXTERNAL_IDS.WEARABLE);
        BigDecimal mainbalanceWearables = BigDecimal.valueOf(5);
        vodWearable.setConsumableMainBalanceAmount(mainbalanceWearables);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodUnlimited.getCatalogItemExternalId(), Long.valueOf(vodUnlimited.getResourceId()),
                vodUnlimited);
        aopStage.appendVisibleOfferDetailsMap(
                vodWearable.getCatalogItemExternalId(), Long.valueOf(vodWearable.getResourceId()),
                vodWearable);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                newCiId);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);

        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        instance.getChangeServiceAdvice(request, response);
        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(newCiId, response.getNewCatalogItem().getCatalogItemExternalId());
        long expectedResourceId = poPlus.getResourceId();
        assertEquals(
                expectedResourceId, response.getCurrentCatalogItem().getResourceId().longValue());
        int expectedDiscountPrice = poExtn.getChargeAmount().intValue();
        assertEquals(
                expectedDiscountPrice,
                response.getCurrentCatalogItem().getDiscountPrice().intValue());
        ServiceTaxResponse currentTaxDetails = CommonUtils.getServiceTaxResponseFromJsonString(
                enrolledPoiExtn.getTaxDetails());
        int expectedGrossPrice = currentTaxDetails.getGrossPrice().intValue();
        assertEquals(
                expectedGrossPrice, response.getCurrentCatalogItem().getGrossPrice().intValue());
    }

    @SuppressWarnings({
        "unchecked", "serial"
    })
    @Test
    public void test_getChangeServiceAdvice_Given_Subscriber_In_Group_Then_GroupDetails_In_Response(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscriber is in a group."
        };
        td.when = new String[] {
            "."
        };
        td.then = new String[] {
            "SubscriberGroups should be returned with GroupExternalId, GroupName, GroupTier, SubscriberMemberCount."
        };
        td.printDescription();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        String subscriptionExternalId = "123";
        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        // String newCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.BASE_CURRENT);
        request.setGrossPrice(BigDecimal.valueOf(100));
        // BigDecimal newDiscountPrice = BigDecimal.valueOf(30);
        request.setDiscountPrice(
                CommonTestHelper.getOfferPrice(request.getNewCatalogItemExternalId()));
        request.setSubscriptionExternalId(subscriptionExternalId);
        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        String oldCi = CI_EXTERNAL_IDS.PLUS_CURRENT;
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poPlus = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCi);
        VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poPlus.getAttr();
        poExtn.setPaidCycleStartDate(null);
        subscription.getPurchasedOfferArrayAppender().add(poPlus);
        subscription.getParentGroupIdArrayAppender().clear();
        subscription.getParentGroupIdArrayAppender().add(new MtxObjectId("1-2-3-4"));

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCi);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCi));
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(null);

        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(oldCi, request.getNewCatalogItemExternalId()));

        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));

        VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                oldCi);
        BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
        vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                CI_EXTERNAL_IDS.WEARABLE);
        BigDecimal mainbalanceWearables = BigDecimal.valueOf(5);
        vodWearable.setConsumableMainBalanceAmount(mainbalanceWearables);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodUnlimited.getCatalogItemExternalId(), Long.valueOf(vodUnlimited.getResourceId()),
                vodUnlimited);
        aopStage.appendVisibleOfferDetailsMap(
                vodWearable.getCatalogItemExternalId(), Long.valueOf(vodWearable.getResourceId()),
                vodWearable);
        String subGroupName = "GN99";
        MtxResponseGroup respGrp = CommonTestHelper.getMtxResponseGroup(
                "PP-" + subscriptionExternalId, "Account", 4L,
                subscriptionResponse.getObjectId().toString(), "1-2-3-4", "6-7-8-9", "4-3-2-1");
        SubscriberGroup sg = new SubscriberGroup(respGrp);
        aopStage.appendSubscriberGroupList(sg);
        sg.setGroupName(subGroupName);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));

        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

        emulateSubscriptionGroup(instance, new HashMap<String, String>() {

            {
                put("GroupName", subGroupName);
            }
        });

        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                request.getNewCatalogItemExternalId());
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);
        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        instance.getChangeServiceAdvice(request, response);
        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(subGroupName, response.getAtSubscriberGroups(0).getGroupName());
    }

    @SuppressWarnings({
        "unchecked"
    })
    @Test
    public void test_getChangeServiceAdvice_When_ChangeCycleOnly_Then_Use_All_Mainbalance(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription PaidCycleStartDate before today. This means Manual Pay is not run for next cycle."
        };
        td.when = new String[] {
            "Api is called with valid parameters."
        };
        td.then = new String[] {
            "Allocate max. mainbalance to new offer."
        };
        td.printDescription();

        String subscriptionExternalId = "123";
        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        String newCiId = CI_EXTERNAL_IDS.PRO_CURRENT;
        String oldCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        request.setNewCatalogItemExternalId(newCiId);
        request.setGrossPrice(BigDecimal.valueOf(100));
        request.setDiscountPrice(BigDecimal.valueOf(45));
        request.setSubscriptionExternalId(subscriptionExternalId);
        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        String randomPastDate = "1900-01-01";
        BigDecimal enroldCiPrice = BigDecimal.valueOf(40);
        BigDecimal mainbalance = BigDecimal.valueOf(40);

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poUnlimited = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCiId);
        VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poUnlimited.getAttr();
        poExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));
        subscription.getPurchasedOfferArrayAppender().add(poUnlimited);

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(subscriptionExternalId, mainbalance));
        PurchasedOfferInfo poiPlus = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCiId);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiPlus.getAttr();
        enrolledPoiExtn.setChargeAmount(enroldCiPrice);
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(oldCiId, newCiId, CI_EXTERNAL_IDS.PLUS_2535_GRANT));

        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));
        VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                oldCiId);
        BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
        vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                CI_EXTERNAL_IDS.WEARABLE);
        BigDecimal mainbalanceWearables = BigDecimal.valueOf(5);
        vodWearable.setConsumableMainBalanceAmount(mainbalanceWearables);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodUnlimited.getCatalogItemExternalId(), Long.valueOf(vodUnlimited.getResourceId()),
                vodUnlimited);
        aopStage.appendVisibleOfferDetailsMap(
                vodWearable.getCatalogItemExternalId(), Long.valueOf(vodWearable.getResourceId()),
                vodWearable);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());
        BigDecimal aocAmount = BigDecimal.valueOf(45);
        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                newCiId);
        biiMain.setImpactAmount(aocAmount);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);
        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        String taxApiResp = CommonTestHelper.getTaxApiResp(newCiId);
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp);
            instance.getChangeServiceAdvice(request, response);
        }
        System.out.println(td.getTestMethod() + ":" + response.toJson());
        assertEquals(
                mainbalance.intValue(),
                response.getChangeCycle().getConsumableMainBalance().intValue());
    }

    @SuppressWarnings({
        "unchecked"
    })
    @Test
    public void test_getChangeServiceAdvice_When_Core2CoreDowngrade_Then_ZeroPayments(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has PLUS2VIS22WB."
        };
        td.when = new String[] {
            "Api is called with BASE2VISIBLE22."
        };
        td.then = new String[] {
            "ChangeCycle should show ZERO value for AocAmount, ConsumableMainBalance, PayableAmount, TotalAmount.",
            "TaxDetails should be empty / null / blank", "There should be no Credits node."
        };
        td.printDescription();
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        String subscriptionExternalId = "123";
        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        String newCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        String oldCiId = CI_EXTERNAL_IDS.PLUS_CURRENT;
        request.setNewCatalogItemExternalId(newCiId);
        request.setGrossPrice(BigDecimal.valueOf(100));
        BigDecimal newDiscountPrice = BigDecimal.valueOf(30);
        request.setDiscountPrice(newDiscountPrice);
        request.setSubscriptionExternalId(subscriptionExternalId);
        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poPlus = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCiId);
        VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poPlus.getAttr();
        poExtn.setPaidCycleStartDate(null);
        subscription.getPurchasedOfferArrayAppender().add(poPlus);

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCiId);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(null);

        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(oldCiId, newCiId));

        MtxResponseWallet wallet = emulateMtxResponseWallet(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        wallet.getBillingCycle().setCurrentPeriodEndTime(
                new MtxTimestamp(
                        System.currentTimeMillis() + DATE_TIME_CONSTANTS.MILLISECONDS_IN_A_DAY));

        VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                oldCiId);
        BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
        vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                CI_EXTERNAL_IDS.WEARABLE);
        BigDecimal mainbalanceWearables = BigDecimal.valueOf(5);
        vodWearable.setConsumableMainBalanceAmount(mainbalanceWearables);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodUnlimited.getCatalogItemExternalId(), Long.valueOf(vodUnlimited.getResourceId()),
                vodUnlimited);
        aopStage.appendVisibleOfferDetailsMap(
                vodWearable.getCatalogItemExternalId(), Long.valueOf(vodWearable.getResourceId()),
                vodWearable);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                newCiId);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);

        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        instance.getChangeServiceAdvice(request, response);
        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(0, response.getChangeCycle().getAocAmount().intValue());
        assertEquals(0, response.getChangeCycle().getTotalAmount().intValue());
        assertEquals(0, response.getChangeCycle().getConsumableMainBalance().intValue());
        assertEquals(0, response.getChangeCycle().getPayableAmount().intValue());
    }

    @SuppressWarnings({
        "unchecked"
    })
    @Test
    public void test_getChangeServiceAdvice_When_ChangeCycleOnly_Then_TaxOnProratedPriceDifference(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with base offer. PaidCycleStartDate is in past."
        };
        td.when = new String[] {
            "Api is called with new base offer. Delta needs to be paid for change cycle."
        };
        td.then = new String[] {
            "Tax Api should be called with FeeOnly template. DiscountPrice=Proration of difference between old and new price "
        };

        TwoParameterTest pTests = (oldCi, newCi) -> {
            td.printDescription();
            String randomPastDate = "1900-01-01";
            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(newCi.toString());
            request.setDiscountPrice(CommonTestHelper.getOfferPrice(newCi.toString()));
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            String oldCiId = oldCi.toString();
            BigDecimal enroldCiPrice = BigDecimal.valueOf(40);
            BigDecimal mainbalance = BigDecimal.valueOf(40);
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCiId);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            poExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscriptionExternalId));
            PurchasedOfferInfo poiPlus = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCiId);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiPlus.getAttr();
            enrolledPoiExtn.setChargeAmount(enroldCiPrice);
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

            emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            oldCiId, CI_EXTERNAL_IDS.BASE_2535_GRANT,
                            CI_EXTERNAL_IDS.PLUS_2535_GRANT));

            MtxResponsePricingCatalogItem pci = emulateMtxResponsePricingCatalogItem(
                    instance, request.getNewCatalogItemExternalId());
            pci.getCatalogItemInfo().setExternalId(request.getNewCatalogItemExternalId());
            String deltaTaxInputMsgID = "XYZDELTAXYZ";
            String deltaTaxInput = "{   \"msgID\":" + "\"" + deltaTaxInputMsgID + "\""
                    + ",   \"customerType\": \"99\",   \"planID\": \"BASE001A\",   \"grossPrice\": \"0\",   \"discountPrice\": \"0\",   \"geocode\": \"US\",   \"glDate\": \"2019-09-01\",   \"taxTreatment\": \"inclusive\",   \"classCode\": \"SVC\",   \"offer606RevAdjDailyRecog\": \"0\",   \"promotionCredit\": false,   \"dpcGroupList\": [     {       \"dpcGroup\": \"5018\",       \"dpcItemList\": [         {           \"dpcItem\": \"618\",           \"cP\": \".9719167977\",           \"cycleNSR\": \"0\",           \"glReference\": \"Visible_Unlimited_Data\"         },         {           \"dpcItem\": \"601\",           \"cP\": \".0238925768\",           \"cycleNSR\": \"0\",           \"glReference\": \"Visible_Unlimited_Voice\"         },         {           \"dpcItem\": \"662\",           \"cP\": \".0000041959\",           \"cycleNSR\": \"0\",           \"glReference\": \"Visible_Unlimited_Text\"         },         {           \"dpcItem\": \"629\",           \"cP\": \".0041864296\",           \"cycleNSR\": \"0\",           \"glReference\": \"Visible_Unlimited_MMS\"         }       ]     }   ] }";
            MtxPricingMetadataInfo pmi = new MtxPricingMetadataInfo();
            pmi.setName(CI_METADATA.CHANGE_CYCLE_DELTA_TAX_INPUT);
            pmi.setType("String");
            pmi.setValue(deltaTaxInput);
            pci.getCatalogItemInfo().getMetadataListAppender().add(pmi);
            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));
            VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    oldCiId);
            BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
            vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

            VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    CI_EXTERNAL_IDS.WEARABLE);
            BigDecimal mainbalanceWearables = BigDecimal.valueOf(5);
            vodWearable.setConsumableMainBalanceAmount(mainbalanceWearables);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodUnlimited.getCatalogItemExternalId(),
                    Long.valueOf(vodUnlimited.getResourceId()), vodUnlimited);
            aopStage.appendVisibleOfferDetailsMap(
                    vodWearable.getCatalogItemExternalId(),
                    Long.valueOf(vodWearable.getResourceId()), vodWearable);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            BigDecimal aocAmount = BigDecimal.valueOf(45);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchase(
                    request.getNewCatalogItemExternalId(), aocAmount);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxApiResp = CommonTestHelper.getTaxApiResp(newCi.toString());
            ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(
                                any(), argumentCaptor.capture())).thenReturn(taxApiResp);
                instance.getChangeServiceAdvice(request, response);
            }
            argumentCaptor.getAllValues().forEach(val -> {
                try {
                    ServiceTaxRequest taxReq = CommonTestHelper.getJsonFromString(
                            ServiceTaxRequest.class, val);
                    System.out.println(td.getTestMethod() + ":" + taxReq.toJson());
                    assertEquals(deltaTaxInputMsgID, taxReq.getMsgID());
                    assertEquals(
                            aocAmount.doubleValue(), taxReq.getDiscountPrice().doubleValue(), 0.01);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        };

        td.printDescription();
        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT);
    }

    @SuppressWarnings({
        "unchecked"
    })
    @Test
    public void test_getChangeServiceAdvice_When_ChangeCycleOnly_Core2CoreDowngrade_Then_NoTaxes(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with PLUS2VIS22WB. PaidCycleStartDate is in past."
        };
        td.when = new String[] {
            "Api is called with BASE2VISIBLE22. "
        };
        td.then = new String[] {
            "No Taxes."
        };
        td.printDescription();
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        String subscriptionExternalId = "123";
        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        String newCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        String oldCiId = CI_EXTERNAL_IDS.PLUS_CURRENT;
        request.setNewCatalogItemExternalId(newCiId);
        request.setGrossPrice(BigDecimal.valueOf(100));
        BigDecimal newDiscountPrice = BigDecimal.valueOf(30);
        request.setDiscountPrice(newDiscountPrice);
        request.setSubscriptionExternalId(subscriptionExternalId);
        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poPlus = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCiId);
        VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poPlus.getAttr();
        poExtn.setPaidCycleStartDate(null);

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCiId);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(null);

        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(oldCiId, newCiId));

        MtxResponseWallet wallet = emulateMtxResponseWallet(
                instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        wallet.getBillingCycle().setCurrentPeriodEndTime(
                new MtxTimestamp(
                        System.currentTimeMillis() + DATE_TIME_CONSTANTS.MILLISECONDS_IN_A_DAY));

        VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                CI_EXTERNAL_IDS.UNLIMITED);
        BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
        vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                CI_EXTERNAL_IDS.WEARABLE);
        BigDecimal mainbalanceWearables = BigDecimal.valueOf(5);
        vodWearable.setConsumableMainBalanceAmount(mainbalanceWearables);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodUnlimited.getCatalogItemExternalId(), Long.valueOf(vodUnlimited.getResourceId()),
                vodUnlimited);
        aopStage.appendVisibleOfferDetailsMap(
                vodWearable.getCatalogItemExternalId(), Long.valueOf(vodWearable.getResourceId()),
                vodWearable);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                newCiId);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);
        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        instance.getChangeServiceAdvice(request, response);
        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertTrue(StringUtils.isBlank(response.getChangeCycle().getTaxDetails()));
    }

    @SuppressWarnings({
        "unchecked"
    })
    @Test
    public void test_getChangeServiceAdvice_When_GeoCodeInAdviceRequest_Then_GeocodeInTaxRequest(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with base offer. PaidCycleStartDate is in past."
        };
        td.when = new String[] {
            "Api is called with valid base offer and geocode. Delta for change cycle"
        };
        td.then = new String[] {
            "Geocode from change service advice request is passed to taxapi."
        };
        td.printDescription();

        String subscriptionExternalId = "123";
        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        String newCiId = CI_EXTERNAL_IDS.PLUS_CURRENT;
        String oldCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        request.setNewCatalogItemExternalId(newCiId);
        request.setGrossPrice(BigDecimal.valueOf(100));
        request.setDiscountPrice(BigDecimal.valueOf(45));
        request.setSubscriptionExternalId(subscriptionExternalId);
        String geoCode = "XYZGEOCODE";
        request.setTaxGeoCode(geoCode);
        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        String randomPastDate = "1900-01-01";
        BigDecimal mainbalance = BigDecimal.valueOf(40);

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poUnlimited = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCiId);
        VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poUnlimited.getAttr();
        poExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCiId);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(oldCiId, CI_EXTERNAL_IDS.PLUS_2535_GRANT));
        MtxResponsePricingCatalogItem pci = emulateMtxResponsePricingCatalogItem(instance, newCiId);
        String deltaTaxInputMsgID = "XYZDELTAXYZ";
        String deltaTaxInput = "{   \"msgID\":" + "\"" + deltaTaxInputMsgID + "\""
                + ", \"customerType\": \"99\", \"planID\": \"BASE001A\", \"grossPrice\": \"0\", \"discountPrice\": \"0\", \"geocode\": \"US\", \"glDate\": \"2019-09-01\", \"taxTreatment\": \"inclusive\", \"classCode\": \"SVC\", \"offer606RevAdjDailyRecog\": \"0\", \"promotionCredit\": false, \"dpcGroupList\": [{ \"dpcGroup\": \"5018\",\"dpcItemList\": [{ \"dpcItem\": \"618\", \"cP\": \".9719167977\", \"cycleNSR\": \"0\", \"glReference\": \"Visible_Unlimited_Data\" }, { \"dpcItem\": \"601\", \"cP\": \".0238925768\", \"cycleNSR\": \"0\", \"glReference\": \"Visible_Unlimited_Voice\" }, { \"dpcItem\": \"662\", \"cP\": \".0000041959\", \"cycleNSR\": \"0\", \"glReference\": \"Visible_Unlimited_Text\" }, { \"dpcItem\": \"629\", \"cP\": \".0041864296\", \"cycleNSR\": \"0\", \"glReference\": \"Visible_Unlimited_MMS\" }]}]}";
        MtxPricingMetadataInfo pmi = new MtxPricingMetadataInfo();
        pmi.setName(CI_METADATA.CHANGE_CYCLE_DELTA_TAX_INPUT);
        pmi.setType("String");
        pmi.setValue(deltaTaxInput);
        pci.getCatalogItemInfo().getMetadataListAppender().add(pmi);
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

        VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                oldCiId);
        BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
        vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                CI_EXTERNAL_IDS.WEARABLE);
        BigDecimal mainbalanceWearables = BigDecimal.valueOf(5);
        vodWearable.setConsumableMainBalanceAmount(mainbalanceWearables);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodUnlimited.getCatalogItemExternalId(), Long.valueOf(vodUnlimited.getResourceId()),
                vodUnlimited);
        aopStage.appendVisibleOfferDetailsMap(
                vodWearable.getCatalogItemExternalId(), Long.valueOf(vodWearable.getResourceId()),
                vodWearable);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                newCiId);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);
        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        String taxApiResp = CommonTestHelper.getTaxApiResp(newCiId);
        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            instance.getChangeServiceAdvice(request, response);
        }
        argumentCaptor.getAllValues().forEach(val -> {
            try {
                ServiceTaxRequest taxReq = CommonTestHelper.getJsonFromString(
                        ServiceTaxRequest.class, val);
                System.out.println(td.getTestMethod() + ":" + taxReq.toJson());
                assertEquals(geoCode, taxReq.getGeocode());
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    @Test
    public void test_getChangeServiceAdvice_When_ChangeCycleOnly_Then_MinimumChargeNotApplicable(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with base offer. PaidCycleStartDate is in past."
        };
        td.when = new String[] {
            "Api is called with new base offer. Delta needs to be paid."
        };
        td.then = new String[] {
            "Minimum charge should not be applicable for Delta payment."
        };
        String subscriptionExternalId = "123";

        @SuppressWarnings("unchecked")
        ThreeParameterTest pTests = (oldCi, newCi, promoForNewOffer) -> {
            td.printDescription();
            String randomPastDate = "1900-01-01";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(newCi.toString());
            request.setDiscountPrice(CommonTestHelper.getOfferPrice(newCi.toString()));
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            BigDecimal mainbalance = BigDecimal.valueOf(40);
            String oldCiId = oldCi.toString();
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCiId);
            BigDecimal ref35Credits = BigDecimal.valueOf(5);
            VisiblePurchasedOfferExtension enrolledExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            enrolledExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));
            subscription.getPurchasedOfferArrayAppender().add(poEnrolled);
            if ((boolean) promoForNewOffer) {
                emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.REF35_GRANT);
                CommonTestHelper.getMtxPurchasedOfferInfo(
                        subscription, CI_EXTERNAL_IDS.REF35_GRANT, null, ref35Credits, null);
            }

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            subscription.getExternalId(), mainbalance));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCiId);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

            List<String> balPriList = Arrays.asList(BALANCE_NAMES.REF35_GRANT);
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));
            emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            oldCiId, request.getNewCatalogItemExternalId(),
                            CI_EXTERNAL_IDS.PLUS_2535_GRANT, CI_EXTERNAL_IDS.BASE_2535_GRANT));
            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    CI_EXTERNAL_IDS.UNLIMITED);
            BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
            vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

            VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    CI_EXTERNAL_IDS.WEARABLE);
            BigDecimal mainbalanceWearables = BigDecimal.valueOf(5);
            vodWearable.setConsumableMainBalanceAmount(mainbalanceWearables);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodUnlimited.getCatalogItemExternalId(),
                    Long.valueOf(vodUnlimited.getResourceId()), vodUnlimited);
            aopStage.appendVisibleOfferDetailsMap(
                    vodWearable.getCatalogItemExternalId(),
                    Long.valueOf(vodWearable.getResourceId()), vodWearable);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtn);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCiId);

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                    newCi.toString());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            String taxApiResp = CommonTestHelper.getTaxApiResp(newCi.toString());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxApiResp);
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertEquals(0, response.getRechargeAmount().intValue());
        };

        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT, true);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.BASE_CURRENT, true);
    }

    @Test
    public void test_getChangeServiceAdvice_When_ChangeCycleOnly_FixedFeeMoreThanAoc_Then_PayFixedFee(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription PaidCycleStartDate before today. This means Manual Pay is not run for next cycle.",
            "Promotions are present"
        };
        td.when = new String[] {
            "Api is called with new base offer. Taxes have fixed fee which is more than aoc"
        };
        td.then = new String[] {
            "Payable amount and total amount for service should be equal to fixedfeet."
        };
        @SuppressWarnings({
            "unchecked"
        })
        TwoParameterTest pTests = (oldCi, newCi) -> {
            td.printDescription();
            String randomPastDate = "1900-01-01";
            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(newCi.toString());
            request.setDiscountPrice(CommonTestHelper.getOfferPrice(newCi.toString()));
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            BigDecimal mainbalance = BigDecimal.valueOf(40);

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getPurchasedOfferArrayAppender().clear();

            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCi.toString());
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            poExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCi.toString());
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCi.toString()));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

            emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            oldCi.toString(), CI_EXTERNAL_IDS.BASE_2535_GRANT,
                            CI_EXTERNAL_IDS.PLUS_2535_GRANT));

            MtxResponsePricingCatalogItem pci = emulateMtxResponsePricingCatalogItem(
                    instance, request.getNewCatalogItemExternalId());
            String deltaTaxInputMsgID = "\"XYZDELTAXYZ\"";
            String deltaTaxInput = "{   \"msgID\":" + deltaTaxInputMsgID
                    + ",   \"customerType\": \"99\",   \"planID\": \"BASE001A\",   \"grossPrice\": \"0\",   \"discountPrice\": \"0\",   \"geocode\": \"US\",   \"glDate\": \"2019-09-01\",   \"taxTreatment\": \"inclusive\",   \"classCode\": \"SVC\",   \"offer606RevAdjDailyRecog\": \"0\",   \"promotionCredit\": false,   \"dpcGroupList\": [     {       \"dpcGroup\": \"5018\",       \"dpcItemList\": [         {           \"dpcItem\": \"618\",           \"cP\": \".9719167977\",           \"cycleNSR\": \"0\",           \"glReference\": \"Visible_Unlimited_Data\"         },         {           \"dpcItem\": \"601\",           \"cP\": \".0238925768\",           \"cycleNSR\": \"0\",           \"glReference\": \"Visible_Unlimited_Voice\"         },         {           \"dpcItem\": \"662\",           \"cP\": \".0000041959\",           \"cycleNSR\": \"0\",           \"glReference\": \"Visible_Unlimited_Text\"         },         {           \"dpcItem\": \"629\",           \"cP\": \".0041864296\",           \"cycleNSR\": \"0\",           \"glReference\": \"Visible_Unlimited_MMS\"         }       ]     }   ] }";
            MtxPricingMetadataInfo pmi = new MtxPricingMetadataInfo();
            pmi.setName(CI_METADATA.CHANGE_CYCLE_DELTA_TAX_INPUT);
            pmi.setType("String");
            pmi.setValue(deltaTaxInput);
            pci.getCatalogItemInfo().getMetadataListAppender().add(pmi);
            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    CI_EXTERNAL_IDS.UNLIMITED);
            BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
            vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

            VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    CI_EXTERNAL_IDS.WEARABLE);
            BigDecimal mainbalanceWearables = BigDecimal.valueOf(5);
            vodWearable.setConsumableMainBalanceAmount(mainbalanceWearables);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodUnlimited.getCatalogItemExternalId(),
                    Long.valueOf(vodUnlimited.getResourceId()), vodUnlimited);
            aopStage.appendVisibleOfferDetailsMap(
                    vodWearable.getCatalogItemExternalId(),
                    Long.valueOf(vodWearable.getResourceId()), vodWearable);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            BigDecimal aocAmount = BigDecimal.valueOf(1);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                    newCi.toString());
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(newCi.toString());
            BigDecimal fixedfee = BigDecimal.valueOf(1.81);

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxResp = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxResp.getTransactionElement().get(0).setTotalFeeAmount(fixedfee);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxResp.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());

            assertEquals(fixedfee, response.getChangeCycle().getPayableAmount());
        };

        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_CURRENT);
    }

    @Test
    @Disabled("Nib Plans are obsolete")
    public void test_getChangeServiceAdvice_ChangeCycleOnly_NibToCoreUpgrade_Then_CorrectChangeCycleOutput(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with base offer. PaidCycleStartDate is in past."
        };
        td.when = new String[] {
            "Api is called for NibToCoreUpgrade"
        };
        td.then = new String[] {
            "Validate ChangeCycleFields"
        };
    }

    @Test
    public void test_getChangeServiceAdvice_ChangeCycleOnly_With_Aoc_BasePriceImpactPromos_In_Event_Then_UseActuals(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with base offer. PaidCycleStartDate is in past.There are base price impacting credits present in recurring event."
        };
        td.when = new String[] {
            "Api is called for NibToCoreUpgrade"
        };
        td.then = new String[] {
            "Calculate base price with actuals. Hence the Delta."
        };

        @SuppressWarnings({
            "unchecked", "rawtypes"
        })
        OneParameterTest pTests = (tCase) -> {
            String subscriptionExternalId = "123";
            TestConditions testCase = (TestConditions) tCase;
            td.printDescription();
            System.out.println(
                    "**************************Executing " + testCase.testNum
                            + "********************************");

            String randomPastDate = "1900-01-01";
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal goodwillCredits = BigDecimal.valueOf(testCase.otherPromos);

            BigDecimal ca5Actuals = BigDecimal.valueOf(4);
            BigDecimal ca5Limit = BigDecimal.valueOf(5);

            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setNewCatalogItemExternalId(testCase.newCi);
            request.setDiscountPrice(CommonTestHelper.getOfferPrice(testCase.newCi));

            String oldCiId = testCase.oldCi;
            BigDecimal oldPrice = CommonTestHelper.getOfferPrice(oldCiId);

            request.setSubscriptionExternalId(subscriptionExternalId);
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));

            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            String goodwillTax = CommonTestHelper.getPromoTaxResp(
                    CI_EXTERNAL_IDS.GRANT_GOODWILL, oldCiId, goodwillCredits);
            String ca5Tax = CommonTestHelper.getPromoTaxResp(
                    CI_EXTERNAL_IDS.CA5_GRANT, oldCiId, TAX_CLASS_CODES.CA5, ca5Actuals);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            List.of(oldCiId, CI_EXTERNAL_IDS.CA5_GRANT)));
            MtxBalanceInfo biGoodwillGrant = CommonTestHelper.getMtxBalanceInfo(
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Grant.json", 4, 43);
            biGoodwillGrant.setAmount(BigDecimal.ZERO);
            biGoodwillGrant.setAvailableAmount(BigDecimal.ZERO);
            subscriptionResponse.getBalanceArrayAppender().add(biGoodwillGrant);

            MtxBalanceInfo biGoodwillConsumable = CommonTestHelper.getMtxBalanceInfo(
                    DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Consumable.json", 4, 44);
            biGoodwillConsumable.setAmount(goodwillCredits.negate());
            biGoodwillConsumable.setAvailableAmount(goodwillCredits);
            subscriptionResponse.getBalanceArrayAppender().add(biGoodwillConsumable);
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCiId);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().add(goodwillTax);
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().add(ca5Tax);

            emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(subscriptionResponse));

            emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.CA5_GRANT);
            emulateMtxResponsePricingCatalogItem(instance, oldCiId);

            MtxResponsePricingCatalogItem pciNewCi = emulateMtxResponsePricingCatalogItem(
                    instance, request.getNewCatalogItemExternalId());

            emulateMtxResponseWallet(
                    instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
            VisibleTemplate vtNewCi = (VisibleTemplate) pciNewCi.getCatalogItemInfo().getTemplateAttr();
            vtNewCi.setIgnoreTax_ForPayableAmount("false");

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(oldPrice);
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().add(goodwillTax);
            enrolledExtnEvent.setPaidCycleStartDate(new MtxDate(randomPastDate));
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().add(ca5Tax);

            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledPoiExtn);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCiId);

            VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    oldCiId);
            BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
            vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

            VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    CI_EXTERNAL_IDS.WEARABLE);
            BigDecimal mainbalanceWearables = BigDecimal.valueOf(5);
            vodWearable.setConsumableMainBalanceAmount(mainbalanceWearables);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodUnlimited.getCatalogItemExternalId(),
                    Long.valueOf(vodUnlimited.getResourceId()), vodUnlimited);
            aopStage.appendVisibleOfferDetailsMap(
                    vodWearable.getCatalogItemExternalId(),
                    Long.valueOf(vodWearable.getResourceId()), vodWearable);

            MtxResponseGroup respGrp = CommonTestHelper.getMtxResponseGroupCA(
                    subscriptionResponse.getExternalId(), "CAGroup",
                    List.of(subscriptionResponse.getObjectId().toString(), "1-2-3-4", "6-7-8-9"),
                    List.of(
                            String.format(
                                    GROUP_CONSTANTS.CA_LINK_FORMAT,
                                    subscriptionResponse.getExternalId(), "13579")));
            SubscriberGroup sg = new SubscriberGroup(respGrp);
            aopStage.appendSubscriberGroupList(sg);

            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            doAnswer(new Answer() {

                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    String redeemOffer = args[1].toString();
                    if (CI_EXTERNAL_IDS.CA5_REDEEM.equalsIgnoreCase(redeemOffer)) {
                        return ca5Limit.negate();
                    } else {
                        return BigDecimal.ZERO;
                    }
                }
            }).when(instance).getChargeableAmountForPurchaseOffer(any(), any(), any(), any());

            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                    request.getNewCatalogItemExternalId());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            List<String> balPriList = Arrays.asList(BALANCE_NAMES.GOODWILL_GRANT);
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));

            MtxResponseOneTimeOffer reverseOffers = new MtxResponseOneTimeOffer();
            reverseOffers.setResult(0L);
            reverseOffers.setResultText("OK");

            MtxPurchasedOfferInfo poiGoodwill = CommonTestHelper.loadJsonMessage(
                    MtxPurchasedOfferInfo.class, DATA_DIR.CHANGE_SERVICE
                            + "MtxPurchasedOfferInfo_Visible_Redeem_Goodwill_Credits.json");
            poiGoodwill.setResourceId(55L);

            emulateMtxResponseOneTimeOffer(instance, poiGoodwill);

            MtxResponsePricingCatalogItem goodwillGrant = CommonTestHelper.loadJsonMessage(
                    MtxResponsePricingCatalogItem.class, DATA_DIR.COMMON
                            + "MtxResponsePricingCatalogItem_Visible_Grant_Goodwill_Credits.json");
            emulateMtxResponsePricingCatalogItem(
                    instance, goodwillGrant, CI_EXTERNAL_IDS.GRANT_GOODWILL);
            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ObjectMapper om = TestUtils.getObjectMapper();
                ServiceTaxResponse resp = om.readValue(taxRespString, ServiceTaxResponse.class);
                resp.getTransactionElement().get(0).setTotalFeeAmount(
                        BigDecimal.valueOf(testCase.fixedFee));
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                resp.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            assertEquals(
                    request.getDiscountPrice().subtract(ca5Limit).subtract(oldPrice).add(
                            ca5Actuals).max(BigDecimal.ZERO).doubleValue(),
                    response.getChangeCycle().getDelta().doubleValue(), 0.001);

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            System.out.println(
                    "**************************End of " + testCase.testNum
                            + "********************************");
        };

        TestConditions tc_1 = new TestConditions();
        tc_1.oldCi = TestConstants.CI_EXTERNAL_IDS.PRO_CURRENT;
        tc_1.newCi = TestConstants.CI_EXTERNAL_IDS.PLUS_CURRENT;
        tc_1.otherPromos = 5;
        tc_1.aocDelta = 0.33;
        tc_1.fixedFee = 1.81;
        tc_1.minimumCharge = 5;
        String testString1 = "-AocDelta-" + 0.33 + "-OtherPromos-" + 5;
        tc_1.testNum = "#1" + testString1;
        pTests.test(tc_1);

        TestConditions tc_2 = new TestConditions();
        tc_2.oldCi = TestConstants.CI_EXTERNAL_IDS.PLUS_CURRENT;
        tc_2.newCi = TestConstants.CI_EXTERNAL_IDS.PRO_CURRENT;
        tc_2.otherPromos = 5;
        tc_2.aocDelta = 0.33;
        tc_2.fixedFee = 1.81;
        tc_2.minimumCharge = 5;
        String testString2 = "-AocDelta-" + 0.33 + "-OtherPromos-" + 5;
        tc_2.testNum = "#2" + testString2;
        pTests.test(tc_2);
    }

    @Test
    @Disabled("CA5 is purchased as subscription based promo. Promo limit is used to calculate delta. AoC not done.")
    public void test_getChangeServiceAdvice_When_AocPromo_Then_Info_Is_PurchaseService(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with base offer.In recurring event, CreditTaxDetailsArray has no Aoc Promo ."
        };
        td.when = new String[] {
            "Api is called"
        };
        td.then = new String[] {
            "Info=PurchaseService should be passed to Aoc promo when they are called to get values for Delta Base Price."
        };
    }

    @Test
    @Disabled("PartyPay, VBPP, Chime, Unlimited, Base22, Plus22 are obsolete. Can not be tested")
    public void test_getChangeServiceAdvice_When_NibToCore_CreditTaxForVbpp_And_No_GrantForVbpp_Then_UseConsumablesToCalculateDelta(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with base offer.In recurring event, CreditTaxDetailsArray has no Aoc Promo.",
            "https://jira.unico.com.au/browse/MTXVER2-139"
        };
        td.when = new String[] {
            "Api gets Zero as grant from Aoc."
        };
        td.then = new String[] {
            "Consumables should be used to get values for Delta Base Price."
        };
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getChangeServiceAdvice_ChangeCycleOnly_CoreToCoreDowngrade_If_PreActiveOffer_Exists_Then_CorrectChangeCycleOutput(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with Preactive Base22 and Active Plus22. PaidCycleStartDate is in past."
        };
        td.when = new String[] {
            "Api is called for CoreToCoreDowngrade. i.e. With Base22 as new offer."
        };
        td.then = new String[] {
            "Api throws error."
        };
        td.printDescription();

        String subscriptionExternalId = "123";
        String randomPastDate = "1900-01-01";

        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setSubscriptionExternalId(subscriptionExternalId);
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.BASE_CURRENT);
        request.setDiscountPrice(OFFER_PRICES.BASE_CURRENT);
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));

        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        String oldCiId = CI_EXTERNAL_IDS.PLUS_CURRENT;
        BigDecimal oldPrice = OFFER_PRICES.PLUS_CURRENT;
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poEnrolledPlus = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCiId);

        MtxPurchasedOfferInfo poEnrolledBase = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, request.getNewCatalogItemExternalId());

        VisiblePurchasedOfferExtension enrolledExtn = (VisiblePurchasedOfferExtension) poEnrolledPlus.getAttr();
        enrolledExtn.setChargeAmount(oldPrice);
        enrolledExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));
        poEnrolledBase.setOfferStatusDescription(OFFER_CONSTANTS.OFFER_STATUS_PRE_ACTIVE);

        emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(
                        subscription.getExternalId(), List.of(oldCiId),
                        List.of(request.getNewCatalogItemExternalId())));

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        emulateMtxResponsePricingCatalogItem(instance, oldCiId);
        MtxResponsePricingCatalogItem pciNewCi = emulateMtxResponsePricingCatalogItem(
                instance, request.getNewCatalogItemExternalId());

        BigDecimal mainbalance = BigDecimal.ZERO;
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

        VisibleTemplate vtNewCi = (VisibleTemplate) pciNewCi.getCatalogItemInfo().getTemplateAttr();
        vtNewCi.setIgnoreTax_ForPayableAmount("false");

        EventQueryResponseEvents eqre = new EventQueryResponseEvents();
        emulateEventQueryResponseEvents(instance, eqre);
        EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                EventQueryEventInfo.class,
                DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
        eqre.getEventListAppender().add(eqei);
        MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
        recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtn);
        recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCiId);

        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    "");
        }

        Exception exception = assertThrows(
                InvalidRequestException.class,
                () -> instance.getChangeServiceAdvice(request, response));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertEquals(
                request.getNewCatalogItemExternalId()
                        + " is already a preactive offer that gets activated on or before next bill cycle.",
                exception.getMessage().trim());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getChangeServiceAdvice_When_PromoIs_ApplicableToOldOffer_NotApplicableToNewOffer_Then_Promo_Is_NonRedeemable()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "VisibleTemplate.CreditIncludeAttributeValues is EMPTY.",
            "Promotion has OLD offer as ApplicableCI.",
            "Promotion does NOT have NEW offer as ApplicableCI.",
            "Promotion does NOT have any enrolled addon offer as ApplicableCI.",
            "Promotion is non-zero."
        };
        td.when = new String[] {
            "Api is called."
        };
        td.then = new String[] {
            "Promotion is present in non redeemable credits."
        };
        td.comments = new String[] {
            "MTXVER2-171", "VER-142"
        };
        td.printDescription();

        String subscriptionExternalId = "123";
        String randomPastDate = "1900-01-01";
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setSubscriptionExternalId(subscriptionExternalId);
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        request.setDiscountPrice(OFFER_PRICES.PLUS_CURRENT);
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));

        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        String oldCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        BigDecimal oldPrice = OFFER_PRICES.BASE_CURRENT;

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poEnrolledPlus = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCiId);

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCiId);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

        VisiblePurchasedOfferExtension enrolledExtn = (VisiblePurchasedOfferExtension) poEnrolledPlus.getAttr();
        enrolledExtn.setChargeAmount(oldPrice);
        enrolledExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(oldCiId, request.getNewCatalogItemExternalId()));

        BigDecimal mainbalance = BigDecimal.ZERO;
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

        VisibleOfferDetails vodBase22 = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                oldCiId);
        BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(20);
        vodBase22.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());
        BigDecimal first25Credits = BigDecimal.TEN;

        ServiceStage ss = new ServiceStage(oldCiId);

        GlobalCreditStage gcsF25 = new GlobalCreditStage(
                ciF25Grant.getCatalogItemInfo().getExternalId(), vtF25);
        gcsF25.setPromotionName(vtF25.getPromotionName());
        gcsF25.setAvailableCredits(first25Credits);
        gcsF25.setAvailableCreditsConsumable(BigDecimal.ZERO);
        gcsF25.setAvailableCreditsGrant(first25Credits);
        gcsF25.setRedeemOfferCi(vtF25.getRedeemOffer());
        gcsF25.setApplicableCiCsv(oldCiId);
        gcsF25.getApplicableCiOrderMap().put(oldCiId, 2L);

        CreditStage csFirst25 = new CreditStage(gcsF25, oldCiId);
        csFirst25.setApplicableServiceStage(ss);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodBase22.getCatalogItemExternalId(), Long.valueOf(vodBase22.getResourceId()),
                vodBase22);
        aopStage.getCreditMap().put(
                new PromoOfferPair(oldCiId, gcsF25.getGrantOfferCi()), csFirst25);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                MtxBalanceImpactInfo.class,
                DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
        biiMain.setImpactAmount(BigDecimal.ZERO);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                TestUtils.getFirstDateTimeOfCurrentMonth());
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                TestUtils.getLastDateTimeOfCurrentMonth());
        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    "");
        }

        instance.getChangeServiceAdvice(request, response);
        assertEquals(
                gcsF25.getPromotionName(),
                response.getNonRedeemableCredits().get(0).getPromotionName());
        assertEquals(
                first25Credits.intValue(),
                response.getNonRedeemableCredits().get(0).getCreditGrant().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getChangeServiceAdvice_When_OnlyFilter_MatchOldOffer_BlockNewOffer_Then_Promo_Is_NonRedeemable()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "VisibleTemplate.CreditIncludeAttributeValues multiple valid entries.",
            "Promotion has both OLD and NEW offers as ApplicableCIs.", "Promotion is non-zero"
        };
        td.when = new String[] {
            "Api is called.",
            "At least one CreditIncludeAttributeValues DOES match with VisiblePurchasedOfferExtension.OfferChangeType of OLD base offer.",
            "NONE of CreditIncludeAttributeValues match with VisiblePurchasedOfferExtension.OfferChangeType of NEW base offer.",
            "NONE of CreditIncludeAttributeValues match with VisiblePurchasedOfferExtension.OfferChangeType of enrolled addon offer."
        };
        td.then = new String[] {
            "Promotion is present in non redeemable credits."
        };
        td.comments = new String[] {
            "MTXVER2-171", "VER-142"
        };
        td.printDescription();

        String subscriptionExternalId = "123";
        String randomPastDate = "1900-01-01";

        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setSubscriptionExternalId(subscriptionExternalId);
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        request.setDiscountPrice(OFFER_PRICES.PLUS_CURRENT);
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));

        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        String oldCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        BigDecimal oldPrice = OFFER_PRICES.BASE_CURRENT;
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poEnrolledPlus = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCiId);

        VisiblePurchasedOfferExtension enrolledExtn = (VisiblePurchasedOfferExtension) poEnrolledPlus.getAttr();
        enrolledExtn.setChargeAmount(oldPrice);
        enrolledExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCiId);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(oldCiId, request.getNewCatalogItemExternalId()));

        BigDecimal mainbalance = BigDecimal.ZERO;
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

        VisibleOfferDetails vodBase22 = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                oldCiId);
        BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(20);
        vodBase22.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());
        BigDecimal first25Credits = BigDecimal.TEN;
        vtF25.setApplicableOfferName(request.getNewCatalogItemExternalId());

        ServiceStage ss = new ServiceStage(oldCiId);

        GlobalCreditStage gcsF25 = new GlobalCreditStage(
                ciF25Grant.getCatalogItemInfo().getExternalId(), vtF25);
        gcsF25.setPromotionName(vtF25.getPromotionName());
        gcsF25.setAvailableCredits(first25Credits);
        gcsF25.setAvailableCreditsConsumable(BigDecimal.ZERO);
        gcsF25.setAvailableCreditsGrant(first25Credits);
        gcsF25.setRedeemOfferCi(vtF25.getRedeemOffer());
        gcsF25.setApplicableCiCsv(oldCiId + "," + request.getNewCatalogItemExternalId());
        gcsF25.getApplicableCiOrderMap().put(oldCiId, 2L);
        gcsF25.getApplicableCiOrderMap().put(request.getNewCatalogItemExternalId(), 3L);

        String offerChangeType = "NOT_" + AppPropertyProvider.getInstance().getString(
                CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_PREFIX + oldCiId
                        + CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_OFFER_SEPARATOR_TO
                        + request.getNewCatalogItemExternalId());
        gcsF25.getCreditIncludeAttributeValues().add(
                VisiblePurchasedOfferExtension.class.getSimpleName() + GENERIC_CONSTANTS.DOT
                        + "OfferChangeType" + GENERIC_CONSTANTS.EQUALS + offerChangeType);

        gcsF25.getCreditIncludeAttributeValues().add(
                VisiblePurchasedOfferExtension.class.getSimpleName() + GENERIC_CONSTANTS.DOT
                        + "OfferChangeType" + GENERIC_CONSTANTS.EQUALS + "VALID_CHANGE");

        CreditStage csFirst25 = new CreditStage(gcsF25, oldCiId);
        csFirst25.setApplicableServiceStage(ss);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodBase22.getCatalogItemExternalId(), Long.valueOf(vodBase22.getResourceId()),
                vodBase22);
        aopStage.getCreditMap().put(
                new PromoOfferPair(oldCiId, gcsF25.getGrantOfferCi()), csFirst25);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                MtxBalanceImpactInfo.class,
                DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
        biiMain.setImpactAmount(BigDecimal.ZERO);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                TestUtils.getFirstDateTimeOfCurrentMonth());
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                TestUtils.getLastDateTimeOfCurrentMonth());
        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    "");
        }

        instance.getChangeServiceAdvice(request, response);
        assertEquals(
                gcsF25.getPromotionName(),
                response.getNonRedeemableCredits().get(0).getPromotionName());
        assertEquals(
                first25Credits.intValue(),
                response.getNonRedeemableCredits().get(0).getCreditGrant().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getChangeServiceAdvice_When_AnyFilter_MatchOldOffer_BlockNewOffer_Then_Promo_Is_NonRedeemable()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "VisibleTemplate.CreditIncludeAttributeValues has only one entry, and the entry is valid.",
            "Promotion has both OLD and NEW offers as ApplicableCIs.", "Promotion is non-zero"
        };
        td.when = new String[] {
            "Api is called.",
            "CreditIncludeAttributeValues DOES match with VisiblePurchasedOfferExtension.OfferChangeType of OLD base offer.",
            "CreditIncludeAttributeValues does NOT match with VisiblePurchasedOfferExtension.OfferChangeType of NEW base offer.",
            "CreditIncludeAttributeValues does NOT match with VisiblePurchasedOfferExtension.OfferChangeType of enrolled addon offer."
        };
        td.then = new String[] {
            "Promotion is present in non redeemable credits."
        };
        td.comments = new String[] {
            "MTXVER2-171", "VER-142"
        };
        td.printDescription();

        String subscriptionExternalId = "123";
        String randomPastDate = "1900-01-01";

        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setSubscriptionExternalId(subscriptionExternalId);
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        request.setDiscountPrice(OFFER_PRICES.PLUS_CURRENT);
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));

        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        String oldCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        BigDecimal oldPrice = OFFER_PRICES.BASE_CURRENT;
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poEnrolledPlus = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCiId);

        VisiblePurchasedOfferExtension enrolledExtn = (VisiblePurchasedOfferExtension) poEnrolledPlus.getAttr();
        enrolledExtn.setChargeAmount(oldPrice);
        enrolledExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCiId);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(oldCiId, request.getNewCatalogItemExternalId()));

        BigDecimal mainbalance = BigDecimal.ZERO;
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

        VisibleOfferDetails vodBase22 = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                oldCiId);
        BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(20);
        vodBase22.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());
        BigDecimal first25Credits = BigDecimal.TEN;
        vtF25.setApplicableOfferName(request.getNewCatalogItemExternalId());

        ServiceStage ss = new ServiceStage(oldCiId);

        GlobalCreditStage gcsF25 = new GlobalCreditStage(
                ciF25Grant.getCatalogItemInfo().getExternalId(), vtF25);
        gcsF25.setPromotionName(vtF25.getPromotionName());
        gcsF25.setAvailableCredits(first25Credits);
        gcsF25.setAvailableCreditsConsumable(BigDecimal.ZERO);
        gcsF25.setAvailableCreditsGrant(first25Credits);
        gcsF25.setRedeemOfferCi(vtF25.getRedeemOffer());
        gcsF25.setApplicableCiCsv(oldCiId + "," + request.getNewCatalogItemExternalId());
        gcsF25.getApplicableCiOrderMap().put(oldCiId, 2L);
        gcsF25.getApplicableCiOrderMap().put(request.getNewCatalogItemExternalId(), 3L);

        String offerChangeType = "NoMatchChange";
        gcsF25.getCreditIncludeAttributeValues().add(
                VisiblePurchasedOfferExtension.class.getSimpleName() + GENERIC_CONSTANTS.DOT
                        + "OfferChangeType" + GENERIC_CONSTANTS.EQUALS + offerChangeType);

        CreditStage csFirst25 = new CreditStage(gcsF25, oldCiId);
        csFirst25.setApplicableServiceStage(ss);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodBase22.getCatalogItemExternalId(), Long.valueOf(vodBase22.getResourceId()),
                vodBase22);
        aopStage.getCreditMap().put(
                new PromoOfferPair(oldCiId, gcsF25.getGrantOfferCi()), csFirst25);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());
        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                MtxBalanceImpactInfo.class,
                DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
        biiMain.setImpactAmount(BigDecimal.ZERO);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                TestUtils.getFirstDateTimeOfCurrentMonth());
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                TestUtils.getLastDateTimeOfCurrentMonth());
        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    "");
        }

        instance.getChangeServiceAdvice(request, response);
        assertEquals(
                gcsF25.getPromotionName(),
                response.getNonRedeemableCredits().get(0).getPromotionName());
        assertEquals(
                first25Credits.intValue(),
                response.getNonRedeemableCredits().get(0).getCreditGrant().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getChangeServiceAdvice_When_AnyFilter_MatchNewOffer_Then_Promo_Not_In_NonRedeemable()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "VisibleTemplate.CreditIncludeAttributeValues has multiple valid entries.",
            "Promotion is non-zero."
        };
        td.when = new String[] {
            "Api is called.",
            "At least one of CreditIncludeAttributeValues DOES match with VisiblePurchasedOfferExtension.OfferChangeType of NEW base offer.",
            "Promotion is not blocked by any other rule."
        };
        td.then = new String[] {
            "Promotion is NOT present in non redeemable credits."
        };
        td.comments = new String[] {
            "MTXVER2-171", "VER-142"
        };
        td.printDescription();

        String subscriptionExternalId = "123";
        String randomPastDate = "1900-01-01";

        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setSubscriptionExternalId(subscriptionExternalId);
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        request.setDiscountPrice(OFFER_PRICES.PLUS_CURRENT);
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));

        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        String oldCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        BigDecimal oldPrice = OFFER_PRICES.BASE_CURRENT;
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poEnrolledPlus = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCiId);

        VisiblePurchasedOfferExtension enrolledExtn = (VisiblePurchasedOfferExtension) poEnrolledPlus.getAttr();
        enrolledExtn.setChargeAmount(oldPrice);
        enrolledExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance, CommonTestHelper.getEmptySubscriptionResponse(subscriptionExternalId));
        PurchasedOfferInfo poiPlus = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCiId);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiPlus.getAttr();
        enrolledPoiExtn.setChargeAmount(oldPrice);
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(oldCiId, request.getNewCatalogItemExternalId()));

        BigDecimal mainbalance = BigDecimal.ZERO;
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

        VisibleOfferDetails vodBase22 = CommonTestHelper.getVisibleOfferDetails(
                oldCiId, new MtxDate(randomPastDate), CommonTestHelper.getOfferPrice(oldCiId));
        BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(20);
        vodBase22.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());
        BigDecimal first25Credits = BigDecimal.TEN;
        vtF25.setApplicableOfferName(request.getNewCatalogItemExternalId());

        ServiceStage ss = new ServiceStage(oldCiId);

        GlobalCreditStage gcsF25 = new GlobalCreditStage(
                ciF25Grant.getCatalogItemInfo().getExternalId(), vtF25);
        gcsF25.setPromotionName(vtF25.getPromotionName());
        gcsF25.setAvailableCredits(first25Credits);
        gcsF25.setAvailableCreditsConsumable(BigDecimal.ZERO);
        gcsF25.setAvailableCreditsGrant(first25Credits);
        gcsF25.setRedeemOfferCi(vtF25.getRedeemOffer());
        gcsF25.setApplicableCiCsv(oldCiId + "," + request.getNewCatalogItemExternalId());
        gcsF25.getApplicableCiOrderMap().put(oldCiId, 2L);
        gcsF25.getApplicableCiOrderMap().put(request.getNewCatalogItemExternalId(), 3L);

        String offerChangeType = AppPropertyProvider.getInstance().getString(
                CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_PREFIX + oldCiId
                        + CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_OFFER_SEPARATOR_TO
                        + request.getNewCatalogItemExternalId());
        gcsF25.getCreditIncludeAttributeValues().add(
                VisiblePurchasedOfferExtension.class.getSimpleName() + GENERIC_CONSTANTS.DOT
                        + "OfferChangeType" + GENERIC_CONSTANTS.EQUALS + offerChangeType);

        gcsF25.getCreditIncludeAttributeValues().add(
                VisiblePurchasedOfferExtension.class.getSimpleName() + GENERIC_CONSTANTS.DOT
                        + "OfferChangeType" + GENERIC_CONSTANTS.EQUALS + "VALID_CHANGE");

        CreditStage csFirst25 = new CreditStage(gcsF25, oldCiId);
        csFirst25.setApplicableServiceStage(ss);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodBase22.getCatalogItemExternalId(), Long.valueOf(vodBase22.getResourceId()),
                vodBase22);
        aopStage.getCreditMap().put(
                new PromoOfferPair(oldCiId, gcsF25.getGrantOfferCi()), csFirst25);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                MtxBalanceImpactInfo.class,
                DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                TestUtils.getFirstDateTimeOfCurrentMonth());
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                TestUtils.getLastDateTimeOfCurrentMonth());
        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    "");
            instance.getChangeServiceAdvice(request, response);
        }

        assertNull(response.getNonRedeemableCredits());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getChangeServiceAdvice_When_OnlyFilter_MatchNewOffer_Then_Promo_Not_In_NonRedeemable()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "VisibleTemplate.CreditIncludeAttributeValues has only one entry, and the entry is valid.",
            "Promotion is non-zero."
        };
        td.when = new String[] {
            "Api is called.",
            "CreditIncludeAttributeValues DOES match with VisiblePurchasedOfferExtension.OfferChangeType of NEW base offer.",
            "Promotion is not blocked by any other rule."
        };
        td.then = new String[] {
            "Promotion is NOT present in non redeemable credits."
        };
        td.comments = new String[] {
            "MTXVER2-171", "VER-142"
        };
        td.printDescription();

        String subscriptionExternalId = "123";
        String randomPastDate = "1900-01-01";

        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setSubscriptionExternalId(subscriptionExternalId);
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        request.setDiscountPrice(OFFER_PRICES.PLUS_CURRENT);
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));

        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        String oldCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        BigDecimal oldPrice = OFFER_PRICES.BASE_CURRENT;
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poEnrolledPlus = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCiId);

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCiId);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

        VisiblePurchasedOfferExtension enrolledExtn = (VisiblePurchasedOfferExtension) poEnrolledPlus.getAttr();
        enrolledExtn.setChargeAmount(oldPrice);
        enrolledExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(oldCiId, request.getNewCatalogItemExternalId()));

        BigDecimal mainbalance = BigDecimal.ZERO;
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

        VisibleOfferDetails vodBase22 = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                oldCiId);
        BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(20);
        vodBase22.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());
        BigDecimal first25Credits = BigDecimal.TEN;
        vtF25.setApplicableOfferName(request.getNewCatalogItemExternalId());

        ServiceStage ss = new ServiceStage(oldCiId);

        GlobalCreditStage gcsF25 = new GlobalCreditStage(
                ciF25Grant.getCatalogItemInfo().getExternalId(), vtF25);
        gcsF25.setPromotionName(vtF25.getPromotionName());
        gcsF25.setAvailableCredits(first25Credits);
        gcsF25.setAvailableCreditsConsumable(BigDecimal.ZERO);
        gcsF25.setAvailableCreditsGrant(first25Credits);
        gcsF25.setRedeemOfferCi(vtF25.getRedeemOffer());
        gcsF25.setApplicableCiCsv(oldCiId + "," + request.getNewCatalogItemExternalId());
        gcsF25.getApplicableCiOrderMap().put(oldCiId, 2L);
        gcsF25.getApplicableCiOrderMap().put(request.getNewCatalogItemExternalId(), 3L);

        String offerChangeType = AppPropertyProvider.getInstance().getString(
                CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_PREFIX + oldCiId
                        + CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_OFFER_SEPARATOR_TO
                        + request.getNewCatalogItemExternalId());
        gcsF25.getCreditIncludeAttributeValues().add(
                VisiblePurchasedOfferExtension.class.getSimpleName() + GENERIC_CONSTANTS.DOT
                        + "OfferChangeType" + GENERIC_CONSTANTS.EQUALS + offerChangeType);

        CreditStage csFirst25 = new CreditStage(gcsF25, oldCiId);
        csFirst25.setApplicableServiceStage(ss);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodBase22.getCatalogItemExternalId(), Long.valueOf(vodBase22.getResourceId()),
                vodBase22);
        aopStage.getCreditMap().put(
                new PromoOfferPair(oldCiId, gcsF25.getGrantOfferCi()), csFirst25);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                MtxBalanceImpactInfo.class,
                DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
        biiMain.setImpactAmount(BigDecimal.ZERO);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                TestUtils.getFirstDateTimeOfCurrentMonth());
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                TestUtils.getLastDateTimeOfCurrentMonth());
        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    "");
        }

        instance.getChangeServiceAdvice(request, response);
        assertNull(response.getNonRedeemableCredits());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getChangeServiceAdvice_When_PromoHasNoAttributeFilters_Then_ProcessNormally()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "VisibleTemplate.CreditIncludeAttributeValues is empty for promotion."
        };
        td.when = new String[] {
            "Api called."
        };
        td.then = new String[] {
            "Promotion eligibility is decided by ignoring CreditIncludeAttributeValues."
        };
        td.comments = new String[] {
            "MTXVER2-171", "VER-142"
        };
        td.printDescription();

        String subscriptionExternalId = "123";
        String randomPastDate = "1900-01-01";

        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setSubscriptionExternalId(subscriptionExternalId);
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        request.setDiscountPrice(OFFER_PRICES.PLUS_CURRENT);
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));

        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        String oldCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        BigDecimal oldPrice = OFFER_PRICES.BASE_CURRENT;
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poEnrolledPlus = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCiId);

        VisiblePurchasedOfferExtension enrolledExtn = (VisiblePurchasedOfferExtension) poEnrolledPlus.getAttr();
        enrolledExtn.setChargeAmount(oldPrice);
        enrolledExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCiId);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(oldCiId, request.getNewCatalogItemExternalId()));

        BigDecimal mainbalance = BigDecimal.ZERO;
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

        VisibleOfferDetails vodBase22 = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                oldCiId);
        BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(20);
        vodBase22.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());
        BigDecimal first25Credits = BigDecimal.TEN;
        vtF25.setApplicableOfferName(request.getNewCatalogItemExternalId());

        ServiceStage ss = new ServiceStage(oldCiId);

        GlobalCreditStage gcsF25 = new GlobalCreditStage(
                ciF25Grant.getCatalogItemInfo().getExternalId(), vtF25);
        gcsF25.setPromotionName(vtF25.getPromotionName());
        gcsF25.setAvailableCredits(first25Credits);
        gcsF25.setAvailableCreditsConsumable(BigDecimal.ZERO);
        gcsF25.setAvailableCreditsGrant(first25Credits);
        gcsF25.setRedeemOfferCi(vtF25.getRedeemOffer());
        gcsF25.setApplicableCiCsv(oldCiId + "," + request.getNewCatalogItemExternalId());
        gcsF25.getApplicableCiOrderMap().put(oldCiId, 2L);
        gcsF25.getApplicableCiOrderMap().put(request.getNewCatalogItemExternalId(), 3L);
        gcsF25.clearCreditIncludeAttributeValues();

        CreditStage csFirst25 = new CreditStage(gcsF25, oldCiId);
        csFirst25.setApplicableServiceStage(ss);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodBase22.getCatalogItemExternalId(), Long.valueOf(vodBase22.getResourceId()),
                vodBase22);
        aopStage.getCreditMap().put(
                new PromoOfferPair(oldCiId, gcsF25.getGrantOfferCi()), csFirst25);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());
        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                MtxBalanceImpactInfo.class,
                DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
        biiMain.setImpactAmount(BigDecimal.ZERO);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                TestUtils.getFirstDateTimeOfCurrentMonth());
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                TestUtils.getLastDateTimeOfCurrentMonth());
        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    "");
        }

        instance.getChangeServiceAdvice(request, response);
        assertNull(response.getNonRedeemableCredits());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getChangeServiceAdvice_When_OnlyAttributeFilter_is_Empty_Then_ProcessNormally()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "VisibleTemplate.CreditIncludeAttributeValues has only one entry, and the entry is EMPTY."
        };
        td.when = new String[] {
            "Api called."
        };
        td.then = new String[] {
            "Promotion eligibility is decided by ignoring CreditIncludeAttributeValues."
        };
        td.comments = new String[] {
            "MTXVER2-171", "VER-142"
        };
        td.printDescription();

        String subscriptionExternalId = "123";
        String randomPastDate = "1900-01-01";

        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setSubscriptionExternalId(subscriptionExternalId);
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        request.setDiscountPrice(OFFER_PRICES.PLUS_CURRENT);
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));

        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        String oldCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        BigDecimal oldPrice = OFFER_PRICES.BASE_CURRENT;
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poEnrolledPlus = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCiId);

        VisiblePurchasedOfferExtension enrolledExtn = (VisiblePurchasedOfferExtension) poEnrolledPlus.getAttr();
        enrolledExtn.setChargeAmount(oldPrice);
        enrolledExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCiId);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(oldCiId, request.getNewCatalogItemExternalId()));

        BigDecimal mainbalance = BigDecimal.ZERO;
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

        VisibleOfferDetails vodBase22 = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                oldCiId);
        BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(20);
        vodBase22.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());
        BigDecimal first25Credits = BigDecimal.TEN;
        vtF25.setApplicableOfferName(request.getNewCatalogItemExternalId());

        ServiceStage ss = new ServiceStage(oldCiId);

        GlobalCreditStage gcsF25 = new GlobalCreditStage(
                ciF25Grant.getCatalogItemInfo().getExternalId(), vtF25);
        gcsF25.setPromotionName(vtF25.getPromotionName());
        gcsF25.setAvailableCredits(first25Credits);
        gcsF25.setAvailableCreditsConsumable(BigDecimal.ZERO);
        gcsF25.setAvailableCreditsGrant(first25Credits);
        gcsF25.setRedeemOfferCi(vtF25.getRedeemOffer());
        gcsF25.setApplicableCiCsv(oldCiId + "," + request.getNewCatalogItemExternalId());
        gcsF25.getApplicableCiOrderMap().put(oldCiId, 2L);
        gcsF25.getApplicableCiOrderMap().put(request.getNewCatalogItemExternalId(), 3L);
        gcsF25.getCreditIncludeAttributeValues().add("");

        CreditStage csFirst25 = new CreditStage(gcsF25, oldCiId);
        csFirst25.setApplicableServiceStage(ss);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodBase22.getCatalogItemExternalId(), Long.valueOf(vodBase22.getResourceId()),
                vodBase22);
        aopStage.getCreditMap().put(
                new PromoOfferPair(oldCiId, gcsF25.getGrantOfferCi()), csFirst25);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());
        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                MtxBalanceImpactInfo.class,
                DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
        biiMain.setImpactAmount(BigDecimal.ZERO);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                TestUtils.getFirstDateTimeOfCurrentMonth());
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                TestUtils.getLastDateTimeOfCurrentMonth());
        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    "");
        }

        instance.getChangeServiceAdvice(request, response);
        assertNull(response.getNonRedeemableCredits());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getChangeServiceAdvice_When_OnlyAttributeFilter_is_Invalid_Then_IgnoreInvalidEntry()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "VisibleTemplate.CreditIncludeAttributeValues has only one entry, and the entry is invalid."
        };
        td.when = new String[] {
            "Api called."
        };
        td.then = new String[] {
            "Api ignores invalid entry."
        };
        td.comments = new String[] {
            "MTXVER2-171", "VER-142"
        };
        td.printDescription();

        String subscriptionExternalId = "123";
        String randomPastDate = "1900-01-01";

        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setSubscriptionExternalId(subscriptionExternalId);
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        request.setDiscountPrice(OFFER_PRICES.PLUS_CURRENT);
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));

        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        String oldCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        BigDecimal oldPrice = OFFER_PRICES.BASE_CURRENT;
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poEnrolledPlus = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCiId);

        VisiblePurchasedOfferExtension enrolledExtn = (VisiblePurchasedOfferExtension) poEnrolledPlus.getAttr();
        enrolledExtn.setChargeAmount(oldPrice);
        enrolledExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCiId);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(oldCiId, request.getNewCatalogItemExternalId()));

        BigDecimal mainbalance = BigDecimal.ZERO;
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

        VisibleOfferDetails vodBase22 = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                oldCiId);
        BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(20);
        vodBase22.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());
        BigDecimal first25Credits = BigDecimal.TEN;
        vtF25.setApplicableOfferName(request.getNewCatalogItemExternalId());

        ServiceStage ss = new ServiceStage(oldCiId);

        GlobalCreditStage gcsF25 = new GlobalCreditStage(
                ciF25Grant.getCatalogItemInfo().getExternalId(), vtF25);
        gcsF25.setPromotionName(vtF25.getPromotionName());
        gcsF25.setAvailableCredits(first25Credits);
        gcsF25.setAvailableCreditsConsumable(BigDecimal.ZERO);
        gcsF25.setAvailableCreditsGrant(first25Credits);
        gcsF25.setRedeemOfferCi(vtF25.getRedeemOffer());
        gcsF25.setApplicableCiCsv(oldCiId + "," + request.getNewCatalogItemExternalId());
        gcsF25.getApplicableCiOrderMap().put(oldCiId, 2L);
        gcsF25.getApplicableCiOrderMap().put(request.getNewCatalogItemExternalId(), 3L);
        gcsF25.getCreditIncludeAttributeValues().add("Bl! Bl$ Bl*");

        CreditStage csFirst25 = new CreditStage(gcsF25, oldCiId);
        csFirst25.setApplicableServiceStage(ss);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodBase22.getCatalogItemExternalId(), Long.valueOf(vodBase22.getResourceId()),
                vodBase22);
        aopStage.getCreditMap().put(
                new PromoOfferPair(oldCiId, gcsF25.getGrantOfferCi()), csFirst25);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());
        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                MtxBalanceImpactInfo.class,
                DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
        biiMain.setImpactAmount(BigDecimal.ZERO);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                TestUtils.getFirstDateTimeOfCurrentMonth());
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                TestUtils.getLastDateTimeOfCurrentMonth());
        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    "");
        }

        instance.getChangeServiceAdvice(request, response);
        assertNull(response.getNonRedeemableCredits());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getChangeServiceAdvice_When_AnyAttributeFilter_is_Invalid_Then_IgnoreInvalidEntry()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "VisibleTemplate.CreditIncludeAttributeValues has multiple entries, and at least one entry is invalid"
        };
        td.when = new String[] {
            "Api called."
        };
        td.then = new String[] {
            "Api ignores invalid entry."
        };
        td.comments = new String[] {
            "MTXVER2-171", "VER-142"
        };
        td.printDescription();

        String subscriptionExternalId = "123";
        String randomPastDate = "1900-01-01";

        VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
        request.setSubscriptionExternalId(subscriptionExternalId);
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        request.setDiscountPrice(OFFER_PRICES.PLUS_CURRENT);
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));

        VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

        String oldCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
        BigDecimal oldPrice = OFFER_PRICES.BASE_CURRENT;
        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getMtxResponseSubscription());
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poEnrolledPlus = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, oldCiId);

        VisiblePurchasedOfferExtension enrolledExtn = (VisiblePurchasedOfferExtension) poEnrolledPlus.getAttr();
        enrolledExtn.setChargeAmount(oldPrice);
        enrolledExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

        SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
        PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, oldCiId);
        VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
        enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
        enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
        enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(oldCiId, request.getNewCatalogItemExternalId()));

        BigDecimal mainbalance = BigDecimal.ZERO;
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

        VisibleOfferDetails vodBase22 = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                CI_EXTERNAL_IDS.BASE_CURRENT);
        BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(20);
        vodBase22.setConsumableMainBalanceAmount(mainbalanceUnlimited);

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());
        BigDecimal first25Credits = BigDecimal.TEN;
        vtF25.setApplicableOfferName(request.getNewCatalogItemExternalId());

        ServiceStage ss = new ServiceStage(oldCiId);

        GlobalCreditStage gcsF25 = new GlobalCreditStage(
                ciF25Grant.getCatalogItemInfo().getExternalId(), vtF25);
        gcsF25.setPromotionName(vtF25.getPromotionName());
        gcsF25.setAvailableCredits(first25Credits);
        gcsF25.setAvailableCreditsConsumable(BigDecimal.ZERO);
        gcsF25.setAvailableCreditsGrant(first25Credits);
        gcsF25.setRedeemOfferCi(vtF25.getRedeemOffer());
        gcsF25.setApplicableCiCsv(oldCiId + "," + request.getNewCatalogItemExternalId());
        gcsF25.getApplicableCiOrderMap().put(oldCiId, 2L);
        gcsF25.getApplicableCiOrderMap().put(request.getNewCatalogItemExternalId(), 3L);
        gcsF25.getCreditIncludeAttributeValues().add("XYZ=ABC");

        String offerChangeType = AppPropertyProvider.getInstance().getString(
                CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_PREFIX + CI_EXTERNAL_IDS.BASE_CURRENT
                        + CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_OFFER_SEPARATOR_TO
                        + CI_EXTERNAL_IDS.PLUS_CURRENT);
        gcsF25.getCreditIncludeAttributeValues().add(
                VisiblePurchasedOfferExtension.class.getSimpleName() + GENERIC_CONSTANTS.DOT
                        + "OfferChangeType" + GENERIC_CONSTANTS.EQUALS + offerChangeType);

        CreditStage csFirst25 = new CreditStage(gcsF25, oldCiId);
        csFirst25.setApplicableServiceStage(ss);

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
        aopStage.appendVisibleOfferDetailsMap(
                vodBase22.getCatalogItemExternalId(), Long.valueOf(vodBase22.getResourceId()),
                vodBase22);
        aopStage.getCreditMap().put(
                new PromoOfferPair(oldCiId, gcsF25.getGrantOfferCi()), csFirst25);
        aopStage.setRecurringChargeInfo(
                CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
        doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());
        doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

        MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
        MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                MtxBalanceImpactInfo.class,
                DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
        biiMain.setImpactAmount(BigDecimal.ZERO);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactListAppender().add(biiMain);
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                TestUtils.getFirstDateTimeOfCurrentMonth());
        deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                TestUtils.getLastDateTimeOfCurrentMonth());
        doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                any(),
                argThat(
                        (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                request.getNewCatalogItemExternalId())),
                any(), any());

        emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    "");
        }

        instance.getChangeServiceAdvice(request, response);
        assertNull(response.getNonRedeemableCredits());
    }

    @Test
    public void test_getChangeServiceAdvice_ChangeCycleOnly_BaseMonthly2PlusMonthly_Then_CorrectChangeCycleOutput(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with base offer. PaidCycleStartDate is in past."
        };
        td.when = new String[] {
            "Api is called for CoreToCore change that takes affect immidiately"
        };
        td.then = new String[] {
            "Validate ChangeCycleFields"
        };

        @SuppressWarnings("unchecked")
        OneParameterTest pTests = (tCase) -> {
            String subscriptionExternalId = "123";
            TestConditions testCase = (TestConditions) tCase;
            td.printDescription();
            System.out.println(
                    "**************************Executing " + testCase.testNum
                            + "********************************");

            AppPropertyProvider.getInstance().setProperty(
                    CREDIT_CONSTANTS.AOC_GRANT_OFFERS,
                    CI_EXTERNAL_IDS.VBPP5_AOC_GRANT + "," + CI_EXTERNAL_IDS.CHIME_AOC_GRANT);

            MtxResponsePricingCatalogItem pciVbpp = emulateMtxResponsePricingCatalogItem(
                    instance, CI_EXTERNAL_IDS.VBPP5_AOC_GRANT);
            VisibleTemplate vtVbpp = (VisibleTemplate) pciVbpp.getCatalogItemInfo().getTemplateAttr();
            vtVbpp.setIgnoreTax_ForPayableAmount("false");

            MtxResponsePricingCatalogItem pciChime = emulateMtxResponsePricingCatalogItem(
                    instance, CI_EXTERNAL_IDS.CHIME_AOC_GRANT);
            VisibleTemplate vtChime = (VisibleTemplate) pciChime.getCatalogItemInfo().getTemplateAttr();
            vtChime.setIgnoreTax_ForPayableAmount("false");

            String randomPastDate = "1900-01-01";
            BigDecimal oldVbpp = BigDecimal.ZERO;
            BigDecimal newVbpp = BigDecimal.ZERO;
            if (testCase.vbppEligible && vtVbpp.getApplicableOfferName().contains(testCase.oldCi)) {
                oldVbpp = BigDecimal.valueOf(5);
            }
            if (testCase.vbppEligible && vtVbpp.getApplicableOfferName().contains(testCase.newCi)) {
                newVbpp = BigDecimal.valueOf(5);
            }
            BigDecimal oldChime = BigDecimal.ZERO;
            BigDecimal newChime = BigDecimal.ZERO;
            if (testCase.chimeEligible
                    && vtChime.getApplicableOfferName().contains(testCase.oldCi)) {
                oldChime = BigDecimal.valueOf(5);
            }
            if (testCase.chimeEligible
                    && vtChime.getApplicableOfferName().contains(testCase.newCi)) {
                newChime = BigDecimal.valueOf(5);
            }

            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setSubscriptionExternalId(subscriptionExternalId);
            request.setNewCatalogItemExternalId(testCase.newCi);
            request.setDiscountPrice(testCase.getNewCiPrice());
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));

            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            String oldCiId = testCase.oldCi;
            BigDecimal oldPrice = testCase.getOldCiPrice();
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getPurchasedOfferArrayAppender().clear();

            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCiId);

            BigDecimal goodwillCredits = BigDecimal.valueOf(testCase.otherPromos);
            String goodwillTax = CommonTestHelper.getPromoTaxResp(
                    CI_EXTERNAL_IDS.GRANT_GOODWILL, oldCiId, goodwillCredits);

            VisiblePurchasedOfferExtension enrolledExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            enrolledExtn.setChargeAmount(oldPrice);
            enrolledExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtn.getCreditTaxDetailsArrayAppender().add(goodwillTax);
            enrolledExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCiId);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(oldCiId, request.getNewCatalogItemExternalId()));

            BigDecimal mainbalance = BigDecimal.ZERO;
            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtn);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCiId);

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    oldCiId);
            ;
            BigDecimal mainbalanceOldCi = BigDecimal.valueOf(35);
            vodOldCi.setConsumableMainBalanceAmount(mainbalanceOldCi);

            VisibleOfferDetails vodWearable = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    CI_EXTERNAL_IDS.WEARABLE);
            BigDecimal mainbalanceWearables = BigDecimal.valueOf(5);
            vodWearable.setConsumableMainBalanceAmount(mainbalanceWearables);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.appendVisibleOfferDetailsMap(
                    vodWearable.getCatalogItemExternalId(),
                    Long.valueOf(vodWearable.getResourceId()), vodWearable);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.valueOf(testCase.aocDelta);

            doReturn(BigDecimal.valueOf(5)).when(instance).getChargeableAmountForPurchaseOffer(
                    any(), any(), any(), any());

            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ObjectMapper om = TestUtils.getObjectMapper();
                ServiceTaxResponse resp = om.readValue(taxRespString, ServiceTaxResponse.class);
                resp.getTransactionElement().get(0).setTotalFeeAmount(
                        BigDecimal.valueOf(testCase.fixedFee));
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                resp.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertEquals(
                    response.getNewCatalogItem().getDiscountPrice().subtract(newVbpp).subtract(
                            newChime).subtract(
                                    response.getCurrentCatalogItem().getDiscountPrice()).add(
                                            oldVbpp).add(oldChime).max(BigDecimal.ZERO).intValue(),
                    response.getChangeCycle().getDelta().intValue(), "Check Delta");
            assertEquals(
                    testCase.aocDelta, response.getChangeCycle().getAocAmount().doubleValue(),
                    0.001, "Check Aoc amount is as per Aoc Response");
            assertEquals(
                    BigDecimal.valueOf(testCase.aocDelta).max(
                            BigDecimal.valueOf(testCase.fixedFee)).doubleValue(),
                    response.getChangeCycle().getPayableAmount().doubleValue(), 0.001,
                    "Payable Amount of ChangeCycle is MAX(Aoc Amount, FixedFee)");
            assertEquals(
                    BigDecimal.valueOf(testCase.aocDelta).max(
                            BigDecimal.valueOf(testCase.fixedFee)).doubleValue(),
                    response.getChangeCycle().getTotalAmount().doubleValue(), 0.001,
                    "Total Amount of ChangeCycle is MAX(Aoc Amount, FixedFee)");

            System.out.println(
                    "**************************End of " + testCase.testNum
                            + "********************************");
        };

        TestConditions tc = new TestConditions();
        double otherPromos = 10;
        // double[] aocScale = {
        // 0, 0.5, 0.9
        // };
        // for (double scale : aocScale) {
        tc.vbppEligible = true;
        tc.chimeEligible = true;
        tc.otherPromos = otherPromos;
        tc.fixedFee = 1.81;
        tc.oldCi = CI_EXTERNAL_IDS.BASE_CURRENT;
        tc.newCi = CI_EXTERNAL_IDS.PLUS_CURRENT;
        tc.aocDelta = 15 * .5 + 0.33; // random scaling down
        tc.testNum = "#7" + "-AocDelta-" + tc.aocDelta + "-OtherPromos-" + otherPromos;
        pTests.test(tc);
        // }
    }

    @Test
    public void test_getChangeServiceAdvice_ChangeImmidiate_Then_CycleDatesFromAOC(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with Base Monthly offer. PaidCycleStartDate is in past."
        };
        td.when = new String[] {
            "Api is called (With Plus Monthly) for CoreToCore change that affects immidiately"
        };
        td.then = new String[] {
            "CurrentBillCycle Dates should be today and year after that."
        };

        @SuppressWarnings("unchecked")
        OneParameterTest pTests = (tCase) -> {
            String subscriptionExternalId = "123";
            TestConditions testCase = (TestConditions) tCase;
            td.printDescription();
            System.out.println(
                    "**************************Executing " + testCase.testNum
                            + "********************************");

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
            String randomPastDate = "1900-01-01";

            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            request.setSubscriptionExternalId(subscriptionExternalId);
            request.setNewCatalogItemExternalId(testCase.newCi);
            request.setDiscountPrice(testCase.getNewCiPrice());
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.valueOf(100)));

            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            String oldCiId = testCase.oldCi;
            BigDecimal oldPrice = testCase.getOldCiPrice();
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getPurchasedOfferArrayAppender().clear();

            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCiId);

            VisiblePurchasedOfferExtension enrolledExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            enrolledExtn.setChargeAmount(oldPrice);
            enrolledExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCiId);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCiId));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(new MtxDate(randomPastDate));

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(oldCiId, request.getNewCatalogItemExternalId()));

            BigDecimal mainbalance = BigDecimal.ZERO;
            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtn);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(oldCiId);

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    oldCiId);
            BigDecimal mainbalanceOldCi = BigDecimal.valueOf(35);
            vodOldCi.setConsumableMainBalanceAmount(mainbalanceOldCi);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.valueOf(testCase.aocDelta);

            MtxTimestamp newCiStartTime = new MtxTimestamp(
                    LocalDateTime.now().toEpochSecond(ZoneOffset.UTC) * 1000);
            MtxTimestamp newCiEndTime;
            newCiEndTime = TestUtils.getLastDateTimeOfNextMonth();

            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                    testCase.newCi);
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    newCiStartTime);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    newCiEndTime);
            System.out.println(td.getTestMethod() + ":" + deltaAocResp.toJson());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            String taxRespString = CommonTestHelper.getTaxApiResp(testCase.newCi);
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ObjectMapper om = TestUtils.getObjectMapper();
                ServiceTaxResponse resp = om.readValue(taxRespString, ServiceTaxResponse.class);
                resp.getTransactionElement().get(0).setTotalFeeAmount(
                        BigDecimal.valueOf(testCase.fixedFee));
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                resp.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            System.out.println(td.getTestMethod() + ":" + response.toJson());
            System.out.println(newCiStartTime);
            assertEquals(
                    newCiStartTime.longValue(),
                    response.getChangeCycle().getCycleStartTime().longValue(),
                    "Cycle Start Time should be from Aoc Response");
            assertEquals(
                    newCiEndTime.longValue(),
                    response.getChangeCycle().getCycleEndTime().longValue(),
                    "Cycle End Time should be from Aoc Response");
            System.out.println(
                    "**************************End of " + testCase.testNum
                            + "********************************");
        };

        TestConditions tc = new TestConditions();
        SimpleEntry<String, String> change1 = new SimpleEntry<>(
                TestConstants.CI_EXTERNAL_IDS.BASE_CURRENT,
                TestConstants.CI_EXTERNAL_IDS.PLUS_CURRENT);
        List<SimpleEntry<String, String>> changes = List.of(change1);

        for (SimpleEntry<String, String> change : changes) {
            tc.oldCi = change.getKey();
            tc.newCi = change.getValue();
            tc.testNum = "#" + "oldCi:" + tc.oldCi + "-" + "newCi:" + tc.newCi;
            pTests.test(tc);
        }
    }

    @SuppressWarnings("unchecked")
    @Test
    @Tag("VER-207")
    public void getChangeServiceAdvice_When_BaseMonthly2PlusMonthly_PromoNotPurchased_TemplateApplicableBoth_Then_CorrectDelta(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "PaidCycleStartDate is in past.", "Subscriber has BaseMonthly.",
            "Subscriber has no purchased offer instance for 15OFFN."
        };
        td.when = new String[] {
            "ChangeAdvice is called for PlusMonthly offer with 15OFFN."
        };
        td.then = new String[] {
            "ChangeAdvice response should show correct delta."
        };
        td.testInfo = testInfo;
        td.comments = new String[] {
            "MTXVER2-241, VER-207"
        };

        @SuppressWarnings({
            "rawtypes"
        })
        ThreeParameterTest pTests = (req, tc, er) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            ExpectedResponse eResp = (ExpectedResponse) er;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(new ArrayList()));
            Map<String, MtxResponsePricingCatalogItem> ciMap = emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT, tCase.oldCi,
                            request.getNewCatalogItemExternalId()));
            MtxResponsePricingCatalogItem pci15OffN = ciMap.get(CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT);
            VisibleTemplate vt15OffN = (VisibleTemplate) pci15OffN.getCatalogItemInfo().getTemplateAttr();
            vt15OffN.setApplicableOfferName(
                    tCase.oldCi + "," + request.getNewCatalogItemExternalId());
            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            MtxDate paidCycleStartDate = ((VisiblePurchasedOfferExtension) poEnrolled.getAttr()).getPaidCycleStartDate();

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(paidCycleStartDate);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            doReturn("[" + request.getNewCatalogItemExternalId() + "]").when(
                    instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, paidCycleStartDate);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertEquals(
                    ((BigDecimal) eResp.resultMap.get("delta")).intValue(),
                    response.getChangeCycle().getDelta().intValue(),
                    eResp.resultMap.get("deltaDescription").toString());
        };

        // BaseMonthly2PlusMonthly
        TestConditions chg;
        ExpectedResponse eResp;
        VisibleRequestChangeServiceAdvice request;
        String subscriptionExternalId = "123";

        request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        request.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS_CURRENT));
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
        request.setSubscriptionExternalId(subscriptionExternalId);
        VisibleChangeServicePromo csp = new VisibleChangeServicePromo();
        csp.setGrantOfferCI(CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT);
        csp.setGrantAmount(BigDecimal.valueOf(5000));
        VisiblePromoExtension pe = new VisiblePromoExtension();
        pe.setPromotionLimit(BigDecimal.valueOf(9));
        csp.setAttr(pe);
        request.getNewPromotionListAppender().add(csp);

        chg = new TestConditions() {

            {
                newCi = request.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE_CURRENT;
            }
        };
        eResp = new ExpectedResponse() {

            {
                resultMap.put("delta", BigDecimal.valueOf(1));
                resultMap.put("deltaDescription", "(Plus-15OFFN)-(Base)=(35-9)-(25) = 1");
            }
        };
        pTests.test(request, chg, eResp);
    }

    @SuppressWarnings("unchecked")
    @Test
    @Tag("VER-207")
    public void getChangeServiceAdvice_When_BaseMonthly2PlusMonthly_PromoPurchasedAndTaxed_TemplateApplicableBoth_Promo_NOTIN_Request_Then_CorrectDelta(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "PaidCycleStartDate is in past.", "Subscriber has BaseMonthly.",
            "Subscriber has 15OFFN in purchased offer and taxes with it."
        };
        td.when = new String[] {
            "ChangeAdvice is called for PlusMonthly offer. New request does NOT have 15OFFN."
        };
        td.then = new String[] {
            "ChangeAdvice response should show correct delta."
        };
        td.comments = new String[] {
            "MTXVER2-241, VER-207"
        };
        td.testInfo = testInfo;

        ThreeParameterTest pTests = (req, tc, er) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            ExpectedResponse eResp = (ExpectedResponse) er;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            Map<String, MtxResponsePricingCatalogItem> ciMap = emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT, tCase.oldCi,
                            request.getNewCatalogItemExternalId()));
            MtxResponsePricingCatalogItem pci15OffN = ciMap.get(CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT);
            VisibleTemplate vt15OffN = (VisibleTemplate) pci15OffN.getCatalogItemInfo().getTemplateAttr();
            vt15OffN.setApplicableOfferName(
                    tCase.oldCi + "," + request.getNewCatalogItemExternalId());

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            MtxDate paidCycleStartDate = poExtn.getPaidCycleStartDate();
            String promoTax = CommonTestHelper.getPromoTaxResp(
                    CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT, tCase.oldCi,
                    (BigDecimal) tCase.promoMap.get("XOFFNUSED"));
            poExtn.getCreditTaxDetailsArrayAppender().clear();
            poExtn.getCreditTaxDetailsArrayAppender().add(promoTax);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(paidCycleStartDate);

            CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT, null,
                    BigDecimal.valueOf(5000), BigDecimal.ZERO, false);

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().add(promoTax);
            enrolledExtnEvent.setPaidCycleStartDate(paidCycleStartDate);
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));
            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            doReturn("[" + request.getNewCatalogItemExternalId() + "]").when(
                    instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, paidCycleStartDate);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertEquals(
                    ((BigDecimal) eResp.resultMap.get("delta")).intValue(),
                    response.getChangeCycle().getDelta().intValue(),
                    eResp.resultMap.get("deltaDescription").toString());
        };

        // BaseMonthly2PlusMonthly
        TestConditions chg;
        ExpectedResponse eResp;
        VisibleRequestChangeServiceAdvice request;
        String subscriptionExternalId = "123";

        request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        request.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS_CURRENT));
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
        request.setSubscriptionExternalId(subscriptionExternalId);

        chg = new TestConditions() {

            {
                newCi = request.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE_CURRENT;
            }
        };
        chg.promoMap.put("XOFFNUSED", BigDecimal.valueOf(8));
        eResp = new ExpectedResponse() {

            {
                resultMap.put("delta", BigDecimal.valueOf(3));
                resultMap.put(
                        "deltaDescription",
                        "(Plus-XOFFNNew)-(Base-XOFFNUsed)=(35-15)-(25-8)=(20)-(17) = 3");
            }
        };
        pTests.test(request, chg, eResp);
    }

    @SuppressWarnings("unchecked")
    @Test
    @Tag("VER-207")
    public void getChangeServiceAdvice_When_BaseMonthly2PlusMonthly_PromoPurchasedNotTaxed_TemplateApplicableBoth_Promo_NOT_inRequest_Then_CorrectDelta(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "PaidCycleStartDate is in past.", "Subscriber has BaseMonthly.",
            "Subscriber has 15OFFN in purchased offer but no event with taxes."
        };
        td.when = new String[] {
            "ChangeAdvice is called for PlusMonthly offer. New request does NOT have 15OFFN."
        };
        td.then = new String[] {
            "ChangeAdvice response should show correct delta."
        };
        td.comments = new String[] {
            "MTXVER2-241, VER-207"
        };
        td.testInfo = testInfo;

        ThreeParameterTest pTests = (req, tc, er) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            ExpectedResponse eResp = (ExpectedResponse) er;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            Map<String, MtxResponsePricingCatalogItem> ciMap = emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT, tCase.oldCi,
                            request.getNewCatalogItemExternalId()));
            MtxResponsePricingCatalogItem pci15OffN = ciMap.get(CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT);
            VisibleTemplate vt15OffN = (VisibleTemplate) pci15OffN.getCatalogItemInfo().getTemplateAttr();
            vt15OffN.setApplicableOfferName(
                    tCase.oldCi + "," + request.getNewCatalogItemExternalId());

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            MtxDate paidCycleStartDate = poExtn.getPaidCycleStartDate();
            poExtn.getCreditTaxDetailsArrayAppender().clear();

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(paidCycleStartDate);

            MtxPurchasedOfferInfo promoEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT, null,
                    BigDecimal.valueOf(5000), BigDecimal.ZERO, false);
            VisiblePurchasedOfferExtension promoExtn = (VisiblePurchasedOfferExtension) promoEnrolled.getAttr();
            promoExtn.setPromotionLimit((BigDecimal) tCase.promoMap.get("XOFFNLIMIT"));

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));
            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            doReturn("[" + request.getNewCatalogItemExternalId() + "]").when(
                    instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, paidCycleStartDate);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertEquals(
                    ((BigDecimal) eResp.resultMap.get("delta")).intValue(),
                    response.getChangeCycle().getDelta().intValue(),
                    eResp.resultMap.get("deltaDescription").toString());
        };

        // BaseMonthly2PlusMonthly
        TestConditions chg;
        ExpectedResponse eResp;
        VisibleRequestChangeServiceAdvice request;
        String subscriptionExternalId = "123";

        request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        request.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS_CURRENT));
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
        request.setSubscriptionExternalId(subscriptionExternalId);

        chg = new TestConditions() {

            {
                newCi = request.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE_CURRENT;
            }
        };
        chg.promoMap.put("XOFFNLIMIT", BigDecimal.valueOf(15));
        eResp = new ExpectedResponse() {

            {
                resultMap.put("delta", BigDecimal.valueOf(10));
                resultMap.put(
                        "deltaDescription",
                        "(Plus-XOFFNLIMIT)-(Base-XOFFNLIMIT)=(35-15)-(25-15)=(20)-(10) = 10");
            }
        };
        pTests.test(request, chg, eResp);
    }

    @SuppressWarnings("unchecked")
    @Test
    @Tag("VER-207")
    public void getChangeServiceAdvice_When_BaseMonthly2PlusMonthly_PromoPurchasedAndTaxed_TemplateApplicableBoth_Promo_IN_Request_Then_CorrectDelta(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "PaidCycleStartDate is in past.", "Subscriber has BaseMonthly.",
            "Subscriber has 15OFFN in purchased offer and taxes with it."
        };
        td.when = new String[] {
            "ChangeAdvice is called for PlusMonthly offer. New request does have 15OFFN."
        };
        td.then = new String[] {
            "ChangeAdvice response should show correct delta."
        };
        td.comments = new String[] {
            "MTXVER2-241, VER-207"
        };
        td.testInfo = testInfo;

        ThreeParameterTest pTests = (req, tc, er) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            ExpectedResponse eResp = (ExpectedResponse) er;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            Map<String, MtxResponsePricingCatalogItem> ciMap = emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT, tCase.oldCi,
                            request.getNewCatalogItemExternalId()));
            MtxResponsePricingCatalogItem pci15OffN = ciMap.get(CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT);
            VisibleTemplate vt15OffN = (VisibleTemplate) pci15OffN.getCatalogItemInfo().getTemplateAttr();
            vt15OffN.setApplicableOfferName(
                    tCase.oldCi + "," + request.getNewCatalogItemExternalId());

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            MtxDate paidCycleStartDate = poExtn.getPaidCycleStartDate();
            String promoTax = "{\"msgID\":\"15OFFN\",\"customerType\":\"99\",\"planID\":\"BASE001A\",\"grossPrice\":\"10.00\",\"discountPrice\":\""
                    + tCase.promoMap.get("XOFFNUSED")
                    + "\",\"promotionCredit\":\"true\",\"offer606RevAdjDailyRecog\":\"0\",\"promotionReason\":\"Group_Discounts\",\"geocode\":\"US0100108296\",\"taxTreatment\":\"inclusive\",\"classCode\":\"15OFFN\",\"glDate\":\"2019-03-07\",\"transactionElement\":[{\"btcTransactionCode\":\"01\",\"totalTaxAmount\":\"0.07389163\",\"totalFeeAmount\":\"0.00000000\",\"totalNetRevenue\":\"4.92610836\",\"modifiedDisplayNetRevenue\":\"4.93\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"618\",\"cP\":\"0.75\",\"glReference\":\"Visible_Unlimited_Data\",\"dpcItemTaxAmount\":\"0.00000000\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"3.69458128\",\"taxItemList\":[]},{\"dpcItem\":\"601\",\"cP\":\"0.12\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.03546798\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.59113300\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.02364532\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.01182266\"}]},{\"dpcItem\":\"662\",\"cP\":\"0.04\",\"glReference\":\"Visible_Unlimited_Text\",\"dpcItemTaxAmount\":\"0.01182266\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.19704433\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.00788177\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.00394089\"}]},{\"dpcItem\":\"629\",\"cP\":\"0.09\",\"glReference\":\"Visible_Unlimited_MMS\",\"dpcItemTaxAmount\":\"0.02660099\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.44334975\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.01773399\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.00886700\"}]}]}]},{\"btcTransactionCode\":\"93\",\"totalTaxAmount\":\"0.03002956\",\"totalFeeAmount\":\"0.00000000\",\"totalNetRevenue\":\"4.92610836\",\"modifiedDisplayNetRevenue\":\"4.93\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"601\",\"cP\":\"0.12\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.03002956\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.59113300\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000000016\",\"tat\":\"0\",\"taxCategory\":\"00\",\"taxType\":\"35\",\"description\":\"Fed Universal Service Charge\",\"rate\":\"0.050800000000\",\"taxAmount\":\"0.03002956\"}]}]}]}]}";
            poExtn.getCreditTaxDetailsArrayAppender().clear();
            poExtn.getCreditTaxDetailsArrayAppender().add(promoTax);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(paidCycleStartDate);

            CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT, null,
                    BigDecimal.valueOf(5000), BigDecimal.ZERO, false);
            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().add(promoTax);
            enrolledExtnEvent.setPaidCycleStartDate(paidCycleStartDate);
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            doReturn("[" + request.getNewCatalogItemExternalId() + "]").when(
                    instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, paidCycleStartDate);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertEquals(
                    ((BigDecimal) eResp.resultMap.get("delta")).intValue(),
                    response.getChangeCycle().getDelta().intValue(),
                    eResp.resultMap.get("deltaDescription").toString());
        };

        // BaseMonthly2PlusMonthly
        TestConditions chg;
        ExpectedResponse eResp;
        VisibleRequestChangeServiceAdvice request;
        String subscriptionExternalId = "123";

        request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        request.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS_CURRENT));
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
        request.setSubscriptionExternalId(subscriptionExternalId);
        VisibleChangeServicePromo csp = new VisibleChangeServicePromo();
        csp.setGrantOfferCI(CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT);
        csp.setGrantAmount(BigDecimal.valueOf(5000));
        VisiblePromoExtension pe = new VisiblePromoExtension();
        pe.setPromotionLimit(BigDecimal.valueOf(9));
        csp.setAttr(pe);
        request.getNewPromotionListAppender().add(csp);

        chg = new TestConditions() {

            {
                newCi = request.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE_CURRENT;
            }
        };
        chg.promoMap.put("XOFFNUSED", BigDecimal.valueOf(8));
        eResp = new ExpectedResponse() {

            {
                resultMap.put("delta", BigDecimal.valueOf(9));
                resultMap.put(
                        "deltaDescription",
                        "(Plus-XOFFNLIMIT)-(Base-XOFFNUSED)=(35-9)-(25-8)=(26)-(17) = 9");
            }
        };
        pTests.test(request, chg, eResp);
    }

    @SuppressWarnings("unchecked")
    @Test()
    @Tag("VER-143")
    public void test_getChangeServiceAdvice_When_Promo_NotApplicable_InTemplate_And_Promo_In_Request_Then_PromoIgnored(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscriber is enrolled in BaseMonthly.", "PaidCycleStartDate is in past."
        };
        td.when = new String[] {
            "ChangeServiceAdvice is called to upgrade to PlusMonthly.", "A promo is in request.",
            "Promo is not applicable to plus monthly as per Template Attributes"
        };
        td.then = new String[] {
            "Promo should not be in response.", "Promo should be ignored from delta calculation.",
            "There should be a warning message."
        };

        ThreeParameterTest pTests = (req, tc, er) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            ExpectedResponse eResp = (ExpectedResponse) er;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            Map<String, MtxResponsePricingCatalogItem> ciMap = emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT, tCase.oldCi,
                            request.getNewCatalogItemExternalId()));
            MtxResponsePricingCatalogItem pci15OffN = ciMap.get(CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT);
            VisibleTemplate vt15OffN = (VisibleTemplate) pci15OffN.getCatalogItemInfo().getTemplateAttr();
            vt15OffN.setApplicableOfferName(tCase.oldCi);

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            MtxDate paidCycleStartDate = poExtn.getPaidCycleStartDate();

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(paidCycleStartDate);

            CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT, null,
                    BigDecimal.valueOf(5000), BigDecimal.ZERO, false);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));
            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            doReturn("[" + request.getNewCatalogItemExternalId() + "]").when(
                    instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, paidCycleStartDate);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertEquals(
                    ((BigDecimal) eResp.resultMap.get("delta")).intValue(),
                    response.getChangeCycle().getDelta().intValue(),
                    eResp.resultMap.get("deltaDescription").toString());
        };

        // BaseMonthly2PlusMonthly
        TestConditions chg;
        ExpectedResponse eResp;
        VisibleRequestChangeServiceAdvice request;
        String subscriptionExternalId = "123";

        request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PRO_CURRENT);
        request.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PRO_CURRENT));
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
        request.setSubscriptionExternalId(subscriptionExternalId);
        VisibleChangeServicePromo csp = new VisibleChangeServicePromo();
        csp.setGrantOfferCI(CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT);
        csp.setGrantAmount(BigDecimal.valueOf(5000));
        VisiblePromoExtension pe = new VisiblePromoExtension();
        pe.setPromotionLimit(BigDecimal.valueOf(14));
        csp.setAttr(pe);
        request.getNewPromotionListAppender().add(csp);

        chg = new TestConditions() {

            {
                newCi = request.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE_CURRENT;
            }
        };
        eResp = new ExpectedResponse() {

            {
                resultMap.put("delta", BigDecimal.valueOf(35));
                resultMap.put(
                        "deltaDescription",
                        "(Pro-0)-(Base-15OFFN)=(45-0)-(30-15OFFN)=(45)-(25-15) = 35");
            }
        };
        pTests.test(request, chg, eResp);
    }

    @SuppressWarnings("unchecked")
    @Test()
    @Tag("VER-143")
    public void test_getChangeServiceAdvice_When_Promo_NotApplicable_InPurchasedGrant_And_Promo_Not_In_Request_Then_PromoIgnored(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscriber is enrolled in BaseMonthly.", "PaidCycleStartDate is in past."
        };
        td.when = new String[] {
            "ChangeServiceAdvice is called to upgrade to PlusMonthly.",
            "A promo is not in request.",
            "Promo is not applicable to plus monthly as per Purchased Grant Attributes"
        };
        td.then = new String[] {
            "Promo should not be in response.", "Promo should be ignored from delta calculation."
        };

        ThreeParameterTest pTests = (req, tc, er) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            ExpectedResponse eResp = (ExpectedResponse) er;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            Map<String, MtxResponsePricingCatalogItem> ciMap = emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT, tCase.oldCi,
                            request.getNewCatalogItemExternalId()));
            MtxResponsePricingCatalogItem pci15OffN = ciMap.get(CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT);
            VisibleTemplate vt15OffN = (VisibleTemplate) pci15OffN.getCatalogItemInfo().getTemplateAttr();
            vt15OffN.setApplicableOfferName(tCase.oldCi + "," + tCase.newCi);

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            MtxDate paidCycleStartDate = poExtn.getPaidCycleStartDate();

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            MtxPurchasedOfferInfo grantEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT, null,
                    BigDecimal.valueOf(5000), BigDecimal.ZERO, false);
            VisiblePurchasedOfferExtension grantAttr = (VisiblePurchasedOfferExtension) grantEnrolled.getAttr();
            grantAttr.setApplicableOfferName(tCase.oldCi);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));
            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            doReturn("[" + request.getNewCatalogItemExternalId() + "]").when(
                    instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, paidCycleStartDate);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertEquals(
                    ((BigDecimal) eResp.resultMap.get("delta")).intValue(),
                    response.getChangeCycle().getDelta().intValue(),
                    eResp.resultMap.get("deltaDescription").toString());
        };

        // BaseMonthly2PlusMonthly
        TestConditions chg;
        ExpectedResponse eResp;
        VisibleRequestChangeServiceAdvice request;
        String subscriptionExternalId = "123";

        request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PRO_CURRENT);
        request.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PRO_CURRENT));
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
        request.setSubscriptionExternalId(subscriptionExternalId);

        chg = new TestConditions() {

            {
                newCi = request.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE_CURRENT;
            }
        };
        eResp = new ExpectedResponse() {

            {
                resultMap.put("delta", BigDecimal.valueOf(35));
                resultMap.put(
                        "deltaDescription",
                        "(Pro-0)-(BAse-15OFFN)=(45-0)-(25-15OFFN)=(45)-(25-15) = 35");
            }
        };
        pTests.test(request, chg, eResp);
    }

    @SuppressWarnings({
        "unchecked"
    })
    @Test
    @Tag("VER-300")
    public void test_getChangeServiceAdvice_When_TrialAndPlusMonthly_DowngradeToBaseMonthly_Then_Success(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has PLUS2VIS22WB and Trial offer.", "Trial offer is configured as"
        };
        td.when = new String[] {
            "Api is called with BASE2VISIBLE22."
        };
        td.then = new String[] {
            "ChangeCycle advice should ignore trial offer and consider plus offer. This should be based on change type properties listed in rsgateway.properties"
        };
        td.comments = new String[] {
            "VER-300"
        };

        OneParameterTest pTests = (offerTypeTrial) -> {
            String temp = td.given[1];
            td.given[1] = td.given[1] + " " + offerTypeTrial.toString();
            td.printDescription();
            td.given[1] = temp;

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = new VisibleRequestChangeServiceAdvice();
            String newCiId = CI_EXTERNAL_IDS.BASE_CURRENT;
            BigDecimal newDiscountPrice = OFFER_PRICES.BASE_CURRENT;
            String oldCiId = CI_EXTERNAL_IDS.PLUS_CURRENT;
            BigDecimal oldPrice = OFFER_PRICES.PLUS_CURRENT;

            request.setNewCatalogItemExternalId(newCiId);
            request.setGrossPrice(BigDecimal.valueOf(100));
            request.setDiscountPrice(newDiscountPrice);
            request.setSubscriptionExternalId(subscriptionExternalId);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poPlus = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldCiId);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poPlus.getAttr();
            poExtn.setPaidCycleStartDate(null);

            CommonTestHelper.getMtxPurchasedOfferInfo(subscription, CI_EXTERNAL_IDS.TRIAL22);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscriptionExternalId));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCiId);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(oldPrice);
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(null);

            CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, CI_EXTERNAL_IDS.TRIAL22);

            Map<String, MtxResponsePricingCatalogItem> pciMap = emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(oldCiId, CI_EXTERNAL_IDS.TRIAL22, newCiId));
            VisibleTemplate vtTrial = (VisibleTemplate) pciMap.get(
                    CI_EXTERNAL_IDS.TRIAL22).getCatalogItemInfo().getTemplateAttr();
            vtTrial.setOfferType(offerTypeTrial.toString());

            System.out.println(pciMap.get(CI_EXTERNAL_IDS.TRIAL22).toJson());

            MtxResponseWallet wallet = emulateMtxResponseWallet(
                    instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
            wallet.getBillingCycle().setCurrentPeriodEndTime(
                    new MtxTimestamp(
                            System.currentTimeMillis()
                                    + DATE_TIME_CONSTANTS.MILLISECONDS_IN_A_DAY));

            VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetailsForServicOffer(
                    oldCiId);
            BigDecimal mainbalanceUnlimited = BigDecimal.valueOf(35);
            vodUnlimited.setConsumableMainBalanceAmount(mainbalanceUnlimited);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodUnlimited.getCatalogItemExternalId(),
                    Long.valueOf(vodUnlimited.getResourceId()), vodUnlimited);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());

            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                    newCiId);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);

            instance.getChangeServiceAdvice(request, response);
            System.out.println(td.getTestMethod() + ":" + response.toJson());

            String expectedChangeType = AppPropertyProvider.getInstance().getString(
                    CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_PREFIX + oldCiId
                            + CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_OFFER_SEPARATOR_TO
                            + request.getNewCatalogItemExternalId());
            assertEquals(expectedChangeType, response.getChangeType());
            assertEquals(0, response.getChangeCycle().getPayableAmount().intValue());
        };
        pTests.test("Base");
        pTests.test("Promo");
    }

    @SuppressWarnings({
        "unchecked"
    })
    @Test
    @Tag("VER-367")
    public void test_getChangeServiceAdvice_When_IncludePaymentAdvice_And_ChangeToMonthly_Then_IncludePaymentAdvice(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service."
        };
        td.when = new String[] {
            "Api is called with with target monthly service.", "IncludePaymentAdvice = Y"
        };
        td.then = new String[] {
            "Advice should include PaymentAdvice for next service."
        };
        td.comments = new String[] {
            "VER-367"
        };

        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(tCase.oldCi, request.getNewCatalogItemExternalId()));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            if (tCase.paidCycleStartDate != null) {
                poExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            }

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getEmptyMtxResponseMulti());

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            doReturn("[" + request.getNewCatalogItemExternalId() + "]").when(
                    instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getFirstDateTimeOfNextMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertTrue(
                    response.getRechargeAmount().compareTo(
                            response.getChangeCycle().getDelta()) <= 0);
            assertTrue(response.getNextCyclePaymentAdvice() != null);
            assertEquals(
                    request.getNewCatalogItemExternalId(),
                    response.getNextCyclePaymentAdvice().getAtVisibleOfferDetailsList(
                            0).getCatalogItemExternalId());
            assertEquals(
                    request.getDiscountPrice().intValue(),
                    response.getNextCyclePaymentAdvice().getAtVisibleOfferDetailsList(
                            0).getPayableAmount().intValue());
        };

        String subscriptionExternalId = "123";

        // BaseMonthly2PlusMonthly
        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS_CURRENT));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId(subscriptionExternalId);
        requestUp.setIncludePaymentAdvice("Y");

        TestConditions chgUp = new TestConditions() {

            {
                newCi = requestUp.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE_CURRENT;
                paidCycleStartDate = TestUtils.getDateYesterday();
            }
        };
        pTests.test(requestUp, chgUp);
    }

    @SuppressWarnings({
        "unchecked"
    })
    @Test
    @Tag("VER-367")
    public void test_getChangeServiceAdvice_When_IncludePaymentAdvice_And_ChangeToMonthly_WithWearableAndInsurance_Then_PromosInPaymentAdvice(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service."
        };
        td.when = new String[] {
            "Api is called with with target monthly service.", "IncludePaymentAdvice = Y",
            "Subscriber has Insurance and/or wearable"
        };
        td.then = new String[] {
            "Advice should include PaymentAdvice for next service with insurance / wearable."
        };
        td.comments = new String[] {
            "VER-367"
        };

        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            tCase.oldCi, request.getNewCatalogItemExternalId(),
                            CI_EXTERNAL_IDS.INSURANCE, CI_EXTERNAL_IDS.WEARABLE));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            if (tCase.paidCycleStartDate != null) {
                poExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            }

            MtxPurchasedOfferInfo poInsurance = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, CI_EXTERNAL_IDS.INSURANCE);
            VisiblePurchasedOfferExtension insuranceExtn = (VisiblePurchasedOfferExtension) poInsurance.getAttr();
            if (tCase.paidCycleStartDate != null) {
                insuranceExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            }

            MtxPurchasedOfferInfo poWearable = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, CI_EXTERNAL_IDS.WEARABLE);
            VisiblePurchasedOfferExtension wearableExtn = (VisiblePurchasedOfferExtension) poWearable.getAttr();
            if (tCase.paidCycleStartDate != null) {
                wearableExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            }

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            PurchasedOfferInfo poiInsurance = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, CI_EXTERNAL_IDS.INSURANCE);
            VisiblePurchasedOfferExtension insurancePoiExtn = (VisiblePurchasedOfferExtension) poiInsurance.getAttr();
            insurancePoiExtn.setChargeAmount(
                    CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.INSURANCE));
            insurancePoiExtn.getCreditTaxDetailsArrayAppender().clear();
            insurancePoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            PurchasedOfferInfo poiWearable = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, CI_EXTERNAL_IDS.WEARABLE);
            VisiblePurchasedOfferExtension wearablePoiExtn = (VisiblePurchasedOfferExtension) poiWearable.getAttr();
            wearablePoiExtn.setChargeAmount(
                    CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.WEARABLE));
            wearablePoiExtn.getCreditTaxDetailsArrayAppender().clear();
            wearablePoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getEmptyMtxResponseMulti());

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            doReturn("[" + request.getNewCatalogItemExternalId() + "]").when(
                    instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getFirstDateTimeOfNextMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            System.out.println(
                    td.getTestMethod() + ":" + response.getRechargeAmount() + "--"
                            + response.getChangeCycle().getDelta());
            assertTrue(
                    response.getRechargeAmount().compareTo(
                            response.getChangeCycle().getDelta()) <= 0);
            assertTrue(response.getNextCyclePaymentAdvice() != null);

            boolean basePresent = false;
            boolean insurancePresent = false;
            boolean wearablePresent = false;
            for (VisibleOfferDetails vod : response.getNextCyclePaymentAdvice().getVisibleOfferDetailsList()) {
                if (request.getNewCatalogItemExternalId().equalsIgnoreCase(
                        vod.getCatalogItemExternalId())) {
                    basePresent = true;
                }
                if (CI_EXTERNAL_IDS.WEARABLE.equalsIgnoreCase(vod.getCatalogItemExternalId())) {
                    wearablePresent = true;
                }
                if (CI_EXTERNAL_IDS.INSURANCE.equalsIgnoreCase(vod.getCatalogItemExternalId())) {
                    insurancePresent = true;
                }
            }
            assertTrue(basePresent);
            assertTrue(wearablePresent);
            assertTrue(insurancePresent);
        };

        String subscriptionExternalId = "123";

        // BaseMonthly2PlusMonthly
        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS_CURRENT));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId(subscriptionExternalId);
        requestUp.setIncludePaymentAdvice("Y");

        TestConditions chgUp = new TestConditions() {

            {
                newCi = requestUp.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE_CURRENT;
                paidCycleStartDate = TestUtils.getDateYesterday();
            }
        };
        pTests.test(requestUp, chgUp);
    }

    @SuppressWarnings({
        "unchecked"
    })
    @Test
    @Tag("VER-367")
    public void test_getChangeServiceAdvice_When_IncludePaymentAdvice_And_ChangeToMonthly_NewServiceStartsLater_Then_IncludePaymentAdvice(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service."
        };
        td.when = new String[] {
            "Api is called with with target monthly service.", "IncludePaymentAdvice = Y",
            "New service starts next month."
        };
        td.then = new String[] {
            "Advice should include PaymentAdvice for next service."
        };
        td.comments = new String[] {
            "VER-367"
        };
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(tCase.oldCi, request.getNewCatalogItemExternalId()));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            if (tCase.paidCycleStartDate != null) {
                poExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            }

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getEmptyMtxResponseMulti());

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            doReturn("[" + request.getNewCatalogItemExternalId() + "]").when(
                    instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_BASE2VISIBLE22_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getFirstDateTimeOfNextMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertTrue(
                    response.getRechargeAmount().compareTo(
                            response.getChangeCycle().getDelta()) <= 0);
            assertTrue(response.getNextCyclePaymentAdvice() != null);
            assertEquals(
                    request.getNewCatalogItemExternalId(),
                    response.getNextCyclePaymentAdvice().getAtVisibleOfferDetailsList(
                            0).getCatalogItemExternalId());
            assertEquals(
                    request.getDiscountPrice().intValue(),
                    response.getNextCyclePaymentAdvice().getAtVisibleOfferDetailsList(
                            0).getPayableAmount().intValue());
        };

        String subscriptionExternalId = "123";

        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.BASE_CURRENT);
        requestUp.setDiscountPrice(
                CommonTestHelper.getOfferPrice(requestUp.getNewCatalogItemExternalId()));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId(subscriptionExternalId);
        requestUp.setIncludePaymentAdvice("Y");

        TestConditions chgUp = new TestConditions() {

            {
                newCi = requestUp.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.PLUS_CURRENT;
                paidCycleStartDate = TestUtils.getDateYesterday();
            }
        };
        pTests.test(requestUp, chgUp);
    }

    @SuppressWarnings({
        "unchecked"
    })
    @Test
    @Tag("VER-367")
    public void test_getChangeServiceAdvice_When_IncludePaymentAdvice_And_ChangeToAnnual_Then_IncludePaymentAdvice(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service."
        };
        td.when = new String[] {
            "Api is called with with target Annual service.", "IncludePaymentAdvice = Y"
        };
        td.then = new String[] {
            "Advice should include PaymentAdvice."
        };
        td.comments = new String[] {
            "VER-367"
        };
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(tCase.oldCi, request.getNewCatalogItemExternalId()));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            if (tCase.paidCycleStartDate != null) {
                poExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            }

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            subscriptionResponse.getBillingCycle().setDateOffset(1L);
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getEmptyMtxResponseMulti());

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            doReturn("[" + request.getNewCatalogItemExternalId() + "]").when(
                    instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            Map<String, BigDecimal> balImpactMap = Map.of(
                    BALANCE_NAMES.GLOBAL_PASS, BigDecimal.ONE);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), aocAmount, null, balImpactMap, true);

            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                // Since new Ci starts next cycle there will be no prorated charge. TaxApi gets
                // called only once.
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertTrue(
                    response.getRechargeAmount().compareTo(
                            response.getChangeCycle().getDelta()) <= 0);
            assertTrue(response.getNextCyclePaymentAdvice() != null);
            assertEquals(
                    request.getNewCatalogItemExternalId(),
                    response.getNextCyclePaymentAdvice().getAtVisibleOfferDetailsList(
                            0).getCatalogItemExternalId());
            assertEquals(
                    request.getDiscountPrice().intValue(),
                    response.getNextCyclePaymentAdvice().getAtVisibleOfferDetailsList(
                            0).getPayableAmount().intValue());
        };

        String subscriptionExternalId = "123";

        // BaseMonthly2PlusMonthly
        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS3ANNUAL));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId(subscriptionExternalId);
        requestUp.setIncludePaymentAdvice("Y");

        TestConditions chgUp = new TestConditions() {

            {
                newCi = requestUp.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.PLUS3VIS23WB;
                paidCycleStartDate = TestUtils.getDateYesterday();
            }
        };
        pTests.test(requestUp, chgUp);
    }

    @SuppressWarnings({
        "unchecked"
    })
    @Test
    @Tag("VER-367")
    public void test_getChangeServiceAdvice_When_IncludePaymentAdvice_And_ChangeToMonthly_PromosNowAvailable_Then_PromosInPaymentAdvice(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service."
        };
        td.when = new String[] {
            "Api is called with with target monthly service.", "IncludePaymentAdvice = Y",
            "New service is eligible for some existing promos"
        };
        td.then = new String[] {
            "Advice should include PaymentAdvice for next service with promos."
        };
        td.comments = new String[] {
            "VER-367"
        };
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            String promoGrantOffer = tCase.promoMap.get("PROMOOFFER").toString();

            Map<String, MtxResponsePricingCatalogItem> pricingCiMap = emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(
                            tCase.oldCi, request.getNewCatalogItemExternalId(), promoGrantOffer));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            if (tCase.paidCycleStartDate != null) {
                poExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            }

            BigDecimal ref20Grant = (BigDecimal) tCase.promoMap.get("PROMOGRANT");
            CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, promoGrantOffer, null, ref20Grant, BigDecimal.ZERO, false);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            List<String> balPriList = Arrays.asList(
                    CommonTestHelper.getGrantBalanceName(promoGrantOffer));
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            doReturn("[" + request.getNewCatalogItemExternalId() + "]").when(
                    instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.ZERO;
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getFirstDateTimeOfNextMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            MtxResponsePricingCatalogItem ciRef35 = pricingCiMap.get(promoGrantOffer);
            VisibleTemplate vtRef35 = ((VisibleTemplate) ciRef35.getCatalogItemInfo().getTemplateAttr());
            vtRef35.setApplicableOfferName(tCase.newCi);

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            assertTrue(response.getNextCyclePaymentAdvice() != null);
            assertTrue(response.getNextCyclePaymentAdvice().getCredits() != null);
            assertEquals(
                    request.getNewCatalogItemExternalId(),
                    response.getNextCyclePaymentAdvice().getAtCredits(0).getApplicableCI());
            assertEquals(
                    CommonTestHelper.getRedeemOfferName(promoGrantOffer),
                    response.getNextCyclePaymentAdvice().getAtCredits(
                            0).getCreditRedeemableOfferCI());
            assertTrue(
                    ((BigDecimal) tCase.promoMap.get("PROMOREDEEM")).compareTo(
                            response.getNextCyclePaymentAdvice().getAtCredits(
                                    0).getRedeemableCredits()) == 0);
            assertTrue(
                    ((BigDecimal) tCase.promoMap.get("PROMOREDEEM")).compareTo(
                            response.getNextCyclePaymentAdvice().getAtVisibleOfferDetailsList(
                                    0).getAtCredits(0).getRedeemableCredits()) == 0);
        };

        String subscriptionExternalId = "123";

        // BaseMonthly2PlusMonthly
        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS_CURRENT));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId(subscriptionExternalId);
        requestUp.setIncludePaymentAdvice("Y");

        TestConditions chgUp = new TestConditions() {

            {
                newCi = requestUp.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE_CURRENT;
                paidCycleStartDate = TestUtils.getFirstDateOfCurrentMonth();
            }
        };
        chgUp.promoMap.put("PROMOGRANT", BigDecimal.valueOf(20));
        chgUp.promoMap.put("PROMOREDEEM", BigDecimal.valueOf(20));
        chgUp.promoMap.put("PROMOOFFER", CI_EXTERNAL_IDS.REF20_GRANT);
        pTests.test(requestUp, chgUp);
    }

    @SuppressWarnings({
        "unchecked"
    })
    @Test
    @Tag("VER-367")
    public void test_getChangeServiceAdvice_When_IncludePaymentAdvice_And_ChangeToMonthly_AocPromosAvailable_Then_PromosInPaymentAdvice(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service."
        };
        td.when = new String[] {
            "Api is called with with target monthly service.", "IncludePaymentAdvice = Y",
            "New service is eligible for some aoc existing promos"
        };
        td.then = new String[] {

            "Advice should include PaymentAdvice for next service with promos."
        };
        td.comments = new String[] {
            "VER-367"
        };
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            String promoOffer = CI_EXTERNAL_IDS.CA5_GRANT;
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getSubscriptionResponse(List.of(tCase.oldCi, promoOffer)));

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(subscriptionResponse));
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) subscription.getAtPurchasedOfferArray(
                    0).getAttr();
            emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            tCase.oldCi, request.getNewCatalogItemExternalId(),
                            CI_EXTERNAL_IDS.CA5_GRANT));

            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getEmptyMtxResponseMulti());

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(poExtn);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            doReturn("[" + request.getNewCatalogItemExternalId() + "]").when(
                    instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.ZERO;
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getFirstDateTimeOfNextMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            MtxResponseGroup respGrp = CommonTestHelper.getMtxResponseGroupCA(
                    subscriptionResponse.getExternalId(), "CAGroup",
                    List.of(subscriptionResponse.getObjectId().toString(), "1-2-3-4", "6-7-8-9"),
                    List.of(
                            String.format(
                                    GROUP_CONSTANTS.CA_LINK_FORMAT,
                                    subscriptionResponse.getExternalId(), "13579")));

            SubscriberGroup sg = new SubscriberGroup(respGrp);
            aopStage.appendSubscriberGroupList(sg);

            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            BigDecimal vbppCredits = BigDecimal.valueOf(5);
            doReturn(vbppCredits.negate()).when(instance).getChargeableAmountForPurchaseOffer(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    CI_EXTERNAL_IDS.CA5_REDEEM)),
                    any(), any());

            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());

            List<String> balPriList = Arrays.asList(BALANCE_NAMES.CA5_GRANT);
            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));
            
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            assertTrue(response.getNextCyclePaymentAdvice() != null);
            assertTrue(response.getNextCyclePaymentAdvice().getCredits() != null);
            assertEquals(
                    request.getNewCatalogItemExternalId(),
                    response.getNextCyclePaymentAdvice().getAtCredits(0).getApplicableCI());
            assertEquals(
                    CommonTestHelper.getRedeemOfferName(promoOffer),
                    response.getNextCyclePaymentAdvice().getAtCredits(
                            0).getCreditRedeemableOfferCI());
            assertTrue(
                    vbppCredits.compareTo(
                            response.getNextCyclePaymentAdvice().getAtCredits(
                                    0).getRedeemableCredits()) == 0);
            assertTrue(
                    vbppCredits.compareTo(
                            response.getNextCyclePaymentAdvice().getAtVisibleOfferDetailsList(
                                    0).getAtCredits(0).getRedeemableCredits()) == 0);
        };

        String subscriptionExternalId = "123";

        // BaseMonthly2PlusMonthly
        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS_CURRENT));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId(subscriptionExternalId);
        requestUp.setIncludePaymentAdvice("Y");

        TestConditions chgUp = new TestConditions() {

            {
                newCi = requestUp.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE_CURRENT;
                paidCycleStartDate = TestUtils.getFirstDateOfCurrentMonth();
            }
        };
        pTests.test(requestUp, chgUp);
    }

    @SuppressWarnings({
        "unchecked"
    })
    @Test
    @Tag("VER-367")
    public void test_getChangeServiceAdvice_When_IncludePaymentAdvice_And_ChangeToMonthly_PromosWillBeAvailable_Then_PromosInPaymentAdvice(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service."
        };
        td.when = new String[] {
            "Api is called with with target monthly service.", "IncludePaymentAdvice = Y",
            "New service is eligible for some new promos that will be supplied in input parameters"
        };
        td.then = new String[] {
            "Advice should include PaymentAdvice for next service with new promos."
        };
        td.comments = new String[] {
            "VER-367"
        };

        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            String promoGrantOffer = request.getAtNewPromotionList(0).getGrantOfferCI();

            emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            tCase.oldCi, request.getNewCatalogItemExternalId(),
                            CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            if (tCase.paidCycleStartDate != null) {
                poExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            }

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getEmptyMtxResponseMulti());

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            doReturn("[" + request.getNewCatalogItemExternalId() + "]").when(
                    instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getFirstDateTimeOfNextMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            assertTrue(response.getNextCyclePaymentAdvice() != null);
            assertTrue(response.getNextCyclePaymentAdvice().getCredits() != null);
            assertEquals(
                    request.getNewCatalogItemExternalId(),
                    response.getNextCyclePaymentAdvice().getAtCredits(0).getApplicableCI());
            assertEquals(
                    CommonTestHelper.getRedeemOfferName(promoGrantOffer),
                    response.getNextCyclePaymentAdvice().getAtCredits(
                            0).getCreditRedeemableOfferCI());
            assertTrue(
                    ((BigDecimal) tCase.promoMap.get("PROMOREDEEM")).compareTo(
                            response.getNextCyclePaymentAdvice().getAtCredits(
                                    0).getRedeemableCredits()) == 0);
            assertTrue(
                    ((BigDecimal) tCase.promoMap.get("PROMOREDEEM")).compareTo(
                            response.getNextCyclePaymentAdvice().getAtVisibleOfferDetailsList(
                                    0).getAtCredits(0).getRedeemableCredits()) == 0);
        };

        String subscriptionExternalId = "123";

        VisibleChangeServicePromo csp = new VisibleChangeServicePromo();
        csp.setGrantOfferCI(CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT);
        csp.setGrantAmount(BigDecimal.valueOf(5000));
        VisiblePromoExtension pe = new VisiblePromoExtension();
        csp.setAttr(pe);

        // BaseMonthly2PlusMonthly
        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS_CURRENT));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId(subscriptionExternalId);
        requestUp.getNewPromotionListAppender().add(csp);
        requestUp.setIncludePaymentAdvice("Y");

        TestConditions chgUp = new TestConditions() {

            {
                newCi = requestUp.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE_CURRENT;
                paidCycleStartDate = TestUtils.getFirstDateOfCurrentMonth();
            }
        };
        chgUp.promoMap.put("PROMOREDEEM", BigDecimal.valueOf(15));
        pTests.test(requestUp, chgUp);
    }

    @Test
    @Tags({
        @Tag("VER-448"), @Tag("VER-535")
    })
    public void test_getChangeServiceAdvice_When_AddItems_Then_AoP_Has_NewItems(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service.",
            "Service could be BASE2VISIBLE22 or BASE3VISIBLE23 or BASE3VISIBLE23A"
        };
        td.when = new String[] {
            "Change to PLUS3VIS23WB", "New addons to be added.",
            "Addon could be CD2VISIBLE2023 or CD2VISIBLE2023A.", "IncludePaymentAdvice = Y",
        };
        td.then = new String[] {
            "Advice shows PaymentAdvice with new addon."
        };

        @SuppressWarnings("unchecked")
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            List<String> pciList = new ArrayList<String>();
            request.setDiscountPrice(
                    CommonTestHelper.getOfferPrice(request.getNewCatalogItemExternalId()));
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
            BigDecimal expectedRecharge = request.getDiscountPrice();
            for (String offerName : tCase.addOfferList) {
                VisibleChangeServiceAddItem csai = new VisibleChangeServiceAddItem();
                csai.setCatalogItemExternalId(offerName);
                csai.setDiscountPrice(
                        CommonTestHelper.getOfferPrice(csai.getCatalogItemExternalId()));
                csai.setGrossPrice(csai.getDiscountPrice().add(BigDecimal.TEN));
                request.getAddItemsAppender().add(csai);
                pciList.add(offerName);
                expectedRecharge = expectedRecharge.add(csai.getDiscountPrice());
            }
            ;
            pciList.add(tCase.oldCi);
            pciList.add(request.getNewCatalogItemExternalId());

            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            emulateMtxResponsePricingCatalogItems(instance, pciList);

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            if (tCase.paidCycleStartDate != null) {
                poExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            }

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getEmptyMtxResponseMulti());

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            doReturn("[" + request.getNewCatalogItemExternalId() + "]").when(
                    instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                    request.getNewCatalogItemExternalId());
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getFirstDateTimeOfNextMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023, BigDecimal.ZERO, null);
            doReturn(purResponseBase).when(instance).getAocCurrencyBalanceImpactInfo(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023)),
                    any(), any());

            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());
            System.out.println(
                    td.getTestMethod() + ":" + aopStage.getRecurringChargeInfo().toJson());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            List<String> actualOfferList = new ArrayList<String>();
            for (VisibleOfferDetails vod : response.getNextCyclePaymentAdvice().getVisibleOfferDetailsList()) {
                actualOfferList.add(vod.getCatalogItemExternalId());
            }
            assertTrue(response.getNextCyclePaymentAdvice() != null);
            assertTrue(
                    actualOfferList.contains(request.getAtAddItems(0).getCatalogItemExternalId()));
            assertEquals(
                    expectedRecharge.doubleValue(),
                    response.getNextCyclePaymentAdvice().getRechargeAmount().doubleValue(), 0.001);
        };

        String subscriptionExternalId = "123";

        VisibleRequestChangeServiceAdvice request01 = new VisibleRequestChangeServiceAdvice();
        request01.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        request01.setSubscriptionExternalId(subscriptionExternalId);
        request01.setIncludePaymentAdvice("Y");
        TestConditions tc01 = new TestConditions() {

            {
                newCi = request01.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE_CURRENT;
                paidCycleStartDate = TestUtils.getFirstDateOfCurrentMonth();
            }
        };
        tc01.addOfferList.add(CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023);
        pTests.test(request01, tc01);

        VisibleRequestChangeServiceAdvice request02 = new VisibleRequestChangeServiceAdvice();
        request02.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PRO_CURRENT);
        request02.setSubscriptionExternalId(subscriptionExternalId);
        request02.setIncludePaymentAdvice("Y");
        TestConditions tc02 = new TestConditions() {

            {
                newCi = request02.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE_CURRENT;
                paidCycleStartDate = TestUtils.getFirstDateOfCurrentMonth();
            }
        };
        tc02.addOfferList.add(CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023);
        pTests.test(request02, tc02);
    }

    @Test
    @Tags({
        @Tag("VER-448"), @Tag("VER-535")
    })
    public void test_getChangeServiceAdvice_When_CancelItems_No_Then_AoP_Has_Items_Not_In_AoP(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service.",
            "Service could be PLUS3VIS23WB or PLUS3VIS23WBA"
        };
        td.when = new String[] {
            "Change to BASE3VISIBLE23 or BASE3VISIBLE23A", "Existing addons to be cancelled.",
            "Addon could be CD3VISIBLE2023 or CD2VISIBLE2023 or CD3VISIBLE2023A.",
            "IncludePaymentAdvice = Y",
        };
        td.then = new String[] {
            "Advice shows PaymentAdvice with new addon."
        };

        @SuppressWarnings("unchecked")
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            subscriptionResponse.getBillingCycle().setDateOffset(1L);
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);

            List<String> pciList = new ArrayList<String>();
            request.setDiscountPrice(
                    CommonTestHelper.getOfferPrice(request.getNewCatalogItemExternalId()));
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
            BigDecimal expectedRecharge = request.getDiscountPrice();
            for (String offerName : tCase.cancelOfferList) {
                VisibleChangeServiceCancelItem csci = new VisibleChangeServiceCancelItem();
                csci.setCatalogItemExternalId(offerName);
                request.getCancelItemsAppender().add(csci);
                pciList.add(offerName);
                PurchasedOfferInfo poiAddon = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                        subscriptionResponse, offerName);
                CommonTestHelper.getMtxPurchasedOfferInfo(subscription, offerName);
                if (tCase.conditionMap.get("RESOURCEID") != null
                        && "Y".equalsIgnoreCase((String) tCase.conditionMap.get("RESOURCEID"))) {
                    csci.setResourceId(poiAddon.getResourceId());
                }
            }
            ;
            pciList.add(tCase.oldCi);
            pciList.add(request.getNewCatalogItemExternalId());

            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
            BigDecimal mainbalance = BigDecimal.ZERO;
            emulateMtxResponsePricingCatalogItems(instance, pciList);

            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            if (tCase.paidCycleStartDate != null) {
                poExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            }

            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getEmptyMtxResponseMulti());

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            doReturn("[" + request.getNewCatalogItemExternalId() + "]").when(
                    instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                    request.getNewCatalogItemExternalId());
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getFirstDateTimeOfNextMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            System.out.println(td.getTestMethod() + ":" + subscription.toJson());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            List<String> actualOfferList = new ArrayList<String>();
            for (VisibleOfferDetails vod : response.getNextCyclePaymentAdvice().getVisibleOfferDetailsList()) {
                actualOfferList.add(vod.getCatalogItemExternalId());
            }
            assertTrue(response.getNextCyclePaymentAdvice() != null);
            assertFalse(
                    actualOfferList.contains(
                            request.getAtCancelItems(0).getCatalogItemExternalId()));
            assertEquals(
                    expectedRecharge.doubleValue(),
                    response.getNextCyclePaymentAdvice().getRechargeAmount().doubleValue(), 0.001);
        };

        String subscriptionExternalId = "123";

        VisibleRequestChangeServiceAdvice request01 = new VisibleRequestChangeServiceAdvice();
        request01.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.BASE_CURRENT);
        request01.setSubscriptionExternalId(subscriptionExternalId);
        request01.setIncludePaymentAdvice("Y");
        TestConditions tc01 = new TestConditions() {

            {
                newCi = request01.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.PLUS_CURRENT;
                paidCycleStartDate = TestUtils.getFirstDateOfCurrentMonth();
            }
        };
        tc01.cancelOfferList.add(CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023);
        tc01.conditionMap.put("RESOURCEID", "N");
        pTests.test(request01, tc01);

        VisibleRequestChangeServiceAdvice request02 = new VisibleRequestChangeServiceAdvice();
        request02.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.BASE_CURRENT);
        request02.setSubscriptionExternalId(subscriptionExternalId);
        request02.setIncludePaymentAdvice("Y");
        TestConditions tc02 = new TestConditions() {

            {
                newCi = request02.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.PLUS_CURRENT;
                paidCycleStartDate = TestUtils.getFirstDateOfCurrentMonth();
            }
        };
        tc02.cancelOfferList.add(CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023);
        tc02.conditionMap.put("RESOURCEID", "Y");
        pTests.test(request02, tc02);
    }

    @Test
    @Tags({
        @Tag("VER-448"), @Tag("VER-535"), @Tag("MTXVER2TMA-4558")
    })
    public void test_getChangeServiceAdvice_When_Add_ZeroDollarWearable_and_Has_mainbalance_Then_Correct_PayableForWearable(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service.", "has Wearable", "has lot of mainbalance"
        };
        td.when = new String[] {
            "Change to PLUS3VIS23WB", "New zero dollar addon to be added.",
            "Existing addons to be cancelled.",
        };
        td.then = new String[] {
            "Advice shows PaymentAdvice with new addon and drops old ones.",
            "Payable Amounts in ZeroDollar wearable are zero."
        };

        @SuppressWarnings("unchecked")
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            List<String> pciList = new ArrayList<String>();
            request.setDiscountPrice(
                    CommonTestHelper.getOfferPrice(request.getNewCatalogItemExternalId()));
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
            BigDecimal expectedRecharge = request.getDiscountPrice();

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            subscription.getPurchasedOfferArrayAppender().clear();

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);

            for (String offerName : tCase.addOfferList) {
                VisibleChangeServiceAddItem csai = new VisibleChangeServiceAddItem();
                csai.setCatalogItemExternalId(offerName);
                csai.setDiscountPrice(
                        CommonTestHelper.getOfferPrice(csai.getCatalogItemExternalId()));
                csai.setGrossPrice(csai.getDiscountPrice().add(BigDecimal.TEN));
                request.getAddItemsAppender().add(csai);
                pciList.add(offerName);
                expectedRecharge = expectedRecharge.add(csai.getDiscountPrice());
            }
            ;
            for (String offerName : tCase.cancelOfferList) {
                VisibleChangeServiceCancelItem csci = new VisibleChangeServiceCancelItem();
                csci.setCatalogItemExternalId(offerName);
                request.getCancelItemsAppender().add(csci);
                pciList.add(offerName);
                PurchasedOfferInfo poiAddon = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                        subscriptionResponse, offerName);
                CommonTestHelper.getMtxPurchasedOfferInfo(subscription, offerName);
                if (tCase.conditionMap.get("RESOURCEID") != null
                        && "Y".equalsIgnoreCase((String) tCase.conditionMap.get("RESOURCEID"))) {
                    csci.setResourceId(poiAddon.getResourceId());
                }
            }
            ;

            pciList.add(tCase.oldCi);
            pciList.add(request.getNewCatalogItemExternalId());

            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.valueOf(80);
            emulateMtxResponsePricingCatalogItems(instance, pciList);

            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            if (tCase.paidCycleStartDate != null) {
                poExtn.setPaidCycleStartDate(tCase.paidCycleStartDate);
            }

            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getEmptyMtxResponseMulti());

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.setPaidCycleStartDate(poExtn.getPaidCycleStartDate());
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            doReturn("[" + request.getNewCatalogItemExternalId() + "]").when(
                    instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                    request.getNewCatalogItemExternalId());
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getFirstDateTimeOfNextMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, poExtn.getPaidCycleStartDate());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION, BigDecimal.ZERO, null);
            doReturn(purResponseBase).when(instance).getAocCurrencyBalanceImpactInfo(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION)),
                    any(), any());

            System.out.println(td.getTestMethod() + ":" + subscriptionResponse.toJson());
            System.out.println(
                    td.getTestMethod() + ":" + aopStage.getRecurringChargeInfo().toJson());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            List<String> actualOfferList = new ArrayList<String>();
            VisibleOfferDetails addOnVod = null;
            for (VisibleOfferDetails vod : response.getNextCyclePaymentAdvice().getVisibleOfferDetailsList()) {
                actualOfferList.add(vod.getCatalogItemExternalId());
                if (request.getAtAddItems(0).getCatalogItemExternalId().equalsIgnoreCase(
                        vod.getCatalogItemExternalId())) {
                    addOnVod = vod;
                }
            }
            assertTrue(response.getNextCyclePaymentAdvice() != null);
            assertTrue(
                    actualOfferList.contains(request.getAtAddItems(0).getCatalogItemExternalId()));
            assertFalse(
                    actualOfferList.contains(
                            request.getAtCancelItems(0).getCatalogItemExternalId()));
            assertEquals(0, addOnVod.getPayableAmount().doubleValue());
        };

        String subscriptionExternalId = "123";

        VisibleRequestChangeServiceAdvice request01 = new VisibleRequestChangeServiceAdvice();
        request01.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3VIS23WB);
        request01.setSubscriptionExternalId(subscriptionExternalId);
        request01.setIncludePaymentAdvice("Y");
        TestConditions tc01 = new TestConditions() {

            {
                newCi = request01.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE3VIS23;
                paidCycleStartDate = TestUtils.getFirstDateOfCurrentMonth();
            }
        };
        tc01.addOfferList.add(CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION);
        tc01.cancelOfferList.add(CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023);
        pTests.test(request01, tc01);
    }

    @Test
    @Tags({
        @Tag("VER-545"), @Tag("Timezone")
    })
    public void test_getChangeServiceAdvice_When_SubsciptionTZPlus12_SystemTZBeforePlus12_ChangeOnSameDay_Then_NoError(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service.(BASE3VISIBLE23)",
            "Base service was purchased few minutes ago."
        };
        td.when = new String[] {
            "Change to BASE3VISIBLE23A"
        };
        td.then = new String[] {
            "Advice should be provided without error."
        };
        td.comments = new String[] {
            "Assume Auckland is sub's timezone.",
            "Let sub's offers start 1 min ago. If timezone is ignored this time is in future for most of the timezones.",
            "Make sure change service advice completes successfully.",
            "This proves that time to decide an offer to be active is as per sub's timezone and not system timezone."
        };
        @SuppressWarnings("unchecked")
        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            request.setDiscountPrice(
                    CommonTestHelper.getOfferPrice(request.getNewCatalogItemExternalId()));
            request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));

            String subtimeZoneString = "Pacific/Auckland";
            MtxTimestamp nowInAuckland = CommonUtils.getCurrentTimeInZone(subtimeZoneString);
            MtxTimestamp agoInAuckland = nowInAuckland.minusMilli(60000);
            MtxTimestamp offerStartTime = agoInAuckland;

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription(
                            request.getSubscriptionExternalId(), Arrays.asList(tCase.oldCi)));
            subscription.setTimeZone(subtimeZoneString);
            MtxPurchasedOfferInfo mpoiEnrolled = subscription.getAtPurchasedOfferArray(0);
            mpoiEnrolled.setPurchaseTime(offerStartTime);
            mpoiEnrolled.setStartTime(offerStartTime);
            mpoiEnrolled.setCurrentStatusTransitionTime(offerStartTime);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            request.getSubscriptionExternalId(), Arrays.asList(tCase.oldCi)));
            subscriptionResponse.setTimeZone(subtimeZoneString);

            MtxPurchasedOfferInfo poiEnrolled = subscriptionResponse.getAtPurchasedOfferArray(0);
            poiEnrolled.setPurchaseTime(offerStartTime);
            poiEnrolled.setStartTime(offerStartTime);
            poiEnrolled.setCurrentStatusTransitionTime(offerStartTime);
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(tCase.oldCi, request.getNewCatalogItemExternalId()));
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getEmptyMtxResponseMulti());

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();

            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) subscription.getAtPurchasedOfferArray(
                    0).getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            emulateMtxResponseWallet(
                    instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));

            doReturn("[" + request.getNewCatalogItemExternalId() + "]").when(
                    instance).getLoggingKey(any());

            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                    request.getNewCatalogItemExternalId());
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getFirstDateTimeOfNextMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, enrolledExtnSub.getPaidCycleStartDate());

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            MtxResponsePurchase purResponseBase = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION, BigDecimal.ZERO, null);
            doReturn(purResponseBase).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION)),
                    any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson()).thenReturn(taxRespNextCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }
            assertEquals(RESULT_CODES.MTX_SUCCESS, response.getResult());
        };

        String subscriptionExternalId = "123";

        VisibleRequestChangeServiceAdvice request01 = new VisibleRequestChangeServiceAdvice();
        request01.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS3VIS23WB);
        request01.setSubscriptionExternalId(subscriptionExternalId);
        TestConditions tc01 = new TestConditions() {

            {
                newCi = request01.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE3VIS23;
            }
        };
        pTests.test(request01, tc01);
    }

    @Test
    @Tag("VER-367")
    public void test_getChangeServiceAdvice_When_IncludePaymentAdvice_And_ChangeToMonthly_MailbalanceAvailable_Then_CorrectMainBalanceAmounts(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has active base service."
        };
        td.when = new String[] {
            "Api is called with target monthly service.", "IncludePaymentAdvice = Y",
            "Subscriber has some mainbalance."
        };
        td.then = new String[] {
            "Advice should include PaymentAdvice for next service with mainbalance that is not used by change cycle."
        };
        td.comments = new String[] {
            "VER-367"
        };
    }
}
