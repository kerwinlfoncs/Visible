package com.matrixx.vag.gift.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixx.datacontainer.mdc.*;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.common.Constants.MATRIXX_CONSTANTS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestUtils;
import com.matrixx.vag.exception.GiftServiceException;
import com.matrixx.vag.exception.InvalidRequestException;
import com.matrixx.vag.subscriber.service.GiftService;
import com.matrixx.vag.tax.model.ServiceTaxResponse;
import com.matrixx.vag.util.MDCTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;

public class GiftServiceTest extends MDCTest {

    @Spy
    @InjectMocks
    private GiftService instance = new GiftService();

    private TestInfo testInfo;

    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        instance = new GiftService();
        MockitoAnnotations.openMocks(this);
        doReturn("").when(instance).getRoute(any());
        this.testInfo = testInfo;
    }

    @ParameterizedTest(name = "test_giftSubscriber_When_LowMainbalance_Then_Error")
    @Tag("VER-635")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Gifter has recharge event with tax."
                +"|      |Has mainbalance less than discount price in tax.|"
                +"|      |Has no promotions.|"
                +"|When  |Api is called.|"
                +"|Then  |Error.|"
                +"|Comments|This should be tested against request validator.|"})
    // @formatter:on
    public void test_giftSubscriber_When_LowMainbalance_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestGiftService request = CommonTestHelper.getVisibleRequestGiftService(
                "2024090321320", "Gifter Xyz","gifter@gift.com", "2024090321321", CI_EXTERNAL_IDS.PLUS3ANNUAL, "12345");
        System.out.println("request:" + request.toJson());
        VisibleGiftServiceResponse response = new VisibleGiftServiceResponse();

        SubscriptionResponse gifterSubscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse(
                request.getGifterExternalId());
        System.out.println("gifterSubscriptionResponse:" + gifterSubscriptionResponse.toJson());
        SubscriptionResponse gifteeSubscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                request.getGifteeExternalId(), List.of(CI_EXTERNAL_IDS.SETUP_SERVICES));
                
        MtxRechargeEvent gifterRech = CommonTestHelper.getGifterRechargeEvent(
                request.getGifterExternalId(),
                request.getGiftingServiceInfo().getCatalogItemExternalId());
        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEventQueryResponseEvents();
        gifterEvents.getAtEventList(0).setEventDetails(gifterRech);
        VisibleRechargeExtension extn = (VisibleRechargeExtension)gifterRech.getRechargeAttr();
        extn.setGiftTaxDetails("Not a Json");
        System.out.println("gifterRech:" + gifterRech.getRechargeAttr().toJson());
        
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        doReturn(gifterEvents).when(instance).queryRechargeEvents(
                eq(request.getGifterExternalId()));
        doReturn(gifterSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifterExternalId()));
        doReturn(gifteeSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifteeExternalId()));
        doReturn(multiRes).when(instance).multiRequest(any(), any(), any());

        Exception exception = assertThrows(GiftServiceException.class, () ->  instance.giftSubscriber(request, response));
        exception.printStackTrace();
        assertEquals("Tax details is in incorrect json format", exception.getMessage());
    }

    @ParameterizedTest(name = "test_giftSubscriber_When_InvalidTax_Then_Error")
    @Tag("VER-635")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Gifter has recharge event with tax."
                +"|      |Tax is not valid json.|"
                +"|When  |Api is called.|"
                +"|Then  |Error.|"
                +"|Comments|This should be tested against request validator.|"})
    // @formatter:on
    public void test_giftSubscriber_When_InvalidTax_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestGiftService request = CommonTestHelper.getVisibleRequestGiftService(
                "2024090321320", "Gifter Xyz","gifter@gift.com", "2024090321321", CI_EXTERNAL_IDS.PLUS3ANNUAL, "12345");
        System.out.println("request:" + request.toJson());
        VisibleGiftServiceResponse response = new VisibleGiftServiceResponse();

        SubscriptionResponse gifterSubscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse(
                request.getGifterExternalId());
        SubscriptionResponse gifteeSubscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                request.getGifteeExternalId(), List.of(CI_EXTERNAL_IDS.SETUP_SERVICES));
                
        MtxRechargeEvent gifterRech = CommonTestHelper.getGifterRechargeEvent(
                request.getGifterExternalId(),
                request.getGiftingServiceInfo().getCatalogItemExternalId());
        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEventQueryResponseEvents();
        gifterEvents.getAtEventList(0).setEventDetails(gifterRech);
        VisibleRechargeExtension extn = (VisibleRechargeExtension)gifterRech.getRechargeAttr();
        extn.setGiftTaxDetails("Not a Json");
        System.out.println("gifterRech:" + gifterRech.getRechargeAttr().toJson());
        
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        doReturn(gifterEvents).when(instance).queryRechargeEvents(
                eq(request.getGifterExternalId()));
        doReturn(gifterSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifterExternalId()));
        doReturn(gifteeSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifteeExternalId()));
        doReturn(multiRes).when(instance).multiRequest(any(), any(), any());

        Exception exception = assertThrows(GiftServiceException.class, () ->  instance.giftSubscriber(request, response));
        exception.printStackTrace();
        assertEquals("Tax details is in incorrect json format", exception.getMessage());
    }

    @ParameterizedTest(name = "test_giftSubscriber_When_Giftee_No_SetupServices_Then_Error")
    @Tag("VER-635")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Giftee has no setup services."
                +"|When  |Api is called.|"
                +"|Then  |Error.|"
                +"|Comments|This should be tested against request validator.|"})
    // @formatter:on
    public void test_giftSubscriber_When_Giftee_No_SetupServices_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestGiftService request = CommonTestHelper.getVisibleRequestGiftService(
                "2024090321320", "Gifter Xyz","gifter@gift.com", "2024090321321", CI_EXTERNAL_IDS.PLUS3ANNUAL, "12345");
        System.out.println("request:" + request.toJson());
        VisibleGiftServiceResponse response = new VisibleGiftServiceResponse();

        SubscriptionResponse gifterSubscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse(
                request.getGifterExternalId());
        SubscriptionResponse gifteeSubscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse(
                request.getGifteeExternalId());

        System.out.println("gifteeSubscriptionResponse:" + gifteeSubscriptionResponse.toJson());
        
        MtxRechargeEvent gifterRech = CommonTestHelper.getGifterRechargeEvent(
                request.getGifterExternalId(),
                request.getGiftingServiceInfo().getCatalogItemExternalId());
        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEventQueryResponseEvents();
        gifterEvents.getAtEventList(0).setEventDetails(gifterRech);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        doReturn(gifterEvents).when(instance).queryRechargeEvents(
                eq(request.getGifterExternalId()));
        doReturn(gifterSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifterExternalId()));
        doReturn(gifteeSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifteeExternalId()));
        doReturn(multiRes).when(instance).multiRequest(any(), any(), any());

        Exception exception = assertThrows(InvalidRequestException.class, () ->  instance.giftSubscriber(request, response));
        exception.printStackTrace();
        assertEquals("Giftee does not have Set up Services", exception.getMessage());
    }

    @ParameterizedTest(name = "test_giftSubscriber_When_Giftee_No_Mainbalance_Then_Error")
    @Tag("VER-635")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Giftee has no mainbalance."
                +"|When  |Api is called.|"
                +"|Then  |Error.|"
                +"|Comments|This should be tested against request validator.|"})
    // @formatter:on
    public void test_giftSubscriber_When_Giftee_No_Mainbalance_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestGiftService request = CommonTestHelper.getVisibleRequestGiftService(
                "2024090321320", "Gifter Xyz","gifter@gift.com", "2024090321321", CI_EXTERNAL_IDS.PLUS3ANNUAL, "12345");
        System.out.println("request:" + request.toJson());
        VisibleGiftServiceResponse response = new VisibleGiftServiceResponse();

        SubscriptionResponse gifterSubscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse(
                request.getGifterExternalId());
        SubscriptionResponse gifteeSubscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                request.getGifteeExternalId(), List.of(CI_EXTERNAL_IDS.SETUP_SERVICES));

        gifteeSubscriptionResponse.getBalanceArrayAppender().clear();
        gifteeSubscriptionResponse.getWalletBalancesAppender().clear();
        
        System.out.println("gifteeSubscriptionResponse:" + gifteeSubscriptionResponse.toJson());
        
        MtxRechargeEvent gifterRech = CommonTestHelper.getGifterRechargeEvent(
                request.getGifterExternalId(),
                request.getGiftingServiceInfo().getCatalogItemExternalId());
        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEventQueryResponseEvents();
        gifterEvents.getAtEventList(0).setEventDetails(gifterRech);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        doReturn(gifterEvents).when(instance).queryRechargeEvents(
                eq(request.getGifterExternalId()));
        doReturn(gifterSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifterExternalId()));
        doReturn(gifteeSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifteeExternalId()));
        doReturn(multiRes).when(instance).multiRequest(any(), any(), any());

        Exception exception = assertThrows(InvalidRequestException.class, () ->  instance.giftSubscriber(request, response));
        exception.printStackTrace();
        assertEquals("Giftee does not have Wallet Balances ", exception.getMessage());
    }

    @ParameterizedTest(name = "test_giftSubscriber_When_Giftee_No_BillCycle_Then_Error")
    @Tag("VER-635")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Giftee has no  bill cycle setup."
                +"|When  |Api is called.|"
                +"|Then  |Error.|"
                +"|Comments|This should be tested against request validator.|"})
    // @formatter:on
    public void test_giftSubscriber_When_Giftee_No_BillCycle_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestGiftService request = CommonTestHelper.getVisibleRequestGiftService(
                "2024090321320", "Gifter Xyz","gifter@gift.com", "2024090321321", CI_EXTERNAL_IDS.PLUS3ANNUAL, "12345");
        System.out.println("request:" + request.toJson());
        VisibleGiftServiceResponse response = new VisibleGiftServiceResponse();

        SubscriptionResponse gifterSubscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse(
                request.getGifterExternalId());
        SubscriptionResponse gifteeSubscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                request.getGifteeExternalId(), List.of(CI_EXTERNAL_IDS.SETUP_SERVICES));
        gifteeSubscriptionResponse.setBillingCycle((MtxBillingCycleInfo)null);
        System.out.println("gifteeSubscriptionResponse:" + gifteeSubscriptionResponse.toJson());
        
        MtxRechargeEvent gifterRech = CommonTestHelper.getGifterRechargeEvent(
                request.getGifterExternalId(),
                request.getGiftingServiceInfo().getCatalogItemExternalId());
        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEventQueryResponseEvents();
        gifterEvents.getAtEventList(0).setEventDetails(gifterRech);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        doReturn(gifterEvents).when(instance).queryRechargeEvents(
                eq(request.getGifterExternalId()));
        doReturn(gifterSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifterExternalId()));
        doReturn(gifteeSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifteeExternalId()));
        doReturn(multiRes).when(instance).multiRequest(any(), any(), any());

        Exception exception = assertThrows(InvalidRequestException.class, () ->  instance.giftSubscriber(request, response));
        exception.printStackTrace();
        assertEquals("Giftee does not have bill cycle", exception.getMessage());
    }

    @ParameterizedTest(name = "test_giftSubscriber_When_GifteeHasOtherServices_Then_Error")
    @Tag("VER-635")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Giftee has subscriptions other than setupservice and promos."
                +"|When  |Api is called.|"
                +"|Then  |Error.|"
                +"|Comments|This should be tested against request validator.|"})
    // @formatter:on
    public void test_giftSubscriber_When_GifteeHasOtherServices_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestGiftService request = CommonTestHelper.getVisibleRequestGiftService(
                "2024090321320", "Gifter Xyz","gifter@gift.com", "2024090321321", CI_EXTERNAL_IDS.PLUS3ANNUAL, "12345");
        System.out.println("request:" + request.toJson());
        VisibleGiftServiceResponse response = new VisibleGiftServiceResponse();

        SubscriptionResponse gifterSubscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse(
                request.getGifterExternalId());
        SubscriptionResponse gifteeSubscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                request.getGifteeExternalId(), List.of(CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023, CI_EXTERNAL_IDS.SETUP_SERVICES));
        System.out.println("gifteeSubscriptionResponse:" + gifteeSubscriptionResponse.toJson());
        
        MtxRechargeEvent gifterRech = CommonTestHelper.getGifterRechargeEvent(
                request.getGifterExternalId(),
                request.getGiftingServiceInfo().getCatalogItemExternalId());
        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEventQueryResponseEvents();
        gifterEvents.getAtEventList(0).setEventDetails(gifterRech);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        doReturn(gifterEvents).when(instance).queryRechargeEvents(
                eq(request.getGifterExternalId()));
        doReturn(gifterSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifterExternalId()));
        doReturn(gifteeSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifteeExternalId()));
        doReturn(multiRes).when(instance).multiRequest(any(), any(), any());

        Exception exception = assertThrows(GiftServiceException.class, () ->  instance.giftSubscriber(request, response));
        exception.printStackTrace();
        assertEquals("Giftee is an active subscriber", exception.getMessage());
    }

    @ParameterizedTest(name = "test_giftSubscriber_When_GifteeHasNoGeoCode_Then_Error")
    @Tag("VER-635")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Gifter has recharge event with tax. Has mainbalance matching recharge event.|"
                +"|      |Giftee has no geocode.|"
                +"|When  |Api is called.|"
                +"|Then  |Error.|"
                +"|Comments|This should be tested against request validator.|"})
    // @formatter:on
    public void test_giftSubscriber_When_GifteeHasNoGeoCode_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestGiftService request = CommonTestHelper.getVisibleRequestGiftService(
                "2024090321320", "Gifter Xyz","gifter@gift.com", "2024090321321", CI_EXTERNAL_IDS.PLUS3ANNUAL, "12345");
        System.out.println("request:" + request.toJson());
        VisibleGiftServiceResponse response = new VisibleGiftServiceResponse();

        SubscriptionResponse gifterSubscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse(
                request.getGifterExternalId());
        SubscriptionResponse gifteeSubscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse(
                request.getGifteeExternalId());
        gifteeSubscriptionResponse.setGlCenter(null);
        VisibleSubscriberExtension extn = (VisibleSubscriberExtension)gifteeSubscriptionResponse.getAttr();
        extn.setGeoCode(null);
        System.out.println("gifteeSubscriptionResponse:" + gifteeSubscriptionResponse.toJson());
        
        MtxRechargeEvent gifterRech = CommonTestHelper.getGifterRechargeEvent(
                request.getGifterExternalId(),
                request.getGiftingServiceInfo().getCatalogItemExternalId());
        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEventQueryResponseEvents();
        gifterEvents.getAtEventList(0).setEventDetails(gifterRech);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        doReturn(gifterEvents).when(instance).queryRechargeEvents(
                eq(request.getGifterExternalId()));
        doReturn(gifterSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifterExternalId()));
        doReturn(gifteeSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifteeExternalId()));
        doReturn(multiRes).when(instance).multiRequest(any(), any(), any());

        Exception exception = assertThrows(InvalidRequestException.class, () ->  instance.giftSubscriber(request, response));
        exception.printStackTrace();
        System.out.println(td.getTestMethod() + ": response:" + response.toJson());
    }

    @ParameterizedTest(name = "test_giftSubscriber_When_MultirequestSuccess_Then_Success")
    @Tag("VER-635")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Gifter has recharged. Giftee has setupservices.|"
                +"|When  |Api is called. Subman api calls are successful.|"
                +"|Then  |Api responds with correct values.|"})
    // @formatter:on
    public void test_giftSubscriber_When_MultirequestSuccess_Then_Success(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestGiftService request = CommonTestHelper.getVisibleRequestGiftService(
                "2024090321320", "Gifter Xyz","gifter@gift.com", "2024090321321", CI_EXTERNAL_IDS.PLUS3ANNUAL, "12345");
        System.out.println("request:" + request.toJson());
        VisibleGiftServiceResponse response = new VisibleGiftServiceResponse();

        SubscriptionResponse gifterSubscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse(
                request.getGifterExternalId());
        SubscriptionResponse gifteeSubscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                request.getGifteeExternalId(), List.of(CI_EXTERNAL_IDS.SETUP_SERVICES));

        MtxRechargeEvent gifterRech = CommonTestHelper.getGifterRechargeEvent(
                request.getGifterExternalId(),
                request.getGiftingServiceInfo().getCatalogItemExternalId());
        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEventQueryResponseEvents();
        gifterEvents.getAtEventList(0).setEventDetails(gifterRech);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingCatalogItem pci = CommonTestHelper.getMtxResponsePricingCatalogItem(
                CI_EXTERNAL_IDS.PLUS3ANNUAL);
        emulateMtxResponsePricingCatalogItem(instance, pci, CI_EXTERNAL_IDS.PLUS3ANNUAL);
        doReturn(gifterEvents).when(instance).queryRechargeEvents(
                eq(request.getGifterExternalId()));
        doReturn(gifterSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifterExternalId()));
        doReturn(gifteeSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifteeExternalId()));
        doReturn(multiRes).when(instance).multiRequest(any(), any(), any());
        
        instance.giftSubscriber(request, response);
        System.out.println(td.getTestMethod() + ": response:" + response.toJson());
        assertEquals(request.getGifterExternalId(), response.getGifterExternalId());
        assertEquals(request.getGifteeExternalId(), response.getGifteeExternalId());
        assertEquals(
                CommonTestHelper.getOfferPrice(
                        request.getGiftingServiceInfo().getCatalogItemExternalId()),
                response.getGiftAmount());
        assertEquals(RESULT_CODES.MTX_SUCCESS, response.getResult());
        assertEquals(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS, response.getResultText());
    }

    @ParameterizedTest(
            name = "test_giftSubscriber_When_MultiRequestSuccess_InCaseOfPromotions_Then_Success")
    @Tag("VER-635")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
            "|Given |Gifter has recharged. Giftee has setupservices. Gifter has promotions|"
           +"|When  |Api is called. Subman api calls are successful.|"
           +"|Then  |Api responds with correct values.|"})
    // @formatter:on
    public void test_giftSubscriber_When_MultiRequestSuccess_InCaseOfPromotions_Then_Success(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String gifterPromoExternaID = CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT;
        BigDecimal gifterPromoAmount = BigDecimal.valueOf(50);
        VisibleRequestGiftService request = CommonTestHelper.getVisibleRequestGiftService(
                "2024090321320", "Gifter Xyz", "gifter@gift.com", "2024090321321",
                CI_EXTERNAL_IDS.PLUS3ANNUAL, "12345");
        System.out.println("request:" + request.toJson());
        VisibleGiftServiceResponse response = new VisibleGiftServiceResponse();

        SubscriptionResponse gifterSubscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse(
                request.getGifterExternalId());
        SubscriptionResponse gifteeSubscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                request.getGifteeExternalId(), List.of(CI_EXTERNAL_IDS.SETUP_SERVICES));

        MtxRechargeEvent gifterRech = CommonTestHelper.getGifterRechargeEvent(
                request.getGifterExternalId(),
                request.getGiftingServiceInfo().getCatalogItemExternalId(), gifterPromoExternaID, gifterPromoAmount);
        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEventQueryResponseEvents();
        gifterEvents.getAtEventList(0).setEventDetails(gifterRech);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingCatalogItem pci = CommonTestHelper.getMtxResponsePricingCatalogItem(
                CI_EXTERNAL_IDS.PLUS3ANNUAL);
        emulateMtxResponsePricingCatalogItem(instance, pci, CI_EXTERNAL_IDS.PLUS3ANNUAL);
        MtxResponsePurchase basePurchase = CommonTestHelper.getMtxResponsePurchase(
                request.getGiftingServiceInfo().getCatalogItemExternalId(),
                CommonTestHelper.getOfferPrice(
                        request.getGiftingServiceInfo().getCatalogItemExternalId()));
        multiRes.getResponseListAppender().add(basePurchase);

        doReturn(gifterEvents).when(instance).queryRechargeEvents(
                eq(request.getGifterExternalId()));
        doReturn(gifterSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifterExternalId()));
        doReturn(gifteeSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifteeExternalId()));
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        instance.giftSubscriber(request, response);
        System.out.println(td.getTestMethod() + ": response:" + response.toJson());
        assertEquals(request.getGifterExternalId(), response.getGifterExternalId());
        assertEquals(request.getGifteeExternalId(), response.getGifteeExternalId());
        BigDecimal expectedGiftAmount = CommonTestHelper.getOfferPrice(
                request.getGiftingServiceInfo().getCatalogItemExternalId()).subtract(gifterPromoAmount); 
        assertEquals(expectedGiftAmount.intValue(),
                response.getGiftAmount().intValue());
        assertEquals(RESULT_CODES.MTX_SUCCESS, response.getResult());
        assertEquals(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS, response.getResultText());
    }

    @ParameterizedTest(name = "test_giftSubscriber_When_Valid_GG_Pair_Then_CorrectMultirequest")
    @Tag("VER-635")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Gifter has recharge event with tax. Has mainbalance matching recharge event.|"
                +"|      |Giftee has setupservices.|"
                +"|When  |Api is called.|"
                +"|Then  |Multirequest in subman call has correct order of individual requests.|"})
    // @formatter:on
    public void test_giftSubscriber_When_Valid_GG_Pair_Then_CorrectMultirequest(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestGiftService request = CommonTestHelper.getVisibleRequestGiftService(
                "2024090321320", "Gifter Xyz","gifter@gift.com", "2024090321321", CI_EXTERNAL_IDS.PLUS3ANNUAL, "12345");
        System.out.println("request:" + request.toJson());
        VisibleGiftServiceResponse response = new VisibleGiftServiceResponse();

        SubscriptionResponse gifterSubscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse(
                request.getGifterExternalId());
        SubscriptionResponse gifteeSubscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                request.getGifteeExternalId(), List.of(CI_EXTERNAL_IDS.SETUP_SERVICES));

        MtxRechargeEvent gifterRech = CommonTestHelper.getGifterRechargeEvent(
                request.getGifterExternalId(),
                request.getGiftingServiceInfo().getCatalogItemExternalId());
        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEventQueryResponseEvents();
        gifterEvents.getAtEventList(0).setEventDetails(gifterRech);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingCatalogItem pci = CommonTestHelper.getMtxResponsePricingCatalogItem(
                CI_EXTERNAL_IDS.PLUS3ANNUAL);
        emulateMtxResponsePricingCatalogItem(instance, pci, CI_EXTERNAL_IDS.PLUS3ANNUAL);
        doReturn(gifterEvents).when(instance).queryRechargeEvents(
                eq(request.getGifterExternalId()));
        doReturn(gifterSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifterExternalId()));
        doReturn(gifteeSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifteeExternalId()));
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
        
        instance.giftSubscriber(request, response);
        System.out.println(td.getTestMethod() + ": response:" + response.toJson());
        argumentCaptor.getAllValues().forEach(multiReq -> {
            System.out.println(td.getTestMethod() + ": MultiRequest:" + multiReq.toJson());
        });
        Iterator<MtxRequest> itr = argumentCaptor.getValue().getRequestList().iterator();

        assertEquals(
                MtxRequestSubscriptionModify.class.getSimpleName(), itr.next().getMdcName());
        assertEquals(
                MtxRequestSubscriberTransferBalance.class.getSimpleName(), itr.next().getMdcName());
        assertEquals(
                MtxRequestSubscriberPurchaseOffer.class.getSimpleName(), itr.next().getMdcName());
    }

    @ParameterizedTest(name = "test_giftSubscriber_When_Valid_GG_Pair_Then_CorrectBalancetransferRequest")
    @Tag("VER-635")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Gifter has recharge event with tax. Has mainbalance matching recharge event.|"
                +"|      |Giftee has setupservices.|"
                +"|When  |Api is called.|"
                +"|Then  |Subman call is made to transfer balance from gifter to giftee.|"})
    // @formatter:on
    public void test_giftSubscriber_When_Valid_GG_Pair_Then_CorrectBalancetransferRequest(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestGiftService request = CommonTestHelper.getVisibleRequestGiftService(
                "2024090321320", "Gifter Xyz","gifter@gift.com", "2024090321321", CI_EXTERNAL_IDS.PLUS3ANNUAL, "12345");
        System.out.println("request:" + request.toJson());
        VisibleGiftServiceResponse response = new VisibleGiftServiceResponse();

        SubscriptionResponse gifterSubscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse(
                request.getGifterExternalId());
        SubscriptionResponse gifteeSubscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                request.getGifteeExternalId(), List.of(CI_EXTERNAL_IDS.SETUP_SERVICES));

        MtxRechargeEvent gifterRech = CommonTestHelper.getGifterRechargeEvent(
                request.getGifterExternalId(),
                request.getGiftingServiceInfo().getCatalogItemExternalId());
        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEventQueryResponseEvents();
        gifterEvents.getAtEventList(0).setEventDetails(gifterRech);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingCatalogItem pci = CommonTestHelper.getMtxResponsePricingCatalogItem(
                CI_EXTERNAL_IDS.PLUS3ANNUAL);
        emulateMtxResponsePricingCatalogItem(instance, pci, CI_EXTERNAL_IDS.PLUS3ANNUAL);
        doReturn(gifterEvents).when(instance).queryRechargeEvents(
                eq(request.getGifterExternalId()));
        doReturn(gifterSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifterExternalId()));
        doReturn(gifteeSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifteeExternalId()));
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
        
        instance.giftSubscriber(request, response);
        System.out.println(td.getTestMethod() + ": response:" + response.toJson());
        argumentCaptor.getAllValues().forEach(multiReq -> {
            System.out.println(td.getTestMethod() + ": MultiRequest:" + multiReq.toJson());
        });
        MtxRequestSubscriberTransferBalance req = new MtxRequestSubscriberTransferBalance(
                argumentCaptor.getValue().getAtRequestList(1));
        
        long expectedGifterBalanceResourceId = gifterSubscriptionResponse.getAtWalletBalances(0).getResourceId();
        long expectedGifteeBalanceResourceId = gifteeSubscriptionResponse.getAtWalletBalances(0).getResourceId();
        assertEquals(expectedGifterBalanceResourceId, req.getBalanceResourceId());
        assertEquals(expectedGifteeBalanceResourceId, req.getTargetBalanceResourceId());
        assertEquals(request.getGifterExternalId(), req.getSubscriberSearchData().getExternalId());
        assertEquals(
                request.getGifteeExternalId(), req.getTargetSubscriberSearchData().getExternalId());
        assertEquals(
                CommonTestHelper.getOfferPrice(
                        request.getGiftingServiceInfo().getCatalogItemExternalId()).intValue(),
                req.getAmount().intValue());
        assertFalse(req.getAmountIsPct());
    }

    @ParameterizedTest(
            name = "test_giftSubscriber_When_Valid_GG_Pair_Then_ActivePurchaseOfferRequest")
    @Tag("VER-635")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Gifter has recharge event with tax. Has mainbalance matching recharge event.|"
                +"|      |Giftee has setupservices.|"
                +"|When  |Api is called.|"
                +"|Then  |Subman call is made to purchase service offer for giftee.|"
                +"|      |purchase request should not set offer status so that offer will be purchased in active state.|"})
    // @formatter:on
    public void test_giftSubscriber_When_Valid_GG_Pair_Then_ActivePurchaseOfferRequest(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestGiftService request = CommonTestHelper.getVisibleRequestGiftService(
                "2024090321320", "Gifter Xyz","gifter@gift.com", "2024090321321", CI_EXTERNAL_IDS.PLUS3ANNUAL, "12345");
        System.out.println("request:" + request.toJson());
        VisibleGiftServiceResponse response = new VisibleGiftServiceResponse();

        SubscriptionResponse gifterSubscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse(
                request.getGifterExternalId());
        SubscriptionResponse gifteeSubscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                request.getGifteeExternalId(), List.of(CI_EXTERNAL_IDS.SETUP_SERVICES));

        MtxRechargeEvent gifterRech = CommonTestHelper.getGifterRechargeEvent(
                request.getGifterExternalId(),
                request.getGiftingServiceInfo().getCatalogItemExternalId());
        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEventQueryResponseEvents();
        gifterEvents.getAtEventList(0).setEventDetails(gifterRech);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingCatalogItem pci = CommonTestHelper.getMtxResponsePricingCatalogItem(
                CI_EXTERNAL_IDS.PLUS3ANNUAL);
        emulateMtxResponsePricingCatalogItem(instance, pci, CI_EXTERNAL_IDS.PLUS3ANNUAL);
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + request.getGifteeExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(gifterEvents).when(instance).queryRechargeEvents(
                eq(request.getGifterExternalId()));
        doReturn(gifterSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifterExternalId()));
        doReturn(gifteeSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifteeExternalId()));
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
        
        instance.giftSubscriber(request, response);
        System.out.println(td.getTestMethod() + ": response:" + response.toJson());
        argumentCaptor.getAllValues().forEach(multiReq -> {
            System.out.println(td.getTestMethod() + ": MultiRequest:" + multiReq.toJson());
        });
        
        MtxRequestSubscriberPurchaseOffer req = new MtxRequestSubscriberPurchaseOffer(
                argumentCaptor.getValue().getAtRequestList(1));
        assertNull(req.getAtOfferRequestArray(0).getPreActiveState());
        assertNull(req.getAtOfferRequestArray(0).getOfferStatusValue());
    }

    @ParameterizedTest(name = "test_giftSubscriber_When_Valid_GG_Pair_Then_CorrectApiEventData")
    @Tag("VER-635")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Gifter has recharge event with tax. Has mainbalance matching recharge event.|"
                +"|      |Giftee has setupservices.|"
                +"|When  |Api is called.|"
                +"|Then  |Subman call is made to purchase service offer for giftee.|"
                +"|      |purchase request should have correct apieventdata.|"})
    // @formatter:on
    public void test_giftSubscriber_When_Valid_GG_Pair_Then_CorrectApiEventData(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestGiftService request = CommonTestHelper.getVisibleRequestGiftService(
                "2024090321320", "Gifter Xyz","gifter@gift.com", "2024090321321", CI_EXTERNAL_IDS.PLUS3ANNUAL, "12345");
        System.out.println("request:" + request.toJson());
        VisibleGiftServiceResponse response = new VisibleGiftServiceResponse();

        SubscriptionResponse gifterSubscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse(
                request.getGifterExternalId());
        SubscriptionResponse gifteeSubscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                request.getGifteeExternalId(), List.of(CI_EXTERNAL_IDS.SETUP_SERVICES));

        MtxRechargeEvent gifterRech = CommonTestHelper.getGifterRechargeEvent(
                request.getGifterExternalId(),
                request.getGiftingServiceInfo().getCatalogItemExternalId());
        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEventQueryResponseEvents();
        gifterEvents.getAtEventList(0).setEventDetails(gifterRech);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingCatalogItem pci = CommonTestHelper.getMtxResponsePricingCatalogItem(
                CI_EXTERNAL_IDS.PLUS3ANNUAL);
        emulateMtxResponsePricingCatalogItem(instance, pci, CI_EXTERNAL_IDS.PLUS3ANNUAL);
        doReturn(gifterEvents).when(instance).queryRechargeEvents(
                eq(request.getGifterExternalId()));
        doReturn(gifterSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifterExternalId()));
        doReturn(gifteeSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifteeExternalId()));
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
        
        instance.giftSubscriber(request, response);
        System.out.println(td.getTestMethod() + ": response:" + response.toJson());
        argumentCaptor.getAllValues().forEach(multiReq -> {
            System.out.println(td.getTestMethod() + ": MultiRequest:" + multiReq.toJson());
        });

        VisibleApiEventData eDataMulti = (VisibleApiEventData)argumentCaptor.getValue().getApiEventData();
        assertEquals(request.getGifterExternalId(),eDataMulti.getGifterGlobalKey());

    }

    @ParameterizedTest(name = "test_giftSubscriber_When_Valid_GG_Pair_Then_GlDate_as_Today")
    @Tag("VER-635")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Gifter has recharge event with tax. Has mainbalance matching recharge event.|"
                +"|      |Giftee has setupservices.|"
                +"|When  |Api is called.|"
                +"|Then  |Subman call is made to purchase service offer for giftee.|"
                +"|      |GL Date in tax should be updated to TODAY.|"})
    // @formatter:on
    public void test_giftSubscriber_When_Valid_GG_Pair_Then_GlDate_as_Today(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestGiftService request = CommonTestHelper.getVisibleRequestGiftService(
                "2024090321320", "Gifter Xyz","gifter@gift.com", "2024090321321", CI_EXTERNAL_IDS.PLUS3ANNUAL, "12345");
        System.out.println("request:" + request.toJson());
        VisibleGiftServiceResponse response = new VisibleGiftServiceResponse();

        SubscriptionResponse gifterSubscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse(
                request.getGifterExternalId());
        SubscriptionResponse gifteeSubscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                request.getGifteeExternalId(), List.of(CI_EXTERNAL_IDS.SETUP_SERVICES));

        MtxRechargeEvent gifterRech = CommonTestHelper.getGifterRechargeEvent(
                request.getGifterExternalId(),
                request.getGiftingServiceInfo().getCatalogItemExternalId());
        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEventQueryResponseEvents();
        gifterEvents.getAtEventList(0).setEventDetails(gifterRech);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        MtxResponsePricingCatalogItem pci = CommonTestHelper.getMtxResponsePricingCatalogItem(
                CI_EXTERNAL_IDS.PLUS3ANNUAL);
        emulateMtxResponsePricingCatalogItem(instance, pci, CI_EXTERNAL_IDS.PLUS3ANNUAL);
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + request.getGifteeExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(gifterEvents).when(instance).queryRechargeEvents(
                eq(request.getGifterExternalId()));
        doReturn(gifterSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifterExternalId()));
        doReturn(gifteeSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifteeExternalId()));
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        gifteeSubscriptionResponse.setTimeZone("America/New_York");
        instance.giftSubscriber(request, response);
        System.out.println(td.getTestMethod() + ": response:" + response.toJson());
        argumentCaptor.getAllValues().forEach(multiReq -> {
            System.out.println(td.getTestMethod() + ": MultiRequest:" + multiReq.toJson());
        });
        MtxRequestSubscriberPurchaseOffer req = new MtxRequestSubscriberPurchaseOffer(
                argumentCaptor.getValue().getAtRequestList(2));
        VisiblePurchasedOfferExtension attr= (VisiblePurchasedOfferExtension)req.getAtOfferRequestArray(0).getAttr();
        ObjectMapper om = TestUtils.getObjectMapper();
        ServiceTaxResponse resp = om.readValue(attr.getTaxDetails(), ServiceTaxResponse.class);
        String expectedGlDate = TestUtils.getSubsciberDateNow(gifteeSubscriptionResponse.getTimeZone()).getTime(); 
        assertEquals(expectedGlDate,resp.getGlDate());
    }

    @ParameterizedTest(name = "test_giftSubscriber_When_Valid_GG_Pair_Then_msgIDHasGifterId")
    @Tag("VER-635")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Gifter has recharge event with tax. Has mainbalance matching recharge event.|"
                +"|      |Giftee has setupservices.|"
                +"|When  |Api is called.|"
                +"|Then  |Subman call is made to purchase service offer for giftee.|"
                +"|      |Tax msgId should have gifter external id.|"})
    // @formatter:on
    public void test_giftSubscriber_When_Valid_GG_Pair_Then_msgIDHasGifterId(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestGiftService request = CommonTestHelper.getVisibleRequestGiftService(
                "2024090321320", "Gifter Xyz","gifter@gift.com", "2024090321321", CI_EXTERNAL_IDS.PLUS3ANNUAL, "12345");
        System.out.println("request:" + request.toJson());
        VisibleGiftServiceResponse response = new VisibleGiftServiceResponse();

        SubscriptionResponse gifterSubscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse(
                request.getGifterExternalId());
        SubscriptionResponse gifteeSubscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                request.getGifteeExternalId(), List.of(CI_EXTERNAL_IDS.SETUP_SERVICES));
        MtxRechargeEvent gifterRech = CommonTestHelper.getGifterRechargeEvent(
                request.getGifterExternalId(),
                request.getGiftingServiceInfo().getCatalogItemExternalId());
        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEventQueryResponseEvents();
        gifterEvents.getAtEventList(0).setEventDetails(gifterRech);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingCatalogItem pci = CommonTestHelper.getMtxResponsePricingCatalogItem(
                CI_EXTERNAL_IDS.PLUS3ANNUAL);
        emulateMtxResponsePricingCatalogItem(instance, pci, CI_EXTERNAL_IDS.PLUS3ANNUAL);
        doReturn(gifterEvents).when(instance).queryRechargeEvents(
                eq(request.getGifterExternalId()));
        doReturn(gifterSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifterExternalId()));
        doReturn(gifteeSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifteeExternalId()));
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());
        
        System.out.println("gifteeSubscriptionResponse:" + gifteeSubscriptionResponse.toJson());
        
        instance.giftSubscriber(request, response);
        System.out.println(td.getTestMethod() + ": response:" + response.toJson());
        argumentCaptor.getAllValues().forEach(multiReq -> {
            System.out.println(td.getTestMethod() + ": MultiRequest:" + multiReq.toJson());
        });
        MtxRequestSubscriberPurchaseOffer req = new MtxRequestSubscriberPurchaseOffer(
                argumentCaptor.getValue().getAtRequestList(2));
        VisiblePurchasedOfferExtension attr= (VisiblePurchasedOfferExtension)req.getAtOfferRequestArray(0).getAttr();
        ObjectMapper om = TestUtils.getObjectMapper();
        ServiceTaxResponse resp = om.readValue(attr.getTaxDetails(), ServiceTaxResponse.class);
        assertEquals("Gift", resp.getMsgID().split("\\|")[0]);
        assertEquals(request.getGifterExternalId(), resp.getMsgID().split("\\|")[1]);
    }


    @ParameterizedTest(name = "test_giftSubscriber_When_Valid_CreditTaxDetails_Then_ValidCreditTaxDetailsInGifteeSubsResponse")
    @Tag("VER-635")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
            "|Given |Gifter has recharge event with tax. Has mainbalance matching recharge event.|"
                    +"|      |Giftee has setupservices.| Giftee has creditTaxDetails"
                    +"|When  |Api is called.|"
                    +"|Then  |Subman call is made to purchase service offer for giftee.|"
                    +"|      |CreditTaxDetails should appear in purchased offer Array of Giftee.|"})
    // @formatter:on
    public void test_giftSubscriber_When_Valid_CreditTaxDetails_Then_ValidCreditTaxDetailsInGifteeSubsResponse(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String gifterPromoExternaID = CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT;
        BigDecimal gifterPromoAmount = BigDecimal.valueOf(50);
        VisibleRequestGiftService request = CommonTestHelper.getVisibleRequestGiftService(
                "2024090321320", "Gifter Xyz","gifter@gift.com", "2024090321321", CI_EXTERNAL_IDS.PLUS3ANNUAL, "12345");
        System.out.println("request:" + request.toJson());
        VisibleGiftServiceResponse response = new VisibleGiftServiceResponse();

        SubscriptionResponse gifterSubscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse(
                request.getGifterExternalId());
        SubscriptionResponse gifteeSubscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                request.getGifteeExternalId(), List.of(CI_EXTERNAL_IDS.SETUP_SERVICES));

        MtxRechargeEvent gifterRech = CommonTestHelper.getGifterRechargeEvent(
                request.getGifterExternalId(),
                request.getGiftingServiceInfo().getCatalogItemExternalId(), gifterPromoExternaID, gifterPromoAmount);
        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEventQueryResponseEvents();
        gifterEvents.getAtEventList(0).setEventDetails(gifterRech);


        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingCatalogItem pci = CommonTestHelper.getMtxResponsePricingCatalogItem(
                CI_EXTERNAL_IDS.PLUS3ANNUAL);
        emulateMtxResponsePricingCatalogItem(instance, pci, CI_EXTERNAL_IDS.PLUS3ANNUAL);
        MtxResponsePurchase basePurchase = CommonTestHelper.getMtxResponsePurchase(
                request.getGiftingServiceInfo().getCatalogItemExternalId(),
                CommonTestHelper.getOfferPrice(
                        request.getGiftingServiceInfo().getCatalogItemExternalId()));
        multiRes.getResponseListAppender().add(basePurchase);

        doReturn(gifterEvents).when(instance).queryRechargeEvents(
                eq(request.getGifterExternalId()));
        doReturn(gifterSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifterExternalId()));
        doReturn(gifteeSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifteeExternalId()));
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        System.out.println("gifteeSubscriptionResponse:" + gifteeSubscriptionResponse.toJson());

        instance.giftSubscriber(request, response);
        System.out.println(td.getTestMethod() + ": response:" + response.toJson());
        argumentCaptor.getAllValues().forEach(multiReq -> {
            System.out.println(td.getTestMethod() + ": MultiRequest:" + multiReq.toJson());
        });
        MtxRequestSubscriberPurchaseOffer req = new MtxRequestSubscriberPurchaseOffer(
                argumentCaptor.getAllValues().get(0).getAtRequestList(2));
        VisiblePurchasedOfferExtension attr= (VisiblePurchasedOfferExtension)req.getAtOfferRequestArray(0).getAttr();
        ObjectMapper om = TestUtils.getObjectMapper();
        assertNotNull(attr.getCreditTaxDetailsArray().get(0));

    }

    @ParameterizedTest(
            name = "test_giftSubscriber_When_AnnualPlan_ThenAttrShouldPopulateCycleLength")
    @Tag("VER-635")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
            "|Given |Gifter has recharge event with tax. Has mainbalance matching recharge event.|"
                    +"|      |Giftee has setupservices.|"
                    +"|When  |Api is called.|"
                    +"|Then  |Subman call is made to purchase service offer for giftee.|"
                    +"|      |Giftee should have a cyclelength Attr set to Year.|"})
    // @formatter:on
    public void test_giftSubscriber_When_AnnualPlan_ThenAttrShouldPopulateCycleLength(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestGiftService request = CommonTestHelper.getVisibleRequestGiftService(
                "2024090321320", "Gifter Xyz","gifter@gift.com", "2024090321321", CI_EXTERNAL_IDS.PLUS3ANNUAL, "12345");
        System.out.println("request:" + request.toJson());
        VisibleGiftServiceResponse response = new VisibleGiftServiceResponse();

        SubscriptionResponse gifterSubscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse(
                request.getGifterExternalId());
        SubscriptionResponse gifteeSubscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                request.getGifteeExternalId(), List.of(CI_EXTERNAL_IDS.SETUP_SERVICES));

        MtxRechargeEvent gifterRech = CommonTestHelper.getGifterRechargeEvent(
                request.getGifterExternalId(),
                request.getGiftingServiceInfo().getCatalogItemExternalId());
        EventQueryResponseEvents gifterEvents = CommonTestHelper.getEventQueryResponseEvents();
        gifterEvents.getAtEventList(0).setEventDetails(gifterRech);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponsePricingCatalogItem pci = CommonTestHelper.getMtxResponsePricingCatalogItem(
                CI_EXTERNAL_IDS.PLUS3ANNUAL);
        emulateMtxResponsePricingCatalogItem(instance, pci, CI_EXTERNAL_IDS.PLUS3ANNUAL);
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + request.getGifteeExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(gifterEvents).when(instance).queryRechargeEvents(
                eq(request.getGifterExternalId()));
        doReturn(gifterSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifterExternalId()));
        doReturn(gifteeSubscriptionResponse).when(instance).querySubscriptionByExternalId(
                any(), any(), eq(request.getGifteeExternalId()));
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiRes).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        instance.giftSubscriber(request, response);
        System.out.println(td.getTestMethod() + ": response:" + response.toJson());
        argumentCaptor.getAllValues().forEach(multiReq -> {
            System.out.println(td.getTestMethod() + ": MultiRequest:" + multiReq.toJson());
        });

        MtxRequestSubscriptionModify req = new MtxRequestSubscriptionModify(
                argumentCaptor.getValue().getAtRequestList(0));

        VisibleSubscriberExtension se = (VisibleSubscriberExtension) req.getAttr();
        assertEquals("Year", se.getCycleLength());
    }


}
