package com.matrixx.vag.subscriber.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.EventQueryResponseEvents;
import com.matrixx.datacontainer.mdc.MtxBalanceUpdate;
import com.matrixx.datacontainer.mdc.MtxPaymentAuthorizationEvent;
import com.matrixx.datacontainer.mdc.MtxRecurringEvent;
import com.matrixx.datacontainer.mdc.MtxRequest;
import com.matrixx.datacontainer.mdc.MtxRequestMulti;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberAdjustBalance;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberCancelOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberModifyOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberRefundPayment;
import com.matrixx.datacontainer.mdc.MtxResponseCancel;
import com.matrixx.datacontainer.mdc.MtxResponseMulti;
import com.matrixx.datacontainer.mdc.MtxResponsePaymentHistory;
import com.matrixx.datacontainer.mdc.MtxResponsePricingCatalogItem;
import com.matrixx.datacontainer.mdc.MtxResponsePricingOffer;
import com.matrixx.datacontainer.mdc.MtxResponseRefundPayment;
import com.matrixx.datacontainer.mdc.MtxResponseWallet;
import com.matrixx.datacontainer.mdc.MtxSubscriberSearchData;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleRequestRefundService;
import com.matrixx.datacontainer.mdc.VisibleResponseRefundService;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.CI_METADATA;
import com.matrixx.vag.common.Constants.MATRIXX_CONSTANTS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.Constants.SUBSCRIBER_SERVICE_CONSTANTS;
import com.matrixx.vag.common.Constants.TAX_CONSTANTS;
import com.matrixx.vag.common.TestConstants.BALANCE_IDS;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestUtils;
import com.matrixx.vag.tax.client.TaxApiClient;
import com.matrixx.vag.tax.model.ServiceTaxRequest;
import com.matrixx.vag.tax.model.ServiceTaxResponse;
import com.matrixx.vag.util.MDCTest;

@ExtendWith(MockitoExtension.class)
public class RefundInsuranceV3Test extends MDCTest {

    @Spy
    @InjectMocks
    private final RefundServiceV3 instance = new RefundServiceV3();

    @Mock
    private SubscriberManagementApi api;

    private TestInfo testInfo;

    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        MockitoAnnotations.openMocks(this);
        this.testInfo = testInfo;
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_refundServiceInsuranceV3_Given_PaidOneCycle_When_RefundType2_RefundSuccess")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Insurance. Paid for one cycle.|"
       +"|When  |Request for Remorse Refund.|"
       +"|Then  |Refund should complete normally.|"})
    // @formatter:on
    public void test_refundServiceInsuranceV3_Given_PaidOneCycle_When_RefundType2_RefundSuccess(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        // Test case to check that Full Amount is returned
        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "2");

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);
        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks

        doReturn("").when(instance).getRoute(any());
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(multiRes).when(instance).multiRequest(any(), any());

        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        printUnitTest("input: " + input.toJson());
        printUnitTest("output: " + output.toJson());

        // Assertions here.
        MtxRecurringEvent recEvent = (MtxRecurringEvent) subscriberEventInfo.getAtEventList(
                0).getEventDetails();
        printUnitTest("recEvent: " + recEvent.toJson());
        HashMap<String, BigDecimal> chargeMap = CommonTestHelper.getCiChargeMapFromRecurringEvent(
                recEvent);
        printUnitTest("chargeMap: " + chargeMap);

        assertEquals(RESULT_CODES.MTX_SUCCESS, output.getResult());
        assertEquals(
                "SubscriberExternalID: " + input.getSubscriberExternalId() + " Response: OK",
                output.getResultText());
        assertEquals(
                chargeMap.get(ciExternalId).doubleValue(),
                (new BigDecimal(output.getRefundedAmount())).doubleValue());
    }

    @ParameterizedTest(
            name = "test_refundServiceInsuranceV3_RefundType2_RefundMultiNullResponse_SubscriberException")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscriber is in insurance remorse period|"
       +"|When  |Request for multimonth refund. Multirequest returns error.|"
       +"|Then  |Api returns error.|"})
    // @formatter:on
    public void test_refundServiceInsuranceV3_RefundType2_RefundMultiNullResponse_SubscriberException(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String subExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                subExternalId, ciExternalId, "2", 2);

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
        multiRes.setResultText("NotOK");
        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        when(api.multi(any())).thenReturn(multiRes);

        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        printUnitTest(": InputRequest: " + input.toJson());
        printUnitTest(": output: " + output.toJson());
        assertEquals(
                "SubscriberExternalID: " + input.getSubscriberExternalId()
                        + " Error Message: Failed to Refund Service  - NotOK",
                output.getResultText());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_refundServiceInsuranceV3_Given_PaidTwoBillingCycles_When_RefundType2_Then_RefundSuccess")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscriber is in insurance remorse period with two payments.|"
       +"|When  |Request for multimonth refund.|"
       +"|Then  |Refund correct amount to each payment authorization.|"})
    // @formatter:on
    public void test_refundServiceInsuranceV3_Given_PaidTwoBillingCycles_When_RefundType2_Then_RefundSuccess(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String subExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                subExternalId, ciExternalId, "2", 2);

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);
        // Change resource id for ease of identifying in assertion.
        long pridPayment1 = 1;
        long pridPayment2 = 2;
        PurHistoryRes.getAtPaymentInfoList(0).setResourceId(pridPayment1);
        PurHistoryRes.getAtPaymentInfoList(1).setResourceId(pridPayment2);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());

        // Capture Arguments for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(argumentCaptor.capture())).thenReturn(multiRes);

        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        printUnitTest(": InputRequest: " + input.toJson());
        printUnitTest(": Response: " + output.toJson());

        argumentCaptor.getAllValues().forEach(multiReq -> {
            printUnitTest(": multiReq: " + multiReq.toJson());
        });

        // Assertions here.
        BigDecimal refundActualPayment1 = BigDecimal.ZERO;
        BigDecimal refundActualPayment2 = BigDecimal.ZERO;
        for (MtxRequestMulti multiReq : argumentCaptor.getAllValues()) {
            for (MtxRequest req : multiReq.getRequestList()) {
                if (!MtxRequestSubscriberRefundPayment.class.getSimpleName().equalsIgnoreCase(
                        req.getMdcName())) {
                    continue;
                }
                MtxRequestSubscriberRefundPayment refReq = new MtxRequestSubscriberRefundPayment(
                        req);
                if (pridPayment1 == refReq.getResourceId()) {
                    refundActualPayment1 = refReq.getAmount();
                }
                if (pridPayment2 == refReq.getResourceId()) {
                    refundActualPayment2 = refReq.getAmount();
                }
            }
        }

        HashMap<String, BigDecimal> chargeMap1 = CommonTestHelper.getCiChargeMapFromRecurringEvent(
                (MtxRecurringEvent) subscriberEventInfo.getAtEventList(0).getEventDetails());
        HashMap<String, BigDecimal> chargeMap2 = CommonTestHelper.getCiChargeMapFromRecurringEvent(
                (MtxRecurringEvent) subscriberEventInfo.getAtEventList(2).getEventDetails());

        assertEquals(
                chargeMap1.get(ciExternalId).doubleValue(), refundActualPayment1.doubleValue());
        assertEquals(
                chargeMap2.get(ciExternalId).doubleValue(), refundActualPayment2.doubleValue());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_refundServiceInsuranceV3_Given_PaidThreeBillingCycles_When_RefundType2_Then_CorrectRefundAmounts")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscriber is in insurance remorse period with three payments.|"
       +"|When  |Request for multimonth refund.|"
       +"|Then  |Refund correct amount to each payment authorization.|"})
    // @formatter:on
    public void test_refundServiceInsuranceV3_Given_PaidThreeBillingCycles_When_RefundType2_Then_CorrectRefundAmounts(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String subExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                subExternalId, ciExternalId, "2", 3);

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);
        // Change resource id for ease of identifying in assertion.
        long pridPayment1 = 1;
        long pridPayment2 = 2;
        long pridPayment3 = 3;
        PurHistoryRes.getAtPaymentInfoList(0).setResourceId(pridPayment1);
        PurHistoryRes.getAtPaymentInfoList(1).setResourceId(pridPayment2);
        PurHistoryRes.getAtPaymentInfoList(2).setResourceId(pridPayment3);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());

        // Capture Arguments for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(argumentCaptor.capture())).thenReturn(multiRes);

        System.out.println(testInfo.getDisplayName() + ": InputRequest: " + input.toJson());
        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }

        // Assertions here.
        BigDecimal refundActualPayment1 = BigDecimal.ZERO;
        BigDecimal refundActualPayment2 = BigDecimal.ZERO;
        BigDecimal refundActualPayment3 = BigDecimal.ZERO;
        for (MtxRequestMulti multiReq : argumentCaptor.getAllValues()) {
            for (MtxRequest req : multiReq.getRequestList()) {
                if (!MtxRequestSubscriberRefundPayment.class.getSimpleName().equalsIgnoreCase(
                        req.getMdcName())) {
                    continue;
                }
                MtxRequestSubscriberRefundPayment refReq = new MtxRequestSubscriberRefundPayment(
                        req);
                if (pridPayment1 == refReq.getResourceId()) {
                    refundActualPayment1 = refReq.getAmount();
                }
                if (pridPayment2 == refReq.getResourceId()) {
                    refundActualPayment2 = refReq.getAmount();
                }
                if (pridPayment3 == refReq.getResourceId()) {
                    refundActualPayment3 = refReq.getAmount();
                }
            }
        }

        HashMap<String, BigDecimal> chargeMap1 = CommonTestHelper.getCiChargeMapFromRecurringEvent(
                (MtxRecurringEvent) subscriberEventInfo.getAtEventList(0).getEventDetails());
        HashMap<String, BigDecimal> chargeMap2 = CommonTestHelper.getCiChargeMapFromRecurringEvent(
                (MtxRecurringEvent) subscriberEventInfo.getAtEventList(2).getEventDetails());
        HashMap<String, BigDecimal> chargeMap3 = CommonTestHelper.getCiChargeMapFromRecurringEvent(
                (MtxRecurringEvent) subscriberEventInfo.getAtEventList(4).getEventDetails());
        assertEquals(
                chargeMap1.get(ciExternalId).doubleValue(), refundActualPayment1.doubleValue());
        assertEquals(
                chargeMap2.get(ciExternalId).doubleValue(), refundActualPayment2.doubleValue());
        assertEquals(
                chargeMap3.get(ciExternalId).doubleValue(), refundActualPayment3.doubleValue());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_refundServiceInsuranceV3_Given_PaidThreeBillingCycles_When_RefundType2_Then_CorrectAdjustments")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscriber is in insurance remorse period with three payments.|"
       +"|When  |Request for multimonth refund.|"
       +"|Then  |Adjustment reason has correct event ids.|"})
    // @formatter:on
    public void test_refundServiceInsuranceV3_Given_PaidThreeBillingCycles_When_RefundType2_Then_CorrectAdjustments(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        // Below tests are not done
        // 2. Prorated unused amount is adjusted to main balance
        // 3. Individual requests in multirequest are in correct order:
        // AdjustBalance->SubscriberRefund->CancelOffer

        String subExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                subExternalId, ciExternalId, "2", 3);

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);
        // Change resource id for ease of identifying in assertion.
        long pridPayment1 = 1;
        long pridPayment2 = 2;
        long pridPayment3 = 3;
        PurHistoryRes.getAtPaymentInfoList(0).setResourceId(pridPayment1);
        PurHistoryRes.getAtPaymentInfoList(1).setResourceId(pridPayment2);
        PurHistoryRes.getAtPaymentInfoList(2).setResourceId(pridPayment3);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());

        // Capture Arguments for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(argumentCaptor.capture())).thenReturn(multiRes);

        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        printUnitTest(":InputRequest:" + input.toJson());
        printUnitTest(":output:" + output.toJson());

        // Assertions here.
        MtxRequestSubscriberAdjustBalance adjReq1 = (MtxRequestSubscriberAdjustBalance) argumentCaptor.getAllValues().get(
                0).getRequestList().get(0);
        assertTrue(adjReq1.getReason().startsWith(CommonUtils.REVERSAL_PREFIX));
        assertTrue(
                adjReq1.getReason().contains(input.getAtEventGroupList(0).getRecurringEventId()));
        assertTrue(
                adjReq1.getReason().contains(input.getAtEventGroupList(1).getRecurringEventId()));
        assertTrue(
                adjReq1.getReason().contains(input.getAtEventGroupList(2).getRecurringEventId()));

        MtxRequestSubscriberAdjustBalance adjReq2 = (MtxRequestSubscriberAdjustBalance) argumentCaptor.getAllValues().get(
                0).getRequestList().get(1);
        assertTrue(adjReq2.getReason().startsWith(CommonUtils.REVERSAL_PREFIX));
        assertTrue(
                adjReq2.getReason().contains(input.getAtEventGroupList(0).getRecurringEventId()));
        assertTrue(
                adjReq2.getReason().contains(input.getAtEventGroupList(1).getRecurringEventId()));
        assertTrue(
                adjReq2.getReason().contains(input.getAtEventGroupList(2).getRecurringEventId()));

        MtxRequestSubscriberAdjustBalance adjReq3 = (MtxRequestSubscriberAdjustBalance) argumentCaptor.getAllValues().get(
                0).getRequestList().get(2);
        assertTrue(adjReq3.getReason().startsWith(CommonUtils.REVERSAL_PREFIX));
        assertTrue(
                adjReq3.getReason().contains(input.getAtEventGroupList(0).getRecurringEventId()));
        assertTrue(
                adjReq3.getReason().contains(input.getAtEventGroupList(1).getRecurringEventId()));
        assertTrue(
                adjReq3.getReason().contains(input.getAtEventGroupList(2).getRecurringEventId()));
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_refundServiceInsuranceV3_When_RefundType1_RefundSuccess")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Insurance.|"
       +"|When  |Request for Prorated Refund.|"
       +"|Then  |Refund should complete normally.|"})
    // @formatter:on
    public void test_refundServiceInsuranceV3_When_RefundType1_RefundSuccess(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "1");

        MtxResponseMulti multiRes1 = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes1.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());

        MtxResponseMulti multiRes2 = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes2.getResponseListAppender().add(CommonTestHelper.getOkMtxResponseRefundPayment());

        MtxResponseCancel cancelResp = CommonTestHelper.getMtxResponseCancel();

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);
        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        when(api.multi(any(), any())).thenReturn(multiRes1).thenReturn(multiRes2);

        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        printUnitTest(": InputRequest: " + input.toJson());
        printUnitTest(": OutputRequest: " + output.toJson());
        // Assertions here.
        assertEquals("0", String.valueOf(output.getResult()));
        assertEquals(
                "SubscriberExternalID: " + input.getSubscriberExternalId() + " Response: OK",
                output.getResultText());
        double cancelAOCImpactAmount = cancelResp.getCancelInfoArray().get(
                0).getBalanceImpactGroupList().get(0).getBalanceImpactList().get(
                        0).getImpactAmount().negate().doubleValue();
        assertEquals(cancelAOCImpactAmount, Double.parseDouble(output.getRefundedAmount()), 0.01);
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-294")
    @ParameterizedTest(
            name = "test_refundServiceInsuranceV3_Given_RecurringEventHasMultipleOffers_When_RefundType1_RefundSuccess")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Insurance and Base Service.|"
       +"|When  |Request for Prorated Refund.|"
       +"|Then  |Refund should complete normally.|"})
    // @formatter:on
    public void test_refundServiceInsuranceV3_Given_RecurringEventHasMultipleOffers_When_RefundType1_Then_RefundSuccess(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "1");

        MtxResponseMulti multiRes1 = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes1.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());

        MtxResponseMulti multiRes2 = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes2.getResponseListAppender().add(CommonTestHelper.getOkMtxResponseRefundPayment());

        MtxResponseCancel cancelResp = CommonTestHelper.getMtxResponseCancel();

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);
        MtxRecurringEvent recEvent = CommonTestHelper.getMtxRecurringEvent(
                List.of(CI_EXTERNAL_IDS.INSURANCE, CI_EXTERNAL_IDS.PLUS_CURRENT));
        recEvent.setEventId(input.getAtEventGroupList(0).getRecurringEventId());
        subscriberEventInfo.getAtEventList(0).setEventDetails(recEvent);

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);
        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));

        doReturn("").when(instance).getRoute(any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        // doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        when(api.multi(any(), any())).thenReturn(multiRes1).thenReturn(multiRes2);

        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        printUnitTest(": InputRequest: " + input.toJson());
        printUnitTest(": OutputRequest: " + output.toJson());

        // Assertions here.
        assertEquals("0", String.valueOf(output.getResult()));
        assertEquals(
                "SubscriberExternalID: " + input.getSubscriberExternalId() + " Response: OK",
                output.getResultText());
        assertEquals(
                cancelResp.getCancelInfoArray().get(0).getBalanceImpactGroupList().get(
                        0).getBalanceImpactList().get(0).getImpactAmount().negate().doubleValue(),
                Double.parseDouble(output.getRefundedAmount()), 0.01);
        assertEquals(
                (new MtxResponseRefundPayment(
                        multiRes2.getAtResponseList(0))).getRefundInfo().getRefundTime().toString(),
                output.getRefundAmountInfo());

    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_refundServiceInsuranceV3_When_RefundType1_AocError_Then_Exception")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Insurance.|"
       +"|When  |Request for Prorated Refund. Cancel AoC error. |"
       +"|Then  |Error.|"})
    // @formatter:on
    public void test_refundServiceInsuranceV3_When_RefundType1_AocError_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "1");

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());

        MtxResponseCancel cancelErrorResp = CommonTestHelper.getMtxResponseCancel();
        cancelErrorResp.setResult(11L);
        cancelErrorResp.setResultText("NOTOK");
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        Mockito.doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(
                any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(cancelErrorResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());

        instance.refundService(input, output);
        printUnitTest(": InputRequest: " + input.toJson());
        printUnitTest(": OutputRequest: " + output.toJson());

        assertEquals(
                "SubscriberExternalID: " + input.getSubscriberExternalId()
                        + " Error Message: Failed to get AOC on cancel subscriber offer - NOTOK",
                output.getResultText());
    }

    @Tag("Multirequest")
    @ParameterizedTest(
            name = "test_refundServiceInsuranceV3_When_RefundType1_CancellServices_Then_CorrectMultiRequestOrdering")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Insurance.|"
       +"|When  |Request to prorated refund with service cancellation|"
       +"|Then  |Order of requests in multirequest should be correct.|"})
    // @formatter:on
    public void test_refundServiceInsuranceV3_When_RefundType1_CancellServices_Then_CorrectMultiRequestOrdering(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "1");

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);

        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        MtxResponseCancel cancelResp = CommonTestHelper.getMtxResponseCancel_Precesion2();

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        printUnitTest(": InputRequest: " + input.toJson());
        printUnitTest(": output: " + output.toJson());
        argumentCaptor.getAllValues().forEach(multiRequest -> {
            printUnitTest(": multiRequest: " + multiRequest.toJson());
        });

        MtxRequestMulti multNonRefund = argumentCaptor.getAllValues().get(0);
        assertEquals(2, multNonRefund.getRequestList().size());
        assertEquals(
                MtxRequestSubscriberModifyOffer.class.getSimpleName(),
                multNonRefund.getAtRequestList(0).getContainer().getName());
        assertEquals(
                MtxRequestSubscriberCancelOffer.class.getSimpleName(),
                multNonRefund.getAtRequestList(1).getContainer().getName());

        MtxRequestMulti multRefund = argumentCaptor.getAllValues().get(1);
        assertEquals(1, multRefund.getRequestList().size());
        assertEquals(
                MtxRequestSubscriberRefundPayment.class.getSimpleName(),
                multRefund.getAtRequestList(0).getContainer().getName());
    }

    @Tag("Multirequest")
    @ParameterizedTest(
            name = "test_refundServiceInsuranceV3_When_RefundType1_DeltaAdjustment_Then_CorrectMultiRequestOrdering")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Insurance.|"
       +"|When  |Request to prorated refund. But results in delta due to rounding corrections.|"
       +"|Then  |Order of requests in multirequest should be correct.|"})
    // @formatter:on
    public void test_refundServiceInsuranceV3_When_RefundType1_DeltaAdjustment_Then_CorrectMultiRequestOrdering(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "1");

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);

        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        MtxResponseCancel cancelResp = CommonTestHelper.getMtxResponseCancel_Precesion6();

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        printUnitTest(": InputRequest: " + input.toJson());
        printUnitTest(": output: " + output.toJson());
        argumentCaptor.getAllValues().forEach(multiRequest -> {
            printUnitTest(": multiRequest: " + multiRequest.toJson());
        });

        MtxRequestMulti multNonRefund = argumentCaptor.getAllValues().get(0);
        assertEquals(
                MtxRequestSubscriberAdjustBalance.class.getSimpleName(),
                multNonRefund.getAtRequestList(0).getContainer().getName());
        MtxRequestSubscriberAdjustBalance adjReq = new MtxRequestSubscriberAdjustBalance(
                multNonRefund.getAtRequestList(0));
        assertEquals("rounding_error_adjustment", adjReq.getReason());
    }

    @Tag("Multirequest")
    @ParameterizedTest(
            name = "test_refundServiceInsuranceV3_When_RefundType1_KeepServices_Then_CorrectMultiRequestOrdering")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Insurance.|"
       +"|When  |Request to prorated refund with NO service cancellation|"
       +"|Then  |Order of requests in multirequest should be correct.|"})
    // @formatter:on
    public void test_refundServiceInsuranceV3_When_RefundType1_KeepServices_Then_CorrectMultiRequestOrdering(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "1");
        input.setCancelServices(SUBSCRIBER_SERVICE_CONSTANTS.REFUND_CANCEL_NO);

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);

        MtxResponsePaymentHistory purHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        MtxResponseCancel cancelResp = CommonTestHelper.getMtxResponseCancel_Precesion2();

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());
        doReturn(purHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        printUnitTest(": InputRequest: " + input.toJson());
        printUnitTest(": output: " + output.toJson());
        printUnitTest(": cancelResp: " + cancelResp.toJson());
        argumentCaptor.getAllValues().forEach(multiRequest -> {
            printUnitTest(": multiRequest: " + multiRequest.toJson());
        });
        MtxRequestMulti multNonRefund = argumentCaptor.getAllValues().get(0);
        assertEquals(1, multNonRefund.getRequestList().size());
        assertEquals(
                MtxRequestSubscriberAdjustBalance.class.getSimpleName(),
                multNonRefund.getAtRequestList(0).getContainer().getName());

        MtxRequestMulti multRefund = argumentCaptor.getAllValues().get(1);
        assertEquals(1, multRefund.getRequestList().size());
        assertEquals(
                MtxRequestSubscriberRefundPayment.class.getSimpleName(),
                multRefund.getAtRequestList(0).getContainer().getName());
    }

    @Tag("Multirequest")
    @ParameterizedTest(
            name = "test_refundServiceInsuranceV3_When_RefundType1_KeepServices_Then_CorrectMultiRequestOrdering")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Insurance.|"
       +"|When  |Request to remorse refund|"
       +"|Then  |Order of requests in multirequest should be correct.|"})
    // @formatter:on
    public void test_refundServiceInsuranceV3_When_RefundType2_Then_CorrectMultiRequestOrdering(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "2");

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(argumentCaptor.capture())).thenReturn(multiRes);

        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }

        System.out.println(testInfo.getDisplayName() + ": InputRequest: " + input.toJson());
        System.out.println(testInfo.getDisplayName() + ": outputRequest: " + output.toJson());
        // Assertions here.
        assertEquals(
                MtxRequestSubscriberAdjustBalance.class.getSimpleName(),
                argumentCaptor.getAllValues().get(0).getAtRequestList(0).getContainer().getName());
        assertEquals(
                MtxRequestSubscriberCancelOffer.class.getSimpleName(),
                argumentCaptor.getAllValues().get(0).getAtRequestList(1).getContainer().getName());
        assertEquals(
                MtxRequestSubscriberRefundPayment.class.getSimpleName(),
                argumentCaptor.getAllValues().get(1).getAtRequestList(0).getContainer().getName());
    }

    @SuppressWarnings("unchecked")
    @Tag("Tax")
    @ParameterizedTest(
            name = "test_refundServiceInsuranceV3_When_RefundType1_Then_OfferUpdatedWithNewVendorPayable")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Insurance. Insurance has vendor payable.|"
       +"|When  |Request to prorate refund|"
       +"|Then  |Updated tax should have updated vendor payable.|"})
    // @formatter:on
    public void test_refundServiceInsuranceV3_When_RefundType1_Then_OfferUpdatedWithNewVendorPayable(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "1");

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        MtxResponseCancel cancelResp = CommonTestHelper.getMtxResponseCancel();

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);

        VisibleResponseRefundService output = new VisibleResponseRefundService();
        // mocks
        emulateMtxResponsePricingCatalogItem(
                instance, input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());

        MtxRecurringEvent recEvent = (MtxRecurringEvent) subscriberEventInfo.getAtEventList(
                0).getEventDetails();
        VisiblePurchasedOfferExtension eventAttr = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                0).getPurchasedBundleAttr();
        String taxApiResp1 = eventAttr.getTaxDetails();
        ServiceTaxResponse taxApiResp1Json = CommonTestHelper.getServiceTaxResponseFromString(
                taxApiResp1);

        BigDecimal expectedVP = cancelResp.getAtCancelInfoArray(0).getAtBalanceImpactGroupList(
                0).getAtBalanceImpactList(0).getImpactAmount().abs().multiply(
                        taxApiResp1Json.getVendorPayableNonProrated()).divide(
                                eventAttr.getChargeAmount(),
                                TAX_CONSTANTS.TAX_API_DISPLAY_PRECISION, RoundingMode.HALF_UP);

        ArgumentCaptor<MtxRequestMulti> argumentCaptorMulti = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptorMulti.capture())).thenReturn(multiRes);

        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        ServiceTaxResponse taxApiResp2Json = CommonTestHelper.getServiceTaxResponseFromString(
                taxApiResp2);

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        System.out.println(testInfo.getDisplayName() + ": InputRequest: " + input.toJson());
        System.out.println(testInfo.getDisplayName() + ": outputRequest: " + output.toJson());
        argumentCaptor.getAllValues().forEach(taxReq -> {
            System.out.println(testInfo.getDisplayName() + ": taxReq: " + taxReq);
        });
        ServiceTaxRequest taxReq = CommonTestHelper.getServiceTaxRequestFromString(
                argumentCaptor.getAllValues().get(0));

        assertEquals(expectedVP.doubleValue(), taxReq.getVendorPayable().doubleValue(), 0.01);

        ServiceTaxResponse taxRespModifyReq = CommonTestHelper.getServiceTaxResponseFromString(
                (((VisiblePurchasedOfferExtension) (new MtxRequestSubscriberModifyOffer(
                        argumentCaptorMulti.getAllValues().get(0).getAtRequestList(
                                1).getContainer())).getAttr()).getTaxDetails()));
        assertEquals(
                taxApiResp2Json.getVendorPayable().doubleValue(),
                taxRespModifyReq.getVendorPayable().doubleValue(), 0.001);
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-356")
    @ParameterizedTest(
            name = "test_refundServiceInsuranceV3_When_ProratedRefund_Then_CorrectTaxRequest")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has active insurance service.|"
                +"|When  |Api is called for prorated refund.|"
                +"|Then  |Tax for cancellation should be calculated with tax template from insurance.|"})
    // @formatter:on
    public void test_refundServiceInsuranceV3_When_ProratedRefund_Then_CorrectTaxRequest(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;
        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "1");

        MtxResponseWallet walletRes = CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO);

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());

        MtxResponseCancel cancelResp = CommonTestHelper.getMtxResponseCancel();

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);
        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        MtxResponsePricingCatalogItem pci = emulateMtxResponsePricingCatalogItem(
                instance, input.getRefundServiceOrderInfo().getServiceOfferExternalId());

        doReturn("").when(instance).getRoute(any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingProductOffer(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        when(api.multi(any())).thenReturn(multiRes);
        doReturn(walletRes).when(instance).querySubscriptionWallet(any(), any(), any());

        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }

        printUnitTest(": InputRequest: " + input.toJson());
        printUnitTest(": OutputRequest: " + output.toJson());

        ObjectMapper om = TestUtils.getObjectMapper();
        ServiceTaxRequest taxReq = om.readValue(
                argumentCaptor.getAllValues().get(0), ServiceTaxRequest.class);

        StringBuffer taxStringMetadata = new StringBuffer("");
        pci.getCatalogItemInfo().getMetadataList().forEach(pmi -> {
            if (CI_METADATA.TAX_INPUT.equalsIgnoreCase(pmi.getName())) {
                taxStringMetadata.append(pmi.getValue());
            }
        });
        ServiceTaxRequest taxReqMetadata = om.readValue(
                taxStringMetadata.toString(), ServiceTaxRequest.class);

        // Assertions here.
        assertEquals(taxReqMetadata.getPlanID(), taxReq.getPlanID());
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-875")
    @Tag("ConnectedAccounts")
    @ParameterizedTest(
            name = "test_refundInsuranceV3_Given_PaidByPayer_When_Prorated_Then_RefundToPayer")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription with a payer. Paid by payer.|"
                +"|When  |Request for prorated refund.|"
                +"|Then  |Beneficiary's mainbalance should be adjusted so that amount from cancellation is zeroed out.|"})
    // @formatter:on
    public void test_refundInsuranceV3_Given_PaidByPayer_When_Prorated_Then_AdjustBalanceBeneficiary(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String benExternalId = "12345";
        String payExternalId = "67890";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;

        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "1");
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                Map.of(
                        input.getAtEventGroupList(0).getAtPaymentAuthorizationEventIds(0),
                        CommonTestHelper.getOfferPrice(ciExternalId)));
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input, payExternalId);
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);
        BigDecimal refundAmount = BigDecimal.valueOf(5.123456);
        MtxResponseCancel cancelResp = CommonTestHelper.getMtxResponseCancel_Precesion6(refundAmount);
        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItem(
                instance, input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        doReturn("").when(instance).getRoute(any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        printUnitTest("cancelResp:"+cancelResp.toJson());
        printUnitTest(input.toJson());
        printUnitTest(output.toJson());
        argumentCaptor.getAllValues().forEach(multiReq->{
            printUnitTest("multiReq: "+multiReq.toJson());
        });
        // Assertions here.
        ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();
        MtxRequestSubscriberAdjustBalance benAdjRequest = null;
        for(MtxRequest req:reqList) {
            if(MtxRequestSubscriberAdjustBalance.class.getSimpleName().equalsIgnoreCase(req.getContainer().getName())) {
                MtxRequestSubscriberAdjustBalance adjRequest = (MtxRequestSubscriberAdjustBalance) req;
                if(adjRequest.getSubscriberSearchData().getExternalId().equalsIgnoreCase(benExternalId)) {
                    benAdjRequest = adjRequest;
                    break;
                }
            }            
        }
        printUnitTest("benAdjRequest:"+benAdjRequest.toJson());

        assertEquals(MATRIXX_CONSTANTS.BALANCE_ADJUSTMENT_TYPE_DEBIT, benAdjRequest.getAdjustType());
        assertEquals(refundAmount.floatValue(), benAdjRequest.getAmount().floatValue());
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-875")
    @Tag("ConnectedAccounts")
    @ParameterizedTest(
            name = "test_refundInsuranceV3_Given_PaidByPayer_When_Prorated_KeepService_Then_NoAdjustToBeneficiary")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription with a payer. Paid by payer.|"
                +"|When  |Request for prorated refund. But do not cancel Insurance service.|"
                +"|Then  |Beneficiary's mainbalance should NOT be adjusted, as, there would be no cancel impact to beneficiary's mainbalance.|"})
    // @formatter:on
    public void test_refundInsuranceV3_Given_PaidByPayer_When_Prorated_KeepService_Then_NoAdjustToBeneficiary(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String benExternalId = "12345";
        String payExternalId = "67890";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;

        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "1");
        input.setCancelServices(SUBSCRIBER_SERVICE_CONSTANTS.REFUND_CANCEL_NO);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                Map.of(
                        input.getAtEventGroupList(0).getAtPaymentAuthorizationEventIds(0),
                        CommonTestHelper.getOfferPrice(ciExternalId)));
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input, payExternalId);
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);
        BigDecimal refundAmount = BigDecimal.valueOf(5.123456);
        MtxResponseCancel cancelResp = CommonTestHelper.getMtxResponseCancel_Precesion6(refundAmount);
        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
//        emulateMtxResponsePricingCatalogItem(
//                instance, input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        doReturn("").when(instance).getRoute(any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        printUnitTest("cancelResp:"+cancelResp.toJson());
        printUnitTest(input.toJson());
        printUnitTest(output.toJson());
        argumentCaptor.getAllValues().forEach(multiReq->{
            printUnitTest("multiReq: "+multiReq.toJson());
        });
        // Assertions here.
        ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();
        MtxRequestSubscriberAdjustBalance benAdjRequest = null;
        for(MtxRequest req:reqList) {
            if(MtxRequestSubscriberAdjustBalance.class.getSimpleName().equalsIgnoreCase(req.getContainer().getName())) {
                MtxRequestSubscriberAdjustBalance adjRequest = (MtxRequestSubscriberAdjustBalance) req;
                if(adjRequest.getSubscriberSearchData().getExternalId().equalsIgnoreCase(benExternalId)) {
                    benAdjRequest = adjRequest;
                    break;
                }
            }            
        }
        assertNull(benAdjRequest);
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-875")
    @Tag("ConnectedAccounts")
    @ParameterizedTest(
            name = "test_refundInsuranceV3_Given_PaidByPayer_When_Prorated_Then_RefundToPayer")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription with a payer. Paid by payer.|"
                +"|When  |Request for prorated refund.|"
                +"|Then  |Payer's mainbalance should be adjusted so that money is present before refund.|"})
    // @formatter:on
    public void test_refundInsuranceV3_Given_PaidByPayer_When_Prorated_Then_AdjustBalancePayer(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String benExternalId = "12345";
        String payExternalId = "67890";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;

        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "1");
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                Map.of(
                        input.getAtEventGroupList(0).getAtPaymentAuthorizationEventIds(0),
                        CommonTestHelper.getOfferPrice(ciExternalId)));
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input, payExternalId);
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);
        BigDecimal refundAmount = BigDecimal.valueOf(5.123456);        
        MtxResponseCancel cancelResp = CommonTestHelper.getMtxResponseCancel_Precesion6(refundAmount);
        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItem(
                instance, input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        doReturn("").when(instance).getRoute(any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        printUnitTest("cancelResp:"+cancelResp.toJson());
        printUnitTest(input.toJson());
        printUnitTest(output.toJson());
        BigDecimal btRefundAmount = new BigDecimal(output.getRefundedAmount());
        argumentCaptor.getAllValues().forEach(multiReq->{
            printUnitTest("multiReq: "+multiReq.toJson());
        });
        // Assertions here.
        ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();
        MtxRequestSubscriberAdjustBalance payAdjRequest = null;
        for(MtxRequest req:reqList) {
            if(MtxRequestSubscriberAdjustBalance.class.getSimpleName().equalsIgnoreCase(req.getContainer().getName())) {
                MtxRequestSubscriberAdjustBalance adjRequest = (MtxRequestSubscriberAdjustBalance) req;
                if(adjRequest.getSubscriberSearchData().getExternalId().equalsIgnoreCase(payExternalId)) {
                    payAdjRequest = adjRequest;
                    break;
                }
            }            
        }
        printUnitTest("payAdjRequest:"+payAdjRequest.toJson());

        assertEquals(MATRIXX_CONSTANTS.BALANCE_ADJUSTMENT_TYPE_CREDIT, payAdjRequest.getAdjustType());
        assertEquals(btRefundAmount.floatValue(), payAdjRequest.getAmount().floatValue());
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-875")
    @Tag("ConnectedAccounts")
    @ParameterizedTest(
            name = "test_refundInsuranceV3_Given_PaidByPayer_When_Prorated_KeepServices_Then_AdjustBalancePayer")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription with a payer. Paid by payer.|"
                +"|When  |Request for prorated refund. Do not cancel Insurance service.|"
                +"|Then  |Payer's mainbalance should be adjusted so that money is present before refund.|"})
    // @formatter:on
    public void test_refundInsuranceV3_Given_PaidByPayer_When_Prorated_KeepServices_Then_AdjustBalancePayer(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String benExternalId = "12345";
        String payExternalId = "67890";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;

        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "1");
        input.setCancelServices(SUBSCRIBER_SERVICE_CONSTANTS.REFUND_CANCEL_NO);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                Map.of(
                        input.getAtEventGroupList(0).getAtPaymentAuthorizationEventIds(0),
                        CommonTestHelper.getOfferPrice(ciExternalId)));
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input, payExternalId);
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);
        BigDecimal refundAmount = BigDecimal.valueOf(5.123456);        
        MtxResponseCancel cancelResp = CommonTestHelper.getMtxResponseCancel_Precesion6(refundAmount);
        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        printUnitTest("cancelResp:"+cancelResp.toJson());
        printUnitTest(input.toJson());
        printUnitTest(output.toJson());
        BigDecimal btRefundAmount = new BigDecimal(output.getRefundedAmount());
        argumentCaptor.getAllValues().forEach(multiReq->{
            printUnitTest("multiReq: "+multiReq.toJson());
        });
        // Assertions here.
        ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();
        MtxRequestSubscriberAdjustBalance payAdjRequest = null;
        for(MtxRequest req:reqList) {
            if(MtxRequestSubscriberAdjustBalance.class.getSimpleName().equalsIgnoreCase(req.getContainer().getName())) {
                MtxRequestSubscriberAdjustBalance adjRequest = (MtxRequestSubscriberAdjustBalance) req;
                if(adjRequest.getSubscriberSearchData().getExternalId().equalsIgnoreCase(payExternalId)) {
                    payAdjRequest = adjRequest;
                    break;
                }
            }            
        }
        printUnitTest("payAdjRequest:"+payAdjRequest.toJson());

        assertEquals(MATRIXX_CONSTANTS.BALANCE_ADJUSTMENT_TYPE_CREDIT, payAdjRequest.getAdjustType());
        assertEquals(btRefundAmount.floatValue(), payAdjRequest.getAmount().floatValue());
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-875")
    @ParameterizedTest(
            name = "test_refundInsuranceV3_Given_PaidByBeneficiary_When_BTRefund_LessThan_MatrixxRefund_Then_ReduceFromBeneficiary")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription with no payer. Paid by beneficiary.|"
                +"|When  |Prorated refund with round off error. Braintree refund less than Matrixx refund|"
                +"|Then  |Beneficiary's's mainbalance should be adjusted to reduce from beneficiary.|"})
    // @formatter:on
    public void test_refundInsuranceV3_Given_PaidByBeneficiary_When_BTRefund_LessThan_MatrixxRefund_Then_ReduceFromBeneficiary(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;

        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "1");
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                Map.of(
                        input.getAtEventGroupList(0).getAtPaymentAuthorizationEventIds(0),
                        CommonTestHelper.getOfferPrice(ciExternalId)));
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);
        BigDecimal refundAmount = BigDecimal.valueOf(5.123456);
        MtxResponseCancel cancelResp = CommonTestHelper.getMtxResponseCancel_Precesion6(refundAmount);
        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItem(
                instance, input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        doReturn("").when(instance).getRoute(any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        printUnitTest("cancelResp:"+cancelResp.toJson());
        printUnitTest(input.toJson());
        printUnitTest(output.toJson());
        BigDecimal btRefundAmount = new BigDecimal(output.getRefundedAmount());
        argumentCaptor.getAllValues().forEach(multiReq->{
            printUnitTest("multiReq: "+multiReq.toJson());
        });
        // Assertions here.
        ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();
        MtxRequestSubscriberAdjustBalance benAdjRequest = null;
        for(MtxRequest req:reqList) {
            if(MtxRequestSubscriberAdjustBalance.class.getSimpleName().equalsIgnoreCase(req.getContainer().getName())) {
                MtxRequestSubscriberAdjustBalance adjRequest = (MtxRequestSubscriberAdjustBalance) req;
                if(adjRequest.getSubscriberSearchData().getExternalId().equalsIgnoreCase(benExternalId)) {
                    benAdjRequest = adjRequest;
                    break;
                }
            }            
        }
        printUnitTest("benAdjRequest:"+benAdjRequest.toJson());

        assertEquals(MATRIXX_CONSTANTS.BALANCE_ADJUSTMENT_TYPE_DEBIT, benAdjRequest.getAdjustType());
        assertEquals(refundAmount.subtract(btRefundAmount).floatValue(), benAdjRequest.getAmount().floatValue());
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-875")
    @ParameterizedTest(
            name = "test_refundInsuranceV3_Given_PaidByBeneficiary_When_KeepService_BT_LessThan_Matrixx_Then_ReduceFromBeneficiary")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription with no payer. Paid by beneficiary.|"
                +"|When  |Prorated refund with round off error. Braintree refund less than Matrixx refund. Do not cancel service|"
                +"|Then  |Beneficiary's's mainbalance should be adjusted to add BT refund amount to beneficiary.|"})
    // @formatter:on
    public void test_refundInsuranceV3_Given_PaidByBeneficiary_When_KeepService_BT_LessThan_Matrixx_Then_ReduceFromBeneficiary(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;

        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "1");
        input.setCancelServices(SUBSCRIBER_SERVICE_CONSTANTS.REFUND_CANCEL_NO);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                Map.of(
                        input.getAtEventGroupList(0).getAtPaymentAuthorizationEventIds(0),
                        CommonTestHelper.getOfferPrice(ciExternalId)));
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);
        BigDecimal refundAmount = BigDecimal.valueOf(5.123456);
        MtxResponseCancel cancelResp = CommonTestHelper.getMtxResponseCancel_Precesion6(refundAmount);
        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        printUnitTest("cancelResp:"+cancelResp.toJson());
        printUnitTest(input.toJson());
        printUnitTest(output.toJson());
        BigDecimal btRefundAmount = new BigDecimal(output.getRefundedAmount());
        argumentCaptor.getAllValues().forEach(multiReq->{
            printUnitTest("multiReq: "+multiReq.toJson());
        });
        // Assertions here.
        ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();
        MtxRequestSubscriberAdjustBalance benAdjRequest = null;
        for(MtxRequest req:reqList) {
            if(MtxRequestSubscriberAdjustBalance.class.getSimpleName().equalsIgnoreCase(req.getContainer().getName())) {
                MtxRequestSubscriberAdjustBalance adjRequest = (MtxRequestSubscriberAdjustBalance) req;
                if(adjRequest.getSubscriberSearchData().getExternalId().equalsIgnoreCase(benExternalId)) {
                    benAdjRequest = adjRequest;
                    break;
                }
            }            
        }
        printUnitTest("benAdjRequest:"+benAdjRequest.toJson());

        assertEquals(MATRIXX_CONSTANTS.BALANCE_ADJUSTMENT_TYPE_CREDIT, benAdjRequest.getAdjustType());
        assertEquals(btRefundAmount.floatValue(), benAdjRequest.getAmount().floatValue());
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-875")    
    @ParameterizedTest(
            name = "test_refundInsuranceV3_Given_PaidByBeneficiary_When_BTRefund_MoreThan_MatrixxRefund_Then_AddToBeneficiary")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription with no payer. Paid by beneficiary.|"
                +"|When  |Prorated refund with round off error. Braintree refund is more than Matrixx refund|"
                +"|Then  |Beneficiary's's mainbalance should be adjusted to add to beneficiary.|"})
    // @formatter:on
    public void test_refundInsuranceV3_Given_PaidByBeneficiary_When_BTRefund_MoreThan_MatrixxRefund_Then_AddToBeneficiary(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;

        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "1");
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                Map.of(
                        input.getAtEventGroupList(0).getAtPaymentAuthorizationEventIds(0),
                        CommonTestHelper.getOfferPrice(ciExternalId)));
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);
        BigDecimal refundAmount = BigDecimal.valueOf(5.129876);
        MtxResponseCancel cancelResp = CommonTestHelper.getMtxResponseCancel_Precesion6(refundAmount);
        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItem(
                instance, input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        doReturn("").when(instance).getRoute(any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        printUnitTest("cancelResp:"+cancelResp.toJson());
        printUnitTest(input.toJson());
        printUnitTest(output.toJson());
        BigDecimal btRefundAmount = new BigDecimal(output.getRefundedAmount());
        argumentCaptor.getAllValues().forEach(multiReq->{
            printUnitTest("multiReq: "+multiReq.toJson());
        });
        // Assertions here.
        ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();
        MtxRequestSubscriberAdjustBalance benAdjRequest = null;
        for(MtxRequest req:reqList) {
            if(MtxRequestSubscriberAdjustBalance.class.getSimpleName().equalsIgnoreCase(req.getContainer().getName())) {
                MtxRequestSubscriberAdjustBalance adjRequest = (MtxRequestSubscriberAdjustBalance) req;
                if(adjRequest.getSubscriberSearchData().getExternalId().equalsIgnoreCase(benExternalId)) {
                    benAdjRequest = adjRequest;
                    break;
                }
            }            
        }
        printUnitTest("benAdjRequest:"+benAdjRequest.toJson());

        assertEquals(MATRIXX_CONSTANTS.BALANCE_ADJUSTMENT_TYPE_CREDIT, benAdjRequest.getAdjustType());
        assertEquals(refundAmount.subtract(btRefundAmount).abs().floatValue(), benAdjRequest.getAmount().floatValue());
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-875")    
    @ParameterizedTest(
            name = "test_refundInsuranceV3_Given_PaidByBeneficiary_When_KeepService_BT_MoreThan_Matrixx_Then_AddToBeneficiary")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription with no payer. Paid by beneficiary.|"
                +"|When  |Prorated refund with round off error. Braintree refund is more than Matrixx refund. Do Not cancel Insurance service.|"
                +"|Then  |Beneficiary's's mainbalance should be adjusted to add BT refund amount to beneficiary.|"})
    // @formatter:on
    public void test_refundInsuranceV3_Given_PaidByBeneficiary_When_KeepService_BT_MoreThan_Matrixx_Then_AddToBeneficiary(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;

        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "1");
        input.setCancelServices(SUBSCRIBER_SERVICE_CONSTANTS.REFUND_CANCEL_NO);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                Map.of(
                        input.getAtEventGroupList(0).getAtPaymentAuthorizationEventIds(0),
                        CommonTestHelper.getOfferPrice(ciExternalId)));
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);
        BigDecimal refundAmount = BigDecimal.valueOf(5.129876);
        MtxResponseCancel cancelResp = CommonTestHelper.getMtxResponseCancel_Precesion6(refundAmount);
        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        printUnitTest("cancelResp:"+cancelResp.toJson());
        printUnitTest(input.toJson());
        printUnitTest(output.toJson());
        BigDecimal btRefundAmount = new BigDecimal(output.getRefundedAmount());
        argumentCaptor.getAllValues().forEach(multiReq->{
            printUnitTest("multiReq: "+multiReq.toJson());
        });
        // Assertions here.
        ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();
        MtxRequestSubscriberAdjustBalance benAdjRequest = null;
        for(MtxRequest req:reqList) {
            if(MtxRequestSubscriberAdjustBalance.class.getSimpleName().equalsIgnoreCase(req.getContainer().getName())) {
                MtxRequestSubscriberAdjustBalance adjRequest = (MtxRequestSubscriberAdjustBalance) req;
                if(adjRequest.getSubscriberSearchData().getExternalId().equalsIgnoreCase(benExternalId)) {
                    benAdjRequest = adjRequest;
                    break;
                }
            }            
        }
        printUnitTest("benAdjRequest:"+benAdjRequest.toJson());

        assertEquals(MATRIXX_CONSTANTS.BALANCE_ADJUSTMENT_TYPE_CREDIT, benAdjRequest.getAdjustType());
        assertEquals(btRefundAmount.floatValue(), benAdjRequest.getAmount().floatValue());
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-875")
    @ParameterizedTest(
            name = "test_refundInsuranceV3_Given_PaidByBeneficiary_When_NoRoundingError_Then_NoAdjustToBeneficiary")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription with no payer. Paid by beneficiary.|"
                +"|When  |Prorated refund with NO round off error.|"
                +"|Then  |Beneficiary's's mainbalance should NOT be adjusted.|"})
    // @formatter:on
    public void test_refundInsuranceV3_Given_PaidByBeneficiary_When_NoRoundingerror_Then_NoAdjustToBeneficiary(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;

        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "1");
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                Map.of(
                        input.getAtEventGroupList(0).getAtPaymentAuthorizationEventIds(0),
                        CommonTestHelper.getOfferPrice(ciExternalId)));
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);
        BigDecimal refundAmount = BigDecimal.valueOf(5.12);
        MtxResponseCancel cancelResp = CommonTestHelper.getMtxResponseCancel_Precesion2(refundAmount);
        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItem(
                instance, input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        doReturn("").when(instance).getRoute(any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        printUnitTest("cancelResp:"+cancelResp.toJson());
        printUnitTest(input.toJson());
        printUnitTest(output.toJson());

        argumentCaptor.getAllValues().forEach(multiReq->{
            printUnitTest("multiReq: "+multiReq.toJson());
        });
        // Assertions here.
        ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();
        MtxRequestSubscriberAdjustBalance benAdjRequest = null;
        for(MtxRequest req:reqList) {
            if(MtxRequestSubscriberAdjustBalance.class.getSimpleName().equalsIgnoreCase(req.getContainer().getName())) {
                MtxRequestSubscriberAdjustBalance adjRequest = (MtxRequestSubscriberAdjustBalance) req;
                if(adjRequest.getSubscriberSearchData().getExternalId().equalsIgnoreCase(benExternalId)) {
                    benAdjRequest = adjRequest;
                    break;
                }
            }            
        }

        assertNull(benAdjRequest);       
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-875")
    @ParameterizedTest(
            name = "test_refundInsuranceV3_Given_PaidByBeneficiary_When_KeepServices_NoRounding_Then_AdjustToBeneficiary")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription with no payer. Paid by beneficiary.|"
                +"|When  |Prorated refund with NO round off error. do Not Cancel services.|"
                +"|Then  |Beneficiary's's mainbalance should be adjusted to add BT refund amount to beneficiary.|"})
    // @formatter:on
    public void test_refundInsuranceV3_Given_PaidByBeneficiary_When_KeepServices_NoRounding_Then_AdjustToBeneficiary(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String benExternalId = "12345";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;

        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "1");
        input.setCancelServices(SUBSCRIBER_SERVICE_CONSTANTS.REFUND_CANCEL_NO);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                Map.of(
                        input.getAtEventGroupList(0).getAtPaymentAuthorizationEventIds(0),
                        CommonTestHelper.getOfferPrice(ciExternalId)));
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);
        BigDecimal refundAmount = BigDecimal.valueOf(5.12);
        MtxResponseCancel cancelResp = CommonTestHelper.getMtxResponseCancel_Precesion2(refundAmount);
        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        printUnitTest("cancelResp:"+cancelResp.toJson());
        printUnitTest(input.toJson());
        printUnitTest(output.toJson());
        BigDecimal btRefundAmount = new BigDecimal(output.getRefundedAmount());
        argumentCaptor.getAllValues().forEach(multiReq->{
            printUnitTest("multiReq: "+multiReq.toJson());
        });
        // Assertions here.
        ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(0).getRequestList();
        MtxRequestSubscriberAdjustBalance benAdjRequest = null;
        for(MtxRequest req:reqList) {
            if(MtxRequestSubscriberAdjustBalance.class.getSimpleName().equalsIgnoreCase(req.getContainer().getName())) {
                MtxRequestSubscriberAdjustBalance adjRequest = (MtxRequestSubscriberAdjustBalance) req;
                if(adjRequest.getSubscriberSearchData().getExternalId().equalsIgnoreCase(benExternalId)) {
                    benAdjRequest = adjRequest;
                    break;
                }
            }            
        }

        assertEquals(MATRIXX_CONSTANTS.BALANCE_ADJUSTMENT_TYPE_CREDIT, benAdjRequest.getAdjustType());
        assertEquals(btRefundAmount.floatValue(), benAdjRequest.getAmount().floatValue());
       
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-814")
    @Tag("ConnectedAccounts")
    @ParameterizedTest(
            name = "test_refundInsuranceV3_Given_PaidByPayer_When_Prorated_Then_RefundToPayer")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription with a payer. Paid by payer.|"
                +"|When  |Request for prorated refund.|"
                +"|Then  |Pay to payer.|"})
    // @formatter:on
    public void test_refundInsuranceV3_Given_PaidByPayer_When_Prorated_Then_RefundToPayer(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String payExternalId = "67890";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;

        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "1");
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                Map.of(
                        input.getAtEventGroupList(0).getAtPaymentAuthorizationEventIds(0),
                        CommonTestHelper.getOfferPrice(ciExternalId)));
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input, payExternalId);
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);
        MtxResponseCancel cancelResp = CommonTestHelper.getMtxResponseCancel();
        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        emulateMtxResponsePricingCatalogItem(
                instance, input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        doReturn("").when(instance).getRoute(any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        printUnitTest(subscriberEventInfo.toJson());
        printUnitTest(input.toJson());
        printUnitTest(output.toJson());
        // Assertions here.
        ArrayList<MtxRequest> reqList = argumentCaptor.getAllValues().get(1).getRequestList();
        assertEquals(
                MtxRequestSubscriberRefundPayment.class.getSimpleName(),
                reqList.get(0).getMdcName());
        MtxRequestSubscriberRefundPayment refundReq = (MtxRequestSubscriberRefundPayment) reqList.get(
                0);
        assertEquals(payExternalId, refundReq.getSubscriberSearchData().getExternalId());
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-814")
    @Tag("ConnectedAccounts")
    @ParameterizedTest(
            name = "test_refundInsuranceV3_Given_PartiallyPaidByPayer_When_Remorse_Then_RefundToPayerAndBeneficiary")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription with a payer. First month paid by Beneficiary. Second month paid by payer.|"
                +"|When  |Request for remorse refund.|"
                +"|Then  |Pay first month to to beneficiary. Pay second month to payer.|"
                +"|Comments|Requirement under  discussion.|"})
    // @formatter:on
    public void test_refundInsuranceV3_Given_PartiallyPaidByPayer_When_Remorse_Then_RefundToPayerAndBeneficiary(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String payExternalId = "67890";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;

        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "2", 2);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        /***********************************/
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input, payExternalId);
        BigDecimal proratedAmount = CommonTestHelper.getOfferPrice(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId()).divide(
                        BigDecimal.valueOf(2));
        // Alter first recurring event for partial amount
        MtxRecurringEvent resEvent1 = (MtxRecurringEvent) subscriberEventInfo.getAtEventList(
                0).getEventDetails();
        int index = -1;
        for (MtxBalanceUpdate mbu : resEvent1.getBalanceUpdateArray()) {
            index++;
            if (BALANCE_IDS.MAIN_BALANCE == mbu.getBalanceTemplateId().longValue()) {
                mbu.setAmount(proratedAmount);
            }
        }
        resEvent1.getAtChargeList(index).setAmount(proratedAmount);

        // First payment by beneficiary-self
        subscriberEventInfo.getAtEventList(1).getEventDetails().setInitiatorExternalId(
                benExternalId);
        /***********************************/
        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);
        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);
        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        printUnitTest(input.toJson());
        printUnitTest(output.toJson());

        argumentCaptor.getAllValues().forEach(multiReq -> {
            printUnitTest("multiReq:" + multiReq.toJson());
        });
        // Assertions here.
        assertEquals(
                MtxRequestSubscriberRefundPayment.class.getSimpleName(),
                argumentCaptor.getAllValues().get(1).getRequestList().get(0).getMdcName());
        MtxRequestSubscriberRefundPayment refundReq1 = (MtxRequestSubscriberRefundPayment) argumentCaptor.getAllValues().get(
                1).getRequestList().get(0);
        assertEquals(
                MtxRequestSubscriberRefundPayment.class.getSimpleName(),
                argumentCaptor.getAllValues().get(2).getRequestList().get(0).getMdcName());
        MtxRequestSubscriberRefundPayment refundReq2 = (MtxRequestSubscriberRefundPayment) argumentCaptor.getAllValues().get(
                2).getRequestList().get(0);

        MtxRequestSubscriberRefundPayment partialRefundReq = null;
        MtxRequestSubscriberRefundPayment fullRefundReq = null;
        if (proratedAmount.intValue() == refundReq1.getAmount().intValue()) {
            partialRefundReq = refundReq1;
            fullRefundReq = refundReq2;
        } else if (proratedAmount.intValue() == refundReq2.getAmount().intValue()) {
            partialRefundReq = refundReq2;
            fullRefundReq = refundReq1;
        }

        assertEquals(benExternalId, partialRefundReq.getSubscriberSearchData().getExternalId());
        assertEquals(payExternalId, fullRefundReq.getSubscriberSearchData().getExternalId());
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-814")
    @Tag("ConnectedAccounts")
    @ParameterizedTest(
            name = "test_refundInsuranceV3_Given_PartiallyPaidByPayer_When_Remorse_Then_getPaymentHistoryFromBoth")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription with a payer. First month paid by Beneficiary. Second month paid by payer.|"
                +"|When  |Request for remorse refund.|"
                +"|Then  |Get first month PaymentHistory from beneficiary. Get second month PaymentHistory from payer.|"
                +"|Comments|Requirement under  discussion.|"})
    // @formatter:on
    public void test_refundInsuranceV3_Given_PartiallyPaidByPayer_When_Remorse_Then_getPaymentHistoryFromBoth(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String payExternalId = "67890";
        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;

        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "2", 2);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        /***********************************/
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input, payExternalId);
        BigDecimal proratedAmount = CommonTestHelper.getOfferPrice(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId()).divide(
                        BigDecimal.valueOf(2));
        // Alter first recurring event for partial amount
        MtxRecurringEvent resEvent1 = (MtxRecurringEvent) subscriberEventInfo.getAtEventList(
                0).getEventDetails();
        int index = -1;
        for (MtxBalanceUpdate mbu : resEvent1.getBalanceUpdateArray()) {
            index++;
            if (BALANCE_IDS.MAIN_BALANCE == mbu.getBalanceTemplateId().longValue()) {
                mbu.setAmount(proratedAmount);
            }
        }
        resEvent1.getAtChargeList(index).setAmount(proratedAmount);

        // First payment by beneficiary-self
        subscriberEventInfo.getAtEventList(3).getEventDetails().setInitiatorExternalId(
                benExternalId);
        /***********************************/
        MtxResponsePaymentHistory PurHistoryRes1 = CommonTestHelper.getMtxResponsePaymentHistory(
                (MtxPaymentAuthorizationEvent) subscriberEventInfo.getAtEventList(
                        1).getEventDetails());
        MtxResponsePaymentHistory PurHistoryRes2 = CommonTestHelper.getMtxResponsePaymentHistory(
                (MtxPaymentAuthorizationEvent) subscriberEventInfo.getAtEventList(
                        3).getEventDetails());

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);
        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        when(api.multi(any())).thenReturn(multiRes);

        ArgumentCaptor<MtxSubscriberSearchData> argumentCaptor = ArgumentCaptor.forClass(
                MtxSubscriberSearchData.class);
        doReturn(PurHistoryRes1).doReturn(PurHistoryRes2).when(
                instance).querySubscriberPaymentHistory(any(), any(), argumentCaptor.capture());

        // method to test
        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        printUnitTest(input.toJson());
        printUnitTest(output.toJson());

        boolean beneficiaryPaymentHistoryRequested = false;
        boolean payerPaymentHistoryRequested = false;

        for (MtxSubscriberSearchData searchData : argumentCaptor.getAllValues()) {
            printUnitTest("searchData:" + searchData.toJson());
            if (benExternalId.equalsIgnoreCase(searchData.getExternalId())) {
                beneficiaryPaymentHistoryRequested = true;
            } else if (payExternalId.equalsIgnoreCase(searchData.getExternalId())) {
                payerPaymentHistoryRequested = true;
            }
        }
        ;

        // Assertions here.
        assertTrue(beneficiaryPaymentHistoryRequested);
        assertTrue(payerPaymentHistoryRequested);
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-814")
    @Tag("ConnectedAccounts")
    @ParameterizedTest(
            name = "test_refundDefaultV3_Given_PaidByMultiplePeople_Then_RefundToOriginalPayer")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with a payer. First month paid by Beneficiary. Paid by multiple payers next months.|"
       +"|When  |Request for multimonth refund.|"
       +"|Then  |Pay first month to to beneficiary. Pay second and third month to payers.|"})
    // @formatter:on
    public void test_refundDefaultV3_Given_PaidByMultiplePeople_Then_RefundToOriginalPayer(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String benExternalId = "12345";
        String payExternalId1 = "67890";
        String payExternalId2 = "98760";

        long benPayInfoResourceId = 111L;
        long pay1PayInfoResourceId = 222L;
        long pay2PayInfoResourceId = 333L;

        // For ease of testing keep amounts different for each month.
        BigDecimal firstMonthAmount = BigDecimal.ONE; // Say this is partial
        BigDecimal secondMonthAmount = BigDecimal.TEN; // Say this is signup price
        BigDecimal thirdMonthAmount = BigDecimal.valueOf(11); // Say price hike

        String ciExternalId = CI_EXTERNAL_IDS.INSURANCE;

        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                benExternalId, ciExternalId, "2", 3);
        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        /***********************************/
        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input, payExternalId2);

        // Alter first recurring event for partial amount
        MtxRecurringEvent firstMonthRecEvent = (MtxRecurringEvent) subscriberEventInfo.getAtEventList(
                0).getEventDetails();
        int index = -1;
        for (MtxBalanceUpdate mbu : firstMonthRecEvent.getBalanceUpdateArray()) {
            index++;
            if (BALANCE_IDS.MAIN_BALANCE == mbu.getBalanceTemplateId().longValue()) {
                mbu.setAmount(firstMonthAmount);
            }
        }
        firstMonthRecEvent.getAtChargeList(index).setAmount(firstMonthAmount);

        MtxRecurringEvent secondMonthRecEvent = (MtxRecurringEvent) subscriberEventInfo.getAtEventList(
                2).getEventDetails();
        index = -1;
        for (MtxBalanceUpdate mbu : secondMonthRecEvent.getBalanceUpdateArray()) {
            index++;
            if (BALANCE_IDS.MAIN_BALANCE == mbu.getBalanceTemplateId().longValue()) {
                mbu.setAmount(secondMonthAmount);
            }
        }
        secondMonthRecEvent.getAtChargeList(index).setAmount(secondMonthAmount);

        MtxRecurringEvent thirdMonthRecEvent = (MtxRecurringEvent) subscriberEventInfo.getAtEventList(
                4).getEventDetails();
        index = -1;
        for (MtxBalanceUpdate mbu : thirdMonthRecEvent.getBalanceUpdateArray()) {
            index++;
            if (BALANCE_IDS.MAIN_BALANCE == mbu.getBalanceTemplateId().longValue()) {
                mbu.setAmount(thirdMonthAmount);
            }
        }
        thirdMonthRecEvent.getAtChargeList(index).setAmount(thirdMonthAmount);

        MtxPaymentAuthorizationEvent firstMonthAuthEvent = (MtxPaymentAuthorizationEvent) subscriberEventInfo.getAtEventList(
                1).getEventDetails();
        MtxPaymentAuthorizationEvent secondMonthAuthEvent = (MtxPaymentAuthorizationEvent) subscriberEventInfo.getAtEventList(
                3).getEventDetails();
        MtxPaymentAuthorizationEvent thirdMonthAuthEvent = (MtxPaymentAuthorizationEvent) subscriberEventInfo.getAtEventList(
                5).getEventDetails();
        // First payment by beneficiary-self
        firstMonthAuthEvent.setInitiatorExternalId(benExternalId);
        // Second payment by payer-1
        secondMonthAuthEvent.setInitiatorExternalId(payExternalId1);
        // Third payment by payer-2
        thirdMonthAuthEvent.setInitiatorExternalId(payExternalId2);
        /***********************************/

        /* +++++++++++++++++++++++++++++++++ */
        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);
        PurHistoryRes.getPaymentInfoList().stream().filter(
                pi -> firstMonthAuthEvent.getEventId().equalsIgnoreCase(
                        pi.getAuthorizationEventId())).findAny().get().setResourceId(
                                benPayInfoResourceId);
        PurHistoryRes.getPaymentInfoList().stream().filter(
                pi -> firstMonthAuthEvent.getEventId().equalsIgnoreCase(
                        pi.getAuthorizationEventId())).findAny().get().setAuthorizationAmount(
                                firstMonthAmount);

        PurHistoryRes.getPaymentInfoList().stream().filter(
                pi -> secondMonthAuthEvent.getEventId().equalsIgnoreCase(
                        pi.getAuthorizationEventId())).findAny().get().setResourceId(
                                pay1PayInfoResourceId);
        PurHistoryRes.getPaymentInfoList().stream().filter(
                pi -> secondMonthAuthEvent.getEventId().equalsIgnoreCase(
                        pi.getAuthorizationEventId())).findAny().get().setAuthorizationAmount(
                                secondMonthAmount);

        PurHistoryRes.getPaymentInfoList().stream().filter(
                pi -> thirdMonthAuthEvent.getEventId().equalsIgnoreCase(
                        pi.getAuthorizationEventId())).findAny().get().setResourceId(
                                pay2PayInfoResourceId);
        PurHistoryRes.getPaymentInfoList().stream().filter(
                pi -> thirdMonthAuthEvent.getEventId().equalsIgnoreCase(
                        pi.getAuthorizationEventId())).findAny().get().setAuthorizationAmount(
                                thirdMonthAmount);
        /* +++++++++++++++++++++++++++++++++ */

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);
        VisibleResponseRefundService output = new VisibleResponseRefundService();

        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));
        doReturn("").when(instance).getRoute(any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());

        // Capture Arguements for multirequest
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(argumentCaptor.capture())).thenReturn(multiRes);

        // method to test
        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                    taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        printUnitTest("input: " + input.toJson());
        printUnitTest("output: " + output.toJson());

        argumentCaptor.getAllValues().forEach(multiReq -> {
            printUnitTest("multiReq:" + multiReq.toJson());
        });
        // Assertions here.
        MtxRequestSubscriberRefundPayment firstMonthRefundReq = null;
        MtxRequestSubscriberRefundPayment secondMonthRefundReq = null;
        MtxRequestSubscriberRefundPayment thirdMonthRefundReq = null;

        for (int j = 1; j < 4; j++) {
            MtxRequestSubscriberRefundPayment refundReq = (MtxRequestSubscriberRefundPayment) argumentCaptor.getAllValues().get(
                    j).getRequestList().get(0);
            if (firstMonthAmount.intValue() == refundReq.getAmount().intValue()) {
                firstMonthRefundReq = refundReq;
            } else if (secondMonthAmount.intValue() == refundReq.getAmount().intValue()) {
                secondMonthRefundReq = refundReq;
            } else if (thirdMonthAmount.intValue() == refundReq.getAmount().intValue()) {
                thirdMonthRefundReq = refundReq;
            }
        }

        assertEquals(benExternalId, firstMonthRefundReq.getSubscriberSearchData().getExternalId());
        assertEquals(
                payExternalId1, secondMonthRefundReq.getSubscriberSearchData().getExternalId());
        assertEquals(payExternalId2, thirdMonthRefundReq.getSubscriberSearchData().getExternalId());

        assertEquals(benPayInfoResourceId, firstMonthRefundReq.getResourceId());
        assertEquals(pay1PayInfoResourceId, secondMonthRefundReq.getResourceId());
        assertEquals(pay2PayInfoResourceId, thirdMonthRefundReq.getResourceId());
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-863")
    @ParameterizedTest(
            name = "test_refundServiceInsuranceV2_When_InuranceNoBundle_Then_ModifyOfferPresent")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Visible_Wearable_Insurance_CI. CI is based on single offer and is not in a bundle.|"
       +"|When  |Refund success.|"
       +"|Then  |Modify offer request withh taxes should run.|"
       +"|Coments|Attributes are read from recurring events. In case of non-bundled ci, it should be read from AppliedOfferArray. Which will then be used in creating modify offer request. |"})
    // @formatter:on
    public void test_refundServiceInsuranceV2_When_InuranceNoBundle_Then_ModifyOfferPresent(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                "1234", CI_EXTERNAL_IDS.WEARABLE_INSURANCE, "1", 1);

        VisibleResponseRefundService output = new VisibleResponseRefundService();

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);

        System.out.println(
                testInfo.getDisplayName() + ": subscriberEventInfo: "
                        + subscriberEventInfo.toJson());

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        MtxResponseCancel cancelResp = CommonTestHelper.getMtxResponseCancel();

        MtxResponsePricingOffer pricingOffer = CommonTestHelper.getMtxResponsePricingOffer(
                CI_EXTERNAL_IDS.DEVICE_INSURANCE);

        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));

        doReturn("").when(instance).getRoute(any());
        doReturn(pricingOffer).when(instance).queryPricingOffer(any(), any(), any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());

        ArgumentCaptor<MtxRequestMulti> argumentCaptorMulti = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptorMulti.capture())).thenReturn(multiRes);

        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        System.out.println(testInfo.getDisplayName() + ": InputRequest: " + input.toJson());
        System.out.println(testInfo.getDisplayName() + ": output: " + output.toJson());
        System.out.println(
                testInfo.getDisplayName() + ": multireq: "
                        + argumentCaptorMulti.getAllValues().get(0).toJson());
        MtxRequest req = argumentCaptorMulti.getAllValues().get(0).getAtRequestList(1);

        System.out.println(testInfo.getDisplayName() + ": req: " + req.toJson());
        MtxRequestSubscriberModifyOffer modReq = new MtxRequestSubscriberModifyOffer(req);
        assertEquals(
                VisiblePurchasedOfferExtension.class.getSimpleName(),
                modReq.getAttr().getMdcName());
    }

    @SuppressWarnings("unchecked")
    @Tag("VER-875")
    @ParameterizedTest(
            name = "test_refundServiceInsuranceV2_When_NoAocBalanceImpact_Then_ZeroRefund")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
        "|Given |Subscription with Visible_Wearable_Insurance_CI.|"
       +"|When  |Refund requested on last day of bill cycle. Aoc Cancellation does not return any balance impact.|"
       +"|Then  |Refund should complete for zero dollars.|"
       +"|Coments|Aoc response depends on pricing. |"})
    // @formatter:on
    public void test_refundServiceInsuranceV2_When_NoAocBalanceImpact_Then_ZeroRefund(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestRefundService input = CommonTestHelper.getRefundServiceRequest(
                "1234", CI_EXTERNAL_IDS.WEARABLE_INSURANCE, "1", 1);

        VisibleResponseRefundService output = new VisibleResponseRefundService();

        MtxResponseMulti multiRes = CommonTestHelper.getEmptyMtxResponseMulti();
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());
        multiRes.getResponseListAppender().add(CommonTestHelper.getOkMtxResponse());

        EventQueryResponseEvents subscriberEventInfo = CommonTestHelper.getRefundServiceEvents(
                input);

        System.out.println(
                testInfo.getDisplayName() + ": subscriberEventInfo: "
                        + subscriberEventInfo.toJson());

        MtxResponsePaymentHistory PurHistoryRes = CommonTestHelper.getMtxResponsePaymentHistory(
                subscriberEventInfo);

        MtxResponseCancel cancelResp = CommonTestHelper.getMtxResponseCancel_NoBalanceImact();

        // mocks
        emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(BigDecimal.ZERO));

        doReturn("").when(instance).getRoute(any());
        doReturn(cancelResp).when(instance).doSubscriberCancelOfferAOC(
                any(), any(), ArgumentMatchers.anyLong(), ArgumentMatchers.anyLong(), any());
        doReturn(PurHistoryRes).when(instance).querySubscriberPaymentHistory(any(), any(), any());
        doReturn(subscriberEventInfo).when(instance).queryEventListByEventIds(any(), any(), any());

        ArgumentCaptor<MtxRequestMulti> argumentCaptorMulti = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        when(api.multi(any(), argumentCaptorMulti.capture())).thenReturn(multiRes);

        String taxApiResp2 = CommonTestHelper.getTaxApiResp(
                input.getRefundServiceOrderInfo().getServiceOfferExternalId());

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), any())).thenReturn(
                            taxApiResp2);
            // method to test
            instance.refundService(input, output);
        }
        System.out.println(testInfo.getDisplayName() + ": InputRequest: " + input.toJson());
        System.out.println(testInfo.getDisplayName() + ": output: " + output.toJson());
        assertEquals(RESULT_CODES.MTX_SUCCESS, output.getResult());
        assertEquals(BigDecimal.ZERO.floatValue(), (new BigDecimal(output.getRefundedAmount()).floatValue()));
    }

    private void printUnitTest(Object msg) {
        System.out.println(testInfo.getDisplayName() + ":" + msg);
    }

}
