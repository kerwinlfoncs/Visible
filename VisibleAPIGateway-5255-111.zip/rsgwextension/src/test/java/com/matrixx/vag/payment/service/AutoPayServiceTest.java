package com.matrixx.vag.payment.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.lang3.StringUtils;
import org.gradle.internal.impldep.org.joda.time.LocalDate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.test.util.ReflectionTestUtils;

import com.matrixx.datacontainer.MtxDate;
import com.matrixx.datacontainer.MtxObjectId;
import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.MtxPaymentMethodInfo;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferData;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.MtxRequest;
import com.matrixx.datacontainer.mdc.MtxRequestMulti;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberModifyOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberPurchaseOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberRecharge;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriptionModify;
import com.matrixx.datacontainer.mdc.MtxResponse;
import com.matrixx.datacontainer.mdc.MtxResponseMulti;
import com.matrixx.datacontainer.mdc.MtxResponsePaymentMethodInfo;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.MtxResponseUser;
import com.matrixx.datacontainer.mdc.SubscriptionResponse;
import com.matrixx.datacontainer.mdc.VisibleBraintreeChargeMethodExtension;
import com.matrixx.datacontainer.mdc.VisibleCredits;
import com.matrixx.datacontainer.mdc.VisibleGroup;
import com.matrixx.datacontainer.mdc.VisibleOfferDetails;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleRechargeExtension;
import com.matrixx.datacontainer.mdc.VisibleRequestAutoPay;
import com.matrixx.datacontainer.mdc.VisibleResponseAutoPay;
import com.matrixx.datacontainer.mdc.VisibleResponsePaymentAdviceService;
import com.matrixx.datacontainer.mdc.VisibleSubscriberDevice;
import com.matrixx.datacontainer.mdc.VisibleSubscriberExtension;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.advice.service.PaymentAdviceService;
import com.matrixx.vag.amq.client.ActiveMQClient;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.AUTOPAY_CONSTANTS;
import com.matrixx.vag.common.Constants.AUTOPAY_MESSAGES;
import com.matrixx.vag.common.Constants.CHANGE_SERVICE_CONSTANTS;
import com.matrixx.vag.common.Constants.DEVICE_CONSTANTS;
import com.matrixx.vag.common.Constants.NOTIFICATION_CONSTANTS;
import com.matrixx.vag.common.Constants.OFFER_CONSTANTS;
import com.matrixx.vag.common.Constants.PAYMENT_CONSTANTS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.Constants.SUBSCRIPTION_CONSTANTS;
import com.matrixx.vag.common.OneParameterTest;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestConstants.DATA_DIR;
import com.matrixx.vag.common.TestConstants.DATE_TIME_CONSTANTS;
import com.matrixx.vag.common.TestConstants.OFFER_PRICES;
import com.matrixx.vag.common.TestUtils;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.MissingRequestParametersException;
import com.matrixx.vag.exception.PaymentAdviceException;
import com.matrixx.vag.util.MDCTest;

public class AutoPayServiceTest extends MDCTest {

    @Spy
    @InjectMocks
    private AutoPayService instance = new AutoPayService();

    @Mock
    private SubscriberManagementApi api;

    PaymentAdviceService adviceInstance = null;
    private TestInfo testInfo;

    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        instance = new AutoPayService();
        adviceInstance = Mockito.spy(new PaymentAdviceService());
        ReflectionTestUtils.setField(instance, "paymentAdviceService", adviceInstance);
        MockitoAnnotations.openMocks(this);
        this.testInfo = testInfo;
        doReturn("").when(instance).getRoute(any());
        AppPropertyProvider.getInstance().setProperty(
                AUTOPAY_CONSTANTS.PROP_DELTA_HOURS, AUTOPAY_CONSTANTS.DELTA_HOURS_DEFAULT);
        AppPropertyProvider.getInstance().setProperty(
                AUTOPAY_CONSTANTS.PROP_RETRY_WAIT_HOURS,
                AUTOPAY_CONSTANTS.RETRY_WAIT_HOURS_DEFAULT);
    }

    @Test
    public void test_autoPay_When_No_SubscriptionExternalId_Then_Exception(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Null"
        };
        td.when = new String[] {
            "Api is called with no SubscriptionExternalId."
        };
        td.then = new String[] {
            "Exception."
        };
        td.printDescription();

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        Exception exception = assertThrows(
                MissingRequestParametersException.class, () -> instance.autoPay(request, response));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();

        assertThat(exception.getMessage()).contains("SubscriptionExternalId");
    }

    @SuppressWarnings("rawtypes")
    @ParameterizedTest(name = "test_autoPay_When_No_PaymentMethods_Then_Exception")
    @Tag("VER-803")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription with no payment methods.|"
                +"|When |Api is called for subscription.|"
                +"|Then |Exception.|"})
    // @formatter:on
    public void test_autoPay_When_No_PaymentMethods_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance, CommonTestHelper.getSubscriptionResponseAutopay(
                        List.of(CI_EXTERNAL_IDS.PRO25), null));
        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);

        emulateMtxResponsePaymentMethodInfo(instance, (MtxPaymentMethodInfo) null);

        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setEstimatedPayableAmount(BigDecimal.ZERO);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        instance.autoPay(request, response);
        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(
                RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult().longValue());
        assertThat(response.getResultText()).contains(
                AUTOPAY_MESSAGES.NO_PAYMENT_METHODS_ERROR_265);
    }

    @SuppressWarnings("rawtypes")
    @ParameterizedTest(name = "test_autoPay_When_Unsuccessful_ReadPaymentMethods_Then_Exception")
    @Tag("VER-803")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Autopay Subscription ..|"
                +"|When  |Api is called for subscription. Payment methods could not be retrieved.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    public void test_autoPay_When_Unsuccessful_ReadPaymentMethods_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance, CommonTestHelper.getSubscriptionResponseAutopay(
                        List.of(CI_EXTERNAL_IDS.PRO25), null));
        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);

        MtxResponsePaymentMethodInfo rpmi = emulateMtxResponsePaymentMethodInfo(
                instance, (MtxPaymentMethodInfo) null);
        rpmi.setResult(RESULT_CODES.MTX_NOT_FOUND);

        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setEstimatedPayableAmount(BigDecimal.ZERO);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        instance.autoPay(request, response);
        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(
                RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult().longValue());
        assertThat(response.getResultText()).contains(
                AUTOPAY_MESSAGES.READ_PAYMENT_METHODS_ERROR_264);
    }

    @SuppressWarnings("rawtypes")
    @ParameterizedTest(name = "test_autoPay_When_No_DefaultPaymentMethod_Then_Exception")
    @Tag("VER-803")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has no default payment method.|"
                +"|When  |Api is called for subscription.|"
                +"|Then  |Exception.|"})
    // @formatter:on
    public void test_autoPay_When_No_DefaultPaymentMethod_Then_Exception(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance, CommonTestHelper.getSubscriptionResponseAutopay(
                        List.of(CI_EXTERNAL_IDS.PRO25), null));
        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        System.out.println(subscription.toJson());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getNonDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        BigDecimal recAmount = BigDecimal.ONE;
        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setEstimatedPayableAmount(recAmount);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        instance.autoPay(request, response);
        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(
                RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult().longValue());
        assertThat(response.getResultText()).contains(
                AUTOPAY_MESSAGES.NO_DEFAULT_PAYMENT_METHOD_ERROR_266);
    }

    @Test
    public void test_autoPay_When_No_Attr_Then_Exception(TestInfo testInfo) throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with no attributes. "
        };
        td.when = new String[] {
            "Api is called for subscription."
        };
        td.then = new String[] {
            "Exception."
        };
        td.printDescription();

        MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                api, CommonTestHelper.getEmptySubscriptionResponse_NoAttributes());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        instance.autoPay(request, response);
        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(
                RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult().longValue());
        assertThat(response.getResultText()).contains(
                AUTOPAY_MESSAGES.NO_SUBSCRIPTION_ATTR_ERROR_267);
    }

    @Test
    public void test_autoPay_When_No_PaymentPreference_Then_Exception(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with attributes. But has no payment preference."
        };
        td.when = new String[] {
            "Api is called for subscription."
        };
        td.then = new String[] {
            "Exception."
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED)));
        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference("");
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        instance.autoPay(request, response);
        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(
                RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult().longValue());
        assertThat(response.getResultText()).contains(AUTOPAY_MESSAGES.NO_PAYMENT_PREFERENCE_268);
    }

    @Test
    public void test_autoPay_When_Preference_is_ManualPay_Then_Exception(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription with Manual Pay as payment preference."
        };
        td.when = new String[] {
            "Api is called for subscription."
        };
        td.then = new String[] {
            "Skip subscriber."
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance, CommonTestHelper.getEmptySubscriptionResponse());
        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.MANUALPAY);
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        instance.autoPay(request, response);
        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(RESULT_CODES.AUTOPAY_SKIP_SUB, response.getResult().longValue());
        assertThat(response.getResultText()).contains(AUTOPAY_MESSAGES.MANUAL_PAY_SUBSCRIPTION_269);
    }

    @Test
    public void test_autoPay_When_No_WalletHasNoEndTime_Then_Exception(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription."
        };
        td.when = new String[] {
            "Api is called for subscription. Wallet does not have bill cycle details."
        };
        td.then = new String[] {
            "Exception."
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance, CommonTestHelper.getEmptySubscriptionResponse());
        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.getBillingCycle().setCurrentPeriodEndTime(null);
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        instance.autoPay(request, response);
        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(
                RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult().longValue());
        assertThat(response.getResultText()).contains(AUTOPAY_MESSAGES.SUBSCRIPTION_DATA_ERROR_280);
    }

    @Test
    public void test_autoPay_When_Subscription_not_Active_not_paused_Then_Error(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription is Active."
        };
        td.when = new String[] {
            "Api is called for subscription."
        };
        td.then = new String[] {
            "STATUS_NOT_ACTIVE_PAUSE_271 error."
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance, CommonTestHelper.getEmptySubscriptionResponse());
        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_LAPSE);
        CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscription, CI_EXTERNAL_IDS.UNLIMITED);
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        instance.autoPay(request, response);
        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(RESULT_CODES.AUTOPAY_SKIP_SUB, response.getResult().longValue());
        assertThat(response.getResultText()).contains(AUTOPAY_MESSAGES.STATUS_NOT_ACTIVE_PAUSE_271);
    }

    @Test
    public void test_autoPay_When_RechargeWindowNotReached_Then_Error(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription. Recharge window not reached"
        };
        td.when = new String[] {
            "Api is called for subscription."
        };
        td.then = new String[] {
            "error."
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED)));
        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(
                new MtxTimestamp(
                        System.currentTimeMillis()
                                + DATE_TIME_CONSTANTS.MILLISECONDS_IN_A_DAY * 2));
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        instance.autoPay(request, response);
        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(RESULT_CODES.AUTOPAY_SKIP_SUB, response.getResult().longValue());
        assertThat(response.getResultText()).contains(
                AUTOPAY_MESSAGES.RECHARGE_WINDOW_NOT_REACHED_273);
    }

    @Test
    public void test_autoPay_When_Subscription_Terminated_Then_Error(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription is Terminated. Termination date is before endtime / first of next bill cycle."
        };
        td.when = new String[] {
            "Api is called for subscription."
        };
        td.then = new String[] {
            "error."
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance, CommonTestHelper.getEmptySubscriptionResponse());
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);
        System.out.println(endTime);
        MtxTimestamp beforeEndTime = endTime.minusMilli(2);

        System.out.println(endTime);

        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        ZonedDateTime terminateDate = CommonUtils.getZonedDateTimeFromMtxTimestamp(
                beforeEndTime, subscription.getTimeZone());
        extn.setTerminateDate(terminateDate.toString());
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);

        CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscription, CI_EXTERNAL_IDS.UNLIMITED);
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        instance.autoPay(request, response);
        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(RESULT_CODES.AUTOPAY_SKIP_SUB, response.getResult().longValue());
        assertThat(response.getResultText()).contains(AUTOPAY_MESSAGES.TERMINATION_DATE_277);
    }

    @Test
    public void test_autoPay_When_Subscription_Payment_Already_Done_Then_Skip(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription has already been paid for."
        };
        td.when = new String[] {
            "Api is called for subscription."
        };
        td.then = new String[] {
            "skip payment."
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED)));
        int deltaHours = AppPropertyProvider.getInstance().getInt(
                AUTOPAY_CONSTANTS.PROP_DELTA_HOURS);
        MtxTimestamp endTimeSameAsPaymentDate = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), deltaHours);
        MtxTimestamp activationTimePlusDeltaAfterEndTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 1);
        if (subscription.getAtPurchasedOfferArray(0) != null) {
            subscription.getAtPurchasedOfferArray(0).setActivationTime(
                    activationTimePlusDeltaAfterEndTime);
        }
        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        extn.setPaymentDate(endTimeSameAsPaymentDate);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTimeSameAsPaymentDate);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        instance.autoPay(request, response);
        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(RESULT_CODES.AUTOPAY_SKIP_SUB, response.getResult().longValue());
        assertThat(response.getResultText()).contains(AUTOPAY_MESSAGES.RECHARGE_ALREADY_DONE_274);
    }

    @Test
    public void test_autoPay_When_Subscription_In_Retry_Period_Then_Skip(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription is in retry period."
        };
        td.when = new String[] {
            "Api is called for subscription."
        };
        td.then = new String[] {
            "skip payment."
        };
        td.printDescription();
        AppPropertyProvider.getInstance().setProperty(AUTOPAY_CONSTANTS.PROP_DELTA_HOURS, 72);
        long currentMillis = System.currentTimeMillis();

        MtxTimestamp paymentRetry = new MtxTimestamp(
                currentMillis + DATE_TIME_CONSTANTS.MILLISECONDS_IN_A_DAY * 2);
        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED)));
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);

        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        extn.setPaymentRetry(paymentRetry.toString());
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        instance.autoPay(request, response);
        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(RESULT_CODES.AUTOPAY_SKIP_SUB, response.getResult().longValue());
        assertThat(response.getResultText()).contains(AUTOPAY_MESSAGES.IN_RETRY_PERIOD_275);
    }

    @Test
    public void test_autoPay_When_PaymentAdviceErrorThrown_Then_Exception(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Active Subscription."
        };
        td.when = new String[] {
            "Api is called for subscription. PaymentAdvice error thrown"
        };
        td.then = new String[] {
            "Error."
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED)));
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);

        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        doThrow(
                new PaymentAdviceException(
                        RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, "Test Exception.")).when(
                                adviceInstance).getAOP(any(), any());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        instance.autoPay(request, response);
        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(
                RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult().longValue());
        assertThat(response.getResultText()).contains(AUTOPAY_MESSAGES.PAYMENT_ADVICE_ERROR_301);
        assertThat(response.getResultText()).contains(AUTOPAY_MESSAGES.PAYMENT_ADVICE_FAILED_279);
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void test_autoPay_When_PaymentAdviceErrorReturned_Then_Exception(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Active Subscription."
        };
        td.when = new String[] {
            "Api is called for subscription. PaymentAdvice error returned."
        };
        td.then = new String[] {
            "Error."
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED)));
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);

        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
                aop.setResultText("Test Error.");
                return null;
            }
        }).when(adviceInstance).getAOP(any(), any());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        instance.autoPay(request, response);
        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(
                RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult().longValue());
        assertThat(response.getResultText()).contains(AUTOPAY_MESSAGES.PAYMENT_ADVICE_ERROR_301);
        assertThat(response.getResultText()).contains(AUTOPAY_MESSAGES.PAYMENT_ADVICE_FAILED_279);
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void test_autoPay_When_autoPay_complete_Then_update_paymentdate(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription is Active. "
        };
        td.when = new String[] {
            "Autopay is complete."
        };
        td.then = new String[] {
            "update paymentdate."
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED)));
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);

        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());

        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setEstimatedPayableAmount(BigDecimal.ZERO);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS, response.getResult().longValue());

        argumentCaptor.getAllValues().forEach(multi -> {
            System.out.println(multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        boolean foundModifyReq = false;
        MtxRequestSubscriptionModify subModify = null;
        for (MtxRequest req : multiReq.getRequestList()) {
            foundModifyReq = req.getMdcName().equalsIgnoreCase(
                    MtxRequestSubscriptionModify.class.getSimpleName());
            if (foundModifyReq) {
                subModify = (MtxRequestSubscriptionModify) req;
                break;
            }
        }
        assertTrue(foundModifyReq);

        VisibleSubscriberExtension attr = (VisibleSubscriberExtension) subModify.getAttr();
        assertEquals(
                subscription.getBillingCycle().getCurrentPeriodEndTime().toString(),
                attr.getPaymentDate().toString());
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void test_autoPay_When_Advice_For_No_Recharge_Then_MultiRequest_Has_No_Recharge(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Active Subscription."
        };
        td.when = new String[] {
            "Api is called for subscription. PaymentAdvice is to recharge zero amount."
        };
        td.then = new String[] {
            "Final multirequest should NOT have a recharge request."
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED)));
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);
        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setEstimatedPayableAmount(BigDecimal.ZERO);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        argumentCaptor.getAllValues().forEach(multi -> {
            System.out.println(multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        boolean foundRechReq = false;
        for (MtxRequest req : multiReq.getRequestList()) {
            foundRechReq = req.getMdcName().equalsIgnoreCase(
                    MtxRequestSubscriberRecharge.class.getSimpleName());
            if (foundRechReq)
                break;
        }

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS, response.getResult().longValue());
        assertFalse(foundRechReq);
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void test_autoPay_When_Advice_For_Recharge_Then_MultiRequest_Has_Recharge(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Active Subscription."
        };
        td.when = new String[] {
            "Api is called for subscription. PaymentAdvice is to recharge nonzero amount."
        };
        td.then = new String[] {
            "Final multirequest should have a recharge request. Recharge amount should be correct."
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED)));
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);

        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        BigDecimal recAmount = BigDecimal.ONE;
        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setEstimatedPayableAmount(recAmount);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS, response.getResult().longValue());

        argumentCaptor.getAllValues().forEach(multi -> {
            System.out.println(multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        boolean foundRechReq = false;
        MtxRequestSubscriberRecharge rechReq = null;
        for (MtxRequest req : multiReq.getRequestList()) {
            foundRechReq = req.getMdcName().equalsIgnoreCase(
                    MtxRequestSubscriberRecharge.class.getSimpleName());
            if (foundRechReq) {
                rechReq = (MtxRequestSubscriberRecharge) req;
                break;
            }
        }
        assertTrue(foundRechReq);
        assertEquals(recAmount.doubleValue(), rechReq.getAmount().doubleValue(), 0.001);
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void test_autoPay_When_Advice_For_Recharge_Then_verify_braintree_atributes(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Active Subscription."
        };
        td.when = new String[] {
            "Api is called for subscription. PaymentAdvice is to recharge nonzero amount."
        };
        td.then = new String[] {
            "Final recharge request should have correct braintree attributes."
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED)));
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);

        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        BigDecimal recAmount = BigDecimal.ONE;

        VisibleSubscriberDevice svcDev = new VisibleSubscriberDevice();
        svcDev.setAccessNumber("SVC-1");
        svcDev.setDeviceType(DEVICE_CONSTANTS.DEVICE_TYPE_SERVICE);

        VisibleSubscriberDevice wblDev = new VisibleSubscriberDevice();
        wblDev.setAccessNumber("WBL-1");
        wblDev.setDeviceType(DEVICE_CONSTANTS.DEVICE_TYPE_WEARABLE);
        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setEstimatedPayableAmount(recAmount);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }
        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS, response.getResult().longValue());

        argumentCaptor.getAllValues().forEach(multi -> {
            System.out.println(multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        boolean foundRechReq = false;
        MtxRequestSubscriberRecharge rechReq = null;
        for (MtxRequest req : multiReq.getRequestList()) {
            foundRechReq = req.getMdcName().equalsIgnoreCase(
                    MtxRequestSubscriberRecharge.class.getSimpleName());
            if (foundRechReq) {
                rechReq = (MtxRequestSubscriberRecharge) req;
                break;
            }
        }
        VisibleBraintreeChargeMethodExtension btAttr = (VisibleBraintreeChargeMethodExtension) rechReq.getChargeMethodData().getChargeMethodAttr();
        assertTrue(StringUtils.isNotBlank(btAttr.getOrderId()));
        assertEquals(AUTOPAY_CONSTANTS.TRANSACTION_TYPE, btAttr.getTransactionType());
        assertEquals(false, btAttr.getVisibleRecurringOverride());
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void test_autoPay_When_Advice_For_Recharge_Then_verify_recharge_atributes(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Active Subscription."
        };
        td.when = new String[] {
            "Api is called for subscription. PaymentAdvice is to recharge nonzero amount."
        };
        td.then = new String[] {
            "Final recharge request should have correct attributes."
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance, CommonTestHelper.getEmptySubscriptionResponse());
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);

        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscription, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        BigDecimal recAmount = BigDecimal.ONE;

        VisibleSubscriberDevice svcDev = new VisibleSubscriberDevice();
        svcDev.setAccessNumber("SVC-1");
        svcDev.setDeviceType(DEVICE_CONSTANTS.DEVICE_TYPE_SERVICE);

        VisibleSubscriberDevice wblDev = new VisibleSubscriberDevice();
        wblDev.setAccessNumber("WBL-1");
        wblDev.setDeviceType(DEVICE_CONSTANTS.DEVICE_TYPE_WEARABLE);

        VisibleOfferDetails vodSvc = CommonTestHelper.loadJsonMessage(
                VisibleOfferDetails.class,
                DATA_DIR.CHANGE_SERVICE_ADVICE + "VisibleOfferDetails_Unlimited.json");
        VisibleOfferDetails vodWbl = CommonTestHelper.loadJsonMessage(
                VisibleOfferDetails.class,
                DATA_DIR.CHANGE_SERVICE_ADVICE + "VisibleOfferDetails_Wearable.json");
        doAnswer(new Answer() {

            @SuppressWarnings("unchecked")
            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setSubscriberExternalId(subscription.getExternalId());
                aop.setEstimatedPayableAmount(recAmount);
                aop.getSubscriberDevicesAppender().add(svcDev);
                aop.getSubscriberDevicesAppender().add(wblDev);
                aop.getVisibleOfferDetailsListAppender().add(vodSvc);
                aop.getVisibleOfferDetailsListAppender().add(vodWbl);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }
        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS, response.getResult().longValue());

        argumentCaptor.getAllValues().forEach(multi -> {
            System.out.println(multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        boolean foundRechReq = false;
        MtxRequestSubscriberRecharge rechReq = null;
        for (MtxRequest req : multiReq.getRequestList()) {
            foundRechReq = req.getMdcName().equalsIgnoreCase(
                    MtxRequestSubscriberRecharge.class.getSimpleName());
            if (foundRechReq) {
                rechReq = (MtxRequestSubscriberRecharge) req;
                break;
            }
        }
        assertTrue(foundRechReq);
        assertTrue(rechReq.getPayNow());
        assertEquals(recAmount.doubleValue(), rechReq.getAmount().doubleValue(), 0.001);
        assertEquals(AUTOPAY_CONSTANTS.RECHARGE_REASON, rechReq.getReason());

        VisibleRechargeExtension rechAttr = (VisibleRechargeExtension) rechReq.getRechargeAttr();
        assertTrue(StringUtils.isNotBlank(rechAttr.getOrderId()));
        assertEquals(svcDev.getAccessNumber(), rechAttr.getServiceMDN());
        assertEquals(wblDev.getAccessNumber(), rechAttr.getWearableMDN());
        assertEquals(vodSvc.getCatalogItemExternalId(), rechAttr.getRatePlan());
        assertEquals(vodWbl.getCatalogItemExternalId(), rechAttr.getWearableRatePlan());
        assertEquals(vodSvc.getChargeAmount().toPlainString(), rechAttr.getPlanAmount());
        assertEquals(vodWbl.getChargeAmount().toPlainString(), rechAttr.getWearablePlanAmount());
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void test_autoPay_When_advice_has_base_insurance_and_wearable_Then_tax_updated(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription is Active. "
        };
        td.when = new String[] {
            "Paymentadvice response; Has Base offer; Has Wearables; Has insurance."
        };
        td.then = new String[] {
            "ServiceTax should be applied for BaseOffer, Wearables and Insurance."
        };
        td.printDescription();

        long currentMillis = System.currentTimeMillis();
        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(
                        Arrays.asList(
                                CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.WEARABLE,
                                CI_EXTERNAL_IDS.INSURANCE)));
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);

        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        BigDecimal recAmount = BigDecimal.ONE;

        VisibleOfferDetails vodSvc = CommonTestHelper.loadJsonMessage(
                VisibleOfferDetails.class,
                DATA_DIR.CHANGE_SERVICE_ADVICE + "VisibleOfferDetails_Unlimited.json");
        vodSvc.setResourceId("1");
        vodSvc.setTaxDetails("Service Taxes");
        vodSvc.setPurchaseServiceType(PAYMENT_CONSTANTS.PURCHASE_SERVICE_TYPE_RENEWAL);
        vodSvc.setPaidCycleStartDate(
                new MtxDate(currentMillis + DATE_TIME_CONSTANTS.MILLISECONDS_IN_A_DAY));

        VisibleOfferDetails vodWbl = CommonTestHelper.loadJsonMessage(
                VisibleOfferDetails.class,
                DATA_DIR.CHANGE_SERVICE_ADVICE + "VisibleOfferDetails_Wearable.json");
        vodWbl.setResourceId("2");
        vodWbl.setTaxDetails("Wearable Taxes");
        vodWbl.setPaidCycleStartDate(
                new MtxDate(currentMillis + DATE_TIME_CONSTANTS.MILLISECONDS_IN_A_DAY));

        VisibleOfferDetails vodIns = CommonTestHelper.loadJsonMessage(
                VisibleOfferDetails.class,
                DATA_DIR.CHANGE_SERVICE_ADVICE + "VisibleOfferDetails_Insurance.json");
        vodIns.setResourceId("3");
        vodIns.setTaxDetails("Insurance Taxes");
        vodIns.setPaidCycleStartDate(
                new MtxDate(currentMillis + DATE_TIME_CONSTANTS.MILLISECONDS_IN_A_DAY));
        doAnswer(new Answer() {

            @SuppressWarnings("unchecked")
            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setSubscriberExternalId(subscription.getExternalId());
                aop.setEstimatedPayableAmount(recAmount);
                aop.getVisibleOfferDetailsListAppender().add(vodSvc);
                aop.getVisibleOfferDetailsListAppender().add(vodWbl);
                aop.getVisibleOfferDetailsListAppender().add(vodIns);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());

        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS, response.getResult().longValue());

        argumentCaptor.getAllValues().forEach(multi -> {
            System.out.println(multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        boolean foundSvcReq = false;
        boolean foundWblReq = false;
        boolean foundInsReq = false;
        String svcTax = "";
        String wblTax = "";
        String insTax = "";
        for (MtxRequest req : multiReq.getRequestList()) {
            if (MtxRequestSubscriberModifyOffer.class.getSimpleName().equalsIgnoreCase(
                    req.getMdcName())) {
                MtxRequestSubscriberModifyOffer modify = (MtxRequestSubscriberModifyOffer) req;
                VisiblePurchasedOfferExtension attr = (VisiblePurchasedOfferExtension) modify.getAttr();
                if (modify.getResourceId().toString().equalsIgnoreCase(vodSvc.getResourceId())) {
                    foundSvcReq = true;
                    svcTax = attr.getTaxDetails();
                }
                if (modify.getResourceId().toString().equalsIgnoreCase(vodWbl.getResourceId())) {
                    foundWblReq = true;
                    wblTax = attr.getTaxDetails();
                }
                if (modify.getResourceId().toString().equalsIgnoreCase(vodIns.getResourceId())) {
                    foundInsReq = true;
                    insTax = attr.getTaxDetails();
                }
            }
        }

        assertTrue(foundSvcReq);
        assertTrue(foundWblReq);
        assertTrue(foundInsReq);
        assertEquals(vodSvc.getTaxDetails(), svcTax);
        assertEquals(vodWbl.getTaxDetails(), wblTax);
        assertEquals(vodIns.getTaxDetails(), insTax);
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void test_autoPay_When_recharge_complete_Then_update_paidcyclestartdate(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription is Active. "
        };
        td.when = new String[] {
            "Autopay is complete."
        };
        td.then = new String[] {
            "update paidcyclestartdate."
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED)));
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);

        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        BigDecimal recAmount = BigDecimal.ONE;

        VisibleOfferDetails vodSvc = CommonTestHelper.loadJsonMessage(
                VisibleOfferDetails.class,
                DATA_DIR.CHANGE_SERVICE_ADVICE + "VisibleOfferDetails_Unlimited.json");
        vodSvc.setResourceId("1");
        vodSvc.setTaxDetails("Service Taxes");
        vodSvc.setPurchaseServiceType(PAYMENT_CONSTANTS.PURCHASE_SERVICE_TYPE_RENEWAL);
        vodSvc.setPaidCycleStartDate(TestUtils.getDateTomorrow(subscription.getTimeZone()));
        VisibleOfferDetails vodWbl = CommonTestHelper.loadJsonMessage(
                VisibleOfferDetails.class,
                DATA_DIR.CHANGE_SERVICE_ADVICE + "VisibleOfferDetails_Wearable.json");
        vodWbl.setResourceId("2");
        vodWbl.setTaxDetails("Wearable Taxes");
        vodWbl.setPaidCycleStartDate(TestUtils.getDateTomorrow(subscription.getTimeZone()));
        doAnswer(new Answer() {

            @SuppressWarnings("unchecked")
            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setSubscriberExternalId(subscription.getExternalId());
                aop.setEstimatedPayableAmount(recAmount);
                aop.getVisibleOfferDetailsListAppender().add(vodSvc);
                aop.getVisibleOfferDetailsListAppender().add(vodWbl);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS, response.getResult().longValue());

        argumentCaptor.getAllValues().forEach(multi -> {
            System.out.println(multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        boolean foundSvcReq = false;
        boolean foundWblReq = false;
        MtxDate pcsdSvc = null;
        MtxDate pcsdWbl = null;

        for (MtxRequest req : multiReq.getRequestList()) {
            if (MtxRequestSubscriberModifyOffer.class.getSimpleName().equalsIgnoreCase(
                    req.getMdcName())) {
                MtxRequestSubscriberModifyOffer modify = (MtxRequestSubscriberModifyOffer) req;
                VisiblePurchasedOfferExtension attr = (VisiblePurchasedOfferExtension) modify.getAttr();
                if (modify.getResourceId().toString().equalsIgnoreCase(vodSvc.getResourceId())) {
                    foundSvcReq = true;
                    pcsdSvc = attr.getPaidCycleStartDate();
                }
                if (modify.getResourceId().toString().equalsIgnoreCase(vodWbl.getResourceId())) {
                    foundWblReq = true;
                    pcsdWbl = attr.getPaidCycleStartDate();
                }
            }
        }

        assertTrue(foundSvcReq);
        assertTrue(foundWblReq);
        assertEquals(vodSvc.getPaidCycleStartDate().toString(), pcsdSvc.toString());
        assertEquals(vodWbl.getPaidCycleStartDate().toString(), pcsdWbl.toString());
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void test_autoPay_When_adviceHasGroupData_success_Then_modifySubscriptionWithGroup(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription is Active. "
        };
        td.when = new String[] {
            "Payment advice reports group."
        };
        td.then = new String[] {
            "Subscription should be modified with group info."
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED)));
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);

        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        BigDecimal recAmount = BigDecimal.ONE;

        VisibleOfferDetails vodSvc = CommonTestHelper.loadJsonMessage(
                VisibleOfferDetails.class,
                DATA_DIR.CHANGE_SERVICE_ADVICE + "VisibleOfferDetails_Unlimited.json");
        vodSvc.setResourceId("1");
        vodSvc.setChargeAmount(OFFER_PRICES.UNLIMITED);

        VisibleGroup vg = new VisibleGroup();
        vg.setGroupExternalId("GRPX-123");
        vg.setGroupName("GRPN-123");
        vg.setGroupTier("GRPT-123");
        vg.setSubscriberMemberCount(3L);
        doAnswer(new Answer() {

            @SuppressWarnings("unchecked")
            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setSubscriberExternalId(subscription.getExternalId());
                aop.setEstimatedPayableAmount(recAmount);
                aop.getVisibleOfferDetailsListAppender().add(vodSvc);
                aop.getSubscriberGroupsAppender().add(vg);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS, response.getResult().longValue());

        argumentCaptor.getAllValues().forEach(multi -> {
            System.out.println(multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        boolean foundModReq = false;
        VisiblePurchasedOfferExtension modAttr = null;

        for (MtxRequest req : multiReq.getRequestList()) {
            if (MtxRequestSubscriberModifyOffer.class.getSimpleName().equalsIgnoreCase(
                    req.getMdcName())) {
                MtxRequestSubscriberModifyOffer modify = (MtxRequestSubscriberModifyOffer) req;
                if (modify.getResourceId().toString().equalsIgnoreCase(vodSvc.getResourceId())) {
                    foundModReq = true;
                    modAttr = (VisiblePurchasedOfferExtension) modify.getAttr();
                    break;
                }
            }
        }

        assertTrue(foundModReq);
        assertEquals(vg.getGroupName(), modAttr.getGroupName());
        assertEquals(vg.getGroupTier(), modAttr.getGroupTier());
        assertEquals(
                vg.getSubscriberMemberCount().longValue(),
                modAttr.getGroupMemberCount().longValue());
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void test_autoPay_When_advice_has_base_needs_recharge_Then_lifetime_tracker(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription is Active. "
        };
        td.when = new String[] {
            "Paymentadvice response; Has Base offer; Advice is to recharge."
        };
        td.then = new String[] {
            "Lifetime tracker should be purchased with recharge amount."
        };
        td.printDescription();

        long currentMillis = System.currentTimeMillis();
        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance, CommonTestHelper.getEmptySubscriptionResponse());
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);
        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscription, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        BigDecimal recAmount = BigDecimal.ONE;

        VisibleOfferDetails vodSvc = CommonTestHelper.loadJsonMessage(
                VisibleOfferDetails.class,
                DATA_DIR.CHANGE_SERVICE_ADVICE + "VisibleOfferDetails_Unlimited.json");
        vodSvc.setResourceId("1");
        vodSvc.setChargeAmount(OFFER_PRICES.UNLIMITED);
        vodSvc.setTaxDetails("Service Taxes");
        vodSvc.setPurchaseServiceType(PAYMENT_CONSTANTS.PURCHASE_SERVICE_TYPE_RENEWAL);
        vodSvc.setPaidCycleStartDate(
                new MtxDate(currentMillis + DATE_TIME_CONSTANTS.MILLISECONDS_IN_A_DAY));
        VisibleOfferDetails vodWbl = CommonTestHelper.loadJsonMessage(
                VisibleOfferDetails.class,
                DATA_DIR.CHANGE_SERVICE_ADVICE + "VisibleOfferDetails_Wearable.json");
        vodWbl.setResourceId("2");
        vodWbl.setTaxDetails("Wearable Taxes");
        vodWbl.setChargeAmount(OFFER_PRICES.WEARABLE);
        vodWbl.setPaidCycleStartDate(
                new MtxDate(currentMillis + DATE_TIME_CONSTANTS.MILLISECONDS_IN_A_DAY));
        doAnswer(new Answer() {

            @SuppressWarnings("unchecked")
            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setSubscriberExternalId(subscription.getExternalId());
                aop.setEstimatedPayableAmount(recAmount);
                aop.getVisibleOfferDetailsListAppender().add(vodSvc);
                aop.getVisibleOfferDetailsListAppender().add(vodWbl);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS, response.getResult().longValue());

        argumentCaptor.getAllValues().forEach(multi -> {
            System.out.println(multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        boolean foundPurchReq = false;
        BigDecimal lifeTimeIncrement = BigDecimal.ZERO;
        for (MtxRequest req : multiReq.getRequestList()) {
            if (MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                    req.getMdcName())) {
                MtxRequestSubscriberPurchaseOffer purch = (MtxRequestSubscriberPurchaseOffer) req;
                MtxPurchasedOfferData pod = purch.getAtOfferRequestArray(0);
                if (AppPropertyProvider.getInstance().getString(
                        OFFER_CONSTANTS.OFFER_EXTERNAL_ID_VISIBLE_SERVICE_CHARGES).equalsIgnoreCase(
                                pod.getExternalId())) {
                    foundPurchReq = true;
                    VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) pod.getAttr();
                    lifeTimeIncrement = lifeTimeIncrement.add(poExtn.getChargeAmount());
                }
            }
        }

        assertTrue(foundPurchReq);
        assertEquals(OFFER_PRICES.UNLIMITED.doubleValue(), lifeTimeIncrement.doubleValue(), 0.001);
    }

    @SuppressWarnings({
        "rawtypes", "unchecked"
    })
    @Test
    public void test_autoPay_When_advice_has_promos_for_base_and_wearable_Then_creditTax_updated(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription is Active. "
        };
        td.when = new String[] {
            "Paymentadvice response; Has Base offer; Has Wearables; Has promos applicable to both."
        };
        td.then = new String[] {
            "PromoTax should be applied for BaseOffer. PromoTax should be applied for Wearables"
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance, CommonTestHelper.getSubscriptionResponse(
                        Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.WEARABLE)));
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);

        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        BigDecimal recAmount = BigDecimal.ONE;

        VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.UNLIMITED, TestUtils.getFirstDateOfCurrentMonth(), BigDecimal.ZERO);
        VisibleCredits vcGoodSvc = CommonTestHelper.getVisibleCredits(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, CI_EXTERNAL_IDS.UNLIMITED, BigDecimal.ZERO,
                BigDecimal.ONE);
        vodUnlimited.getCreditsAppender().add(vcGoodSvc);

        VisibleOfferDetails vodWbl = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.WEARABLE, TestUtils.getFirstDateOfCurrentMonth(), BigDecimal.ZERO);
        VisibleCredits vcGoodWbl = CommonTestHelper.getVisibleCredits(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, CI_EXTERNAL_IDS.WEARABLE, BigDecimal.ZERO,
                BigDecimal.ONE);
        vodWbl.getCreditsAppender().add(vcGoodWbl);

        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setSubscriberExternalId(subscription.getExternalId());
                aop.setEstimatedPayableAmount(recAmount);
                aop.getVisibleOfferDetailsListAppender().add(vodUnlimited);
                aop.getVisibleOfferDetailsListAppender().add(vodWbl);
                aop.getCreditsAppender().add(vcGoodSvc);
                aop.getCreditsAppender().add(vcGoodWbl);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS, response.getResult().longValue());

        argumentCaptor.getAllValues().forEach(multi -> {
            System.out.println(multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        boolean foundSvcReq = false;
        boolean foundWblReq = false;
        String goodwillTaxSvc = "";
        String goodwillTaxWbl = "";

        for (MtxRequest req : multiReq.getRequestList()) {
            if (MtxRequestSubscriberModifyOffer.class.getSimpleName().equalsIgnoreCase(
                    req.getMdcName())) {
                MtxRequestSubscriberModifyOffer modify = (MtxRequestSubscriberModifyOffer) req;
                VisiblePurchasedOfferExtension attr = (VisiblePurchasedOfferExtension) modify.getAttr();
                if (modify.getResourceId().toString().equalsIgnoreCase(
                        vodUnlimited.getResourceId())) {
                    foundSvcReq = true;
                    goodwillTaxSvc = attr.getCreditTaxDetailsArray().get(0);
                }
                if (modify.getResourceId().toString().equalsIgnoreCase(vodWbl.getResourceId())) {
                    foundWblReq = true;
                    goodwillTaxWbl = attr.getCreditTaxDetailsArray().get(0);
                }
            }
        }

        assertTrue(foundSvcReq);
        assertTrue(foundWblReq);
        assertEquals(vcGoodSvc.getTaxDetails(), goodwillTaxSvc);
        assertEquals(vcGoodWbl.getTaxDetails(), goodwillTaxWbl);
    }

    @SuppressWarnings({
        "rawtypes", "unchecked"
    })
    @Test
    public void test_autoPay_When_advice_has_promos_with_no_transferables_Then_noRedeem(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription is Active. "
        };
        td.when = new String[] {
            "Paymentadvice response; Has promos with no need for transfer to consumable."
        };
        td.then = new String[] {
            "Promo redeem should not be purchased. Promo tax should be updated."
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance, CommonTestHelper.getSubscriptionResponse(
                        Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.WEARABLE)));
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);

        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        BigDecimal recAmount = BigDecimal.ONE;

        VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.UNLIMITED, TestUtils.getFirstDateOfCurrentMonth(), BigDecimal.ZERO);
        VisibleCredits vcGoodSvc = CommonTestHelper.getVisibleCredits(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, CI_EXTERNAL_IDS.UNLIMITED, BigDecimal.ZERO,
                BigDecimal.ONE);
        vodUnlimited.getCreditsAppender().add(vcGoodSvc);

        VisibleOfferDetails vodWbl = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.WEARABLE, TestUtils.getFirstDateOfCurrentMonth(), BigDecimal.ZERO);
        VisibleCredits vcGoodWbl = CommonTestHelper.getVisibleCredits(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, CI_EXTERNAL_IDS.WEARABLE, BigDecimal.ZERO,
                BigDecimal.ONE);
        vodWbl.getCreditsAppender().add(vcGoodWbl);

        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setSubscriberExternalId(subscription.getExternalId());
                aop.setEstimatedPayableAmount(recAmount);
                aop.getVisibleOfferDetailsListAppender().add(vodUnlimited);
                aop.getVisibleOfferDetailsListAppender().add(vodWbl);
                aop.getCreditsAppender().add(vcGoodSvc);
                aop.getCreditsAppender().add(vcGoodWbl);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS, response.getResult().longValue());

        argumentCaptor.getAllValues().forEach(multi -> {
            System.out.println(multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        boolean foundPurchReq = false;

        for (MtxRequest req : multiReq.getRequestList()) {
            if (MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                    req.getMdcName())) {
                MtxRequestSubscriberPurchaseOffer purch = (MtxRequestSubscriberPurchaseOffer) req;
                MtxPurchasedOfferData pod = purch.getAtOfferRequestArray(0);
                if (CI_EXTERNAL_IDS.GOODWILL_REDEEM.equalsIgnoreCase(pod.getExternalId())) {
                    foundPurchReq = true;
                }
            }
        }
        assertFalse(foundPurchReq);
    }

    @SuppressWarnings({
        "rawtypes", "unchecked"
    })
    @Test
    public void test_autoPay_When_advice_has_promos_with_transferables_Then_correctRedeem(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription is Active. "
        };
        td.when = new String[] {
            "Paymentadvice response; Has promos that need transfer to consumable."
        };
        td.then = new String[] {
            "Promo redeemed offer should be purchased for each tranferable. Promo tax should be updated."
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance, CommonTestHelper.getSubscriptionResponse(
                        Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.WEARABLE)));
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);

        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        BigDecimal recAmount = BigDecimal.ONE;

        VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.UNLIMITED, TestUtils.getFirstDateOfCurrentMonth(), BigDecimal.ZERO);
        VisibleCredits vcGoodSvc = CommonTestHelper.getVisibleCredits(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, CI_EXTERNAL_IDS.UNLIMITED, BigDecimal.valueOf(8),
                BigDecimal.valueOf(5));
        vodUnlimited.getCreditsAppender().add(vcGoodSvc);

        VisibleOfferDetails vodWbl = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.WEARABLE, TestUtils.getFirstDateOfCurrentMonth(), BigDecimal.ZERO);
        VisibleCredits vcGoodWbl = CommonTestHelper.getVisibleCredits(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, CI_EXTERNAL_IDS.WEARABLE, BigDecimal.valueOf(8),
                BigDecimal.valueOf(3));
        vodWbl.getCreditsAppender().add(vcGoodWbl);

        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setSubscriberExternalId(subscription.getExternalId());
                aop.setEstimatedPayableAmount(recAmount);
                aop.getVisibleOfferDetailsListAppender().add(vodUnlimited);
                aop.getVisibleOfferDetailsListAppender().add(vodWbl);
                aop.getCreditsAppender().add(vcGoodSvc);
                aop.getCreditsAppender().add(vcGoodWbl);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS, response.getResult().longValue());

        argumentCaptor.getAllValues().forEach(multi -> {
            System.out.println(multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        boolean foundSvcRedeem = false;
        boolean foundWblRedeem = false;
        BigDecimal svcTransferable = BigDecimal.ZERO;
        BigDecimal wblTransferable = BigDecimal.ZERO;
        for (MtxRequest req : multiReq.getRequestList()) {
            if (MtxRequestSubscriberPurchaseOffer.class.getSimpleName().equalsIgnoreCase(
                    req.getMdcName())) {
                MtxRequestSubscriberPurchaseOffer purch = (MtxRequestSubscriberPurchaseOffer) req;
                MtxPurchasedOfferData pod = purch.getAtOfferRequestArray(0);
                VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) pod.getAttr();
                if (CI_EXTERNAL_IDS.GOODWILL_REDEEM.equalsIgnoreCase(pod.getExternalId())) {
                    if (vodUnlimited.getCatalogItemExternalId().equalsIgnoreCase(
                            poExtn.getCoreBasePlanCI())) {
                        foundSvcRedeem = true;
                        svcTransferable = poExtn.getChargeAmount();
                    }
                    if (vodWbl.getCatalogItemExternalId().equalsIgnoreCase(
                            poExtn.getCoreBasePlanCI())) {
                        foundWblRedeem = true;
                        wblTransferable = poExtn.getChargeAmount();
                    }
                }
            }
        }

        assertTrue(foundSvcRedeem);
        assertTrue(foundWblRedeem);
        assertEquals(
                vcGoodSvc.getEstimatedTransferableCredits().doubleValue(),
                svcTransferable.doubleValue(), 0.001);
        assertEquals(
                vcGoodWbl.getEstimatedTransferableCredits().doubleValue(),
                wblTransferable.doubleValue(), 0.001);
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void test_autoPay_When_multirequest_success_Then_success_notification(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription is Active. "
        };
        td.when = new String[] {
            "Multirequest is complete."
        };
        td.then = new String[] {
            "Send success notification."
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED)));
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);

        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        BigDecimal recAmount = BigDecimal.ONE;
        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setSubscriberExternalId(subscription.getExternalId());
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setEstimatedPayableAmount(recAmount);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), any());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");
        ArgumentCaptor<String> argumentCaptorBody = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> argumentCaptorCorr = ArgumentCaptor.forClass(String.class);
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(
                            any(), argumentCaptorBody.capture(),
                            argumentCaptorCorr.capture())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS, response.getResult().longValue());

        argumentCaptorBody.getAllValues().forEach(body -> {
            System.out.println(body);
        });
        argumentCaptorCorr.getAllValues().forEach(corr -> {
            System.out.println(corr);
        });

        String correlationId = argumentCaptorCorr.getValue();
        assertEquals(response.getOrderId(), correlationId);

        String msgBody = argumentCaptorBody.getValue();
        Map msgMap = CommonUtils.getObjectMapper().readValue(msgBody, Map.class);
        assertEquals(
                AUTOPAY_CONSTANTS.SUCCESS_NOTIF_CONTAINER,
                msgMap.get(
                        AppPropertyProvider.getInstance().getString(
                                NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_NOTIFICATION_NAME_KEY)));
    }

    @ParameterizedTest(name = "test_autoPay_When_success_Then_notification_with_offerarray")
    @Tag("VER-495")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription is Active.|"
                +"|When  |Multirequest is successful.|"
                +"|Then  |Send notification with offer array.|"})
    // @formatter:on
    @SuppressWarnings("rawtypes")
    public void test_autoPay_When_success_Then_notification_with_offerarray(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(
                        Arrays.asList(
                                CI_EXTERNAL_IDS.PLUS3VIS23WB, CI_EXTERNAL_IDS.WEARABLE_FREE,
                                CI_EXTERNAL_IDS.INSURANCE)));
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);

        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        BigDecimal recAmount = BigDecimal.ONE;
        doAnswer(new Answer() {

            @SuppressWarnings("unchecked")
            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setSubscriberExternalId(subscription.getExternalId());
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setEstimatedPayableAmount(recAmount);
                aop.getVisibleOfferDetailsListAppender().add(
                        CommonTestHelper.getVisibleOfferDetails(
                                CI_EXTERNAL_IDS.PLUS3VIS23WB, TestUtils.getDateYesterday()));
                aop.getVisibleOfferDetailsListAppender().add(
                        CommonTestHelper.getVisibleOfferDetails(
                                CI_EXTERNAL_IDS.WEARABLE_FREE, TestUtils.getDateYesterday()));
                aop.getVisibleOfferDetailsListAppender().add(
                        CommonTestHelper.getVisibleOfferDetails(
                                CI_EXTERNAL_IDS.INSURANCE, TestUtils.getDateYesterday()));
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), any());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");
        ArgumentCaptor<String> argumentCaptorBody = ArgumentCaptor.forClass(String.class);
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(
                            any(), argumentCaptorBody.capture(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS, response.getResult().longValue());

        String msgBody = argumentCaptorBody.getValue();
        Map msgMap = CommonUtils.getObjectMapper().readValue(msgBody, Map.class);
        System.out.println(msgMap.get(NOTIFICATION_CONSTANTS.OFFER_LIST_KEY).toString());
        @SuppressWarnings("unchecked")
        List<String> offerList = (List<String>) msgMap.get(NOTIFICATION_CONSTANTS.OFFER_LIST_KEY);
        assertTrue(offerList.contains(CI_EXTERNAL_IDS.PLUS3VIS23WB));
        assertTrue(offerList.contains(CI_EXTERNAL_IDS.INSURANCE));
        assertFalse(offerList.contains(CI_EXTERNAL_IDS.WEARABLE_FREE));
    }

    @ParameterizedTest(name = "test_autoPay_When_success_Then_notification_with_offerarray")
    @Tag("VER-803")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription with payer.|"
                +"|When  |Multirequest is successful.|"
                +"|Then  |Send notification with payer details.|"})
    // @formatter:on
    @SuppressWarnings("rawtypes")
    public void test_autoPayGiven_Payer_When_success_Then_notification_with_offerarray(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        String payerExternalId = "1234567890";
        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance, CommonTestHelper.getSubscriptionResponseAutopay(
                        List.of(CI_EXTERNAL_IDS.PLUS3VIS23WB), null));
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);

        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);
        System.out.println(pmi.toJson());
        BigDecimal recAmount = BigDecimal.ONE;

        doAnswer(new Answer() {

            @SuppressWarnings("unchecked")
            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setSubscriberExternalId(subscription.getExternalId());
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setPayerExternalId(payerExternalId);
                aop.setEstimatedPayableAmount(recAmount);
                aop.getVisibleOfferDetailsListAppender().add(
                        CommonTestHelper.getVisibleOfferDetails(
                                CI_EXTERNAL_IDS.PLUS3VIS23WB, TestUtils.getDateYesterday()));
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), any());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");
        ArgumentCaptor<String> argumentCaptorBody = ArgumentCaptor.forClass(String.class);
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(
                            any(), argumentCaptorBody.capture(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS, response.getResult().longValue());

        String msgBody = argumentCaptorBody.getValue();
        Map msgMap = CommonUtils.getObjectMapper().readValue(msgBody, Map.class);
        System.out.println(msgMap.toString());
        System.out.println(msgMap.get(NOTIFICATION_CONSTANTS.PAYER_KEY).toString());
        assertNotNull(msgMap.get(NOTIFICATION_CONSTANTS.PAYER_KEY));

        assertEquals(
                payerExternalId, ((Map) msgMap.get(NOTIFICATION_CONSTANTS.PAYER_KEY)).get(
                        NOTIFICATION_CONSTANTS.PAYER_EXTERNAL_ID_KEY));
        assertEquals(
                NOTIFICATION_CONSTANTS.PAYER_CONTAINER_NAME,
                ((Map) msgMap.get(NOTIFICATION_CONSTANTS.PAYER_KEY)).get("$"));
        assertEquals(
                pmi.getName(),
                ((Map) msgMap.get(NOTIFICATION_CONSTANTS.PAYER_KEY)).get("PaymentMethodName"));
    }

    @ParameterizedTest(name = "test_autoPay_When_success_Then_CycleLength_as_per_SubAttr")
    @Tag("VER-523")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription is Active with cycle length populated.|"
                +"|When  |Multirequest is successful.|"
                +"|Then  |Send notification with offer array.|"})
    // @formatter:on
    @SuppressWarnings("rawtypes")
    public void test_autoPay_When_success_Then_CycleLength_as_per_SubAttr(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        OneParameterTest pTests = (cLength) -> {
            td.printDescription();
            SubscriptionResponse subscription = emulateSubscriptionResponse(
                    instance, CommonTestHelper.getSubscriptionResponse(
                            Arrays.asList(CI_EXTERNAL_IDS.PLUS3VIS23WB)));
            MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                    subscription.getTimeZone(), 24);

            VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
            extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
            String cycleLength = (String) cLength;
            if (cycleLength != null) {
                extn.setCycleLength(cycleLength);
            }
            subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
            subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
            if (subscription.getAtPurchasedOfferArray(0).getCycleInfo() != null) {
                subscription.getAtPurchasedOfferArray(0).getCycleInfo().setCycleEndTime(endTime);
            }

            emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
            MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
            emulateMtxResponsePaymentMethodInfo(instance, pmi);

            BigDecimal recAmount = BigDecimal.ONE;
            doAnswer(new Answer() {

                @SuppressWarnings("unchecked")
                public Object answer(InvocationOnMock invocation) {
                    Object[] args = invocation.getArguments();
                    VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                    aop.setSubscriberExternalId(subscription.getExternalId());
                    aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                    aop.setResultText("OK");
                    aop.setEstimatedPayableAmount(recAmount);
                    aop.getVisibleOfferDetailsListAppender().add(
                            CommonTestHelper.getVisibleOfferDetails(
                                    CI_EXTERNAL_IDS.PLUS3VIS23WB, TestUtils.getDateYesterday()));
                    return null;
                }
            }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

            MtxResponseMulti multiResp = new MtxResponseMulti();
            multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
            doReturn(multiResp).when(instance).multiRequest(any(), any(), any());

            VisibleRequestAutoPay request = new VisibleRequestAutoPay();
            request.setSubscriptionExternalId(subscription.getExternalId());
            VisibleResponseAutoPay response = new VisibleResponseAutoPay();
            MtxResponse qResp = new MtxResponse();
            qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
            qResp.setResultText("OK");
            ArgumentCaptor<String> argumentCaptorBody = ArgumentCaptor.forClass(String.class);
            try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(
                    ActiveMQClient.class)) {
                mockedStatic.when(
                        () -> ActiveMQClient.sendAuopayMessage(
                                any(), argumentCaptorBody.capture(), any())).thenReturn(qResp);
                instance.autoPay(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS, response.getResult().longValue());

            String msgBody = argumentCaptorBody.getValue();
            Map msgMap = CommonUtils.getObjectMapper().readValue(msgBody, Map.class);
            System.out.println(msgMap);
            String notifCycleLength = (String) msgMap.get(NOTIFICATION_CONSTANTS.CYCLE_LENGTH);
            System.out.println(notifCycleLength);
            assertEquals(cycleLength, notifCycleLength);
        };
        pTests.test(null);
        pTests.test("XYZ");
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void test_autoPay_When_multirequest_error_Then_error_notification(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription is Active. "
        };
        td.when = new String[] {
            "Multirequest is complete."
        };
        td.then = new String[] {
            "Send error notification."
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED)));
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);

        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        BigDecimal recAmount = BigDecimal.ONE;
        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setEstimatedPayableAmount(recAmount);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), any());

        MtxResponse retryResp = new MtxResponse();
        retryResp.setResult(RESULT_CODES.MTX_SUCCESS);
        doReturn(retryResp).when(instance).modifySubscription(any(), any());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");
        ArgumentCaptor<String> argumentCaptorBody = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> argumentCaptorCorr = ArgumentCaptor.forClass(String.class);
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(
                            any(), argumentCaptorBody.capture(),
                            argumentCaptorCorr.capture())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        assertEquals(
                RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult().longValue());

        argumentCaptorBody.getAllValues().forEach(body -> {
            System.out.println(body);
        });
        argumentCaptorCorr.getAllValues().forEach(corr -> {
            System.out.println(corr);
        });

        String correlationId = argumentCaptorCorr.getValue();
        assertEquals(response.getOrderId(), correlationId);

        String msgBody = argumentCaptorBody.getValue();
        Map msgMap = CommonUtils.getObjectMapper().readValue(msgBody, Map.class);
        assertEquals(
                AUTOPAY_CONSTANTS.FAILURE_NOTIF_CONTAINER,
                msgMap.get(
                        AppPropertyProvider.getInstance().getString(
                                NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_NOTIFICATION_NAME_KEY)));
    }

    @ParameterizedTest(name = "test_autoPay_When_error_Then_notification_with_offerarray")
    @Tag("VER-495")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription is Active.|"
                +"|When  |Multirequest failed.|"
                +"|Then  |Send notification with offer array.|"})
    // @formatter:on
    @SuppressWarnings("rawtypes")
    public void test_autoPay_When_error_Then_notification_with_offerarray(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(
                        Arrays.asList(
                                CI_EXTERNAL_IDS.PLUS3VIS23WB,
                                CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION,
                                CI_EXTERNAL_IDS.INSURANCE)));
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);

        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        BigDecimal recAmount = BigDecimal.ONE;
        doAnswer(new Answer() {

            @SuppressWarnings("unchecked")
            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setSubscriberExternalId(subscription.getExternalId());
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setEstimatedPayableAmount(recAmount);
                aop.getVisibleOfferDetailsListAppender().add(
                        CommonTestHelper.getVisibleOfferDetails(
                                CI_EXTERNAL_IDS.PLUS3VIS23WB, TestUtils.getDateYesterday()));
                aop.getVisibleOfferDetailsListAppender().add(
                        CommonTestHelper.getVisibleOfferDetails(
                                CI_EXTERNAL_IDS.WEARABLE_FREE, TestUtils.getDateYesterday()));
                aop.getVisibleOfferDetailsListAppender().add(
                        CommonTestHelper.getVisibleOfferDetails(
                                CI_EXTERNAL_IDS.INSURANCE, TestUtils.getDateYesterday()));
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), any());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");
        ArgumentCaptor<String> argumentCaptorBody = ArgumentCaptor.forClass(String.class);
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(
                            any(), argumentCaptorBody.capture(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());

        String msgBody = argumentCaptorBody.getValue();
        Map msgMap = CommonUtils.getObjectMapper().readValue(msgBody, Map.class);
        System.out.println(msgMap.get(NOTIFICATION_CONSTANTS.OFFER_LIST_KEY).toString());
        @SuppressWarnings("unchecked")
        List<String> offerList = (List<String>) msgMap.get(NOTIFICATION_CONSTANTS.OFFER_LIST_KEY);
        assertTrue(offerList.contains(CI_EXTERNAL_IDS.PLUS3VIS23WB));
        assertTrue(offerList.contains(CI_EXTERNAL_IDS.INSURANCE));
        assertFalse(offerList.contains(CI_EXTERNAL_IDS.WEARABLE_FREE));
    }

    @ParameterizedTest(name = "test_autoPay_When_error_Then_no_CycleLength_in_Notification")
    @Tag("VER-523")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription is Active with cycle length populated.|"
                +"|When  |Multirequest failed.|"
                +"|Then  |Send notification without cycle length.|"})
    // @formatter:on
    @SuppressWarnings("rawtypes")
    public void test_autoPay_When_error_Then_no_CycleLength_in_Notification(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance, CommonTestHelper.getSubscriptionResponse(
                        Arrays.asList(CI_EXTERNAL_IDS.PLUS3VIS23WB)));
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);

        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        if (subscription.getAtPurchasedOfferArray(0).getCycleInfo() != null) {
            subscription.getAtPurchasedOfferArray(0).getCycleInfo().setCycleEndTime(endTime);
        }
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        BigDecimal recAmount = BigDecimal.ONE;
        doAnswer(new Answer() {

            @SuppressWarnings("unchecked")
            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setSubscriberExternalId(subscription.getExternalId());
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setEstimatedPayableAmount(recAmount);
                aop.getVisibleOfferDetailsListAppender().add(
                        CommonTestHelper.getVisibleOfferDetails(
                                CI_EXTERNAL_IDS.PLUS3VIS23WB, TestUtils.getDateYesterday()));
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), any());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");
        ArgumentCaptor<String> argumentCaptorBody = ArgumentCaptor.forClass(String.class);
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(
                            any(), argumentCaptorBody.capture(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());

        String msgBody = argumentCaptorBody.getValue();
        Map msgMap = CommonUtils.getObjectMapper().readValue(msgBody, Map.class);
        String notifCycleLength = (String) msgMap.get(NOTIFICATION_CONSTANTS.CYCLE_LENGTH);
        System.out.println(notifCycleLength);
        assertNull(notifCycleLength);
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void test_autoPay_When_multirequest_error_Then_update_retry_date(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription is Active. "
        };
        td.when = new String[] {
            "Multirequest error."
        };
        td.then = new String[] {
            "update retry date."
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED)));
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);

        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscription, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        BigDecimal recAmount = BigDecimal.ONE;
        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setEstimatedPayableAmount(recAmount);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), any());

        ArgumentCaptor<MtxRequestSubscriptionModify> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestSubscriptionModify.class);
        MtxResponse retryResp = new MtxResponse();
        retryResp.setResult(RESULT_CODES.MTX_SUCCESS);
        doReturn(retryResp).when(instance).modifySubscription(any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");

        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        assertEquals(
                RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult().longValue());

        argumentCaptor.getAllValues().forEach(req -> {
            System.out.println(req.toJson());
        });

        MtxRequestSubscriptionModify modReq = argumentCaptor.getValue();
        VisibleSubscriberExtension modExtn = (VisibleSubscriberExtension) modReq.getAttr();
        System.out.println(modReq.toJson());
        assertTrue(modExtn.getPaymentRetry().startsWith(LocalDate.now().toString()));
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void test_autoPay_When_retry_date_error_response_Then_error(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription is Active. "
        };
        td.when = new String[] {
            "updating retry date gives error response."
        };
        td.then = new String[] {
            "error."
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED)));
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);
        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        BigDecimal recAmount = BigDecimal.ONE;
        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setEstimatedPayableAmount(recAmount);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), any());

        MtxResponse retryResp = new MtxResponse();
        retryResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
        doReturn(retryResp).when(instance).modifySubscription(any(), any());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");

        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        assertEquals(
                RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult().longValue());
        assertThat(response.getResultText()).contains(
                AUTOPAY_MESSAGES.PAYMENT_RETRY_UPDATE_ERROR_281);
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void test_autoPay_When_retry_date_error_thrown_Then_error(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription is Active. "
        };
        td.when = new String[] {
            "updating retry date gives error thrown."
        };
        td.then = new String[] {
            "error."
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance, CommonTestHelper.getEmptySubscriptionResponse());
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);
        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscription, CI_EXTERNAL_IDS.UNLIMITED);
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        BigDecimal recAmount = BigDecimal.ONE;
        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setEstimatedPayableAmount(recAmount);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), any());

        doThrow(NullPointerException.class).when(instance).modifySubscription(any(), any());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");

        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        assertEquals(
                RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult().longValue());
        assertThat(response.getResultText()).contains(
                AUTOPAY_MESSAGES.PAYMENT_RETRY_UPDATE_ERROR_281);
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void test_autoPay_When_autopaycomplete_Then_notification_structure(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription is Active. "
        };
        td.when = new String[] {
            "Autopay is complete."
        };
        td.then = new String[] {
            "Notification structure is correct."
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance, CommonTestHelper.getEmptySubscriptionResponse());
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);

        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscription, CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseUser user = emulateMtxResponseUser(
                instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        BigDecimal recAmount = BigDecimal.ONE;
        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setSubscriberExternalId(subscription.getExternalId());
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setEstimatedPayableAmount(recAmount);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), any());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");
        ArgumentCaptor<String> argumentCaptorBody = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> argumentCaptorCorr = ArgumentCaptor.forClass(String.class);
        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(
                            any(), argumentCaptorBody.capture(),
                            argumentCaptorCorr.capture())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS, response.getResult().longValue());

        argumentCaptorBody.getAllValues().forEach(body -> {
            System.out.println(body);
        });
        argumentCaptorCorr.getAllValues().forEach(corr -> {
            System.out.println(corr);
        });

        String correlationId = argumentCaptorCorr.getValue();
        assertEquals(response.getOrderId(), correlationId);

        String msgBody = argumentCaptorBody.getValue();
        Map msgMap = CommonUtils.getObjectMapper().readValue(msgBody, Map.class);
        PropertiesConfiguration props = AppPropertyProvider.getInstance();

        assertEquals(
                AUTOPAY_CONSTANTS.SUCCESS_NOTIF_CONTAINER,
                msgMap.get(
                        props.getString(
                                NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_NOTIFICATION_NAME_KEY)));
        assertEquals(
                props.getInt(
                        NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_OBJECT_TYPE_VALUE),
                msgMap.get(
                        props.getString(
                                NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_OBJECT_TYPE_KEY)));
        assertEquals(
                subscription.getObjectId().toString(),
                msgMap.get(NOTIFICATION_CONSTANTS.OBJECT_ID_KEY));
        assertEquals(
                subscription.getExternalId(),
                msgMap.get(
                        props.getString(
                                NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_OBJECT_EXTERNAL_ID_KEY)));
        assertEquals(
                pmi.getName(),
                msgMap.get(
                        props.getString(
                                NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_PAYMENT_METHOD_NAME_KEY)));
        assertEquals(
                response.getRechargeAmount() + "", msgMap.get(NOTIFICATION_CONSTANTS.AMOUNT_KEY));
        assertEquals(
                props.getString(NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_STATUS_VALUE),
                msgMap.get(
                        props.getString(NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_STATUS_KEY)));
        assertThat(
                msgMap.get(
                        props.getString(
                                NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_NOTIFICATION_ID_KEY)).toString()).startsWith(
                                        subscription.getObjectId().toString());
        assertEquals(
                (int) AUTOPAY_CONSTANTS.SUCCESS_NOTIF_TYPE,
                msgMap.get(
                        props.getString(
                                NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_NOTIFICATION_TYPE_KEY)));
        assertEquals(
                PAYMENT_CONSTANTS.AUTOPAY,
                msgMap.get(
                        props.getString(
                                NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_PAYMENT_PREFERENCE_KEY)));
        assertEquals(user.getContactEmail(), msgMap.get(NOTIFICATION_CONSTANTS.CONTACT_EMAIL_KEY));
        assertNotNull(msgMap.get(NOTIFICATION_CONSTANTS.BEFORE_CYCLE_END));
        assertNotNull(msgMap.get(NOTIFICATION_CONSTANTS.NOTIFICATION_EXPIRATION_OFFSET_KEY));
        assertEquals(
                AUTOPAY_CONSTANTS.NOTIF_EXP_OFFSET_TYPE,
                msgMap.get(NOTIFICATION_CONSTANTS.NOTIFICATION_EXPIRATION_OFFSET_TYPE_KEY));
        assertNotNull(msgMap.get(NOTIFICATION_CONSTANTS.EXPIRATION_TIME_KEY));
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void test_autoPay_When_notification_error_Then_error(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription is Active. "
        };
        td.when = new String[] {
            "Autopay is complete. Notification Error."
        };
        td.then = new String[] {
            "error."
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED)));
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);

        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        BigDecimal recAmount = BigDecimal.ONE;
        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setSubscriberExternalId(subscription.getExternalId());
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setEstimatedPayableAmount(recAmount);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), any());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
        qResp.setResultText("Not-OK");

        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        assertEquals(
                RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, response.getResult().longValue());
        assertThat(response.getResultText()).contains(
                AUTOPAY_MESSAGES.RECHARGE_SUCESS_NOTIFICATION_ERROR_282);
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void test_autoPay_When_No_Payment_No_Gift_No_Promo_AnnualPan_Only_Then_No_ModifyOffer(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription is Active. ", "Enrolled in AnnualPlan only",
            "Not in last month of service."
        };
        td.when = new String[] {
            "Autopay calls PaymentAdvice", "PaymentAdvice response has no gift or promo",
            "PaymentAdvice response has no payment for annual offer"
        };
        td.then = new String[] {
            "There should be NO modify offer for annualplan"
        };
        td.printDescription();
        long currentMillis = System.currentTimeMillis();
        MtxTimestamp endTime = new MtxTimestamp(
                currentMillis + DATE_TIME_CONSTANTS.MILLISECONDS_IN_A_DAY);
        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance, CommonTestHelper.getSubscriptionResponse(
                        "1234", Arrays.asList(CI_EXTERNAL_IDS.PLUS2ANNUAL)));
        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        if (subscription.getAtPurchasedOfferArray(0) != null) {
            subscription.getAtPurchasedOfferArray(0).getCycleInfo().setCycleEndTime(
                    TestUtils.addHours(
                            TestUtils.getFirstDateTimeOfCurrentMonth(
                                    subscription.getLastActivityTime()),
                            1));
        }
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        VisibleOfferDetails vodAnnual = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.PLUS2ANNUAL, TestUtils.getFirstDateOfCurrentMonth(),
                BigDecimal.ZERO);

        doAnswer(new Answer() {

            @SuppressWarnings("unchecked")
            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setSubscriberExternalId(subscription.getExternalId());
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setEstimatedPayableAmount(BigDecimal.ZERO);
                aop.getVisibleOfferDetailsListAppender().add(vodAnnual);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
        qResp.setResultText("Not-OK");

        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        argumentCaptor.getAllValues().forEach(multi -> {
            System.out.println(td.getTestMethod() + ":" + multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        boolean foundSvcReq = false;
        for (MtxRequest req : multiReq.getRequestList()) {
            if (MtxRequestSubscriberModifyOffer.class.getSimpleName().equalsIgnoreCase(
                    req.getMdcName())) {
                MtxRequestSubscriberModifyOffer modify = (MtxRequestSubscriberModifyOffer) req;
                if (modify.getResourceId().toString().equalsIgnoreCase(vodAnnual.getResourceId())) {
                    foundSvcReq = true;
                }
            }
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        assertFalse(foundSvcReq);
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void test_autoPay_When_No_Payment_No_Gift_No_Promo_Multiple_Services_Then_No_Modify_For_Annual(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription is Active. ", "Enrolled in AnnualPlan and MonthlyPlan",
            "Not in last month of service."
        };
        td.when = new String[] {
            "Autopay calls PaymentAdvice", "PaymentAdvice response has no gift or promo",
            "PaymentAdvice response has no payment for annual offer"
        };
        td.then = new String[] {
            "There should be NO modify offer for annualplan",
            "There should be NO modify offer for monthlyplan"
        };
        td.printDescription();

        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance, CommonTestHelper.getSubscriptionResponse(
                        Arrays.asList(CI_EXTERNAL_IDS.PLUS2ANNUAL, CI_EXTERNAL_IDS.WEARABLE)));
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);

        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        VisibleOfferDetails vodAnnual = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.PLUS2ANNUAL, TestUtils.getFirstDateOfCurrentMonth(),
                BigDecimal.ZERO);
        VisibleOfferDetails vodWbl = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.WEARABLE, TestUtils.getFirstDateOfCurrentMonth());

        doAnswer(new Answer() {

            @SuppressWarnings("unchecked")
            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setSubscriberExternalId(subscription.getExternalId());
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setEstimatedPayableAmount(vodWbl.getChargeAmount());
                aop.getVisibleOfferDetailsListAppender().add(vodAnnual);
                aop.getVisibleOfferDetailsListAppender().add(vodWbl);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
        qResp.setResultText("Not-OK");

        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        argumentCaptor.getAllValues().forEach(multi -> {
            System.out.println(td.getTestMethod() + ":" + multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        boolean foundSvcReq = false;
        boolean foundWblReq = false;
        for (MtxRequest req : multiReq.getRequestList()) {
            if (MtxRequestSubscriberModifyOffer.class.getSimpleName().equalsIgnoreCase(
                    req.getMdcName())) {
                MtxRequestSubscriberModifyOffer modify = (MtxRequestSubscriberModifyOffer) req;
                if (modify.getResourceId().toString().equalsIgnoreCase(vodAnnual.getResourceId())) {
                    foundSvcReq = true;
                }
                if (modify.getResourceId().toString().equalsIgnoreCase(vodWbl.getResourceId())) {
                    foundWblReq = true;
                }
            }
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        assertFalse(foundSvcReq);
        assertTrue(foundWblReq);
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void test_autoPay_When_Payment_AnnualPan_Only_Then_ModifyOffer(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription is Active. ", "Enrolled in AnnualPlan only", "In last month of service."
        };
        td.when = new String[] {
            "Autopay calls PaymentAdvice",
            "PaymentAdvice response has payable amount for annual offer"
        };
        td.then = new String[] {
            "There should be modify offer for annualplan"
        };
        td.printDescription();

        long currentMillis = System.currentTimeMillis();
        MtxTimestamp endTime = new MtxTimestamp(
                currentMillis + DATE_TIME_CONSTANTS.MILLISECONDS_IN_A_DAY);
        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance, CommonTestHelper.getSubscriptionResponse(
                        "1234", Arrays.asList(CI_EXTERNAL_IDS.PLUS2ANNUAL)));
        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        if (subscription.getAtPurchasedOfferArray(0) != null) {
            subscription.getAtPurchasedOfferArray(0).setAutoActivationTime((MtxTimestamp) null);
            subscription.getAtPurchasedOfferArray(0).getCycleInfo().setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth(subscription.getLastActivityTime()));
            subscription.getAtPurchasedOfferArray(0).getCycleInfo().setCycleEndTime(
                    TestUtils.addHours(
                            TestUtils.getFirstDateTimeOfCurrentMonth(
                                    subscription.getLastActivityTime()),
                            1));
        }
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        VisibleOfferDetails vodAnnual = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.PLUS2ANNUAL, TestUtils.getFirstDateOfCurrentMonth());
        doAnswer(new Answer() {

            @SuppressWarnings("unchecked")
            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setSubscriberExternalId(subscription.getExternalId());
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setEstimatedPayableAmount(vodAnnual.getChargeAmount());
                aop.getVisibleOfferDetailsListAppender().add(vodAnnual);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
        qResp.setResultText("Not-OK");

        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        argumentCaptor.getAllValues().forEach(multi -> {
            System.out.println(td.getTestMethod() + ":" + multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        boolean foundSvcReq = false;
        for (MtxRequest req : multiReq.getRequestList()) {
            if (MtxRequestSubscriberModifyOffer.class.getSimpleName().equalsIgnoreCase(
                    req.getMdcName())) {
                MtxRequestSubscriberModifyOffer modify = (MtxRequestSubscriberModifyOffer) req;
                if (modify.getResourceId().toString().equalsIgnoreCase(vodAnnual.getResourceId())) {
                    foundSvcReq = true;
                }
            }
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        assertTrue(foundSvcReq);
    }

    @SuppressWarnings({
        "unchecked", "rawtypes"
    })
    @Test
    public void test_autoPay_When_Gift_AnnualPan_Only_Then_ModifyOffer(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription is Active. ", "Enrolled in AnnualPlan only", "In last month of service."
        };
        td.when = new String[] {
            "Autopay calls PaymentAdvice", "PaymentAdvice response has gift"
        };
        td.then = new String[] {
            "There should be modify offer for annualplan"
        };
        td.printDescription();

        long currentMillis = System.currentTimeMillis();
        MtxTimestamp endTime = new MtxTimestamp(
                currentMillis + DATE_TIME_CONSTANTS.MILLISECONDS_IN_A_DAY);
        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance, CommonTestHelper.getSubscriptionResponse(
                        "1234", Arrays.asList(CI_EXTERNAL_IDS.PLUS2ANNUAL)));
        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        if (subscription.getAtPurchasedOfferArray(0) != null) {
            subscription.getAtPurchasedOfferArray(0).getCycleInfo().setCycleEndTime(
                    TestUtils.addHours(
                            TestUtils.getFirstDateTimeOfCurrentMonth(
                                    subscription.getLastActivityTime()),
                            1));
        }
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        VisibleOfferDetails vodAnnual = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.PLUS2ANNUAL, TestUtils.getFirstDateOfCurrentMonth(),
                BigDecimal.ZERO);
        VisibleCredits vcGift = CommonTestHelper.getVisibleCredits(
                CI_EXTERNAL_IDS.GIFT_GRANT, CI_EXTERNAL_IDS.PLUS2ANNUAL, OFFER_PRICES.PLUS2ANNUAL);
        vodAnnual.getCreditsAppender().add(vcGift);
        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setSubscriberExternalId(subscription.getExternalId());
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setEstimatedPayableAmount(vodAnnual.getPayableAmount());
                aop.getVisibleOfferDetailsListAppender().add(vodAnnual);
                aop.getCreditsAppender().add(vcGift);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
        qResp.setResultText("Not-OK");

        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        argumentCaptor.getAllValues().forEach(multi -> {
            System.out.println(td.getTestMethod() + ":" + multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        boolean foundSvcReq = false;
        VisiblePurchasedOfferExtension attr = new VisiblePurchasedOfferExtension();
        for (MtxRequest req : multiReq.getRequestList()) {
            if (MtxRequestSubscriberModifyOffer.class.getSimpleName().equalsIgnoreCase(
                    req.getMdcName())) {
                MtxRequestSubscriberModifyOffer modify = (MtxRequestSubscriberModifyOffer) req;
                if (modify.getResourceId().toString().equalsIgnoreCase(vodAnnual.getResourceId())) {
                    foundSvcReq = true;
                    attr = (VisiblePurchasedOfferExtension) modify.getAttr();
                }
            }
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        assertTrue(foundSvcReq);
        assertFalse(attr.getCreditTaxDetailsArray() == null);
        assertFalse(attr.getCreditTaxDetailsArray().isEmpty());
        assertTrue(StringUtils.isNotBlank(attr.getAtCreditTaxDetailsArray(0)));
    }

    @SuppressWarnings({
        "unchecked", "rawtypes"
    })
    @Test
    public void test_autoPay_When_Promo_AnnualPan_Only_Then_ModifyOffer(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscription is Active. ", "Enrolled in AnnualPlan only", "In last month of service."
        };
        td.when = new String[] {
            "Autopay calls PaymentAdvice", "PaymentAdvice response has promo"
        };
        td.then = new String[] {
            "There should be modify offer for annualplan"
        };
        td.printDescription();

        long currentMillis = System.currentTimeMillis();
        MtxTimestamp endTime = new MtxTimestamp(
                currentMillis + DATE_TIME_CONSTANTS.MILLISECONDS_IN_A_DAY);
        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance, CommonTestHelper.getSubscriptionResponse(
                        "1234", Arrays.asList(CI_EXTERNAL_IDS.PLUS2ANNUAL)));
        VisibleSubscriberExtension extn = (VisibleSubscriberExtension) subscription.getAttr();
        extn.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);
        if (subscription.getAtPurchasedOfferArray(0) != null) {
            subscription.getAtPurchasedOfferArray(0).getCycleInfo().setCycleEndTime(
                    TestUtils.addHours(
                            TestUtils.getFirstDateTimeOfCurrentMonth(
                                    subscription.getLastActivityTime()),
                            1));
        }
        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        VisibleOfferDetails vodAnnual = CommonTestHelper.getVisibleOfferDetails(
                CI_EXTERNAL_IDS.PLUS2ANNUAL, TestUtils.getFirstDateOfCurrentMonth(),
                BigDecimal.ZERO);
        VisibleCredits vcGoodwill = CommonTestHelper.getVisibleCredits(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, CI_EXTERNAL_IDS.PLUS2ANNUAL,
                OFFER_PRICES.PLUS2ANNUAL);
        vodAnnual.getCreditsAppender().add(vcGoodwill);
        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                VisibleResponsePaymentAdviceService aop = (VisibleResponsePaymentAdviceService) args[1];
                aop.setSubscriberExternalId(subscription.getExternalId());
                aop.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
                aop.setResultText("OK");
                aop.setEstimatedPayableAmount(vodAnnual.getPayableAmount());
                aop.getVisibleOfferDetailsListAppender().add(vodAnnual);
                aop.getCreditsAppender().add(vcGoodwill);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
        qResp.setResultText("Not-OK");

        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        argumentCaptor.getAllValues().forEach(multi -> {
            System.out.println(td.getTestMethod() + ":" + multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        boolean foundSvcReq = false;
        VisiblePurchasedOfferExtension attr = new VisiblePurchasedOfferExtension();
        for (MtxRequest req : multiReq.getRequestList()) {
            if (MtxRequestSubscriberModifyOffer.class.getSimpleName().equalsIgnoreCase(
                    req.getMdcName())) {
                MtxRequestSubscriberModifyOffer modify = (MtxRequestSubscriberModifyOffer) req;
                if (modify.getResourceId().toString().equalsIgnoreCase(vodAnnual.getResourceId())) {
                    foundSvcReq = true;
                    attr = (VisiblePurchasedOfferExtension) modify.getAttr();
                }
            }
        }

        System.out.println(td.getTestMethod() + ":" + response.toJson());
        assertTrue(foundSvcReq);
        assertFalse(attr.getCreditTaxDetailsArray() == null);
        assertFalse(attr.getCreditTaxDetailsArray().isEmpty());
        assertTrue(StringUtils.isNotBlank(attr.getAtCreditTaxDetailsArray(0)));
    }

    @SuppressWarnings("rawtypes")
    @ParameterizedTest(
            name = "test_autoPay_When_FreeAddon_NoInsurance_NoRecharge_Then_No_MDN_in_RechargeReq")
    @Tag("VER-654")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription has service and wearable device. Enrolled in plusannual with free addon.|"
                +"|     |Has no insurance. In first 11 months of service.|"
                +"|When |Api called betwen 1st to 11th month to pay.|"
                +"|Then |Multirequest has no recharge request.|"})
    // @formatter:on
    public void test_autoPay_When_FreeAddon_NoInsurance_NoRecharge_Then_No_MDN_in_RechargeReq(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(
                        List.of(
                                CI_EXTERNAL_IDS.PLUS3ANNUAL,
                                CI_EXTERNAL_IDS.WEARABLE_ANNUAL_2023)));
        makeSubscreiptionAutopayReady(subscription);

        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        List<VisibleResponsePaymentAdviceService> aopList = new ArrayList<VisibleResponsePaymentAdviceService>();
        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                VisibleResponsePaymentAdviceService aop = CommonTestHelper.getPaymentAdviceResponse(
                        invocation, subscription);
                aopList.add(aop);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");

        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        argumentCaptor.getAllValues().forEach(multi -> {
            printUnitTest(multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        printUnitTest(response.toJson());
        List<String> requests = new ArrayList<String>();
        multiReq.getRequestList().forEach(req -> {
            requests.add(req.getMdcName());
        });
        printUnitTest(multiReq.toJson());
        assertFalse(requests.contains(MtxRequestSubscriberRecharge.class.getSimpleName()));
    }

    @SuppressWarnings({
        "rawtypes"
    })
    @ParameterizedTest(
            name = "test_autoPay_When_FreeAddon_ChargeInsuranceOnly_Then_No_MDN_In_RechargeAttr")
    @Tag("VER-654")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription  has wearable device. Enrolled in plusannual with free addon.|"
                +"|     |HAS insurance. In first 11 months of service.|"
                +"|When |Api called betwen 1st to 11th month to pay.|"
                +"|Then |recharge request has no recharge attributes with device details(Neither Service Nor Wearable).|"
                +"|     |Has order id.|"})
    // @formatter:on
    public void test_autoPay_When_FreeAddon_ChargeInsuranceOnly_Then_No_MDN_In_RechargeAttr(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(
                        List.of(
                                CI_EXTERNAL_IDS.PLUS3ANNUAL, CI_EXTERNAL_IDS.WEARABLE_ANNUAL_2023,
                                CI_EXTERNAL_IDS.INSURANCE)));
        makeSubscreiptionAutopayReady(subscription);

        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        List<VisibleResponsePaymentAdviceService> aopList = new ArrayList<VisibleResponsePaymentAdviceService>();
        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                VisibleResponsePaymentAdviceService aop = CommonTestHelper.getPaymentAdviceResponse(
                        invocation, subscription);
                aopList.add(aop);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");

        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        argumentCaptor.getAllValues().forEach(multi -> {
            printUnitTest(multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        printUnitTest(response.toJson());
        printUnitTest(multiReq.toJson());
        MtxRequestSubscriberRecharge rechReq = null;
        for (MtxRequest req : multiReq.getRequestList()) {
            if (MtxRequestSubscriberRecharge.class.getSimpleName().equalsIgnoreCase(
                    req.getMdcName()))
                rechReq = (MtxRequestSubscriberRecharge) req;
        }

        VisibleRechargeExtension rechAttr = (VisibleRechargeExtension) rechReq.getRechargeAttr();
        assertNotNull(rechReq);

        assertNull(rechAttr.getServiceMDN());
        assertNull(rechAttr.getRatePlan());
        assertNull(rechAttr.getPlanAmount());

        assertNull(rechAttr.getWearableMDN());
        assertNull(rechAttr.getWearableRatePlan());
        assertNull(rechAttr.getWearablePlanAmount());
    }

    @SuppressWarnings({
        "rawtypes", "unchecked"
    })
    @ParameterizedTest(
            name = "test_autoPay_When_ServiceWithFreeAddon_No_WearableDevice_ChargeAll_Then_ServiceMDN_In_RechargeAttr")
    @Tag("VER-654")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription  has service device. No wearable device. Enrolled in plusannual with free addon.|"
                +"|     |In 12th month, need to pay for renewal of next year.|"
                +"|When |Api called to renew for next year.|"
                +"|Then |Recharge request has recharge attributes with service device details.|"})
    // @formatter:on
    public void test_autoPay_When_ServiceWithFreeAddon_No_WearableDevice_ChargeAll_Then_ServiceMDN_In_RechargeAttr(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(
                        List.of(
                                CI_EXTERNAL_IDS.PLUS3ANNUAL,
                                CI_EXTERNAL_IDS.WEARABLE_ANNUAL_2023)));
        makeSubscreiptionAutopayReady(subscription);

        MtxPurchasedOfferInfo po = subscription.getAtPurchasedOfferArray(0);
        po.getCycleInfo().setCycleEndTime(subscription.getBillingCycle().getCurrentPeriodEndTime());

        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        subscription.getDeviceIdArrayAppender().clear();
        subscription.getDeviceIdArrayAppender().add(new MtxObjectId("1-2-3-4"));
        List<VisibleResponsePaymentAdviceService> aopList = new ArrayList<VisibleResponsePaymentAdviceService>();
        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                VisibleResponsePaymentAdviceService aop = CommonTestHelper.getPaymentAdviceResponse(
                        invocation, subscription);
                aopList.add(aop);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");

        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        VisibleOfferDetails vodBase = aopList.get(0).getVisibleOfferDetailsList().stream().filter(
                vod -> OFFER_CONSTANTS.OFFER_TYPE_BASE.equalsIgnoreCase(
                        vod.getOfferType())).findFirst().get();

        String baseMDN = "";
        for (VisibleSubscriberDevice dev : aopList.get(0).getSubscriberDevices()) {
            if (DEVICE_CONSTANTS.DEVICE_TYPE_WEARABLE.equalsIgnoreCase(dev.getDeviceType())) {
            } else {
                baseMDN = dev.getAccessNumber();
            }
        }

        argumentCaptor.getAllValues().forEach(multi -> {
            printUnitTest(multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        printUnitTest(response.toJson());
        printUnitTest(multiReq.toJson());
        MtxRequestSubscriberRecharge rechReq = null;
        for (MtxRequest req : multiReq.getRequestList()) {
            if (MtxRequestSubscriberRecharge.class.getSimpleName().equalsIgnoreCase(
                    req.getMdcName()))
                rechReq = (MtxRequestSubscriberRecharge) req;
        }

        VisibleRechargeExtension rechAttr = (VisibleRechargeExtension) rechReq.getRechargeAttr();
        assertNotNull(rechReq);

        assertEquals(baseMDN, rechAttr.getServiceMDN());
        assertEquals(vodBase.getCatalogItemExternalId(), rechAttr.getRatePlan());
        assertEquals(vodBase.getChargeAmount().toPlainString(), rechAttr.getPlanAmount());

        assertNull(rechAttr.getWearableMDN());
        assertNull(rechAttr.getWearableRatePlan());
        assertNull(rechAttr.getWearablePlanAmount());
    }

    @SuppressWarnings({
        "rawtypes"
    })
    @ParameterizedTest(
            name = "test_autoPay_When_ServiceWithFreeAddon_Has_Wearable_Device_ChargeAll_Then_BothMDN_In_RechargeAttr")
    @Tag("VER-654")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription  has service and wearable device. Enrolled in plusannual with free addon.|"
                +"|     |In 12th month, need to pay for renewal of next year.|"
                +"|When |Api called to renew for next year.|"
                +"|Then |Recharge request has recharge attributes with service and wearable device details.|"})
    // @formatter:on
    public void test_autoPay_When_ServiceWithFreeAddon_Has_Wearable_Device_ChargeAll_Then_BothMDN_In_RechargeAttr(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(
                        List.of(
                                CI_EXTERNAL_IDS.PLUS3ANNUAL,
                                CI_EXTERNAL_IDS.WEARABLE_ANNUAL_2023)));
        makeSubscreiptionAutopayReady(subscription);

        MtxPurchasedOfferInfo po = subscription.getAtPurchasedOfferArray(0);
        po.getCycleInfo().setCycleEndTime(subscription.getBillingCycle().getCurrentPeriodEndTime());

        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        List<VisibleResponsePaymentAdviceService> aopList = new ArrayList<VisibleResponsePaymentAdviceService>();
        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                VisibleResponsePaymentAdviceService aop = CommonTestHelper.getPaymentAdviceResponse(
                        invocation, subscription);
                aopList.add(aop);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");

        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        VisibleOfferDetails vodBase = aopList.get(0).getVisibleOfferDetailsList().stream().filter(
                vod -> OFFER_CONSTANTS.OFFER_TYPE_BASE.equalsIgnoreCase(
                        vod.getOfferType())).findFirst().get();
        VisibleOfferDetails vodAddon = aopList.get(0).getVisibleOfferDetailsList().stream().filter(
                vod -> OFFER_CONSTANTS.OFFER_TYPE_ADDON.equalsIgnoreCase(
                        vod.getOfferType())).findFirst().get();

        String baseMDN = "";
        String wblMDN = "";
        for (VisibleSubscriberDevice dev : aopList.get(0).getSubscriberDevices()) {
            if (DEVICE_CONSTANTS.DEVICE_TYPE_WEARABLE.equalsIgnoreCase(dev.getDeviceType())) {
                wblMDN = dev.getAccessNumber();
            } else {
                baseMDN = dev.getAccessNumber();
            }
        }

        argumentCaptor.getAllValues().forEach(multi -> {
            printUnitTest(multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        printUnitTest(response.toJson());
        printUnitTest(multiReq.toJson());
        MtxRequestSubscriberRecharge rechReq = null;
        for (MtxRequest req : multiReq.getRequestList()) {
            if (MtxRequestSubscriberRecharge.class.getSimpleName().equalsIgnoreCase(
                    req.getMdcName()))
                rechReq = (MtxRequestSubscriberRecharge) req;
        }

        VisibleRechargeExtension rechAttr = (VisibleRechargeExtension) rechReq.getRechargeAttr();
        assertNotNull(rechReq);

        assertEquals(baseMDN, rechAttr.getServiceMDN());
        assertEquals(vodBase.getCatalogItemExternalId(), rechAttr.getRatePlan());
        assertEquals(vodBase.getChargeAmount().toPlainString(), rechAttr.getPlanAmount());

        assertEquals(wblMDN, rechAttr.getWearableMDN());
        assertEquals(vodAddon.getCatalogItemExternalId(), rechAttr.getWearableRatePlan());
        assertNull(rechAttr.getWearablePlanAmount());
    }

    @SuppressWarnings("rawtypes")
    @ParameterizedTest(
            name = "test_autoPay_When_PaidAddon_ChargeAddon_Then_Wearable_MDN_In_RechargeReq")
    @Tag("VER-654")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription  has service and wearable device. Enrolled in baseannual with paid addon.|"
                +"|     |In first 11 months of service.|"
                +"|When |Api called betwen 1st to 11th month to pay.|"
                +"|Then |Recharge request has recharge attributes with wearable device details.|"})
    // @formatter:on
    public void test_autoPay_When_PaidAddon_ChargeAddon_Then_Wearable_MDN_In_RechargeReq(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(
                        List.of(
                                CI_EXTERNAL_IDS.BASE3ANNUAL,
                                CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023)));
        makeSubscreiptionAutopayReady(subscription);

        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        List<VisibleResponsePaymentAdviceService> aopList = new ArrayList<VisibleResponsePaymentAdviceService>();
        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                VisibleResponsePaymentAdviceService aop = CommonTestHelper.getPaymentAdviceResponse(
                        invocation, subscription);
                aopList.add(aop);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");

        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        argumentCaptor.getAllValues().forEach(multi -> {
            printUnitTest(multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        printUnitTest(response.toJson());
        printUnitTest(multiReq.toJson());

        VisibleOfferDetails vodAddon = aopList.get(0).getVisibleOfferDetailsList().stream().filter(
                vod -> OFFER_CONSTANTS.OFFER_TYPE_ADDON.equalsIgnoreCase(
                        vod.getOfferType())).findFirst().get();

        String wblMDN = "";
        for (VisibleSubscriberDevice dev : aopList.get(0).getSubscriberDevices()) {
            if (DEVICE_CONSTANTS.DEVICE_TYPE_WEARABLE.equalsIgnoreCase(dev.getDeviceType())) {
                wblMDN = dev.getAccessNumber();
            }
        }

        MtxRequestSubscriberRecharge rechReq = null;
        for (MtxRequest req : multiReq.getRequestList()) {
            if (MtxRequestSubscriberRecharge.class.getSimpleName().equalsIgnoreCase(
                    req.getMdcName()))
                rechReq = (MtxRequestSubscriberRecharge) req;
        }

        VisibleRechargeExtension rechAttr = (VisibleRechargeExtension) rechReq.getRechargeAttr();
        assertNotNull(rechReq);

        assertNull(rechAttr.getServiceMDN());
        assertNull(rechAttr.getRatePlan());
        assertNull(rechAttr.getPlanAmount());

        assertEquals(wblMDN, rechAttr.getWearableMDN());
        assertEquals(vodAddon.getCatalogItemExternalId(), rechAttr.getWearableRatePlan());
        assertEquals(vodAddon.getChargeAmount().toPlainString(), rechAttr.getWearablePlanAmount());
    }

    @SuppressWarnings("rawtypes")
    @ParameterizedTest(
            name = "test_autoPay_When_ServiceWithPaidAddon_ChargeAll_Then_BothMDN_In_RechargeAttr")
    @Tag("VER-654")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription  has service and wearable device. Enrolled in baseannual with paid addon.|"
                +"|     |In 12th month, need to pay for renewal of next year.|"
                +"|When |Api called to renew for next year.|"
                +"|Then |Recharge request has recharge attributes with both service and wearable device details.|"})
    // @formatter:on
    public void test_autoPay_When_ServiceWithPaidAddon_ChargeAll_Then_BothMDN_In_RechargeAttr(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(
                        List.of(
                                CI_EXTERNAL_IDS.BASE3ANNUAL,
                                CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023)));
        makeSubscreiptionAutopayReady(subscription);

        MtxPurchasedOfferInfo po = subscription.getAtPurchasedOfferArray(0);
        po.getCycleInfo().setCycleEndTime(subscription.getBillingCycle().getCurrentPeriodEndTime());

        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        List<VisibleResponsePaymentAdviceService> aopList = new ArrayList<VisibleResponsePaymentAdviceService>();
        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                VisibleResponsePaymentAdviceService aop = CommonTestHelper.getPaymentAdviceResponse(
                        invocation, subscription);
                aopList.add(aop);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");

        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        VisibleOfferDetails vodBase = aopList.get(0).getVisibleOfferDetailsList().stream().filter(
                vod -> OFFER_CONSTANTS.OFFER_TYPE_BASE.equalsIgnoreCase(
                        vod.getOfferType())).findFirst().get();
        VisibleOfferDetails vodAddon = aopList.get(0).getVisibleOfferDetailsList().stream().filter(
                vod -> OFFER_CONSTANTS.OFFER_TYPE_ADDON.equalsIgnoreCase(
                        vod.getOfferType())).findFirst().get();

        String baseMDN = "";
        String wblMDN = "";
        for (VisibleSubscriberDevice dev : aopList.get(0).getSubscriberDevices()) {
            if (DEVICE_CONSTANTS.DEVICE_TYPE_WEARABLE.equalsIgnoreCase(dev.getDeviceType())) {
                wblMDN = dev.getAccessNumber();
            } else {
                baseMDN = dev.getAccessNumber();
            }
        }
        argumentCaptor.getAllValues().forEach(multi -> {
            printUnitTest(multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        printUnitTest(response.toJson());
        printUnitTest(multiReq.toJson());
        MtxRequestSubscriberRecharge rechReq = null;
        for (MtxRequest req : multiReq.getRequestList()) {
            if (MtxRequestSubscriberRecharge.class.getSimpleName().equalsIgnoreCase(
                    req.getMdcName()))
                rechReq = (MtxRequestSubscriberRecharge) req;
        }

        VisibleRechargeExtension rechAttr = (VisibleRechargeExtension) rechReq.getRechargeAttr();
        assertNotNull(rechReq);

        assertEquals(baseMDN, rechAttr.getServiceMDN());
        assertEquals(vodBase.getCatalogItemExternalId(), rechAttr.getRatePlan());
        assertEquals(vodBase.getChargeAmount().toPlainString(), rechAttr.getPlanAmount());

        assertEquals(wblMDN, rechAttr.getWearableMDN());
        assertEquals(vodAddon.getCatalogItemExternalId(), rechAttr.getWearableRatePlan());
        assertEquals(vodAddon.getChargeAmount().toPlainString(), rechAttr.getWearablePlanAmount());

    }

    @SuppressWarnings({
        "rawtypes", "unchecked"
    })
    @ParameterizedTest(
            name = "test_autoPay_When_MonthlyServiceWithFreeAddon_No_WearableDevice_ChargeAll_Then_ServiceMDN_In_RechargeAttr")
    @Tag("VER-655")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription  has service device. Has no wearable device. Enrolled in plus monthly with free addon.|"     
                +"|When |Api called to renew.|"
                +"|Then |Recharge request has recharge attributes with service device details.|"})
    // @formatter:on
    public void test_autoPay_When_MonthlyServiceWithFreeAddon_No_WearableDevice_ChargeAll_Then_ServiceMDN_In_RechargeAttr(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(
                        List.of(
                                CI_EXTERNAL_IDS.PLUS3VIS23WB,
                                CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION)));
        makeSubscreiptionAutopayReady(subscription);

        MtxPurchasedOfferInfo po = subscription.getAtPurchasedOfferArray(0);
        po.getCycleInfo().setCycleEndTime(subscription.getBillingCycle().getCurrentPeriodEndTime());

        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        subscription.getDeviceIdArrayAppender().clear();
        subscription.getDeviceIdArrayAppender().add(new MtxObjectId("1-2-3-4"));
        List<VisibleResponsePaymentAdviceService> aopList = new ArrayList<VisibleResponsePaymentAdviceService>();
        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                VisibleResponsePaymentAdviceService aop = CommonTestHelper.getPaymentAdviceResponse(
                        invocation, subscription);
                aopList.add(aop);
                return null;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");

        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        VisibleOfferDetails vodBase = aopList.get(0).getVisibleOfferDetailsList().stream().filter(
                vod -> OFFER_CONSTANTS.OFFER_TYPE_BASE.equalsIgnoreCase(
                        vod.getOfferType())).findFirst().get();

        String baseMDN = "";
        for (VisibleSubscriberDevice dev : aopList.get(0).getSubscriberDevices()) {
            if (DEVICE_CONSTANTS.DEVICE_TYPE_WEARABLE.equalsIgnoreCase(dev.getDeviceType())) {
            } else {
                baseMDN = dev.getAccessNumber();
            }
        }

        argumentCaptor.getAllValues().forEach(multi -> {
            printUnitTest(multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        printUnitTest(response.toJson());
        printUnitTest(multiReq.toJson());
        MtxRequestSubscriberRecharge rechReq = null;
        for (MtxRequest req : multiReq.getRequestList()) {
            if (MtxRequestSubscriberRecharge.class.getSimpleName().equalsIgnoreCase(
                    req.getMdcName()))
                rechReq = (MtxRequestSubscriberRecharge) req;
        }

        VisibleRechargeExtension rechAttr = (VisibleRechargeExtension) rechReq.getRechargeAttr();
        assertNotNull(rechReq);

        assertEquals(baseMDN, rechAttr.getServiceMDN());
        assertEquals(vodBase.getCatalogItemExternalId(), rechAttr.getRatePlan());
        assertEquals(vodBase.getChargeAmount().toPlainString(), rechAttr.getPlanAmount());

        assertNull(rechAttr.getWearableMDN());
        assertNull(rechAttr.getWearableRatePlan());
        assertNull(rechAttr.getWearablePlanAmount());
    }

    @SuppressWarnings({
        "rawtypes", "unchecked"
    })
    @ParameterizedTest(
            name = "test_autoPay_When_MonthlyServiceWithFreeAddon_Has_WearableDevice_ChargeAll_Then_BothMDN_In_RechargeAttr")
    @Tag("VER-654")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription  has service and wearable device. Enrolled in plus monthly with free addon.|"     
                +"|When |Api called to renew.|"
                +"|Then |Recharge request has recharge attributes with service and wearable device details.|"})
    // @formatter:on
    public void test_autoPay_When_MonthlyServiceWithFreeAddon_Has_WearableDevice_ChargeAll_Then_BothMDN_In_RechargeAttr(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(
                        List.of(
                                CI_EXTERNAL_IDS.PLUS3VIS23WB,
                                CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION)));
        makeSubscreiptionAutopayReady(subscription);

        MtxPurchasedOfferInfo po = subscription.getAtPurchasedOfferArray(0);
        po.getCycleInfo().setCycleEndTime(subscription.getBillingCycle().getCurrentPeriodEndTime());

        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        subscription.getDeviceIdArrayAppender().clear();
        subscription.getDeviceIdArrayAppender().add(new MtxObjectId("1-2-3-4"));
        List<VisibleResponsePaymentAdviceService> aopList = new ArrayList<VisibleResponsePaymentAdviceService>();
        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                VisibleResponsePaymentAdviceService aop = CommonTestHelper.getPaymentAdviceResponse(
                        invocation, subscription);
                aopList.add(aop);
                return aop;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());

        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");

        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }

        VisibleOfferDetails vodBase = aopList.get(0).getVisibleOfferDetailsList().stream().filter(
                vod -> OFFER_CONSTANTS.OFFER_TYPE_BASE.equalsIgnoreCase(
                        vod.getOfferType())).findFirst().get();

        String baseMDN = "";
        for (VisibleSubscriberDevice dev : aopList.get(0).getSubscriberDevices()) {
            if (DEVICE_CONSTANTS.DEVICE_TYPE_WEARABLE.equalsIgnoreCase(dev.getDeviceType())) {

            } else {
                baseMDN = dev.getAccessNumber();
            }
        }

        argumentCaptor.getAllValues().forEach(multi -> {
            printUnitTest(multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        printUnitTest(response.toJson());
        printUnitTest(multiReq.toJson());
        MtxRequestSubscriberRecharge rechReq = null;
        for (MtxRequest req : multiReq.getRequestList()) {
            if (MtxRequestSubscriberRecharge.class.getSimpleName().equalsIgnoreCase(
                    req.getMdcName()))
                rechReq = (MtxRequestSubscriberRecharge) req;
        }

        VisibleRechargeExtension rechAttr = (VisibleRechargeExtension) rechReq.getRechargeAttr();
        assertNotNull(rechReq);

        assertEquals(baseMDN, rechAttr.getServiceMDN());
        assertEquals(vodBase.getCatalogItemExternalId(), rechAttr.getRatePlan());
        assertEquals(vodBase.getChargeAmount().toPlainString(), rechAttr.getPlanAmount());

        assertNull(rechAttr.getWearableMDN());
        assertNull(rechAttr.getWearableRatePlan());
        assertNull(rechAttr.getWearablePlanAmount());
    }

    @SuppressWarnings("rawtypes")
    @ParameterizedTest(
            name = "test_autoPay_When_MonthlyServiceWithPaidAddon_Has_WearableDevice_ChargeAll_Then_BothMDN_In_RechargeAttr")
    @Tag("VER-654")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscription  has service and wearable device. Enrolled in base monthly with paid addon.|"     
                +"|When |Api called to renew.|"
                +"|Then |Recharge request has recharge attributes with service and wearable device details.|"})
    // @formatter:on
    public void test_autoPay_When_MonthlyServiceWithPaidAddon_Has_WearableDevice_ChargeAll_Then_BothMDN_In_RechargeAttr(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        SubscriptionResponse subscription = emulateSubscriptionResponse(
                instance,
                CommonTestHelper.getSubscriptionResponse(
                        List.of(
                                CI_EXTERNAL_IDS.BASE3VIS23,
                                CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023)));
        makeSubscreiptionAutopayReady(subscription);

        emulateMtxResponseUser(instance, CommonTestHelper.getMtxResponseUser());
        MtxPaymentMethodInfo pmi = CommonTestHelper.getDefaultMtxPaymentMethodInfo();
        emulateMtxResponsePaymentMethodInfo(instance, pmi);

        List<VisibleResponsePaymentAdviceService> aopList = new ArrayList<VisibleResponsePaymentAdviceService>();
        doAnswer(new Answer() {

            public Object answer(InvocationOnMock invocation) {
                VisibleResponsePaymentAdviceService aop = CommonTestHelper.getPaymentAdviceResponse(
                        invocation, subscription);
                aopList.add(aop);
                return aop;
            }
        }).when(adviceInstance).getAOPForAutopay(any(), any(), any());
        MtxResponseMulti multiResp = new MtxResponseMulti();
        multiResp.setResult(RESULT_CODES.MTX_SUCCESS);
        ArgumentCaptor<MtxRequestMulti> argumentCaptor = ArgumentCaptor.forClass(
                MtxRequestMulti.class);
        doReturn(multiResp).when(instance).multiRequest(any(), any(), argumentCaptor.capture());

        VisibleRequestAutoPay request = new VisibleRequestAutoPay();
        request.setSubscriptionExternalId(subscription.getExternalId());
        VisibleResponseAutoPay response = new VisibleResponseAutoPay();
        MtxResponse qResp = new MtxResponse();
        qResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        qResp.setResultText("OK");

        try (MockedStatic<ActiveMQClient> mockedStatic = Mockito.mockStatic(ActiveMQClient.class)) {
            mockedStatic.when(
                    () -> ActiveMQClient.sendAuopayMessage(any(), any(), any())).thenReturn(qResp);
            instance.autoPay(request, response);
        }
        printUnitTest(aopList.get(0).toJson());
        VisibleOfferDetails vodBase = aopList.get(0).getVisibleOfferDetailsList().stream().filter(
                vod -> OFFER_CONSTANTS.OFFER_TYPE_BASE.equalsIgnoreCase(
                        vod.getOfferType())).findFirst().get();
        VisibleOfferDetails vodAddon = aopList.get(0).getVisibleOfferDetailsList().stream().filter(
                vod -> OFFER_CONSTANTS.OFFER_TYPE_ADDON.equalsIgnoreCase(
                        vod.getOfferType())).findFirst().get();

        String baseMDN = "";
        String wblMDN = "";
        for (VisibleSubscriberDevice dev : aopList.get(0).getSubscriberDevices()) {
            if (DEVICE_CONSTANTS.DEVICE_TYPE_WEARABLE.equalsIgnoreCase(dev.getDeviceType())) {
                wblMDN = dev.getAccessNumber();
            } else {
                baseMDN = dev.getAccessNumber();
            }
        }
        printUnitTest(subscription.toJson());
        argumentCaptor.getAllValues().forEach(multi -> {
            printUnitTest(multi.toJson());
        });
        MtxRequestMulti multiReq = argumentCaptor.getValue();
        printUnitTest(response.toJson());
        printUnitTest(multiReq.toJson());
        MtxRequestSubscriberRecharge rechReq = null;
        for (MtxRequest req : multiReq.getRequestList()) {
            if (MtxRequestSubscriberRecharge.class.getSimpleName().equalsIgnoreCase(
                    req.getMdcName()))
                rechReq = (MtxRequestSubscriberRecharge) req;
        }

        VisibleRechargeExtension rechAttr = (VisibleRechargeExtension) rechReq.getRechargeAttr();
        assertNotNull(rechReq);

        assertEquals(baseMDN, rechAttr.getServiceMDN());
        assertEquals(vodBase.getCatalogItemExternalId(), rechAttr.getRatePlan());
        assertEquals(vodBase.getChargeAmount().toPlainString(), rechAttr.getPlanAmount());

        assertEquals(wblMDN, rechAttr.getWearableMDN());
        assertEquals(vodAddon.getCatalogItemExternalId(), rechAttr.getWearableRatePlan());
        assertEquals(vodAddon.getChargeAmount().toPlainString(), rechAttr.getWearablePlanAmount());
    }

    /*********************** Private Methods ********************************/
    private void printUnitTest(Object msg) {
        System.out.println(testInfo.getDisplayName() + ":" + msg);
    }

    private void makeSubscreiptionAutopayReady(SubscriptionResponse subscription) {
        MtxTimestamp endTime = TestUtils.getTimestampAfterHoursFromNow(
                subscription.getTimeZone(), 24);

        VisibleSubscriberExtension subAttr = (VisibleSubscriberExtension) subscription.getAttr();
        subAttr.setPaymentPreference(PAYMENT_CONSTANTS.AUTOPAY);
        subscription.setStatusDescription(SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE);
        subscription.getBillingCycle().setCurrentPeriodEndTime(endTime);

    }

}
