package com.matrixx.vag.payment.service;

import static org.junit.jupiter.api.Assertions.fail;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;

import com.matrixx.datacontainer.mdc.ManualPayRequest;
import com.matrixx.datacontainer.mdc.VisibleRequestRecharge;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;

import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.exception.InvalidRequestException;
import com.matrixx.vag.exception.InvalidRequestParameterException;
import com.matrixx.vag.exception.MissingRequestParametersException;
import com.matrixx.vag.exception.VisibleUnitTestException;
import com.matrixx.vag.util.MDCTest;

public class RequestValidatorTest extends MDCTest {

    final String LOGGING_KEY = "UnitTest";
    private TestInfo testInfo;

    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        this.testInfo = testInfo;
    }
    @Test
    public void test()
            throws InvalidRequestException, 
            IOException, VisibleUnitTestException {

        ManualPayRequest input = CommonTestHelper.loadJsonMessage(
                ManualPayRequest.class, "src/test/resources/data/manualpay/ManualPayRequest.json");
        RequestValidator.validateRequest(LOGGING_KEY, input);

        input.getCredits().get(0).setApprovedTransferableCredits(new BigDecimal("10.0"));
        RequestValidator.validateRequest(LOGGING_KEY, input);

        input.getCredits().get(0).setApprovedTransferableCredits(new BigDecimal("0.0"));
        RequestValidator.validateRequest(LOGGING_KEY, input);

        try {
            input.getPayNow().setPaymentInfo(null);
            RequestValidator.validateRequest(LOGGING_KEY, input);
            fail("Expecting MissingRequestParametersException");
        } catch (MissingRequestParametersException ex) {
            System.out.println(ex.getMessage());
        }

        try {
            input.getVisibleOfferDetailsList().get(0).setResourceId("Error");
            RequestValidator.validateRequest(LOGGING_KEY, input);
            fail("Expecting InvalidRequestParameterException");
        } catch (InvalidRequestParameterException ex) {
            System.out.println(ex.getMessage());
        }

        try {
            input.getVisibleOfferDetailsList().get(0).setResourceId(null);
            RequestValidator.validateRequest(LOGGING_KEY, input);
            fail("Expecting MissingRequestParametersException");
        } catch (MissingRequestParametersException ex) {
            System.out.println(ex.getMessage());
        }

        try {
            input.getPayNow().setChargeAmount(new BigDecimal("0.0"));
            input.getCredits().get(0).setApprovedTransferableCredits(null);
            RequestValidator.validateRequest(LOGGING_KEY, input);
            fail("Expecting MissingRequestParametersException");
        } catch (MissingRequestParametersException ex) {
            System.out.println(ex.getMessage());
        }

    }

    @ParameterizedTest(name = "test_recharge_When_NoOrderId_Then_Error")
    @Tag("VER-771") @Tag("VER-791")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|None.|"
                +"|When |No orderID in input request.|"
                +"|Then |Error.|"})
    // @formatter:on
    public void test_recharge_When_NoOrderId_Then_Error(ArgumentsAccessor acceptance) throws VisibleUnitTestException, IOException, InvalidRequestException {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestRecharge request = CommonTestHelper.getVisibleRequestRecharge("12345",
                "67890", "",List.of(CI_EXTERNAL_IDS.PLUS25));
        System.out.println(td.getTestMethod() + ":" +request.toJson());

        Exception exception = assertThrows(
                MissingRequestParametersException.class, () -> RequestValidator.validateRequest(LOGGING_KEY, request));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("Missing mandatory parameter OrderId"));
    }
    
    @ParameterizedTest(name = "test_recharge_When_NoRechargeAmount_Then_Error")
    @Tag("VER-771") @Tag("VER-791")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|None.|"
                +"|When |No Recharge Amount in input request.|"
                +"|Then |Error.|"})
    // @formatter:on
    public void test_recharge_When_NoRechargeAmount_Then_Error(ArgumentsAccessor acceptance) throws VisibleUnitTestException, IOException {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestRecharge request = CommonTestHelper.getVisibleRequestRecharge("12345",
                "67890", "O-12345",null);
        System.out.println(td.getTestMethod() + ":" +request.toJson());

        Exception exception = assertThrows(
                MissingRequestParametersException.class, () -> RequestValidator.validateRequest(LOGGING_KEY, request));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("Invalid value for parameter RechargeAmount"));   
    }
    
    @ParameterizedTest(name = "test_recharge_When_NoBeneficiaryMDN_Then_Error")
    @Tag("VER-771") @Tag("VER-791")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|None.|"
                +"|When |No Beneficiary Service MDN in input request.|"
                +"|Then |Error.|"})
    // @formatter:on
    public void test_recharge_When_NoBeneficiaryMDN_Then_Error(ArgumentsAccessor acceptance) throws VisibleUnitTestException, IOException {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestRecharge request = CommonTestHelper.getVisibleRequestRecharge("12345",
                "67890", "O-12345",List.of(CI_EXTERNAL_IDS.PLUS25), true);
        System.out.println(td.getTestMethod() + ":" +request.toJson());

        Exception exception = assertThrows(
                MissingRequestParametersException.class, () -> RequestValidator.validateRequest(LOGGING_KEY, request));
        System.out.println(td.getTestMethod() + ":");
        exception.printStackTrace();
        assertTrue(exception.getMessage().startsWith("Missing mandatory parameter ServiceMDN"));
    }
}
