package com.matrixx.vag.util;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.BeforeClass;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.matrixx.datacontainer.Containers;
import com.matrixx.datacontainer.DataContainerFactory;
import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.EventQueryResponseEvents;
import com.matrixx.datacontainer.mdc.MtxBalanceImpactInfo;
import com.matrixx.datacontainer.mdc.MtxBalanceInfo;
import com.matrixx.datacontainer.mdc.MtxPaymentMethodInfo;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.MtxResponseGroup;
import com.matrixx.datacontainer.mdc.MtxResponseMulti;
import com.matrixx.datacontainer.mdc.MtxResponseOneTimeOffer;
import com.matrixx.datacontainer.mdc.MtxResponsePaymentMethodInfo;
import com.matrixx.datacontainer.mdc.MtxResponsePricingCatalogItem;
import com.matrixx.datacontainer.mdc.MtxResponsePurchase;
import com.matrixx.datacontainer.mdc.MtxResponseRecurringChargeInfo;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.MtxResponseUser;
import com.matrixx.datacontainer.mdc.MtxResponseWallet;
import com.matrixx.datacontainer.mdc.MtxSubscriberSearchData;
import com.matrixx.datacontainer.mdc.SubscriptionResponse;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.advice.service.PaymentAdviceService;
import com.matrixx.vag.common.Constants.CREDIT_CONSTANTS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.Constants.SUBSCRIBER_SERVICE_CONSTANTS;
import com.matrixx.vag.common.TestConstants.DATA_DIR;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.VisibleUnitTestException;
import com.matrixx.vag.service.IntegrationService;

/*
 * Base class for unit tests that require MATRIXX Data Container (MDC) to be initialized.
 */
public class MDCTest {

    protected static DataContainerFactory dcf;
    protected static Containers containers;   
    //private static final Logger m_logger = LoggerFactory.getLogger(MDCTest.class);

    static {
        System.setProperty("rsgateway.extensions", "rsgateway.properties");

        // Merge base MDC definitions with the custom MDC definitions to create a single file for
        // initilisation
        final String SOURCE_FILE1 = "../extensions/src/main/resources/mdc_config_custom.xml";
        final String SOURCE_FILE2 = "../extensions/src/main/resources/extension-rest-mdc.xml";
        final String SOURCE_FILE3 = "build/rsgateway-mdc.xml";

        final String MDC_CONFIG_TMP = "build/tmp/test/mdc_config_custom_tmp.xml";
        final String MDC_CONFIG_ALL = "build/tmp/test/mdc_config_custom.xml";

        final String MTX_CONTAINERS = "build/mtx_containers.xml";

        mergeMdcFiles(SOURCE_FILE1, SOURCE_FILE2, MDC_CONFIG_TMP);
        mergeMdcFiles(MDC_CONFIG_TMP, SOURCE_FILE3, MDC_CONFIG_ALL);

        DataContainerFactory.addExtraFile(MDC_CONFIG_ALL);
        dcf = DataContainerFactory.getInstance(MTX_CONTAINERS);
        containers = Containers.instance();
        setJunitOnlyProperties();
    }

    public static void setJunitOnlyProperties() {
        System.out.println("Set junit only properties from  cgiTesting.properties");        
        try (BufferedReader br1 = new BufferedReader(new FileReader("src/test/resources/cgiTesting.properties"))) {
            String line1 = null;
            while ((line1 = br1.readLine()) != null) {
                String prop[]=line1.split("=");
                if(StringUtils.isBlank(line1)) {
                    continue;
                }else if("change.service.type.list.start.immediate".equalsIgnoreCase(prop[0].trim())) {
                    String extendProp = AppPropertyProvider.getInstance().getProperty("change.service.type.list.start.immediate")+","+prop[1].trim();
                    AppPropertyProvider.getInstance().setProperty(prop[0].trim(), extendProp);
                }else {
                    AppPropertyProvider.getInstance().setProperty(prop[0].trim(), prop[1].trim());    
                }                    
            }            
        } catch (IOException e) {
            throw new RuntimeException(e);
        }        
    }
    
    public static void mergeMdcFiles(String sourceFile1, String sourceFile2, String targetFile) {
        System.out.println(
                "Merging " + sourceFile1 + " and " + sourceFile2 + " into " + targetFile);
        try {
            BufferedReader br1 = new BufferedReader(new FileReader(sourceFile1));
            BufferedReader br2 = new BufferedReader(new FileReader(sourceFile2));
            Files.createDirectories(Paths.get(targetFile).getParent());
            BufferedWriter br3 = new BufferedWriter(new FileWriter(targetFile));
            String line1 = null;
            while ((line1 = br1.readLine()) != null) {
                if (line1.trim().contains("</mdc_configuration>")) {
                    String line2 = null;
                    boolean skipHeaders = true;
                    while ((line2 = br2.readLine()) != null) {
                        if (line2.contains("<container") || line2.contains("<subtype")) {
                            skipHeaders = false;
                        }
                        if (!skipHeaders && !line2.trim().contains("</mdc_configuration>")
                                && !line2.trim().contains("</configuration>")) {
                            br3.write(line2);
                            br3.write("\n");
                        }
                    }
                }
                br3.write(line1);
                br3.write("\n");
            }
            br1.close();
            br2.close();
            br3.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @BeforeClass
    public static void setUpClass() throws Exception {

        // Update the configs for local test
        PropertiesConfiguration props = AppPropertyProvider.getInstance();
        props.setProperty(SUBSCRIBER_SERVICE_CONSTANTS.SERVICE_PAYMENT_USING_RECHARGE, true);
    }

    protected String getTestLoggingKey(String methodName) {
        return "[MethodName=" + methodName + "]: ";
    }    
    
    /***************************Purchase Offer
     * @throws VisibleUnitTestException *******************************/
    protected void emulateAocServicePurchase(PaymentAdviceService instance)
            throws IOException, VisibleUnitTestException {
        MtxResponsePurchase aocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase.json");
        aocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactList().forEach(bi -> {
                    // Set all amounts to zero
                    bi.setImpactAmount(BigDecimal.ZERO);
                    bi.getBalanceImpactOfferList().forEach(bioi -> {
                        bioi.getBalanceImpactUpdateList().forEach(biui -> {
                            biui.setAmount(BigDecimal.ZERO);
                        });
                    });
                });
        for (MtxBalanceImpactInfo bi : aocResp.getAtPurchaseInfoArray(
                0).getAtBalanceImpactGroupList(0).getBalanceImpactList()) {
            // Set only one amount to 40
            bi.setImpactAmount(new BigDecimal(40.0));
            break;
        }
        doReturn(aocResp).when(instance).doSubscriberPurchaseOfferAOC(
                any(), any(), any(), any());
    }

    /***************************MultiRequest
     * @throws VisibleUnitTestException *******************************/
    protected void emulate2MtxResponseMulti(PaymentAdviceService instance,List<String> filePaths )
            throws IOException, VisibleUnitTestException {
    		MtxResponseMulti multiResponse0 = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class, filePaths.get(0));
    		MtxResponseMulti multiResponse1 = CommonTestHelper.loadJsonMessage(MtxResponseMulti.class, filePaths.get(1));
    		doReturn(multiResponse0).doReturn(multiResponse1).when(instance).multiRequest(any(), any(), any());    		        
    }

    protected void emulate2MtxResponseMultiFromObjects(IntegrationService instance,List<MtxResponseMulti> multiResponses )
            throws IOException {
    		doReturn(multiResponses.get(0)).doReturn(multiResponses.get(1)).when(instance).multiRequest(any(), any(), any());    		        
    }   

    protected void emulateMtxResponseMultiFromObject(IntegrationService instance, MtxResponseMulti multiResponse )
            throws IOException {
    		doReturn(multiResponse).when(instance).multiRequest(any(), any(), any());    		        
    }   

    protected MtxResponseMulti emulateMtxResponseMulti(IntegrationService instance, String filePath)
            throws IOException, VisibleUnitTestException {
        MtxResponseMulti multiResponse = CommonTestHelper.loadJsonMessage(
        		MtxResponseMulti.class, filePath);
        doReturn(multiResponse).when(instance).multiRequest(any(), any(), any());
        return multiResponse;
    }
    
    protected MtxResponseMulti emulateMtxResponseMulti_CreditBalances(IntegrationService instance, MtxResponseSubscription subscription)
            throws IOException, VisibleUnitTestException {
        List<String> balPriList = new ArrayList<String>();
        for(MtxBalanceInfo bal:subscription.getBalanceArray()) {
        	if("Credits".equalsIgnoreCase(bal.getClassName())) {
        		balPriList.add(bal.getName());	
        	}
        	
        }
        
        MtxResponseMulti multiResponse = CommonTestHelper.getMtxResponsePricingBalances(balPriList);
        emulateMtxResponseMultiFromObject(instance,multiResponse);
        return multiResponse;
    }

    protected MtxResponseMulti emulateMtxResponseMulti_CreditBalances(IntegrationService instance, SubscriptionResponse subscription)
            throws IOException, VisibleUnitTestException {
        List<String> balPriList = new ArrayList<String>();
        if(subscription.getWalletBalances()!=null) {
            for(MtxBalanceInfo bal:subscription.getWalletBalances()) {
            	if("Credits".equalsIgnoreCase(bal.getClassName())) {
            		balPriList.add(bal.getName());	
            	}        	
            }
        }
        
        MtxResponseMulti multiResponse = CommonTestHelper.getMtxResponsePricingBalances(balPriList);
        emulateMtxResponseMultiFromObject(instance,multiResponse);
        return multiResponse;
    }
    
    /***************************Pricing Catalog*******************************/
    protected void emulateMtxResponsePricingCatalogItem(IntegrationService instance, MtxResponsePricingCatalogItem pricingCatalogItem, String ci) 
    		throws IOException {
        doReturn(pricingCatalogItem).when(instance).queryPricingCatalogItem(any(), any(), eq(ci));
    }

    protected MtxResponsePricingCatalogItem emulateMtxResponsePricingCatalogItem(PaymentAdviceService instance,String filePath, String ci) 
    		throws IOException, VisibleUnitTestException {
        MtxResponsePricingCatalogItem pricingCatalogItem = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingCatalogItem.class,
                filePath);              
        emulateMtxResponsePricingCatalogItem(instance,pricingCatalogItem, ci);
        return pricingCatalogItem;
    }
    protected MtxResponsePricingCatalogItem emulateMtxResponsePricingCatalogItem(IntegrationService instance, String ci) 
    		throws IOException, VisibleUnitTestException {
        MtxResponsePricingCatalogItem pricingCatalogItem = CommonTestHelper.getMtxResponsePricingCatalogItem(ci);
        emulateMtxResponsePricingCatalogItem(instance,pricingCatalogItem, ci);
        return pricingCatalogItem;
    }

    protected Map<String, MtxResponsePricingCatalogItem> emulateMtxResponsePricingCatalogItems(IntegrationService instance, List<String> ciExternalIds) 
    		throws IOException, VisibleUnitTestException {
    	Map<String, MtxResponsePricingCatalogItem> retMap = new HashMap<String, MtxResponsePricingCatalogItem>();
    	for(String ciExternalId:ciExternalIds) {
            MtxResponsePricingCatalogItem pricingCatalogItem = CommonTestHelper.getMtxResponsePricingCatalogItem(ciExternalId);
            emulateMtxResponsePricingCatalogItem(instance,pricingCatalogItem, ciExternalId);
            retMap.put(ciExternalId, pricingCatalogItem);
    	}
    	return retMap;
    }
    
    /***************************Recurring Charge
     * @throws VisibleUnitTestException *******************************/
    protected MtxResponseRecurringChargeInfo emulateMtxResponseRecurringChargeInfo(SubscriberManagementApi api,String filePath)
            throws IOException, VisibleUnitTestException {
    	//Most of the test cases run on current date
    	MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.loadJsonMessage(
    			MtxResponseRecurringChargeInfo.class, filePath);
        Date stDate =new Date();
        Date endDate = DateUtils.addMonths(stDate, 1);
        chargeInfo.getBalanceImpactGroupList().forEach(biig->{
            biig.setCycleStartTime(new MtxTimestamp(stDate.getTime()));
            biig.setCycleEndTime(new MtxTimestamp(endDate.getTime()));        	
        });
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        return chargeInfo;    	
    }
    
    protected MtxResponseRecurringChargeInfo emulateMtxResponseRecurringChargeInfo(SubscriberManagementApi api,MtxResponseRecurringChargeInfo chargeInfo)
            throws IOException {
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        return chargeInfo;    	
    }
    /***************************Subscriber*******************************/
    protected MtxResponseSubscription emulateMtxResponseSubscription(IntegrationService instance,MtxResponseSubscription subscription)
            throws IOException {
        doReturn(subscription).when(instance).querySubscriptionData(any(), any());
        return subscription;
    }

    protected MtxResponseSubscription emulateMtxResponseSubscription(SubscriberManagementApi api,String filePath)
            throws IOException, VisibleUnitTestException {
        MtxResponseSubscription subscription = CommonTestHelper.loadJsonMessage(
                MtxResponseSubscription.class, filePath);
        doReturn(subscription).when(api).subscriptionQuery(any());
        doReturn(subscription).when(api).subscriptionQuery(any(), any());
        return subscription;
    }

    protected SubscriptionResponse emulateSubscriptionResponse(IntegrationService instance,String filePath)
            throws IOException, VisibleUnitTestException {
    	SubscriptionResponse subscription = CommonTestHelper.loadJsonMessage(
    			SubscriptionResponse.class, filePath);
        return emulateSubscriptionResponse(instance, subscription);
    }

    protected MtxResponseUser emulateMtxResponseUser(IntegrationService instance,String filePath)
            throws IOException, VisibleUnitTestException {
    	MtxResponseUser user = CommonTestHelper.loadJsonMessage(
    			MtxResponseUser.class, filePath);
        return emulateMtxResponseUser(instance,user);
    }

    protected MtxResponseUser emulateMtxResponseUser(IntegrationService instance,MtxResponseUser user)
            throws IOException {
        doReturn(user).when(instance).queryUserBySearchData(any(), any());
        return user;
    }

    protected MtxResponseSubscription emulateMtxResponseSubscription(SubscriberManagementApi api,MtxResponseSubscription subscription)
            throws IOException {   	
        doReturn(subscription).when(api).subscriptionQuery(any());
        return subscription;
    }
    
    protected SubscriptionResponse emulateSubscriptionResponse(IntegrationService instance,SubscriptionResponse subscription)
            throws IOException {
        doReturn(subscription).when(instance).querySubscriptionByRQT(any(),any(),any());
        return subscription;
    }
    
    /***************************Wallet*******************************/

    protected MtxResponseWallet emulateMtxResponseWallet(IntegrationService instance,MtxResponseWallet walletRes)
            throws IOException {
        doReturn(walletRes).when(instance).querySubscriptionWallet(any(), any(), any());
        return walletRes;
    }

    protected MtxResponseWallet emulateMtxResponseWalletMinimal(IntegrationService instance,MtxResponseWallet walletRes)
            throws IOException {
        doReturn(walletRes).when(instance).querySubscriptionWalletMinimal(any(), any(), any());
        return walletRes;
    }

    /***************************Party Group
     * @throws VisibleUnitTestException *******************************/
    protected void mockSubscriberGroup(IntegrationService instance, Map<String, String> groupParams)
            throws IOException, VisibleUnitTestException {
        doReturn(getGroupResponse(groupParams)).when(instance).querySubscriptionGroups(any(), any(), any());
    }

    protected MtxResponseMulti emulateSubscriptionGroup(PaymentAdviceService instance, Map<String, String> groupParams)
            throws IOException, VisibleUnitTestException {
    	MtxResponseMulti groupResponse = getGroupResponse(groupParams);
        doReturn(groupResponse).when(instance).querySubscriptionGroups(any(), any(), any());
        return groupResponse;
    }
    
    @SuppressWarnings("unchecked")
    private MtxResponseMulti getGroupResponse(Map<String, String> groupParams) throws IOException, VisibleUnitTestException{
    	MtxResponseMulti groupResponse;
    	if (groupParams==null) {
    		groupResponse = null;
    	}else {
        	groupResponse = CommonTestHelper.getEmptyMtxResponseMulti();
                MtxResponseGroup grp = CommonTestHelper.getMtxResponseGroup(
                        "GroupId", "Account", 2L, "1-0-0-0", "1-0-0-1");
                groupResponse.getResponseListAppender().add(grp);
            groupResponse.getResponseList().forEach(resp -> {
            	if (resp.getMdcName().equals(MtxResponseGroup.class.getSimpleName())) {                	
            		MtxResponseGroup grpResp = (MtxResponseGroup) resp;
                    if (groupParams.get("SubscriberMemberCount") != null) {
                    	grpResp.setSubscriberMemberCount(Long.parseLong(groupParams.get("SubscriberMemberCount")));
                    }
                    if (groupParams.get("GroupName") != null) {
                            grpResp.setName(groupParams.get("GroupName"));
                    }
                    if (groupParams.get("GroupTier") != null) {
                        	grpResp.setTier(groupParams.get("GroupTier"));
                    }
                }
            });    		
    	}
    	return groupResponse;
    }

    /***************************Events*******************************/
    protected void emulateEventQueryResponseEvents(IntegrationService instance,EventQueryResponseEvents eqre)
            throws IOException {
        doReturn(eqre).when(instance).querySubscriberEventList(any(),any(),any(),any(),any());
    }
    
    /***************************OneTimeOffers*******************************/
    @SuppressWarnings("unchecked")
	protected MtxResponseOneTimeOffer emulateMtxResponseOneTimeOffer(IntegrationService instance, MtxPurchasedOfferInfo...pois ) {
    	MtxResponseOneTimeOffer ret = new MtxResponseOneTimeOffer();
    	ret.setResult(0l);
    	ret.setResultText("OK");
    	if(pois!=null) {
        	for(MtxPurchasedOfferInfo poi:pois) {
            	if(poi!=null) {
            		ret.getOneTimeOfferArrayAppender().add(poi);
            	}        		
        	}        	    		
    	}
    	doReturn(ret).when(instance).querySubscriptionOneTimeOffer(any(), any());
    	return ret;
    }
    /***************************PaymentMethods*******************************/
    @SuppressWarnings("unchecked")
    protected MtxResponsePaymentMethodInfo emulateMtxResponsePaymentMethodInfo(IntegrationService instance, MtxPaymentMethodInfo...pois ) {
    	MtxResponsePaymentMethodInfo ret = new MtxResponsePaymentMethodInfo();
    	ret.setResult(RESULT_CODES.MTX_SUCCESS);
    	ret.setResultText("OK");
    	if(pois!=null) {
        	for(MtxPaymentMethodInfo pmi:pois) {
            	if(pmi!=null) {
            		ret.getPaymentMethodInfoListAppender().add(pmi);
            	}        		
        	}        	    		
    	}

        doReturn(ret).when(instance).queryPaymentMethodInfo(any(),any(),argThat((MtxSubscriberSearchData searchData)->true)	);
        
    	return ret;    	
    }
}
