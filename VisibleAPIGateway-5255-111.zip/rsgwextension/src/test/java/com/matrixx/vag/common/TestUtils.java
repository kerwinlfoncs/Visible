package com.matrixx.vag.common;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TimeZone;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.core.JsonGenerator.Feature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixx.datacontainer.MtxDate;
import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.vag.common.Constants.MATRIXX_CONSTANTS;

public class TestUtils {

    public static MtxDate getMtxDateFromMtxTimestamp(MtxTimestamp timestamp) {
        String dateString = timestamp.getTime().split("T")[0];
        return new MtxDate(dateString);
    }
    public static long getDayOfMonthFromMtxTimestamp(MtxTimestamp timestamp) {
        String dayString = timestamp.getTime().split("-")[1];
        return Long.valueOf(dayString);
    }
    public static MtxDate getFirstDateOfCurrentMonth() {
        LocalDateTime rightNow = LocalDateTime.now();
        LocalDate today = LocalDate.now();
        ZoneId systemZone = ZoneId.systemDefault();
        ZoneOffset systemOffset = systemZone.getRules().getOffset(rightNow);
        return new MtxDate(
                today.with(TemporalAdjusters.firstDayOfMonth()).toString() + "T00:00:00.000000"
                        + systemOffset);
    }

    public static MtxDate getDateYesterday() {
        LocalDateTime rightNow = LocalDateTime.now();
        LocalDate yesterday = LocalDate.now().minusDays(1);
        ZoneId systemZone = ZoneId.systemDefault();
        ZoneOffset systemOffset = systemZone.getRules().getOffset(rightNow);
        return new MtxDate(yesterday.toString() + "T00:00:00.000000" + systemOffset);
    }

    public static MtxDate getDateTomorrow(String timeZoneString) {
        ZonedDateTime zdtNow = ZonedDateTime.now(ZoneId.of(timeZoneString));
        TimeZone.getTimeZone(timeZoneString).getRawOffset();
        return new MtxDate(zdtNow.plusDays(1).toOffsetDateTime().toString());
    }

    public static MtxDate getDistantFutureDate() {
        LocalDateTime rightNow = LocalDateTime.now();
        ZoneId systemZone = ZoneId.systemDefault();
        ZoneOffset systemOffset = systemZone.getRules().getOffset(rightNow);
        return new MtxDate("4712-12-31T00:00:00.000000" + systemOffset);
    }

    public static MtxDate getFirstDateOfNextMonth() {
        LocalDateTime rightNow = LocalDateTime.now();
        ZoneId systemZone = ZoneId.systemDefault();
        ZoneOffset systemOffset = systemZone.getRules().getOffset(rightNow);
        return new MtxDate(
                rightNow.with(TemporalAdjusters.firstDayOfNextMonth()).toEpochSecond(systemOffset)
                        * 1000);
    }

    public static MtxDate getLastDateOfCurrentMonth() {
        LocalDateTime rightNow = LocalDateTime.now();
        ZoneId systemZone = ZoneId.systemDefault();
        ZoneOffset systemOffset = systemZone.getRules().getOffset(rightNow);
        return new MtxDate(
                rightNow.with(TemporalAdjusters.lastDayOfMonth()).toEpochSecond(systemOffset)
                        * 1000);
    }

    public static String getYYYYMMDDToday() {
        LocalDate today = LocalDate.now();
        return "" + today.getYear() + today.getMonthValue() + today.getDayOfMonth();
    }

    public static MtxTimestamp getDateTimeOfMidnightToday() {
        LocalDateTime rightNow = LocalDateTime.now();
        ZoneId systemZone = ZoneId.systemDefault();
        ZoneOffset systemOffset = systemZone.getRules().getOffset(rightNow);
        return new MtxTimestamp(
                rightNow.truncatedTo(ChronoUnit.DAYS).toEpochSecond(systemOffset) * 1000);
    }

    public static MtxTimestamp getDateTimeOfMidnightToday(String timeZoneString) {
        if(StringUtils.isBlank(timeZoneString)) {
            return getDateTimeOfMidnightToday();
        }
        LocalDateTime rightNow = LocalDateTime.now();
        LocalDate today = LocalDate.now();
        ZoneId timeZone = ZoneId.of(timeZoneString);
        ZoneOffset timeZoneOffset = timeZone.getRules().getOffset(rightNow);
        return new MtxTimestamp(today.toString() + "T00:00:00.000000" + timeZoneOffset);
    }

    public static MtxTimestamp getSubsciberDateTimeNow(String subTimeZoneString) {
        LocalDateTime rightNow = LocalDateTime.now();
        ZoneId systemZone = ZoneId.systemDefault();
        ZoneId subZone = ZoneId.of(subTimeZoneString);
        int timeDiff = subZone.getRules().getOffset(rightNow).getTotalSeconds()
                - systemZone.getRules().getOffset(rightNow).getTotalSeconds();
        return new MtxTimestamp(
                rightNow.plusSeconds(timeDiff) + "" + subZone.getRules().getOffset(rightNow));
    }

    public static MtxDate getSubsciberDateNow(String subTimeZoneString) {
        LocalDateTime rightNow = LocalDateTime.now();
        ZoneId systemZone = ZoneId.systemDefault();
        ZoneId subZone = ZoneId.of(subTimeZoneString);
        int timeDiff = subZone.getRules().getOffset(rightNow).getTotalSeconds()
                - systemZone.getRules().getOffset(rightNow).getTotalSeconds();
        MtxTimestamp timeStamp = new MtxTimestamp(
                rightNow.plusSeconds(timeDiff) + "" + subZone.getRules().getOffset(rightNow));
        MtxDate retDate = new MtxDate(timeStamp.getTime().split("T")[0]);
        return retDate;
    }

    public static Long getDaysBetween(MtxTimestamp startTime, MtxTimestamp endTime) {
        long ms = endTime.longValue() - startTime.longValue();
        return ms / 1000 / 60 / 60 / 24;
    }

    public static MtxTimestamp changeTimezoneKeepTime(MtxTimestamp inputTmestamp,
                                                      String newTimeZoneString) {
        ZoneId newZone = ZoneId.of(newTimeZoneString);
        LocalDateTime rightNow = LocalDateTime.now();
        return new MtxTimestamp(
                (inputTmestamp + "").split("\\+")[0] + newZone.getRules().getOffset(rightNow));
    }

    public static MtxTimestamp getFirstDateTimeOfLastMonth() {
        LocalDateTime rightNow = LocalDateTime.now();
        LocalDate today = LocalDate.now();
        ZoneId systemZone = ZoneId.systemDefault();
        ZoneOffset systemOffset = systemZone.getRules().getOffset(rightNow);
        return new MtxTimestamp(
                today.minusMonths(1).with(TemporalAdjusters.firstDayOfMonth()).toString()
                        + "T00:00:00.000000" + systemOffset);
    }

    public static MtxTimestamp getLastDateTimeOfLastMonth(String timeZoneString) {
        LocalDateTime rightNow = LocalDateTime.now();
        LocalDate today = LocalDate.now();
        ZoneId timeZone = ZoneId.of(timeZoneString);
        ZoneOffset timeZoneOffset = timeZone.getRules().getOffset(rightNow);
        return new MtxTimestamp(
                today.minusMonths(1).with(TemporalAdjusters.lastDayOfMonth()).toString()
                        + "T00:00:00.000000" + timeZoneOffset);
    }

    public static MtxTimestamp getFirstDateTimeOfCurrentMonth() {
        LocalDateTime rightNow = LocalDateTime.now();
        LocalDate today = LocalDate.now();
        ZoneId systemZone = ZoneId.systemDefault();
        ZoneOffset systemOffset = systemZone.getRules().getOffset(rightNow);
        return new MtxTimestamp(
                today.with(TemporalAdjusters.firstDayOfMonth()).toString() + "T00:00:00.000000"
                        + systemOffset);
    }

    public static MtxTimestamp getFirstDateTimeOfCurrentMonth(MtxTimestamp refTimestamp) {
        LocalDateTime rightNow = LocalDateTime.now();
        ZoneId systemZone = ZoneId.systemDefault();
        ZoneOffset systemOffset = systemZone.getRules().getOffset(rightNow);
        return MtxTimestamp.ofEpochMilli(
                rightNow.with(TemporalAdjusters.firstDayOfMonth()).truncatedTo(
                        ChronoUnit.DAYS).toEpochSecond(systemOffset) * 1000,
                refTimestamp);
    }

    public static MtxTimestamp getFirstDateTimeOfCurrentMonth(String timeZoneString) {
        LocalDate today = LocalDate.now();
        ZoneId timeZone = ZoneId.of(timeZoneString);
        return getMtxTimestampFromLocalDatetime(today.withDayOfMonth(1).atStartOfDay(), timeZone);
    }

    public static MtxTimestamp getLastDateTimeOfCurrentMonth() {
        LocalDateTime rightNow = LocalDateTime.now();
        ZoneId systemZone = ZoneId.systemDefault();
        ZoneOffset systemOffset = systemZone.getRules().getOffset(rightNow);
        return new MtxTimestamp(
                rightNow.with(TemporalAdjusters.lastDayOfMonth()).toEpochSecond(systemOffset)
                        * 1000);
    }

    public static MtxTimestamp getLastDateTimeOfCurrentMonth(String timeZoneString) {
        LocalDateTime rightNow = LocalDateTime.now();
        LocalDate today = LocalDate.now();
        ZoneId timeZone = ZoneId.of(timeZoneString);
        ZoneOffset timeZoneOffset = timeZone.getRules().getOffset(rightNow);
        return new MtxTimestamp(
                today.with(TemporalAdjusters.lastDayOfMonth()).toString() + "T00:00:00.000000"
                        + timeZoneOffset);
    }

    public static MtxTimestamp getLastDateTimeOfCurrentMonth(MtxTimestamp zoneRefTimestamp) {
        LocalDateTime rightNow = LocalDateTime.now();
        ZoneId systemZone = ZoneId.systemDefault();
        ZoneOffset systemOffset = systemZone.getRules().getOffset(rightNow);
        return MtxTimestamp.ofEpochMilli(
                rightNow.with(TemporalAdjusters.lastDayOfMonth()).toEpochSecond(systemOffset)
                        * 1000,
                zoneRefTimestamp);
    }

    public static MtxTimestamp getFirstDateTimeOfNextMonth() {
        LocalDateTime rightNow = LocalDateTime.now();
        LocalDate today = LocalDate.now();
        ZoneId systemZone = ZoneId.systemDefault();
        ZoneOffset systemOffset = systemZone.getRules().getOffset(rightNow);
        return new MtxTimestamp(
                today.with(TemporalAdjusters.firstDayOfNextMonth()).toString() + "T00:00:00.000000"
                        + systemOffset);
    }

    public static MtxTimestamp getFirstDateTimeOfNextMonth(MtxTimestamp zoneRefTimestamp) {
        LocalDateTime rightNow = LocalDateTime.now();
        LocalDate today = LocalDate.parse(zoneRefTimestamp.getTime().split("T")[0]);
        ZoneId systemZone = ZoneId.systemDefault();
        ZoneOffset systemOffset = systemZone.getRules().getOffset(rightNow);
        return new MtxTimestamp(
                today.plusMonths(1).with(TemporalAdjusters.firstDayOfMonth()).toString()
                        + "T00:00:00.000000" + systemOffset);
    }

    public static MtxTimestamp getFirstDateTimeOfNextMonth(String timeZoneString) {
        LocalDateTime rightNow = LocalDateTime.now();
        LocalDate today = LocalDate.now();
        ZoneId timeZone = ZoneId.of(timeZoneString);
        ZoneOffset timeZoneOffset = timeZone.getRules().getOffset(rightNow);
        return new MtxTimestamp(
                today.plusMonths(1).with(TemporalAdjusters.firstDayOfMonth()).toString()
                        + "T00:00:00.000000" + timeZoneOffset);
    }

    public static MtxTimestamp getLastDateTimeOfNextMonth() {
        LocalDateTime rightNow = LocalDateTime.now();
        ZoneId systemZone = ZoneId.systemDefault();
        ZoneOffset systemOffset = systemZone.getRules().getOffset(rightNow);
        return new MtxTimestamp(
                rightNow.with(TemporalAdjusters.lastDayOfMonth()).plusMonths(1).toEpochSecond(
                        systemOffset) * 1000);
    }

    public static MtxTimestamp getFirstDateTimeOfCurrentYear() {
        LocalDateTime rightNow = LocalDateTime.now();
        ZoneId systemZone = ZoneId.systemDefault();
        ZoneOffset systemOffset = systemZone.getRules().getOffset(rightNow);
        return new MtxTimestamp(
                rightNow.with(TemporalAdjusters.firstDayOfYear()).toEpochSecond(systemOffset)
                        * 1000);
    }

    public static MtxTimestamp getFirstDateTimeOfNextYear() {
        LocalDateTime rightNow = LocalDateTime.now();
        ZoneId systemZone = ZoneId.systemDefault();
        ZoneOffset systemOffset = systemZone.getRules().getOffset(rightNow);
        return new MtxTimestamp(
                rightNow.with(TemporalAdjusters.firstDayOfNextYear()).toEpochSecond(systemOffset)
                        * 1000);
    }

    public static MtxTimestamp getFirstDateTimeOfYearAfterNextYear() {
        LocalDateTime rightNow = LocalDateTime.now();
        ZoneId systemZone = ZoneId.systemDefault();
        ZoneOffset systemOffset = systemZone.getRules().getOffset(rightNow);
        return new MtxTimestamp(
                rightNow.with(TemporalAdjusters.firstDayOfNextYear()).plusYears(1).toEpochSecond(
                        systemOffset) * 1000);
    }

    public static MtxTimestamp getLastDateTimeOfNextYear() {
        LocalDateTime rightNow = LocalDateTime.now();
        ZoneId systemZone = ZoneId.systemDefault();
        ZoneOffset systemOffset = systemZone.getRules().getOffset(rightNow);
        return new MtxTimestamp(
                rightNow.with(TemporalAdjusters.lastDayOfYear()).plusYears(1).toEpochSecond(
                        systemOffset) * 1000);
    }

    public static MtxTimestamp getYesterdayThisTime() {
        LocalDateTime rightNow = LocalDateTime.now();
        ZoneId systemZone = ZoneId.systemDefault();
        ZoneOffset systemOffset = systemZone.getRules().getOffset(rightNow);
        return new MtxTimestamp(rightNow.minusDays(1).toEpochSecond(systemOffset) * 1000);
    }

    public static MtxTimestamp addHours(MtxTimestamp refDate, int hours) {
        MtxTimestamp tsRef = MtxTimestamp.ofEpochMilli(refDate.longValue(), refDate);
        ZonedDateTime zdt = CommonUtils.getZonedDateTimeFromMtxTimestamp(tsRef, null);
        return MtxTimestamp.ofEpochMilli(zdt.plusHours(hours).toEpochSecond() * 1000, refDate);
    }

    public static MtxTimestamp getTimestampAfterHoursFromNow(String timeZoneString, int hours) {
        LocalDateTime ldt = LocalDate.now().atStartOfDay().plusHours(hours);
        ZoneId zoneId = ZoneId.of(timeZoneString);
        return getMtxTimestampFromLocalDatetime(ldt, zoneId);
    }

    public static MtxTimestamp addOneWeek(MtxTimestamp refDate) {
        MtxTimestamp tsRef = MtxTimestamp.ofEpochMilli(refDate.longValue(), refDate);
        ZonedDateTime zdt = CommonUtils.getZonedDateTimeFromMtxTimestamp(tsRef, null);
        return MtxTimestamp.ofEpochMilli(zdt.plusDays(7).toEpochSecond() * 1000, refDate);
    }

    public static MtxTimestamp addDays(MtxTimestamp refDate, int days) {
        MtxTimestamp tsRef = MtxTimestamp.ofEpochMilli(refDate.longValue(), refDate);
        ZonedDateTime zdt = CommonUtils.getZonedDateTimeFromMtxTimestamp(tsRef, null);
        return MtxTimestamp.ofEpochMilli(zdt.plusDays(days).toEpochSecond() * 1000, refDate);
    }

    public static MtxTimestamp addOneMonth(MtxTimestamp refDate) {
        LocalDateTime rightNow = LocalDateTime.now();
        LocalDate today = LocalDate.parse(refDate.getTime().split("T")[0]);
        ZoneId systemZone = ZoneId.systemDefault();
        ZoneOffset systemOffset = systemZone.getRules().getOffset(rightNow);
        return new MtxTimestamp(today.plusMonths(1).toString() + "T00:00:00.000000" + systemOffset);
    }

    public static MtxTimestamp addOneMonth(MtxTimestamp refDate, String timeZoneString) {

        String[] timestampSplit = refDate.getTime().split("T");
        String[] timeSplit = timestampSplit[1].split(":");
        int hour = Integer.parseInt(timeSplit[0]);
        int minute = Integer.parseInt(timeSplit[1]);
        String[] a = timeSplit[2].split("\\.");
        int second = Integer.parseInt(a[0]);

        LocalDate today = LocalDate.parse(timestampSplit[0]);
        LocalDateTime nextMonthTime = today.atStartOfDay().plusHours(hour).plusMinutes(
                minute).plusSeconds(second).plusMonths(1);

        ZoneId timeZone = ZoneId.of(timeZoneString);
        ZoneOffset timeZoneOffset = timeZone.getRules().getOffset(nextMonthTime);
        return new MtxTimestamp(
                nextMonthTime.format(DateTimeFormatter.ISO_DATE_TIME).toString() + ".000000"
                        + timeZoneOffset);
    }

    public static MtxTimestamp addMonths(MtxTimestamp refDate, int months) {
        LocalDateTime rightNow = LocalDateTime.now();
        LocalDate today = LocalDate.parse(refDate.getTime().split("T")[0]);
        ZoneId systemZone = ZoneId.systemDefault();
        ZoneOffset systemOffset = systemZone.getRules().getOffset(rightNow);
        return new MtxTimestamp(
                today.plusMonths(months).toString() + "T00:00:00.000000" + systemOffset);
    }

    public static MtxTimestamp addMonths(MtxTimestamp refDate, int months, String timeZoneString) {
        if(StringUtils.isBlank(timeZoneString)) {
            return addMonths(refDate,months);
        }
        LocalDate today = LocalDate.parse(refDate.getTime().split("T")[0]);
        ZoneId timeZone = ZoneId.of(timeZoneString);
        LocalDate afterMonths = today.plusMonths(months);
        ZoneOffset timeZoneOffset = timeZone.getRules().getOffset(afterMonths.atStartOfDay());
        return new MtxTimestamp(afterMonths.toString() + "T00:00:00.000000" + timeZoneOffset);
    }
    
    public static String getSystemTimezoneOffset() {
        ZoneId systemZone = ZoneId.systemDefault();
        return systemZone.toString();
    }

    public static MtxTimestamp addOneYear(MtxTimestamp refDate) {
        LocalDateTime rightNow = LocalDateTime.now();
        LocalDate today = LocalDate.parse(refDate.getTime().split("T")[0]);
        ZoneId systemZone = ZoneId.systemDefault();
        ZoneOffset systemOffset = systemZone.getRules().getOffset(rightNow);
        return new MtxTimestamp(today.plusYears(1).toString() + "T00:00:00.000000" + systemOffset);
    }

    public static MtxTimestamp addOneYear(MtxTimestamp refDate, String timeZoneString) {
        if(StringUtils.isBlank(timeZoneString)) {
            return addOneYear(refDate);
        }
        LocalDate today = LocalDate.parse(refDate.getTime().split("T")[0]);
        ZoneId timeZone = ZoneId.of(timeZoneString);
        LocalDate afterOneYear = today.plusYears(1);
        ZoneOffset timeZoneOffset = timeZone.getRules().getOffset(afterOneYear.atStartOfDay());
        return new MtxTimestamp(afterOneYear.toString() + "T00:00:00.000000" + timeZoneOffset);
    }

    public static MtxTimestamp subtractOneYear(MtxTimestamp refDate, String timeZoneString) {
        if(StringUtils.isBlank(timeZoneString)) {
            return addOneYear(refDate);
        }
        LocalDate today = LocalDate.parse(refDate.getTime().split("T")[0]);
        ZoneId timeZone = ZoneId.of(timeZoneString);
        LocalDate afterOneYear = today.minusYears(1);
        ZoneOffset timeZoneOffset = timeZone.getRules().getOffset(afterOneYear.atStartOfDay());
        return new MtxTimestamp(afterOneYear.toString() + "T00:00:00.000000" + timeZoneOffset);
    }
    
    public static MtxTimestamp subtractOneYear(MtxTimestamp refDate) {
        MtxTimestamp tsRef = MtxTimestamp.ofEpochMilli(refDate.longValue(), refDate);
        ZonedDateTime zdt = CommonUtils.getZonedDateTimeFromMtxTimestamp(tsRef, null);
        return MtxTimestamp.ofEpochMilli(zdt.minusYears(1).toEpochSecond() * 1000, refDate);
    }
 
    public static MtxTimestamp subtractMonths(MtxTimestamp refDate, int months, String timeZoneString) {
        if(StringUtils.isBlank(timeZoneString)) {
            return addMonths(refDate,months);
        }
        LocalDate today = LocalDate.parse(refDate.getTime().split("T")[0]);
        ZoneId timeZone = ZoneId.of(timeZoneString);
        LocalDate afterMonths = today.minusMonths(months);
        ZoneOffset timeZoneOffset = timeZone.getRules().getOffset(afterMonths.atStartOfDay());
        return new MtxTimestamp(afterMonths.toString() + "T00:00:00.000000" + timeZoneOffset);
    }

    public static ObjectMapper getObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(Feature.WRITE_BIGDECIMAL_AS_PLAIN, true);
        return objectMapper;
    }

    public static String getFileContentsAsString(String pathString) throws IOException {
        Path path = Paths.get(pathString);
        List<String> lines = Files.readAllLines(path);
        return String.join(StringUtils.LF, lines);
    }

    public static List<String> mergeStringList(List<String> list1, List<String> list2) {
        List<String> retList = new ArrayList<String>();
        Set<String> tempSet = new HashSet<String>();
        for (String item : list1)
            tempSet.add(item);
        for (String item : list2)
            tempSet.add(item);
        for (String item : tempSet)
            retList.add(item);
        return retList;
    }

    private static MtxTimestamp getMtxTimestampFromLocalDatetime(LocalDateTime ldt,
                                                                 ZoneId timeZone) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(
                MATRIXX_CONSTANTS.MTX_DATE_TIME_FORMAT);
        String zdtString = ldt.atZone(timeZone).format(formatter);
        if (zdtString.endsWith("+00:00")) {
            zdtString = zdtString.replace("+00:00", "Z");
        }
        return new MtxTimestamp(zdtString);
    }
}
