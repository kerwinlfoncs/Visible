package com.matrixx.vag.advice.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doReturn;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.matrixx.datacontainer.MtxDate;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.EventQueryEventInfo;
import com.matrixx.datacontainer.mdc.EventQueryResponseEvents;
import com.matrixx.datacontainer.mdc.MtxBalanceImpactInfo;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferData;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.MtxRecurringEvent;
import com.matrixx.datacontainer.mdc.MtxResponseGroup;
import com.matrixx.datacontainer.mdc.MtxResponsePurchase;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.MtxResponseWallet;
import com.matrixx.datacontainer.mdc.PurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.SubscriptionResponse;
import com.matrixx.datacontainer.mdc.VisibleChangeServiceCredit;
import com.matrixx.datacontainer.mdc.VisibleChangeServicePromo;
import com.matrixx.datacontainer.mdc.VisibleOfferDetails;
import com.matrixx.datacontainer.mdc.VisiblePromoExtension;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleRequestChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleResponseChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleSubscriberExtension;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.advice.model.PromoOfferPair;
import com.matrixx.vag.advice.model.SubscriberGroup;
import com.matrixx.vag.common.TestUtils;
import com.matrixx.vag.common.ThreeParameterTest;
import com.matrixx.vag.common.TwoParameterTest;
import com.matrixx.vag.common.Constants.CREDIT_CONSTANTS;
import com.matrixx.vag.common.TestConstants.BALANCE_NAMES;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestConstants.DATA_DIR;
import com.matrixx.vag.common.TestConstants.TAX_CLASS_CODES;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.tax.client.TaxApiClient;
import com.matrixx.vag.tax.model.ServiceTaxResponse;
import com.matrixx.vag.util.MDCTest;

public class CsaNewPromoTest extends MDCTest {

    @Spy
    @InjectMocks
    private PaymentAdviceService instance = new PaymentAdviceService();

    @Mock
    private SubscriberManagementApi api;
    private TestInfo testInfo;

    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        instance = new PaymentAdviceService();
        MockitoAnnotations.openMocks(this);
        this.testInfo = testInfo;
        doReturn("").when(instance).getRoute(any());
    }

    @ParameterizedTest(
            name = "getChangeServiceAdvice_When_ChangeToCoreMonthly_NewGrant_Purchased_Then_NewPromoInResponse")
    @Tags(value = {
        @Tag("VER-209"), @Tag("MTXVER2-204")
    })
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |PaidCycleStartDate is in past. Subscriber has Visible_Unlimited. Eligible for 2535. 2535 grant offer is purchased.|"
                +"|When  |ChangeAdvice is called for CoreMonthly offer.|"
                +"|Then  |ChangeAdvice response should show 2535Plus / 2535Base newpromo in response.|"})
    // @formatter:on
    @SuppressWarnings("unchecked")
    public void getChangeServiceAdvice_When_ChangeToCoreMonthly_NewGrant_Purchased_Then_NewPromoInResponse(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        ThreeParameterTest pTests = (req, oldCi, oldPromo) -> {
            td.printDescription();
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            CI_EXTERNAL_IDS.PLUS_2535_GRANT, CI_EXTERNAL_IDS.BASE_2535_GRANT,
                            oldCi.toString(), request.getNewCatalogItemExternalId()));
            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, oldCi.toString());
            MtxDate paidCycleStartDate = ((VisiblePurchasedOfferExtension) poEnrolled.getAttr()).getPaidCycleStartDate();
            MtxPurchasedOfferInfo promoEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldPromo.toString(), null, BigDecimal.valueOf(5000),
                    BigDecimal.ONE);
            ((VisiblePurchasedOfferExtension) promoEnrolled.getAttr()).setPromotionLimit(
                    BigDecimal.valueOf(15));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCi.toString());
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(
                    CommonTestHelper.getOfferPrice(oldCi.toString()));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(paidCycleStartDate);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));
            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            doReturn("[" + request.getSubscriptionExternalId() + "]").when(instance).getLoggingKey(
                    any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetails(
                    oldCi.toString(), paidCycleStartDate);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodUnlimited.getCatalogItemExternalId(),
                    Long.valueOf(vodUnlimited.getResourceId()), vodUnlimited);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
//                if (CI_EXTERNAL_IDS.PLUS2VIS22.equalsIgnoreCase(oldCi.toString())
//                        && CI_EXTERNAL_IDS.BASE2VIS22.equalsIgnoreCase(
//                                request.getNewCatalogItemExternalId())) {
                    // Since new Ci starts next cycle there will be no prorated charge. TaxApi gets
                    // called only once.
                    mockedStatic.when(
                            () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                    taxRespNextCycle.toJson());
//                } else {
//                    mockedStatic.when(
//                            () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
//                                    taxRespChangeCycle.toJson()).thenReturn(
//                                            taxRespNextCycle.toJson());
//                }
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            boolean foundNewPromo = false;
            for (VisibleChangeServiceCredit newPromo : response.getNewRedeemableCredits()) {
                if (TAX_CLASS_CODES.PLUS2535.equalsIgnoreCase(newPromo.getClassCode())
                        || TAX_CLASS_CODES.BASE2535.equalsIgnoreCase(newPromo.getClassCode())) {
                    foundNewPromo = true;
                }
            }
            assertTrue(
                    foundNewPromo,
                    "New promo should be present for " + request.getNewCatalogItemExternalId());
        };

        VisibleChangeServicePromo csp;
        VisibleRequestChangeServiceAdvice request;
        String subscriptionExternalId = "123";

        request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PRO_CURRENT);
        request.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PRO_CURRENT));
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
        request.setSubscriptionExternalId(subscriptionExternalId);
        csp = new VisibleChangeServicePromo();
        csp.setGrantOfferCI(CI_EXTERNAL_IDS.PLUS_2535_GRANT);
        csp.setGrantAmount(BigDecimal.valueOf(5000));
        request.getNewPromotionListAppender().add(csp);
        pTests.test(request, CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_2535_GRANT);

        request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        request.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS_CURRENT));
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
        request.setSubscriptionExternalId(subscriptionExternalId);
        csp = new VisibleChangeServicePromo();
        csp.setGrantOfferCI(CI_EXTERNAL_IDS.BASE_2535_GRANT);
        csp.setGrantAmount(BigDecimal.valueOf(5000));
        request.getNewPromotionListAppender().add(csp);
        pTests.test(request, CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.BASE_2535_GRANT);
    }

    @ParameterizedTest(
            name = "getChangeServiceAdvice_When_ChangeToCoreMonthly_NewGrant_NOT_Purchased_Then_NewPromoInResponse")
    @Tags(value = {
        @Tag("VER-209"), @Tag("MTXVER2-204")
    })
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |PaidCycleStartDate is in past. Subscriber has Visible_Unlimited. Eligible for 2535. 2535 grant offer not purchased.|"
                +"|When  |ChangeAdvice is called for CoreMonthly offer.|"
                +"|Then  |ChangeAdvice response should show 2535Plus / 2535Base newpromo in response.|"})
    // @formatter:on
    @SuppressWarnings("unchecked")
    public void getChangeServiceAdvice_When_ChangeToCoreMonthly_NewGrant_NOT_Purchased_Then_NewPromoInResponse(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        @SuppressWarnings({
            "rawtypes"
        })
        ThreeParameterTest pTests = (req, oldCi, oldPromo) -> {
            td.printDescription();
            String subscriptionExternalId = "123";
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            emulateMtxResponseMultiFromObject(
                    instance, CommonTestHelper.getMtxResponsePricingBalances(new ArrayList()));
            emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            CI_EXTERNAL_IDS.PLUS_2535_GRANT, CI_EXTERNAL_IDS.BASE_2535_GRANT,
                            oldCi.toString(), request.getNewCatalogItemExternalId()));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, oldCi.toString());
            MtxDate paidCycleStartDate = ((VisiblePurchasedOfferExtension) poEnrolled.getAttr()).getPaidCycleStartDate();

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCi.toString());
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(
                    CommonTestHelper.getOfferPrice(oldCi.toString()));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(paidCycleStartDate);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));

            doReturn("[" + subscriptionExternalId + "]").when(instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodUnlimited = CommonTestHelper.getVisibleOfferDetails(
                    oldCi.toString(), paidCycleStartDate);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodUnlimited.getCatalogItemExternalId(),
                    Long.valueOf(vodUnlimited.getResourceId()), vodUnlimited);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
//                if (CI_EXTERNAL_IDS.PLUS2VIS22.equalsIgnoreCase(oldCi.toString())
//                        && CI_EXTERNAL_IDS.BASE2VIS22.equalsIgnoreCase(
//                                request.getNewCatalogItemExternalId())) {
                    // Since new Ci starts next cycle there will be no prorated charge. TaxApi gets
                    // called only once.
                    mockedStatic.when(
                            () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                    taxRespNextCycle.toJson());

//                } else {
//                    mockedStatic.when(
//                            () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
//                                    taxRespChangeCycle.toJson()).thenReturn(
//                                            taxRespNextCycle.toJson());
//                }
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            boolean foundNewPromo = false;
            for (VisibleChangeServiceCredit newPromo : response.getNewRedeemableCredits()) {
                if (TAX_CLASS_CODES.PLUS2535.equalsIgnoreCase(newPromo.getClassCode())
                        || TAX_CLASS_CODES.BASE2535.equalsIgnoreCase(newPromo.getClassCode())) {
                    foundNewPromo = true;
                }
            }
            assertTrue(
                    foundNewPromo,
                    "New promo should be present for " + request.getNewCatalogItemExternalId());
        };
        VisibleChangeServicePromo csp;
        VisibleRequestChangeServiceAdvice request;
        String subscriptionExternalId = "123";

        request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PRO_CURRENT);
        request.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PRO_CURRENT));
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
        request.setSubscriptionExternalId(subscriptionExternalId);
        csp = new VisibleChangeServicePromo();
        csp.setGrantOfferCI(CI_EXTERNAL_IDS.PLUS_2535_GRANT);
        csp.setGrantAmount(BigDecimal.valueOf(5000));
        request.getNewPromotionListAppender().add(csp);
        pTests.test(request, CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.PLUS_2535_GRANT);

        request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        request.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS_CURRENT));
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
        request.setSubscriptionExternalId(subscriptionExternalId);
        csp = new VisibleChangeServicePromo();
        csp.setGrantOfferCI(CI_EXTERNAL_IDS.BASE_2535_GRANT);
        csp.setGrantAmount(BigDecimal.valueOf(5000));
        request.getNewPromotionListAppender().add(csp);
        pTests.test(request, CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.BASE_2535_GRANT);
    }

    @ParameterizedTest(
            name = "getChangeServiceAdvice_When_BaseMonthly2PlusMonthly_NO_PromoTax_Then_CorrectDelta")
    @Tags(value = {
        @Tag("VER-209"), @Tag("MTXVER2-204")
    })
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |PaidCycleStartDate is in past. Subscriber has BaseMonthly. Subscriber has 2535. Subscribers event has no promo tax.|"
                +"|When  |ChangeAdvice is called for PlusMonthly offer.|"
                +"|Then  |ChangeAdvice response should show correct delta.|"})
    // @formatter:on
    @SuppressWarnings("unchecked")
    public void getChangeServiceAdvice_When_BaseMonthly2PlusMonthly_NO_PromoTax_Then_CorrectDelta(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        ThreeParameterTest pTests = (req, tc, er) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            ExpectedResponse eResp = (ExpectedResponse) er;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            // if (tCase.vbppEligible) {
            // AppPropertyProvider.getInstance().setProperty(
            // CREDIT_CONSTANTS.AOC_GRANT_OFFERS, CI_EXTERNAL_IDS.VBPP5_AOC_GRANT);
            // } else if (tCase.chimeEligible) {
            // AppPropertyProvider.getInstance().setProperty(
            // CREDIT_CONSTANTS.AOC_GRANT_OFFERS, CI_EXTERNAL_IDS.CHIME_AOC_GRANT);
            // } else {
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
            // }

            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());
            emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            CI_EXTERNAL_IDS.PLUS_2535_GRANT, CI_EXTERNAL_IDS.BASE_2535_GRANT,
                            // CI_EXTERNAL_IDS.VBPP5_AOC_GRANT, CI_EXTERNAL_IDS.CHIME_AOC_GRANT,
                            tCase.oldCi, request.getNewCatalogItemExternalId()));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, CI_EXTERNAL_IDS.BASE_2535_GRANT);
            MtxDate paidCycleStartDate = ((VisiblePurchasedOfferExtension) poEnrolled.getAttr()).getPaidCycleStartDate();

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(paidCycleStartDate);

            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            doReturn("[" + request.getNewCatalogItemExternalId() + "]").when(
                    instance).getLoggingKey(any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            Map<String, BigDecimal> balImpactMap = new HashMap<String, BigDecimal>();
            balImpactMap.put(BALANCE_NAMES.GLOBAL_PASS, BigDecimal.ONE);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), aocAmount, null, balImpactMap, false);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, paidCycleStartDate);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            // BigDecimal coreVbpp = tCase.vbppEligible ? BigDecimal.valueOf(5) : BigDecimal.ZERO;
            // doReturn(coreVbpp.negate()).when(instance).getChargeableAmountForPurchaseOffer(
            // any(),
            // argThat(
            // (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
            // CI_EXTERNAL_IDS.VBPP_CORE_REDEEM)),
            // any(), any());
            //
            // BigDecimal coreChime = tCase.chimeEligible ? BigDecimal.valueOf(5) : BigDecimal.ZERO;
            // doReturn(coreChime.negate()).when(instance).getChargeableAmountForPurchaseOffer(
            // any(),
            // argThat(
            // (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
            // CI_EXTERNAL_IDS.CHIME_AOC_REDEEM)),
            // any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                // if (CI_EXTERNAL_IDS.PLUS2VIS22.equalsIgnoreCase(tCase.oldCi)
                // && CI_EXTERNAL_IDS.BASE2VIS22.equalsIgnoreCase(tCase.newCi)) {
                // Since new Ci starts next cycle there will be no prorated charge. TaxApi gets
                // called only once.
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespNextCycle.toJson());

                // } else {
                // mockedStatic.when(
                // () -> TaxApiClient.getTaxApiResult(
                // any(), anyString())).thenReturn(
                // taxRespChangeCycle.toJson()).thenReturn(
                // taxRespNextCycle.toJson());
                // }
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertEquals(
                    ((BigDecimal) eResp.resultMap.get("delta")).intValue(),
                    response.getChangeCycle().getDelta().intValue(),
                    eResp.resultMap.get("deltaDescription").toString());
        };

        // BaseMonthly2PlusMonthly
        TestConditions chg;
        ExpectedResponse eResp;
        VisibleRequestChangeServiceAdvice request;
        String subscriptionExternalId = "123";

        request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PRO_CURRENT);
        request.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PRO_CURRENT));
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
        request.setSubscriptionExternalId(subscriptionExternalId);
        VisibleChangeServicePromo csp = new VisibleChangeServicePromo();
        csp.setGrantOfferCI(CI_EXTERNAL_IDS.PLUS_2535_GRANT);
        csp.setGrantAmount(BigDecimal.valueOf(5000));
        request.getNewPromotionListAppender().add(csp);

        chg = new TestConditions() {

            {
                newCi = request.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE_CURRENT;
            }
        };
        eResp = new ExpectedResponse() {

            {
                resultMap.put("delta", BigDecimal.valueOf(15));
                resultMap.put(
                        "deltaDescription",
                        "(Pro-2535PLUS)-(Base-2535BASE)=(45-2535PLUS)-(25-2535BASE)=(45-10)-(25-5) = 15");
            }
        };
        pTests.test(request, chg, eResp);
    }

    @ParameterizedTest(
            name = "getChangeServiceAdvice_When_BaseMonthly2PlusMonthly_With_PromoTax_Then_CorrectDelta")
    @Tags(value = {
        @Tag("VER-209"), @Tag("MTXVER2-204")
    })
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |PaidCycleStartDate is in future. Subscriber has BaseMonthly. Subscriber has 2535. Subscribers events have promo tax.|"
                +"|When  |ChangeAdvice is called for PlusMonthly offer.|"
                +"|Then  |ChangeAdvice response should show correct delta.|"})
    // @formatter:on
    @SuppressWarnings("unchecked")
    public void getChangeServiceAdvice_When_BaseMonthly2PlusMonthly_With_PromoTax_Then_CorrectDelta(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        ThreeParameterTest pTests = (req, tc, er) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            ExpectedResponse eResp = (ExpectedResponse) er;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            // if (tCase.vbppEligible) {
            // AppPropertyProvider.getInstance().setProperty(
            // CREDIT_CONSTANTS.AOC_GRANT_OFFERS, CI_EXTERNAL_IDS.VBPP5_AOC_GRANT);
            // } else if (tCase.chimeEligible) {
            // AppPropertyProvider.getInstance().setProperty(
            // CREDIT_CONSTANTS.AOC_GRANT_OFFERS, CI_EXTERNAL_IDS.CHIME_AOC_GRANT);
            // } else {
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
            // }

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            CI_EXTERNAL_IDS.PLUS_2535_GRANT, CI_EXTERNAL_IDS.BASE_2535_GRANT,
                            // CI_EXTERNAL_IDS.VBPP5_AOC_GRANT, CI_EXTERNAL_IDS.CHIME_AOC_GRANT,
                            tCase.oldCi, request.getNewCatalogItemExternalId()));

            subscription.getPurchasedOfferArrayAppender().clear();

            CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, CI_EXTERNAL_IDS.BASE_2535_GRANT);

            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, tCase.oldCi);
            VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            MtxDate paidCycleStartDate = poExtn.getPaidCycleStartDate();
            String base2535Tax = "{\"msgID\":\"2535BASE\",\"customerType\":\"99\",\"planID\":\"BASE001A\",\"grossPrice\":\"10.00\",\"discountPrice\":\""
                    + tCase.promoMap.get("BASE2535USED")
                    + "\",\"promotionCredit\":\"true\",\"offer606RevAdjDailyRecog\":\"0\",\"promotionReason\":\"Group_Discounts\",\"geocode\":\"US0100108296\",\"taxTreatment\":\"inclusive\",\"classCode\":\"2535BASE\",\"glDate\":\"2019-03-07\",\"transactionElement\":[{\"btcTransactionCode\":\"01\",\"totalTaxAmount\":\"0.07389163\",\"totalFeeAmount\":\"0.00000000\",\"totalNetRevenue\":\"4.92610836\",\"modifiedDisplayNetRevenue\":\"4.93\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"618\",\"cP\":\"0.75\",\"glReference\":\"Visible_Unlimited_Data\",\"dpcItemTaxAmount\":\"0.00000000\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"3.69458128\",\"taxItemList\":[]},{\"dpcItem\":\"601\",\"cP\":\"0.12\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.03546798\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.59113300\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.02364532\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.01182266\"}]},{\"dpcItem\":\"662\",\"cP\":\"0.04\",\"glReference\":\"Visible_Unlimited_Text\",\"dpcItemTaxAmount\":\"0.01182266\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.19704433\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.00788177\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.00394089\"}]},{\"dpcItem\":\"629\",\"cP\":\"0.09\",\"glReference\":\"Visible_Unlimited_MMS\",\"dpcItemTaxAmount\":\"0.02660099\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.44334975\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.01773399\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.00886700\"}]}]}]},{\"btcTransactionCode\":\"93\",\"totalTaxAmount\":\"0.03002956\",\"totalFeeAmount\":\"0.00000000\",\"totalNetRevenue\":\"4.92610836\",\"modifiedDisplayNetRevenue\":\"4.93\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"601\",\"cP\":\"0.12\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.03002956\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.59113300\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000000016\",\"tat\":\"0\",\"taxCategory\":\"00\",\"taxType\":\"35\",\"description\":\"Fed Universal Service Charge\",\"rate\":\"0.050800000000\",\"taxAmount\":\"0.03002956\"}]}]}]}]}";
            poExtn.getCreditTaxDetailsArrayAppender().clear();
            poExtn.getCreditTaxDetailsArrayAppender().add(base2535Tax);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(paidCycleStartDate);

            EventQueryResponseEvents eqre = new EventQueryResponseEvents();
            emulateEventQueryResponseEvents(instance, eqre);
            EventQueryEventInfo eqei = CommonTestHelper.loadJsonMessage(
                    EventQueryEventInfo.class,
                    DATA_DIR.CHANGE_SERVICE_ADVICE + "EventQueryEventInfo_MtxRecurringEvent.json");
            eqre.getEventListAppender().add(eqei);
            MtxRecurringEvent recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            VisiblePurchasedOfferExtension enrolledExtnEvent = (VisiblePurchasedOfferExtension) recEvent.getAtAppliedBundleArray(
                    0).getPurchasedBundleAttr();
            enrolledExtnEvent.setChargeAmount(tCase.getOldCiPrice());
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().clear();
            enrolledExtnEvent.getCreditTaxDetailsArrayAppender().add(base2535Tax);
            enrolledExtnEvent.setPaidCycleStartDate(paidCycleStartDate);
            VisiblePurchasedOfferExtension enrolledExtnSub = (VisiblePurchasedOfferExtension) poEnrolled.getAttr();
            recEvent.getAtAppliedBundleArray(0).setPurchasedBundleAttr(enrolledExtnSub);
            recEvent.getAtAppliedCatalogItemArray(0).setCatalogItemExternalId(tCase.oldCi);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));
            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            doReturn("[" + request.getSubscriptionExternalId() + "]").when(instance).getLoggingKey(
                    any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi, paidCycleStartDate);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            BigDecimal coreVbpp = tCase.vbppEligible ? BigDecimal.valueOf(5) : BigDecimal.ZERO;
            // doReturn(coreVbpp.negate()).when(instance).getChargeableAmountForPurchaseOffer(
            // any(),
            // argThat(
            // (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
            // CI_EXTERNAL_IDS.VBPP_CORE_REDEEM)),
            // any(), any());
            //
            // BigDecimal coreChime = tCase.chimeEligible ? BigDecimal.valueOf(5) : BigDecimal.ZERO;
            // doReturn(coreChime.negate()).when(instance).getChargeableAmountForPurchaseOffer(
            // any(),
            // argThat(
            // (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
            // CI_EXTERNAL_IDS.CHIME_AOC_REDEEM)),
            // any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                // if (CI_EXTERNAL_IDS.PLUS2VIS22.equalsIgnoreCase(tCase.oldCi)
                // && CI_EXTERNAL_IDS.BASE2VIS22.equalsIgnoreCase(tCase.newCi)) {
                // Since new Ci starts next cycle there will be no prorated charge. TaxApi gets
                // called only once.
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespNextCycle.toJson());
                // } else {
                // mockedStatic.when(
                // () -> TaxApiClient.getTaxApiResult(
                // any(), anyString())).thenReturn(
                // taxRespChangeCycle.toJson()).thenReturn(
                // taxRespNextCycle.toJson());
                // }
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertEquals(
                    ((BigDecimal) eResp.resultMap.get("delta")).intValue(),
                    response.getChangeCycle().getDelta().intValue(),
                    eResp.resultMap.get("deltaDescription").toString());
        };

        // BaseMonthly2PlusMonthly
        TestConditions chg;
        ExpectedResponse eResp;
        VisibleChangeServicePromo csp;
        VisibleRequestChangeServiceAdvice request;
        String subscriptionExternalId = "123";

        request = new VisibleRequestChangeServiceAdvice();
        request.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PRO_CURRENT);
        request.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PRO_CURRENT));
        request.setGrossPrice(request.getDiscountPrice().add(BigDecimal.TEN));
        request.setSubscriptionExternalId(subscriptionExternalId);
        csp = new VisibleChangeServicePromo();
        csp.setGrantOfferCI(CI_EXTERNAL_IDS.PLUS_2535_GRANT);
        csp.setGrantAmount(BigDecimal.valueOf(5000));
        request.getNewPromotionListAppender().add(csp);

        chg = new TestConditions() {

            {
                newCi = CI_EXTERNAL_IDS.PRO_CURRENT;
                oldCi = CI_EXTERNAL_IDS.BASE_CURRENT;
            }
        };
        chg.promoMap.put("BASE2535USED", BigDecimal.valueOf(4));
        eResp = new ExpectedResponse() {

            {
                resultMap.put("delta", BigDecimal.valueOf(14));
                resultMap.put(
                        "deltaDescription",
                        "(Pro-2535PLUS)-(Base-2535BASE)=(45-2535PLUS)-(25-2535BASE)=(45-10)-(25-4) = 14");
            }
        };
        pTests.test(request, chg, eResp);
    }

    @ParameterizedTest(
            name = "getChangeServiceAdvice_When_CoreMonthly2CoreMonthly_With_NewGrant_In_Request_Then_CorrectReeemable")
    @Tags(value = {
        @Tag("VER-209"), @Tag("MTXVER2-252")
    })
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |PaidCycleStartDate is in future. Subscriber has CoreMonthly. Subscriber has old 2535.|"
                +"|When  |ChangeAdvice is called for another CoreMonthly offer. New 2535 is in request.|"
                +"|Then  |ChangeAdvice response should show next cycle.|"
                +"|      |ChangeAdvice response should show 2535Redeemable = 2535Promolimit.|"})
    // @formatter:on
    @SuppressWarnings("unchecked")
    public void getChangeServiceAdvice_When_CoreMonthly2CoreMonthly_With_NewGrant_In_Request_Then_CorrectReeemable(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        TwoParameterTest pTests = (req, tc) -> {
            td.printDescription();
            TestConditions tCase = (TestConditions) tc;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            tCase.oldCi, request.getNewCatalogItemExternalId(),
                            CI_EXTERNAL_IDS.PLUS_2535_GRANT, CI_EXTERNAL_IDS.BASE_2535_GRANT));

            subscription.getPurchasedOfferArrayAppender().clear();
            CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(subscription, tCase.oldCi);

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, tCase.oldCi);
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(tCase.oldCi));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();

            String oldGrantOffer = CI_EXTERNAL_IDS.BASE_CURRENT.equalsIgnoreCase(tCase.oldCi)
                    ? CI_EXTERNAL_IDS.BASE_2535_GRANT : CI_EXTERNAL_IDS.PLUS_2535_GRANT;
            CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, oldGrantOffer, BigDecimal.valueOf(5000), BigDecimal.valueOf(5000),
                    BigDecimal.ZERO);

            MtxResponseWallet wallet = emulateMtxResponseWallet(
                    instance, CommonTestHelper.getMtxResponseWallet(mainbalance));
            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            doReturn("[" + request.getSubscriptionExternalId() + "]").when(instance).getLoggingKey(
                    any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.loadJsonMessage(
                    MtxBalanceImpactInfo.class,
                    DATA_DIR.COMMON + "MtxBalanceImpactInfo_PLUS2VIS22WB_Mainbalance.json");
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());
            BigDecimal fixedfeeChangeCycle = BigDecimal.ZERO;

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    tCase.oldCi,
                    new MtxDate(wallet.getBillingCycle().getCurrentPeriodStartTime().longValue()));

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                taxRespChangeCycle.getTransactionElement().get(0).setTotalFeeAmount(
                        fixedfeeChangeCycle);
                ServiceTaxResponse taxRespNextCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
//                if (CI_EXTERNAL_IDS.PLUS2VIS22.equalsIgnoreCase(tCase.oldCi)
//                        && CI_EXTERNAL_IDS.BASE2VIS22.equalsIgnoreCase(tCase.newCi)) {
                    // Since new Ci starts next cycle there will be no prorated charge. TaxApi gets
                    // called only once.
                    mockedStatic.when(
                            () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                    taxRespNextCycle.toJson());
//                } else {
//                    mockedStatic.when(
//                            () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
//                                    taxRespChangeCycle.toJson()).thenReturn(
//                                            taxRespNextCycle.toJson());
//                }
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            boolean foundNewPromo = false;
            for (VisibleChangeServiceCredit newPromo : response.getNewRedeemableCredits()) {
                if (TAX_CLASS_CODES.PLUS2535.equalsIgnoreCase(newPromo.getClassCode())
                        || TAX_CLASS_CODES.BASE2535.equalsIgnoreCase(newPromo.getClassCode())) {
                    foundNewPromo = true;
                }
            }
            assertTrue(
                    foundNewPromo,
                    "New promo should be present for " + request.getNewCatalogItemExternalId());
        };

        VisibleChangeServicePromo cspDown = new VisibleChangeServicePromo();
        cspDown.setGrantOfferCI(CI_EXTERNAL_IDS.BASE_2535_GRANT);
        cspDown.setGrantAmount(BigDecimal.valueOf(5000));
        VisiblePromoExtension peDown = new VisiblePromoExtension();
        peDown.setPromotionLimit(BigDecimal.valueOf(5));
        cspDown.setAttr(peDown);

        // PlusMonthly2BaseMonthly
        VisibleRequestChangeServiceAdvice requestDown = new VisibleRequestChangeServiceAdvice();
        requestDown.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.BASE_CURRENT);
        requestDown.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.BASE_CURRENT));
        requestDown.setGrossPrice(requestDown.getDiscountPrice().add(BigDecimal.TEN));
        requestDown.setSubscriptionExternalId("123");
        requestDown.getNewPromotionListAppender().add(cspDown);

        TestConditions chgDown = new TestConditions() {

            {
                newCi = requestDown.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.PLUS_CURRENT;
            }
        };

        pTests.test(requestDown, chgDown);

        // BaseMonthly2PlusMonthly
        VisibleChangeServicePromo cspUp = new VisibleChangeServicePromo();
        cspUp.setGrantOfferCI(CI_EXTERNAL_IDS.PLUS_2535_GRANT);
        cspUp.setGrantAmount(BigDecimal.valueOf(5000));
        VisiblePromoExtension peUp = new VisiblePromoExtension();
        peUp.setPromotionLimit(BigDecimal.valueOf(10));
        cspUp.setAttr(peUp);

        // PlusMonthly2BaseMonthly
        VisibleRequestChangeServiceAdvice requestUp = new VisibleRequestChangeServiceAdvice();
        requestUp.setNewCatalogItemExternalId(CI_EXTERNAL_IDS.PLUS_CURRENT);
        requestUp.setDiscountPrice(CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.PLUS_CURRENT));
        requestUp.setGrossPrice(requestUp.getDiscountPrice().add(BigDecimal.TEN));
        requestUp.setSubscriptionExternalId("123");
        requestUp.getNewPromotionListAppender().add(cspUp);

        TestConditions chgUp = new TestConditions() {

            {
                newCi = requestDown.getNewCatalogItemExternalId();
                oldCi = CI_EXTERNAL_IDS.BASE_CURRENT;
            }
        };

        pTests.test(requestUp, chgUp);
    }

    @ParameterizedTest(name = "getChangeServiceAdvice_When_SubHasNoPromo_Then_NewPromoInResponse")
    @Tag("VER-707")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |PaidCycleStartDate is in past. Subscriber has NO grant offer is purchased. Subscriber has valid base offer.|"
                +"|When  |ChangeAdvice is called with new promo and reset parameter is Y or N or null"
                +"|Then  |ChangeAdvice response should show new promo with grant in response.|"})
    // @formatter:on   
    public void getChangeServiceAdvice_When_SubHasNoPromo_Then_NewPromoInResponse(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        BigDecimal grantAmount = BigDecimal.valueOf(375);
        @SuppressWarnings("unchecked")
        TwoParameterTest pTests = (req, oldCi) -> {
            String promoGrant = CI_EXTERNAL_IDS.GENERIC_GRANT;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            emulateMtxResponsePricingCatalogItems(
                    instance,
                    List.of(promoGrant, oldCi.toString(), request.getNewCatalogItemExternalId()));
            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, oldCi.toString());
            MtxDate paidCycleStartDate = ((VisiblePurchasedOfferExtension) poEnrolled.getAttr()).getPaidCycleStartDate();

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCi.toString());
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCi.toString()));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(paidCycleStartDate);

            emulateMtxResponseWallet(instance, CommonTestHelper.getMtxResponseWallet(mainbalance));
            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            doReturn("[" + request.getSubscriptionExternalId() + "]").when(instance).getLoggingKey(
                    any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.loadJsonMessage(
                    MtxResponsePurchase.class, DATA_DIR.COMMON + "MtxResponsePurchase.json");
            MtxBalanceImpactInfo biiMain = CommonTestHelper.getMtxBalanceImpactInfoForSingleItemMainBalance(
                    request.getNewCatalogItemExternalId());
            biiMain.setImpactAmount(aocAmount);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                    0).getBalanceImpactListAppender().add(biiMain);
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleStartTime(
                    TestUtils.getFirstDateTimeOfCurrentMonth());
            deltaAocResp.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).setCycleEndTime(
                    TestUtils.getLastDateTimeOfCurrentMonth());
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    oldCi.toString(), paidCycleStartDate);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            assertNotNull(response.getNewRedeemableCredits());
            assertEquals(
                    grantAmount.intValue(),
                    response.getAtNewRedeemableCredits(0).getGrantAmount().intValue());
        };
        String subscriptionExternalId = "123";
        VisibleRequestChangeServiceAdvice request1 = CommonTestHelper.getVisibleRequestChangeServiceAdvice(
                subscriptionExternalId, CI_EXTERNAL_IDS.PLUS3VIS23WB);
        CommonTestHelper.addNewGrantToVisibleRequestChangeServiceAdvice(
                request1, CI_EXTERNAL_IDS.GENERIC_GRANT, "WELCOMEDISCOUNT", null, grantAmount,
                BigDecimal.valueOf(15));
        pTests.test(request1, CI_EXTERNAL_IDS.BASE3VIS23);

        VisibleRequestChangeServiceAdvice request2 = CommonTestHelper.getVisibleRequestChangeServiceAdvice(
                subscriptionExternalId, CI_EXTERNAL_IDS.PLUS3VIS23WB);
        CommonTestHelper.addNewGrantToVisibleRequestChangeServiceAdvice(
                request2, CI_EXTERNAL_IDS.GENERIC_GRANT, "WELCOMEDISCOUNT", "Y", grantAmount,
                BigDecimal.valueOf(15));
        pTests.test(request2, CI_EXTERNAL_IDS.BASE3VIS23);

        VisibleRequestChangeServiceAdvice request3 = CommonTestHelper.getVisibleRequestChangeServiceAdvice(
                subscriptionExternalId, CI_EXTERNAL_IDS.PLUS3VIS23WB);
        CommonTestHelper.addNewGrantToVisibleRequestChangeServiceAdvice(
                request3, CI_EXTERNAL_IDS.GENERIC_GRANT, "WELCOMEDISCOUNT", "N", grantAmount,
                BigDecimal.valueOf(15));
        pTests.test(request3, CI_EXTERNAL_IDS.BASE3VIS23);

    }

    @ParameterizedTest(
            name = "getChangeServiceAdvice_When_NoPromoReset_But_ExistingPromo_Then_NewPromoHasNoGrant")
    @Tag("VER-707")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |PaidCycleStartDate is in past. Subscriber has grant offer is purchased. Subscriber has valid base offer.|"
                +"|When  |ChangeAdvice is called with new promo and reset parameter as N.|"
                +"|Then  |ChangeAdvice response should show new promo with NO grant in response.|"})
    // @formatter:on   
    public void getChangeServiceAdvice_When_NoPromoReset_But_ExistingPromo_Then_NewPromoHasNoGrant(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        @SuppressWarnings("unchecked")
        TwoParameterTest pTests = (req, oldCi) -> {
            String promoGrant = CI_EXTERNAL_IDS.GENERIC_GRANT;
            VisibleRequestChangeServiceAdvice request = (VisibleRequestChangeServiceAdvice) req;
            VisibleResponseChangeServiceAdvice response = new VisibleResponseChangeServiceAdvice();

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
            BigDecimal mainbalance = BigDecimal.ZERO;
            MtxResponseSubscription subscription = emulateMtxResponseSubscription(
                    api, CommonTestHelper.getMtxResponseSubscription());

            emulateMtxResponsePricingCatalogItems(
                    instance,
                    List.of(promoGrant, oldCi.toString(), request.getNewCatalogItemExternalId()));
            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo poEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo_PaidCurrentCycle(
                    subscription, oldCi.toString());
            MtxDate paidCycleStartDate = ((VisiblePurchasedOfferExtension) poEnrolled.getAttr()).getPaidCycleStartDate();
            MtxPurchasedOfferInfo promoEnrolled = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, promoGrant, null, BigDecimal.valueOf(5000), BigDecimal.ONE);
            ((VisiblePurchasedOfferExtension) promoEnrolled.getAttr()).setPromotionLimit(
                    BigDecimal.valueOf(15));

            SubscriptionResponse subscriptionResponse = emulateSubscriptionResponse(
                    instance,
                    CommonTestHelper.getEmptySubscriptionResponse(subscription.getExternalId()));
            PurchasedOfferInfo poiEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, oldCi.toString());
            VisiblePurchasedOfferExtension enrolledPoiExtn = (VisiblePurchasedOfferExtension) poiEnrolled.getAttr();
            enrolledPoiExtn.setChargeAmount(CommonTestHelper.getOfferPrice(oldCi.toString()));
            enrolledPoiExtn.getCreditTaxDetailsArrayAppender().clear();
            enrolledPoiExtn.setPaidCycleStartDate(paidCycleStartDate);

            // emulateMtxResponseWallet(instance,
            // CommonTestHelper.getMtxResponseWallet(mainbalance));
            emulateMtxResponseMultiFromObject(
                    instance,
                    CommonTestHelper.getMtxResponseMulti_For_CreditBalances(subscription));

            doReturn("[" + request.getSubscriptionExternalId() + "]").when(instance).getLoggingKey(
                    any());
            BigDecimal aocAmount = BigDecimal.valueOf(4);
            Map<String, BigDecimal> balImpactMap = new HashMap<String, BigDecimal>();
            balImpactMap.put(BALANCE_NAMES.GLOBAL_PASS, BigDecimal.ONE);
            MtxResponsePurchase deltaAocResp = CommonTestHelper.getMtxResponsePurchaseMultiBalance(
                    request.getNewCatalogItemExternalId(), aocAmount, null, balImpactMap, false);
            doReturn(deltaAocResp).when(instance).getAocResponsePurchase(
                    any(),
                    argThat(
                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                    request.getNewCatalogItemExternalId())),
                    any(), any());

            emulateMtxResponseOneTimeOffer(instance, (MtxPurchasedOfferInfo) null);
            String taxRespString = CommonTestHelper.getTaxApiResp(
                    request.getNewCatalogItemExternalId());

            VisibleOfferDetails vodOldCi = CommonTestHelper.getVisibleOfferDetails(
                    oldCi.toString(), paidCycleStartDate);

            AdviceDataStage aopStage = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, false);
            aopStage.appendVisibleOfferDetailsMap(
                    vodOldCi.getCatalogItemExternalId(), Long.valueOf(vodOldCi.getResourceId()),
                    vodOldCi);
            aopStage.setRecurringChargeInfo(
                    CommonTestHelper.getMtxResponseRecurringChargeInfo(subscriptionResponse));
            doReturn(aopStage).when(instance).getAOPStage(any(), any(), any(), any(), any());

            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                ServiceTaxResponse taxRespChangeCycle = CommonTestHelper.getJsonFromString(
                        ServiceTaxResponse.class, taxRespString);
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                                taxRespChangeCycle.toJson());
                instance.getChangeServiceAdvice(request, response);
            }

            System.out.println(td.getTestMethod() + ":" + response.toJson());
            System.out.println(
                    td.getTestMethod() + ":" + response.getAtNewRedeemableCredits(0).toJson());
            assertNotNull(response.getNewRedeemableCredits());
            assertNull(response.getAtNewRedeemableCredits(0).getGrantAmount());
        };
        String subscriptionExternalId = "123";
        VisibleRequestChangeServiceAdvice request = CommonTestHelper.getVisibleRequestChangeServiceAdvice(
                subscriptionExternalId, CI_EXTERNAL_IDS.PLUS3VIS23WB);
        CommonTestHelper.addNewGrantToVisibleRequestChangeServiceAdvice(
                request, CI_EXTERNAL_IDS.GENERIC_GRANT, "WELCOMEDISCOUNT", "N",
                BigDecimal.valueOf(375), BigDecimal.valueOf(15));
        pTests.test(request, CI_EXTERNAL_IDS.BASE3VIS23);
    }

}
